<?php
/**
 * WellSystem — ATENDIMENTO (WhatsApp, robô, Chatwoot, n8n) configurável por CLIQUE, para qualquer provedor.
 *
 * Cada empresa tem a SUA Evolution, o SEU Typebot, o SEU Chatwoot e o SEU n8n; aqui ficam só os endereços e as escolhas.
 * Padrão de instalação nova: SÓ HUMANO (sem robô). Tudo muda depois, na tela Atendimento, sem terminal.
 *
 * Guarda em cache/atendimento.json:
 *   configurado, pulou, empresa, slug, num (1|2), inst[0..1] = {nome,tipo(comum|api),ativa},
 *   robo (0|1), tb_url, tb_slug, chatwoot (0|1), cw_url, cw_token, cw_conta, n8n (0|1), n8n_url
 * e espelha em cache/whatsapp.json (o que o resto do sistema já lê): url/apikey/instance/instancias_extra/instancia_api/meta_oficial.
 */
if (!defined('WS_CACHE')) require_once __DIR__ . '/config.php';
require_once __DIR__ . '/whatsapp.php';

const WS_AT_ARQ = 'atendimento.json';

function ws_at_cfg(): array {
    $c = json_decode((string)@file_get_contents(WS_CACHE . '/' . WS_AT_ARQ), true);
    $pad = ['configurado' => 0, 'pulou' => 0, 'empresa' => '', 'slug' => '', 'num' => 1,
        'inst' => [['nome' => '', 'tipo' => 'comum', 'ativa' => 1], ['nome' => '', 'tipo' => 'api', 'ativa' => 0]],
        'robo' => 0, 'tb_url' => '', 'tb_slug' => '', 'chatwoot' => 0, 'cw_url' => '', 'cw_token' => '', 'cw_conta' => '1', 'n8n' => 0, 'n8n_url' => ''];
    return is_array($c) ? array_merge($pad, $c) : $pad;
}
function ws_at_salvar(array $novo): void {
    $c = array_merge(ws_at_cfg(), $novo);
    @file_put_contents(WS_CACHE . '/' . WS_AT_ARQ, json_encode($c, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    @chmod(WS_CACHE . '/' . WS_AT_ARQ, 0640);
}
/** "Acme Telecom Ltda" → "Acme-Telecom-Ltda" (só letras, números e hífen; sem acento) — vira o nome das instâncias. */
function ws_at_slug(string $empresa): string {
    $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $empresa); if ($s === false) $s = $empresa;
    $s = preg_replace('/[^A-Za-z0-9]+/', '-', trim((string)$s)); $s = trim((string)$s, '-');
    return mb_substr($s !== '' ? $s : 'Empresa', 0, 30);
}
/** Precisa do assistente de primeira entrada? Instalação nova: sem Evolution e sem escolha já feita. */
function ws_at_precisa_assistente(): bool {
    if (is_file(WS_CACHE . '/' . WS_AT_ARQ)) return false;
    $wa = ws_wa_config();
    return trim((string)($wa['instance'] ?? '')) === '';   // instalação nova: ainda sem número escolhido (a ponte embutida só preenche url/chave)
}

/** Chamada à Evolution (qualquer método). [código, array|null, bruto]. $inst usa o token próprio da instância, se houver. */
function ws_at_evo(string $metodo, string $caminho, ?array $corpo = null, string $inst = ''): array {
    $c = ws_wa_config(); $base = rtrim((string)($c['url'] ?? ''), '/');
    if ($base === '' || trim((string)($c['apikey'] ?? '')) === '') return [0, null, 'Evolution não configurada'];
    $chave = $inst !== '' ? ws_wa_chave($c, $inst) : (string)$c['apikey'];
    $ch = curl_init($base . $caminho);
    $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 8,
          CURLOPT_HTTPHEADER => ['apikey: ' . $chave, 'Content-Type: application/json']];
    if ($corpo !== null) $o[CURLOPT_POSTFIELDS] = json_encode($corpo, JSON_UNESCAPED_UNICODE);
    curl_setopt_array($ch, $o); $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $e = curl_error($ch); curl_close($ch);
    if ($r === false) return [0, null, 'curl: ' . $e];
    return [$s, json_decode((string)$r, true), (string)$r];
}

/** Grava em cache/whatsapp.json o que o resto do sistema lê, a partir das escolhas da tela. Wellnet-like (2 números: comum + API) e simples (1 número) saem das mesmas regras. */
function ws_at_aplicar_whatsapp(string $url, string $apikey): void {
    $a = ws_at_cfg(); $ativas = [];
    foreach ($a['inst'] as $i) if (!empty($i['ativa']) && $i['nome'] !== '') $ativas[] = $i;
    if (!$ativas) return;
    $api = ''; foreach ($ativas as $i) if (($i['tipo'] ?? '') === 'api') { $api = $i['nome']; break; }
    $cfg = ['gateway' => 'evolution', 'instance' => $ativas[0]['nome'],
            'instancias_extra' => implode(',', array_map(fn($i) => $i['nome'], array_slice($ativas, 1))),
            'instancia_api' => $api, 'meta_oficial' => $api !== '' ? 1 : 0];
    if ($url !== '') $cfg['url'] = rtrim($url, '/');
    if ($apikey !== '') $cfg['apikey'] = $apikey;
    ws_wa_salvar($cfg);
    @file_put_contents(WS_CACHE . '/wa_estado.json', '{}');
}

/** Cria a instância na Evolution (comum = QR code; api = API oficial da Meta). Devolve '' se ok, ou o motivo. */
function ws_at_criar_instancia(string $nome, string $tipo, array $meta = []): string {
    [$s0, $j0] = ws_at_evo('GET', '/instance/connectionState/' . rawurlencode($nome));
    if ($s0 >= 200 && $s0 < 300) return '';   // já existe
    $corpo = ['instanceName' => $nome];
    if ($tipo === 'api') {
        $corpo += ['integration' => 'WHATSAPP-BUSINESS', 'token' => trim((string)($meta['token'] ?? '')), 'number' => trim((string)($meta['numero_id'] ?? '')), 'businessId' => trim((string)($meta['waba'] ?? ''))];
        if ($corpo['token'] === '' || $corpo['number'] === '') return 'Faltam o token e o ID do número da Meta.';
    } else {
        $corpo += ['integration' => 'WHATSAPP-BAILEYS', 'qrcode' => true];
    }
    [$s, $j, $raw] = ws_at_evo('POST', '/instance/create', $corpo);
    if ($s >= 200 && $s < 300) {
        $tok = (string)($j['hash']['apikey'] ?? ($j['hash'] ?? ''));
        if (is_string($tok) && $tok !== '') { $c = ws_wa_config(); $ch = (array)($c['chaves_instancias'] ?? []); $ch[$nome] = $tok; ws_wa_salvar(['chaves_instancias' => $ch]); }
        return '';
    }
    return 'A Evolution recusou (HTTP ' . $s . '): ' . mb_substr(is_array($j) ? json_encode($j['response']['message'] ?? $j, JSON_UNESCAPED_UNICODE) : $raw, 0, 200);
}
/** QR code da instância comum: [ok, imagem(data:...), texto]. */
function ws_at_qr(string $nome): array {
    [$s, $j, $raw] = ws_at_evo('GET', '/instance/connect/' . rawurlencode($nome), null, $nome);
    if ($s >= 200 && $s < 300 && is_array($j)) {
        $img = (string)($j['base64'] ?? ($j['qrcode']['base64'] ?? ''));
        if ($img !== '') return [true, $img, ''];
        if (!empty($j['instance']['state']) && $j['instance']['state'] === 'open') return [true, '', 'Já está conectado.'];
        return [false, '', 'O QR ainda não ficou pronto. Tente de novo em instantes.'];
    }
    return [false, '', 'Não consegui o QR (HTTP ' . $s . ').'];
}
/** 'conectado' | 'desconectado' | 'nao_criada' | 'sem_evolution' */
function ws_at_estado_instancia(string $nome): string {
    $c = ws_wa_config();
    if (trim((string)($c['url'] ?? '')) === '' || trim((string)($c['apikey'] ?? '')) === '') return 'sem_evolution';
    [$s, $j] = ws_at_evo('GET', '/instance/connectionState/' . rawurlencode($nome), null, $nome);
    if ($s === 404 || $s === 0) return $s === 0 ? 'sem_evolution' : 'nao_criada';
    $st = strtolower((string)($j['instance']['state'] ?? ($j['state'] ?? '')));
    return $st === 'open' ? 'conectado' : 'desconectado';
}

/** Robô (Typebot) da instância: cria/atualiza na Evolution. $ligar=false só desliga (mantém o resto). '' = ok. */
function ws_at_robo(string $inst, bool $ligar, string $tbUrl = '', string $tbSlug = ''): string {
    [$s, $j] = ws_at_evo('GET', '/typebot/find/' . rawurlencode($inst), null, $inst);
    $atual = (is_array($j) && isset($j[0]) && is_array($j[0])) ? $j[0] : [];
    if (!$ligar) { return $atual ? ws_wa_robo_ligar($inst, false) : ''; }
    $tbUrl = rtrim($tbUrl !== '' ? $tbUrl : (string)($atual['url'] ?? ''), '/'); $tbSlug = $tbSlug !== '' ? $tbSlug : (string)($atual['typebot'] ?? '');
    if ($tbUrl === '' || $tbSlug === '') return 'Informe o endereço e o código (slug) do fluxo do Typebot.';
    $corpo = ['enabled' => true, 'description' => 'WellSystem', 'url' => $tbUrl, 'typebot' => $tbSlug, 'expire' => 30, 'keywordFinish' => '#SAIR',
        'delayMessage' => 500, 'unknownMessage' => 'Mensagem não reconhecida', 'listeningFromMe' => false, 'stopBotFromMe' => true, 'keepOpen' => false, 'debounceTime' => 5,
        'triggerType' => 'keyword', 'triggerOperator' => 'regex', 'triggerValue' => '^(?!.*(Abrir Recibo|Sim enviar)).+$'];
    [$s2, , $raw] = !empty($atual['id']) ? ws_at_evo('PUT', '/typebot/update/' . $atual['id'] . '/' . rawurlencode($inst), $corpo, $inst) : ws_at_evo('POST', '/typebot/create/' . rawurlencode($inst), $corpo, $inst);
    return ($s2 >= 200 && $s2 < 300) ? '' : 'A Evolution recusou o robô (HTTP ' . $s2 . ').';
}
/** Chatwoot da instância: liga/desliga na Evolution. '' = ok. */
function ws_at_chatwoot(string $inst, bool $ligar, string $url = '', string $token = '', string $conta = '1'): string {
    $corpo = $ligar
        ? ['enabled' => true, 'accountId' => $conta, 'token' => $token, 'url' => rtrim($url, '/'), 'signMsg' => false, 'reopenConversation' => true, 'conversationPending' => false,
           'nameInbox' => $inst, 'importContacts' => false, 'importMessages' => false, 'daysLimitImportMessages' => 7, 'autoCreate' => true]
        : ['enabled' => false, 'accountId' => $conta, 'token' => $token ?: 'x', 'url' => $url ?: 'https://x'];
    if ($ligar && ($url === '' || $token === '')) return 'Informe o endereço e o token do Chatwoot.';
    [$s] = ws_at_evo('POST', '/chatwoot/set/' . rawurlencode($inst), $corpo, $inst);
    return ($s >= 200 && $s < 300) ? '' : 'A Evolution recusou o Chatwoot (HTTP ' . $s . ').';
}
/** O robô (Typebot) está ligado nesta instância? null = sem resposta. */
function ws_at_robo_ligado(string $inst): ?bool {
    [$s, $j] = ws_at_evo('GET', '/typebot/find/' . rawurlencode($inst), null, $inst);
    if ($s < 200 || $s >= 300) return null;
    $b = (is_array($j) && isset($j[0]) && is_array($j[0])) ? $j[0] : (is_array($j) && isset($j['enabled']) ? $j : null);
    return $b ? !empty($b['enabled']) : false;
}

/* =====================================================================================================
 * MODELOS DO ROBÔ (Typebot) — os dois fluxos prontos (Atendimento e Fora do horário), sem nada de nenhuma empresa.
 * robo_modelos/*.json trazem marcadores (__WS_API__, __WS_AUTH__, __EMPRESA__, __WS_CENTRAL__, __PIX_*__) que aqui são preenchidos com os dados DESTE
 * provedor. O provedor importa o arquivo no Typebot dele (ou o painel importa e publica sozinho, com o token da API do Typebot) e depois liga o robô.
 * ===================================================================================================== */
/** Endereço público deste sistema, o que o Typebot precisa alcançar (sem barra no fim). */
function ws_robo_base_url(): string {
    $a = ws_at_cfg(); $b = trim((string)($a['base_url'] ?? ''));
    if ($b !== '') return rtrim($b, '/');
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = (string)($_SERVER['HTTP_HOST'] ?? ''); return $host !== '' ? ($https ? 'https://' : 'http://') . $host : '';
}
/** Credencial que o robô usa para falar com o sistema: gerada UMA vez (o hash fica em Mensagens > Servidor; o texto, só aqui). */
function ws_robo_credencial(bool $gerar = true): string {
    $f = WS_CACHE . '/robo_credencial.json'; $j = json_decode((string)@file_get_contents($f), true);
    if (is_array($j) && !empty($j['tok'])) return (string)$j['tok'];
    if (!$gerar) return '';
    require_once __DIR__ . '/api_chatbot.php';
    $tok = base64_encode('robo:' . bin2hex(random_bytes(16)));
    $cb = ws_chatbot_cfg(); $cb['auth_hash'] = ws_chatbot_auth_hash($tok); $cb['ativo'] = 1; ws_chatbot_salvar($cb);
    @file_put_contents($f, json_encode(['tok' => $tok, 'em' => date('c')]), LOCK_EX); @chmod($f, 0640);
    return $tok;
}
/** Chaves PIX e banco do provedor (Cadastro de contas) para os textos do robô. */
function ws_robo_pix_dados(): array {
    $o = ['', '', ''];
    try {
        $rs = ws_db()->query("SELECT * FROM ws_banco WHERE ativo=1 AND TRIM(COALESCE(pix,''))<>'' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rs as $i => $b) { if ($i < 2) $o[$i] = trim((string)$b['pix']); if ($i === 0) $o[2] = trim((string)($b['banco'] ?? ($b['nome'] ?? ''))); }
    } catch (Throwable $e) {}
    return $o;
}
/** JSON do modelo ('atendimento' | 'fora') já com os dados deste provedor. */
function ws_robo_modelo_json(string $qual): string {
    $arq = __DIR__ . '/robo_modelos/' . ($qual === 'fora' ? 'fora_horario.json' : 'atendimento.json');
    $t = (string)@file_get_contents($arq); if ($t === '') return '';
    $emp = function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : 'Provedor'; $base = ws_robo_base_url();
    [$p1, $p2, $bk] = ws_robo_pix_dados();
    $esc = fn(string $v) => substr(json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 1, -1);
    return strtr($t, ['__WS_API__' => $esc($base), '__WS_AUTH__' => $esc(ws_robo_credencial()), '__EMPRESA__' => $esc($emp),
        '__WS_CENTRAL__' => $esc($base . '/central_pub.php'), '__PIX_CHAVE_1__' => $esc($p1 !== '' ? $p1 : '(cadastre a chave PIX em Provedor)'),
        '__PIX_CHAVE_2__' => $esc($p2 !== '' ? $p2 : '(segunda chave PIX, se houver)'), '__PIX_BANCO__' => $esc($bk !== '' ? $bk : 'seu banco')]);
}
/** Importa o modelo no Typebot do provedor pela API (token da API do Typebot) e publica. ['ok','slug','erro']. Sem token, use o arquivo baixado. */
function ws_robo_importar_typebot(string $tbUrl, string $tbToken, string $workspaceId, string $qual): array {
    $json = ws_robo_modelo_json($qual); $t = json_decode($json, true);
    if (!is_array($t)) return ['ok' => false, 'erro' => 'Modelo do robô não encontrado.'];
    $tbUrl = rtrim($tbUrl, '/'); if ($tbUrl === '' || $tbToken === '' || $workspaceId === '') return ['ok' => false, 'erro' => 'Informe o endereço do Typebot, o token da API e o ID do espaço de trabalho.'];
    $http = function (string $m, string $p, ?array $b = null) use ($tbUrl, $tbToken): array {
        $ch = curl_init($tbUrl . $p); $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_TIMEOUT => 60, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $tbToken, 'Content-Type: application/json']];
        if ($b !== null) $o[CURLOPT_POSTFIELDS] = json_encode($b, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); curl_setopt_array($ch, $o);
        $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$s, json_decode((string)$r, true), (string)$r];
    };
    unset($t['id']);
    [$s, $j, $raw] = $http('POST', '/api/v1/typebots', ['workspaceId' => $workspaceId, 'typebot' => $t]);
    $id = (string)($j['typebot']['id'] ?? ($j['id'] ?? ''));
    if ($s < 200 || $s >= 300 || $id === '') return ['ok' => false, 'erro' => 'O Typebot recusou a importação (HTTP ' . $s . '). Use o arquivo baixado e importe pelo próprio Typebot.'];
    [$s2] = $http('POST', '/api/v1/typebots/' . rawurlencode($id) . '/publish', []);
    [$s3, $g] = $http('GET', '/api/v1/typebots/' . rawurlencode($id));
    $slug = (string)($g['typebot']['publicId'] ?? ($j['typebot']['publicId'] ?? ''));
    if ($s2 < 200 || $s2 >= 300) return ['ok' => false, 'slug' => $slug, 'erro' => 'Importou, mas não consegui publicar (HTTP ' . $s2 . '). Publique no Typebot e informe o código do fluxo.'];
    return ['ok' => $slug !== '', 'slug' => $slug, 'erro' => $slug === '' ? 'Publicou, mas não achei o código do fluxo. Copie-o do Typebot.' : ''];
}
