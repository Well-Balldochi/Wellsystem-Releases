<?php
/**
 * WellSystem — rotina da ATUALIZAÇÃO (cron, a cada minuto, como ROOT). Só linha de comando. Regras em atualizar_lib.php.
 *   · pedido da tela (cache/atualizar_pedido.json): "Atualizar agora" ou "Voltar à versão anterior";
 *   · automática: só se estiver LIGADA, na hora marcada (1x por dia) e se houver versão mais nova.
 * Quem aplica é ws-atualizar-aplicar.sh (copia de segurança + ATUALIZAR.sh + conferência + volta sozinho se falhar).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php';
require_once __DIR__ . '/atualizar_lib.php';
if (function_exists('posix_geteuid') && posix_geteuid() !== 0) exit(0);   // só root aplica atualização
$trava = fopen(WS_CACHE . '/atualizar.lock', 'c'); if (!$trava || !flock($trava, LOCK_EX | LOCK_NB)) exit(0);

$pedidoArq = WS_CACHE . '/atualizar_pedido.json';
$pedido = is_file($pedidoArq) ? (json_decode((string)@file_get_contents($pedidoArq), true) ?: []) : [];
$c = ws_atu_cfg(); $acao = '';
if (!empty($pedido['acao']) && in_array($pedido['acao'], ['atualizar', 'voltar', 'linux', 'tudo'], true)) { $acao = $pedido['acao']; @unlink($pedidoArq); }
elseif (!empty($c['auto']) && date('H:i') === (string)$c['hora'] && date('Y-m-d') !== (string)($c['ultimo_auto'] ?? '')) { $acao = 'auto'; ws_atu_salvar(['ultimo_auto' => date('Y-m-d')]); }
if ($acao === '') exit(0);
if ($acao === 'atualizar' || $acao === 'auto') ws_atu_estado('Verificando a versão do WellSystem…', 10);

$aplicar = __DIR__ . '/ws-atualizar-aplicar.sh';
if ($acao === 'linux' || $acao === 'tudo') {   // Linux e pacotes do sistema (apt), sem perguntas
    ws_atu_log('atualizando o Linux e os pacotes (apt)…');
    ws_atu_estado('Atualizando a lista de pacotes do Linux…', 10);
    $out = []; exec('DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>&1', $out, $rc);
    if ($rc === 0) { ws_atu_estado('Atualizando o Linux e os pacotes (pode levar vários minutos)…', 25); $out = []; exec('DEBIAN_FRONTEND=noninteractive apt-get -y -qq -o Dpkg::Options::=--force-confold upgrade 2>&1', $out, $rc); }
    ws_atu_log($rc === 0 ? 'Linux e pacotes atualizados.' : 'FALHA ao atualizar o Linux: ' . mb_substr(implode(' ', array_slice($out, -2)), 0, 200));
    if ($acao === 'linux') { ws_atu_estado($rc === 0 ? 'Linux e pacotes atualizados.' : 'Falhou ao atualizar o Linux — veja o histórico.', 100, false); exit($rc); }
    ws_atu_estado('Linux atualizado. Verificando a versão do WellSystem…', 55);
    $acao = 'atualizar';
}
if ($acao === 'voltar') {
    ws_atu_log('voltando à versão anterior (pedido pela tela)…');
    ws_atu_estado('Voltando à versão anterior…', 40); $out = []; exec('bash ' . escapeshellarg($aplicar) . ' --voltar 2>&1', $out, $rc); ws_atu_estado($rc === 0 ? 'Versão anterior restaurada.' : 'Falhou ao voltar a versão.', 100, false);
    ws_atu_log($rc === 0 ? 'versão anterior restaurada: ' . ws_atu_versao() : 'FALHA ao voltar: ' . mb_substr(implode(' ', array_slice($out, -2)), 0, 200));
    exit($rc);
}
$u = ws_atu_ultima();
if (!$u['ok']) { ws_atu_log('verificação: ' . $u['msg']); ws_atu_estado('Não foi possível verificar: ' . $u['msg'], 100, false); exit(0); }
if (!ws_atu_mais_nova($u['versao'], ws_atu_versao())) { if ($acao === 'atualizar') ws_atu_log('já está na versão mais nova (' . ws_atu_versao() . ').'); ws_atu_estado('Já está na versão mais nova (' . ws_atu_versao() . ').', 100, false); exit(0); }
ws_atu_log("baixando a versão {$u['versao']} (instalada: " . ws_atu_versao() . ')…');
ws_atu_estado("Baixando a versão {$u['versao']}…", 65);
[$tar, $erro] = ws_atu_baixar($u, sys_get_temp_dir() . '/wellsystem-atu-' . getmypid());
if ($tar === '') { ws_atu_log('NÃO atualizado: ' . $erro); ws_atu_estado('Não atualizado: ' . $erro, 100, false); exit(1); }
ws_atu_estado('Aplicando a atualização (cópia de segurança, instalação e conferência)…', 80);
$out = []; exec('bash ' . escapeshellarg($aplicar) . ' ' . escapeshellarg($tar) . ' ' . escapeshellarg($u['versao']) . ' 2>&1', $out, $rc);
@unlink($tar); @rmdir(dirname($tar));
ws_atu_estado($rc === 0 ? "Atualizado para a versão {$u['versao']}." : 'Falhou e voltou à versão anterior — veja o histórico.', 100, false);
ws_atu_log($rc === 0 ? "atualizado para a versão {$u['versao']}." : "FALHOU e voltou à versão anterior: " . mb_substr(implode(' ', array_slice($out, -3)), 0, 240));
exit($rc);
