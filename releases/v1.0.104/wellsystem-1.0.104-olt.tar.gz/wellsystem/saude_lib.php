<?php
/**
 * WellSystem — SAÚDE DO SISTEMA (01/10/2026).
 * Confere, a cada minuto (saude_run.php no cron), tudo de que o provedor depende e AVISA A EQUIPE NO WHATSAPP quando
 * algo cai e quando volta (mesmos números de Suporte → Notificações de chamado):
 *   banco de dados · concentradores (porta de gerência) · servidores monitorados · RADIUS (processo + contabilização)
 *   · OLT (monitor atualizando + PONs em queda) · WhatsApp (instância conectada) · rotinas (sincronização RADIUS,
 *   backup, Lytex, BB PIX) · disco · licença.
 * Anti-alarme-falso: só avisa depois de 3 falhas seguidas (≈3 min) e avisa a volta uma vez. Item marcado como
 * "não monitorar" na tela (ex.: concentrador de reserva desligado de propósito) não gera aviso.
 * Nada aqui altera o sistema: só lê e testa conexão.
 */

const WS_SAUDE_ESTADO = 'saude_estado.json';
const WS_SAUDE_FALHAS_AVISO = 3;

function ws_saude_cfg(): array {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/saude_cfg.json'), true);
    return (is_array($j) ? $j : []) + ['silenciar' => [], 'avisar' => 1];
}
function ws_saude_cfg_salvar(array $c): void {
    @file_put_contents(WS_CACHE . '/saude_cfg.json', json_encode($c, JSON_UNESCAPED_UNICODE)); @chmod(WS_CACHE . '/saude_cfg.json', 0640);
}

/** Testa uma porta TCP (sem login, sem comando). */
function ws_saude_tcp(string $host, int $porta, float $tempo = 3.0): bool {
    if ($host === '' || $porta <= 0) return false;
    $fp = @fsockopen($host, $porta, $en, $es, $tempo);
    if (!$fp) return false;
    fclose($fp);
    return true;
}

/** Idade em minutos de um arquivo (null = não existe). */
function ws_saude_idade(string $arq): ?int { return is_file($arq) ? (int)floor((time() - filemtime($arq)) / 60) : null; }

/** Executa todas as verificações. Cada item: [id, grupo, nome, ok(bool|null=não se aplica), detalhe]. */
function ws_saude_checar(): array {
    $itens = [];
    $add = function (string $id, string $grupo, string $nome, ?bool $ok, string $det) use (&$itens) { $itens[$id] = compact('id', 'grupo', 'nome', 'ok', 'det'); };
    $db = null;
    try { $db = ws_db(); $db->query('SELECT 1'); $add('db', 'Sistema', 'Banco de dados', true, 'respondendo'); }
    catch (Throwable $e) { $add('db', 'Sistema', 'Banco de dados', false, 'sem conexão: ' . mb_substr($e->getMessage(), 0, 80)); }

    if (!function_exists('ws_wa_chave') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
    // WhatsApp (Evolution): TODAS as instâncias (principal + extras), no topo — é o que mais se usa no dia a dia
    $wa = json_decode((string)@file_get_contents(WS_CACHE . '/whatsapp.json'), true) ?: [];
    if (!empty($wa['url']) && !empty($wa['apikey'])) {
        $insts = array_values(array_unique(array_filter(array_map('trim', array_merge([(string)($wa['instance'] ?? '')], preg_split('/[,;\s]+/', (string)($wa['instancias_extra'] ?? '')) ?: [])))));
        foreach ($insts as $k => $inst) {
            $ch = curl_init(rtrim((string)$wa['url'], '/') . '/instance/connectionState/' . rawurlencode($inst));
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($wa, (string)$inst)]]);
            $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            $st = strtolower((string)(json_decode((string)$r, true)['instance']['state'] ?? ''));
            $add($k ? 'whatsapp_' . preg_replace('/\W/', '', $inst) : 'whatsapp', 'Sistema', 'WhatsApp (' . $inst . ')', $c === 200 && in_array($st, ['open', 'connected'], true), $c === 200 ? ($st === 'open' ? 'conectado' : ($st ?: 'sem estado')) : 'Evolution sem resposta (HTTP ' . $c . ')');
        }
    }

    /* RECEBIMENTO (06/11/2026): "conectada" não prova que o WhatsApp comum está RECEBENDO. Em 06/11 a Wellnet-01 ficou 4 h "open" sem entrar uma mensagem de cliente (sessão vinculada zumbi) e ninguém foi avisado.
       Aqui: instância do WhatsApp comum conectada + nenhuma mensagem de CLIENTE (individual, não grupo) há mais de 150 min em horário comercial (seg–sáb, 8h–19h) = alerta, com o caminho da correção
       (reiniciar o celular do número e reconectar em Manutenção → QR ao vivo). Consulta a Evolution no máximo a cada 5 min; fora do horário comercial não alerta. */
    try {
        $apiI = trim((string)($wa['instancia_api'] ?? ''));
        if (!empty($wa['url']) && !empty($wa['apikey'])) foreach ($insts as $kR => $iR) {
            if ($iR === $apiI) continue;
            $idCon = $kR ? 'whatsapp_' . preg_replace('/\W/', '', $iR) : 'whatsapp';
            if (empty($itens[$idCon]['ok'])) continue;   // desconectada: o item acima já cuida
            /* (08/11/2026) status/stories ACEITOS no WhatsApp comum (readStatus=true): recusar status trava a entrega e a instância fica "conectada" sem receber (ws_wa_status_aceitar). Confere no máx. 1x/30 min. */
            $arqSt = WS_CACHE . '/saude_status_' . preg_replace('/\W/', '', $iR) . '.txt';
            if (function_exists('ws_wa_status_aceitar') && (!is_file($arqSt) || time() - (int)@filemtime($arqSt) >= 1800)) { @file_put_contents($arqSt, ws_wa_status_aceitar((string)$iR)); @chmod($arqSt, 0640); }
            $arqR =WS_CACHE . '/saude_recebe_' . preg_replace('/\W/', '', $iR) . '.json'; $cR = json_decode((string)@file_get_contents($arqR), true) ?: [];
            if (time() - (int)($cR['em'] ?? 0) >= 300) {
                $chR = curl_init(rtrim((string)$wa['url'], '/') . '/chat/findMessages/' . rawurlencode($iR));
                curl_setopt_array($chR, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($wa, (string)$iR), 'Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode(['where' => new stdClass(), 'page' => 1, 'offset' => 80])]);
                $jR = json_decode((string)curl_exec($chR), true); curl_close($chR); $ultR = 0;
                foreach ((array)($jR['messages']['records'] ?? []) as $mR) {
                    if (!is_array($mR) || !empty($mR['key']['fromMe'])) continue;
                    $jid = (string)($mR['key']['remoteJid'] ?? ''); if (substr($jid, -5) === '@g.us' || strpos($jid, 'broadcast') !== false) continue;
                    $ultR = max($ultR, (int)($mR['messageTimestamp'] ?? 0));
                }
                if (is_array($jR) && isset($jR['messages'])) { $cR = ['em' => time(), 'ultima' => $ultR ?: (int)($cR['ultima'] ?? 0)]; @file_put_contents($arqR, json_encode($cR)); @chmod($arqR, 0640); }
            }
            $ultR = (int)($cR['ultima'] ?? 0); if ($ultR <= 0) continue;
            $minR = (int)floor((time() - $ultR) / 60); $horaCom = ((int)date('G') >= 8 && (int)date('G') < 19 && (int)date('N') <= 6);
            $okR = !($horaCom && $minR > 150);
            $add($idCon . '_recebe', 'Sistema', 'WhatsApp recebendo (' . $iR . ')', $okR,
                 $okR ? 'última mensagem de cliente há ' . ($minR >= 90 ? round($minR / 60, 1) . ' h' : $minR . ' min')
                      : 'conectada, mas SEM receber mensagem de cliente há ' . round($minR / 60, 1) . ' h — reinicie o celular do número e reconecte em Manutenção → "Reconectar WhatsApp (QR ao vivo)"');
        }
    } catch (Throwable $e) {}

    // ATENDIMENTO (14/10/2026): caixa de conversas e robô — se caírem, o cliente fica sem resposta. Só testa se responde (HTTP < 500); nada de login.
    $resp = function (string $u, array $h = []): int { $ch = curl_init($u); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_NOBODY => false, CURLOPT_HTTPHEADER => $h]); curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return $c; };
    try {
        if (!function_exists('ws_cw_cfg') && is_file(__DIR__ . '/aviso_provedor_lib.php')) require_once __DIR__ . '/aviso_provedor_lib.php';
        $cwc = function_exists('ws_cw_cfg') ? array_values(ws_cw_cfg()) : [];
        if ($cwc && !empty($cwc[0]['url'])) { $cc = $resp(rtrim((string)$cwc[0]['url'], '/') . '/api/v1/profile', ['api_access_token: ' . (string)($cwc[0]['token'] ?? '')]); $add('chatwoot', 'Sistema', 'Caixa de atendimento', $cc > 0 && $cc < 500, $cc > 0 && $cc < 500 ? 'respondendo' : 'SEM RESPOSTA (HTTP ' . $cc . ')'); }
    } catch (Throwable $e) {}
    try {
        if (!empty($wa['url']) && !empty($wa['apikey'])) {
            $inC = trim((string)($wa['instance'] ?? '')); $tb = '';
            foreach (array_filter(array_merge([$inC], preg_split('/[,;\s]+/', (string)($wa['instancias_extra'] ?? '')) ?: [])) as $iT) {
                $ch = curl_init(rtrim((string)$wa['url'], '/') . '/typebot/find/' . rawurlencode($iT)); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($wa, $iT)]]);
                $rT = json_decode((string)curl_exec($ch), true); curl_close($ch); $bT = isset($rT[0]) ? $rT[0] : (is_array($rT) && isset($rT['url']) ? $rT : null);
                if ($bT && !empty($bT['url']) && !empty($bT['enabled'])) { $tb = rtrim((string)$bT['url'], '/'); break; }
            }
            if ($tb !== '') { $ct = $resp($tb); $add('typebot', 'Sistema', 'Robô de atendimento', $ct > 0 && $ct < 500, $ct > 0 && $ct < 500 ? 'respondendo' : 'SEM RESPOSTA (HTTP ' . $ct . ')'); }
        }
    } catch (Throwable $e) {}

    /* EMISSÃO NO GATEWAY (15/10/2026): título que vence nos próximos 7 dias e ainda não foi emitido no CelCash/Lytex (conta com Emissão = gateway/lytex) = o cliente não recebe boleto/código de barras. Com a emissão automática
       (emitir_pendentes_run.php) isso deve ficar em zero; acima disso, algo travou (limite do gateway, credencial, cron parado). */
    if ($db) {
        try {
            $qe = $db->query("SELECT COUNT(*) FROM ws_fatura f JOIN ws_contrato ct ON ct.id=f.contrato_id JOIN ws_cliente c ON c.id=f.cliente_id JOIN ws_banco b ON b.id=COALESCE(NULLIF(f.banco_id,0), ct.banco_id)
                               WHERE f.status='aberto' AND COALESCE(f.celcash_charge_id,'')='' AND COALESCE(f.lytex_id,'')='' AND COALESCE(f.linha_digitavel,'')='' AND b.emissao IN ('gateway','lytex')
                                 AND c.status NOT IN ('cancelado','inativo') AND ct.status <> 'cancelado' AND f.vencimento >= CURDATE() AND f.vencimento <= CURDATE() + INTERVAL 7 DAY");
            $ne = (int)$qe->fetchColumn(); $add('emissao', 'Sistema', 'Emissão de boletos no gateway', $ne === 0, $ne === 0 ? 'em dia (nada vencendo em 7 dias sem emissão)' : $ne . ' boleto(s) vencendo em até 7 dias ainda SEM emissão no gateway');
        } catch (Throwable $e) {}
    }

    // Licença
    if (function_exists('ws_ativado')) $add('licenca', 'Sistema', 'Licença', ws_ativado(), ws_ativado() ? 'ativada neste servidor' : 'NÃO ativada');

    // Disco da pasta do sistema
    $tot = @disk_total_space(WS_DIR); $liv = @disk_free_space(WS_DIR);
    if ($tot) { $pct = round($liv / $tot * 100); $add('disco', 'Sistema', 'Espaço em disco', $pct >= 10, $pct . '% livre (' . round($liv / 1073741824, 1) . ' GB)'); }

    // Concentradores: só abre a porta de gerência (accel-ppp 2000 / MikroTik API) — não faz login.
    if ($db) {
        try {
            foreach ($db->query("SELECT id, nome, tipo, host, porta, usuario, senha FROM ws_concentrador WHERE ativo=1 AND host<>''")->fetchAll(PDO::FETCH_ASSOC) as $c) {
                $p = (int)$c['porta'] ?: ($c['tipo'] === 'mikrotik' ? 8728 : 2000);
                $ok = ws_saude_tcp((string)$c['host'], $p) || ws_saude_tcp((string)$c['host'], $p, 4.0);
                // (03/10/2026) junto do "respondendo": CPU, memória e sessões LIDAS AGORA no concentrador (ws_saude_conc_medir)
                $qz = $ok ? ws_saude_conc_medir($c, $p) : '';
                $add('conc' . $c['id'], 'Rede', 'Concentrador ' . $c['nome'], $ok, $c['host'] . ':' . $p . ($ok ? ' respondendo' . $qz : ' SEM RESPOSTA'));
            }
        } catch (Throwable $e) {}
    }
    // Servidores Linux monitorados na tela de Tráfego (porta SSH)
    $lx = json_decode((string)@file_get_contents(WS_CACHE . '/trafego_srv_linux.json'), true);
    foreach ((array)$lx as $s) {
        if (($s['modo'] ?? '') !== 'ssh' || empty($s['host'])) continue;
        $ok = ws_saude_tcp((string)$s['host'], (int)($s['porta'] ?? 22) ?: 22);
        $add('srv' . preg_replace('/\W/', '', (string)$s['id']), 'Rede', 'Servidor ' . ($s['nome'] ?? $s['host']), $ok, $s['host'] . ($ok ? ' respondendo' : ' SEM RESPOSTA'));
    }

    // RADIUS: processo (quando instalado aqui) + contabilização chegando (interim dos concentradores)
    $temFr = is_file('/usr/sbin/freeradius') || is_file('/usr/sbin/radiusd');
    if ($temFr && function_exists('exec')) {
        $o = []; @exec('pgrep -x freeradius || pgrep -x radiusd', $o, $rc);
        $add('radius', 'Rede', 'Servidor RADIUS', $rc === 0, $rc === 0 ? 'em execução' : 'PARADO — ninguém autentica');
    }
    if ($db) {
        foreach (['radius', 'mkradius'] as $rdb) {
            try {
                $m = $db->query("SELECT MAX(acctupdatetime) FROM $rdb.radacct WHERE acctstoptime IS NULL")->fetchColumn();
                if ($m === false) continue;
                $min = $m ? (int)floor((time() - strtotime((string)$m)) / 60) : null;
                $add('acct', 'Rede', 'Contabilização RADIUS', $min !== null && $min <= 15, $min === null ? 'nenhuma sessão aberta' : "última atualização há $min min");
                break;
            } catch (Throwable $e) {}
        }
        /* CGNAT (11/11/2026): a consulta de ofício só responde certo se TODA conexão estiver sendo registrada. Normal: ~690-730 clientes
           com sessão aberta e atualizada; abaixo de 600 a coleta está falhando (foi o que aconteceu na troca de sistema, 20/09-20/10).
           Alerta da Saúde (gerência) para corrigir na hora, em vez de descobrir quando a polícia pedir. */
        try {
            $nCg = (int)$db->query("SELECT COUNT(DISTINCT username) FROM radacct WHERE acctstoptime IS NULL AND acctupdatetime >= DATE_SUB(NOW(), INTERVAL 20 MINUTE)")->fetchColumn();
            $add('cgnat_cobertura', 'Rede', 'Registro de conexões (CGNAT)', $nCg >= 600, $nCg >= 600 ? "$nCg clientes com sessão registrada agora" : "só $nCg clientes com sessão registrada (normal: mais de 600) — a consulta de ofício fica incompleta");
        } catch (Throwable $e) {}
    }

    // OLT: monitor atualizando a lista de ONUs + PONs em queda total agora
    foreach ([WS_DIR . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'] as $d) {
        if (!is_file($d . '/olt_onus_cache.json')) continue;
        $i = ws_saude_idade($d . '/olt_onus_cache.json');
        $add('olt', 'Rede', 'OLT (monitor)', $i !== null && $i <= 30, $i === null ? 'sem leitura' : "lista atualizada há $i min");
        $q = function_exists('ws_olt_pon_quedas') ? ws_olt_pon_quedas() : (json_decode((string)@file_get_contents($d . '/olt_pon_estado.json'), true) ?: []);
        $add('pon', 'Rede', 'PONs da OLT', !$q, $q ? count($q) . ' PON(s) em QUEDA: ' . implode(', ', array_keys($q)) : 'nenhuma PON em queda');
        break;
    }


    // Rotinas automáticas
    $rot = [
        ['radius_sync', 'Sincronização RADIUS (bloqueio/desbloqueio)', WS_CACHE . '/radius_sync.ts', 10],
        ['backup', 'Backup diário', WS_CACHE . '/backup_ultimo.txt', 26 * 60],
    ];
    if (is_file(WS_CACHE . '/lytex.json')) $rot[] = ['lytex', 'Conferência Lytex', WS_CACHE . '/lytex_sync.ts', 15];
    if (function_exists('ws_bb_pronto') && ws_bb_pronto()) $rot[] = ['bbpix', 'Baixa automática BB PIX', WS_CACHE . '/bb_pix_status.json', 10];
    foreach ($rot as [$id, $nome, $arq, $lim]) {
        $i = ws_saude_idade($arq);
        $add('rot_' . $id, 'Rotinas', $nome, $i !== null && $i <= $lim, $i === null ? 'ainda não rodou' : ($i < 120 ? "rodou há $i min" : 'rodou há ' . round($i / 60, 1) . ' h'));
    }
    // Teste semanal de restauração do backup (backup_teste_run.php)
    $bt = json_decode((string)@file_get_contents(WS_CACHE . '/backup_teste.json'), true);
    if (is_array($bt) && !empty($bt['em'])) { $dias = (int)floor((time() - (int)$bt['em']) / 86400);
        $add('bk_teste', 'Rotinas', 'Teste de restauração do backup', !empty($bt['ok']) && $dias <= 8, (!empty($bt['ok']) ? 'restaurou OK' : 'FALHOU: ' . ($bt['erro'] ?? '')) . " há $dias dia(s)"); }
    return $itens;
}

/** Roda, compara com a última vez e avisa a equipe das mudanças (cron). Devolve o estado gravado. */
/** Medição real do concentrador a cada rodada (03/10/2026). accel-ppp: "show stat" (CPU e memória do serviço accel,
 *  sessões ativas). MikroTik: /system/resource (CPU e memória da MÁQUINA). Devolve " · CPU …" ou '' se não leu. */
function ws_saude_conc_medir(array $c, int $p): string {
    $pz = [];
    try {
        if (($c['tipo'] ?? '') === 'mikrotik') {
            if (!class_exists('RouterosAPI') && is_file(__DIR__ . '/routeros_api.class.php')) require_once __DIR__ . '/routeros_api.class.php';
            if (class_exists('RouterosAPI')) {
                /* 31/10/2026: cada leitura vira 2 linhas no log da RB ("logged in/out ... via api"); CPU/memória do MikroTik só são relidos a cada 5 min — nas rodadas de 1 min entre elas vale a última medida. */
                $mf = WS_CACHE . '/saude_mk_medida.json'; $mm = json_decode((string)@file_get_contents($mf), true); $mm = is_array($mm) ? $mm : [];
                $mk = (string)$c['host'] . ':' . $p;
                if (isset($mm[$mk]) && time() - (int)$mm[$mk]['em'] < 300) return (string)$mm[$mk]['txt'];
                $api = new RouterosAPI();
                if (@$api->connect((string)$c['host'], (string)$c['usuario'], (string)$c['senha'], $p, 3)) {
                    $r = $api->comm('/system/resource/print', ['.proplist' => 'cpu-load,free-memory,total-memory']); $api->disconnect();
                    $r0 = is_array($r) && isset($r[0]) ? $r[0] : [];
                    if (isset($r0['cpu-load'])) $pz[] = 'CPU ' . (int)$r0['cpu-load'] . '%';
                    if (!empty($r0['total-memory'])) $pz[] = 'memória ' . (int)round(100 - (float)$r0['free-memory'] * 100 / (float)$r0['total-memory']) . '%';
                    if ($pz) { $mm[$mk] = ['em' => time(), 'txt' => ' · ' . implode(' · ', $pz)]; @file_put_contents($mf, json_encode($mm), LOCK_EX); }
                }
            }
        } else {
            $s = @fsockopen((string)$c['host'], $p, $en, $es, 3);
            if ($s) {
                stream_set_timeout($s, 3); fputs($s, "show stat\r\nexit\r\n");
                $r = ''; $t0 = microtime(true); while (!feof($s) && microtime(true) - $t0 < 4) { $l = fgets($s, 8192); if ($l === false) break; $r .= $l; } fclose($s);
                if (preg_match('/\bcpu:\s*(\d+)%/', $r, $m)) $pz[] = 'CPU do accel ' . (int)$m[1] . '%';
                if (preg_match('/mem\(rss\/virt\):\s*(\d+)\//', $r, $m)) $pz[] = 'memória do accel ' . round((int)$m[1] / 1024) . ' MB';
                if (preg_match('/active Total:\s*(\d+)/', $r, $m)) $pz[] = (int)$m[1] . ' sessões';
            }
        }
    } catch (Throwable $e) {}
    return $pz ? ' · ' . implode(' · ', $pz) : '';
}

function ws_saude_rodar(bool $avisar = true): array {
    $cfg = ws_saude_cfg();
    $arq = WS_CACHE . '/' . WS_SAUDE_ESTADO;
    $ant = json_decode((string)@file_get_contents($arq), true) ?: [];
    $itens = ws_saude_checar();
    $quedas = []; $voltas = [];
    foreach ($itens as $id => &$it) {
        $p = $ant['itens'][$id] ?? [];
        $it['falhas'] = $it['ok'] === false ? (int)($p['falhas'] ?? 0) + 1 : 0;
        $it['avisado'] = !empty($p['avisado']);
        $it['desde'] = ($it['ok'] === (($p['ok'] ?? null))) ? ($p['desde'] ?? time()) : time();
        $mudo = in_array($id, (array)$cfg['silenciar'], true);
        /* TENTATIVA DE RECONEXÃO (14/10): WhatsApp comum em "close" por 2 verificações seguidas (antes do aviso) → manda um RESTART à Evolution. Queda parcial às vezes volta sozinha; se foi deslogado de vez, só o QR resolve
           (aí o aviso leva o link do painel). Não mexe na instância da API oficial. */
        if ($it['ok'] === false && (int)$it['falhas'] === 2 && strpos((string)$id, 'whatsapp') === 0 && preg_match('/\(([^)]+)\)/', (string)$it['nome'], $mI)) {
            try {
                if (!function_exists('ws_wa_config') && is_file(WS_DIR . '/whatsapp.php')) require_once WS_DIR . '/whatsapp.php';
                $waR = ws_wa_config(); $instR = $mI[1];
                if ($instR !== trim((string)($waR['instancia_api'] ?? '')) && !empty($waR['url'])) {
                    $chR = curl_init(rtrim((string)$waR['url'], '/') . '/instance/restart/' . rawurlencode($instR));
                    curl_setopt_array($chR, [CURLOPT_CUSTOMREQUEST => 'POST', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($waR, $instR)]]);
                    curl_exec($chR); curl_close($chR);
                }
            } catch (Throwable $e) {}
        }
        if ($it['ok'] === false && $it['falhas'] >= WS_SAUDE_FALHAS_AVISO && !$it['avisado']) { $it['avisado'] = true; if (!$mudo) $quedas[] = $it; }
        if ($it['ok'] === true && $it['avisado']) { $it['avisado'] = false; if (!$mudo) $voltas[] = $it; }
    }
    unset($it);
    $estado = ['em' => time(), 'itens' => $itens];
    @file_put_contents($arq, json_encode($estado, JSON_UNESCAPED_UNICODE)); @chmod($arq, 0640);
    if (($quedas || $voltas) && function_exists('ws_evento')) {
        try { $db = ws_db();
            foreach ($quedas as $q) ws_evento($db, null, 'saude', "🔴 {$q['nome']}: {$q['det']}");
            foreach ($voltas as $v) ws_evento($db, null, 'saude', "🟢 {$v['nome']} voltou: {$v['det']}");
        } catch (Throwable $e) {}
    }
    if ($avisar && !empty($cfg['avisar']) && ($quedas || $voltas)) {
        $txt = "🩺 *Saúde do sistema* — " . date('d/m H:i') . "\n"
             . implode('', array_map(fn($q) => "\n🔴 *{$q['nome']}* — {$q['det']}", $quedas))
             . implode('', array_map(fn($v) => "\n🟢 *{$v['nome']}* normalizou — {$v['det']}", $voltas));
        /* link do painel para ler o QR quando é o WhatsApp comum que caiu (14/10) */
        foreach ($quedas as $qW) if (strpos((string)$qW['id'], 'whatsapp') === 0) { try { if (!function_exists('ws_wa_config') && is_file(WS_DIR . '/whatsapp.php')) require_once WS_DIR . '/whatsapp.php'; $uW = rtrim((string)(ws_wa_config()['url'] ?? ''), '/'); if ($uW !== '') { $txt .= "\n\n🔧 Tentei reconectar sozinho. Se não voltar, abra " . $uW . "/manager e leia o QR com o celular."; } } catch (Throwable $e) {} break; }
        $nc = ['numeros' => ws_alertas_numeros()];   // GERÊNCIA (Saúde do sistema → números), não o técnico
        if (!empty($nc['numeros']) && is_file(WS_DIR . '/whatsapp.php')) {
            require_once WS_DIR . '/whatsapp.php';
            foreach (array_slice(array_filter(array_map('trim', preg_split('/[,;\r\n]+/', (string)$nc['numeros']) ?: [])), 0, 10) as $n)
                try { ws_wa_enviar_conversa($n, $txt, ['evento' => 'chamado', 'automatica' => true]); } catch (Throwable $e) {}   /* aviso à equipe = texto: pelo WhatsApp comum (Wellnet-01); se ele estiver fora, cai para a API (o aviso da queda não se perde) (14/10) */
        }
        /* RESERVA POR E-MAIL (14/10): o alerta só por WhatsApp pode não ser entregue (a API oficial aceita o envio mas a Meta nem sempre entrega fora da janela; e se o WhatsApp comum é o que caiu, o aviso depende da API).
           Com SMTP e e-mail do provedor cadastrados, o mesmo aviso vai também por e-mail — um canal que não depende do WhatsApp. */
        try {
            $pv = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: []; $em = trim((string)($pv['email'] ?? ''));
            if ($em !== '' && filter_var($em, FILTER_VALIDATE_EMAIL) && is_file(WS_DIR . '/mailer.php')) { require_once WS_DIR . '/mailer.php'; ws_email_texto($em, '🩺 Saúde do sistema — ' . ($quedas ? 'ALERTA' : 'normalizou'), strip_tags(str_replace('*', '', $txt))); }
        } catch (Throwable $e) {}
    }
    return $estado;
}
