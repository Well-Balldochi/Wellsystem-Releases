<?php
/**
 * WellSystem — LICENÇA ONLINE (18/11/2026, pedido do dono: dificultar cópia/clone/pirataria).
 *
 * REGRA DE OURO: o cliente NUNCA é bloqueado por falha técnica. Internet caída, site do fornecedor fora do ar, DNS mudado,
 * VM do fornecedor queimada, resposta sem assinatura, resposta com erro = o sistema segue funcionando como sempre.
 * A ÚNICA coisa que bloqueia é uma resposta ASSINADA do servidor de licenças dizendo "revogada" (decisão do fornecedor,
 * painel Administração > Licenças do site). Mesmo assim: aviso por 7 dias, depois SOMENTE LEITURA (nada é apagado; o login,
 * a ativação e a consulta continuam funcionando). O fornecedor restaura a chave e na consulta seguinte volta ao normal.
 *
 * Como funciona:
 *  - 1 consulta por dia (ws_lic_tick, chamado pela rotina da saúde, a cada minuto só confere se já passou 24 h; se falhar tenta
 *    de novo em 3 h). Sem internet o sistema continua e consulta quando a conexão voltar, sem "bloqueio ao voltar".
 *  - A consulta leva: a chave de ativação, a "impressão da máquina" (machine-id + MAC + UUID do disco, só como hash), a versão
 *    e o hash dos arquivos da trava. O servidor compara: mesma chave em mais máquinas que o permitido = possível clone (aparece
 *    no painel; quem decide é o fornecedor); arquivo alterado = aparece no painel.
 *  - A resposta vem assinada (Ed25519, chave pública embutida abaixo) e com o "nonce" da consulta (não dá para reaproveitar
 *    resposta antiga nem forjar revogação).
 *  - Lista de endereços de consulta: o servidor devolve a lista atualizada; se o endereço mudar, o cliente aprende sozinho.
 *  - Estado guardado nas mesmas cópias da ativação (cache/, /var/lib/wellsystem, /var/tmp): apagar o arquivo não adianta; a data
 *    da revogação vem do servidor.
 */
if (!defined('WS_LICENCA_STATUS_PUBKEY')) define('WS_LICENCA_STATUS_PUBKEY', '/nmxwnhVQzh4JfTt+EalWnSQ45u99QQMcSww7LvlS8o=');
if (!defined('WS_LIC_URL_PADRAO')) define('WS_LIC_URL_PADRAO', 'https://wellsystem.wellnet.com.br/licenca.php');
if (!defined('WS_LIC_TOLERANCIA_DIAS')) define('WS_LIC_TOLERANCIA_DIAS', 7);
if (!defined('WS_LIC_AVISO_SEM_CONTATO_DIAS')) define('WS_LIC_AVISO_SEM_CONTATO_DIAS', 60);

/** Impressão da máquina: hash de machine-id + MAC + UUID do disco raiz. Devolve ['fp' => hash completo, 'partes' => hashes curtos de cada parte]. */
function ws_lic_impressao(): array {
    static $r = null; if ($r !== null) return $r;
    $mid = function_exists('ws_servidor_id') ? ws_servidor_id() : '';
    $mac = '';
    foreach ((array)@glob('/sys/class/net/*/address') as $f) {
        $n = basename(dirname($f));
        if ($n === 'lo' || preg_match('/^(veth|docker|br-|virbr|tap|tun|wg|ifb|dummy)/', $n)) continue;
        $v = strtolower(trim((string)@file_get_contents($f)));
        if (preg_match('/^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/', $v) && $v !== '00:00:00:00:00:00') { $mac = $v; break; }
    }
    $dev = '';
    foreach ((array)@file('/proc/mounts', FILE_IGNORE_NEW_LINES) as $l) { $c = explode(' ', (string)$l); if (($c[1] ?? '') === '/' && strpos((string)$c[0], '/dev/') === 0) $dev = $c[0]; }
    $uuid = '';
    if ($dev !== '') foreach ((array)@glob('/dev/disk/by-uuid/*') as $u) { if (@realpath($u) !== false && @realpath($u) === @realpath($dev)) { $uuid = basename($u); break; } }
    $h = function ($x) { return $x === '' ? '' : substr(hash('sha256', 'wsfp|' . $x), 0, 12); };
    return $r = ['fp' => hash('sha256', 'wsfp|' . $mid . '|' . $mac . '|' . $uuid), 'partes' => ['m' => $h($mid), 'n' => $h($mac), 'd' => $h($uuid)]];
}
/** Hash dos arquivos da trava (o servidor mostra no painel quem está com arquivo diferente do oficial da mesma versão). */
function ws_lic_hashes(): array {
    $o = [];
    foreach (['config.php', 'ativacao.php', 'licenca_online.php', 'edicoes.php'] as $a) { $f = __DIR__ . '/' . $a; if (is_file($f)) $o[$a] = (string)@hash_file('sha256', $f); }
    return $o;
}
function ws_lic_versao(): string { return trim((string)@file_get_contents(__DIR__ . '/VERSAO')); }

/** Estado da licença online (cópias iguais às da ativação). */
function ws_lic_estado(bool $recarregar = false): array {
    static $e = null; if ($e !== null && !$recarregar) return $e;
    $j = function_exists('ws_ativacao_ler') ? ws_ativacao_ler('licenca_estado') : [];
    return $e = is_array($j) ? $j : [];
}
function ws_lic_estado_gravar(array $novo): void {
    if (function_exists('ws_ativacao_gravar')) { try { ws_ativacao_gravar('licenca_estado', $novo); } catch (Throwable $x) {} }
    ws_lic_estado(true);
}

/** Faz UMA consulta (tenta cada endereço). Devolve ['ok' => bool, 'status' => ..., 'motivo' => ...]. NUNCA muda o status em caso de falha. */
function ws_lic_consultar(): array {
    $at = function_exists('ws_ativacao_ler') ? ws_ativacao_ler('ativacao') : [];
    $lic = is_array($at['licenca'] ?? null) ? $at['licenca'] : [];
    $chave = (string)($at['chave'] ?? '');
    if ($chave === '' && trim((string)($lic['n'] ?? '')) === '') return ['ok' => false, 'motivo' => 'ativação por senha (sem chave assinada): nada a consultar'];
    if (!function_exists('sodium_crypto_sign_verify_detached') || !function_exists('curl_init')) return ['ok' => false, 'motivo' => 'falta sodium/curl'];
    $est = ws_lic_estado(true);
    $imp = ws_lic_impressao(); $nonce = bin2hex(random_bytes(12));
    $corpo = json_encode(['v' => 1, 'chave' => $chave, 'lic' => $lic, 'fp' => $imp['fp'], 'partes' => $imp['partes'], 'nonce' => $nonce, 'versao' => ws_lic_versao(),
        'edicao' => function_exists('ws_edicao') ? ws_edicao() : 'completo', 'host' => function_exists('ws_host_atual') ? ws_host_atual() : '', 'hashes' => ws_lic_hashes()], JSON_UNESCAPED_SLASHES);
    $urls = [];
    foreach ((array)($est['enderecos'] ?? []) as $u) if (is_string($u) && preg_match('~^https://[A-Za-z0-9.-]+(:\d+)?/[A-Za-z0-9._/-]*$~', $u)) $urls[] = $u;
    $urls[] = WS_LIC_URL_PADRAO; $urls = array_values(array_unique($urls));
    $pub = base64_decode((string)WS_LICENCA_STATUS_PUBKEY, true);
    $pl = null; $ultimoErro = 'sem resposta';
    foreach ($urls as $u) {
        $ch = curl_init($u);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $corpo, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4, CURLOPT_USERAGENT => 'WellSystem-Licenca/1']);
        $r = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($r === false || $code !== 200) { $ultimoErro = 'HTTP ' . $code; continue; }
        $j = json_decode((string)$r, true);
        if (!is_array($j) || empty($j['p']) || empty($j['s'])) { $ultimoErro = 'resposta sem assinatura'; continue; }
        $json = base64_decode((string)$j['p'], true); $sig = base64_decode((string)$j['s'], true);
        if ($json === false || $sig === false || $pub === false || strlen($sig) !== 64 || strlen($pub) !== 32) { $ultimoErro = 'resposta inválida'; continue; }
        try { if (!sodium_crypto_sign_verify_detached($sig, $json, $pub)) { $ultimoErro = 'assinatura não confere'; continue; } } catch (Throwable $x) { continue; }
        $p = json_decode($json, true);
        if (!is_array($p) || !hash_equals($nonce, (string)($p['nonce'] ?? ''))) { $ultimoErro = 'nonce diferente'; continue; }
        $pl = $p; break;
    }
    $agora = time();
    if ($pl === null) {   // FALHA: só anota a tentativa; o status NÃO muda
        $est['ultima_tentativa'] = $agora; $est['falhas'] = (int)($est['falhas'] ?? 0) + 1; $est['ultimo_erro'] = $ultimoErro;
        ws_lic_estado_gravar($est);
        return ['ok' => false, 'motivo' => $ultimoErro];
    }
    $est['ultimo_ok'] = $agora; $est['ultima_tentativa'] = $agora; $est['falhas'] = 0; unset($est['ultimo_erro']);
    $est['status'] = (($pl['status'] ?? '') === 'revogada') ? 'revogada' : 'ok';
    $est['msg'] = mb_substr((string)($pl['msg'] ?? ''), 0, 200);
    if ($est['status'] === 'revogada') {
        $desde = (int)($pl['desde'] ?? 0);   // a data vem do servidor: apagar o arquivo de estado não reinicia o prazo
        $est['revogada_desde'] = $desde > 0 ? $desde : ((int)($est['revogada_desde'] ?? 0) ?: $agora);
    } else { unset($est['revogada_desde']); }
    $en = [];
    foreach ((array)($pl['enderecos'] ?? []) as $u) if (is_string($u) && preg_match('~^https://[A-Za-z0-9.-]+(:\d+)?/[A-Za-z0-9._/-]*$~', $u)) $en[] = $u;
    if ($en) $est['enderecos'] = array_slice($en, 0, 6);
    ws_lic_estado_gravar($est);
    return ['ok' => true, 'status' => $est['status']];
}
/** Chamada pela rotina da saúde a cada minuto: consulta no máximo 1x ao dia (e tenta de novo em 3 h se falhou). Nunca lança erro. */
function ws_lic_tick(): void {
    try {
        $e = ws_lic_estado(true); $agora = time();
        if ($agora - (int)($e['ultimo_ok'] ?? 0) < 86400) return;
        if ($agora - (int)($e['ultima_tentativa'] ?? 0) < 10800) return;
        ws_lic_consultar();
    } catch (Throwable $x) {}
}
/** Texto do bloqueio quando o sistema está em SOMENTE LEITURA (revogada há mais de 7 dias); null = livre. */
function ws_lic_bloqueado(): ?string {
    try {
        $e = ws_lic_estado();
        if (($e['status'] ?? '') !== 'revogada') return null;
        $desde = (int)($e['revogada_desde'] ?? 0);
        if ($desde <= 0 || time() - $desde < WS_LIC_TOLERANCIA_DIAS * 86400) return null;
        return (string)($e['msg'] ?? '') !== '' ? (string)$e['msg'] : 'Licença revogada pelo fornecedor. Entre em contato com o suporte WellSystem.';
    } catch (Throwable $x) { return null; }
}
/** Guarda das páginas (POST): em somente leitura, só login, ativação e consulta passam. Chamado no início do config.php. */
function ws_lic_guarda_web(): void {
    if (PHP_SAPI === 'cli' || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;
    $m = ws_lic_bloqueado(); if ($m === null) return;
    $s = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    if (in_array($s, ['ativacao.php', 'login.php', 'sair.php'], true)) return;
    if ($s === 'index.php' && strpos(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '')), '/api/') === false) return;   // login
    http_response_code(403);
    if (stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'json') !== false || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== '') { header('Content-Type: application/json; charset=utf-8'); echo json_encode(['status' => 'erro', 'mensagem' => 'Sistema em somente leitura: ' . $m], JSON_UNESCAPED_UNICODE); exit; }
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui,sans-serif;max-width:560px;margin:12vh auto;padding:0 16px"><h2>Sistema em somente leitura</h2><p>' . htmlspecialchars($m, ENT_QUOTES, 'UTF-8') . '</p><p>Seus dados estão preservados. Fale com o suporte WellSystem para regularizar.</p><p><a href="javascript:history.back()">Voltar</a></p></body>';
    exit;
}
/** Guarda de rotinas (cron/CLI) que geram trabalho novo: true = pode seguir. */
function ws_lic_liberado(): bool { return ws_lic_bloqueado() === null; }
/** Linha de situação para a Saúde/Manutenção: [bool ok, texto]. */
function ws_lic_situacao(): array {
    $e = ws_lic_estado(true); $agora = time();
    if (($e['status'] ?? '') === 'revogada') {
        $desde = (int)($e['revogada_desde'] ?? 0); $rest = max(0, (int)ceil((WS_LIC_TOLERANCIA_DIAS * 86400 - ($agora - $desde)) / 86400));
        return [false, 'LICENÇA REVOGADA' . ((string)($e['msg'] ?? '') !== '' ? ' — ' . $e['msg'] : '') . ($rest > 0 ? ' · somente leitura em ' . $rest . ' dia(s)' : ' · SISTEMA EM SOMENTE LEITURA')];
    }
    $ult = (int)($e['ultimo_ok'] ?? 0);
    if ($ult === 0) return [true, 'consulta online ainda não feita'];
    $d = (int)floor(($agora - $ult) / 86400);
    if ($d >= WS_LIC_AVISO_SEM_CONTATO_DIAS) return [false, 'sem consultar o servidor de licenças há ' . $d . ' dias (confira a internet do servidor; o sistema segue funcionando)'];
    return [true, 'ok · última consulta há ' . ($d > 0 ? $d . ' d' : 'menos de 1 dia')];
}
