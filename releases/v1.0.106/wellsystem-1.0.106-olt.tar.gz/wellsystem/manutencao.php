<?php
/**
 * WellSystem ERP — Manutenção / Emergência (SÓ ROOT).
 * Reúne comandos em massa que ajudam a resolver problemas em produção. Cada ação:
 *  - só aparece/roda para o usuário ROOT (nível de acesso 99);
 *  - exige a SENHA do root para executar (confirmação);
 *  - explica exatamente o que faz antes de executar.
 * NENHUMA ação apaga boletos/faturas nem o banco de dados.
 */
require __DIR__ . '/config.php';
if (function_exists('ws_edicao_manutencao_filtrar') && in_array(ws_edicao(), ['fiscal', 'olt'], true)) ob_start('ws_edicao_manutencao_filtrar');   // edição isolada: só os cards do módulo + servidor
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$db = ws_db();
$h  = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$ehRoot = ws_eh_root();
/* QR AO VIVO do WhatsApp comum (Baileys) — 06/11/2026. Só root. O QR da Evolution muda a cada ~20 s; mandar a imagem por mensagem/e-mail chega vencida. Esta rota devolve o estado e o QR atual para a tela
   se atualizar sozinha. Não grava nada; só consulta a Evolution (e, se a instância estiver desconectada, pede o QR). */
if ($ehRoot && isset($_GET['qr_vivo'])) {
    header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    require_once __DIR__ . '/whatsapp.php';
    $cw = ws_wa_config(); $permit = array_values(array_unique(array_merge(ws_wa_instancias($cw), function_exists('ws_wa_instancias_comum') ? ws_wa_instancias_comum($cw) : [])));
    $in = (string)$_GET['qr_vivo'];
    if (!in_array($in, $permit, true)) { echo json_encode(['erro' => 'instância desconhecida']); exit; }
    $baseW = rtrim((string)$cw['url'], '/'); $kW = ws_wa_chave($cw, $in);
    $chamar = function (string $p) use ($baseW, $kW) { $ch = curl_init($baseW . $p); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_HTTPHEADER => ['apikey: ' . $kW]]); $r = curl_exec($ch); curl_close($ch); return json_decode((string)$r, true); };
    $e = $chamar('/instance/connectionState/' . rawurlencode($in)); $estado = (string)($e['instance']['state'] ?? '?');
    $qr = ''; $cnt = 0;
    if ($estado !== 'open') { $j = $chamar('/instance/connect/' . rawurlencode($in)); $qr = (string)($j['base64'] ?? ''); $cnt = (int)($j['count'] ?? 0); }
    echo json_encode(['estado' => $estado, 'qr' => $qr, 'count' => $cnt, 'em' => date('H:i:s')]); exit;
}
$manutLogin = function_exists('ws_manutencao_login') ? ws_manutencao_login() : ['ativo' => false, 'motivo' => ''];
// DIAGNÓSTICOS (só leitura, só root): ?diag=nas | internet — resultado aparece no card correspondente.
$diagNome = ($ehRoot && in_array($_GET['diag'] ?? '', ['nas', 'internet'], true)) ? (string)$_GET['diag'] : ''; $diagRes = null;
if ($diagNome !== '' && is_file(__DIR__ . '/manutencao_diag.php')) {
    require_once __DIR__ . '/manutencao_diag.php';
    try { $diagRes = $diagNome === 'nas' ? mnt_diag_nas($db) : mnt_diag_internet(); } catch (Throwable $e) { $diagRes = null; }
}

// ÁREA DO FORNECEDOR: o código de desbloqueio (gerado pelo fornecedor para ESTE servidor) destrava licença/demo nesta sessão.
if ($ehRoot && ($_POST['acao'] ?? '') === 'fornecedor_desbloquear') {
    $_SESSION['ws_flash_forn'] = ws_fornecedor_token_ok((string)($_POST['codigo'] ?? '')) ? 'ok' : 'erro';
    header('Location: manutencao.php#fornecedor'); exit;
}
if ($ehRoot && ($_POST['acao'] ?? '') === 'fornecedor_travar') { ws_fornecedor_travar(); header('Location: manutencao.php#fornecedor'); exit; }
// Excluir uma CONTA de teste do demo (esta página já é só-root; não repete a senha pra algo do sandbox).
if ($ehRoot && ws_fornecedor_desbloqueado() && ($_POST['acao'] ?? '') === 'demo_user_excluir' && !empty($_POST['login'])) {
    ws_demo_user_excluir((string)$_POST['login']);
    header('Location: manutencao.php#demousers'); exit;
}

/** Confere a senha do próprio usuário logado (root). */
function mnt_senha_ok(PDO $db): bool {
    $st = $db->prepare("SELECT senha_hash FROM ws_usuario WHERE id=?"); $st->execute([(int)ws_user()['id']]);
    return password_verify($_POST['senha'] ?? '', (string)$st->fetchColumn());
}

$ok = ''; $err = '';
if ($ehRoot && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if (!mnt_senha_ok($db)) {
        $err = 'Senha do root incorreta — nenhuma ação foi executada.';
    } else {
        if (is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
        if (is_file(__DIR__ . '/radius_emergencia.php')) require_once __DIR__ . '/radius_emergencia.php';
        try {
            switch ($acao) {

                /* EMERGÊNCIA DO RADIUS — mesma função da tela da OLT, aqui na Manutenção.
                   Fala DIRETO com o painel de cada concentrador; não depende do Radius estar de pé.
                   Compartilha a configuração dos painéis com a tela da OLT (mesmo arquivo). */
                /* SINCRONIZAR OS DADOS DE REDE DE TODOS OS CONTRATOS.
                   A ficha do cliente se atualiza sozinha a cada 45s — mas só enquanto ALGUÉM a
                   mantém aberta. O cliente que ninguém abre fica com zona, VLAN, placa, PON e
                   sinal do dia da instalação, e é justamente ele que dá trabalho quando aparece
                   um problema. Este botão faz a mesma coisa para a base inteira, com as MESMAS
                   regras (ws_contrato_sincronizar_olt, em radius_lib.php): valor igual não é
                   reescrito, campo vazio é preenchido e o que o operador digitou em campo de
                   cadastro não é desfeito. */
                case 'sinc_rede': {
                    if (!function_exists('ws_contrato_sincronizar_olt')) {
                        $err = 'Função de sincronização indisponível (radius_lib.php não carregou).';
                        break;
                    }
                    $r = ws_contrato_sincronizar_olt($db);
                    $ok = '✅ Sincronização concluída: ' . (int)$r['contratos'] . ' contrato(s) conferido(s) · '
                        . (int)$r['atualizados'] . ' atualizado(s) · ' . (int)$r['campos'] . ' campo(s) preenchido(s)'
                        . ' · ' . (int)$r['olt'] . ' com dado da OLT · ' . (int)$r['conexao'] . ' com conexão ativa.'
                        . ((int)$r['olt'] === 0
                            ? ' Nenhum dado veio da OLT — abra o Gerenciador OLT e deixe a lista de ONUs carregar antes de repetir.'
                            : '');
                    break;
                }

                case 'radpanel_salvar': {
                    $in = json_decode((string)($_POST['paineis'] ?? '[]'), true);
                    if (!is_array($in)) $in = [];
                    $ok = ws_radpanel_save($in)
                        ? '✅ Painéis salvos. A mesma configuração vale na tela da OLT.'
                        : '';
                    if ($ok === '') $err = '❌ Não consegui gravar o arquivo dos painéis (permissão na pasta de cache).';
                    break;
                }
                case 'radpanel_emergencia':
                case 'radpanel_radius': {
                    $modo = ($acao === 'radpanel_emergencia') ? 'emergencia' : 'radius';
                    $r = ws_radpanel_acionar($modo);
                    $linhas = [];
                    foreach ($r['itens'] as $i) {
                        $linhas[] = ($i['ok'] ? '✅' : '❌') . ' ' . $i['nome'] . ' — ' . $i['msg'];
                    }
                    $txt = ($modo === 'emergencia' ? 'QUALQUER LOGIN ativado' : 'Voltou ao RADIUS') . ': ' . $r['msg'];
                    if ($r['ok']) $ok  = '✅ ' . $txt . ' · ' . implode(' · ', $linhas);
                    else          $err = '❌ ' . $txt . ' · ' . implode(' · ', $linhas);
                    ws_evento($db, null, 'emergencia', $txt);
                    break;
                }

                case 'bloquear_todos': {
                    $cts = $db->query("SELECT * FROM ws_contrato WHERE status='ativo'")->fetchAll();
                    $n = 0;
                    foreach ($cts as $ct) {
                        $db->prepare("UPDATE ws_contrato SET status='bloqueado' WHERE id=?")->execute([$ct['id']]);
                        if (function_exists('ws_rad_sync_contrato')) { try { $ct['status'] = 'bloqueado'; ws_rad_sync_contrato($db, $ct, true); } catch (Throwable $e) {} }
                        $n++;
                    }
                    $ok = "$n contrato(s) ATIVOS foram bloqueados (no sistema e no RADIUS).";
                    break;
                }

                case 'desbloquear_todos': {
                    $cts = $db->query("SELECT * FROM ws_contrato WHERE status='bloqueado'")->fetchAll();
                    $n = 0;
                    foreach ($cts as $ct) {
                        $db->prepare("UPDATE ws_contrato SET status='ativo', confianca_ate=NULL WHERE id=?")->execute([$ct['id']]);
                        if (function_exists('ws_rad_sync_contrato')) { try { $ct['status'] = 'ativo'; ws_rad_sync_contrato($db, $ct, false); } catch (Throwable $e) {} }
                        $n++;
                    }
                    $ok = "$n contrato(s) BLOQUEADOS foram liberados (no sistema e no RADIUS).";
                    break;
                }

                case 'apagar_chamados': {
                    try { $db->exec("DELETE FROM ws_chamado_msg"); } catch (Throwable $e) {}
                    $n = $db->exec("DELETE FROM ws_chamado");
                    $ok = "Todos os chamados foram apagados ($n removido(s)). Clientes, contratos e boletos NÃO foram tocados.";
                    break;
                }

                case 'zerar_caixa': {
                    $ini = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['ini'] ?? '') ? $_POST['ini'] : date('Y-m-01');
                    $fim = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['fim'] ?? '') ? $_POST['fim'] : date('Y-m-d');
                    $sel = $db->prepare("SELECT DISTINCT fatura_id FROM ws_pagamento WHERE data_pgto BETWEEN ? AND ?");
                    $sel->execute([$ini, $fim]);
                    $fids = array_values(array_filter(array_map('intval', $sel->fetchAll(PDO::FETCH_COLUMN))));
                    $del = $db->prepare("DELETE FROM ws_pagamento WHERE data_pgto BETWEEN ? AND ?");
                    $del->execute([$ini, $fim]);
                    $nPag = $del->rowCount();
                    $nBol = 0;
                    if ($fids) {
                        $in = implode(',', array_fill(0, count($fids), '?'));
                        // Só reabre a fatura que ficou SEM nenhum pagamento (se sobrou pagamento fora do período, mantém paga).
                        $upd = $db->prepare("UPDATE ws_fatura SET status='aberto', valor_pago=NULL, data_pagamento=NULL, recibo_em=NULL
                                             WHERE id IN ($in) AND (SELECT COUNT(*) FROM ws_pagamento pp WHERE pp.fatura_id=ws_fatura.id)=0");
                        $upd->execute($fids);
                        $nBol = $upd->rowCount();
                    }
                    $ok = "Caixa zerado de $ini a $fim: $nPag recebimento(s) apagados; $nBol boleto(s) voltaram para 'aberto'. NENHUM boleto foi excluído.";
                    break;
                }

                case 'restaurar_seguro': {
                    // Restaurar backup JÁ PAUSANDO o envio de mensagens e recarregando os concentradores (quem executa a restauração é o backup.php).
                    if (is_file(__DIR__ . '/backup_lib.php')) require_once __DIR__ . '/backup_lib.php';
                    $bk = basename((string)($_POST['arquivo'] ?? ''));
                    if ($bk === '' || strtolower(pathinfo($bk, PATHINFO_EXTENSION)) !== 'sql' || !is_file(WS_BACKUP_DIR . '/' . $bk)) { $err = 'Escolha um backup válido da lista.'; break; }
                    header('Location: backup.php?restaurar=' . rawurlencode($bk) . '&confirm=1&pausar=1'); exit;
                }

                case 'zerar_fila_avisos': {
                    @file_put_contents(WS_CACHE . '/msg_eventos_fila.json', '[]'); @unlink(WS_CACHE . '/msg_estado_bloqueio.json');
                    $ok = '🧹 Fila de avisos de bloqueio/desbloqueio zerada. A próxima passada só tira a foto dos status (não dispara aviso por mudança antiga).';
                    break;
                }

                case 'msg_pausar': case 'msg_retomar': {
                    // PAUSAR/RETOMAR todo envio automático de WhatsApp do sistema (cobrança, avisos de bloqueio/desbloqueio, recibos, resumo). Use ao restaurar backup em servidor de teste.
                    if (!is_file(__DIR__ . '/whatsapp.php')) { $err = 'whatsapp.php não encontrado.'; break; }
                    require_once __DIR__ . '/whatsapp.php';
                    $waM = ws_wa_config(); $autoF = WS_CACHE . '/msg_auto.json';
                    $autoM = is_file($autoF) ? (json_decode((string)@file_get_contents($autoF), true) ?: []) : [];
                    if ($acao === 'msg_pausar') {
                        $antes = (string)($waM['gateway'] ?? 'evolution'); if ($antes === 'desativado') $antes = (string)($waM['gateway_antes'] ?? 'evolution');
                        ws_wa_salvar(['gateway_antes' => $antes, 'gateway' => 'desativado']);
                        $autoM['ativo_antes'] = (int)($autoM['ativo'] ?? 1) ?: (int)($autoM['ativo_antes'] ?? 1); $autoM['ativo'] = 0;
                        foreach (['msg_eventos_fila.json'] as $q) @file_put_contents(WS_CACHE . '/' . $q, '[]');
                        @unlink(WS_CACHE . '/msg_estado_bloqueio.json');
                        $ok = '⏸️ Envio de mensagens PAUSADO: nada sai pelo WhatsApp (cobrança, avisos, recibos, resumo). A fila de avisos foi zerada.';
                    } else {
                        $volta = (string)($waM['gateway_antes'] ?? ''); if ($volta === '' || $volta === 'desativado') $volta = 'evolution';
                        ws_wa_salvar(['gateway' => $volta]);
                        $autoM['ativo'] = (int)($autoM['ativo_antes'] ?? 1);
                        @unlink(WS_CACHE . '/msg_estado_bloqueio.json');   // 1ª passada só tira a foto: não dispara aviso por status antigo
                        $ok = '▶️ Envio de mensagens RETOMADO (' . $volta . '). Os avisos de bloqueio/desbloqueio recomeçam só a partir de agora.';
                    }
                    @file_put_contents($autoF, json_encode($autoM)); @chmod($autoF, 0640);
                    break;
                }

                case 'radius_recarregar_nas': {
                    // O FreeRADIUS só lê a lista de concentradores (NAS) ao iniciar. Apaga o "hash" da última leitura: a rotina do root (1/min) reinicia o serviço.
                    @unlink(WS_CACHE . '/nas_freeradius.hash');
                    $ok = '🔄 Pedido enviado: o FreeRADIUS recarrega a lista de concentradores em até 1 minuto (leva ~2 s; quem está conectado continua).';
                    break;
                }

                case 'licenca_consultar': {
                    // 18/11/2026: consulta AGORA o servidor de licenças (licenca_online.php). Falha de rede só informa; nunca bloqueia.
                    if (!function_exists('ws_lic_consultar')) { $erro = 'Licença online indisponível nesta instalação.'; break; }
                    $rl = ws_lic_consultar();
                    if (!empty($rl['ok'])) $ok = '✅ Consulta feita: ' . ($rl['status'] === 'revogada' ? 'licença REVOGADA pelo fornecedor.' : 'licença em dia.');
                    else $ok = 'ℹ️ Não consegui consultar agora (' . ($rl['motivo'] ?? 'sem resposta') . '). O sistema segue funcionando normalmente e tenta de novo sozinho.';
                    break;
                }

                case 'logs_envio_reaplicar': {
                    // 31/10/2026: reaplica HORA (chrony) e ENVIO DE LOGS (rsyslog) deste servidor. A web só apaga o controle; a rotina do root (1/min) refaz — logs_envio_lib.php.
                    @unlink(WS_CACHE . '/logs_envio.hash');
                    $ok = '🔄 Pedido enviado: a hora certa e o envio dos logs são reaplicados em até 1 minuto. O resultado aparece em Logs de conexão.';
                    break;
                }

                case 'atendimento_revisar_agora': {
                    // 02/11/2026: a web só grava o pedido; a rotina do root (1/min) lê o Chatwoot e grava o relatório — atendimento_revisao_lib.php.
                    @file_put_contents(WS_CACHE . '/atendimento_revisao.pedido', json_encode(['em' => time()]), LOCK_EX); @chmod(WS_CACHE . '/atendimento_revisao.pedido', 0664);
                    $ok = '🔄 Pedido enviado: em até 1 minuto o sistema revisa as conversas desde a última revisão. O resultado aparece neste card.';
                    break;
                }

                case 'ura_ligar': case 'ura_desligar': case 'ura_envio_ligar': case 'ura_envio_desligar': case 'ura_voz_ligar': case 'ura_voz_desligar': case 'ura_chat_ligar': case 'ura_chat_desligar': {
                    // 14/11/2026: URA telefônica (boleto, confiança, suporte pelo telefone) — liga/desliga a URA e o envio do boleto por WhatsApp (Wellnet-02, tem custo) — ura_lib.php.
                    require_once __DIR__ . '/ura_lib.php';
                    if ($acao === 'ura_ligar') { ws_ura_salvar(['ativo' => true]); $ok = '📞 URA telefônica LIGADA.'; }
                    elseif ($acao === 'ura_desligar') { ws_ura_salvar(['ativo' => false]); $ok = '📞 URA telefônica DESLIGADA: quem digitar a opção da URA cai direto no atendimento.'; }
                    elseif ($acao === 'ura_voz_ligar') { ws_ura_salvar(['voz' => true]); $ok = '🎤 Voz na URA LIGADA: o cliente pode falar ou digitar (transcrição da OpenAI, custo de centavos por minuto).'; }
                    elseif ($acao === 'ura_chat_ligar') { ws_ura_salvar(['chat_menu' => true]); $ok = '💬 Menu do chat após a ligação LIGADO: opção 4 fora do horário abre o robô pela Wellnet-01 (1 vez por número em 24 h, só se tiver WhatsApp).'; }
                    elseif ($acao === 'ura_chat_desligar') { ws_ura_salvar(['chat_menu' => false]); $ok = '💬 Menu do chat após a ligação DESLIGADO: fora do horário fica só o aviso falado.'; }
                    elseif ($acao === 'ura_voz_desligar') { ws_ura_salvar(['voz' => false]); $ok = '🎤 Voz na URA DESLIGADA: a URA só aceita teclado.'; }
                    elseif ($acao === 'ura_envio_ligar') { ws_ura_salvar(['envio_whatsapp' => true]); $ok = '💬 Envio do boleto por WhatsApp LIGADO (Wellnet-02, tem custo por mensagem).'; }
                    else { ws_ura_salvar(['envio_whatsapp' => false]); $ok = '💬 Envio do boleto por WhatsApp DESLIGADO: a URA só informa valor e vencimento por voz.'; }
                    break;
                }

                case 'logs_retencao_agora': {
                    // 01/11/2026: prazo legal dos registros de conexão (1 ano). A web só grava o pedido; a rotina do root (1/min) apaga o que passou do prazo — logs_envio_lib.php.
                    @file_put_contents(WS_CACHE . '/logs_retencao.pedido', json_encode(['em' => time()]), LOCK_EX); @chmod(WS_CACHE . '/logs_retencao.pedido', 0664);
                    $ok = '🔄 Pedido enviado: em até 1 minuto o sistema apaga os registros de conexão que passaram de 1 ano (o resultado aparece neste card).';
                    break;
                }

                case 'reiniciar_servidor': {
                    // 23/10/2026: kernel novo (segurança) só vale depois de reiniciar. A web roda como www-data: grava o PEDIDO e a rotina do root (atualizar_run.php, cron de 1 min) reinicia.
                    $qt = 0; try { $qt = (int)$db->query("SELECT COUNT(*) FROM radacct WHERE acctstoptime IS NULL")->fetchColumn(); } catch (Throwable $e) {}
                    @file_put_contents(WS_CACHE . '/reiniciar_servidor.pedido', json_encode(['em' => time(), 'por' => (string)($_SESSION['ws_user']['login'] ?? '')]), LOCK_EX); @chmod(WS_CACHE . '/reiniciar_servidor.pedido', 0664);
                    $ok = '♻️ Reinício pedido: o servidor reinicia em até 1 minuto e volta em cerca de 1 minuto (as ' . $qt . ' sessões abertas ficam nos concentradores; só autenticações novas falham nesse intervalo). Faça login de novo depois.';
                    break;
                }

                case 'espelho_pedido': {
                    // 05/11/2026: servidor principal/reserva. A web só grava o PEDIDO; a rotina do root (1/min, espelho_lib.php) executa — troca de papel exige root no banco.
                    $acaoEsp = (string)($_POST['espelho_acao'] ?? '');
                    if (!in_array($acaoEsp, ['promover', 'virar_replica', 'auto_on', 'auto_off', 'configurar', 'instalar'], true)) { $err = '❌ Ação do espelho inválida.'; break; }
                    $pedEsp = ['acao' => $acaoEsp, 'em' => time(), 'por' => (string)($_SESSION['ws_user']['login'] ?? '')];
                    if ($acaoEsp === 'configurar' || $acaoEsp === 'instalar') {
                        $ipEsp = trim((string)($_POST['esp_par'] ?? ''));
                        if (!filter_var($ipEsp, FILTER_VALIDATE_IP)) { $err = '❌ Informe o IP do outro servidor (ex.: 100.65.5.6).'; break; }
                        $pedEsp += ['par' => $ipEsp, 'preferido' => (string)($_POST['esp_pref'] ?? 'principal'), 'falhas_limite' => (int)($_POST['esp_limite'] ?? 3), 'quarentena_s' => (int)($_POST['esp_quar'] ?? 180)];
                    }
                    @file_put_contents(WS_CACHE . '/espelho_pedido.json', json_encode($pedEsp), LOCK_EX); @chmod(WS_CACHE . '/espelho_pedido.json', 0664);
                    $ok = '🪞 Pedido enviado: em até 1 minuto o servidor executa (' . ['promover' => 'ASSUMIR como principal', 'virar_replica' => 'virar réplica do outro', 'auto_on' => 'ligar o modo automático', 'auto_off' => 'voltar ao modo manual', 'configurar' => 'salvar a configuração', 'instalar' => 'LIGAR o espelho (copiar o banco e começar a replicar)'][$acaoEsp] . '). O resultado aparece na seção Espelho.';
                    break;
                }

                case 'trocar_chave_robo': {
                    // 23/10/2026: troca a chave do robô (links PIX, webhooks, n8n). A antiga continua valendo (chave_anterior) até ser apagada — nada que já foi enviado quebra.
                    require_once __DIR__ . '/api_chatbot.php'; require_once __DIR__ . '/aviso_provedor_lib.php';
                    ws_chatbot_chave_trocar();
                    $cw = []; foreach (array_keys((array)ws_cw_cfg()) as $inst) { $o = []; @exec('php ' . escapeshellarg(__DIR__ . '/evo_config.php') . ' proxy ligar ' . escapeshellarg((string)$inst) . ' 2>&1', $o, $rc); $cw[] = $inst . ($rc === 0 ? ' ok' : ' FALHOU'); }
                    $ok = '🔐 Chave trocada. A anterior continua valendo até você apagá-la. Chatwoot: ' . ($cw ? implode(', ', $cw) : 'nenhuma caixa') . '. A Evolution é atualizada sozinha em até 1 minuto. Atualize o n8n (nó "Cobrança ainda aberta?") com o novo endereço e só depois apague a chave anterior.';
                    break;
                }

                case 'apagar_chave_anterior': {
                    require_once __DIR__ . '/api_chatbot.php';
                    ws_chatbot_chave_anterior_apagar();
                    $ok = '🗑️ Chave anterior apagada: só a nova vale agora (links PIX antigos e endereços antigos deixam de funcionar).';
                    break;
                }

                case 'apagar_ativacao': {
                    if (!ws_fornecedor_desbloqueado()) { $err = 'Esta ação é da área do fornecedor: destrave com o código de desbloqueio (Manutenção → Área do fornecedor).'; break; }
                    // Apaga a chave de ativação DESTE servidor: cache/ + as cópias de segurança (/var/lib e /var/tmp). Sem apagar todas, o sistema se reativa sozinho.
                    $nApag = 0; $nFalha = 0;
                    foreach (['ativacao', 'licenca'] as $nmAt) foreach (ws_ativacao_arquivos($nmAt) as $arqAt) {
                        if (!@is_file($arqAt)) continue;
                        if (@unlink($arqAt)) $nApag++; else $nFalha++;
                    }
                    if ($nFalha > 0) $err = "❌ Apaguei $nApag cópia(s), mas $nFalha não pôde ser removida (permissão) — a ativação pode voltar sozinha. Apague pelo terminal: sudo rm /var/lib/wellsystem/wellsystem_ativacao_* /var/lib/wellsystem/wellsystem_licenca_* /var/tmp/wellsystem_ativacao_* /var/tmp/wellsystem_licenca_*";
                    else $ok = "✅ Chave de ativação apagada ($nApag cópia(s)). No próximo acesso o sistema pede a chave de novo.";
                    break;
                }

                case 'liberar_auth': {
                    $planoX = (int)($_POST['plano_id'] ?? 0);
                    $pl = $db->prepare("SELECT nome FROM ws_plano WHERE id=?"); $pl->execute([$planoX]);
                    $planoNome = $pl->fetchColumn();
                    if (!$planoNome) { $err = 'Escolha um plano de velocidade válido.'; break; }
                    if (!function_exists('ws_rad_sync_contrato')) { $err = 'RADIUS (radius_lib.php) não disponível neste servidor.'; break; }
                    // Emergência: re-provisiona TODO contrato ativo/bloqueado no RADIUS já LIBERADO e com a
                    // velocidade do plano X — resolve autenticação quando o RADIUS está inconsistente.
                    $cts = $db->query("SELECT * FROM ws_contrato WHERE status IN ('ativo','bloqueado')")->fetchAll();
                    $n = 0;
                    foreach ($cts as $ct) {
                        $ct['plano_id'] = $planoX;
                        try { ws_rad_sync_contrato($db, $ct, false); $n++; } catch (Throwable $e) {}
                    }
                    $ok = "Autenticação de emergência liberada para $n contrato(s) no plano \"$planoNome\". Eles voltam a autenticar mesmo com o RADIUS inconsistente. Depois, use 'Ressincronizar' normal para voltar cada um ao seu plano real.";
                    break;
                }

                case 'limpar_caches': {
                    $n = 0;
                    foreach (glob(WS_CACHE . '/olt_*.json') ?: [] as $f) { if (@unlink($f)) $n++; }
                    $ok = "Caches temporários da OLT limpos ($n arquivo(s)). Não afeta clientes, boletos nem configuração.";
                    break;
                }

                /* REPARO — rotina ÚNICA em ws_reparar.php, a MESMA que o menu do servidor (PuTTY,
                   opção 6) roda pela linha de comando. Assim a tela e o terminal reparam igual. */
                case 'ressync_radius': {
                    require_once __DIR__ . '/ws_reparar.php';
                    $rr = ws_reparar_radius($db);
                    if (!$rr['ok']) { $err = 'RADIUS (radius_lib.php) não disponível.'; break; }
                    $ok = "RADIUS ressincronizado: {$rr['n']} contrato(s) reprovisionados ({$rr['bloq']} bloqueado(s) pela regra de inadimplência). Corrige senhas/grupos/IP fora de sincronia.";
                    break;
                }

                case 'verificar_tabelas': {
                    require_once __DIR__ . '/ws_reparar.php';
                    $re = ws_reparar_estrutura($db);   // schema + migrações + auto-heal INTEIRO (apaga a marca de "já feito")
                    $ok = "Estrutura verificada e SINCRONIZADA: {$re['tabelas']} tabela(s) conferidas + migrações + auto-heal aplicados. Só cria o que falta — nenhum dado existente é alterado.";
                    break;
                }

                case 'apagar_leads': {
                    $n = $db->exec("DELETE FROM ws_lead");
                    $ok = "Leads (comercial) apagados ($n). Clientes, contratos e boletos NÃO foram tocados.";
                    break;
                }

                case 'reprocessar_atraso': {
                    if (!function_exists('ws_rad_sync_contrato')) { $err = 'RADIUS (radius_lib.php) não disponível.'; break; }
                    $cts = $db->query("SELECT * FROM ws_contrato WHERE status='ativo'")->fetchAll();
                    $n = 0;
                    foreach ($cts as $ct) {
                        if (function_exists('ws_rad_deve_bloquear') && ws_rad_deve_bloquear($db, $ct)) {
                            $db->prepare("UPDATE ws_contrato SET status='bloqueado' WHERE id=?")->execute([$ct['id']]);
                            try { $ct['status'] = 'bloqueado'; ws_rad_sync_contrato($db, $ct, true); } catch (Throwable $e) {}
                            $n++;
                        }
                    }
                    $ok = "Faturas em atraso reprocessadas: $n contrato(s) inadimplentes foram bloqueados. Quem está em dia NÃO foi tocado.";
                    break;
                }

                case 'resetar_2fa': {
                    $uid = (int)($_POST['operador_id'] ?? 0);
                    if (!$uid) { $err = 'Escolha um operador.'; break; }
                    $db->prepare("UPDATE ws_usuario SET twofa_enabled=0, twofa_secret=NULL, twofa_recovery=NULL WHERE id=?")->execute([$uid]);
                    $nm = $db->prepare("SELECT nome FROM ws_usuario WHERE id=?"); $nm->execute([$uid]);
                    $ok = "2FA resetado para \"" . ($nm->fetchColumn() ?: $uid) . "\". Esse operador entra só com login e senha até reativar o 2FA.";
                    break;
                }

                case 'limpar_sessoes': {
                    $path = session_save_path() ?: sys_get_temp_dir();
                    $atual = 'sess_' . session_id();
                    $n = 0;
                    foreach (glob(rtrim($path, '/\\') . '/sess_*') ?: [] as $f) { if (basename($f) !== $atual && @unlink($f)) $n++; }
                    $ok = "Sessões limpas ($n). Os outros usuários precisarão fazer login de novo. Sua sessão foi mantida.";
                    break;
                }

                case 'backup_agora': {
                    if (!function_exists('ws_backup_gerar') && is_file(__DIR__ . '/backup_lib.php')) require_once __DIR__ . '/backup_lib.php';
                    if (!function_exists('ws_backup_gerar')) { $err = 'Backup (backup_lib.php) não disponível.'; break; }
                    try {
                        $rb = ws_backup_gerar();
                        $ok = 'Backup gerado agora. Baixe/veja em Provedor → Backup do sistema.';
                        if (!empty($rb['envio']) && is_array($rb['envio'])) {
                            $partesB = [];
                            foreach ($rb['envio'] as $canalB => $stB) { $partesB[] = "$canalB=" . (is_string($stB) ? $stB : json_encode($stB, JSON_UNESCAPED_UNICODE)); }
                            if ($partesB) $ok .= ' Envio: ' . implode(', ', $partesB) . '.';
                        }
                    }
                    catch (Throwable $e) { $err = 'Falha ao gerar backup: ' . $e->getMessage(); }
                    break;
                }

                case 'backup_fiscal_agora': {   // 12/11/2026: backup do módulo Fiscal (notas, XML, emissor, certificado, logo) com envio à pasta "Sistema Fiscal"
                    if (!function_exists('ws_fbk_gerar') && is_file(__DIR__ . '/fiscal_backup_lib.php')) require_once __DIR__ . '/fiscal_backup_lib.php';
                    if (!function_exists('ws_fbk_gerar')) { $err = 'Backup do Fiscal (fiscal_backup_lib.php) não disponível.'; break; }
                    try {
                        [$pf, $mf] = ws_fbk_gerar(ws_db(), 'manutencao'); $envF = ws_fbk_enviar($pf);
                        $ok = 'Backup do Fiscal gerado (' . ($mf['contagem']['notas'] ?? 0) . ' nota(s), ' . ($mf['contagem']['xml'] ?? 0) . ' XML). Envio: ' . json_encode($envF, JSON_UNESCAPED_UNICODE) . '. Veja em Backup → Backup do Fiscal.';
                    } catch (Throwable $e) { $err = 'Falha ao gerar o backup do Fiscal: ' . $e->getMessage(); }
                    break;
                }
                /* HTTPS SEM TERMINAL — pede o certificado à Let's Encrypt e o instala no Apache.
                 *
                 * A execução é de UM script fixo, via sudo, autorizado na instalação
                 * (/etc/sudoers.d/wellsystem-certificado). O www-data não ganha "sudo": ganha
                 * permissão de rodar aquele caminho exato, que valida os domínios antes de chamar
                 * o certbot. Argumentos livres aqui seriam execução de comando como root a partir
                 * de um campo de formulário — exatamente o que não se faz num sistema com login.
                 *
                 * A renovação não precisa de agendamento nosso: o certbot instala a própria tarefa
                 * e renova antes de vencer. */
                case 'emitir_certificado': {
                    /* AUTOMÁTICO (24/09/2026): a lista fica GRAVADA e o cron (certificado_lib.php) cuida do resto —
                     * domínio que ainda não aponta para cá entra sozinho no certificado quando passar a apontar.
                     * O botão só roda a mesma verificação na hora. */
                    require_once __DIR__ . '/certificado_lib.php';
                    $email = trim((string)($_POST['cert_email'] ?? ''));
                    $doms = ws_cert_normalizar((string)($_POST['cert_dominios'] ?? ''));
                    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $err = 'Informe um e-mail válido — é nele que a Let\'s Encrypt avisa se um certificado vai vencer.'; break; }
                    if (!$doms) { $err = 'Informe ao menos um domínio válido (ex.: erp.seudominio.com.br).'; break; }
                    if (!is_file(WS_CERT_SCRIPT)) {
                        $err = 'Este servidor não tem a emissão pelo painel habilitada. Ela é instalada pelo INSTALAR.sh; em instalação feita à mão, emita pelo terminal com o certbot.';
                        break;
                    }
                    $cc = ws_cert_cfg();
                    $cc['dominios'] = $doms; $cc['email'] = $email; $cc['auto'] = true;
                    ws_cert_salvar($cc);
                    @unlink(WS_CACHE . '/ip_publico.txt');   // confere o IP público de novo agora
                    $rr = ws_cert_auto_run(true);
                    $cc = ws_cert_cfg();
                    $msgC = htmlspecialchars((string)($cc['estado']['msg'] ?? ''), ENT_QUOTES, 'UTF-8');
                    if (!empty($rr['rodou']) && empty($rr['ok'])) {
                        /* A saída do certbot é a informação mais útil que existe quando ele falha —
                         * ela diz QUAL domínio não resolveu. Mostrar só "falhou" obrigaria a ir ao terminal. */
                        $err = $msgC . '<br>Resposta do certbot:<br><pre style="white-space:pre-wrap;font-size:12px;margin:6px 0 0">'
                             . htmlspecialchars((string)($cc['ultima']['saida'] ?? '(sem saída)'), ENT_QUOTES, 'UTF-8') . '</pre>';
                    } elseif (in_array($rr['motivo'] ?? '', ['ip', 'email'], true)) {
                        $err = $msgC;
                    } else {
                        $ok = 'Domínios gravados: ' . htmlspecialchars(implode(', ', $doms), ENT_QUOTES, 'UTF-8') . '. ' . $msgC
                            . ' A partir de agora é automático: a cada 10 min o sistema confere e emite/aumenta o certificado sozinho.';
                    }
                    break;
                }

                /* CONTINGÊNCIA DO RADIUS — liga/desliga a regra que aceita todo mundo quando o
                 * BANCO cai. Mesma proteção do certificado: script fixo, via sudo, com o argumento
                 * validado aqui e de novo lá dentro. */
                /* NORMALIZAR ENDEREÇOS agora, sem esperar o cron.
                 * O cron faz em lotes de 300 a cada 2 minutos; aqui vai até 5.000 de uma vez, para
                 * quem acabou de importar uma base e quer ver o resultado na hora. */
                case 'normalizar_enderecos': {
                    require_once WS_DIR . '/schema_endereco.php';
                    $rn = ws_end_migrar($db, 5000);
                    if (!empty($rn['erro'])) { $err = 'Normalização: ' . $rn['erro']; break; }
                    $ok = sprintf(
                        'Endereços normalizados: %d cliente(s) e %d contrato(s) vinculados. '
                        . 'Cadastro criado nesta passada: %d logradouro(s), %d bairro(s), %d cidade(s). '
                        . 'Rode de novo se ainda houver pendente.',
                        $rn['clientes'], $rn['contratos'], $rn['logradouros'], $rn['bairros'], $rn['cidades']);
                    break;
                }

                /* UNIFICAR zonas, bairros e cidades agora (16/10/2026) — mesma rotina do cron (zonas_sync), com relatório. */
                case 'unificar_zonas': {
                    require_once WS_DIR . '/zonas_unificar_lib.php';
                    $ru = ws_zonas_bairros_unificar($db, true);
                    $ok = sprintf('Unificação feita: %d zona(s) e %d cidade(s) e %d bairro(s) repetidos juntados; %d zona(s) e %d bairro(s) criados; %d contrato(s) e %d cliente(s) com texto acertado; regra de VLAN: %d contrato(s). Ainda sem zona: %d contrato(s) ativos.%s',
                        count($ru['zonas_juntadas']), count($ru['cidades_juntadas']), count($ru['bairros_juntados']), count($ru['zonas_criadas']), count($ru['bairros_criados']), $ru['contratos_acertados'], $ru['clientes_bairro_acertados'], count($ru['vlan_zona']), $ru['sem_zona'], $ru['backup'] ? ' Antes guardado em cache/' . $ru['backup'] . '.' : '');
                    break;
                }

                /* APOSENTAR / RESTAURAR as colunas de texto do endereço.
                 * Reversível de propósito — ver o comentário em schema_endereco.php. Só root: é
                 * alteração de estrutura no banco que fatura. */
                case 'endereco_texto': {
                    if (!ws_eh_root()) { $err = '🔒 Só o root pode alterar a estrutura do endereço.'; break; }
                    require_once WS_DIR . '/schema_endereco.php';
                    if (($_POST['et_acao'] ?? '') === 'restaurar') {
                        $rr = ws_end_texto_restaurar($db);
                        $ok = $rr['restauradas'] . ' coluna(s) de texto restaurada(s) — o sistema volta a mantê-las.';
                        if ($rr['erros']) $ok .= ' Avisos: ' . implode(' · ', $rr['erros']);
                    } else {
                        $ra = ws_end_texto_aposentar($db);
                        $ok = $ra['renomeadas'] . ' coluna(s) de texto aposentada(s). O endereço agora vem SÓ do cadastro. '
                            . 'Confira boleto, recibo e a ficha do cliente; se algo ficar em branco, use "Restaurar".';
                        if ($ra['erros']) $ok .= ' Avisos: ' . implode(' · ', $ra['erros']);
                    }
                    break;
                }

                /* Item 6: CPF/CNPJ, RG, celular e telefone gravados com pontuação em cadastros
                 * ANTERIORES a ws_so_numeros() existir. Botão manual (não roda sozinho numa
                 * atualização), em lotes, idempotente — mesma filosofia do normalizar_enderecos. */
                case 'normalizar_documentos': {
                    $rd = ws_normalizar_documentos_texto($db, 5000);
                    $ok = $rd['cliente'] . ' campo(s) de CPF/CNPJ, RG, celular ou telefone limpo(s) (pontuação removida). '
                        . 'Rode de novo se ainda houver pendente.';
                    if ($rd['erros']) $ok .= ' Avisos: ' . implode(' · ', $rd['erros']);
                    break;
                }

                case 'radius_contingencia': {
                    $lig = (($_POST['cont_estado'] ?? '') === 'on');
                    $mb  = (int)($_POST['cont_megas'] ?? 0);
                    if ($lig && ($mb < 1 || $mb > 10000)) { $err = 'Velocidade inválida para a contingência.'; break; }
                    if (!is_file('/usr/local/sbin/ws-radius-fallback.sh')) {
                        $err = 'Este servidor não tem a contingência habilitada pelo painel (ela é instalada pelo INSTALAR.sh).';
                        break;
                    }
                    $cmd = 'sudo -n /usr/local/sbin/ws-radius-fallback.sh '
                         . ($lig ? ('on ' . escapeshellarg((string)$mb)) : 'off') . ' 2>&1';
                    $saida = (string)@shell_exec($cmd);
                    if (strpos($saida, 'PRONTO') !== false) {
                        $ok = $lig
                            ? ('Contingência LIGADA a ' . $mb . ' Mbps. Enquanto o banco estiver respondendo, nada muda: ela só age se a consulta falhar.')
                            : 'Contingência DESLIGADA. Com o banco fora, ninguém autentica — é o comportamento padrão.';
                    } else {
                        $err = 'Não foi possível alterar a contingência:<br><pre style="white-space:pre-wrap;font-size:12px;margin:6px 0 0">'
                             . htmlspecialchars(mb_substr(trim($saida) ?: '(sem saída)', -900), ENT_QUOTES, 'UTF-8') . '</pre>';
                    }
                    break;
                }

                case 'reprov_radius': {
                    if (!function_exists('ws_rad_sync_contrato')) { $err = 'RADIUS (radius_lib.php) não disponível.'; break; }
                    $tipo = in_array($_POST['tipo'] ?? '', ['pppoe', 'ipoe'], true) ? $_POST['tipo'] : '';
                    $vlan = trim($_POST['vlan'] ?? '');
                    $w = "status<>'cancelado'"; $par = [];
                    if ($tipo) { $w .= " AND tipo_conexao=?"; $par[] = $tipo; }
                    if ($vlan !== '' && ctype_digit($vlan)) { $w .= " AND vlan=?"; $par[] = (int)$vlan; }
                    $st = $db->prepare("SELECT * FROM ws_contrato WHERE $w"); $st->execute($par);
                    $n = 0;
                    foreach ($st->fetchAll() as $ct) {
                        try { $deve = function_exists('ws_rad_deve_bloquear') ? ws_rad_deve_bloquear($db, $ct) : ($ct['status'] !== 'ativo'); ws_rad_sync_contrato($db, $ct, $deve); $n++; } catch (Throwable $e) {}
                    }
                    $ok = "Reprovisionados $n contrato(s) no RADIUS" . ($tipo ? " ($tipo)" : "") . ($vlan !== '' ? " VLAN $vlan" : " (todas as VLANs)") . ". Recria senha/grupo/IP.";
                    break;
                }

                case 'zera_senhas': {
                    if (!function_exists('ws_rad_sync_contrato')) { $err = 'RADIUS (radius_lib.php) não disponível.'; break; }
                    $tipo = in_array($_POST['tipo'] ?? '', ['pppoe', 'ipoe'], true) ? $_POST['tipo'] : '';
                    $w = "status<>'cancelado' AND login_pppoe IS NOT NULL AND login_pppoe<>''"; $par = [];
                    if ($tipo) { $w .= " AND tipo_conexao=?"; $par[] = $tipo; }
                    $st = $db->prepare("SELECT * FROM ws_contrato WHERE $w"); $st->execute($par);
                    $n = 0;
                    foreach ($st->fetchAll() as $ct) {
                        $lg = (string)$ct['login_pppoe'];
                        $db->prepare("UPDATE ws_contrato SET senha_pppoe=? WHERE id=?")->execute([$lg, $ct['id']]);
                        try { $ct['senha_pppoe'] = $lg; $deve = function_exists('ws_rad_deve_bloquear') ? ws_rad_deve_bloquear($db, $ct) : false; ws_rad_sync_contrato($db, $ct, $deve); } catch (Throwable $e) {}
                        $n++;
                    }
                    $ok = "Senha redefinida para IGUAL ao login em $n contrato(s)" . ($tipo ? " ($tipo)" : "") . ". RADIUS atualizado.";
                    break;
                }

                case 'derrubar_conexoes': {
                    if (!function_exists('ws_rad_disconnect')) { $err = 'RADIUS (radius_lib.php) não disponível.'; break; }
                    $por = in_array($_POST['por'] ?? '', ['todos', 'vlan', 'login', 'ip', 'nome', 'nome_reduzido', 'senha', 'cpf'], true) ? $_POST['por'] : 'todos';
                    $val = trim($_POST['valor'] ?? '');
                    $logins = [];
                    if ($por === 'ip' && $val !== '') {
                        try { $s = $db->prepare("SELECT DISTINCT username FROM radacct WHERE framedipaddress=? AND acctstoptime IS NULL"); $s->execute([$val]); $logins = $s->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
                        $s2 = $db->prepare("SELECT login_pppoe FROM ws_contrato WHERE ip_fixo=? AND login_pppoe<>''"); $s2->execute([$val]);
                        foreach ($s2->fetchAll(PDO::FETCH_COLUMN) as $l) $logins[] = $l;
                    } else {
                        // PPPoE E IPoE: a sessão viva usa um dos dois logins (a maioria do parque é IPoE); só o PPPoE deixava
                        // essas sessões de fora e "Derrubar conexões" não derrubava quase ninguém.
                        $sql = "SELECT ct.login_pppoe, ct.login_ipoe FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                                WHERE ct.status<>'cancelado'
                                  AND ((ct.login_pppoe IS NOT NULL AND ct.login_pppoe<>'') OR (ct.login_ipoe IS NOT NULL AND ct.login_ipoe<>''))";
                        $par = [];
                        if ($val !== '') {
                            if ($por === 'vlan' && ctype_digit($val))          { $sql .= " AND ct.vlan=?"; $par[] = (int)$val; }
                            elseif ($por === 'login')          { $sql .= " AND (ct.login_pppoe=? OR ct.login_ipoe=?)"; $par[] = $val; $par[] = $val; }
                            elseif ($por === 'senha')          { $sql .= " AND ct.senha_pppoe=?"; $par[] = $val; }
                            elseif ($por === 'nome')           { $sql .= " AND c.nome LIKE ?"; $par[] = "%$val%"; }
                            elseif ($por === 'nome_reduzido')  { $sql .= " AND c.nome_resumido LIKE ?"; $par[] = "%$val%"; }
                            elseif ($por === 'cpf')            { $sql .= " AND REPLACE(REPLACE(REPLACE(c.cpf_cnpj,'.',''),'-',''),'/','')=?"; $par[] = preg_replace('/\D/', '', $val); }
                        }
                        $s = $db->prepare($sql); $s->execute($par);
                        foreach ($s->fetchAll(PDO::FETCH_NUM) as $lr) { foreach ($lr as $lg) { if ((string)$lg !== '') $logins[] = $lg; } }
                    }
                    $logins = array_unique(array_filter($logins));
                    $n = function_exists('ws_rad_disconnect_muitos') ? ws_rad_disconnect_muitos($db, $logins) : 0;
                    if (!function_exists('ws_rad_disconnect_muitos')) {
                        foreach ($logins as $lg) { try { if (ws_rad_disconnect($db, (string)$lg)) $n++; } catch (Throwable $e) {} }
                    }
                    $ok = "Conexões derrubadas: $n sessão(ões) reiniciada(s)" . ($por !== 'todos' ? " (por $por: $val)" : " (todos)") . ". O cliente reconecta sozinho.";
                    break;
                }

                case 'manutencao_login_toggle': {
                    $ativar = ($_POST['ativar'] ?? '') === '1';
                    $motivo = trim($_POST['motivo'] ?? '');
                    if (!function_exists('ws_manutencao_login_salvar')) { $err = 'Função indisponível (config.php desatualizado).'; break; }
                    ws_manutencao_login_salvar($ativar, $motivo);
                    $ok = $ativar
                        ? 'Modo manutenção LIGADO: só admin/root conseguem entrar agora. Quem já estava logado sem ser admin/root foi desconectado.'
                        : 'Modo manutenção DESLIGADO: todo mundo volta a conseguir entrar normalmente.';
                    break;
                }

                case 'zera_trafego': {
                    $n1 = 0; $n2 = 0; $nc = 0;
                    try { $n1 = $db->exec("DELETE FROM radacct"); } catch (Throwable $e) {}
                    try { $n2 = $db->exec("DELETE FROM ws_online_hist"); } catch (Throwable $e) {}
                    $cfg = function_exists('ws_olt_link_config') ? ws_olt_link_config() : [];
                    foreach (glob(WS_CACHE . '/olt_*traf*.json') ?: [] as $f) { if (@unlink($f)) $nc++; }
                    if (!empty($cfg['caminho'])) foreach (glob(rtrim($cfg['caminho'], '/\\') . '/*traf*.json') ?: [] as $f) { if (@unlink($f)) $nc++; }
                    $ok = "Tráfego zerado: $n1 registro(s) de accounting (radacct), $n2 de histórico online, $nc cache(s) de tráfego. Os gráficos recomeçam do zero.";
                    break;
                }

                case 'demo_ligar': {
                    if (!ws_fornecedor_desbloqueado()) { $erro = 'Área do fornecedor travada.'; break; }
                    $horas = (int)($_POST['horas'] ?? 24); if ($horas < 1 || $horas > 168) $horas = 24;
                    ws_demo_reset();   // zera os dados do demo (fresco a cada Ligar: admin/admin123, sem senha antiga)
                    @unlink(WS_CACHE . '/demo_sessions.json');   // zera a contagem de usuários
                    // Inicia a janela GLOBAL do demo (mesmo tempo pra todos os visitantes).
                    ws_demo_salvar(['ativo' => true, 'horas' => $horas, 'expira_em' => time() + $horas * 3600]);
                    $ok = "Ambiente DEMO LIGADO e ZERADO (validade $horas h). Acesse por: demo.php";
                    break;
                }
                case 'demo_desligar': {
                    if (!ws_fornecedor_desbloqueado()) { $erro = 'Área do fornecedor travada.'; break; }
                    $c = ws_demo_cfg(); $c['ativo'] = false; ws_demo_salvar($c);
                    $ok = 'Ambiente DEMO DESLIGADO. A URL de demonstração fica bloqueada.';
                    break;
                }
                case 'demo_resetar': {
                    if (!ws_fornecedor_desbloqueado()) { $erro = 'Área do fornecedor travada.'; break; }
                    [$okD, $mD] = ws_demo_reset();
                    if ($okD) $ok = $mD; else $err = $mD;
                    break;
                }

                default: $err = 'Ação desconhecida.';
            }
        } catch (Throwable $e) {
            $err = 'Erro ao executar: ' . $e->getMessage();
        }
    }
}

/* PLANOS PARA A EMERGÊNCIA DE AUTENTICAÇÃO.
 * Só "ativo=1" deixava o combo VAZIO em base onde nenhum plano está marcado como ativo — e aí a
 * ferramenta de emergência não servia para nada justamente na hora da queda, sem dizer por quê.
 * Agora, se a lista filtrada vier vazia, entram TODOS os planos: numa emergência importa existir
 * uma velocidade para aplicar, não o estado do cadastro. E se a coluna "ativo" nem existir nesta
 * instalação, a consulta com filtro falharia e derrubaria a tela inteira — por isso o try. */
$planos = [];
if ($ehRoot) {
    try { $planos = $db->query("SELECT id,nome FROM ws_plano WHERE ativo=1 ORDER BY nome")->fetchAll(); }
    catch (Throwable $e) { $planos = []; }
    if (!$planos) {
        try { $planos = $db->query("SELECT id,nome FROM ws_plano ORDER BY nome")->fetchAll(); }
        catch (Throwable $e) { $planos = []; }
    }
}
$operadores = $ehRoot ? $db->query("SELECT id,nome FROM ws_usuario WHERE ativo=1 ORDER BY nome")->fetchAll() : [];

// ---- DIAGNÓSTICO (estado do sistema, bem detalhado, para manutenção emergencial) ----
$diag = []; $diagFin = []; $diagRede = []; $diagDb = [];
if ($ehRoot) {
    $q  = function ($sql) use ($db) { try { return number_format((int)$db->query($sql)->fetchColumn(), 0, ',', '.'); } catch (Throwable $e) { return '—'; } };
    $qi = function ($sql) use ($db) { try { return (int)$db->query($sql)->fetchColumn(); } catch (Throwable $e) { return 0; } };
    $qm = function ($sql) use ($db) { try { return 'R$ ' . number_format((float)$db->query($sql)->fetchColumn(), 2, ',', '.'); } catch (Throwable $e) { return '—'; } };
    $fbytes = function ($b) { $b = (float)$b; $u = ['B','KB','MB','GB','TB']; $i = 0; while ($b >= 1024 && $i < 4) { $b /= 1024; $i++; } return number_format($b, $i ? 1 : 0, ',', '.') . ' ' . $u[$i]; };

    // Cadastros / operação
    $diag = [
        'Clientes'             => $q("SELECT COUNT(*) FROM ws_cliente"),
        'Clientes ativos'      => $q("SELECT COUNT(*) FROM ws_cliente WHERE status='ativo'"),
        'Instalações Recentes' => $q("SELECT COUNT(*) FROM ws_cliente WHERE status<>'cancelado' AND (criado_em >= (CURDATE() - INTERVAL 90 DAY) OR criado_em IS NULL)"),
        'Contratos ativos'     => $q("SELECT COUNT(*) FROM ws_contrato WHERE status='ativo'"),
        'Contratos bloqueados' => $q("SELECT COUNT(*) FROM ws_contrato WHERE status='bloqueado'"),
        'Contratos cancelados' => $q("SELECT COUNT(*) FROM ws_contrato WHERE status='cancelado'"),
        'Contratos PPPoE'      => $q("SELECT COUNT(*) FROM ws_contrato WHERE tipo_conexao='pppoe'"),
        'Contratos IPoE'       => $q("SELECT COUNT(*) FROM ws_contrato WHERE tipo_conexao='ipoe'"),
        'Comodato'             => $q("SELECT COUNT(*) FROM ws_contrato WHERE comodato=1"),
        'Chamados (total)'     => $q("SELECT COUNT(*) FROM ws_chamado"),
        'Chamados abertos'     => $q("SELECT COUNT(*) FROM ws_chamado WHERE status IN('aberto','em_andamento','agendado')"),
        'Leads (comercial)'    => $q("SELECT COUNT(*) FROM ws_lead"),
        'Planos ativos'        => $q("SELECT COUNT(*) FROM ws_plano WHERE ativo=1"),
        'Cidades'              => $q("SELECT COUNT(*) FROM ws_cidade"),
        'Bairros'              => $q("SELECT COUNT(*) FROM ws_bairro"),
        'Ramais'               => $q("SELECT COUNT(*) FROM ws_ramal"),
        'Zonas'                => $q("SELECT COUNT(*) FROM ws_zona"),
        'Ruas cadastradas'     => $q("SELECT COUNT(*) FROM ws_rua"),
        'CTOs'                 => $q("SELECT COUNT(*) FROM ws_cto"),
        'Estoque (itens)'      => $q("SELECT COUNT(*) FROM ws_estoque"),
        'Bancos/PIX'           => $q("SELECT COUNT(*) FROM ws_banco"),
        'NFS-e'                => $q("SELECT COUNT(*) FROM ws_nfse"),
        'Operadores ativos'    => $q("SELECT COUNT(*) FROM ws_usuario WHERE ativo=1"),
    ];

    // Financeiro (R$)
    $diagFin = [
        'Faturas abertas'      => $q("SELECT COUNT(*) FROM ws_fatura WHERE status='aberto'" . ws_sql_fatura_viva('ws_fatura') . ""),
        'Faturas vencidas'     => $q("SELECT COUNT(*) FROM ws_fatura WHERE status='aberto' AND vencimento < CURDATE()" . ws_sql_fatura_viva('ws_fatura') . ""),
        'Vencem em 7 dias'     => $q("SELECT COUNT(*) FROM ws_fatura WHERE status='aberto' AND vencimento BETWEEN CURDATE() AND CURDATE()+INTERVAL 7 DAY" . ws_sql_fatura_viva('ws_fatura') . ""),
        'Faturas pagas'        => $q("SELECT COUNT(*) FROM ws_fatura WHERE status='pago'"),
        'A receber (aberto)'   => $qm("SELECT COALESCE(SUM(valor),0) FROM ws_fatura WHERE status='aberto'" . ws_sql_fatura_viva('ws_fatura') . ""),
        'Inadimplência'        => $qm("SELECT COALESCE(SUM(valor),0) FROM ws_fatura WHERE status='aberto' AND vencimento < CURDATE()" . ws_sql_fatura_viva('ws_fatura') . ""),
        'Recebido hoje'        => $qm("SELECT COALESCE(SUM(valor_pago),0) FROM ws_pagamento WHERE data_pgto=CURDATE()"),
        'Recebido no mês'      => $qm("SELECT COALESCE(SUM(valor_pago),0) FROM ws_pagamento WHERE data_pgto>=DATE_FORMAT(CURDATE(),'%Y-%m-01')"),
        'Recebido (total)'     => $qm("SELECT COALESCE(SUM(valor_pago),0) FROM ws_pagamento"),
        'Pagamentos (total)'   => $q("SELECT COUNT(*) FROM ws_pagamento"),
    ];

    // Rede / RADIUS
    $diagRede = [
        'Sessões online agora' => $q("SELECT COUNT(*) FROM radacct WHERE acctstoptime IS NULL"),
        'Logins no RADIUS'     => $q("SELECT COUNT(*) FROM radcheck"),
        'Vínculos de grupo'    => $q("SELECT COUNT(*) FROM radusergroup"),
        'Grupos distintos'     => $q("SELECT COUNT(DISTINCT groupname) FROM radusergroup"),
        'Registros radacct'    => $q("SELECT COUNT(*) FROM radacct"),
        'Concentradores/NAS'   => $q("SELECT COUNT(*) FROM nas"),

        /* INDICADORES QUE MOSTRAM SE O RADIUS ESTÁ SAUDÁVEL — e não apenas quantos registros tem.
         * Cada um responde a uma pergunta que, sem ele, só se descobre com o cliente reclamando. */

        // Quantos autenticam por SENHA (PPPoE e IPoE com senha) e quantos por IDENTIDADE
        // (IPoE sem senha, aceito pela porta do concentrador). A soma tem de bater com os logins.
        'Logins com senha'     => $q("SELECT COUNT(*) FROM radcheck WHERE attribute='Cleartext-Password'"),
        'Logins por identidade'=> $q("SELECT COUNT(*) FROM radcheck WHERE attribute='Auth-Type'"),

        // Trava de sessão simultânea. Zero significa que a proteção contra senha compartilhada
        // NÃO está aplicada — o mesmo login pode estar em várias casas ao mesmo tempo.
        'Trava 1 sessão'       => $q("SELECT COUNT(*) FROM radcheck WHERE attribute='Simultaneous-Use'"),

        // Quantos estão no grupo de bloqueio AGORA. Tem de bater com os contratos bloqueados;
        // divergência grande significa sincronismo parado.
        'No grupo de bloqueio' => $q("SELECT COUNT(*) FROM radusergroup WHERE groupname=" . $db->quote(defined('WS_GRUPO_BLOQUEIO') ? WS_GRUPO_BLOQUEIO : 'bloqueado')),

        // Recusas nas últimas 24h. Subiu de repente? Secret trocado, senha dessincronizada ou
        // alguém tentando entrar. É o primeiro lugar a olhar quando "ninguém consegue conectar".
        'Recusas (24h)'        => $q("SELECT COUNT(*) FROM radpostauth WHERE reply='Access-Reject' AND authdate >= (NOW() - INTERVAL 1 DAY)"),
        'Aceites (24h)'        => $q("SELECT COUNT(*) FROM radpostauth WHERE reply='Access-Accept' AND authdate >= (NOW() - INTERVAL 1 DAY)"),

        // Sessão aberta há mais de 24h sem atualização é quase sempre RESÍDUO: o concentrador
        // reiniciou sem enviar o "stop". Isso infla o "online agora" e, com a trava de sessão
        // simultânea ligada, IMPEDE o cliente legítimo de reconectar.
        'Sessões presas (>24h)'=> $q("SELECT COUNT(*) FROM radacct WHERE acctstoptime IS NULL AND acctstarttime < (NOW() - INTERVAL 1 DAY)"),
    ];

    /* A pool de corte existe no grupo de bloqueio? É ELA que prende o inadimplente; sem ela o
     * bloqueio vira apenas redução de velocidade, e o cliente continua navegando. */
    try {
        $temPool = (int)$db->query("SELECT COUNT(*) FROM radgroupreply WHERE groupname="
                   . $db->quote(defined('WS_GRUPO_BLOQUEIO') ? WS_GRUPO_BLOQUEIO : 'bloqueado') . " AND attribute='Framed-Pool'")->fetchColumn();
        $diagRede['Pool de corte'] = $temPool ? 'OK' : 'FALTA';
    } catch (Throwable $e) {}
    try { $st = ws_olt_stats(); $diagRede['ONUs autorizadas (cache)'] = number_format((int)($st['autorizadas'] ?? 0), 0, ',', '.'); $diagRede['ONUs aguardando'] = number_format((int)($st['pendentes'] ?? 0), 0, ',', '.'); } catch (Throwable $e) {}

    // Infra / servidor
    $cfgDb = function_exists('ws_db_config') ? ws_db_config() : [];
    try { $dbver = $db->getAttribute(PDO::ATTR_SERVER_VERSION); } catch (Throwable $e) { $dbver = '—'; }
    $cacheOk = is_dir(WS_CACHE) && is_writable(WS_CACHE);
    $dbMB = null; try { $dbMB = (float)$db->query("SELECT COALESCE(SUM(data_length+index_length),0) FROM information_schema.tables WHERE table_schema=DATABASE()")->fetchColumn(); } catch (Throwable $e) {}
    $exts = []; foreach (['pdo_mysql','mysqli','gd','curl','mbstring','zip'] as $e) $exts[] = ($ok2 = extension_loaded($e)) ? $e : "$e(✗)";
    $ultBackup = '—';
    foreach (['backups','uploads/backups','cache/backups'] as $bd) { $g = glob(__DIR__ . '/' . $bd . '/*'); if ($g) { $ts = max(array_map('filemtime', $g)); $ultBackup = date('d/m/Y H:i', $ts); break; } }
    $diagDb = [
        'Banco'          => ($cfgDb['dbname'] ?? '—') . ' @ ' . ($cfgDb['host'] ?? '—') . ':' . ($cfgDb['porta'] ?? '3306'),
        'Usuário do banco'=> $cfgDb['user'] ?? '—',
        'Tamanho do banco'=> $dbMB !== null ? $fbytes($dbMB) : '—',
        'MySQL/MariaDB'  => $dbver,
        'PHP'            => PHP_VERSION,
        'Extensões PHP'  => implode(' · ', $exts),
        'Memória PHP'    => ini_get('memory_limit') . ' (uso ' . $fbytes(memory_get_usage(true)) . ')',
        'Upload máx.'    => ini_get('upload_max_filesize'),
        'Servidor'       => $_SERVER['SERVER_SOFTWARE'] ?? php_uname('s'),
        'Disco livre'    => $fbytes(@disk_free_space(__DIR__)) . ' de ' . $fbytes(@disk_total_space(__DIR__)),
        'Cache'          => ($cacheOk ? 'gravável' : 'NÃO gravável!') . ' — ' . WS_CACHE,
        'Timezone'       => date_default_timezone_get(),
        'Último backup'  => $ultBackup,
        'Usuário logado' => (ws_user()['nome'] ?? '') . ' (root)',
        'Data/hora'      => date('d/m/Y H:i:s'),
    ];

    // Indicadores visuais (barras de %)
    $ctAt = $qi("SELECT COUNT(*) FROM ws_contrato WHERE status='ativo'");
    $ctBl = $qi("SELECT COUNT(*) FROM ws_contrato WHERE status='bloqueado'");
    $onl  = $qi("SELECT COUNT(*) FROM radacct WHERE acctstoptime IS NULL");
    $rAb = 0.0; $rVen = 0.0; $recMes = 0.0;
    try { $rAb = (float)$db->query("SELECT COALESCE(SUM(valor),0) FROM ws_fatura WHERE status='aberto'" . ws_sql_fatura_viva('ws_fatura') . "")->fetchColumn(); } catch (Throwable $e) {}
    try { $rVen = (float)$db->query("SELECT COALESCE(SUM(valor),0) FROM ws_fatura WHERE status='aberto' AND vencimento<CURDATE()" . ws_sql_fatura_viva('ws_fatura') . "")->fetchColumn(); } catch (Throwable $e) {}
    try { $recMes = (float)$db->query("SELECT COALESCE(SUM(valor_pago),0) FROM ws_pagamento WHERE data_pgto>=DATE_FORMAT(CURDATE(),'%Y-%m-01')")->fetchColumn(); } catch (Throwable $e) {}
    $pct = fn($a, $b) => $b > 0 ? max(0.0, min(100.0, round($a / $b * 100, 1))) : 0.0;
    $ind = [
        ['Inadimplência (R$ vencido ÷ a receber)', $pct($rVen, $rAb), '#dc2626'],
        ['Clientes online agora',                  $pct($onl, $ctAt), '#16a34a'],
        ['Contratos bloqueados',                   $pct($ctBl, $ctAt + $ctBl), '#d97706'],
        ['Recebido do mês ÷ (recebido + a receber)', $pct($recMes, $recMes + $rAb), '#2563eb'],
    ];
}
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Manutenção</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
  .mnt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;margin-top:14px}
  .mnt-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:9px}
  .mnt-card h3{margin:0;font-size:16px}
  .mnt-grid{align-items:start}
  /* Cartões do mesmo tamanho (sem espaço em branco): o que passa da altura fica cortado e o "ver tudo" abre o cartão POR CIMA dos de baixo, sem empurrar a grade. */
  .mnt-grid{position:relative}
  .mnt-card.mnt-comp{max-height:215px;overflow:hidden;position:relative}
  .mnt-card.mnt-comp::after{content:'';position:absolute;left:0;right:0;bottom:0;height:52px;background:linear-gradient(rgba(0,0,0,0),var(--surface));pointer-events:none}
  .mnt-vermais{position:absolute;left:50%;bottom:6px;transform:translateX(-50%);z-index:3;border:1px solid var(--border);background:var(--surface);color:var(--muted);border-radius:12px;padding:1px 14px;font-size:12px;cursor:pointer}
  .mnt-card.mnt-sobre{position:absolute;max-height:none;overflow:visible;z-index:40;box-shadow:0 12px 40px rgba(0,0,0,.35)}
  .mnt-card.mnt-sobre::after{display:none}
  .mnt-card.mnt-sobre > .mnt-vermais{position:static;transform:none;align-self:center;margin-top:6px}
  /* Explicação SEMPRE visível (fixa, sem efeito de mouse). */
  .mnt-card .resumo{font-size:12.5px;color:var(--muted);line-height:1.45;margin:-2px 0 0;font-weight:600}
  .mnt-card .oque{font-size:12.5px;color:var(--muted);line-height:1.55;flex:1}
  .mnt-card.perigo{border-color:var(--err)}
  /* A Emergência do Radius é um cartão como os outros — mesma moldura, mesmo espaçamento —, mas
     ocupa a LINHA INTEIRA da grade: a tabela de painéis dos concentradores tem sete campos por
     linha e não cabe numa coluna de 320px. Antes ela era um .ws-panel solto FORA da grade, e por
     isso destoava de todos os cartões em volta. */
  .mnt-emerg{grid-column:1 / -1}
  /* Sub-blocos do cartão de emergência: moldura mais leve que a do cartão, para ficar claro que
     são partes DELE e não três cartões outra vez. */
  .mnt-emerg-dois{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:12px;align-items:start;margin-top:4px}
  .mnt-sub{background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:13px 14px;display:flex;flex-direction:column;gap:8px}
  .mnt-sub h3{margin:0;font-size:14px}
  .mnt-emerg-titulo{margin-top:16px;padding-top:13px;border-top:1px dashed var(--border);font-size:14px;font-weight:700}
  .mnt-card .senha{padding:9px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)}
  .mnt-badge{display:inline-block;font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px}
  .mnt-badge.d{background:rgba(220,38,38,.12);color:var(--err)}
  .mnt-badge.s{background:rgba(2,132,199,.12);color:var(--info)}
  /* QUADROS DO DIAGNÓSTICO — todos do mesmo tamanho, com o rótulo sempre na mesma altura.
     Antes: o quadro era um bloco simples e o valor podia quebrar em duas linhas ("R$" numa,
     "205.781,50" na outra). A linha inteira da grade crescia junto, e o resultado medido era
     quadro de 96px ao lado de quadro de 69px, com o rótulo caindo a 42px num e a 69px no outro.
     Agora: coluna um pouco mais larga, valor em UMA linha só (white-space:nowrap) e caixa em
     flex centrado com altura mínima. Medido depois: uma altura só (76px) e um rótulo só (44px).
     A classe "longo" entra pelo PHP quando o valor passa de 12 caracteres (R$ com milhão, por
     exemplo) e reduz a fonte — diminuir o número é aceitável; cortar valor em dinheiro não é. */
  .mnt-diag{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:10px;margin-top:12px}
  .mnt-di{background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:12px 10px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-height:76px;text-decoration:none;color:inherit;transition:.12s}
  a.mnt-di:hover{border-color:var(--brand);box-shadow:var(--shadow);transform:translateY(-1px)}
  /* Altura fixa na caixa do valor: com ela o rótulo fica na MESMA altura em todos os quadros,
     inclusive nos que usam a fonte menor. Sem isso sobrava 2px de diferença entre um e outro. */
  .mnt-di span{display:flex;align-items:center;justify-content:center;min-height:22px;font-size:18px;font-weight:800;line-height:1.15;white-space:nowrap;letter-spacing:-.2px;max-width:100%}
  .mnt-di.longo span{font-size:15px}
  .mnt-di label{font-size:11px;color:var(--muted);line-height:1.25}
  .mnt-info{display:flex;flex-wrap:wrap;gap:6px 20px;margin-top:12px;font-size:12.5px;color:var(--muted)}
  .mnt-info b{color:var(--text)}
  .mnt-sec{margin:16px 0 4px;font-size:13px;font-weight:700;color:var(--brand);border-bottom:1px solid var(--border);padding-bottom:4px;scroll-margin-top:56px}
  /* Atalhos por seção (05/11/2026): barra que acompanha a rolagem; montada pelo script no fim da página a partir dos títulos .mnt-sec */
  #mntNav{position:sticky;top:0;z-index:20;display:flex;flex-wrap:wrap;gap:6px;padding:8px 0;margin:8px 0 0;background:var(--bg)}
  #mntNav a{font-size:12px;font-weight:700;padding:5px 11px;border-radius:20px;border:1px solid var(--border);background:var(--surface);color:var(--text);text-decoration:none;white-space:nowrap}
  #mntNav a:hover{border-color:var(--brand);color:var(--brand)}
  /* Espelho: indicador do modo (automático × manual) e os dois servidores lado a lado */
  .esp-modo{padding:11px 14px;border-radius:12px;font-size:13px;font-weight:700;line-height:1.5;border:1px solid}
  .esp-modo small{display:block;font-weight:600;opacity:.85}
  .esp-modo.auto{background:rgba(22,163,74,.12);border-color:rgba(22,163,74,.5)}
  .esp-modo.manual{background:rgba(217,119,6,.13);border-color:rgba(217,119,6,.5)}
  .esp-modo.off{background:rgba(100,116,139,.12);border-color:rgba(100,116,139,.4)}
  .esp-par{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .esp-no{border:1px solid var(--border);border-radius:10px;padding:10px 12px;font-size:12.5px;line-height:1.5}
  .esp-no b.t{display:block;font-size:14px;margin-bottom:2px}
  .esp-no.este{border-color:var(--brand)}
  @media (max-width:640px){.esp-par{grid-template-columns:1fr}}
  .mnt-bars{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px 20px;margin-top:12px}
  .mnt-bar-top{display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px;gap:8px}
  .mnt-bar-top span{color:var(--muted)}
  .mnt-bar-track{height:12px;background:var(--bg);border:1px solid var(--border);border-radius:20px;overflow:hidden}
  .mnt-bar-fill{height:100%;border-radius:20px;transition:width .4s ease;min-width:2px}
  /* Responsivo: em telas estreitas tudo empilha e nada estoura a largura. */
  @media(max-width:640px){
    .mnt-grid{grid-template-columns:1fr}
    /* No celular a coluna não pode cair para 120px: "R$ 595.583,73" não cabe em uma linha nessa
       largura, e aí ou voltava a quebrar ou teria de ser cortado. 150px com fonte menor cabe. */
    .mnt-diag{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}
    .mnt-di span{font-size:16px}
    .mnt-di.longo span{font-size:13.5px}
    .mnt-info{gap:4px 14px}
    .mnt-bars{grid-template-columns:1fr}
  }
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('config') ?></header><main class="ws-main">

<div class="ws-head-row">
  <h2>🛠️ Manutenção / Emergência <span class="ws-muted" style="font-size:13px;font-weight:400">(apenas usuário root)</span></h2>
  <?php if ($ehRoot): ?>
  <div style="margin-left:auto">
    <input type="search" id="mntBusca" placeholder="🔍 Buscar manutenção..." style="padding:6px 12px; border-radius:20px; width:220px; border:1px solid var(--border); background:var(--bg); color:var(--text); font-size:13px">
  </div>
  <?php endif; ?>
</div>

<?php if (!$ehRoot): ?>
  <div class="ws-alert err">Esta área é exclusiva do usuário <b>root</b> (nível de acesso 99). Seu usuário não tem permissão.</div>
<?php else: ?>
  <?php if ($ok): ?><div class="ws-alert ok"><?= $h($ok) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="ws-alert err"><?= $h($err) ?></div><?php endif; ?>
  <p class="ws-muted" style="font-size:13px;max-width:900px">Cada comando abaixo explica exatamente o que faz. Todos exigem a <b>senha do root</b> para executar. Nada aqui apaga boletos nem o banco de dados.</p>

  <!-- DIAGNÓSTICO -->
  <div class="ws-panel" style="margin-top:6px">
    <b>📊 Diagnóstico do sistema</b>
    <div class="mnt-sec">📈 Indicadores</div>
    <div class="mnt-bars">
      <?php foreach ($ind as $b): ?>
        <div class="mnt-bar">
          <div class="mnt-bar-top"><span><?= $h($b[0]) ?></span><b><?= number_format($b[1], 1, ',', '.') ?>%</b></div>
          <div class="mnt-bar-track"><div class="mnt-bar-fill" style="width:<?= $b[1] ?>%;background:<?= $b[2] ?>"></div></div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php
      // Cada card do diagnóstico leva à página relacionada (clicável).
      $diagUrl = [
        'Clientes' => 'erp.php?p=clientes', 'Clientes ativos' => 'erp.php?p=clientes&status=ativo',
        'Instalações Recentes' => 'erp.php?p=clientes&status=recentes',
        'Contratos ativos' => 'erp.php?p=clientes&status=ativo', 'Contratos bloqueados' => 'erp.php?p=clientes&status=bloqueado',
        'Contratos cancelados' => 'erp.php?p=clientes&status=cancelado', 'Contratos PPPoE' => 'erp.php?p=clientes',
        'Contratos IPoE' => 'erp.php?p=clientes', 'Comodato' => 'erp.php?p=clientes',
        'Chamados (total)' => 'chamados.php?p=lista', 'Chamados abertos' => 'chamados.php?p=lista',
        'Leads (comercial)' => 'comercial.php', 'Planos ativos' => 'erp.php?p=planos',
        'Cidades' => 'erp.php?p=cadastros&t=cidades', 'Bairros' => 'erp.php?p=cadastros&t=bairros',
        'Ramais' => 'erp.php?p=cadastros&t=ramais', 'Zonas' => 'zonas.php', 'Estoque (itens)' => 'estoque.php',
        'Bancos/PIX' => 'provedor.php?p=bancos', 'NFS-e' => 'fiscal.php?p=notas',
        'Operadores ativos' => 'erp.php?p=config&t=operadores',
        'Faturas abertas' => 'financeiro.php?p=faturas', 'Faturas vencidas' => 'financeiro.php?p=faturas',
        'Vencem em 7 dias' => 'financeiro.php?p=faturas', 'Faturas pagas' => 'recibos.php',
        'Pagamentos (total)' => 'relatorios.php?p=caixa', 'Recebido hoje' => 'relatorios.php?p=caixa',
        'Recebido no mês' => 'relatorios.php?p=caixa', 'Recebido (total)' => 'relatorios.php?p=caixa',
        'A receber (aberto)' => 'relatorios.php?p=receber', 'Inadimplência' => 'relatorios.php?p=receber',
        'Sessões online agora' => 'radius.php?p=online', 'Logins no RADIUS' => 'radius.php?p=usuarios',
        'Registros radacct' => 'radius.php?p=usuarios', 'Concentradores/NAS' => 'radius.php?p=conc',
        'Ruas cadastradas' => 'erp.php?p=cadastros&t=cidades', 'CTOs' => 'olt_erp.php?p=cto',
      ];
      $secoes = ['👥 Cadastros & Operação' => $diag, '💰 Financeiro' => $diagFin, '🌐 Rede / RADIUS' => $diagRede];
      foreach ($secoes as $titulo => $itens): if (!$itens) continue; ?>
      <div class="mnt-sec"><?= $h($titulo) ?></div>
      <div class="mnt-diag">
        <?php foreach ($itens as $k => $v): $u = $diagUrl[$k] ?? '';
          /* Valor comprido (R$ na casa dos milhões) entra com a fonte menor, para caber em uma
             linha só e o quadro continuar do mesmo tamanho dos outros. */
          $cls = 'mnt-di' . (mb_strlen((string)$v) > 12 ? ' longo' : '');
          if ($u): ?>
            <a class="<?= $cls ?>" href="<?= $h($u) ?>" title="Abrir <?= $h($k) ?>"><span><?= $h($v) ?></span><label><?= $h($k) ?></label></a>
          <?php else: ?>
            <div class="<?= $cls ?>"><span><?= $h($v) ?></span><label><?= $h($k) ?></label></div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
    <div class="mnt-sec">🖥️ Servidor / Banco / Infra</div>
    <div class="mnt-info">
      <?php foreach ($diagDb as $k => $v): ?>
        <div><b><?= $h($k) ?>:</b> <?= $h($v) ?></div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ESPELHO: servidor principal + reserva (troca manual aqui; automática pelo modo) -->
  <?php require_once __DIR__ . '/espelho_lib.php'; $espC = ws_espelho_cfg(); $espE = ws_espelho_estado(); $espOn = !empty($espC['ativo']) && $espC['par'] !== ''; $espAuto = !empty($espC['failover_auto']);
        $espPapel = (string)($espE['papel'] ?? ''); $espIdade = !empty($espE['verificado_em']) ? time() - (int)$espE['verificado_em'] : null; $espParP = (string)($espE['par_papel'] ?? '?'); $espParOk = !empty($espE['par_alcancavel']); ?>
  <div class="mnt-sec" style="margin-top:20px" id="espelho">🪞 Espelho — servidor principal + reserva</div>
  <div class="mnt-grid">
    <!-- Configuração do espelho (campos) + ligar -->
    <?php $espLog = WS_CACHE . '/espelho_instalar.log'; $espLogTxt = (is_file($espLog) && time() - (int)@filemtime($espLog) < 21600) ? trim((string)@file_get_contents($espLog)) : ''; $espLogL = $espLogTxt !== '' ? array_slice(explode("\n", $espLogTxt), -14) : []; ?>
    <form method="post" class="mnt-card mnt-aberto" style="grid-column:1/-1">
      <span class="mnt-badge s">CONFIGURAÇÃO</span>
      <h3>⚙️ Configurar o espelho</h3>
      <div class="oque">Só é preciso se você tem <b>dois servidores</b> WellSystem. Com um servidor só, deixe como está: nada muda e o sistema trabalha normalmente. Rode a instalação no servidor de <b>produção</b> (o principal); ele copia o banco e os arquivos para o outro. O outro servidor precisa aceitar a chave deste: se a instalação pedir, ela mostra a linha para colar no outro servidor, uma vez.</div>
      <label class="ws-muted" style="font-size:12px">IP do outro servidor</label>
      <input class="senha" type="text" name="esp_par" value="<?= h((string)$espC['par']) ?>" placeholder="ex.: 100.65.5.6" pattern="[0-9a-fA-F:.]{7,45}">
      <label class="ws-muted" style="font-size:12px">Este servidor é o</label>
      <select class="senha" name="esp_pref"><option value="principal"<?= $espC['preferido'] === 'principal' ? ' selected' : '' ?>>Principal (o de produção, que está em uso)</option><option value="reserva"<?= $espC['preferido'] === 'reserva' ? ' selected' : '' ?>>Reserva (cópia do outro)</option></select>
      <label class="ws-muted" style="font-size:12px">Minutos sem resposta do principal para o reserva assumir (só no modo automático)</label>
      <input class="senha" type="number" name="esp_limite" min="1" max="30" value="<?= (int)$espC['falhas_limite'] ?>">
      <label class="ws-muted" style="font-size:12px">Quarentena depois de uma troca, em segundos (sem cobrança/mensagem automática, para nada sair em dobro)</label>
      <input class="senha" type="number" name="esp_quar" min="60" max="900" value="<?= (int)$espC['quarentena_s'] ?>">
      <input type="hidden" name="acao" value="espelho_pedido">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ws-btn" name="espelho_acao" value="configurar">Salvar configuração</button>
        <?php if (!$espOn): ?><button class="ws-btn primary" name="espelho_acao" value="instalar" onclick="return confirm('LIGAR O ESPELHO?\n\nO MariaDB deste servidor reinicia por alguns segundos (a escrita para) e o banco é copiado para o outro servidor. Faça de madrugada ou num horário calmo.')">🚀 Ligar o espelho</button><?php endif; ?>
      </div>
      <?php if ($espLogL): ?><div class="oque"><b>Passo a passo da instalação:</b><pre style="white-space:pre-wrap;font-size:12px;margin:6px 0 0"><?= h(implode("\n", $espLogL)) ?></pre></div><?php endif; ?>
    </form>

    <form method="post" class="mnt-card mnt-aberto<?= ($espOn && $espAuto) ? '' : ' perigo' ?>" style="grid-column:1/-1" onsubmit="return confirm('Confirma a ação do espelho?\n\nTrocar para este servidor: ele passa a gravar e os serviços automáticos (cobrança, mensagens, emissão, faturamento) passam a sair DAQUI; o outro vira cópia. Os serviços automáticos voltam depois de 3 minutos, para nada sair em dobro.')">
      <span class="mnt-badge <?= $espOn ? 's' : 'd' ?>">ESPELHO</span>
      <h3>🪞 Principal e reserva</h3>
      <?php if (!$espOn): ?>
      <div class="esp-modo off">⚪ NÃO CONFIGURADO<small>Com um servidor só está tudo certo: nada muda. Se você tem um segundo servidor, digite o <b>IP dele</b> no cartão <b>Configurar o espelho</b> (logo acima), salve e clique em <b>Ligar o espelho</b> (no servidor de produção). O outro vira cópia contínua (banco e arquivos); só o principal grava e envia cobrança e mensagens.</small></div>
      <?php else: ?>
      <?php if ($espAuto): ?>
      <div class="esp-modo auto">🤖 MODO AUTOMÁTICO — LIGADO<small>Se o principal ficar <?= (int)$espC['falhas_limite'] ?> min sem responder, o reserva assume sozinho. Você também pode trocar à mão quando quiser (botão abaixo).</small></div>
      <?php else: ?>
      <div class="esp-modo manual">🖐️ MODO MANUAL<small>Nada muda sozinho: a troca só acontece quando você mandar aqui. Se o principal cair, ligue o modo automático ou use "Trocar para este servidor".</small></div>
      <?php endif; ?>
      <div class="esp-par">
        <div class="esp-no este"><b class="t">Este servidor</b><?= $espPapel === 'principal' ? '🟢 PRINCIPAL — grava e envia' : ($espPapel === 'reserva' ? '🟡 RESERVA — só leitura, copiando do principal' : '❔ ainda sem leitura') ?></div>
        <div class="esp-no"><b class="t">Outro servidor (<?= h((string)$espC['par']) ?>)</b><?= !$espParOk ? '🔴 sem resposta' : ($espParP === 'principal' ? '🟢 PRINCIPAL' : '🟡 RESERVA') ?></div>
      </div>
      <div class="oque">
        <b>Cópia do banco:</b> <?= $espPapel === 'reserva' ? (!empty($espE['replica_io']) && !empty($espE['replica_sql']) ? '🟢 replicando' . (isset($espE['atraso_s']) ? ', atraso ' . (int)$espE['atraso_s'] . ' s' : '') : '🔴 parada' . (!empty($espE['replica_erro']) ? ' — ' . h((string)$espE['replica_erro']) : '')) : 'este é o principal; o outro copia daqui' ?>
        · <b>Batimento:</b> <?= isset($espE['pulso_idade_s']) ? 'há ' . (int)$espE['pulso_idade_s'] . ' s' : 'sem dado' ?>
        · <b>Arquivos copiados:</b> <?= !empty($espE['arquivos_em']) ? h(date('d/m H:i', (int)$espE['arquivos_em'])) . ' (' . (int)($espE['arquivos_qtd'] ?? 0) . ')' : '—' ?><?= !empty($espE['arquivos_erro']) ? ' <span style="color:var(--err)">ERRO: ' . h((string)$espE['arquivos_erro']) . '</span>' : '' ?>
        <?php if (!empty($espE['alerta'])): ?><br><b style="color:var(--err)">⚠️ <?= h((string)$espE['alerta']) ?></b><?php endif; ?>
        <?php if (!empty($espE['ultimo_pedido'])): ?><br><b>Último pedido:</b> <?= h((string)$espE['ultimo_pedido']) ?> (<?= h(date('d/m H:i', (int)($espE['ultimo_pedido_em'] ?? 0))) ?>)<?php endif; ?>
        <br><span style="opacity:.75">Verificado há <?= $espIdade === null ? '—' : (int)$espIdade . ' s' ?>. Cobrança, mensagens, emissão e faturamento automáticos saem só do principal; a baixa vale nos dois (o banco copia); ação manual feita no principal aparece no reserva na hora.</span>
      </div>
      <input type="hidden" name="acao" value="espelho_pedido">
      <select name="espelho_acao" class="senha" required>
        <?php if ($espPapel === 'reserva'): ?><option value="promover">🔁 Trocar para ESTE servidor (ele vira o principal, sem perder dados)</option><?php endif; ?>
        <?php if ($espPapel === 'principal'): ?><option value="virar_replica">⬇️ Este servidor vira RESERVA (só se o outro já é o principal)</option><?php endif; ?>
        <?php if (!$espAuto): ?><option value="auto_on">🤖 Ligar o MODO AUTOMÁTICO</option><?php else: ?><option value="auto_off">🖐️ Voltar para o MODO MANUAL</option><?php endif; ?>
      </select>
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Executar</button>
      <?php endif; ?>
    </form>

  </div>

  <?php if (!ws_fornecedor_desbloqueado()): $fl = $_SESSION['ws_flash_forn'] ?? ''; unset($_SESSION['ws_flash_forn']); ?>
  <div class="mnt-sec" style="margin-top:20px" id="fornecedor">🔒 Área do fornecedor</div>
  <div class="mnt-grid"><div class="mnt-card">
    <span class="mnt-badge s">TRAVADA</span>
    <h3>Licença e demonstração</h3>
    <?php if ($fl === 'erro'): ?><div class="ws-alert err">Código inválido, vencido ou de outro servidor.</div><?php elseif ($fl === 'ok'): ?><div class="ws-alert ok">Destravado.</div><?php endif; ?>
    <div class="resumo">Código deste servidor: <b style="letter-spacing:1px"><?= $h(ws_servidor_codigo()) ?></b></div>
    <form method="post" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="acao" value="fornecedor_desbloquear">
      <input name="codigo" class="senha" placeholder="código de desbloqueio" autocomplete="off" spellcheck="false" style="flex:1 1 240px" required>
      <button class="ws-btn primary">Destravar</button></form>
  </div></div>
  <?php else: ?>
  <form method="post" style="margin:20px 0 0"><input type="hidden" name="acao" value="fornecedor_travar"><button class="ws-btn">🔒 Travar a área do fornecedor</button></form>
  <div class="mnt-sec" style="margin-top:20px">🔐 Segurança, Licença &amp; Demonstração</div>
  <p class="ws-muted" style="font-size:12.5px;margin:2px 0 0">Controle de licença/ativação, senhas e o ambiente de demonstração isolado.</p>
  <div class="mnt-grid">

    <!-- Licença & Senhas (ativação + banco) -->
    <a class="mnt-card" href="erp.php?p=config&t=licenca" style="text-decoration:none;color:inherit">
      <span class="mnt-badge s">LICENÇA</span>
      <h3>🔐 Licença &amp; Senhas</h3>
      <div class="resumo">Status da ativação e troca de senhas por caixa (só root).</div>
      <div class="oque" style="display:flex;flex-direction:column;gap:5px">
        <span>📊 <b>Status da ativação</b> — mostra o host amarrado e a data em que este servidor foi ativado.</span>
        <span>🔑 <b>Senha de ATIVAÇÃO</b> — a que libera o sistema em cada servidor (até a de recuperação); trocada por caixa, sem terminal.</span>
        <span>🗄️ <b>Senha do BANCO</b> — muda a senha do usuário do banco no MySQL e atualiza a configuração.</span>
        <span>👤 <b>Senha de OPERADOR</b> — redefine a senha de login de qualquer operador (inclusive root).</span>
      </div>
      <span class="ws-btn primary" style="pointer-events:none;text-align:center">Abrir Licença &amp; Senhas →</span>
    </a>

    <!-- Ambiente DEMO -->
    <?php
      $demoCfg = ws_demo_cfg(); $demoOn = !empty($demoCfg['ativo']);
      $demoUrl = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://'
               . ($_SERVER['HTTP_HOST'] ?? '') . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/') . '/demo.php';
      // estilos das linhas (rótulo + campo)
      $rw = 'display:flex;align-items:center;gap:8px;margin-bottom:6px';
      $lb = 'width:88px;flex:none;color:var(--muted);font-size:12px';
    ?>
    <div class="mnt-card">
      <span class="mnt-badge s">DEMO</span>
      <h3>🧪 Ambiente de demonstração</h3>
      <div class="resumo">Ambiente de teste isolado (não afeta a produção). Você liga, envia o link e o cliente testa.</div>
      <div class="oque">
        🔒 <b>Sandbox isolado</b> — roda num banco separado (<code>_demo</code>); nada afeta seus dados reais (OLT, provedor e clientes reais não aparecem).<br><br>
        🔑 <b>Acesso do visitante:</b> <b>admin / admin123</b> · o sistema obriga a criar uma senha pessoal no 1º acesso.<br><br>
        ⏳ <b>Validade:</b> definida na "Duração"; ao vencer, a sessão encerra e os dados são apagados (limpo pro próximo).
      </div>

      <!-- Estado (só exibe) -->
      <div style="<?= $rw ?>"><span style="<?= $lb ?>">Estado</span><b style="color:<?= $demoOn?'var(--ok)':'var(--muted)' ?>"><?= $demoOn?'LIGADO':'Desligado' ?></b></div>

      <!-- LIGAR: Duração + Senha root -->
      <form method="post" style="margin:0">
        <input type="hidden" name="acao" value="demo_ligar">
        <div style="<?= $rw ?>"><span style="<?= $lb ?>">Duração</span><input class="senha" name="horas" value="<?= (int)($demoCfg['horas']??24) ?>" style="width:64px"><span style="font-size:12px;color:var(--muted)">horas</span></div>
        <div style="<?= $rw ?>"><span style="<?= $lb ?>">Senha root</span><input class="senha" type="password" name="senha" placeholder="sua senha root" required style="flex:1;min-width:80px"><button class="ws-btn verde">Ligar</button></div>
      </form>

      <!-- DESLIGAR -->
      <form method="post" style="margin:0">
        <input type="hidden" name="acao" value="demo_desligar">
        <div style="<?= $rw ?>"><span style="<?= $lb ?>">Senha root</span><input class="senha" type="password" name="senha" placeholder="sua senha root" required style="flex:1;min-width:80px"><button class="ws-btn">Desligar</button></div>
      </form>

      <!-- RESETAR -->
      <form method="post" style="margin:0" onsubmit="return confirm('Apagar TODOS os dados do ambiente demo?')">
        <input type="hidden" name="acao" value="demo_resetar">
        <div style="<?= $rw ?>"><span style="<?= $lb ?>">Senha root</span><input class="senha" type="password" name="senha" placeholder="sua senha root" required style="flex:1;min-width:80px"><button class="ws-btn danger">Resetar dados</button></div>
      </form>

      <!-- URL do demo (editável + botão abrir) -->
      <div style="<?= $rw ?>;margin-top:8px;border-top:1px dashed var(--border);padding-top:8px;margin-bottom:0">
        <span style="<?= $lb ?>">Demo URL</span>
        <input class="senha" id="demo_url_in" value="<?= $h($demoUrl) ?>" onclick="this.select()" title="Edite/copie o link do demo" style="flex:1;min-width:80px;font-size:11.5px;white-space:nowrap">
        <button type="button" onclick="var i=document.getElementById('demo_url_in');i.select();navigator.clipboard&&navigator.clipboard.writeText(i.value);this.textContent='✔ copiado';var b=this;setTimeout(function(){b.textContent='⧉ copiar'},1500);return false" class="ws-btn" style="padding:6px 10px;font-size:12px;flex:none" title="Copiar o link do demo">⧉ copiar</button>
        <a href="<?= $h($demoUrl) ?>" onclick="window.open(document.getElementById('demo_url_in').value,'_blank');return false" class="ws-btn" style="padding:6px 10px;font-size:12px;flex:none" title="Abrir a demonstração">↗ abrir</a>
      </div>
    </div>

    <!-- Contas de teste criadas no DEMO -->
    <?php
      $demoUsers  = ws_demo_users_lista();          // [login => expira_ts] (contas criadas pelos visitantes)
      $demoOnline = ws_demo_logins_online();        // [login => true] (vistos nos últimos 5 min)
      $nOnline    = 0; foreach ($demoUsers as $lg => $ex) if (!empty($demoOnline[$lg])) $nOnline++;
    ?>
    <div class="mnt-card" id="demousers">
      <span class="mnt-badge s">DEMO · CONTAS</span>
      <h3>👥 Contas de teste no demo</h3>
      <div class="resumo"><b style="font-size:17px;color:var(--brand)"><?= count($demoUsers) ?></b> conta(s) criada(s) · <b style="color:var(--ok)"><?= $nOnline ?> online</b> agora</div>
      <?php if ($demoUsers): ?>
        <div style="max-height:190px;overflow:auto;margin-top:6px">
          <?php foreach ($demoUsers as $lg => $exp): $on = !empty($demoOnline[$lg]); $rest = max(0, (int)$exp - time()); ?>
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;font-size:12px;padding:5px 0;border-bottom:1px solid var(--border)">
              <span style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <span title="<?= $on ? 'online' : 'offline' ?>" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:<?= $on ? 'var(--ok)' : 'var(--muted,#999)' ?>;margin-right:6px"></span>
                <b><?= $h($lg) ?></b>
                <span class="ws-muted" style="margin-left:6px"><?= $on ? 'online' : 'offline' ?> · <?= $rest > 0 ? (floor($rest/3600) . 'h' . str_pad((string)floor(($rest%3600)/60), 2, '0', STR_PAD_LEFT)) . 'min' : 'expirada' ?></span>
              </span>
              <form method="post" onsubmit="return confirm('Excluir a conta de teste \'<?= $h($lg) ?>\'? Ela sai do demo imediatamente.')" style="margin:0;flex:none">
                <input type="hidden" name="acao" value="demo_user_excluir">
                <input type="hidden" name="login" value="<?= $h($lg) ?>">
                <button class="ws-btn danger" style="padding:4px 9px;font-size:11.5px" title="Excluir esta conta de teste">🗑 excluir</button>
              </form>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="ws-muted" style="font-size:12px;margin-top:4px">Nenhuma conta de teste criada ainda. Os visitantes criam a conta deles depois de entrar com admin/admin123.</div>
      <?php endif; ?>
      <div class="oque">Cada linha é uma <b>conta de teste</b> que um visitante criou (login próprio + tempo próprio). O ponto <b style="color:var(--ok)">verde</b> = online agora; cinza = offline. Use <b>🗑 excluir</b> para remover a conta do sandbox na hora.</div>
    </div>

  </div>

  <?php endif; /* área do fornecedor */ ?>

  <div class="mnt-sec">🌐 Rede / RADIUS / Conexões</div>
  <p class="ws-muted" style="font-size:12.5px;margin:2px 0 0">Bloqueio/liberação em massa, sincronização do RADIUS e sessões dos clientes.</p>
  <div class="mnt-grid">

    <?php /* SINCRONIZAR DADOS DE REDE — só LEITURA da OLT e dos concentradores; não desconecta
             ninguém, não mexe em bloqueio, não altera cobrança. Por isso não é card de perigo. */ ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Conferir a OLT e os concentradores e preencher os dados de rede dos contratos?\n\nSó LEITURA: ninguém é desconectado e nada de cobrança muda.')">
      <span class="mnt-badge">SEGURO</span>
      <input type="hidden" name="acao" value="sinc_rede">
      <b>📡 Sincronizar dados de rede dos contratos</b>
      <small>Preenche zona, VLAN, placa, PON, sinal RX/TX, retorno da OLT, modelo do equipamento,
        último IP e concentrador — em <b>todos</b> os contratos de uma vez.
        A ficha do cliente já faz isso sozinha a cada 45s, mas só enquanto alguém a mantém aberta;
        aqui vale para quem ninguém abre. Valor igual não é reescrito, campo vazio é preenchido e
        o que você digitou em campo de cadastro não é desfeito.</small>
      <input type="password" name="senha" placeholder="senha do root" required autocomplete="off">
      <button type="submit">Sincronizar agora</button>
    </form>

    <!-- Bloquear todos -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('BLOQUEAR TODOS os clientes ativos? Eles ficam sem internet até desbloquear.')">
      <span class="mnt-badge d">EM MASSA</span>
      <h3>🔒 Bloquear todos</h3>
      <div class="oque">Coloca <b>todos os contratos ATIVOS</b> em status <b>bloqueado</b> e reflete no RADIUS na hora — o cliente perde a conexão. Não apaga nada. Use em corte geral programado.</div>
      <input type="hidden" name="acao" value="bloquear_todos">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Bloquear todos</button>
    </form>

    <!-- Desbloquear todos -->
    <form method="post" class="mnt-card" onsubmit="return confirm('DESBLOQUEAR TODOS os clientes bloqueados?')">
      <span class="mnt-badge s">EM MASSA</span>
      <h3>🔓 Desbloquear todos</h3>
      <div class="oque">Volta <b>todos os contratos BLOQUEADOS</b> para <b>ativo</b> e libera no RADIUS na hora. Use para religar geral após um corte.</div>
      <input type="hidden" name="acao" value="desbloquear_todos">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn verde">Desbloquear todos</button>
    </form>


    <!-- Ressincronizar RADIUS -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Ressincronizar TODOS os contratos no RADIUS agora?')">
      <span class="mnt-badge s">RADIUS</span>
      <h3>🔁 Ressincronizar RADIUS (todos)</h3>
      <div class="oque">Reprovisiona <b>todo contrato não cancelado</b> no RADIUS, aplicando a <b>regra de bloqueio por inadimplência</b> (bloqueia quem deve, libera quem está em dia). Corrige senha/grupo/IP fora de sincronia — a "faxina" padrão do RADIUS.</div>
      <input type="hidden" name="acao" value="ressync_radius">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Ressincronizar RADIUS</button>
    </form>

    <!-- Reprovisionar RADIUS por tipo/VLAN -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Reprovisionar o RADIUS com esse filtro?')">
      <span class="mnt-badge s">RADIUS</span>
      <h3>🧩 Reprovisionar RADIUS (tipo/VLAN)</h3>
      <div class="oque">Recria no RADIUS (senha/grupo/IP) os contratos filtrados por <b>tipo</b> (PPPoE/IPoE) e/ou <b>VLAN</b>. Deixe em branco para <b>todos</b>. Aplica a regra de bloqueio. Use para "zerar" IPoE/PPPoE ou uma VLAN específica.</div>
      <div style="display:flex;gap:8px">
        <select class="senha" name="tipo" style="flex:1"><option value="">Todos os tipos</option><option value="pppoe">PPPoE</option><option value="ipoe">IPoE</option></select>
        <input class="senha" name="vlan" placeholder="VLAN (opcional)" style="flex:1">
      </div>
      <input type="hidden" name="acao" value="reprov_radius">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Reprovisionar</button>
    </form>

    <!-- Zerar senhas (= login) -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('Redefinir a senha de conexão para IGUAL ao login em massa?')">
      <span class="mnt-badge d">RADIUS</span>
      <h3>🔑 Zerar senhas (senha = login)</h3>
      <div class="oque">Redefine a <b>senha de conexão de todos</b> os contratos (ou só do tipo escolhido) para ficar <b>igual ao login</b>, e atualiza o RADIUS. Resolve senha fora de sincronia. Os clientes autenticam com senha = login.</div>
      <select class="senha" name="tipo"><option value="">Todos os tipos</option><option value="pppoe">Só PPPoE</option><option value="ipoe">Só IPoE</option></select>
      <input type="hidden" name="acao" value="zera_senhas">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Zerar senhas</button>
    </form>

    <!-- Derrubar conexões -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Derrubar/reiniciar as conexões com esse filtro?')">
      <span class="mnt-badge s">CONEXÃO</span>
      <h3>⚡ Derrubar/reiniciar conexões</h3>
      <div class="oque">Força a <b>reconexão</b> (disconnect) das sessões ativas — em massa ou filtrando por <b>VLAN</b>, <b>login (ID)</b> ou <b>IP</b>. O cliente reconecta sozinho. Use após trocar plano/bloqueio ou para limpar sessões travadas.</div>
      <div style="display:flex;gap:8px">
        <select class="senha" name="por" style="flex:1">
          <option value="todos">Todos</option>
          <option value="vlan">Por VLAN</option>
          <option value="login">Por login PPPoE</option>
          <option value="senha">Por senha PPPoE</option>
          <option value="ip">Por IP</option>
          <option value="nome">Por nome</option>
          <option value="nome_reduzido">Por nome reduzido</option>
          <option value="cpf">Por CPF/CNPJ</option>
        </select>
        <input class="senha" name="valor" placeholder="valor (VLAN/login/senha/IP/nome/CPF)" style="flex:1">
      </div>
      <input type="hidden" name="acao" value="derrubar_conexoes">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Derrubar conexões</button>
    </form>

    <!-- Modo manutenção (login travado, exceto admin/root) -->
    <form method="post" class="mnt-card <?= $manutLogin['ativo'] ? 'perigo' : '' ?>" onsubmit="return confirm('<?= $manutLogin['ativo'] ? 'DESLIGAR' : 'LIGAR' ?> o modo manutenção agora?')">
      <span class="mnt-badge <?= $manutLogin['ativo'] ? 'd' : 's' ?>">ACESSO</span>
      <h3>🚧 Modo manutenção (só admin/root)</h3>
      <div class="oque">Enquanto ligado, <b>ninguém consegue entrar ou continuar usando o sistema</b> exceto usuários <b>admin/root</b> — quem já estava logado sem ser admin/root é <b>desconectado na hora</b>. Use antes de uma manutenção delicada; desligue depois para liberar todo mundo de novo.
        <br>Status atual: <b><?= $manutLogin['ativo'] ? '🔴 LIGADO' : '🟢 desligado' ?></b><?= ($manutLogin['ativo'] && trim($manutLogin['motivo']) !== '') ? ' — ' . $h($manutLogin['motivo']) : '' ?></div>
      <input class="senha" name="motivo" placeholder="motivo (opcional, aparece pra quem tentar entrar)" value="<?= $h($manutLogin['motivo']) ?>">
      <input type="hidden" name="acao" value="manutencao_login_toggle">
      <input type="hidden" name="ativar" value="<?= $manutLogin['ativo'] ? '0' : '1' ?>">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn <?= $manutLogin['ativo'] ? 'danger' : 'primary' ?>"><?= $manutLogin['ativo'] ? 'Desligar modo manutenção' : 'Ligar modo manutenção' ?></button>
    </form>

    <!-- Zerar tráfego -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('ZERAR todo o tráfego/histórico? Os gráficos recomeçam do zero.')">
      <span class="mnt-badge d">TRÁFEGO</span>
      <h3>📉 Zerar tráfego geral</h3>
      <div class="oque">Apaga o <b>accounting (radacct)</b>, o <b>histórico de online</b> e os <b>caches de tráfego</b>. Os gráficos de consumo/online recomeçam do zero. Não afeta clientes, boletos nem conexões ativas.</div>
      <input type="hidden" name="acao" value="zera_trafego">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Zerar tráfego</button>
    </form>

  </div>

  <div class="mnt-sec">💰 Financeiro / Cobrança</div>
  <p class="ws-muted" style="font-size:12.5px;margin:2px 0 0">Ações sobre recebimentos e inadimplência (não excluem boletos).</p>
  <div class="mnt-grid">

    <!-- Diagnóstico: concentradores (NAS) × RADIUS (só leitura) -->
    <div class="mnt-card" id="diag-nas">
      <span class="mnt-badge s">DIAGNÓSTICO</span>
      <h3>📡 Concentradores × RADIUS</h3>
      <div class="oque">Mostra, para cada concentrador cadastrado, se o RADIUS o <b>conhece</b>, quantos pedidos foram <b>ignorados na última hora</b> e quantas sessões estão abertas. Só leitura.</div>
      <?php if ($diagNome === 'nas' && is_array($diagRes)): ?>
        <table class="ws-table" style="font-size:12.5px"><thead><tr><th>Concentrador</th><th>Sessões</th><th>Logins OK (1 h)</th><th>Ignorados (1 h)</th></tr></thead><tbody>
        <?php foreach ($diagRes['nas'] as $ip => $x): ?><tr><td><b><?= $h($x['nome']) ?></b> <span class="ws-muted"><?= $h($ip) ?></span></td><td><?= (int)$x['sessoes'] ?></td><td><?= (int)$x['ok'] ?></td><td style="<?= $x['ignorados'] > 0 ? 'color:#dc2626;font-weight:700' : '' ?>"><?= (int)$x['ignorados'] ?></td></tr><?php endforeach; ?>
        <?php if (!$diagRes['nas']): ?><tr><td colspan="4" class="ws-muted">Nenhum concentrador cadastrado.</td></tr><?php endif; ?>
        </tbody></table>
        <?php if ($diagRes['desconhecidos']): ?><div class="ws-muted" style="font-size:12px;margin-top:6px"><b>Não cadastrados</b> (pedidos na última hora): <?php foreach (array_slice($diagRes['desconhecidos'], 0, 8, true) as $ip => $n) echo $h($ip) . ' (' . (int)$n . ') · '; ?><br>Se algum for um concentrador seu, cadastre-o e use "Recarregar concentradores". IP de fora da sua rede costuma ser varredura da internet.</div><?php endif; ?>
        <?php if (!$diagRes['log_lido']): ?><div class="ws-muted" style="font-size:12px">Não consegui ler o registro do RADIUS neste servidor.</div><?php endif; ?>
      <?php endif; ?>
      <a class="ws-btn primary" href="manutencao.php?diag=nas#diag-nas">Verificar agora</a>
    </div>

    <!-- Diagnóstico: internet e DNS (só leitura) -->
    <div class="mnt-card" id="diag-internet">
      <span class="mnt-badge s">DIAGNÓSTICO</span>
      <h3>🌐 Internet e DNS do servidor</h3>
      <div class="oque">Testa se este servidor <b>resolve nomes</b> e <b>alcança</b> a Evolution, o n8n, o GitHub, o Debian e os gateways de cobrança. Mostra o que está fora do ar. Só leitura (leva alguns segundos).</div>
      <?php if ($diagNome === 'internet' && is_array($diagRes)): ?>
        <table class="ws-table" style="font-size:12.5px"><thead><tr><th>Serviço</th><th>DNS</th><th>Resposta</th><th>Tempo</th></tr></thead><tbody>
        <?php foreach ($diagRes as $x): ?><tr><td><b><?= $h($x['nome']) ?></b> <span class="ws-muted"><?= $h($x['host']) ?></span></td><td><?= $x['dns'] ? '✅' : '❌ não resolve' ?></td><td style="color:<?= $x['http'] > 0 ? '#16a34a' : '#dc2626' ?>"><?= $x['http'] > 0 ? 'HTTP ' . (int)$x['http'] : '❌ sem resposta' ?></td><td><?= (int)$x['ms'] ?> ms</td></tr><?php endforeach; ?>
        </tbody></table>
      <?php endif; ?>
      <a class="ws-btn primary" href="manutencao.php?diag=internet#diag-internet">Testar agora</a>
    </div>

    <!-- Restaurar backup com segurança -->
    <?php if (!function_exists('ws_backup_lista') && is_file(__DIR__ . '/backup_lib.php')) { require_once __DIR__ . '/backup_lib.php'; } $bkLista = defined('WS_BACKUP_DIR') ? (glob(WS_BACKUP_DIR . '/*.sql') ?: []) : []; usort($bkLista, fn($a, $b) => filemtime($b) <=> filemtime($a)); ?>
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('RESTAURAR este backup? Ele SUBSTITUI os dados deste servidor. O envio de WhatsApp fica PAUSADO ao terminar e os concentradores são recarregados.')">
      <span class="mnt-badge d">BACKUP</span>
      <h3>♻️ Restaurar backup com segurança</h3>
      <div class="oque">Restaura o backup escolhido e, ao terminar, <b>deixa o envio de mensagens pausado</b> (para servidor de teste não mandar aviso a cliente real) e <b>recarrega os concentradores</b> no RADIUS. Depois, em "Retomar envio de mensagens", você liga de volta quando quiser. <b>Substitui os dados deste servidor.</b></div>
      <select name="arquivo" class="senha" required>
        <?php foreach (array_slice($bkLista, 0, 15) as $bkf): ?><option value="<?= $h(basename($bkf)) ?>"><?= $h(basename($bkf)) ?> — <?= round(filesize($bkf) / 1048576, 1) ?> MB — <?= date('d/m H:i', filemtime($bkf)) ?></option><?php endforeach; ?>
        <?php if (!$bkLista): ?><option value="">(nenhum backup na pasta — envie um em Backup)</option><?php endif; ?>
      </select>
      <input type="hidden" name="acao" value="restaurar_seguro">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Restaurar com segurança</button>
    </form>

    <!-- Fila de avisos de bloqueio/desbloqueio -->
    <?php $filaAv = json_decode((string)@file_get_contents(WS_CACHE . '/msg_eventos_fila.json'), true); $nFilaB = 0; $nFilaD = 0; foreach ((array)$filaAv as $fa) { if (($fa['tipo'] ?? '') === 'bloqueio') $nFilaB++; elseif (($fa['tipo'] ?? '') === 'desbloqueio') $nFilaD++; } ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Zerar a fila de avisos de bloqueio/desbloqueio?')">
      <span class="mnt-badge s">MENSAGENS</span>
      <h3>🧹 Fila de avisos de bloqueio/desbloqueio</h3>
      <div class="oque">Na fila agora: <b><?= $nFilaB ?></b> aviso(s) de bloqueio e <b><?= $nFilaD ?></b> de desbloqueio, esperando a janela de envio. Zerar descarta esses avisos e <b>esquece o estado antigo</b>: a próxima passada só tira a foto (nada é enviado por mudança antiga).</div>
      <input type="hidden" name="acao" value="zerar_fila_avisos">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Zerar fila</button>
    </form>

    <!-- Pausar / retomar envio de mensagens -->
    <?php $waCard = (is_file(__DIR__ . '/whatsapp.php') ? (function () { require_once __DIR__ . '/whatsapp.php'; return ws_wa_config(); })() : []); $envioPausado = (($waCard['gateway'] ?? 'evolution') === 'desativado'); ?>
    <form method="post" class="mnt-card <?= $envioPausado ? '' : 'perigo' ?>" onsubmit="return confirm('<?= $envioPausado ? 'RETOMAR o envio automático de WhatsApp?' : 'PAUSAR todo envio automático de WhatsApp (cobrança, avisos, recibos, resumo)?' ?>')">
      <span class="mnt-badge <?= $envioPausado ? 's' : 'd' ?>">MENSAGENS</span>
      <h3><?= $envioPausado ? '▶️ Retomar envio de mensagens' : '⏸️ Pausar envio de mensagens' ?></h3>
      <div class="oque">Estado agora: <b><?= $envioPausado ? 'PAUSADO — nada sai pelo WhatsApp' : 'LIGADO' ?></b>. Pausar corta <b>todo envio automático</b> (cobrança, aviso de bloqueio/desbloqueio, recibo, resumo) e zera a fila. Use ao <b>restaurar backup em servidor de teste</b>, para não mandar mensagem a cliente real.</div>
      <input type="hidden" name="acao" value="<?= $envioPausado ? 'msg_retomar' : 'msg_pausar' ?>">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn <?= $envioPausado ? 'primary' : 'danger' ?>"><?= $envioPausado ? 'Retomar envio' : 'Pausar envio' ?></button>
    </form>

    <!-- WhatsApp comum: reconectar pelo QR ao vivo -->
    <?php $waInstComum = (function () { require_once __DIR__ . '/whatsapp.php'; $c = ws_wa_config(); return array_values(array_unique(array_merge(ws_wa_instancias($c), function_exists('ws_wa_instancias_comum') ? ws_wa_instancias_comum($c) : []))); })(); ?>
    <div class="mnt-card" id="cartao-qr">
      <span class="mnt-badge s">WHATSAPP</span>
      <h3>📱 Reconectar WhatsApp (QR ao vivo)</h3>
      <div class="oque">Use quando a conversa pelo WhatsApp comum <b>parar de receber</b> ou ficar desconectada. Aparece o QR <b>atualizando sozinho</b> (ele troca a cada ~20 s): no celular do número, <b>WhatsApp → Aparelhos conectados → Conectar um aparelho</b> e aponte para a tela. Quando conectar, a tela avisa. Só consulta; não apaga nada.</div>
      <select id="qr-inst" class="senha"><?php foreach ($waInstComum as $iq) echo '<option>' . $h($iq) . '</option>'; ?></select>
      <button type="button" class="ws-btn primary" id="qr-btn" onclick="qrVivo()">Mostrar QR</button>
      <div id="qr-area" style="text-align:center"></div>
    </div>
    <script>
    var qrT = null;
    function qrVivo(){
      var inst = document.getElementById('qr-inst').value, area = document.getElementById('qr-area');
      if (qrT) { clearInterval(qrT); qrT = null; }
      function passo(){
        fetch('manutencao.php?qr_vivo=' + encodeURIComponent(inst), {cache:'no-store'}).then(function(r){return r.json();}).then(function(j){
          if (j.erro) { area.textContent = j.erro; return; }
          if (j.estado === 'open') { area.innerHTML = '<p><b>✅ ' + inst + ' CONECTADA</b> (' + j.em + ')</p>'; clearInterval(qrT); qrT = null; return; }
          area.innerHTML = j.qr ? '<img alt="QR" style="width:260px;height:260px;image-rendering:pixelated;background:#fff;padding:8px" src="' + j.qr + '"><p style="font-size:12px">Atualizado ' + j.em + ' — estado: ' + j.estado + '</p>' : '<p>Gerando o QR… (estado: ' + j.estado + ')</p>';
        }).catch(function(){ area.textContent = 'Sem resposta do servidor.'; });
      }
      passo(); qrT = setInterval(passo, 12000);
    }
    </script>

    <!-- Recarregar concentradores no RADIUS -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Recarregar a lista de concentradores no FreeRADIUS? (leva ~2 s, quem está conectado continua)')">
      <span class="mnt-badge s">RADIUS</span>
      <h3>🔄 Recarregar concentradores (NAS)</h3>
      <div class="oque">O RADIUS só lê a lista de concentradores ao iniciar. Se ele ignora um concentrador (<b>"concentrador desconhecido"</b> no log), use aqui: o serviço reinicia em até 1 minuto e passa a aceitar. Acontece sozinho quando a lista muda; este botão é para forçar.</div>
      <input type="hidden" name="acao" value="radius_recarregar_nas">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Recarregar agora</button>
    </form>

    <!-- Licença online (consulta diária ao servidor de licenças) -->
    <?php [$licO, $licT] = function_exists('ws_lic_situacao') ? ws_lic_situacao() : [true, 'indisponível']; ?>
    <form method="post" class="mnt-card">
      <span class="mnt-badge <?= $licO ? 's' : '' ?>">LICENÇA</span>
      <h3>🔐 Licença online (consulta diária)</h3>
      <div class="oque">O sistema confere com o servidor de licenças <b>uma vez por dia</b>. Sem internet ou com o servidor fora do ar, <b>nada trava</b>: ele só bloqueia se o fornecedor revogar a licença (aviso por 7 dias, depois somente leitura). Situação agora: <b><?= h($licT) ?></b>.</div>
      <input type="hidden" name="acao" value="licenca_consultar">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Consultar agora</button>
    </form>

    <!-- Hora certa e envio de logs ao servidor de logs -->
    <form method="post" class="mnt-card">
      <span class="mnt-badge">REDE</span>
      <h3>🕒 Hora e logs do servidor</h3>
      <div class="oque">Refaz a <b>hora certa</b> (chrony com a NTP.br) e o <b>envio dos logs</b> deste servidor ao servidor de logs — log do RADIUS, acessos e registro de cada conexão. Use se a hora estiver errada ou depois de trocar o endereço do servidor de logs (<a href="logs_servidor.php">Logs de conexão</a>). Não derruba ninguém.</div>
      <input type="hidden" name="acao" value="logs_envio_reaplicar">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Reaplicar agora</button>
    </form>

    <!-- Revisão do atendimento (Chatwoot) -->
    <?php $atr = json_decode((string)@file_get_contents(WS_CACHE . '/atendimento_revisao.json'), true); $atr = is_array($atr) ? $atr : []; $atc = []; foreach ((array)($atr['achados'] ?? []) as $ax) $atc[$ax['categoria']] = ($atc[$ax['categoria']] ?? 0) + 1; ?>
    <form method="post" class="mnt-card">
      <span class="mnt-badge">ATENDIMENTO</span>
      <h3>🔎 Revisão do atendimento</h3>
      <p><?= $atr ? 'Última revisão: ' . h(date('d/m/Y H:i', (int)$atr['ate'])) . ' — ' . (int)$atr['conversas'] . ' conversa(s), ' . count((array)$atr['achados']) . ' ponto(s) a corrigir' . ($atc ? ' (' . h(implode(', ', array_map(function ($k, $v) { return "$k: $v"; }, array_keys($atc), $atc))) . ')' : '') . '.' : 'Ainda não rodou.' ?></p>
      <?php foreach (array_slice((array)($atr['achados'] ?? []), 0, 8) as $ax): ?><p><small>#<?= (int)$ax['conversa'] ?> <?= h($ax['contato']) ?> · <?= h($ax['quando']) ?> · <?= h($ax['categoria']) ?> — <?= h($ax['detalhe']) ?></small></p><?php endforeach; ?>
      <input type="hidden" name="acao" value="atendimento_revisar_agora">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Revisar agora</button>
    </form>

    <!-- URA telefônica -->
    <?php require_once __DIR__ . '/ura_lib.php'; $uraC = ws_ura_cfg(); ?>
    <div class="mnt-card">
      <span class="mnt-badge s">TELEFONIA</span>
      <h3>📞 URA telefônica (boleto, confiança, suporte)</h3>
      <div class="oque">O cliente liga, digita o CPF e faz pelo telefone o que o robô do WhatsApp faz: <b>1</b> segunda via, <b>2</b> liberação em confiança, <b>3</b> suporte, <b>4</b> atendente. Estado: <b>URA <?= $uraC['ativo'] ? 'LIGADA' : 'DESLIGADA' ?></b> · envio do boleto por WhatsApp <b><?= $uraC['envio_whatsapp'] ? 'LIGADO (Wellnet-02, custo por mensagem; no máximo ' . (int)$uraC['envio_dia'] . ' por CPF em 24 h)' : 'DESLIGADO (só voz)' ?></b> · voz (falar em vez de digitar) <b><?= $uraC['voz'] ? 'LIGADA' : 'DESLIGADA (só teclado)' ?></b> · menu do chat depois da opção 4 fora do horário (robô da Wellnet-01, 1 vez por número em 24 h) <b><?= $uraC['chat_menu'] ? 'LIGADO' : 'DESLIGADO' ?></b> · chave: <b><?= $uraC['chave'] !== '' ? 'definida' : 'NÃO definida (a URA recusa tudo)' ?></b>. Desligada, a opção da URA manda o cliente direto para o atendimento.</div>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="<?= $uraC['ativo'] ? 'ura_desligar' : 'ura_ligar' ?>"><input class="senha" type="password" name="senha" placeholder="senha do root" required> <button class="ws-btn <?= $uraC['ativo'] ? 'danger' : 'primary' ?>"><?= $uraC['ativo'] ? 'Desligar a URA' : 'Ligar a URA' ?></button></form>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="<?= $uraC['envio_whatsapp'] ? 'ura_envio_desligar' : 'ura_envio_ligar' ?>"><input class="senha" type="password" name="senha" placeholder="senha do root" required> <button class="ws-btn <?= $uraC['envio_whatsapp'] ? 'danger' : 'primary' ?>"><?= $uraC['envio_whatsapp'] ? 'Desligar envio por WhatsApp' : 'Ligar envio por WhatsApp' ?></button></form>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="<?= $uraC['voz'] ? 'ura_voz_desligar' : 'ura_voz_ligar' ?>"><input class="senha" type="password" name="senha" placeholder="senha do root" required> <button class="ws-btn <?= $uraC['voz'] ? 'danger' : 'primary' ?>"><?= $uraC['voz'] ? 'Desligar a voz' : 'Ligar a voz' ?></button></form>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="<?= $uraC['chat_menu'] ? 'ura_chat_desligar' : 'ura_chat_ligar' ?>"><input class="senha" type="password" name="senha" placeholder="senha do root" required> <button class="ws-btn <?= $uraC['chat_menu'] ? 'danger' : 'primary' ?>"><?= $uraC['chat_menu'] ? 'Desligar menu do chat' : 'Ligar menu do chat' ?></button></form>
    </div>

    <!-- Prazo legal dos registros de conexão -->
    <?php $retj = json_decode((string)@file_get_contents(WS_CACHE . '/logs_retencao.json'), true); $retj = is_array($retj) ? $retj : []; ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('APAGAR os registros de conexão com mais de 1 ano?\n\nÉ o prazo da lei (Marco Civil da Internet, art. 13). Sessões ainda abertas nunca são apagadas. Não dá para desfazer.')">
      <span class="mnt-badge">LEI</span>
      <h3>⚖️ Prazo legal dos registros de conexão (1 ano)</h3>
      <div class="oque">Guarda os <b>registros de conexão</b> (sessões do RADIUS, tentativas de login e arquivos do FreeRADIUS) só pelo prazo que a lei exige — <b>1 ano</b> (Marco Civil da Internet, art. 13). Passou disso, o dia mais antigo é apagado para dar lugar ao novo; isso roda sozinho todo dia depois das 03:10. Sessão ainda aberta nunca é apagada. <?= $retj ? '<br><b>Última rodada:</b> ' . h(date('d/m/Y H:i', strtotime((string)$retj['em']))) . ' — apagou ' . (int)$retj['radacct'] . ' sessão(ões), ' . (int)$retj['radpostauth'] . ' tentativa(s) de login e ' . (int)$retj['arquivos'] . ' arquivo(s)' . (!empty($retj['erro']) ? ' (erro: ' . h($retj['erro']) . ')' : '') . '.' : '<br>Ainda não rodou.' ?></div>
      <input type="hidden" name="acao" value="logs_retencao_agora">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Rodar agora</button>
    </form>

    <!-- Reiniciar o servidor (kernel novo, atualizações do Linux) -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('REINICIAR O SERVIDOR?\n\nEle fica fora do ar por cerca de 1 minuto: não autentica cliente novo nesse intervalo e o painel cai. As sessões já abertas continuam nos concentradores.')">
      <span class="mnt-badge d">SERVIDOR</span>
      <h3>♻️ Reiniciar o servidor</h3>
      <div class="oque">Reinicia o computador do WellSystem (Linux, painel, banco e RADIUS). Use depois de atualizar o Linux quando aparecer <b>kernel novo</b> (só passa a valer após reiniciar). Leva cerca de 1 minuto; escolha um horário calmo. Não apaga nada.</div>
      <input type="hidden" name="acao" value="reiniciar_servidor">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Reiniciar agora</button>
    </form>

    <!-- Trocar a chave do robô -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('TROCAR A CHAVE DO ROBÔ?\n\nA chave antiga continua valendo até você apagá-la, então nada que já foi enviado quebra.')">
      <span class="mnt-badge d">SEGURANÇA</span>
      <h3>🔐 Trocar a chave do robô</h3>
      <div class="oque">Gera uma chave nova para os endereços do robô (links PIX, webhooks da Evolution e do Chatwoot, n8n). A <b>anterior continua valendo</b> até ser apagada. Depois de atualizar o n8n, use "Apagar chave anterior".</div>
      <input type="hidden" name="acao" value="trocar_chave_robo">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Trocar a chave</button>
    </form>

    <!-- Apagar a chave anterior do robô -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('APAGAR A CHAVE ANTERIOR?\n\nLinks PIX e endereços antigos deixam de funcionar. Faça isso só depois de atualizar o n8n.')">
      <span class="mnt-badge d">SEGURANÇA</span>
      <h3>🗑️ Apagar chave anterior do robô</h3>
      <div class="oque">Encerra a validade da chave antiga (links PIX já enviados e endereços antigos param de funcionar). Use só depois de trocar a chave e atualizar o n8n.</div>
      <input type="hidden" name="acao" value="apagar_chave_anterior">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Apagar chave anterior</button>
    </form>

    <?php if (ws_fornecedor_desbloqueado()): ?>
    <!-- Apagar chave de ativação -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('APAGAR A CHAVE DE ATIVAÇÃO deste servidor?\n\nO sistema volta a pedir a chave no próximo acesso. Tenha a chave em mãos antes de continuar.')">
      <span class="mnt-badge d">LICENÇA</span>
      <h3>🔑 Apagar chave de ativação</h3>
      <div class="oque">Remove a chave de ativação <b>deste servidor</b> (e as cópias de segurança dela). Depois o sistema <b>pede a chave de novo</b> no próximo acesso. Não apaga clientes, boletos nem configurações.</div>
      <input type="hidden" name="acao" value="apagar_ativacao">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Apagar chave de ativação</button>
    </form>
    <?php endif; ?>

    <!-- Zerar caixa -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('ZERAR O CAIXA no período? Apaga os RECEBIMENTOS (os boletos voltam a aberto, mas NÃO são excluídos).')">
      <span class="mnt-badge d">FINANCEIRO</span>
      <h3>🧾 Zerar caixa (por período)</h3>
      <div class="oque">Apaga <b>todos os recebimentos/pagamentos</b> do período escolhido (zera boleto em massa). Os <b>boletos NÃO são excluídos</b> — voltam para <b>aberto</b>. Não mexe em cliente/contrato. Irreversível.</div>
      <div style="display:flex;gap:8px">
        <input class="senha" type="date" name="ini" value="<?= date('Y-m-01') ?>" style="flex:1" required>
        <input class="senha" type="date" name="fim" value="<?= date('Y-m-d') ?>" style="flex:1" required>
      </div>
      <input type="hidden" name="acao" value="zerar_caixa">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Zerar caixa do período</button>
    </form>

    <!-- Reprocessar faturas em atraso -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Reprocessar inadimplência e bloquear quem está em atraso?')">
      <span class="mnt-badge s">COBRANÇA</span>
      <h3>⏰ Reprocessar faturas em atraso</h3>
      <div class="oque">Verifica <b>todos os contratos ativos</b> e <b>bloqueia só os inadimplentes</b> (pela regra de vencimento/tolerância), no sistema e no RADIUS. Quem está em dia não é tocado. Roda o "corte" na hora, sem esperar o cron.</div>
      <input type="hidden" name="acao" value="reprocessar_atraso">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Reprocessar atraso</button>
    </form>

  </div>

  <div class="mnt-sec">🗑️ Limpeza de dados</div>
  <p class="ws-muted" style="font-size:12.5px;margin:2px 0 0">Apaga registros auxiliares (nunca clientes, contratos ou boletos).</p>
  <div class="mnt-grid">

    <!-- Apagar chamados -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('APAGAR TODOS os chamados? Irreversível.')">
      <span class="mnt-badge d">EM MASSA</span>
      <h3>🗑️ Apagar chamados em massa</h3>
      <div class="oque">Apaga <b>todos os chamados</b> e suas mensagens. Clientes, contratos e boletos <b>não são tocados</b>. Use para limpar a base de chamados de teste/antigos. Irreversível.</div>
      <input type="hidden" name="acao" value="apagar_chamados">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Apagar todos os chamados</button>
    </form>

    <!-- Apagar leads -->
    <form method="post" class="mnt-card perigo" onsubmit="return confirm('APAGAR TODOS os leads do comercial? Irreversível.')">
      <span class="mnt-badge d">EM MASSA</span>
      <h3>🗑️ Apagar leads (comercial)</h3>
      <div class="oque">Apaga <b>todos os leads</b> do módulo Comercial. Clientes, contratos e boletos <b>não são tocados</b>. Use para limpar leads de teste/antigos. Irreversível.</div>
      <input type="hidden" name="acao" value="apagar_leads">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn danger">Apagar leads</button>
    </form>

    <!-- Limpar caches -->
    <form method="post" class="mnt-card">
      <span class="mnt-badge s">CACHE</span>
      <h3>🧹 Limpar caches da OLT</h3>
      <div class="oque">Apaga os arquivos de <b>cache temporário da OLT</b> (autorizações, autofind, tráfego). Não afeta clientes, boletos nem configuração — os dados voltam na próxima leitura da OLT.</div>
      <input type="hidden" name="acao" value="limpar_caches">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn">Limpar caches</button>
    </form>

  </div>

  <div class="mnt-sec">🧱 Sistema, Backup &amp; Acesso</div>
  <p class="ws-muted" style="font-size:12.5px;margin:2px 0 0">Estrutura do banco, backup e acesso dos operadores.</p>
  <div class="mnt-grid">

    <!-- Verificar/criar tabelas -->
    <form method="post" class="mnt-card">
      <span class="mnt-badge s">ESTRUTURA</span>
      <h3>🧱 Verificar / criar tabelas</h3>
      <div class="oque">Roda a <b>criação de tabelas</b> e as <b>migrações</b> (colunas novas). <b>Só cria o que falta</b> — não altera nem apaga dado existente. Use se aparecer erro de "tabela/coluna inexistente" após atualizar o sistema.</div>
      <input type="hidden" name="acao" value="verificar_tabelas">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn">Verificar estrutura</button>
    </form>

    <!-- Backup rápido -->
    <form method="post" class="mnt-card">
      <span class="mnt-badge s">BACKUP</span>
      <h3>💾 Gerar backup agora</h3>
      <div class="oque">Gera um <b>backup do sistema na hora</b> (mesmo processo do backup automático). Fica salvo em <b>Provedor → Backup do sistema</b> para você baixar. Não altera nada.</div>
      <input type="hidden" name="acao" value="backup_agora">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn verde">Gerar backup</button>
    </form>

    <!-- Backup do Fiscal -->
    <form method="post" class="mnt-card">
      <span class="mnt-badge s">BACKUP</span>
      <h3>🧾 Gerar backup do Fiscal agora</h3>
      <div class="oque">Gera na hora o <b>backup do menu de nota fiscal</b> (notas, XML autorizados, emissor, certificado e logo) e envia para a pasta <b>"Sistema Fiscal"</b> do servidor de backup. Fica na lista em <b>Backup → Backup do Fiscal</b>. Não altera nada.</div>
      <input type="hidden" name="acao" value="backup_fiscal_agora">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn verde">Gerar backup do Fiscal</button>
    </form>
    <!-- Contingência do RADIUS (banco fora do ar) -->
    <?php
      $contOk = is_file('/usr/local/sbin/ws-radius-fallback.sh');
      $contEstado = 'DESLIGADA'; $contVel = '';
      if ($contOk) {
          $s = trim((string)@shell_exec('sudo -n /usr/local/sbin/ws-radius-fallback.sh status 2>&1'));
          if (strpos($s, 'LIGADA') === 0) { $contEstado = 'LIGADA'; $contVel = trim(substr($s, 6)); }
      }
    ?>
    <?php
      /* ENDEREÇOS NORMALIZADOS — quanto já está vinculado, e o botão para terminar agora.
       * Mostrar o número é o que separa "ainda está processando" de "parou": sem ele, um endereço
       * que não normalizou seria indistinguível de um cron que não está rodando. */
      $endTotal = 0; $endFeitos = 0; $endLog = 0; $endBai = 0; $endCid = 0;
      try {
          $endTotal  = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE COALESCE(logradouro,'')<>''")->fetchColumn();
          $endFeitos = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE logradouro_id IS NOT NULL")->fetchColumn();
          $endLog    = (int)$db->query("SELECT COUNT(*) FROM ws_logradouro")->fetchColumn();
          $endBai    = (int)$db->query("SELECT COUNT(*) FROM ws_bairro")->fetchColumn();
          $endCid    = (int)$db->query("SELECT COUNT(*) FROM ws_cidade")->fetchColumn();
      } catch (Throwable $e) {}
      $endFalta = max(0, $endTotal - $endFeitos);
    ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Normalizar os endereços pendentes agora?')">
      <h3>🏠 Endereços normalizados <?= $endFalta === 0 && $endTotal > 0 ? '— <b style="color:#16a34a">em dia</b>' : ($endFalta > 0 ? '— <b style="color:#b45309">' . $endFalta . ' pendente(s)</b>' : '') ?></h3>
      <div class="mnt-exp">
        O endereço deixou de ser texto solto dentro do cliente e passou a apontar para um cadastro:
        <b>UF → cidade → bairro → logradouro</b>, cada um numa tabela, ligados pelo <b>código</b>.
        <br><br>
        É o que acaba com a mesma rua escrita de cinco formas — <code>AV. BRASIL</code>,
        <code>AVENIDA BRASIL</code>, <code>Av Brasil</code> eram cinco endereços para o banco e um
        só na vida real. Agora, quem digita qualquer uma dessas grafias cai na rua que
        <b>já existe</b>: o sistema ignora caixa, acento, pontuação, espaço repetido e abreviação de
        tipo de via. Corrigir o nome de uma rua passa a corrigir para todos os clientes dela de uma
        vez, e o vínculo é pelo código — renomear não desvincula ninguém.
        <br><br>
        Cadastro hoje: <b><?= $endCid ?></b> cidade(s), <b><?= $endBai ?></b> bairro(s),
        <b><?= $endLog ?></b> logradouro(s). Clientes vinculados: <b><?= $endFeitos ?></b> de <b><?= $endTotal ?></b>.
        <?php if ($endFalta > 0): ?>
          <br><br>O restante é normalizado sozinho pelo cron, em lotes, a cada 2 minutos. O botão
          abaixo faz até 5.000 de uma vez, para não ter de esperar.
        <?php endif; ?>
        <br><br>
        <span class="ws-muted">As colunas de texto continuam preenchidas ao lado, com a grafia
        cadastrada — é o que mantém boleto, NFS-e e fiscal funcionando sem alteração.</span>
      </div>
      <input type="hidden" name="acao" value="normalizar_enderecos">
      <button class="ws-btn primary">🏠 Normalizar endereços agora</button>
    </form>

    <?php
      $zsync = @json_decode((string)@file_get_contents(WS_CACHE . '/zonas_sync.json'), true);
      require_once WS_DIR . '/zonas_unificar_lib.php';
      $vzm = ws_vlan_zona_mapa(); ksort($vzm);
    ?>
    <?php if (ws_fornecedor_desbloqueado()): /* ferramenta do fornecedor */ ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Unificar zonas, bairros e cidades agora? (o estado anterior fica guardado em cache/)')">
      <h3>🗺️ Zonas, bairros e cidades — unificação</h3>
      <div class="mnt-exp">
        <b>Como funciona (informação interna).</b> As zonas nascem na OLT (o técnico escolhe ao liberar a ONU) e o sistema as traz sozinho a cada 10 minutos
        (<code>zonas_sync.php</code>), preenchendo a zona dos contratos que estiverem sem ela. Ele <b>nunca apaga nem renomeia</b> zona: uma zona pode existir só no cadastro
        (obra, rádio, OLT fora do ar na leitura) e apagar por leitura incompleta levaria junto a zona dos clientes.
        <br><br>
        <b>Sem repetição:</b> zona, bairro e cidade são comparados por uma chave (MAIÚSCULA, sem acento, espaço único; cidade ainda sem emoji/número no início e "-UF" no fim; bairro sem o "BAIRRO " do começo).
        Mesma chave = mesma coisa, então "TAMATAUPE  1" e "TAMATAUPE 1" são uma zona só. Números diferentes (CADEIA 1 / CADEIA 2, ALTO DA SANTA 1 / 2) <b>nunca</b> são juntados.
        A OLT e o cadastro "que segue a OLT" gravam sempre o nome já cadastrado. Cada passada guarda o estado anterior em <code>cache/unificar_zonas_*.json</code>.
        <br><br>
        <b>Regra de VLAN → zona</b> (a VLAN define a zona do contrato e, nas famílias 1/2, o bairro):
        <?= implode(' · ', array_map(fn($v, $z) => '<b>' . (int)$v . '</b> = ' . htmlspecialchars($z, ENT_QUOTES, 'UTF-8'), array_keys($vzm), $vzm)) ?>.
        Para acrescentar uma VLAN sem mexer no código: <code>cache/vlan_zona.json</code> com <code>{"261":"NOME DA ZONA"}</code>.
        <br><br>
        <b>Contagens:</b> as telas Zonas e Cadastros → Bairros contam só cliente/contrato <b>ativo</b> (cancelado fica fora). O balancete (Relatórios → Balancete) usa:
        saldo anterior (atrasados) + previsto do período = a receber; menos o recebido (o mesmo número do Caixa do Dia) = saldo, que passa para a linha seguinte; o primeiro período já herda os atrasados de antes dele.
        O saldo é uma conta corrida e pode diferir dos boletos em aberto por multa/juros recebidos a mais e por pagamentos adiantados.
        <br><br>
        <?php if (is_array($zsync)): ?>
          <b>Última sincronização com a OLT:</b> <?= htmlspecialchars((string)($zsync['em'] ?? '?'), ENT_QUOTES, 'UTF-8') ?> —
          <?= (int)($zsync['zonas_vistas'] ?? 0) ?> zona(s) vista(s), <?= (int)($zsync['zonas_novas'] ?? 0) ?> criada(s), <?= (int)($zsync['contratos'] ?? 0) ?> contrato(s) preenchido(s).
          <?php if (!empty($zsync['erro'])): ?><br><span style="color:#b45309">⚠️ <?= htmlspecialchars((string)$zsync['erro'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
        <?php else: ?><span style="color:#b45309">⚠️ O sincronismo ainda não rodou neste servidor (entra sozinho em até 10 minutos).</span><?php endif; ?>
      </div>
      <input type="hidden" name="acao" value="unificar_zonas">
      <button class="ws-btn primary">🗺️ Unificar zonas, bairros e cidades agora</button>
    </form>
    <?php endif; /* zonas: ferramenta do fornecedor */ ?>

    <?php
      $qtdSujo = 0;
      try { $qtdSujo = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE
          (cpf_cnpj REGEXP '[^0-9]') OR (rg_ie REGEXP '[^0-9]') OR
          (celular REGEXP '[^0-9]') OR (telefone REGEXP '[^0-9]')")->fetchColumn();
      } catch (Throwable $e) {}
    ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Limpar a pontuação de CPF/CNPJ, RG, celular e telefone já gravados?')">
      <h3>🔢 CPF/CNPJ, RG e telefones — só número</h3>
      <div class="mnt-exp">
        Esses campos agora são gravados <b>só com dígito</b> (a pontuação — ponto, traço, barra,
        parêntese — é aplicada apenas na TELA, nunca gravada). Cadastros feitos <b>antes</b> dessa
        correção ainda têm a pontuação junto com o número; este botão limpa o que já existe, em
        lotes, sem mexer no que já estiver limpo.
        <br><br>
        Campo(s) com pontuação hoje: <b><?= $qtdSujo ?></b>.
      </div>
      <input type="hidden" name="acao" value="normalizar_documentos">
      <button class="ws-btn primary" <?= $qtdSujo === 0 ? 'disabled' : '' ?>>🔢 Normalizar documentos e telefones agora</button>
    </form>

    <?php
      /* CONFERÊNCIA DA BASE — de onde vem cada cliente, e onde há duplicata.
       *
       * "Importei 1.625 e ficaram 1.679" é a pergunta que não tinha resposta em tela nenhuma: para
       * responder era preciso montar consulta à mão. Um número que ninguém consegue explicar vira
       * desconfiança do sistema inteiro — e com razão, porque cliente duplicado significa dois
       * cadastros disputando a mesma conexão e uma cobrança que ninguém entende.
       *
       * A conta aqui é fechada: titulares + adicionais = total. E as duplicatas são listadas pelo
       * mesmo critério que a importação usa para barrá-las, então o que aparecer aqui é exatamente
       * o que escapou. */
      $cb = ['total'=>0,'adicionais'=>0,'titulares'=>0,'sem_doc_sem_login'=>0,'com_contrato'=>0,
             'com_login'=>0,'sem_contrato'=>0,'dup_doc'=>0,'dup_nome'=>0,'dup_login'=>0];
      try {
          $cb['total']      = (int)$db->query("SELECT COUNT(*) FROM ws_cliente")->fetchColumn();
          $cb['adicionais'] = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE titular_id IS NOT NULL")->fetchColumn();
          $cb['titulares']  = $cb['total'] - $cb['adicionais'];
          $cb['com_contrato'] = (int)$db->query("SELECT COUNT(DISTINCT cliente_id) FROM ws_contrato")->fetchColumn();
          $cb['sem_contrato'] = $cb['total'] - $cb['com_contrato'];
          $cb['com_login']  = (int)$db->query("SELECT COUNT(*) FROM ws_contrato
                                               WHERE COALESCE(login_pppoe,'')<>'' OR COALESCE(login_ipoe,'')<>''")->fetchColumn();
          // Cliente sem documento e sem login: é o que a importação não conseguia deduplicar.
          $cb['sem_doc_sem_login'] = (int)$db->query("SELECT COUNT(*) FROM ws_cliente c
              WHERE COALESCE(c.cpf_cnpj,'')='' AND NOT EXISTS (SELECT 1 FROM ws_contrato ct
                    WHERE ct.cliente_id=c.id AND (COALESCE(ct.login_pppoe,'')<>'' OR COALESCE(ct.login_ipoe,'')<>''))")->fetchColumn();
          // Documento repetido (ignorando pontuação), contando os EXCEDENTES de cada grupo.
          $cb['dup_doc'] = (int)$db->query("SELECT COALESCE(SUM(n-1),0) FROM (
              SELECT COUNT(*) n FROM ws_cliente WHERE COALESCE(cpf_cnpj,'')<>''
              GROUP BY REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/',''),' ','')
              HAVING COUNT(*)>1) t")->fetchColumn();
          // Nome repetido dentro do MESMO ramal (homônimo em cidade diferente é plausível).
          $cb['dup_nome'] = (int)$db->query("SELECT COALESCE(SUM(n-1),0) FROM (
              SELECT COUNT(*) n FROM ws_cliente GROUP BY UPPER(TRIM(nome)), COALESCE(ramal_id,0)
              HAVING COUNT(*)>1) t")->fetchColumn();
          /* MESMA IDENTIDADE EM CONTRATOS DIFERENTES — conta CONTRATOS DISTINTOS, não linhas.
           *
           * A primeira versão desta consulta contava linhas do UNION ALL, e acusou 714 conflitos
           * numa base que não tinha nenhum. O motivo: no IPoE o sistema grava o MESMO valor em
           * `login_pppoe` e em `login_ipoe` (é o ID da ONU nas duas colunas — ver o importador e o
           * salvamento do contrato). O UNION ALL trazia esse valor DUAS VEZES vindo do MESMO
           * contrato, e a contagem lia isso como dois contratos disputando a mesma conexão.
           *
           * Um número desses é pior que não ter número: ele manda o operador procurar e "resolver"
           * um problema que não existe — e, no caminho, apagar cadastro bom.
           *
           * COUNT(DISTINCT id) responde a pergunta certa: quantos CONTRATOS usam esta identidade.
           * Duas colunas do mesmo contrato contam como um. */
          $cb['dup_login'] = (int)$db->query("SELECT COALESCE(SUM(n-1),0) FROM (
              SELECT COUNT(DISTINCT id) n FROM (
                  SELECT id, login_pppoe ident FROM ws_contrato WHERE COALESCE(login_pppoe,'')<>''
                  UNION ALL
                  SELECT id, login_ipoe  ident FROM ws_contrato WHERE COALESCE(login_ipoe,'')<>''
              ) u GROUP BY ident HAVING COUNT(DISTINCT id)>1) t")->fetchColumn();
      } catch (Throwable $e) {}
      $cbSoma = ($cb['titulares'] + $cb['adicionais']) === $cb['total'];
      $cbDup  = $cb['dup_doc'] + $cb['dup_nome'] + $cb['dup_login'];
    ?>
    <?php if (ws_fornecedor_desbloqueado()): /* ferramenta do fornecedor */ ?>
    <div class="mnt-card">
      <h3>🧮 Conferência da base de clientes <?= $cbDup === 0 ? '— <b style="color:#16a34a">sem duplicata</b>' : '— <b style="color:#b91c1c">' . $cbDup . ' suspeita(s)</b>' ?></h3>
      <div class="mnt-exp">
        <b>De onde vem cada cliente</b><br>
        Titulares: <b><?= $cb['titulares'] ?></b> ·
        Adicionais: <b><?= $cb['adicionais'] ?></b> ·
        Total: <b><?= $cb['total'] ?></b> <?= $cbSoma ? '✅' : '⚠️' ?>
        <br>
        <span class="ws-muted">O <b>adicional</b> é um cliente próprio, ligado ao titular — por isso o
        total do sistema é MAIOR que o número de clientes do backup antigo. Se o backup tinha 1.625
        em <code>sis_cliente</code> e 44 em <code>sis_adicional</code>, o esperado aqui é 1.669.</span>
        <br><br>
        <b>Conexão</b><br>
        Com contrato: <b><?= $cb['com_contrato'] ?></b> ·
        Sem contrato nenhum: <b><?= $cb['sem_contrato'] ?></b> ·
        Contratos com login (PPPoE ou IPoE): <b><?= $cb['com_login'] ?></b>
        <br>
        <span class="ws-muted">Só contrato COM login vai para o RADIUS. É por isso que o
        <code>radcheck</code> tem cerca do dobro desse número: cada login grava a senha e o
        <code>Simultaneous-Use</code>.</span>
        <br><br>
        <b>Duplicata</b><br>
        Mesmo CPF/CNPJ: <b><?= $cb['dup_doc'] ?></b> ·
        Mesmo nome no mesmo ramal: <b><?= $cb['dup_nome'] ?></b> ·
        Mesma identidade em 2 contratos: <b><?= $cb['dup_login'] ?></b>
        <br>
        Sem CPF/CNPJ <i>e</i> sem login: <b><?= $cb['sem_doc_sem_login'] ?></b>
        <br>
        <span class="ws-muted">Este último é o grupo que a importação <b>não conseguia</b>
        deduplicar: sem documento e sem login, não havia por onde comparar, e reimportar o mesmo
        backup criava outro cadastro. Agora a comparação cai no nome, dentro do ramal.</span>
        <?php if ($cb['dup_login'] > 0): ?>
          <br><br><span style="color:#b91c1c">⚠️ <b>Identidade repetida em mais de um contrato</b> é o
          caso grave: dois cadastros disputam a mesma conexão, e o <code>Simultaneous-Use</code> vai
          recusar o cliente legítimo. Veja em <a href="erp.php?p=clientes">Clientes</a> e cancele o
          cadastro que sobrou.</span>
        <?php endif; ?>
      </div>
      <?php
        /* O QUE NÃO ENTROU NA ÚLTIMA IMPORTAÇÃO.
         *
         * Aqui fica só o PLACAR — quantos ficaram de fora. A lista completa, com o motivo de cada
         * um, mora em importacao_fora.php, que é uma tela própria com filtro por motivo e busca.
         *
         * Ela saiu daqui porque estava despejando dezenas de linhas no meio de um cartão que serve
         * para outra coisa, empurrando para baixo tudo o que vinha depois. Contar é barato e cabe
         * num cartão; listar não.
         *
         * O dado vem de cache/importacao_fora.csv, escrito pelo importador no instante em que
         * descarta cada registro — ver mk_fora_registrar() em mkauth_import.php. */
        $arqFora = WS_CACHE . '/importacao_fora.csv';
        $temFora = is_file($arqFora);
        $linhasFora = 0;
        if ($temFora) {
            // Conta sem carregar o arquivo inteiro na memória: ele pode ter milhares de linhas.
            $fh = @fopen($arqFora, 'r');
            if ($fh) {
                $prim = true;
                while (($l = fgets($fh)) !== false) {
                    if ($prim) { $prim = false; continue; }   // cabeçalho
                    if (trim($l) !== '') $linhasFora++;
                }
                fclose($fh);
            }
        }
      ?>
      <div style="margin-top:12px;padding-top:12px;border-top:1px dashed var(--border)">
        <b>O que ficou de fora na última importação</b>
        <?php if (!$temFora): ?>
          <div class="ws-muted" style="font-size:12px;margin-top:5px">
            Nenhuma importação registrada ainda neste servidor. Na próxima, cada registro que não
            entrar fica registrado <b>com o motivo</b> — em vez de só um número.
          </div>
        <?php elseif ($linhasFora === 0): ?>
          <div style="font-size:12.5px;margin-top:5px;color:var(--ok)">
            ✅ Nenhum registro ficou de fora na última importação.
          </div>
        <?php else: ?>
          <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:8px">
            <div style="font-size:12.5px">
              <b style="color:var(--warn);font-size:15px"><?= $linhasFora ?></b>
              registro(s) do backup <b>não entraram</b>.
            </div>
            <a class="ws-btn primary" href="importacao_fora.php">📋 Ver a lista com o motivo de cada um</a>
          </div>
          <div class="ws-muted" style="font-size:11.5px;margin-top:6px">
            A tela abre a lista completa, com filtro por motivo, busca por nome/login/documento e
            a planilha para baixar.
          </div>
        <?php endif; ?>
      </div>
      <a class="ws-btn" href="erp.php?p=clientes">👥 Abrir Clientes</a>
    </div>
    <?php endif; /* conferência da base: ferramenta do fornecedor */ ?>

    <?php
      require_once WS_DIR . '/schema_endereco.php';
      $txtAtivo = ws_end_texto_ativo($db);
    ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('<?= $txtAtivo ? 'Aposentar as colunas de texto do endereço? É reversível pelo botão Restaurar.' : 'Restaurar as colunas de texto do endereço?' ?>')">
      <h3>🗂️ Colunas de texto do endereço <?= $txtAtivo ? '— <b style="color:#b45309">em circulação</b>' : '— <b style="color:#16a34a">aposentadas</b>' ?></h3>
      <div class="mnt-exp">
        O endereço do cliente era guardado como <b>texto solto</b> dentro de <code>ws_cliente</code>
        (cep, logradouro, bairro, cidade, uf). Com o cadastro normalizado no ar, essas colunas
        deixaram de ser necessárias — <b>nenhuma leitura do sistema depende mais delas</b>: boleto,
        NFS-e, gateway de cobrança, documentos, mensagens, portal do assinante e a ficha do cliente
        já leem do cadastro.
        <br><br>
        <?php if ($txtAtivo): ?>
          Hoje elas ainda existem, mantidas como <b>cópia de leitura</b>. Aposentá-las conclui a
          normalização: o endereço passa a existir em <b>um lugar só</b>.
          <br><br>
          <b>Elas são RENOMEADAS, não apagadas.</b> O conteúdo fica intacto em
          <code>cidade<?= WS_END_SUFIXO ?></code> e companhia. Isso dá duas coisas que o apagar não
          daria: volta em um clique se alguma leitura escapou, e, se escapou, ela <b>dá erro visível</b>
          em vez de imprimir um endereço em branco num documento fiscal.
          <br><br>
          Depois de aposentar: confira um <b>boleto</b>, um <b>recibo</b> e a <b>ficha de um cliente</b>.
          Se algo vier em branco, use Restaurar — nada se perde.
        <?php else: ?>
          Aposentadas. O endereço vem <b>só</b> do cadastro normalizado, existindo em um lugar único.
          O conteúdo antigo continua guardado nas colunas
          <code>…<?= WS_END_SUFIXO ?></code>, caso você queira conferir algo.
        <?php endif; ?>
      </div>
      <input type="hidden" name="acao" value="endereco_texto">
      <input type="hidden" name="et_acao" value="<?= $txtAtivo ? 'aposentar' : 'restaurar' ?>">
      <button class="ws-btn <?= $txtAtivo ? 'danger' : '' ?>">
        <?= $txtAtivo ? '🗂️ Aposentar as colunas de texto' : '↩️ Restaurar as colunas de texto' ?>
      </button>
    </form>


    <!-- Domínio & HTTPS (certificado automático) -->
    <?php
      /* Mostra o estado atual para o operador não pedir certificado achando que não tem, nem
         achar que tem quando não tem. Lê o que o Apache realmente carregou. */
      $temHttps = false; $dominiosAtuais = '';
      foreach (@glob('/etc/letsencrypt/live/*/cert.pem') ?: [] as $c) { $temHttps = true; $dominiosAtuais .= ($dominiosAtuais ? ', ' : '') . basename(dirname($c)); }
      $podeEmitir = is_file('/usr/local/sbin/ws-certificado.sh');
      require_once __DIR__ . '/certificado_lib.php';
      $certCfg = ws_cert_cfg();
      $certSit = $certCfg['estado']['dominios'] ?? [];
      if (!$temHttps && $certSit) foreach ($certSit as $s) if (!empty($s['coberto'])) $temHttps = true;
    ?>
    <form method="post" class="mnt-card" onsubmit="return confirm('Gravar os domínios e emitir agora os que já apontam para este servidor? Os outros entram sozinhos quando apontarem.')">
      <h3>🔒 Domínio &amp; HTTPS</h3>
      <div class="oque">
        Pede o certificado à <b>Let's Encrypt</b> e o instala no servidor, sem terminal. Depois disso
        o acesso por <code>http://</code> passa a ser redirecionado para <code>https://</code>, e a
        <b>renovação é automática</b> — não há o que agendar.
        <br><br>
        <b>Automático:</b> informe <b>todos</b> os domínios do provedor uma vez. Os que já apontam para este
        servidor recebem o certificado na hora; os que ainda apontam para outro lugar <b>entram sozinhos</b>
        assim que o DNS for trocado (o sistema confere a cada 10 min). Nada de terminal.
        <?php if ($temHttps): ?>
          <br><br>✅ <b>Já existe certificado</b> para: <?= $h($dominiosAtuais) ?>. Pedir de novo
          apenas acrescenta domínios; nada é perdido.
        <?php endif; ?>
        <?php if (!$podeEmitir): ?>
          <br><br>⚠️ Este servidor não foi preparado para emitir pelo painel (isso é feito pelo
          <code>INSTALAR.sh</code>). Em instalação manual, use o <code>certbot</code> no terminal.
        <?php endif; ?>
      </div>
      <?php if ($certCfg['dominios']): ?>
        <div class="oque" style="margin-top:8px">
          <b>🤖 Automático ligado</b> — a cada 10 min o sistema confere estes domínios e emite ou aumenta o
          certificado sozinho assim que cada um apontar para este servidor<?= !empty($certCfg['estado']['ip_publico']) ? ' (<code>' . $h($certCfg['estado']['ip_publico']) . '</code>)' : '' ?>.
          <table style="width:100%;margin-top:6px;font-size:12px;border-collapse:collapse">
            <tr style="text-align:left"><th>Domínio</th><th>DNS aponta para</th><th>Aqui?</th><th>HTTPS</th></tr>
            <?php foreach ($certCfg['dominios'] as $d): $s = $certSit[$d] ?? []; ?>
              <tr>
                <td><?= $h($d) ?></td>
                <td><?= $h(!empty($s['dns']) ? implode(', ', $s['dns']) : (isset($s['dns']) ? 'sem DNS' : '—')) ?></td>
                <td><?= !empty($s['aqui']) ? '✅' : '⏳' ?></td>
                <td><?= !empty($s['coberto']) ? '🔒 ok' . (!empty($s['vence']) ? ' até ' . date('d/m/Y', (int)$s['vence']) : '') : '—' ?></td>
              </tr>
            <?php endforeach; ?>
          </table>
          <?php if (!empty($certCfg['estado']['msg'])): ?><div style="margin-top:6px"><?= $h($certCfg['estado']['msg']) ?><?= !empty($certCfg['estado']['quando']) ? ' <small>(conferido ' . date('d/m H:i', (int)$certCfg['estado']['quando']) . ')</small>' : '' ?></div><?php endif; ?>
          <?php if (!empty($certCfg['ultima']) && empty($certCfg['ultima']['ok'])): ?>
            <details style="margin-top:6px"><summary>Última tentativa falhou (<?= date('d/m H:i', (int)$certCfg['ultima']['quando']) ?>) — ver resposta do certbot</summary>
              <pre style="white-space:pre-wrap;font-size:11px"><?= $h((string)$certCfg['ultima']['saida']) ?></pre></details>
          <?php endif; ?>
        </div>
      <?php endif; ?>
      <input type="hidden" name="acao" value="emitir_certificado">
      <input type="text" name="cert_dominios" value="<?= $h(implode(', ', $certCfg['dominios'])) ?>" placeholder="erp.seudominio.com.br, financeiro.seudominio.com.br, assinantes.seudominio.com.br" required <?= $podeEmitir ? '' : 'disabled' ?>>
      <input type="email" name="cert_email" value="<?= $h(ws_cert_email($certCfg)) ?>" placeholder="e-mail para avisos de vencimento" required <?= $podeEmitir ? '' : 'disabled' ?>>
      <input class="senha" type="password" name="senha" placeholder="senha do root" required <?= $podeEmitir ? '' : 'disabled' ?>>
      <button class="ws-btn verde" <?= $podeEmitir ? '' : 'disabled' ?>>Salvar e emitir agora</button>
    </form>

    <!-- Resetar 2FA de operador -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Resetar o 2FA deste operador?')">
      <span class="mnt-badge s">ACESSO</span>
      <h3>🔑 Resetar 2FA de operador</h3>
      <div class="oque">Desliga o <b>2FA (autenticação em 2 fatores)</b> de um operador que ficou <b>travado fora</b> (perdeu o app/telefone). Ele volta a entrar só com login e senha, e pode reativar o 2FA depois.</div>
      <select class="senha" name="operador_id" required>
        <option value="">— escolha o operador —</option>
        <?php foreach ($operadores as $u) echo "<option value='{$u['id']}'>" . $h($u['nome']) . "</option>"; ?>
      </select>
      <input type="hidden" name="acao" value="resetar_2fa">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn">Resetar 2FA</button>
    </form>

    <!-- Limpar sessões -->
    <form method="post" class="mnt-card" onsubmit="return confirm('Encerrar as sessões de todos os outros usuários?')">
      <span class="mnt-badge s">ACESSO</span>
      <h3>🚪 Limpar sessões (forçar re-login)</h3>
      <div class="oque">Encerra as <b>sessões de todos os outros usuários</b> (a sua é mantida) — todos precisam fazer login de novo. Use quando alguém ficou "preso" logado ou após trocar senhas.</div>
      <input type="hidden" name="acao" value="limpar_sessoes">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn">Limpar sessões</button>
    </form>

  <!-- ============================================================================================
       EMERGÊNCIA DO RADIUS — "Qualquer login".
       Cópia fiel da tela que existe no módulo da OLT, trazida para cá porque é AQUI que se procura
       quando o Radius cai. Fala direto com o painel de cada concentrador, sem passar pelo Radius —
       é justamente para quando ele está fora. A configuração dos painéis é a MESMA das duas telas
       (cache_trafego/olt_radpanel.json): configurar num lugar vale no outro.
       ============================================================================================ -->
  <?php
  if (is_file(__DIR__ . '/radius_emergencia.php')) require_once __DIR__ . '/radius_emergencia.php';
  $mntPaineis = function_exists('ws_radpanel_load') ? ws_radpanel_load() : [];
  if (!$mntPaineis) $mntPaineis = [[]];   // sempre uma linha em branco para configurar
  ?>
  <!-- ==============================================================================================
       EMERGÊNCIA DE AUTENTICAÇÃO — as três ferramentas num cartão só.
       ==============================================================================================
       Elas viviam espalhadas em três cartões ("Liberar autenticação", "Contingência do RADIUS" e
       "Qualquer login") e pareciam a mesma coisa repetida. Agora estão juntas, na ordem em que se
       recorre a elas.

       O QUE NÃO FOI FEITO, E POR QUÊ: não viraram UMA ferramenta só. A finalidade parece a mesma
       ("deixar o cliente conectar"), mas cada uma age numa CAMADA diferente e, principalmente,
       cada uma funciona numa queda em que as outras NÃO funcionam:

         · Contingência  age no FreeRADIUS e é a única que serve quando o BANCO cai — as outras
                         duas dependem do banco só para serem acionadas;
         · Liberar auth  age no banco do RADIUS: serve quando o banco está de pé e o que está
                         errado são os dados de autenticação;
         · Qualquer login age no painel de cada concentrador, sem passar pelo WellSystem nem pelo
                         RADIUS: é a única que funciona com o servidor inteiro fora.

       Fundir as três apagaria, em cada cenário, a única que resolveria aquele cenário. Unificamos
       a TELA, não a capacidade. ============================================================== -->
  <div class="mnt-card mnt-emerg">
    <span class="mnt-badge s">EMERGÊNCIA</span>
    <h3>🚨 Emergência de autenticação</h3>
    <div class="oque">
      Três caminhos para o cliente voltar a conectar. <b>Qual usar depende do que caiu</b> —
      e é por isso que os três continuam existindo:
      <div class="ws-tabela-rolagem" style="margin-top:8px">
        <table class="ws-table" style="font-size:12px">
          <thead><tr><th class="ws-th-esq">O que caiu</th><th class="ws-th-esq">Use</th><th class="ws-th-esq">Age em</th></tr></thead>
          <tbody>
            <tr><td class="ws-th-esq"><b>O banco de dados</b></td>
                <td class="ws-th-esq">Contingência do RADIUS</td>
                <td class="ws-th-esq">FreeRADIUS — sozinha, sem ninguém clicar</td></tr>
            <tr><td class="ws-th-esq"><b>Os dados do RADIUS</b> (banco de pé)</td>
                <td class="ws-th-esq">Liberar autenticação</td>
                <td class="ws-th-esq">banco do RADIUS</td></tr>
            <tr><td class="ws-th-esq"><b>O RADIUS ou o servidor inteiro</b></td>
                <td class="ws-th-esq">Qualquer login</td>
                <td class="ws-th-esq">painel de cada concentrador</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 1 e 2: as duas que dependem do servidor, lado a lado. -->
    <div class="mnt-emerg-dois">
    <form method="post" class="mnt-sub" onsubmit="return confirm('Alterar a contingência do RADIUS?')">
      <h3>🛟 Contingência do RADIUS <?= $contEstado === 'LIGADA' ? '— <b style="color:#16a34a">LIGADA</b>' : '— <b style="color:var(--muted)">desligada</b>' ?></h3>
      <div class="oque">
        Se o <b>banco de dados parar</b>, o FreeRADIUS deixa de conseguir conferir senha e passa a
        recusar <b>todo mundo</b> — a cidade inteira cai junto com o MySQL. Com a contingência
        ligada, nesse caso específico ele <b>aceita as conexões</b> com a velocidade escolhida aqui,
        e o cliente nem percebe a queda.
        <br><br>
        <b>Ela só age quando a consulta ao banco FALHA.</b> Cliente que o banco recusou continua
        recusado: "banco fora" e "senha errada" são coisas diferentes, e só a primeira aciona.
        Com o banco no ar, absolutamente nada muda — planos, bloqueios e velocidades seguem normais.
        <br><br>
        ⚠️ <b>O preço:</b> durante a queda ninguém consegue conferir senha nenhuma, então qualquer
        usuário e senha entram — inclusive de quem não é cliente. É uma troca consciente: alguns
        minutos com a cidade navegando é melhor que a cidade offline. Voltando o banco, tudo volta
        a ser conferido sozinho.
        <?php if ($contEstado === 'LIGADA' && $contVel): ?>
          <br><br>Velocidade configurada agora: <b><?= $h($contVel) ?></b>.
        <?php endif; ?>
        <?php if (!$contOk): ?>
          <br><br>⚠️ Não habilitada neste servidor (é instalada pelo <code>INSTALAR.sh</code>).
        <?php endif; ?>
      </div>
      <input type="hidden" name="acao" value="radius_contingencia">
      <select name="cont_estado" <?= $contOk ? '' : 'disabled' ?>>
        <option value="on" <?= $contEstado === 'LIGADA' ? 'selected' : '' ?>>Ligar a contingência</option>
        <option value="off" <?= $contEstado === 'LIGADA' ? '' : 'selected' ?>>Desligar a contingência</option>
      </select>
      <select name="cont_megas" <?= $contOk ? '' : 'disabled' ?>>
        <?php foreach ([100, 200, 300, 400, 500, 1000] as $mb): ?>
          <option value="<?= $mb ?>" <?= ($contVel && strpos($contVel, (string)($mb * 1000) . 'k') === 0) ? 'selected' : ($mb === 300 ? 'selected' : '') ?>><?= $mb ?> Mbps</option>
        <?php endforeach; ?>
      </select>
      <input class="senha" type="password" name="senha" placeholder="senha do root" required <?= $contOk ? '' : 'disabled' ?>>
      <button class="ws-btn verde" <?= $contOk ? '' : 'disabled' ?>>Aplicar</button>
    </form>
    <form method="post" class="mnt-sub" onsubmit="return confirm('Liberar autenticação de emergência para TODOS no plano escolhido?')">
      <span class="mnt-badge s">EMERGÊNCIA</span>
      <h3>📡 Liberar autenticação (plano X)</h3>
      <div class="oque">Quando o <b>RADIUS</b> está com problema de autenticação, isto <b>re-provisiona todo contrato</b> (ativo/bloqueado) já <b>liberado</b> e com a velocidade do plano escolhido — todo mundo volta a conectar. Depois, ressincronize para voltar cada um ao plano real.</div>
      <?php if (!$planos): ?>
        <div style="font-size:12.5px;color:var(--err);border:1px solid var(--err);border-radius:8px;padding:9px 11px">
          <b>Nenhum plano de velocidade cadastrado.</b> Esta ferramenta aplica a velocidade de um
          plano em todo mundo, então sem plano ela não tem o que aplicar.
          <a href="erp.php?p=planos">Cadastrar um plano</a>.
        </div>
      <?php else: ?>
        <select class="senha" name="plano_id" required>
          <option value="">— escolha o plano de velocidade —</option>
          <?php foreach ($planos as $pl) echo "<option value='{$pl['id']}'>" . $h($pl['nome']) . "</option>"; ?>
        </select>
      <?php endif; ?>
      <input type="hidden" name="acao" value="liberar_auth">
      <input class="senha" type="password" name="senha" placeholder="senha do root" required>
      <button class="ws-btn primary">Liberar autenticação</button>
    </form>
    </div>

    <!-- 3: a que não depende de nada daqui. Fica por último e ocupa a largura toda, porque a
         tabela de painéis dos concentradores tem sete campos por linha. -->
    <div class="mnt-emerg-titulo">⚠️ Qualquer login — direto no painel do concentrador</div>
    <div class="mnt-emerg-aviso">
      <b>⚠️ Modo de emergência.</b> "Qualquer login" faz os clientes autenticarem
      <b>sem passar pelo Radius</b> (inclusive bloqueados). Use só quando o Radius estiver com
      problema e <b>volte ao Radius</b> depois.
    </div>

    <div class="mnt-emerg-botoes">
      <form method="post" onsubmit="return mntEmergConfirmar(this,'ATIVAR o Qualquer login')">
        <input type="hidden" name="acao" value="radpanel_emergencia">
        <input type="hidden" name="senha" class="mnt-emerg-senha">
        <button class="mnt-emerg-bt vermelho" type="submit">⚡ ATIVAR Qualquer login</button>
      </form>
      <form method="post" onsubmit="return mntEmergConfirmar(this,'VOLTAR ao Radius')">
        <input type="hidden" name="acao" value="radpanel_radius">
        <input type="hidden" name="senha" class="mnt-emerg-senha">
        <button class="mnt-emerg-bt verde" type="submit">🛡️ VOLTAR ao Radius</button>
      </form>
    </div>

    <div class="mnt-emerg-cab">
      <span>Painéis dos concentradores</span>
      <button type="button" class="ws-btn" onclick="mntEmergAdd()">+ Adicionar</button>
    </div>

    <form method="post" id="mntEmergForm" onsubmit="return mntEmergSalvar(this)">
      <input type="hidden" name="acao" value="radpanel_salvar">
      <input type="hidden" name="senha" class="mnt-emerg-senha">
      <input type="hidden" name="paineis" id="mntEmergJson">
      <div id="mntEmergLista">
        <?php foreach ($mntPaineis as $p): ?>
        <div class="mnt-emerg-linha">
          <label class="mnt-emerg-apl" title="Aplicar o modo neste painel">
            <input type="checkbox" class="p-on" <?= !empty($p['on']) ? 'checked' : '' ?>> aplicar
          </label>
          <input class="p-nome"   placeholder="apelido (ex.: Concentrador 1)" value="<?= h($p['nome'] ?? '') ?>">
          <input class="p-base"   placeholder="http://IP:porta/adm"           value="<?= h($p['base'] ?? '') ?>">
          <a class="ws-btn mnt-emerg-abrir" target="_blank" rel="noopener"
             href="<?= h($p['base'] ?? '#') ?>">↗ Abrir painel</a>
          <button type="button" class="ws-btn mnt-emerg-del" title="Remover este painel"
                  onclick="this.closest('.mnt-emerg-linha').remove()">🗑</button>
          <input class="p-user"   placeholder="usuário do painel" value="<?= h($p['user'] ?? '') ?>">
          <input class="p-pass"   placeholder="<?= !empty($p['pass']) ? '•••••• (já salva)' : 'senha do painel' ?>" type="password">
          <input class="p-dmco"   placeholder="dmco"  value="<?= h($p['dmco']  ?? '') ?>">
          <input class="p-inter"  placeholder="inter" value="<?= h($p['inter'] ?? '') ?>">
          <select class="p-defrat">
            <?php foreach (['1'=>'50 mega','2'=>'100 mega','3'=>'200 mega'] as $vk => $vl): ?>
              <option value="<?= $vk ?>" <?= ((string)($p['defrat'] ?? '3') === $vk) ? 'selected' : '' ?>><?= $vl ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="mnt-emerg-dica">
        URL até <b>/adm</b> (ex.: http://192.0.2.21:8086/adm) · usuário/senha do painel ·
        <b>dmco/inter/defrat</b> = os mesmos valores do Aplicar (não alteram o resto da config).
        Senha em branco mantém a que já está gravada.
      </div>
      <button class="mnt-emerg-bt verde" type="submit">💾 Salvar painéis</button>
    </form>
  </div>
  </div>

  <script>
  /* Monta o JSON dos painéis a partir das linhas da tela e confirma antes de agir.
     A senha do root é pedida UMA vez por ação (esta tela inteira já exige senha em todo POST). */
  function mntEmergColeta(){
    var out = [];
    document.querySelectorAll('#mntEmergLista .mnt-emerg-linha').forEach(function(l){
      var v = function(c){ var e = l.querySelector('.' + c); return e ? e.value.trim() : ''; };
      if (v('p-base') === '' && v('p-nome') === '') return;   // linha vazia não vira painel
      out.push({ on: l.querySelector('.p-on').checked ? 1 : 0, nome: v('p-nome'), base: v('p-base'),
                 user: v('p-user'), pass: v('p-pass'), dmco: v('p-dmco'), inter: v('p-inter'),
                 defrat: v('p-defrat') });
    });
    return out;
  }
  function mntEmergSenha(form, texto){
    var s = prompt('Senha do root para ' + texto + ':');
    if (s === null || s === '') return false;
    form.querySelector('.mnt-emerg-senha').value = s;
    return true;
  }
  function mntEmergSalvar(form){
    document.getElementById('mntEmergJson').value = JSON.stringify(mntEmergColeta());
    return mntEmergSenha(form, 'salvar os painéis');
  }
  function mntEmergConfirmar(form, texto){
    if (!confirm(texto + '?\n\nIsto age nos painéis marcados como "aplicar" — ou em TODOS, se nenhum estiver marcado.')) return false;
    return mntEmergSenha(form, texto);
  }
  function mntEmergAdd(){
    var l = document.querySelector('#mntEmergLista .mnt-emerg-linha');
    if (!l) return;
    var n = l.cloneNode(true);
    n.querySelectorAll('input').forEach(function(i){ if (i.type === 'checkbox') i.checked = false; else i.value = ''; });
    document.getElementById('mntEmergLista').appendChild(n);
  }
  </script>

  <!-- ============================================================================================
       COMANDOS DE TERMINAL.
       Os botões acima resolvem o que dá para resolver de dentro do sistema. Quando o problema é
       o serviço em si — PHP-FPM travado, FreeRADIUS fora, permissão errada — só o terminal
       resolve, e é justamente a hora em que ninguém lembra o comando. Ficam aqui, prontos para
       copiar, com o que cada um faz escrito ao lado.
       O guia completo está em Documentação › MANUTENÇÃO (comandos).
       ============================================================================================ -->
  <div class="ws-panel" style="margin-top:14px">
    <b>⌨️ Comandos de terminal</b>
    <p class="ws-muted" style="font-size:12.5px;margin:6px 0 12px">
      Executar no servidor como <b>root</b>. Clique para copiar. Os marcados com ⚠️ alteram algo —
      o resto só lê. Guia completo em <a href="docs.php?doc=<?= urlencode('MANUTENÇÃO (comandos)') ?>">Documentação › Manutenção</a>.
    </p>

    <?php
    // Um lugar só para a lista: [rótulo, comando, explicação, altera?]
    $WS_DIR_ADDON = __DIR__;
    $cmds = [
      ['Validar TODOS os PHP',
       'cd ' . $WS_DIR_ADDON . ' && for f in *.php; do php -l "$f" | grep -v "^No syntax errors"; done; echo "fim da checagem"',
       'Procura erro de sintaxe em todos os arquivos. Se não imprimir nada além de "fim da checagem", está íntegro. Rode SEMPRE depois de atualizar arquivos.', false],

      ['Recarregar o painel (PHP-FPM)',
       '/etc/init.d/php-admin reload',
       'O painel usa o pool php-admin. Recarregar o php7.3-fpm genérico NÃO recarrega o painel — é o engano mais comum.', true],

      ['Sincronizar js/ e css/',
       'cd ' . $WS_DIR_ADDON . '; [ -f ws_confianca.js ] && cp -f ws_confianca.js js/; [ -f wellsystem.js ] && cp -f wellsystem.js js/; [ -f wellsystem.css ] && cp -f wellsystem.css css/; echo "ok"',
       'Arquivos de js/ e css/ pertencem às SUBPASTAS. Quando ficam na raiz, a página continua carregando a versão antiga e parece que a alteração não subiu.', true],

      ['Corrigir permissões',
       'cd ' . $WS_DIR_ADDON . ' && chown -R www-data:www-data cache uploads backups && chmod -R u+rwX cache uploads backups',
       'Sintomas: upload falha, configuração não salva, tela em branco. Acontece depois de copiar arquivos como root.', true],

      /* APPARMOR — a causa de "Permission denied" que NENHUM chmod resolve.
         No MK-Auth o php-fpm do painel roda confinado pelo perfil "sistema.php-admin", em enforce
         mode. O perfil, e não o sistema de arquivos, decide onde o PHP pode escrever: com dono
         correto e 775 na pasta, a gravação continua sendo negada. O sistema já contorna sozinho
         (as imagens vão para a pasta de cache, em /var/tmp, que o perfil libera), então este
         comando é OPCIONAL — serve para quem prefere as imagens dentro da pasta do addon.
         Faz cópia de segurança do perfil antes, não repete a regra se já existir, e insere ANTES
         da última chave para não quebrar a sintaxe do arquivo. */
      ['Liberar AppArmor p/ gravar imagens',
       'P=$(ls /etc/apparmor.d/ 2>/dev/null | grep -i "php-admin" | head -1); '
       . '[ -n "$P" ] || { echo "perfil php-admin nao encontrado — nada a fazer"; exit 0; }; '
       . 'F="/etc/apparmor.d/$P"; cp -n "$F" "$F.bak-wellsystem"; '
       . 'grep -q "addons/wellsystem" "$F" || sed -i \'$ s|^}|  ' . $WS_DIR_ADDON . '/** rwk,\\n}|\' "$F"; '
       . 'apparmor_parser -r "$F" && echo "OK: perfil $P liberado e recarregado" && tail -3 "$F"',
       'Use quando o envio de logo/foto falhar com "Permission denied" mesmo com a pasta liberada. '
       . 'O PHP do painel roda dentro de um perfil AppArmor que proíbe escrita em /opt/mk-auth — '
       . 'chmod e chown não têm efeito nenhum sobre isso. Guarda cópia do perfil (.bak-wellsystem).', true],

      ['Backup do banco',
       'mkdir -p /root/bkp && mysqldump --single-transaction wellsystem | gzip > /root/bkp/wellsystem_$(date +%F_%H%M).sql.gz && ls -lh /root/bkp | tail -3',
       'Faça ANTES de importação, correção em massa ou atualização. Não trava o sistema (--single-transaction).', true],

      ['Qual banco o sistema usa',
       'cd ' . $WS_DIR_ADDON . ' && php -r \'require "config.php"; $c=ws_db_config(); echo "{$c["user"]}@{$c["host"]}:{$c["porta"]} banco {$c["dbname"]}\n";\'',
       'Confirma host, usuário e banco realmente em uso. Útil quando a tela mostra dados que você não reconhece.', false],

      ['Qual banco o FreeRADIUS lê',
       'grep -E "^\\s*(server|radius_db|login)" /etc/freeradius/3.0/mods-enabled/sql',
       'Como addon do MK-Auth, o FreeRADIUS lê mkradius e o WellSystem grava em wellsystem. É a origem da maioria dos "não teve efeito na conexão".', false],

      ['Sessões de um cliente',
       'cd ' . $WS_DIR_ADDON . ' && php ws_diag_sessao.php LOGIN_DO_CLIENTE',
       'Mostra as últimas sessões, o IP entregue em cada uma e se o bloqueio voltou. Troque LOGIN_DO_CLIENTE.', false],

      ['Confiança fora de sincronia',
       'cd ' . $WS_DIR_ADDON . ' && php ws_sincronizar_confianca.php',
       'Lista quem está em confiança no sistema mas continua cortado no MK-Auth (sem IP de navegação). Só lista; para aplicar acrescente --aplica.', false],

      ['Conferir a contagem da OLT',
       'cd ' . $WS_DIR_ADDON . ' && php ws_olt_conferir.php',
       'Pergunta à OLT ao vivo e compara com o cache que a tela usa, dizendo QUAL serial falta ou sobra e em que placa. Só lê. Acrescente --detalhe para listar todos, ou o número da placa para conferir só uma.', false],

      ['Erros recentes do Apache',
       'tail -50 /var/log/apache2/error.log',
       'Primeira parada quando uma tela abre em branco ou dá erro 500.', false],

      ['Espaço em disco',
       'df -h / && du -sh ' . $WS_DIR_ADDON . '/* 2>/dev/null | sort -h | tail -10',
       'Disco cheio derruba upload, backup e o próprio banco. As 10 maiores pastas do sistema aparecem no fim.', false],
    ];
    ?>

    <div class="mnt-cmds">
      <?php if (function_exists('ws_edicao_manutencao_cmds')) $cmds = ws_edicao_manutencao_cmds($cmds);   // edição isolada: sem comandos de RADIUS/MK-Auth/robô
    foreach ($cmds as $i => $c): ?>
        <div class="mnt-cmd">
          <div class="mnt-cmd-top">
            <b><?= $c[3] ? '⚠️ ' : '' ?><?= $h($c[0]) ?></b>
            <button type="button" class="ws-btn mnt-cmd-copiar" data-alvo="cmd<?= $i ?>">📋 Copiar</button>
          </div>
          <div class="oque"><?= $h($c[2]) ?></div>
          <code id="cmd<?= $i ?>" class="mnt-cmd-txt"><?= $h($c[1]) ?></code>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <script>
  /* Copiar para a área de transferência, com retorno visual no próprio botão.
     execCommand é o caminho antigo, mas é o único que funciona em HTTP puro — e este painel
     costuma ser acessado por IP, sem HTTPS, onde navigator.clipboard não existe. */
  (function () {
    document.querySelectorAll('.mnt-cmd-copiar').forEach(function (b) {
      b.addEventListener('click', function () {
        var el = document.getElementById(b.dataset.alvo);
        if (!el) return;
        var txt = el.textContent;
        var rot = b.textContent;
        function fim(ok) {
          b.textContent = ok ? '✅ copiado' : '⚠️ selecione e copie';
          setTimeout(function () { b.textContent = rot; }, 2000);
        }
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(txt).then(function () { fim(true); }, function () { fim(false); });
          return;
        }
        try {
          var ta = document.createElement('textarea');
          ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.select();
          fim(document.execCommand('copy'));
          document.body.removeChild(ta);
        } catch (e) { fim(false); }
      });
    });
  })();
  </script>
  <script>
  (function(){
    const mntBusca = document.getElementById('mntBusca');
    if (mntBusca) {
      mntBusca.addEventListener('input', function() {
        const q = this.value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
        
        // Filtra os cards e o conteúdo solto
        document.querySelectorAll('.mnt-card, .mnt-emerg, .mnt-info, .mnt-diag, .mnt-bars').forEach(card => {
          const text = card.textContent.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
          const paiSecao = card.closest('.mnt-grid, .ws-panel') || card.parentElement;
          if (text.includes(q)) {
            card.style.display = '';
            if (paiSecao) paiSecao.dataset.match = "1";
          } else {
            card.style.display = 'none';
          }
        });
        
        // Esconde os títulos das seções (.mnt-sec) e .ws-muted próximos se não houver cards visíveis perto
        document.querySelectorAll('.mnt-sec').forEach(sec => {
          let hasVisible = false;
          let el = sec.nextElementSibling;
          while (el && !el.classList.contains('mnt-sec')) {
            if (el.dataset.match === "1" || (el.style.display !== 'none' && (el.classList.contains('mnt-grid') || el.classList.contains('mnt-bars') || el.classList.contains('mnt-info') || el.classList.contains('mnt-diag')))) {
                let anyCardVis = el.querySelector('.mnt-card:not([style*="display: none"]), .mnt-emerg:not([style*="display: none"]), .mnt-bar:not([style*="display: none"]), .mnt-di:not([style*="display: none"])');
                if (anyCardVis || el.classList.contains('mnt-info') && el.textContent.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "").includes(q)) {
                    hasVisible = true;
                    break;
                }
            }
            if (el.classList.contains('mnt-card') && el.style.display !== 'none') hasVisible = true;
            el = el.nextElementSibling;
          }
          
          sec.style.display = hasVisible ? '' : 'none';
          if (sec.nextElementSibling && sec.nextElementSibling.classList.contains('ws-muted')) {
              sec.nextElementSibling.style.display = hasVisible ? '' : 'none';
          }
        });
        
        document.querySelectorAll('.mnt-grid, .ws-panel').forEach(g => delete g.dataset.match);
      });
    }
  })();
  </script>
  <script>
  /* Atalhos por seção (05/11/2026): lista só os títulos de nível superior (os de dentro do painel de diagnóstico ficam de fora). Não muda nenhum card. */
  (function(){
    var secs = [].slice.call(document.querySelectorAll('.mnt-sec')).filter(function(s){ return !s.closest('.ws-panel'); });
    var painel = document.querySelector('.ws-panel'); if (secs.length < 3 || !painel) return;
    var nav = document.createElement('div'); nav.id = 'mntNav'; nav.setAttribute('aria-label', 'Ir para a seção');
    var a0 = document.createElement('a'); a0.href = '#'; a0.textContent = '📊 Diagnóstico'; a0.addEventListener('click', function(e){ e.preventDefault(); painel.scrollIntoView({behavior:'smooth', block:'start'}); }); nav.appendChild(a0);
    secs.forEach(function(s, i){ if (!s.id) s.id = 'mnt-sec-' + i; var a = document.createElement('a'); a.href = '#' + s.id; a.textContent = s.textContent.trim().replace(/\s+/g, ' ').substring(0, 34); a.addEventListener('click', function(e){ e.preventDefault(); s.scrollIntoView({behavior:'smooth', block:'start'}); }); nav.appendChild(a); });
    painel.parentNode.insertBefore(nav, painel);
  })();
  </script>

<?php endif; ?>

</main><?= ws_footer_bar() ?>
<script>
/* Cartões da Manutenção: todos do mesmo tamanho; o que passar da altura ganha "ver tudo", que abre o cartão inteiro POR CIMA dos de baixo. */
(function(){
  var H=215, aberto=null;
  function fechar(){
    if(!aberto) return; var c=aberto.card;
    c.classList.remove('mnt-sobre'); c.style.cssText=aberto.estilo; if(aberto.ph&&aberto.ph.parentNode) aberto.ph.parentNode.removeChild(aberto.ph);
    var b=c.querySelector(':scope > .mnt-vermais'); if(b) b.textContent='ver tudo \u25BE'; aberto=null;
  }
  function abrir(c){
    fechar(); var g=c.parentNode, ph=document.createElement('div');
    /* (08/11/2026) mede a posição ANTES de pôr o espaço reservado: depois dele o cartão já foi empurrado para a casa seguinte da grade e abria fora do lugar. */
    var est=c.style.cssText, l=c.offsetLeft, t=c.offsetTop, w=c.offsetWidth, h=c.offsetHeight;
    ph.style.cssText='grid-column:'+(c.style.gridColumn||'auto')+';height:'+h+'px';
    g.insertBefore(ph,c);
    c.classList.add('mnt-sobre'); c.style.boxSizing='border-box'; c.style.left=l+'px'; c.style.top=t+'px'; c.style.width=w+'px';
    var b=c.querySelector(':scope > .mnt-vermais'); if(b) b.textContent='recolher \u25B4';
    aberto={card:c,ph:ph,estilo:est};
  }
  function montar(){
    document.querySelectorAll('.mnt-grid > .mnt-card').forEach(function(c){
      if(c.classList.contains('mnt-aberto')||c.classList.contains('mnt-emerg')||c.dataset.mntOk) return;
      if(c.scrollHeight<=H+6) return;
      c.dataset.mntOk='1'; c.classList.add('mnt-comp');
      var b=document.createElement('button'); b.type='button'; b.className='mnt-vermais'; b.textContent='ver tudo \u25BE';
      b.addEventListener('click',function(e){e.stopPropagation(); if(aberto&&aberto.card===c) fechar(); else abrir(c);});
      c.appendChild(b);
    });
  }
  document.addEventListener('click',function(e){ if(aberto&&!aberto.card.contains(e.target)) fechar(); });
  document.addEventListener('keydown',function(e){ if(e.key==='Escape') fechar(); });
  window.addEventListener('resize',fechar);
  if(document.readyState==='complete') montar(); else window.addEventListener('load',montar);
})();
</script>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
</body></html>
