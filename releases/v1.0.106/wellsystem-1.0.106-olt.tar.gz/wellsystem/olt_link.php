<?php
/**
 * WellSystem ERP — Unificação com o addon da OLT (wellsystem_olt).
 *
 * Lê os dados de aprovisionamento que o addon já grava em cache_trafego/*.json:
 *   - olt_autorizacoes.json  -> ONUs autorizadas (SN, F/S/P, ONT-ID, nome, VLAN, zona, endereço)
 *   - olt_autofind.json      -> ONUs aguardando autorização (pendentes)
 *   - olt_onus_cache.json    -> total de ONUs conhecidas (para contagem)
 *
 * Config em cache/olt_link.json (Config → Integração). Na instalação UNIFICADA
 * (addon + ERP no mesmo servidor) basta apontar o caminho da pasta cache_trafego do addon.
 */
require_once __DIR__ . '/config.php';

define('WS_OLT_LINK_CFG', WS_CACHE . '/olt_link.json');

function ws_olt_link_config(): array {
    // olt_url   = seu gerenciador da OLT (olt.php — fala Telnet ao vivo com a OLT na rede)
    // radius_url= sua página Total Radius (index.php — concentradores/CNC ao vivo)
    $def = ['modo' => 'arquivo', 'caminho' => '', 'url' => '', 'cron_key' => '', 'olt_url' => '', 'radius_url' => ''];
    // UNIFICAÇÃO AUTOMÁTICA: se o addon foi copiado para wellsystem/olt/, já aponta pra ele.
    // Módulo da OLT unificado na raiz (olt/ só redireciona): a Gerência e os dados são os da raiz.
    if (is_file(__DIR__ . '/olt.php')) {
        $def['olt_url'] = 'olt.php';
        $def['caminho'] = __DIR__ . '/cache_trafego'; $def['modo'] = 'arquivo';
    } elseif (is_dir(__DIR__ . '/olt')) {
        if (is_file(__DIR__ . '/olt/olt.php')) $def['olt_url'] = 'olt/olt.php';
        if (is_dir(__DIR__ . '/olt/cache_trafego')) { $def['caminho'] = __DIR__ . '/olt/cache_trafego'; $def['modo'] = 'arquivo'; }
    }
    if (is_file(WS_OLT_LINK_CFG)) {
        $c = json_decode(@file_get_contents(WS_OLT_LINK_CFG), true);
        if (is_array($c)) return array_merge($def, array_filter($c, fn($v) => $v !== '' && $v !== null));
    }
    return $def;
}
function ws_olt_link_salvar(array $cfg): void {
    @file_put_contents(WS_OLT_LINK_CFG, json_encode(array_merge(ws_olt_link_config(), $cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_OLT_LINK_CFG, 0640);
}

/** Lê um JSON de cache do addon (por caminho de arquivo ou via HTTP do addon). */
/**
 * TODAS as pastas onde o módulo da OLT pode estar gravando o cache.
 *
 * O addon grava em VÁRIOS lugares e usa o mais recente (olt_cache_dirs/olt_cache_save, no
 * olt_huawei.php). Quando a pasta do addon não é gravável pelo www-data, ele cai para a pasta de
 * sistema — e o arquivo dentro de olt/cache_trafego CONGELA numa data antiga. Lendo só aquela
 * pasta, o ERP via dado velho ou não via nada: era por isso que a migração não puxava zona, VLAN
 * e placa/PON mesmo com a OLT instalada ao lado.
 *
 * A ordem aqui não decide nada — quem decide é a data de modificação, igual ao addon.
 */
function ws_olt_cache_dirs(): array {
    $c = ws_olt_link_config();
    $dirs = [];
    // chr(92) é a barra invertida. Escrita assim de propósito: a barra invertida literal dentro de
    // aspas simples já quebrou este arquivo uma vez — ela escapava a aspa de fechamento e o PHP
    // parava de abrir. Aqui a separação de pasta é normalizada para "/" antes de tirar a do fim.
    if ($c['modo'] === 'arquivo' && $c['caminho'] !== '') {
        $dirs[] = rtrim(str_replace(chr(92), '/', $c['caminho']), '/');
    }
    $dirs[] = __DIR__ . '/olt/cache_trafego';                   // addon em wellsystem/olt/
    $dirs[] = __DIR__ . '/cache_trafego';                       // addon na raiz do wellsystem
    $dirs[] = sys_get_temp_dir() . '/acellApp_cache_trafego';   // fallback do addon (pasta sem permissão)
    $out = [];
    foreach ($dirs as $d) { if ($d !== '' && is_dir($d) && !in_array($d, $out, true)) $out[] = $d; }
    return $out;
}

function ws_olt_ler_json(string $arquivo): ?array {
    $c = ws_olt_link_config();
    if ($c['modo'] === 'arquivo') {
        // Vence o MAIS RECENTE entre as pastas — mesma regra do addon.
        $melhor = null; $mts = -1;
        foreach (ws_olt_cache_dirs() as $d) {
            $f = $d . '/' . $arquivo;
            if (!is_file($f)) continue;
            $t = (int)@filemtime($f);
            if ($t < $mts) continue;
            $j = json_decode((string)@file_get_contents($f), true);
            if (is_array($j)) { $melhor = $j; $mts = $t; }
        }
        if ($melhor !== null) return $melhor;
        if ($c['caminho'] !== '') return null;   // apontado por caminho e não achou: não tenta HTTP
    }
    if ($c['modo'] === 'http' && $c['url'] !== '' && function_exists('curl_init')) {
        // busca o arquivo cru servido pelo addon (cache_trafego é protegido; então usamos o endpoint mkfiles_get se existir)
        $u = rtrim($c['url'], '/') . '/olt_huawei.php?acao=mkfiles_get&file=' . rawurlencode($arquivo) . '&key=' . rawurlencode($c['cron_key']);
        $ch = curl_init($u);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_SSL_VERIFYPEER => false]);
        $raw = curl_exec($ch); curl_close($ch);
        $d = $raw ? json_decode($raw, true) : null;
        return is_array($d) ? $d : null;
    }
    return null;
}

/** Lista de ONUs autorizadas (normalizada) — junta o cache do addon (se estiver linkado) COM o
 *  cache nativo do WellSystem (gravado por ws_olt_autorizar()), pra tudo aparecer numa lista só,
 *  não importa por qual caminho a ONU foi liberada. */
function ws_olt_autorizacoes(): array {
    if (function_exists('ws_em_demo') && ws_em_demo()) return [];   // DEMO não vê a OLT real
    $j = ws_olt_ler_json('olt_autorizacoes.json') ?: [];
    $nativoFile = WS_CACHE . '/olt_autorizacoes_nativo.json';
    $jn = is_file($nativoFile) ? (json_decode((string)@file_get_contents($nativoFile), true) ?: []) : [];
    if (is_array($jn)) $j = array_merge($j, $jn); // nativo prevalece em caso de SN repetido (mais recente)
    $out = [];
    foreach ($j as $sn => $r) {
        if (!is_array($r)) continue;
        $out[] = [
            'sn'     => $r['sn'] ?? (is_string($sn) ? $sn : ''),
            'fsp'    => $r['fsp'] ?? '',
            'ont_id' => (string)($r['ont_id'] ?? ''),
            'nome'   => $r['nome'] ?? '',
            'vlan'   => (int)($r['vlan'] ?? 0),
            'zona'   => $r['zona'] ?? '',
            'bairro' => $r['bairro'] ?? '',
            'rua'    => $r['rua'] ?? '',
            'cidade' => $r['cidade'] ?? '',
            'numero' => $r['numero'] ?? '',
            'tipo'   => $r['tipo'] ?? '',
            'modo'   => $r['modo'] ?? '',
            'data'   => $r['data'] ?? '',
        ];
    }
    // mais recentes primeiro
    usort($out, fn($a, $b) => strcmp($b['data'], $a['data']));
    return $out;
}

/** Contagens para o painel da aba OLT. */
function ws_olt_stats(): array {
    if (function_exists('ws_em_demo') && ws_em_demo()) return ['autorizadas' => 0, 'pendentes' => 0, 'total_onus' => 0];  // DEMO isolado
    $aut = ws_olt_autorizacoes();
    $af  = ws_olt_ler_json('olt_autofind.json');
    $pend = 0;
    if (is_array($af) && isset($af['pendentes']) && is_array($af['pendentes'])) $pend = count($af['pendentes']);
    // Cache nativo (motor de telnet próprio do WellSystem) — soma se ainda não tiver vindo do addon.
    if ($pend === 0) {
        $nf = WS_CACHE . '/olt_autofind_nativo.json';
        if (is_file($nf)) { $nj = json_decode((string)@file_get_contents($nf), true); if (is_array($nj) && !empty($nj['pendentes'])) $pend = count($nj['pendentes']); }
    }
    $onus = ws_olt_ler_json('olt_onus_cache.json');
    $total = is_array($onus) ? (isset($onus['onus']) && is_array($onus['onus']) ? count($onus['onus']) : count($onus)) : count($aut);
    return ['autorizadas' => count($aut), 'pendentes' => $pend, 'total_onus' => $total];
}

/** Remove do CACHE de autorizações a ONU de um F/S/P + ONT-ID (usado no "Excluir" — assim a ONU
 *  some da lista e NÃO volta, mesmo com a OLT offline; se estiver online, some da OLT também). */
function ws_olt_cache_remover_fsp(string $fsp, int $ontId): int {
    $rem = 0; $cfg = ws_olt_link_config(); $files = [];
    if (!empty($cfg['caminho'])) $files[] = rtrim($cfg['caminho'], '/\\') . '/olt_autorizacoes.json';
    $files[] = WS_CACHE . '/olt_autorizacoes_nativo.json';
    foreach ($files as $f) {
        if (!is_file($f)) continue;
        $j = json_decode((string)@file_get_contents($f), true); if (!is_array($j)) continue;
        $mud = false;
        foreach ($j as $sn => $r) {
            if (is_array($r) && ($r['fsp'] ?? '') === $fsp && (string)($r['ont_id'] ?? '') === (string)$ontId) { unset($j[$sn]); $mud = true; $rem++; }
        }
        if ($mud) @file_put_contents($f, json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    return $rem;
}

/** SNs já vinculados a algum contrato ATIVO (para marcar "já é cliente").
 *
 *  Contrato CANCELADO não é dono do serial. Antes esta consulta pegava qualquer contrato com
 *  sn_onu preenchido, inclusive cancelado — então uma ONU reaproveitada continuava "pertencendo"
 *  ao cliente anterior: ao aprovisionar, vinha o nome antigo, e o serial era contado como
 *  "já é cliente" em vez de "aguardando liberação" (daí a quantidade divergir da OLT).
 *  Equipamento devolvido e reutilizado é o caso normal num provedor, não a exceção.
 */
function ws_olt_sns_vinculados(PDO $db): array {
    $r = [];
    $sql = "SELECT UPPER(sn_onu) s FROM ws_contrato
            WHERE sn_onu IS NOT NULL AND sn_onu <> ''
              AND COALESCE(status,'') <> 'cancelado'";
    foreach ($db->query($sql)->fetchAll(PDO::FETCH_COLUMN) as $s) $r[$s] = true;
    return $r;
}
