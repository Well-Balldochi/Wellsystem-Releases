#!/bin/sh
# ============================================================================
#  OLT MONITOR — TAREFAS AUTOMATICAS (Wellnet)  ·  ARQUIVO UNICO DE CRON
# ----------------------------------------------------------------------------
#  INDEPENDENTE do MK-Auth: roda em QUALQUER servidor (radius, servidor
#  proprio, VPS...). Ele so conversa com o servidor da PAGINA por HTTP (curl),
#  entao nao precisa do MK-Auth pra funcionar — pode ser outro radius no futuro.
#
#  O QUE ELE FAZ (sozinho, 24/7):
#    - scan       : varre a OLT, atualiza o cache, detecta PON em queda,
#                   registra no relatorio e DISPARA as notificacoes (WhatsApp/
#                   Telegram) — tudo numa chamada (acao=cron_scan).
#    - relatorio  : forca o "vira-mes" (limpeza automatica do relatorio no dia 1).
#
#  ------------------------------------------------------------------------
#  COMO INSTALAR (so 1 vez, numa instalacao nova):
#    1) copie este arquivo pro servidor (ex.: /opt/olt_monitor.sh)
#    2) edite a linha BASE abaixo com a URL do addon (onde estao os .php)
#    3) de permissao:   chmod +x /opt/olt_monitor.sh
#    4) instale os crons:   /opt/olt_monitor.sh install
#    Pronto. A partir daqui roda sozinho, sem navegador aberto.
#
#  OUTROS COMANDOS:
#    /opt/olt_monitor.sh uninstall   -> remove os crons
#    /opt/olt_monitor.sh scan        -> roda a varredura AGORA (teste)
#    /opt/olt_monitor.sh status      -> mostra os crons instalados
#
#  OBS: se o arquivo foi editado no Windows e nao rodar ("bad interpreter"),
#       rode:  sed -i 's/\r$//' /opt/olt_monitor.sh   (tira o \r do Windows)
# ============================================================================

# >>>>>>>>>>>>>>>>>>>>  NAO PRECISA AJUSTAR NADA  <<<<<<<<<<<<<<<<<<<<<<<<<<<
# Desde que este script esteja NA MESMA PASTA do olt_huawei.php (que e o caso numa
# instalacao do WellSystem), ele se acha sozinho e trabalha por CLI — sem URL, sem
# chave, sem limite de tempo do PHP-FPM. Foi esse "ajuste aqui" que fez o monitor
# nunca subir num servidor novo: ficava apontando pro endereco do servidor ANTIGO,
# e o sintoma era a pagina da OLT vazia, sem alerta de PON, sem coleta de sinal e
# sem backup — tudo em silencio, porque o cron rodava e falava com o lugar errado.
#
# Para forcar outro destino (ex.: pagina hospedada em OUTRO servidor), exporte:
#     OLT_DIR=/caminho/da/pasta/com/os/php     (preferido — roda por CLI)
#     OLT_BASE=http://host/caminho/olt_huawei.php
SELF_DIR="$(dirname "$(readlink -f "$0" 2>/dev/null || echo "$0")")"

if   [ -n "$OLT_BASE" ];                        then BASE="$OLT_BASE"
elif [ -f "$SELF_DIR/olt_huawei.php" ];         then BASE="http://127.0.0.1/olt_huawei.php"
else BASE="http://127.0.0.1/olt_huawei.php"; fi

# Intervalo da varredura automatica, em MINUTOS. Com 1, o SNMP (sinal + ALERTA RAPIDO de queda
# de PON) roda a cada 1 min; o Telnet pesado fica espacado por TELNET_EVERY abaixo.
SCAN_MIN=1
# Prazo máximo da varredura pesada (lista completa da OLT), em SEGUNDOS. Numa OLT grande e lenta
# a varredura completa leva minutos; passando disto, ela é encerrada e o próximo ciclo tenta de novo
# (o registro em cache_trafego/olt_monitor.log mostra quanto cada etapa levou de verdade).
PESADO_MAX=600
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#
# OBS: com o LOGIN ativo (olt_auth.php na pasta), o cron precisa ser aceito sem
# sessao. O backend libera o cron_scan quando ele vem do proprio servidor OU com
# a chave abaixo. A chave e criada sozinha em cache_trafego/olt_cron_key.txt na
# primeira execucao; para forcar uma, defina aqui (mesmo valor do arquivo).
CRON_KEY=""

# Pasta LOCAL onde estao os .php, NESTE servidor. Preenchida, TUDO roda por CLI
# como www-data (mesma pasta de cache do site, SEM o limite de 15s do PHP-FPM nem
# WAF) — 100% confiavel, e e o caminho que o scan pesado precisa.
#
# A deteccao e por vizinhanca: se o olt_huawei.php esta ao lado deste script, e
# aqui. Numa instalacao do WellSystem isso da certo sempre, sem ninguem editar
# nada — que e o ponto. O caminho do MK-Auth fica so como ultimo recurso, para o
# servidor do addon, onde este script vive fora da pasta dos .php.
if   [ -n "$OLT_DIR" ];                 then ADDON_DIR="$OLT_DIR"
elif [ -f "$SELF_DIR/olt_huawei.php" ]; then ADDON_DIR="$SELF_DIR"
else ADDON_DIR="/opt/mk-auth/admin/addons/wellsystem_olt"; fi

# Caminho absoluto deste proprio script (pros crons apontarem certo).
SELF="$(readlink -f "$0" 2>/dev/null || echo "$0")"
TAG="# OLT_MONITOR_WELLNET"   # marca as nossas linhas no crontab

# Backup diario: prefere CLI como www-data (mesma pasta do site, sem limite de 15s
# nem WAF). Se ADDON_DIR nao existir aqui, cai no HTTP normal.
backup_run() {
  if [ -n "$ADDON_DIR" ] && [ -f "$ADDON_DIR/olt_huawei.php" ]; then
    su -s /bin/sh www-data -c "cd '$ADDON_DIR' && php -r '\$_GET=[\"acao\"=>\"backup_run\"]; \$_SERVER[\"REMOTE_ADDR\"]=\"127.0.0.1\"; include \"olt_huawei.php\";'" >/dev/null 2>&1
  else
    curl -s --max-time 15 "$BASE?acao=backup_run$K" >/dev/null 2>&1
  fi
}

# Expira a confiança VENCIDA (revoga observacao='sim' cuja data ja passou). Roda local
# (CLI), independe da OLT. Quem pagou nao e afetado; quem nao pagou volta a ser bloqueado.
confianca_expira() {
  if [ -n "$ADDON_DIR" ] && [ -f "$ADDON_DIR/confianca_expirar.php" ]; then
    su -s /bin/sh www-data -c "cd '$ADDON_DIR' && php confianca_expirar.php" >/dev/null 2>&1
  fi
}

# Roda uma ACAO do olt_huawei.php por CLI (www-data) — SEM o limite de 15s do PHP-FPM nem WAF.
# Essencial p/ o scan/uplink/tx/coleta que passam de 15s via HTTP (eram cortados). $1 = monta $_GET.
# Retorna 0 se rodou por CLI; 1 se nao ha ADDON_DIR local (ai o chamador cai no curl HTTP).
# ---------------------------------------------------------------------------
# PRAZO POR ETAPA — era isto que fazia o monitor "sumir" por 10, 20, 35 minutos.
#
# Leitura de Telnet que continua recebendo bytes NÃO estoura o max_execution_time
# do PHP (tempo parado em socket não conta). Então uma varredura numa OLT lenta
# podia ficar pendurada sem hora para acabar: ela segurava a trava e TODO minuto
# seguinte desistia — autofind parava, ONU nova não aparecia para aprovisionar, e
# o conferidor só dizia "monitor sem rodar há X", sem explicar nada. Pior: quando
# a trava vencia (30 min), um ciclo NOVO entrava por cima do antigo, que continuava
# vivo, e os dois disputavam as sessões da OLT.
#
# Agora cada etapa tem prazo, medido no próprio php (o `timeout` fica DENTRO do su,
# então quem morre é o php, não o su). `timeout` é do coreutils, padrão no Linux;
# onde não existir, o comportamento é o de antes — nada quebra.
CICLO_LOG=""
cli_acao() {
  if [ -n "$ADDON_DIR" ] && [ -f "$ADDON_DIR/olt_huawei.php" ]; then
    _lim="${2:-120}"; _nm="${3:-etapa}"; _t0=$(date +%s)
    if command -v timeout >/dev/null 2>&1; then _tmo="timeout -k 5 ${_lim}s "; else _tmo=""; fi
    su -s /bin/sh www-data -c "cd '$ADDON_DIR' && ${_tmo}php -d max_execution_time=300 -r '$1 \$_SERVER[\"REMOTE_ADDR\"]=\"127.0.0.1\"; include \"olt_huawei.php\";'" >/dev/null 2>&1
    _rc=$?
    _dt=$(( $(date +%s) - _t0 ))
    if [ "$_rc" = "124" ] || [ "$_rc" = "137" ]; then _nm="$_nm:ESTOUROU_${_lim}s"; fi
    CICLO_LOG="$CICLO_LOG $_nm=${_dt}s"
    return 0
  fi
  return 1
}

# Pasta onde ficam o registro e a trava da parte pesada (a mesma que a tela enxerga).
ciclo_dir() { _d="$ADDON_DIR/cache_trafego"; [ -d "$_d" ] || _d="${TMPDIR:-/tmp}"; echo "$_d"; }

# Registro do ciclo (cache_trafego/olt_monitor.log e olt_monitor_status.txt): quando começou, quanto
# durou e quanto levou cada etapa. É o que responde "por que o monitor não atualizou" sem ninguém
# ter de adivinhar — e é o que o ws-conferir.sh mostra junto do aviso.
ciclo_registrar() {
  _dir="$(ciclo_dir)"
  _linha="$(date '+%d/%m %H:%M:%S') ciclo=$1 total=$2s$3"
  echo "$_linha" >> "$_dir/olt_monitor.log" 2>/dev/null
  echo "$_linha" > "$_dir/olt_monitor_status.txt" 2>/dev/null
  if [ -f "$_dir/olt_monitor.log" ]; then
    tail -n 300 "$_dir/olt_monitor.log" > "$_dir/olt_monitor.log.tmp" 2>/dev/null && mv "$_dir/olt_monitor.log.tmp" "$_dir/olt_monitor.log" 2>/dev/null
  fi
  chmod 664 "$_dir/olt_monitor.log" "$_dir/olt_monitor_status.txt" 2>/dev/null
}

# TRAVA DA PARTE PESADA (varredura completa, Tx, uplink, alarmes, SmartOLT) — separada da trava do
# ciclo. A varredura completa pode levar minutos; enquanto ela roda, o ciclo leve (sinal por SNMP e
# autofind) CONTINUA rodando de minuto em minuto, que é o que faz a ONU nova aparecer para
# aprovisionar. No máximo uma pesada + uma leve ao mesmo tempo — nunca a pilha de dez que esgotava
# as sessões da OLT.
pesado_pegar() {
  PLOCK="$(ciclo_dir)/olt_pesado.lock"
  if [ -d "$PLOCK" ]; then
    ACHOU="$(find "$PLOCK" -maxdepth 0 -mmin +$((PESADO_MAX / 60 + 3)) 2>/dev/null)"
    if [ -n "$ACHOU" ]; then
      VELHO="$(cat "$PLOCK/pid" 2>/dev/null)"
      [ -n "$VELHO" ] && kill -TERM "$VELHO" 2>/dev/null
      # varre sobra antiga: php da OLT rodando há mais tempo que o prazo da pesada
      for p in $(ps -eo pid,etimes,args 2>/dev/null | grep 'olt_huawei.php' | grep -v grep | awk -v lim=$((PESADO_MAX + 120)) '$2 > lim {print $1}'); do
        kill -TERM "$p" 2>/dev/null
      done
      sleep 2
      [ -n "$VELHO" ] && kill -KILL "$VELHO" 2>/dev/null
      rm -rf "$PLOCK"
    fi
  fi
  mkdir "$PLOCK" 2>/dev/null || return 1
  echo "$$" > "$PLOCK/pid" 2>/dev/null
  return 0
}
pesado_soltar() { [ -n "$PLOCK" ] && [ "$(cat "$PLOCK/pid" 2>/dev/null)" = "$$" ] && rm -rf "$PLOCK"; return 0; }
# Solta a trava do CICLO assim que a parte leve termina: a pesada tem trava própria, e é isso que
# deixa o minuto seguinte rodar sinal e autofind enquanto a varredura completa ainda está indo.
# Só solta se a trava for MESMO deste processo (nunca apaga a de um ciclo novo que já começou).
trava_soltar() { [ -n "$LOCK" ] && [ "$(cat "$LOCK/pid" 2>/dev/null)" = "$$" ] && rm -rf "$LOCK"; return 0; }

run() {
  K=""
  [ -n "$CRON_KEY" ] && K="&key=$CRON_KEY"
  case "$1" in
    scan)      T0=$(date +%s)
               # O CONTADOR SOBE NO COMEÇO do ciclo (antes era no meio): assim "monitor rodou há Xs"
               # mostra que o ciclo COMEÇOU, e não só quando a parte pesada conseguiu terminar. A
               # agenda (n%4, n%10, n%20) continua exatamente a mesma.
               CF="${TMPDIR:-/tmp}/olt_scan_count"
               n=$(cat "$CF" 2>/dev/null || echo 0); n=$((n+1)); echo "$n" > "$CF"
               backup_run                                                         # backup diario (CLI local ou HTTP)
               confianca_expira                                                   # expira confiança vencida (regra geral)
               # CONVERGE os arquivos de config entre /tmp e cache_trafego (persistente) — TODO ciclo, barato.
               # Garante que conexao/backup/notif salvos pela TELA (no /tmp) vao pro cache_trafego -> nao
               # somem no restart. Roda por CLI (que consegue gravar no cache_trafego).
               cli_acao '$_GET=["acao"=>"cache_sync"];' 30 cache_sync || curl -s --max-time 15 "$BASE?acao=cache_sync$K" >/dev/null 2>&1
               # SNMP (sem Telnet, sem colisao): sinal + graficos + ALERTA RAPIDO de queda — TODO ciclo (1 min). 23/10/2026: limite 150 s (era 60): a tabela de sinal das ONUs leva ~47 s na OLT e, com 60 s, o passo era cortado a cada ciclo e a coleta de sinal nunca concluía.
               cli_acao '$_GET=["acao"=>"snmp_coletar"];' 150 snmp || curl -s --max-time 120 "$BASE?acao=snmp_coletar$K" >/dev/null 2>&1
               # AGENDA (a trava do Telnet agora é COMPARTILHADA entre a tela e o cron, em cache_trafego —
               # antes cada um tinha a sua no próprio /tmp e as sessões se atropelavam na OLT):
               #   · autofind TODO minuto: comando leve, e é o que faz a ONU nova aparecer para aprovisionar
               #     em até 1 min (antes 2 min — e na Gerência, que lia outro cache, nunca);
               #   · revarredura da placa de ONU recém-aprovisionada: sem pedido não abre Telnet;
               #   · depois, UMA operação pesada: lista completa a cada 4 min (antes 10), Tx e uplink
               #     a cada 20 min, e alarmes nos ciclos que sobram.
               cli_acao '$_GET=["acao"=>"autofind","force"=>1];'  70 autofind || curl -s --max-time 60  "$BASE?acao=autofind&force=1$K"  >/dev/null 2>&1
               cli_acao '$_GET=["acao"=>"rescan_pendente"];'      90 rescan   || curl -s --max-time 120 "$BASE?acao=rescan_pendente$K"   >/dev/null 2>&1
               # SmartOLT (API, sem Telnet): zona e modo Bridge/Router de todas as ONUs, a cada 10 min.
               trava_soltar   # parte leve terminou: o próximo minuto já pode rodar
               # PARTE PESADA — com trava própria e prazo: se a varredura anterior ainda está
               # rodando, ESTE ciclo não a repete (e o leve acima já rodou do mesmo jeito).
               if pesado_pegar; then
                 [ $((n % 10)) -eq 6 ] && { cli_acao '$_GET=["acao"=>"smartolt_map"];' 90 smartolt || curl -s --max-time 60 "$BASE?acao=smartolt_map$K" >/dev/null 2>&1; }
                 if   [ $((n % 4))  -eq 1 ]; then cli_acao '$_GET=["acao"=>"cron_scan"];'                 "$PESADO_MAX" lista_completa || curl -s --max-time 200 "$BASE?acao=cron_scan$K"              >/dev/null 2>&1
                 elif [ $((n % 20)) -eq 3 ]; then cli_acao '$_GET=["acao"=>"pon_tx","force"=>1];'         180 pon_tx || curl -s --max-time 120 "$BASE?acao=pon_tx&force=1$K"          >/dev/null 2>&1
                 elif [ $((n % 20)) -eq 11 ]; then cli_acao '$_GET=["acao"=>"uplink_listar","force"=>1];'  180 uplink || curl -s --max-time 120 "$BASE?acao=uplink_listar&force=1$K"  >/dev/null 2>&1
                 # FALLBACK: nos ciclos SEM outra operacao Telnet, le os ALARMES reais da OLT (display alarm active
                 # all list) e detecta PON caida (LOS/energia em massa) e PLACA caida -> alerta IMEDIATO (~2min),
                 # mantendo 1 Telnet por ciclo. So roda quando nada acima rodou (ciclos antes ociosos).
                 else cli_acao '$_GET=["acao"=>"alarmes_check"];'                                          120 alarmes || curl -s --max-time 60  "$BASE?acao=alarmes_check$K"          >/dev/null 2>&1
                 fi
                 pesado_soltar
               else
                 CICLO_LOG="$CICLO_LOG pesada=pulada(anterior_em_andamento)"
               fi
               ciclo_registrar "$n" "$(( $(date +%s) - T0 ))" "$CICLO_LOG" ;;
    # CLI primeiro, HTTP como reserva — igual ao scan. Estas duas ainda iam direto pro curl,
    # entao numa instalacao sem BASE configurada o vira-mes do relatorio simplesmente nao
    # acontecia, e ninguem tinha como saber: cron sem saida, sem log, sem erro.
    relatorio) cli_acao '$_GET=["acao"=>"relatorio"];'   || curl -s --max-time 30 "$BASE?acao=relatorio$K"   >/dev/null 2>&1 ;;
    alertas)   cli_acao '$_GET=["acao"=>"pon_alertas"];' || curl -s --max-time 30 "$BASE?acao=pon_alertas$K" >/dev/null 2>&1 ;;
    # teste: mostra a resposta na tela (para conferir se o cron consegue rodar)
    testar)    echo "GET $BASE?acao=cron_scan$K"; curl -s --max-time 200 "$BASE?acao=cron_scan$K"; echo ;;
  esac
}

install_cron() {
  TMP="$(mktemp)"
  crontab -l 2>/dev/null | grep -v "$TAG" > "$TMP"
  echo "*/$SCAN_MIN * * * * $SELF scan $TAG"      >> "$TMP"   # varredura + alertas + notificacoes
  echo "1 0 1 * * $SELF relatorio $TAG"           >> "$TMP"   # limpeza do relatorio no dia 1, 00:01
  crontab "$TMP"; rm -f "$TMP"
  echo "OK — crons instalados. BASE=$BASE  (scan a cada ${SCAN_MIN}min)"
  crontab -l | grep "$TAG"
}

uninstall_cron() {
  TMP="$(mktemp)"
  crontab -l 2>/dev/null | grep -v "$TAG" > "$TMP"
  crontab "$TMP"; rm -f "$TMP"
  echo "OK — crons do OLT Monitor removidos."
}

# TRAVA DE EXECUCAO — um ciclo por vez.
#
# O scan roda de minuto em minuto, e uma operacao Telnet pode demorar mais que isso quando a
# OLT esta lenta ou a rede oscila. Sem trava, o cron empilha: dez copias disputando as poucas
# sessoes VTY da OLT, que e exatamente o que derruba as acoes ao vivo da tela ("falta de
# comunicacao com a OLT") e faz o operador achar que a OLT e que esta ruim.
#
# Se o ciclo anterior ainda esta rodando, este simplesmente desiste — nao ha o que fazer com
# dois scans simultaneos, e o proximo minuto tenta de novo.
#
# mkdir e atomico em qualquer sistema de arquivos, entao serve de trava sem depender do flock
# estar instalado. A trava e descartada se ficar velha (30 min), para que um processo morto a
# machado nao deixe o monitor parado para sempre.
trava_pegar() {
  LOCK="${TMPDIR:-/tmp}/ws-olt-monitor.lock"
  if [ -d "$LOCK" ]; then
    # Com prazo em cada etapa, um ciclo não passa de poucos minutos. Passou de 12, é ciclo
    # pendurado: o processo dele é ENCERRADO antes de liberar a trava — senão o antigo continuaria
    # vivo disputando as sessões da OLT com o ciclo novo (foi o que aconteceu em produção).
    ACHOU="$(find "$LOCK" -maxdepth 0 -mmin +12 2>/dev/null)"
    if [ -n "$ACHOU" ]; then
      VELHO="$(cat "$LOCK/pid" 2>/dev/null)"
      [ -n "$VELHO" ] && kill -TERM "$VELHO" 2>/dev/null && sleep 2 && kill -KILL "$VELHO" 2>/dev/null
      rm -rf "$LOCK"
    fi
  fi
  if ! mkdir "$LOCK" 2>/dev/null; then
    echo "$(date '+%d/%m %H:%M:%S') pulado: ciclo anterior ainda rodando" >> "$(ciclo_dir)/olt_monitor.log" 2>/dev/null
    return 1
  fi
  echo "$$" > "$LOCK/pid" 2>/dev/null
  trap 'trava_soltar; pesado_soltar' EXIT INT TERM
  return 0
}

# ESPELHO (05/11/2026): no servidor RESERVA (ou em quarentena logo depois de uma troca) o monitor da OLT fica calado: só UMA máquina conversa com a OLT
# (Telnet é 1 sessão por vez) e dispara alerta de PON. Qualquer falha na consulta = roda (nunca derruba o monitoramento por causa do espelho).
pode_rodar() { [ -f "$SELF_DIR/espelho_cli.php" ] || return 0; php "$SELF_DIR/espelho_cli.php" pode >/dev/null 2>&1; r=$?; [ "$r" -ne 1 ]; }

case "$1" in
  install)               install_cron ;;
  uninstall)             uninstall_cron ;;
  status)                crontab -l 2>/dev/null | grep "$TAG" || echo "(nenhum cron do OLT Monitor instalado)" ;;
  scan)                  pode_rodar || exit 0; trava_pegar || exit 0; run scan ;;
  relatorio|alertas)     pode_rodar || exit 0; run "$1" ;;
  backup)                K=""; [ -n "$CRON_KEY" ] && K="&key=$CRON_KEY"; backup_run; echo "backup disparado (ADDON_DIR=$ADDON_DIR)" ;;
  *) echo "uso: $0 {install|uninstall|status|scan|relatorio|backup}" ;;
esac
