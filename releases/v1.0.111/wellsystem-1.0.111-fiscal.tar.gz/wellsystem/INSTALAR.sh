#!/bin/bash
# =================================================================================================
# WellSystem — instalação COMPLETA sem Docker, direto no servidor.
#
#     sudo ./INSTALAR.sh
#
# Instala e configura, de uma vez:
#   · Apache + PHP 8 com as extensões que o sistema usa
#   · MariaDB, com banco e usuário próprios do WellSystem
#   · FreeRADIUS lendo esse mesmo banco (autenticação, bloqueio, contabilidade)
#   · as tarefas automáticas no cron (sincronismo, cobrança, faturamento, backup)
#
# É idempotente: rodar de novo não estraga nada e não troca senha já gerada.
#
# POR QUE ESTA VERSÃO EXISTE
# O arranjo em Docker/Swarm funciona, mas cria três obstáculos que só aparecem com o RADIUS:
# a rede overlay que o host não enxerga, o NAT do Swarm que TROCA o IP de origem dos pacotes
# (e o FreeRADIUS identifica o concentrador justamente pelo IP), e a recusa do Swarm em publicar
# porta presa ao loopback. Sem container, nada disso existe: tudo na mesma máquina, falando por
# localhost, com o pacote chegando como foi enviado.
# =================================================================================================
set -e

cd "$(dirname "$0")"
RAIZ="$(pwd)"
DESTINO="${WS_DESTINO:-/var/www/wellsystem}"
DB_NOME="${WS_DB_NOME:-wellsystem}"
DB_USER="${WS_DB_USER:-wellsystem}"
# BANCO PRÓPRIO DO FREERADIUS. Separado do banco do sistema de propósito: credencial separada,
# retenção separada (radacct cresce sem parar) e o schema do FreeRADIUS sem coluna nossa no meio.
# Ver o cabeçalho do schema_radius.php para o raciocínio completo — inclusive o que a separação
# NÃO resolve (sessão presa, que é falta do Accounting-Stop e não problema de banco).
DB_RADIUS="${WS_DB_RADIUS:-radius}"
ARQ_SENHAS="/root/.wellsystem-instalacao"

echo ''
echo '================================================='
echo ' WellSystem — instalação direta (sem Docker)'
echo '================================================='
echo ''

[ "$(id -u)" = "0" ] || { echo "ERRO: rode como root (sudo ./INSTALAR.sh)" >&2; exit 1; }
[ -f "$RAIZ/config.php" ] || { echo "ERRO: rode de dentro da pasta do WellSystem (config.php nao encontrado)" >&2; exit 1; }
[ -f "$RAIZ/ws-ambiente.sh" ] || { echo "ERRO: ws-ambiente.sh nao veio no pacote — gere o pacote de novo." >&2; exit 1; }
. "$RAIZ/ws-ambiente.sh"

# ---- 0) ESTE SERVIDOR E PARA ESTE INSTALADOR? ------------------------------------------------------
# O INSTALAR.sh monta o CENARIO SERVIDOR: instala Apache, MariaDB e FreeRADIUS, desliga o site
# padrao do Apache e reinicia o FreeRADIUS. Num servidor que ja e de outro sistema, isso e
# destrutivo: no MK-Auth, derrubaria o painel e a autenticacao de todos os clientes do provedor.
# A decisao e de ws_amb_bloqueio_instalar() (ws-ambiente.sh, coberta pelo autoteste) e acontece
# ANTES de qualquer pacote ser instalado.
# ADDON EM OUTRO ERP, informado: a pasta desse ERP não tem padrão, então vem uma vez pela variável.
if [ -n "${WS_ADDON:-}" ]; then
    exec bash "$RAIZ/ws-instalar-addon.sh"
fi
BLOQUEIO="$(ws_amb_bloqueio_instalar "$RAIZ")"
case "$BLOQUEIO" in
    '') ;;
    container)
        echo 'ERRO: rodando DENTRO de um container. Em Docker a instalacao e pelo docker compose,' >&2
        echo '      na pasta do projeto, no servidor:   docker compose up -d --build' >&2
        exit 1 ;;
    mkauth)
        # Servidor MK-Auth: nada do cenário servidor pode rodar aqui (derrubaria o painel e o
        # FreeRADIUS dele). O WellSystem entra como ADDON — banco, usuário, cópia e tabelas feitos
        # sozinhos pelo ws-instalar-addon.sh, sem tocar em nada do MK-Auth.
        echo 'Servidor MK-Auth detectado: instalando o WellSystem como ADDON.'
        exec bash "$RAIZ/ws-instalar-addon.sh" ;;
    wellsystem-addon:*)
        # WellSystem já instalado como addon de outro ERP: reinstalar completa o que faltar ali.
        echo "WellSystem ja instalado como addon em ${BLOQUEIO#wellsystem-addon:} — completando a instalacao."
        WS_ADDON="${BLOQUEIO#wellsystem-addon:}" exec bash "$RAIZ/ws-instalar-addon.sh" ;;
    wellsystem-*)
        echo "O WellSystem ja esta instalado aqui: ${BLOQUEIO#wellsystem-}" >&2
        echo 'Para atualizar:   bash ATUALIZAR.sh' >&2
        exit 1 ;;
    *)
        if [ "${WS_FORCAR:-0}" != "1" ]; then
            echo "ATENCAO: este servidor ja serve outro sistema: $BLOQUEIO" >&2
            echo '         O INSTALAR.sh desliga o site padrao do Apache e poderia tirar esse sistema do ar.' >&2
            echo '         Para instalar como ADDON desse sistema, informe a pasta do addon dentro do site dele:' >&2
            echo '             WS_ADDON=/pasta/do/site/wellsystem bash INSTALAR.sh' >&2
            echo '         Se tem certeza de que este servidor e so do WellSystem:   WS_FORCAR=1 bash INSTALAR.sh' >&2
            exit 1
        fi ;;
esac

# ---- senhas: geradas uma vez e reaproveitadas ---------------------------------------------------
# Guardadas em arquivo só do root. Gerar de novo a cada execução quebraria a instalação existente,
# porque o banco e o FreeRADIUS já estariam configurados com as anteriores.
if [ -f "$ARQ_SENHAS" ]; then
    . "$ARQ_SENHAS"
    echo "Reaproveitando as senhas de $ARQ_SENHAS"
else
    DB_SENHA="$(openssl rand -base64 24 | tr -d '$/+=' | cut -c1-20)"
    RAD_SENHA="$(openssl rand -base64 24 | tr -d '$/+=' | cut -c1-20)"
    printf 'DB_SENHA=%s\nRAD_SENHA=%s\n' "$DB_SENHA" "$RAD_SENHA" > "$ARQ_SENHAS"
    chmod 600 "$ARQ_SENHAS"
    echo "Senhas geradas e guardadas em $ARQ_SENHAS"
fi

# ---- 1) pacotes ---------------------------------------------------------------------------------
echo ''
echo '==> 1/7 instalando Apache, PHP, MariaDB e FreeRADIUS...'
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
    apache2 libapache2-mod-php \
    php php-mysql php-gd php-curl php-mbstring php-zip php-xml \
    mariadb-server mariadb-client \
    freeradius freeradius-mysql freeradius-utils \
    unzip cron openssl rsync >/dev/null
# Leitura dos comprovantes PIX (selo antifraude): PDF (poppler-utils) e print/foto (OCR tesseract em português).
# Opcional: sem eles o selo compara só o arquivo — por isso não interrompe a instalação se falhar.
apt-get install -y -qq poppler-utils tesseract-ocr tesseract-ocr-por >/dev/null 2>&1 || true
# SNMP (21/10/2026): tráfego/sinal da OLT e TODOS os gráficos da OLT vêm de SNMP (extensão do PHP + net-snmp). Sem eles a OLT abre, mas
# os gráficos ficam em "Coletando…" para sempre. O servidor anterior (Ubuntu) tinha; a ISO Debian 13 não instalava.
apt-get install -y -qq --no-install-recommends snmp php-snmp >/dev/null 2>&1 || echo 'AVISO: nao consegui instalar snmp/php-snmp - os graficos da OLT nao vao coletar (apt-get install snmp php-snmp).'
# HORA CERTA (31/10/2026): servidor sem sincronismo de hora grava registro de conexão com horário errado. chrony + NTP.br; o servidor de logs entra depois, pela tela Logs de conexão.
apt-get install -y -qq chrony >/dev/null 2>&1 || echo 'AVISO: nao consegui instalar o chrony - a hora do servidor nao sera sincronizada ate o sistema instalar sozinho (atualizar_run.php).'
# PROTECAO DO SSH CONTRA FORCA BRUTA (15/11/2026): servidor com IP publico recebe milhares de tentativas de senha por dia no SSH de root (medido: 8 a 12 mil/dia em cada VM).
# O fail2ban bloqueia quem insiste; redes internas nunca sao bloqueadas e o login (senha ou chave) continua exatamente como estava. Nao interrompe a instalacao se falhar.
if apt-get install -y -qq fail2ban python3-systemd >/dev/null 2>&1; then
    mkdir -p /etc/fail2ban/jail.d
    cat > /etc/fail2ban/jail.d/wellnet-sshd.local <<F2B
[DEFAULT]
ignoreip = 127.0.0.0/8 ::1 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 100.64.0.0/10

[sshd]
enabled  = true
backend  = systemd
port     = $(sshd -T 2>/dev/null | awk '/^port /{print $2; exit}' | grep -E '^[0-9]+$' || echo 22)
maxretry = 5
findtime = 10m
bantime  = 1h
bantime.increment = true
bantime.factor = 4
bantime.maxtime = 7d
F2B
    systemctl enable --now fail2ban >/dev/null 2>&1 || true
else
    echo 'AVISO: nao consegui instalar o fail2ban - o SSH fica sem protecao contra forca bruta (apt-get install fail2ban).'
fi
a2enmod rewrite headers >/dev/null 2>&1 || true
systemctl enable --now mariadb >/dev/null 2>&1 || true
# Disco ROTATIVO (HDD): cada gravacao confirmada leva ~17 ms e deixava o servidor em espera de disco (wa 45-50%, rotina do RADIUS de minutos).
# Modo 2 = o banco confirma na hora e o disco recebe a gravacao a cada 1 s (perda maxima numa queda dura: 1 s). Disco SSD fica no modo padrao.
if cat /sys/block/sd*/queue/rotational /sys/block/vd*/queue/rotational 2>/dev/null | grep -q 1 && [ ! -f /etc/mysql/mariadb.conf.d/71-wellsystem-disco.cnf ] && [ -d /etc/mysql/mariadb.conf.d ]; then
    printf '[mysqld]\ninnodb_flush_log_at_trx_commit = 2\n' > /etc/mysql/mariadb.conf.d/71-wellsystem-disco.cnf
    systemctl restart mariadb >/dev/null 2>&1 || true
fi
echo "    php $(php -r 'echo PHP_VERSION;') · $(mariadb --version | cut -d' ' -f4-6) · $(freeradius -v 2>/dev/null | head -1 | cut -d' ' -f2-3)"

# ---- 2) código ----------------------------------------------------------------------------------
echo '==> 2/7 publicando o código em' "$DESTINO"
mkdir -p "$DESTINO"

# PRESERVA O QUE É DO SERVIDOR, NÃO DO PACOTE.
#
#   cache/          configuração desta instalação (banco, ativação, preferências)
#   uploads/        fotos, documentos e anexos dos clientes
#   cache_trafego/  CONEXÃO DA OLT (IP, usuário, senha, SNMP), histórico de tráfego, relatórios
#
# Copiar por cima dessas três devolve a instalação ao estado de fábrica — e o sintoma é cruel:
# ninguém mexeu na senha da OLT, mas ela "parou de entrar", logo depois de uma atualização. Já
# aconteceu duas vezes: primeiro porque o Docker recriava o container, agora porque este script
# copiava tudo. O ATUALIZAR.sh já protegia; faltava aqui, e o INSTALAR.sh é justamente o que se
# roda de novo para reaplicar configuração — ou seja, o mais perigoso de todos.
if command -v rsync >/dev/null 2>&1; then
    # backups/ entrou aqui depois de encontrado o defeito: sem ela, os dumps do banco do servidor eram
    # substituidos pelos do pacote (ou seja, pelos do computador que gerou o ZIP).
    rsync -a --exclude 'cache/' --exclude 'uploads/' --exclude 'cache_trafego/' --exclude 'backups/' --exclude 'Mkfiles/' \
             --exclude '.env' --exclude '.git/' "$RAIZ"/ "$DESTINO"/
else
    # Sem rsync: copia item a item, pulando as três pastas protegidas.
    for item in "$RAIZ"/* "$RAIZ"/.[!.]*; do
        [ -e "$item" ] || continue
        nome="$(basename "$item")"
        case "$nome" in cache|uploads|cache_trafego|backups|Mkfiles|.env|.git) continue ;; esac
        cp -a "$item" "$DESTINO/" 2>/dev/null || true
    done
fi
# uploads/mkfiles guarda as fotos de modelo de ONU/ONT enviadas pela tela da OLT. Fica dentro
# de uploads/ de proposito: e a unica pasta que sobrevive a publicacao E ja tem o .htaccess que
# proibe execucao de PHP — obrigatorio em pasta que recebe arquivo enviado pela web.
mkdir -p "$DESTINO/cache" "$DESTINO/uploads" "$DESTINO/uploads/mkfiles" "$DESTINO/assets" "$DESTINO/cache_trafego"
chown -R www-data:www-data "$DESTINO"
find "$DESTINO" -type d -exec chmod 755 {} \; 2>/dev/null || true
find "$DESTINO" -type f -exec chmod 644 {} \; 2>/dev/null || true
chmod -R 775 "$DESTINO/cache" "$DESTINO/uploads" "$DESTINO/assets" "$DESTINO/cache_trafego"
[ -d "$DESTINO/Mkfiles" ] && chmod -R 775 "$DESTINO/Mkfiles" 2>/dev/null || true

# ---- 3) banco -----------------------------------------------------------------------------------
echo '==> 3/7 criando banco e usuários...'
# A conta de manutenção do Debian tem privilégio total e não exige senha de root do MySQL — é o
# caminho que funciona tanto em instalação nova quanto em servidor que já tem root com senha.
MYSQL_ADM="mariadb"
[ -f /etc/mysql/debian.cnf ] && MYSQL_ADM="mariadb --defaults-file=/etc/mysql/debian.cnf"

$MYSQL_ADM <<SQL
CREATE DATABASE IF NOT EXISTS \`$DB_NOME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS \`${DB_NOME}_demo\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS \`$DB_RADIUS\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AS DUAS CONTAS DO MESMO USUARIO: 'localhost' e '127.0.0.1'.
-- Para o MySQL elas nao sao a mesma coisa (ele autoriza por usuario E origem), e a config que
-- gravamos logo abaixo usa host 127.0.0.1. Onde o servidor resolve nomes, 127.0.0.1 vira
-- "localhost" e a conta de localhost serve; onde skip-name-resolve esta ligado, nao vira, e a
-- instalacao morria em "[1045] Access denied for user '$DB_USER'@'127.0.0.1'" — mesmo codigo,
-- mesma senha, erro em um servidor e nao no outro. Criar as duas resolve nos dois casos.
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_SENHA';
ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_SENHA';
CREATE USER IF NOT EXISTS '$DB_USER'@'127.0.0.1' IDENTIFIED BY '$DB_SENHA';
ALTER USER '$DB_USER'@'127.0.0.1' IDENTIFIED BY '$DB_SENHA';
GRANT ALL PRIVILEGES ON \`$DB_NOME\`.* TO '$DB_USER'@'localhost';
GRANT ALL PRIVILEGES ON \`$DB_NOME\`.* TO '$DB_USER'@'127.0.0.1';
-- O usuário do sistema precisa de acesso ao banco do RADIUS porque é ELE quem escreve
-- radcheck/radusergroup a partir dos contratos (o WellSystem é a fonte da verdade; o FreeRADIUS
-- só lê). As visões no banco do sistema apontam para cá — ver schema_radius.php.
GRANT ALL PRIVILEGES ON \`$DB_RADIUS\`.* TO '$DB_USER'@'localhost';
GRANT ALL PRIVILEGES ON \`$DB_RADIUS\`.* TO '$DB_USER'@'127.0.0.1';
-- Bancos auxiliares (demo e o temporário da importação de backup). O "\\_" escapa o sublinhado,
-- que em GRANT é curinga de um caractere.
GRANT ALL PRIVILEGES ON \`${DB_NOME}\\_%\`.* TO '$DB_USER'@'localhost';
GRANT ALL PRIVILEGES ON \`${DB_NOME}\\_%\`.* TO '$DB_USER'@'127.0.0.1';

-- O usuário do RADIUS é criado aqui, mas as permissões dele vêm DEPOIS das tabelas (passo 4):
-- GRANT por tabela exige que a tabela exista, e quem as cria é o instalador do sistema.
CREATE USER IF NOT EXISTS 'radius'@'localhost' IDENTIFIED BY '$RAD_SENHA';
ALTER USER 'radius'@'localhost' IDENTIFIED BY '$RAD_SENHA';
FLUSH PRIVILEGES;
SQL
echo "    banco $DB_NOME e usuarios criados"

# ---- 4) tabelas ---------------------------------------------------------------------------------
echo '==> 4/7 criando as tabelas do sistema...'
# O próprio instalador do WellSystem cria tudo; aqui só entregamos as credenciais.
mkdir -p "$DESTINO/cache"
cat > "$DESTINO/cache/wellsystem_db.json" <<JSON
{
    "host": "127.0.0.1",
    "porta": 3306,
    "user": "$DB_USER",
    "pass": "$DB_SENHA",
    "dbname": "$DB_NOME",
    "radius_db": "$DB_RADIUS"
}
JSON
chown www-data:www-data "$DESTINO/cache/wellsystem_db.json"
chmod 640 "$DESTINO/cache/wellsystem_db.json"
# ESPELHO QUE SOBREVIVE AO REBOOT. O Apache do Debian roda com PrivateTmp: o /var/tmp que o PHP
# enxerga e apagado a cada restart do servico, e o espelho antigo ia junto. /var/lib nao sofre
# isso. O PHP nao consegue criar pasta aqui (e do root), por isso ela nasce na instalacao, ja
# com dono www-data — dai em diante o proprio sistema mantem a copia atualizada.
mkdir -p /var/lib/wellsystem
chown www-data:www-data /var/lib/wellsystem
chmod 750 /var/lib/wellsystem
# E a copia ja nasce feita — nao depende de o sistema ser aberto no navegador antes do 1o reboot.
command -v ws_amb_espelhar_config_banco >/dev/null 2>&1 && ws_amb_espelhar_config_banco "$DESTINO" "www-data:www-data"
# Roda como www-data (os arquivos que o PHP grava ficam com o dono certo). O Debian minimo NAO traz
# sudo — antes era "sudo -u" e, sem ele, as tabelas simplesmente nao eram criadas. runuser vem no
# util-linux (sempre presente); como ultimo recurso roda como root e devolve o dono depois.
if command -v runuser >/dev/null 2>&1; then runuser -u www-data -- php "$DESTINO/install_cli.php"
elif command -v sudo >/dev/null 2>&1; then sudo -u www-data php "$DESTINO/install_cli.php"
else (cd "$DESTINO" && php install_cli.php)
fi || echo "    AVISO: as tabelas nao foram criadas agora — o navegador cria sozinho no primeiro acesso"
chown -R www-data:www-data "$DESTINO/cache" 2>/dev/null || true

# Permissões do RADIUS — só agora, com as tabelas já criadas.
# São por TABELA de propósito: o RADIUS lê o que decide a autenticação e escreve apenas nas duas
# tabelas de registro. Dar a ele o usuário do sistema seria entregar escrita em clientes e faturas
# a um serviço exposto à rede — e serviço exposto é o primeiro lugar por onde se entra.
echo '    liberando o usuario radius nas tabelas...'
$MYSQL_ADM <<SQL 2>/dev/null || echo "    AVISO: falha ao liberar o radius — rode o INSTALAR.sh de novo apos o sistema criar as tabelas"
GRANT SELECT ON \`$DB_RADIUS\`.radcheck      TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_RADIUS\`.radreply      TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_RADIUS\`.radgroupcheck TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_RADIUS\`.radgroupreply TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_RADIUS\`.radusergroup  TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_RADIUS\`.nas           TO 'radius'@'localhost';
-- nasreload: a checagem de Simultaneous-Use do FreeRADIUS consulta esta tabela; sem ela (ou sem permissão) o login de quem tem limite de sessões falha (21/10/2026). COLLATE explícito: sem ele o MariaDB novo usa uca1400 e a consulta do FreeRADIUS dá "Illegal mix of collations" (23/10/2026).
CREATE TABLE IF NOT EXISTS \`$DB_RADIUS\`.nasreload (nasipaddress VARCHAR(15) NOT NULL, reloadtime DATETIME NOT NULL, PRIMARY KEY (nasipaddress)) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
GRANT SELECT ON \`$DB_RADIUS\`.nasreload TO 'radius'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON \`$DB_RADIUS\`.radacct TO 'radius'@'localhost';
-- radpostauth NÃO recebe permissão porque NÃO é usada: o postauth_query fica desligado no módulo
-- sql. Ela gravava uma linha a cada autenticação E a cada falha — centenas de milhares de linhas
-- por mês que ninguém lê, inchando banco e backup e deixando o caminho crítico da autenticação
-- mais lento. O histórico que tem valor (quem conectou, quando, de onde, quanto trafegou) está
-- em radacct.
-- Estas duas NÃO são do RADIUS, e mesmo assim ele precisa lê-las: a consulta que devolve o
-- SRouter-IPoE-Alias (nome do cliente na sessão IPoE) roda COMO o usuário radius, e busca o nome
-- em ws_cliente passando por ws_contrato. Sem elas a consulta volta vazia e o atributo não é
-- enviado — a autenticação funciona, mas a sessão aparece no concentrador com o identificador
-- hexadecimal em vez do nome, que é justamente o que o suporte usa para saber de quem é.
-- Só SELECT, e só nestas duas: o RADIUS continua sem poder escrever no cadastro.
GRANT SELECT ON \`$DB_NOME\`.ws_cliente  TO 'radius'@'localhost';
GRANT SELECT ON \`$DB_NOME\`.ws_contrato TO 'radius'@'localhost';
FLUSH PRIVILEGES;
SQL

# ---- 5) Apache ----------------------------------------------------------------------------------
echo '==> 5/7 configurando o Apache...'
cat > /etc/apache2/sites-available/wellsystem.conf <<APACHE
<VirtualHost *:80>
    DocumentRoot $DESTINO
    <Directory $DESTINO>
        AllowOverride All
        Require all granted
    </Directory>
    # uploads/ guarda arquivo enviado por usuário: PHP ali dentro NUNCA deve executar.
    <Directory $DESTINO/uploads>
        php_admin_flag engine off
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/wellsystem-error.log
    CustomLog \${APACHE_LOG_DIR}/wellsystem-access.log combined
</VirtualHost>
APACHE
a2dissite 000-default >/dev/null 2>&1 || true
a2ensite wellsystem >/dev/null
# Cache e compressão dos estáticos — na configuração do Apache, e não num .htaccess (ver o script).
[ -f "$DESTINO/ws-apache-desempenho.sh" ] && bash "$DESTINO/ws-apache-desempenho.sh" "$DESTINO"

# ---- phpMyAdmin (opcional) ----------------------------------------------------------------------
# Instalado sob demanda: WS_PHPMYADMIN=1 ./INSTALAR.sh
#
# Fica DESLIGADO por padrão de propósito. Um phpMyAdmin acessível é a porta da frente do banco
# inteiro, com usuário e senha como única barreira, e é varrido por robôs o dia todo. Quem precisa
# dele precisa de verdade; quem não precisa não deve tê-lo no ar sem saber.
if [ "${WS_PHPMYADMIN:-0}" = "1" ]; then
    echo '    instalando phpMyAdmin...'
    apt-get install -y -qq phpmyadmin >/dev/null 2>&1 || apt-get install -y -qq phpmyadmin
    # O pacote publica em /phpmyadmin do site padrão; aqui ele é ligado ao site do WellSystem.
    if [ -f /etc/phpmyadmin/apache.conf ]; then
        ln -sf /etc/phpmyadmin/apache.conf /etc/apache2/conf-available/phpmyadmin.conf
        a2enconf phpmyadmin >/dev/null 2>&1 || true
    fi
    echo "    phpMyAdmin em http://$(hostname -I | awk '{print $1}')/phpmyadmin"
    echo "    entre com o usuario $DB_USER e a senha de $ARQ_SENHAS"
fi

# restart (não reload): o PHP e as extensões (inclusive snmp) foram instalados nesta execução; reload deixa o módulo antigo na memória.
systemctl restart apache2
echo "    site publicado em http://$(hostname -I | awk '{print $1}')/"

# ---- HTTPS pela tela do sistema -----------------------------------------------------------------
# O certificado passa a ser pedido pelo painel (Manutenção → Domínio & HTTPS), sem terminal. Para
# isso o www-data precisa executar UM comando como root — e apenas ele.
#
# O script fica FORA da pasta web de propósito: dentro dela, qualquer falha que permitisse escrita
# em arquivo do sistema viraria execução como root. Em /usr/local/sbin, só o root altera.
# A regra do sudoers autoriza o caminho exato, sem curinga: o www-data não ganha "sudo", ganha
# permissão de rodar este script — que por sua vez valida os domínios antes de chamar o certbot.
install -m 750 -o root -g www-data "$RAIZ/ws-certificado.sh"     /usr/local/sbin/ws-certificado.sh     2>/dev/null || true
install -m 755 -o root -g root "$RAIZ/ws-apt-fonte.sh" /usr/local/sbin/ws-apt-fonte.sh 2>/dev/null && bash /usr/local/sbin/ws-apt-fonte.sh || true   # fonte online do Debian (certbot, Docker, atualizações)
install -m 750 -o root -g www-data "$RAIZ/ws-radius-fallback.sh" /usr/local/sbin/ws-radius-fallback.sh 2>/dev/null || true
if [ -f /usr/local/sbin/ws-certificado.sh ]; then
    {
      echo 'www-data ALL=(root) NOPASSWD: /usr/local/sbin/ws-certificado.sh'
      echo 'www-data ALL=(root) NOPASSWD: /usr/local/sbin/ws-radius-fallback.sh'
    } > /etc/sudoers.d/wellsystem-certificado
    chmod 440 /etc/sudoers.d/wellsystem-certificado
    # visudo -c recusa arquivo malformado: melhor descobrir agora do que quebrar o sudo do servidor.
    if visudo -c >/dev/null 2>&1; then
        echo '    HTTPS pelo painel habilitado (Manutencao -> Dominio & HTTPS)'
    else
        rm -f /etc/sudoers.d/wellsystem-certificado
        echo '    AVISO: regra de sudo recusada — o HTTPS tera de ser emitido pelo terminal'
    fi
fi
apt-get install -y -qq certbot python3-certbot-apache >/dev/null 2>&1 || true

# ---- 6) FreeRADIUS ------------------------------------------------------------------------------
echo '==> 6/7 configurando o FreeRADIUS...'
if   [ -d /etc/freeradius/3.0 ]; then FR=/etc/freeradius/3.0
elif [ -d /etc/freeradius ];     then FR=/etc/freeradius
else echo "ERRO: pasta de configuracao do FreeRADIUS nao encontrada" >&2; exit 1; fi

cat > "$FR/mods-available/sql" <<CONF
# Gerado pelo INSTALAR.sh do WellSystem.
sql {
    dialect = "mysql"
    driver  = "rlm_sql_\${dialect}"

    server   = "localhost"
    port     = 3306
    login    = "radius"
    password = "$RAD_SENHA"
    # BANCO PRÓPRIO DO RADIUS — não é o banco do ERP. O WellSystem escreve aqui pelas visões que
    # mantém no banco dele; o FreeRADIUS lê as tabelas reais, direto, sem passar por visão.
    radius_db = "$DB_RADIUS"

    # Obrigatório: o queries.conf referencia \${group_attribute} nas consultas de grupo.
    group_attribute = "SQL-Group"

    # Concentradores vêm da tabela 'nas' do WellSystem — cadastrar na tela passa a valer.
    read_clients = yes
    client_table = "nas"

    acct_table1 = "radacct"
    acct_table2 = "radacct"
    # ESTA LINHA PRECISA EXISTIR, mesmo com a gravação em radpostauth desligada.
    # O queries.conf é incluído no fim deste bloco e referencia \${..postauth_table} na consulta de
    # post-auth. Sem a variável definida, o FreeRADIUS nem faz o parse do arquivo — recusa a
    # configuração inteira com "Reference \${..postauth_table} not found" e não sobe. Ou seja:
    # tirar a variável não desliga nada, só quebra a leitura do arquivo.
    # Quem desliga de verdade é o SITE, mais abaixo neste script, onde o modulo sql e retirado da secao
    # post-auth. A consulta continua definida e simplesmente nunca é chamada — por isso a tabela
    # radpostauth também não precisa existir.
    postauth_table = "radpostauth"
    authcheck_table = "radcheck"
    authreply_table = "radreply"
    groupcheck_table = "radgroupcheck"
    groupreply_table = "radgroupreply"
    usergroup_table = "radusergroup"

    # Limpa sessão presa (concentrador que reiniciou sem enviar o "stop"). Sem isto, a trava de
    # sessão simultânea passaria a recusar o cliente LEGÍTIMO por "já está conectado".
    delete_stale_sessions = yes

    # (A gravação em radpostauth é desligada no SITE, logo abaixo neste script — não aqui. Definir
    #  postauth_query vazio neste bloco não funcionaria: o \$INCLUDE do queries.conf vem depois e
    #  redefiniria a consulta.)

    pool {
        start = 3
        min   = 2
        max   = 10
        spare = 3
        lifetime = 0
        idle_timeout = 60
    }
    \$INCLUDE \${modconfdir}/\${.:name}/main/\${dialect}/queries.conf
}
CONF
ln -sf "$FR/mods-available/sql" "$FR/mods-enabled/sql"
chown freerad:freerad "$FR/mods-available/sql" 2>/dev/null || true
chmod 640 "$FR/mods-available/sql"

# Liga o sql nos sites — vem comentado de fábrica, e é o passo que mais trava instalação manual:
# sem ele o FreeRADIUS sobe, não reclama de nada, e recusa todo mundo porque nunca consulta o banco.
for s in "$FR/sites-enabled/default" "$FR/sites-enabled/inner-tunnel"; do
    [ -f "$s" ] || continue
    sed -i 's/^\([[:space:]]*\)-sql[[:space:]]*$/\1sql/; s/^\([[:space:]]*\)#[[:space:]]*sql[[:space:]]*$/\1sql/' "$s"

    # RADPOSTAUTH DESLIGADO — o sql sai da seção post-auth (e só dela).
    #
    # A tabela radpostauth grava uma linha a cada autenticação E a cada falha. Num provedor de mil
    # clientes que reconectam ao longo do dia são centenas de milhares de linhas por mês que ninguém
    # lê: incha o banco, incha o backup e põe uma escrita a mais no caminho crítico da autenticação.
    # O histórico que tem valor — quem conectou, quando, de onde, quanto trafegou — fica em radacct,
    # que é o registro de sessão de verdade.
    #
    # O corte é feito AQUI, no site, e não no módulo: zerar postauth_query dentro do bloco sql não
    # funcionaria, porque o \$INCLUDE do queries.conf vem depois e redefine a consulta.
    #
    # O awk conta as chaves para agir somente DENTRO de post-auth — inclusive no Post-Auth-Type
    # REJECT aninhado, que grava a mesma tabela. Fora dessa seção o sql continua ligado: é ele que
    # autentica (authorize) e registra a sessão (accounting), e desligar ali derrubaria o parque.
    awk '
        BEGIN { dentro = 0; nivel = 0 }
        {
            if (!dentro && $0 ~ /^[[:space:]]*post-auth[[:space:]]*\{/) { dentro = 1; nivel = 0 }
            if (dentro) {
                n = gsub(/\{/, "{"); nivel += n
                m = gsub(/\}/, "}"); nivel -= m
                if ($0 ~ /^[[:space:]]*sql[[:space:]]*$/) { sub(/sql/, "# sql  (WellSystem: radpostauth desligado de proposito)") }
                print
                if (nivel <= 0) dentro = 0
                next
            }
            print
        }
    ' "$s" > /tmp/ws-site-pa && mv /tmp/ws-site-pa "$s"
    chown freerad:freerad "$s" 2>/dev/null || true
done

# Nome resumido do cliente na sessão IPoE (SRouter-IPoE-Alias): dicionário do SRouter + regra no
# post-auth. Tudo no ws-radius-alias.sh — o mesmo que o ATUALIZAR.sh usa, para instalação nova e
# servidor antigo ficarem com a MESMA regra. Aqui não reinicia: o teste e o restart vêm logo abaixo.
if [ -f "$RAIZ/ws-radius-alias.sh" ]; then
    bash "$RAIZ/ws-radius-alias.sh" --pasta "$RAIZ" --banco "$DB_NOME" --sem-reiniciar \
        || echo '    AVISO: nome IPoE nao aplicado (o RADIUS segue funcionando; veja a mensagem acima)' >&2
fi
# Sessão presa do MESMO equipamento (MAC): reconexão não pode ser recusada por causa de uma sessão
# que ficou aberta sem Accounting-Stop. Mesma proteção da regra acima (cópia, -CX e volta sozinho).
if [ -f "$RAIZ/ws-radius-sessao-mac.sh" ]; then
    bash "$RAIZ/ws-radius-sessao-mac.sh" --sem-reiniciar \
        || echo '    AVISO: regra da sessao presa nao aplicada (o RADIUS segue funcionando)' >&2
fi
# Log de autenticação sempre ligado (auth = yes; senhas NÃO vão para o log). Mesma proteção acima.
if [ -f "$RAIZ/ws-radius-log.sh" ]; then
    bash "$RAIZ/ws-radius-log.sh" --sem-reiniciar \
        || echo '    AVISO: log de autenticacao nao ligado (o RADIUS segue funcionando)' >&2
fi

if freeradius -CX >/tmp/fr-check.log 2>&1; then
    # "mask" é o desligamento definitivo do systemd — nem o próprio serviço consegue subir depois.
    # Ele aparece quando alguém precisou tirar o FreeRADIUS do caminho (numa migração de container,
    # por exemplo) e, meses depois, ninguém lembra. O erro é "Unit is masked", que não diz o que
    # fazer. Desfazer aqui é inofensivo quando não há máscara e resolve quando há.
    systemctl unmask freeradius >/dev/null 2>&1 || true
    systemctl enable freeradius >/dev/null 2>&1 || true
    systemctl restart freeradius
    echo "    FreeRADIUS no ar"
else
    echo ''
    echo 'ERRO na configuracao do FreeRADIUS:' >&2
    tail -20 /tmp/fr-check.log >&2
    echo 'O resto da instalacao seguiu; corrija e rode: systemctl restart freeradius' >&2
fi

# ---- 7) tarefas automáticas ---------------------------------------------------------------------
echo '==> 7/7 instalando as tarefas automáticas...'
cat > /etc/cron.d/wellsystem <<CRON
*/2 * * * * www-data php $DESTINO/radius_sync.php >/dev/null 2>&1
* * * * * www-data php $DESTINO/lytex_run.php >/dev/null 2>&1
* * * * * www-data php $DESTINO/emitir_pendentes_run.php 3 0 >/dev/null 2>&1
* * * * * www-data php $DESTINO/emitir_pendentes_run.php 3 1 >/dev/null 2>&1
* * * * * www-data php $DESTINO/emitir_pendentes_run.php 3 2 >/dev/null 2>&1
* * * * * www-data php $DESTINO/bb_pix_run.php >/dev/null 2>&1
* * * * * www-data php $DESTINO/saude_run.php >/dev/null 2>&1
* * * * * root php $DESTINO/atualizar_run.php >/dev/null 2>&1
*/10 * * * * www-data php $DESTINO/zonas_sync.php >/dev/null 2>&1
0 9   * * * www-data php $DESTINO/cobranca_run.php >/dev/null 2>&1
30 6  * * * www-data php $DESTINO/faturar_run.php >/dev/null 2>&1
0 3   * * * www-data php $DESTINO/backup_run.php >/dev/null 2>&1
30 4  * * 0 www-data php $DESTINO/backup_teste_run.php >/dev/null 2>&1
# MONITOR DA OLT — a rotina que mantém a página da OLT viva.
# É ele quem varre a OLT, atualiza a lista de ONUs (de onde saem as ZONAS), coleta o sinal
# óptico por SNMP, detecta PON e placa caídas, dispara os alertas e faz o backup diário da
# OLT. Roda de minuto em minuto de propósito: o alerta rápido de queda é por SNMP (barato),
# e as operações por Telnet são escalonadas dentro do próprio script, no máximo uma por
# ciclo, para não esgotar as poucas sessões VTY da OLT.
# Precisa ser root: ele chama o PHP como www-data via su.
* * * * * root $DESTINO/olt_monitor.sh scan >/dev/null 2>&1
1 0 1 * * root $DESTINO/olt_monitor.sh relatorio >/dev/null 2>&1
CRON
chmod 644 /etc/cron.d/wellsystem
# Todo script executável e sem \r do Windows — o unzip não preserva o bit de execução, e o
# resultado é "Permission denied" num script que está ali, com dono certo. Ver ATUALIZAR.sh.
for s in "$RAIZ"/*.sh "$DESTINO"/*.sh; do
    [ -f "$s" ] || continue
    sed -i 's/\r$//' "$s" 2>/dev/null || true
    chmod +x "$s" 2>/dev/null || true
done
systemctl enable --now cron >/dev/null 2>&1 || service cron start >/dev/null 2>&1 || true

# ---- 8) menu de configuracao no terminal --------------------------------------------------------
# O menu que abre ao entrar por SSH como root (disco, senha do painel, chave ssh, update,
# downgrade, reparo, IP, restauracao de backup, reiniciar). Existe para o momento em que a tela
# web e justamente o que nao abre.
echo '==> instalando o menu de terminal (comando: wellsystem)...'
ws_amb_menu_instalar "$DESTINO"
# Menu do servidor no navegador (Provedor → Menu do servidor): ttyd + Apache, com teste e reversão.
[ -f "$DESTINO/ws-terminal-web.sh" ] && bash "$DESTINO/ws-terminal-web.sh" "$DESTINO"

# ---- central do assinante: a CENTRAL CLASSICA (central_files/padrao) ja vem ATIVA como padrao do sistema (usa o nome do provedor); o provedor troca/envia outra em Central (ZIP) ------------
CENTRAL_PADRAO=padrao
if [ -f "$DESTINO/central_files/$CENTRAL_PADRAO/index.html" ] && command -v php >/dev/null 2>&1; then
    mkdir -p "$DESTINO/cache"
    php -r '$f=$argv[1]; $j=is_file($f)?json_decode((string)file_get_contents($f),true):[]; if(!is_array($j)) $j=[]; if(!array_key_exists("folder",$j)){ $j["folder"]=$argv[2]; $j["index"]="index.html"; $j["host"]=$j["host"]??""; $j["hosts"]=$j["hosts"]??[]; file_put_contents($f,json_encode($j,JSON_PRETTY_PRINT)); }' "$DESTINO/cache/central.json" "$CENTRAL_PADRAO"
    chown www-data:www-data "$DESTINO/cache/central.json" 2>/dev/null || true
fi

# ---- 9) ponte de WhatsApp (Evolution API) junto com o sistema --------------------------------------
# Para o provedor que nao tem Evolution: o QR code aparece na tela Atendimento. So configura se ainda nao ha Evolution
# apontada no sistema; falha aqui NAO derruba a instalacao. Para pular: WS_SEM_EVOLUTION=1 bash INSTALAR.sh
if [ "${WS_SEM_EVOLUTION:-0}" != "1" ] && [ -f "$RAIZ/ws-evolution.sh" ]; then
    WS_DESTINO="$DESTINO" bash "$RAIZ/ws-evolution.sh" || true
fi

IP="$(hostname -I | awk '{print $1}')"
SEG="$(grep -A6 'client localhost' "$FR/clients.conf" 2>/dev/null | grep -m1 -E '^[[:space:]]*secret' | sed 's/.*=[[:space:]]*//' | tr -d '" ')"
[ -n "$SEG" ] || SEG="testing123"

echo ''
echo '================================================='
echo ' PRONTO'
echo '================================================='
echo ''
echo "Sistema:   http://$IP/"
echo "Banco:     $DB_NOME · usuario $DB_USER · senha em $ARQ_SENHAS"
echo ''
echo 'Testar a autenticacao (troque por um login real):'
echo "    radtest LOGIN SENHA 127.0.0.1 0 $SEG"
echo ''
echo 'Sincronizar o RADIUS agora:'
echo "    sudo -u www-data php $DESTINO/radius_sync.php"
echo ''
echo 'Nos concentradores: servidor RADIUS'" $IP"', portas 1812 e 1813,'
echo 'com o secret cadastrado em Rede -> NAS (FreeRADIUS).'
echo ''
