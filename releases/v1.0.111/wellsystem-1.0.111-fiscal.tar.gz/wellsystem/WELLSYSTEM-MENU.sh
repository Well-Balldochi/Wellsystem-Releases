#!/bin/bash
# =================================================================================================
# WellSystem — MENU DE CONFIGURAÇÃO do servidor (terminal)
# =================================================================================================
# É o menu que aparece ao entrar por SSH como root: mesma ideia do menu do MK-Auth, com as tarefas
# que precisam do servidor na mão — disco, senha do painel, chave SSH, atualização, reparo, IP,
# restauração de backup e reinício.
#
# POR QUE ELE EXISTE: as telas web resolvem o dia a dia, mas existem momentos em que justamente a
# web é o que não abre — IP trocado errado, banco fora, senha do admin perdida, disco cheio. Nesses
# momentos o operador só tem o terminal, e digitar comando por comando é onde se erra. O menu
# oferece as mesmas operações em uma lista, com confirmação e backup antes do que é irreversível.
#
# O PROMPT SÓ APARECE DEPOIS: quem entra cai no menu, e o shell só é liberado ao escolher "Sair
# para o terminal". É deliberado — a linha de comando solta é o caminho mais curto para um engano
# em servidor de produção.
#
# SENHA: por padrão o menu abre DIRETO. Quem chega aqui já entrou no SSH como root, com a senha do
# root — pedir a mesma senha de novo não protegia nada e só atrapalhava (pedido do usuário em
# 2026-09-16). A senha volta a ser pedida SÓ se alguém definir uma senha própria do menu
# (wellsystem --definir-senha → /etc/wellsystem/menu.hash): útil quando o console fica exposto.
#
# INSTALAÇÃO (o INSTALAR.sh já faz isso):
#     cp WELLSYSTEM-MENU.sh /usr/local/sbin/wellsystem
#     chmod 750 /usr/local/sbin/wellsystem
#     # e, no /root/.bashrc, a chamada que abre o menu no login interativo
#
# Uso avulso:  wellsystem            → abre o menu
#              wellsystem --selftest → confere a própria lógica, sem tocar no servidor
# =================================================================================================

# A biblioteca de detecção (ws-ambiente.sh) é instalada ao lado do menu pelo INSTALAR.sh e pelo
# ATUALIZAR.sh. Com ela, o menu descobre sozinho ONDE o sistema está e com qual usuário os arquivos
# ficam — em vez de presumir /var/www/wellsystem e www-data.
for WS_LIB in /usr/local/lib/wellsystem/ws-ambiente.sh "$(dirname "$0")/ws-ambiente.sh"; do
    [ -f "$WS_LIB" ] && { . "$WS_LIB"; break; }
done
if [ -z "${WS_DIR:-}" ]; then
    if command -v ws_amb_instalacoes >/dev/null 2>&1; then
        WS_DIR="$(ws_amb_instalacoes | head -1)"
    fi
    WS_DIR="${WS_DIR:-/var/www/wellsystem}"
fi
# Dono dos arquivos: o que a instalação já usa (a biblioteca preserva o de hoje).
if command -v ws_amb_dono >/dev/null 2>&1 && [ -d "$WS_DIR" ]; then WS_DONO="$(ws_amb_dono "$WS_DIR")"; fi
WS_DONO="${WS_DONO:-www-data:www-data}"
WS_MENU_HASH="${WS_MENU_HASH:-/etc/wellsystem/menu.hash}"
WS_VERSOES="${WS_VERSOES:-/var/backups/wellsystem-versoes}"
WS_TITULO="CONFIGURACAO WELLSYSTEM"

# ------------------------------------------------------------------------------------------------
# Caixas de diálogo. whiptail é o padrão do Debian/Ubuntu; dialog é o equivalente quando existe.
# Sem nenhum dos dois, o menu ainda funciona em modo texto simples — servidor recém-instalado não
# pode ficar sem acesso às ferramentas por causa de um pacote de interface.
# ------------------------------------------------------------------------------------------------
ws_ui() {
    if command -v whiptail >/dev/null 2>&1; then echo whiptail
    elif command -v dialog >/dev/null 2>&1; then echo dialog
    else echo texto; fi
}
UI="$(ws_ui)"
# Botões em português em TODAS as caixas (whiptail usa --*-button; dialog, --*-label).
if [ "$UI" = "dialog" ]; then
    WS_B_OK=(--ok-label Aceitar --cancel-label Cancelar); WS_B_SN=(--yes-label Sim --no-label Não)
else
    WS_B_OK=(--ok-button Aceitar --cancel-button Cancelar); WS_B_SN=(--yes-button Sim --no-button Não)
fi

# CAIXAS QUE CABEM NO TERMINAL DE QUEM ESTÁ ACESSANDO.
# whiptail com tamanho fixo some com o conteúdo (ou nem abre) em janela estreita — e o console do
# servidor, o celular com app de SSH e a janela do PuTTY reduzida são exatamente onde este menu é
# usado. Cada caixa pede o tamanho que gostaria e recebe o que couber: nunca mais que a tela, nunca
# menos que o mínimo em que o texto ainda se lê.
ws_dim() {  # $1=altura desejada  $2=largura desejada → "altura largura"
    local l c ah aw
    l=$(tput lines 2>/dev/null || echo 24); c=$(tput cols 2>/dev/null || echo 80)
    [ "$l" -ge 10 ] 2>/dev/null || l=24
    [ "$c" -ge 40 ] 2>/dev/null || c=80
    ah=$1; aw=$2
    [ "$ah" -gt $((l - 2)) ] && ah=$((l - 2)); [ "$ah" -lt 8 ]  && ah=8
    [ "$aw" -gt $((c - 4)) ] && aw=$((c - 4)); [ "$aw" -lt 40 ] && aw=40
    echo "$ah $aw"
}
ws_msg() {   # $1=texto
    case "$UI" in
        texto) printf '\n%s\n\n' "$1"; printf 'Enter para continuar... '; read -r _ ;;
        *) "$UI" --title "$WS_TITULO" --msgbox "$1" $(ws_dim 20 76) ;;
    esac
}
# RESULTADO DE UMA AÇÃO, COM O <Ok> JÁ MARCADO.
# Antes era uma caixa com rolagem (--textbox --scrolltext): o foco começava no TEXTO e era preciso
# apertar Tab para chegar ao Ok. Agora é uma caixa simples, sem rolagem, com o botão focado — terminou,
# Enter fecha. O que não cabe na tela não se perde: mostra as últimas linhas (onde fica o resultado,
# ex.: "PRONTO") e grava o relatório inteiro em /var/log/wellsystem/, com o caminho na própria caixa.
WS_MENU_LOGS="${WS_MENU_LOGS:-/var/log/wellsystem}"
ws_texto_arquivo() {  # $1=arquivo
    if [ "$UI" = "texto" ]; then cat "$1"; printf '\nEnter para continuar... '; read -r _; return; fi
    local dim alt larg cabe total txt log
    dim=$(ws_dim 22 88); alt=${dim% *}; larg=${dim#* }
    cabe=$((alt - 7)); [ "$cabe" -lt 4 ] && cabe=4
    total=$(wc -l < "$1" | tr -d ' ')
    if [ "$total" -le "$cabe" ]; then
        txt="$(cut -c1-$((larg - 4)) "$1")"
    else
        mkdir -p "$WS_MENU_LOGS" 2>/dev/null
        log="$WS_MENU_LOGS/menu-$(date +%Y%m%d-%H%M%S).log"
        cp "$1" "$log" 2>/dev/null || log='(nao foi possivel gravar o relatorio)'
        txt="[... $((total - cabe + 3)) linhas acima — relatorio completo: $log]
$(tail -n $((cabe - 3)) "$1" | cut -c1-$((larg - 4)))"
    fi
    "$UI" --title "$WS_TITULO" --msgbox "$txt" "$alt" "$larg"
}
ws_confirma() {  # $1=pergunta → 0 = sim
    case "$UI" in
        texto) printf '\n%s [s/N] ' "$1"; read -r r; [ "$r" = "s" ] || [ "$r" = "S" ] ;;
        *) "$UI" --title "$WS_TITULO" "${WS_B_SN[@]}" --yesno "$1" $(ws_dim 14 76) ;;
    esac
}
ws_pergunta() {  # $1=rótulo $2=valor inicial → responde no stdout
    case "$UI" in
        texto) printf '%s [%s]: ' "$1" "$2" >&2; read -r r; [ -n "$r" ] && echo "$r" || echo "$2" ;;
        *) "$UI" --title "$WS_TITULO" "${WS_B_OK[@]}" --inputbox "$1" $(ws_dim 10 70) "$2" 3>&1 1>&2 2>&3 ;;
    esac
}
ws_senha() {  # $1=rótulo → responde no stdout
    case "$UI" in
        texto) printf '%s: ' "$1" >&2; stty -echo 2>/dev/null; read -r r; stty echo 2>/dev/null; echo >&2; echo "$r" ;;
        *) "$UI" --title "$WS_TITULO" "${WS_B_OK[@]}" --passwordbox "$1" $(ws_dim 10 70) 3>&1 1>&2 2>&3 ;;
    esac
}

# ------------------------------------------------------------------------------------------------
# SENHA — confere o que foi digitado contra um hash no formato do /etc/shadow ($6$…, $y$…).
#
# A conta é feita pela própria biblioteca do sistema (crypt), passando o HASH INTEIRO como
# referência: é dele que saem o algoritmo e o sal, então isto funciona igual em servidor com
# sha-512 e em servidor com yescrypt (Debian 12), sem o script precisar saber qual é qual.
#
# Três caminhos, porque nem todo servidor tem os três: python3 (quase sempre tem), mkpasswd
# (pacote whois) e openssl (só para os hashes que ele conhece). Se nenhum existir, o menu não
# inventa uma verificação fraca — ele diz que não consegue conferir e não abre.
# ------------------------------------------------------------------------------------------------
ws_crypt() {  # $1=senha  $2=hash de referência → hash calculado no stdout
    local senha="$1" ref="$2" out=''
    if command -v python3 >/dev/null 2>&1; then
        out=$(python3 -c 'import crypt,sys; print(crypt.crypt(sys.argv[1], sys.argv[2]))' "$senha" "$ref" 2>/dev/null)
        [ -n "$out" ] && { echo "$out"; return 0; }
    fi
    if command -v mkpasswd >/dev/null 2>&1; then
        local alg sal
        alg=$(echo "$ref" | cut -d'$' -f2); sal=$(echo "$ref" | cut -d'$' -f3)
        case "$alg" in
            6) out=$(mkpasswd -m sha-512 -S "$sal" "$senha" 2>/dev/null) ;;
            5) out=$(mkpasswd -m sha-256 -S "$sal" "$senha" 2>/dev/null) ;;
            y) out=$(mkpasswd -m yescrypt -S "$sal" "$senha" 2>/dev/null) ;;
        esac
        [ -n "$out" ] && { echo "$out"; return 0; }
    fi
    if command -v openssl >/dev/null 2>&1; then
        local alg sal
        alg=$(echo "$ref" | cut -d'$' -f2); sal=$(echo "$ref" | cut -d'$' -f3)
        [ "$alg" = "6" ] && out=$(openssl passwd -6 -salt "$sal" "$senha" 2>/dev/null)
        [ "$alg" = "1" ] && out=$(openssl passwd -1 -salt "$sal" "$senha" 2>/dev/null)
        [ -n "$out" ] && { echo "$out"; return 0; }
    fi
    return 1
}
ws_confere_senha() {  # $1=senha digitada  $2=hash de referência → 0 = confere
    local calc
    [ -n "$2" ] || return 1
    calc=$(ws_crypt "$1" "$2") || return 2      # 2 = não foi possível conferir
    [ "$calc" = "$2" ]
}
ws_hash_referencia() {   # o hash que vale neste servidor
    # No navegador vale SEMPRE a senha do root (pedido do usuário); a senha própria é só para o PuTTY.
    if [ "${WS_MODO_WEB:-0}" != 1 ] && [ -s "$WS_MENU_HASH" ]; then head -n1 "$WS_MENU_HASH"; return 0; fi
    awk -F: '$1=="root"{print $2}' /etc/shadow 2>/dev/null
}

ws_portao() {
    local ref senha tentativas=0
    ref="$(ws_hash_referencia)"
    if [ -z "$ref" ] || [ "${ref#\$}" = "$ref" ]; then
        ws_msg "Não consegui ler a senha de referência deste servidor (/etc/shadow ou $WS_MENU_HASH).\n\nO menu não abre sem conferir a senha. Rode como root, ou defina uma senha própria do menu com:\n\n    wellsystem --definir-senha"
        return 1
    fi
    while [ "$tentativas" -lt 3 ]; do
        if [ "${WS_MODO_WEB:-0}" = 1 ]; then senha="$(ws_senha 'Senha do ROOT do servidor para abrir o Menu WellSystem')" || return 1
        else senha="$(ws_senha 'Senha para abrir o menu do WellSystem')" || return 1; fi
        [ -z "$senha" ] && return 1                       # cancelou
        ws_confere_senha "$senha" "$ref"
        case "$?" in
            0) return 0 ;;
            2) ws_msg "Este servidor não tem python3, mkpasswd nem openssl — não há como conferir a senha com segurança, então o menu não abre.\n\nInstale um deles:  apt install whois"; return 1 ;;
        esac
        tentativas=$((tentativas + 1))
        [ "$tentativas" -lt 3 ] && ws_msg "Senha incorreta. Tentativa $tentativas de 3."
    done
    ws_msg 'Três tentativas incorretas. Saindo.'
    return 1
}

# ------------------------------------------------------------------------------------------------
# AÇÕES DO MENU
# ------------------------------------------------------------------------------------------------
ws_tmp() { mktemp /tmp/wellsystem-menu.XXXXXX; }

ws_trabalho_discos() {  # $1 = arquivo da segunda tela
    local d i=0
    ws_etapa 10 'Lendo o espaco dos discos...'
    echo '=== ESPAÇO EM DISCO ==='; echo
    df -h | grep -vE '^(tmpfs|udev|overlay)' || df -h
    echo; echo '=== O QUE O WELLSYSTEM OCUPA ==='; echo
    for d in "$WS_DIR" "$WS_DIR/uploads" "$WS_DIR/cache" "$WS_DIR/backups" "$WS_DIR/cache_trafego" /var/lib/mysql /var/log; do
        i=$((i + 1)); ws_etapa $((15 + i * 8)) "Medindo $d..."
        [ -d "$d" ] && printf '%-28s %s\n' "$d" "$(du -sh "$d" 2>/dev/null | cut -f1)"
    done
    ws_etapa 80 'Procurando as maiores pastas de /var...'
    { echo '=== MAIORES PASTAS DE /var ==='; echo; du -h --max-depth=2 /var 2>/dev/null | sort -rh | head -10; } > "$1" 2>&1
    ws_etapa 100 'Pronto.'
}
ws_acao_discos() {
    local t t2; t=$(ws_tmp); t2=$(ws_tmp)
    ws_com_progresso "$t" "" ws_trabalho_discos "$t2"
    ws_texto_arquivo "$t"
    # Segunda tela: cabe inteira no PuTTY padrão (24 linhas), então nada fica escondido.
    ws_texto_arquivo "$t2"; rm -f "$t" "$t2"
}

# PHP COMO DONO DOS ARQUIVOS. O menu roda como root; rodar o config.php do sistema como root criava
# arquivos em cache/ com dono root (configuração espelhada, marcas), que o site (www-data) depois não
# conseguia regravar. runuser vem no util-linux (sempre presente); sudo nem sempre existe.
ws_php_dono() {
    local u="${WS_DONO%%:*}"
    if [ -n "$u" ] && [ "$u" != "root" ] && id "$u" >/dev/null 2>&1; then
        if command -v runuser >/dev/null 2>&1; then runuser -u "$u" -- php "$@"; return $?; fi
        if command -v sudo >/dev/null 2>&1; then sudo -u "$u" php "$@"; return $?; fi
    fi
    php "$@"
}

# Resetar a senha do painel: ZERA o hash do admin. O WellSystem obriga a criar uma senha nova no
# primeiro acesso quando o hash está vazio — então isto devolve o acesso sem nunca inventar uma
# senha padrão, que é o que transforma "recuperar acesso" em porta dos fundos.
ws_trabalho_senha_painel() {
    ws_etapa 30 'Conectando ao banco do sistema...'
    ws_php_dono -r '
        require $argv[1] . "/config.php";
        try {
            $st = ws_db()->prepare("UPDATE ws_usuario SET senha_hash=? WHERE login=?");
            $st->execute(["", "admin"]);
            echo $st->rowCount() > 0 ? "Senha do admin resetada. Entre no painel com o usuario admin e defina a nova senha.\n"
                                     : "Nenhum usuario admin com senha encontrado — nada foi alterado.\n";
        } catch (Throwable $e) { echo "Falha: ", $e->getMessage(), "\n"; }
    ' "$WS_DIR"
    ws_etapa 100 'Pronto.'
}
ws_acao_senha_painel() {
    [ -f "$WS_DIR/config.php" ] || { ws_msg "Não achei o WellSystem em $WS_DIR."; return; }
    command -v php >/dev/null 2>&1 || { ws_msg 'PHP não encontrado neste servidor.'; return; }
    ws_confirma 'Resetar a senha do usuário "admin" do painel?\n\nO acesso passa a pedir a criação de uma senha nova no próximo login. Nenhuma senha padrão é criada.' || return
    local t; t=$(ws_tmp)
    ws_com_progresso "$t" "" ws_trabalho_senha_painel
    ws_texto_arquivo "$t"; rm -f "$t"
}

ws_trabalho_chave_ssh() {
    ws_etapa 15 'Removendo as chaves antigas...'
    rm -f /etc/ssh/ssh_host_*
    ws_etapa 40 'Gerando as chaves novas...'
    if ssh-keygen -A; then
        ws_etapa 75 'Reiniciando o SSH...'
        systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || service ssh restart
    else
        echo 'FALHA ao gerar as chaves — o SSH NAO foi reiniciado (a sessao atual continua valendo).'
    fi
    ws_etapa 95 'Lendo as impressoes digitais...'
    echo; echo 'Novas impressões digitais:'
    for k in /etc/ssh/ssh_host_*_key.pub; do [ -f "$k" ] && ssh-keygen -lf "$k"; done
    ws_etapa 100 'Pronto.'
}
ws_acao_chave_ssh() {
    ws_confirma 'Gerar novas chaves do servidor SSH?\n\nATENÇÃO: quem já acessou este servidor vai receber o aviso de "identificação do host mudou" e precisará aceitar a nova chave. A sessão atual NÃO cai.' || return
    local t; t=$(ws_tmp)
    ws_com_progresso "$t" "" ws_trabalho_chave_ssh
    ws_texto_arquivo "$t"; rm -f "$t"
}

# ------------------------------------------------------------------------------------------------
# PACOTES (update e downgrade) — ONDE COLOCAR O ARQUIVO
# ------------------------------------------------------------------------------------------------
# Pasta OFICIAL para largar um pacote pelo WinSCP: /var/www/atualizacao (criada sozinha). Vale para
# a versão NOVA (opção 4) e para uma versão ANTIGA que se queira subir (opção 5). Também são aceitos
# os lugares de costume — /var/www, /root, /tmp e /home/* — para quem já enviava para lá.
# Só entra na lista o ZIP que tem o ATUALIZAR.sh dentro: outro .zip qualquer não é oferecido.
WS_ATUALIZACAO="${WS_ATUALIZACAO:-/var/www/atualizacao}"
WS_LOCAIS_PACOTE="$WS_ATUALIZACAO, /var/www, /root, /tmp ou /home"

ws_pacotes() {   # lista os pacotes do WellSystem, mais novo primeiro
    mkdir -p "$WS_ATUALIZACAO" 2>/dev/null
    local z
    ls -1t "$WS_ATUALIZACAO"/*.zip /var/www/*.zip /root/*.zip /tmp/*.zip /home/*/*.zip 2>/dev/null \
        | awk '!visto[$0]++' | while IFS= read -r z; do
            unzip -l "$z" 2>/dev/null | grep -q 'ATUALIZAR\.sh$' && echo "$z"
        done
}
ws_zip_mais_recente() { ws_pacotes | head -1; }
ws_pacote_legivel() {   # $1=zip → "nome.zip  (23/09/2026 14:05, 12M)"
    printf '%s  (%s, %s)' "$(basename "$1")" "$(date -r "$1" '+%d/%m/%Y %H:%M' 2>/dev/null)" "$(du -h "$1" 2>/dev/null | cut -f1)"
}
# Escolhe um pacote: um só → ele mesmo; vários → lista para escolher. Caminho no stdout.
ws_escolhe_pacote() {   # $1 = pergunta
    local lista n z i=0 args=()
    lista="$(ws_pacotes)"
    [ -n "$lista" ] || return 1
    if [ "$(printf '%s\n' "$lista" | wc -l)" -eq 1 ]; then printf '%s\n' "$lista"; return 0; fi
    if [ "$UI" = "texto" ]; then
        while IFS= read -r z; do i=$((i+1)); printf '%2d) %s\n' "$i" "$(ws_pacote_legivel "$z")" >&2; done <<< "$lista"
        n=$(ws_pergunta "$1 (número)" '1')
    else
        while IFS= read -r z; do i=$((i+1)); args+=("$i" "$(ws_pacote_legivel "$z")"); done <<< "$lista"
        n=$("$UI" --title "$WS_TITULO" --menu "$1" $(ws_dim 20 78) 10 "${args[@]}" 3>&1 1>&2 2>&3) || return 1
    fi
    printf '%s\n' "$lista" | sed -n "${n}p"
}

# BARRA DE PROGRESSO. Roda o trabalho em segundo plano gravando o log e, enquanto ele não termina,
# mostra a barra (whiptail/dialog --gauge) com a etapa atual. $1 = log, $2 = função que traduz o log
# em "percentual|texto da etapa", $3 = PID do trabalho. Sem caixas de diálogo, mostra o log ao vivo.
ws_progresso() {
    local log="$1" fn="$2" pid="$3" linha pct txt
    if [ "$UI" = "texto" ]; then
        tail --pid="$pid" -n +1 -f "$log" 2>/dev/null | grep -av '^@@ '
        return
    fi
    {
        while kill -0 "$pid" 2>/dev/null; do
            linha="$("$fn" "$log")"; pct="${linha%%|*}"; txt="${linha#*|}"
            printf 'XXX\n%s\n%s\nXXX\n' "$pct" "$txt"
            sleep 1
        done
        printf 'XXX\n100\nConcluido.\nXXX\n'; sleep 1
    } | "$UI" --title "$WS_TITULO" --gauge 'Iniciando...' $(ws_dim 9 72) 0
}
# ETAPAS — o mesmo mecanismo para TODAS as opções que executam algo.
# Dentro do trabalho, "ws_etapa 40 texto" grava uma marca no log; a barra mostra a última marca.
# As marcas são apagadas do log antes de o resultado aparecer na tela.
ws_etapa() { printf '@@ %s %s\n' "$1" "$2"; }
ws_etapa_do_log() {  # $1=log → "percentual|texto"
    local l; l="$(grep -a '^@@ [0-9]' "$1" 2>/dev/null | tail -1)"
    if [ -n "$l" ]; then l="${l#@@ }"; echo "${l%% *}|${l#* }"; else echo '2|Iniciando...'; fi
}
# Roda um trabalho em segundo plano com a barra padrão. $1=log, $2=função de etapas ("" = marcas),
# $3...=comando. Devolve o código de saída do trabalho; o log fica sem as marcas.
ws_com_progresso() {
    local log="$1" fn="${2:-ws_etapa_do_log}" pid rc; shift 2
    ( "$@" ) > "$log" 2>&1 < /dev/null &
    pid=$!
    ws_progresso "$log" "$fn" "$pid"
    wait "$pid"; rc=$?
    sed -i '/^@@ [0-9]/d' "$log" 2>/dev/null
    return $rc
}
# Etapas da atualização → percentual (as linhas que o próprio ATUALIZAR.sh imprime).
ws_update_etapa() {
    local l="$1"
    if   grep -q '^PRONTO' "$l";                          then echo '100|Pronto.'
    elif grep -q '^==> recarregando' "$l";                then echo '92|Recarregando o servidor web...'
    elif grep -q '^==> servidor:' "$l";                   then echo '80|Tarefas agendadas, menu e Apache...'
    elif grep -q '^==> configuracao do banco' "$l";       then echo '65|Conferindo a configuracao do banco...'
    elif grep -q '^==> publicando o codigo' "$l";         then echo '45|Publicando o codigo novo...'
    else ws_etapa_do_log "$l"; fi
}

# Versão guardada = só o CÓDIGO. uploads/ e backups/ podem ter gigabytes e não são tocados pelo
# downgrade — copiar tudo a cada atualização enchia o disco (justamente num servidor que já está
# apertado). Ficam as 5 versões mais recentes.
ws_guardar_versao() {  # $1 = destino
    local item
    mkdir -p "$1" || return 1
    for item in "$WS_DIR"/* "$WS_DIR"/.[!.]*; do
        [ -e "$item" ] || continue
        case "$(basename "$item")" in cache|uploads|backups|cache_trafego|Mkfiles) continue ;; esac
        cp -a "$item" "$1/" 2>/dev/null
    done
    ls -1dt "$WS_VERSOES"/*/ 2>/dev/null | tail -n +6 | while IFS= read -r velha; do rm -rf "$velha"; done
}

# ATUALIZAR PELO MENU — sem digitar caminho nenhum: acha o ZIP enviado ao servidor, abre numa pasta
# temporária própria e roda o ATUALIZAR.sh que veio NELE (o do pacote novo).
ws_trabalho_update() {  # $1=zip  $2=destino da versão guardada  $3=pasta temporária
    ws_etapa 10 'Guardando a versao atual (para downgrade)...'
    echo "guardando a versao atual em $2"
    ws_guardar_versao "$2"
    echo
    ws_etapa 30 'Abrindo o pacote...'
    echo "abrindo o pacote em $3"
    local s=''
    # O ATUALIZAR.sh pode estar em wellsystem/ (ZIP do GERAR-ZIP) ou na raiz do ZIP: procura os dois.
    unzip -q -o "$1" -d "$3" && s="$(find "$3" -maxdepth 3 -name ATUALIZAR.sh -type f 2>/dev/null | head -1)"
    if [ -n "$s" ]; then
        # WS_DESTINO: o menu já sabe qual instalação está usando — o script não pergunta de novo.
        WS_DESTINO="$WS_DIR" bash "$s"
    else
        echo "O arquivo $1 não parece um pacote do WellSystem (ATUALIZAR.sh não encontrado dentro)."
    fi
}
# Instala um pacote (usado pelo update E pelo downgrade de ZIP): guarda a versão atual antes.
ws_instalar_pacote() {   # $1 = zip
    local t tmpdir; t=$(ws_tmp); tmpdir="$(mktemp -d /tmp/ws-pacote.XXXXXX)"
    ws_com_progresso "$t" ws_update_etapa ws_trabalho_update "$1" "$WS_VERSOES/$(date +%Y%m%d-%H%M%S)" "$tmpdir"
    rm -rf "$tmpdir"
    ws_texto_arquivo "$t"; rm -f "$t"
}
# UPDATE PELA INTERNET (01/11/2026): é o MESMO caminho do botão "Atualizar agora" do painel — pacote oficial ASSINADO do GitHub (Wellsystem-Releases);
# o sistema confere a assinatura, guarda cópia da versão atual e volta sozinho se falhar. O menu grava o pedido e roda a rotina do root na hora.
ws_atualizar_internet() {
    [ -f "$WS_DIR/atualizar_run.php" ] || { ws_msg "Não achei o WellSystem em $WS_DIR."; return; }
    command -v php >/dev/null 2>&1 || { ws_msg "PHP não encontrado neste servidor."; return; }
    local antes depois log t; antes="$(cat "$WS_DIR/VERSAO" 2>/dev/null)"
    ws_confirma "Baixar e instalar a versão mais nova do WellSystem pela internet?\n\nVersão instalada agora: ${antes:-?}\n\nO pacote é o oficial e assinado: o sistema confere a assinatura, guarda uma cópia da versão atual e volta sozinho se algo falhar. Seus dados não são apagados." || return
    printf '{"acao":"atualizar","em":%s,"por":"menu"}' "$(date +%s)" > "$WS_DIR/cache/atualizar_pedido.json"
    chown --reference="$WS_DIR/cache" "$WS_DIR/cache/atualizar_pedido.json" 2>/dev/null; chmod 664 "$WS_DIR/cache/atualizar_pedido.json" 2>/dev/null
    case "$UI" in texto) echo "Atualizando... aguarde." ;; *) "$UI" --title "$WS_TITULO" --infobox "Baixando e instalando a versão mais nova...\n\nAguarde (pode levar alguns minutos). Não desligue o servidor." 8 66 ;; esac
    t="$(mktemp)"; ( cd "$WS_DIR" && php atualizar_run.php >"$t" 2>&1 ); rm -f "$t"
    depois="$(cat "$WS_DIR/VERSAO" 2>/dev/null)"
    log="$(php -r 'foreach (array_slice((array)json_decode((string)@file_get_contents($argv[1]), true), 0, 6) as $l) echo $l, "\n";' "$WS_DIR/cache/atualizacao_log.json" 2>/dev/null)"
    ws_msg "Versão antes: ${antes:-?}\nVersão agora: ${depois:-?}\n\nÚltimos avisos do atualizador:\n${log:-(sem avisos)}"
}
ws_acao_update() {
    [ -d "$WS_DIR" ] || { ws_msg "Não achei o WellSystem em $WS_DIR."; return; }
    if [ "$UI" = texto ]; then ws_atualizar_internet; return; fi
    local c; c=$("$UI" --title "$WS_TITULO" --menu "Fazer update de onde?" $(ws_dim 14 76) 2 \
        1 "Baixar a versão mais nova pela internet (recomendado)" \
        2 "Usar um pacote .zip que eu coloquei no servidor" 3>&1 1>&2 2>&3) || return
    case "$c" in 1) ws_atualizar_internet ;; 2) ws_acao_update_pacote ;; esac
}
ws_acao_update_pacote() {
    [ -d "$WS_DIR" ] || { ws_msg "Não achei o WellSystem em $WS_DIR."; return; }
    local zip; zip="$(ws_escolhe_pacote 'Atualizar com qual pacote?')"
    if [ -z "$zip" ]; then
        ws_msg "Nenhum pacote do WellSystem encontrado.\n\nOnde colocar o arquivo (WinSCP ou scp):\n  $WS_ATUALIZACAO   ← pasta recomendada\n\nTambém procuro em: /var/www, /root, /tmp e /home.\nO arquivo deve ser o .zip gerado pelo GERAR-ZIP (o que tem o ATUALIZAR.sh dentro).\n\nDepois de enviar, escolha esta opção de novo."
        return
    fi
    ws_confirma "Atualizar o WellSystem instalado em:\n  $WS_DIR\n\ncom o pacote:\n  $(ws_pacote_legivel "$zip")\n  em $(dirname "$zip")\n\nA versão atual é guardada antes em $WS_VERSOES, para poder voltar pela opção 5 (downgrade)." || return
    ws_instalar_pacote "$zip"
}

# "20260916-181530" → "16/09/2026 18:15"
ws_versao_legivel() { local v="$1"; echo "${v:6:2}/${v:4:2}/${v:0:4} ${v:9:2}:${v:11:2}"; }

ws_trabalho_downgrade() {  # $1 = versão escolhida
    local item
    ws_etapa 15 'Removendo o codigo atual...'
    # Troca SÓ o código: apaga o que não é dado do servidor e copia a versão guardada.
    for item in "$WS_DIR"/* "$WS_DIR"/.[!.]*; do
        [ -e "$item" ] || continue
        case "$(basename "$item")" in cache|uploads|backups|cache_trafego|Mkfiles) continue ;; esac
        rm -rf "$item"
    done
    ws_etapa 50 'Copiando a versao guardada...'
    for item in "$WS_VERSOES/$1"/* "$WS_VERSOES/$1"/.[!.]*; do
        [ -e "$item" ] || continue
        case "$(basename "$item")" in cache|uploads|backups|cache_trafego|Mkfiles) continue ;; esac
        cp -a "$item" "$WS_DIR/"
    done
    ws_etapa 85 'Ajustando o dono dos arquivos...'
    chown -R "$WS_DONO" "$WS_DIR" 2>/dev/null
    echo "Sistema restaurado para a versao de $(ws_versao_legivel "$1")."
    ws_etapa 100 'Pronto.'
}
ws_acao_downgrade() {
    # DUAS FONTES, numa lista só:
    #   V<data> = versão GUARDADA automaticamente a cada update feito por este menu ($WS_VERSOES);
    #   P<n>    = PACOTE .zip que você colocar em $WS_ATUALIZACAO (ou /var/www, /root, /tmp, /home) —
    #             é assim que se sobe uma versão específica que não foi guardada aqui.
    local versoes pacotes escolha args=() v z i=0
    versoes=$(ls -1r "$WS_VERSOES" 2>/dev/null | grep -E '^[0-9]{8}-[0-9]{6}$' | head -10)
    pacotes="$(ws_pacotes)"
    if [ -z "$versoes" ] && [ -z "$pacotes" ]; then
        ws_msg "Nenhuma versão disponível para voltar.\n\nVersões guardadas (automático a cada update pelo menu):\n  $WS_VERSOES\n\nPara subir uma versão sua, coloque o .zip dela em:\n  $WS_ATUALIZACAO\n\ne escolha esta opção de novo."
        return
    fi
    while IFS= read -r v; do [ -n "$v" ] && args+=("V$v" "Versão guardada de $(ws_versao_legivel "$v")"); done <<< "$versoes"
    while IFS= read -r z; do [ -n "$z" ] && { i=$((i+1)); args+=("P$i" "Pacote: $(ws_pacote_legivel "$z")"); }; done <<< "$pacotes"
    if [ "$UI" = "texto" ]; then
        local k=0; while [ $k -lt ${#args[@]} ]; do printf '%-18s %s\n' "${args[$k]}" "${args[$((k+1))]}" >&2; k=$((k+2)); done
        escolha=$(ws_pergunta 'Qual (ex.: V20260916-181530 ou P1)' "${args[0]}")
    else
        escolha=$("$UI" --title "$WS_TITULO" --menu "Voltar para qual versão?\n\nGuardadas: $WS_VERSOES\nPacotes: $WS_ATUALIZACAO" $(ws_dim 22 78) 10 "${args[@]}" 3>&1 1>&2 2>&3) || return
    fi
    case "$escolha" in
        P[0-9]*)   # pacote .zip: instala como um update (guarda a versão atual antes)
            z="$(printf '%s\n' "$pacotes" | sed -n "${escolha#P}p")"
            [ -n "$z" ] && [ -f "$z" ] || { ws_msg 'Pacote inválido.'; return; }
            ws_confirma "Subir a versão do pacote:\n  $(ws_pacote_legivel "$z")\n\nA versão atual é guardada antes. Banco de dados, uploads, backups e configuração NÃO são tocados." || return
            ws_instalar_pacote "$z"
            return ;;
        V*) escolha="${escolha#V}" ;;
    esac
    [ -n "$escolha" ] && [ -d "$WS_VERSOES/$escolha" ] || { ws_msg 'Versão inválida.'; return; }
    [ -f "$WS_VERSOES/$escolha/config.php" ] || { ws_msg 'Essa versão guardada está incompleta (sem config.php). Nada foi alterado.'; return; }
    ws_confirma "Voltar o sistema para a versão de $(ws_versao_legivel "$escolha")?\n\nO código atual é substituído. Banco de dados, uploads, backups e configuração NÃO são tocados." || return
    local t; t=$(ws_tmp)
    ws_com_progresso "$t" "" ws_trabalho_downgrade "$escolha"
    ws_texto_arquivo "$t"; rm -f "$t"
}

# "Reparar" = repor o que o sistema espera encontrar: tabelas/colunas, pastas e permissões.
# REPARAR = a MESMA rotina da tela Manutenção ("Verificar tabelas" + "Ressincronizar RADIUS"): as
# duas chamam ws_reparar.php, então o terminal e o painel reparam exatamente igual. Antes daqui
# roda só o install_cli.php, para CRIAR o banco se ele nem existir (instalação quebrada).
ws_trabalho_reparar() {
    local d s
    ws_etapa 5 'Recriando as pastas de trabalho...'
    echo '=== pastas e permissões ==='
    for d in cache uploads uploads/mkfiles assets cache_trafego backups; do
        mkdir -p "$WS_DIR/$d" && echo "ok  $WS_DIR/$d"
    done
    ws_etapa 10 'Ajustando dono e permissoes...'
    chown -R "$WS_DONO" "$WS_DIR" 2>/dev/null && echo "dono ajustado para $WS_DONO"
    chmod -R 775 "$WS_DIR/cache" "$WS_DIR/uploads" "$WS_DIR/assets" "$WS_DIR/cache_trafego" "$WS_DIR/backups" 2>/dev/null && echo 'permissões de escrita ajustadas'
    ws_etapa 14 'Conferindo os servicos...'
    echo; echo '=== serviços ==='
    for s in apache2 mariadb mysql freeradius cron wellsystem-terminal; do
        if systemctl is-active --quiet "$s" 2>/dev/null; then echo "ativo    $s"
        elif systemctl list-unit-files "$s.service" 2>/dev/null | grep -q "^$s"; then echo "PARADO   $s"
        fi
    done
    ws_etapa 17 'Conferindo o banco...'
    echo; echo '=== banco ==='
    if [ -f "$WS_DIR/install_cli.php" ] && command -v php >/dev/null 2>&1; then
        (cd "$WS_DIR" && ws_php_dono "$WS_DIR/install_cli.php") 2>&1 | tail -5
    fi
    # Estrutura + RADIUS + derrubada: ws_reparar.php imprime as próprias etapas (@@ 20/50/90) para a barra.
    echo
    if [ -f "$WS_DIR/ws_reparar.php" ] && command -v php >/dev/null 2>&1; then
        (cd "$WS_DIR" && ws_php_dono "$WS_DIR/ws_reparar.php" --derrubar) 2>&1
        ws_etapa 100 'Pronto.'
        return
    fi
    # Versão antiga sem ws_reparar.php (ex.: logo após um downgrade): cai no caminho de antes.
    echo 'ws_reparar.php não encontrado — usando o reparo antigo'
    rm -f "$WS_DIR/cache/schema_ok.json" && echo 'marca de schema limpa (a próxima página revalida tudo)'
    # Igual ao MK-Auth: reparar termina derrubando TODOS os clientes na hora, pra forçar reconexão
    # já com os dados/permissões consertados (sem esperar cada um cair sozinho por conta própria).
    # Usa EXATAMENTE o mesmo critério do card "Derrubar/reiniciar conexões" do Menu Manutenção com
    # o filtro "Todos" (manutencao.php, case 'derrubar_conexoes'): lista pelo CADASTRO
    # (ws_contrato ativo, PPPoE + IPoE), não pelo radacct — se o radacct estiver desatualizado
    # (a própria razão de rodar o Reparar, às vezes) ele mostra sessão errada ou fica faltando
    # gente. E manda tudo pro MESMO ws_rad_disconnect_muitos (uma conexão por concentrador).
    ws_etapa 95 'Derrubando todas as conexoes...'
    echo; echo '=== conexoes ==='
    if [ -f "$WS_DIR/config.php" ] && [ -f "$WS_DIR/radius_lib.php" ] && command -v php >/dev/null 2>&1; then
        ws_php_dono -r '
            require $argv[1] . "/config.php";
            require $argv[1] . "/radius_lib.php";
            try {
                $db = ws_db();
                $rs = $db->query("SELECT ct.login_pppoe, ct.login_ipoe FROM ws_contrato ct
                                   WHERE ct.status<>\"cancelado\"
                                     AND ((ct.login_pppoe IS NOT NULL AND ct.login_pppoe<>\"\")
                                       OR (ct.login_ipoe IS NOT NULL AND ct.login_ipoe<>\"\"))")->fetchAll(PDO::FETCH_NUM);
                $logins = [];
                foreach ($rs as $lr) { foreach ($lr as $lg) { if ((string)$lg !== "") $logins[] = $lg; } }
                $logins = array_values(array_unique(array_filter($logins)));
                $n = function_exists("ws_rad_disconnect_muitos") ? ws_rad_disconnect_muitos($db, $logins) : 0;
                echo count($logins), " login(s) de contrato ativo, ", $n, " derrubada(s). O cliente reconecta sozinho.\n";
            } catch (Throwable $e) { echo "Falha ao derrubar conexoes: ", $e->getMessage(), "\n"; }
        ' "$WS_DIR"
    else
        echo 'radius_lib.php nao encontrado — pulei a derrubada de conexoes'
    fi
    ws_etapa 100 'Pronto.'
}
ws_acao_reparar() {
    ws_confirma 'Reparar os dados do sistema?\n\nConfere e cria as tabelas e colunas que faltarem, recria as pastas de trabalho, corrige dono e permissões, e por fim DERRUBA TODAS AS CONEXÕES ATIVAS (o cliente reconecta sozinho, já com tudo corrigido). Nenhum dado é apagado.' || return
    local t; t=$(ws_tmp)
    ws_com_progresso "$t" "" ws_trabalho_reparar
    ws_texto_arquivo "$t"; rm -f "$t"
}

ws_acao_reiniciar() {
    ws_confirma 'Reiniciar o servidor AGORA?\n\nTodos os acessos caem, inclusive a autenticação dos clientes, até a máquina voltar.' || return
    ws_confirma 'Confirma mesmo? O servidor vai reiniciar imediatamente.' || return
    # A mesma barra das outras opções: contagem de 5 segundos antes de reiniciar.
    local i
    if [ "$UI" = "texto" ]; then
        for i in 5 4 3 2 1; do printf 'Reiniciando em %s s...\n' "$i"; sleep 1; done
    else
        { for i in 5 4 3 2 1; do printf 'XXX\n%s\nReiniciando o servidor em %s s... reconecte em alguns instantes.\nXXX\n' $(( (6 - i) * 20 - 20 )) "$i"; sleep 1; done
          printf 'XXX\n100\nReiniciando agora.\nXXX\n'; sleep 1; } | "$UI" --title "$WS_TITULO" --gauge 'Reiniciando...' $(ws_dim 9 72) 0
    fi
    ( systemctl reboot 2>/dev/null || reboot ) &
    exit 0
}

# ------------------------------------------------------------------------------------------------
# IP DO SERVIDOR — a razão de este menu existir no terminal.
# ------------------------------------------------------------------------------------------------
ws_metodo_rede() {
    if [ -d /etc/netplan ] && ls /etc/netplan/*.yaml >/dev/null 2>&1; then echo netplan
    elif [ -f /etc/network/interfaces ]; then echo interfaces
    elif command -v nmcli >/dev/null 2>&1; then echo nmcli
    else echo desconhecido; fi
}
ws_mask_cidr() {  # 255.255.255.0 -> 24
    local m="$1" bits=0 o
    for o in $(echo "$m" | tr '.' ' '); do
        case "$o" in
            255) bits=$((bits+8)) ;; 254) bits=$((bits+7)) ;; 252) bits=$((bits+6)) ;; 248) bits=$((bits+5)) ;;
            240) bits=$((bits+4)) ;; 224) bits=$((bits+3)) ;; 192) bits=$((bits+2)) ;; 128) bits=$((bits+1)) ;;
            0) : ;; *) echo 24; return ;;
        esac
    done
    echo "$bits"
}
ws_cidr_mask() {  # 30 -> 255.255.255.252 (vazio ou inválido -> 255.255.255.0)
    local c="$1" m="" i o
    case "$c" in ''|*[!0-9]*) echo 255.255.255.0; return ;; esac
    [ "$c" -le 32 ] || { echo 255.255.255.0; return; }
    for i in 1 2 3 4; do
        if [ "$c" -ge 8 ]; then o=255; c=$((c - 8)); else o=$((256 - (1 << (8 - c)))); c=0; fi
        m="$m${m:+.}$o"
    done
    echo "$m"
}
ws_ip_valido() { echo "$1" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
    local o; for o in $(echo "$1" | tr '.' ' '); do [ "$o" -le 255 ] 2>/dev/null || return 1; done; return 0; }

ws_testa_conexao() {  # $1=gateway $2=dns → imprime o relatório e devolve 0 se tudo passou
    local falhou=0
    if [ -n "$1" ]; then
        if ping -c 2 -W 2 "$1" >/dev/null 2>&1; then echo "OK      gateway $1 responde"
        else echo "FALHOU  gateway $1 nao responde"; falhou=1; fi
    fi
    if ping -c 2 -W 2 8.8.8.8 >/dev/null 2>&1; then echo 'OK      internet (8.8.8.8) responde'
    else echo 'FALHOU  internet (8.8.8.8) sem resposta'; falhou=1; fi
    if [ -n "$2" ]; then
        if (command -v dig >/dev/null 2>&1 && dig +short +time=2 +tries=1 "@$2" google.com 2>/dev/null | grep -qE '^[0-9]+\.') \
           || (command -v nslookup >/dev/null 2>&1 && nslookup google.com "$2" 2>/dev/null | grep -q 'Address') \
           || { ! command -v dig >/dev/null 2>&1 && ! command -v nslookup >/dev/null 2>&1 && getent ahostsv4 google.com >/dev/null 2>&1; }; then   # Debian mínimo não tem dig/nslookup: confere pelo resolvedor do sistema (o DNS novo já está em 1º no resolv.conf)
            echo "OK      DNS $2 resolve nomes"
        else echo "FALHOU  DNS $2 nao resolveu google.com"; falhou=1; fi
    fi
    return $falhou
}

# TROCAR = SUBSTITUIR, NUNCA SOMAR (24/09/2026). O netplan JUNTA todos os .yaml: o menu gravava o IP novo no
# 99-wellsystem.yaml e a placa continuava no arquivo original (00-installer-config.yaml, 50-cloud-init.yaml...)
# com o IP e o gateway antigos — o servidor subia com OS DOIS IPs e DUAS rotas padrão (192.0.2.18 + 192.0.2.2,
# via .17 + via .1). Agora a placa sai dos outros arquivos antes de gravar a nova (cópia de tudo no backup).
ws_netplan_tirar_iface() {  # $1 = interface · $2 = pasta de backup
    local f
    if command -v python3 >/dev/null 2>&1 && python3 -c 'import yaml' 2>/dev/null; then
        python3 -c '
import sys, glob, os, yaml
ifn = sys.argv[1]
for f in sorted(glob.glob("/etc/netplan/*.yaml")):
    if os.path.basename(f) == "99-wellsystem.yaml": continue
    try:
        with open(f) as h: d = yaml.safe_load(h) or {}
    except Exception as e:
        print("netplan: nao consegui ler " + f + ": " + str(e)); continue
    net = d.get("network") or {}
    eth = net.get("ethernets") or {}
    if ifn not in eth: continue
    del eth[ifn]
    if not eth: net.pop("ethernets", None)
    if [k for k in net if k != "version"]:
        with open(f, "w") as h: yaml.safe_dump(d, h, default_flow_style=False, sort_keys=False)
        os.chmod(f, 0o600); print("netplan: " + ifn + " retirada de " + f)
    else:
        os.remove(f); print("netplan: " + f + " so tinha " + ifn + " - retirado (copia no backup)")
' "$1"
    else
        # sem python3-yaml: tira o arquivo inteiro que configura a placa (a cópia fica no backup)
        for f in /etc/netplan/*.yaml; do
            [ -f "$f" ] && [ "${f##*/}" != 99-wellsystem.yaml ] || continue
            grep -qE "^[[:space:]]+$1:[[:space:]]*$" "$f" || continue
            mkdir -p "$2/netplan-retirados"; mv "$f" "$2/netplan-retirados/"
            echo "netplan: $f retirado (copia em $2/netplan-retirados)"
        done
    fi
}

# Depois de aplicar: tira da placa todo IPv4 que não é o novo e toda rota padrão dela que não vai pelo gateway
# novo. Vale para netplan, interfaces e NetworkManager — o que ficou do IP antigo na placa sai na hora.
ws_rede_limpar_sobras() {  # $1=interface $2=ip $3=cidr $4=gateway
    local a r
    for a in $(ip -4 -o addr show dev "$1" 2>/dev/null | awk '{print $4}'); do
        [ "$a" = "$2/$3" ] && continue
        ip addr del "$a" dev "$1" && echo "retirado o IP antigo $a de $1"
    done
    [ -n "$4" ] || return 0
    ip route show default 2>/dev/null | grep " dev $1 " | grep -v " via $4 " | while read -r r; do
        ip route del $r && echo "retirada a rota padrao antiga: $r"
    done
}

# /etc/network/interfaces SEM a configuração IPv4 de UMA interface (stdin → stdout).
# Antes o menu apagava as linhas address/netmask/gateway de TODAS as interfaces — num servidor de
# provedor, com uma placa para a internet e outra para os concentradores, trocar o IP de uma
# derrubava a outra. Agora só sai o bloco "iface <ifn> inet ..." e as linhas auto/allow-hotplug dela;
# IPv6 (inet6), outras placas, "source" e comentários ficam como estão.
ws_interfaces_sem_iface() {  # $1 = interface
    awk -v IF="$1" '
        function inicio_bloco(l) { return l ~ /^[[:space:]]*(auto|allow-[a-z]+|iface|mapping|source|source-directory|rename)[[:space:]]/ }
        {
            if ($1 == "iface" && $2 == IF && $3 == "inet") { pular = 1; next }
            if (inicio_bloco($0)) pular = 0
            if (pular) next
            if ($1 == "auto" || $1 ~ /^allow-/) {
                saida = $1; resto = 0
                for (i = 2; i <= NF; i++) if ($i != IF) { saida = saida " " $i; resto++ }
                if (NF > 1 && resto == 0) next
                if (resto != NF - 1) { print saida; next }
            }
            print
        }'
}

# TROCAR O IP PELO SSH SEM FICAR TRANCADO PARA FORA.
# Aplicar e testar rodam DESTACADOS da sessão (setsid): quando o IP muda, a conexão SSH cai — e antes
# o próprio menu morria junto, no meio da troca, sem testar nem reverter. Agora:
#   - a troca, o teste e a reversão por falha acontecem mesmo que a sessão caia;
#   - passou no teste: a configuração nova fica PENDENTE por 3 minutos. Confirme no menu (se a sessão
#     não caiu) ou entrando de novo pelo IP novo — o menu pergunta na hora. Sem confirmação, volta
#     sozinha para a anterior. Assim um IP que "funciona" mas não é alcançável por você não tranca o
#     servidor.
WS_IP_PENDENTE="${WS_IP_PENDENTE:-/var/lib/wellsystem/ip-pendente}"
# Etapas da troca de IP → percentual (as linhas que o aplicar.sh grava no log).
ws_ip_etapa() {  # $1=aplicar.log
    local l="$1"
    if   grep -qa '^RESULTADO: OK' "$l";        then echo '100|Teste OK.'
    elif grep -qa '^RESULTADO: FALHOU' "$l";    then echo '100|Teste falhou — configuracao anterior restaurada.'
    elif grep -qa '=== TESTE DE CONEXAO' "$l";  then echo '70|Testando gateway, internet e DNS...'
    elif grep -qa 'aguardando a interface' "$l"; then echo '50|Aguardando a interface assentar...'
    elif grep -qa '^aplicando' "$l";            then echo '25|Aplicando a configuracao nova...'
    else echo '5|Iniciando...'; fi
}
ws_acao_ip() {
    local metodo ifn ip mask gw dns cidr t bkp con
    metodo="$(ws_metodo_rede)"
    [ "$metodo" = "desconhecido" ] && { ws_msg 'Não identifiquei o gerenciador de rede deste servidor (netplan, /etc/network/interfaces ou NetworkManager). Nada foi alterado.'; return; }
    [ -f "$WS_IP_PENDENTE" ] && { ws_msg 'Já existe uma troca de IP aguardando confirmação. Confirme ou reverta antes (feche e abra o menu de novo).'; return; }
    ifn=$(ip -o link show 2>/dev/null | awk -F': ' '$2!="lo"{print $2; exit}'); ifn="${ifn%%@*}"
    ifn=$(ws_pergunta 'Interface de rede' "$ifn") || return
    ip link show "$ifn" >/dev/null 2>&1 || { ws_msg "A interface $ifn não existe neste servidor."; return; }
    ip=$(ws_pergunta 'Endereço IP' "$(ip -4 -o addr show "$ifn" 2>/dev/null | awk '{print $4; exit}' | cut -d/ -f1)") || return
    # máscara sugerida = a que a placa usa hoje (antes vinha sempre 255.255.255.0 — num /30 errava a sub-rede)
    mask=$(ws_pergunta 'Máscara de sub-rede' "$(ws_cidr_mask "$(ip -4 -o addr show "$ifn" 2>/dev/null | awk '{print $4; exit}' | cut -d/ -f2)")") || return
    gw=$(ws_pergunta 'Gateway' "$(ip route 2>/dev/null | awk '/^default/{print $3; exit}')") || return
    dns=$(ws_pergunta 'DNS' '8.8.8.8') || return
    ws_ip_valido "$ip"   || { ws_msg 'IP inválido.'; return; }
    ws_ip_valido "$mask" || { ws_msg 'Máscara inválida.'; return; }
    [ -z "$gw" ]  || ws_ip_valido "$gw"  || { ws_msg 'Gateway inválido.'; return; }
    [ -z "$dns" ] || ws_ip_valido "$dns" || { ws_msg 'DNS inválido.'; return; }
    cidr=$(ws_mask_cidr "$mask")
    ws_confirma "Aplicar em $ifn?\n\n  IP ....... $ip/$cidr\n  Gateway .. ${gw:-nenhum}\n  DNS ...... ${dns:-nenhum}\n\nA configuração atual é salva antes. Se a sessão cair, entre de novo pelo IP novo em até 3 minutos e confirme — senão a anterior volta sozinha." || return

    bkp="${WS_REDE_BKP:-/var/backups}/wellsystem-rede-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$bkp" "$(dirname "$WS_IP_PENDENTE")"
    # ---- script de REVERSÃO (usado pela falha no teste, pelo "não manter" e pelo relógio de 3 min)
    {
        echo '#!/bin/bash'
        case "$metodo" in
            netplan)
                cp -a /etc/netplan/. "$bkp/netplan/" 2>/dev/null || { mkdir -p "$bkp/netplan"; cp -a /etc/netplan/. "$bkp/netplan/"; }
                [ -f /etc/network/interfaces ] && cp -a /etc/network/interfaces "$bkp/interfaces"
                echo "rm -f /etc/netplan/99-wellsystem.yaml; cp -a '$bkp/netplan/.' /etc/netplan/; [ -f '$bkp/interfaces' ] && cp -a '$bkp/interfaces' /etc/network/interfaces; ip addr flush dev '$ifn'; netplan apply" ;;
            interfaces)
                cp -a /etc/network/interfaces "$bkp/interfaces"
                echo "cp -a '$bkp/interfaces' /etc/network/interfaces; [ -f '$bkp/resolv.conf' ] && cp -a '$bkp/resolv.conf' /etc/resolv.conf; ifdown --force '$ifn' 2>/dev/null; ip addr flush dev '$ifn'; ifup '$ifn' || systemctl restart networking" ;;
            nmcli)
                con="$(nmcli -g GENERAL.CONNECTION device show "$ifn" 2>/dev/null | head -1)"; [ -n "$con" ] || con="$ifn"
                printf '%s\n' "$con" > "$bkp/nmcli-conexao"
                nmcli -g ipv4.method,ipv4.addresses,ipv4.gateway,ipv4.dns con show "$con" > "$bkp/nmcli-antes" 2>/dev/null
                echo "C='$con'; { read -r M; read -r A; read -r G; read -r D; } < '$bkp/nmcli-antes'"
                echo 'nmcli con mod "$C" ipv4.method "$M" ipv4.addresses "$A" ipv4.gateway "$G" ipv4.dns "$D"; nmcli con up "$C"' ;;
        esac
        echo "rm -f '$WS_IP_PENDENTE'"
    } > "$bkp/reverter.sh"
    # ---- script de APLICAÇÃO + teste
    {
        echo '#!/bin/bash'
        declare -f ws_testa_conexao ws_interfaces_sem_iface ws_netplan_tirar_iface ws_rede_limpar_sobras
        echo "exec >> '$bkp/aplicar.log' 2>&1"
        echo "echo 'aplicando...'"
        case "$metodo" in
            netplan)
                echo "ws_netplan_tirar_iface '$ifn' '$bkp'"
                # a mesma placa também em /etc/network/interfaces (ifupdown) subiria o IP antigo junto no boot
                echo "if [ -f '$bkp/interfaces' ] && grep -qE '^[[:space:]]*iface[[:space:]]+$ifn[[:space:]]+inet[[:space:]]' '$bkp/interfaces'; then ws_interfaces_sem_iface '$ifn' < '$bkp/interfaces' > /etc/network/interfaces.novo && mv /etc/network/interfaces.novo /etc/network/interfaces && echo 'interfaces: $ifn retirada (a placa e do netplan)'; fi"
                printf '%s\n' "cat > /etc/netplan/99-wellsystem.yaml <<'YAML'" 'network:' '  version: 2' '  ethernets:' "    $ifn:" '      dhcp4: no' "      addresses: [$ip/$cidr]"
                [ -n "$gw" ]  && printf '%s\n' '      routes:' '        - to: default' "          via: $gw"
                [ -n "$dns" ] && printf '%s\n' '      nameservers:' "        addresses: [$dns]"
                printf '%s\n' 'YAML' 'chmod 600 /etc/netplan/99-wellsystem.yaml' 'netplan apply' ;;
            interfaces)
                echo "ws_interfaces_sem_iface '$ifn' < '$bkp/interfaces' > /etc/network/interfaces.novo"
                echo "{ echo; echo 'auto $ifn'; echo 'iface $ifn inet static'; echo '    address $ip/$cidr'; $( [ -n "$gw" ] && echo "echo '    gateway $gw';" ) $( [ -n "$dns" ] && echo "echo '    dns-nameservers $dns';" ) } >> /etc/network/interfaces.novo"
                echo "mv /etc/network/interfaces.novo /etc/network/interfaces"
                echo "ifdown --force '$ifn' 2>/dev/null; ip addr flush dev '$ifn'; ifup '$ifn' || systemctl restart networking"
                [ -n "$dns" ] && echo "grep -q '^nameserver $dns' /etc/resolv.conf 2>/dev/null || { cp -a /etc/resolv.conf '$bkp/resolv.conf' 2>/dev/null; [ -e /etc/resolv.conf ] || : > /etc/resolv.conf; sed -i '1i nameserver $dns' /etc/resolv.conf 2>/dev/null; }" ;;
            nmcli)
                echo "nmcli con mod '$(cat "$bkp/nmcli-conexao")' ipv4.addresses '$ip/$cidr' ipv4.gateway '$gw' ipv4.dns '$dns' ipv4.method manual"
                echo "nmcli con up '$(cat "$bkp/nmcli-conexao")'" ;;
        esac
        echo "sleep 2; ws_rede_limpar_sobras '$ifn' '$ip' '$cidr' '$gw'"
        echo "echo; echo 'aguardando a interface assentar...'; sleep 4"
        echo "echo; echo '=== IP E ROTAS AGORA ==='; ip -4 -o addr show dev '$ifn' | awk '{print \$4}'; ip route show default"
        echo "echo; echo '=== TESTE DE CONEXAO ==='"
        echo "if ws_testa_conexao '$gw' '$dns'; then"
        echo "    echo; echo 'RESULTADO: OK — aguardando confirmacao (3 minutos)'"
        echo "    printf '%s\n' '$bkp' > '$WS_IP_PENDENTE'"
        echo "    ( sleep 180; [ -f '$WS_IP_PENDENTE' ] && grep -qx '$bkp' '$WS_IP_PENDENTE' && { echo 'sem confirmacao: revertendo'; bash '$bkp/reverter.sh'; } ) &"
        echo "else"
        echo "    echo; echo 'RESULTADO: FALHOU — revertendo para a configuracao anterior'"
        echo "    bash '$bkp/reverter.sh'; echo 'REVERTIDO'"
        echo "fi"
    } > "$bkp/aplicar.sh"
    : > "$bkp/aplicar.log"
    setsid nohup bash "$bkp/aplicar.sh" > /dev/null 2>&1 < /dev/null &

    # A sessão pode cair aqui (IP trocado). Se não cair, acompanha até o resultado.
    # Acompanha com a MESMA barra das outras opções (até 60 s).
    ( espera=0; while [ "$espera" -lt 60 ] && ! grep -q '^RESULTADO:' "$bkp/aplicar.log" 2>/dev/null; do sleep 1; espera=$((espera + 1)); done ) &
    local pid_espera=$!
    ws_progresso "$bkp/aplicar.log" ws_ip_etapa "$pid_espera"
    wait "$pid_espera"
    t=$(ws_tmp); cp "$bkp/aplicar.log" "$t"
    ws_texto_arquivo "$t"; rm -f "$t"
    if grep -q '^RESULTADO: OK' "$bkp/aplicar.log"; then
        if ws_confirma "Teste de conexão OK.\n\nMANTER a configuração nova?\n\n(Não = volta para a anterior agora. Sem resposta em 3 minutos, volta sozinha.)"; then
            rm -f "$WS_IP_PENDENTE"
            ws_msg "Configuração nova mantida.\n\nBackup da anterior em:\n$bkp"
        else
            bash "$bkp/reverter.sh" >/dev/null 2>&1
            ws_msg "Revertido para a configuração anterior.\n\nBackup usado: $bkp"
        fi
    elif grep -q '^RESULTADO: FALHOU' "$bkp/aplicar.log"; then
        ws_msg "O teste de conexão falhou e a configuração anterior JÁ FOI RESTAURADA.\n\nDetalhes em: $bkp/aplicar.log"
    else
        ws_msg "A troca ainda está em andamento. Veja o resultado em:\n$bkp/aplicar.log\n\nSe passar no teste, confirme abrindo o menu de novo em até 3 minutos."
    fi
}

# Troca de IP esperando confirmação: quem entrou de novo (pelo IP novo) confirma aqui.
ws_ip_pendente_confirmar() {
    [ -f "$WS_IP_PENDENTE" ] || return 0
    local bkp; bkp="$(head -1 "$WS_IP_PENDENTE")"
    if ws_confirma "Há uma troca de IP aguardando confirmação.\n\nVocê entrou por ela, então ela está funcionando.\n\nMANTER a configuração nova?\n\n(Não = volta para a anterior agora.)"; then
        rm -f "$WS_IP_PENDENTE"; ws_msg 'Configuração nova mantida.'
    else
        [ -f "$bkp/reverter.sh" ] && bash "$bkp/reverter.sh" >/dev/null 2>&1
        rm -f "$WS_IP_PENDENTE"; ws_msg "Revertido para a configuração anterior.\n\nBackup usado: $bkp"
    fi
}

# Quantos bytes do arquivo $1 já foram lidos por quem o está restaurando (gunzip/mysql).
ws_posicao_leitura() {
    local alvo p fd pos
    alvo="$(readlink -f "$1" 2>/dev/null)"
    for p in $(pgrep -x gunzip 2>/dev/null) $(pgrep -x mysql 2>/dev/null) $(pgrep -x mariadb 2>/dev/null); do
        for fd in /proc/"$p"/fd/*; do
            [ "$(readlink "$fd" 2>/dev/null)" = "$alvo" ] || continue
            pos="$(awk '/^pos:/{print $2; exit}' "/proc/$p/fdinfo/${fd##*/}" 2>/dev/null)"
            [ -n "$pos" ] && { echo "$pos"; return; }
        done
    done
    echo 0
}
# Barra REAL da restauração: bytes lidos do backup / tamanho do backup.
ws_restaurar_etapa() {  # $1=log
    local l arq tam pos pct
    l="$(grep -a '^@@F ' "$1" 2>/dev/null | tail -1)"
    if [ -z "$l" ] || grep -qa '^@@ 100 ' "$1"; then ws_etapa_do_log "$1"; return; fi
    tam="$(echo "$l" | awk '{print $2}')"; arq="${l#@@F * }"
    pos="$(ws_posicao_leitura "$arq")"
    [ "${tam:-0}" -gt 0 ] 2>/dev/null || tam=1
    pct=$(( 10 + pos * 88 / tam )); [ "$pct" -gt 98 ] && pct=98
    echo "$pct|Restaurando: $(( pos / 1048576 )) MB de $(( tam / 1048576 )) MB lidos..."
}
ws_trabalho_restaurar() {  # $1=pasta  $2=arquivo
    local H='' P='' U='' S='' D='' cnf f="$1/$2"
    ws_etapa 5 'Lendo as credenciais do banco...'
    # As credenciais saem da própria configuração do sistema — nada de senha escrita no script.
    eval "$(ws_php_dono -r 'require $argv[1] . "/config.php"; $c = ws_db_config();
        printf("H=%s; P=%s; U=%s; S=%s; D=%s;", escapeshellarg($c["host"]), escapeshellarg((string)$c["porta"]),
               escapeshellarg($c["user"]), escapeshellarg($c["pass"]), escapeshellarg($c["dbname"]));' "$WS_DIR" 2>/dev/null)"
    if [ -z "$D" ]; then echo 'Não consegui ler as credenciais do banco em config.php.'; ws_etapa 100 'Falhou.'; return 1; fi
    # Senha num arquivo temporário só do root, e não na linha de comando (onde apareceria no ps).
    cnf="$(mktemp)"; chmod 600 "$cnf"
    printf '[client]\nhost=%s\nport=%s\nuser=%s\npassword="%s"\n' "$H" "$P" "$U" "$(printf '%s' "$S" | sed 's/\\/\\\\/g; s/"/\\"/g')" > "$cnf"
    echo "restaurando $2 em $D ..."
    printf '@@F %s %s\n' "$(stat -c %s "$f" 2>/dev/null || echo 0)" "$f"
    local rc=0
    case "$2" in
        *.gz)  gunzip -c < "$f" | mysql --defaults-extra-file="$cnf" "$D" || rc=1 ;;
        *.sql) mysql --defaults-extra-file="$cnf" "$D" < "$f" || rc=1 ;;
    esac
    rm -f "$cnf"
    if [ "$rc" = 0 ]; then echo 'Restauração concluída.'; else echo 'A restauração FALHOU (veja a mensagem acima).'; fi
    ws_etapa 100 'Pronto.'
    return $rc
}
ws_acao_restaurar() {
    local dir arqs escolha t
    dir="$WS_DIR/backups"
    [ -d "$dir" ] || { ws_msg "Não achei a pasta de backups em $dir."; return; }
    arqs=$(ls -1t "$dir" 2>/dev/null | grep -E '\.(sql|sql\.gz)$' | head -10)
    [ -n "$arqs" ] || { ws_msg "Nenhum backup (.sql ou .sql.gz) encontrado em $dir."; return; }
    if [ "$UI" = "texto" ]; then
        echo "$arqs"; escolha=$(ws_pergunta 'Qual arquivo restaurar' "$(echo "$arqs" | head -1)")
    else
        local args=() a
        while IFS= read -r a; do args+=("$a" "$(du -h "$dir/$a" 2>/dev/null | cut -f1)"); done <<< "$arqs"
        escolha=$("$UI" --title "$WS_TITULO" --menu 'Restaurar qual backup?' $(ws_dim 18 72) 8 "${args[@]}" 3>&1 1>&2 2>&3) || return
    fi
    [ -n "$escolha" ] && [ -f "$dir/$escolha" ] || { ws_msg 'Arquivo inválido.'; return; }
    ws_confirma "RESTAURAR $escolha?\n\nO conteúdo atual do banco é SUBSTITUÍDO pelo do backup. O que foi cadastrado depois desse backup se perde." || return
    ws_confirma 'Última confirmação: restaurar e substituir os dados de agora?' || return
    t=$(ws_tmp)
    ws_com_progresso "$t" ws_restaurar_etapa ws_trabalho_restaurar "$dir" "$escolha"
    sed -i '/^@@F /d' "$t" 2>/dev/null
    ws_texto_arquivo "$t"; rm -f "$t"
}

ws_definir_senha_menu() {
    local s1 s2 h
    s1=$(ws_senha 'Nova senha para abrir o menu (deixe vazio para o menu voltar a abrir sem senha)') || return
    if [ -z "$s1" ]; then rm -f "$WS_MENU_HASH"; ws_msg 'Senha própria removida — o menu volta a abrir direto, sem senha.'; return; fi
    s2=$(ws_senha 'Repita a senha') || return
    [ "$s1" = "$s2" ] || { ws_msg 'As senhas não conferem.'; return; }
    h=$(ws_crypt "$s1" "\$6\$$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')") || { ws_msg 'Não consegui gerar o hash neste servidor (instale python3 ou whois).'; return; }
    mkdir -p "$(dirname "$WS_MENU_HASH")"
    printf '%s\n' "$h" > "$WS_MENU_HASH"; chmod 600 "$WS_MENU_HASH"
    ws_msg "Senha do menu definida.\n\nA partir de agora o menu pede ESTA senha ao abrir."
}

# Expandir disco: depois de aumentar o disco da máquina virtual, o espaço novo só aparece no sistema
# quando a partição, o LVM e o sistema de arquivos são esticados. Primeiro mostra o PLANO (simulação,
# nada muda), pede confirmação e só então aplica. A lógica e as travas estão no ws-expandir-disco.sh.
# Etapas do ws-expandir-disco.sh → percentual (as linhas que o próprio script imprime).
ws_disco_etapa() {  # $1=log
    local l="$1"
    if   grep -qa '^==> depois' "$l";                                   then echo '100|Concluido.'
    elif grep -qa 'atualizando initramfs' "$l";                         then echo '94|Atualizando o initramfs...'
    elif grep -qa 'resize2fs\|xfs_growfs\|btrfs filesystem resize' "$l"; then echo '86|Esticando o sistema de arquivos...'
    elif grep -qa 'pvresize\|lvextend' "$l";                            then echo '76|Esticando o LVM...'
    elif grep -qa 'criando /swapfile' "$l";                             then echo '66|Criando o arquivo de swap...'
    elif grep -qa 'sfdisk --no-reread -N' "$l";                         then echo '55|Esticando a particao...'
    elif grep -qa 'sfdisk --no-reread --delete\|swapoff' "$l";          then echo '45|Liberando o caminho (swap)...'
    elif grep -qa '^==> /' "$l";                                        then echo '30|Analisando as particoes...'
    elif grep -qa 'relendo o tamanho' "$l";                             then echo '18|Relendo o tamanho dos discos...'
    elif grep -qa '^==> antes' "$l";                                    then echo '8|Lendo o espaco atual...'
    else echo '2|Iniciando...'; fi
}
ws_acao_expandir_disco() {
    local sc="" c t
    for c in /usr/local/lib/wellsystem/ws-expandir-disco.sh "$WS_DIR/ws-expandir-disco.sh" "$(dirname "$0")/ws-expandir-disco.sh"; do
        [ -f "$c" ] && { sc="$c"; break; }
    done
    [ -n "$sc" ] || { ws_msg 'ws-expandir-disco.sh não encontrado. Atualize o sistema (opção 4) e tente de novo.'; return; }
    t=$(ws_tmp)
    ws_com_progresso "$t" ws_disco_etapa env WS_SIMULAR=1 bash "$sc"
    ws_texto_arquivo "$t"
    if ! grep -q 'espaço novo disponível\|partição de SWAP está entre' "$t"; then
        rm -f "$t"
        ws_msg 'Não há espaço novo para usar agora (ou existe uma partição com dados no caminho — veja o plano).\n\nNada foi alterado.\n\nSe acabou de aumentar o disco no painel da VM e ele não aparece, reinicie o servidor (opção 7) e tente de novo.'
        return
    fi
    rm -f "$t"
    ws_confirma 'Aplicar o plano mostrado e usar o espaço novo do disco?\n\nO sistema continua no ar. A tabela de partições é salva em /root antes.' || return
    t=$(ws_tmp)
    ws_com_progresso "$t" ws_disco_etapa env WS_SIM=1 bash "$sc"
    ws_texto_arquivo "$t"; rm -f "$t"
}

# ------------------------------------------------------------------------------------------------
# MENU
# ------------------------------------------------------------------------------------------------
ws_menu() {
    local op botoes
    # Rótulos dos botões: whiptail usa --ok-button/--cancel-button; dialog, --ok-label/--cancel-label.
    if [ "$UI" = "dialog" ]; then botoes="--ok-label Aceitar --cancel-label Cancelar"
    else botoes="--ok-button Aceitar --cancel-button Cancelar"; fi
    while :; do
        if [ "$UI" = "texto" ]; then
            printf '\n===== MENU WELLSYSTEM =====\n'
            printf ' 1 Uso dos discos rigidos\n 2 Resetar senha do painel (admin)\n 3 Gerar nova chave ssh\n'
            printf ' 4 Fazer update do sistema\n 5 Fazer downgrade do sistema\n 6 Reparar dados do sistema\n'
            printf ' 7 Reiniciar servidor\n 8 Configurar IP do servidor\n 9 Restaurar backup\n'
            printf '10 Expandir disco (usar o espaco novo)\n'
            if [ "${WS_MODO_WEB:-0}" = 1 ]; then printf ' 0 Sair (encerrar)\n'; else printf ' 0 Sair para o terminal\n'; fi
            printf 'Opcao: '; read -r op
        else
            # Igual ao menu do MK-Auth: <Aceitar> executa a opção; <Cancelar> libera o terminal.
            op=$("$UI" --title "$WS_TITULO" $botoes --menu 'MENU WELLSYSTEM' $(ws_dim 21 66) 11 \
                1 'Uso dos discos rigidos' \
                2 'Resetar senha do painel (admin)' \
                3 'Gerar nova chave ssh' \
                4 'Fazer update do sistema' \
                5 'Fazer downgrade do sistema' \
                6 'Reparar dados do sistema' \
                7 'Reiniciar servidor' \
                8 'Configurar IP do servidor' \
                9 'Restaurar backup' \
                10 'Expandir disco (usar o espaco novo)' \
                0 "$([ "${WS_MODO_WEB:-0}" = 1 ] && echo 'Sair (encerrar a tela)' || echo 'Sair para o terminal')" 3>&1 1>&2 2>&3) || op=0
        fi
        case "$op" in
            1) ws_acao_discos ;;      2) ws_acao_senha_painel ;;  3) ws_acao_chave_ssh ;;
            4) ws_acao_update ;;      5) ws_acao_downgrade ;;     6) ws_acao_reparar ;;
            7) ws_acao_reiniciar ;;   8) ws_acao_ip ;;            9) ws_acao_restaurar ;;
            10) ws_acao_expandir_disco ;;
            0) clear 2>/dev/null
               if [ "${WS_MODO_WEB:-0}" = 1 ]; then echo 'Menu encerrado. Clique em Abrir de novo para voltar.'; exit 0; fi
               echo 'WellSystem — terminal liberado. Digite "wellsystem" para abrir o menu de novo.'; return 0 ;;
            *) : ;;
        esac
    done
}

# ------------------------------------------------------------------------------------------------
# AUTOTESTE — confere a lógica que dá para conferir sem mexer no servidor (hash de senha, máscara,
# validação de IP, leitura do relatório de teste). Roda em qualquer máquina: é o que permite mudar
# este script com alguma segurança sem ter um servidor à mão.
# ------------------------------------------------------------------------------------------------
ws_selftest() {
    local ok=0 falha=0
    t() { if [ "$2" = "$3" ]; then ok=$((ok+1)); echo "OK    | $1"; else falha=$((falha+1)); echo "FALHA | $1 (esperado '$3', veio '$2')"; fi; }

    t 'mascara /24'  "$(ws_mask_cidr 255.255.255.0)"   24
    t 'mascara /16'  "$(ws_mask_cidr 255.255.0.0)"     16
    t 'mascara /30'  "$(ws_mask_cidr 255.255.255.252)" 30
    t 'mascara /8'   "$(ws_mask_cidr 255.0.0.0)"       8
    t 'mascara invalida cai no padrao' "$(ws_mask_cidr 255.255.abc.0)" 24

    ws_ip_valido 192.168.0.1   && t 'ip valido'            sim sim || t 'ip valido'            nao sim
    ws_ip_valido 999.1.1.1     && t 'ip com octeto >255'   sim nao || t 'ip com octeto >255'   nao nao
    ws_ip_valido 192.168.0     && t 'ip incompleto'        sim nao || t 'ip incompleto'        nao nao
    ws_ip_valido ''            && t 'ip vazio'             sim nao || t 'ip vazio'             nao nao

    # Senha: gera um hash de verdade e confere certo/errado.
    local ref
    ref=$(ws_crypt 'SenhaCerta123' '$6$wellsystemtest$' 2>/dev/null)
    if [ -n "$ref" ]; then
        ws_confere_senha 'SenhaCerta123' "$ref" && t 'senha correta confere'   sim sim || t 'senha correta confere'   nao sim
        ws_confere_senha 'SenhaErrada'  "$ref" && t 'senha errada e recusada' sim nao || t 'senha errada e recusada' nao nao
        ws_confere_senha ''             "$ref" && t 'senha vazia e recusada'  sim nao || t 'senha vazia e recusada'  nao nao
        ws_confere_senha 'x' ''         && t 'sem hash de referencia recusa'  sim nao || t 'sem hash de referencia recusa' nao nao
    else
        echo 'AVISO | sem python3/mkpasswd/openssl aqui — parte da senha nao pode ser testada'
    fi

    # Leitura do relatório de teste de conexão (é o que decide entre "aceita" e "reverter").
    local rel
    rel="$(printf 'OK      gateway 192.168.0.1 responde\nOK      internet (8.8.8.8) responde\nOK      DNS 8.8.8.8 resolve nomes\n')"
    echo "$rel" | grep -q '^FALHOU' && t 'relatorio todo OK nao acusa falha' sim nao || t 'relatorio todo OK nao acusa falha' nao nao
    rel="$(printf 'OK      gateway responde\nFALHOU  internet (8.8.8.8) sem resposta\n')"
    echo "$rel" | grep -q '^FALHOU' && t 'relatorio com falha e detectado' sim sim || t 'relatorio com falha e detectado' nao sim

    echo; echo "== $ok OK, $falha FALHA(S) =="
    [ "$falha" = "0" ]
}

# Para testes: carregar só as funções, sem abrir o menu.
[ "${WS_MENU_SO_FUNCOES:-0}" = "1" ] && return 0 2>/dev/null

# ------------------------------------------------------------------------------------------------
# ENTRADA
# ------------------------------------------------------------------------------------------------
case "${1:-}" in
    --selftest)      ws_selftest; exit $? ;;
    --definir-senha) [ "$(id -u)" = "0" ] || { echo 'Rode como root.' >&2; exit 1; }
                     ws_portao || exit 1; ws_definir_senha_menu; exit 0 ;;
    # Modo NAVEGADOR (ws-terminal-web.sh / Provedor → Menu do servidor): senha do root SEMPRE, e sair
    # encerra a tela — nunca entrega o shell do root pela web.
    # No navegador o fundo fica PRETO: a tela ocupa a área inteira da página, e o roxo padrão do
    # whiptail dava a sensação de uma janela enorme. As caixas continuam com as cores de sempre.
    --web)           WS_MODO_WEB=1
                     export NEWT_COLORS='root=white,black' ;;
    --ajuda|-h|--help)
        sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
esac

[ "$(id -u)" = "0" ] || { echo 'O menu do WellSystem precisa ser aberto como root.' >&2; exit 1; }
# Senha só quando o dono definiu uma senha própria do menu (ver o cabeçalho).
if [ "${WS_MODO_WEB:-0}" = "1" ]; then
    clear 2>/dev/null
    ws_portao || exit 1
elif [ -s "$WS_MENU_HASH" ]; then
    ws_portao || exit 1
fi
ws_ip_pendente_confirmar
ws_menu