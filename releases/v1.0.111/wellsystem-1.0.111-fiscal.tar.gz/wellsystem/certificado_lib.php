<?php
/**
 * WellSystem — CERTIFICADO HTTPS AUTOMÁTICO (24/09/2026).
 *
 * O operador informa UMA VEZ os domínios do provedor (Manutenção → Domínio & HTTPS). Daí em diante o
 * cron (radius_sync.php, a cada 2 min; esta verificação roda a cada 10) confere sozinho:
 *   1. se o certificado que o servidor entrega cobre cada domínio (lido pela porta 443, com SNI —
 *      sem depender de permissão em /etc/letsencrypt);
 *   2. faltando algum, se TODOS os domínios já apontam no DNS para o IP público deste servidor;
 *   3. aí pede o certificado (ws-certificado.sh via sudo, o mesmo caminho da tela, com --expand).
 *
 * TODOS apontando, e não "os que já apontam": a Let's Encrypt recusa o pedido inteiro por um domínio
 * errado, e pedir só uma parte trocaria o certificado atual por um que não cobre os outros. Falhou:
 * espera 6 h antes de tentar de novo (limite de tentativas da Let's Encrypt). Mudou a lista: tenta já.
 * Estado em cache/certificado.json — a tela mostra domínio por domínio o que falta.
 */

const WS_CERT_SCRIPT = '/usr/local/sbin/ws-certificado.sh';

function ws_cert_arquivo(): string { return WS_CACHE . '/certificado.json'; }

function ws_cert_cfg(): array {
    $c = @json_decode((string)@file_get_contents(ws_cert_arquivo()), true);
    $c = is_array($c) ? $c : [];
    return $c + ['dominios' => [], 'email' => '', 'auto' => true, 'estado' => [], 'ultima' => [], 'proxima' => 0];
}

function ws_cert_salvar(array $c): void {
    @file_put_contents(ws_cert_arquivo(), json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

/** Texto livre ("erp.x.com.br, https://financeiro.x.com.br/") → lista de domínios válidos, sem repetir. */
function ws_cert_normalizar($texto): array {
    $doms = [];
    foreach (preg_split('/[\s,;]+/', is_array($texto) ? implode(' ', $texto) : (string)$texto) as $d) {
        $d = strtolower(trim($d));
        $d = preg_replace('#^https?://#', '', $d);
        $d = explode('/', $d, 2)[0];
        $d = explode(':', $d, 2)[0];
        // Só nome de domínio. O que não casar aqui não chega perto do certbot.
        if ($d !== '' && preg_match('/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/', $d) && strpos($d, '.') !== false
            && !filter_var($d, FILTER_VALIDATE_IP) && !in_array($d, $doms, true)) $doms[] = $d;
    }
    return $doms;
}

/** E-mail dos avisos da Let's Encrypt: o salvo na tela; senão o do cadastro do provedor. */
function ws_cert_email(array $c): string {
    if (filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) return $c['email'];
    $p = @json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true);
    return (is_array($p) && filter_var($p['email'] ?? '', FILTER_VALIDATE_EMAIL)) ? $p['email'] : '';
}

/** IP público deste servidor (o que a internet vê — atrás de NAT não é o da placa). Guardado por 1 h. */
function ws_cert_ip_publico(): string {
    $f = WS_CACHE . '/ip_publico.txt';
    if (is_file($f) && time() - filemtime($f) < 3600) {
        $ip = trim((string)@file_get_contents($f));
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return $ip;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 5], 'ssl' => ['verify_peer' => true]]);
    foreach (['https://api.ipify.org', 'https://ipv4.icanhazip.com', 'https://ifconfig.me/ip'] as $u) {
        $ip = trim((string)@file_get_contents($u, false, $ctx));
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) { @file_put_contents($f, $ip); return $ip; }
    }
    return '';
}

/** IPv4 para onde o domínio aponta no DNS ([] = sem registro). */
function ws_cert_dns(string $d): array {
    $ips = @gethostbynamel($d . '.');   // o ponto final evita o "search" do resolv.conf
    return is_array($ips) ? array_values(array_unique($ips)) : [];
}

/** O certificado que o servidor entrega para o domínio (porta 443 local, com SNI) cobre esse nome? */
function ws_cert_cobre(string $d): ?array {
    $ctx = stream_context_create(['ssl' => ['peer_name' => $d, 'SNI_enabled' => true, 'capture_peer_cert' => true,
                                            'verify_peer' => false, 'verify_peer_name' => false]]);
    $s = @stream_socket_client('ssl://127.0.0.1:443', $en, $es, 5, STREAM_CLIENT_CONNECT, $ctx);
    if (!$s) return null;   // sem HTTPS no servidor
    $par = stream_context_get_params($s); fclose($s);
    $x = isset($par['options']['ssl']['peer_certificate']) ? @openssl_x509_parse($par['options']['ssl']['peer_certificate']) : false;
    if (!$x) return null;
    $nomes = [];
    foreach (explode(',', (string)($x['extensions']['subjectAltName'] ?? '')) as $n) {
        $n = trim($n); if (stripos($n, 'DNS:') === 0) $nomes[] = strtolower(substr($n, 4));
    }
    $cobre = false;
    foreach ($nomes as $n) {
        if ($n === $d || (strpos($n, '*.') === 0 && substr($d, strpos($d, '.')) === substr($n, 1))) { $cobre = true; break; }
    }
    return ['cobre' => $cobre, 'vence' => (int)($x['validTo_time_t'] ?? 0), 'nomes' => $nomes];
}

/** Situação de cada domínio: DNS, se aponta para cá e se o certificado cobre. */
function ws_cert_situacao(array $doms, string $ipPub): array {
    $r = [];
    foreach ($doms as $d) {
        $dns = ws_cert_dns($d);
        $cert = ws_cert_cobre($d);
        $r[$d] = ['dns' => $dns, 'aqui' => ($ipPub !== '' && in_array($ipPub, $dns, true)),
                  'coberto' => !empty($cert['cobre']), 'vence' => $cert['vence'] ?? 0];
    }
    return $r;
}

/** Pede o certificado para a lista inteira (o mesmo script da tela). Devolve [ok, saída]. */
function ws_cert_emitir(string $email, array $doms): array {
    if (!is_file(WS_CERT_SCRIPT)) return [false, 'ws-certificado.sh não instalado neste servidor (INSTALAR.sh/ATUALIZAR.sh instalam).'];
    $cmd = (function_exists('posix_geteuid') && posix_geteuid() === 0 ? '' : 'sudo -n ') . WS_CERT_SCRIPT . ' ' . escapeshellarg($email);
    foreach ($doms as $d) $cmd .= ' ' . escapeshellarg($d);
    $saida = (string)@shell_exec($cmd . ' 2>&1');
    return [strpos($saida, 'PRONTO') !== false, $saida];
}

/** Chamado pelo cron. $forcar = true ignora o intervalo de 10 min e a espera de 6 h (botão da tela). */
function ws_cert_auto_run(bool $forcar = false): array {
    $c = ws_cert_cfg();
    if (empty($c['auto']) || !$c['dominios']) return ['rodou' => false, 'motivo' => 'sem domínios'];
    $marca = WS_CACHE . '/certificado_auto.ok';
    if (!$forcar && is_file($marca) && time() - filemtime($marca) < 600) return ['rodou' => false, 'motivo' => 'intervalo'];
    @touch($marca);

    $ipPub = ws_cert_ip_publico();
    $sit = ws_cert_situacao($c['dominios'], $ipPub);
    $c['estado'] = ['quando' => time(), 'ip_publico' => $ipPub, 'dominios' => $sit];
    /* Pede para os domínios que JÁ APONTAM para cá — o que ainda aponta para outro lugar não é atendido por
       este servidor mesmo, e esperar por ele travaria os outros (ex.: financeiro pronto, erp ainda no IP
       antigo). Quando ele passar a apontar, entra no pedido seguinte e o certificado é aumentado (--expand).
       Nunca sai do pedido um domínio que aponta para cá: o certificado novo cobre sempre tudo o que chega aqui. */
    $pedir = array_keys(array_filter($sit, fn($s) => $s['aqui']));
    $faltam = array_values(array_filter($pedir, fn($d) => !$sit[$d]['coberto']));
    $foraDaqui = array_keys(array_filter($sit, fn($s) => !$s['aqui']));
    $esperaDns = $foraDaqui ? ' Aguardando o DNS: ' . implode(', ', $foraDaqui) . ($ipPub !== '' ? " ainda não aponta para $ipPub" : '') . ' — entra sozinho quando apontar.' : '';

    if ($ipPub === '')       { $c['estado']['msg'] = 'Não consegui descobrir o IP público deste servidor (sem internet?).'; ws_cert_salvar($c); return ['rodou' => false, 'motivo' => 'ip']; }
    if (!$pedir)             { $c['estado']['msg'] = trim($esperaDns); ws_cert_salvar($c); return ['rodou' => false, 'motivo' => 'dns']; }
    if (!$faltam)            { $c['estado']['msg'] = trim('Certificado cobre: ' . implode(', ', $pedir) . '.' . $esperaDns); ws_cert_salvar($c); return ['rodou' => false, 'motivo' => 'ok']; }
    $email = ws_cert_email($c);
    if ($email === '')       { $c['estado']['msg'] = 'Falta o e-mail para avisos da Let\'s Encrypt (tela ou cadastro do provedor).'; ws_cert_salvar($c); return ['rodou' => false, 'motivo' => 'email']; }
    // falhou: espera 6 h — a menos que a lista a pedir tenha mudado (ex.: acabou de apontar outro domínio)
    if (!$forcar && time() < (int)$c['proxima'] && ($c['ultima']['dominios'] ?? []) === $pedir) {
        $c['estado']['msg'] = 'Última tentativa falhou; nova tentativa às ' . date('d/m H:i', (int)$c['proxima']) . '.' . $esperaDns; ws_cert_salvar($c); return ['rodou' => false, 'motivo' => 'espera'];
    }

    [$ok, $saida] = ws_cert_emitir($email, $pedir);
    $c['ultima'] = ['quando' => time(), 'ok' => $ok, 'dominios' => $pedir, 'saida' => mb_substr(trim($saida), -1500)];
    $c['proxima'] = $ok ? 0 : time() + 6 * 3600;
    $c['estado']['msg'] = ($ok ? 'Certificado emitido para: ' . implode(', ', $pedir) . '.' : 'A emissão falhou (detalhes abaixo). Nova tentativa em 6 h.') . $esperaDns;
    if ($ok) foreach ($pedir as $d) $c['estado']['dominios'][$d]['coberto'] = true;
    ws_cert_salvar($c);
    if (function_exists('ws_evento')) { try { ws_evento(ws_db(), null, 'certificado', ($ok ? 'Certificado HTTPS emitido automaticamente: ' : 'Falha ao emitir certificado HTTPS: ') . implode(', ', $pedir)); } catch (Throwable $e) {} }
    return ['rodou' => true, 'ok' => $ok];
}
