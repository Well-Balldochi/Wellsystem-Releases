<?php
/**
 * WellSystem — CGNAT determinístico (porta estática) e relatório de conexão.
 *
 * Como funciona o CGNAT da Wellnet (explicado pelo dono, 10/11/2026):
 *   cada IP privado do cliente sai SEMPRE pelo mesmo IP público e pela mesma faixa de portas.
 *   NÃO existe (nem é exigido) log de cada conexão: a identificação é feita pela TABELA fixa
 *   (IP público + faixa de portas <-> IP privado) cruzada com as SESSÕES do assinante (radacct:
 *   quem estava com aquele IP privado, de quando até quando) — Marco Civil, art. 13.
 *
 * A tabela é guardada com VERSÃO e data "vigente desde": se a distribuição mudar, a versão antiga
 * continua respondendo pelas datas em que valeu.
 *
 * As sessões vêm da view `radacct` do banco do WellSystem (que aponta para radius.radacct).
 * Nunca se junta a view com tabelas ws_* no mesmo SQL (collation da view é diferente): os
 * cruzamentos são feitos em PHP.
 */

/** SQL das tabelas do módulo (definição única: schema.php e ws_selfheal() usam esta lista). */
function ws_cgnat_sql(): array {
    return [
        "CREATE TABLE IF NOT EXISTS ws_cgnat_versao (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vigente_desde DATETIME NOT NULL,
        descricao VARCHAR(200) DEFAULT NULL,
        arquivo VARCHAR(200) DEFAULT NULL,
        sha256 CHAR(64) DEFAULT NULL,
        linhas INT NOT NULL DEFAULT 0,
        ips_publicos INT NOT NULL DEFAULT 0,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        criado_por VARCHAR(80) DEFAULT NULL,
        INDEX idx_vigente (vigente_desde)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS ws_cgnat_mapa (
        versao_id INT NOT NULL,
        ip_publico INT UNSIGNED NOT NULL,
        porta_ini SMALLINT UNSIGNED NOT NULL,
        porta_fim SMALLINT UNSIGNED NOT NULL,
        ip_privado INT UNSIGNED NOT NULL,
        PRIMARY KEY (versao_id, ip_privado),
        KEY idx_pub (versao_id, ip_publico, porta_ini)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS ws_cgnat_hist (
        uid VARCHAR(80) NOT NULL PRIMARY KEY,
        username VARCHAR(64) NOT NULL DEFAULT '',
        ip VARCHAR(15) NOT NULL DEFAULT '',
        mac VARCHAR(50) DEFAULT NULL,
        nas VARCHAR(15) DEFAULT NULL,
        inicio DATETIME DEFAULT NULL,
        fim DATETIME DEFAULT NULL,
        atualizacao DATETIME DEFAULT NULL,
        causa VARCHAR(32) DEFAULT NULL,
        origem VARCHAR(20) NOT NULL DEFAULT 'mkauth',
        KEY idx_ip (ip, inicio),
        KEY idx_user (username, inicio),
        KEY idx_inicio (inicio)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS ws_cgnat_consulta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        usuario VARCHAR(80) DEFAULT NULL,
        ip_usuario VARCHAR(45) DEFAULT NULL,
        tipo VARCHAR(20) NOT NULL DEFAULT 'judicial',
        parametros TEXT DEFAULT NULL,
        resultado MEDIUMTEXT DEFAULT NULL,
        sha256 CHAR(64) DEFAULT NULL,
        INDEX idx_criado (criado_em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        /* 15/11/2026: texto ORIGINAL do arquivo de cada versão da tabela (para baixar de novo exatamente como foi enviado; o sha256 da versão confere). */
        "CREATE TABLE IF NOT EXISTS ws_cgnat_arquivo (
        versao_id INT NOT NULL PRIMARY KEY,
        conteudo MEDIUMTEXT NOT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

/** Cria as tabelas do módulo (também declaradas em schema.php e no ws_selfheal()). */
function ws_cgnat_schema(PDO $db): void {
    static $feito = false;
    if ($feito) return;
    $feito = true;
    foreach (ws_cgnat_sql() as $q) $db->exec($q);
}

/** IPv4 em texto -> inteiro sem sinal (ou null se inválido). */
function ws_cgnat_ip2int(string $ip): ?int {
    $ip = trim($ip);
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return null;
    return (int)sprintf('%u', ip2long($ip));
}
function ws_cgnat_int2ip(int $n): string { return long2ip($n); }

/**
 * Lê o arquivo da distribuição: uma linha por cliente, "IP_PUBLICO PORTA_INI-PORTA_FIM IP_PRIVADO".
 * Linhas vazias e comentários (#) são ignorados. Confere tudo antes de gravar: IP inválido, porta
 * fora de 0–65535, IP privado repetido e faixas sobrepostas no mesmo IP público derrubam a importação.
 * @return array{ok:bool, linhas:array, erros:string[], publicos:int}
 */
function ws_cgnat_ler_arquivo(string $conteudo): array {
    $linhas = []; $erros = []; $privVisto = []; $porPub = [];
    $n = 0;
    foreach (preg_split('/\r\n|\r|\n/', $conteudo) as $bruta) {
        $n++;
        $l = trim(preg_replace('/#.*/', '', $bruta));
        if ($l === '') continue;
        $p = preg_split('/[\s;,\t]+/', $l);
        if (count($p) !== 3 || !preg_match('/^(\d{1,5})-(\d{1,5})$/', $p[1], $m)) { $erros[] = "linha $n: formato inválido ($l)"; continue; }
        $pub = ws_cgnat_ip2int($p[0]); $priv = ws_cgnat_ip2int($p[2]);
        $ini = (int)$m[1]; $fim = (int)$m[2];
        if ($pub === null) { $erros[] = "linha $n: IP público inválido ({$p[0]})"; continue; }
        if ($priv === null) { $erros[] = "linha $n: IP privado inválido ({$p[2]})"; continue; }
        if ($ini > $fim || $fim > 65535) { $erros[] = "linha $n: faixa de portas inválida ({$p[1]})"; continue; }
        if (isset($privVisto[$priv])) { $erros[] = "linha $n: IP privado {$p[2]} repetido (já está na linha {$privVisto[$priv]})"; continue; }
        $privVisto[$priv] = $n;
        $porPub[$pub][] = [$ini, $fim, $n];
        $linhas[] = [$pub, $ini, $fim, $priv];
        if (count($erros) > 50) break;
    }
    foreach ($porPub as $pub => $faixas) {
        usort($faixas, fn($a, $b) => $a[0] <=> $b[0]);
        for ($i = 1; $i < count($faixas); $i++) {
            if ($faixas[$i][0] <= $faixas[$i - 1][1])
                $erros[] = 'faixas sobrepostas no IP ' . ws_cgnat_int2ip($pub) . " (linhas {$faixas[$i-1][2]} e {$faixas[$i][2]})";
        }
    }
    if (!$linhas && !$erros) $erros[] = 'arquivo vazio';
    return ['ok' => !$erros, 'linhas' => $linhas, 'erros' => $erros, 'publicos' => count($porPub)];
}

/**
 * Grava uma nova versão da tabela. Não apaga versões antigas: elas continuam valendo para as
 * datas anteriores ao "vigente desde" da nova.
 * @return array{ok:bool, msg:string, versao_id?:int}
 */
function ws_cgnat_importar(PDO $db, string $conteudo, string $vigenteDesde, string $arquivo, string $descricao, string $usuario): array {
    ws_cgnat_schema($db);
    $dt = DateTime::createFromFormat('Y-m-d\TH:i:s', $vigenteDesde) ?: (DateTime::createFromFormat('Y-m-d\TH:i', $vigenteDesde) ?: DateTime::createFromFormat('Y-m-d H:i:s', $vigenteDesde));
    if (!$dt) return ['ok' => false, 'msg' => 'Informe a data e a hora em que esta tabela passou a valer.'];
    $r = ws_cgnat_ler_arquivo($conteudo);
    if (!$r['ok']) return ['ok' => false, 'msg' => 'Arquivo NÃO importado: ' . implode('; ', array_slice($r['erros'], 0, 8)) . (count($r['erros']) > 8 ? ' …' : '')];
    $quando = $dt->format('Y-m-d H:i:s');
    $st = $db->prepare("SELECT COUNT(*) FROM ws_cgnat_versao WHERE vigente_desde = ?"); $st->execute([$quando]);
    if ((int)$st->fetchColumn() > 0) return ['ok' => false, 'msg' => 'Já existe uma versão vigente desde ' . $dt->format('d/m/Y H:i:s') . '. Use outra data/hora.'];
    $db->beginTransaction();
    try {
        $db->prepare("INSERT INTO ws_cgnat_versao (vigente_desde, descricao, arquivo, sha256, linhas, ips_publicos, criado_por) VALUES (?,?,?,?,?,?,?)")
           ->execute([$quando, mb_substr($descricao, 0, 200), mb_substr($arquivo, 0, 200), hash('sha256', $conteudo), count($r['linhas']), $r['publicos'], mb_substr($usuario, 0, 80)]);
        $vid = (int)$db->lastInsertId();
        $db->prepare("INSERT INTO ws_cgnat_arquivo (versao_id, conteudo) VALUES (?,?)")->execute([$vid, $conteudo]);   // 15/11/2026: guarda o arquivo original para baixar depois
        foreach (array_chunk($r['linhas'], 500) as $bloco) {
            $sql = "INSERT INTO ws_cgnat_mapa (versao_id, ip_publico, porta_ini, porta_fim, ip_privado) VALUES " . implode(',', array_fill(0, count($bloco), '(?,?,?,?,?)'));
            $par = [];
            foreach ($bloco as $l) { array_push($par, $vid, $l[0], $l[1], $l[2], $l[3]); }
            $db->prepare($sql)->execute($par);
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollBack();
        return ['ok' => false, 'msg' => 'Erro ao gravar a tabela: ' . $e->getMessage()];
    }
    return ['ok' => true, 'versao_id' => $vid, 'msg' => count($r['linhas']) . " clientes, {$r['publicos']} IPs públicos — vigente desde " . $dt->format('d/m/Y H:i:s') . '.'];
}

/**
 * 15/11/2026: guarda o texto original de uma versão que ainda não o tem (as cadastradas antes de existir o download). Só aceita se o sha256 do texto for IGUAL ao da versão
 * (prova de que é o mesmo arquivo). @return bool
 */
function ws_cgnat_arquivo_guardar(PDO $db, int $versaoId, string $conteudo): bool {
    ws_cgnat_schema($db);
    $st = $db->prepare("SELECT sha256 FROM ws_cgnat_versao WHERE id = ?"); $st->execute([$versaoId]);
    $sha = (string)$st->fetchColumn();
    if ($sha === '' || !hash_equals($sha, hash('sha256', $conteudo))) return false;
    $db->prepare("INSERT INTO ws_cgnat_arquivo (versao_id, conteudo) VALUES (?,?) ON DUPLICATE KEY UPDATE conteudo = VALUES(conteudo)")->execute([$versaoId, $conteudo]);
    return true;
}

/**
 * 15/11/2026: arquivo da tabela de uma versão para BAIXAR. Usa o texto original quando está guardado; senão REGERA a partir da tabela gravada, no mesmo formato
 * ("IP_público faixa IP_privado", uma linha por cliente), ordenado por IP público e porta. @return array{texto:string, nome:string, original:bool}|null
 */
function ws_cgnat_arquivo_texto(PDO $db, int $versaoId): ?array {
    ws_cgnat_schema($db);
    $st = $db->prepare("SELECT * FROM ws_cgnat_versao WHERE id = ?"); $st->execute([$versaoId]);
    $v = $st->fetch(PDO::FETCH_ASSOC);
    if (!$v) return null;
    $nome = 'cgnat-tabela-' . date('d-m-Y_Hi', strtotime((string)$v['vigente_desde'])) . '.txt';
    $q = $db->prepare("SELECT conteudo FROM ws_cgnat_arquivo WHERE versao_id = ?"); $q->execute([$versaoId]);
    $orig = $q->fetchColumn();
    if ($orig !== false && $orig !== '') return ['texto' => (string)$orig, 'nome' => $nome, 'original' => true];
    $m = $db->prepare("SELECT ip_publico, porta_ini, porta_fim, ip_privado FROM ws_cgnat_mapa WHERE versao_id = ? ORDER BY ip_publico, porta_ini"); $m->execute([$versaoId]);
    $t = '';
    foreach ($m->fetchAll(PDO::FETCH_ASSOC) as $r) $t .= ws_cgnat_int2ip((int)$r['ip_publico']) . ' ' . (int)$r['porta_ini'] . '-' . (int)$r['porta_fim'] . ' ' . ws_cgnat_int2ip((int)$r['ip_privado']) . "\n";
    return ['texto' => $t, 'nome' => $nome, 'original' => false];
}

/** Versões cadastradas, da mais nova para a mais antiga. */
function ws_cgnat_versoes(PDO $db): array {
    ws_cgnat_schema($db);
    return $db->query("SELECT * FROM ws_cgnat_versao ORDER BY vigente_desde DESC")->fetchAll(PDO::FETCH_ASSOC);
}

/** Versão que valia num instante (Y-m-d H:i:s, horário do servidor). */
function ws_cgnat_versao_em(PDO $db, string $quando): ?array {
    ws_cgnat_schema($db);
    $st = $db->prepare("SELECT * FROM ws_cgnat_versao WHERE vigente_desde <= ? ORDER BY vigente_desde DESC LIMIT 1");
    $st->execute([$quando]);
    $v = $st->fetch(PDO::FETCH_ASSOC);
    return $v ?: null;
}

/** IP público + porta -> IP privado na versão informada (ou null). */
function ws_cgnat_privado(PDO $db, int $versaoId, int $ipPub, int $porta): ?array {
    $st = $db->prepare("SELECT ip_privado, porta_ini, porta_fim FROM ws_cgnat_mapa
                         WHERE versao_id = ? AND ip_publico = ? AND porta_ini <= ? AND porta_fim >= ? LIMIT 1");
    $st->execute([$versaoId, $ipPub, $porta, $porta]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    return $r ? ['ip_privado' => (int)$r['ip_privado'], 'porta_ini' => (int)$r['porta_ini'], 'porta_fim' => (int)$r['porta_fim']] : null;
}

/** IP privado -> IP público e faixa de portas na versão informada (ou null se não é CGNAT). */
function ws_cgnat_publico(PDO $db, int $versaoId, int $ipPriv): ?array {
    $st = $db->prepare("SELECT ip_publico, porta_ini, porta_fim FROM ws_cgnat_mapa WHERE versao_id = ? AND ip_privado = ?");
    $st->execute([$versaoId, $ipPriv]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    return $r ? ['ip_publico' => (int)$r['ip_publico'], 'porta_ini' => (int)$r['porta_ini'], 'porta_fim' => (int)$r['porta_fim']] : null;
}

/**
 * Converte data/hora informada (no fuso do ofício) para o horário do servidor (Brasília).
 * $fuso: 'brt' (UTC−3), 'utc' ou deslocamento "+hh:mm"/"-hh:mm".
 */
function ws_cgnat_para_local(string $data, string $hora, string $fuso): ?DateTime {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data) || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $hora)) return null;
    if (strlen($hora) === 5) $hora .= ':00';
    $tz = $fuso === 'utc' ? '+00:00' : ($fuso === 'brt' || $fuso === '' ? '-03:00' : $fuso);
    if (!preg_match('/^[+-]\d{2}:\d{2}$/', $tz)) return null;
    try {
        $dt = new DateTime("$data $hora", new DateTimeZone($tz));
        $dt->setTimezone(new DateTimeZone(date_default_timezone_get()));
        return $dt;
    } catch (Throwable $e) { return null; }
}

/** Linha do histórico (ws_cgnat_hist) no mesmo formato das linhas do radacct. */
function ws_cgnat_linha_hist(array $h): array {
    return ['radacctid' => null, 'acctsessionid' => '', 'username' => $h['username'], 'framedipaddress' => $h['ip'],
            'callingstationid' => (string)$h['mac'], 'nasipaddress' => (string)$h['nas'], 'acctstarttime' => $h['inicio'],
            'acctstoptime' => $h['fim'], 'acctupdatetime' => $h['atualizacao'], 'acctsessiontime' => null,
            'acctterminatecause' => (string)$h['causa'], 'origem' => (string)($h['origem'] ?? 'mkauth')];
}
/** Junta sessões do radacct (vivo) com as do histórico importado, sem repetir (mesmo login, IP e início). */
function ws_cgnat_unir_sessoes(array $vivas, array $hist): array {
    $v = []; $out = [];
    foreach ($vivas as $s) { $s['origem'] = 'radacct'; $k = $s['username'] . '|' . $s['framedipaddress'] . '|' . $s['acctstarttime']; $v[$k] = 1; $out[] = $s; }
    foreach ($hist as $h) { $s = ws_cgnat_linha_hist($h); $k = $s['username'] . '|' . $s['framedipaddress'] . '|' . $s['acctstarttime']; if (!isset($v[$k])) $out[] = $s; }
    usort($out, fn($a, $b) => strcmp((string)$a['acctstarttime'], (string)$b['acctstarttime']));
    return $out;
}
/** Sessões de um IP privado que encostam no intervalo [$ini, $fim] (horário do servidor): radacct vivo + histórico do MK-Auth. */
function ws_cgnat_sessoes_ip(PDO $db, string $ipPriv, string $ini, string $fim): array {
    ws_cgnat_schema($db);
    $st = $db->prepare("SELECT radacctid, acctsessionid, username, framedipaddress, callingstationid, nasipaddress,
                               acctstarttime, acctstoptime, acctupdatetime, acctsessiontime, acctterminatecause
                          FROM radacct
                         WHERE framedipaddress = ? AND acctstarttime <= ?
                           AND (acctstoptime IS NULL OR acctstoptime >= ?)
                         ORDER BY acctstarttime");
    $st->execute([$ipPriv, $fim, $ini]);
    $vivas = $st->fetchAll(PDO::FETCH_ASSOC);
    $hist = [];
    try {
        $st = $db->prepare("SELECT username, ip, mac, nas, inicio, fim, atualizacao, causa, origem FROM ws_cgnat_hist
                             WHERE ip = ? AND inicio <= ? AND (fim IS NULL OR fim >= ?) ORDER BY inicio");
        $st->execute([$ipPriv, $fim, $ini]);
        $hist = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { /* sem histórico: só o radacct */ }
    return ws_cgnat_unir_sessoes($vivas, $hist);
}

/**
 * Copia as sessões do radacct (vivo) para o histórico (ws_cgnat_hist), só as de IP de CGNAT, sem repetir (uid = acctuniqueid).
 * Motivo: o backup do ERP não leva o radacct (por tamanho) mas leva o histórico; assim as sessões também sobrevivem a uma
 * reinstalação. Sessão ainda aberta é regravada a cada rodada até fechar. Chamada pela rotina diária (ws_logs_retencao).
 * @return int linhas copiadas/atualizadas
 */
function ws_cgnat_hist_sincronizar(PDO $db): int {
    ws_cgnat_schema($db);
    try {
        $st = $db->prepare("INSERT INTO ws_cgnat_hist (uid, username, ip, mac, nas, inicio, fim, atualizacao, causa, origem)
            SELECT CONCAT('wsr-', r.radacctid), r.username, r.framedipaddress, r.callingstationid, r.nasipaddress,
                   r.acctstarttime, r.acctstoptime, r.acctupdatetime, r.acctterminatecause, 'wellsystem'
              FROM radacct r
             WHERE r.acctstarttime IS NOT NULL AND r.framedipaddress <> ''
               AND INET_ATON(r.framedipaddress) IN (SELECT DISTINCT ip_privado FROM ws_cgnat_mapa)
            ON DUPLICATE KEY UPDATE fim = VALUES(fim), atualizacao = VALUES(atualizacao), causa = VALUES(causa), mac = VALUES(mac)");
        $st->execute();
        return (int)$st->rowCount();
    } catch (Throwable $e) { return -1; }
}

/**
 * Retenção de 1 ano (Marco Civil, art. 13): apaga do histórico as sessões que terminaram há mais de $dias dias
 * (sessão sem fim conta pelo início). Chamada pela rotina diária de retenção (ws_logs_retencao).
 * A tabela do CGNAT e a auditoria das consultas NÃO entram: não são sessões.
 */
function ws_cgnat_hist_retencao(PDO $db, int $dias = 365): int {
    ws_cgnat_schema($db);
    $lim = date('Y-m-d H:i:s', strtotime('-' . max(30, $dias) . ' days')); $tot = 0;
    for ($i = 0; $i < 60; $i++) {
        $st = $db->prepare('DELETE FROM ws_cgnat_hist WHERE COALESCE(fim, inicio) < ? LIMIT 5000'); $st->execute([$lim]);
        $n = $st->rowCount(); $tot += $n; if ($n < 5000) break;
    }
    return $tot;
}

/** Auditoria das consultas de ofício (ws_cgnat_consulta): mesma regra de 1 ano; a mais antiga sai. */
function ws_cgnat_consulta_retencao(PDO $db, int $dias = 365): int {
    ws_cgnat_schema($db);
    $st = $db->prepare('DELETE FROM ws_cgnat_consulta WHERE criado_em < ?');
    $st->execute([date('Y-m-d H:i:s', strtotime('-' . max(30, $dias) . ' days'))]);
    return $st->rowCount();
}

/** Início do histórico de sessões (menor data entre radacct e histórico importado) e quantas vêm do histórico. */
function ws_cgnat_cobertura(PDO $db): array {
    ws_cgnat_schema($db);
    $a = null; $b = null; $n = 0;
    try { $a = $db->query("SELECT MIN(acctstarttime) FROM radacct")->fetchColumn() ?: null; } catch (Throwable $e) {}
    try { $r = $db->query("SELECT MIN(inicio), COUNT(*) FROM ws_cgnat_hist")->fetch(PDO::FETCH_NUM); $b = $r[0] ?: null; $n = (int)$r[1]; } catch (Throwable $e) {}
    $min = $a && $b ? min($a, $b) : ($a ?: $b);
    return ['desde' => $min, 'hist_linhas' => $n, 'hist_desde' => $b];
}

/**
 * Importa o TSV gerado a partir dos backups do MK-Auth (uid, login, ip, mac, nas, inicio, fim, atualizacao, causa; \N = vazio).
 * Aceita .tsv ou .tsv.gz. Idempotente: a mesma sessão (uid) é regravada, não duplica.
 * @return array{ok:bool, msg:string, linhas:int}
 */
function ws_cgnat_hist_importar(PDO $db, string $arquivo, string $origem = 'mkauth'): array {
    ws_cgnat_schema($db);
    if (!is_file($arquivo)) return ['ok' => false, 'msg' => 'Arquivo não encontrado.', 'linhas' => 0];
    $fh = substr($arquivo, -3) === '.gz' ? @gzopen($arquivo, 'rb') : @fopen($arquivo, 'rb');
    if (!$fh) return ['ok' => false, 'msg' => 'Não consegui abrir o arquivo.', 'linhas' => 0];
    $lerLinha = substr($arquivo, -3) === '.gz' ? 'gzgets' : 'fgets';
    $eof = substr($arquivo, -3) === '.gz' ? 'gzeof' : 'feof';
    $v = fn($x) => ($x === '\N' || $x === '') ? null : $x;
    $lote = []; $n = 0; $ruins = 0;
    $grava = function (array $lote) use ($db) {
        if (!$lote) return;
        $sql = "INSERT INTO ws_cgnat_hist (uid, username, ip, mac, nas, inicio, fim, atualizacao, causa, origem) VALUES "
             . implode(',', array_fill(0, count($lote), '(?,?,?,?,?,?,?,?,?,?)'))
             . " ON DUPLICATE KEY UPDATE username=VALUES(username), ip=VALUES(ip), mac=VALUES(mac), nas=VALUES(nas), inicio=VALUES(inicio), fim=VALUES(fim), atualizacao=VALUES(atualizacao), causa=VALUES(causa)";
        $par = []; foreach ($lote as $l) foreach ($l as $c) $par[] = $c;
        $db->prepare($sql)->execute($par);
    };
    while (!$eof($fh)) {
        $l = $lerLinha($fh); if ($l === false) break;
        $c = explode("\t", rtrim($l, "\r\n"));
        if (count($c) < 9 || $c[0] === '' || !filter_var($c[2], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) { $ruins++; continue; }
        $lote[] = [mb_substr($c[0], 0, 80), mb_substr($c[1], 0, 64), $c[2], $v($c[3]), $v($c[4]), $v($c[5]), $v($c[6]), $v($c[7]), $v($c[8]), $origem];
        $n++;
        if (count($lote) >= 500) { $grava($lote); $lote = []; }
    }
    $grava($lote);
    $gz = substr($arquivo, -3) === '.gz' ? 'gzclose' : 'fclose'; $gz($fh);
    return ['ok' => true, 'linhas' => $n, 'msg' => "$n sessões gravadas" . ($ruins ? " ($ruins linhas ignoradas)" : '') . '.'];
}

/** Situação da sessão: 'conectado' (sessão aberta e viva), 'encerrada' ou 'sem_atualizacao'. */
function ws_cgnat_situacao(array $s): string {
    if (!empty($s['acctstoptime'])) return 'encerrada';
    $ult = strtotime((string)($s['acctupdatetime'] ?: $s['acctstarttime']));
    return ($ult && time() - $ult <= 20 * 60) ? 'conectado' : 'sem_atualizacao';
}

/**
 * Titular de cada login (contrato + cliente). O login é o do contrato HOJE: se um login foi
 * reaproveitado por outro contrato, o relatório avisa pela data de criação do contrato.
 * @return array login => dados
 */
function ws_cgnat_titulares(PDO $db, array $logins): array {
    $logins = array_values(array_unique(array_filter(array_map('strval', $logins), fn($l) => $l !== '')));
    if (!$logins) return [];
    $in = implode(',', array_fill(0, count($logins), '?'));
    $mapa = [];
    try {
        $temIpoe = (bool)$db->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_contrato' AND column_name='login_ipoe'")->fetchColumn();
        $colIpoe = $temIpoe ? 'ct.login_ipoe' : 'NULL';
        $where = $temIpoe ? "ct.login_pppoe IN ($in) OR ct.login_ipoe IN ($in)" : "ct.login_pppoe IN ($in)";
        $st = $db->prepare("SELECT ct.id contrato_id, ct.status contrato_status, ct.criado_em contrato_criado,
                                   ct.login_pppoe, $colIpoe login_ipoe,
                                   ct.inst_logradouro, ct.inst_numero, ct.inst_bairro, ct.inst_cidade,
                                   c.id cliente_id, c.nome, c.tipo, c.cpf_cnpj, c.rg_ie, c.celular, c.telefone, c.email,
                                   c.logradouro, c.numero, c.bairro, c.cidade, c.uf
                              FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                             WHERE $where");
        $st->execute($temIpoe ? array_merge($logins, $logins) : $logins);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            foreach ([$r['login_pppoe'], $r['login_ipoe']] as $lg) {
                $lg = (string)$lg;
                if ($lg !== '' && in_array($lg, $logins, true) && !isset($mapa[$lg])) $mapa[$lg] = $r;
            }
        }
    } catch (Throwable $e) { /* sem cadastro: o relatório mostra só o login */ }
    return $mapa;
}

/** Endereço de instalação (ou do cadastro) numa linha. */
function ws_cgnat_endereco(array $t): string {
    $l = trim((string)($t['inst_logradouro'] ?? '')) !== ''
        ? [$t['inst_logradouro'], $t['inst_numero'], $t['inst_bairro'], $t['inst_cidade']]
        : [$t['logradouro'] ?? '', $t['numero'] ?? '', $t['bairro'] ?? '', trim(($t['cidade'] ?? '') . (empty($t['uf']) ? '' : '/' . $t['uf']))];
    return implode(', ', array_filter(array_map(fn($x) => trim((string)$x), $l), fn($x) => $x !== ''));
}

/** Data/hora do servidor -> texto "dd/mm/aaaa HH:MM:SS". */
function ws_cgnat_dh(?string $s): string { return $s ? date('d/m/Y H:i:s', strtotime($s)) : '—'; }

/**
 * CONSULTA JUDICIAL: IP público + porta + data/hora -> quem era.
 * @return array resultado completo (também usado no PDF e na auditoria)
 */
/**
 * Termômetro da coleta NO MOMENTO do ofício: quantos clientes (logins) têm uma sessão registrada cobrindo aquele instante
 * (histórico + radacct vivo). Com a coleta íntegra fica em ~690-730; nos dias de falha já medimos 73 a 553. Abaixo de 600 = dúvida.
 * Sessão sem fim conta até 20 min depois da última atualização (mesma regra da consulta).
 */
function ws_cgnat_cobertura_momento(PDO $db, string $quando): int {
    $logins = [];
    try {
        $st = $db->prepare('SELECT DISTINCT username FROM ws_cgnat_hist WHERE inicio <= ? AND COALESCE(fim, DATE_ADD(COALESCE(atualizacao, inicio), INTERVAL 20 MINUTE)) >= ?');
        $st->execute([$quando, $quando]); foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $u) $logins[strtolower((string)$u)] = 1;
    } catch (Throwable $e) {}
    try {   // radacct vivo: cobre o dia de hoje, que o histórico só recebe na rotina das 03:10
        $st = $db->prepare('SELECT DISTINCT username FROM radacct WHERE acctstarttime <= ? AND (acctstoptime >= ? OR (acctstoptime IS NULL AND COALESCE(acctupdatetime, acctstarttime) >= DATE_SUB(?, INTERVAL 20 MINUTE)))');
        $st->execute([$quando, $quando, $quando]); foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $u) $logins[strtolower((string)$u)] = 1;
    } catch (Throwable $e) {}
    return count($logins);
}

function ws_cgnat_consulta_judicial(PDO $db, string $ipPub, int $porta, DateTime $quando, int $tolMin = 0): array {
    ws_cgnat_schema($db);
    $res = ['ok' => false, 'ip_publico' => $ipPub, 'porta' => $porta, 'quando' => $quando->format('Y-m-d H:i:s'), 'tolerancia_min' => $tolMin,
            'versao' => null, 'ip_privado' => null, 'faixa' => null, 'sessoes' => [], 'titulares' => [], 'mensagem' => ''];
    $pubInt = ws_cgnat_ip2int($ipPub);
    if ($pubInt === null) { $res['mensagem'] = 'IP público inválido.'; return $res; }
    if ($porta < 0 || $porta > 65535) { $res['mensagem'] = 'Porta inválida.'; return $res; }
    $v = ws_cgnat_versao_em($db, $res['quando']);
    if (!$v) { $res['mensagem'] = 'Não há tabela de CGNAT vigente nessa data. Cadastre a tabela com a data em que passou a valer.'; return $res; }
    $res['versao'] = $v;
    $map = ws_cgnat_privado($db, (int)$v['id'], $pubInt, $porta);
    if (!$map) {
        $res['mensagem'] = "O IP $ipPub com a porta $porta não pertence à tabela de CGNAT vigente nessa data (o IP não é do CGNAT ou a porta está fora das faixas).";
        return $res;
    }
    $priv = ws_cgnat_int2ip($map['ip_privado']);
    $res['ip_privado'] = $priv; $res['faixa'] = [$map['porta_ini'], $map['porta_fim']];
    $ini = (clone $quando)->modify("-$tolMin minutes")->format('Y-m-d H:i:s');
    $fim = (clone $quando)->modify("+$tolMin minutes")->format('Y-m-d H:i:s');
    $res['sessoes'] = ws_cgnat_sessoes_ip($db, $priv, $ini, $fim);
    $res['titulares'] = ws_cgnat_titulares($db, array_column($res['sessoes'], 'username'));
    $res['ok'] = true;
    $res['mensagem'] = $res['sessoes'] ? '' : "Nesse horário o IP privado $priv (dono da porta $porta do IP $ipPub) não estava entregue a nenhum cliente.";
    // Coleta fraca no dia: o sistema NÃO pode afirmar que o IP estava livre (pode ser falha de registro, não ausência de uso).
    $nMom = ws_cgnat_cobertura_momento($db, $res['quando']);
    $res['cobertura_n'] = $nMom;
    if ($nMom < 600) {
        $res['cobertura_duvidosa'] = true;
        if (!$res['sessoes']) $res['mensagem'] = "Não foi encontrada sessão para o IP privado $priv nesse horário, MAS o registro de conexões em " . date('d/m/Y H:i:s', strtotime($res['quando'])) . " está incompleto (só $nMom clientes com sessão registrada nesse momento; com a coleta íntegra são mais de 600). Por isso não é possível afirmar que o IP não estava em uso: a ausência pode ser falha de coleta.";
    }
    return $res;
}

/**
 * CONSULTA JUDICIAL POR FAIXA DE PORTAS (15/11/2026, pedido do dono): Porta Inicial e Porta Final (o CGNAT entrega por faixa).
 * Só a inicial (ou inicial = final) = a consulta de sempre, uma porta. Com a faixa: todos os blocos da tabela vigente que encostam nela,
 * e cada bloco é respondido pela MESMA regra da consulta de uma porta (ws_cgnat_consulta_judicial). Devolve uma lista de resultados (1 por bloco).
 */
function ws_cgnat_consulta_judicial_faixa(PDO $db, string $ipPub, int $pIni, int $pFim, DateTime $quando, int $tolMin = 0): array {
    if ($pFim < $pIni) { $t = $pIni; $pIni = $pFim; $pFim = $t; }
    if ($pFim === $pIni) return [ws_cgnat_consulta_judicial($db, $ipPub, $pIni, $quando, $tolMin)];
    ws_cgnat_schema($db);
    $pubInt = ws_cgnat_ip2int($ipPub);
    $v = $pubInt === null ? null : ws_cgnat_versao_em($db, $quando->format('Y-m-d H:i:s'));
    if ($pubInt === null || !$v) return [ws_cgnat_consulta_judicial($db, $ipPub, $pIni, $quando, $tolMin)];   // devolve a mesma mensagem de erro (IP inválido / sem tabela vigente)
    $st = $db->prepare('SELECT porta_ini, porta_fim FROM ws_cgnat_mapa WHERE versao_id = ? AND ip_publico = ? AND porta_ini <= ? AND porta_fim >= ? ORDER BY porta_ini LIMIT 64');
    $st->execute([(int)$v['id'], $pubInt, $pFim, $pIni]);
    $blocos = $st->fetchAll(PDO::FETCH_ASSOC);
    if (!$blocos) {
        $r = ws_cgnat_consulta_judicial($db, $ipPub, $pIni, $quando, $tolMin);
        $r['faixa_pedida'] = [$pIni, $pFim];
        $r['mensagem'] = "O IP $ipPub com a faixa de portas $pIni a $pFim não pertence à tabela de CGNAT vigente nessa data (o IP não é do CGNAT ou a faixa está fora dos blocos).";
        return [$r];
    }
    $lista = [];
    foreach ($blocos as $b) {
        $r = ws_cgnat_consulta_judicial($db, $ipPub, max($pIni, (int)$b['porta_ini']), $quando, $tolMin);   // uma porta de dentro do bloco e da faixa pedida
        $r['faixa_pedida'] = [$pIni, $pFim];
        if ($r['ok'] && !$r['sessoes'] && empty($r['cobertura_duvidosa']))
            $r['mensagem'] = "Nesse horário o IP privado {$r['ip_privado']} (bloco de portas {$b['porta_ini']} a {$b['porta_fim']} do IP $ipPub) não estava entregue a nenhum cliente.";
        $lista[] = $r;
    }
    return $lista;
}

/** Texto da resposta quando a consulta foi por faixa e abrangeu mais de um bloco (um parágrafo por bloco). */
function ws_cgnat_texto_judicial_faixa(array $lista, string $fusoTxt): string {
    if (count($lista) === 1) return ws_cgnat_texto_judicial($lista[0], $fusoTxt);
    $a = $lista[0]['faixa_pedida'] ?? [0, 0]; $n = count($lista);
    $txt = "A faixa de portas de origem {$a[0]} a {$a[1]} do endereço IP público {$lista[0]['ip_publico']} abrange $n blocos da tabela de CGNAT; a identificação de cada bloco segue abaixo.";
    foreach ($lista as $i => $r) $txt .= "\n\nBloco " . ($i + 1) . " de $n: " . ws_cgnat_texto_judicial($r, $fusoTxt);
    return $txt;
}

/** Texto da resposta da consulta judicial (vai na tela, no PDF e no hash da auditoria). */
function ws_cgnat_texto_judicial(array $r, string $fusoTxt): string {
    $q = date('d/m/Y \à\s H:i:s', strtotime($r['quando']));
    if (!$r['ok'] || !$r['sessoes']) return $r['mensagem'] !== '' ? $r['mensagem'] : 'Sem resultado.';
    $v = $r['versao'];
    $portaTxt = isset($r['faixa_pedida']) ? "faixa de portas de origem {$r['faixa_pedida'][0]} a {$r['faixa_pedida'][1]}" : "porta de origem {$r['porta']}";
    $verbo = isset($r['faixa_pedida']) ? 'abrangia o bloco do' : 'pertencia ao';
    $txt = "Em $q (horário de Brasília$fusoTxt), o endereço IP público {$r['ip_publico']}, $portaTxt, "
         . "$verbo IP privado {$r['ip_privado']} (faixa de portas {$r['faixa'][0]} a {$r['faixa'][1]}, "
         . "tabela de CGNAT nº {$v['id']}, vigente desde " . date('d/m/Y H:i:s', strtotime($v['vigente_desde'])) . ").";
    foreach ($r['sessoes'] as $s) {
        $t = $r['titulares'][$s['username']] ?? null;
        $quem = $t ? ("cliente {$t['nome']}" . ($t['cpf_cnpj'] ? ' (' . ($t['tipo'] === 'PJ' ? 'CNPJ' : 'CPF') . " {$t['cpf_cnpj']})" : '') . ", contrato nº {$t['contrato_id']}") : 'login sem cadastro no sistema';
        $fimS = $s['acctstoptime'] ? 'encerrada em ' . ws_cgnat_dh($s['acctstoptime']) : (($s['origem'] ?? '') === 'mkauth' ? 'sem encerramento registrado' : 'ainda ativa (sem encerramento registrado)');
        $durS = $s['acctstoptime'] ? ', duração de ' . ws_cgnat_duracao($s) : '';
        $txt .= " Nesse horário o IP privado estava em uso pelo login {$s['username']} — $quem — na sessão iniciada em "
              . ws_cgnat_dh($s['acctstarttime']) . " e $fimS$durS, concentrador {$s['nasipaddress']}"
              . ($s['callingstationid'] ? ", equipamento (MAC) {$s['callingstationid']}" : '') . '.';
    }
    if (count($r['sessoes']) > 1) $txt .= ' Atenção: mais de uma sessão encosta no intervalo pesquisado; confira os horários acima.';
    if (!empty($r['cobertura_duvidosa'])) $txt .= ' Atenção: o registro de conexões nesse momento está incompleto (só ' . (int)($r['cobertura_n'] ?? 0) . ' clientes com sessão registrada; o normal é acima de 600); a lista acima pode não estar completa.';
    return $txt;
}

/** Grava a consulta na auditoria e devolve [id, sha256]. */
function ws_cgnat_auditar(PDO $db, string $tipo, array $parametros, string $resultado): array {
    ws_cgnat_schema($db);
    $hash = hash('sha256', $resultado);
    $db->prepare("INSERT INTO ws_cgnat_consulta (usuario, ip_usuario, tipo, parametros, resultado, sha256) VALUES (?,?,?,?,?,?)")
       ->execute([$_SESSION['ws_user']['login'] ?? '-', $_SERVER['REMOTE_ADDR'] ?? '-', $tipo,
                  json_encode($parametros, JSON_UNESCAPED_UNICODE), $resultado, $hash]);
    return [(int)$db->lastInsertId(), $hash];
}

/**
 * BUSCA DE CONEXÕES (relatório): filtros por IP público, porta, IP privado, login/nome, período e situação.
 * @return array{erro:?string, linhas:array, total:int}
 */
function ws_cgnat_buscar(PDO $db, array $f, int $limite = 2000): array {
    ws_cgnat_schema($db);
    // Hora inicial/final são opcionais (HH:MM): sem elas vale o dia inteiro.
    $hi = preg_match('/^\d{2}:\d{2}(:\d{2})?$/', (string)($f['hi'] ?? '')) ? $f['hi'] : '00:00:00'; if (strlen($hi) === 5) $hi .= ':00';
    $hf = preg_match('/^\d{2}:\d{2}(:\d{2})?$/', (string)($f['hf'] ?? '')) ? $f['hf'] : '23:59:59'; if (strlen($hf) === 5) $hf .= ':59';
    $de = $f['de'] . ' ' . $hi; $ate = $f['ate'] . ' ' . $hf;
    $ips = null;   // null = sem filtro de IP
    $vAte = ws_cgnat_versao_em($db, $ate);
    if ($f['ip_publico'] !== '') {
        $pub = ws_cgnat_ip2int($f['ip_publico']);
        if ($pub === null) return ['erro' => 'IP público inválido.', 'linhas' => [], 'total' => 0];
        if (!$vAte) return ['erro' => 'Não há tabela de CGNAT vigente no período.', 'linhas' => [], 'total' => 0];
        $ips = [];
        foreach (ws_cgnat_versoes($db) as $v) {   // todas as versões que valeram no período
            if ($v['vigente_desde'] > $ate) continue;
            $pIni = (int)$f['porta']; $pFim = (($f['porta_fim'] ?? '') !== '') ? (int)$f['porta_fim'] : $pIni; if ($pFim < $pIni) { $tp = $pIni; $pIni = $pFim; $pFim = $tp; }   // porta inicial e final: todos os blocos que encostam na faixa
            $sql = "SELECT ip_privado FROM ws_cgnat_mapa WHERE versao_id = ? AND ip_publico = ?" . ($f['porta'] !== '' ? " AND porta_ini <= ? AND porta_fim >= ?" : '');
            $par = [(int)$v['id'], $pub]; if ($f['porta'] !== '') array_push($par, $pFim, $pIni);
            $st = $db->prepare($sql); $st->execute($par);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $p) $ips[ws_cgnat_int2ip((int)$p)] = true;
            if ($v['vigente_desde'] <= $de) break;
        }
        $ips = array_keys($ips);
        if (!$ips) return ['erro' => null, 'linhas' => [], 'total' => 0];
    }
    if ($f['ip_privado'] !== '') {
        if (ws_cgnat_ip2int($f['ip_privado']) === null) return ['erro' => 'IP privado inválido.', 'linhas' => [], 'total' => 0];
        $ips = $ips === null ? [$f['ip_privado']] : array_values(array_intersect($ips, [$f['ip_privado']]));
        if (!$ips) return ['erro' => null, 'linhas' => [], 'total' => 0];
    }
    $logins = null;
    if ($f['cliente'] !== '') {   // login exato/parcial ou nome do cliente
        $logins = [];
        $st = $db->prepare("SELECT ct.login_pppoe, " . (ws_cgnat_tem_ipoe($db) ? 'ct.login_ipoe' : 'NULL') . " login_ipoe FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                             WHERE c.nome LIKE ? OR c.cpf_cnpj LIKE ? OR ct.login_pppoe LIKE ?" . (ws_cgnat_tem_ipoe($db) ? " OR ct.login_ipoe LIKE ?" : '') . " LIMIT 200");
        $like = '%' . $f['cliente'] . '%';
        $st->execute(ws_cgnat_tem_ipoe($db) ? [$like, $like, $like, $like] : [$like, $like, $like]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) foreach ([$r['login_pppoe'], $r['login_ipoe']] as $l) if ((string)$l !== '') $logins[(string)$l] = true;
        $logins = array_keys($logins);
        if (!$logins) $logins = [$f['cliente']];   // pode ser um login sem cadastro
    }
    $w = ["acctstarttime <= ?", "(acctstoptime IS NULL OR acctstoptime >= ?)"]; $par = [$ate, $de];
    if ($ips !== null) { $w[] = 'framedipaddress IN (' . implode(',', array_fill(0, count($ips), '?')) . ')'; $par = array_merge($par, $ips); }
    if ($logins !== null) { $w[] = 'username IN (' . implode(',', array_fill(0, count($logins), '?')) . ')'; $par = array_merge($par, $logins); }
    if ($f['situacao'] === 'conectado') { $w[] = "acctstoptime IS NULL AND acctupdatetime >= ?"; $par[] = date('Y-m-d H:i:s', time() - 20 * 60); }
    if ($f['situacao'] === 'encerrada') { $w[] = "acctstoptime IS NOT NULL"; }
    $where = implode(' AND ', $w);
    try {
        $st = $db->prepare("SELECT COUNT(*) FROM radacct WHERE $where"); $st->execute($par); $total = (int)$st->fetchColumn();
        $st = $db->prepare("SELECT radacctid, username, framedipaddress, callingstationid, nasipaddress, acctstarttime, acctstoptime,
                                   acctupdatetime, acctsessiontime, acctterminatecause
                              FROM radacct WHERE $where ORDER BY acctstarttime DESC LIMIT " . (int)$limite);
        $st->execute($par); $linhas = $st->fetchAll(PDO::FETCH_ASSOC);
        // Histórico importado do MK-Auth (mesmos filtros, colunas com outro nome).
        $wh = str_replace(['acctstarttime', 'acctstoptime', 'acctupdatetime', 'framedipaddress'], ['inicio', 'fim', 'atualizacao', 'ip'], $where);
        try {
            $st = $db->prepare("SELECT COUNT(*) FROM ws_cgnat_hist WHERE $wh"); $st->execute($par); $totalH = (int)$st->fetchColumn();
            $st = $db->prepare("SELECT username, ip, mac, nas, inicio, fim, atualizacao, causa, origem FROM ws_cgnat_hist WHERE $wh ORDER BY inicio DESC LIMIT " . (int)$limite);
            $st->execute($par); $hist = $st->fetchAll(PDO::FETCH_ASSOC);
            if ($hist) {
                $linhas = array_reverse(ws_cgnat_unir_sessoes($linhas, $hist));   // mais novas primeiro
                $linhas = array_slice($linhas, 0, (int)$limite);
                $total += $totalH;
            }
        } catch (Throwable $e) { /* sem histórico importado */ }
    } catch (Throwable $e) {
        return ['erro' => 'Não consegui ler as sessões (radacct): ' . $e->getMessage(), 'linhas' => [], 'total' => 0];
    }
    // IP público e faixa de cada sessão, pela versão da tabela que valia no início da sessão.
    $cacheV = []; $primeira = null;
    foreach ($linhas as &$s) {
        $s['ip_publico'] = ''; $s['faixa'] = ''; $s['porta_ini'] = ''; $s['porta_fim'] = '';
        $priv = ws_cgnat_ip2int((string)$s['framedipaddress']);
        $v = ws_cgnat_versao_em($db, max((string)$s['acctstarttime'], $de)) ?? $vAte;
        if ($priv !== null && $v) {
            $k = $v['id'] . ':' . $priv;
            if (!isset($cacheV[$k])) $cacheV[$k] = ws_cgnat_publico($db, (int)$v['id'], $priv);
            if ($cacheV[$k]) { $s['ip_publico'] = ws_cgnat_int2ip($cacheV[$k]['ip_publico']); $s['faixa'] = $cacheV[$k]['porta_ini'] . '–' . $cacheV[$k]['porta_fim']; $s['porta_ini'] = (int)$cacheV[$k]['porta_ini']; $s['porta_fim'] = (int)$cacheV[$k]['porta_fim']; }
        }
        $s['situacao'] = ws_cgnat_situacao($s);
    }
    unset($s);
    return ['erro' => null, 'linhas' => $linhas, 'total' => $total];
}

function ws_cgnat_tem_ipoe(PDO $db): bool {
    static $r = null;
    if ($r === null) $r = (bool)$db->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_contrato' AND column_name='login_ipoe'")->fetchColumn();
    return $r;
}

/** Duração em texto (segundos -> "3d 04h12m"). */
function ws_cgnat_duracao(array $s): string {
    $ini = strtotime((string)$s['acctstarttime']);
    $fim = $s['acctstoptime'] ? strtotime((string)$s['acctstoptime']) : time();
    $d = max(0, $fim - $ini);
    $dias = intdiv($d, 86400); $h = intdiv($d % 86400, 3600); $m = intdiv($d % 3600, 60);
    return ($dias ? $dias . 'd ' : '') . str_pad((string)$h, 2, '0', STR_PAD_LEFT) . 'h' . str_pad((string)$m, 2, '0', STR_PAD_LEFT) . 'm';
}
