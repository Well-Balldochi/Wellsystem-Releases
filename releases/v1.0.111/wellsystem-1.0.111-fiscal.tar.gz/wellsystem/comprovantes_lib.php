<?php
/**
 * WellSystem — COMPROVANTES PIX recebidos pelo robô do WhatsApp (24/09/2026).
 *
 * O PEDIDO: no robô (Typebot), o cliente paga pelo QR Code MANUAL e manda o comprovante. Antes o arquivo ficava
 * só na conversa do WhatsApp; agora vai para Financeiro → Comprovantes PIX, onde se abre, confere e dá baixa.
 *
 * O CAMINHO:
 *   1. O Typebot guarda o que o cliente mandou na variável {{comprovante}}. A Evolution NÃO passa o arquivo, e sim o
 *      tipo e o ID da mensagem no WhatsApp: "imageMessage|wamid.HBgM..." ou "documentMessage|wamid...".
 *      Vários arquivos vêm em várias linhas. Formato confirmado nos resultados reais do robô (21 e 22/09/2026).
 *   2. Depois do "nome do cliente", um bloco HTTP do robô faz POST https://<domínio>/api/comprovante (api/index.php)
 *      com a MESMA credencial Basic do "GERA TOKEN" e o JSON:
 *        {comprovante, nome_informado, remoteJid, pushName, cpf}
 *   3. ws_comp_receber() grava a linha e já tenta baixar o arquivo (ws_comp_baixar). Se a Evolution ainda não tiver o
 *      arquivo, fica "pendente" e é tentado de novo sozinho ao abrir a tela (até 10 vezes). NADA SE PERDE: a linha
 *      com telefone, nome e ID da mensagem existe mesmo sem o arquivo.
 *   4. De onde vem o arquivo (ws_comp_midia), em cada instância da Evolution (mesma URL/chave de Mensagens → Servidor),
 *      nesta ordem:
 *        a) chat/findMessages com key.id = wamid. Com S3 ligado na Evolution, a mensagem traz message.mediaUrl, que
 *           é baixado. Com "webhook base64" ligado, a mensagem traz message.base64.
 *        b) chat/getBase64FromMediaMessage, que pede o arquivo à Evolution pelo ID.
 *   5. O cliente é achado pelo TELEFONE do WhatsApp (últimos 8 dígitos, celular ou telefone do cadastro) e, se vier,
 *      pelo CPF. Sem cliente único, a tela mostra o nome digitado e o operador escolhe.
 *
 * ONDE FICA O ARQUIVO: uploads/comprovantes/AAAA-MM/, com .htaccess que BLOQUEIA acesso direto (comprovante tem
 * dado bancário). Só abre por comprovantes.php?ver=, com operador logado.
 * Tabela ws_comprovante: definida aqui (ws_comp_sql) e usada pelo schema.php e pelo ws_selfheal() do config.php.
 */

/** Definição da tabela — a MESMA string vai no schema.php (instalação nova) e no ws_selfheal() (instalação existente). */
function ws_comp_sql(): string {
    return "CREATE TABLE IF NOT EXISTS ws_comprovante (
        id INT AUTO_INCREMENT PRIMARY KEY,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        telefone VARCHAR(20) DEFAULT NULL,
        jid VARCHAR(60) DEFAULT NULL,
        nome_whats VARCHAR(120) DEFAULT NULL,
        nome_informado VARCHAR(160) DEFAULT NULL,
        cpf VARCHAR(20) DEFAULT NULL,
        cliente_id INT DEFAULT NULL,
        mensagens TEXT NULL,
        arquivos TEXT NULL,
        baixado VARCHAR(10) NOT NULL DEFAULT 'pendente',
        tentativas INT NOT NULL DEFAULT 0,
        erro VARCHAR(255) DEFAULT NULL,
        status VARCHAR(12) NOT NULL DEFAULT 'novo',
        fatura_id INT DEFAULT NULL,
        obs VARCHAR(255) DEFAULT NULL,
        conferido_por VARCHAR(80) DEFAULT NULL,
        conferido_em DATETIME DEFAULT NULL,
        INDEX idx_status (status, criado_em), INDEX idx_cli (cliente_id), INDEX idx_baixado (baixado)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
}

/** Pasta dos arquivos, criada com .htaccess que nega acesso direto pela web (o uploads/ serve tudo por padrão). */
function ws_comp_dir(): string {
    $d = WS_UPLOADS . '/comprovantes';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    if (!is_file($d . '/.htaccess'))
        @file_put_contents($d . '/.htaccess', "# Comprovantes PIX: só por comprovantes.php (operador logado).\n"
            . "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n");
    return $d;
}

/** "imageMessage|wamid...\ndocumentMessage|wamid..." → [['tipo'=>'image','id'=>'wamid...'], ...]. Link http(s) também vale. */
function ws_comp_parse(string $txt): array {
    $out = [];
    if (preg_match_all('/(image|document|video|sticker|audio)Message\|([A-Za-z0-9._:=\-]+)/', $txt, $m, PREG_SET_ORDER))
        foreach ($m as $x) $out[$x[2]] = ['tipo' => $x[1], 'id' => $x[2]];
    if (preg_match_all('#https?://[^\s"\'<>]+#', $txt, $u))
        foreach ($u[0] as $url) $out[$url] = ['tipo' => 'url', 'id' => $url];
    return array_values($out);
}

/** Acha o cliente: CPF (se veio) ou telefone do WhatsApp. Só devolve quando é UM cliente (titular com adicionais conta 1). */
function ws_comp_casar_cliente(PDO $db, string $tel, string $cpf): ?int {
    $cpf = preg_replace('/\D/', '', $cpf);
    if (strlen($cpf) === 11 || strlen($cpf) === 14) {
        $st = $db->prepare("SELECT id FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/',''),' ','')=? ORDER BY id LIMIT 2");
        $st->execute([$cpf]); $ids = $st->fetchAll(PDO::FETCH_COLUMN);
        if (count($ids) >= 1) return (int)$ids[0];
    }
    $n = preg_replace('/\D/', '', $tel);
    if (strlen($n) < 8) return null;
    $fim8 = substr($n, -8);
    $st = $db->prepare("SELECT id, celular, telefone FROM ws_cliente WHERE celular LIKE ? OR telefone LIKE ? ORDER BY id LIMIT 50");
    $like = '%' . substr($n, -4); $st->execute([$like, $like]);
    $ids = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c)
        foreach ([$c['celular'], $c['telefone']] as $f) if (substr(preg_replace('/\D/', '', (string)$f), -8) === $fim8) $ids[(int)$c['id']] = 1;
    if (count($ids) === 1) return (int)array_key_first($ids);
    /* (15/10, caso Célia de Albuquerque) titular e adicional com o MESMO celular são a MESMA conta: antes eram 2 achados e o comprovante ficava "não identificado". Todos do mesmo titular → fica o TITULAR (regra de ouro: titular e adicionais andam juntos). Pessoas de contas diferentes continuam ambíguas (null). */
    if (count($ids) > 1) {
        try {
            $tit = [];
            $q = $db->prepare("SELECT COALESCE(NULLIF(titular_id,0), id) FROM ws_cliente WHERE id=?");
            foreach (array_keys($ids) as $i) { $q->execute([$i]); $tit[(int)$q->fetchColumn()] = 1; }
            if (count($tit) === 1) return (int)array_key_first($tit);
        } catch (Throwable $e) {}
    }
    return null;
}

/** Recebe o que o robô mandou. Grava, casa o cliente e tenta baixar. Retorna o ID da linha. */
function ws_comp_receber(PDO $db, array $d): int {
    $txt  = (string)($d['comprovante'] ?? '');
    $msgs = ws_comp_parse($txt);
    $jid  = substr(trim((string)($d['remoteJid'] ?? '')), 0, 60);
    $tel  = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), 0, 20);
    $cpf  = substr(preg_replace('/\D/', '', (string)($d['cpf'] ?? '')), 0, 20);
    $cli  = ws_comp_casar_cliente($db, $tel, $cpf);
    $st = $db->prepare("INSERT INTO ws_comprovante (telefone, jid, nome_whats, nome_informado, cpf, cliente_id, mensagens, erro) VALUES (?,?,?,?,?,?,?,?)");
    $st->execute([$tel ?: null, $jid ?: null, mb_substr(trim((string)($d['pushName'] ?? '')), 0, 120) ?: null,
        mb_substr(trim((string)($d['nome_informado'] ?? '')), 0, 160) ?: null, $cpf ?: null, $cli,
        json_encode($msgs, JSON_UNESCAPED_SLASHES), $msgs ? null : 'o robô não mandou arquivo (texto: ' . mb_substr($txt, 0, 120) . ')']);
    $id = (int)$db->lastInsertId();
    if ($msgs) ws_comp_baixar($db, $id);
    else $db->prepare("UPDATE ws_comprovante SET baixado='sem' WHERE id=?")->execute([$id]);
    return $id;
}

/** GET simples (o arquivo do S3 da Evolution). */
function ws_comp_get(string $url, array $headers = []): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_TIMEOUT => 30, CURLOPT_HTTPHEADER => $headers]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $mime = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    return [$code, $raw === false ? '' : (string)$raw, $mime];
}

/** Busca o arquivo de UMA mensagem na Evolution (ordem no topo do arquivo). [bytes, mime, nome] ou [null, erro]. */
function ws_comp_midia(array $m, array $c): array {
    if ($m['tipo'] === 'url') {
        [$code, $b, $mime] = ws_comp_get($m['id']);
        return ($code === 200 && strlen($b) > 100) ? [$b, $mime, basename(parse_url($m['id'], PHP_URL_PATH) ?: 'arquivo')] : [null, "link respondeu $code"];
    }
    // entregue pelo webhook da Evolution (02/10/2026 — no número oficial da Meta é o único caminho)
    if (function_exists('ws_midia_pegar') && ($mw = ws_midia_pegar((string)$m['id'], 0))) return [$mw[0], $mw[1], $mw[2] ?: 'comprovante'];
    $base = rtrim((string)($c['url'] ?? ''), '/');
    if ($base === '' || ($c['apikey'] ?? '') === '') return [null, 'Evolution não configurada em Mensagens → Servidor'];
    $h = ['Content-Type: application/json', 'apikey: ' . $c['apikey']];
    $inst = function_exists('ws_wa_instancias') ? ws_wa_instancias($c) : [(string)($c['instance'] ?? '')];
    foreach (preg_split('/[,;\s]+/', (string)($c['instancias_comum'] ?? '')) ?: [] as $i) if (trim($i) !== '' && !in_array(trim($i), $inst, true)) $inst[] = trim($i);
    $erros = [];
    foreach ($inst as $i) {
        if ($i === '') continue;
        $h = ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)$i)];   // token próprio da instância, se houver (14/10)
        $mime = ''; $nome = '';
        // a) a mensagem guardada na Evolution
        [$code, $resp] = ws_wa_http("$base/chat/findMessages/" . rawurlencode($i), $h, ['where' => ['key' => ['id' => $m['id']]]]);
        $recs = is_array($resp) ? ($resp['messages']['records'] ?? ($resp['records'] ?? [])) : [];
        foreach ((array)$recs as $r) {
            if (!is_array($r) || (($r['key']['id'] ?? '') !== $m['id'])) continue;
            $msg = (array)($r['message'] ?? []);
            foreach (['imageMessage', 'documentMessage', 'videoMessage', 'stickerMessage', 'documentWithCaptionMessage'] as $k)
                if (!empty($msg[$k])) {
                    $x = $k === 'documentWithCaptionMessage' ? (array)($msg[$k]['message']['documentMessage'] ?? []) : (array)$msg[$k];
                    $mime = (string)($x['mimetype'] ?? ''); $nome = (string)($x['fileName'] ?? '');
                }
            if (!empty($msg['base64'])) { $b = base64_decode((string)$msg['base64'], true); if ($b !== false && strlen($b) > 100) return [$b, $mime, $nome]; }
            if (!empty($msg['mediaUrl'])) {
                [$gc, $b, $gm] = ws_comp_get((string)$msg['mediaUrl']);
                if ($gc === 200 && strlen($b) > 100) return [$b, $mime ?: $gm, $nome];
                $erros[] = "$i: mediaUrl respondeu $gc";
            }
        }
        // b) pedir o arquivo pelo ID
        [$code, $resp, $raw] = ws_wa_http("$base/chat/getBase64FromMediaMessage/" . rawurlencode($i), $h,
            ['message' => ['key' => ['id' => $m['id']]], 'convertToMp4' => false]);
        if ($code >= 200 && $code < 300 && is_array($resp) && !empty($resp['base64'])) {
            $b = base64_decode((string)$resp['base64'], true);
            if ($b !== false && strlen($b) > 100) return [$b, (string)($resp['mimetype'] ?? $mime), (string)($resp['fileName'] ?? $nome)];
        }
        $erros[] = "$i: " . ($recs ? 'mensagem achada, arquivo não' : 'mensagem não achada') . " (base64 $code)";
    }
    return [null, mb_substr(implode(' · ', $erros) ?: 'nenhuma instância', 0, 250)];
}

/** Baixa o que ainda falta de UM comprovante. Retorna true quando todos os arquivos estão salvos. */
function ws_comp_baixar(PDO $db, int $id): bool {
    if (!function_exists('ws_wa_config') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
    $st = $db->prepare("SELECT * FROM ws_comprovante WHERE id=?"); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
    if (!$r) return false;
    $msgs = json_decode((string)$r['mensagens'], true) ?: [];
    $arqs = json_decode((string)$r['arquivos'], true) ?: [];
    if (!$msgs) return false;
    $c = ws_wa_config(); $erro = '';
    $sub = date('Y-m', strtotime((string)$r['criado_em']) ?: time());
    $dir = ws_comp_dir() . '/' . $sub; if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif', 'application/pdf' => 'pdf', 'video/mp4' => 'mp4'];
    foreach ($msgs as $n => $m) {
        if (isset($arqs[$n])) continue;
        [$b, $mime, $nome] = ws_comp_midia($m, $c) + [null, '', ''];
        if ($b === null) { $erro = (string)$mime; continue; }
        if (strlen($b) > 20 * 1024 * 1024) { $erro = 'arquivo maior que 20 MB'; continue; }
        // o tipo real vem dos bytes (o que a Evolution diz pode faltar)
        if (function_exists('finfo_open')) { $fi = finfo_open(FILEINFO_MIME_TYPE); $real = (string)finfo_buffer($fi, $b); finfo_close($fi); if ($real !== '') $mime = $real; }
        $mime = strtolower(trim(explode(';', (string)$mime)[0])) ?: 'application/octet-stream';
        $arq = $sub . '/' . $id . '_' . $n . '_' . bin2hex(random_bytes(4)) . '.' . ($ext[$mime] ?? 'bin');
        if (@file_put_contents(ws_comp_dir() . '/' . $arq, $b) === false) { $erro = 'sem permissão de gravar em uploads/comprovantes'; continue; }
        // sha1 = impressão digital do arquivo: o MESMO comprovante mandado de novo (golpe comum: reaproveitar um
        // comprovante antigo ou de outra pessoa) é apontado na tela — ws_comp_repetidos().
        $arqs[$n] = ['arquivo' => $arq, 'mime' => $mime, 'nome' => mb_substr((string)$nome, 0, 120), 'tam' => strlen($b), 'sha1' => sha1($b)];
    }
    $tudo = count($arqs) >= count($msgs);
    $db->prepare("UPDATE ws_comprovante SET arquivos=?, baixado=?, tentativas=tentativas+1, erro=? WHERE id=?")
       ->execute([json_encode($arqs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $tudo ? 'ok' : ($arqs ? 'parcial' : 'pendente'), $tudo ? null : mb_substr($erro, 0, 255), $id]);
    if ($tudo) { try { ws_comp_selar($db, $id); ws_comp_reenvio_marcar($db, $id); } catch (Throwable $e) {} }   // lê e sela na chegada (selo antifraude) + reenvio
    return $tudo;
}

/* ===== REENVIO PELO OUTRO WHATSAPP (09/10/2026, pedido do provedor) =====
   O cliente manda o MESMO comprovante nas duas instâncias (Wellnet-01 e Wellnet-02). Antes viravam 2 cartões e os dois
   apareciam como "POSSÍVEL FRAUDE" (arquivo repetido). Agora: mesmo comprovante (mesmo ID do PIX ou mesmo arquivo) do
   MESMO cliente/telefone que já está registrado e não foi recusado = REENVIO. A cópia nova é recusada sozinha
   ("Reenvio do #X") e o robô responde, pela conversa onde o cliente mandou, que o comprovante já foi recebido e está
   em análise para a baixa (ou que a baixa já foi feita). De OUTRO cliente/telefone continua sendo possível fraude. */
function ws_comp_reenvio_original(PDO $db, int $id): ?array {
    $q = $db->prepare("SELECT c.*, s.duplicado_de FROM ws_comprovante c LEFT JOIN ws_pix_selo s ON s.comprovante_id=c.id WHERE c.id=?"); $q->execute([$id]);
    $c = $q->fetch(PDO::FETCH_ASSOC); if (!$c) return null;
    $cands = [];
    if (!empty($c['duplicado_de'])) {   // mesmo ID do PIX (ou mesmo arquivo) já selado antes
        $o = $db->prepare("SELECT s2.comprovante_id FROM ws_pix_selo s1 JOIN ws_pix_selo s2 ON s2.chave=s1.chave WHERE s1.id=? AND s2.comprovante_id<>?");
        $o->execute([(int)$c['duplicado_de'], $id]); $cands = array_map('intval', $o->fetchAll(PDO::FETCH_COLUMN));
    }
    foreach ((json_decode((string)$c['arquivos'], true) ?: []) as $a) if (!empty($a['sha1'])) {   // mesmo arquivo
        $o = $db->prepare("SELECT id FROM ws_comprovante WHERE id<>? AND arquivos LIKE ? AND criado_em > NOW() - INTERVAL 60 DAY");
        $o->execute([$id, '%' . $a['sha1'] . '%']); $cands = array_merge($cands, array_map('intval', $o->fetchAll(PDO::FETCH_COLUMN)));
    }
    $cands = array_values(array_unique(array_filter($cands))); sort($cands);
    if (!$cands) return null;
    $fim8 = fn($t) => substr(preg_replace('/\D/', '', (string)$t), -8);
    $in = implode(',', $cands);
    foreach ($db->query("SELECT * FROM ws_comprovante WHERE id IN ($in) AND status<>'recusado' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $o) {
        $mesmoTel = strlen($fim8($c['telefone'])) === 8 && $fim8($c['telefone']) === $fim8($o['telefone']);
        $mesmoCli = (int)$c['cliente_id'] > 0 && (int)$c['cliente_id'] === (int)$o['cliente_id'];
        if ((int)$o['id'] < $id) return $o + ['_mesmo' => ($mesmoTel || $mesmoCli)];   // 09/10/2026: de OUTRO número também é barrado (pedido do provedor)
    }
    return null;
}
/** Marca a cópia como reenvio (recusada sozinha). Devolve o comprovante original ou null. */
function ws_comp_reenvio_marcar(PDO $db, int $id): ?array {
    $st = $db->prepare("SELECT status, obs FROM ws_comprovante WHERE id=?"); $st->execute([$id]); $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c || $c['status'] !== 'novo') return null;
    $o = ws_comp_reenvio_original($db, $id); if (!$o) return null;
    $db->prepare("UPDATE ws_comprovante SET status='recusado', obs=?, conferido_por='Automático (reenvio)', conferido_em=NOW() WHERE id=? AND status='novo'")
       ->execute([empty($o['_mesmo']) ? 'Reenvio do comprovante #' . (int)$o['id'] . ' (mesmo comprovante enviado de novo por OUTRO número — barrado no atendimento)'
                                      : 'Reenvio do comprovante #' . (int)$o['id'] . ' (mesmo comprovante mandado de novo, talvez pelo outro WhatsApp)', $id]);
    return $o;
}
/** Mensagem ao cliente quando o comprovante $id é reenvio. '' = não é reenvio. */
function ws_comp_reenvio_msg(PDO $db, int $id): string {
    $st = $db->prepare("SELECT obs FROM ws_comprovante WHERE id=? AND status='recusado' AND conferido_por='Automático (reenvio)'"); $st->execute([$id]);
    $obs = (string)$st->fetchColumn(); if (!preg_match('/#(\d+)/', $obs, $m)) return '';
    $q = $db->prepare("SELECT status, criado_em FROM ws_comprovante WHERE id=?"); $q->execute([(int)$m[1]]); $o = $q->fetch(PDO::FETCH_ASSOC); if (!$o) return '';
    $quando = date('d/m', strtotime((string)$o['criado_em'])) . ' às ' . date('H:i', strtotime((string)$o['criado_em']));
    if (strpos($obs, 'OUTRO número') !== false)   // mesmo comprovante vindo de outro telefone: barra e orienta
        return "⚠️ Este comprovante já foi enviado antes ({$quando})" . (in_array($o['status'], ['conferido', 'baixado'], true) ? ' e a baixa já foi feita' : ' e está em análise pelo provedor — é só aguardar a baixa') . ". Não precisa enviar de novo. Se este é OUTRO pagamento, envie o comprovante dele.";
    /* 12/10/2026: ✅ sempre no COMEÇO da frase (como o 🔏) e o aviso abre igual aos outros ("✅ Comprovante recebido.") */
    if (in_array($o['status'], ['conferido', 'baixado'], true)) return "✅ Comprovante recebido.\n\n🔏 Este comprovante já foi recebido ({$quando}) e a baixa já foi feita.\n\n✅ Não precisa enviar de novo.\n\nObrigado.🤝";
    return "✅ Comprovante recebido.\n\n🔏 Este comprovante já foi recebido ({$quando}) e está em análise pelo provedor para o processamento da baixa.\n\n✅ Não precisa enviar de novo — assim que for conferido, você recebe a confirmação.\n\nObrigado.🤝";
}

/** Tenta de novo os que ficaram sem arquivo (até 10 vezes cada, só dos últimos 7 dias). Chamado ao abrir a tela. */
function ws_comp_pendentes_run(PDO $db, int $max = 5): void {
    try {
        $ids = $db->query("SELECT id FROM ws_comprovante WHERE baixado IN ('pendente','parcial') AND tentativas < 10
                            AND criado_em > NOW() - INTERVAL 7 DAY ORDER BY id DESC LIMIT " . (int)$max)->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $i) ws_comp_baixar($db, (int)$i);
    } catch (Throwable $e) {}
}

/* COMPROVANTE FALSO — o que dá e o que não dá para saber (24/09/2026).
 * A imagem sozinha NÃO prova pagamento: qualquer um edita um print. Prova é o dinheiro no extrato da conta.
 * Por isso a tela avisa "confira no extrato antes da baixa", e a baixa é sempre de um operador.
 * O que o sistema aponta sozinho: o MESMO arquivo já mandado em outro comprovante (mesmo sha1), que é o golpe
 * mais comum (reaproveitar comprovante antigo ou de outra pessoa). Conferência automática de verdade só com a
 * API PIX do banco (consulta dos PIX recebidos) ou com o extrato importado em Conciliação (OFX). */
/** [id => [ids de OUTROS comprovantes com arquivo idêntico]] para as linhas da tela. */
function ws_comp_repetidos(PDO $db, array $rows): array {
    $hs = []; $info = [];
    foreach ($rows as $r) { $info[(int)$r['id']] = $r; foreach ((json_decode((string)$r['arquivos'], true) ?: []) as $a) if (!empty($a['sha1'])) $hs[$a['sha1']][] = (int)$r['id']; }
    if (!$hs) return [];
    $todos = [];
    // procura em TODOS os comprovantes (não só os da página): o antigo pode estar em "Conferidos" de meses atrás
    $st = $db->query("SELECT id, arquivos, status, telefone, cliente_id FROM ws_comprovante WHERE arquivos LIKE '%sha1%' ORDER BY id DESC LIMIT 5000");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) { $info[(int)$x['id']] = $x; foreach ((json_decode((string)$x['arquivos'], true) ?: []) as $a)
        if (!empty($a['sha1']) && isset($hs[$a['sha1']])) $todos[$a['sha1']][(int)$x['id']] = 1; }
    /* 09/10/2026: cópia RECUSADA não conta (o provedor já descartou o reenvio), e o MESMO cliente/telefone mandando de novo
       o comprovante que ainda não teve baixa é só reenvio — não é golpe. Continua apontando: cópia já conferida (baixa feita)
       ou cópia vinda de outro cliente/telefone. */
    $mesmo = function (int $a, int $b) use ($info): bool {
        $x = $info[$a] ?? []; $y = $info[$b] ?? [];
        $ta = substr(preg_replace('/\D/', '', (string)($x['telefone'] ?? '')), -8); $tb = substr(preg_replace('/\D/', '', (string)($y['telefone'] ?? '')), -8);
        return (strlen($ta) === 8 && $ta === $tb) || ((int)($x['cliente_id'] ?? 0) > 0 && (int)($x['cliente_id'] ?? 0) === (int)($y['cliente_id'] ?? 0));
    };
    $out = [];
    foreach ($hs as $h => $ids) foreach ($ids as $id) {
        if ((string)($info[$id]['status'] ?? '') === 'recusado') continue;
        $outros = [];
        foreach (array_diff(array_keys($todos[$h] ?? []), [$id]) as $o) {
            $so = (string)($info[$o]['status'] ?? '');
            if ($so === 'recusado') continue;
            if (!in_array($so, ['conferido', 'baixado'], true)) continue;   // 09/10/2026: só é golpe se a outra cópia JÁ foi aceita/baixada; antes disso o selo impede baixa dupla
            $outros[] = $o;
        }
        if ($outros) $out[$id] = array_values(array_unique(array_merge($out[$id] ?? [], $outros)));
    }
    return $out;
}

/** BAIXA POR OUTRO MEIO (14/10/2026): comprovante ainda "novo" cujo título JÁ foi baixado direto no sistema ou pela API (e o recibo já foi enviado) não precisa mais de conferência: sai de "Para conferir" e fica só
 *  em "Todos" (status 'baixado', com o título ligado). Conservador: mesmo cliente, título pago no dia do comprovante (ou na véspera: a baixa automática do PIX pode vir antes do arquivo), recibo já enviado e — quando o valor do PIX foi lido — valor igual ao do título. Roda no máx. 1x/min. */
function ws_comp_baixados_outro_meio(PDO $db): int {
    $arq = WS_CACHE . '/comp_baixado_outro.ts'; if (is_file($arq) && time() - filemtime($arq) < 60) return 0; @touch($arq);
    try {
        /* (08/11/2026, caso Jamylle Kessia: PIX de R$ 73,50 = R$ 70,00 + encargos do atraso; a baixa foi feita direto no cadastro por R$ 70,00 e o comprovante ficou em "Para conferir")
           valor do PIX = valor do título MAIS ENCARGOS (até 15% acima) também fecha — só se o título foi pago no MESMO dia e DEPOIS de o comprovante chegar; a diferença fica anotada. */
        $st = $db->query("SELECT c.id, c.criado_em, f.id fid, f.data_pagamento, f.recibo_em, sl.valor pix_valor, COALESCE(f.valor_pago,f.valor) baixa_valor
                          FROM ws_comprovante c
                          LEFT JOIN ws_pix_selo sl ON sl.comprovante_id=c.id
                          JOIN ws_fatura f ON f.cliente_id=c.cliente_id AND f.status='pago' AND f.recibo_em IS NOT NULL AND f.recibo_em >= c.criado_em - INTERVAL 1 DAY
                               AND f.data_pagamento >= DATE(c.criado_em) - INTERVAL 1 DAY AND (sl.valor IS NOT NULL OR f.recibo_em >= c.criado_em - INTERVAL 1 HOUR)
                               AND f.id = (SELECT f2.id FROM ws_fatura f2 WHERE f2.cliente_id=c.cliente_id AND f2.status='pago' AND f2.recibo_em IS NOT NULL AND f2.recibo_em >= c.criado_em - INTERVAL 1 DAY AND f2.data_pagamento >= DATE(c.criado_em) - INTERVAL 1 DAY
                                           AND (sl.valor IS NULL OR ABS(COALESCE(f2.valor_pago,f2.valor)-sl.valor)<=0.01 OR ABS(f2.valor-sl.valor)<=0.01
                                                OR (f2.data_pagamento = DATE(c.criado_em) AND f2.recibo_em >= c.criado_em AND sl.valor >= f2.valor - 0.01 AND sl.valor <= f2.valor * 1.15 + 0.01))
                                           ORDER BY f2.recibo_em LIMIT 1)
                          WHERE c.status='novo' AND c.cliente_id IS NOT NULL AND c.criado_em >= NOW() - INTERVAL 30 DAY");
        $n = 0;
        $rs = fn($v) => 'R$ ' . number_format((float)$v, 2, ',', '.');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $dif = ($r['pix_valor'] !== null && abs((float)$r['pix_valor'] - (float)$r['baixa_valor']) >= 0.01) ? ' PIX de ' . $rs($r['pix_valor']) . ' x baixa de ' . $rs($r['baixa_valor']) . ' (encargos).' : '';
            $db->prepare("UPDATE ws_comprovante SET status='baixado', fatura_id=?, conferido_por='Automático (baixa por outro meio)', conferido_em=NOW(), obs=? WHERE id=? AND status='novo'")
               ->execute([(int)$r['fid'], mb_substr('Título #' . (int)$r['fid'] . ' baixado por outro meio em ' . date('d/m/Y', strtotime((string)$r['data_pagamento'])) . ' — recibo já enviado.' . $dif, 0, 255), (int)$r['id']]);
            $n++;
        }
        return $n;
    } catch (Throwable $e) { return 0; }
}
/** Quantos comprovantes NOVOS (não conferidos) — número do menu/aba. */
function ws_comp_novos(PDO $db): int {
    ws_comp_baixados_outro_meio($db);
    try { return (int)$db->query("SELECT COUNT(*) FROM ws_comprovante WHERE status='novo'")->fetchColumn(); } catch (Throwable $e) { return 0; }
}

/* =====================================================================================================================
 * SELO ANTIFRAUDE (30/09/2026, pedido do provedor)
 *
 * Todo comprovante que chega pelo robô é LIDO (PDF: pdftotext; print/foto: OCR tesseract em português) e dele saem o
 * ID DA TRANSAÇÃO PIX (E2E — "E" + 31 caracteres, único no país para cada PIX), o valor, a data e o pagador. Com isso
 * o comprovante ganha um SELO (ex.: WS-7K3Q-92XD) gravado em ws_pix_selo — tabela PERMANENTE: excluir o comprovante
 * da tela NÃO apaga o selo, senão o golpe de reaproveitar comprovante antigo voltaria a passar.
 *   - Chave do selo = E2E. Sem E2E legível, a impressão digital do arquivo (SHA1) — pega o mesmo arquivo reenviado.
 *   - Mesma chave já registrada = comprovante REPETIDO: ele é marcado (duplicado_de) e a tela/robô avisam.
 *   - Na BAIXA (financeiro.php, baixa_manual com comprovante_id) o selo é conferido: repetido ou já usado em outro
 *     título = baixa RECUSADA com "⚠️ POSSÍVEL FRAUDE" e o histórico de onde ele foi usado. Baixa feita = selo
 *     atrelado ao cliente/título, com quem e quando.
 * Limite honesto: o selo pega comprovante REPETIDO, não comprovante INVENTADO (print editado com E2E que nunca
 * existiu) — esse só a conferência no extrato/API PIX do banco pega. Por isso a tela continua pedindo o extrato.
 * Sem pdftotext/tesseract no servidor, o selo usa só o SHA1 do arquivo e a tela avisa o que instalar.
 * ================================================================================================================== */

function ws_comp_selo_sql(): string {
    return "CREATE TABLE IF NOT EXISTS ws_pix_selo (
        id INT AUTO_INCREMENT PRIMARY KEY,
        comprovante_id INT NOT NULL,
        chave VARCHAR(60) NOT NULL,
        e2e VARCHAR(40) DEFAULT NULL,
        selo VARCHAR(20) NOT NULL,
        duplicado_de INT DEFAULT NULL,
        valor DECIMAL(10,2) DEFAULT NULL,
        data_pix VARCHAR(20) DEFAULT NULL,
        pagador VARCHAR(120) DEFAULT NULL,
        leitura VARCHAR(12) DEFAULT NULL,
        cliente_id INT DEFAULT NULL,
        fatura_id INT DEFAULT NULL,
        usado_em DATETIME DEFAULT NULL,
        usado_por VARCHAR(80) DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comp (comprovante_id), UNIQUE KEY uq_selo (selo), INDEX idx_chave (chave)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
}

/** Ferramentas de leitura disponíveis no servidor. */
function ws_comp_leitores(): array {
    static $r = null;
    if ($r === null) $r = ['pdf' => trim((string)@shell_exec('command -v pdftotext 2>/dev/null')) !== '',
                           'ocr' => trim((string)@shell_exec('command -v tesseract 2>/dev/null')) !== ''];
    return $r;
}

/** Texto do arquivo (PDF ou imagem). '' se não deu para ler. */
function ws_comp_ler(string $abs, string $mime): string {
    $l = ws_comp_leitores(); $o = [];
    if ($mime === 'application/pdf' && $l['pdf']) {
        @exec('timeout 20 pdftotext -layout ' . escapeshellarg($abs) . ' - 2>/dev/null', $o);
        /* PDF SÓ DE IMAGEM (08/10/2026): comprovante que o app do banco "imprime" como figura não tem texto — o pdftotext volta vazio e o robô
           achava que não era comprovante (o cliente mandou o PDF e ele nunca apareceu em Comprovantes PIX). Sem texto: rasteriza as 2 primeiras
           páginas e lê por OCR. */
        if (mb_strlen(trim(implode("
", $o))) < 20 && $l['ocr'] && trim((string)@shell_exec('command -v pdftoppm 2>/dev/null')) !== '') {
            $base = tempnam(sys_get_temp_dir(), 'wsp'); @unlink($base); $o = [];
            @exec('timeout 25 pdftoppm -r 150 -f 1 -l 2 -png ' . escapeshellarg($abs) . ' ' . escapeshellarg($base) . ' 2>/dev/null');
            foreach (glob($base . '*.png') ?: [] as $png) { @exec('timeout 25 tesseract ' . escapeshellarg($png) . ' stdout -l por --psm 3 2>/dev/null', $o); @unlink($png); }
        }
    }
    elseif (strpos($mime, 'image/') === 0 && $l['ocr']) @exec('timeout 25 tesseract ' . escapeshellarg($abs) . ' stdout -l por --psm 3 2>/dev/null', $o);
    return mb_substr(implode("\n", $o), 0, 20000);
}

/** Do texto lido: E2E, valor, data e pagador (o que der para achar). */
/** PAGAMENTO DE BOLETO (10/10/2026): comprovante de boleto (Mercado Pago, bancos…) traz "Código de barras" com 44 dígitos; deles saem o VALOR exato
 *  (posições 10-19, em centavos — o OCR perde os centavos pequenos do "R$ 103⁵⁰") e o VENCIMENTO (fator, com o recomeço de 22/02/2025). null = não é boleto. */
function ws_comp_boleto_info(string $txt): ?array {
    // "Código de barras" com ou sem dois-pontos; 44 dígitos (código de barras) OU 47 (linha digitável, escrita em grupos)
    $achou = null;
    if (preg_match('/c[óo]digo de barras\s*:?\s*([\d\s.\-]{44,90})/iu', $txt, $m)) $achou = $m[1];
    /* SEM RÓTULO (qualquer banco): a LINHA DIGITÁVEL de boleto tem forma fixa — 5.5 5.6 5.6 1 14 dígitos — e o texto fala em boleto/cobrança/vencimento; vale mesmo se o rótulo vier diferente ("Linha digitável", "Cód. de barras", sem rótulo). */
    if ($achou === null && preg_match('/boleto|cobran[cç]a|vencimento/iu', $txt) && preg_match('/(?<!\d)(\d{5}[.\s]?\d{5}\s+\d{5}[.\s]?\d{6}\s+\d{5}[.\s]?\d{6}\s+\d\s+\d{14})(?!\d)/', $txt, $ml)) $achou = $ml[1];
    if ($achou === null) return null;
    $d = preg_replace('/\D/', '', $achou); $n = strlen($d); if ($n < 44) return null;
    if ($n === 47) { $fator = (int)substr($d, 33, 4); $cent = (int)substr($d, 37, 10); $d = substr($d, 0, 47); }   // linha digitável: fator+valor são os últimos 14
    else { $d = substr($d, 0, 44); $cent = (int)substr($d, 9, 10); $fator = (int)substr($d, 5, 4); }
    $venc = null;
    foreach ([strtotime('1997-10-07 +' . $fator . ' days'), strtotime('2025-02-22 +' . ($fator - 1000) . ' days')] as $t) if ($t && abs($t - time()) < 500 * 86400) { $venc = date('Y-m-d', $t); break; }
    // "Pagamento agendado … Data do débito: 13/10/2026": o dinheiro AINDA NÃO saiu da conta do cliente
    $agend = null;
    if (preg_match('/pagamento agendado|agendamento/iu', $txt) && preg_match('/data do d[eé]bito\s*:?\s*(\d{2})\/(\d{2})\/(\d{4})/iu', $txt, $md)) { $dt = $md[3] . '-' . $md[2] . '-' . $md[1]; if ($dt > date('Y-m-d')) $agend = $dt; }
    return ['barras' => $d, 'valor' => $cent > 0 ? round($cent / 100, 2) : null, 'venc' => $venc, 'agendado' => $agend];
}
function ws_comp_extrair(string $txt): array {
    $out = ['e2e' => null, 'valor' => null, 'data' => null, 'pagador' => null];
    // OCR quebra o E2E em pedaços e troca O por 0: junta tudo e procura E + 8 dígitos (ISPB) + data AAAAMMDDhhmm + 11
    /* 09/10/2026: o ID do PIX diferencia maiúsculas de minúsculas ("…7katvO4uDLN" no Mercado Pago). Antes tudo virava MAIÚSCULO e O→0,
       e o banco respondia "não existe" (fraude falsa). Agora só a parte de NÚMEROS (banco + data/hora) troca O por 0; o final fica como lido. */
    $compacto = preg_replace('/\s+/', '', $txt);
    if (preg_match_all('/[Ee]([\dOo]{8})(20[\dOo]{10})([A-Za-z0-9]{11})/', $compacto, $mm, PREG_SET_ORDER))
        foreach ($mm as $m) { $dg = strtr($m[1] . $m[2], ['O' => '0', 'o' => '0']);
            if (preg_match('/^\d{8}20\d{2}(?:0[1-9]|1[0-2])(?:[0-2]\d|3[01])(?:[01]\d|2[0-3])[0-5]\d$/', $dg)) { $out['e2e'] = 'E' . $dg . $m[3]; break; } }
    if (preg_match('/R[\$S]\s*([\d.]{1,9},\d{2})/u', $txt, $v)) $out['valor'] = (float)str_replace(',', '.', str_replace('.', '', $v[1]));
    elseif (preg_match('/R[\$S]\s*(\d{1,3}(?:\.\d{3})+|\d{1,7})(?![\d,])/u', $txt, $v)) {   // "R$ 70" (Mercado Pago, sem centavos)
        $out['valor'] = (float)str_replace('.', '', $v[1]);
        /* Mercado Pago escreve os centavos pequenos e no alto ("R$ 74⁵⁰") e o OCR junta: "R$ 7450". Número sem ponto/vírgula com 4+
           algarismos é lido como reais + centavos (74,50) — valor de mensalidade acima de R$ 1.000 sem separador não existe nesse layout. */
        if (strpos($v[1], '.') === false && strlen($v[1]) >= 4) $out['valor'] = round((float)$v[1] / 100, 2);
    }
    $boI = ws_comp_boleto_info($txt);   // boleto: o código de barras traz o valor exato (centavos pequenos o OCR perde)
    if ($boI && $boI['valor'] && ($out['valor'] === null || floor($out['valor']) == floor($boI['valor']))) $out['valor'] = $boI['valor'];
    if (preg_match('/\b(\d{2}\/\d{2}\/\d{4})(?:[^\d\n]{0,8}(\d{2}:\d{2}))?/', $txt, $d)) $out['data'] = $d[1] . (isset($d[2]) ? ' ' . $d[2] : '');
    elseif (preg_match('/\b(\d{1,2})\s*(?:\/|de)?\s*(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-zç]*\.?\s*(?:\/|de)?\s*(20\d{2})(?:[^\d\n]{0,8}(\d{2}:\d{2}))?/iu', $txt, $d)) {   // "8/outubro/2026 às 15:41"
        $mes = array_search(mb_strtolower(mb_substr($d[2], 0, 3)), ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']) + 1;
        $out['data'] = sprintf('%02d/%02d/%s', (int)$d[1], $mes, $d[3]) . (!empty($d[4]) ? ' ' . $d[4] : '');
    }
    /* 09/10/2026: o título "Origem e destino" / "Dados de origem" não é o rótulo do pagador (virava "Quem pagou: e destino"). O rótulo
       ignora maiúsculas, mas o NOME tem que começar com maiúscula e não pode ser palavra de layout.
       31/10/2026: filtro único e mais forte — "\bde" (ex.: "INSTITUIÇÃO DE PAGAMENTO S.A.") e rótulos de cabeçalho ("Data do pagamento",
       "Sobre a transação") viravam "nome" por engano (casos reais: Stone → "PAGAMENTO S.A." virou pagador; Inter → "Data do pagamento"
       virou pagador). Lista única usada nos dois pontos desta função. */
    /* 31/10/2026: "s.a.$" tinha que achar só a instituição ("Banco X S.A."); sem limite de palavra, qualquer nome terminado em "-osa"
       (Barbosa, Sousa…) caía nessa regra por engano (olhar antes de letra ou início do texto). */
    $naoNome = '/(pagamentos?|sobre a transa[cç][aã]o|hor[aá]rio|\bbco\b|banco|(?<![A-Za-zÀ-ÿ])s\.?\s?a\.?\s*$|mercado pago|nubank|pagbank|picpay|ita[uú]|bradesco|caixa|santander|inter\b|sicoob|sicredi|c6|institui|ag[eê]ncia|conta|ocorreu|quem (pagou|recebeu)|id d[ae]|pix enviado|cpf|cnpj|transa[cç][aã]o|e destino|destino|dados|data do|valor|^nome$)/iu';
    if (preg_match_all('/(?i:pagador|quem pagou|pessoa que pagou|quem fez a transa[cç][aã]o|empresa\s*:|origem|\bde)\s*[:\-]?\s*\n?\s*(?:Nome\s*:?\s*\n?\s*)?([A-ZÀ-Ú][A-Za-zÀ-ú .]{5,60})/u', $txt, $pp, PREG_SET_ORDER))
        foreach ($pp as $p) { $nm = trim(preg_replace('/^(?:De|Para)\s+(?=[A-ZÀ-Ú])/u', '', trim(preg_split('/\s{2,}|\s+(?:CPF|CNPJ|Institui|Ag[eê]ncia|Conta|Banco)\b/u', $p[1])[0])));
            if (mb_strlen($nm) >= 5 && !preg_match('/^(e destino|destino|dados|nome|cpf|cnpj|conta|ag[eê]ncia|institui|banco|pix|valor|data)\b/iu', $nm) && !preg_match($naoNome, $nm) && preg_match('/\s/u', $nm)) { $out['pagador'] = $nm; break; } }
    /* LAYOUT COM RÓTULOS SEPARADOS DOS VALORES (Neon, Inter e outros, 10-31/10/2026): o OCR devolve "Quem pagou / Nome / CPF / Instituição /
       Quem recebeu / Nome / CPF / Instituição" (ou a ordem inversa) todos juntos, e só depois os valores, NA MESMA ORDEM dos rótulos — o 1º
       nome de pessoa que aparece depois dos rótulos é de quem o rótulo que veio PRIMEIRO fala (Neon: pagou primeiro; Inter: recebeu primeiro).
       Banco, rótulo e dado de conta não contam. Só considera texto A PARTIR do primeiro rótulo — nome de verdade nunca vem antes dele (era
       assim que "Data do pagamento", escrito no topo do recibo do Inter, virava pagador, 31/10/2026). */
    if (preg_match('/quem pagou/iu', $txt) && preg_match('/quem recebeu/iu', $txt)) {
        $pagAntes = $out['pagador'];
        $posPagou = mb_stripos($txt, 'quem pagou'); $posRecebeu = mb_stripos($txt, 'quem recebeu');
        $ordem = $posPagou < $posRecebeu ? ['pagador', 'recebedor'] : ['recebedor', 'pagador'];   // quem o rótulo de cima descreve
        $pIni = min($posPagou, $posRecebeu);
        $achados = [];
        foreach (preg_split('/\R/u', mb_substr($txt, $pIni)) as $ln) { $ln = trim($ln);
            /* OCR às vezes cola o rótulo "Nome" na mesma linha do valor ("Nome MAYARA NAYANNE BELO", 31/10/2026) — tira o rótulo antes de testar. */
            $lnSemRotulo = preg_replace('/^Nome\s*[:\-]?\s*(?=[A-ZÀ-Ú])/iu', '', $ln);
            if (preg_match('/^[A-ZÀ-Ú][A-Za-zÀ-ú\'.]+(?:\s+[A-Za-zÀ-ú\'.]+){1,6}$/u', $lnSemRotulo) && !preg_match($naoNome, $lnSemRotulo)) { $achados[] = $lnSemRotulo; if (count($achados) >= 2) break; } }
        $nm = isset($achados[0]) && $ordem[0] === 'pagador' ? $achados[0] : ($achados[1] ?? null);
        if ($nm !== null && ($pagAntes === null || ($nm !== $pagAntes && mb_substr($nm, -mb_strlen($pagAntes)) === $pagAntes))) $out['pagador'] = $nm;   // nome inteiro vence o pedaço que a regra do "de" pegou ("…DE TAL" → "TAL")
    }
    return $out;
}

function ws_comp_selo_novo(PDO $db): string {
    $abc = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';   // sem 0/O/1/I/L: lido e ditado sem confusão
    for ($t = 0; $t < 20; $t++) {
        $c = ''; for ($i = 0; $i < 8; $i++) $c .= $abc[random_int(0, strlen($abc) - 1)];
        $s = 'WS-' . substr($c, 0, 4) . '-' . substr($c, 4);
        $q = $db->prepare("SELECT 1 FROM ws_pix_selo WHERE selo=?"); $q->execute([$s]);
        if (!$q->fetchColumn()) return $s;
    }
    return 'WS-' . strtoupper(bin2hex(random_bytes(5)));
}

/** Lê e sela UM comprovante (idempotente: já selado devolve o registro). null = arquivo ainda não chegou. */
function ws_comp_selar(PDO $db, int $compId): ?array {
    $q = $db->prepare("SELECT * FROM ws_pix_selo WHERE comprovante_id=?"); $q->execute([$compId]);
    if ($r = $q->fetch(PDO::FETCH_ASSOC)) return $r;
    $st = $db->prepare("SELECT * FROM ws_comprovante WHERE id=?"); $st->execute([$compId]); $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c) return null;
    $arqs = json_decode((string)$c['arquivos'], true) ?: [];
    if (!$arqs) return null;
    $lido = ['e2e' => null, 'valor' => null, 'data' => null, 'pagador' => null]; $sha = ''; $leitura = 'arquivo';
    foreach ($arqs as $a) {
        if ($sha === '' && !empty($a['sha1'])) $sha = (string)$a['sha1'];
        $rel = (string)($a['arquivo'] ?? ''); $abs = ws_comp_dir() . '/' . $rel;
        if ($rel === '' || strpos($rel, '..') !== false || !is_file($abs)) continue;
        $x = ws_comp_extrair(ws_comp_ler($abs, (string)($a['mime'] ?? '')));
        foreach ($x as $k => $v) if ($lido[$k] === null && $v !== null) $lido[$k] = $v;
        if ($lido['e2e']) { $leitura = 'e2e'; break; }
    }
    if (!$lido['e2e'] && ($lido['valor'] || $lido['data'])) $leitura = 'parcial';
    $chave = $lido['e2e'] ?: ($sha !== '' ? 'SHA1:' . $sha : 'COMP:' . $compId);
    $dq = $db->prepare("SELECT id FROM ws_pix_selo WHERE chave=? AND duplicado_de IS NULL ORDER BY id LIMIT 1"); $dq->execute([$chave]);
    $orig = (int)$dq->fetchColumn() ?: null;
    try {
        $db->prepare("INSERT INTO ws_pix_selo (comprovante_id, chave, e2e, selo, duplicado_de, valor, data_pix, pagador, leitura, cliente_id) VALUES (?,?,?,?,?,?,?,?,?,?)")
           ->execute([$compId, $chave, $lido['e2e'], ws_comp_selo_novo($db), $orig, $lido['valor'], $lido['data'],
                      $lido['pagador'] ? mb_substr($lido['pagador'], 0, 120) : null, $leitura, $c['cliente_id'] ?: null]);
    } catch (Throwable $e) { /* corrida: outra requisição selou junto — o SELECT abaixo devolve o registro */ }
    /* CONFERÊNCIA NO BANCO (bb_pix.php, 01/10/2026): com a API PIX do Banco do Brasil ligada, o E2E lido é consultado
       na conta. Existe = pagamento confirmado (e já baixado se casar com um título). Não existe = comprovante falso. */
    if ($lido['e2e'] && !$orig && is_file(__DIR__ . '/bb_pix.php')) {
        require_once __DIR__ . '/bb_pix.php';
        $realE2e = null; $sb = ws_bb_conferir_comprovante($db, $lido['e2e'], $lido['valor'] !== null ? (float)$lido['valor'] : null, $realE2e);
        if ($sb !== '') $db->prepare("UPDATE ws_pix_selo SET leitura=? WHERE comprovante_id=?")->execute([$sb, $compId]);
        if ($sb === 'banco_ok' && $realE2e && $realE2e !== $lido['e2e']) {   // 09/10/2026: OCR leu o E2E com erro; o banco achou o real — o selo passa a usar o real
            $dq2 = $db->prepare("SELECT id FROM ws_pix_selo WHERE chave=? AND comprovante_id<>? AND duplicado_de IS NULL ORDER BY id LIMIT 1"); $dq2->execute([$realE2e, $compId]); $orig2 = (int)$dq2->fetchColumn();
            if ($orig2) $db->prepare("UPDATE ws_pix_selo SET e2e=?, duplicado_de=? WHERE comprovante_id=?")->execute([$realE2e, $orig2, $compId]);
            else $db->prepare("UPDATE ws_pix_selo SET e2e=?, chave=? WHERE comprovante_id=?")->execute([$realE2e, $realE2e, $compId]);
            $lido['e2e'] = $realE2e; if ($orig2) $sb = 'duplicado';
        }
        if ($sb === 'banco_ok') { try { ws_comp_auto_baixa($db, $compId, (string)$lido['e2e']); } catch (Throwable $e) { @error_log('[comp_auto_baixa] ' . $e->getMessage()); } }
    }
    $q->execute([$compId]);
    return $q->fetch(PDO::FETCH_ASSOC) ?: null;
}

/** Sela os comprovantes que já têm arquivo e ainda não foram lidos (cron, poucos por vez — OCR leva segundos). */
function ws_comp_selo_pendentes(PDO $db, int $max = 5): int {
    $n = 0;
    try {
        $ids = $db->query("SELECT c.id FROM ws_comprovante c LEFT JOIN ws_pix_selo s ON s.comprovante_id=c.id
                           WHERE s.id IS NULL AND c.baixado IN ('ok','parcial') ORDER BY c.id DESC LIMIT " . max(1, $max))->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $id) if (ws_comp_selar($db, (int)$id)) $n++;
    } catch (Throwable $e) {}
    return $n;
}

/** O "repetido" do selo ainda vale? (09/10/2026) Não vale quando o ORIGINAL foi RECUSADO e nunca usado em baixa:
 *  o provedor descartou a outra cópia, então esta passa a ser a que conta. */
function ws_comp_selo_dup_vale(PDO $db, array $s): bool {
    if (empty($s['duplicado_de'])) return false;
    try {
        $q = $db->prepare("SELECT o.usado_em, c.status FROM ws_pix_selo o LEFT JOIN ws_comprovante c ON c.id=o.comprovante_id WHERE o.id=?");
        $q->execute([(int)$s['duplicado_de']]); $o = $q->fetch(PDO::FETCH_ASSOC);
        if ($o && (string)$o['status'] === 'recusado' && empty($o['usado_em'])) return false;
    } catch (Throwable $e) {}
    return true;
}
/** Aviso de fraude do selo. '' = pode usar.
 *  - ORIGINAL (o 1º a chegar com aquela chave): liberado; só é barrado se já foi usado na baixa de OUTRO título.
 *  - REPETIDO (duplicado_de preenchido): sempre barrado, citando o original e onde ele foi usado. */
function ws_comp_selo_fraude(PDO $db, array $s, int $faturaDestino = 0): string {
    if (($s['leitura'] ?? '') === 'banco_nao')
        return '⚠️ POSSÍVEL FRAUDE — o PIX deste comprovante (ID ' . $s['e2e'] . ') NÃO existe na conta do Banco do Brasil: o dinheiro não entrou. Baixa não permitida.';
    /* 09/10/2026 — FRAUDE SÓ QUANDO É FRAUDE: o mesmo comprovante em 2 cartões (cliente mandou nos 2 WhatsApps, ou mandou de novo)
       NÃO é golpe enquanto nenhuma cópia foi usada. Vira POSSÍVEL FRAUDE quando alguma cópia (esta ou outra com o mesmo ID PIX/arquivo)
       JÁ foi usada numa baixa ou já foi conferida — aí apresentar de novo é reaproveitamento. Isso também impede a baixa dupla. */
    $ref = null;
    if (!empty($s['usado_em']) && (int)$s['fatura_id'] !== $faturaDestino) {
        $ref = $s;
        $c2 = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $c2->execute([(int)$s['cliente_id']]); $ref['cliente_nome'] = (string)$c2->fetchColumn();
    } elseif ((string)($s['chave'] ?? '') !== '' && strpos((string)$s['chave'], 'COMP:') !== 0) {
        $q = $db->prepare("SELECT s.*, c.status comp_status, cl.nome cliente_nome FROM ws_pix_selo s LEFT JOIN ws_comprovante c ON c.id=s.comprovante_id
                           LEFT JOIN ws_cliente cl ON cl.id=s.cliente_id WHERE s.chave=? AND s.comprovante_id<>? ORDER BY (s.usado_em IS NULL), s.id");
        $q->execute([(string)$s['chave'], (int)$s['comprovante_id']]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $o) {
            if (($o['comp_status'] ?? '') === 'recusado' && empty($o['usado_em'])) continue;   // cópia descartada pelo provedor
            if (!empty($o['usado_em']) || in_array(($o['comp_status'] ?? ''), ['conferido', 'baixado'], true)) { $ref = $o; break; }
        }
    }
    if (!$ref) return '';
    $chave = (string)$s['chave'];
    $id = strpos($chave, 'E') === 0 ? 'ID PIX ' . $chave : 'o mesmo arquivo';
    if ((int)$ref['comprovante_id'] === (int)$s['comprovante_id'])
        $msg = '⚠️ POSSÍVEL FRAUDE — este comprovante (' . $id . ') já foi usado';
    else $msg = '⚠️ POSSÍVEL FRAUDE — este comprovante (' . $id . ') já foi apresentado antes: selo ' . $ref['selo']
         . ', comprovante #' . (int)$ref['comprovante_id'] . ' em ' . date('d/m/Y H:i', strtotime((string)$ref['criado_em']));
    if (!empty($ref['usado_em']))
        $msg .= ' — usado na baixa do título #' . (int)$ref['fatura_id'] . (!empty($ref['cliente_nome']) ? ' de ' . $ref['cliente_nome'] : '')
              . ' em ' . date('d/m/Y H:i', strtotime((string)$ref['usado_em'])) . ' por ' . ($ref['usado_por'] ?: 'operador');
    else $msg .= ' — já conferido';
    return $msg . '. Baixa não permitida.';
}
/** Relê o arquivo e completa valor/data/pagador do selo (não mexe na chave nem no uso). */
function ws_comp_selo_reler(PDO $db, array $s): array {
    $fx = WS_CACHE . '/selo_relido2.json'; $ja = json_decode((string)@file_get_contents($fx), true) ?: [];
    if (isset($ja[(int)$s['id']])) return $s;   // já tentou uma vez: não fica relendo (OCR leva segundos)
    $ja[(int)$s['id']] = time(); if (count($ja) > 2000) $ja = array_slice($ja, -1500, null, true); @file_put_contents($fx, json_encode($ja), LOCK_EX);
    $st = $db->prepare("SELECT arquivos FROM ws_comprovante WHERE id=?"); $st->execute([(int)$s['comprovante_id']]);
    $lido = ['valor' => null, 'data' => null, 'pagador' => null];
    foreach ((json_decode((string)$st->fetchColumn(), true) ?: []) as $a) {
        $rel = (string)($a['arquivo'] ?? ''); $abs = ws_comp_dir() . '/' . $rel;
        if ($rel === '' || strpos($rel, '..') !== false || !is_file($abs)) continue;
        $x = ws_comp_extrair(ws_comp_ler($abs, (string)($a['mime'] ?? '')));
        foreach ($lido as $k => $v) if ($v === null && ($x[$k] ?? null) !== null) $lido[$k] = $x[$k];
    }
    if ($lido['valor'] === null && $lido['data'] === null) return $s;
    $db->prepare("UPDATE ws_pix_selo SET valor=?, data_pix=COALESCE(?, data_pix), pagador=? WHERE id=?")
       ->execute([$lido['valor'], $lido['data'], $lido['pagador'] ? mb_substr($lido['pagador'], 0, 120) : null, (int)$s['id']]);
    $s['valor'] = $lido['valor']; if ($lido['data']) $s['data_pix'] = $lido['data']; $s['pagador'] = $lido['pagador'];
    return $s;
}
/** Este PIX JÁ TEVE BAIXA? (09/10/2026) — pelo selo (mesmo ID PIX/arquivo usado numa baixa) ou por outra cópia do mesmo arquivo já
 *  conferida com título. Devolve ['comp','fatura','em','por','cliente','mesmo'] ou null. 'mesmo' = é o mesmo cliente/telefone
 *  (aí é só duplicidade: o cartão informa a baixa e esconde o botão; de OUTRO cliente continua sendo POSSÍVEL FRAUDE). */
function ws_comp_ja_baixado(PDO $db, array $r, ?array $sl): ?array {
    $achado = null;
    try {
        if ($sl && (string)($sl['chave'] ?? '') !== '' && strpos((string)$sl['chave'], 'COMP:') !== 0) {
            $q = $db->prepare("SELECT s.comprovante_id comp, s.fatura_id fatura, s.usado_em em, s.usado_por por, s.cliente_id cli, c.telefone, cl.nome cliente
                               FROM ws_pix_selo s LEFT JOIN ws_comprovante c ON c.id=s.comprovante_id LEFT JOIN ws_cliente cl ON cl.id=s.cliente_id
                               WHERE s.chave=? AND s.usado_em IS NOT NULL ORDER BY s.usado_em LIMIT 1");
            $q->execute([(string)$sl['chave']]); $achado = $q->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if (!$achado) foreach ((json_decode((string)($r['arquivos'] ?? ''), true) ?: []) as $a) if (!empty($a['sha1'])) {
            $q = $db->prepare("SELECT c.id comp, c.fatura_id fatura, c.conferido_em em, c.conferido_por por, c.cliente_id cli, c.telefone, cl.nome cliente
                               FROM ws_comprovante c LEFT JOIN ws_cliente cl ON cl.id=c.cliente_id
                               WHERE c.id<>? AND c.status IN ('conferido','baixado') AND c.fatura_id IS NOT NULL AND c.arquivos LIKE ? ORDER BY c.id LIMIT 1");
            $q->execute([(int)$r['id'], '%' . $a['sha1'] . '%']); if ($achado = $q->fetch(PDO::FETCH_ASSOC) ?: null) break;
        }
    } catch (Throwable $e) { return null; }
    if (!$achado) return null;
    $t1 = substr(preg_replace('/\D/', '', (string)($r['telefone'] ?? '')), -8); $t2 = substr(preg_replace('/\D/', '', (string)($achado['telefone'] ?? '')), -8);
    $achado['mesmo'] = (int)$achado['comp'] === (int)$r['id'] || (strlen($t1) === 8 && $t1 === $t2) || ((int)($r['cliente_id'] ?? 0) > 0 && (int)$r['cliente_id'] === (int)$achado['cli']);
    return $achado;
}
/** Mapa comprovante_id => selo (+ aviso de fraude) para a tela. */
function ws_comp_selos(PDO $db, array $compIds): array {
    $compIds = array_values(array_filter(array_map('intval', $compIds)));
    if (!$compIds) return [];
    $out = [];
    try {
        $reler = 3;   // 09/10/2026: selo antigo sem valor/data (ex.: Mercado Pago "R$ 70", "8/outubro/2026") é relido aos poucos
        foreach ($db->query("SELECT * FROM ws_pix_selo WHERE comprovante_id IN (" . implode(',', $compIds) . ")")->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $vSusp = $s['valor'] === null || ((float)$s['valor'] >= 1000 && fmod((float)$s['valor'], 1.0) == 0.0);   // sem valor, ou "R$ 7450" (centavos do Mercado Pago colados)
            if ($reler > 0 && $vSusp && empty($s['usado_em'])) { $reler--; try { $s = ws_comp_selo_reler($db, $s); } catch (Throwable $e) {} }
            $s['fraude'] = ws_comp_selo_fraude($db, $s); $out[(int)$s['comprovante_id']] = $s;
        }
    } catch (Throwable $e) {}
    return $out;
}

/** Na BAIXA: confere o selo do comprovante. [ok, mensagem]. Sem selo ainda (arquivo não lido) = lê agora. */
function ws_comp_selo_conferir_baixa(PDO $db, int $compId, int $faturaId): array {
    $s = ws_comp_selar($db, $compId);
    if (!$s) return [true, ''];   // sem arquivo: nada a comparar (a tela já pede conferir no extrato)
    $f = ws_comp_selo_fraude($db, $s, $faturaId);
    return $f === '' ? [true, ''] : [false, $f];
}

/** ESTORNO do título (09/10/2026): o comprovante que deu aquela baixa volta para "novo" (com aviso) e o selo fica livre de novo.
 *  Antes o estorno reabria o título mas o comprovante continuava "conferido" e o selo "usado" nesse título. */
function ws_comp_estorno_fatura(PDO $db, int $faturaId): void {
    try {
        $db->prepare("UPDATE ws_pix_selo SET usado_em=NULL, usado_por=NULL, fatura_id=NULL WHERE fatura_id=? AND usado_em IS NOT NULL")->execute([$faturaId]);
        $db->prepare("UPDATE ws_comprovante SET status='novo', fatura_id=NULL, conferido_por=NULL, conferido_em=NULL, obs=LEFT(CONCAT('Baixa estornada no título #', ?, '. ', COALESCE(obs,'')), 255) WHERE fatura_id=? AND status='conferido'")
           ->execute([$faturaId, $faturaId]);
    } catch (Throwable $e) {}
}
/** Baixa feita: o selo fica atrelado ao título/cliente, com quem e quando. */
function ws_comp_selo_usar(PDO $db, int $compId, int $faturaId, int $clienteId, string $quem): void {
    try {
        $db->prepare("UPDATE ws_pix_selo SET fatura_id=?, cliente_id=?, usado_em=NOW(), usado_por=? WHERE comprovante_id=? AND usado_em IS NULL")
           ->execute([$faturaId, $clienteId ?: null, mb_substr($quem, 0, 80), $compId]);
    } catch (Throwable $e) {}
}

/* ===== COMPROVANTE ENVIADO FORA DO FLUXO DO ROBÔ (08/10/2026) =====
   O cliente manda a foto/PDF do PIX no meio de um atendimento HUMANO (opção 7) ou em qualquer momento em que o robô não está no passo
   "enviar comprovante": antes, a mídia ficava 2 h no cache e sumia — nunca chegava em Comprovantes PIX (caso real: foto de R$ 100 às 15:59).
   Agora o webhook da Evolution anota quem mandou (cache/midia_pendentes.json) e, passados 10 min (tempo de sobra para o fluxo normal do robô
   registrar por conta própria — quem já foi registrado é pulado pelo ID da mensagem), um processo de fundo lê o arquivo por OCR/PDF e, se for
   mesmo comprovante (E2E, valor ou palavras de PIX/transferência), registra no cliente certo. Foto que não é comprovante (roteador etc.) é ignorada. */
function ws_comp_pendentes_arq(): string { return WS_CACHE . '/midia_pendentes.json'; }
function ws_comp_pendente_add(string $id, string $jid, string $push, string $tipo): void {
    if ($id === '') return;
    $f = ws_comp_pendentes_arq(); $h = @fopen($f, 'c+'); if (!$h) return;
    if (flock($h, LOCK_EX)) {
        $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = [];
        foreach ($j as $k => $v) if (time() - (int)($v['em'] ?? 0) > 3 * 3600) unset($j[$k]);
        if (!isset($j[$id])) $j[$id] = ['jid' => substr($jid, 0, 60), 'push' => mb_substr($push, 0, 120), 'tipo' => $tipo, 'em' => time()];
        ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j, JSON_UNESCAPED_UNICODE)); fflush($h); flock($h, LOCK_UN);
    }
    fclose($h); @chmod($f, 0640);
}
/** Há mídia esperando a vez (≥ 10 min, ainda não vista)? Barato: só lê um JSON pequeno. */
function ws_comp_pendentes_prontos(): bool {
    $j = json_decode((string)@file_get_contents(ws_comp_pendentes_arq()), true); if (!is_array($j)) return false;
    foreach ($j as $v) if (empty($v['feito']) && time() - (int)($v['em'] ?? 0) >= 300) return true;
    return false;
}
/** Processa as pendentes prontas. Devolve quantos comprovantes registrou. */
function ws_comp_orfas(PDO $db): int {
    $f = ws_comp_pendentes_arq(); $j = json_decode((string)@file_get_contents($f), true); if (!is_array($j)) return 0;
    $reg = 0; $mudou = false;
    foreach ($j as $id => $v) {
        if (!empty($v['feito']) || time() - (int)($v['em'] ?? 0) < 300) continue;
        $mudou = true; $j[$id]['feito'] = 1;
        try {
            $q = $db->prepare("SELECT id FROM ws_comprovante WHERE mensagens LIKE ? LIMIT 1"); $q->execute(['%' . $id . '%']);
            if ($q->fetchColumn()) { $j[$id]['obs'] = 'ja registrado'; continue; }
            $arq = function_exists('ws_midia_pegar') ? ws_midia_pegar((string)$id, 2) : null;
            if (!$arq) { $j[$id]['obs'] = 'arquivo expirou'; continue; }
            $tmp = tempnam(sys_get_temp_dir(), 'wsor'); file_put_contents($tmp, $arq[0]);
            $mime = $arq[1] ?: (($v['tipo'] ?? '') === 'imageMessage' ? 'image/jpeg' : 'application/pdf');
            $tx = ws_comp_ler($tmp, $mime); @unlink($tmp); $lx = ws_comp_extrair($tx);
            $ehComp = $lx['e2e'] || preg_match('/\b(pix|comprovante|transfer[eê]ncia|pagamento efetuado|pagamento realizado|favorecido|recebedor|destinat[aá]rio|autentica[cç][aã]o)\b/iu', $tx);
            if (!$ehComp) { $j[$id]['obs'] = 'nao e comprovante'; continue; }
            $tp = ($v['tipo'] ?? '') === 'imageMessage' ? 'imageMessage' : 'documentMessage';
            $cid = ws_comp_receber($db, ['comprovante' => $tp . '|' . $id, 'remoteJid' => (string)($v['jid'] ?? ''), 'pushName' => (string)($v['push'] ?? '')]);
            $j[$id]['obs'] = 'registrado #' . $cid; $reg++;
            if (($rm = ws_comp_reenvio_msg($db, $cid)) !== '') {   // reenvio: avisa (pela conversa onde ele falou por último) em vez de perguntar o nome
                $j[$id]['obs'] .= ' (reenvio)';
                $tl = preg_replace('/\D/', '', explode('@', (string)($v['jid'] ?? ''))[0]);
                if (defined('WS_COMP_SEM_ENVIO')) $GLOBALS['ws_comp_ultimo_envio'] = $rm;
                elseif ($tl !== '' && function_exists('ws_wa_enviar_conversa')) { try { ws_wa_enviar_conversa($tl, $rm, ['evento' => 'comprovante', 'automatica' => true]); } catch (Throwable $e) {} }
                continue;
            }
            try { if (ws_comp_perguntar_nome($db, $cid)) $j[$id]['obs'] .= ' (perguntou o nome)'; } catch (Throwable $e) { @error_log('[comp_perguntar] ' . $e->getMessage()); }
        } catch (Throwable $e) { $j[$id]['obs'] = 'erro'; @error_log('[comp_orfas] ' . $e->getMessage()); }
    }
    if ($mudou) { @file_put_contents($f, json_encode($j, JSON_UNESCAPED_UNICODE), LOCK_EX); @chmod($f, 0640); }
    return $reg;
}

/* ===== CONFERÊNCIA DO COMPROVANTE: QUEM PAGOU × DE QUEM É A CONTA × QUANTO (08/10/2026) =====
   Dinheiro envolvido: cada cartão mostra, lado a lado e sem ambiguidade, (1) o CLIENTE titular da conta que será baixada, (2) QUEM PAGOU (nome e
   CPF/CNPJ lidos no comprovante — o app do banco mascara o CPF, então confere pelos dígitos visíveis), (3) o WHATSAPP de onde veio (telefone na base?
   nome confere com o titular?), (4) o VALOR DO BOLETO e o VALOR PAGO lido, (5) se o RECEBEDOR é a conta da empresa. Tudo vira uma lista de
   verificações com semáforo (🟢 pronto / 🟡 conferir / 🔴 bloqueado). A baixa é SEMPRE pelo valor pago lido; só o operador decide quando algo foge. */
function ws_comp_leitura_tabela(PDO $db): void {
    static $ok = false; if ($ok) return; $ok = true;
    $db->exec("CREATE TABLE IF NOT EXISTS ws_comp_leitura (
        comprovante_id INT NOT NULL PRIMARY KEY,
        dados MEDIUMTEXT DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function ws_comp_norm_nome(string $s): string {
    $s = mb_strtolower($s, 'UTF-8');
    $s = strtr($s, ['á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'é' => 'e', 'ê' => 'e', 'í' => 'i', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ú' => 'u', 'ç' => 'c']);
    return trim(preg_replace('/[^a-z ]+/', ' ', $s));
}
function ws_comp_tokens(string $s): array {
    $out = [];
    foreach (explode(' ', ws_comp_norm_nome($s)) as $w) if (strlen($w) >= 3 && !in_array($w, ['dos', 'das', 'del', 'the', 'ltda', 'epp', 'mei'], true)) $out[$w] = $w;
    return array_values($out);
}
/** Mesma pessoa? 2 ou mais palavras em comum (ou a única palavra do menor nome). */
function ws_comp_nomes_batem(string $a, string $b): bool {
    $ta = ws_comp_tokens($a); $tb = ws_comp_tokens($b); if (!$ta || !$tb) return false;
    $c = count(array_intersect($ta, $tb));
    return $c >= 2 || ($c >= 1 && min(count($ta), count($tb)) === 1);
}
/** Do texto lido: nome/documento de QUEM PAGOU e de QUEM RECEBEU (o que der para achar; vazio quando o banco não mostra).
 *  Os bancos escrevem de jeitos diferentes ("Pagador Nome Fulano CPF ***.509.394-**", "Recebedor Fulano CNPJ 4.154.749/0001-44", "Origem/Destino…")
 *  e o OCR troca letras (CNPJ vira "CNP)"); por isso o nome vai até a próxima palavra-chave, e o documento aceita máscara e espaços. */
function ws_comp_extrair_detalhe(string $txt): array {
    // OCR troca a máscara do CPF ("***.409.974-**" vira "*+*4.409.974-**"): volta ao formato do banco
    $txt = preg_replace('/[*+#•]{2,}\d?[.,](\d{3})[.,](\d{3})-[*•+]{1,2}/u', '***.$1.$2-**', $txt);   // também "***,988.804-**" (vírgula)
    $c = trim(preg_replace('/\s+/u', ' ', $txt));
    $o = ['v' => 7, 'pagador_nome' => '', 'pagador_doc' => '', 'recebedor_nome' => '', 'recebedor_doc' => '', 'recebedor_inst' => '', 'recebedor_chave' => ''];
    $boD = ws_comp_boleto_info($txt); if ($boD) $o['boleto'] = $boD;   // pagamento de boleto (v6, 10/10/2026)   // v = versão da leitura (cache antigo é relido)
    // 09/10/2026: Bradesco "Dados de quem fez a transação" / "Dados de quem recebe"; outros: "quem enviou", "quem transferiu", "pago por"
    $mP = '/(?:dados de quem pagou|nome do pagador|pagador|quem pagou|quem fez a transa[cç][aã]o|quem enviou|quem transferiu|pago por|empresa(?=\s*:)|origem(?!\s+e\s+destino)|remetente)\b/iu';   // "Empresa:" = conta PJ que pagou (Bradesco Net Empresa)
    $mR = '/(?:dados de quem recebeu|quem vai receber|quem recebe\b|recebedor|(?<!origem e )destino|favorecido|destinat[aá]rio|quem recebeu|benefici[aá]rio)\b/iu';
    $achar = function (string $rx) use ($c): ?array { return preg_match($rx, $c, $m, PREG_OFFSET_CAPTURE) ? [(int)$m[0][1], (int)$m[0][1] + strlen($m[0][0])] : null; };
    $aP = $achar($mP); $aR = $achar($mR);
    $seg = function (?array $a, ?array $outro) use ($c): string {
        if ($a === null) return '';
        $fim = ($outro !== null && $outro[0] > $a[0]) ? $outro[0] : $a[1] + 260;
        return trim(ltrim(trim(mb_strcut($c, $a[1], max(10, min(260, $fim - $a[1])), 'UTF-8')), ':- '));   // "Empresa: FULANO" → "FULANO"
    };
    // 09/10/2026: CNPJ mascarado do Santander ("04.***.***/0001-4*") — antes não casava, o CNPJ ficava vazio e o recebedor era julgado só pelo nome
    $docRx = '/(\d{1,2}\.?\d{3}\.?\d{3}\/?\d{4}-?\s?\d{2}|[\d\*•xX]{1,2}\.[\d\*•xX]{3}\.[\d\*•xX]{3}\/[\d\*•xX]{4}-?\s?[\d\*•xX]{2}|[\d\*•xX]{3}[.\s]?[\d\*•xX]{3}[.\s]?[\d\*•xX]{3}-?\s?[\d\*•xX]{2})/u';
    $nomeRx = '/^(?:Nome\s*[:\x{2014}\x{2013}\-]*\s*|(?:Para|De)\s+(?=[A-ZÀ-Ú]))?([A-ZÀ-Ú][A-Za-zÀ-ú\'.\- ]{2,70}?)(?=\s+(?:CPF|CNPJ|CNP\)|CNP\b|Institui|Ag[eê]ncia|Chave|Conta|Banco|Tipo|Dados|ID\b)|\s*$)/u';
    foreach (['pagador' => $seg($aP, $aR), 'recebedor' => $seg($aR, $aP)] as $k => $s) {
        if ($s === '') continue;
        $pt = @preg_split('/Institui[cç][aã]o/iu', $s); $antes = is_array($pt) ? $pt[0] : $s;
        /* 20/11/2026 (Stone): rótulos numa linha e valores na seguinte ("Nome CPF ELZA MARIA… ***.017.484-**") — tira o rótulo do documento. */
        if (preg_match('/^\s*Nome\s+(?:CPF|CNPJ)(?:\s*\/\s*CNPJ)?\s+(?=[A-ZÀ-Ú])/iu', $antes)) {
            $antesN = preg_replace('/^\s*Nome\s+(?:CPF|CNPJ)(?:\s*\/\s*CNPJ)?\s+(?=[A-ZÀ-Ú])/iu', 'Nome ', ltrim($antes));
            $antesN = preg_replace('/\s+[\d\*•].*$/su', '', $antesN);   // o nome termina onde começa o documento (números ou máscara ***)
        } else $antesN = $antes;   // documento e nome vêm antes da instituição (o CNPJ do banco não é de quem pagou)
        if (preg_match($nomeRx, $antesN, $m) && !preg_match('/^(nome|cpf|cnpj|chave|conta|banco|tipo|dados)\b/iu', trim($m[1])) && mb_strlen(trim($m[1])) >= 4) $o[$k . '_nome'] = trim($m[1]);
        if (preg_match_all($docRx, $antes, $mm)) foreach ($mm[1] as $cand) { if (ws_comp_doc_plausivel($cand)) { $o[$k . '_doc'] = trim($cand); break; } }
        // chave PIX do recebedor (09/10/2026): telefone, e-mail ou CNPJ — se for a chave da empresa, o dinheiro entrou na conta dela
        if ($k === 'recebedor' && preg_match('/Chave(?:\s*Pix)?\s*:?\s*\*?([\w.+\-]+@[\w.\-]+\.\w+|\+?[\d(][\d\s().\/\-]{7,22}\d)/iu', $s, $m)) $o['recebedor_chave'] = trim($m[1]);
        if ($k === 'recebedor' && preg_match('/Institui[cç][aã]o\s*(?:Destino|Recebedor)?\s*:?\s*(?:\d+\s+)?([A-ZÀ-Ú][A-Za-zÀ-ú.\' \-]{2,40})/u', $s, $m)) $o['recebedor_inst'] = trim(preg_replace('/\s+(?:Dados|Chave|Ag[eê]ncia|Conta|Tipo|CPF|CNPJ)\b.*$/iu', '', $m[1]));
    }
    if ($o['pagador_nome'] === '' && preg_match('/Pessoa que pagou\s+([A-ZÀ-Ú][A-Za-zÀ-ú\'. \-]{4,70}?)\s+(?:Meio de pagamento|Pago via|Banco\b|Forma de)/u', $c, $mpq)) $o['pagador_nome'] = trim($mpq[1]);
    /* "ORIGEM E DESTINO" sem rótulos (Mercado Pago e outros, 09/10/2026): 1º nome = quem pagou (+ banco + CPF), 2º nome = quem recebeu
       (+ banco + CNPJ). Antes "Origem e destino" virava "Quem pagou: e destino" e o recebedor ficava sendo o próprio pagador. */
    if (preg_match('/origem\s+e\s+destino\s*\n(.*)$/isu', $txt, $mo)) {
        $docRx2 = '/(?:CPF|CNPJ|CNP\))\s*:?\s*([\d\*•xX][\d\*•xX.\/\- ]{9,20}[\d\*•xX])/u';
        $bancoRx = '/\b(banco|s\.?\s?a\.?$|mercado pago|nubank|pagbank|picpay|ita[uú]|bradesco|caixa|santander|inter\b|sicoob|sicredi|c6|institui|ag[eê]ncia|conta)/iu';
        $blocos = []; $atual = ['nome' => '', 'doc' => '', 'inst' => ''];
        foreach (preg_split('/\R/u', $mo[1]) as $ln) {
            $ln = trim($ln); if ($ln === '') continue;
            if (preg_match($docRx2, $ln, $md)) { $atual['doc'] = trim($md[1]); $blocos[] = $atual; $atual = ['nome' => '', 'doc' => '', 'inst' => '']; if (count($blocos) >= 2) break; continue; }
            if (preg_match('/^(n\.?\s?º|id |valor|data|chave|tipo)/iu', $ln)) break;
            $nm = trim(preg_replace('/^(?:[^A-Za-zÀ-ú]*\S{0,2}\s+)(?=[A-ZÀ-Ú][a-zà-úA-ZÀ-Ú])/u', '', $ln));   // tira o ícone que o OCR lê como "S", "&", "@"
            if ($atual['nome'] === '' && !preg_match($bancoRx, $nm) && preg_match('/^[A-ZÀ-Ú][A-Za-zÀ-ú\'.]+(?:\s+[A-Za-zÀ-ú\'.]+)+$/u', $nm)) $atual['nome'] = $nm;
            elseif ($atual['nome'] !== '' && $atual['inst'] === '' && !preg_match($bancoRx, $nm) && preg_match('/^[A-ZÀ-Ú][a-zà-ú\'.]+(?:\s+[A-ZÀ-Ú][a-zà-ú\'.]+)?$/u', $nm)) $atual['nome'] .= ' ' . $nm;   // nome em 2 linhas ("… de Freitas / Ribeiro")
            elseif ($atual['nome'] !== '' && $atual['inst'] === '') $atual['inst'] = $nm;
        }
        if ($atual['nome'] !== '') $blocos[] = $atual;
        if (!empty($blocos[0]['nome'])) { $o['pagador_nome'] = $blocos[0]['nome']; if ($blocos[0]['doc'] !== '' && ws_comp_doc_plausivel($blocos[0]['doc'])) $o['pagador_doc'] = $blocos[0]['doc']; }
        if (!empty($blocos[1]['nome'])) { $o['recebedor_nome'] = $blocos[1]['nome']; $o['recebedor_inst'] = $blocos[1]['inst'];
            $o['recebedor_doc'] = ($blocos[1]['doc'] !== '' && ws_comp_doc_plausivel($blocos[1]['doc'])) ? $blocos[1]['doc'] : ''; }
    }
    /* RÓTULO SOZINHO NA LINHA (PicPay e outros, 09/10/2026): "Para" / "De" (ou "Pagador", "Recebedor", "Destino", "Origem") numa linha e o
       nome nas 1–2 linhas de baixo, depois o CPF/CNPJ e o banco. Só preenche o que as regras acima não acharam. */
    $linhas = array_values(array_filter(array_map('trim', preg_split('/\R/u', $txt)), fn($l) => $l !== ''));
    foreach ($linhas as $i => $ln) {
        $lado = preg_match('/^(?:de|pagador|origem|quem pagou)\s*:?$/iu', $ln) ? 'pagador' : (preg_match('/^(?:para|recebedor|destino|favorecido|quem recebeu)\s*:?$/iu', $ln) ? 'recebedor' : '');
        if ($lado === '' || $o[$lado . '_nome'] !== '') continue;
        $nm = ''; $j = $i + 1;
        for (; $j < count($linhas) && $j <= $i + 3; $j++) {
            $l2 = $linhas[$j];
            if (preg_match('/^[\d*•xX]/u', $l2) || preg_match('/\b(banco|bco|s\.a\.|picpay|nubank|mercado pago|institui|cpf|cnpj|ag[eê]ncia|conta)\b/iu', $l2)) break;
            if (!preg_match('/^[A-ZÀ-Ú][A-Za-zÀ-ú\'. \-]+$/u', $l2)) break;
            $nm = trim($nm . ' ' . $l2);
        }
        if (mb_strlen($nm) < 4 || !preg_match('/\s/u', $nm)) continue;
        $o[$lado . '_nome'] = $nm;
        for (; $j < count($linhas) && $j <= $i + 6; $j++) {
            if ($o[$lado . '_doc'] === '' && preg_match('/^(?:CPF|CNPJ|CPF\/CNPJ)?\s*:?\s*([\d*•xX][\d*•xX.\/\- ]{9,20}[\d*•xX])$/u', $linhas[$j], $md) && ws_comp_doc_plausivel(trim($md[1]))) { $o[$lado . '_doc'] = trim($md[1]); continue; }
            if ($lado === 'recebedor' && $o['recebedor_inst'] === '' && preg_match('/\b(banco|bco|s\.a\.)/iu', $linhas[$j])) $o['recebedor_inst'] = $linhas[$j];
            if (preg_match('/^(?:de|para|id|dados|valor)\b/iu', $linhas[$j])) break;
        }
    }
    return $o;
}
/** O número lido é mesmo um CPF/CNPJ? Telefone (chave PIX por celular, ex.: 5511999990000) não pode virar "documento" e acusar recebedor errado (09/10/2026).
 *  Com máscara (*) vale pelos dígitos visíveis; formatado (pontos/traço) vale; só dígitos precisa ter dígito verificador de CPF ou ser CNPJ de 14. */
function ws_comp_doc_plausivel(string $doc): bool {
    if (preg_match('/[*•xX]/u', $doc)) return ws_comp_doc_padrao($doc) !== null;
    $d = preg_replace('/\D/', '', $doc);
    if (preg_match('/[.\/-]/', $doc)) return in_array(strlen($d), [11, 13, 14], true);   // 13 = CNPJ sem o zero da frente (OCR)
    if (strlen($d) === 14) return true;
    if (strlen($d) !== 11 || preg_match('/^(\d)\1{10}$/', $d)) return false;
    for ($t = 9; $t < 11; $t++) { $sm = 0; for ($c = 0; $c < $t; $c++) $sm += (int)$d[$c] * (($t + 1) - $c); $dv = ((10 * $sm) % 11) % 10; if ((int)$d[$t] !== $dv) return false; }
    return true;
}
/** Detalhes lidos do comprovante (cache em ws_comp_leitura). Sem cache e com arquivo: lê agora (OCR leva segundos — $ler controla). */
function ws_comp_detalhes(PDO $db, int $compId, bool $ler = true): ?array {
    ws_comp_leitura_tabela($db);
    $q = $db->prepare("SELECT dados FROM ws_comp_leitura WHERE comprovante_id=?"); $q->execute([$compId]);
    $j = $q->fetchColumn();
    $velho = null;
    if ($j !== false) {
        $velho = json_decode((string)$j, true) ?: [];
        if ((int)($velho['v'] ?? 1) >= 7) return $velho;
        if (!$ler) return $velho + ['_velho' => 1];   // 09/10/2026: enquanto a releitura não chega, mostra a leitura antiga (não some o nome); '_velho' = precisa reler   // leitura de versão antiga (sem CNPJ mascarado/chave): a tela relê o arquivo (fila de OCR)
    }
    if (!$ler) return null;
    $st = $db->prepare("SELECT arquivos FROM ws_comprovante WHERE id=?"); $st->execute([$compId]);
    $arqs = json_decode((string)$st->fetchColumn(), true) ?: [];
    if (!$arqs) return $velho;
    $tx = '';
    foreach ($arqs as $a) {
        $rel = (string)($a['arquivo'] ?? ''); $abs = ws_comp_dir() . '/' . $rel;
        if ($rel === '' || strpos($rel, '..') !== false || !is_file($abs)) continue;
        $tx .= "\n" . ws_comp_ler($abs, (string)($a['mime'] ?? ''));
    }
    if (trim($tx) === '' && $velho !== null) return $velho;   // arquivo sumiu: fica com a leitura antiga
    $d = trim($tx) === '' ? [] : ws_comp_extrair_detalhe($tx);
    $db->prepare("REPLACE INTO ws_comp_leitura (comprovante_id, dados) VALUES (?,?)")->execute([$compId, json_encode($d, JSON_UNESCAPED_UNICODE)]);
    return $d;
}
/** Documento sem a máscara do banco (09/10/2026): "***.509.394-**" vira "509.394"; CPF/CNPJ completo fica como está. */
function ws_comp_doc_limpo(string $doc): string {
    $x = preg_replace('/[*•xX]+/u', '', $doc);
    return trim(preg_replace('/\s+/', '', $x), '.-/');
}
/** "***.509.394-**" vira '___509394__' (LIKE sobre o CPF/CNPJ só com dígitos). null se poucos dígitos visíveis. */
function ws_comp_doc_padrao(string $doc): ?string {
    $p = ''; $vis = 0;
    foreach (preg_split('//u', $doc, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
        if (ctype_digit($ch)) { $p .= $ch; $vis++; } elseif (in_array($ch, ['*', '•', 'x', 'X'], true)) $p .= '_';
    }
    if (strpos($p, '_') === false && strlen($p) === 13) $p = '0' . $p;   // CNPJ "4.154.749/0001-44" (o OCR perdeu o 0 da frente)
    return ($vis >= 4 && in_array(strlen($p), [11, 14], true)) ? $p : null;
}
function ws_comp_doc_casa(string $padrao, string $docLimpo): bool {
    if (strlen($padrao) !== strlen($docLimpo)) return false;
    return (bool)preg_match('/^' . str_replace('_', '\d', $padrao) . '$/', $docLimpo);
}
/** CPF/CNPJ COMPLETO de quem pagou (09/10/2026): o banco mascara; se os dígitos visíveis batem com o do titular (ou do titular do titular) ou com UM cliente da base, mostra o documento inteiro. '' = só o parcial. */
function ws_comp_doc_completo(PDO $db, string $docMascarado, int $clienteId = 0): string {
    $pad = ws_comp_doc_padrao($docMascarado); if (!$pad) return '';
    if ($clienteId > 0) {
        $q = $db->prepare("SELECT c.cpf_cnpj, t.cpf_cnpj tit FROM ws_cliente c LEFT JOIN ws_cliente t ON t.id=c.titular_id WHERE c.id=?"); $q->execute([$clienteId]); $r = $q->fetch(PDO::FETCH_ASSOC) ?: [];
        foreach ([$r['cpf_cnpj'] ?? '', $r['tit'] ?? ''] as $dc) { $dl = preg_replace('/\D/', '', (string)$dc); if ($dl !== '' && ws_comp_doc_casa($pad, $dl)) return function_exists('ws_doc_formatado') ? (ws_doc_formatado($dl) ?: $dl) : $dl; }
    }
    $ach = ws_comp_clientes_por_doc($db, $pad);
    if (count($ach) === 1) { $q = $db->prepare("SELECT cpf_cnpj FROM ws_cliente WHERE id=?"); $q->execute([(int)$ach[0]['id']]); $dl = preg_replace('/\D/', '', (string)$q->fetchColumn()); if ($dl !== '') return function_exists('ws_doc_formatado') ? (ws_doc_formatado($dl) ?: $dl) : $dl; }
    return '';
}
/** Clientes da base cujo CPF/CNPJ casa com o padrão mascarado (até 3). */
function ws_comp_clientes_por_doc(PDO $db, string $padrao): array {
    $q = $db->prepare("SELECT id, nome FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/',''),' ','') LIKE ? ORDER BY (titular_id IS NULL) DESC, id LIMIT 3");
    $q->execute([$padrao]); return $q->fetchAll(PDO::FETCH_ASSOC);
}
/** Clientes ativos cujo nome contém as palavras de $nome (até 3, sem o cliente $exceto). */
function ws_comp_sugerir_clientes(PDO $db, string $nome, int $exceto = 0): array {
    $tk = array_slice(ws_comp_tokens($nome), 0, 3); if (!$tk) return [];
    $sql = "SELECT id, nome FROM ws_cliente WHERE status NOT IN ('cancelado','desativado')" . str_repeat(' AND nome LIKE ?', count($tk)) . ($exceto > 0 ? ' AND id<>' . (int)$exceto : '') . ' ORDER BY (titular_id IS NULL) DESC, id LIMIT 3';
    try {
        $q = $db->prepare($sql); $q->execute(array_map(fn($w) => '%' . $w . '%', $tk)); $ach = $q->fetchAll(PDO::FETCH_ASSOC);
        if ($ach || count($tk) < 2) return $ach;
        /* (16/10/2026) nome DIGITADO com erro de uma letra ("Ednalva Brito de Macena" x "EDNALVA BRITO DE MASCENA BARBOSA"): procura pelo 1º nome e aceita palavra com 1 letra de diferença (≥ 5 letras). */
        $q2 = $db->prepare("SELECT id, nome FROM ws_cliente WHERE status NOT IN ('cancelado','desativado') AND nome LIKE ?" . ($exceto > 0 ? ' AND id<>' . (int)$exceto : '') . ' ORDER BY (titular_id IS NULL) DESC, id LIMIT 300'); $q2->execute(['%' . $tk[0] . '%']);
        $sai = [];
        foreach ($q2->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $pal = ws_comp_tokens((string)$r['nome']); $ok = true;
            foreach ($tk as $w) { $achou = false; foreach ($pal as $p) { if ($p === $w || (strlen($w) >= 5 && strlen($p) >= 5 && levenshtein($p, $w) <= 1)) { $achou = true; break; } } if (!$achou) { $ok = false; break; } }
            if ($ok) $sai[] = $r; if (count($sai) >= 3) break;
        }
        return $sai;
    } catch (Throwable $e) { return []; }
}
/* ===== CLIENTE NÃO IDENTIFICADO PELO TELEFONE (09/10/2026) =====
   WhatsApp que não está no cadastro (ou número oculto/@lid) deixava o cartão "cliente não identificado". Agora o sistema procura o cliente
   pelo que está NO RECIBO e na conversa e dá pontos: CPF/CNPJ de quem pagou (3), nome de quem pagou (2), nome informado ao robô (2),
   nome do WhatsApp (1) e boleto em aberto com o MESMO valor pago (2). Liga sozinho só com 5+ pontos, um candidato único na frente e o
   boleto batendo; senão mostra os candidatos para o operador escolher com um clique. */
function ws_comp_identificar(PDO $db, array $r, ?array $det, ?array $sl): array {
    $pts = []; $mot = [];
    $add = function (array $lista, int $p, string $m) use (&$pts, &$mot) { foreach ($lista as $c) { $i = (int)$c['id']; $pts[$i] = ($pts[$i] ?? 0) + $p; $mot[$i][$m] = 1; } };
    $docP = (string)($det['pagador_doc'] ?? '');
    if ($docP !== '' && ($pad = ws_comp_doc_padrao($docP))) $add(ws_comp_clientes_por_doc($db, $pad), 3, 'CPF de quem pagou');
    $nomeLe = function (string $n) use ($db): array { return count(ws_comp_tokens($n)) >= 2 ? ws_comp_sugerir_clientes($db, $n) : []; };
    $pag = trim((string)($det['pagador_nome'] ?? ''));
    if ($pag !== '') $add($nomeLe($pag), 2, 'nome de quem pagou');
    $inf = trim((string)($r['nome_informado'] ?? '')); if ($inf !== '' && ws_comp_nomes_batem($inf, $pag) === false) $add($nomeLe($inf), 2, 'nome informado ao robô');
    $pw = trim((string)($r['nome_whats'] ?? '')); if ($pw !== '' && !ws_comp_nomes_batem($pw, $pag) && !ws_comp_nomes_batem($pw, $inf)) $add($nomeLe($pw), 1, 'nome do WhatsApp');
    if (!$pts) return ['auto' => null, 'sug' => []];
    $valor = ($sl && $sl['valor'] !== null) ? round((float)$sl['valor'], 2) : null;
    if ($valor !== null) {
        $in = implode(',', array_map('intval', array_keys($pts)));
        foreach ($db->query("SELECT * FROM ws_fatura WHERE cliente_id IN ($in) AND status IN ('aberto','vencido')")->fetchAll(PDO::FETCH_ASSOC) as $f)
            if (abs((float)ws_fatura_valor_cobrado($f) - $valor) < 0.01 || abs((float)$f['valor'] - $valor) < 0.01) { $i = (int)$f['cliente_id']; if (empty($mot[$i]['boleto com o valor pago'])) { $pts[$i] += 2; $mot[$i]['boleto com o valor pago'] = 1; } }
    }
    arsort($pts); $ids = array_keys($pts);
    $nomes = []; $q = $db->query("SELECT id, nome FROM ws_cliente WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")"); foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $c) $nomes[(int)$c['id']] = $c['nome'];
    $sug = []; foreach (array_slice($ids, 0, 3) as $i) $sug[] = ['id' => $i, 'nome' => $nomes[$i] ?? ('#' . $i), 'motivo' => implode(' + ', array_keys($mot[$i])), 'pontos' => $pts[$i]];
    $top = $ids[0]; $seg = $pts[$ids[1] ?? -1] ?? 0;
    $auto = ($pts[$top] >= 5 && $pts[$top] > $seg && !empty($mot[$top]['boleto com o valor pago'])) ? $top : null;
    return ['auto' => $auto, 'sug' => $sug];
}
/** Conferência completa → ['semaforo'=>'pronto|conferir|bloqueado','checks'=>[[true|false|null,texto],…],'titulo'=>fatura sugerida|null,'valor_lido'=>?float,'sugestoes'=>[clientes]]. */
function ws_comp_conferir(PDO $db, array $r, ?array $sl, ?array $det, array $abertosCli): array {
    $checks = []; $ruim = false; $bloq = false;
    $cid = (int)$r['cliente_id']; $valor = ($sl && $sl['valor'] !== null) ? round((float)$sl['valor'], 2) : null;
    $cli = null;
    if ($cid) {
        $q = $db->prepare("SELECT c.id, c.nome, c.cpf_cnpj, c.celular, c.telefone, t.nome tit_nome, t.cpf_cnpj tit_doc FROM ws_cliente c LEFT JOIN ws_cliente t ON t.id=c.titular_id WHERE c.id=?");
        $q->execute([$cid]); $cli = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    // o telefone de QUEM ENVIOU é um dos telefones do cadastro do cliente? (últimos 8 dígitos)
    $telBate = false;
    if ($cli) { $fim8 = substr(preg_replace('/\D/', '', (string)($r['telefone'] ?? '')), -8); if (strlen($fim8) === 8) foreach ([$cli['celular'], $cli['telefone']] as $tf) if (substr(preg_replace('/\D/', '', (string)$tf), -8) === $fim8) $telBate = true; }
    $igualCli = function (string $nome) use ($cli): bool { return $cli && (ws_comp_nomes_batem($nome, (string)$cli['nome']) || ($cli['tit_nome'] && ws_comp_nomes_batem($nome, (string)$cli['tit_nome']))); };
    // 1) cliente / telefone
    if (!$cli) { $checks[] = [false, 'Cliente não identificado pelo telefone — escolha o cliente antes de dar baixa']; $ruim = true; }
    elseif ($telBate) $checks[] = [true, 'Telefone do WhatsApp está no cadastro de ' . $cli['nome']];
    else $checks[] = [null, 'O telefone de quem enviou NÃO está no cadastro de ' . $cli['nome'] . ' — será registrado no Caixa junto com o nome de quem pagou'];
    // 2) de quem é a conta × o que o cliente disse ao robô
    $inf = trim((string)($r['nome_informado'] ?? ''));
    if ($inf !== '' && $cli) {
        if ($igualCli($inf)) $checks[] = [true, 'O nome informado ao robô ("' . $inf . '") confere com o cliente'];
        else { $checks[] = [false, 'Disse que o pagamento é de "' . $inf . '", mas o telefone está ligado a ' . $cli['nome'] . ' — confirme de quem é a conta']; $ruim = true; }
    }
    // 3) CPF/CNPJ de quem pagou (mascarado) × titular × base
    $docP = (string)($det['pagador_doc'] ?? ''); $pad = $docP !== '' ? ws_comp_doc_padrao($docP) : null;
    if ($pad) {
        $docs = [];
        if ($cli) { $docs[] = preg_replace('/\D/', '', (string)$cli['cpf_cnpj']); if ($cli['tit_doc']) $docs[] = preg_replace('/\D/', '', (string)$cli['tit_doc']); }
        $ehTit = false; foreach ($docs as $d) if ($d !== '' && ws_comp_doc_casa($pad, $d)) $ehTit = true;
        if ($ehTit) $checks[] = [true, 'CPF/CNPJ de quem pagou (' . ws_comp_doc_limpo($docP) . ') confere com o titular'];
        else {
            $outros = ws_comp_clientes_por_doc($db, $pad);
            if ($outros) $checks[] = [null, 'Quem pagou (' . ws_comp_doc_limpo($docP) . ') não é o titular, mas está na base: ' . implode(', ', array_map(fn($x) => $x['nome'] . ' (#' . $x['id'] . ')', $outros))];
            else $checks[] = [null, 'Quem pagou (' . ws_comp_doc_limpo($docP) . ') é uma terceira pessoa — CPF/CNPJ fora da base'];
        }
    } else $checks[] = [null, 'CPF/CNPJ de quem pagou não aparece no comprovante'];
    // 4) nome de quem pagou × titular (terceiro pagando?)
    $slPag = trim((string)($sl['pagador'] ?? ''));   // selo antigo pode ter guardado lixo de layout ("e destino") — 09/10/2026
    if ($slPag !== '' && (!preg_match('/^[A-ZÀ-Ú]/u', $slPag) || !preg_match('/\s/u', $slPag) || preg_match('/^(e destino|destino|dados|nome|cpf|cnpj|conta|ag[eê]ncia|institui|banco|pix|valor|data)\b/iu', $slPag))) $slPag = '';
    $slPag = preg_replace('/^(?:De|Para)\s+(?=[A-ZÀ-Ú])/u', '', $slPag);
    $pagNome = trim((string)(($det['pagador_nome'] ?? '') ?: $slPag));
    if ($pagNome !== '' && $cli) {
        if ($igualCli($pagNome)) $checks[] = [true, 'Quem pagou (' . $pagNome . ') é o próprio cliente'];
        else $checks[] = [null, 'Quem pagou (' . $pagNome . ') é diferente do cliente — vai para "Quem pagou" no Caixa e no recibo'];
    }
    // 5) o recebedor é a conta da empresa?
    $prov = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
    $cnpjProv = preg_replace('/\D/', '', (string)($prov['cnpj'] ?? '')); $recDoc = preg_replace('/\D/', '', (string)($det['recebedor_doc'] ?? ''));
    $recNome = (string)($det['recebedor_nome'] ?? '');
    $nomeProv = ws_comp_tokens(trim(($prov['fantasia'] ?? '') . ' ' . ($prov['razao'] ?? '')));
    // chave PIX do recebedor é da empresa? (telefone/WhatsApp/CNPJ/e-mail do cadastro do provedor)
    $chv = trim((string)($det['recebedor_chave'] ?? '')); $chvOk = false;
    if ($chv !== '') {
        if (strpos($chv, '@') !== false) $chvOk = strcasecmp($chv, trim((string)($prov['email'] ?? ''))) === 0;
        else {
            $cd = preg_replace('/\D/', '', $chv);
            if ($cnpjProv !== '' && $cd === $cnpjProv) $chvOk = true;
            elseif (strlen($cd) >= 10) foreach (['telefone', 'whatsapp', 'celular'] as $kf) { $tp = preg_replace('/\D/', '', (string)($prov[$kf] ?? '')); if (strlen($tp) >= 10 && substr($cd, -9) === substr($tp, -9)) $chvOk = true; }
        }
    }
    if ($recDoc !== '' && $cnpjProv !== '' && ($recDoc === $cnpjProv || (($padR0 = ws_comp_doc_padrao((string)$det['recebedor_doc'])) && ws_comp_doc_casa($padR0, $cnpjProv)))) $checks[] = [true, 'Recebedor é a conta da empresa (CNPJ confere)'];
    elseif ($chvOk) $checks[] = [true, 'Recebedor é a conta da empresa (chave PIX ' . $chv . ' é da empresa)'];
    else {
        // 09/10/2026: o nome também vale — empresa (fantasia/razão) ou o responsável por inteiro ("Wellington Severino da Silva", "... ME")
        $tkResp = ws_comp_tokens((string)($prov['responsavel'] ?? '')); $tkRec = ws_comp_tokens($recNome);
        $ehResp = $recNome !== '' && count($tkResp) >= 2 && !array_diff($tkResp, $tkRec);
        $nomeOk = $recNome !== '' && ($ehResp || ($nomeProv && array_intersect($tkRec, $nomeProv)));
        /* POSSÍVEL FRAUDE só com PROVA: o comprovante mostra um CPF/CNPJ de recebedor que NÃO é o da empresa E o nome também não é
           (dinheiro foi para outra pessoa). Leitura falha do OCR, nome diferente sem documento ou documento diferente com nome da
           empresa = "confira no extrato" (vermelho na conferência, sem a marca de fraude). */
        if ($recDoc !== '' && $cnpjProv !== '' && !$nomeOk && strlen($recDoc) >= 11 && $recNome !== '') {
            $checks[] = [false, 'ATENÇÃO: o recebedor do PIX (' . $recNome . ', ' . ws_comp_doc_limpo((string)$det['recebedor_doc']) . ') NÃO é a conta da empresa']; $bloq = true;
        } elseif ($nomeOk) $checks[] = [true, 'Recebedor (' . $recNome . ') é a empresa' . ($ehResp ? ' (nome do responsável)' : '') . ($recDoc !== '' ? ' — documento lido diferente, confira no extrato' : '')];
        elseif ($recNome !== '' || $recDoc !== '') { $checks[] = [false, 'Não deu para confirmar que o recebedor (' . ($recNome ?: $recDoc) . ') é a empresa — confira no extrato antes da baixa']; $ruim = true; }
        else $checks[] = [null, 'Recebedor não identificado no comprovante'];
    }
    // 6) valor pago × boleto
    $sug = null;
    if ($valor !== null) {
        // VÁLIDO: o valor do boleto SEM a taxa de emissão (desconto do PIX direto, sem API) OU o valor cheio com a taxa
        foreach ($abertosCli as $f) if (abs((float)$f['cobrado'] - $valor) < 0.01 || abs((float)$f['valor'] - $valor) < 0.01) { $sug = $f; break; }
        if ($sug) {
            $semTaxa = abs((float)$sug['cobrado'] - $valor) >= 0.01;
            $checks[] = [true, 'Valor pago R$ ' . number_format($valor, 2, ',', '.') . ($semTaxa ? ' é o valor do boleto #' . (int)$sug['id'] . ' sem a taxa de emissão (permitido: desconto do PIX direto)' : ' é igual ao boleto #' . (int)$sug['id'])];
        }
        elseif ($abertosCli) {
            /* 10/10/2026: diz QUANTO falta/sobra e contra qual título (antes só "não bate com nenhum"): pagou R$ 63,00 e o boleto é R$ 63,50 (60,00 + 3,50 de taxa) → diferença de R$ 0,50. */
            $prox = null; $dif = null; foreach ($abertosCli as $f) { $d = $valor - (float)$f['cobrado']; if ($dif === null || abs($d) < abs($dif)) { $dif = $d; $prox = $f; } }
            $det2 = ($prox && $dif !== null) ? ' — boleto #' . (int)$prox['id'] . ': valores aceitos R$ ' . number_format((float)$prox['cobrado'], 2, ',', '.') . ((float)$prox['cobrado'] != (float)$prox['valor'] ? ' (cheio) ou R$ ' . number_format((float)$prox['valor'], 2, ',', '.') . ' (sem a taxa de emissão, que é opcional)' : '') . '; este pagamento ficou ' . ($dif < 0 ? 'R$ ' . number_format(-$dif, 2, ',', '.') . ' abaixo do cheio' : 'R$ ' . number_format($dif, 2, ',', '.') . ' acima') : '';
            $checks[] = [false, 'Valor pago R$ ' . number_format($valor, 2, ',', '.') . ' não bate com nenhum boleto em aberto' . $det2 . '. Confira antes da baixa (valor diferente só passa com a caixa de confirmação)']; $ruim = true; }
        else { $checks[] = [false, 'Cliente sem boleto em aberto']; $ruim = true; }
    } else { $checks[] = [null, 'Valor não lido no comprovante — digite o valor que aparece na imagem']; $ruim = true; }
    /* 6b) O MÊS DESTE PIX JÁ FOI BAIXADO? (09/10/2026 — casos reais #73 e #67: o mês do PIX já estava pago direto no boleto, o cartão
       oferecia o título do MÊS SEGUINTE e a baixa caía nele sem dinheiro novo). Regra simples: o título do cliente que vence perto do PIX
       (20 dias antes até 25 dias depois) é o mês do PIX. Se ele está PAGO e não há outro título em aberto nesse período, o comprovante é
       desse pagamento: JÁ BAIXADO — sem botão de baixa. Também vale título pago com o mesmo valor pago perto da data do PIX. */
    $dPix = null; if (preg_match('#(\d{2})/(\d{2})/(\d{4})#', (string)($sl['data_pix'] ?? ''), $mdp)) $dPix = strtotime("{$mdp[3]}-{$mdp[2]}-{$mdp[1]}");
    if (!$dPix) $dPix = strtotime(substr((string)($r['criado_em'] ?? ''), 0, 10)) ?: null;
    $jaBaixado = null;
    if ($cli && $dPix) {
        $ini = date('Y-m-d', $dPix - 20 * 86400); $fim = date('Y-m-d', $dPix + 25 * 86400);
        $abertoNoMes = array_values(array_filter($abertosCli, fn($f) => (string)$f['vencimento'] >= $ini && (string)$f['vencimento'] <= $fim));
        try {
            $qp = $db->prepare("SELECT id, vencimento, data_pagamento, valor_pago FROM ws_fatura WHERE cliente_id=? AND status='pago'
                                AND ((vencimento BETWEEN ? AND ?)" . ($valor !== null ? " OR (data_pagamento BETWEEN ? AND ? AND ABS(COALESCE(valor_pago,0) - ?) < 0.01)" : '') . ")
                                ORDER BY ABS(DATEDIFF(vencimento, ?)) LIMIT 1");
            $par = [(int)$cli['id'], $ini, $fim]; if ($valor !== null) array_push($par, date('Y-m-d', $dPix - 86400), date('Y-m-d', $dPix + 5 * 86400), $valor); $par[] = date('Y-m-d', $dPix);
            $qp->execute($par); $pj = $qp->fetch(PDO::FETCH_ASSOC) ?: null;
            $peloSelo = $pj && $sl && !empty($sl['usado_em']) && (int)$sl['fatura_id'] === (int)$pj['id'];
            $abertoAteMes = array_filter($abertosCli, fn($f) => (string)$f['vencimento'] <= $fim);   // mês do PIX ou ATRASADO em aberto = pagamento legítimo de atraso
            if ($pj && !$peloSelo && !$abertoAteMes) {
                $jaBaixado = $pj;
                $checks[] = [false, 'JÁ BAIXADO: o mês deste PIX (título #' . (int)$pj['id'] . ', venc. ' . date('d/m/Y', strtotime($pj['vencimento'])) . ') já foi pago em '
                    . date('d/m/Y', strtotime((string)$pj['data_pagamento'])) . ' (R$ ' . number_format((float)$pj['valor_pago'], 2, ',', '.') . '). Este comprovante é desse pagamento — não dê baixa em outro mês'];
                $bloq = true; $sug = null;
            } elseif ($abertoNoMes && $sug && !in_array((int)$sug['id'], array_map(fn($f) => (int)$f['id'], $abertoNoMes), true)) {
                $sug = $abertoNoMes[0];   // o título do MÊS do PIX vem antes do mês seguinte
            }
        } catch (Throwable $e) {}
    }
    if ($sug && $dPix && !$bloq && strtotime((string)$sug['vencimento']) > $dPix + 25 * 86400) {
        $checks[] = [false, 'O título sugerido (#' . (int)$sug['id'] . ', venc. ' . date('d/m/Y', strtotime($sug['vencimento'])) . ') é de um mês DEPOIS do PIX — só dê baixa se for adiantamento'];
        $ruim = true;
    }
    // 7) data do PIX
    $dtP = (string)($sl['data_pix'] ?? '');
    if ($dtP !== '' && preg_match('#(\d{2})/(\d{2})/(\d{4})#', $dtP, $m)) {
        /* 09/10/2026: conta a partir de QUANDO O CLIENTE MANDOU o comprovante, não de hoje. Comprovante que chegou no dia do PIX e só
           está sendo conferido agora não é "PIX antigo" (antes ficava laranja só por esperar na fila). */
        $chegou = strtotime((string)($r['criado_em'] ?? '')) ?: time();
        $dias = (int)floor(($chegou - strtotime("{$m[3]}-{$m[2]}-{$m[1]}")) / 86400);
        if ($dias > 3) { $checks[] = [false, 'PIX de ' . $m[1] . '/' . $m[2] . '/' . $m[3] . ' — mandado ' . $dias . ' dias depois do pagamento (comprovante antigo?)']; $ruim = true; }
        else $checks[] = [true, 'PIX de ' . $m[1] . '/' . $m[2] . '/' . $m[3] . ' — comprovante mandado no prazo'];
    }
    // 8) selo / banco
    if ($sl) {
        if (($sl['leitura'] ?? '') === 'banco_ok') $checks[] = [true, 'PIX confirmado na conta do banco'];
        elseif (($sl['leitura'] ?? '') === 'banco_nao') { $checks[] = [false, 'PIX NÃO existe na conta do banco — possível fraude']; $bloq = true; }
        else $checks[] = [null, 'Ainda não conferido no banco — confira o extrato antes da baixa'];
        $propria = !empty($sl['usado_em']) && (int)($sl['fatura_id'] ?? 0) > 0 && (int)$sl['fatura_id'] === (int)($r['fatura_id'] ?? 0);   // a baixa feita POR ESTE cartão não é "repetido"
        if (!$propria && ($sl['leitura'] ?? '') !== 'banco_nao' && ($frS = ws_comp_selo_fraude($db, $sl)) !== '') { $checks[] = [false, 'Comprovante repetido — ' . preg_replace('/^⚠️ POSSÍVEL FRAUDE — /u', '', $frS)]; $bloq = true; }
        elseif (!empty($sl['duplicado_de'])) {   // mesma cópia em outro cartão, nenhuma usada ainda: só avisa (não é fraude)
            $qo = $db->prepare("SELECT comprovante_id FROM ws_pix_selo WHERE id=?"); $qo->execute([(int)$sl['duplicado_de']]); $co = (int)$qo->fetchColumn();
            $checks[] = [null, 'O mesmo comprovante também está no #' . $co . ' (sem baixa ainda) — dê baixa por um só; o outro fica bloqueado sozinho'];
        }
    }
    $sugest = [];
    if (!$cli) { try { $sugest = ws_comp_identificar($db, $r, $det, $sl)['sug']; } catch (Throwable $e) {} }   // pelo recibo (CPF, nomes, valor do boleto)
    elseif ($inf !== '' && !$igualCli($inf)) $sugest = ws_comp_sugerir_clientes($db, $inf, $cid);
    return ['ja_baixado' => $jaBaixado, 'semaforo' => $bloq ? 'bloqueado' : ($ruim ? 'conferir' : 'pronto'), 'checks' => $checks, 'titulo' => $sug, 'valor_lido' => $valor, 'sugestoes' => $sugest, 'pagador' => $pagNome, 'tel_bate' => $telBate, 'terceiro' => ($pagNome !== '' && $cli) ? !$igualCli($pagNome) : null];
}

/* ===== BAIXA AUTOMÁTICA DO COMPROVANTE CONFIRMADO NO BANCO (08/10/2026) =====
   O dinheiro é conferido NO BANCO (API PIX do BB: o E2E do comprovante tem de existir na conta) — a imagem sozinha nunca baixa nada. Quando o banco
   já baixou pelo identificador/CPF (ws_bb_processar), não há o que fazer. Quando ele NÃO achou o título (PIX por chave, sem txid) mas o comprovante veio
   do WhatsApp de um cliente identificado, baixa sozinho SE TODAS as travas passarem; senão deixa em Comprovantes PIX para o operador (nada se perde):
     1. API do BB ligada e "auto_comprovante" ligado (cache/bb_pix.json);   2. PIX recebido registrado e ainda "sem_titulo" (não baixado);
     3. valor do BANCO = valor lido no comprovante (OCR conferido contra o banco);   4. cliente identificado pelo telefone (único);
     5. quem pagou confere: CPF/CNPJ do pagador (do banco) = titular, OU nome informado ao robô = cliente;
     6. exatamente UM título em aberto com aquele valor exato;   7. comprovante não repetido e ainda não usado;   8. PIX de até 3 dias.
   Baixa pela mesma rotina das outras baixas do banco (ws_bb_baixar: recibo + desbloqueio), com "Quem pagou" = pagador do banco quando é terceiro. */
function ws_comp_auto_baixa(PDO $db, int $compId, string $e2e): string {
    if ($e2e === '' || !is_file(__DIR__ . '/bb_pix.php')) return '';
    require_once __DIR__ . '/bb_pix.php';
    if (!ws_bb_pronto() || empty(ws_bb_cfg()['auto_comprovante'])) return '';
    $q = $db->prepare("SELECT * FROM ws_pix_recebido WHERE e2e=?"); $q->execute([$e2e]); $pr = $q->fetch(PDO::FETCH_ASSOC);
    if (!$pr || $pr['situacao'] !== 'sem_titulo') return '';
    $c = $db->prepare("SELECT * FROM ws_comprovante WHERE id=?"); $c->execute([$compId]); $comp = $c->fetch(PDO::FETCH_ASSOC);
    $sl = $db->prepare("SELECT * FROM ws_pix_selo WHERE comprovante_id=?"); $sl->execute([$compId]); $selo = $sl->fetch(PDO::FETCH_ASSOC);
    if (!$comp || !$selo || $comp['status'] !== 'novo' || !empty($selo['duplicado_de']) || !empty($selo['usado_em']) || !(int)$comp['cliente_id']) return '';
    $valor = round((float)$pr['valor'], 2);
    if ($selo['valor'] === null || abs((float)$selo['valor'] - $valor) > 0.009) return '';                                    // 3
    if (!empty($pr['horario']) && time() - strtotime((string)$pr['horario']) > 3 * 86400) return '';                       // 8
    $cl = $db->prepare("SELECT c.id, c.nome, c.cpf_cnpj, t.cpf_cnpj tit_doc, t.nome tit_nome FROM ws_cliente c LEFT JOIN ws_cliente t ON t.id=c.titular_id WHERE c.id=?");
    $cl->execute([(int)$comp['cliente_id']]); $cli = $cl->fetch(PDO::FETCH_ASSOC); if (!$cli) return '';
    $docBanco = preg_replace('/\D/', '', (string)$pr['pagador_doc']);
    $limp = fn($v) => preg_replace('/\D/', '', (string)$v);
    $docOk = $docBanco !== '' && in_array($docBanco, array_filter([$limp($cli['cpf_cnpj']), $limp($cli['tit_doc'])]), true);
    $inf = trim((string)$comp['nome_informado']);
    $nomeOk = $inf !== '' && (ws_comp_nomes_batem($inf, (string)$cli['nome']) || ($cli['tit_nome'] && ws_comp_nomes_batem($inf, (string)$cli['tit_nome'])));
    /* 09/10/2026 (pedido do provedor): baixa AUTOMÁTICA só com o CPF/CNPJ de quem pagou — informado pelo BANCO — igual ao do cliente ou
       do titular. Só o nome digitado no robô não basta (alguém poderia mandar o print de um PIX de outra pessoa e dizer o nome de um
       cliente): nesse caso o comprovante fica para o financeiro conferir. */
    if (!$docOk) return '';                                                                                                    // 5
    $fs = $db->prepare("SELECT * FROM ws_fatura WHERE cliente_id=? AND status IN ('aberto','vencido') ORDER BY vencimento, id"); $fs->execute([(int)$cli['id']]);
    $iguais = [];
    foreach ($fs->fetchAll(PDO::FETCH_ASSOC) as $f) if (abs((float)ws_fatura_valor_cobrado($f) - $valor) < 0.01 || abs((float)$f['valor'] - $valor) < 0.01) $iguais[] = $f;   // com a taxa de emissão OU sem ela (desconto do PIX direto)
    if (count($iguais) !== 1) return '';                                                                                       // 6
    $f = $iguais[0];
    $p = ['endToEndId' => $e2e, 'valor' => $valor, 'horario' => $pr['horario'], 'pagador' => ['nome' => (string)$pr['pagador_nome']], '_comprovante' => $compId];
    $detA = ws_comp_detalhes($db, $compId, false) ?: [];
    $pp = trim((string)(($detA['pagador_nome'] ?? '') ?: (string)$pr['pagador_nome'] ?: $comp['nome_informado'] ?: $comp['nome_whats']));   // 09/10/2026: nome do RECIBO/banco primeiro
    if ($pp !== '' && !ws_comp_nomes_batem($pp, (string)$cli['nome'])) $p['_pago_por'] = $pp;   // quem pagou, como coletado no WhatsApp (terceiro)
    if (!ws_bb_baixar($db, $f, $p)) return '';
    $db->prepare("UPDATE ws_pix_recebido SET situacao='baixado', fatura_id=?, cliente_id=?, obs=? WHERE e2e=?")->execute([(int)$f['id'], (int)$cli['id'], 'baixa automática pelo comprovante do WhatsApp #' . $compId, $e2e]);
    $db->prepare("UPDATE ws_comprovante SET status='baixado', conferido_por='Baixa automática PIX/QR', conferido_em=NOW(), fatura_id=?, obs=? WHERE id=?")
       ->execute([(int)$f['id'], 'Baixa automática PIX/QR: PIX confirmado no Banco do Brasil', $compId]);
    if (function_exists('ws_evento')) ws_evento($db, (int)$cli['id'], 'pagamento', 'Baixa automática pelo comprovante do WhatsApp #' . $compId . ' (PIX confirmado no banco) — título #' . (int)$f['id'] . ' R$ ' . number_format($valor, 2, ',', '.'));
    return 'baixado';
}
/* ===== O ROBÔ PERGUNTA "PARA QUEM É ESSE PAGAMENTO?" (08/10/2026) =====
   Comprovante que chega FORA do passo do robô (durante atendimento humano, ou como 1ª mensagem) não traz o nome de quem é a conta. Pergunta só quando faz
   sentido (inteligente): cliente NÃO identificado pelo telefone, ou o pagador lido no comprovante é OUTRA pessoa/ilegível. Cliente identificado e pagando
   por si mesmo não é incomodado. Uma pergunta por conversa a cada 30 min; a resposta (próximo texto do cliente, até 24 h) vira "nome informado" do
   comprovante — e, se o nome achar UM cliente e o comprovante estiver sem cliente, já liga. Tudo aparece no cartão e no "Quem pagou" do Caixa. */
function ws_comp_perguntas_arq(): string { return WS_CACHE . '/comp_perguntas.json'; }
function ws_comp_perguntas_ler(): array { $j = json_decode((string)@file_get_contents(ws_comp_perguntas_arq()), true); return is_array($j) ? $j : []; }
function ws_comp_perguntas_gravar(array $j): void {
    foreach ($j as $k => $v) if (time() - (int)($v['em'] ?? 0) > 86400) unset($j[$k]);
    @file_put_contents(ws_comp_perguntas_arq(), json_encode($j), LOCK_EX); @chmod(ws_comp_perguntas_arq(), 0640);
}
/** Pergunta o nome ao cliente que mandou o comprovante $compId, se precisar. true = perguntou. */
function ws_comp_perguntar_nome(PDO $db, int $compId): bool {
    $c = $db->prepare("SELECT * FROM ws_comprovante WHERE id=?"); $c->execute([$compId]); $comp = $c->fetch(PDO::FETCH_ASSOC);
    if (!$comp || trim((string)$comp['nome_informado']) !== '' || $comp['status'] !== 'novo') return false;
    $tel = preg_replace('/\D/', '', (string)$comp['telefone']); if (strlen($tel) < 10) return false;
    $cid = (int)$comp['cliente_id']; $precisa = ($cid === 0);
    if (!$precisa) {
        $q = $db->prepare("SELECT c.nome, t.nome tit FROM ws_cliente c LEFT JOIN ws_cliente t ON t.id=c.titular_id WHERE c.id=?"); $q->execute([$cid]); $cli = $q->fetch(PDO::FETCH_ASSOC);
        $det = ws_comp_detalhes($db, $compId, true); $pag = trim((string)($det['pagador_nome'] ?? ''));
        $precisa = !$cli || $pag === '' || !(ws_comp_nomes_batem($pag, (string)$cli['nome']) || ($cli['tit'] && ws_comp_nomes_batem($pag, (string)$cli['tit'])));
    }
    if (!$precisa) return false;
    $est = ws_comp_perguntas_ler();
    if (isset($est[$tel]) && time() - (int)$est[$tel]['em'] < 1800) return false;   // já perguntou há pouco nesta conversa
    $sl = ws_comp_selar($db, $compId); $val = ($sl && $sl['valor'] !== null) ? ' de *R$ ' . number_format((float)$sl['valor'], 2, ',', '.') . '*' : '';
    $txt = "✅ Recebi seu comprovante{$val}!\n\nPara eu dar baixa no boleto certo: *para quem é esse pagamento?* Me diga o *CPF* ou o *nome do titular* da conta"
         . ($cid ? '' : ' (e o seu nome, se foi outra pessoa que pagou)') . '. 🙏';
    if (!function_exists('ws_wa_enviar')) { if (is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php'; }
    if (defined('WS_COMP_SEM_ENVIO')) { $GLOBALS['ws_comp_ultimo_envio'] = $txt; $r = ['ok' => true]; }   // teste: não manda ao cliente
    else $r = ws_wa_enviar_conversa($tel, $txt, ['evento' => 'comprovante', 'automatica' => true]);
    if (empty($r['ok'])) return false;
    $est[$tel] = ['comp' => $compId, 'em' => time()]; ws_comp_perguntas_gravar($est);
    return true;
}
/** Chamado quando chega um TEXTO do cliente: se havia pergunta de nome pendente, registra a resposta. Devolve o agradecimento enviado ou null. */
function ws_comp_pergunta_resposta(PDO $db, string $jidDigits, string $texto): ?string {
    $tel = preg_replace('/\D/', '', $jidDigits); $texto = trim($texto);
    if ($tel === '' || mb_strlen($texto) < 3 || preg_match('/^\s*\d{1,2}\s*$/', $texto) || preg_match('/^\s*(menu|sim|nao|não|ok|oi|ola|olá|bom dia|boa tarde|boa noite)\s*$/iu', $texto)) return null;
    $est = ws_comp_perguntas_ler(); $k = null;
    /* 05/11/2026 (caso Dimmas/"Debora"): a pergunta "para quem é esse pagamento?" ficou aberta 2 h e engoliu a palavra solta "Pagamento" do menu ("Anotei: pagamento de Pagamento"); o comprovante seguinte foi baixado na fatura de quem
       manda o WhatsApp e não na do titular citado. Pergunta aberta vale 90 min (igual a ws_comp_juntar_texto) e palavra genérica (pagamento, pix, boleto, comprovante…) NUNCA é nome de titular. */
    if (preg_match('/^\s*(?:(?:o|a|um|uma|meu|minha|segue|segue\s+o|aqui|esse|essa|este|esta|isso)\s+)*(?:pagamento|pagar|pagando|pagou|pago|paguei|pix|boleto|fatura|comprovante|recibo|conta|mensalidade|obrigad[oa]|valeu|segue|aqui|enviei|mandei)(?:\s+(?:do|da|de|dele|dela|meu|minha))?\s*[.!?]*\s*$/iu', $texto)) return null;
    foreach ($est as $t => $v) if (substr($t, -8) === substr($tel, -8) && time() - (int)$v['em'] < 5400) { $k = $t; break; }
    if ($k === null) return null;
    $compId = (int)$est[$k]['comp'];
    @touch(WS_CACHE . '/comp_resp_' . substr($tel, -8) . '.txt');   // o /api/audio sabe que esta resposta já foi tratada (não repete nem diz "não entendi")
    /* CPF/CNPJ na resposta ("Cpf : 090 346 604 00 / Cliente : João …"): liga o comprovante ao cadastro desse documento */
    if (preg_match('/(?<!\d)(\d[\d.\-\s\/]{9,20}\d)(?!\d)/', $texto, $mcpf)) {
        $dd = preg_replace('/\D/', '', $mcpf[1]);
        if (in_array(strlen($dd), [11, 14], true)) {
            $qc = $db->prepare("SELECT id, nome FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND status NOT IN ('cancelado','inativo','desativado') ORDER BY (titular_id IS NOT NULL), id LIMIT 1");
            $qc->execute([$dd]); $cc = $qc->fetch(PDO::FETCH_ASSOC);
            if ($cc) {
                unset($est[$k]); ws_comp_perguntas_gravar($est);
                $db->prepare("UPDATE ws_comprovante SET cliente_id=?, nome_informado=? WHERE id=? AND (cliente_id IS NULL OR cliente_id=0)")->execute([(int)$cc['id'], mb_substr((string)$cc['nome'], 0, 160), $compId]);
                $db->prepare("UPDATE ws_comprovante SET nome_informado=? WHERE id=? AND (nome_informado IS NULL OR nome_informado='')")->execute([mb_substr((string)$cc['nome'], 0, 160), $compId]);
                $ag = "✅ Obrigado! Liguei o comprovante ao cadastro de *" . mb_convert_case(mb_strtolower((string)$cc['nome'], 'UTF-8'), MB_CASE_TITLE, 'UTF-8') . "*. Já vamos conferir e dar baixa.";
                if (!function_exists('ws_wa_enviar') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
                if (defined('WS_COMP_SEM_ENVIO')) $GLOBALS['ws_comp_ultimo_envio'] = $ag;
                elseif (function_exists('ws_wa_enviar_conversa')) { try { ws_wa_enviar_conversa($tel, $ag, ['evento' => 'comprovante', 'automatica' => true]); } catch (Throwable $e) {} }
                if (function_exists('ws_sessao_concluir')) { try { ws_sessao_concluir($tel); } catch (Throwable $e) {} }
                return $ag;
            }
        }
        /* (16/10/2026, caso Ednalva Brito) CPF válido que não está no cadastro NÃO pode se perder: o cliente digitou certo e o cadastro é que podia estar com outro número. Guarda no comprovante (campo cpf)
           para o financeiro conferir, e confirma ao cliente em vez de ficar calado/pedir de novo. */
        $docValido = function_exists('ws_cpf_cnpj_valido') ? ws_cpf_cnpj_valido($dd) : in_array(strlen($dd), [11, 14], true);
        if (in_array(strlen($dd), [11, 14], true) && $docValido) {
            $db->prepare("UPDATE ws_comprovante SET cpf=? WHERE id=? AND (cpf IS NULL OR cpf='')")->execute([$dd, $compId]);
            $resto = trim(preg_replace('/\b(?:cpf|cnpj|cliente|nome|titular)\b\s*:?/iu', ' ', str_replace($mcpf[1], ' ', $texto)), " \n.,:-");
            if (mb_strlen($resto) < 3) {   // só mandou o CPF: anotado, fecha a pergunta
                unset($est[$k]); ws_comp_perguntas_gravar($est);
                $ag = "✅ Obrigado! Anotei o CPF *" . (strlen($dd) === 11 ? substr($dd, 0, 3) . '.' . substr($dd, 3, 3) . '.' . substr($dd, 6, 3) . '-' . substr($dd, 9) : $dd) . "* informado. O financeiro vai conferir o cadastro e dar baixa.";
                if (!function_exists('ws_wa_enviar') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
                if (defined('WS_COMP_SEM_ENVIO')) $GLOBALS['ws_comp_ultimo_envio'] = $ag;
                elseif (function_exists('ws_wa_enviar_conversa')) { try { ws_wa_enviar_conversa($tel, $ag, ['evento' => 'comprovante', 'automatica' => true]); } catch (Throwable $e) {} }
                if (function_exists('ws_sessao_concluir')) { try { ws_sessao_concluir($tel); } catch (Throwable $e) {} }
                return $ag;
            }
        }
        // CPF que não achou ninguém: tira o número e os rótulos ("cpf", "cliente", "nome") e segue só com o nome
        $texto = trim(preg_replace('/\b(?:cpf|cnpj|cliente|nome|titular)\b\s*:?/iu', ' ', str_replace($mcpf[1], ' ', $texto)), " \n.,:-");
    }
    $texto = trim(preg_replace('/\b(?:cliente|nome|titular)\s*:\s*/iu', '', $texto));   // "Cliente : João Nelson" → "João Nelson"
    // tira a moldura da frase ("é da Maria Silva", "o nome é…", "para o João") e deixa o nome; texto longo passa pela IA de nomes
    $nome = trim(preg_replace('/^(?:é|e|eh|foi|o nome é|o nome e|nome|para|pra|pro|de|da|do|a conta é|a conta e|é para|e para)\s+(?:(?:a|o|da|do)\s+)?/iu', '', $texto), " .,!?\n");
    $nome = trim(preg_replace('/^(?:dona|seu|sr\.?|sra\.?|senhor|senhora|dr\.?|dra\.?)\s+/iu', '', $nome));   // tira o tratamento ("dona Maria" vira "Maria")
    if (str_word_count($nome) > 6 && function_exists('ws_chatbot_texto_entender')) $nome = trim((string)ws_chatbot_texto_entender($texto, 'Nome do cliente', 'Para quem é esse pagamento? Diga o nome do titular.')) ?: $nome;
    $nome = mb_substr(mb_convert_case(mb_strtolower($nome, 'UTF-8'), MB_CASE_TITLE, 'UTF-8'), 0, 160);
    if (mb_strlen($nome) < 3) return null;
    unset($est[$k]); ws_comp_perguntas_gravar($est);
    $db->prepare("UPDATE ws_comprovante SET nome_informado=? WHERE id=? AND (nome_informado IS NULL OR nome_informado='')")->execute([$nome, $compId]);
    $c = $db->prepare("SELECT cliente_id FROM ws_comprovante WHERE id=?"); $c->execute([$compId]);
    if (!(int)$c->fetchColumn()) {   // sem cliente: se o nome achar UM cliente, liga
        $s = ws_comp_sugerir_clientes($db, $nome);
        if (count($s) === 1) $db->prepare("UPDATE ws_comprovante SET cliente_id=? WHERE id=? AND cliente_id IS NULL")->execute([(int)$s[0]['id'], $compId]);
    }
    $ag = "✅ Obrigado! Anotei: pagamento de *{$nome}*.\nJá vamos conferir e dar baixa.";
    if (!function_exists('ws_wa_enviar') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
    if (defined('WS_COMP_SEM_ENVIO')) $GLOBALS['ws_comp_ultimo_envio'] = $ag;
    elseif (function_exists('ws_wa_enviar_conversa')) { try { ws_wa_enviar_conversa($tel, $ag, ['evento' => 'comprovante', 'automatica' => true]); } catch (Throwable $e) {} }
    // Bug Geovane (13/10/2026): após confirmar o comprovante o TypeBot reiniciava o fluxo (saudação com nome da atendente).
    // Encerra a sessão idle para o robô não agir mais sobre essa conversa.
    if (function_exists('ws_sessao_concluir')) { try { ws_sessao_concluir($tel); } catch (Throwable $e) {} }
    return $ag;
}

/* JUNTAR AS PEÇAS SOLTAS (10/10/2026) — o cliente manda o comprovante e, depois, em QUALQUER lugar da conversa (até na pergunta de avaliação) escreve "CPF … / nome …".
 * Não precisa de pergunta aberta: se este WhatsApp tem um comprovante recente (≤ 90 min, status novo) AINDA SEM CLIENTE, o CPF/CNPJ (ou o nome que acha UM cadastro só) liga o
 * comprovante ao cadastro e o cliente recebe o agradecimento. Devolve a mensagem enviada ou null (nada a juntar). */
function ws_comp_juntar_texto(PDO $db, string $tel, string $texto): ?string {
    $tel = preg_replace('/\D/', '', $tel); $f8 = substr($tel, -8); $texto = trim($texto);
    if (strlen($f8) < 8 || mb_strlen($texto) < 6 || preg_match('/^\s*\d{1,2}\s*$/', $texto)) return null;
    /* O CPF solto pode ser de OUTRA conexão, para SUPORTE ("minha internet caiu, o CPF é …"), e não do dono do pagamento: texto de suporte/conexão nunca religa comprovante. */
    if (preg_match('/(suporte|sem internet|sem sinal|internet|\bnet\b|wi-?fi|roteador|modem|\bonu\b|caiu|caindo|lent[ao]|travando|t[eé]cnic|conex[aã]o|outro ponto|outra (casa|conex|linha)|outro endere|chamado|visita)/iu', $texto)) return null;
    $q = $db->prepare("SELECT id FROM ws_comprovante WHERE RIGHT(REPLACE(telefone,'+',''),8)=? AND criado_em > NOW() - INTERVAL 90 MINUTE AND status='novo' AND (cliente_id IS NULL OR cliente_id=0) ORDER BY id DESC LIMIT 1");
    $q->execute([$f8]); $compId = (int)$q->fetchColumn(); if ($compId <= 0) return null;
    $cc = null;
    if (preg_match('/(?<!\d)(\d[\d.\-\s\/]{9,20}\d)(?!\d)/', $texto, $m)) {
        $dd = preg_replace('/\D/', '', $m[1]);
        if (in_array(strlen($dd), [11, 14], true)) {
            $qc = $db->prepare("SELECT id, nome FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND status NOT IN ('cancelado','inativo','desativado') ORDER BY (titular_id IS NOT NULL), id LIMIT 1");
            $qc->execute([$dd]); $cc = $qc->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        $texto = trim(preg_replace('/\b(?:cpf|cnpj)\b\s*:?/iu', ' ', str_replace($m[1], ' ', $texto)));
    }
    if (!$cc) {   // sem CPF que ache alguém: o nome ("Cliente : João Nelson Sinfronio Filho") só vale se achar UM cadastro
        $nome = trim(preg_replace('/\b(?:cliente|nome|titular)\s*:\s*/iu', '', $texto), " \n.,:-");
        if (mb_strlen($nome) >= 8 && preg_match('/\s/u', $nome) && !preg_match('/\d/', $nome)) { $s = ws_comp_sugerir_clientes($db, $nome); if (count($s) === 1) $cc = ['id' => (int)$s[0]['id'], 'nome' => (string)($s[0]['nome'] ?? $nome)]; }
    }
    if (!$cc) return null;
    $db->prepare("UPDATE ws_comprovante SET cliente_id=?, nome_informado=COALESCE(NULLIF(nome_informado,''), ?) WHERE id=? AND (cliente_id IS NULL OR cliente_id=0)")->execute([(int)$cc['id'], mb_substr((string)$cc['nome'], 0, 160), $compId]);
    $est = ws_comp_perguntas_ler(); foreach ($est as $k => $v) if (substr((string)$k, -8) === $f8) unset($est[$k]); ws_comp_perguntas_gravar($est);
    @touch(WS_CACHE . '/comp_resp_' . $f8 . '.txt');
    $ag = "✅ Obrigado! Liguei o comprovante ao cadastro de *" . mb_convert_case(mb_strtolower((string)$cc['nome'], 'UTF-8'), MB_CASE_TITLE, 'UTF-8') . "*. Já vamos conferir e dar baixa.";
    if (!function_exists('ws_wa_enviar') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
    if (defined('WS_COMP_SEM_ENVIO')) $GLOBALS['ws_comp_ultimo_envio'] = $ag;
    elseif (function_exists('ws_wa_enviar_conversa')) { try { ws_wa_enviar_conversa($tel, $ag, ['evento' => 'comprovante', 'automatica' => true]); } catch (Throwable $e) {} }
    if (function_exists('ws_robo_log')) { try { ws_robo_log($tel, 'juntei as peças: texto solto com CPF/nome ligou o comprovante #' . $compId . ' ao cadastro de ' . mb_substr((string)$cc['nome'], 0, 40) . '.', (int)$cc['id']); } catch (Throwable $e) {} }
    return $ag;
}
/* =====================================================================================================================================
 * PEDIR CONFIRMAÇÃO DO PIX A QUEM TEM ACESSO AO BANCO (10/10/2026)
 * O atendente não vê a conta: no cartão do comprovante ele aperta "Pedir confirmação" e marca para QUEM vai (todos ou só alguns dos
 * confirmadores — Recibos → Configuração → "Confirmadores do PIX"). Cada um recebe a MESMA mensagem, com um link próprio (pix_confirmar.php,
 * sem login): "✅ Existe no banco" ou "❌ Não encontrei". A PRIMEIRA resposta vale para todos; quem abre depois vê "já respondido por fulano".
 * A API oficial da Meta não cria grupo — por isso uma linha por confirmador, ligadas pelo mesmo "grupo" (pedido).
 * Tabela ws_pix_pedido: definição única aqui (schema.php e ws_selfheal() do config.php chamam ws_pixped_sql()).
 * ===================================================================================================================================== */
function ws_pixped_sql(): string {
    return "CREATE TABLE IF NOT EXISTS ws_pix_pedido (
        id INT AUTO_INCREMENT PRIMARY KEY,
        comprovante_id INT NOT NULL,
        grupo CHAR(16) NOT NULL,
        numero VARCHAR(20) NOT NULL,
        nome VARCHAR(60) DEFAULT NULL,
        token CHAR(32) NOT NULL,
        pedido_por VARCHAR(80) DEFAULT NULL,
        enviado TINYINT NOT NULL DEFAULT 0,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resposta VARCHAR(10) DEFAULT NULL,
        respondido_em DATETIME DEFAULT NULL,
        UNIQUE KEY uq_tok (token), INDEX idx_comp (comprovante_id), INDEX idx_grupo (grupo)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
}
/** Confirmadores cadastrados (Recibos → Configuração): uma linha por pessoa, "Nome=5581999999999" ou só o número. */
function ws_pixped_destinos(): array {
    $cfg = function_exists('ws_recibo_config') ? ws_recibo_config() : [];
    $out = []; $vistos = [];
    foreach (preg_split('/[,;\r\n]+/', (string)($cfg['pix_confirmadores'] ?? '')) as $linha) {
        $linha = trim($linha); if ($linha === '') continue;
        $nome = ''; $num = $linha;
        if (strpos($linha, '=') !== false) { [$nome, $num] = array_map('trim', explode('=', $linha, 2)); }
        $dig = preg_replace('/\D/', '', $num); if (strlen($dig) < 10) continue;
        if (strlen($dig) <= 11) $dig = '55' . $dig;
        if (isset($vistos[$dig])) continue; $vistos[$dig] = 1;
        $out[] = ['numero' => $dig, 'nome' => $nome !== '' ? $nome : ('final ' . substr($dig, -4))];
    }
    return $out;
}
/** Cria o pedido e envia a mensagem para os números marcados. Devolve ['grupo'=>..., 'envios'=>[['nome','ok','raw'],...]]. */
function ws_pixped_criar(PDO $db, int $compId, array $numerosMarcados, string $por, string $baseUrl): array {
    $db->exec(ws_pixped_sql());
    $q = $db->prepare("SELECT c.id, c.criado_em, c.telefone, c.nome_whats, c.nome_informado, cl.nome cliente, s.valor, s.pagador, s.data_pix, s.e2e
                         FROM ws_comprovante c LEFT JOIN ws_cliente cl ON cl.id=c.cliente_id LEFT JOIN ws_pix_selo s ON s.comprovante_id=c.id WHERE c.id=?");
    $q->execute([$compId]); $c = $q->fetch(PDO::FETCH_ASSOC);
    if (!$c) return ['grupo' => '', 'envios' => [], 'erro' => 'comprovante não encontrado'];
    $permitidos = []; foreach (ws_pixped_destinos() as $d) $permitidos[$d['numero']] = $d;
    $alvos = []; foreach ($numerosMarcados as $n) { $n = preg_replace('/\D/', '', (string)$n); if (isset($permitidos[$n])) $alvos[$n] = $permitidos[$n]; }
    if (!$alvos) return ['grupo' => '', 'envios' => [], 'erro' => 'nenhum confirmador marcado'];
    $grupo = bin2hex(random_bytes(8)); $envios = [];
    $valor = $c['valor'] !== null ? 'R$ ' . number_format((float)$c['valor'], 2, ',', '.') : 'valor não lido';
    foreach ($alvos as $n => $d) {
        $tok = bin2hex(random_bytes(16));
        $db->prepare("INSERT INTO ws_pix_pedido (comprovante_id, grupo, numero, nome, token, pedido_por) VALUES (?,?,?,?,?,?)")->execute([$compId, $grupo, $n, $d['nome'], $tok, mb_substr($por, 0, 80)]);
        $idp = (int)$db->lastInsertId();
        $txt = "🔎 *Confirmar PIX no banco*\n\n👤 Cliente: " . (($c['cliente'] ?? '') ?: (($c['nome_informado'] ?? '') ?: (($c['nome_whats'] ?? '') ?: 'não identificado'))) . "\n💰 Valor: $valor"
             . (!empty($c['pagador']) ? "\n🙋 Pagador: {$c['pagador']}" : '') . "\n🕒 Recebido: " . date('d/m H:i', strtotime((string)$c['criado_em']))
             . (!empty($c['e2e']) ? "\n🔑 ID do PIX: {$c['e2e']}" : '') . "\n📋 Pedido por: $por\n\nVocê tem acesso à conta? Abra e responda — *quem responder primeiro vale para todos*:\n" . rtrim($baseUrl, '/') . '/pix_confirmar.php?t=' . $tok;
        $r = ['ok' => false, 'raw' => ''];
        try { $r = ws_wa_enviar_conversa($n, $txt, ['evento' => 'pix_confirmar', 'automatica' => true]);   /* aviso à equipe = texto: pelo WhatsApp comum (Wellnet-01); se estiver fora cai para a API (14/10) */ } catch (Throwable $e) { $r = ['ok' => false, 'raw' => $e->getMessage()]; }
        $db->prepare("UPDATE ws_pix_pedido SET enviado=? WHERE id=?")->execute([!empty($r['ok']) ? 1 : 0, $idp]);
        $envios[] = ['nome' => $d['nome'], 'ok' => !empty($r['ok']), 'raw' => mb_substr((string)($r['raw'] ?? ''), 0, 120)];
    }
    if (function_exists('ws_evento')) { try { $cid = (int)$db->query("SELECT cliente_id FROM ws_comprovante WHERE id=" . (int)$compId)->fetchColumn(); ws_evento($db, $cid ?: null, 'pagamento', "Pedido de confirmação do PIX (comprovante #$compId) enviado a " . implode(', ', array_column($alvos, 'nome')) . " por $por."); } catch (Throwable $e) {} }
    return ['grupo' => $grupo, 'envios' => $envios];
}
/** Estado do pedido mais recente do comprovante, para o cartão: ['estado'=>'aguardando'|'confirmado'|'nao_achou','quem','quando','para'=>[nomes]] ou null. */
function ws_pixped_estado(PDO $db, int $compId): ?array {
    try {
        $g = $db->prepare("SELECT grupo FROM ws_pix_pedido WHERE comprovante_id=? ORDER BY id DESC LIMIT 1"); $g->execute([$compId]); $grupo = (string)$g->fetchColumn();
        if ($grupo === '') return null;
        $q = $db->prepare("SELECT nome, resposta, respondido_em, criado_em FROM ws_pix_pedido WHERE grupo=? ORDER BY id"); $q->execute([$grupo]); $rows = $q->fetchAll(PDO::FETCH_ASSOC);
        $para = array_column($rows, 'nome'); $res = null;
        foreach ($rows as $r) if ($r['resposta'] !== null) { $res = $r; break; }
        if (!$res) return ['estado' => 'aguardando', 'quem' => '', 'quando' => (string)$rows[0]['criado_em'], 'para' => $para];
        return ['estado' => $res['resposta'] === 'sim' ? 'confirmado' : 'nao_achou', 'quem' => (string)$res['nome'], 'quando' => (string)$res['respondido_em'], 'para' => $para];
    } catch (Throwable $e) { return null; }
}
/** Registra a resposta de um link. Devolve ['ok'=>bool,'ja'=>bool,'quem'=>..,'resposta'=>..] — ja=true quando outro confirmador respondeu antes. */
function ws_pixped_responder(PDO $db, string $token, string $resposta): array {
    $q = $db->prepare("SELECT * FROM ws_pix_pedido WHERE token=?"); $q->execute([$token]); $p = $q->fetch(PDO::FETCH_ASSOC);
    if (!$p) return ['ok' => false, 'erro' => 'link inválido'];
    if (strtotime((string)$p['criado_em']) < time() - 3 * 86400) return ['ok' => false, 'erro' => 'link vencido'];
    $db->beginTransaction();
    try {
        $o = $db->prepare("SELECT nome, resposta, respondido_em FROM ws_pix_pedido WHERE grupo=? AND resposta IS NOT NULL ORDER BY respondido_em LIMIT 1 FOR UPDATE"); $o->execute([$p['grupo']]); $ant = $o->fetch(PDO::FETCH_ASSOC);
        if ($ant) { $db->commit(); return ['ok' => true, 'ja' => true, 'quem' => $ant['nome'], 'resposta' => $ant['resposta'], 'quando' => $ant['respondido_em']]; }
        if (!in_array($resposta, ['sim', 'nao'], true)) { $db->commit(); return ['ok' => true, 'ja' => false, 'quem' => '', 'resposta' => null]; }
        $db->prepare("UPDATE ws_pix_pedido SET resposta=?, respondido_em=NOW() WHERE id=?")->execute([$resposta, (int)$p['id']]);
        $db->commit();
    } catch (Throwable $e) { try { $db->rollBack(); } catch (Throwable $e2) {} return ['ok' => false, 'erro' => 'não consegui gravar']; }
    if (function_exists('ws_evento')) { try { $cid = (int)$db->query("SELECT cliente_id FROM ws_comprovante WHERE id=" . (int)$p['comprovante_id'])->fetchColumn(); ws_evento($db, $cid ?: null, 'pagamento', 'PIX do comprovante #' . (int)$p['comprovante_id'] . ($resposta === 'sim' ? ' CONFIRMADO no banco' : ': NÃO encontrado no banco') . ' por ' . $p['nome'] . '.'); } catch (Throwable $e) {} }
    return ['ok' => true, 'ja' => false, 'quem' => $p['nome'], 'resposta' => $resposta, 'quando' => date('Y-m-d H:i:s')];
}
