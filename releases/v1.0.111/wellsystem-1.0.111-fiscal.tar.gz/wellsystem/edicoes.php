<?php
/**
 * EDIÇÕES DO WELLSYSTEM (18/11/2026) — UMA fonte de verdade para ERP / OLT / Fiscal / Completo.
 *
 *  completo = ERP + OLT + Fiscal (comportamento de sempre; é o padrão de toda instalação antiga).
 *  erp      = só o ERP (sem OLT e sem Fiscal).
 *  olt      = só a OLT (gerência, ONUs, rede FTTH, ACS).
 *  fiscal   = só o Fiscal (NF-e, NFS-e, NFCom, produtos, tomadores, certificado).
 *
 * COMO A EDIÇÃO É DEFINIDA (nesta ordem):
 *  1. Campo `e` da CHAVE DE ATIVAÇÃO assinada (erp | olt | fiscal | completo). Ampliar = chave nova com edição maior.
 *  2. Arquivo `EDICAO` na raiz (erp | olt | fiscal). Vem DENTRO do pacote/ISO da edição; o pacote de uma edição só leva os
 *     arquivos dela, então não há o que "desbloquear". Vale para chave antiga (sem campo `e`).
 *  3. Nenhum dos dois = completo (toda instalação antiga, inclusive os servidores 18 e 19).
 *
 * Este arquivo é usado também pelo gerador de pacote (ferramentas-fornecedor) para decidir quais arquivos entram em cada edição.
 * Mexeu na lista de arquivos de um módulo? É AQUI e só aqui.
 */

/** Edições válidas e o que cada uma contém. */
function ws_edicoes_def(): array {
    return [
        'completo' => ['nome' => 'WellSystem',        'mods' => ['erp', 'olt', 'fiscal']],
        'erp'      => ['nome' => 'WellSystem ERP',    'mods' => ['erp']],
        'olt'      => ['nome' => 'WellSystem OLT',    'mods' => ['olt']],
        'fiscal'   => ['nome' => 'WellSystem Fiscal', 'mods' => ['fiscal']],
    ];
}

/** Arquivos EXCLUSIVOS de cada módulo (padrões fnmatch, caminho relativo à raiz do sistema). */
function ws_edicao_padroes(string $mod): array {
    if ($mod === 'olt') return [
        'olt.php', 'olt_*.php', 'olt_*.sh', 'olt_*.js', 'olt/*', 'acs.php', 'acs_cwmp.php',
        'rede_ftth.php', 'rede_ftth_lib.php', 'ws_olt_conferir.php', 'ws-olt-*.sh',
        'diagnostico_olt.php', 'coordenadas_onu_cli.php', 'ws_diag_onu_nome.php',
    ];
    if ($mod === 'fiscal') return [
        'fiscal.php', 'fiscal_*.php', 'nfe55.php', 'nfe55_*.php', 'nfse.php', 'nfse_*.php', 'nfcom.php',
    ];
    return [];
}

/** Bibliotecas PEQUENAS usadas pelo núcleo (backup, manutenção, cron, ponte ERP↔OLT): vão em TODAS as edições. */
function ws_edicao_compartilhados(): array {
    return ['fiscal_backup_lib.php', 'certificado_lib.php', 'ws-certificado.sh', 'olt_link.php', 'acs_lib.php', 'licenca_online.php'];   // acs_lib: o robô (ERP) troca Wi-Fi por ele
}

/** Arquivos do núcleo/ERP que uma edição ISOLADA também precisa (a lista do pacote da OLT/Fiscal inclui estes além do módulo). */
function ws_edicao_extras(string $ed): array {
    if ($ed === 'olt') return ['zonas.php', 'zonas_sync.php', 'zonas_unificar.php', 'ws_ping.php', 'socket_telnet.php'];   // Zonas/VLAN (+ sincronização) classificam as ONUs; ws_ping mantém a sessão da tela da OLT; socket_telnet = Telnet por socket
    return [];
}

/** A qual módulo pertence um arquivo (caminho relativo): 'olt', 'fiscal' ou 'erp' (resto, inclusive o compartilhado). */
function ws_edicao_modulo_do_arquivo(string $rel): string {
    $rel = ltrim(str_replace('\\', '/', $rel), '/');
    if (in_array($rel, ws_edicao_compartilhados(), true)) return 'erp';
    foreach (['olt', 'fiscal'] as $m) {
        foreach (ws_edicao_padroes($m) as $p) {
            if (fnmatch($p, $rel)) return $m;
        }
    }
    return 'erp';
}

/**
 * NÚCLEO das edições "olt" e "fiscal": o que precisa existir para logar, ativar, atualizar, fazer backup e manter o servidor.
 * (Na edição "erp" e na "completo" vale tudo que não é de outro módulo.) Os `require` desses arquivos são seguidos
 * automaticamente pelo gerador (fecho transitivo), então só entram aqui as PORTAS DE ENTRADA.
 */
function ws_edicao_nucleo_entradas(): array {
    return [
        'config.php', 'edicoes.php', 'index.php', 'schema.php', 'branding.php', 'erp.php', 'ativacao.php', 'licenca.php',
        'atualizar.php', 'atualizar_lib.php', 'atualizar_run.php', 'install.php', 'install_cli.php', 'install-check.php',
        'backup.php', 'backup_lib.php', 'manutencao.php', 'recupera_deletado.php', 'saude_run.php', 'saude_lib.php', 'rede_servidor.php',
        'usuarios.php', 'radius_sync.php', 'backup_run.php', 'backup_teste_run.php', 'schema_radius.php', 'ws_reparar.php', 'ws-ambiente.sh', 'INSTALAR.sh', 'ATUALIZAR.sh', 'WELLSYSTEM-MENU.sh', 'VERSAO',
    ];
}

/** Edição EFETIVA desta instalação. */
function ws_edicao(): string {
    static $e = null; if ($e !== null) return $e;
    $def = ws_edicoes_def();
    $lic = function_exists('ws_ativacao_ler') ? ws_ativacao_ler('ativacao') : [];
    $k = strtolower(trim((string)($lic['licenca']['e'] ?? '')));
    if ($k !== '' && isset($def[$k])) return $e = $k;                                // chave assinada com edição (ampliar = chave nova)
    $m = strtolower(trim((string)@file_get_contents(__DIR__ . '/EDICAO')));
    if ($m !== '' && isset($def[$m])) return $e = $m;                                // pacote de uma edição específica
    return $e = 'completo';                                                          // chave antiga / sem marcador = completo
}
/** A edição atual tem este módulo? ('erp' | 'olt' | 'fiscal') */
function ws_edicao_tem(string $mod): bool {
    $d = ws_edicoes_def()[ws_edicao()] ?? null;
    return $d ? in_array($mod, $d['mods'], true) : true;
}
/** Nome do produto conforme a edição (tela de login, título). */
function ws_edicao_nome(): string { return ws_edicoes_def()[ws_edicao()]['nome'] ?? 'WellSystem'; }

/** A chave (campo e) é aceita por este pacote? Pacote de edição fixa só aceita chave da mesma edição, completa ou antiga (sem campo). */
function ws_edicao_chave_aceita(array $lic): bool {
    $def = ws_edicoes_def();
    $m = strtolower(trim((string)@file_get_contents(__DIR__ . '/EDICAO')));
    if ($m === '' || $m === 'completo' || !isset($def[$m])) return true;
    $k = strtolower(trim((string)($lic['e'] ?? '')));
    return $k === '' || $k === 'completo' || $k === $m;
}

/** Este arquivo (relativo à raiz) pode ser usado na edição atual? */
function ws_edicao_arquivo_ok(string $rel): bool {
    $mod = ws_edicao_modulo_do_arquivo($rel);
    return $mod === 'erp' ? true : ws_edicao_tem($mod);
}

/** Primeira tela de quem entra em edição que não tem o painel do ERP. */
function ws_edicao_home(): string {
    switch (ws_edicao()) {
        case 'olt':    return 'olt_erp.php';
        case 'fiscal': return 'fiscal.php?p=notas';
        default:       return 'erp.php?p=dashboard';
    }
}

/** Link do menu disponível nesta edição? (módulo permitido E arquivo presente no pacote). */
function ws_edicao_href_ok(string $href): bool {
    $h = parse_url($href, PHP_URL_PATH) ?: $href;
    if ($h === '' || $h[0] === '#' || preg_match('#^(https?:)?//#', $h)) return true;
    $arq = basename($h);
    if (substr($arq, -4) !== '.php') return true;
    if (!ws_edicao_arquivo_ok($arq)) return false;
    return is_file(__DIR__ . '/' . $arq);
}

/**
 * MENU PRÓPRIO das edições que NÃO têm o ERP (OLT e Fiscal): módulo ISOLADO — nada de Clientes/Financeiro/Provedor/Migração de outro ERP/
 * Backup para MK-Auth etc. Só o que o módulo usa, mais o básico do servidor (backup do módulo, manutenção, atualização, operadores e segurança).
 * REGRA (18/11/2026): módulo isolado é tratado como se o resto do sistema NÃO existisse; tudo o que ele precisa para trabalhar sozinho
 * (cadastros, conta de recebimento, configuração) fica DENTRO dele.
 */
function ws_edicao_menu_proprio(string $ed): array {
    $basico = [
        ['label' => 'Backup', 'items' => [
            ['backup.php' . ($ed === 'fiscal' ? '?t=fiscal' : ''), $ed === 'fiscal' ? '💾 Backup do Fiscal' : '💾 Backup do sistema'],
            ['backup.php?t=lista', '🗂️ Backups salvos'],
            ['backup.php?t=smtp', '📧 Servidor de e-mail (envio do backup)'],
        ]],
        ['label' => 'Manutenção', 'href' => 'manutencao.php'],
        ['label' => 'Opções', 'items' => array_merge([
            ['erp.php?p=config&t=geral', '🎨 Geral · Marca · Operadores'],
            ['erp.php?p=config&t=seguranca', '🔐 Segurança / 2FA'],
            ['atualizar.php', '⬆️ Atualizações do sistema'],
        ], function_exists('ws_pode_configurar') && ws_pode_configurar() ? [['recupera_deletado.php', '♻️ Recupera Deletado']] : [])],
    ];
    if ($ed === 'fiscal') return array_merge([
        ['label' => 'Notas', 'sections' => [
            'Notas fiscais' => [['fiscal.php?p=notas', '🧾 Notas emitidas'], ['fiscal.php?p=nova', '➕ Nova nota'], ['fiscal.php?p=arquivos', '🗂️ Arquivos XML']],
            'Cadastros'     => [['fiscal.php?p=tomadores', '👤 Tomadores'], ['fiscal.php?p=produtos', '📦 Produtos e serviços']],
        ]],
        ['label' => 'Emissor', 'items' => [['fiscal.php?p=emissor', '⚙️ Dados do emissor e certificado'], ['fiscal.php?p=contas', '💳 Conta do PIX']]],
    ], $basico);
    if ($ed === 'olt') return array_merge([
        ['label' => 'OLT', 'sections' => [
            'Gerência'    => [['olt.php', '🛰️ Gerência OLT', '_blank'], ['olt_erp.php', '🔧 Aprovisionamento ONU / ONT'], ['olt_erp.php?p=terminal', '💻 Gerenciador (Telnet)'], ['olt_erp.php?p=config', '🔌 Conexão com a OLT'], ['diagnostico_olt.php', '🔎 Diagnóstico da OLT']],
            'Relatórios'  => [['olt_erp.php?p=trafego', '📶 Relatório de tráfego'], ['olt_erp.php?p=cto', '📍 Mapa de CTO'], ['olt_erp.php?p=cto_clientes', '📦 Relatório CTO (ONUs por caixa)']],
            'Rede óptica' => [['rede_ftth.php', '🗺️ Rede FTTH (postes, cabos, CTOs)'], ['zonas.php', '🗺️ Zonas'], ['acs.php', '📡 ACS / TR-069 (ONUs)']],
        ]],
    ], $basico);
    return [];
}

/** Títulos (trecho, minúsculo) dos cards da Manutenção que valem para cada edição sem ERP. */
function ws_edicao_manutencao_permitidos(string $ed): array {
    $comum = ['licen', 'domínio', 'hora e logs', 'internet e dns', 'reiniciar o servidor', 'verificar / criar tabelas', 'gerar backup agora', 'restaurar backup', 'resetar 2fa', 'limpar sessões', 'apagar chave de ativação'];
    return $ed === 'fiscal' ? array_merge($comum, ['backup do fiscal']) : ($ed === 'olt' ? array_merge($comum, ['olt']) : []);
}
/** Filtra o HTML da Manutenção: some o card que não é da edição (ERP/RADIUS/robô). Recorte por texto (cada card é um <form|div class="mnt-card">);
 *  NÃO usa DOM: o DOMDocument reescreve o <script> da página e a quebra. Edições erp/completo: não mexe. */
function ws_edicao_manutencao_filtrar(string $html): string {
    $ed = ws_edicao(); if (!in_array($ed, ['fiscal', 'olt'], true)) return $html;
    $ok = ws_edicao_manutencao_permitidos($ed);
    $out = ''; $pos = 0; $re = '/<(form|div)\b[^>]*\bclass="[^"]*\bmnt-card\b[^"]*"[^>]*>/u';
    while (preg_match($re, $html, $m, PREG_OFFSET_CAPTURE, $pos)) {
        $ini = $m[0][1]; $tag = $m[1][0]; $depth = 1; $scan = $ini + strlen($m[0][0]);
        while ($depth > 0 && preg_match('#<(/?)' . $tag . '\b#i', $html, $t, PREG_OFFSET_CAPTURE, $scan)) { $depth += ($t[1][0] === '/') ? -1 : 1; $scan = $t[0][1] + strlen($t[0][0]); }
        $gt = strpos($html, '>', $scan); $fim = ($gt === false) ? strlen($html) : $gt + 1;
        $card = substr($html, $ini, $fim - $ini);
        $tit = preg_match('#<h3[^>]*>(.*?)</h3>#su', $card, $h) ? mb_strtolower(trim(strip_tags($h[1])), 'UTF-8') : '';
        $bom = false; foreach ($ok as $k) if ($tit !== '' && mb_strpos($tit, $k, 0, 'UTF-8') !== false) { $bom = true; break; }
        $out .= substr($html, $pos, $ini - $pos) . ($bom ? $card : '');
        $pos = $fim;
    }
    $html = $out . substr($html, $pos);
    // seções inteiras que são do ERP/RADIUS/robô (o botão de atalho do topo nasce dessas seções, então some junto)
    $seg = preg_split('/(?=<div class="mnt-sec")/u', $html); $res = []; $apaga = false;
    foreach ($seg as $i => $x) {
        if ($i === 0) { $res[] = $x; continue; }
        $tit = preg_match('#^<div class="mnt-sec"[^>]*>(.*?)</div>#su', $x, $m) ? mb_strtolower(trim(strip_tags($m[1])), 'UTF-8') : '';
        if (mb_strpos($tit, 'indicadores', 0, 'UTF-8') !== false) $apaga = true;              // do "Indicadores" até antes de "Servidor / Banco / Infra": números de clientes/contratos
        if (mb_strpos($tit, 'servidor / banco', 0, 'UTF-8') !== false) $apaga = false;
        $fora = false; foreach (['espelho', 'rede / radius', 'financeiro / cobran', 'limpeza de dados'] as $k) if (mb_strpos($tit, $k, 0, 'UTF-8') !== false) $fora = true;
        if ($apaga || $fora) continue;
        $res[] = $x;
    }
    return implode('', $res);
}

/** Comandos de terminal da Manutenção que não fazem sentido numa edição isolada (RADIUS, MK-Auth, robô, OLT no Fiscal...). */
function ws_edicao_manutencao_cmds(array $cmds): array {
    $ed = ws_edicao(); if (!in_array($ed, ['fiscal', 'olt'], true)) return $cmds;
    $fora = ['freeradius', 'mk-auth', 'mkradius', 'apparmor', 'php-fpm', 'php-admin', 'sessões de um cliente', 'confiança'];
    if ($ed === 'fiscal') $fora[] = 'olt';
    return array_values(array_filter($cmds, function ($c) use ($fora) {
        $t = mb_strtolower(((string)($c[0] ?? '')) . ' ' . ((string)($c[1] ?? '')) . ' ' . ((string)($c[2] ?? '')), 'UTF-8');
        foreach ($fora as $k) if (mb_strpos($t, $k, 0, 'UTF-8') !== false) return false;
        return true;
    }));
}

/** Arquivos .php da raiz que esta edição pode abrir (para a busca global). null = todos (edição completa). */
function ws_edicao_busca_arquivos(): ?array {
    if (ws_edicao() === 'completo') return null;
    $ed = ws_edicao(); $o = [];
    $casa = ['erp.php', 'backup.php', 'manutencao.php', 'atualizar.php', 'ativacao.php', 'licenca.php'];   // telas do núcleo de qualquer edição
    foreach (glob(__DIR__ . '/*.php') ?: [] as $f) {
        $b = basename($f);
        if (!ws_edicao_arquivo_ok($b)) continue;
        if (in_array($ed, ['olt', 'fiscal'], true) && !(ws_edicao_modulo_do_arquivo($b) === $ed || in_array($b, array_merge($casa, ws_edicao_extras($ed)), true))) continue;   // edição isolada: só o módulo + núcleo (nada de página do ERP que veio só como biblioteca)
        $o[] = $b;
    }
    return $o;
}

/** Menu (array de grupos de ws_nav_completo) sem o que a edição não tem. */
function ws_edicao_filtrar_menu(array $grupos): array {
    $ed = ws_edicao();
    if ($ed === 'completo') return $grupos;
    if ($ed === 'fiscal' || $ed === 'olt') return ws_edicao_menu_proprio($ed);   // módulo isolado: menu próprio
    $mantem = [
        'olt'    => ['Painel', 'OLT', 'Backup', 'Provedor', 'Manutenção', 'Opções', 'Servidores'],
        'fiscal' => ['Painel', 'Cobrança', 'Backup', 'Provedor', 'Manutenção', 'Opções', 'Servidores'],
        'erp'    => null,
    ][$ed] ?? null;
    $out = [];
    foreach ($grupos as $g) {
        if ($mantem !== null && !in_array($g['label'] ?? '', $mantem, true)) continue;
        if (isset($g['href']) && !ws_edicao_href_ok((string)$g['href'])) continue;
        if (isset($g['items']) && is_array($g['items'])) {
            $g['items'] = array_values(array_filter($g['items'], fn($it) => !is_array($it) || !isset($it[0]) || ws_edicao_href_ok((string)$it[0])));
            if (!$g['items']) continue;
        }
        if (isset($g['sections']) && is_array($g['sections'])) {
            $secs = [];
            foreach ($g['sections'] as $nome => $its) {
                if (!is_array($its)) { continue; }
                $its = array_values(array_filter($its, fn($it) => !is_array($it) || !isset($it[0]) || ws_edicao_href_ok((string)$it[0])));
                if ($its) $secs[$nome] = $its;
            }
            if (!$secs) continue;
            $g['sections'] = $secs;
        }
        $out[] = $g;
    }
    return $out;
}

/**
 * GUARDA DE ROTA: página/cron de um módulo que a edição não tem NÃO abre (nem por URL direta).
 * Roda na carga do config.php. No pacote da edição o arquivo nem existe; aqui cobre a instalação "completo" com chave de edição menor.
 */
function ws_edicao_guarda(): void {
    if (ws_edicao() === 'completo') return;
    $arq = basename((string)($_SERVER['SCRIPT_FILENAME'] ?? ($_SERVER['argv'][0] ?? '')));
    if ($arq === '' || $arq === 'config.php') return;
    if (ws_edicao_arquivo_ok($arq)) return;
    if (PHP_SAPI === 'cli') exit(0);
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . htmlspecialchars(ws_edicao_nome()) . '</title>'
       . '<body style="font-family:sans-serif;text-align:center;padding:60px"><h2>Módulo não disponível nesta edição</h2>'
       . '<p>Seu plano é o <b>' . htmlspecialchars(ws_edicao_nome()) . '</b>. Para ampliar, fale com o fornecedor.</p>'
       . '<p><a href="' . htmlspecialchars(ws_edicao_home()) . '">Voltar</a></p></body>';
    exit;
}
