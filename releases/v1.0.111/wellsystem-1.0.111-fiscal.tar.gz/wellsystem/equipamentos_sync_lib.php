<?php
/**
 * WellSystem — SERIAL e MAC dos equipamentos, sozinhos (16/10/2026).
 *
 * O PROBLEMA
 *   Cadastros → Equipamentos só tinha os MODELOS (121AC, EG8145V5…) com Serial e MAC em branco, e o MAC do equipamento do cliente (Comodatos)
 *   nunca era preenchido — embora o serial já estivesse em cada contrato e o MAC passe por toda sessão do cliente no RADIUS.
 *
 * O QUE FAZ (idempotente; roda sozinho a cada ~10 min pelo radius_sync e pode ser chamado na mão)
 *   1) MAC: o "Calling-Station-Id" da sessão mais recente (60 dias) de cada login vira o equip_mac do contrato (AA:BB:CC:DD:EE:FF). É medição: troca de
 *      roteador atualiza sozinho; leitura vazia nunca apaga.
 *   1b) MODELO e TIPO: contrato sem modelo recebe o que a OLT lê da ONU (pelo serial); o tipo (ONU Bridge / ONT Router / Roteador) vem do CATÁLOGO do modelo —
 *      os cartões de Comodatos contavam o tipo digitado no contrato (673 "ONU (Bridge)" quando 272 eram ONT Router). O modo da conexão (campo equipamento) é da OLT e não é tocado.
 *   2) Unidades: cada contrato ativo com serial (equip_serial, senão sn_onu) ganha/atualiza a sua linha em ws_equipamento — serial, MAC, modelo, tipo e
 *      "Cliente: …" na observação, status comodato. Linha sem serial continua sendo o MODELO do catálogo (e guarda a foto do modelo).
 *   Não apaga nada, não mexe em contrato cancelado, e não troca o tipo/modelo que alguém já digitou na unidade (só completa o vazio).
 */

/** MAC no padrão AA:BB:CC:DD:EE:FF ('' se não for um MAC de 12 dígitos). */
function ws_equip_mac_fmt($m): string {
    $h = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', (string)$m));
    return strlen($h) === 12 ? implode(':', str_split($h, 2)) : '';
}

function ws_equip_sincronizar(PDO $db): array {
    $res = ['macs' => 0, 'unidades_novas' => 0, 'unidades_atualizadas' => 0, 'modelos' => 0, 'tipos' => 0];
    $norm = fn($s) => strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s));

    /* ---- 1) MAC por login: a sessão mais recente de cada usuário ---- */
    $macPorLogin = [];
    try {
        $q = $db->query("SELECT username, callingstationid FROM radacct WHERE acctstarttime >= (NOW() - INTERVAL 60 DAY) AND callingstationid <> '' ORDER BY acctstarttime ASC", PDO::FETCH_NUM);
        foreach ($q as $r) { $m = ws_equip_mac_fmt($r[1]); if ($m !== '') $macPorLogin[$norm($r[0])] = $m; }   // a última (mais nova) vence
    } catch (Throwable $e) {}

    $ctrs = $db->query("SELECT ct.id, ct.login_pppoe, ct.login_ipoe, ct.ont_id, ct.sn_onu, ct.equip_serial, ct.equip_modelo, ct.equip_tipo, ct.equip_mac, cl.nome
                          FROM ws_contrato ct JOIN ws_cliente cl ON cl.id = ct.cliente_id WHERE ct.status <> 'cancelado'")->fetchAll(PDO::FETCH_ASSOC);
    $updMac = $db->prepare("UPDATE ws_contrato SET equip_mac=? WHERE id=?");
    foreach ($ctrs as &$c) {
        foreach ([$c['login_pppoe'], $c['login_ipoe'], $c['ont_id'], $c['sn_onu']] as $lg) {
            $k = $norm($lg); if ($k !== '' && isset($macPorLogin[$k])) {
                $m = $macPorLogin[$k];
                if (ws_equip_mac_fmt($c['equip_mac']) !== $m) { $updMac->execute([$m, (int)$c['id']]); $res['macs']++; }
                $c['equip_mac'] = $m; break;
            }
        }
    }
    unset($c);

    /* ---- 1b) modelo (OLT) e tipo (catálogo do modelo) ---- */
    $nm = fn($x) => preg_replace('/[^A-Z0-9]/', '', mb_strtoupper((string)$x, 'UTF-8'));
    $catTipo = [];
    foreach ($db->query("SELECT modelo, tipo FROM ws_equipamento WHERE TRIM(COALESCE(serial,''))='' AND modelo<>'' AND TRIM(COALESCE(tipo,''))<>'' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $e) { $k = $nm($e['modelo']); if ($k !== '' && !isset($catTipo[$k])) $catTipo[$k] = (string)$e['tipo']; }
    $oltModelo = [];
    foreach ([__DIR__ . '/cache_trafego/olt_onus_cache.json', (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/olt_onus_cache.json'] as $arq) {
        if (!is_file($arq)) continue; $j = json_decode((string)@file_get_contents($arq), true);
        foreach ((is_array($j) ? ($j['slots'] ?? []) : []) as $lista) { if (!is_array($lista)) continue; foreach ($lista as $o) { if (is_array($o) && trim((string)($o['modelo'] ?? '')) !== '' && trim((string)($o['serial'] ?? '')) !== '') $oltModelo[$norm($o['serial'])] = trim((string)$o['modelo']); } }
        if ($oltModelo) break;
    }
    $updMod = $db->prepare("UPDATE ws_contrato SET equip_modelo=? WHERE id=?"); $updTipo = $db->prepare("UPDATE ws_contrato SET equip_tipo=? WHERE id=?");
    foreach ($ctrs as &$c) {
        if (trim((string)$c['equip_modelo']) === '') {
            $sn = $norm(trim((string)$c['equip_serial']) !== '' ? $c['equip_serial'] : $c['sn_onu']);
            if ($sn !== '' && isset($oltModelo[$sn])) { $c['equip_modelo'] = $oltModelo[$sn]; $updMod->execute([$c['equip_modelo'], (int)$c['id']]); $res['modelos']++; }
        }
        $kt = $nm($c['equip_modelo']); $tipoCat = null;
        if ($kt !== '') {
            if (isset($catTipo[$kt])) $tipoCat = $catTipo[$kt];
            else { $melhor = 0; foreach ($catTipo as $kc => $tc) if (strlen((string)$kc) >= 4 && strlen($kt) >= 4 && (strpos($kt, (string)$kc) !== false || strpos((string)$kc, $kt) !== false) && strlen((string)$kc) > $melhor) { $tipoCat = $tc; $melhor = strlen((string)$kc); } }   // "Loco" = "Nano M5Loco-Ubiquit"; "GPT2742GX4X5" = "GPT2742GX4X5-GVT"
        }
        if ($tipoCat !== null && trim((string)$c['equip_tipo']) !== $tipoCat) { $c['equip_tipo'] = $tipoCat; $updTipo->execute([$tipoCat, (int)$c['id']]); $res['tipos']++; }
    }
    unset($c);

    /* ---- 2) uma linha de ws_equipamento por unidade (serial) ---- */
    try { $db->exec("DELETE FROM ws_equipamento WHERE obs LIKE 'Cliente: %preenchido automaticamente' AND TRIM(COALESCE(serial,'')) <> '' AND UPPER(serial) NOT REGEXP '^[0-9A-F]{16}$' AND id NOT IN (SELECT x.id FROM (SELECT e.id FROM ws_equipamento e) x WHERE 1=0)"); } catch (Throwable $e) {}
    $existe = [];
    foreach ($db->query("SELECT id, tipo, modelo, serial, mac, status, obs FROM ws_equipamento WHERE TRIM(COALESCE(serial,'')) <> ''")->fetchAll(PDO::FETCH_ASSOC) as $e) $existe[$norm($e['serial'])] = $e;
    $ins = $db->prepare("INSERT INTO ws_equipamento (tipo, modelo, serial, mac, status, obs, ativo) VALUES (?, ?, ?, ?, 'comodato', ?, 1)");
    $upd = $db->prepare("UPDATE ws_equipamento SET tipo=?, modelo=?, mac=?, status='comodato', obs=? WHERE id=?");
    foreach ($ctrs as $c) {
        $serial = trim((string)$c['equip_serial']) !== '' ? trim((string)$c['equip_serial']) : trim((string)$c['sn_onu']);
        $k = $norm($serial); if ($k === '') continue;
        if (!preg_match('/^[0-9A-F]{16}$/', $k) && !isset($oltModelo[$k])) continue;   // login/número solto no campo serial (rádio, "1"): não é serial de equipamento
        $modelo = trim((string)$c['equip_modelo']); $tipo = trim((string)$c['equip_tipo']); $mac = ws_equip_mac_fmt($c['equip_mac']);
        $obs = 'Cliente: ' . trim((string)$c['nome']) . ' (contrato #' . (int)$c['id'] . ') — preenchido automaticamente';
        if (!isset($existe[$k])) {
            $ins->execute([$tipo, $modelo !== '' ? $modelo : 'Sem modelo', $serial, $mac !== '' ? $mac : null, $obs]);
            $existe[$k] = ['id' => (int)$db->lastInsertId(), 'tipo' => $tipo, 'modelo' => $modelo, 'mac' => $mac, 'status' => 'comodato', 'obs' => $obs];
            $res['unidades_novas']++; continue;
        }
        $e = $existe[$k];
        $novoModelo = (trim((string)$e['modelo']) === '' || $e['modelo'] === 'Sem modelo') && $modelo !== '' ? $modelo : $e['modelo'];   // só completa o vazio
        $autoGerada = strpos((string)$e['obs'], 'Cliente: ') === 0;
        $novoTipo   = (trim((string)$e['tipo']) === '' || ($autoGerada && $tipo !== '' && $e['tipo'] !== $tipo)) && $tipo !== '' ? $tipo : $e['tipo'];   // unidade gerada pelo sistema segue o tipo certo
        $novoMac    = $mac !== '' ? $mac : (string)$e['mac'];
        $obsFinal   = (trim((string)$e['obs']) === '' || strpos((string)$e['obs'], 'Cliente: ') === 0) ? $obs : (string)$e['obs'];   // observação digitada à mão fica
        if ($novoModelo !== $e['modelo'] || $novoTipo !== $e['tipo'] || $novoMac !== (string)$e['mac'] || $e['status'] !== 'comodato' || (string)$e['obs'] !== $obsFinal) {
            $upd->execute([$novoTipo, $novoModelo, $novoMac !== '' ? $novoMac : null, $obsFinal, (int)$e['id']]); $res['unidades_atualizadas']++;
        }
    }
    return $res;
}
