<?php
/**
 * WellSystem — ERP (Fase 1: Clientes, Contratos, Planos).
 * App single-file: login de sessão + roteador por ?p= + handlers POST.
 * Banco próprio `wellsystem` (ver config.php / install.php).
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/backup_lib.php';
// Nunca deixa o navegador cachear o HTML do painel — evita ficar preso numa versão antiga em cache.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__ . '/anexos.php';
require_once __DIR__ . '/charts.php';
require_once __DIR__ . '/seguranca.php';
require_once __DIR__ . '/twofa.php';
require_once __DIR__ . '/radius_lib.php';

// MODO MANUTENÇÃO: com ele ativo, só admin/root consegue usar o sistema. Quem já estava logado
// sem ser admin/root é desconectado agora — a próxima ação já cai na tela de login.
if (function_exists('ws_manutencao_login_bloqueia') && !empty($_SESSION['ws_user']) && ws_manutencao_login_bloqueia($_SESSION['ws_user'])) {
    unset($_SESSION['ws_user']);
}
// Gate de ATIVAÇÃO (anti-cópia amarrada ao domínio): se há senha definida (licenca.php) e este
// servidor/domínio ainda não foi ativado, manda pra tela de ativação antes de qualquer coisa.
if (function_exists('ws_ativacao_exigida') && ws_ativacao_exigida() && !ws_ativado()) { header('Location: ativacao.php'); exit; }
// BANCO INACESSÍVEL (instalação nova, configuração perdida, tabelas ausentes): em vez de a tela de
// login responder "Banco não instalado? Rode o install.php", vai direto ao instalador automático,
// que acha as credenciais e cria o que faltar sozinho. ws_inst=1 evita ida-e-volta infinita.
if (empty($_SESSION['ws_user']) && empty($_SESSION['ws_demo']) && empty($_GET['ws_inst'])) {
    try { ws_db()->query('SELECT 1 FROM ws_usuario LIMIT 1'); }
    catch (Throwable $e) { header('Location: install.php'); exit; }
}

/* ------------------------------------------------------------------ AUTH */
/* ws_user() agora mora em config.php (compartilhada por todas as páginas — antes só existia
   aqui, o que arriscava "função indefinida" em qualquer outra tela). */

/** Existe esse nome reduzido em outro cliente? */
function ws_nr_existe(PDO $db, string $nr, int $excId): bool {
    $st = $db->prepare("SELECT COUNT(*) FROM ws_cliente WHERE nome_resumido=? AND id<>?");
    $st->execute([$nr, $excId]); return (int)$st->fetchColumn() > 0;
}
/** Gera nome reduzido: nome+sobrenome; se repetir, junta os nomes do meio; senão, +número. */
/** <datalist> das zonas cadastradas (para os campos zona). Silencioso se a tabela não existir. */
function ws_zonas_datalist(PDO $db): string {
    try { $z = $db->query("SELECT nome FROM ws_zona WHERE ativo=1 ORDER BY nome")->fetchAll(PDO::FETCH_COLUMN); }
    catch (Throwable $e) { return ''; }
    $o = ''; foreach ($z as $n) $o .= '<option value="' . htmlspecialchars($n, ENT_QUOTES) . '">';
    return '<datalist id="ws_zonas">' . $o . '</datalist>';
}

function ws_gerar_nome_resumido(PDO $db, string $nome, int $excId): string {
    $slug = function ($s) {
        $t = @iconv('UTF-8', 'ASCII//TRANSLIT', $s); if ($t !== false) $s = $t;
        return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $s));
    };
    $stop = ['da','de','do','das','dos','e','di','du','del','la'];   // conectores ignorados
    $todas = array_values(array_filter(preg_split('/\s+/', trim($nome))));
    // parts = nomes "de verdade" (sem conectores); mantém pelo menos o primeiro se tudo virar stop
    $parts = array_values(array_filter($todas, fn($p) => !in_array(mb_strtolower($p), $stop, true)));
    if (!$parts) $parts = $todas;
    $cands = [];
    if (count($parts) >= 2) {
        // Regra: PRIMEIRO + SEGUNDO nome. Se repetir, tenta ir juntando o 3º, 4º... nome.
        $acc = $parts[0];
        for ($i = 1; $i < count($parts); $i++) { $acc .= $parts[$i]; $cands[] = $slug($acc); }
    } else {
        $cands[] = $slug($parts[0] ?? 'cliente');
    }
    foreach ($cands as $c) { if ($c !== '' && !ws_nr_existe($db, $c, $excId)) return substr($c, 0, 60); }
    $base = substr($cands[0] ?: 'cliente', 0, 55); $i = 2;
    while (ws_nr_existe($db, $base . $i, $excId)) $i++;
    return $base . $i;
}

if (($_POST['acao'] ?? '') === 'login') {
    $__lg = trim($_POST['login'] ?? ''); $__bq = ws_login_bloqueado($__lg, 'login'); $__senhaOk = false;   // limite de tentativas (17/11/2026)
    if ($__bq > 0) { $loginErro = ws_login_msg_bloqueio($__bq); }
    else try {
        $st = ws_db()->prepare("SELECT * FROM ws_usuario WHERE login=? AND ativo=1");
        $st->execute([$__lg]);
        $u = $st->fetch();
        if ($u && password_verify($_POST['senha'] ?? '', $u['senha_hash'])) {
            $__senhaOk = true; ws_login_ok($__lg, 'login');
            if (function_exists('ws_manutencao_login_bloqueia') && ws_manutencao_login_bloqueia($u)) {
                $m = trim((string)(ws_manutencao_login()['motivo'] ?? ''));
                $loginErro = 'Sistema em manutenção — só admin/root pode entrar agora.' . ($m !== '' ? ' (' . $m . ')' : '');
            } else {
            // DEMO: a conta 'admin' é só a PORTA — manda o visitante criar a conta pessoal dele.
            if (ws_em_demo() && ($u['login'] ?? '') === 'admin') { $_SESSION['ws_demo_criar'] = 1; header('Location: erp.php'); exit; }
            if (!empty($u['twofa_enabled']) && !empty($u['twofa_secret'])) {
                // 2FA ativo: guarda pendência e pede o código (não loga ainda)
                @session_regenerate_id(true);   // nova sessão ao autenticar (evita fixação de sessão)
                $_SESSION['ws_2fa_pending'] = ['id' => $u['id'], 'nome' => $u['nome'], 'nivel' => $u['nivel']];
                ws_render_2fa(''); exit;
            }
            @session_regenerate_id(true);   // nova sessão ao autenticar (evita fixação de sessão)
            $_SESSION['ws_user'] = ['id' => $u['id'], 'nome' => $u['nome'], 'nivel' => $u['nivel'], 'nivel_acesso' => (int)($u['nivel_acesso'] ?? 0), 'login' => $u['login']];
            ws_login_registrar((int)$u['id']);   // acesso atual/anterior + sessoes (barra do topo)
            // DEMO (conta pessoal): usa o TEMPO PRÓPRIO da conta.
            if (ws_em_demo()) $_SESSION['ws_demo_expira'] = ws_demo_user_expira((string)$u['login']) ?: (time() + ws_demo_horas() * 3600);
            header('Location: erp.php'); exit;
            }
        }
        if (!$__senhaOk) ws_login_falha($__lg, 'login');
        $loginErro = 'Login ou senha inválidos.';
    } catch (Throwable $e) {
        $loginErro = 'Banco não instalado? Rode o install.php. (' . h($e->getMessage()) . ')';
    }
}
// DEMO: cria a CONTA PESSOAL do visitante (login + senha próprios, tempo próprio).
if (($_POST['acao'] ?? '') === 'demo_criar_conta' && ws_em_demo()) {
    $nome  = trim($_POST['nome'] ?? '');
    $login = preg_replace('/[^a-z0-9_.]/', '', strtolower(trim($_POST['novo_login'] ?? '')));
    $senha = (string)($_POST['nova_senha'] ?? '');
    if ($nome === '' || strlen($login) < 3 || strlen($senha) < 4) { $loginErro = 'Preencha nome, login (mín. 3) e senha (mín. 4).'; $_SESSION['ws_demo_criar'] = 1; }
    else {
        try {
            $db = ws_db();
            $chk = $db->prepare("SELECT id FROM ws_usuario WHERE login=?"); $chk->execute([$login]);
            if ($chk->fetchColumn()) { $loginErro = 'Esse login já existe no demo — escolha outro.'; $_SESSION['ws_demo_criar'] = 1; }
            else {
                $db->prepare("INSERT INTO ws_usuario (nome,login,senha_hash,nivel,ativo) VALUES (?,?,?,'admin',1)")
                   ->execute([mb_substr($nome, 0, 80), $login, password_hash($senha, PASSWORD_DEFAULT)]);
                $uid = (int)$db->lastInsertId();
                try { $db->exec("UPDATE ws_usuario SET nivel_acesso=3 WHERE id=" . $uid); } catch (Throwable $e) {}
                $exp = ws_demo_user_registrar($login, ws_demo_horas());
                // Estende a janela GLOBAL do ambiente para nunca vencer antes desta conta (não reseta com gente ativa).
                $cfgD = ws_demo_cfg();
                if ((int)($cfgD['expira_em'] ?? 0) < $exp) { $cfgD['expira_em'] = $exp; ws_demo_salvar($cfgD); }
                unset($_SESSION['ws_demo_criar']);
                $_SESSION['ws_user'] = ['id' => $uid, 'nome' => $nome, 'nivel' => 'admin', 'login' => $login];
                ws_login_registrar((int)$uid);
                $_SESSION['ws_demo_expira'] = $exp;
                header('Location: erp.php'); exit;
            }
        } catch (Throwable $e) { $loginErro = 'Erro ao criar conta: ' . h($e->getMessage()); $_SESSION['ws_demo_criar'] = 1; }
    }
}
// Segundo fator: valida o código TOTP ou um código de recuperação
if (($_POST['acao'] ?? '') === 'login_2fa' && !empty($_SESSION['ws_2fa_pending'])) {
    $pend = $_SESSION['ws_2fa_pending'];
    $__bq = ws_login_bloqueado('u' . (int)$pend['id'], '2fa');   // limite de tentativas do código (17/11/2026)
    if ($__bq > 0) { ws_render_2fa(ws_login_msg_bloqueio($__bq)); exit; }
    $st = ws_db()->prepare("SELECT * FROM ws_usuario WHERE id=?"); $st->execute([$pend['id']]); $u = $st->fetch();
    $code = trim($_POST['codigo'] ?? '');
    $ok = $u && ws_totp_verifica($u['twofa_secret'], $code);
    // tenta código de recuperação (uso único)
    if (!$ok && $u && !empty($u['twofa_recovery'])) {
        $recs = json_decode($u['twofa_recovery'], true) ?: [];
        foreach ($recs as $i => $hash) {
            if (password_verify(strtoupper($code), $hash)) {
                unset($recs[$i]);
                ws_db()->prepare("UPDATE ws_usuario SET twofa_recovery=? WHERE id=?")->execute([json_encode(array_values($recs)), $u['id']]);
                $ok = true; break;
            }
        }
    }
    if (!$ok) ws_login_falha('u' . (int)$pend['id'], '2fa'); else ws_login_ok('u' . (int)$pend['id'], '2fa');
    if ($ok) {
        unset($_SESSION['ws_2fa_pending']);
        @session_regenerate_id(true);   // nova sessão ao autenticar (evita fixação de sessão)
        $_SESSION['ws_user'] = ['id' => $u['id'], 'nome' => $u['nome'], 'nivel' => $u['nivel'], 'nivel_acesso' => (int)($u['nivel_acesso'] ?? 0), 'login' => $u['login'] ?? null];
        ws_login_registrar((int)$u['id']);   // 2FA: mesmo registro dos outros caminhos de entrada
        header('Location: erp.php'); exit;
    }
    ws_render_2fa('Código inválido. Tente de novo ou use um código de recuperação.'); exit;
}
if (isset($_GET['sair'])) {
    // DEMO: deslogar NÃO sai do sandbox — mantém a sessão demo pra próxima pessoa entrar com
    // o login dela (ou admin/admin123 pra criar outra conta). Fora do demo, encerra tudo.
    if (!empty($_SESSION['ws_demo'])) {
        $exp = (int)($_SESSION['ws_demo_expira'] ?? 0);
        $_SESSION = ['ws_demo' => 1, 'ws_demo_expira' => $exp];
        header('Location: erp.php'); exit;
    }
    if (function_exists('ws_marcar_saida')) ws_marcar_saida();   // sai da lista de "Atendentes online" na hora
    session_destroy(); header('Location: erp.php'); exit;
}
// DEMO: volta da tela "criar conta" para o login (sem perder a sessão de demonstração).
if (isset($_GET['demo_login'])) { unset($_SESSION['ws_demo_criar']); header('Location: erp.php'); exit; }
// "Reflexo": ressincroniza TODO o código (recarrega o opcache do PHP) + limpa caches voláteis,
// depois desloga o usuário e pede a senha de novo. NÃO apaga nenhum dado nem configuração.
if (isset($_GET['ws_reflexo'])) {
    if (function_exists('opcache_reset')) @opcache_reset();
    clearstatcache(true);
    if (function_exists('ws_marcar_saida')) ws_marcar_saida();
    session_destroy();
    header('Location: erp.php?reflexo=1'); exit;
}
if (!empty($_SESSION['ws_2fa_pending']) && !ws_user()) { ws_render_2fa(''); exit; }

// DEMO: depois de entrar com admin/admin123, o visitante cria a CONTA PESSOAL dele.
if (ws_em_demo() && !empty($_SESSION['ws_demo_criar']) && !ws_user()) { ws_render_demo_criar($loginErro ?? ''); exit; }
/* =================================================================================================
 * PRIMEIRO ACESSO — O CLIENTE CRIA A PRÓPRIA SENHA DE ADMINISTRADOR.
 * -------------------------------------------------------------------------------------------------
 * Antes o instalador criava 'admin' com a senha 'admin123', publicada em três arquivos de
 * documentação. Toda instalação do mundo subia com a mesma senha conhecida, e quem chegasse à tela
 * de login antes do dono tomava o sistema.
 *
 * Agora o admin nasce com senha_hash VAZIO. Isso não é "senha em branco": password_verify() contra
 * hash vazio sempre falha, então ninguém entra pelo login. O único caminho é esta tela, que aparece
 * sozinha e não deixa passar.
 *
 * POR QUE É SEGURO mostrar isto sem pedir senha: o gate de ativação roda ANTES (topo deste arquivo
 * e do index.php). Sem a senha de ativação — que é sua, por instalação — ninguém chega até aqui.
 *
 * A senha criada é do CLIENTE. Ela não passa por você, não vai para arquivo nenhum e não existe em
 * lista alguma: só o hash fica no banco dele.
 * ============================================================================================== */
$wsPrimeiroAcesso = false;
if (!ws_user() && !ws_em_demo()) {
    try {
        $stPA = ws_db()->query("SELECT id, login FROM ws_usuario
                                 WHERE ativo=1 AND (senha_hash IS NULL OR senha_hash='')
                                 ORDER BY id LIMIT 1");
        $wsPrimeiroAcesso = $stPA ? ($stPA->fetch() ?: false) : false;
    } catch (Throwable $e) { $wsPrimeiroAcesso = false; }   // banco ainda não instalado: segue pro login
}

if ($wsPrimeiroAcesso && ($_POST['acao'] ?? '') === 'definir_senha_inicial') {
    $s1 = (string)($_POST['senha'] ?? '');
    $s2 = (string)($_POST['senha2'] ?? '');
    if (strlen($s1) < 6)      $loginErro = 'A senha precisa ter pelo menos 6 caracteres.';
    elseif ($s1 !== $s2)      $loginErro = 'As duas senhas não são iguais.';
    else {
        try {
            /* A condição do UPDATE repete "senha_hash vazio" de propósito: se alguém abrir esta tela
               em duas abas, ou se a senha já tiver sido definida enquanto isso, a segunda gravação
               não sobrescreve a primeira. */
            $upPA = ws_db()->prepare("UPDATE ws_usuario SET senha_hash=?
                                       WHERE id=? AND (senha_hash IS NULL OR senha_hash='')");
            $upPA->execute([password_hash($s1, PASSWORD_DEFAULT), (int)$wsPrimeiroAcesso['id']]);
            if ($upPA->rowCount() > 0) {
                header('Location: erp.php?senha_criada=1'); exit;
            }
            $loginErro = 'Esta senha já foi definida. Entre normalmente com ela.';
            $wsPrimeiroAcesso = false;
        } catch (Throwable $e) { $loginErro = 'Não consegui gravar a senha: ' . h($e->getMessage()); }
    }
}

if ($wsPrimeiroAcesso) { ws_render_senha_inicial((string)$wsPrimeiroAcesso['login'], $loginErro ?? ''); exit; }

if (!ws_user()) { ws_render_login($loginErro ?? '',
    isset($_GET['senha_criada'])
        ? '✅ Senha criada. Entre com o usuário admin e a senha que você acabou de definir.'
        : (isset($_GET['reflexo']) ? '↻ Sistema ressincronizado. Entre novamente com sua senha.' : '')); exit; }

/* --------------------------------------------------------------- ACTIONS */
$db = ws_db();
// Adicional espelha o titular na confiança: se o titular não está em confiança (pagou, venceu ou nunca
// esteve), a confiança que ficou no adicional sai AGORA — antes de qualquer tela/consulta ler o dado.
if (!empty($_SESSION['ws_user']) && empty($_GET['ws_inst']) && is_file(__DIR__ . '/atendimento_lib.php') && is_file(__DIR__ . '/atendimento.php') && function_exists('ws_nivel_acesso') && ws_nivel_acesso() >= 3) {
    require_once __DIR__ . '/atendimento_lib.php';
    if (ws_at_precisa_assistente()) { header('Location: atendimento.php?assistente=1'); exit; }
}
if (function_exists('ws_rad_espelhar_confianca_adicionais') && !empty($_SESSION['ws_user'])) { try { ws_rad_espelhar_confianca_adicionais($db); } catch (Throwable $e) {} }

/* -------------------------------------------------------------------------------------------
 * RESSINCRONIZAR CONEXÃO (AJAX).
 * Derruba a sessão do cliente para ele reautenticar do zero. Resolve "autenticado mas não
 * navega", IP preso de sessão antiga e perfil desatualizado depois de mudar plano/desbloquear.
 * NÃO altera cadastro, NÃO apaga nada — mexe só na conectividade.
 *
 * Tenta pelos dois caminhos, porque cada instalação tem um: primeiro pelo MK-Auth (onde as
 * sessões realmente ficam quando o WellSystem roda como addon) e depois pelo RADIUS próprio.
 * ------------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------------
 * DADOS DA ONU NA OLT — leitura ao vivo para a ficha do cliente.
 *
 * Tudo que a ficha marca como "auto" nasce da OLT: sinal RX/TX, zona, VLAN, placa, PON, ONT-ID e
 * o modelo/tipo do equipamento. Gravado uma vez na migração, isso envelhece: o sinal muda com
 * chuva e emenda; zona, placa e PON mudam quando a ONU é remanejada. Parado no cadastro, o campo
 * mente com cara de verdade. A ficha passa a perguntar de 45 em 45 segundos.
 *
 * LÊ O CACHE DA OLT, não a OLT. O cache é o mesmo que o Gerenciador mantém; consultar o
 * equipamento a cada 45s por ficha aberta derrubaria a sessão de telnet de quem estiver
 * trabalhando nele. Campo sem valor novo volta vazio e a tela MANTÉM o que já está — nunca apaga
 * um valor bom por causa de uma leitura que não veio.
 * ------------------------------------------------------------------------------------------- */
if (($_GET['acao'] ?? '') === 'onu_sinal') {
    header('Content-Type: application/json; charset=utf-8');
    $sn = trim((string)($_GET['sn'] ?? ''));
    if ($sn === '') { echo json_encode(['ok' => false, 'erro' => 'sem serial']); exit; }
    if (!function_exists('mk_olt_dados') && is_file(__DIR__ . '/mkauth_import.php')) {
        try { require_once __DIR__ . '/mkauth_import.php'; } catch (Throwable $e) {}
    }
    $out = [];

    /* FONTE 2 — CONCENTRADOR. Entra ANTES da OLT para que o dado da OLT, quando existir,
       prevaleça no que é dela (zona, placa, PON, sinal). A VLAN é o caso em que a conexão manda:
       é onde o cliente autenticou AGORA. Assim a ficha se completa mesmo quando a OLT está fora
       do ar — que é exatamente quando alguém está olhando o cadastro para entender o problema. */
    $lgSn = trim((string)($_GET['login'] ?? ''));
    if ($lgSn !== '' && function_exists('ws_conexao_viva') && function_exists('ws_conexao_norm')) {
        try {
            $kSn = ws_conexao_norm($lgSn);
            $viv = ws_conexao_viva(60);
            if ($kSn !== '' && !empty($viv[$kSn])) {
                if (!empty($viv[$kSn]['vlan'])) $out['vlan'] = (string)$viv[$kSn]['vlan'];
            }
        } catch (Throwable $e) {}
    }

    if (function_exists('mk_olt_dados')) {
        try {
            $d = mk_olt_dados($sn);
            if ($d) {
                // Chave = name do campo no formulário do contrato. Só sai o que tem valor.
                /* ATENÇÃO — 'ont_id' NÃO entra nesta lista, e é proposital.
                 * "ont_id" na OLT é o ÍNDICE da ONT dentro da PON (0, 1, 2 … 127). No cadastro,
                 * o campo "ID da ONU/ONT" guarda o SERIAL (ex.: 4857544385b985b3), que no IPoE
                 * ainda vira login e senha do cliente. São coisas diferentes com o mesmo nome:
                 * copiar um no outro escrevia "2" por cima do serial e derrubava a autenticação.
                 * O índice da ONT já está representado por placa_pon + pon. */
                foreach (['rx_sinal' => 'rx_sinal', 'tx_sinal' => 'tx_sinal', 'rx_olt' => 'rx_olt',
                          'zona' => 'zona', 'vlan' => 'vlan', 'placa_pon' => 'placa_pon',
                          'pon' => 'pon', 'equipamento' => 'equipamento', 'equip_modelo' => 'equip_modelo'] as $de => $para) {
                    $v = trim((string)($d[$de] ?? ''));
                    if ($v !== '') $out[$para] = $v;
                }
                // O modelo alimenta também o campo de equipamento em comodato da ficha.
                if (!empty($out['equip_modelo'])) {
                    if (function_exists('ws_equip_tipo_por_modelo')) {
                        $t = ws_equip_tipo_por_modelo($out['equip_modelo'], $sn);
                        if ($t !== '') $out['equip_tipo'] = $t;
                    }
                }
            }
        } catch (Throwable $e) {}
    }
    /* SÓ RESPONDE SE MUDOU.
     * A ficha pergunta de 45 em 45 segundos, mas o normal é a OLT devolver exatamente o mesmo
     * retrato — sinal estável, zona e PON parados há meses. Mandar o pacote inteiro de volta a
     * cada ciclo, para a tela concluir "é igual" e jogar fora, é trabalho à toa dos dois lados.
     *
     * A resposta carrega uma ASSINATURA do conjunto (md5 dos campos). A tela devolve a assinatura
     * que já tem; batendo, a resposta é só "igual: true" — sem campos, sem comparação, sem
     * escrita. Consulta descartada, como tem que ser. */
    ksort($out);
    $sig = $out ? md5(json_encode($out, JSON_UNESCAPED_UNICODE)) : '';
    if ($sig !== '' && $sig === trim((string)($_GET['sig'] ?? ''))) {
        echo json_encode(['ok' => true, 'igual' => true, 'sig' => $sig, 'em' => date('H:i:s')]);
        exit;
    }
    echo json_encode(['ok' => !empty($out), 'igual' => false, 'sig' => $sig,
                      'campos' => $out, 'em' => date('H:i:s')], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------------------------------------------------------------------------------------------
 * TEMPO DE CONEXÃO AO VIVO — alimenta o hover da coluna "Situação" na lista de Clientes.
 *
 * O uptime é renderizado uma vez, junto com a página. Numa tela que fica aberta a tarde inteira
 * no atendimento, isso vira mentira em minutos: o tooltip diz "conectado há 4 min" quando já são
 * duas horas, e a resposta ao cliente sai errada. Este endpoint devolve só o par login→uptime,
 * lido do MESMO cache de conexões do Painel (nenhuma consulta extra ao concentrador).
 * ------------------------------------------------------------------------------------------- */
/* VALIDAÇÃO DO WHATSAPP NA FICHA (15/10/2026): o ✓ verde depois de "Celular-1/2" só aparece quando a Evolution confirma que o número tem WhatsApp (resposta guardada 30 dias; "não tem" 2 dias). {ok, v: true|false|null (não deu para saber)} */
if (($_GET['acao'] ?? '') === 'wa_validar') {
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    $v = null;
    try { require_once __DIR__ . '/whatsapp.php'; $nn = preg_replace('/\D/', '', (string)($_GET['n'] ?? '')); if (strlen($nn) >= 10) $v = ws_wa_eh_whatsapp($nn); } catch (Throwable $e) {}
    echo json_encode(['ok' => true, 'v' => $v]); exit;
}
if (($_GET['acao'] ?? '') === 'conexao_uptime') {
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json; charset=utf-8');
    $out = [];
    if (function_exists('ws_conexao_viva')) {
        try {
            // 30s de validade: é a mesma cadência da tela, não adianta guardar por mais tempo.
            // Devolve uptime E ip: a lista de Clientes usa o tempo, a ficha do contrato usa o IP
            // dinâmico. Uma leitura só serve as duas — o cache das conexões é o mesmo.
            $ips = [];
            foreach (ws_conexao_viva(30) as $k => $it) {
                if (!empty($it['uptime'])) $out[$k] = (string)$it['uptime'];
                if (!empty($it['ip']))     $ips[$k] = (string)$it['ip'];
            }
        } catch (Throwable $e) {}
    }
    echo json_encode(['ok' => true, 'uptimes' => $out, 'ips' => ($ips ?? [])], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_GET['acao'] ?? '') === 'ressincronizar') {
    header('Content-Type: application/json; charset=utf-8');
    $login = trim((string)($_POST['login'] ?? $_GET['login'] ?? ''));
    if ($login === '') { echo json_encode(['status' => 'erro', 'message' => 'login vazio']); exit; }

    $msgs = [];
    $ok = false;
    if (is_file(__DIR__ . '/mkauth_bridge.php')) {
        require_once __DIR__ . '/mkauth_bridge.php';
        if (function_exists('ws_mk_desconectar')) {
            $d = ws_mk_desconectar($login);
            $ok = $ok || $d['ok'];
            $msgs[] = 'MK-Auth: ' . ($d['detalhe'] ?: ($d['ok'] ? 'ok' : 'falhou'));
        }
    }
    try { if (ws_rad_disconnect($db, $login)) { $ok = true; $msgs[] = 'RADIUS próprio: desconectado'; } }
    catch (Throwable $e) { $msgs[] = 'RADIUS próprio: ' . $e->getMessage(); }

    echo json_encode(['status' => $ok ? 'ok' : 'aviso', 'login' => $login,
                      'message' => implode(' · ', $msgs)], JSON_UNESCAPED_UNICODE);
    exit;
}
ws_selfheal($db);
$p  = $_GET['p'] ?? 'dashboard';
// Edição sem o ERP (OLT / Fiscal): o painel do ERP não existe — a primeira tela é a do módulo.
if ($p === 'dashboard' && function_exists('ws_edicao_tem') && !ws_edicao_tem('erp') && !empty($_SESSION['ws_user'])) { header('Location: ' . ws_edicao_home()); exit; }

// DEMO expirado (passou das horas) -> encerra a sessão e volta pra tela de demonstração.
if (ws_em_demo() && !ws_demo_no_prazo()) { $_SESSION = []; header('Location: demo.php'); exit; }
if (ws_em_demo() && ws_user()) ws_demo_ping();   // registra presença (contagem no card de Manutenção)

// Clientes recentes: excluir selecionados. 14/11/2026: tratado AQUI, antes de qualquer HTML — dentro da tela o header() de volta
// chegava depois do topo já enviado ("headers already sent", erp.php:2910 no log de 07/11) e a página ficava em branco depois de excluir.
if ($p === 'clientes_recentes') {
    if (isset($_POST['acao_recentes']) && $_POST['acao_recentes'] === 'excluir' && ws_pode_deletar()) {
        $ids = array_map('intval', $_POST['ids'] ?? []);
        $ramalDel = ws_ramal_atual();
        foreach ($ids as $cid) {
            if ($cid > 0) {
                // Com um ramal ativo, só apaga cliente da própria cidade (ou sem ramal) — nunca de outra.
                if ($ramalDel) {
                    $ok = $db->prepare("SELECT 1 FROM ws_cliente WHERE id=? AND (ramal_id=? OR ramal_id IS NULL)");
                    $ok->execute([$cid, $ramalDel['id']]);
                    if (!$ok->fetchColumn()) continue;
                }
                $db->prepare("DELETE FROM ws_contrato WHERE cliente_id=?")->execute([$cid]);
                $db->prepare("DELETE FROM ws_cliente WHERE id=?")->execute([$cid]);
            }
        }
        $_SESSION['ws_flash_ok'] = count($ids) . ' cliente(s) excluído(s).';
        header('Location: erp.php?p=clientes_recentes'); exit;
    }
}

// Salvar cliente
if (($_POST['acao'] ?? '') === 'salvar_cliente') {
    $id = (int)($_POST['id'] ?? 0);
    $campos = ['tipo','nome','nome_resumido','cpf_cnpj','rg_ie','inscricao_municipal','email','celular','telefone','data_nasc','data_cadastro',
               'cep','logradouro','apto_casa','numero','complemento','bairro','cidade','uf','lat','lng','status','obs','titular_id','ramal_id',
               'cob_cep','cob_logradouro','cob_apto_casa','cob_numero','cob_complemento','cob_bairro','cob_cidade','cob_uf','cob_lat','cob_lng'];   // endereço de cobrança (opcional)
    $vals = [];
    foreach ($campos as $c) { $v = trim($_POST[$c] ?? ''); $vals[$c] = ($v === '') ? null : $v; }
    // 19/11/2026: dois campos na tela (RG para Pessoa Física, IE para Pessoa Jurídica), mas um só dado no banco (rg_ie).
    $vals['rg_ie'] = (($_POST['tipo'] ?? '') === 'PJ') ? trim((string)($_POST['ie_pj'] ?? '')) : trim((string)($_POST['rg_pf'] ?? ''));
    $vals['rg_ie'] = $vals['rg_ie'] === '' ? null : $vals['rg_ie'];
    // Correção de acentuação (mojibake) — mesma função usada na migração/importação (item 5:
    // unificar em TODOS os pontos de entrada, não só no importador do MK-Auth).
    foreach (['nome','nome_resumido','logradouro','complemento','bairro','cidade','obs'] as $cm) {
        if (!empty($vals[$cm]) && is_string($vals[$cm])) $vals[$cm] = ws_fix_mojibake($vals[$cm]);
    }
    // Item 13: campo "Acesso simultâneo" removido do cadastro — não controlava a proteção real
    // (essa é feita globalmente via cache/radius.json -> simultaneas, ver radius_lib.php).
    // Coluna do banco mantida intacta, apenas deixou de ser preenchida por aqui.

    // Adicional: herda AUTOMÁTICO do titular os campos de identificação/contato/endereço que
    // ficarem em branco no cadastro (mesmo documento/família). Só preenche o que não foi digitado.
    if (!empty($vals['titular_id'])) {
        $tt = $db->prepare("SELECT cpf_cnpj,rg_ie,inscricao_municipal,email,celular,telefone,cep,logradouro,numero,complemento,bairro,cidade,uf,lat,lng,ramal_id,data_cadastro FROM ws_cliente WHERE id=?");
        $tt->execute([(int)$vals['titular_id']]);
        if ($tit = $tt->fetch(PDO::FETCH_ASSOC)) {
            foreach (['cpf_cnpj','rg_ie','inscricao_municipal','email','celular','telefone','cep','logradouro','numero','complemento','bairro','cidade','uf','lat','lng','ramal_id','data_cadastro'] as $hc) {
                if ((empty($vals[$hc]) || $vals[$hc] === null) && !empty($tit[$hc])) $vals[$hc] = $tit[$hc];
            }
        }
    }
    if (empty($vals['data_cadastro'])) $vals['data_cadastro'] = date('Y-m-d');

    // Item 6: CPF/CNPJ, RG, celular e telefone gravam SÓ DÍGITO — pontuação era gravada junto com
    // o número, e o mesmo documento digitado de duas formas virava dois valores diferentes para o
    // banco (não batia em busca, não batia em duplicidade). A máscara (000.000.000-00 etc.) passa
    // a ser só de EXIBIÇÃO — ver ws_fmt_cpf_cnpj()/ws_fmt_telefone() em config.php. Roda depois da
    // herança do titular para normalizar também o que veio herdado de um cadastro antigo.
    foreach (['cpf_cnpj', 'rg_ie', 'celular', 'telefone'] as $sn) {
        if (!empty($vals[$sn])) $vals[$sn] = ws_so_numeros($vals[$sn]) ?: null;
    }

    // Regra mínima de correção: sem NOME não salva; se estiver criando a conexão (plano/login/ID),
    // exige login e senha (PPPoE) ou o ID da ONU/ONT (IPoE). Mostra alerta e devolve o que foi digitado.
    $voltaForm = 'erp.php?p=cliente' . (!empty($_POST['titular_id']) ? '&titular=' . (int)$_POST['titular_id'] : '') . ($id ? '&id=' . $id : '');
    if (empty($vals['nome'])) {
        $_SESSION['ws_flash_err'] = '⚠️ O nome é obrigatório.';
        $_SESSION['ws_form_repost'] = $_POST; header('Location: ' . $voltaForm); exit;
    }
    // Item 4: CPF/CNPJ passa a ser mínimo obrigatório também (junto com o Nome) — antes só o nome
    // travava o cadastro. Roda depois da herança do titular, então um ADICIONAL que herdou o
    // documento do titular continua passando normal.
    if (empty($vals['cpf_cnpj'])) {
        $_SESSION['ws_flash_err'] = '⚠️ CPF/CNPJ é obrigatório.';
        $_SESSION['ws_form_repost'] = $_POST; header('Location: ' . $voltaForm); exit;
    }
    // CNPJ do próprio provedor: exceção que vale em TODAS as checagens de documento abaixo (item 3
    // e a de duplicidade mais adiante) — calculada aqui, antes de qualquer uma delas, porque antes
    // só a checagem de duplicidade conhecia essa exceção; a checagem de dígito verificador (item 3)
    // não, e travava o cadastro TITULAR com o CNPJ do provedor antes mesmo de chegar na duplicidade
    // (no ADICIONAL o campo normalmente vem herdado do titular já cadastrado, por isso não aparecia lá).
    $cnpjProv = function_exists('ws_provedor_cnpj') ? ws_provedor_cnpj() : '';
    $docLimpo = preg_replace('/\D/', '', (string)($vals['cpf_cnpj'] ?? ''));
    $ehCnpjProvedor = ($cnpjProv !== '' && $docLimpo === $cnpjProv);
    // Item 3: CPF/CNPJ com dígito verificador conferido — recusa número aleatório/sequência
    // repetida (ex.: 111.111.111-11) antes de gravar. Campo vazio continua permitido (opcional).
    // Só valida se for CADASTRO NOVO ou se o valor mudou na edição — assim um cliente antigo com
    // CPF/CNPJ "sujo" (de antes dessa validação existir) não fica travado pra editar OUTRA coisa.
    $cpfCnpjMudou = true;
    if ($id) {
        $antigoDoc = $db->prepare("SELECT cpf_cnpj FROM ws_cliente WHERE id=?"); $antigoDoc->execute([$id]);
        $cpfCnpjMudou = (string)$antigoDoc->fetchColumn() !== (string)($vals['cpf_cnpj'] ?? '');
    }
    // "Validar CPF/CNPJ" = Não (Provedor → Recursos do sistema): aceita o número sem conferir o dígito.
    if (ws_recursos()['validar_cpf'] && $cpfCnpjMudou && !empty($vals['cpf_cnpj']) && !$ehCnpjProvedor && !ws_cpf_cnpj_valido((string)$vals['cpf_cnpj'])) {
        $qtdDig = strlen(preg_replace('/\D/', '', (string)$vals['cpf_cnpj']));
        $_SESSION['ws_flash_err'] = '⚠️ CPF/CNPJ inválido — confira os números digitados.'
            . ($qtdDig !== 11 && $qtdDig !== 14 ? ' (CPF tem 11 dígitos, CNPJ tem 14 — você digitou ' . $qtdDig . ')' : '');
        $_SESSION['ws_form_repost'] = $_POST; header('Location: ' . $voltaForm); exit;
    }
    // CONEXÃO INCOMPLETA NÃO TRAVA MAIS O CADASTRO. Só Nome e CPF/CNPJ são obrigatórios (acima).
    // Sem login PPPoE / ID da ONU o contrato é criado assim mesmo, mas o operador é AVISADO que a
    // conexão ainda não está cadastrada no RADIUS (sem login não há o que autenticar) — completa
    // depois no contrato. Antes, faltar o login devolvia o formulário e impedia salvar o cliente.
    $avisoConexao = '';
    // Algum dado de conexão digitado? (plano, login, senha, ID, SN, VLAN...) — é o gatilho do contrato.
    $qTemConexao = false;
    foreach (['q_plano_id', 'q_login', 'q_senha', 'q_ont', 'q_sn', 'q_vlan', 'q_login_ipoe', 'q_placa_pon', 'q_pon'] as $qc)
        if (trim((string)($_POST[$qc] ?? '')) !== '') { $qTemConexao = true; break; }
    if (!$id && $qTemConexao) {
        $qtipo = ($_POST['q_tipo'] ?? 'pppoe') === 'ipoe' ? 'ipoe' : 'pppoe';
        $qlogin = trim($_POST['q_login'] ?? ''); $qsenha = trim($_POST['q_senha'] ?? ''); $qont = trim($_POST['q_ont'] ?? '');
        if ($qtipo === 'ipoe') { if ($qont === '' && $qlogin === '') $avisoConexao = 'ID da ONU/ONT (IPoE) não informado'; }
        else { if ($qlogin === '') $avisoConexao = 'login PPPoE não informado'; elseif ($qsenha === '') $avisoConexao = 'senha PPPoE não informada'; }
    }
    // Data de desativação: marca a data quando o cliente vira "cancelado" (desativado); ao reativar, limpa.
    // Mantém a data original se já era cancelado (não sobrescreve a cada edição).
    $campos[] = 'data_desativacao';
    if (($vals['status'] ?? '') === 'cancelado') {
        $antiga = null;
        if ($id) { $e = $db->prepare("SELECT data_desativacao FROM ws_cliente WHERE id=?"); $e->execute([$id]); $antiga = $e->fetchColumn() ?: null; }
        $vals['data_desativacao'] = $antiga ?: date('Y-m-d');
    } else {
        $vals['data_desativacao'] = null;
    }
    // CPF/CNPJ já usado por outro cliente -> BLOQUEIA o cadastro E TAMBÉM A EDIÇÃO (antes só o
    // cadastro novo checava; alterar um cliente pra um CPF/CNPJ de outro passava direto). Não
    // existe mais opção de "forçar"/prosseguir mesmo assim. Regras de exceção — as ÚNICAS
    // permitidas ($ehCnpjProvedor já calculado acima, antes do item 3):
    //   1) CNPJ do próprio provedor: aceito sempre, pode repetir em vários cadastros — é
    //      EXCLUSIVIDADE do provedor, só o CNPJ dele tem esse privilégio de se repetir em vários
    //      clientes/nomes diferentes.
    //   2) Cadastro ADICIONAL cujo CPF/CNPJ é o MESMO do titular ao qual está sendo vinculado: é o
    //      documento normal da família/empresa, não é uma duplicidade de verdade.
    // Fora essas duas exceções, qualquer duplicidade impede salvar o cadastro (cadastrar OU alterar).
    if (!empty($vals['cpf_cnpj']) && !$ehCnpjProvedor) {
        $dup = $db->prepare("SELECT cl.id, cl.nome, cl.cidade cidade_cli, c.nome cidade, r.nome ramal
                             FROM ws_cliente cl
                             LEFT JOIN ws_ramal r ON r.id=cl.ramal_id
                             LEFT JOIN ws_cidade c ON c.id=r.cidade_id
                             WHERE cl.cpf_cnpj=? AND cl.titular_id IS NULL AND cl.status<>'cancelado' AND cl.id<>? LIMIT 1");
        $dup->execute([$vals['cpf_cnpj'], $id]);
        if ($existe = $dup->fetch()) {
            $ehDocDoProprioTitular = !empty($vals['titular_id']) && (int)$existe['id'] === (int)$vals['titular_id'];
            if (!$ehDocDoProprioTitular) {
                // Mostra o ramal (se houver) OU, na falta dele, a cidade do cadastro — nunca fica sem local.
                $ondeRamal = !empty($existe['ramal'])
                    ? ' — ramal: ' . $existe['cidade'] . ' / ' . $existe['ramal']
                    : (!empty($existe['cidade_cli']) ? ' — cidade: ' . $existe['cidade_cli'] : '');
                $_SESSION['ws_flash_err'] = 'Este CPF/CNPJ já está cadastrado com outro cliente: ' . $existe['nome'] . ' (#' . $existe['id'] . ')' . $ondeRamal . '. Não é possível cadastrar/salvar com um CPF/CNPJ já usado por outro cliente.';
                $_SESSION['ws_form_repost'] = $_POST; // preserva o que foi digitado (item: reaproveita o cadastro em andamento)
                header('Location: ' . $voltaForm); exit;
            }
        }
    }
    // Cadastro num RAMAL (cidade) diferente do que está selecionado no topo agora — avisa e pede
    // confirmação antes de gravar lá (nunca troca sozinho: cada cidade fica isolada por padrão).
    $ramalAtivoSalvar = ws_ramal_atual();
    // A CIDADE sempre bate com o ramal escolhido — nunca deixa o cadastro num ramal com a cidade
    // de outro (o ramal manda; a cidade do endereço passa a ser a do ramal).
    if (!empty($vals['ramal_id'])) {
        $rc = $db->prepare("SELECT c.nome FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.id=?");
        $rc->execute([(int)$vals['ramal_id']]);
        if ($cidadeDoRamal = $rc->fetchColumn()) $vals['cidade'] = $cidadeDoRamal;
    }
    // Confirmação SÓ no CADASTRO NOVO em ramal diferente do que está logado (evita cadastrar na
    // cidade errada por engano). Na EDIÇÃO, trocar o ramal TRANSFERE direto — sem travar o salvar.
    $precisaConfirmar = !$id && !empty($vals['ramal_id']) && !empty($ramalAtivoSalvar['id']) && (int)$vals['ramal_id'] !== (int)$ramalAtivoSalvar['id'];
    if ($precisaConfirmar && ($_POST['forcar_outra_cidade'] ?? '') !== '1') {
        $rDest = $db->prepare("SELECT r.nome, c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.id=?");
        $rDest->execute([(int)$vals['ramal_id']]); $destino = $rDest->fetch();
        $_SESSION['ws_flash_err'] = '⚠️ Você está logado em "' . $ramalAtivoSalvar['cidade'] . ' — ' . $ramalAtivoSalvar['nome']
            . '", mas escolheu cadastrar em "' . ($destino['cidade'] ?? '?') . ' — ' . ($destino['nome'] ?? '?')
            . '". Confirme que é isso mesmo antes de salvar.';
        $_SESSION['ws_form_repost'] = $_POST;
        header('Location: erp.php?p=cliente&confirmar_cidade=1'); exit;
    }
    // 'obs' (Observações) NÃO vai para maiúsculas: guarda senha de roteador, login de suporte etc., onde maiúscula/minúscula importa (08/10/2026)
    foreach (['nome','rg_ie','logradouro','numero','complemento','bairro','cidade','uf'] as $up)
        if (!empty($vals[$up])) $vals[$up] = mb_strtoupper($vals[$up], 'UTF-8');
    if (!empty($vals['nome_resumido'])) $vals['nome_resumido'] = mb_strtolower($vals['nome_resumido'], 'UTF-8');

    /* ENDEREÇO PASSA PELO RESOLVEDOR — é aqui que a duplicata deixava de existir ou nascia.
     *
     * Antes, o que o operador digitasse ia direto para as colunas de texto do cliente. Resultado:
     * "AV. BRASIL", "AVENIDA BRASIL" e "Av Brasil" viravam três endereços distintos para o banco e
     * um só na vida real — e filtrar por rua, agrupar por bairro ou corrigir o nome de uma via
     * deixava de funcionar.
     *
     * Agora o endereço é resolvido contra as tabelas ws_logradouro / ws_bairro / ws_cidade / ws_uf /
     * ws_cep: o resolvedor encontra a rua que JÁ existe (ignorando caixa, acento, pontuação, espaço
     * repetido e abreviação de tipo de via) e devolve o CÓDIGO dela. A quinta grafia de uma avenida
     * deixa de criar a sexta linha.
     *
     * O texto continua sendo gravado ao lado, mas com a grafia CADASTRADA — não a digitada. É assim
     * que a base converge para uma escrita só, em vez de acumular variações. E é o que mantém
     * boleto, NFS-e e fiscal funcionando sem alteração: para eles nada mudou.
     */
    if (is_file(__DIR__ . '/schema_endereco.php')) {
        require_once __DIR__ . '/schema_endereco.php';
        try {
            $end = ws_end_resolver($db, [
                'cep'        => (string)($vals['cep'] ?? ''),
                'logradouro' => (string)($vals['logradouro'] ?? ''),
                'bairro'     => (string)($vals['bairro'] ?? ''),
                'cidade'     => (string)($vals['cidade'] ?? ''),
                'uf'         => (string)($vals['uf'] ?? ''),
            ]);
            if ($end['logradouro_id']) {
                // O código é a autoridade.
                if (!in_array('logradouro_id', $campos, true)) $campos[] = 'logradouro_id';
                $vals['logradouro_id'] = $end['logradouro_id'];
                foreach (['logradouro','bairro','cidade','uf','cep'] as $k)
                    if ($end[$k] !== '') $vals[$k] = $end[$k];
            }
            // Item 7: UF por ID direto no cliente, não só pontuação de texto — o resolvedor já
            // calcula o uf_id da UF digitada, mesmo quando não há rua/CEP resolvidos (cadastro
            // rápido só com cidade/UF). Grava sempre que o resolvedor achar a sigla em ws_uf.
            if ($end['uf_id']) {
                if (!in_array('uf_id', $campos, true)) $campos[] = 'uf_id';
                $vals['uf_id'] = $end['uf_id'];
            }
            /* COLUNAS DE TEXTO APOSENTADAS: saem da gravação.
             * Enquanto existem, são mantidas como cópia de leitura. Aposentadas (renomeadas pelo
             * botão em Manutenção), tentar gravá-las daria "Unknown column" e o cadastro do cliente
             * pararia de salvar. Um teste, aqui, é o que torna a aposentadoria segura e reversível
             * sem mexer em mais nada. */
            if (!ws_end_texto_ativo($db)) {
                foreach (['logradouro','bairro','cidade','uf','cep'] as $k) {
                    unset($vals[$k]);
                    $campos = array_values(array_diff($campos, [$k]));
                }
            }
        } catch (Throwable $e) { /* endereço ilegível não pode impedir o cadastro do cliente */ }
    }
    // Nome reduzido automático: nome+sobrenome; se repetir, vai juntando os nomes do meio até ficar único.
    if (empty($vals['nome_resumido']) && !empty($vals['nome'])) {
        $vals['nome_resumido'] = ws_gerar_nome_resumido($db, $vals['nome'], $id);
    }
    if ($id) {
        // Status ANTES de salvar — pra saber se o operador mudou (e aí aplicar bloqueio/desbloqueio real).
        $stOld = $db->prepare("SELECT status FROM ws_cliente WHERE id=?"); $stOld->execute([$id]); $statusAntigo = (string)$stOld->fetchColumn();
        $set = implode(',', array_map(fn($c) => "$c=:$c", $campos));
        $st = $db->prepare("UPDATE ws_cliente SET $set WHERE id=:id");
        $st->execute($vals + ['id' => $id]);
        /* Addon MK-Auth: o nome resumido editado aqui vai na hora para nome_res do MK-Auth, que é o
           nome que o FreeRADIUS de lá manda ao concentrador na sessão IPoE. Sem MK-Auth, nada acontece. */
        if (!empty($vals['nome_resumido']) && is_file(__DIR__ . '/mkauth_bridge.php')) {
            require_once __DIR__ . '/mkauth_bridge.php';
            try { ws_mk_sincronizar_nome_res($db, $id, true); } catch (Throwable $e) {}
        }
        // Cliente marcado como CANCELADO na própria ficha: remove do RADIUS na hora (todos os
        // contratos dele), em vez de esperar a próxima sincronização automática.
        if (($vals['status'] ?? '') === 'cancelado' && is_file(__DIR__ . '/radius_lib.php')) {
            require_once __DIR__ . '/radius_lib.php';
            $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
            $lg->execute([$id]);
            foreach ($lg->fetchAll(PDO::FETCH_COLUMN) as $login) { try { if (!ws_rad_disconnect($db, (string)$login) && ws_rad_sessao_aberta($db, (string)$login)) ws_rad_pendente_marcar((string)$login); } catch (Throwable $e) {} ws_rad_remover($db, (string)$login); }
            // Acabou de ser desativado: limpa ID, Login/Senha IPoE, SN ONU/ONT e Login/Senha PPPoE (03/10/2026).
            if ($statusAntigo !== 'cancelado') ws_contratos_limpar_desativacao($db, $id);
        }
        // Mudou o status para BLOQUEADO/ATIVO pelo cadastro? Aplica de verdade (contratos + RADIUS)
        // e CASCATEIA para os adicionais (REGRA GERAL). Bloqueio pelo cadastro conta como MANUAL.
        $novoStatus = (string)($vals['status'] ?? '');
        if ($novoStatus !== $statusAntigo && in_array($novoStatus, ['bloqueado', 'ativo'], true)) {
            ws_cliente_bloqueio($db, $id, $novoStatus === 'bloqueado', true, true);
        }
    } else {
        $cols = implode(',', $campos); $ph = ':' . implode(',:', $campos);
        $db->prepare("INSERT INTO ws_cliente ($cols) VALUES ($ph)")->execute($vals);
        $id = (int)$db->lastInsertId();
        ws_cliente_codigo($db, $id);   // código do cliente nasce junto
        ws_evento($db, $id, 'cliente', 'Cliente cadastrado: ' . $vals['nome']);

        // Contrato rápido: se preencheu QUALQUER dado de conexão no cadastro (plano, login, ID, SN...),
        // já cria o 1º contrato (PPPoE ou IPoE). Antes só criava com plano escolhido — no ADICIONAL o
        // operador preenchia login/ONU, salvava, e o contrato não existia (os dados se perdiam).
        // Sem plano escolhido: o ADICIONAL herda o plano do contrato ativo do titular; o titular fica
        // sem plano (aparece no contrato para completar).
        if ($qTemConexao) {
            $qPlanoId = (int)($_POST['q_plano_id'] ?? 0);
            if (!$qPlanoId && !empty($vals['titular_id'])) {
                $pt = $db->prepare("SELECT plano_id FROM ws_contrato WHERE cliente_id=? AND plano_id IS NOT NULL
                                    ORDER BY (status='cancelado') ASC, id DESC LIMIT 1");
                $pt->execute([(int)$vals['titular_id']]); $qPlanoId = (int)$pt->fetchColumn();
            }
            $valorPlano = null;
            if ($qPlanoId) { $pl = $db->prepare("SELECT valor FROM ws_plano WHERE id=?"); $pl->execute([$qPlanoId]); $valorPlano = $pl->fetchColumn(); }
            // Item 4: campo de valor não pode ficar aberto pra funcionário comum (risco de fraude —
            // digitar um valor menor que o do plano e embolsar a diferença). Só quem pode configurar
            // (nível 3+/root) tem permissão de sobrescrever o valor oficial do plano por aqui.
            if (ws_pode_editar_valor_contrato() && trim($_POST['q_valor'] ?? '') !== '') $valorPlano = (float)str_replace(',', '.', str_replace('.', '', $_POST['q_valor']));
            $tipo = ($_POST['q_tipo'] ?? 'pppoe') === 'ipoe' ? 'ipoe' : 'pppoe';
            $ont  = trim($_POST['q_ont'] ?? '') ?: null;
            if ($ont) $ont = mb_strtolower($ont, 'UTF-8');
            // IPoE: login e senha = ID da ONU/ONT (iguais). PPPoE: login/senha PRÓPRIOS do cliente
            // (ex.: joaoseverino / 1040), mesmo que o cliente tenha ID de ONU/ONT cadastrado.
            $login = $tipo === 'ipoe' ? $ont : (trim($_POST['q_login'] ?? '') ?: null);
            $senha = $tipo === 'ipoe' ? $ont : (trim($_POST['q_senha'] ?? '') ?: null);
            if ($login) $login = mb_strtolower($login, 'UTF-8');
            if ($senha) $senha = mb_strtolower($senha, 'UTF-8');
            // Concentradores: "todos" (padrão/opção do seletor) ou o concentrador único escolhido.
            $qConcRaw = trim((string)($_POST['q_concentrador_id'] ?? 'todos'));
            $qConcTodos = ($qConcRaw === 'todos' || $qConcRaw === '' || (isset($_POST['q_conc_todos']) && $_POST['q_conc_todos'] === '1'));
            $qConcId = $qConcTodos ? null : ((int)$qConcRaw ?: null);
            $qConcentradores = $qConcTodos ? 'todos' : ($qConcId ? (string)$qConcId : 'todos');
            $loginIpoe = $tipo === 'ipoe' ? (trim($_POST['q_login_ipoe'] ?? '') ?: null) : null;
            $senhaIpoe = $tipo === 'ipoe' ? (trim($_POST['q_senha_ipoe'] ?? '') ?: null) : null;
            $qBancoId = (int)($_POST['q_banco_id'] ?? 0) ?: null;   // conta que imprime o boleto/PIX
            
            // Validar se ID da ONU, SN/MAC ou Login já existe em outro contrato
            $q_sn_onu = trim($_POST['q_sn'] ?? '') ?: null;
            $chkVals = ['ont_id' => $ont, 'sn_onu' => $q_sn_onu, 'login_pppoe' => $login];
            $chkCols = ['ont_id' => 'ID da ONU/ONT', 'sn_onu' => 'SN/MAC da ONU', 'login_pppoe' => 'Login PPPoE/IPoE'];
            foreach ($chkCols as $k => $nomeLegivel) {
                if (!empty($chkVals[$k])) {
                    $qk = $db->prepare("SELECT c.nome, c.id AS cid FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE ct.$k=? LIMIT 1");
                    $qk->execute([$chkVals[$k]]);
                    if ($cx = $qk->fetch()) {
                        $_SESSION['ws_flash_warn'] = "⚠️ O cliente foi salvo, MAS A CONEXÃO NÃO: O $nomeLegivel informado já está registrado para o cliente " . h($cx['nome']) . " (#" . $cx['cid'] . "). Cadastre a conexão manualmente.";
                        header('Location: erp.php?p=cliente&id=' . $id); exit;
                    }
                }
            }

            $db->prepare("INSERT INTO ws_contrato
                          (cliente_id,plano_id,banco_id,login_pppoe,senha_pppoe,tipo_conexao,sn_onu,ont_id,vlan,zona,
                           placa_pon,pon,rx_sinal,tx_sinal,equipamento,concentrador_id,concentradores,dia_vencimento,valor,status,data_ativacao,lat,lng,inst_cidade,inst_bairro,inst_logradouro,inst_numero,login_ipoe,senha_ipoe)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'ativo', CURDATE(), ?,?,?,?,?,?,?,?)")
               ->execute([$id, $qPlanoId ?: null, $qBancoId, $login, $senha, $tipo,
                          trim($_POST['q_sn'] ?? '') ?: null, $ont, (int)($_POST['q_vlan'] ?? 0) ?: null, trim($_POST['q_zona'] ?? '') ?: null,
                          trim($_POST['q_placa_pon'] ?? '') ?: null, trim($_POST['q_pon'] ?? '') ?: null, trim($_POST['q_rx'] ?? '') ?: null, trim($_POST['q_tx'] ?? '') ?: null, trim($_POST['q_equipamento'] ?? '') ?: null,
                          $qConcId, $qConcentradores,
                          (int)($_POST['q_venc'] ?? 10), $valorPlano ?: null, $vals['lat'], $vals['lng'],
                          $vals['cidade'], $vals['bairro'], $vals['logradouro'], $vals['numero'], $loginIpoe, $senhaIpoe]);
            $ctid = (int)$db->lastInsertId();
            ws_evento($db, $id, 'contrato', 'Contrato ' . strtoupper($tipo) . ' criado no cadastro');
            if (is_file(__DIR__ . '/radius_lib.php')) {
                require_once __DIR__ . '/radius_lib.php';
                $st = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $st->execute([$ctid]); $ct = $st->fetch();
                if ($ct && $login) { try { ws_rad_sync_contrato($db, $ct, false); } catch (Throwable $e) {} }
            }
            if ($avisoConexao !== '')
                $_SESSION['ws_flash_warn'] = '⚠️ Cliente e contrato salvos, mas a conexão NÃO está cadastrada no RADIUS ('
                    . $avisoConexao . '). Complete o login/ID no contrato para o cliente conectar.';
        }

        // Item 10: ao finalizar um CADASTRO NOVO, abre automaticamente um chamado (instalação),
        // já vinculado ao cliente (e ao contrato, se um foi criado agora). Não trava o cadastro se
        // der algum erro aqui — o cliente já foi salvo, isso é só um passo a mais.
        try {
            $tituloChamado = 'Instalação — novo cliente: ' . $vals['nome'];
            $db->prepare("INSERT INTO ws_chamado (cliente_id,contrato_id,tipo,titulo,descricao,prioridade,status,aberto_por)
                          VALUES (?,?, 'instalacao', ?, 'Aberto automaticamente ao finalizar o cadastro.', 'normal', 'aberto', ?)")
               ->execute([$id, $ctid ?? null, $tituloChamado, (int)(ws_user()['id'] ?? 0) ?: null]);
            ws_evento($db, $id, 'chamado', 'Chamado de instalação aberto automaticamente no cadastro');
        } catch (Throwable $e) { /* cadastro do cliente já foi salvo; chamado é um passo a mais, não crítico */ }
    }
    // Registra a rua automaticamente (regra: 1 por CEP; ramal/cidade diferente pode repetir).
    if (!empty($vals['logradouro'])) ws_rua_registrar($db, (string)$vals['logradouro'], $vals['cep'] ?? null, $vals['cidade'] ?? null, isset($vals['ramal_id']) ? (int)$vals['ramal_id'] : null);
    // Se é adicional (tem titular_id), mantém na página dedicada dele; senão volta pra ficha normal.
    $paginaVolta = !empty($vals['titular_id']) ? 'adicional' : 'cliente';
    header("Location: erp.php?p=$paginaVolta&id=$id&ok=1"); exit;
}

// Salvar contrato
if (($_POST['acao'] ?? '') === 'salvar_contrato') {
    $id = (int)($_POST['id'] ?? 0);
    $campos = ['cliente_id','plano_id','concentrador_id','banco_id','login_pppoe','senha_pppoe','tipo_conexao',
               'login_ipoe','senha_ipoe',
               'ip_fixo','pool','sn_onu','ont_id','vlan','dia_vencimento','valor','inst_cep','inst_logradouro','inst_numero',
               'inst_complemento','inst_bairro','inst_cidade','inst_uf','lat','lng','zona',
               'placa_pon','pon','rx_sinal','tx_sinal','rx_olt','equipamento','concentradores',
               'comodato','equip_modelo','equip_serial','equip_mac','equip_foto','roteador_comodato','roteador_modelo',
               'data_ativacao','status','obs'];
    $vals = [];
    foreach ($campos as $c) { $v = trim($_POST[$c] ?? ''); $vals[$c] = ($v === '') ? null : $v; }
    // Foto do equipamento: só aceita caminho dentro do acervo (uploads/equipamentos/), por segurança.
    if (!empty($vals['equip_foto'])) {
        $ef = (string)$vals['equip_foto'];
        $vals['equip_foto'] = (strpos($ef, 'uploads/equipamentos/') === 0 && strpos($ef, '..') === false && is_file(ws_caminho_fisico($ef))) ? $ef : null;
    }
    // Concentradores: "todos" (seletor ou checkbox) ou o concentrador único escolhido.
    $cConcRaw = trim((string)($_POST['concentrador_id'] ?? 'todos'));
    $cConcTodos = ($cConcRaw === 'todos' || $cConcRaw === '' || (isset($_POST['conc_todos']) && $_POST['conc_todos'] === '1'));
    $vals['concentrador_id'] = $cConcTodos ? null : ((int)$cConcRaw ?: null);
    $vals['concentradores'] = $cConcTodos ? 'todos' : ($vals['concentrador_id'] ? (string)$vals['concentrador_id'] : 'todos');
    /* ENDEREÇO DE INSTALAÇÃO pelo mesmo resolvedor do cliente.
     *
     * O endereço de instalação é o que importa para a rede (é onde a fibra chega) e costuma ser
     * diferente do endereço de cobrança. Se ele não passasse pelo resolvedor, a normalização
     * valeria só para metade dos endereços do sistema — e a duplicata continuaria nascendo por
     * aqui, o que é pior que não normalizar, porque daria a impressão de estar resolvido. */
    if (is_file(__DIR__ . '/schema_endereco.php')) {
        require_once __DIR__ . '/schema_endereco.php';
        try {
            $endI = ws_end_resolver($db, [
                'cep'        => (string)($vals['inst_cep'] ?? ''),
                'logradouro' => (string)($vals['inst_logradouro'] ?? ''),
                'bairro'     => (string)($vals['inst_bairro'] ?? ''),
                'cidade'     => (string)($vals['inst_cidade'] ?? ''),
                'uf'         => (string)($vals['inst_uf'] ?? ''),
            ]);
            if ($endI['logradouro_id']) {
                if (!in_array('inst_logradouro_id', $campos, true)) $campos[] = 'inst_logradouro_id';
                $vals['inst_logradouro_id'] = $endI['logradouro_id'];
                foreach (['logradouro','bairro','cidade','uf','cep'] as $k)
                    if ($endI[$k] !== '') $vals['inst_' . $k] = $endI[$k];
            }
            // Item 7: mesma correção do cliente — UF do endereço de instalação por ID direto.
            if ($endI['uf_id']) {
                if (!in_array('inst_uf_id', $campos, true)) $campos[] = 'inst_uf_id';
                $vals['inst_uf_id'] = $endI['uf_id'];
            }
            // Colunas de texto aposentadas: saem da gravação (mesma razão do cadastro do cliente).
            if (!ws_end_texto_ativo($db)) {
                foreach (['inst_logradouro','inst_bairro','inst_cidade','inst_uf','inst_cep'] as $k) {
                    unset($vals[$k]);
                    $campos = array_values(array_diff($campos, [$k]));
                }
            }
        } catch (Throwable $e) { /* endereço ilegível não pode impedir o cadastro do contrato */ }
    }

    // IPoE: o ID da ONU/ONT vira o login e a senha (iguais, minúsculo).
    // PPPoE: mantém login/senha PRÓPRIOS do cliente (ex.: joaoseverino / 1040), mesmo tendo
    // ID de ONU/ONT cadastrado — o cliente PPPoE tem ONU, mas o usuário/senha são dele.
    if (!empty($vals['ont_id'])) $vals['ont_id'] = mb_strtolower($vals['ont_id'], 'UTF-8');
    if (($vals['tipo_conexao'] ?? '') === 'ipoe' && !empty($vals['ont_id'])) {
        $vals['login_pppoe'] = $vals['ont_id'];
        $vals['senha_pppoe'] = $vals['ont_id'];
    }
    // Valor mensal: por padrão vem SEMPRE do plano escolhido. Item 4: campo de valor não pode ficar
    // aberto pra funcionário comum (risco de fraude — digitar um valor menor que o do plano e
    // embolsar a diferença) — só quem pode configurar (nível 3+/root) tem permissão de gravar um
    // valor diferente do oficial do plano; o campo no formulário também fica travado (readonly)
    // pra quem não tem essa permissão, então isso aqui é o reforço do lado do servidor.
    $valorDoPlano = null;
    if (!empty($vals['plano_id'])) {
        try { $pv = $db->prepare("SELECT valor FROM ws_plano WHERE id=?"); $pv->execute([(int)$vals['plano_id']]); $pvv = $pv->fetchColumn(); if ($pvv !== false && $pvv !== null) $valorDoPlano = $pvv; } catch (Throwable $e) {}
    }
    if (!ws_pode_editar_valor_contrato()) {
        if ($valorDoPlano !== null) {
            $vals['valor'] = $valorDoPlano;
        } elseif ($id) {
            // Contrato sem plano vinculado (valor manual/negociado por quem configura): funcionário
            // comum editando outra coisa não pode zerar/alterar esse valor por tabela.
            try { $ve = $db->prepare("SELECT valor FROM ws_contrato WHERE id=?"); $ve->execute([$id]); $vve = $ve->fetchColumn(); $vals['valor'] = ($vve !== false) ? $vve : null; } catch (Throwable $e) { $vals['valor'] = null; }
        } else {
            $vals['valor'] = null; // contrato novo sem plano: campo travado, não há valor oficial pra puxar
        }
    } elseif (trim((string)($vals['valor'] ?? '')) === '' || $vals['valor'] === null) {
        $vals['valor'] = $valorDoPlano;
    } else {
        // normaliza "1.234,56" -> 1234.56 (aceita o que o operador digitou)
        $vals['valor'] = (float)str_replace(',', '.', str_replace('.', '', preg_replace('/[^\d,\.]/', '', (string)$vals['valor'])));
    }
    // REGRA: equipamento ONU => (Bridge), ONT => (Router). Se o operador não marcou "Equipamento",
    // deriva automaticamente do modelo/serial (inclusive pelo tipo cadastrado em Equipamentos).
    if (empty($vals['equipamento'])) {
        $ref = mb_strtoupper((string)($vals['equip_modelo'] ?? '') . ' ' . (string)($vals['equip_serial'] ?? ''), 'UTF-8');
        if (!empty($vals['equip_serial'])) { try { $te = $db->prepare("SELECT tipo,modelo FROM ws_equipamento WHERE serial=? LIMIT 1"); $te->execute([$vals['equip_serial']]); if ($row = $te->fetch()) $ref .= ' ' . mb_strtoupper($row['tipo'] . ' ' . $row['modelo'], 'UTF-8'); } catch (Throwable $e) {} }
        if (preg_match('/\bONT\b|ROUTER|ROTEADOR/', $ref)) $vals['equipamento'] = 'ONT (Router)';
        elseif (preg_match('/\bONU\b|BRIDGE/', $ref)) $vals['equipamento'] = 'ONU (Bridge)';
    } elseif ($vals['equipamento'] === 'ONU (Bridge)') {
        /* 03/10/2026 — ONU em BRIDGE (escolhida pelo operador ou pela OLT) com equipamento do tipo ROTEADOR em
           comodato: o modo continua Bridge (a regra acima só age com o campo vazio) e o roteador é anotado em
           "Roteador em comodato". ONU sem roteador (roteador do cliente) não entra: nada é marcado. */
        $refR = mb_strtoupper((string)($vals['equip_modelo'] ?? ''), 'UTF-8');
        if (!empty($vals['equip_serial'])) { try { $te = $db->prepare("SELECT tipo,modelo FROM ws_equipamento WHERE serial=? LIMIT 1"); $te->execute([$vals['equip_serial']]); if ($row = $te->fetch()) $refR .= ' ' . mb_strtoupper($row['tipo'] . ' ' . $row['modelo'], 'UTF-8'); } catch (Throwable $e) {} }
        if (!preg_match('/\bONT\b/', $refR) && preg_match('/ROUTER|ROTEADOR/', $refR)) {
            if (array_key_exists('roteador_comodato', $vals) && (string)$vals['roteador_comodato'] === '') $vals['roteador_comodato'] = 1;
            if (array_key_exists('roteador_modelo', $vals) && trim((string)$vals['roteador_modelo']) === '') $vals['roteador_modelo'] = (string)($vals['equip_modelo'] ?? '') ?: null;
        }
    }
    // login/senha SEMPRE em minúsculo; endereço de instalação e zona em maiúsculo.
    foreach (['login_pppoe','senha_pppoe'] as $lw) if (!empty($vals[$lw])) $vals[$lw] = mb_strtolower($vals[$lw], 'UTF-8');
    foreach (['inst_logradouro','inst_bairro','inst_cidade','inst_uf','zona'] as $up) if (!empty($vals[$up])) $vals[$up] = mb_strtoupper($vals[$up], 'UTF-8');
    
    // Validar se ID da ONU, SN/MAC ou Login já existe em outro contrato
    $chkCols = ['ont_id' => 'ID da ONU/ONT', 'sn_onu' => 'SN/MAC da ONU', 'login_pppoe' => 'Login PPPoE/IPoE'];
    foreach ($chkCols as $k => $nomeLegivel) {
        if (!empty($vals[$k])) {
            $qk = $db->prepare("SELECT c.nome, c.id AS cid, ct.id AS ctid FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE ct.$k=? AND ct.id!=? LIMIT 1");
            $qk->execute([$vals[$k], $id]);
            if ($cx = $qk->fetch()) {
                // Item 3: antes bloqueava aqui mesmo e devolvia pra tela vazia, sem dizer pra onde ir
                // resolver. Agora manda direto pra ficha de quem JÁ tem o equipamento — lá aparece um
                // aviso com botão de "liberar e mover" (ver ws_header(), ação liberar_equip_conflito)
                // que só age com clique confirmado, e devolve pra cá (conflito_volta) pra repetir o salvar.
                header('Location: erp.php?p=cliente&id=' . (int)$cx['cid']
                     . '&conflito=1&conflito_campo=' . $k . '&conflito_ctid=' . (int)$cx['ctid']
                     . '&conflito_volta=' . (int)$vals['cliente_id']); exit;
            }
        }
    }
    
    // Blindagem: não permite criar um 2º contrato ATIVO pro mesmo cliente (o botão já fica desabilitado, isso é o reforço no servidor).
    if (!$id && ($vals['status'] ?? 'ativo') === 'ativo') {
        $chk = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=? AND status='ativo'");
        $chk->execute([$vals['cliente_id']]);
        if ((int)$chk->fetchColumn() > 0) {
            $_SESSION['ws_flash_err'] = 'Este cliente já tem um contrato ativo. Cancele-o antes de criar outro.';
            header('Location: erp.php?p=cliente&id=' . (int)$vals['cliente_id']); exit;
        }
    }
    // Como o contrato estava ANTES de salvar: é o que diz se a sessão de pé precisa cair (abaixo).
    $ctAntes = null;
    if ($id) { $sa = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $sa->execute([$id]); $ctAntes = $sa->fetch() ?: null; }
    if ($id) {
        $set = implode(',', array_map(fn($c) => "$c=:$c", $campos));
        $db->prepare("UPDATE ws_contrato SET $set WHERE id=:id")->execute($vals + ['id' => $id]);
        /* Virou CANCELADO nesta edição: carimba a data (e, se voltou a valer, tira o carimbo).
           É o que alimenta o relatório de Ativação/Desativação com a verdade. */
        $stAgora = (string)($vals['status'] ?? '');
        if ($stAgora === 'cancelado' && ($ctAntes['status'] ?? '') !== 'cancelado')
            $db->prepare("UPDATE ws_contrato SET data_cancelamento=COALESCE(data_cancelamento, CURDATE()) WHERE id=?")->execute([$id]);
        elseif ($stAgora !== 'cancelado' && ($ctAntes['status'] ?? '') === 'cancelado')
            $db->prepare("UPDATE ws_contrato SET data_cancelamento=NULL WHERE id=?")->execute([$id]);
        /* Trocou o PLANO (ou o valor) do contrato: as mensalidades que ainda estão EM ABERTO passam a
           valer o novo valor automaticamente. Só mexe em: status 'aberto' (pago/cancelado nunca), deste
           contrato, categoria mensalidade (ou sem categoria = padrão antigo) — serviço/venda/avulso
           ficam como foram lançados — e no campo valor (modelo B: título = plano; taxa de emissão e
           desconto ficam como estão). O que já foi emitido na CelCoin mantém o valor antigo lá (não há
           como alterar cobrança emitida): a tela avisa quantos são, pra reemitir. */
        $planoMudou = $ctAntes && (int)($ctAntes['plano_id'] ?? 0) !== (int)($vals['plano_id'] ?? 0);
        $valorMudou = $ctAntes && $vals['valor'] !== null && round((float)($ctAntes['valor'] ?? 0), 2) !== round((float)$vals['valor'], 2);
        if (($planoMudou || $valorMudou) && $vals['valor'] !== null && (float)$vals['valor'] > 0) {
            try {
                $novoV = round((float)$vals['valor'], 2);
                $sel = $db->prepare("SELECT id, celcash_charge_id FROM ws_fatura WHERE contrato_id=? AND status='aberto'
                                     AND (categoria IS NULL OR categoria='' OR categoria='mensalidade') AND ROUND(valor,2)<>?");
                $sel->execute([$id, $novoV]);
                $ajustar = $sel->fetchAll();
                if ($ajustar) {
                    $ids = array_map(fn($x) => (int)$x['id'], $ajustar);
                    $in = implode(',', array_fill(0, count($ids), '?'));
                    $db->prepare("UPDATE ws_fatura SET valor=? WHERE id IN ($in) AND status='aberto'")->execute(array_merge([$novoV], $ids));
                    $noGw = count(array_filter($ajustar, fn($x) => trim((string)($x['celcash_charge_id'] ?? '')) !== ''));
                    ws_evento($db, (int)$vals['cliente_id'], 'contrato', 'Plano/valor alterado: ' . count($ids) . ' título(s) em aberto reajustado(s) para R$ ' . number_format($novoV, 2, ',', '.'));
                    $_SESSION['ws_flash_ok'] = '✅ Contrato salvo. ' . count($ids) . ' boleto(s) em aberto reajustado(s) para R$ ' . number_format($novoV, 2, ',', '.') . '.'
                        . ($noGw > 0 ? " ⚠️ $noGw já estava(m) emitido(s) na CelCoin e mantém o valor antigo lá — exclua e gere de novo se precisar do boleto/PIX com o valor novo." : '');
                }
            } catch (Throwable $e) { /* reajuste é acessório: nunca impede o salvar do contrato */ }
        }
        /* Trocou o DIA DE VENCIMENTO (15/10/2026): os boletos em aberto passam para o novo dia, como na troca de plano (ver ws_contrato_redatar_titulos). */
        $diaNovo = (int)($vals['dia_vencimento'] ?? 0);
        if ($ctAntes && $diaNovo > 0 && (int)($ctAntes['dia_vencimento'] ?? 0) !== $diaNovo) {
            try {
                require_once __DIR__ . '/faturamento.php';
                $rd = ws_contrato_redatar_titulos($db, $id, $diaNovo);
                if ($rd['alterados'] > 0) {
                    ws_evento($db, (int)$vals['cliente_id'], 'contrato', 'Vencimento alterado do dia ' . (int)($ctAntes['dia_vencimento'] ?? 0) . ' para o dia ' . $diaNovo . ': ' . $rd['alterados'] . ' boleto(s) em aberto passaram para o novo dia' . ($rd['fila'] ? ' (' . $rd['fila'] . ' já emitido(s) no gateway: a data lá é trocada em seguida, automaticamente)' : '') . ($rd['mantidos'] ? ' · ' . $rd['mantidos'] . ' ficou(aram) como estava(m) (a nova data já passou)' : ''));
                    $_SESSION['ws_flash_ok'] = ($_SESSION['ws_flash_ok'] ?? '✅ Contrato salvo.') . ' 📅 ' . $rd['alterados'] . ' boleto(s) em aberto passaram a vencer no dia ' . $diaNovo . ($rd['fila'] ? ' — ' . $rd['fila'] . ' já emitido(s): a data no gateway é trocada automaticamente em instantes.' : '.');
                }
            } catch (Throwable $e) { /* acessório: nunca impede o salvar do contrato */ }
        }
    } else {
        $cols = implode(',', $campos); $ph = ':' . implode(',:', $campos);
        $db->prepare("INSERT INTO ws_contrato ($cols) VALUES ($ph)")->execute($vals);
        $id = (int)$db->lastInsertId();
        ws_evento($db, (int)$vals['cliente_id'], 'contrato', 'Contrato criado (login ' . ($vals['login_pppoe'] ?? '—') . ')');
    }
    // Gancho RADIUS: reflete o contrato no FreeRADIUS na hora (senha, grupo do plano, IP, bloqueio).
    // Se o status virou "cancelado" nesta edição, REMOVE do RADIUS na hora em vez de sincronizar —
    // antes isso só acontecia na próxima passada do cron/sincronizar tudo, deixando o login
    // provisionado por um tempo mesmo já cancelado.
    if (is_file(__DIR__ . '/radius_lib.php')) {
        require_once __DIR__ . '/radius_lib.php';
        $st = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $st->execute([$id]); $ct = $st->fetch();
        if ($ct) {
            if ($ct['status'] === 'cancelado') {
                // Cancelado: DERRUBA primeiro (a sessão é achada pelo radacct) e depois tira do RADIUS
                // as DUAS identidades — antes só o PPPoE saía, e o IPoE seguia autenticando.
                if (!$ctAntes || $ctAntes['status'] !== 'cancelado') ws_rad_derrubar_contrato($db, $ct);
                foreach ([(string)($ct['login_pppoe'] ?? ''), (string)($ct['login_ipoe'] ?? '')] as $lgC) {
                    if (trim($lgC) !== '') ws_rad_remover($db, trim($lgC));
                }
            } else {
                $bloqAgora = ws_rad_deve_bloquear($db, $ct);
                ws_rad_sync_contrato($db, $ct, $bloqAgora);
                /* Mudou a situação (ativo ↔ bloqueado/suspenso)? O RADIUS só vale na PRÓXIMA
                   autenticação: sem derrubar, o cliente suspenso/bloqueado seguia navegando na
                   sessão antiga — a "conexão presa". Derruba agora, com confirmação e nova
                   tentativa automática se o concentrador não responder. */
                $bloqAntes = $ctAntes ? in_array($ctAntes['status'], ['bloqueado', 'suspenso', 'cancelado'], true) : false;
                if ($ctAntes && $bloqAntes !== $bloqAgora) ws_rad_derrubar_contrato($db, $ct);
            }
        }
    }
    // Registra a rua de instalação automaticamente (1 por CEP; ramal/cidade diferente pode repetir).
    if (!empty($vals['inst_logradouro'])) {
        $rml = $db->prepare("SELECT ramal_id FROM ws_cliente WHERE id=?"); $rml->execute([(int)$vals['cliente_id']]);
        $rmlId = (int)$rml->fetchColumn() ?: null;
        ws_rua_registrar($db, (string)$vals['inst_logradouro'], $vals['inst_cep'] ?? null, $vals['inst_cidade'] ?? null, $rmlId);
    }
    header("Location: erp.php?p=cliente&id={$vals['cliente_id']}&ok=1"); exit;
}

/* Item 3 (ONU/ONT): a etapa 2 do fluxo de conflito acima — libera o campo (ont_id/sn_onu/
 * login_pppoe) do contrato ONDE ele está hoje, só quando o funcionário confirma o clique no botão
 * "Liberar e mover" (nada acontece sozinho no simples redirecionamento). Depois manda de volta pra
 * ficha do cliente que estava tentando salvar, pra ele repetir o salvar — sem precisar sair
 * procurando o outro cadastro manualmente. */
if (($_POST['acao'] ?? '') === 'liberar_equip_conflito') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err'] = '❌ Faça login para liberar equipamento.'; header('Location: erp.php?p=dashboard'); exit; }
    $campoL = (string)($_POST['campo'] ?? '');
    $ctidL = (int)($_POST['contrato_id'] ?? 0);
    $voltaL = (int)($_POST['volta_cliente'] ?? 0);
    if (in_array($campoL, ['ont_id', 'sn_onu', 'login_pppoe'], true) && $ctidL > 0) {
        $sc = $db->prepare("SELECT ct.cliente_id, c.nome FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE ct.id=?");
        $sc->execute([$ctidL]); $ctOrigem = $sc->fetch();
        if ($ctOrigem) {
            $db->prepare("UPDATE ws_contrato SET $campoL=NULL WHERE id=?")->execute([$ctidL]);
            $rotL = ['ont_id' => 'ID da ONU/ONT', 'sn_onu' => 'SN/MAC da ONU', 'login_pppoe' => 'Login PPPoE/IPoE'];
            ws_evento($db, (int)$ctOrigem['cliente_id'], 'contrato', $rotL[$campoL] . ' liberado (contrato #' . $ctidL . ') para mover a outro cliente');
            $_SESSION['ws_flash_ok'] = '✅ ' . $rotL[$campoL] . ' liberado do contrato #' . $ctidL . ' (' . $ctOrigem['nome'] . '). Agora é só salvar o contrato pendente de novo.';
            if (!$voltaL) $voltaL = (int)$ctOrigem['cliente_id'];
        }
    }
    header('Location: erp.php?p=' . ($voltaL ? 'cliente&id=' . $voltaL : 'dashboard')); exit;
}

// Salvar cidade
if (($_POST['acao'] ?? '') === 'salvar_cidade') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $nome = mb_strtoupper(ws_fix_mojibake(trim($_POST['nome'] ?? '')), 'UTF-8');
    if (is_file(__DIR__ . '/zonas_unificar_lib.php')) { require_once __DIR__ . '/zonas_unificar_lib.php'; $nome = mb_strtoupper(ws_zb_cidade_limpa($nome), 'UTF-8'); }   // (16/10/2026) sem emoji/número/"-UF" colados
    $uf = strtoupper(trim($_POST['uf'] ?? '')) ?: null;
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    $lat = trim($_POST['latitude'] ?? '') !== '' ? (float)str_replace(',', '.', $_POST['latitude']) : null;
    $lon = trim($_POST['longitude'] ?? '') !== '' ? (float)str_replace(',', '.', $_POST['longitude']) : null;
    $cep = preg_replace('/\D/', '', (string)($_POST['cep'] ?? '')); $cep = $cep !== '' ? substr($cep,0,5).'-'.substr($cep,5,3) : null;
    if ($nome !== '') {
        $dup = ws_dup_nome($db, 'ws_cidade', $nome, $id);
        if ($dup !== '') {
            $_SESSION['ws_flash_err'] = "Já existe a cidade \"$dup\". O sistema não aceita cidade duplicada (mesmo com grafia/acento diferente) — use a existente ou edite-a.";
            header('Location: erp.php?p=cadastros&t=cidades'); exit;
        }
        /* UF E CEP POR CÓDIGO, não por texto digitado.
         *
         * `uf` era CHAR(2) livre: "PE", "pe" e "Pe" eram três coisas, e um dedo errado gravava "PW"
         * sem ninguém notar. Agora a UF aponta para ws_uf (as 27, lista fixa) e o CEP para ws_cep,
         * onde cada código existe uma vez só. As colunas de texto continuam preenchidas, como cópia
         * de leitura, para não quebrar boleto/NFS-e/fiscal — ver o cabeçalho do schema_endereco.php.
         *
         * A chave normalizada também é gravada: é ela que impede "São José" e "SAO JOSE" de virarem
         * duas cidades na próxima vez que alguém digitar. */
        $ufId = null; $cepId = null; $chave = null;
        if (is_file(__DIR__ . '/schema_endereco.php')) {
            require_once __DIR__ . '/schema_endereco.php';
            try {
                $ufId  = ws_end_uf_id($db, (string)$uf);
                $cepId = ws_end_cep_id($db, (string)$cep);
                $chave = ws_end_chave((string)$nome);
            } catch (Throwable $e) {}
        }
        if ($id) $db->prepare("UPDATE ws_cidade SET nome=?,uf=?,uf_id=?,cep_id=?,chave=?,ativo=?,latitude=?,longitude=?,cep=? WHERE id=?")
                    ->execute([$nome,$uf,$ufId,$cepId,$chave,$ativo,$lat,$lon,$cep,$id]);
        else $db->prepare("INSERT INTO ws_cidade (nome,uf,uf_id,cep_id,chave,ativo,latitude,longitude,cep) VALUES (?,?,?,?,?,?,?,?,?)")
                ->execute([$nome,$uf,$ufId,$cepId,$chave,$ativo,$lat,$lon,$cep]);
    }
    header('Location: erp.php?p=cadastros&t=cidades&ok=1'); exit;
}
if (isset($_GET['del_cidade'])) { if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; } $db->prepare("DELETE FROM ws_cidade WHERE id=?")->execute([(int)$_GET['del_cidade']]); header('Location: erp.php?p=cadastros&t=cidades'); exit; }

// Salvar bairro
if (($_POST['acao'] ?? '') === 'salvar_bairro') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $nome = mb_strtoupper(ws_fix_mojibake(trim($_POST['nome'] ?? '')), 'UTF-8');
    $cidadeId = (int)($_POST['cidade_id'] ?? 0) ?: null;
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    if ($nome !== '') {
        $dup = ws_dup_nome($db, 'ws_bairro', $nome, $id, ['cidade_id' => $cidadeId]);
        if ($dup !== '') {
            $_SESSION['ws_flash_err'] = "Já existe o bairro \"$dup\" nesta cidade. O sistema não aceita bairro duplicado (mesmo com grafia/acento diferente) — use o existente ou edite-o.";
            header('Location: erp.php?p=cadastros&t=bairros'); exit;
        }
        if ($id) $db->prepare("UPDATE ws_bairro SET nome=?,cidade_id=?,ativo=? WHERE id=?")->execute([$nome,$cidadeId,$ativo,$id]);
        else $db->prepare("INSERT INTO ws_bairro (nome,cidade_id,ativo) VALUES (?,?,?)")->execute([$nome,$cidadeId,$ativo]);
    }
    header('Location: erp.php?p=cadastros&t=bairros&ok=1'); exit;
}
if (isset($_GET['del_bairro'])) { if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; } $db->prepare("DELETE FROM ws_bairro WHERE id=?")->execute([(int)$_GET['del_bairro']]); header('Location: erp.php?p=cadastros&t=bairros'); exit; }

// Salvar ramal
if (($_POST['acao'] ?? '') === 'salvar_ramal') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $cidadeId = (int)($_POST['cidade_id'] ?? 0);
    $nome = trim($_POST['nome'] ?? '');
    $codigo = trim($_POST['codigo'] ?? '') ?: null;
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    $oltHost = trim($_POST['olt_host'] ?? '') ?: null;
    $oltPorta = trim($_POST['olt_porta'] ?? '') ?: null;
    $oltUser = trim($_POST['olt_usuario'] ?? '') ?: null;
    $oltSenha = trim($_POST['olt_senha'] ?? '') ?: null;
    /* Conexao da OLT do ramal — host, porta, usuário e senha são credencial de equipamento: níveis 1 e 2
       cadastram o ramal normalmente, mas o que já está gravado aqui não muda por engano nem de
       propósito — mesma regra das telas de API (ws_pode_editar_api). */
    if (!ws_pode_editar_api() && $id) {
        $st = $db->prepare("SELECT olt_host, olt_porta, olt_usuario, olt_senha FROM ws_ramal WHERE id=?");
        $st->execute([$id]); $ja = $st->fetch() ?: [];
        $oltHost = $ja['olt_host'] ?? null; $oltPorta = $ja['olt_porta'] ?? null;
        $oltUser = $ja['olt_usuario'] ?? null; $oltSenha = $ja['olt_senha'] ?? null;
    } elseif (!ws_pode_editar_api()) {
        $oltHost = null; $oltPorta = null; $oltUser = null; $oltSenha = null;   // ramal novo entra sem OLT
    }
    if ($nome !== '' && $cidadeId) {
        if ($id) $db->prepare("UPDATE ws_ramal SET cidade_id=?,nome=?,codigo=?,ativo=?,olt_host=?,olt_porta=?,olt_usuario=?,olt_senha=? WHERE id=?")->execute([$cidadeId,$nome,$codigo,$ativo,$oltHost,$oltPorta,$oltUser,$oltSenha,$id]);
        else $db->prepare("INSERT INTO ws_ramal (cidade_id,nome,codigo,ativo,olt_host,olt_porta,olt_usuario,olt_senha) VALUES (?,?,?,?,?,?,?,?)")->execute([$cidadeId,$nome,$codigo,$ativo,$oltHost,$oltPorta,$oltUser,$oltSenha]);
    }
    header('Location: erp.php?p=cadastros&t=ramais&ok=1'); exit;
}
if (isset($_GET['del_ramal'])) { if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; } $db->prepare("DELETE FROM ws_ramal WHERE id=?")->execute([(int)$_GET['del_ramal']]); header('Location: erp.php?p=cadastros&t=ramais'); exit; }

// Importar FOTOS em lote: casa cada arquivo (pelo NOME) com um equipamento/estoque/contrato já cadastrado
// e grava a foto sozinho. Ordem de casamento: Serial → MAC → Login (PPPoE/IPoE/ONT). Fonte: fotos que o
// operador tem em mãos (o backup .maz do MK-Auth NÃO traz foto). Só grava quando acha correspondência.
if (($_POST['acao'] ?? '') === 'fotos_lote_equip') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $files = $_FILES['fotos'] ?? null; $okc = 0; $nom = 0;
    if ($files && isset($files['name']) && is_array($files['name'])) {
        $norm = fn($s) => strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$s));
        // Só comodato: casa com ws_equipamento (cadastro em comodato) e ws_contrato. O ESTOQUE é módulo
        // próprio e NÃO entra no casamento — a foto do estoque é gerida na tela de Estoque.
        $eqSerial = []; $eqMac = [];
        foreach ($db->query("SELECT id,serial,mac FROM ws_equipamento")->fetchAll() as $r) {
            if (!empty($r['serial'])) $eqSerial[$norm($r['serial'])] = (int)$r['id'];
            if (!empty($r['mac']))    $eqMac[$norm($r['mac'])]    = (int)$r['id'];
        }
        $ctStmt = $db->prepare("SELECT id FROM ws_contrato WHERE LOWER(login_pppoe)=? OR LOWER(login_ipoe)=? OR LOWER(ont_id)=? ORDER BY id DESC LIMIT 1");
        $n = count($files['name']);
        for ($i = 0; $i < $n; $i++) {
            if ((int)($files['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
            $base = pathinfo((string)$files['name'][$i], PATHINFO_FILENAME);
            $key = $norm($base); $login = strtolower(trim($base));
            $tbl = null; $tid = null;
            if ($key !== '' && isset($eqSerial[$key]))   { $tbl = 'ws_equipamento'; $tid = $eqSerial[$key]; }
            elseif ($key !== '' && isset($eqMac[$key]))  { $tbl = 'ws_equipamento'; $tid = $eqMac[$key]; }
            elseif ($login !== '') { $ctStmt->execute([$login, $login, $login]); $cid = (int)$ctStmt->fetchColumn(); if ($cid) { $tbl = 'ws_contrato'; $tid = $cid; } }
            if (!$tbl) { $nom++; continue; }
            $one = ['name'=>$files['name'][$i],'type'=>$files['type'][$i]??'','tmp_name'=>$files['tmp_name'][$i],'error'=>$files['error'][$i],'size'=>$files['size'][$i]??0];
            $path = ws_upload_foto_equip($one);
            if (!$path) { $nom++; continue; }
            if ($tbl === 'ws_equipamento') $db->prepare("UPDATE ws_equipamento SET foto=? WHERE id=?")->execute([$path,$tid]);
            else                           $db->prepare("UPDATE ws_contrato SET equip_foto=? WHERE id=?")->execute([$path,$tid]);
            $okc++;
        }
    }
    /* "0 casadas" tinha DOIS significados colados: nome que não bateu com nenhum equipamento, e
       falha de gravação. São problemas diferentes, com soluções diferentes — agora aparecem
       separados, e o motivo da gravação vem do PHP. */
    $_SESSION['ws_flash_ok'] = "📷 Fotos em lote: $okc casada(s) e salva(s) · $nom sem correspondência (nome não bateu com serial/MAC/login).";
    if (!$okc && !empty($GLOBALS['ws_upload_erro'])) {
        $_SESSION['ws_flash_err'] = 'Nenhuma foto foi gravada: ' . $GLOBALS['ws_upload_erro'];
    }
    header('Location: erp.php?p=cadastros&t=equipamentos'); exit;
}
// Upload de foto(s) para o ACERVO (pasta compartilhada do botão "Foto"). Ficam disponíveis para escolha
// no equipamento em comodato do contrato e no estoque. Salva do mesmo jeito de sempre (ws_upload_foto_equip).
if (($_POST['acao'] ?? '') === 'foto_acervo') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $files = $_FILES['fotos'] ?? null; $ok = 0;
    if ($files && isset($files['name']) && is_array($files['name'])) {
        for ($i = 0; $i < count($files['name']); $i++) {
            if ((int)($files['error'][$i] ?? 4) !== 0) continue;
            $one = ['name'=>$files['name'][$i],'type'=>$files['type'][$i]??'','tmp_name'=>$files['tmp_name'][$i],'error'=>$files['error'][$i],'size'=>$files['size'][$i]??0];
            if (ws_upload_foto_equip($one)) $ok++;
        }
    }
    // Zero enviadas com motivo registrado: mostra o motivo em vez de "0 foto(s) enviada(s)".
    $eqErr = (string)($GLOBALS['ws_upload_erro'] ?? '');
    if (!$ok && $eqErr !== '') $_SESSION['ws_flash_err'] = 'Não consegui gravar a foto: ' . $eqErr;
    else $_SESSION['ws_flash_ok'] = "📷 $ok foto(s) enviada(s) ao acervo.";
    header('Location: erp.php?p=cadastros&t=equipamentos'); exit;
}
// Salvar equipamento (cadastro em comodato — alimenta o autopreenchimento no cadastro do cliente)
/* UNIFICAR MODELOS COM O CADASTRO (Cadastros › Equipamentos = catálogo CORRETO de modelo/tipo).
   Os contratos em comodato vieram do backup com tudo como "ONU (Bridge)", mesmo sendo o mesmo modelo que no
   catálogo está como roteador. Aqui o catálogo PREVALECE: para cada contrato em comodato, acha o modelo no
   catálogo (pelo modelo, ignorando maiúscula/espaço/hífen — ou pelo serial) e copia modelo, tipo e o modo
   (Bridge/Router) para o contrato. Só mexe em contrato em comodato cujo modelo existe no catálogo; o resto
   fica intacto. $aplicar=false só CONTA (prévia), sem gravar nada. */
function ws_equip_unificar_catalogo(PDO $db, bool $aplicar): array {
    $norm = fn($s) => preg_replace('/[^A-Z0-9]/', '', mb_strtoupper((string)$s, 'UTF-8'));
    $porModelo = []; $porSerial = [];
    foreach ($db->query("SELECT modelo, tipo, serial FROM ws_equipamento WHERE modelo<>'' ORDER BY (tipo IS NULL OR tipo='') , id")->fetchAll(PDO::FETCH_ASSOC) as $e) {
        $k = $norm($e['modelo']); if ($k !== '' && !isset($porModelo[$k])) $porModelo[$k] = $e;
        $s = $norm($e['serial'] ?? ''); if ($s !== '' && !isset($porSerial[$s])) $porSerial[$s] = $e;
    }
    $res = ['total' => 0, 'alterar' => 0, 'aplicados' => 0, 'exemplos' => []];
    if (!$porModelo) return $res;
    $mapaModo = ['ONU (Bridge)' => 'ONU (Bridge)', 'ONT (Router)' => 'ONT (Router)', 'Roteador' => 'ONT (Router)'];
    $up = $db->prepare("UPDATE ws_contrato SET equip_modelo=?, equip_tipo=?, equipamento=? WHERE id=?");
    foreach ($db->query("SELECT id, equip_modelo, equip_tipo, equipamento, equip_serial, roteador_comodato FROM ws_contrato WHERE comodato=1")->fetchAll(PDO::FETCH_ASSOC) as $ct) {
        $res['total']++;
        $km = $norm($ct['equip_modelo']); $cat = null;
        if ($km !== '' && isset($porModelo[$km])) $cat = $porModelo[$km];
        elseif ($km !== '') { $melhor = 0; foreach ($porModelo as $kc => $e) { if (strlen($kc) >= 4 && (strpos($km, (string)$kc) !== false || strpos((string)$kc, $km) !== false) && strlen($kc) > $melhor) { $cat = $e; $melhor = strlen($kc); } } }
        if (!$cat) { $ks = $norm($ct['equip_serial'] ?? ''); if ($ks !== '' && isset($porSerial[$ks])) $cat = $porSerial[$ks]; }
        if (!$cat) continue;
        $novoModelo = (string)$cat['modelo'];
        $novoTipo = trim((string)$cat['tipo']) !== '' ? (string)$cat['tipo'] : (string)$ct['equip_tipo'];
        /* (16/10/2026) O MODO da conexão (Bridge/Router, campo equipamento) é da OLT: uma ONT de modelo Router pode estar trabalhando em bridge. Unificar com o cadastro acerta só MODELO e TIPO; antes copiava o tipo do modelo também para o modo e acusava 324 "diferenças" que eram o modo real da conexão. */
        $novoModo = (string)$ct['equipamento'];
        if ($novoModelo === (string)$ct['equip_modelo'] && $novoTipo === (string)$ct['equip_tipo'] && $novoModo === (string)$ct['equipamento']) continue;
        $res['alterar']++;
        if (count($res['exemplos']) < 5) $res['exemplos'][] = trim($ct['equip_modelo'] . ' ' . $ct['equip_tipo']) . ' → ' . trim($novoModelo . ' ' . $novoTipo);
        if ($aplicar) { $up->execute([$novoModelo, $novoTipo, $novoModo, (int)$ct['id']]); $res['aplicados']++; }
    }
    return $res;
}
if (($_POST['acao'] ?? '') === 'unificar_equip_catalogo') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err'] = '❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    try { $ru = ws_equip_unificar_catalogo($db, true); $_SESSION['ws_flash_ok'] = '✅ Modelos unificados com o cadastro: ' . (int)$ru['aplicados'] . ' contrato(s) de ' . (int)$ru['total'] . ' em comodato ajustado(s).'; }
    catch (Throwable $e) { $_SESSION['ws_flash_err'] = '❌ Não deu para unificar: ' . $e->getMessage(); }
    header('Location: erp.php?p=cadastros&t=comodatos'); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_equipamento') {
    if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $tipo = trim($_POST['tipo'] ?? '') ?: null;
    $modelo = trim($_POST['modelo'] ?? '');
    $serial = mb_strtoupper(trim($_POST['serial'] ?? ''), 'UTF-8') ?: null;
    $mac = mb_strtoupper(trim($_POST['mac'] ?? ''), 'UTF-8') ?: null;
    $status = trim($_POST['status'] ?? '') ?: 'estoque';
    $obs = trim($_POST['obs'] ?? '') ?: null;
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    // Foto do equipamento: mantém a atual, troca só se enviaram uma nova.
    $foto = null;
    if ($id) { $sf = $db->prepare("SELECT foto FROM ws_equipamento WHERE id=?"); $sf->execute([$id]); $foto = $sf->fetchColumn() ?: null; }
    $fnew = ws_upload_foto_equip($_FILES['foto'] ?? []);
    if ($fnew) $foto = $fnew;
    /* Falha na foto deixa de ser muda: o equipamento era salvo sem imagem e a tela não dizia
       nada — de fora, "não gravou a foto" e ponto. O motivo vem do PHP (ws_mover_upload). */
    elseif (!empty($_FILES['foto']['name']) && !empty($GLOBALS['ws_upload_erro'])) {
        $_SESSION['ws_flash_err'] = 'Não consegui gravar a foto do equipamento: ' . $GLOBALS['ws_upload_erro'];
    }
    if ($modelo !== '') {
        if ($serial !== null) {
            $stD = $db->prepare("SELECT modelo FROM ws_equipamento WHERE serial=? AND id<>?");
            $stD->execute([$serial, $id]);
            $dupSerial = $stD->fetchColumn();
            if ($dupSerial !== false) {
                $_SESSION['ws_flash_err'] = "Já existe um equipamento com esse serial (\"$dupSerial\"). Use o existente ou edite-o.";
                header('Location: erp.php?p=cadastros&t=equipamentos'); exit;
            }
        }
        if ($id) $db->prepare("UPDATE ws_equipamento SET tipo=?,modelo=?,serial=?,mac=?,status=?,obs=?,ativo=?,foto=? WHERE id=?")->execute([$tipo,$modelo,$serial,$mac,$status,$obs,$ativo,$foto,$id]);
        else $db->prepare("INSERT INTO ws_equipamento (tipo,modelo,serial,mac,status,obs,ativo,foto) VALUES (?,?,?,?,?,?,?,?)")->execute([$tipo,$modelo,$serial,$mac,$status,$obs,$ativo,$foto]);
    }
    header('Location: erp.php?p=cadastros&t=equipamentos&ok=1'); exit;
}
if (isset($_GET['del_equipamento'])) { if (!ws_pode_cadastro_basico()) { $_SESSION['ws_flash_err']='❌ Faça login para cadastrar.'; header('Location: erp.php?p=dashboard'); exit; } $db->prepare("DELETE FROM ws_equipamento WHERE id=?")->execute([(int)$_GET['del_equipamento']]); header('Location: erp.php?p=cadastros&t=equipamentos'); exit; }
// Exclusão em MASSA dos cadastros (checkbox único/todos) — cidades, bairros, ramais e planos.
$massaMap = [
    'excluir_massa_cidade' => ['ws_cidade', 'erp.php?p=cadastros&t=cidades'],
    'excluir_massa_bairro' => ['ws_bairro', 'erp.php?p=cadastros&t=bairros'],
    'excluir_massa_ramal'  => ['ws_ramal',  'erp.php?p=cadastros&t=ramais'],
    'excluir_massa_plano'  => ['ws_plano',  'erp.php?p=planos'],
    'excluir_massa_equipamento' => ['ws_equipamento', 'erp.php?p=cadastros&t=equipamentos'],
];
if (isset($massaMap[$_POST['acao'] ?? ''])) {
    [$tab, $volta] = $massaMap[$_POST['acao']];
    /* Plano é PREÇO: excluir em massa segue nível 3+. Cidade, bairro, ramal e equipamento são
       cadastro do dia a dia, liberados para quem tem login. */
    if (!($tab === 'ws_plano' ? ws_pode_configurar() : ws_pode_cadastro_basico())) { $_SESSION['ws_flash_err']='❌ Sem permissão (plano é nível 3+ e root).'; header('Location: erp.php?p=dashboard'); exit; }
    try {
        $n = ws_excluir_massa($db, $tab, (array)($_POST['ids'] ?? []));
        $_SESSION['ws_flash_ok'] = "🗑 $n registro(s) excluído(s).";
    } catch (Throwable $e) {
        $_SESSION['ws_flash_err'] = '❌ Não foi possível excluir: algum item está em uso (ex.: plano ligado a um contrato). Remova/desative o vínculo primeiro.';
    }
    header('Location: ' . $volta); exit;
}

// Salvar dias de bloqueio / dias de confiança
// Portas de acesso ao equipamento do cliente (Configurações → Geral).
if (($_POST['acao'] ?? '') === 'salvar_equip_porta' && ws_pode_configurar()) { ws_equip_salvar($_POST); header('Location: erp.php?p=config&t=geral&ok=1'); exit; }
if (($_POST['acao'] ?? '') === 'salvar_dias_bloqueio' && ws_pode_configurar()) {
    // Campo em branco volta ao padrão do sistema (5 dias de corte) — antes virava 0 e bloqueava no dia seguinte ao vencimento.
    $dias = trim((string)($_POST['dias_bloqueio'] ?? '')) === '' ? 5 : max(0, (int)$_POST['dias_bloqueio']);
    $diasConf = max(1, (int)($_POST['dias_confianca'] ?? 1));
    ws_dir(WS_CACHE);
    // MESCLA com o que já está salvo: regravar só os dias apagava multa e juros configurados.
    $cobAtual = is_file(WS_CACHE . '/cobranca.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/cobranca.json'), true) ?: []) : [];
    @file_put_contents(WS_CACHE . '/cobranca.json', json_encode(array_merge($cobAtual, ['dias_bloqueio' => $dias, 'dias_confianca' => $diasConf])));
    header('Location: erp.php?p=config&t=cobranca&ok=1'); exit;
}

// Salvar plano
if (($_POST['acao'] ?? '') === 'salvar_plano') {
    /* Plano é preço do provedor: níveis 1 e 2 consultam para conferir com o cliente, não alteram. */
    if (!ws_pode_editar_preco()) { $_SESSION['ws_flash_err']='🔒 Plano é somente leitura no seu nível — quem altera preço é nível 3 ou root.'; header('Location: erp.php?p=planos'); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $v = [
        'nome' => trim($_POST['nome'] ?? ''),
        'down_kbps' => (int)($_POST['down_kbps'] ?? 0),
        'up_kbps' => (int)($_POST['up_kbps'] ?? 0),
        'valor' => (float)str_replace(',', '.', $_POST['valor'] ?? 0),
        'descricao' => trim($_POST['descricao'] ?? '') ?: null,
        'ativo' => isset($_POST['ativo']) ? 1 : 0,
    ];
    if ($id) $db->prepare("UPDATE ws_plano SET nome=:nome,down_kbps=:down_kbps,up_kbps=:up_kbps,valor=:valor,descricao=:descricao,ativo=:ativo WHERE id=$id")->execute($v);
    else   { $db->prepare("INSERT INTO ws_plano (nome,down_kbps,up_kbps,valor,descricao,ativo) VALUES (:nome,:down_kbps,:up_kbps,:valor,:descricao,:ativo)")->execute($v); $id = (int)$db->lastInsertId(); }
    /* Gancho RADIUS: atualiza o grupo de rate-limit do plano E aplica em quem já está conectado.
     *
     * O grupo é `plano_{id}` — o CÓDIGO, não o nome. Por isso renomear o plano aqui não desvincula
     * cliente nenhum: o vínculo em radusergroup continua apontando para o mesmo código.
     *
     * A sincronização em banco, sozinha, só teria efeito no PRÓXIMO login de cada cliente — na
     * prática, "só depois de derrubar todo mundo". O CoA aplica a velocidade nova na sessão viva:
     * o cliente não cai, não reconecta, e o download em andamento não é interrompido. */
    if (is_file(__DIR__ . '/radius_lib.php')) {
        require_once __DIR__ . '/radius_lib.php';
        $st = $db->prepare("SELECT * FROM ws_plano WHERE id=?"); $st->execute([$id]); $pl = $st->fetch();
        if ($pl) {
            if (ws_rad_sync_plano($db, $pl)) {
                try {
                    $fila = ws_rad_vel_marcar_plano($db, (int)$pl['id']);
                    $vel = $fila ? ws_rad_vel_processar($db, 15) : ['aplicadas' => 0, 'pendentes' => 0];
                    if ($fila) $_SESSION['ws_flash_ok'] = "Plano salvo. Velocidade nova sendo aplicada em $fila cliente(s) conectado(s), sem derrubar ninguém"
                        . ($vel['pendentes'] ? ' (o restante em até 2 minutos).' : '.');
                } catch (Throwable $e) { /* sem gerência/CoA o plano vale no próximo login — não é erro de cadastro */ }
            }
        }
    }
    header("Location: erp.php?p=planos&ok=1"); exit;
}

// Upload de anexo (foto/documento do cliente)
if (($_POST['acao'] ?? '') === 'upload_anexo') {
    $cid = (int)($_POST['cliente_id'] ?? 0);
    if ($cid && !empty($_FILES['arquivo'])) {
        $r = ws_anexo_salvar($db, $cid, (int)($_POST['contrato_id'] ?? 0) ?: null, $_POST['tipo'] ?? 'outro', $_FILES['arquivo']);
        if (!$r['ok']) $_SESSION['ws_flash_err'] = $r['erro'];
    }
    header("Location: erp.php?p=cliente&id=$cid&ok=1"); exit;
}
if (($_GET['del_anexo'] ?? '') !== '') {
    $aid = (int)$_GET['del_anexo']; $cid = (int)($_GET['cliente'] ?? 0);
    ws_anexo_excluir($db, $aid);
    header("Location: erp.php?p=cliente&id=$cid"); exit;
}
if (($_POST['acao'] ?? '') === 'del_anexos_massa') {
    $cid = (int)($_POST['cliente'] ?? 0);
    $ids = $_POST['ids'] ?? [];
    if (is_array($ids)) {
        foreach ($ids as $aid) ws_anexo_excluir($db, (int)$aid);
    }
    header("Location: erp.php?p=cliente&id=$cid"); exit;
}

// Marca / logo do sistema (admin) - restrito a root
if (($_POST['acao'] ?? '') === 'salvar_marca' && ws_user()['nivel'] === 'admin') {
    if (!ws_eh_root()) {
        $_SESSION['ws_flash_err'] = '❌ Alterações de marca/logo do sistema são exclusivas para usuários root.';
        header('Location: erp.php?p=config&t=geral'); exit;
    }
    /* Formato da logo: 'auto' mede a imagem, 'circulo' recorta sempre, 'original' nunca.
       Valor fora da lista vira 'auto' — campo de formulario nao escolhe comportamento sozinho. */
    $fmtLogo = $_POST['logo_formato'] ?? 'auto';
    if (!in_array($fmtLogo, ['auto', 'circulo', 'original'], true)) $fmtLogo = 'auto';
    ws_marca_autorizar_nome(trim($_POST['nome_sistema'] ?? '') ?: 'WellSystem');   // nome = marca registrada (senha root do banco)
    /* Link da logo do TOPO = site do provedor (vazio = sem link). Endereço inválido não grava e avisa. */
    $urlLogo = ws_brand_url_normalizar((string)($_POST['logo_url'] ?? ''));
    $salvarMarca = ['nome' => trim($_POST['nome_sistema'] ?? '') ?: 'WellSystem', 'logo_formato' => $fmtLogo];
    if ($urlLogo !== null) $salvarMarca['logo_url'] = $urlLogo;
    ws_branding_salvar($salvarMarca);
    if (!empty($_FILES['logo']['tmp_name'])) {
        $r = ws_logo_upload($_FILES['logo']);
        $_SESSION['ws_flash_ok'] = $r['ok'] ? 'Marca atualizada.' : ('Logo: ' . $r['erro']);
    } else $_SESSION['ws_flash_ok'] = 'Marca atualizada.';
    if (!empty($GLOBALS['ws_marca_negada'])) { if (($_SESSION['ws_flash_ok'] ?? '') === 'Marca atualizada.') $_SESSION['ws_flash_ok'] = 'Logo/formato gravados (o nome não mudou).'; $_SESSION['ws_flash_err'] = '🔒 O nome do sistema NÃO foi trocado: é marca de registro e só muda com a senha root do banco (a senha informada não confere ou está em branco).'; }
    if ($urlLogo === null) $_SESSION['ws_flash_err'] = trim(($_SESSION['ws_flash_err'] ?? '') . ' ❌ Link da logo do topo não gravado: endereço inválido (use algo como https://seuprovedor.com.br).');
    header('Location: erp.php?p=config&t=geral'); exit;
}
if (($_GET['remover_logo'] ?? '') !== '' && ws_user()['nivel'] === 'admin') {
    if (!ws_eh_root()) {
        $_SESSION['ws_flash_err'] = '❌ Alterações de marca/logo do sistema são exclusivas para usuários root.';
        header('Location: erp.php?p=config&t=geral'); exit;
    }
    ws_logo_remover();
    header('Location: erp.php?p=config&t=geral'); exit;
}
// Galeria de fundos da TELA DE LOGIN (upload próprio, separado da central)
if (($_POST['acao'] ?? '') === 'salvar_login_bg' && ws_user()['nivel'] === 'admin' && !ws_em_demo()) {
    $add = !empty($_FILES['login_bg']) ? ws_login_bg_upload($_FILES['login_bg']) : 0;
    /* "Nada adicionado" não explica nada: podia ser tipo de arquivo, tamanho ou falha de
       gravação. Quando ws_login_bg_upload() registrou o motivo do PHP, ele vai para a tela. */
    $erroBgLogin = (string)($GLOBALS['ws_login_bg_erro'] ?? '');
    if ($add)                     $_SESSION['ws_flash_ok']  = "$add foto(s) de fundo do login adicionada(s).";
    elseif ($erroBgLogin !== '')  $_SESSION['ws_flash_err'] = 'Não consegui gravar a imagem: ' . $erroBgLogin;
    else                          $_SESSION['ws_flash_ok']  = 'Nada adicionado (verifique o tipo — JPG, PNG ou WEBP — e o tamanho, até 8 MB).';
    header('Location: erp.php?p=config&t=geral'); exit;
}
if (($_GET['limpar_login_bg'] ?? '') !== '' && ws_user()['nivel'] === 'admin' && !ws_em_demo()) { ws_login_bg_limpar(); header('Location: erp.php?p=config&t=geral'); exit; }
if (($_POST['acao'] ?? '') === 'excluir_login_bg_sel' && ws_user()['nivel'] === 'admin' && !ws_em_demo()) {
    $rem = function_exists('ws_login_bg_excluir') ? ws_login_bg_excluir((array)($_POST['bgs'] ?? [])) : 0;
    $_SESSION['ws_flash_ok'] = "🗑 $rem foto(s) do login excluída(s).";
    header('Location: erp.php?p=config&t=geral'); exit;
}
// Excluir a FOTO de operadores selecionados (só o arquivo; o operador continua e volta pra inicial do nome).
if (($_POST['acao'] ?? '') === 'excluir_foto_operador_sel' && ws_user()['nivel'] === 'admin') {
    $dir = WS_UPLOADS . '/operadores'; $rem = 0;
    foreach ((array)($_POST['ops'] ?? []) as $oid) {
        $oid = (int)$oid; if ($oid <= 0) continue;
        $achou = false;
        foreach (glob("$dir/$oid.*") ?: [] as $f) { @unlink($f); $achou = true; }
        if ($achou) $rem++;
    }
    $_SESSION['ws_flash_ok'] = "🗑 Foto de $rem operador(es) removida — voltou para a inicial do nome.";
    header('Location: erp.php?p=config&t=geral'); exit;
}

// Tokens de integração (olt_token / cron_token) — grava no cache/wellsystem_db.json (admin)
if (($_POST['acao'] ?? '') === 'salvar_tokens' && ws_user()['nivel'] === 'admin') {
    $cfg = is_file(WS_DB_CFG) ? (json_decode(@file_get_contents(WS_DB_CFG), true) ?: []) : ws_db_config();
    // olt_token vazio => gera automaticamente (integração precisa de um token forte)
    $cfg['olt_token']  = trim($_POST['olt_token'] ?? '') ?: bin2hex(random_bytes(16));
    $cfg['cron_token'] = trim($_POST['cron_token'] ?? '');
    @file_put_contents(WS_DB_CFG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_DB_CFG, 0640);
    $_SESSION['ws_flash_ok'] = 'Tokens salvos.';
    header('Location: erp.php?p=config&t=geral'); exit;
}

// Gerar backup agora (admin)
if (($_GET['gerar_backup'] ?? '') !== '' && ws_user()['nivel'] === 'admin') {
    $r = ws_backup_gerar();
    $msgEnvio = '';
    if ($r['ok'] && !empty($r['envio']) && is_array($r['envio'])) {
        $partes = [];
        foreach ($r['envio'] as $canal => $st) { $partes[] = "$canal=" . (is_string($st) ? $st : json_encode($st, JSON_UNESCAPED_UNICODE)); }
        $msgEnvio = $partes ? (' — envio: ' . implode(', ', $partes)) : '';
    }
    $_SESSION['ws_flash_ok'] = $r['ok'] ? ('Backup gerado: ' . $r['arquivo'] . $msgEnvio) : ('Falha no backup: ' . ($r['erro'] ?? ''));
    header('Location: erp.php?p=config&t=migracao'); exit;
}

// 2FA — iniciar configuração (gera segredo temporário)
if (($_GET['twofa_init'] ?? '') !== '') { $_SESSION['ws_2fa_setup'] = ws_totp_secret(); header('Location: erp.php?p=config&t=seguranca'); exit; }
// 2FA — confirmar ativação (valida um código do app)
if (($_POST['acao'] ?? '') === 'twofa_ativar') {
    $secret = $_SESSION['ws_2fa_setup'] ?? '';
    if ($secret && ws_totp_verifica($secret, $_POST['codigo'] ?? '')) {
        $recs = ws_2fa_recovery_gerar(8);
        $hashes = array_map(fn($c) => password_hash($c, PASSWORD_DEFAULT), $recs);
        $_SESSION['ws_2fa_conf_ok'] = 1;
        $db->prepare("UPDATE ws_usuario SET twofa_secret=?, twofa_enabled=1, twofa_recovery=? WHERE id=?")
           ->execute([$secret, json_encode($hashes), (int)ws_user()['id']]);
        unset($_SESSION['ws_2fa_setup']);
        $_SESSION['ws_2fa_codes'] = $recs;   // exibidos UMA vez
        header('Location: erp.php?p=config&t=seguranca'); exit;
    }
    $_SESSION['ws_flash_ok'] = 'Código inválido — 2FA não foi ativado.';
    header('Location: erp.php?p=config&t=seguranca'); exit;
}
// 2FA — desativar (exige a senha atual)
if (($_POST['acao'] ?? '') === 'twofa_desativar' && function_exists('ws_twofa_obrigatorio_para_mim') && ws_twofa_obrigatorio_para_mim()) {
    $_SESSION['ws_flash_ok'] = '🔒 O 2FA é obrigatório para o seu nível de acesso e não pode ser desativado.'; header('Location: erp.php?p=config&t=seguranca'); exit;
}
// Liga/desliga o 2FA obrigatório para nível 3 e root (só root ou nível 3 com 2FA já ativo).
if (($_POST['acao'] ?? '') === 'twofa_obrigatorio' && ws_pode_configurar()) {
    $cfgSeg = ws_seg_cfg(); $cfgSeg['twofa_obrigatorio'] = empty($_POST['twofa_obrigatorio']) ? 0 : 1;
    @file_put_contents(WS_CACHE . '/seguranca.json', json_encode($cfgSeg)); @chmod(WS_CACHE . '/seguranca.json', 0640);
    if (function_exists('ws_evento')) ws_evento($db, null, 'seguranca', '2FA obrigatório para nível 3/root ' . ($cfgSeg['twofa_obrigatorio'] ? 'LIGADO' : 'desligado') . ' por ' . (ws_user()['nome'] ?? 'operador'));
    $_SESSION['ws_flash_ok'] = $cfgSeg['twofa_obrigatorio'] ? '2FA passou a ser obrigatório para nível 3 e root.' : '2FA voltou a ser opcional.';
    header('Location: erp.php?p=config&t=seguranca'); exit;
}
if (($_POST['acao'] ?? '') === 'twofa_desativar') {
    $st = $db->prepare("SELECT senha_hash FROM ws_usuario WHERE id=?"); $st->execute([(int)ws_user()['id']]);
    if (password_verify($_POST['senha'] ?? '', (string)$st->fetchColumn())) {
        $db->prepare("UPDATE ws_usuario SET twofa_enabled=0, twofa_secret=NULL, twofa_recovery=NULL WHERE id=?")->execute([(int)ws_user()['id']]);
        $_SESSION['ws_flash_ok'] = '2FA desativado.';
    } else $_SESSION['ws_flash_ok'] = 'Senha incorreta — 2FA continua ativo.';
    header('Location: erp.php?p=config&t=seguranca'); exit;
}

// Ações rápidas na ficha do cliente: conexão (bloq/desbloq/confiar) e boleto (gerar/receber)
// Gerar boleto único ou CARNÊ direto da ficha do cliente (modal). Só do próprio cliente.
if (($_POST['acao'] ?? '') === 'gerar_boletos') {
    $cid = (int)($_POST['cliente_id'] ?? 0);
    $ct = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=? ORDER BY id LIMIT 1"); $ct->execute([$cid]); $ct = $ct->fetch();
    // Vencimento no passado não é aceito: nada é criado e o motivo aparece na tela.
    if ($ct && ws_venc_passado((string)($_POST['vencimento'] ?? ''))) {
        $_SESSION['ws_flash_err'] = ws_venc_passado_msg((string)$_POST['vencimento']);
        /* GUARDA O QUE FOI DIGITADO. Recusar a data e devolver o formulário em branco obriga o
         * operador a preencher tudo de novo só por causa de um campo — a caixa reabre com os
         * mesmos valores, o aviso dentro dela e o cursor na data, que é o único campo a trocar. */
        $_SESSION['ws_bol_form'] = [
            'cliente_id' => $cid, 'emissao' => (string)($_POST['emissao'] ?? ''), 'tipo' => (string)($_POST['tipo'] ?? ''),
            'qtd' => (string)($_POST['qtd'] ?? ''), 'vencimento' => (string)($_POST['vencimento'] ?? ''),
            'plano_id' => (string)($_POST['plano_id'] ?? ''), 'valor' => (string)($_POST['valor'] ?? ''),
            'taxa_emissao' => (string)($_POST['taxa_emissao'] ?? ''), 'obs' => (string)($_POST['obs'] ?? ''),
            'banco_id' => (string)($_POST['banco_id'] ?? ''),
            'erro' => (string)$_SESSION['ws_flash_err'],
        ];
        $ct = null;
    }
    if ($ct) {
        $tipoSel = $_POST['tipo'] ?? 'boleto';
        $tipo  = $tipoSel === 'carne' ? 'carne' : 'boleto'; // formato: carnê (várias parcelas) x boleto único
        // Categoria do título = o que foi apontado no "Tipo" ao gerar (não força mais "mensalidade").
        $categoria = ['servicos'=>'servico','vendas'=>'venda','outros'=>'outros','carne'=>'mensalidade','boleto'=>'mensalidade'][$tipoSel] ?? 'mensalidade';
        // Quantidade vale para TODAS as modalidades (gera 1 título por mês). Padrão 1.
        $qtd   = max(1, min(36, (int)($_POST['qtd'] ?? 1)));
        $valorBase = (float)str_replace(',', '.', str_replace('.', '', $_POST['valor'] ?? '')) ?: (float)$ct['valor'];
        $taxaEmissao = (float)str_replace(',', '.', str_replace('.', '', $_POST['taxa_emissao'] ?? '')) ?: 0.0;
        $valor = $valorBase; // modelo B (igual ao MK-Auth): título = plano; a taxa fica em taxa_emissao e só entra na cobrança
        $venc0 = $_POST['vencimento'] ?: date('Y-m-d', strtotime('+7 days'));
        $obs   = trim($_POST['obs'] ?? '');
        // Defensivo: só grava a coluna categoria se ela existir (instalações antigas não quebram).
        $temCat = false; try { $db->query("SELECT categoria FROM ws_fatura LIMIT 0"); $temCat = true; } catch (Throwable $e) {}
        // Conta do boleto escolhida na tela (0 = segue o cadastro/contrato, que é o padrão).
        $bancoEscolhido = (int)($_POST['banco_id'] ?? 0) ?: ((int)(ws_bancos_por_emissao($db)[(string)($_POST['emissao'] ?? '')] ?? 0) ?: null);   // sem conta na tela: a vinculada à Emissão
        $temBanco = false; try { $db->query("SELECT banco_id FROM ws_fatura LIMIT 0"); $temBanco = true; } catch (Throwable $e) {}
        $ins = $temCat
            ? $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,taxa_emissao,status,celcash_my_id,obs,categoria) VALUES (?,?,?,?,?,?, 'aberto', ?, ?, ?)")
            : $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,taxa_emissao,status,celcash_my_id,obs) VALUES (?,?,?,?,?,?, 'aberto', ?, ?)");
        $criadas = 0; $novosIds = [];
        // Boleto único: cria SEMPRE (permite vários no mesmo mês, qualquer valor).
        // Carnê: uma parcela por mês; NÃO pula competência (o operador decide os valores/datas).
        for ($i = 0; $i < $qtd; $i++) {
            $venc = date('Y-m-d', strtotime("$venc0 +$i month")); $comp = date('Y-m', strtotime($venc)); if ($i > 0) $venc = ws_venc_ajustar($venc);   // parcelas seguintes: respeita "Vence aos sábados" (competência mantida)
            $celId = 'ws-'.$ct['id'].'-'.str_replace('-','',$comp).'-'.substr(uniqid(),-4);
            $args = [$ct['id'], $ct['cliente_id'], $comp, $venc, $valor, $taxaEmissao, $celId, ($obs ?: null)];
            if ($temCat) $args[] = $categoria;
            $ins->execute($args);
            $fidNovo = (int)$db->lastInsertId();
            /* A conta escolhida entra num UPDATE à parte: o INSERT já tem duas versões (com e sem
               categoria) e uma terceira combinação só para isto deixaria o trecho ilegível. */
            if ($temBanco && $bancoEscolhido)
                $db->prepare("UPDATE ws_fatura SET banco_id=? WHERE id=?")->execute([$bancoEscolhido, $fidNovo]);
            $novosIds[] = $fidNovo;
            $criadas++;
        }
        // Marca os recém-criados p/ exibir "novo"/"PIX/QR" só até abrir/salvar/sair da página.
        $_SESSION['ws_titulo_novo'] = $novosIds;
        /* EMISSÃO NO GATEWAY (CelCoin/GalaxPay).
         *
         * Três defeitos moravam aqui, e juntos davam exatamente o sintoma "salvo, mas o boleto da
         * CelCoin não sai — só o PIX próprio":
         *
         *  1. Pegava TODAS as faturas abertas do contrato, não as que acabaram de ser criadas: título
         *     antigo já emitido voltava para o gateway e o novo podia nem entrar.
         *  2. Gravava $r['linha'] e $r['pix'], chaves que a função NÃO devolve (são linha_digitavel e
         *     pix_emv). Mesmo quando a CelCoin aceitava, a linha digitável e o PIX do banco eram
         *     gravados como NULO — e a tela caía no PIX próprio, que é o que o provedor via.
         *  3. Todo erro era engolido (catch vazio, e nada quando ok=false). Credencial errada,
         *     ambiente trocado ou IP fora da whitelist não apareciam em lugar nenhum.
         *
         * Agora: só os novos, chaves certas (incluindo pix_qr_url e a resposta crua para conferência)
         * e o motivo da recusa vai para a tela. */
        if (($_POST['emissao'] ?? 'proprio') === 'gateway' && $novosIds && is_file(__DIR__ . '/celcash.php')) {
            require_once __DIR__ . '/celcash.php';
            if (function_exists('ws_celcash_criar_cobranca')) {
                require_once __DIR__ . '/schema_endereco.php';
                $in = implode(',', array_fill(0, count($novosIds), '?'));
                $novas = $db->prepare("SELECT f.*, c.*, f.id fid FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE f.id IN ($in)");
                $novas->execute($novosIds);
                $emitidas = 0; $erroGw = '';
                foreach ($novas->fetchAll() as $row) {
                    try {
                        $dados = ['id' => $row['fid'], 'valor' => $row['valor'], 'taxa_emissao' => (float)($row['taxa_emissao'] ?? 0), 'vencimento' => $row['vencimento'],
                                  'competencia' => $row['competencia'], 'celcash_my_id' => $row['celcash_my_id']];
                        $r = ws_celcash_criar_cobranca($dados, function_exists('ws_end_enriquecer') ? ws_end_enriquecer($db, $row) : $row);
                        if (!empty($r['ok'])) {
                            // Emissão é síncrona (já volta com linha digitável/PIX prontos) — título já
                            // nasce 'aberto'. 'processando' ficava travado pra sempre (nada o tirava de
                            // lá além do pagamento via webhook), sumindo da aba "Abertas" sem motivo.
                            $db->prepare("UPDATE ws_fatura SET status='aberto', celcash_charge_id=?, linha_digitavel=?,
                                          boleto_url=?, pix_emv=?, pix_qr_url=?, gateway_raw=? WHERE id=?")
                               ->execute([$r['charge_id'] ?? null, $r['linha_digitavel'] ?? null, $r['boleto_url'] ?? null,
                                          $r['pix_emv'] ?? null, $r['pix_qr_url'] ?? null, $r['raw'] ?? null, $row['fid']]);
                            $emitidas++;
                        } elseif ($erroGw === '') {
                            $erroGw = (string)($r['erro'] ?? 'a CelCoin não respondeu');
                        }
                    } catch (Throwable $e) { if ($erroGw === '') $erroGw = $e->getMessage(); }
                }
                /* O título FOI criado (fica como boleto próprio); o que falhou foi a emissão no
                   gateway. Dizer isso é o que faltava — antes a tela só mostrava "Título gerado". */
                if ($erroGw !== '')
                    $_SESSION['ws_flash_err'] = '⚠️ O título foi criado, mas a CelCoin recusou a emissão: '
                        . mb_substr($erroGw, 0, 400)
                        . ' — teste a conexão em Financeiro → Gateway (credencial, ambiente e whitelist de IP).';
                elseif ($emitidas > 0)
                    $_SESSION['ws_flash'] = "✅ $emitidas boleto(s) emitido(s) na CelCoin (baixa automática pelo webhook).";
            }
        }
        /* EMISSÃO NA LYTEX (lytex.php): só os títulos recém-criados. Falha não apaga o título — ele fica
           como boleto próprio e o motivo vai para a tela (mesma regra da CelCoin acima). */
        if (($_POST['emissao'] ?? '') === 'lytex' && $novosIds && is_file(__DIR__ . '/lytex.php')) {
            require_once __DIR__ . '/lytex.php';
            $lxBanco = ws_lytex_banco_id($db);
            if ($lxBanco && $temBanco) { $inL = implode(',', array_fill(0, count($novosIds), '?')); $db->prepare("UPDATE ws_fatura SET banco_id=? WHERE id IN ($inL)")->execute(array_merge([$lxBanco], $novosIds)); }
            $emitidasL = 0; $erroL = '';
            foreach ($novosIds as $fidL) {
                try { $rL = ws_lytex_emitir_fatura($db, (int)$fidL); if (!empty($rL['ok'])) $emitidasL++; elseif ($erroL === '') $erroL = (string)$rL['erro']; }
                catch (Throwable $e) { if ($erroL === '') $erroL = $e->getMessage(); }
            }
            if ($erroL !== '') $_SESSION['ws_flash_err'] = '⚠️ O título foi criado, mas a Lytex recusou a emissão: ' . mb_substr($erroL, 0, 400) . ' — confira em Financeiro → Gateway.';
            elseif ($emitidasL > 0) $_SESSION['ws_flash'] = "✅ $emitidasL boleto(s) emitido(s) na Lytex (baixa automática).";
        }
        $_SESSION['ws_flash_ok'] = ($tipo==='carne' ? "Carnê gerado: $criadas parcela(s)." : ($criadas > 1 ? "$criadas títulos gerados." : "Título gerado."));
    }
    // Volta pra onde veio (ex.: página de Faturas do Financeiro) se pediram; senão, pra ficha do cliente.
    $volta = (string)($_POST['voltar'] ?? '');
    if ($volta !== '' && preg_match('#^[a-z_]+\.php(\?|$)#i', $volta)) { header('Location: ' . $volta); exit; }
    // Volta ancorado na seção dos títulos (não sobe pro topo da página).
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
// Excluir título — confirmado pela tela "Excluir título" (Motivo + Senha do operador logado).
// POST (antes era um link GET com confirm() nu); exige a senha de quem está logado pra confirmar
// que foi mesmo ele/ela, e guarda o motivo digitado junto do log nativo de exclusões.
if (($_POST['acao'] ?? '') === 'del_fatura_confirmado') {
    $cid = (int)($_POST['cliente'] ?? 0);
    if (!ws_pode_deletar()) { $_SESSION['ws_flash_err'] = '❌ Seu nível de acesso não permite excluir títulos.'; header("Location: erp.php?p=cliente&id=$cid#titulos"); exit; }
    if (!ws_senha_atual_ok($db, (string)($_POST['senha'] ?? ''))) {
        $_SESSION['ws_flash_err'] = '🔒 Senha incorreta — exclusão do título cancelada.';
        header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
    }
    $fid = (int)($_POST['del_fatura'] ?? 0);
    ws_fatura_log_exclusao($db, $fid, (string)($_POST['motivo'] ?? ''));
    $db->prepare("DELETE FROM ws_fatura WHERE id=?")->execute([$fid]);
    $_SESSION['ws_flash_ok'] = "🗑️ Título #$fid excluído.";
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
if (($_POST['acao'] ?? '') === 'del_fatura_lote_confirmado') {
    $cid = (int)($_POST['cliente'] ?? 0);
    if (!ws_pode_deletar()) { $_SESSION['ws_flash_err'] = '❌ Seu nível de acesso não permite excluir títulos.'; header("Location: erp.php?p=cliente&id=$cid#titulos"); exit; }
    if (!ws_senha_atual_ok($db, (string)($_POST['senha'] ?? ''))) {
        $_SESSION['ws_flash_err'] = '🔒 Senha incorreta — exclusão dos títulos cancelada.';
        header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
    }
    $motivo = (string)($_POST['motivo'] ?? '');
    $ids = array_filter(array_map('intval', explode(',', (string)($_POST['del_fatura_lote'] ?? ''))));
    foreach ($ids as $fid2) ws_fatura_log_exclusao($db, (int)$fid2, $motivo);
    if ($ids) { $in = implode(',', array_fill(0, count($ids), '?')); $db->prepare("DELETE FROM ws_fatura WHERE id IN ($in)")->execute(array_values($ids)); }
    $_SESSION['ws_flash_ok'] = '🗑️ ' . count($ids) . ' título(s) excluído(s).';
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
// Excluir título(s) JÁ RECEBIDO(S) (pagos): exige ROOT. Se já é root, exclui direto; senão, valida a
// senha de um usuário root. Remove também o pagamento registrado (é um título já quitado).
if (($_POST['acao'] ?? '') === 'del_recebidos') {
    $cid = (int)($_POST['cliente'] ?? 0);
    $ids = array_filter(array_map('intval', explode(',', (string)($_POST['ids'] ?? ''))));
    $autorizado = ws_eh_root();
    if (!$autorizado) {
        $pw = (string)($_POST['root_pwd'] ?? $_POST['senha'] ?? '');
        if ($pw !== '') {
            try { foreach ($db->query("SELECT senha_hash FROM ws_usuario WHERE nivel_acesso>=99 AND senha_hash IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN) as $hh) {
                    if ($hh && password_verify($pw, (string)$hh)) { $autorizado = true; break; } } } catch (Throwable $e) {}
        }
    }
    // Retorno: a ficha do cliente (padrão) ou o Relatórios › Caixa, que também exclui por aqui.
    // Só aceita voltar para relatorios.php (nada de redirecionar para fora do sistema).
    $voltaDel = (string)($_POST['volta'] ?? '');
    $voltaDel = (strpos($voltaDel, 'relatorios.php') === 0 && strpos($voltaDel, '//') === false) ? $voltaDel : "erp.php?p=cliente&id=$cid";
    if (!$autorizado) { $_SESSION['ws_flash_err'] = '🔒 Senha de root inválida — exclusão de título recebido cancelada.'; header("Location: $voltaDel"); exit; }
    $n = 0;
    foreach ($ids as $fid2) {
        // Cliente de cada título (o Caixa mistura clientes): o evento fica no cadastro certo.
        $cq = $db->prepare("SELECT cliente_id FROM ws_fatura WHERE id=?"); $cq->execute([$fid2]); $cidF = (int)$cq->fetchColumn();
        ws_fatura_log_exclusao($db, (int)$fid2, (string)($_POST['motivo'] ?? ''));
        try { $db->prepare("DELETE FROM ws_pagamento WHERE fatura_id=?")->execute([$fid2]); } catch (Throwable $e) {}
        $db->prepare("DELETE FROM ws_fatura WHERE id=?")->execute([$fid2]);
        ws_evento($db, $cidF ?: ($cid ?: null), 'exclusao', "Título recebido #$fid2 excluído — autorizado por root");
        $n++;
    }
    $_SESSION['ws_flash_ok'] = $n ? "🗑️ $n título(s) recebido(s) excluído(s)." : 'Nenhum título selecionado.';
    header("Location: $voltaDel"); exit;
}
// Estornar pagamento: volta o título pra "aberto", apaga o registro de pagamento e re-sincroniza o
// RADIUS (se o cliente ficar em atraso de novo com o estorno, ele pode voltar a bloquear sozinho).
if (isset($_GET['estornar_fatura']) || ($_POST['acao'] ?? '') === 'estornar') {
    $fid = (int)($_GET['estornar_fatura'] ?? $_POST['estornar_fatura'] ?? 0);
    $cid = (int)($_GET['cliente'] ?? $_POST['cliente'] ?? 0);
    // REGRA DE ESTORNO (preservada): ROOT estorna qualquer dia, sem regra. Níveis 1/2/3 estornam
    // pagamento do PRÓPRIO dia direto; para estornar de DIA ANTERIOR agora é permitido, mas EXIGE a
    // senha de um usuário root (antes era totalmente bloqueado).
    if (!ws_eh_root()) {
        $dp = $db->prepare("SELECT data_pagamento FROM ws_fatura WHERE id=?"); $dp->execute([$fid]);
        $dataPg = (string)$dp->fetchColumn();
        $mesmoDia = ws_pagto_mesmo_dia($db, $dataPg);
        if (!$mesmoDia) {
            $pw = (string)($_POST['root_pwd'] ?? $_POST['senha'] ?? '');
            $okRoot = false;
            if ($pw !== '') {
                try { foreach ($db->query("SELECT senha_hash FROM ws_usuario WHERE nivel_acesso>=99 AND senha_hash IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN) as $hh) {
                        if ($hh && password_verify($pw, (string)$hh)) { $okRoot = true; break; } } } catch (Throwable $e) {}
            }
            if (!$okRoot) {
                $_SESSION['ws_flash_err'] = '🔒 Estorno de pagamento de DIA ANTERIOR exige a senha de um usuário root. Pagamentos recebidos hoje seu nível estorna direto.';
                header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
            }
        }
    }
    $db->prepare("UPDATE ws_fatura SET status='aberto', valor_pago=NULL, data_pagamento=NULL, recibo_em=NULL WHERE id=?")->execute([$fid]);
    $db->prepare("DELETE FROM ws_pagamento WHERE fatura_id=?")->execute([$fid]); // GRAVE 1: apagava só a última linha (LIMIT 1); se a duplicidade do baixa_manual já tinha gravado 2 pagamentos pra mesma fatura, o estorno deixava um "fantasma" pra trás, sumindo da fatura mas continuando a contar no caixa/recibo. Agora limpa todos os pagamentos dessa fatura.
    ws_evento($db, $cid, 'estorno', "Pagamento da fatura #$fid estornado");
    if (is_file(__DIR__ . '/comprovantes_lib.php')) { require_once __DIR__ . '/comprovantes_lib.php'; if (function_exists('ws_comp_estorno_fatura')) ws_comp_estorno_fatura($db, $fid); }   // 09/10/2026: comprovante volta a "novo" e o selo fica livre
    if (is_file(__DIR__ . '/radius_lib.php')) {
        require_once __DIR__ . '/radius_lib.php';
        $ct = $db->prepare("SELECT ct.* FROM ws_fatura f JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?");
        $ct->execute([$fid]); $ctRow = $ct->fetch();
        if ($ctRow && function_exists('ws_rad_deve_bloquear')) { try { ws_rad_sync_contrato($db, $ctRow, ws_rad_deve_bloquear($db, $ctRow)); } catch (Throwable $e) {} }
    }
    $_SESSION['ws_flash_ok'] = "Pagamento da fatura #$fid estornado — voltou pra 'aberto'.";
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
// Estorno em LOTE (dos recebidos selecionados). Mesma regra: root/hoje direto; dia anterior só com senha root.
if (($_POST['acao'] ?? '') === 'estornar_lote') {
    $cid = (int)($_POST['cliente'] ?? 0);
    $ids = array_filter(array_map('intval', explode(',', (string)($_POST['ids'] ?? ''))));
    $isRoot = ws_eh_root(); $okRootPw = false;
    if (!$isRoot) {
        $pw = (string)($_POST['root_pwd'] ?? $_POST['senha'] ?? '');
        if ($pw !== '') { try { foreach ($db->query("SELECT senha_hash FROM ws_usuario WHERE nivel_acesso>=99 AND senha_hash IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN) as $hh) {
                if ($hh && password_verify($pw, (string)$hh)) { $okRootPw = true; break; } } } catch (Throwable $e) {} }
    }
    if (is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    $n = 0; $bloq = 0;
    foreach ($ids as $fid) {
        if (!$isRoot) {
            $dp = $db->prepare("SELECT data_pagamento FROM ws_fatura WHERE id=?"); $dp->execute([$fid]);
            $dataPg = (string)$dp->fetchColumn();
            $mesmoDia = ws_pagto_mesmo_dia($db, $dataPg);
            if (!$mesmoDia && !$okRootPw) { $bloq++; continue; }
        }
        $db->prepare("UPDATE ws_fatura SET status='aberto', valor_pago=NULL, data_pagamento=NULL, recibo_em=NULL WHERE id=?")->execute([$fid]);
        $db->prepare("DELETE FROM ws_pagamento WHERE fatura_id=?")->execute([$fid]); // GRAVE 1: apagava só a última linha (LIMIT 1); se a duplicidade do baixa_manual já tinha gravado 2 pagamentos pra mesma fatura, o estorno deixava um "fantasma" pra trás, sumindo da fatura mas continuando a contar no caixa/recibo. Agora limpa todos os pagamentos dessa fatura.
        ws_evento($db, $cid, 'estorno', "Pagamento da fatura #$fid estornado (lote)");
        if (is_file(__DIR__ . '/comprovantes_lib.php')) { require_once __DIR__ . '/comprovantes_lib.php'; if (function_exists('ws_comp_estorno_fatura')) ws_comp_estorno_fatura($db, $fid); }
        $ct = $db->prepare("SELECT ct.* FROM ws_fatura f JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?"); $ct->execute([$fid]); $ctRow = $ct->fetch();
        if ($ctRow && function_exists('ws_rad_deve_bloquear')) { try { ws_rad_sync_contrato($db, $ctRow, ws_rad_deve_bloquear($db, $ctRow)); } catch (Throwable $e) {} }
        $n++;
    }
    $_SESSION['ws_flash_ok'] = "↩️ $n pagamento(s) estornado(s)" . ($bloq ? " · $bloq bloqueado(s) (dia anterior sem senha root)" : '') . '.';
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
if (isset($_GET['del_contrato'])) {
    if (!ws_pode_deletar()) { $_SESSION['ws_flash_err'] = '❌ Seu nível de acesso não permite excluir contratos.'; header("Location: erp.php?p=cliente&id=" . (int)($_GET['cliente'] ?? 0)); exit; }
    require_once __DIR__ . '/radius_lib.php';
    $ctId = (int)$_GET['del_contrato']; $cid = (int)($_GET['cliente'] ?? 0);
    $lg = $db->prepare("SELECT login_pppoe FROM ws_contrato WHERE id=?"); $lg->execute([$ctId]);
    $login = (string)$lg->fetchColumn(); if ($login !== '') { try { ws_rad_remover($db, $login); } catch (Throwable $e) {} }
    $db->prepare("DELETE FROM ws_contrato WHERE id=?")->execute([$ctId]);
    ws_evento($db, $cid, 'contrato', 'Contrato/conexão excluído');
    header("Location: erp.php?p=cliente&id=$cid"); exit;
}
if (($_POST['acao'] ?? '') === 'editar_nota') {
    $fid = (int)$_POST['fatura_id']; $cid = (int)$_POST['cliente_id'];
    $venc = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['vencimento'] ?? '') ? $_POST['vencimento'] : null;
    // Trocar o vencimento para uma data PASSADA não é aceito (manter a data que já estava, sim).
    if ($venc && ws_venc_passado($venc)) {
        $vAt = $db->prepare("SELECT vencimento FROM ws_fatura WHERE id=?"); $vAt->execute([$fid]);
        if ((string)$vAt->fetchColumn() !== $venc) { $_SESSION['ws_flash_err'] = ws_venc_passado_msg($venc); $venc = null; }
    }
    if ($venc) { $db->prepare("UPDATE ws_fatura SET obs=?, vencimento=? WHERE id=?")->execute([trim($_POST['obs'] ?? '') ?: null, $venc, $fid]); $db->prepare("UPDATE ws_fatura SET status=IF(vencimento<CURDATE(),'vencido','aberto') WHERE id=? AND status IN ('aberto','vencido')")->execute([$fid]); }   // data mudou: status acompanha (16/10/2026)
    else $db->prepare("UPDATE ws_fatura SET obs=? WHERE id=?")->execute([trim($_POST['obs'] ?? '') ?: null, $fid]);
    header("Location: erp.php?p=cliente&id=$cid#titulos"); exit;
}
// Checagem AJAX: já existe titular ATIVO com este CPF/CNPJ? (usado para desativar o botão de salvar)
if (isset($_GET['onu_estado'])) {
    $cid = (int)$_GET['onu_estado']; $v = ((int)($_GET['v'] ?? 1)) === 1 ? 1 : 0;
    $db->prepare("UPDATE ws_contrato SET onu_ativa=? WHERE id=?")->execute([$v, $cid]);
    header('Location: erp.php?p=contrato&id=' . $cid); exit;
}
/* RESUMO COMPACTO do cliente — o cartão que aparece ao PASSAR O MOUSE no nome resumido da lista.
   Mesmos dados da página "Resumo" (p=cliente_resumo), só que enxutos; o clique continua abrindo a página. */
if (($_GET['ajax'] ?? '') === 'resumo_cli') {
    header('Content-Type: text/html; charset=utf-8');
    $idR = (int)($_GET['id'] ?? 0);
    /* Também aceita ?login= (login PPPoE, login IPoE ou SN da ONU): usado pelo resumo ao passar o mouse no nome, na página da OLT. */
    if ($idR === 0 && trim((string)($_GET['login'] ?? '')) !== '') {
        try {
            $lgR = trim((string)$_GET['login']);
            $ql = $db->prepare("SELECT cliente_id FROM ws_contrato WHERE status<>'cancelado' AND (UPPER(login_pppoe)=UPPER(?) OR UPPER(login_ipoe)=UPPER(?) OR UPPER(REPLACE(REPLACE(sn_onu,'-',''),' ',''))=UPPER(?)) ORDER BY (status='ativo') DESC, id LIMIT 1");
            $ql->execute([$lgR, $lgR, $lgR]); $idR = (int)$ql->fetchColumn();
        } catch (Throwable $e) {}
    }
    $sc = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $sc->execute([$idR]); $cliR = $sc->fetch();
    if (!$cliR || (!empty($cliR['ramal_id']) && !ws_ramal_permitido((int)$cliR['ramal_id']))) { echo '<div class="ws-muted">Sem acesso a este cliente.</div>'; exit; }
    $sk = $db->prepare("SELECT ct.*, p.nome plano_nome FROM ws_contrato ct LEFT JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=? ORDER BY (ct.status='ativo') DESC, ct.id LIMIT 1");
    $sk->execute([$idR]); $conR = $sk->fetch();
    $ab = 0; try { $qa = $db->prepare("SELECT COUNT(*) FROM ws_fatura WHERE cliente_id=? AND status IN('aberto','vencido','processando') AND vencimento<CURDATE()"); $qa->execute([$idR]); $ab = (int)$qa->fetchColumn(); } catch (Throwable $e) {}
    // linha SEM quebra (08/10/2026): o cartão cresce até caber; endereço e bairro em linhas separadas
    $lin = function ($r, $v) { return $v !== '' && $v !== null ? '<div style="white-space:nowrap"><span style="opacity:.7">' . $r . ':</span> <b>' . h((string)$v) . '</b></div>' : ''; };
    $foneFmt = function ($t) { $n = preg_replace('/\D/', '', (string)$t); if (strlen($n) >= 12 && substr($n, 0, 2) === '55') $n = substr($n, 2); if (strlen($n) === 10 && preg_match('/^\d{2}[6-9]/', $n)) $n = substr($n, 0, 2) . '9' . substr($n, 2); return strlen($n) === 11 ? '(' . substr($n, 0, 2) . ') ' . substr($n, 2, 5) . '-' . substr($n, 7) : (strlen($n) === 10 ? '(' . substr($n, 0, 2) . ') ' . substr($n, 2, 4) . '-' . substr($n, 6) : (string)$t); };
    $end = trim(($cliR['logradouro'] ?? '') . ' ' . ($cliR['numero'] ?? ''));
    echo '<div style="font-weight:800;font-size:13.5px;margin-bottom:4px">' . h($cliR['nome']) . '</div>'
       . $lin('Status', $cliR['status']) . $lin('Celular', $foneFmt($cliR['celular']))
       . $lin('Cliente desde', !empty($cliR['data_cadastro']) ? date('d/m/Y', strtotime((string)$cliR['data_cadastro'])) : '')
       . $lin('Endereço', $end) . $lin('Bairro', $cliR['bairro'] ?? '')
       . ($conR ? $lin('Login', $conR['login_pppoe'] ?: $conR['login_ipoe']) . $lin('Plano', $conR['plano_nome']) . $lin('Vencimento', $conR['dia_vencimento'] ? 'dia ' . $conR['dia_vencimento'] : '')
                 . $lin('SN / MAC', $conR['sn_onu'] ?: ($conR['equip_mac'] ?? '')) . $lin('VLAN', $conR['vlan'] ?? '') : '<div class="ws-muted">Sem contrato.</div>')
       . ($ab ? '<div style="color:var(--err);font-weight:800;margin-top:4px">⚠ ' . $ab . ' título(s) vencido(s)</div>' : '')
       . '<div style="margin-top:6px;white-space:nowrap"><a href="erp.php?p=cliente_resumo&id=' . (int)$idR . '" style="color:#5aa9ff;font-size:12px;font-weight:600;text-decoration:none" onmouseover="this.style.textDecoration=\'underline\'" onmouseout="this.style.textDecoration=\'none\'">🔎 Clique aqui para abrir o resumo completo</a></div>';
    exit;
}
if (($_GET['ajax'] ?? '') === 'checar_titular') {
    header('Content-Type: application/json');
    $doc = trim($_GET['cpf'] ?? ''); $idAtual = (int)($_GET['id'] ?? 0); $titularRef = (int)($_GET['titular'] ?? 0);
    $resp = ['duplicado' => false, 'invalido' => false];
    if ($doc !== '') {
        // Exceção 1: CNPJ do próprio provedor — checada ANTES do dígito verificador. Vale para
        // titular e adicional igual; antes vinha depois, então um CNPJ de provedor que o algoritmo
        // de dígito considerasse "inválido" travava o cadastro TITULAR ali mesmo, sem nunca chegar
        // nesta exceção (no ADICIONAL o campo costuma vir herdado do titular, por isso não aparecia lá).
        $cnpjProv = function_exists('ws_provedor_cnpj') ? ws_provedor_cnpj() : '';
        $docLimpo = preg_replace('/\D/', '', $doc);
        if ($cnpjProv !== '' && $docLimpo === $cnpjProv) { echo json_encode($resp); exit; }
        // Confere o dígito verificador (item 3) — se está errado, nem vale a pena checar duplicidade
        // ainda (o operador precisa corrigir o número de qualquer forma).
        if (ws_recursos()['validar_cpf'] && !ws_cpf_cnpj_valido($doc)) { $resp['invalido'] = true; echo json_encode($resp); exit; }
        $st = $db->prepare("SELECT id,nome FROM ws_cliente WHERE cpf_cnpj=? AND titular_id IS NULL AND status<>'cancelado' AND id<>? LIMIT 1");
        $st->execute([$doc, $idAtual]);
        if ($r = $st->fetch()) {
            // Exceção 2: é o próprio CPF/CNPJ do titular ao qual este cadastro (adicional) está vinculado.
            if ($titularRef && (int)$r['id'] === $titularRef) { echo json_encode($resp); exit; }
            $resp = ['duplicado' => true, 'invalido' => false, 'id' => (int)$r['id'], 'nome' => $r['nome']];
        }
    }
    echo json_encode($resp); exit;
}
if (($_GET['cli_acao'] ?? '') !== '') {
    require_once __DIR__ . '/radius_lib.php';
    $ctId = (int)($_GET['contrato'] ?? 0); $cid = (int)($_GET['cliente'] ?? 0);
    $st = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $st->execute([$ctId]); $ct = $st->fetch();
    if ($ct) {
        switch ($_GET['cli_acao']) {
            case 'bloquear':
                // Bloqueio MANUAL pela ficha: bloqueia o cliente e CASCATEIA para os adicionais.
                $nA = ws_cliente_bloqueio($db, $cid, true, true, true);
                ws_evento($db, $cid, 'bloqueio', 'Cliente bloqueado (ficha)' . ($nA ? " + $nA adicional(is)" : '')); break;
            case 'desbloquear':
                if (($avM = ws_desbloqueio_aviso($db, $cid)) !== '') { $_SESSION['ws_flash_err'] = $avM; break; }
                $nA = ws_cliente_bloqueio($db, $cid, false, true, true);
                ws_evento($db, $cid, 'desbloqueio', 'Cliente desbloqueado (ficha)' . ($nA ? " + $nA adicional(is)" : '')); break;
            case 'confiar':
                if (($avM = ws_confianca_aviso_mes($db, $cid)) !== '') { $_SESSION['ws_flash_err'] = $avM; break; }
                if (!ws_rad_confiar($db, $ct, ws_dias_confianca())) { $_SESSION['ws_flash_err'] = '⚠️ ' . ws_rad_confiar_aviso(); break; }
                ws_evento($db, $cid, 'confianca', 'Liberado em confiança ' . ws_dias_confianca() . ' dia(s) (ficha)'); break;
            case 'derrubar':
                ws_rad_derrubar_contrato($db, $ct);   // PPPoE e IPoE, com confirmação
                ws_evento($db, $cid, 'conexao', 'Conexão derrubada (disconnect) na ficha');
                $_SESSION['ws_flash_ok'] = 'Comando de desconexão enviado ao concentrador.'; break;
            case 'gerar_fatura':
                require_once __DIR__ . '/faturamento.php';
                $fid = ws_faturar_um($db, $ct);
                header("Location: financeiro.php?p=fatura&id=$fid"); exit;
        }
    }
    header("Location: erp.php?p=cliente&id=$cid&ok=1"); exit;
}
// Liberar em confiança (por cliente) — libera todos os contratos por N dias
// NOTA DO CLIENTE pela lista (03/10/2026): é a mesma Observação da ficha (ws_cliente.obs), sem abrir o cadastro.
if (($_POST['acao'] ?? '') === 'cli_nota') {
    $cidN = (int)($_POST['cliente_id'] ?? 0); $txtN = mb_substr(trim((string)($_POST['nota'] ?? '')), 0, 2000);
    if ($cidN > 0) {
        $db->prepare("UPDATE ws_cliente SET obs=? WHERE id=?")->execute([$txtN !== '' ? $txtN : null, $cidN]);
        ws_evento($db, $cidN, 'cliente', $txtN !== '' ? 'Nota do cliente atualizada: ' . mb_substr($txtN, 0, 150) : 'Nota do cliente apagada.');
        $_SESSION['ws_flash_ok'] = '📝 Nota salva.';
    }
    header('Location: ' . ws_volta_cli($_POST['volta'] ?? '', $cidN, 'erp.php?p=clientes')); exit;   // volta na lista, no próprio cliente
}
if (($_GET['cli_confiar'] ?? '') !== '') {
    require_once __DIR__ . '/radius_lib.php';
    $cid = (int)$_GET['cli_confiar']; $dias = max(1, min(365, (int)($_GET['dias'] ?? ws_dias_confianca())));
    if (empty($_GET['aviso_ok']) && ($avM = ws_confianca_aviso_mes($db, $cid)) !== '') { $_SESSION['ws_flash_err'] = $avM; header('Location: ' . ws_volta_cli($_GET['volta'] ?? '', $cid, 'erp.php?p=clientes')); exit; }
    $cts = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=?"); $cts->execute([$cid]);
    $recusou = false;
    foreach ($cts->fetchAll() as $ct) { if (!ws_rad_confiar($db, $ct, $dias)) $recusou = true; }
    $nm = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $nm->execute([$cid]); $nome = $nm->fetchColumn();
    $ate = date('d/m/Y', strtotime("+$dias days"));
    if ($recusou) {
        $_SESSION['ws_flash_err'] = '⚠️ ' . ws_rad_confiar_aviso();
    } else {
        ws_evento($db, $cid, 'confianca', "Liberado em confiança por $dias dia(s) — até $ate");
        $_SESSION['ws_flash_ok'] = "✅ Desbloqueio em confiança confirmado! Cliente $nome liberado até $ate — re-bloqueia sozinho ao vencer.";
    }
    header('Location: ' . ws_volta_cli($_GET['volta'] ?? '', $cid, 'erp.php?p=clientes')); exit;
}
/**
 * Bloqueia/desbloqueia um cliente (todos os contratos dele de uma vez). REGRA GERAL: se o cliente
 * for TITULAR, a mesma ação CASCATA para todos os seus adicionais. Ações individuais (num adicional
 * específico) usam $cascata=false — aí sobrepõe só aquele cliente, sem mexer nos demais.
 * Retorna quantos adicionais foram afetados em cascata.
 */
function ws_cliente_bloqueio(PDO $db, int $cid, bool $bloq, bool $cascata = true, bool $manual = true): int {
    require_once __DIR__ . '/radius_lib.php';
    $aplica = function (int $id, bool $herdado = false) use ($db, $bloq, $manual) {
        // Bloqueio manual marca bloqueio_manual=1 (persiste mesmo sem dívida). Desbloqueio limpa a flag.
        // Nos ADICIONAIS vira 2 (herdado do titular): sai junto quando o titular é liberado (regra de ouro).
        $mf = ($bloq && $manual) ? ($herdado ? 2 : 1) : 0;
        $cts = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=?"); $cts->execute([$id]);
        foreach ($cts->fetchAll() as $ct) {
            if ($bloq) { $db->prepare("UPDATE ws_contrato SET status='bloqueado', bloqueio_manual=? WHERE id=?")->execute([$mf, $ct['id']]); try { ws_rad_bloquear($db, $ct); } catch (Throwable $e) {} }
            else { $db->prepare("UPDATE ws_contrato SET status='ativo', confianca_ate=NULL, bloqueio_manual=0 WHERE id=?")->execute([$ct['id']]); $ct['status']='ativo'; $ct['confianca_ate']=null; try { ws_rad_desbloquear($db, $ct); } catch (Throwable $e) {} }
        }
        $db->prepare("UPDATE ws_cliente SET status=? WHERE id=? AND status<>'cancelado'")->execute([$bloq ? 'bloqueado' : 'ativo', $id]);
    };
    $aplica($cid);
    $n = 0;
    if ($cascata) {
        $ad = $db->prepare("SELECT id FROM ws_cliente WHERE titular_id=? AND status<>'cancelado'"); $ad->execute([$cid]);
        foreach ($ad->fetchAll(PDO::FETCH_COLUMN) as $aid) { $aplica((int)$aid, true); $n++; }
    }
    return $n;
}

// Bloquear (por cliente, todos os contratos) — ícone/menu rápido da lista. Cascateia p/ adicionais.
if (($_GET['cli_bloquear'] ?? '') !== '') {
    $cid = (int)$_GET['cli_bloquear'];
    $ind = isset($_GET['individual']);   // ação só neste cliente (não cascateia)
    $n = ws_cliente_bloqueio($db, $cid, true, !$ind);
    ws_evento($db, $cid, 'bloqueio', 'Bloqueado (menu rápido da lista)' . ($n ? " + $n adicional(is)" : ''));
    $_SESSION['ws_flash_ok'] = '🔒 Cliente bloqueado' . ($n ? " (e $n adicional(is) junto)" : '') . '.';
    header('Location: ' . ws_volta_cli($_GET['volta'] ?? '', $cid, 'erp.php?p=clientes')); exit;
}

// Desbloquear (por cliente, todos os contratos de uma vez) — usado no ícone rápido da lista.
if (($_GET['cli_desbloquear'] ?? '') !== '') {
    $cid = (int)$_GET['cli_desbloquear'];
    $ind = isset($_GET['individual']);
    if (($avM = ws_desbloqueio_aviso($db, $cid)) !== '') { $_SESSION['ws_flash_err'] = $avM; header('Location: ' . ws_volta_cli($_GET['volta'] ?? '', $cid, 'erp.php?p=clientes')); exit; }   // já liberado no mês: avisa antes (16/10/2026)
    $n = ws_cliente_bloqueio($db, $cid, false, !$ind);
    ws_evento($db, $cid, 'desbloqueio', 'Desbloqueado (menu rápido da lista)' . ($n ? " + $n adicional(is)" : ''));
    $_SESSION['ws_flash_ok'] = '✅ Cliente desbloqueado' . ($n ? " (e $n adicional(is) junto)" : '') . '.';
    header('Location: ' . ws_volta_cli($_GET['volta'] ?? '', $cid, 'erp.php?p=clientes')); exit;
}

// Reativar cliente cancelado (volta cliente + contratos para ativo)
if (($_GET['cli_reativar'] ?? '') !== '') {
    require_once __DIR__ . '/radius_lib.php';
    $cid = (int)$_GET['cli_reativar'];
    $db->prepare("UPDATE ws_cliente SET status='ativo', data_desativacao=NULL WHERE id=?")->execute([$cid]);
    $cts = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=?"); $cts->execute([$cid]);
    foreach ($cts->fetchAll() as $ct) {
        $db->prepare("UPDATE ws_contrato SET status='ativo' WHERE id=?")->execute([$ct['id']]);
        $ct['status'] = 'ativo'; ws_rad_sync_contrato($db, $ct, ws_rad_deve_bloquear($db, $ct));
    }
    ws_evento($db, $cid, 'reativacao', 'Cliente reativado');
    header('Location: erp.php?p=cliente&id=' . $cid . '&ok=1'); exit;
}

// Desativar cliente (Cancelar por completo)
if (($_GET['cli_desativar'] ?? '') !== '') {
    require_once __DIR__ . '/radius_lib.php';
    $cid = (int)$_GET['cli_desativar'];
    $db->prepare("UPDATE ws_cliente SET status='cancelado', data_desativacao=CURDATE() WHERE id=?")->execute([$cid]);
    $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
    $lg->execute([$cid]);
    foreach ($lg->fetchAll(PDO::FETCH_COLUMN) as $login) { try { if (!ws_rad_disconnect($db, (string)$login) && ws_rad_sessao_aberta($db, (string)$login)) ws_rad_pendente_marcar((string)$login); } catch (Throwable $e) {} ws_rad_remover($db, (string)$login); }
    /* A DATA do cancelamento vai no contrato. Sem ela o relatório de Ativação/Desativação ficava
       com "Desativações: 0" para sempre — o cliente saía, e o relatório dizia que ninguém saiu. */
    $db->prepare("UPDATE ws_contrato SET status='cancelado', data_cancelamento=COALESCE(data_cancelamento, CURDATE()) WHERE cliente_id=?")->execute([$cid]);
    $limparDados = (($_GET['limpar'] ?? '1') !== '0');   // janela de confirmação: 1 = limpando tudo (padrão), 0 = sem limpar
    $erroLimpa = ''; try { ws_contratos_limpar_desativacao($db, $cid, $limparDados); } catch (Throwable $e) { $erroLimpa = $e->getMessage(); @error_log('[desativar] limpeza falhou: ' . $erroLimpa); }   // limpa ID, Login/Senha IPoE, SN ONU/ONT e Login/Senha PPPoE (+ guarda a tarja do equipamento)
    ws_evento($db, $cid, 'desativacao', $limparDados ? 'Cliente desativado — dados limpos' : 'Cliente desativado — dados MANTIDOS (sem limpar)');
    if ($erroLimpa !== '') $_SESSION['ws_flash_err'] = '⚠️ Cliente desativado, mas os dados NÃO foram limpos: ' . mb_substr($erroLimpa, 0, 220);
    else $_SESSION['ws_flash_ok'] = $limparDados ? '✅ Cliente desativado. ID, logins/senhas IPoE e PPPoE, SN da ONU/ONT e a seção Equipamento foram limpos; o equipamento ficou registrado na tarja da ficha.' : '✅ Cliente desativado SEM limpar os dados (ID, logins/senhas e SN mantidos).';
    // Desativou pela ficha do cliente: continua na ficha. Pela lista: vai para a lista de cancelados, como antes.
    if (($_GET['volta'] ?? '') === 'ficha') { header('Location: erp.php?p=cliente&id=' . $cid); exit; }
    header('Location: erp.php?p=clientes&status=cancelado&ok=1'); exit;
}

// Excluir cliente individualmente (com confirmação)
if (($_GET['cli_del'] ?? '') !== '') {
    if (!ws_pode_deletar()) {
        $_SESSION['ws_flash_err'] = '❌ Você não tem permissão para excluir clientes.';
        header('Location: erp.php?p=clientes'); exit;
    }
    require_once __DIR__ . '/radius_lib.php';
    $cid = (int)$_GET['cli_del'];
    $stNome = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $stNome->execute([$cid]); $nomeDel = $stNome->fetchColumn() ?: "ID #$cid";
    $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
    $lg->execute([$cid]);
    foreach ($lg->fetchAll(PDO::FETCH_COLUMN) as $login) ws_rad_remover($db, (string)$login);
    $lgA = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE c.titular_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
    $lgA->execute([$cid]);
    foreach ($lgA->fetchAll(PDO::FETCH_COLUMN) as $login) ws_rad_remover($db, (string)$login);
    $db->prepare("DELETE FROM ws_cliente WHERE id=?")->execute([$cid]);
    $_SESSION['ws_flash_ok'] = '✅ Cliente "' . $nomeDel . '" e seus dados foram excluídos com sucesso.';
    header('Location: erp.php?p=' . (($_GET['volta'] ?? '') === 'recentes' ? 'clientes_recentes' : 'clientes')); exit;   // volta para a tela de onde excluiu
}

// Receber (baixa) rápida de uma fatura direto da ficha
if (($_GET['cli_receber'] ?? '') !== '') {
    $fid = (int)$_GET['cli_receber']; $cid = (int)($_GET['cliente'] ?? 0);
    $f = $db->prepare("SELECT valor FROM ws_fatura WHERE id=?"); $f->execute([$fid]); $val = (float)$f->fetchColumn();
    $db->prepare("INSERT INTO ws_pagamento (fatura_id,data_pgto,valor_pago,forma,origem,coletor) VALUES (?,?,?, 'dinheiro','manual',?)")
       ->execute([$fid, date('Y-m-d'), $val, ws_user()['nome'] ?? 'admin']);
    $db->prepare("UPDATE ws_fatura SET status='pago', data_pagamento=CURDATE(), valor_pago=? WHERE id=?")->execute([$val, $fid]);
    ws_evento($db, $cid, 'pagamento', 'Recebido (ficha): R$ ' . number_format($val, 2, ',', '.'));
    // Recibo automático por WhatsApp (se ativado em Recibos → Config)
    if (is_file(__DIR__ . '/whatsapp.php')) {
        require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_recibo_config') && !empty(ws_recibo_config()['auto'])) { try { ws_recibo_enviar($db, $fid); } catch (Throwable $e) {} }
    }
    header("Location: erp.php?p=cliente&id=$cid&ok=1#titulos"); exit;   // volta no bloco dos boletos
}

// Ação em lote nos clientes selecionados (bloquear/desbloquear)
if (($_GET['lote'] ?? '') !== '' && ($_GET['ids'] ?? '') !== '') {
    require_once __DIR__ . '/radius_lib.php';
    $ids = array_filter(array_map('intval', explode(',', $_GET['ids'])));
    // Excluir clientes selecionados (remove login do RADIUS antes)
    if ($_GET['lote'] === 'excluir') {
        foreach ($ids as $cid) {
            $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
            $lg->execute([$cid]);
            foreach ($lg->fetchAll(PDO::FETCH_COLUMN) as $login) ws_rad_remover($db, (string)$login);
            // Titular excluído em massa: limpa também o RADIUS dos adicionais vinculados a ele.
            $lgA = $db->prepare("SELECT ct.login_pppoe FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                                 WHERE c.titular_id=? AND ct.login_pppoe IS NOT NULL AND ct.login_pppoe<>''");
            $lgA->execute([$cid]);
            foreach ($lgA->fetchAll(PDO::FETCH_COLUMN) as $login) ws_rad_remover($db, (string)$login);
            $db->prepare("DELETE FROM ws_cliente WHERE id=?")->execute([$cid]); // ON DELETE CASCADE remove contratos/faturas
        }
        header('Location: erp.php?p=clientes&ok=1'); exit;
    }
    $acao = $_GET['lote'] === 'bloquear' ? 'bloquear' : 'desbloquear';
    $avisados = [];
    foreach ($ids as $cid) {
        if ($acao === 'desbloquear' && ($avM = ws_desbloqueio_aviso($db, (int)$cid)) !== '') { $avisados[] = $avM; continue; }   // já liberado no mês: não desbloqueia no 1º clique (16/10/2026)
        // Em lote é ação MANUAL do operador e CASCATEIA para os adicionais do titular.
        $n = ws_cliente_bloqueio($db, (int)$cid, $acao === 'bloquear', true, true);
        ws_evento($db, (int)$cid, $acao, 'Cliente ' . $acao . ' (em lote)' . ($n ? " + $n adicional(is)" : ''));
    }
    if ($avisados) $_SESSION['ws_flash_err'] = implode("
", array_slice($avisados, 0, 5)) . (count($avisados) > 5 ? "
… e mais " . (count($avisados) - 5) . ' cliente(s) com liberação no mês.' : '');
    header('Location: erp.php?p=clientes&ok=1'); exit;
}

// Trocar a própria senha
if (($_POST['acao'] ?? '') === 'trocar_senha') {
    $nova = (string)($_POST['nova'] ?? '');
    if (strlen($nova) >= 4) {
        $db->prepare("UPDATE ws_usuario SET senha_hash=? WHERE id=?")
           ->execute([password_hash($nova, PASSWORD_DEFAULT), (int)ws_user()['id']]);
    }
    header('Location: erp.php?p=config&t=geral&ok=1'); exit;
}

// Criar/editar operador (só admin)
if (($_POST['acao'] ?? '') === 'salvar_usuario' && ws_user()['nivel'] === 'admin') {
    $id = (int)($_POST['id'] ?? 0);
    // DEMONSTRAÇÃO: só é permitido editar a PRÓPRIA conta (nunca a de outra pessoa testando).
    if (ws_em_demo() && $id && $id !== (int)(ws_user()['id'] ?? 0)) {
        $_SESSION['ws_flash_err'] = '❌ No modo demonstração você só edita a sua própria conta.';
        header('Location: erp.php?p=config&t=operadores'); exit;
    }
    $nome = trim($_POST['nome'] ?? ''); $login = trim($_POST['login'] ?? '');
    $nivel = in_array($_POST['nivel'] ?? '', ['admin','financeiro','tecnico','atendente'], true) ? $_POST['nivel'] : 'atendente';
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    // Nível de acesso numérico (1/2/3/99) — só o Root pode alterar (evita alguém de nível 3
    // se autopromover a Root, ou promover outro operador além do combinado).
    $nivelAcesso = in_array((int)($_POST['nivel_acesso'] ?? 0), [1,2,3,99], true) ? (int)$_POST['nivel_acesso'] : null;
    if ($id) {
        $db->prepare("UPDATE ws_usuario SET nome=?,login=?,nivel=?,ativo=? WHERE id=?")->execute([$nome,$login,$nivel,$ativo,$id]);
        if (!empty($_POST['senha'])) $db->prepare("UPDATE ws_usuario SET senha_hash=? WHERE id=?")->execute([password_hash($_POST['senha'], PASSWORD_DEFAULT), $id]);
        if ($nivelAcesso !== null && ws_eh_root()) $db->prepare("UPDATE ws_usuario SET nivel_acesso=? WHERE id=?")->execute([$nivelAcesso, $id]);
    } else {
        $db->prepare("INSERT INTO ws_usuario (nome,login,senha_hash,nivel,ativo,nivel_acesso) VALUES (?,?,?,?,?,?)")
           ->execute([$nome,$login,password_hash($_POST['senha'] ?: 'trocar123', PASSWORD_DEFAULT),$nivel,$ativo, ($nivelAcesso !== null && ws_eh_root()) ? $nivelAcesso : 2]);
        $id = (int)$db->lastInsertId();
    }
    // Cidades (ramais) deste login — ws_ramais_permitidos(). Só grava se o bloco veio no formulário.
    if ($id > 0 && !empty($_POST['ramais_enviado'])) {
        try {
            $db->prepare("DELETE FROM ws_usuario_ramal WHERE usuario_id=?")->execute([$id]);
            // Cidade PRINCIPAL (a do login) + as outras marcadas, por onde ele transita sem novo login.
            $insR = $db->prepare("INSERT IGNORE INTO ws_usuario_ramal (usuario_id, ramal_id, principal) VALUES (?,?,?)");
            $ramPrin = (int)($_POST['ramal_principal'] ?? 0);
            if ($ramPrin > 0) $insR->execute([$id, $ramPrin, 1]);
            foreach (array_unique(array_map('intval', (array)($_POST['ramais'] ?? []))) as $rid) if ($rid > 0 && $rid !== $ramPrin) $insR->execute([$id, $rid, 0]);
        } catch (Throwable $e) {}
    }
    // Foto do operador (uploads/operadores/<id>.<ext>) — aparece junto ao nome no topo.
    $fErr = '';
    $fe = (int)($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($fe === UPLOAD_ERR_OK && !empty($_FILES['foto']['tmp_name']) && $id > 0) {
        $dir = WS_UPLOADS . '/operadores';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        // valida que é imagem de verdade (não confia só na extensão)
        $mimeOk = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
        $mime = function_exists('finfo_file') ? (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['foto']['tmp_name']) : ($_FILES['foto']['type'] ?? '');
        if (!isset($mimeOk[$mime])) { $fErr = 'A foto precisa ser JPG, PNG, WEBP ou GIF.'; }
        else {
            $ext = $mimeOk[$mime];
            foreach (glob("$dir/$id.*") ?: [] as $old) @unlink($old);
            $dest = "$dir/$id.$ext";
            if (!ws_mover_upload($_FILES['foto']['tmp_name'], $dest)) {
                $fErr = 'Não consegui gravar a foto em ' . $dir . ' — disco cheio ou sistema de arquivos somente leitura.';
            }
        }
    } elseif ($fe !== UPLOAD_ERR_NO_FILE && $fe !== UPLOAD_ERR_OK) {
        $fErr = 'Falha no upload da foto (código ' . $fe . ').';
    }
    if ($fErr) $_SESSION['ws_flash_err'] = '⚠️ Operador salvo, mas a FOTO não: ' . $fErr;
    header('Location: erp.php?p=config&t=operadores&ok=1'); exit;
}
if (($_GET['del_user'] ?? '') !== '' && ws_user()['nivel'] === 'admin' && (int)$_GET['del_user'] !== (int)ws_user()['id']) {
    // DEMONSTRAÇÃO: ninguém exclui a conta de OUTRA pessoa que está testando (blindagem no servidor).
    if (ws_em_demo()) { $_SESSION['ws_flash_err'] = '❌ No modo demonstração você só pode mexer na sua própria conta.'; header('Location: erp.php?p=config&t=operadores'); exit; }
    $db->prepare("DELETE FROM ws_usuario WHERE id=?")->execute([(int)$_GET['del_user']]);
    header('Location: erp.php?p=config&t=operadores'); exit;
}

// Excluir
if (($_GET['excluir'] ?? '') !== '' && isset($_GET['tipo'])) {
    if (!ws_pode_deletar()) { $_SESSION['ws_flash'] = '❌ Seu nível de acesso não permite excluir registros.'; header('Location: erp.php?p=' . ($_GET['volta'] ?? 'dashboard')); exit; }
    $tab = ['cliente' => 'ws_cliente', 'contrato' => 'ws_contrato', 'plano' => 'ws_plano'][$_GET['tipo']] ?? null;
    // Gancho RADIUS: ao excluir contrato, remove o login do FreeRADIUS.
    if ($tab === 'ws_contrato' && is_file(__DIR__ . '/radius_lib.php')) {
        require_once __DIR__ . '/radius_lib.php';
        $st = $db->prepare("SELECT login_pppoe FROM ws_contrato WHERE id=?"); $st->execute([(int)$_GET['excluir']]);
        if ($lg = $st->fetchColumn()) ws_rad_remover($db, (string)$lg);
    }
    // Gancho RADIUS: ao excluir o CLIENTE inteiro, remove TODOS os logins dos contratos dele antes —
    // o ON DELETE CASCADE apaga os contratos do banco, mas não sabe nada sobre radcheck/radreply/
    // radusergroup (tabelas do FreeRADIUS, sem relação de chave estrangeira), então esses registros
    // ficavam órfãos pra sempre. Isso vale tanto pro titular quanto pra qualquer adicional dele.
    if ($tab === 'ws_cliente' && is_file(__DIR__ . '/radius_lib.php')) {
        require_once __DIR__ . '/radius_lib.php';
        $cidExcluir = (int)$_GET['excluir'];
        $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
        $lg->execute([$cidExcluir]);
        foreach ($lg->fetchAll(PDO::FETCH_COLUMN) as $login) { try { if (!ws_rad_disconnect($db, (string)$login) && ws_rad_sessao_aberta($db, (string)$login)) ws_rad_pendente_marcar((string)$login); } catch (Throwable $e) {} ws_rad_remover($db, (string)$login); }
        // Se o cliente excluído for TITULAR, os adicionais dele também têm contratos próprios — limpa também.
        $lgA = $db->prepare("SELECT ct.login_pppoe FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                             WHERE c.titular_id=? AND ct.login_pppoe IS NOT NULL AND ct.login_pppoe<>''");
        $lgA->execute([$cidExcluir]);
        foreach ($lgA->fetchAll(PDO::FETCH_COLUMN) as $login) { try { if (!ws_rad_disconnect($db, (string)$login) && ws_rad_sessao_aberta($db, (string)$login)) ws_rad_pendente_marcar((string)$login); } catch (Throwable $e) {} ws_rad_remover($db, (string)$login); }
    }
    if ($tab) { $db->prepare("DELETE FROM $tab WHERE id=?")->execute([(int)$_GET['excluir']]); }
    header('Location: erp.php?p=' . ($_GET['volta'] ?? 'dashboard')); exit;
}

/* ----------------------------------------------------------------- VIEWS */
if ($p === 'clientes_csv') {
    ws_csv_clientes($db);
    exit;
}

ws_header($p);
switch ($p) {
    case 'clientes':  ws_view_clientes($db);  break;
    case 'clientes_recentes': ws_view_clientes_recentes($db); break;
    case 'cliente':   ws_view_cliente($db);   break;   // ficha + contratos (titular)
    case 'cliente_resumo': ws_view_cliente_resumo($db); break; // resumo rápido
    case 'adicional': ws_view_cliente($db);   break;   // ficha do ADICIONAL — página separada, mas 100% das mesmas funções do titular (mesma função)
    case 'contrato':  ws_view_contrato($db);  break;   // form contrato
    case 'planos':    ws_view_planos($db);    break;
    case 'cadastros':
        // Cadastros (Cidades/Bairros/Ramais) = configuração técnica: só nível 3+ e root.
        ws_view_cadastros($db); break;
    case 'config':    ws_view_config($db);    break;
    case 'atalhos':   ws_view_atalhos($db);   break;
    default:          ws_view_dashboard($db); break;
}
ws_footer($p);

/** Tela pra editar os botões de "Acesso rápido" do Painel — cria/edita/remove atalho
 *  (título + URL), exatamente como pedido: os botões que já existiam viram editáveis. */
function ws_view_atalhos(PDO $db): void {
    if (isset($_GET['restaurar']) && ws_pode_deletar()) {
        @unlink(WS_CACHE . '/atalhos_painel.json'); header('Location: erp.php?p=atalhos&ok=1'); exit;
    }
    if (($_POST['acao'] ?? '') === 'salvar_atalhos' && ws_pode_deletar()) {
        $titulos = $_POST['titulo'] ?? []; $urls = $_POST['url'] ?? [];
        $novos = [];
        foreach ($titulos as $i => $t) { $t = trim($t); $u = trim($urls[$i] ?? ''); if ($t !== '' && $u !== '') $novos[] = [$u, $t]; }
        @file_put_contents(WS_CACHE . '/atalhos_painel.json', json_encode($novos, JSON_UNESCAPED_UNICODE));
        @chmod(WS_CACHE . '/atalhos_painel.json', 0640);
        header('Location: erp.php?p=atalhos&ok=1'); exit;
    }
    $atalhosPadrao = [
        ['erp.php?p=config&t=operadores','👤 Criar usuários'], ['radius.php?p=usuarios','📡 Radius'],
        ['recibos.php?p=resumo','📋 Resumo do dia'], ['relatorios.php','📊 Relatórios'],
        ['erp.php?p=cliente','➕ Cliente novo'], (ws_pode_infra() ? ['radius.php?p=conc','🖧 Concentradores'] : ['servidores.php','🖥️ Painel dos Concentradores']),
        ['backup.php','💾 Backup'], ['chamados.php?p=novo','🛠️ Novo chamado'],
    ];
    $atalhos = $atalhosPadrao;
    if (is_file(WS_CACHE . '/atalhos_painel.json')) { $ja = json_decode((string)@file_get_contents(WS_CACHE . '/atalhos_painel.json'), true); if (is_array($ja) && $ja) $atalhos = $ja; }
    ?>
    <div class="ws-head-row"><h2>⚙️ Configurar atalhos do Painel</h2><a class="ws-btn" href="erp.php?p=dashboard">← Voltar ao Painel</a></div>
    <p class="ws-muted" style="font-size:13px">Edite o título e a URL de cada botão de "Acesso rápido" — pode trocar por qualquer link do sistema (ou externo). Deixe título/URL em branco pra remover um atalho.</p>
    <?php if (isset($_GET['ok'])): ?><div class="ws-alert ok">Salvo.</div><?php endif; ?>
    <form method="post" id="frmAtalhos">
      <input type="hidden" name="acao" value="salvar_atalhos">
      <div id="listaAtalhos">
        <?php foreach ($atalhos as $i => $a): ?>
        <div class="ws-form grid" style="margin-bottom:6px">
          <label class="c2">Título <input name="titulo[]" value="<?= h($a[1]) ?>" placeholder="ex.: 📊 Relatórios"></label>
          <label class="c2">URL <input name="url[]" value="<?= h($a[0]) ?>" placeholder="ex.: relatorios.php"></label>
        </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="ws-btn" onclick="wsNovoAtalho()"><?= ws_icon('mais') ?> Adicionar atalho</button>
      <div style="margin-top:14px"><button class="ws-btn primary">Salvar atalhos</button>
        <a class="ws-btn" style="color:var(--err)" href="erp.php?p=atalhos&restaurar=1" onclick="return confirm('Restaurar os atalhos padrão?')">Restaurar padrão</a></div>
    </form>
    <script>
      function wsNovoAtalho(){
        var d = document.createElement('div'); d.className = 'ws-form grid'; d.style.marginBottom = '6px';
        d.innerHTML = '<label class="c2">Título <input name="titulo[]" placeholder="ex.: 📊 Relatórios"></label>'
                    + '<label class="c2">URL <input name="url[]" placeholder="ex.: relatorios.php"></label>';
        document.getElementById('listaAtalhos').appendChild(d);
      }
    </script>
    <?php
}

/* ================================================================ RENDER */

function ws_header(string $p): void {
  // Classe exclusiva do PAINEL (dashboard) — usada SÓ pela CSS pra tirar o rodapé do modo fixo
  // e deixá-lo no FINAL do conteúdo apenas nesta página, sem tocar em nenhuma outra.
  $bodyClass = $p === 'dashboard' ? ' class="pg-painel"' : '';
  ?>
<!doctype html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>WellSystem</title><?= ws_favicon_tags() ?><link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
</head><body<?= $bodyClass ?>>
<header class="ws-top-wrap">
  <?php
    $navKey = ['dashboard'=>'painel','clientes'=>'clientes','cliente'=>'clientes','adicional'=>'clientes','contrato'=>'clientes',
               'planos'=>'planos','cadastros'=>'cadastros','config'=>'config'][$p] ?? 'painel';
    echo ws_topo_completo($navKey);
  ?>
</header>
<?php if (ws_em_demo()):
  $rest = max(0, (int)($_SESSION['ws_demo_expira'] ?? 0) - time()); $hh = floor($rest/3600); $mm = floor(($rest%3600)/60); ?>
  <div style="background:linear-gradient(90deg,#7f2230,#b23c4d);color:#fff;text-align:center;padding:6px 12px;font-size:13px;font-weight:600;letter-spacing:.2px">
    🧪 AMBIENTE DE DEMONSTRAÇÃO — dados temporários (sandbox). Expira em <b><?= $hh ?>h<?= str_pad((string)$mm,2,'0',STR_PAD_LEFT) ?>min</b>.
  </div>
<?php endif; ?>
<main class="ws-main">
<?php if (isset($_GET['ok'])): ?><div class="ws-alert ok">Salvo com sucesso.</div><?php endif; ?>
<?php if (!empty($_SESSION['ws_flash_ok'])): echo '<div class="ws-alert ok ws-flash">'.h($_SESSION['ws_flash_ok']).'</div>'; unset($_SESSION['ws_flash_ok']); endif; ?>
<?php if (!empty($_SESSION['ws_flash_err'])): echo '<div class="ws-alert err ws-flash">'.h($_SESSION['ws_flash_err']).'</div>'; unset($_SESSION['ws_flash_err']); endif; ?>
<?php if (!empty($_SESSION['ws_flash_warn'])): /* aviso (salvou, mas falta algo) — âmbar, não bloqueia */
  echo '<div class="ws-alert ws-flash" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">'.h($_SESSION['ws_flash_warn']).'</div>'; unset($_SESSION['ws_flash_warn']); endif; ?>
<?php
/* Item 3 (ONU/ONT): 2ª parte do fluxo — quem tentou salvar um ID de ONU/ONT, SN/MAC ou login já
 * usado em OUTRO contrato cai direto aqui (na ficha de quem já tem o equipamento), com este aviso
 * e um botão de liberar. Nada se move sozinho: só ao clicar (com confirmação) o campo é liberado
 * do contrato antigo, e a pessoa volta pra ficha de onde tentou salvar (conflito_volta) pra repetir.
 */
if (($_GET['conflito'] ?? '') === '1' && in_array($_GET['conflito_campo'] ?? '', ['ont_id', 'sn_onu', 'login_pppoe'], true) && (int)($_GET['conflito_ctid'] ?? 0) > 0):
    $rotConflito = ['ont_id' => 'ID da ONU/ONT', 'sn_onu' => 'SN/MAC da ONU', 'login_pppoe' => 'Login PPPoE/IPoE'];
    $campoC = (string)$_GET['conflito_campo']; $ctidC = (int)$_GET['conflito_ctid']; $voltaC = (int)($_GET['conflito_volta'] ?? 0);
?>
  <div class="ws-alert err ws-flash">
    ⚠️ O <b><?= h($rotConflito[$campoC]) ?></b> que tentaram salvar em outro cadastro já está aqui, neste contrato (#<?= $ctidC ?>).
    Se esse equipamento saiu daqui de verdade e foi pra outro cliente, libere o campo abaixo pra poder mover.
    <form method="post" style="margin-top:8px" onsubmit="return confirm('Liberar este campo do contrato #<?= $ctidC ?> e voltar pro cadastro pendente?');">
      <input type="hidden" name="acao" value="liberar_equip_conflito">
      <input type="hidden" name="campo" value="<?= h($campoC) ?>">
      <input type="hidden" name="contrato_id" value="<?= $ctidC ?>">
      <input type="hidden" name="volta_cliente" value="<?= $voltaC ?>">
      <button type="submit" class="ws-btn danger">Liberar e mover</button>
    </form>
  </div>
<?php endif; ?>
<?php }

function ws_footer(string $p = ''): void {
    echo '</main>' . ws_footer_bar($p === 'dashboard') . (function_exists('ws_abrir_ip_js') ? ws_abrir_ip_js() : '') . '<script src="js/wellsystem.js?v=' . ws_ver('js/wellsystem.js') . '"></script>'
       . '<script src="js/ws_confianca.js?v=' . ws_ver('js/ws_confianca.js') . '"></script></body></html>';
}

/**
 * TELA DO PRIMEIRO ACESSO — o cliente define a senha de administrador.
 *
 * Mesma moldura da tela de login (mesmo CSS, mesma logo, mesmo fundo), para não parecer outro
 * sistema no momento mais delicado da instalação. Sem link de "pular": enquanto a senha não for
 * criada, esta é a única tela que o sistema mostra.
 *
 * O texto diz, com todas as letras, que a senha é do cliente e que o fornecedor não a conhece.
 * Isso não é marketing: é a informação de que ele precisa para escolher uma senha de verdade em
 * vez de repetir a que veio no e-mail.
 */
function ws_render_senha_inicial(string $login, string $erro = ''): void {
  $loginBg = function_exists('ws_login_bg_aleatorio') ? ws_login_bg_aleatorio() : '';
  ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title><?= h(function_exists('ws_edicao_nome') ? ws_edicao_nome() : 'WellSystem') ?> — Primeiro acesso</title><?= ws_favicon_tags() ?>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head>
<body class="ws-install" style="background:#1a1013;min-height:100vh;min-height:100dvh">
<?php if ($loginBg): ?>
<div style="position:fixed;inset:0;z-index:0;background-image:url('<?= h(ws_img($loginBg)) ?>');background-position:center;background-size:cover;background-repeat:no-repeat"></div>
<div style="position:fixed;inset:0;z-index:0;background:linear-gradient(180deg,rgba(15,8,11,.45),rgba(15,8,11,.72))"></div>
<?php endif; ?>
<div class="ws-card" style="max-width:420px;position:relative;z-index:1">
  <?= ws_brand_big() ?>
  <h3 style="margin:10px 0 2px">Crie a senha do administrador</h3>
  <p class="ws-muted" style="font-size:12.5px;line-height:1.55;margin:0 0 12px">
    Primeiro acesso deste sistema. A senha que você criar agora é <b>sua</b> —
    ela não foi enviada por ninguém e o fornecedor não tem acesso a ela.
  </p>

  <?php if ($erro): ?><div class="ws-alert err"><?= h($erro) ?></div><?php endif; ?>

  <form method="post" class="ws-form" autocomplete="off">
    <input type="hidden" name="acao" value="definir_senha_inicial">
    <label>Usuário
      <input value="<?= h($login) ?>" disabled style="opacity:.7">
    </label>
    <label>Nova senha
      <input name="senha" type="password" minlength="6" required autofocus autocomplete="new-password">
    </label>
    <label>Repita a senha
      <input name="senha2" type="password" minlength="6" required autocomplete="new-password">
    </label>
    <button class="ws-btn primary">Salvar e entrar</button>
  </form>

  <p class="ws-muted" style="font-size:11.5px;line-height:1.5;margin-top:12px">
    Mínimo de 6 caracteres. <b>Anote em lugar seguro:</b> não há como recuperá-la —
    apenas um novo administrador pode redefinir a senha de outro.
  </p>
</div>
</body></html>
  <?php
}

function ws_render_login(string $erro, string $aviso = ''): void {
  /* TELA DE ENTRADA NO MESMO DESENHO DA CENTRAL DO ASSINANTE (01/10/2026): cartão de vidro escuro, logo em caixa
     branca, campos translúcidos e botão branco. Com foto de fundo: a foto cobre a tela com um véu escuro por cima.
     SEM foto (instalação nova): fundo em degradê da cor da marca — o cartão nunca fica "invisível" no branco. */
  $loginBg = function_exists('ws_login_bg_aleatorio') ? ws_login_bg_aleatorio() : '';
  $prov = [];
  if (is_file(WS_CACHE . '/provedor.json')) { $jp = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true); if (is_array($jp)) $prov = $jp; }
  $pnome = ws_em_demo() ? 'Demonstração' : ((function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: ($prov['razao'] ?? ''))));
  $sist = function_exists('ws_sistema_nome') ? ws_sistema_nome() : 'WellSystem';
  if (function_exists('ws_edicao') && ws_edicao() !== 'completo') $sist = ws_edicao_nome();   // login com o nome da edição
  ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title><?= h($sist) ?> — Entrar</title><?= ws_favicon_tags() ?>
<style>
  :root{--vinho:#9E2A3B}*{box-sizing:border-box}
  html,body{height:100%}
  body{margin:0;font-family:'Segoe UI',system-ui,Arial,sans-serif;min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center;
    padding:16px 16px 48px;position:relative;overflow-x:hidden;color:#fff;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
    <?= $loginBg ? 'background:#1a1013' : 'background:radial-gradient(1200px 800px at 70% -10%,#b23c4d 0%,#7f2230 40%,#2a0f15 100%)' ?>}
  <?php if ($loginBg): ?>
  body::after{content:"";position:fixed;inset:0;z-index:-2;background:url('<?= h(ws_img($loginBg)) ?>') center center / cover no-repeat}
  <?php endif; ?>
  body::before{content:"";position:fixed;inset:0;z-index:-1;background:<?= $loginBg
      ? 'linear-gradient(180deg,rgba(20,10,14,.32),rgba(20,10,14,.55))'
      : 'radial-gradient(900px 500px at 15% 110%,rgba(0,0,0,.35),transparent 60%),radial-gradient(700px 400px at 90% 0,rgba(255,255,255,.08),transparent 55%)' ?>}
  .card{position:relative;z-index:1;background:rgba(20,10,14,.62);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);
    border:1px solid rgba(255,255,255,.16);border-radius:20px;padding:34px 30px 30px;max-width:410px;width:100%;
    box-shadow:0 30px 70px -25px rgba(0,0,0,.75);text-align:center}
  .card .logo{display:flex;justify-content:center;margin-bottom:4px}
  .card .logo img{max-height:64px;max-width:100%;object-fit:contain;background:#fff;border-radius:12px;padding:6px}
  .card .logo *{color:#fff}
  .card h1{font-size:19px;margin:14px 0 2px;letter-spacing:.5px;font-weight:800}
  .card .sub{opacity:.8;font-size:13px;margin:0 0 22px}
  .card label{display:block;text-align:left;font-size:12.5px;opacity:.92;margin:0 0 14px}
  .card input{width:100%;margin-top:5px;padding:13px 14px;border:1px solid rgba(255,255,255,.22);border-radius:11px;
    background:rgba(255,255,255,.12);color:#fff;font-size:15px;outline:none;transition:.15s}
  .card input::placeholder{color:rgba(255,255,255,.55)}
  .card label.lembrar{display:flex;align-items:center;gap:10px;margin:2px 0 12px;font-size:13px;opacity:.95;cursor:pointer;user-select:none}
  .card label.lembrar input{position:absolute!important;opacity:0!important;width:0!important;height:0!important;margin:0!important;padding:0!important;border:0!important}
  .card label.lembrar .sw{flex:0 0 auto;width:40px;height:22px;border-radius:22px;background:rgba(255,255,255,.28);position:relative;transition:.15s}
  .card label.lembrar .sw:after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.15s;box-shadow:0 1px 3px rgba(0,0,0,.4)}
  .card label.lembrar input:checked+.sw{background:#16a34a}
  .card label.lembrar input:checked+.sw:after{left:21px}
  .card label.lembrar input:focus-visible+.sw{outline:2px solid #fff;outline-offset:2px}
  .card input:focus{border-color:#fff;background:rgba(255,255,255,.18)}
  .card input:-webkit-autofill{-webkit-text-fill-color:#fff;-webkit-box-shadow:0 0 0 40px rgba(60,25,32,.95) inset;caret-color:#fff}
  .card button{width:100%;margin-top:6px;padding:14px;border:0;border-radius:11px;background:#fff;color:var(--vinho);
    font-weight:800;font-size:15px;letter-spacing:.4px;cursor:pointer;transition:.15s;box-shadow:0 8px 20px -8px rgba(0,0,0,.5)}
  .card button:hover{transform:translateY(-2px)}
  .card button:disabled{opacity:.7;transform:none;cursor:wait}
  .msg{border-radius:10px;font-size:13px;line-height:1.45;margin-bottom:16px;padding:10px 12px;text-align:left}
  .msg.err{background:rgba(220,38,38,.25);border:1px solid rgba(255,120,120,.5);color:#ffdede}
  .msg.ok{background:rgba(22,163,74,.22);border:1px solid rgba(120,220,150,.45);color:#dcfce7}
  .rod{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);width:max-content;max-width:calc(100% - 24px);text-align:center;color:#fff;font-size:12.5px;z-index:1;padding:6px 14px;border-radius:999px;background:rgba(15,8,11,.55);border:1px solid rgba(255,255,255,.14);text-shadow:0 1px 2px rgba(0,0,0,.6);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
  @media(max-width:420px){.card{padding:28px 20px 24px;border-radius:16px}}
</style></head><body>
<div class="card">
  <div class="logo"><?= ws_brand_big() ?></div>
  <h1>ACESSE O SISTEMA</h1>
  <p class="sub"><?= h($pnome !== '' ? $pnome : $sist) ?></p>
  <?php if (ws_em_demo()): ?>
  <div class="msg ok">🧪 <b>Modo demonstração.</b> Para <b>criar sua conta de teste</b>, entre com <b>admin / admin123</b>.<br>Já tem conta? Entre com <b>seu login pessoal</b>.</div>
  <?php endif; ?>
  <?php if ($aviso): ?><div class="msg ok"><?= h($aviso) ?></div><?php endif; ?>
  <?php if ($erro): ?><div class="msg err"><?= h($erro) ?></div><?php endif; ?>
  <form method="post" onsubmit="var b=this.querySelector('button');b.disabled=true;b.textContent='ENTRANDO…'">
    <input type="hidden" name="acao" value="login">
    <label>Login<input name="login" autofocus autocomplete="username" placeholder="seu login"></label>
    <label>Senha<input name="senha" type="password" autocomplete="current-password" placeholder="sua senha"></label>
    <label class="lembrar"><input type="checkbox" id="wsLembrar"><span class="sw"></span>Lembrar dados</label>
    <button>ENTRAR</button>
  </form>
</div>
<script>
/* LEMBRAR DADOS (17/10/2026): guarda só o LOGIN neste navegador (a senha fica com o gerenciador de senhas do próprio navegador — autocomplete=current-password; nunca é gravada pelo sistema). */
(function(){try{var c=document.getElementById('wsLembrar'),l=document.querySelector('input[name=login]');if(!c||!l)return;var v=localStorage.getItem('ws_lembrar_login');if(v){l.value=v;c.checked=true;var s=document.querySelector('input[name=senha]');if(s)s.focus();}
 c.form.addEventListener('submit',function(){try{if(c.checked&&l.value.trim()!=='')localStorage.setItem('ws_lembrar_login',l.value.trim());else localStorage.removeItem('ws_lembrar_login');}catch(e){}});}catch(e){}})();
</script>
<div class="rod"><?= h($pnome !== '' ? $pnome . ' · ' : '') ?>Sistema <b><?= h((function_exists('ws_edicao') && ws_edicao() !== 'completo') || stripos($sist, 'ERP') !== false ? $sist : $sist . '-ERP') ?></b></div>
</body></html>
<?php }

/** DEMO — tela para o visitante CRIAR SUA CONTA (login + senha próprios, tempo próprio). */
function ws_render_demo_criar(string $erro = ''): void {
  $horas = function_exists('ws_demo_horas') ? ws_demo_horas() : 24; ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Crie sua conta — Demonstração</title><?= ws_favicon_tags() ?>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head>
<body class="ws-install"><div class="ws-card" style="max-width:420px;margin:10vh auto">
<?= ws_brand_big() ?>
<h3 style="text-align:center;margin:8px 0 2px">🧪 Criar sua conta de teste</h3>
<p class="ws-muted" style="text-align:center;font-size:13px;margin:0 0 16px">Crie um login só seu para testar a demonstração de forma independente. Sua conta vale por <b><?= (int)$horas ?>h</b>.</p>
<?php if ($erro): ?><div class="ws-alert err"><?= h($erro) ?></div><?php endif; ?>
<form method="post" class="ws-form">
  <input type="hidden" name="acao" value="demo_criar_conta">
  <label>Seu nome <input name="nome" required autofocus placeholder="Ex.: João Silva"></label>
  <label>Escolha um login <input name="novo_login" required placeholder="ex.: joao (letras/números)"></label>
  <label>Crie uma senha (mín. 4) <input name="nova_senha" type="password" required></label>
  <button class="ws-btn primary">Criar conta e entrar</button>
</form>
<p class="ws-muted" style="text-align:center;font-size:11.5px;margin-top:12px">Já tem conta? <a href="erp.php?demo_login=1">Entrar com meu login</a></p>
</div></body></html>
<?php }

function ws_render_2fa(string $erro): void { ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title><?= h(function_exists('ws_edicao_nome') ? ws_edicao_nome() : 'WellSystem') ?> — Verificação</title><?= ws_favicon_tags() ?>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head>
<body class="ws-install"><div class="ws-card" style="max-width:380px;margin:12vh auto">
<?= ws_brand_big() ?>
<p class="ws-muted">Verificação em 2 etapas</p>
<?php if ($erro): ?><div class="ws-alert err"><?= h($erro) ?></div><?php endif; ?>
<form method="post" class="ws-form">
  <input type="hidden" name="acao" value="login_2fa">
  <label>Código do app (6 dígitos) <input name="codigo" inputmode="numeric" autocomplete="one-time-code" autofocus placeholder="000000"></label>
  <button class="ws-btn primary">Verificar</button>
  <a class="ws-btn" href="erp.php?sair=1">Cancelar</a>
</form>
<p class="ws-muted" style="font-size:12px;margin-top:10px">Perdeu o app? Use um dos seus <b>códigos de recuperação</b> no lugar do código.</p>
</div></body></html>
<?php }

/* --------- Dashboard --------- */
/** Calcula os cards do Painel (Total/Online/Adicional/... + atendimentos). Extraído de
 *  ws_view_dashboard() pra ser usado tanto no render inicial quanto no sincronizador (AJAX) —
 *  as DUAS vias caem exatamente na mesma conta, então os números nunca divergem entre si. */
function ws_dashboard_cards_calc(PDO $db, $ramalAtivo): array {
    $rw = $ramalAtivo ? " AND (ramal_id=" . (int)$ramalAtivo['id'] . " OR ramal_id IS NULL)" : "";
    $q = fn($s) => (float)$db->query($s)->fetchColumn();

    $cards = $db->query(
        "SELECT COALESCE(SUM(status<>'cancelado'),0)                          total,
                COALESCE(SUM(titular_id IS NOT NULL AND status<>'cancelado'),0) adic,
                COALESCE(SUM(status='ativo'),0)                               ativo,
                COALESCE(SUM(status='observacao'),0)                          obs,
                COALESCE(SUM(status='bloqueado'),0)                           bloq
         FROM ws_cliente WHERE 1=1$rw"
    )->fetch() ?: [];
    $total = (int)($cards['total'] ?? 0);
    $adic  = (int)($cards['adic']  ?? 0);
    $ativo = (int)($cards['ativo'] ?? 0);
    $obs   = (int)($cards['obs']   ?? 0);
    $bloq  = (int)($cards['bloq']  ?? 0);
    $ctr   = (int)$q("SELECT COUNT(*) FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE ct.status='ativo'" . ($ramalAtivo ? " AND c.ramal_id=" . (int)$ramalAtivo['id'] : ""));
    $cacheSess = function_exists('ws_sessoes_cache') ? ws_sessoes_cache() : null;
    if ($cacheSess !== null && $ramalAtivo) {
        if (isset($cacheSess['por_ramal'])) {
            $rk = 'r' . (int)$ramalAtivo['id'];
            $online      = (int)($cacheSess['por_ramal'][$rk] ?? 0);
            $onlineContr = (int)($cacheSess['contratos_online_por_ramal'][$rk] ?? 0);
        } else { $cacheSess = null; }
    }
    if ($cacheSess !== null && !$ramalAtivo) {
        $online      = (int)($cacheSess['total'] ?? $cacheSess['contratos_online']);
        $onlineContr = (int)$cacheSess['contratos_online'];
    } elseif ($cacheSess === null) {
        $online = (int)$q("SELECT COUNT(DISTINCT ct.id) FROM ws_contrato ct
                           JOIN ws_cliente c ON c.id=ct.cliente_id
                           JOIN radacct r ON (r.username=ct.login_pppoe OR r.username=ct.login_ipoe) AND r.acctstoptime IS NULL" . ($ramalAtivo ? " WHERE c.ramal_id=" . (int)$ramalAtivo['id'] : ""));
        $onlineContr = $online;
    }
    // Offline = mesma regra do filtro da lista (ws_clientes_offline_count, radius_lib.php).
    $offline = function_exists('ws_clientes_offline_count') ? ws_clientes_offline_count($db, $ramalAtivo) : max(0, $ctr - $onlineContr);
    $atraso = (int)$q("SELECT COUNT(DISTINCT f.cliente_id) FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id
                       WHERE f.status IN('aberto','vencido','processando') AND f.vencimento < CURDATE() AND c.status NOT IN('cancelado','desativado')" . ($ramalAtivo ? " AND c.ramal_id=" . (int)$ramalAtivo['id'] : ""));
    $semTit = (int)$q("SELECT COUNT(DISTINCT c.id) FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id=c.id AND ct.status='ativo'
                       WHERE c.status<>'cancelado'$rw AND NOT EXISTS(SELECT 1 FROM ws_fatura f WHERE f.contrato_id=ct.id AND f.status IN('aberto','vencido','processando'))");
    $conf   = (int)$q("SELECT COUNT(*) FROM ws_cliente c
                       WHERE (EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id
                                     AND ct.confianca_ate IS NOT NULL AND ct.confianca_ate>NOW())
                              OR c.status='observacao'" . ws_obs_auto_sql('c') . ")"
                     . ($ramalAtivo ? " AND c.ramal_id=" . (int)$ramalAtivo['id'] : ""));
    /* CARDS DE ATENDIMENTO ZERAM NA VIRADA DO MÊS (pedido do provedor): Chamados, Chamados em
       aberto e Instalações em aberto contam o que foi aberto no MÊS CORRENTE (desde o dia 1) MAIS o que
       ficou pendente de meses anteriores (aberto/em andamento/agendado) — não feito passa para o mês atual (01/10/2026).
       A lista que cada card abre recebe &mes=AAAA-MM (chamados.php), então número e lista batem.
       Antes o card "Chamados" usava status<>'fechado' — 'fechado' nem existe no ENUM, então
       contava TODOS os chamados da história, inclusive resolvidos e cancelados. */
    $mesIni = "(ch.criado_em >= DATE_FORMAT(CURDATE(),'%Y-%m-01') OR ch.status IN('aberto','em_andamento','agendado'))"; // pendente de mês anterior continua contando no mês corrente
    $chamados = 0; try { $chamados = (int)$q("SELECT COUNT(*) FROM ws_chamado ch JOIN ws_cliente c ON c.id=ch.cliente_id WHERE $mesIni" . ($ramalAtivo ? " AND c.ramal_id=" . (int)$ramalAtivo['id'] : "")); } catch (Throwable $e) {}
    if ($online === 0 && !function_exists('ws_clientes_offline_count')) $offline = $ativo;
    $chAbertos = 0; $instAbertas = 0;
    try { $chAbertos = (int)$q("SELECT COUNT(*) FROM ws_chamado ch JOIN ws_cliente c ON c.id=ch.cliente_id WHERE $mesIni AND ch.status IN('aberto','em_andamento','agendado') AND (ch.tipo<>'instalacao' OR ch.tipo IS NULL)" . ($ramalAtivo ? " AND c.ramal_id=".(int)$ramalAtivo['id'] : "")); } catch (Throwable $e) {}
    try { $instAbertas = (int)$q("SELECT COUNT(*) FROM ws_chamado ch JOIN ws_cliente c ON c.id=ch.cliente_id WHERE $mesIni AND ch.status IN('aberto','em_andamento','agendado') AND ch.tipo='instalacao'" . ($ramalAtivo ? " AND c.ramal_id=".(int)$ramalAtivo['id'] : "")); } catch (Throwable $e) {}
    return compact('total','online','adic','ativo','conf','bloq','atraso','offline','semTit','chamados','chAbertos','instAbertas');
}

// Sincronizador dos cards do Painel: mesma conta de ws_dashboard_cards_calc, servida como JSON pro
// JS reler a cada X segundos e atualizar só os números/percentuais na tela (sem recarregar a página).
if (($_GET['acao'] ?? '') === 'painel_cards') {
    header('Content-Type: application/json; charset=utf-8');
    $d = ws_dashboard_cards_calc($db, ws_ramal_atual());
    echo json_encode(['ok' => true] + $d, JSON_UNESCAPED_UNICODE); exit;
}

function ws_view_dashboard(PDO $db): void {
    // Atalho de consulta de um número só. ERA definido só em ws_dashboard_cards_calc(): quando os cards
    // foram extraídos para lá, o resto do Painel (gráficos, chamados, alertas) seguiu chamando $q e dava
    // "Value of type null is not callable" — erro 500, tela em branco.
    $q = fn($s) => (float)$db->query($s)->fetchColumn();
    // Filtro de cidade/ramal (mesmo seletor do topo): quando um ramal está selecionado, os cards
    // mostram só a base daquela cidade/ramal; em "Todas as cidades" volta a mostrar tudo junto.
    $ramalAtivo = ws_ramal_atual();
    $d = ws_dashboard_cards_calc($db, $ramalAtivo);
    ['total' => $total, 'online' => $online, 'adic' => $adic, 'ativo' => $ativo, 'conf' => $conf,
     'bloq' => $bloq, 'atraso' => $atraso, 'offline' => $offline, 'semTit' => $semTit,
     'chamados' => $chamados, 'chAbertos' => $chAbertos, 'instAbertas' => $instAbertas] = $d;

    // Obs.: o seletor de "Aparência do sistema" (cor) morava aqui, só no Painel — agora fica no
    // topo (cabeçalho), ao lado do botão claro/escuro, igual em TODAS as páginas.
    echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">'
       . '<h2 style="margin:0">📊 Painel <span id="wsOlhoPainel" class="ws-olho" onclick="wsTogglePainel()" title="Mostrar/ocultar valores (passe o mouse no card para ver o número)" style="cursor:pointer;opacity:.9;color:var(--text);filter:grayscale(1) brightness(.55);font-size:22px;vertical-align:middle;user-select:none;margin-left:8px">👁</span></h2><script>var WS_PAINEL_VISIVEL=false;document.body.classList.add("ws-ocultar-valores");</script><style>/* Valores ocultos: o número do card aparece ao passar o mouse; fixo só pelo olho. */body.ws-ocultar-valores .ws-mk:hover .ws-mk-num,body.ws-ocultar-valores .ws-mk:focus .ws-mk-num{font-size:22px!important}body.ws-ocultar-valores .ws-mk:hover .ws-mk-num::after,body.ws-ocultar-valores .ws-mk:focus .ws-mk-num::after{content:none!important}</style><script>function wsTogglePainel(){WS_PAINEL_VISIVEL=!WS_PAINEL_VISIVEL;document.body.classList.toggle("ws-ocultar-valores",!WS_PAINEL_VISIVEL);var olho=document.getElementById("wsOlhoPainel");if(olho){olho.style.opacity=WS_PAINEL_VISIVEL?"1":".9";olho.classList.toggle("ws-olho-off",WS_PAINEL_VISIVEL);olho.textContent=WS_PAINEL_VISIVEL?"🙈":"👁";}}</script>'
       . '</div><div class="ws-mkcards" id="wsPainelCards" data-sync-url="erp.php?acao=painel_cards" data-sync-seg="20">';
    foreach ([
        ['Total','total',$total,'azul','erp.php?p=clientes'],
        ['Online','online',$online,'verde','erp.php?p=clientes&status=online'],
        ['Adicional','adic',$adic,'roxo','erp.php?p=clientes&status=adicional'],
        ['Livres','ativo',$ativo,'ciano','erp.php?p=clientes&status=ativo'],
        ['Observação','conf',$conf,'amarelo','erp.php?p=clientes&status=observacao'],
        ['Bloqueado','bloq',$bloq,'vermelho','erp.php?p=clientes&status=bloqueado'],
        ['Atraso','atraso',$atraso,'laranja','erp.php?p=clientes&status=atraso'],
        ['Offline','offline',$offline,'preto','erp.php?p=clientes&status=offline'],
        ['Sem título','semTit',$semTit,'cinza','erp.php?p=clientes&status=semtitulo'],
        ['Chamados','chamados',$chamados,'roxo','chamados.php?p=lista&mes=' . date('Y-m')],
    ] as [$t,$key,$v,$cor,$lnk]) {
        $pct = $total > 0 ? round($v / $total * 100, 2) : 0;
        echo "<a class='ws-mk ws-mk-$cor' href='".h($lnk)."' data-mk-key='$key' data-mk-total-key='total'><span class='ws-mk-lbl'>".h($t)."</span>"
           . "<span class='ws-mk-num'>".number_format($v,0,',','.')."</span>"
           . "<span class='ws-mk-pct'>$pct%</span></a>";
    }
    echo '</div>';
    // Sincronizador dos cards: data-sync-url + data-sync-seg no container (ver wellsystem.js).
    // ---- Atendimentos (chamados/instalações em aberto) — dados reais, cada um clicável ----
    echo '<div class="ws-cards" style="margin:14px 0">'
       . '<a class="ws-stat" href="chamados.php?p=lista&status=aberto&tipo=!instalacao&mes=' . date('Y-m') . '" title="Abertos neste mês + pendentes de meses anteriores"><span>'.$chAbertos.'</span><label>Chamados em aberto (mês)</label></a>'
       . '<a class="ws-stat" href="chamados.php?p=lista&tipo=instalacao&status=aberto&mes=' . date('Y-m') . '" title="Abertas neste mês + pendentes de meses anteriores"><span>'.$instAbertas.'</span><label>Instalações em aberto (mês)</label></a>'
       . ws_cards_clientes_mes()   // (16/10/2026) ativados / desativados no mês
       . ws_card_central()
       . '</div>';

    // ---- Acesso rápido — EDITÁVEL (Configurar atalhos) ----
    $atalhosPadrao = [
        ['erp.php?p=config&t=operadores','usuario Criar usuários'], ['radius.php?p=usuarios','radio Radius'],
        ['recibos.php?p=resumo','resumo Resumo do dia'], ['relatorios.php','grafico Relatórios'],
        ['erp.php?p=cliente','mais Cliente novo'], ['radius.php?p=conc','rede Concentradores'],
        ['backup.php','salvar Backup'], ['chamados.php?p=novo','chamado Novo chamado'],
    ];
    $atalhos = $atalhosPadrao;
    if (is_file(WS_CACHE . '/atalhos_painel.json')) { $ja = json_decode((string)@file_get_contents(WS_CACHE . '/atalhos_painel.json'), true); if (is_array($ja) && $ja) $atalhos = $ja; }
    echo '<div class="ws-head-row" style="margin:18px 0 8px"><h3 class="ws-muted" style="font-size:12px;text-transform:uppercase;letter-spacing:.4px">Acesso rápido</h3></div>';
    echo '<div class="ws-search ws-cli-filtros">';
    // "Configurar atalhos" agora é o 1º botão da própria linha de atalhos (abaixo de "Acesso rápido").
    echo '<a class="ws-btn primary" href="erp.php?p=atalhos">' . ws_icon('engrenagem') . ' Configurar</a>';
    foreach ($atalhos as $at) {
        // Atalhos salvos ANTES desta troca de ícones ainda trazem o emoji antigo (ex.: "👤 Criar
        // usuários") — extrai só o texto pra continuar usando o ícone SVG moderno normalmente,
        // e se for um atalho custom sem "palavra-chave de ícone" reconhecida, mostra só o texto.
        $rotulo = $at[1];
        $partes = explode(' ', $rotulo, 2);
        $chaveIco = $partes[0];
        $svgsConhecidos = ['usuario','radio','resumo','grafico','mais','rede','salvar','chamado'];
        if (in_array($chaveIco, $svgsConhecidos, true) && isset($partes[1])) {
            echo '<a class="ws-btn" href="' . h($at[0]) . '">' . ws_icon($chaveIco) . ' ' . h($partes[1]) . '</a>';
        } else {
            echo '<a class="ws-btn" href="' . h($at[0]) . '">' . h($rotulo) . '</a>';
        }
    }
    echo '</div>';

    // ---- Log do sistema (últimas atividades — timeline geral) — MESMAS funções do Relatórios ›
    //      Log/Auditoria: ícone+cor por ação (ws_evento_estilo), linha clicável (detalhe em nova
    //      janela), excluir marcados, baixar CSV, seletor de itens por página e paginação. ----
    $lppOpts = [10, 20, 50, 100, 0];   // abre com 10 (17/10/2026); "Exibir" mostra mais
    $lpp = isset($_GET['lpp']) ? (int)$_GET['lpp'] : 10;
    if (!in_array($lpp, $lppOpts, true)) $lpp = 10;
    $lpg = max(1, (int)($_GET['lpg'] ?? 1));
    $logTotal = 0; try { $logTotal = (int)$db->query("SELECT COUNT(*) FROM ws_evento")->fetchColumn(); } catch (Throwable $e) {}
    $lLim = $lpp > 0 ? " LIMIT $lpp OFFSET " . (($lpg-1)*$lpp) : "";
    $logs = [];
    try { $logs = $db->query("SELECT e.*, c.nome cliente, u.nome usuario FROM ws_evento e
                              LEFT JOIN ws_cliente c ON c.id=e.cliente_id LEFT JOIN ws_usuario u ON u.id=e.usuario_id
                              ORDER BY e.id DESC$lLim")->fetchAll(); } catch (Throwable $e) {}
    $logPaginas = $lpp > 0 ? (int)max(1, ceil($logTotal/$lpp)) : 1;
    if ($logs || $logTotal) {
        echo '<div class="ws-panel" id="log" style="margin-top:14px">'
           . '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><b>Log do sistema</b>'
           . '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">'
           . '<a class="ws-btn" style="font-size:12px;padding:4px 10px" href="relatorios.php?p=log_csv" title="Baixar tudo em CSV">⬇️ CSV</a>'
           . '<span style="font-size:12px;color:var(--muted)">Exibir <select onchange="location.href=\'erp.php?p=dashboard&lpp=\'+this.value+\'#log\'" style="padding:3px 6px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--text);font-size:12px">';
        foreach ($lppOpts as $o) { $lbl = $o === 0 ? 'Todos' : $o; echo '<option value="'.$o.'" '.($lpp===$o?'selected':'').'>'.$lbl.'</option>'; }
        echo '</select></span></div></div>';
        echo '<form method="post" action="relatorios.php?p=log_del" onsubmit="return confirm(\'Excluir os eventos marcados?\')">';
        echo '<div style="overflow-x:auto"><table class="ws-table" style="margin-top:8px"><thead><tr>'
           . '<th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"></th>'
           . '<th></th><th style="text-align:center">Atividade</th><th style="text-align:center">Cliente</th><th>Usuário</th><th>Data</th><th>Hora</th><th style="text-align:center">Ações</th></tr></thead><tbody>';
        foreach ($logs as $lg) {
            $tipo = strtolower($lg['tipo'] ?? '');
            [$icon, $cor] = ws_evento_estilo($tipo);
            $texto = h($lg['texto'] ?? $lg['tipo'] ?? '');
            // --- Destaque: boleto pago em mês errado ---
            $highlight = ''; $highlightTitle = '';
            if (strpos($tipo, 'pagamento') !== false || $tipo === 'boleto') {
                if (preg_match('/competencia[:\s]+(\d{4}-\d{2})/i', $lg['texto'] ?? '', $mc) &&
                    preg_match('/(\d{4}-\d{2}-\d{2})/', $lg['criado_em'] ?? '', $md)) {
                    if ($mc[1] !== substr($md[1],0,7)) {
                        $highlight = 'background:rgba(220,38,38,.13);border-left:3px solid #dc2626;';
                        $highlightTitle = 'title="⚠️ Boleto pago em mês diferente da competência!"';
                        $texto = '⚠️ <b style="color:#dc2626">MÊS ERRADO</b> — ' . $texto;
                    }
                }
            }
            $det = 'relatorios.php?p=log_detalhe&id=' . (int)$lg['id'];
            echo '<tr style="' . $highlight . 'cursor:pointer" ' . $highlightTitle . ' onclick="window.open(\'' . $det . '\',\'_blank\',\'width=650,height=550,top=150,left=200\')" title="Clique para abrir os detalhes">'
               . '<td onclick="event.stopPropagation()"><input type="checkbox" class="ws-chk-item" name="ids[]" value="' . (int)$lg['id'] . '"></td>'
               . '<td style="font-size:16px;text-align:center;color:' . $cor . '">' . $icon . '</td>'
               . '<td style="text-align:center;white-space:normal;min-width:260px">' . $texto . '</td>'
               . '<td style="text-align:center;white-space:normal;min-width:140px">' . h($lg['cliente'] ?? '—') . '</td>'
               . '<td style="color:' . $cor . '">' . h($lg['usuario'] ?? '—') . '</td>'
               . '<td style="white-space:nowrap">' . h(date('d/m/y', strtotime($lg['criado_em'] ?? 'now'))) . '</td>'
               . '<td style="white-space:nowrap">' . h(date('H:i\h', strtotime($lg['criado_em'] ?? 'now'))) . '</td>'
               . '<td onclick="event.stopPropagation()" style="text-align:center;white-space:nowrap">'
               . '<a class="ws-btn" style="font-size:11px;padding:3px 9px" href="' . $det . '" onclick="window.open(this.href,\'_blank\',\'width=650,height=550,top=150,left=200\');return false;" title="Ver, imprimir ou baixar este evento">🔎 Ver</a></td></tr>';
        }
        if (!$logs) echo '<tr><td colspan="8" class="ws-muted" style="text-align:center">Sem eventos ainda.</td></tr>';
        echo '</tbody></table></div>';
        echo '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-top:8px">'
           . '<button class="ws-btn danger" style="font-size:12px;padding:5px 10px" type="submit">🗑️ Excluir marcados</button>'
           . '<a class="ws-btn" href="relatorios.php?p=log">Ver tudo →</a></div>';
        echo '</form>';
        if ($logPaginas > 1) {
            echo '<div style="display:flex;gap:6px;justify-content:center;align-items:center;margin-top:10px;flex-wrap:wrap">';
            if ($lpg > 1) echo '<a class="ws-btn" style="font-size:12px;padding:4px 10px" href="erp.php?p=dashboard&lpp='.$lpp.'&lpg='.($lpg-1).'#log">‹ Anterior</a>';
            echo '<span style="font-size:12px;color:var(--muted)">Página '.$lpg.' de '.$logPaginas.'</span>';
            if ($lpg < $logPaginas) echo '<a class="ws-btn" style="font-size:12px;padding:4px 10px" href="erp.php?p=dashboard&lpp='.$lpp.'&lpg='.($lpg+1).'#log">Próxima ›</a>';
            echo '</div>';
        }
        echo '</div>';
    }

    // ================= DASHBOARD MODERNO (GRÁFICOS & INDICADORES) ================= //
    if (ws_ver_valores()) {   // (16/10/2026) o dashboard de gráficos (faturamento, saldo, ticket, planos…) é do nível 3 em diante; atendimento (1 e 2) vê só de Chamados para baixo
    echo '<div class="ws-head-row" style="margin:22px 0 8px"><h3 class="ws-muted" style="font-size:12px;text-transform:uppercase;letter-spacing:.5px;display:flex;align-items:center;gap:6px">📊 Dashboard Operacional & Financeiro</h3></div>';
    ws_dashboard_graficos($db);   // (16/10/2026) gráficos do dashboard num só lugar (charts.php)
    }

    // ---- Chamados abertos (prévia) ----
    $chPrev = [];
    try { $chPrev = $db->query("SELECT ch.id, ch.titulo, ch.prioridade, ch.status, c.nome FROM ws_chamado ch
                                JOIN ws_cliente c ON c.id=ch.cliente_id WHERE ch.status IN('aberto','em_andamento','agendado') AND (ch.tipo<>'instalacao' OR ch.tipo IS NULL)
                                ORDER BY FIELD(ch.prioridade,'urgente','alta','normal','baixa'), ch.id DESC LIMIT 8")->fetchAll(); } catch (Throwable $e) {}
    if ($chPrev) {
        echo '<div class="ws-panel" style="margin-top:14px"><b>Chamados abertos</b>'
           . '<table class="ws-table" style="margin-top:8px"><thead><tr><th>#</th><th>Cliente</th><th>Título</th><th>Prioridade</th><th>Status</th></tr></thead><tbody>';
        foreach ($chPrev as $c) { $prioCor = ['baixa'=>'inativo','normal'=>'ativo','alta'=>'suspenso','urgente'=>'bloqueado'][$c['prioridade']] ?? 'inativo';
          echo '<tr><td><a href="chamados.php?p=ver&id='.$c['id'].'">#'.$c['id'].'</a></td><td>'.h($c['nome']).'</td><td>'.h($c['titulo']).'</td>'
             . '<td><span class="ws-tag '.$prioCor.'">'.h($c['prioridade']).'</span></td><td>'.h(str_replace('_',' ',$c['status'])).'</td></tr>'; }
        echo '</tbody></table><p style="margin-top:8px"><a class="ws-btn" href="chamados.php?p=lista&status=aberto">Ver todos →</a></p></div>';
    }

    // ---- Instalações abertas (prévia) — mesmo cadastro de chamados, tipo=instalacao ----
    $instPrev = [];
    try { $instPrev = $db->query("SELECT ch.id, ch.titulo, ch.status, ch.agendado_para, c.nome FROM ws_chamado ch
                                  JOIN ws_cliente c ON c.id=ch.cliente_id WHERE ch.tipo='instalacao' AND ch.status IN('aberto','em_andamento','agendado')
                                  ORDER BY ch.id DESC LIMIT 8")->fetchAll(); } catch (Throwable $e) {}
    if ($instPrev) {
        echo '<div class="ws-panel" style="margin-top:14px"><b>Instalações abertas</b>'
           . '<table class="ws-table" style="margin-top:8px"><thead><tr><th>#</th><th>Cliente</th><th>Título</th><th>Agenda</th><th>Status</th></tr></thead><tbody>';
        foreach ($instPrev as $c) echo '<tr><td><a href="chamados.php?p=ver&id='.$c['id'].'">#'.$c['id'].'</a></td><td>'.h($c['nome']).'</td><td>'.h($c['titulo']).'</td>'
           . '<td>'.($c['agendado_para']?h(date('d/m H:i\h',strtotime($c['agendado_para']))):'—').'</td><td>'.h(str_replace('_',' ',$c['status'])).'</td></tr>';
        echo '</tbody></table><p style="margin-top:8px"><a class="ws-btn" href="chamados.php?p=lista&tipo=instalacao&status=aberto">Ver todas →</a></p></div>';
    }

    // ================= CHAMADOS ================= //
    $temChamado = false; try { $db->query("SELECT 1 FROM ws_chamado LIMIT 1"); $temChamado = true; } catch (Throwable $e) {}
    if ($temChamado) {
        echo '<div class="ws-head-row" style="margin:22px 0 4px"><h3 style="text-transform:uppercase;font-size:13px;letter-spacing:.4px" class="ws-muted">Chamados</h3></div>';

        // Por assunto (tipo) — todos x só os abertos
        $porAssunto = $db->query("SELECT COALESCE(tipo,'outro') t, COUNT(*) n FROM ws_chamado GROUP BY t")->fetchAll(PDO::FETCH_KEY_PAIR);
        $porAssuntoAberto = $db->query("SELECT COALESCE(tipo,'outro') t, COUNT(*) n FROM ws_chamado WHERE status IN('aberto','em_andamento','agendado') GROUP BY t")->fetchAll(PDO::FETCH_KEY_PAIR);
        // Por técnico — todos x só os abertos
        $porTecnico = $db->query("SELECT COALESCE(tc.nome,u.nome,'Sem técnico') t, COUNT(*) n FROM ws_chamado ch LEFT JOIN ws_usuario u ON u.id=ch.tecnico_id LEFT JOIN ws_tecnico tc ON tc.id=ch.tecnico_cad_id GROUP BY t")->fetchAll(PDO::FETCH_KEY_PAIR);
        $porTecnicoAberto = $db->query("SELECT COALESCE(tc.nome,u.nome,'Sem técnico') t, COUNT(*) n FROM ws_chamado ch LEFT JOIN ws_usuario u ON u.id=ch.tecnico_id LEFT JOIN ws_tecnico tc ON tc.id=ch.tecnico_cad_id WHERE ch.status IN('aberto','em_andamento','agendado') GROUP BY t")->fetchAll(PDO::FETCH_KEY_PAIR);
        $chTotalAbertos = (int)$q("SELECT COUNT(*) FROM ws_chamado WHERE status IN('aberto','em_andamento','agendado')");
        $chTotalFechados = (int)$q("SELECT COUNT(*) FROM ws_chamado WHERE status IN('resolvido','cancelado','fechado')");

        // Widget de SATISFAÇÃO (avaliações que os clientes dão pelo portal).
        $satM = null; $satN = 0; $topTec = '';
        try {
            $srr = $db->query("SELECT AVG(avaliacao) m, COUNT(avaliacao) n FROM ws_chamado WHERE avaliacao IS NOT NULL")->fetch();
            if ($srr) { $satM = $srr['m'] !== null ? round((float)$srr['m'], 2) : null; $satN = (int)$srr['n']; }
            if ($satN > 0) { $tt = $db->query("SELECT COALESCE(tc.nome,u.nome,'Sem técnico') nome, ROUND(AVG(ch.avaliacao),2) m FROM ws_chamado ch LEFT JOIN ws_usuario u ON u.id=ch.tecnico_id LEFT JOIN ws_tecnico tc ON tc.id=ch.tecnico_cad_id WHERE ch.avaliacao IS NOT NULL GROUP BY nome ORDER BY m DESC, COUNT(ch.avaliacao) DESC LIMIT 1")->fetch(); $topTec = $tt ? ($tt['nome'] . ' (' . number_format((float)$tt['m'], 2, ',', '.') . '★)') : ''; }
        } catch (Throwable $e) {}
        if ($satN > 0) {
            $nr = (int)round($satM); $estrelas = str_repeat('★', $nr) . str_repeat('☆', 5 - $nr);
            echo '<a class="ws-chart" href="chamados.php?p=lista" style="display:block;text-decoration:none;color:inherit;margin-bottom:14px"><h3>😊 Satisfação dos clientes</h3>'
               . '<div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:6px 2px">'
               . '<div style="font-size:34px;font-weight:800;color:#f59e0b;line-height:1">' . number_format($satM, 2, ',', '.') . ' <span style="font-size:20px">' . $estrelas . '</span></div>'
               . '<div class="ws-muted">' . $satN . ' avaliação(ões)' . ($topTec ? '<br>🏆 Melhor técnico: <b>' . h($topTec) . '</b>' : '') . '</div>'
               . '</div></a>';
        }

        echo '<div class="ws-two">';
        echo '<div class="ws-chart"><h3>Chamados por assunto</h3>' . ($porAssunto ? ws_svg_pizza($porAssunto) : '<p class="ws-muted">Sem chamados registrados.</p>') . '</div>';
        echo '<div class="ws-chart"><h3>Chamados por técnico</h3>' . ($porTecnico ? ws_svg_pizza($porTecnico) : '<p class="ws-muted">Sem chamados registrados.</p>') . '</div>';
        echo '</div>';
        echo '<div class="ws-two" style="margin-top:14px">';
        echo '<div class="ws-chart"><h3>Chamados abertos por assunto</h3>' . ($porAssuntoAberto ? ws_svg_pizza($porAssuntoAberto) : '<p class="ws-muted">Nenhum chamado em aberto.</p>') . '</div>';
        echo '<div class="ws-chart"><h3>Chamados abertos por técnico</h3>' . ($porTecnicoAberto ? ws_svg_pizza($porTecnicoAberto) : '<p class="ws-muted">Nenhum chamado em aberto.</p>') . '</div>';
        echo '</div>';
        echo '<div class="ws-chart" style="margin-top:14px"><h3>Total de chamados</h3>'
           . ws_svg_barras_n(['Chamados'], ['Abertos'=>[$chTotalAbertos], 'Fechados'=>[$chTotalFechados], 'Saldo'=>[$chTotalAbertos-$chTotalFechados]])
           . '</div>';
    }

    echo '<p class="ws-muted" style="margin-top:8px"><a class="ws-btn" href="relatorios.php">Ver relatórios completos →</a></p>';

    // ---- Alerta do sistema (discreto, pulsa vermelho) — SÓ para BLOQUEIO MANUAL e ERRO do sistema.
    // NÃO mostra bloqueio automático (por dívida). Fecha no X e some; só volta em NOVO LOGIN ou quando
    // surgir um NOVO alerta (assinatura muda). Some sozinho quando não há mais alerta (erro corrigido).
    $alertas = [];
    $nManual = 0; try { $nManual = (int)$q("SELECT COUNT(DISTINCT c.id) FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id=c.id WHERE c.status='bloqueado' AND ct.bloqueio_manual=1" . ($ramalAtivo ? " AND c.ramal_id=".(int)$ramalAtivo['id'] : "")); } catch (Throwable $e) {}
    if ($nManual > 0) $alertas[] = ['🔒 ' . $nManual . ' cliente(s) bloqueado(s) manualmente', 'erp.php?p=clientes&status=bloqueado&destaque=manual'];
    $errLog = 0; try { $errLog = (int)$q("SELECT COUNT(*) FROM ws_evento WHERE tipo IN('erro','falha') AND criado_em >= (NOW() - INTERVAL 1 DAY)"); } catch (Throwable $e) {}
    if ($errLog > 0) $alertas[] = ['❗ ' . $errLog . ' erro(s) do sistema a corrigir (24h)', 'relatorios.php?p=log'];
    // "Pagou o mês errado": pagou uma mensalidade mais nova com outra mais antiga do MESMO contrato em aberto.
    // Mesma lógica do financeiro (fin_mes_errado_query), aqui só como CONTAGEM — respeita o filtro de ramal.
    $nMesErr = 0; try { $nMesErr = (int)$q("SELECT COUNT(DISTINCT c.id) FROM ws_fatura fp
        JOIN ws_contrato ct ON ct.id=fp.contrato_id JOIN ws_cliente c ON c.id=ct.cliente_id
        JOIN ws_fatura fa ON fa.contrato_id=fp.contrato_id
        WHERE fp.status='pago' AND fp.competencia IS NOT NULL AND fp.competencia<>''
          AND fa.status IN('aberto','vencido','processando') AND fa.competencia IS NOT NULL AND fa.competencia<>''
          AND fa.competencia < fp.competencia AND ct.status<>'cancelado'" . ($ramalAtivo ? " AND c.ramal_id=".(int)$ramalAtivo['id'] : "")); } catch (Throwable $e) {}
    if ($nMesErr > 0) $alertas[] = ['⚠️ ' . $nMesErr . ' cliente(s) pagaram um mês mais novo com mensalidade antiga em aberto', 'financeiro.php?p=mes_errado'];
    /* ONU AGUARDANDO LIBERAÇÃO — a tela de Aprovisionamento se atualiza sozinha a cada 45s, mas
       ninguém fica com ela aberta o dia todo. Quando ela NÃO está aberta, o aviso tem que chegar
       onde o operador está: aqui no sino do Painel, com o link levando direto para lá. Contagem
       lida do mesmo cache da OLT que a tela usa — sem consulta nova ao equipamento. */
    // O módulo da OLT é opcional (instalação sem OLT não tem o arquivo) — por isso o carregamento
    // é aqui, sob demanda e condicional, e não no topo do erp.php.
    if (!function_exists('ws_olt_stats') && is_file(__DIR__ . '/olt_link.php')) {
        try { require_once __DIR__ . '/olt_link.php'; } catch (Throwable $e) {}
    }
    if (function_exists('ws_olt_stats')) {
        try {
            $oltSt = ws_olt_stats();
            $nPend = (int)($oltSt['pendentes'] ?? 0);
            if ($nPend > 0) {
                $alertas[] = ['📡 ' . $nPend . ' ONU/ONT aguardando liberação na OLT', 'olt_erp.php?p=painel'];
            }
        } catch (Throwable $e) {}
    }
    if ($alertas) {
        $totAl = count($alertas);
        // Assinatura do conjunto de alertas + id da sessão: o "fechar" só vale enquanto a assinatura
        // não muda; novo login (nova sessão) ou novo alerta faz reaparecer.
        $sig = substr(md5(session_id() . '|' . implode('|', array_map(fn($a) => $a[0], $alertas))), 0, 16);
        echo '<button type="button" class="ws-alert-fab" id="wsAlertFab" title="Mostrar alertas do sistema" style="display:none">🔔 Alertas <span class="n">' . $totAl . '</span></button>';
        echo '<div class="ws-alert-pop" id="wsAlertPop" data-sig="' . $sig . '">';
        echo '<div class="ws-alert-pop-h" id="wsAlertPopH"><span>🔔 Alertas do sistema <span class="n">' . $totAl . '</span></span>'
           . '<button type="button" class="ws-alert-x" id="wsAlertX" title="Fechar">✕</button></div>';
        foreach ($alertas as $al) echo '<a href="' . h($al[1]) . '">' . $al[0] . '</a>';
        echo '</div>';
        echo '<script>(function(){
          var pop=document.getElementById("wsAlertPop"),fab=document.getElementById("wsAlertFab"),
              x=document.getElementById("wsAlertX"),h=document.getElementById("wsAlertPopH"),sig=pop.getAttribute("data-sig");
          if(!pop)return;
          // (14/10) o balão fica logo ABAIXO do topo/menu, alinhado à direita — antes cobria os itens do menu (Servidores, Estoque…).
          /* (15/10/2026) POSIÇÃO PADRÃO: canto direito, logo ABAIXO da linha do menu (Painel … Opções), sem cobrir os itens do menu. Só muda se o atendente ARRASTAR o balão: a nova posição fica guardada neste navegador (duplo clique no título volta ao padrão). */
          function posPadrao(){ try{ var nv=document.querySelector(".ws-nav")||document.querySelector("header.ws-top-wrap")||document.querySelector("header"); pop.style.left="auto"; pop.style.right="18px"; pop.style.top=Math.round((nv?nv.getBoundingClientRect().bottom:90)+6)+"px"; }catch(e){} }
          posPadrao();
          try{ var sp=JSON.parse(localStorage.getItem("ws_alert_pos")||"null"); if(sp&&typeof sp.left==="number"&&typeof sp.top==="number"){ pop.style.left=Math.max(4,Math.min(sp.left,window.innerWidth-120))+"px"; pop.style.top=Math.max(4,Math.min(sp.top,window.innerHeight-60))+"px"; pop.style.right="auto"; } }catch(e){}
          h.addEventListener("dblclick",function(){ try{localStorage.removeItem("ws_alert_pos");}catch(e){} posPadrao(); });
          // Se já foi fechado NESTA sessão para ESTA assinatura, começa recolhido (só o sino).
          try{ if(sessionStorage.getItem("ws_alert_dismiss")===sig){ pop.style.display="none"; fab.style.display="inline-flex"; } }catch(e){}
          x.addEventListener("click",function(){ pop.style.display="none"; fab.style.display="inline-flex"; try{sessionStorage.setItem("ws_alert_dismiss",sig);}catch(e){} });
          fab.addEventListener("click",function(){ pop.style.display="block"; fab.style.display="none"; try{sessionStorage.removeItem("ws_alert_dismiss");}catch(e){} });
          var dx=0,dy=0,drag=false;
          h.addEventListener("mousedown",function(e){drag=true;var r=pop.getBoundingClientRect();dx=e.clientX-r.left;dy=e.clientY-r.top;pop.style.transition="none";e.preventDefault();});
          document.addEventListener("mousemove",function(e){if(!drag)return;pop.style.left=(e.clientX-dx)+"px";pop.style.top=(e.clientY-dy)+"px";pop.style.right="auto";pop.style.bottom="auto";});
          document.addEventListener("mouseup",function(){ if(drag){ try{ var r=pop.getBoundingClientRect(); localStorage.setItem("ws_alert_pos",JSON.stringify({left:Math.round(r.left),top:Math.round(r.top)})); }catch(e){} } drag=false;});
        })();</script>';
    }

    // ---- Rodapé do Painel (só os atalhos; a marca/tagline e o © ficam no rodapé oficial embaixo) ----
    echo '<footer style="margin-top:32px;padding:18px 0 8px;border-top:1px solid var(--border);display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:14px;font-size:12px;color:var(--muted)">'
       . '<a href="erp.php?p=dashboard" style="color:var(--muted);text-decoration:none">Início</a>'
       . '<a href="relatorios.php" style="color:var(--muted);text-decoration:none">Relatórios</a>'
       . '<a href="backup.php" style="color:var(--muted);text-decoration:none">Backup</a>'
       . '<a href="docs.php" style="color:var(--muted);text-decoration:none">Ajuda</a>'
       . '</footer>';
}

/* --------- Lista de clientes --------- */
/** Exibição do plano na LISTA de clientes (só visual, não altera o plano):
 *  "100Mega_Wellnet" (R$120) -> "100_Mega_120". Sem número reconhecível, mostra o nome original. */
function ws_plano_fmt(?string $nome, $valor = null): string {
    $nome = trim((string)$nome);
    if ($nome === '') return '—';
    if (!preg_match('/(\d+)/', $nome, $m)) return $nome;
    $unid = preg_match('/giga|\bgb\b|\bg\b/i', $nome) ? 'Giga' : 'Mega';
    $out = $m[1] . '_' . $unid;
    if ($valor !== null && (float)$valor > 0) $out .= '_' . (int)round((float)$valor);
    return $out;
}

function ws_csv_clientes(PDO $db): void {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=clientes.csv');
    $out = fopen('php://output', 'w');
    // Adiciona BOM para o Excel ler acentos no Windows
    fputs($out, $bom =(chr(0xEF) . chr(0xBB) . chr(0xBF)));
    fputcsv($out, ['ID', 'Nome', 'CPF/CNPJ', 'Celular', 'Email', 'Status', 'Data Cadastro', 'Cidade', 'Bairro', 'Endereco', 'CEP']);
    
    $st = $db->query("SELECT * FROM ws_cliente ORDER BY nome ASC");
    while ($r = $st->fetch()) {
        fputcsv($out, [
            // (01/10/2026) colunas reais do cadastro: cpf_cnpj / logradouro / data_cadastro (antes 'cpf', 'endereco' e 'criado_em' saíam vazios + aviso no log)
            $r['id'], $r['nome'], $r['cpf_cnpj'] ?? '', $r['celular'], $r['email'],
            $r['status'], ($r['data_cadastro'] ?? '') ?: ($r['criado_em'] ?? ''), $r['cidade'], $r['bairro'],
            trim(($r['logradouro'] ?? '') . ' ' . ($r['numero'] ?? '') . ' ' . ($r['complemento'] ?? '')), $r['cep']
        ]);
    }
    fclose($out);
}

function ws_view_cliente_resumo(PDO $db): void {
    $id = (int)($_GET['id'] ?? 0);
    $c = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $c->execute([$id]); $cli = $c->fetch();
    if (!$cli) { echo "Cliente não encontrado."; return; }
    if (!empty($cli['ramal_id']) && !ws_ramal_permitido((int)$cli['ramal_id'])) { echo 'Sem acesso a este cliente.'; return; }   // 14/11/2026: mesma regra de cidade do cartão resumido (antes o resumo abria cliente de qualquer cidade)
    try { require_once __DIR__ . '/schema_endereco.php'; $cli = ws_end_enriquecer($db, $cli); } catch (Throwable $e) {}   // 14/11/2026: endereço do cadastro normalizado (rua → bairro → cidade), como nas notas e no boleto
    $ct = $db->prepare("SELECT ct.*, p.nome AS plano_nome FROM ws_contrato ct LEFT JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=? AND ct.status='ativo' LIMIT 1"); 
    $ct->execute([$id]); $con = $ct->fetch();
    ?>
    <div class="ws-head-row">
        <h2>Resumo: <?= h($cli['nome']) ?></h2>
        <?php /* VOLTAR PARA O CLIENTE NA LISTA: volta para a mesma lista de onde veio (filtros e página
                 preservados pelo referer) e para EXATAMENTE na linha dele (#cliID), sem rolar à procura. */ ?>
        <a href="erp.php?p=clientes#cli<?= (int)$id ?>" id="wsVoltarLista" title="Voltar para Clientes (na linha deste cliente)" aria-label="Voltar" style="color:#dc2626;font-weight:800;font-size:17px;text-decoration:none;margin-left:8px" onmouseover="this.style.color='#991b1b'" onmouseout="this.style.color='#dc2626'">↺</a>
        <script>(function(){ var a=document.getElementById('wsVoltarLista'), r=document.referrer||'';
          if(a && /[?&]p=clientes(&|$)/.test(r) && r.indexOf(location.host)>-1) a.href=r.split('#')[0]+'#cli<?= (int)$id ?>'; })();</script>
    </div>
    <div class="ws-panel">
      <div class="ws-form grid" style="gap:6px 18px">
        <div><b>Nome Resumido:</b> <?= h($cli['nome_resumido'] ?: '—') ?></div>
        <?php $nCont = 0; try { $qn = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=?"); $qn->execute([$id]); $nCont = (int)$qn->fetchColumn(); } catch (Throwable $e) {}
              $tsCad = !empty($cli['criado_em']) ? strtotime((string)$cli['criado_em']) : 0;
              $docL = preg_replace('/\D/', '', (string)($cli['cpf_cnpj'] ?? '')); ?>
        <div><b>Cliente desde:</b> <?= $tsCad ? date('d/m/Y', $tsCad) : '—' ?></div>
        <div><b>Tipo:</b> <?= strlen($docL) > 11 ? 'PJ (CNPJ)' : ($docL !== '' ? 'PF (CPF)' : '—') ?></div>
        <div><b>Bairro:</b> <?= h($cli['bairro'] ?: '—') ?></div>
        <div><b>Contratos:</b> <?= $nCont ?></div>
        <div><b>Documento:</b> <?= h($cli['cpf_cnpj']) ?></div>
        <div><b>Celular:</b> <?= h($cli['celular']) ?></div>
        <div><b>Status:</b> <?= h($cli['status']) ?></div>
        <div style="grid-column:1/-1"><b>Endereço:</b> <?= h(trim(($cli['logradouro'] ?? '') . ' ' . $cli['numero'] . ' ' . $cli['complemento'])) ?><?= $cli['bairro'] ? ' - ' . h($cli['bairro']) : '' ?><?= $cli['cidade'] ? ' - ' . h($cli['cidade']) : '' ?></div>
        <?php if($con): ?>
        <div class="c4 ws-secao" style="margin-top:10px">Conexão Ativa</div>
        <div><b>Login:</b> <?= h($con['login_pppoe'] ?: $con['login_ipoe']) ?></div>
        <div><b>Plano:</b> <?= h($con['plano_nome']) ?></div>
        <div><b>Vencimento:</b> Dia <?= h($con['dia_vencimento'] ?: '—') ?></div>
        <div><b>MAC/SN:</b> <?= h($con['sn_onu'] ?: $con['equip_mac'] ?: '—') ?></div>
        <div style="grid-column:1/-1"><b>IP / VLAN:</b> <?= h($con['ip_fixo'] ?: 'Dinâmico') ?> / <?= h($con['vlan'] ?: '—') ?></div>
        <?php else: ?>
        <div class="c4 ws-muted" style="margin-top:10px">Nenhuma conexão ativa encontrada.</div>
        <?php endif; ?>
      </div>
      <div style="margin-top:20px">
        <a class="ws-btn primary" href="erp.php?p=cliente&id=<?= $id ?>" target="_parent">Abrir Cadastro Completo</a>
      </div>
    </div>
    <?php
}

function ws_view_clientes_recentes(PDO $db): void {
    $dias = (int)($_GET['dias'] ?? 30);
    if ($dias < 1) $dias = 30;
    // Item 3: a página listava clientes de QUALQUER cidade/ramal, mesmo com um ramal ativo
    // selecionado no topo — diferente do resto do sistema (Clientes, Dashboard, etc.), onde cada
    // cidade só vê os seus + os sem ramal. Por isso parecia "listar tudo". Corrigido com o mesmo
    // filtro usado em ws_view_clientes().
    $ramalAtivo = ws_ramal_atual();
    $whereR = "c.criado_em >= DATE_SUB(CURDATE(), INTERVAL ? DAY) AND c.status<>'cancelado'";
    $parR = [$dias];
    if ($ramalAtivo) { $whereR .= " AND (c.ramal_id = ? OR c.ramal_id IS NULL)"; $parR[] = $ramalAtivo['id']; }
    $st = $db->prepare("SELECT c.*, (SELECT ct.login_pppoe FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) login,
                   (SELECT p.nome FROM ws_contrato ct JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) plano
            FROM ws_cliente c WHERE $whereR ORDER BY c.id DESC");
    $st->execute($parR); $rows = $st->fetchAll();
    ?>
    <div class="ws-head-row ws-tarja">
        <h2>⭐ Clientes Recentes<?php if ($ramalAtivo): ?> <span class="ws-tag" style="font-size:11px;font-weight:700">📍 <?= h($ramalAtivo['cidade']) ?> — <?= h($ramalAtivo['nome']) ?></span><?php endif; ?>
          <span class="ws-muted" style="font-size:13px;font-weight:400">últimos <?= $dias ?> dias — <?= count($rows) ?> cadastro(s)</span></h2>
        <a href="erp.php?p=clientes" title="Voltar para Clientes" style="color:#dc2626;font-weight:800;font-size:17px;text-decoration:none;margin-left:8px" onmouseover="this.style.color='#991b1b'" onmouseout="this.style.color='#dc2626'">↺</a>
    </div>
    <div class="ws-search" style="gap:6px;margin-bottom:14px">
      <?php foreach ([7=>'7 dias',15=>'15 dias',30=>'30 dias',60=>'60 dias',90=>'90 dias'] as $d=>$lbl): ?>
        <a class="ws-btn <?= $dias===$d?'primary':'' ?>" href="erp.php?p=clientes_recentes&dias=<?= $d ?>"><?= $lbl ?></a>
      <?php endforeach; ?>
    </div>
    <?php if ($rows): ?>
    <form method="post">
    <input type="hidden" name="acao_recentes" value="excluir">
    <div style="overflow-x:auto"><table class="ws-tbl ws-table"><thead><tr>
      <th style="width:26px"><input type="checkbox" id="chkAll" onclick="document.querySelectorAll('.rc-chk').forEach(c=>c.checked=this.checked)"></th>
      <th class="ws-th-esq">Nome</th><th style="text-align:center">Login</th><th style="text-align:center">Plano</th><th style="text-align:center">Celular</th><th style="text-align:center">Cadastro</th><th style="text-align:center">Ações</th>
    </tr></thead><tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td data-lb=""><input type="checkbox" class="rc-chk" name="ids[]" value="<?= $r['id'] ?>"></td>
        <td class="ws-th-esq" data-lb="Nome"><a href="erp.php?p=cliente&id=<?= $r['id'] ?>"><b><?= h($r['nome']) ?></b></a></td>
        <td data-lb="Login" style="text-align:center"><?= h($r['login'] ?: '—') ?></td>
        <td data-lb="Plano" style="text-align:center"><?= h($r['plano'] ?: '—') ?></td>
        <td data-lb="Celular" style="text-align:center"><?= h($r['celular'] ?: '—') ?></td>
        <td data-lb="Cadastro" style="text-align:center;white-space:nowrap"><?= h(date('d/m/Y', strtotime($r['criado_em'] ?? 'now'))) ?></td>
        <td data-lb="Ações" style="text-align:center;white-space:nowrap"><a class="ws-btn" href="erp.php?p=cliente&id=<?= $r['id'] ?>">Editar</a>
          <?php if (ws_pode_deletar()): ?><a class="ws-btn" style="color:var(--err)" href="erp.php?cli_del=<?= (int)$r['id'] ?>&volta=recentes" onclick="return confirm('Deseja realmente excluir o cliente &quot;<?= h($r['nome']) ?>&quot; e todos os seus contratos/boletos? Esta ação é irreversível.')" title="Excluir cadastro do cliente">🗑️ Deletar</a><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <div style="margin-top:10px">
      <button class="ws-btn danger" type="submit" onclick="return confirm('Excluir os clientes selecionados? Esta ação é irreversível.')">🗑 Excluir selecionados</button>
    </div>
    </form>
    <?php else: ?>
    <div class="ws-muted" style="padding:40px 20px;text-align:center;font-size:14px">✨ Nenhum cliente novo nos últimos <?= $dias ?> dias<?php if ($ramalAtivo): ?> em <?= h($ramalAtivo['cidade']) ?><?php endif; ?>.</div>
    <?php endif; ?>
    <div class="ws-muted" style="margin-top:16px;font-size:12px">💡 A lista é zerada automaticamente conforme os cadastros saem do período selecionado.</div>
    <?php
}

function ws_view_clientes(PDO $db): void {
    $busca = trim($_GET['q'] ?? '');
    $campo = $_GET['campo'] ?? 'tudo';
    $fstatus = $_GET['status'] ?? '';
    $where = []; $par = [];
    if ($busca !== '') {
        $like = "%$busca%";
        $subC = fn($cond) => "EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND $cond)";
        switch ($campo) {
            /* Nome: cada palavra digitada pode ser o INÍCIO de qualquer palavra do nome —
               "jo si" acha JOSE DA SILVA. A função do campo é a mesma: filtrar por nome. */
            case 'nome':     $where[]=ws_busca_cond(['c.nome'], $busca, $par); break;
            case 'id':       $where[]="c.id = ?"; $par[]=(int)$busca; break;
            case 'cpf':      $where[]="c.cpf_cnpj LIKE ?"; $par[]=$like; break;
            case 'endereco': $where[]=ws_busca_cond(['c.logradouro', 'c.bairro', 'c.cidade'], $busca, $par); break;
            case 'login':    $where[]=$subC("ct.login_pppoe LIKE ?"); $par[]=$like; break;
            // IP: procura no fixo E no último IP dinâmico visto no concentrador (obs1/obs2).
            case 'ip':       $where[]=$subC("(ct.ip_fixo LIKE ? OR ct.ultimo_ip LIKE ?)"); array_push($par,$like,$like); break;
            case 'vlan':     $where[]=$subC("ct.vlan = ?"); $par[]=(int)preg_replace('/\D/','',$busca); break;
            // Dia de vencimento do contrato (1..31): lista todos os clientes que vencem nesse dia.
            case 'venc':     $where[]=$subC("ct.status<>'cancelado' AND ct.dia_vencimento = ?"); $par[]=(int)(preg_match('/\d{1,2}/',$busca,$mv) ? $mv[0] : 0); break;
            case 'mac':      $where[]=$subC("(ct.sn_onu LIKE ? OR ct.ont_id LIKE ?)"); array_push($par,$like,$like); break;
            default: // tudo
                /* "TUDO" — a montagem inteira vive em ws_busca_clientes_cond() (config.php).
                 * Está lá, e não aqui, por dois motivos: a regra é longa (todas as colunas do
                 * cliente e do contrato, com e sem pontuação, mais o filtro em dois níveis que
                 * impede uma palavra comum de casar com a base toda), e ela precisa ser UMA só —
                 * esta tela e a lista do CRM tinham cópias que já divergiram entre si. */
                $cond = ws_busca_clientes_cond($db, $busca, $par);
                if ($cond !== '') $where[] = $cond;
        }
    }
    /* OBSERVAÇÃO **É** CONFIANÇA — um botão só, com o nome que o resto do sistema usa.
     *
     * Eram dois botões para a mesma coisa, e um deles vivia zerado:
     *   "Confiança"  contava contrato com confianca_ate no futuro   -> 12
     *   "Observação" contava ws_cliente.status='observacao'          -> 0
     *
     * São o mesmo conceito com dois nomes. No MK-Auth, liberar em confiança É pôr o cliente em
     * "observação" (`observacao='sim'` + `rem_obs=<data-limite>`) — está escrito no próprio
     * importador, em mk_confianca_gravar(). O WellSystem chamou de "confiança" o mecanismo e
     * manteve "observação" como status, e a tela acabou mostrando os dois.
     *
     * Agora é um: o rótulo é **Observação**, que é o nome usado nas outras telas, e o conteúdo é o
     * da confiança, que é onde os clientes realmente estão.
     *
     * O filtro aceita AS DUAS ORIGENS de propósito: contrato em confiança OU status='observacao'.
     * Repontar só para a confiança deixaria inalcançável por filtro quem tenha o status gravado
     * literalmente como 'observacao' (o campo continua existindo na ficha) — um cliente que
     * existe e que nenhum botão encontra é pior que um botão a mais.
     *
     * A chave 'confianca' continua sendo aceita: há links antigos, favoritos e o atalho do Painel
     * apontando para ela. Cai no mesmo filtro, em vez de dar lista vazia. */
    if ($fstatus === 'confianca' || $fstatus === 'observacao') {
        $where[] = "(EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.confianca_ate IS NOT NULL AND ct.confianca_ate>NOW())"
                 . " OR c.status='observacao'" . ws_obs_auto_sql('c') . ")";
    }
    elseif ($fstatus === 'adicional') { $where[] = "c.titular_id IS NOT NULL AND c.status<>'cancelado'"; }
    /* ONLINE / OFFLINE pela MESMA fonte do card do Painel (ws_clientes_online_ids, radius_lib.php).
       Antes a lista olhava só a radacct do banco do WellSystem e só o login_pppoe. Com o RADIUS
       do MK-Auth autenticando, essa radacct fica vazia — o filtro "Offline" devolvia TODOS os
       ativos (e o "Online" nenhum), enquanto o card contava certo pelos concentradores.
       Offline = ativo, com contrato ativo, e fora do conjunto online (igual à conta do card). */
    elseif ($fstatus === 'online' || $fstatus === 'offline') {
        $idsOn = ws_clientes_online_ids($db);
        $inOn  = $idsOn ? implode(',', array_map('intval', $idsOn)) : '0';
        $where[] = $fstatus === 'online'
            ? "c.id IN ($inOn)"
            : "c.status='ativo' AND EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.status='ativo') AND c.id NOT IN ($inOn)";
    }
    elseif ($fstatus === 'atraso') { $where[] = "c.status NOT IN('cancelado','desativado') AND EXISTS(SELECT 1 FROM ws_fatura f WHERE f.cliente_id=c.id AND f.status IN('aberto','vencido','processando') AND f.vencimento<CURDATE())"; }
    elseif ($fstatus === 'semtitulo') { $where[] = "c.status<>'cancelado' AND EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.status='ativo') AND NOT EXISTS(SELECT 1 FROM ws_fatura f JOIN ws_contrato ct2 ON ct2.id=f.contrato_id WHERE ct2.cliente_id=c.id AND f.status IN('aberto','vencido','processando'))"; }
    elseif ($fstatus === 'recentes') { $where[] = "c.status<>'cancelado' AND c.criado_em >= DATE_FORMAT(CURDATE(), '%Y-%m-01')"; }
    // 'observacao' saiu desta lista: é tratado acima, junto da confiança (mesmo conceito).
    elseif (in_array($fstatus, ['ativo','bloqueado','cancelado'], true)) { $where[] = "c.status=?"; $par[] = $fstatus; }
    /* VEIO DO ALERTA "bloqueado(s) manualmente": a lista mostra SÓ eles. O alerta diz
       "1 cliente"; cair numa página com 200 bloqueados e ter de caçar qual é o tal não
       responde ao clique. Com o filtro, a linha aparece — e o destaque pulsa em cima dela. */
    if (($_GET['destaque'] ?? '') === 'manual')
        $where[] = "EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.bloqueio_manual=1)";
    /* BUSCA sem status escolhido: procura em todas as situações ATIVAS do sistema (ativo,
     * bloqueado, suspenso, em confiança) e DEIXA O DESATIVADO DE FORA — igual ao card "Todos",
     * que também não conta cancelado. Antes a busca trazia desativado junto, e o operador que
     * procurava um cliente recebia de volta cadastros que ele mesmo já tinha encerrado.
     * Para achar um desativado, o caminho continua existindo: card "Cancelados" + a busca. */
    /* CORREÇÃO "Cancelados não lista": o `elseif/else` que ficava aqui estava PENDURADO no
     * `if (destaque === 'manual')` acima (que não tem chaves), e não na cadeia de status. Resultado:
     * sem ?destaque=manual, o `else` rodava SEMPRE e somava c.status<>'cancelado' ao filtro
     * c.status='cancelado' → condição impossível → 0 clientes (o botão contava 893, a tabela vinha vazia).
     * Agora é um `if` próprio: "Todos", busca e demais filtros continuam sem cancelado; só o filtro
     * Cancelados fica de fora dessa exclusão. */
    if ($fstatus !== 'cancelado') { $where[] = "c.status<>'cancelado'"; }   // "Todos" NÃO conta cancelado (fica só no card Cancelados)
    // Ramal/cidade ativo no seletor do topo: cada cidade vê os seus clientes E também os SEM ramal
    // (importados do backup cuja cidade não casou com nenhum ramal) — senão eles só apareceriam em
    // "Todas as cidades" e sumiam ao clicar no card. Assim nunca ficam invisíveis.
    $ramalAtivo = ws_ramal_atual();
    if ($ramalAtivo) { $where[] = "(c.ramal_id = ? OR c.ramal_id IS NULL)"; $par[] = $ramalAtivo['id']; }
    /* Rede de segurança: condição vazia nunca vira " WHERE  AND " (SQL quebrado). Condição
       vazia não gera parâmetro nenhum, então tirá-la não desalinha os "?" com $par. */
    $where = array_values(array_filter($where, fn($w) => trim((string)$w) !== ''));
    $wsql = $where ? " WHERE " . implode(' AND ', $where) : "";
    // paginação: 25 / 50 / 100 / todos(0)
    $ppOpts = [25, 50, 100, 0];
    $ppPad = ws_recursos()['registros_pagina'];   // Recursos do sistema → Tema
    $ppReq = (int)($_GET['pp'] ?? $ppPad); $pp = in_array($ppReq, $ppOpts, true) ? $ppReq : $ppPad;
    $pg = max(1, (int)($_GET['pg'] ?? 1));
    $ct = $db->prepare("SELECT COUNT(*) FROM ws_cliente c$wsql"); $ct->execute($par); $total = (int)$ct->fetchColumn();
    $lim = $pp > 0 ? " LIMIT $pp OFFSET " . (($pg - 1) * $pp) : "";
    $ordemSql = ($fstatus === 'recentes') ? " ORDER BY c.id DESC" : " ORDER BY c.nome ASC";
    $sql = "SELECT c.*, (SELECT COUNT(*) FROM ws_contrato ct WHERE ct.cliente_id=c.id) contratos,
                   (SELECT ct.login_pppoe FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) login,
                   (SELECT ct.plano_id FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) plano_id,
                   (SELECT p.nome FROM ws_contrato ct JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) plano_nome,
                   (SELECT p.valor FROM ws_contrato ct JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) plano_valor,
                   (SELECT ct.id FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) contrato_id,
                   (SELECT ct.vlan FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) vlan,
                   /* Senha da conexao: aparece no HOVER do login (a ficha ja' a mostra; o suporte
                      pedia o valor sem ter que abrir o cadastro do cliente para ditar no telefone). */
                   (SELECT COALESCE(NULLIF(ct.senha_pppoe,''), NULLIF(ct.senha_ipoe,'')) FROM ws_contrato ct WHERE ct.cliente_id=c.id ORDER BY ct.id LIMIT 1) senha_con,
                   /* Ultimo IP visto no concentrador (obs2): e o que a coluna IP mostra, em cinza,
                      quando o cliente esta offline (antes ficava so um traco). Gravado por
                      ws_conexao_registrar() (radius_lib.php) na leitura normal do painel. */
                   (SELECT ct.ultimo_ip FROM ws_contrato ct WHERE ct.cliente_id=c.id AND COALESCE(ct.ultimo_ip,'')<>'' ORDER BY ct.ultimo_ip_em DESC LIMIT 1) ultimo_ip,
                   (SELECT MAX(ct.confianca_ate) FROM ws_contrato ct WHERE ct.cliente_id=c.id) conf_ate,
                   (SELECT MAX(ct.bloqueio_manual) FROM ws_contrato ct WHERE ct.cliente_id=c.id) bloq_manual,
                   (SELECT COUNT(*) FROM ws_fatura f JOIN ws_contrato ct2 ON ct2.id=f.contrato_id
                     WHERE ct2.cliente_id=c.id AND f.status IN('aberto','vencido','processando')) abertos,
                   (SELECT COUNT(*) FROM ws_contrato ct3 WHERE ct3.cliente_id=c.id AND ct3.status='ativo') ativos"
            /* Busca por DIA DE VENCIMENTO: traz o dia do contrato e o próximo boleto em aberto, para a
               linha mostrar se o boleto bate com o dia pedido (contrato num dia e boleto noutro = cadastro
               inconsistente, fica em vermelho em vez de passar despercebido). */
            . ($campo === 'venc' && $busca !== '' ? ",
                   (SELECT ct4.dia_vencimento FROM ws_contrato ct4 WHERE ct4.cliente_id=c.id AND ct4.status<>'cancelado' ORDER BY ct4.id LIMIT 1) venc_dia,
                   (SELECT MIN(f4.vencimento) FROM ws_fatura f4 WHERE f4.cliente_id=c.id AND f4.status IN('aberto','vencido','processando')) venc_prox" : "") . "
            FROM ws_cliente c" . $wsql . $ordemSql . $lim;
    $st = $db->prepare($sql); $st->execute($par); $rows = $st->fetchAll();
    /* IP DINÂMICO DO CLIENTE (obs2).
     * Fonte principal: ws_conexao_viva() (radius_lib.php) — a MESMA leitura dos concentradores
     * que o Painel usa. Antes esta lista lia só a tabela radacct do banco do WellSystem; como
     * quem autentica o PPPoE é o FreeRADIUS do MK-Auth (banco mkradius), essa tabela costuma
     * estar vazia e a coluna IP ficava com "—" para todo mundo, mesmo com o cliente conectado.
     * A radacct continua como complemento: instalação sem MK-Auth usa ela normalmente. */
    // $ipsCnc guarda o IP DO CONCENTRADOR (não o do cliente): é o que a etiqueta CNC-1/CNC-2 usa
    // para abrir o painel já filtrado naquele concentrador.
    $ipsOnline = []; $cncOnline = []; $ipsCnc = []; $uptOnline = [];
    $loginsPag = array_filter(array_column($rows, 'login'));
    if ($loginsPag) {
        if (function_exists('ws_conexao_viva')) {
            try {
                $vivos = ws_conexao_viva(90);   // cache curto: não fala com concentrador a cada F5
                foreach ($loginsPag as $lg) {
                    $k = ws_conexao_norm((string)$lg);
                    if ($k === '' || empty($vivos[$k])) continue;
                    if (!empty($vivos[$k]['ip']))       $ipsOnline[$lg] = $vivos[$k]['ip'];
                    $nm = $vivos[$k]['cnc_nome'] ?? ''; $ipc = $vivos[$k]['cnc'] ?? '';
                    if ($nm !== '' || $ipc !== '')      $cncOnline[$lg] = ($nm !== '' ? $nm : $ipc);
                    if ($ipc !== '')                    $ipsCnc[$lg]   = $ipc;
                    if (!empty($vivos[$k]['uptime']))   $uptOnline[$lg] = (string)$vivos[$k]['uptime'];
                }
            } catch (Throwable $e) {}
        }
        try {
            $in = implode(',', array_fill(0, count($loginsPag), '?'));
            $stIp = $db->prepare("SELECT ra.username, ra.framedipaddress, n.shortname
                                  FROM radacct ra LEFT JOIN nas n ON n.nasname=ra.nasipaddress
                                  WHERE ra.acctstoptime IS NULL AND ra.username IN ($in) GROUP BY ra.username");
            $stIp->execute(array_values($loginsPag));
            foreach ($stIp->fetchAll() as $r) {
                if (empty($ipsOnline[$r['username']]))                       $ipsOnline[$r['username']] = $r['framedipaddress'];
                if (!empty($r['shortname']) && empty($cncOnline[$r['username']])) $cncOnline[$r['username']] = $r['shortname'];
            }
        } catch (Throwable $e) {}
    }
    $paginas = $pp > 0 ? (int)ceil($total / $pp) : 1;
    $baseqs = ($fstatus ? "&status=$fstatus" : '') . ($busca ? '&q=' . urlencode($busca) . '&campo=' . urlencode($campo) : '')
            . (($_GET['destaque'] ?? '') === 'manual' ? '&destaque=manual' : '');
    // contadores por status (respeitando a cidade/ramal ativo, se houver)
    // Condição de ramal em DUAS formas: com WHERE (query sem WHERE próprio) e com AND (query que já
    // tem WHERE). Inclui os clientes SEM ramal (importados). Antes o $cntWhere (com WHERE) era colado
    // numa query que já tinha WHERE -> "WHERE ... WHERE ..." -> erro SQL que esvaziava a lista com
    // um ramal específico selecionado (item corrigido).
    $cntWhere = $ramalAtivo ? " WHERE (ramal_id=" . (int)$ramalAtivo['id'] . " OR ramal_id IS NULL)" : "";
    $cntAnd   = $ramalAtivo ? " AND (ramal_id=" . (int)$ramalAtivo['id'] . " OR ramal_id IS NULL)" : "";
    $cnt = []; foreach ($db->query("SELECT status, COUNT(*) n FROM ws_cliente$cntWhere GROUP BY status")->fetchAll() as $x) $cnt[$x['status']] = $x['n'];
    $nTotal = array_sum($cnt) - ($cnt['cancelado'] ?? 0);
    /* Contagem do botão "Online" = MESMA fonte do filtro (ws_clientes_online_ids): concentradores ao vivo
       + radacct, por login PPPoE e IPoE. Antes contava só a radacct, que com o RADIUS do MK-Auth fica vazia. */
    $nOnline = 0; try { $idsOnCnt = ws_clientes_online_ids($db);
        if ($idsOnCnt) $nOnline = (int)$db->query("SELECT COUNT(*) FROM ws_cliente c2 WHERE c2.status<>'cancelado' AND c2.id IN (" . implode(',', array_map('intval', $idsOnCnt)) . ")"
            . ($ramalAtivo ? " AND (c2.ramal_id=" . (int)$ramalAtivo['id'] . " OR c2.ramal_id IS NULL)" : ""))->fetchColumn();
    } catch (Throwable $e) {}
    /* CONTAGEM DO BOTÃO "OBSERVAÇÃO" — tem de usar EXATAMENTE o mesmo critério do filtro.
     *
     * O filtro aceita as duas origens (contrato em confiança OU status='observacao'), então a
     * contagem também. Contar só a confiança faria o botão dizer "(12)" e a lista abrir com 13 —
     * e número que não bate com a própria lista destrói a confiança no resto da tela.
     *
     * COUNT(DISTINCT) sobre ws_cliente, e não sobre ws_contrato: cliente com dois contratos em
     * confiança é UM cliente na lista. */
    $nConf = (int)$db->query("SELECT COUNT(*) FROM ws_cliente c3
                              WHERE (EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c3.id
                                            AND ct.confianca_ate IS NOT NULL AND ct.confianca_ate>NOW())
                                     OR c3.status='observacao'" . ws_obs_auto_sql('c3') . ")"
                            . ($ramalAtivo ? " AND (c3.ramal_id=" . (int)$ramalAtivo['id'] . " OR c3.ramal_id IS NULL)" : ""))->fetchColumn();
    $nRec = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE status<>'cancelado' AND criado_em >= DATE_FORMAT(CURDATE(), '%Y-%m-01')" . $cntAnd)->fetchColumn();
    ?>
    <div class="ws-head-row">
      <h2>👥 Clientes<?php if ($ramalAtivo): ?> <span class="ws-tag" style="font-size:11px;font-weight:700">📍 <?= h($ramalAtivo['cidade']) ?> — <?= h($ramalAtivo['nome']) ?></span><?php endif; ?></h2>
      <a class="ws-btn ws-btn-fx" href="erp.php?p=cliente">Novo cliente</a>
      <a class="ws-btn" style="margin-left:8px;background:#10b981;color:#fff;border-color:#059669" href="erp.php?p=clientes_csv<?= $fstatus ? '&status='.h($fstatus) : '' ?>" target="_blank">📄 Baixar CSV</a>
    </div>
      <?php $nOffline = max(0, ($cnt['ativo'] ?? 0) - $nOnline); ?>
    <div class="ws-search ws-cli-filtros">
      <?php /* O botão "Confiança" SAIU: era o mesmo que "Observação", e um dos dois vivia zerado.
               Ficou um só, com o rótulo "Observação" (o nome usado nas outras telas) e o conteúdo
               da confiança (onde os clientes realmente estão). Ver o filtro em ws_clientes_where.
               O botão "Observação" agora é destacado por $fstatus valer 'observacao' OU 'confianca',
               para um link antigo continuar acendendo o botão certo. */ ?>
      <?php foreach (['' => 'Todos','ativo'=>'Ativos','bloqueado'=>'Bloqueados','observacao'=>'Observação','cancelado'=>'Desativados','recentes'=>'Recentes'] as $k=>$v):
        $n = $k === '' ? (array_sum($cnt) - ($cnt['cancelado'] ?? 0)) : ($k==='observacao' ? $nConf : ($k==='recentes' ? $nRec : ($cnt[$k] ?? 0)));
        $aceso = ($fstatus === $k) || ($k === 'observacao' && $fstatus === 'confianca'); ?>
        <a class="ws-btn <?= $aceso?'primary':'' ?>" href="erp.php?p=clientes<?= $k?"&status=$k":'' ?><?= $busca?'&q='.urlencode($busca):'' ?>"><?= h($v) ?> (<?= $n ?>)</a>
      <?php endforeach; ?>
    </div>
    <!-- BUSCA DE CLIENTES — barra única.
         Eram três controles soltos lado a lado (select + input + botão), cada um com sua borda,
         parecendo três campos sem relação. Agora é UMA barra: o seletor de campo à esquerda, a
         lupa, o texto, um ✕ para limpar e o botão à direita — tudo dentro da mesma moldura, que
         acende no foco. -->
    <form class="ws-busca-bar"><input type="hidden" name="p" value="clientes"><?php if($fstatus): ?><input type="hidden" name="status" value="<?= h($fstatus) ?>"><?php endif; ?>
      <?php /* obs1 — VLAN entrou na lista de "onde procurar": o técnico costuma ter só a VLAN em
               mãos (veio do concentrador ou da OLT) e precisava varrer a lista no olho. */ ?>
      <div class="ws-busca-campo">
        <?php /* Trocar o campo APLICA na hora (submete o formulário) quando já existe algo
                 digitado. Antes era preciso escolher "Tudo" e ainda clicar em Buscar — quem
                 escolhia e esperava o resultado concluía, com razão, que o seletor não filtrava. */ ?>
        <select name="campo" aria-label="Onde procurar"
                onchange="if(this.form.querySelector('[name=q]').value.trim()!=='') this.form.submit();">
          <?php foreach (['tudo'=>'Tudo','nome'=>'Nome','login'=>'Login','ip'=>'IP','vlan'=>'VLAN','venc'=>'Dia de vencimento','mac'=>'MAC / SN ONU / ONT','endereco'=>'Endereço','cpf'=>'CPF/CNPJ','id'=>'ID'] as $k=>$v)
            echo "<option value='$k' ".($campo===$k?'selected':'').">".h($v)."</option>"; ?>
        </select>
      </div>
      <?php /* obs1 — ÍCONE DE VOLTAR, discreto, à esquerda da lupa. Só aparece quando há busca ou
               filtro ativo: é o caminho de volta para a lista inteira depois de pesquisar, sem
               obrigar o operador a caçar o "Todos" lá em cima. Sumindo quando não há o que
               desfazer, ele nunca vira enfeite. */ ?>
      <?php if ($busca !== '' || $fstatus !== ''): ?>
        <a class="ws-busca-voltar" href="erp.php?p=clientes" title="Voltar para a lista completa" aria-label="Voltar para a lista completa">↺</a>
      <?php endif; ?>
      <span class="ws-busca-lupa" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="17" height="17"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="1.9"/><path d="M16 16l4.5 4.5" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>
      </span>
      <input name="q" type="text" id="wsBuscaCli" class="ws-busca-txt" autocomplete="off"
             placeholder="Digite aqui o que deseja encontrar" value="<?= h($busca) ?>">
      <?php if ($busca !== ''): ?>
        <a class="ws-busca-limpar" title="Limpar busca" aria-label="Limpar busca"
           href="erp.php?p=clientes<?= $fstatus ? '&status='.h($fstatus) : '' ?>">&times;</a>
      <?php endif; ?>
      <button class="ws-busca-btn" type="submit">Buscar</button>
    </form>
    <div class="ws-head-row" style="margin:6px 0">
      <span class="ws-muted" style="font-size:13px"><?= number_format($total,0,',','.') ?> cliente(s) · mostrando <?= count($rows) ?></span>
      <label style="font-size:13px;display:flex;align-items:center;gap:6px">Por página
        <select onchange="location=this.value" style="width:auto;padding:6px 10px;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text)">
          <?php foreach ([25=>'25',50=>'50',100=>'100',0=>'Todos'] as $opt=>$lbl): ?>
            <option value="erp.php?p=clientes&pp=<?= $opt . h($baseqs) ?>" <?= $pp===$opt?'selected':'' ?>><?= $lbl ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
    <table class="ws-table"><thead><tr>
      <th class="sel"><input type="checkbox" id="selall" onclick="wsSelAll(this)" title="selecionar todos"></th>
      <th class="ws-th-esq">Nome <a href="erp.php?p=cliente" title="Novo cliente" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;background:var(--brand);color:#fff;border-radius:6px;font-weight:900;font-size:18px;text-decoration:none;line-height:1;vertical-align:middle;margin-left:6px;box-shadow:0 1px 3px rgba(0,0,0,.25)">+</a></th><th style="text-align:center;white-space:nowrap;position:relative;padding-left:34px"><span id="wsInstBtn" class="ws-inst-btn" role="button" tabindex="0" aria-haspopup="true" aria-expanded="false" title="Instalados recentes — do mais novo para o mais antigo"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17V5M3.5 8.5 7 5l3.5 3.5"/><path d="M17 7v12M13.5 15.5 17 19l3.5-3.5"/></svg></span>Login</th><th style="text-align:center">Plano</th><th style="text-align:center">VLAN</th><th style="text-align:center">IP</th><th style="text-align:center">CPF/CNPJ</th><th style="text-align:center">Celular</th><th style="text-align:center">Cidade</th><th style="text-align:center">Situação</th><th style="text-align:center">Ações</th>
    </tr></thead><tbody>
    <style>
    /* Seta verde dos instalados recentes: a MESMA seta da tarja do topo, sem caixa, encostada na
       divisa entre o vinho escuro (Nome) e o vinho claro (Login). */
    /* CANCELADOS: nome do cliente em vermelho nítido (inline na própria lista, não depende do CSS externo). */
    tr[id^="cli"].ws-row-cancelado td a.ws-nome,tr[id^="cli"].ws-row-cancelado td a.ws-nome b{color:#D00000 !important;font-weight:800 !important;opacity:1 !important;text-shadow:none !important;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}
    :root[data-theme="dark"] tr[id^="cli"].ws-row-cancelado td a.ws-nome,:root[data-theme="dark"] tr[id^="cli"].ws-row-cancelado td a.ws-nome b{color:#FF4545 !important}
    @media(prefers-color-scheme:dark){:root:not([data-theme="light"]) tr[id^="cli"].ws-row-cancelado td a.ws-nome,:root:not([data-theme="light"]) tr[id^="cli"].ws-row-cancelado td a.ws-nome b{color:#FF4545 !important}}
    /* 📋 COPIAR NOME — botão fixo na própria lista, DEPOIS do selo verde dos boletos (e do "Adicional"). */
    /* O botão NÃO ocupa espaço na linha (largura 0): a célula do nome, a tarja e as colunas ficam EXATAMENTE como eram.
       O ícone é desenhado por ::before, flutuando logo à direita dos selos. */
    .wsnc{display:inline!important}
    .wsnc-b{display:inline-block;position:relative;width:0;height:1em;margin:0;padding:0;border:0;background:transparent;overflow:visible;vertical-align:middle;cursor:pointer;color:inherit;font-size:0}
    .wsnc-b::before{content:"📋";position:absolute;left:6px;top:50%;transform:translateY(-50%);font-size:16px;line-height:1;opacity:0;transition:opacity .12s;padding:3px;border-radius:5px}
    .wsnc-b.ok::before{content:"✓";font-weight:800;color:#16A34A}
    tr:hover .wsnc-b::before,.wsnc-b:focus::before{opacity:.95}
    .wsnc-b:hover::before{background:rgba(127,127,127,.18)}
    @media (hover:none){.wsnc-b::before{opacity:.65}}
    .ws-inst-btn{position:absolute;left:-2px;top:50%;transform:translateY(-50%);display:inline-flex;align-items:center;justify-content:center;
                 padding:3px;border-radius:6px;color:#4ade80;opacity:.9;cursor:pointer;transition:opacity .15s,background-color .15s}
    .ws-inst-btn:hover,.ws-inst-btn:focus-visible,.ws-inst-btn[aria-expanded="true"]{opacity:1;background:rgba(255,255,255,.12);outline:none}
    </style>
    <script>
    /* 📋 COPIAR NOME (lista de clientes): copia o nome do botão clicado e mostra ✓ por 1s. */
    document.addEventListener('click',function(e){
      var b=e.target.closest?e.target.closest('.wsnc-b'):null; if(!b) return;
      e.preventDefault(); e.stopPropagation();
      var t=b.getAttribute('data-nome')||'', ok=function(){b.classList.add('ok');setTimeout(function(){b.classList.remove('ok');},1000);};
      var velho=function(){var x=document.createElement('textarea');x.value=t;x.style.cssText='position:fixed;left:-9999px;opacity:0';document.body.appendChild(x);x.select();try{document.execCommand('copy');ok();}catch(er){prompt('Copie:',t);}document.body.removeChild(x);};
      if(navigator.clipboard&&window.isSecureContext) navigator.clipboard.writeText(t).then(ok,velho); else velho();
    },true);
    </script>
    <script>
    /* INSTALADOS RECENTES — ícone verde antes do título "Login": contratos pela data de ativação, do mais
       novo para o mais antigo (mesma cidade/ramal do topo). Buscado só no clique. */
    (function(){ function ligar(){ if(!window.wsPopLista) return;
      wsPopLista(document.getElementById('wsInstBtn'), {
        url: function(d){ return 'conexoes_recentes.php?tipo=instalados&d='+encodeURIComponent(d); },
        abas: [{id:'instalados', rot:'🏠 Instalados recentes'}],
        periodos: [['30','30 dias'], ['7','7 dias'], ['90','90 dias']],
        vazio: function(aba, d){ return 'Nenhuma instalação nos últimos '+d.dias+' dias.'; },
        item: function(i, aba, n){
          var quando = i.dias===0 ? 'hoje' : (i.dias===1 ? 'ontem' : 'há '+i.dias+' dias');
          var sub = [i.login, i.plano, i.tipo, i.cidade].filter(function(x){ return x; }).map(wsEsc).join(' · ');
          return '<a class="ws-conex-item" href="erp.php?p=cliente&id='+i.cliente_id+'"><span class="o">'+(n+1)+'</span><span class="n">'+wsEsc(i.nome)+'<small>'+sub+'</small></span><span class="t">'+wsEsc(i.data)+'<br>'+quando+'</span></a>';
        }
      }); }
      if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', ligar); else ligar(); })();
    </script>
    <script>
    /* VOLTOU DO RESUMO (#cliID): centraliza a linha do cliente e destaca por 2 s — sem rolar à procura. */
    (function(){ function ir(){ var m=/^#cli(\d+)$/.exec(location.hash||''); if(!m) return; var tr=document.getElementById('cli'+m[1]); if(!tr) return;
        tr.scrollIntoView({block:'center'}); var o=tr.style.outline; tr.style.outline='2px solid var(--brand)'; tr.style.outlineOffset='-2px';
        setTimeout(function(){ tr.style.outline=o; }, 2200); }
      if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', ir); else ir(); })();
    /* RESUMO COMPACTO AO PASSAR O MOUSE no nome resumido (erp.php?ajax=resumo_cli). O clique continua
       abrindo a página de resumo completa, como antes. Carrega uma vez por cliente (cache). */
    (function(){
      var box=null, timer=null, alvo=null, cache={}, tHide=null;   // tHide: folga de 120 ms; o cartão encosta no nome (sem vão), então dá para entrar nele e clicar no link azul; fica enquanto o mouse estiver no nome ou no cartão (09/10/2026)
      function caixa(){ if(box) return box; box=document.createElement('div');
        box.style.cssText='position:absolute;z-index:100200;width:max-content;max-width:min(560px,94vw);min-width:230px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:10px;padding:10px 12px;font-size:12.5px;line-height:1.55;box-shadow:0 12px 30px -10px rgba(0,0,0,.45);display:none';
        box.addEventListener('mouseenter', function(){ clearTimeout(tHide); }); box.addEventListener('mouseleave', agendarEsconder); document.body.appendChild(box); return box; }
      function posicionar(el){ var r=el.getBoundingClientRect(), b=caixa();
        /* (09/10/2026) nome perto do pé da tela: o cartão SOBE (sobrepõe a linha de cima) em vez de ficar cortado atrás da barra de baixo; e não passa da borda direita */
        var h=b.offsetHeight, w=b.offsetWidth, vh=window.innerHeight, vw=window.innerWidth, rodape=64;
        var cabeEmbaixo=(r.bottom-2+h) <= (vh-rodape), cima=!cabeEmbaixo && (r.top+2-h) >= 4;
        var left=Math.max(8, Math.min(r.left, vw-w-8));
        b.style.left=(window.scrollX+left)+'px';
        b.style.top=(window.scrollY+(cima ? r.top+2-h : (cabeEmbaixo ? r.bottom-2 : Math.max(4, vh-rodape-h))))+'px'; }   // encosta (2 px de sobreposição) no nome: sem vão por onde o mouse "saia"
      function mostrar(el){ var id=el.getAttribute('data-cli'); if(!id) return; var b=caixa();
        if(cache[id]){ b.innerHTML=cache[id]; b.style.display='block'; posicionar(el); return; }
        b.innerHTML='<span style="opacity:.7">Carregando…</span>'; b.style.display='block'; posicionar(el);
        fetch('erp.php?ajax=resumo_cli&id='+encodeURIComponent(id),{credentials:'same-origin'}).then(function(r){return r.text();})
          .then(function(t){ cache[id]=t; if(alvo===el){ b.innerHTML=t; posicionar(el); } }).catch(function(){ b.innerHTML='<span style="opacity:.7">Não consegui carregar.</span>'; }); }
      function esconder(){ clearTimeout(timer); clearTimeout(tHide); alvo=null; if(box) box.style.display='none'; }
      function agendarEsconder(){ clearTimeout(timer); clearTimeout(tHide); tHide=setTimeout(esconder, 120); }   /* folga mínima de 120 ms: some quando o mouse sai do nome E do cartão */
      document.addEventListener('mouseover', function(e){ var el=e.target.closest && e.target.closest('.ws-resumo-hover'); if(el) clearTimeout(tHide); if(!el || el===alvo) return;
        clearTimeout(tHide); alvo=el; clearTimeout(timer); timer=setTimeout(function(){ if(alvo===el) mostrar(el); }, 450); });
      document.addEventListener('mouseout', function(e){ var el=e.target.closest && e.target.closest('.ws-resumo-hover'); if(!el) return;
        var para=e.relatedTarget; if(para && (el.contains(para) || (box && box.contains(para)))) return; agendarEsconder(); });
      document.addEventListener('click', function(e){ if(e.target.closest && e.target.closest('.ws-resumo-hover')) esconder(); }, true);
    })();
    </script>
    <?php foreach ($rows as $r):
      $emConf = !empty($r['conf_ate']) && strtotime((string)$r['conf_ate']) > time();
      $stag = ['ativo'=>'ativo','bloqueado'=>'bloqueado','suspenso'=>'suspenso','inativo'=>'inativo','cancelado'=>'cancelado','observacao'=>'observacao'][$r['status']] ?? 'inativo';
      if ($emConf && ($r['status'] ?? '') !== 'cancelado') $stag = 'confianca';   // cancelado fica SEMPRE vermelho (confiança não sobrepõe)
      // Destaque pulsante quando vindo do alerta de bloqueio manual (fácil identificação).
      $destPulse = (($_GET['destaque'] ?? '') === 'manual' && $r['status'] === 'bloqueado' && !empty($r['bloq_manual'])) ? ' ws-pulse-alert' : ''; ?>
      <?php /* data-login normalizado (só letras e números): é a chave com que o endpoint de
               uptime devolve as conexões, a MESMA normalização usada no painel. */ ?>
      <tr id="cli<?= (int)$r['id'] ?>" class="ws-row-<?= $stag ?><?= $destPulse ?>" data-login="<?= h(strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)($r['login'] ?? '')))) ?>">
        <td class="sel"><input type="checkbox" class="selcli" value="<?= $r['id'] ?>"></td>
        <td class="ws-th-esq"><span class="ws-cp wsnc"><a href="erp.php?p=cliente&id=<?= $r['id'] ?>" class="ws-nome"><b><?= h($r['nome']) ?></b></a><?php if (!empty($r['abertos'])): ?><a class="ws-badge-bol" href="erp.php?p=cliente&id=<?= $r['id'] ?>#titulos" title="<?= (int)$r['abertos'] ?> boleto(s) em aberto — abre a ficha na tarja dos títulos"><?= (int)$r['abertos'] ?></a><?php endif; ?><?php if (!empty($r['titular_id'])): ?><span class="ws-badge-add" title="Cliente adicional">👥 Adicional</span><?php endif; ?><button type="button" class="wsnc-b" data-nome="<?= h($r['nome']) ?>" title="Copiar o nome" aria-label="Copiar o nome"></button></span>
          <?php $cnc = $cncOnline[$r['login']] ?? null; ?>
          <?php if (isset($r['venc_dia'])):
                  /* Boleto "bate" com o dia do contrato se cai no próprio dia ou até 3 dias depois
                     (dia que caiu em fim de semana/feriado vai para o próximo dia útil: 25 -> 26). */
                  $vd = (int)$r['venc_dia']; $vp = (string)($r['venc_prox'] ?? ''); $okVenc = true;
                  if ($vp !== '') { $dv = (int)date('j', strtotime($vp)); $dif = ($dv - $vd + 31) % 31; $okVenc = $dif <= 3; } ?>
            <div style="font-size:11.5px;margin-top:2px;color:<?= $okVenc ? 'var(--muted)' : 'var(--bad,#dc2626)' ?>;font-weight:<?= $okVenc ? '600' : '800' ?>">
              📅 dia <?= $vd ?> · <?= $vp !== '' ? 'próximo boleto ' . h(date('d/m/Y', strtotime($vp))) . ($okVenc ? '' : ' ⚠ não bate com o dia do contrato') : 'sem boleto em aberto' ?>
            </div>
          <?php endif; ?>
          <div class="ws-sub-nome">
            <?php if (!empty($r['nome_resumido'])): echo ws_copiavel_assets(); ?><span class="ws-muted" style="display:inline-flex;align-items:center"><?= ws_copiavel($r['nome_resumido'], '<a href="erp.php?p=cliente_resumo&id='.$r['id'].'" target="_blank" class="ws-resumo-hover" data-cli="'.(int)$r['id'].'" title="Abrir resumo em nova aba" style="color:inherit;text-decoration:none">'.h($r['nome_resumido']).'</a>') ?></span><?php endif; ?>
            <?php /* CNC-1 / CNC-2 — mesma grafia do resto do sistema. A cor separa um do outro
                     de relance: azul forte no principal, azul claro no secundário. */
                  if ($cnc): $cncCurto = ws_cnc_curto($cnc); $cncIx = ws_cnc_indice($cnc);
                  // A etiqueta é um LINK: leva ao Painel dos Concentradores já no concentrador (?cnc=IP)
                  // e DIRETO NESTE CLIENTE (?cliente=login): a busca vem preenchida e a janela dele abre.
                  $cncIp = $ipsCnc[$r['login']] ?? ''; ?>
              <a class="ws-tag-cnc c<?= $cncIx ?: 1 ?>" href="servidores.php?<?= h(http_build_query(array_filter(['cnc' => $cncIp, 'cliente' => (string)($r['login'] ?? '')], 'strlen'))) ?>"
                 title="Conectado no <?= h($cnc) ?> — abrir este cliente no Painel dos Concentradores"><?= h($cncCurto) ?></a>
            <?php endif; ?>
            <?php if ($stag === 'bloqueado'): ?>
              <a href="#" class="ws-icone-bloqueio ws-icone-vermelho" title="Bloqueado — clique pra liberar em confiança (escolher data)"
                 onclick="wsConfiar(<?= $r['id'] ?>,0,'','<?= h(addslashes($r['nome'])) ?>','<?= h(addslashes($r['login'] ?? '')) ?>');return false" title="Confiar (liberar temporariamente)"><?= ws_icon('cadeado') ?></a>
            <?php elseif ($stag === 'confianca'): ?>
              <a href="#" class="ws-icone-bloqueio ws-icone-lilas" title="Em confiança — clique pra alterar prazo (mesma caixa de data)"
                 onclick="wsConfiar(<?= $r['id'] ?>,1,'<?= h(date('d/m/Y',strtotime((string)$r['conf_ate']))) ?>','<?= h(addslashes($r['nome'])) ?>','<?= h(addslashes($r['login'] ?? '')) ?>');return false"><?= ws_icon('desbloqueio') ?></a>
            <?php endif; ?>
          </div>
          <!-- Menu de ações rápidas — aparece abaixo do nome ao MARCAR a caixa de seleção do cliente. -->
          <div class="ws-cli-menu">
            <a href="#" onclick="wsNotaCli(<?= (int)$r['id'] ?>, this);return false" data-nota="<?= h((string)($r['obs'] ?? '')) ?>" data-nome="<?= h($r['nome']) ?>" title="<?= trim((string)($r['obs'] ?? '')) !== '' ? h(mb_substr((string)$r['obs'], 0, 200)) : 'Escrever uma nota neste cliente' ?>"><?= trim((string)($r['obs'] ?? '')) !== '' ? '📝 Nota ●' : '📝 Nota' ?></a>
            <a href="erp.php?p=cliente&id=<?= $r['id'] ?>" title="Alterar dados do cliente">Alterar</a>
            <a href="erp.php?p=contrato&<?= !empty($r['contrato_id']) ? 'id='.(int)$r['contrato_id'] : 'cliente='.$r['id'] ?>" title="Detalhes da conexão do cliente">Detalhes</a>
            <a href="financeiro.php?p=faturas&q=<?= urlencode($r['login'] ?: $r['nome']) ?>" title="Página dos boletos do cliente (enviar, imprimir, receber, excluir…)">Boleto</a>
            <a href="chamados.php?p=novo&cliente=<?= $r['id'] ?>" title="Gerenciar chamados deste cliente">Chamados</a>
            <?php if (!empty($r['login'])): ?><a href="mk_monitor.php?acao=log&login=<?= urlencode($r['login']) ?>" target="_blank" title="Monitorar conexões do cliente">Conexões</a><?php endif; ?>
            <a href="documentos.php?cliente=<?= $r['id'] ?>" target="_blank" title="Ver documentos e anexos">Documentos</a>
            <?php if (!empty($r['login'])): ?>
            <!-- RESSINCRONIZAR CONEXÃO: derruba e reinicia a sessão do cliente para ele
                 reautenticar do zero. Resolve "autenticado mas não navega", IP preso de sessão
                 antiga e perfil desatualizado depois de mudar plano ou desbloquear.
                 Mexe SÓ na conectividade — não altera cadastro nem apaga nada. -->
            <a href="#" onclick="wsRessincronizar('<?= h(addslashes($r['login'])) ?>', this); return false"
               style="color:#0ea5e9" title="Ressincronizar: derruba e reinicia a sessão (não altera cadastro)">🔄 Ressincronizar</a>
            <?php endif; ?>
            <a href="erp.php?p=adicional&titular=<?= $r['id'] ?>" title="Cadastrar dependente/adicional">Adicionais</a>
            <?php // Bloquear/Desbloquear — só um aparece conforme o estado. Adicional age individual (não cascateia).
              $indParam = !empty($r['titular_id']) ? '&individual=1' : '';
              // Volta para a MESMA lista (com a busca e a página), e não para a lista zerada — sem pesquisar o nome de novo.
              $voltaAtual = urlencode('erp.php?' . ((string)($_SERVER['QUERY_STRING'] ?? '') ?: 'p=clientes' . ($fstatus ? '&status='.$fstatus : '')));
              if ($r['status'] !== 'cancelado'): ?>
              <?php if ($r['status'] === 'bloqueado'): ?>
                <a href="erp.php?cli_desbloquear=<?= $r['id'] ?><?= $indParam ?>&volta=<?= $voltaAtual ?>" style="color:var(--ok)" title="Desbloquear o cliente<?= !empty($r['titular_id'])?' (só ele)':' (e seus adicionais)' ?>">🔓 Desbloquear</a>
              <?php else: ?>
                <a href="erp.php?cli_bloquear=<?= $r['id'] ?><?= $indParam ?>&volta=<?= $voltaAtual ?>" onclick="return confirm('Bloquear <?= !empty($r['titular_id'])?'este adicional':'este cliente e seus adicionais' ?>?')" style="color:var(--err)" title="Bloquear o cliente<?= !empty($r['titular_id'])?' (só ele)':' (e seus adicionais)' ?>">🔒 Bloquear</a>
              <?php endif; ?>
            <?php endif; ?>
            <?php if ($r['status']==='bloqueado' || $emConf): ?>
              <a href="#" onclick="wsConfiar(<?= $r['id'] ?>,<?= $emConf?1:0 ?>,'<?= $emConf?h(date('d/m/Y',strtotime((string)$r['conf_ate']))):'' ?>','<?= h(addslashes($r['nome'])) ?>','<?= h(addslashes($r['login'] ?? '')) ?>');return false" style="color:#9333ea">Confiar</a>
            <?php endif; ?>
          </div>
        </td>
        <?php /* LOGIN — o clique continua copiando o login, exatamente como antes. A novidade é o
                 HOVER: mostra a senha da conexão, que o suporte precisa ditar no telefone e hoje
                 obriga a abrir a ficha do cliente só para ler. A senha entra no tooltip, não na
                 tela: ninguém que passe pela mesa vê a coluna cheia de senhas. */
              $senhaCon = ws_recursos()['mostrar_senhas'] ? trim((string)($r['senha_con'] ?? '')) : '';   // "Mostrar senhas" (Recursos do sistema)
              $dicaLogin = $senhaCon !== '' ? ('Senha: ' . $senhaCon . ' · clique para copiar o login')
                                            : 'Clique para copiar o login'; ?>
        <td style="text-align:center"><code class="ws-copy" data-tip="<?= h($dicaLogin) ?>" title="<?= h($dicaLogin) ?>"><?= h($r['login'] ?: '—') ?></code></td>
        <td style="text-align:center" title="<?= h($r['plano_nome'] ?: '') ?>"><?= h(ws_plano_fmt($r['plano_nome'] ?? '', $r['plano_valor'] ?? null)) ?></td>
        <td style="text-align:center"><?= $r['vlan'] ? '<span class="ws-tag ativo">'.h($r['vlan']).'</span>' : '<span class="ws-muted">—</span>' ?></td>
        <?php /* COLUNA IP (obs2) — o mesmo endereço em dois estados bem diferentes:
                 ONLINE  → verde e clicável (monitor/ping/gráfico): é o IP que vale agora.
                 OFFLINE → o ÚLTIMO IP que o concentrador entregou, cinza e riscado, com cara de
                           desabilitado. Continua legível para conferir log e faixa, mas ninguém
                           confunde com conexão ativa. O IP é dinâmico: troca de concentrador,
                           troca de IP, e o valor aqui acompanha sozinho. */ ?>
        <?php /* Os três ícones soltos (gráfico, ping, log) saíram da coluna: eram três alvos
                 minúsculos repetidos em cada linha, poluindo a tabela inteira. As funções não se
                 perderam — o próprio IP abre o monitor, que já traz log, ping e gráfico na
                 mesma tela. Um clique, um destino. */ ?>
        <td style="text-align:center"><?php $ipOn = $ipsOnline[$r['login']] ?? null; $ipUlt = $r['ultimo_ip'] ?? null; if ($ipOn): ?>
          <a href="mk_monitor.php?acao=log&login=<?= urlencode($r['login']) ?>&ip=<?= urlencode($ipOn) ?>" target="_blank" class="ws-ip on" title="Conectado agora — abrir o monitor do cliente (log, ping e gráfico de tráfego)"><?= h($ipOn) ?></a>
        <?php elseif ($ipUlt): ?>
          <span class="ws-ip off" title="Offline — último IP recebido do concentrador"><?= h($ipUlt) ?></span>
        <?php else: ?><span class="ws-muted">—</span><?php endif; ?></td>
        <td style="text-align:center"><span class="ws-copy" data-tip="Clique para copiar o CPF/CNPJ" title="Clique para copiar o CPF/CNPJ"><?= h_doc($r['cpf_cnpj']) ?></span></td><td style="text-align:center"><span class="ws-copy" data-copy="<?= h(preg_replace('/\D/','',(string)$r['celular'])) ?>" data-tip="Clique para copiar o celular" title="Clique para copiar o celular"><?= h_fone($r['celular']) ?></span><?= ws_wa_icone($r['celular'], 'Abrir no WhatsApp', (int)$r['id']) ?></td><td style="text-align:center"><?= h($r['cidade']) ?></td>
        <?php /* SITUAÇÃO — no hover, o TEMPO DE CONEXÃO da sessão atual (uptime lido do
                 concentrador). Saber há quanto tempo o cliente está conectado é a primeira
                 pergunta de qualquer atendimento de "está caindo": sessão de 2 minutos conta uma
                 história bem diferente de uma de 12 dias. Cliente offline não tem uptime, e aí o
                 tooltip continua sendo o que já era. */
              $uptCli = $uptOnline[$r['login']] ?? '';
              /* $tituloBase = a parte do tooltip que NÃO muda (confiança). O JS de 30 em 30
                 segundos reescreve só o tempo de conexão em cima dela — sem isso, a atualização
                 apagaria o aviso de confiança junto. */
              $tituloBase = $emConf
                  ? 'Desbloqueio em confiança até ' . date('d/m/Y H:i\h', strtotime((string)$r['conf_ate']))
                  : '';
              $tituloSit = $tituloBase;
              if ($uptCli !== '') $tituloSit = ($tituloSit !== '' ? $tituloSit . ' · ' : '') . 'Conectado há ' . $uptCli;
              elseif ($tituloSit === '' && !empty($r['login'])) $tituloSit = 'Sem sessão ativa no concentrador'; ?>
        <?php /* data-tip-live no lugar do title: o tempo de conexão precisa CONTINUAR contando
                 enquanto a dica está aberta, e o title do navegador é desenhado uma vez e não muda
                 mais. data-tip-seg guarda os segundos lidos e data-tip-em o instante da leitura —
                 com os dois, a dica calcula o tempo de AGORA a cada segundo. */
              $segIni = ''; if ($uptCli !== '') { $pp2 = array_map('intval', explode(':', preg_replace('/^\d+[d.]\s*/i', '', $uptCli)));
                  if (count($pp2) === 3) $segIni = (string)($pp2[0]*3600 + $pp2[1]*60 + $pp2[2]);
                  elseif (count($pp2) === 2) $segIni = (string)($pp2[0]*60 + $pp2[1]);
                  if ($segIni !== '' && preg_match('/^(\d+)[d.]/i', $uptCli, $md)) $segIni = (string)((int)$segIni + (int)$md[1]*86400); } ?>
        <td style="text-align:center"><span class="ws-tag ws-sit <?= $stag ?>"
              data-base="<?= h($tituloBase) ?>" data-tip-base="<?= h($tituloBase) ?>"
              <?= $segIni !== '' ? 'data-tip-seg="'.h($segIni).'" data-tip-em="'.(time()*1000).'"' : '' ?>
              data-tip-live="1"><?= $emConf ? 'confiança' : h(ws_status_rotulo($r['status'])) ?></span><?php if ($r['status']==='bloqueado' && !empty($r['bloq_manual'])): ?><br><span style="font-size:10px;font-weight:700;color:#b91c1c" title="Bloqueado manualmente pelo operador — não desbloqueia sozinho mesmo sem dívida">🔒 manual</span><?php endif; ?><?php if ($r['status']==='cancelado' && !empty($r['data_desativacao'])): ?><br><span class="ws-muted" style="font-size:11px" title="Data de desativação">🗓 <?= h(date('d/m/Y', strtotime((string)$r['data_desativacao']))) ?></span><?php endif; ?></td>
        <td style="text-align:center;white-space:nowrap"><?php if ($r['status']==='cancelado'): ?><?php else: ?><?= ws_desativar_modal_js() ?><a href="erp.php?cli_desativar=<?= $r['id'] ?>" onclick="return wsDesativar(this, <?= h(json_encode((string)($r['nome'] ?? ''), JSON_UNESCAPED_UNICODE)) ?>)" title="Desativar cliente (cancela e remove do RADIUS)" style="color:var(--warn)">Desativar</a><?php endif; ?>
          · <a href="erp.php?cli_del=<?= $r['id'] ?>" onclick="return confirm('Deseja realmente excluir o cliente &quot;<?= h($r['nome']) ?>&quot; e todos os seus contratos/boletos? Esta ação é irreversível.')" style="color:var(--err)" title="Excluir cadastro do cliente">deletar</a>
          <?php if ($r['status']==='cancelado'): ?>
            · <a href="erp.php?cli_reativar=<?= $r['id'] ?>" onclick="return confirm('Reativar este cliente?')" style="color:var(--ok)">↻ reativar</a>
          <?php endif; ?></td>
      </tr>
    <?php endforeach; if (!$rows) echo '<tr><td colspan="11" class="ws-muted">Nenhum cliente nesta situação.</td></tr>'; ?>
    </tbody></table>
    <?php /* DESTAQUE VINDO DO ALERTA: além de pulsar (classe ws-pulse-alert), a página ROLA até a
             linha e a deixa no meio da tela. Sem isto, o cliente podia estar abaixo da dobra e o
             clique no alerta parecia não ter feito nada. Rola só quando a linha não está visível,
             e de forma suave — se o operador já está olhando para ela, a tela não pula. */
       if (($_GET['destaque'] ?? '') === 'manual'): ?>
    <script>(function(){
      function ir(){
        var l=document.querySelector('tr.ws-pulse-alert'); if(!l) return;
        var r=l.getBoundingClientRect(), dentro=(r.top>=80 && r.bottom<=(window.innerHeight-40));
        if(!dentro){ try{ l.scrollIntoView({behavior:'smooth',block:'center'}); }catch(e){ l.scrollIntoView(); } }
        /* Reinicia a animação: se a página demorou a carregar, o pulso já teria acabado. */
        l.classList.remove('ws-pulse-alert'); void l.offsetWidth; l.classList.add('ws-pulse-alert');
      }
      if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',ir); else ir();
    })();</script>
    <?php endif; ?>
    <?php /* SELETOR DE PÁGINA — no fim da própria lista, não no rodapé fixo.
             Aqui havia dois: o do rodapé fixo (que fica flutuando na tela o tempo todo) e o do
             fim da página. Ficou UM só, o modelo novo (.ws-pag), imprimido logo depois da
             tabela: aparece quando o operador rola até o fim da lista, que é o momento em que
             ele quer trocar de página, e não rouba espaço da tela o resto do tempo. */ ?>
    <?= ws_pager_html($pg, $paginas, "erp.php?p=clientes&pp=$pp$baseqs") ?>
    <script>
      /* TEMPO DE CONEXÃO SEMPRE ATUAL (30s).
         O tooltip da coluna Situação nasce com a página e envelhece junto: numa tela aberta a
         tarde toda, "conectado há 4 min" continua escrito quando já são duas horas — e o
         atendente repassa esse número ao cliente. A cada 30 segundos o tempo é relido do mesmo
         cache de conexões do Painel e reescrito em cima da parte fixa do tooltip (o aviso de
         confiança, que não pode ser apagado junto).
         Pausa quando a aba está em segundo plano: ninguém lê tooltip que não está vendo. */
      (function () {
        function atualizar() {
          if (document.hidden) return;
          fetch('erp.php?acao=conexao_uptime', { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (d) {
              if (!d || !d.ok || !d.uptimes) return;
              /* Ressincroniza a DICA, não o title: guarda os segundos lidos e o instante da
                 leitura. Quem desenha o tempo é a dica, de segundo em segundo — e assim ela
                 continua correndo mesmo entre duas consultas. */
              document.querySelectorAll('tr[data-login]').forEach(function (tr) {
                var tag = tr.querySelector('.ws-sit'); if (!tag) return;
                var k = tr.dataset.login || ''; if (!k) return;
                var seg = (typeof wsUptimeSeg === 'function') ? wsUptimeSeg(d.uptimes[k] || '') : null;
                if (seg === null || isNaN(seg)) {
                  delete tag.dataset.tipSeg; delete tag.dataset.tipEm;   // caiu: some o relógio
                } else {
                  tag.dataset.tipSeg = String(seg);
                  tag.dataset.tipEm  = String(Date.now());
                }
              });
            })
            .catch(function () { /* falha de leitura não altera o que está na tela */ });
        }
        setInterval(atualizar, 30000);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) atualizar(); });
      })();
    </script>
    <div id="selbar" class="ws-selbar hidden">
      <b id="selcount">0</b> selecionado(s) ·
      <a href="#" id="selBloquear" onclick="wsSelAcao('bloquear');return false">Bloquear</a> ·
      <a href="#" id="selDesbloquear" onclick="wsSelAcao('desbloquear');return false">Desbloquear</a> ·
      <a href="#" onclick="wsSelAcao('excluir');return false" style="color:var(--err)">Excluir</a> ·
      <a href="#" onclick="wsSelLimpar();return false" class="ws-muted">limpar</a>
    </div>
    <script>
      window.WS_DIAS_CONFIANCA = <?= (int)ws_dias_confianca() ?>;
      // Selecionou só 1 cliente: mostra só a ação que faz sentido (bloqueado→só Desbloquear,
      // senão→só Bloquear). Com 2+ selecionados, mostra as duas (não dá pra saber o status de
      // todos de uma vez sem mais uma consulta).
      document.querySelectorAll('.selcli').forEach(function(cb){
        cb.addEventListener('change', function(){
          var tr0 = cb.closest('tr'); if (tr0) tr0.classList.toggle('ws-sel', cb.checked); // mostra o menu de ações
          var marcados = document.querySelectorAll('.selcli:checked');
          var bBloq = document.getElementById('selBloquear'), bDesbloq = document.getElementById('selDesbloquear');
          if (marcados.length === 1) {
            var tr = marcados[0].closest('tr');
            var ehBloqueado = tr && tr.classList.contains('ws-row-bloqueado');
            bBloq.style.display = ehBloqueado ? 'none' : '';
            bDesbloq.style.display = ehBloqueado ? '' : 'none';
          } else { bBloq.style.display = ''; bDesbloq.style.display = ''; }
        });
      });
    /**
     * RESSINCRONIZAR CONEXÃO — derruba e reinicia a sessão do cliente.
     * Só conectividade: nenhum dado de cadastro é tocado. O link vira "⏳ ressincronizando…"
     * enquanto trabalha e volta ao normal com o resultado no title.
     */
    function wsRessincronizar(login, el){
      login = String(login || '').trim();
      if (!login) return;
      if (!confirm('Ressincronizar a conexão de "' + login + '"?\n\n' +
                   'A sessão cai agora e reconecta em alguns segundos, já com o perfil atualizado.\n' +
                   'Nenhum dado de cadastro é alterado.')) return;

      var txt = el ? el.innerHTML : '';
      if (el) { el.innerHTML = '⏳ ressincronizando…'; el.style.pointerEvents = 'none'; }

      var corpo = new URLSearchParams();
      corpo.append('login', login);
      fetch('erp.php?acao=ressincronizar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: corpo.toString()
      })
      .then(function(r){ return r.json(); })
      .catch(function(){ return { status: 'erro', message: 'falha de comunicação' }; })
      .then(function(d){
        if (el) {
          el.innerHTML = (d && d.status === 'ok') ? '✅ ressincronizado' : '⚠️ ' + txt;
          el.title = (d && d.message) ? d.message : '';
          setTimeout(function(){ el.innerHTML = txt; el.style.pointerEvents = ''; }, 6000);
        }
        if (d && d.status !== 'ok') {
          alert('Não consegui derrubar a sessão.\n\n' + ((d && d.message) || '') +
                '\n\nSe o cliente estiver offline, não há sessão para reiniciar.');
        }
      });
    }

    /**
     * Desbloqueio em confiança na lista de Clientes.
     * O fluxo compartilhado (aviso de "já em confiança", desbloqueios do mês e aceite) vem de
     * js/ws_confianca.js -> wsConfianca(). Antes esta tela chamava o calendário direto e era a
     * ÚNICA sem o aviso — mesma ação com comportamento diferente de tela para tela.
     */
    function wsConfiar(id, emconf, ate, nome, login){
      wsConfianca({
        login: login || '',
        clienteId: id,
        nome: nome || '',
        jaEmConfiancaAte: emconf ? ate : '',
        onConfirmar: function(dias){ location = 'erp.php?cli_confiar=' + id + '&aviso_ok=1&dias=' + dias + '&volta=' + encodeURIComponent(location.pathname.split('/').pop() + location.search); }
      });
    }
    function wsSelAll(c){document.querySelectorAll('.selcli').forEach(e=>e.checked=c.checked);wsSelUpd();}
    function wsSelUpd(){var n=document.querySelectorAll('.selcli:checked').length;
      document.getElementById('selcount').textContent=n;
      document.getElementById('selbar').classList.toggle('hidden',n===0);}
    function wsSelLimpar(){document.querySelectorAll('.selcli,#selall').forEach(e=>e.checked=false);wsSelUpd();}
    function wsSelAcao(acao){var ids=[...document.querySelectorAll('.selcli:checked')].map(e=>e.value);
      if(!ids.length)return;
      if(!confirm(acao+' '+ids.length+' cliente(s)?'))return;
      window.location='erp.php?p=clientes&lote='+acao+'&ids='+ids.join(',');}
    document.addEventListener('change',function(e){if(e.target.classList.contains('selcli'))wsSelUpd();});
    // Clique pra COPIAR (nome, login, senha, ID, IP, celular, CPF, nome resumido) — mostra ✔ no título.
    document.addEventListener('click',function(e){
      var el=e.target.closest('.ws-copy'); if(!el) return;
      var t=(el.dataset.copy||el.textContent||'').trim(); if(!t||t==='—') return;
      if(navigator.clipboard) navigator.clipboard.writeText(t).catch(function(){});
      var o=el.getAttribute('data-tip')||'Clique para copiar'; el.classList.add('ws-copied'); el.setAttribute('title','✔ Copiado!');
      setTimeout(function(){el.classList.remove('ws-copied'); el.setAttribute('title',o);},1200);
    });
    </script>
    <?php
}

/* --------- Ficha do cliente (form + contratos) --------- */
function ws_view_cliente(PDO $db): void {
    $id = (int)($_GET['id'] ?? 0); $c = null;
    if ($id) { $st = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $st->execute([$id]); $c = $st->fetch();
        /* Endereço do CADASTRO normalizado para preencher o formulário. Sem isto, abrir a ficha e
         * salvar apagaria o endereço: os campos viriam vazios e seriam gravados vazios. */
        require_once __DIR__ . "/schema_endereco.php";
        if ($c) $c = ws_end_enriquecer($db, $c); }
    // Cliente de uma cidade que não está liberada para este login: não abre (nem pelo endereço da página).
    if ($c && !empty($c['ramal_id']) && !ws_ramal_permitido((int)$c['ramal_id'])) {
        echo '<div class="ws-alert err">❌ Este cliente é de uma cidade que não está liberada para o seu login.</div>'; return;
    }
    // Novo ADICIONAL: já mostra PRÉ-PREENCHIDO os dados do TITULAR (identificação/contato/endereço) —
    // continua editável e, se algo ficar vazio, o salvar herda do titular de novo (dupla garantia).
    if (!$id && !empty($_GET['titular'])) {
        $tt = $db->prepare("SELECT cpf_cnpj,rg_ie,inscricao_municipal,email,celular,telefone,cep,logradouro,numero,complemento,bairro,cidade,uf,lat,lng,ramal_id,data_cadastro FROM ws_cliente WHERE id=?");
        $tt->execute([(int)$_GET['titular']]);
        if ($td = $tt->fetch(PDO::FETCH_ASSOC)) {
            // Titular sem data_cadastro salva (comum em cadastro antigo) = NULL, e NULL ?? cai
            // pro fallback como se não tivesse vindo nada. Sem isto aqui, o campo virava hoje de
            // novo, calado, mesmo com a busca acima certa.
            if (empty($td['data_cadastro'])) $td['data_cadastro'] = date('Y-m-d');
            $c = $td;
        }
    }
    // Novo cliente pode vir PRÉ-PREENCHIDO da aba OLT (?pre=1&nome=...&cidade=...): usa o GET como fallback.
    // Se voltou aqui por causa de uma confirmação pendente (CPF duplicado / cidade diferente),
    // usa o que a pessoa tinha digitado antes — sem isso, ela perderia o formulário inteiro.
    $repost = $_SESSION['ws_form_repost'] ?? null; unset($_SESSION['ws_form_repost']);
    $g = fn($k) => h($repost[$k] ?? ($c[$k] ?? ($_GET[$k] ?? '')));
    $sel = fn($k,$v) => ((($repost[$k] ?? $c[$k] ?? '')) == $v ? 'selected' : '');
    ?>
    <?php if (!empty($_GET['pago'])): $pgId = (int)$_GET['pago']; ?>
    <div id="wsPagoOv" class="ws-modal-ov ws-rc" style="display:flex"><div class="ws-modal" style="max-width:380px;overflow:hidden;padding:0">
      <div class="ws-rc-head" style="text-align:center"><h3 style="margin:0">✅ Recebido com sucesso!</h3></div>
      <div style="padding:18px 16px;text-align:center">
        <p style="margin:0 0 14px">Pagamento do título <b>#<?= $pgId ?></b> registrado.</p>
        <div style="display:flex;gap:8px;justify-content:center">
          <a class="ws-btn primary" href="recibo.php?fatura=<?= $pgId ?>&print=1" target="_blank">🖨️ Recibo</a>
          <button type="button" class="ws-btn" onclick="document.getElementById('wsPagoOv').style.display='none'">Fechar</button>
        </div>
        <p class="ws-muted" style="font-size:11px;margin:12px 0 0">Fecha sozinha em <span id="wsPagoSeg">5</span>s…</p>
      </div>
    </div></div>
    <script>(function(){var s=5,el=document.getElementById('wsPagoSeg'),ov=document.getElementById('wsPagoOv');if(!ov)return;
      // Limpa ?pago= e ?ok= da URL pra que F5 apenas ATUALIZE a página (sem reabrir o recibo).
      try{if(window.history&&history.replaceState){var u=new URL(location.href);u.searchParams.delete('pago');u.searchParams.delete('ok');history.replaceState(null,'',u.pathname+(u.search||'')+u.hash);}}catch(e){}
      ov.addEventListener('click',function(e){if(e.target===ov)ov.style.display='none';});
      var t=setInterval(function(){s--;if(el)el.textContent=s;if(s<=0){clearInterval(t);ov.style.display='none';}},1000);})();</script>
    <?php endif; ?>
    <?php $ehAdic = !empty($c['titular_id']) || !empty($_GET['titular']);
          $abrev = trim((string)($c['nome_resumido'] ?? ''));
          $titularIdRef = (int)($c['titular_id'] ?? $_GET['titular'] ?? 0);
          $nomeAtual = trim((string)($c['nome'] ?? ''));
          // Título = NOME do cliente (não mais o texto genérico "Cadastro Cliente Titular/Adicional"),
          // pra deixar claro de cara de QUEM é esta ficha — titular e adicional usam o MESMO padrão.
          $tituloTop = $id ? ($nomeAtual ?: ($ehAdic ? 'Cliente adicional' : 'Cliente')) : ($ehAdic ? 'Novo cliente adicional' : 'Novo cliente'); ?>

    <?php if ($ehAdic && $titularIdRef):
      $tnb = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $tnb->execute([$titularIdRef]); $tnbNome = $tnb->fetchColumn(); ?>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;background:rgba(147,51,234,.10);color:#9333ea;border:1px solid #9333ea;border-radius:10px;padding:10px 14px;margin-bottom:6px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:14px">
          <span style="font-weight:800">👥 CLIENTE ADICIONAL</span>
          <span>vinculado ao titular <a href="erp.php?p=cliente&id=<?= $titularIdRef ?>" style="color:#1e293b;text-decoration:underline;font-weight:800"><?= h($tnbNome) ?></a></span>
        </div>
        <a href="erp.php?p=cliente&id=<?= $titularIdRef ?>" class="ws-btn" style="background:#fff">← Voltar ao titular</a>
      </div>
      <p class="ws-muted" style="font-size:12px;margin:0 0 16px">Cadastro, conexão, boletos e chamados aqui embaixo são <b>100% independentes</b> — só deste adicional, não do titular.</p>
    <?php endif; ?>

    <?php /* Nome do cliente e nome resumido no título: 📋 copiar ao passar o mouse, IGUAL ao das
             tarjas dos adicionais (ws_copiavel). Só quando a ficha já existe. Assets antes do <h2>. */
          if ($id) echo ws_copiavel_assets(); ?>
    <style>
      /* Título da ficha: nome + nome resumido + selos numa linha só, alinhados e juntinhos; o 📋 de copiar
         só ocupa espaço (à direita do texto) enquanto o mouse está em cima. */
      .ws-tit-cli{display:flex;align-items:center;flex-wrap:wrap;gap:4px 8px}
      .ws-tit-cli .ws-cp{gap:0}
      .ws-tit-cli .ws-cp-b{width:0;padding:0;overflow:hidden;opacity:0;transition:width .12s,opacity .12s}
      .ws-tit-cli .ws-cp:hover .ws-cp-b,.ws-tit-cli .ws-cp-b:focus{width:18px;opacity:.85}
      @media (hover:none){.ws-tit-cli .ws-cp-b{width:18px;opacity:.55}}
      .ws-tit-cli .ws-tag{margin-left:0!important}
    </style>
    <div class="ws-head-row"><h2 class="ws-tit-cli"><?= $id && $nomeAtual !== '' ? ws_copiavel($nomeAtual) : h($tituloTop) ?><?php if ($abrev && $id): ?><span class="ws-muted" style="font-size:14px;font-weight:600"><?= ws_copiavel($abrev, '(' . h($abrev) . ')') ?></span><?php endif; ?><?php if ($ehAdic): ?><span class="ws-badge-add">Adicional</span><?php endif; ?>
      <?php if ($id): [$sc,$lb,$cor] = ws_score_cliente($db, $id); ?>
        <span class="ws-tag" title="Score de pagamento" style="background:rgba(37,99,235,.14);color:#2563eb;font-size:10.5px;padding:1px 7px;vertical-align:middle;margin-left:4px">score <?= $sc ?> · <?= h($lb) ?></span>
      <?php endif; ?>
      <?php if ($id): 
          $temComodato = (bool)$db->query("SELECT 1 FROM ws_contrato WHERE cliente_id=".(int)$id." AND comodato=1 LIMIT 1")->fetchColumn();
          if ($temComodato): ?>
            <?php $fotoComod = '';
            try { $qc = $db->prepare("SELECT equip_serial, equip_mac, equip_modelo FROM ws_contrato WHERE cliente_id=? AND comodato=1 ORDER BY id DESC");
                  $qc->execute([(int)$id]);
                  $nz = fn($s) => preg_replace('/[^A-Z0-9]/', '', mb_strtoupper((string)$s, 'UTF-8'));
                  $eqs = $db->query("SELECT modelo, serial, mac, foto FROM ws_equipamento WHERE foto IS NOT NULL AND foto<>'' ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
                  foreach ($qc->fetchAll(PDO::FETCH_ASSOC) as $ctc) {
                      $ks = $nz($ctc['equip_serial']); $km = $nz($ctc['equip_mac']); $kd = $nz($ctc['equip_modelo']);
                      foreach ([0, 1] as $passo) {   // 1º serial/MAC do aparelho; 2º o MODELO do cadastro de Equipamentos
                          foreach ($eqs as $eq) {
                              $ok = $passo === 0 ? (($ks !== '' && $nz($eq['serial']) === $ks) || ($km !== '' && $nz($eq['mac']) === $km))
                                                 : ($kd !== '' && $nz($eq['modelo']) !== '' && ($nz($eq['modelo']) === $kd || strpos($kd, $nz($eq['modelo'])) !== false || strpos($nz($eq['modelo']), $kd) !== false));
                              if ($ok && is_file(ws_caminho_fisico($eq['foto']))) { $fotoComod = $eq['foto']; break 3; }
                          }
                      }
                  }
            } catch (Throwable $e) {}
            if ($fotoComod !== ''): ?>
            <?php /* Foto do comodato em MINIATURA: o clique abre um cartãozinho junto ao selo (não a imagem em página
                     inteira). Fecha ao clicar fora ou com Esc; Ctrl/Shift-clique ainda abre a imagem inteira. */ ?>
            <style>
              .ws-comod{position:relative;display:inline-block;vertical-align:middle;margin-left:4px}
              .ws-comod .ws-comod-pop{display:none;position:absolute;top:calc(100% + 6px);left:0;z-index:60;background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:6px;box-shadow:0 8px 24px rgba(15,23,42,.22);text-align:center;font-size:11px;font-weight:600;line-height:1.3;white-space:nowrap}
              .ws-comod.aberto .ws-comod-pop{display:block}
              .ws-comod .ws-comod-pop img{display:block;max-width:180px;max-height:130px;width:auto;height:auto;object-fit:contain;border-radius:6px;margin:0 auto 4px}
              .ws-comod .ws-comod-pop a{color:#2563eb;text-decoration:underline}
            </style>
            <span class="ws-comod">
              <a class="ws-tag suspenso" href="<?= h(ws_img($fotoComod)) ?>" title="Ver foto do equipamento" style="font-size:10.5px;padding:1px 7px;vertical-align:middle;text-decoration:none;cursor:pointer" onclick="if(event.ctrlKey||event.metaKey||event.shiftKey||event.button===1)return true;event.preventDefault();this.parentNode.classList.toggle('aberto');return false;">Cliente com Equip. em comodato</a>
              <span class="ws-comod-pop" role="dialog" aria-label="Foto do equipamento em comodato">
                <img src="<?= h(ws_img($fotoComod)) ?>" alt="Equipamento em comodato" loading="lazy">
                <a href="<?= h(ws_img($fotoComod)) ?>" target="_blank" rel="noopener">ampliar</a>
              </span>
            </span>
            <script>
              if (!window.__wsComodFoto) { window.__wsComodFoto = 1;
                document.addEventListener('click', function (e) { document.querySelectorAll('.ws-comod.aberto').forEach(function (w) { if (!w.contains(e.target)) w.classList.remove('aberto'); }); });
                document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.ws-comod.aberto').forEach(function (w) { w.classList.remove('aberto'); }); });
              }
            </script>
            <?php else: ?>
            <span class="ws-tag suspenso" title="Sem foto cadastrada para o equipamento" style="font-size:10.5px;padding:1px 7px;vertical-align:middle;margin-left:4px">Cliente com Equip. em comodato</span>
            <?php endif; ?>
      <?php endif; endif; ?><?php if ($id && ($c['status'] ?? '') === 'cancelado') echo ws_tarja_equip_desativado($db, (int)$id); ?></h2>
      <div style="display:flex;gap:8px;align-items:center">
        <?php if ($id): ?><a class="ws-btn" href="documentos.php?cliente=<?= $id ?>" target="_blank">📄 Documentos</a>
        <a class="ws-btn" href="chamados.php?p=novo&cliente=<?= $id ?>">🛠️ Abrir chamado</a>
        <?php /* Desativar direto da ficha (03/10/2026) — a mesma ação do "Desativar" da lista, voltando para esta ficha. */
              if (($c['status'] ?? '') === 'cancelado'): ?>
          <a class="ws-btn" href="erp.php?cli_reativar=<?= $id ?>" onclick="return confirm('Reativar este cliente?')" style="color:var(--ok)">↻ Reativar</a>
        <?php else: ?>
          <?= ws_desativar_modal_js() ?><a class="ws-btn" href="erp.php?cli_desativar=<?= $id ?>&volta=ficha" onclick="return wsDesativar(this, <?= h(json_encode((string)($c['nome'] ?? ''), JSON_UNESCAPED_UNICODE)) ?>)" style="color:var(--err)" title="Desativar cliente (cancela, remove do RADIUS e limpa os dados de acesso)">⛔ Desativar</a>
        <?php endif; ?><?php endif; ?>
        <a href="erp.php?p=clientes" title="Voltar para Cliente Todos" aria-label="Voltar para Cliente Todos" style="color:#dc2626;font-weight:800;font-size:17px;text-decoration:none;margin-left:4px" onmouseover="this.style.color='#991b1b'" onmouseout="this.style.color='#dc2626'">↺</a>
      </div></div>
    <?php if ($id && !$ehAdic): ws_chips_adicionais($db, $id); endif; ?>
    <form method="post" class="ws-form grid" id="ws_form_cliente" onsubmit="var b=document.getElementById('ws_btn_salvar_cliente'); if(b.dataset.enviado)return false; b.dataset.enviado='1'; b.disabled=true; b.textContent='Salvando...';">
      <input type="hidden" name="acao" value="salvar_cliente">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="titular_id" value="<?= h($c['titular_id'] ?? $_GET['titular'] ?? '') ?>">
      <?php if (!empty($_GET['titular']) && !$id): ?><div class="c4 ws-alert ok" style="margin:0">Cadastrando <b>adicional</b> do titular #<?= (int)$_GET['titular'] ?>.</div><?php endif; ?>
      <div class="c4 ws-alert err" id="ws_dup_titular" style="display:none;margin:0">
        <div id="ws_dup_msg"></div>
      </div>

      <?php /* LAYOUT EM 8 COLUNAS (só neste formulário, telas > 820px): campos curtos ocupam menos,
               e as linhas ficam: Nome | Nome resumido | Data de cadastro — Tipo | CPF/CNPJ | RG/IE |
               Nascimento — Status | E-mail | Celular-1 | Celular-2 — CEP | Logradouro | Número |
               Complemento — Bairro | Cidade | UF | Latitude | Longitude. No celular vale a regra geral
               do css/wellsystem.css (2 colunas e depois 1), sem mudança. */ ?>
      <style>
        @media (min-width:821px){
          #ws_form_cliente{grid-template-columns:repeat(8,minmax(0,1fr))}
          #ws_form_cliente>label{grid-column:span 2}
          #ws_form_cliente>.c2{grid-column:span 4}
          #ws_form_cliente>.c4{grid-column:span 8}
          #ws_form_cliente>.cm{grid-column:span 1}
          #ws_form_cliente>.c3{grid-column:span 3}
        }
      </style>
      <style>
        /* 19/11/2026 — alinhamento limpo da ficha do cliente: rótulos no topo, caixas com a mesma altura
           e o mesmo espaçamento em todas as linhas (sem o "auto" esticando uma coluna e não a outra). */
        #ws_form_cliente>label:not(.ws-chk),
        #ws_id4>label,#ws_ident5>label,#ws_end4>label,#ws_end5>label,#ws_cob4>label,#ws_cob3>label{
          justify-content:flex-start!important;align-items:stretch;gap:4px;min-width:0}
        #ws_form_cliente .ws-auto-badge{align-self:flex-start}
        #ws_form_cliente input:not([type=checkbox]):not([type=radio]),
        #ws_form_cliente select{height:38px;box-sizing:border-box;margin-top:0!important;width:100%}
        #ws_form_cliente>label>span:not(.ws-auto-badge){margin-top:0!important}
        #ws_id4,#ws_ident5,#ws_end4,#ws_end5,#ws_cob4,#ws_cob3{align-items:start}
      </style>
      <style>
        #ws_idA,#ws_idB,#ws_endA,#ws_endB{display:grid;gap:12px 14px;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}
        #ws_form_cliente>#ws_idA,#ws_form_cliente>#ws_idB,#ws_form_cliente>#ws_endA,#ws_form_cliente>#ws_endB{grid-column:1 / -1!important}
        #ws_idA>label,#ws_idB>label,#ws_endA>label,#ws_endB>label{display:flex;flex-direction:column;justify-content:flex-start;gap:4px;min-width:0;width:100%}
        #ws_idA input,#ws_idA select,#ws_idB input,#ws_idB select,#ws_endA input,#ws_endB input{height:38px;box-sizing:border-box;width:100%;margin-top:0}
        #ws_endB .ws-auto-badge{align-self:flex-start}
        @media (min-width:821px){
          #ws_idA,#ws_idB,#ws_endA,#ws_endB{grid-template-columns:repeat(12,minmax(0,1fr))}
          .gs2{grid-column:span 2}.gs3{grid-column:span 3}.gs4{grid-column:span 4}
        }
      </style>
      <div class="c4 ws-secao">Identificação</div>
      <div class="c4" id="ws_idA">
      <label class="gs4">Nome / Razão social <?= ws_campo_cc('<input name="nome" required value="' . $g('nome') . '">') ?></label>
      <label class="gs2">Tipo <select name="tipo"><option value="PF" <?= $sel('tipo','PF') ?>>Pessoa Física</option><option value="PJ" <?= $sel('tipo','PJ') ?>>Pessoa Jurídica</option></select></label>
      <label class="gs2">CPF/CNPJ <?= ws_campo_cc('<input name="cpf_cnpj" inputmode="numeric" maxlength="18" oninput="this.value=this.value.replace(/[^0-9]/g,\'\')" value="' . $g('cpf_cnpj') . '">') ?></label>
      <label class="gs2" title="Código do cliente (gerado automaticamente)">Código <input value="<?= $id ? h(ws_cliente_codigo($db, (int)$id, $c['codigo'] ?? null)) : 'auto' ?>" readonly tabindex="-1" style="background:var(--bg);font-weight:700;text-align:center"></label>
      <label class="gs2">Nascimento <input type="date" name="data_nasc" value="<?= $g('data_nasc') ?>"></label>
      </div>
      <div class="c4" id="ws_idB">
      <label class="gs4">Nome resumido <?= ws_campo_cc('<input name="nome_resumido" value="' . $g('nome_resumido') . '" placeholder="apelido/abreviação">') ?></label>
      <label class="gs2">RG <input name="rg_pf" id="ws_rg_pf" value="<?= (($ct_tipo_rg = ($c['tipo'] ?? 'PF')) !== 'PJ') ? $g('rg_ie') : '' ?>" placeholder="só Pessoa Física"></label>
      <label class="gs2">IE <input name="ie_pj" id="ws_ie_pj" value="<?= (($c['tipo'] ?? '') === 'PJ') ? $g('rg_ie') : '' ?>" placeholder="só Pessoa Jurídica"></label>
      <script>
      /* 19/11/2026: RG só para Pessoa Física; IE só para Pessoa Jurídica (o outro fica desativado). */
      (function(){
        var t=document.querySelector('#ws_form_cliente select[name="tipo"]'), rg=document.getElementById('ws_rg_pf'), ie=document.getElementById('ws_ie_pj');
        if(!t||!rg||!ie) return;
        function ajusta(){ var pj=t.value==='PJ'; rg.disabled=pj; ie.disabled=!pj; rg.style.opacity=pj?'.45':''; ie.style.opacity=pj?'':'.45'; }
        t.addEventListener('change',ajusta); ajusta();
      })();
      </script>
      <label class="gs2">Inscrição municipal <input name="inscricao_municipal" id="ws_im" value="<?= $g('inscricao_municipal') ?>" maxlength="30" placeholder="só Pessoa Jurídica"></label>
      <label class="gs2">Data de cadastro <input type="date" name="data_cadastro" value="<?= $g('data_cadastro') ?: date('Y-m-d') ?>"></label>
      </div>
      <?php /* 18/11/2026: Tipo, CPF/CNPJ, RG/IE, Inscrição municipal e Nascimento na MESMA linha, do mesmo tamanho (5 colunas iguais). Inscrição municipal só vale para Pessoa Jurídica: em Pessoa Física o campo fica bloqueado. */ ?>
      <script>
      (function(){
        var t=document.querySelector('#ws_form_cliente select[name="tipo"]'), im=document.querySelector('#ws_form_cliente input[name="inscricao_municipal"]');
        if(!t||!im) return;
        function ajusta(){ var pf=t.value==='PF'; im.readOnly=pf; im.style.opacity=pf?'.45':''; im.style.cursor=pf?'not-allowed':''; im.tabIndex=pf?-1:0; im.placeholder=pf?'só Pessoa Jurídica':'Inscrição municipal'; im.title=pf?'Inscrição municipal só para Pessoa Jurídica':''; }
        t.addEventListener('change',ajusta); ajusta();
      })();
      </script>

      <div class="c4 ws-secao">Contato</div>
      <label>Status <select name="status">
        <?php foreach (['ativo','bloqueado','cancelado','observacao'] as $s) echo "<option value=\"$s\" ".$sel('status',$s).">".ws_status_rotulo($s)."</option>"; ?>
      </select></label>
      <label>E-mail <input type="email" name="email" value="<?= $g('email') ?>"></label>
      <?php /* Celular-1 (antigo "Celular") e Celular-2 (antigo "Telefone"): só o RÓTULO mudou — os
               campos no banco continuam `celular` e `telefone`, então nada que lê o cadastro quebra. */
            $waMini = '<svg width="13" height="13" viewBox="0 0 32 32" fill="#25D366" style="vertical-align:-2px" aria-hidden="true"><path d="M16 3C9.4 3 4 8.4 4 15c0 2.4.7 4.6 1.9 6.5L4 29l7.7-1.9A12 12 0 0 0 16 27c6.6 0 12-5.4 12-12S22.6 3 16 3z"/></svg>'; ?>
      <label><span style="margin-top:0"><?= $waMini ?> Celular-1<b id="ws_wa_ok1" title="Número com WhatsApp confirmado" style="display:none;color:#16a34a;font-weight:800;margin-left:5px">✓</b></span> <span style="position:relative;display:block">
        <input name="celular" id="ws_celular" style="width:100%;padding-right:34px" value="<?= $g('celular') ?>" oninput="wsAtualizaWa()">
        <span id="ws_wa_prev"><?= ws_wa_icone($c['celular'] ?? null, 'Abrir no WhatsApp', $id ?: null, true) ?></span>
      </span></label>
      <?php /* O telefone fixo também recebe o ícone verde: muitos cadastros antigos têm o número
               de WhatsApp gravado AQUI, e não no campo Celular — e quem atende precisava copiar o
               número na mão. O ícone é o mesmo, com o mesmo nome, e leva ao mesmo destino. */ ?>
      <label><span style="margin-top:0"><?= $waMini ?> Celular-2<b id="ws_wa_ok2" title="Número com WhatsApp confirmado" style="display:none;color:#16a34a;font-weight:800;margin-left:5px">✓</b></span> <span style="position:relative;display:block">
        <input name="telefone" id="ws_telefone" style="width:100%;padding-right:34px" value="<?= $g('telefone') ?>" oninput="wsAtualizaWaTel()">
        <span id="ws_wa_prev_tel"><?= ws_wa_icone($c['telefone'] ?? null, 'Abrir no WhatsApp', $id ?: null, true) ?></span>
      </span></label>
      <script>
        /* Um desenho só para os DOIS campos (celular e telefone): o ícone aparece e some conforme
           o número fica válido, sem recarregar a página. O DESTINO vem do PHP — assim o link do
           ícone recém-digitado é o mesmo do ícone que já estava na tela, inclusive quando o
           provedor aponta para uma plataforma de atendimento em vez do wa.me. */
        var WS_WA_SVG = '<svg width="15" height="15" viewBox="0 0 32 32" fill="#25D366" style="vertical-align:middle"><path d="M16.001 3C9.373 3 4 8.373 4 15c0 2.386.697 4.605 1.902 6.47L4 29l7.72-1.865A11.94 11.94 0 0 0 16.001 27C22.63 27 28 21.627 28 15S22.63 3 16.001 3zm6.965 17.06c-.297.836-1.47 1.53-2.406 1.73-.64.137-1.475.246-4.287-.92-3.598-1.49-5.913-5.14-6.093-5.38-.18-.24-1.458-1.94-1.458-3.7 0-1.76.92-2.62 1.246-2.98.326-.36.71-.45.947-.45.237 0 .474.002.68.013.218.012.51-.083.798.61.297.71 1.008 2.47 1.096 2.65.088.18.147.39.03.63-.12.24-.18.39-.356.6-.178.21-.373.47-.533.63-.18.18-.366.373-.157.733.208.36.926 1.53 1.988 2.478 1.366 1.22 2.518 1.598 2.878 1.778.36.18.57.15.78-.09.208-.24.89-1.04 1.128-1.397.238-.36.475-.3.802-.18.326.12 2.073.978 2.43 1.156.356.18.593.27.68.42.09.15.09.87-.207 1.71z"/></svg>';
        var WS_WA_CLIENTE = <?= $id ? (int)$id : 0 ?>;
        var WS_WA_TPL = <?= json_encode(ws_wa_link_destino('%TEL%'), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
        function wsWaHref(n){
          if (WS_WA_CLIENTE) return 'wa_abrir.php?tel=' + n + '&cliente=' + WS_WA_CLIENTE;
          return WS_WA_TPL.indexOf('%TEL%') >= 0 ? WS_WA_TPL.replace('%TEL%', encodeURIComponent(n)) : WS_WA_TPL;
        }
        function wsWaPinta(idCampo, idAlvo){
          var campo = document.getElementById(idCampo), alvo = document.getElementById(idAlvo);
          if (!campo || !alvo) return;
          var v = campo.value.replace(/\D/g,'');
          if (v.length >= 10) {
            var n = v.length <= 11 ? '55'+v : v;
            alvo.innerHTML = '<a href="' + wsWaHref(n) + '" target="_blank" title="Abrir no WhatsApp" style="position:absolute;right:9px;top:50%;transform:translateY(-50%);text-decoration:none;line-height:0;z-index:2">' + WS_WA_SVG + '</a>';
          } else { alvo.innerHTML = ''; }
        }
        /* ✓ verde = número CONFIRMADO como WhatsApp (15/10); sem confirmação, sem ✓. Pergunta ao servidor 0,8 s depois de parar de digitar. */
        var wsWaTimers = {};
        function wsWaValida(idCampo, idOk){ var el = document.getElementById(idCampo), ok = document.getElementById(idOk); if (!el || !ok) return; ok.style.display = 'none'; clearTimeout(wsWaTimers[idOk]);
          var n = (el.value || '').replace(/\D/g, ''); if (n.length < 10) return;
          wsWaTimers[idOk] = setTimeout(function(){ fetch('erp.php?acao=wa_validar&n=' + encodeURIComponent(n), {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(d){ if (document.getElementById(idCampo) && (document.getElementById(idCampo).value || '').replace(/\D/g, '') === n) ok.style.display = (d && d.v === true) ? 'inline' : 'none'; }).catch(function(){}); }, 800); }
        function wsAtualizaWa(){ wsWaPinta('ws_celular', 'ws_wa_prev'); wsWaValida('ws_celular', 'ws_wa_ok1'); }
        function wsAtualizaWaTel(){ wsWaPinta('ws_telefone', 'ws_wa_prev_tel'); wsWaValida('ws_telefone', 'ws_wa_ok2'); }
        wsWaValida('ws_celular', 'ws_wa_ok1'); wsWaValida('ws_telefone', 'ws_wa_ok2');
      </script>

      <div class="c4 ws-secao">Endereço</div>
      <div class="c4" id="ws_endA">
      <label class="gx4">Logradouro <input name="logradouro" id="logradouro" value="<?= $g('logradouro') ?>"></label>
      <label class="gx2">Apartamento ou casa <select name="apto_casa"><option value="" <?= $g('apto_casa')==='' ? 'selected' : '' ?>>—</option><option value="Casa" <?= $g('apto_casa')==='Casa' ? 'selected' : '' ?>>Casa</option><option value="Apartamento" <?= $g('apto_casa')==='Apartamento' ? 'selected' : '' ?>>Apartamento</option></select></label>
      <label class="gx2">Complemento <input name="complemento" value="<?= $g('complemento') ?>"></label>
      <label class="gx1">Número <input name="numero" value="<?= $g('numero') ?>"></label>
      <label class="gx1">CEP <span class="ws-auto-badge" title="Preenchido pela cidade/UF ou pelo ViaCEP">auto</span> <input name="cep" id="cep" value="<?= $g('cep') ?>"></label>
      </div>
      <div class="c4" id="ws_endB">
      <label class="gx2">Bairro <input name="bairro" id="bairro" list="ws_dl_bairros" value="<?= $g('bairro') ?>" placeholder="digite ou escolha"></label>
      <label class="gx2">Cidade <input name="cidade" id="cidade" list="ws_dl_cidades" value="<?= $g('cidade') ?>" placeholder="digite ou escolha"></label>
      <label class="gx2">UF <span class="ws-auto-badge" title="Preenchido automaticamente pela cidade">auto</span> <input name="uf" id="uf" maxlength="2" list="ws_ufs" value="<?= $g('uf') ?>"></label>
      <label class="gx2">Latitude <span class="ws-auto-badge" id="geo_badge" title="Preenchido pela cidade/UF ou pelo CEP">auto</span> <input name="lat" id="lat" value="<?= $g('lat') ?>"></label>
      <label class="gx2">Longitude <input name="lng" id="lng" value="<?= $g('lng') ?>"></label>
      </div>
      <style>
        /* 19/11/2026: Endereço em grade de 10 colunas nas duas linhas, para as divisões ficarem alinhadas de cima para baixo. */
        @media (min-width:821px){
          #ws_endA,#ws_endB{grid-template-columns:repeat(10,minmax(0,1fr))!important}
          .gx4{grid-column:span 4}.gx2{grid-column:span 2}.gx1{grid-column:span 1}
        }
      </style>
      <?php /* 19/11/2026: os 9 campos do endereço do cliente numa linha só, tamanho igual (desktop). */ ?>
      <?php $cidadesMap = $db->query("SELECT nome,uf,cep FROM ws_cidade WHERE ativo=1 ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC); ?>
      <datalist id="ws_dl_cidades"><?php foreach ($cidadesMap as $cm) echo '<option value="' . h($cm['nome']) . '">'; ?></datalist>
      <datalist id="ws_dl_bairros"><?php foreach ($db->query("SELECT nome FROM ws_bairro WHERE ativo=1 ORDER BY nome")->fetchAll(PDO::FETCH_COLUMN) as $bn) echo '<option value="' . h($bn) . '">'; ?></datalist>
      <script>
      // Ao digitar/escolher a Cidade, preenche UF e CEP automáticos (do cadastro de Cidades) só onde
      // estiver vazio — continua tudo editável. Não dispara o ViaCEP (evita sobrescrever o que já veio).
      (function(){
        var mapa = <?= json_encode(array_column(array_map(function($c){return ['k'=>mb_strtoupper($c['nome'],'UTF-8'),'uf'=>$c['uf'],'cep'=>$c['cep']];}, $cidadesMap), null, 'k'), JSON_UNESCAPED_UNICODE) ?>;
        var inpC=document.getElementById('cidade'), inpU=document.getElementById('uf'), inpCep=document.getElementById('cep');
        function auto(){ if(!inpC) return; var d=mapa[(inpC.value||'').trim().toUpperCase()]; if(!d) return;
          if(inpU && d.uf && !inpU.value.trim()) inpU.value=d.uf;
          if(inpCep && d.cep && !inpCep.value.trim()) inpCep.value=d.cep; }
        if(inpC){ inpC.addEventListener('input',auto); inpC.addEventListener('change',auto); auto(); }
      })();
      </script>
      <datalist id="ws_ufs"><?php foreach (['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'] as $u) echo "<option value=\"$u\">"; ?></datalist>
      <script>
      // Geocodifica sozinho: assim que Cidade+UF estão preenchidos (e lat/lng vazios) busca as coordenadas;
      // e ATUALIZA lat/lng quando o CEP é digitado (8 dígitos). Tudo continua editável. Fonte: OpenStreetMap/Nominatim.
      (function(){
        var iC=document.getElementById('cidade'),iU=document.getElementById('uf'),iCep=document.getElementById('cep'),
            iLat=document.getElementById('lat'),iLng=document.getElementById('lng'),bd=document.getElementById('geo_badge');
        if(!iLat||!iLng) return; var t=null,lastQ='';
        function set(la,lo){ if(la&&lo){iLat.value=(+la).toFixed(6);iLng.value=(+lo).toFixed(6);if(bd){bd.textContent='ok';bd.style.background='#16a34a';bd.style.opacity='1';/* verde sólido: o verde 18% com letra branca sumia */}} }
        function geo(q,force){ q=(q||'').trim(); if(!q||q===lastQ) return; if(window.WS_MAPA && !window.WS_MAPA.auto) return; lastQ=q;
          if(!force && (iLat.value.trim()||iLng.value.trim())) return; // só preenche vazio, salvo CEP (force)
          if(bd){bd.textContent='…';}
          wsGeocodificar(q)   // OpenStreet ou Google, conforme Recursos do sistema → Mapas
            .then(function(p){ if(p) set(p.lat,p.lon); else if(bd){bd.textContent='auto';} })
            .catch(function(){ if(bd){bd.textContent='auto';} }); }
        function porCidade(){ var c=(iC&&iC.value||'').trim(); var u=(iU&&iU.value||'').trim();
          if(c && u.length===2){ clearTimeout(t); t=setTimeout(function(){ geo(c+', '+u+', Brasil', false); },700); } }
        function porCep(){ var cep=((iCep&&iCep.value)||'').replace(/\D/g,''); if(cep.length!==8) return;
          clearTimeout(t); t=setTimeout(function(){ lastQ=''; geo('CEP '+cep, true); },700); }
        if(iC){iC.addEventListener('change',porCidade);iC.addEventListener('input',porCidade);}
        if(iU){iU.addEventListener('change',porCidade);iU.addEventListener('input',porCidade);}
        if(iCep){iCep.addEventListener('change',porCep);iCep.addEventListener('blur',porCep);}
        porCidade();
      })();
      </script>

      <?php $temCob = trim($g('cob_cep') . $g('cob_logradouro') . $g('cob_numero') . $g('cob_bairro') . $g('cob_cidade')) !== ''; /* 03/10/2026: campos só aparecem marcando a opção */ ?>
      <label class="c4 ws-chk" style="display:flex!important;flex-direction:row!important;align-items:center;gap:8px;font-weight:600"><input type="checkbox" id="ws_cob_outro" <?= $temCob ? 'checked' : '' ?> onchange="wsCobOutro(this.checked, true)" style="width:auto;height:auto"> <span style="color:#16a34a">📬 Cobrança em outro endereço</span> </label>
      <div class="c4" id="ws_cobA">
      <label class="ws-cob-f gx4">Endereço <input name="cob_logradouro" maxlength="160" value="<?= $g('cob_logradouro') ?>"></label>
      <label class="ws-cob-f gx2">Apartamento ou casa <select name="cob_apto_casa"><option value="" <?= $g('cob_apto_casa')==='' ? 'selected' : '' ?>>—</option><option value="Casa" <?= $g('cob_apto_casa')==='Casa' ? 'selected' : '' ?>>Casa</option><option value="Apartamento" <?= $g('cob_apto_casa')==='Apartamento' ? 'selected' : '' ?>>Apartamento</option></select></label>
      <label class="ws-cob-f gx2">Complemento <input name="cob_complemento" maxlength="80" value="<?= $g('cob_complemento') ?>"></label>
      <label class="ws-cob-f gx1">Número <input name="cob_numero" maxlength="20" value="<?= $g('cob_numero') ?>"></label>
      <label class="ws-cob-f gx1">CEP <input name="cob_cep" id="cob_cep" inputmode="numeric" maxlength="10" value="<?= $g('cob_cep') ?>"></label>
      </div>
      <div class="c4" id="ws_cobB">
      <label class="ws-cob-f gx2">Bairro <input name="cob_bairro" maxlength="80" value="<?= $g('cob_bairro') ?>"></label>
      <label class="ws-cob-f gx2">Cidade <input name="cob_cidade" id="cob_cidade" maxlength="80" value="<?= $g('cob_cidade') ?>"></label>
      <label class="ws-cob-f gx2">UF <input name="cob_uf" id="cob_uf" maxlength="2" style="text-transform:uppercase" value="<?= $g('cob_uf') ?>"></label>
      <label class="ws-cob-f gx2">Latitude <span class="ws-auto-badge" id="cob_geo_badge" title="Preenchido pela cidade/UF ou pelo CEP">auto</span> <input name="cob_lat" id="cob_lat" value="<?= $g('cob_lat') ?>"></label>
      <label class="ws-cob-f gx2">Longitude <input name="cob_lng" id="cob_lng" value="<?= $g('cob_lng') ?>"></label>
      </div>
      <script>
      /* 19/11/2026: latitude/longitude da COBRANÇA preenchidas sozinhas pela cidade+UF ou pelo CEP (mesma regra do endereço principal). Editável. */
      (function(){
        var iC=document.getElementById('cob_cidade'),iU=document.getElementById('cob_uf'),iCep=document.getElementById('cob_cep'),
            iLat=document.getElementById('cob_lat'),iLng=document.getElementById('cob_lng'),bd=document.getElementById('cob_geo_badge');
        if(!iLat||!iLng) return; var t=null,lastQ='';
        function set(la,lo){ if(la&&lo){iLat.value=(+la).toFixed(6);iLng.value=(+lo).toFixed(6);if(bd){bd.textContent='ok';bd.style.background='#16a34a';bd.style.opacity='1';}} }
        function geo(q,force){ q=(q||'').trim(); if(!q||q===lastQ) return; if(window.WS_MAPA && !window.WS_MAPA.auto) return; lastQ=q;
          if(!force && (iLat.value.trim()||iLng.value.trim())) return;
          if(bd){bd.textContent='…';}
          wsGeocodificar(q)
            .then(function(p){ if(p) set(p.lat,p.lon); else if(bd){bd.textContent='auto';} })
            .catch(function(){ if(bd){bd.textContent='auto';} }); }
        function porCidade(){ var c=(iC&&iC.value||'').trim(); var u=(iU&&iU.value||'').trim();
          if(c && u.length===2){ clearTimeout(t); t=setTimeout(function(){ geo(c+', '+u+', Brasil', false); },700); } }
        function porCep(){ var cep=((iCep&&iCep.value)||'').replace(/\D/g,''); if(cep.length!==8) return;
          clearTimeout(t); t=setTimeout(function(){ lastQ=''; geo('CEP '+cep, true); },700); }
        if(iC){iC.addEventListener('change',porCidade);iC.addEventListener('input',porCidade);}
        if(iU){iU.addEventListener('change',porCidade);iU.addEventListener('input',porCidade);}
        if(iCep){iCep.addEventListener('change',porCep);iCep.addEventListener('blur',porCep);}
        porCidade();
      })();
      </script>
      <style>
        #ws_cobA,#ws_cobB{display:grid;gap:12px 14px;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}
        #ws_form_cliente>#ws_cobA,#ws_form_cliente>#ws_cobB{grid-column:1 / -1!important}
        #ws_cobA>label,#ws_cobB>label{display:flex;flex-direction:column;justify-content:flex-start;gap:4px;min-width:0;width:100%}
        #ws_cobA input,#ws_cobB input{height:38px;box-sizing:border-box;width:100%;margin-top:0}
        #ws_cobB select{height:38px;box-sizing:border-box;width:100%;margin-top:0}
        @media (min-width:821px){
          #ws_cobA,#ws_cobB{grid-template-columns:repeat(10,minmax(0,1fr))}
          .gs5{grid-column:span 5}
        }
      </style>
      <script>
      function wsCobOutro(on, limpar){ document.querySelectorAll('.ws-cob-f').forEach(function(l){ l.style.display = on ? '' : 'none'; if(!on && limpar){ var i=l.querySelector('input'); if(i) i.value=''; } }); }
      wsCobOutro(document.getElementById('ws_cob_outro').checked, false);
      </script>

      <div class="c4 ws-secao">Sistema</div>
      <?php $ramais = $db->query("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 ORDER BY c.nome,r.nome")->fetchAll();
        $ramalAtivo = ws_ramal_atual();
        // Respeita o ramal REENVIADO (repost) após a confirmação de "outra cidade"; senão o do
        // cliente; senão (novo cadastro) o ramal ativo. Sem isso o ramal escolhido se perdia. ?>
        <?php $ramalPadrao = $repost['ramal_id'] ?? $c['ramal_id'] ?? ($id ? '' : ($ramalAtivo['id'] ?? '')); ?>
      <label>Ramal / cidade <select name="ramal_id" id="ws_cli_ramal">
        <option value="">—</option>
        <?php foreach ($ramais as $rm): ?><option value="<?= $rm['id'] ?>" data-cidade="<?= h(mb_strtoupper($rm['cidade'],'UTF-8')) ?>" <?= (string)$ramalPadrao===(string)$rm['id']?'selected':'' ?>><?= h($rm['cidade'].' — '.$rm['nome']) ?></option><?php endforeach; ?>
      </select></label>
      <label class="c4">Observações <textarea name="obs"><?= $g('obs') ?></textarea></label>
      <script>
      // Cada cidade/ramal é independente — se a Cidade digitada no endereço não bater com a cidade
      // do Ramal escolhido, confirma antes de salvar (evita cliente cair no ramal errado).
      (function(){
        var frm = document.getElementById('ws_form_cliente'); if (!frm) return;
        // Ramal AUTOMÁTICO: ao preencher/alterar a Cidade, seleciona o ramal daquela cidade
        // (continua editável — o operador pode trocar depois manualmente).
        var inpCidade = document.getElementById('cidade'), selRamal = document.getElementById('ws_cli_ramal');
        function wsAutoRamal(){
          var cid = (inpCidade.value || '').trim().toUpperCase(); if (!cid) return;
          for (var i = 0; i < selRamal.options.length; i++){
            var dc = (selRamal.options[i].getAttribute('data-cidade') || '');
            if (dc && (dc === cid || dc.indexOf(cid) === 0)) { selRamal.selectedIndex = i; break; }
          }
        }
        // Inverso: escolheu/tem ramal e a Cidade está vazia -> preenche com a cidade do ramal (editável).
        function wsAutoCidade(){
          var opt = selRamal.options[selRamal.selectedIndex]; if(!opt) return;
          var dc = (opt.getAttribute('data-cidade') || '').trim();
          if (dc && !(inpCidade.value || '').trim()) inpCidade.value = dc;
        }
        if (inpCidade && selRamal){
          inpCidade.addEventListener('change', wsAutoRamal); inpCidade.addEventListener('input', wsAutoRamal);
          selRamal.addEventListener('change', wsAutoCidade);
          wsAutoCidade();  // se a cidade estiver vazia, puxa a do ramal
          wsAutoRamal();   // ao abrir, sincroniza o ramal com a cidade (mantém os dois batendo)
        }
        frm.addEventListener('submit', function(e){
          var cidadeTxt = (document.getElementById('cidade').value || '').trim().toUpperCase();
          var selR = document.getElementById('ws_cli_ramal'); var opt = selR.options[selR.selectedIndex];
          var cidadeRamal = opt ? (opt.getAttribute('data-cidade') || '') : '';
          if (cidadeTxt && cidadeRamal && cidadeTxt.indexOf(cidadeRamal) === -1 && cidadeRamal.indexOf(cidadeTxt) === -1) {
            if (!confirm('A cidade do endereço ("' + cidadeTxt + '") é diferente da cidade do ramal escolhido ("' + cidadeRamal + '").\nConfirma salvar este cadastro nesse ramal mesmo assim?')) { e.preventDefault(); }
          }
        });
      })();
      </script>

      <?php if (!empty($_GET['confirmar_cidade'])): ?>
      <div class="c4 ws-alert err" style="margin:0">
        <label class="ws-chk" style="font-weight:400"><input type="checkbox" name="forcar_outra_cidade" value="1" required> Sim, quero cadastrar mesmo em outra cidade (diferente da que estou logado agora)</label>
      </div>
      <?php endif; ?>

      <?php if (!$id): $planos = $db->query("SELECT id,nome,valor FROM ws_plano WHERE ativo=1 ORDER BY nome")->fetchAll();
        $concs  = $db->query("SELECT id,nome FROM ws_concentrador WHERE ativo=1 ORDER BY nome")->fetchAll();
        $tipoPre = ($_GET['q_tipo'] ?? 'pppoe') === 'ipoe' ? 'ipoe' : 'pppoe'; ?>
        <div class="c4 ws-secao">Conexão / Plano de velocidade <span class="ws-muted" style="font-size:12px;font-weight:400">(cria o 1º contrato do cliente)</span></div>
        <label class="c2">Plano <span style="float:right"><a href="erp.php?p=planos" style="font-size:11px">criar</a></span>
          <select name="q_plano_id" id="q_plano_id" onchange="wsPlanoValor('q_plano_id','q_valor')">
            <option value="" data-valor="">— sem contrato agora —</option>
            <?php foreach ($planos as $pl) echo "<option value='{$pl['id']}' data-valor='".number_format((float)$pl['valor'],2,',','')."'>".h($pl['nome'])." (R$ ".number_format((float)$pl['valor'],2,',','.').")</option>"; ?>
          </select>
        </label>
        <label>Valor mensal (R$) <?= ws_pode_editar_valor_contrato() ? '' : '<span class="ws-auto-badge" title="Somente nível 2 ou superior pode digitar um valor diferente do plano">auto</span>' ?> <input name="q_valor" id="q_valor" placeholder="puxa do plano" <?= ws_pode_editar_valor_contrato() ? '' : 'readonly title="Valor travado no do plano — fale com um administrador pra alterar"' ?>></label>
        <?php // Conta (banco) que vai IMPRIMIR o boleto/PIX deste cliente — escolhível já no cadastro.
          $bancosQ = []; try { $bancosQ = $db->query("SELECT id,nome,pix,emissao FROM ws_banco WHERE ativo=1 ORDER BY FIELD(emissao,'gateway','lytex','proprio'), nome")->fetchAll(); /* CelCash 1º, Lytex 2º, PIX-QR 3º (03/10/2026) */ } catch (Throwable $e) {} ?>
        <label>Conta do boleto/PIX <span style="float:right"><a href="provedor.php?p=bancos" style="font-size:11px">criar</a></span>
          <select name="q_banco_id">
            <?php $qPri = 0; foreach ($bancosQ as $bk) { echo "<option value='{$bk['id']}'" . (!$qPri ? ' selected' : '') . ">".h($bk['nome']).($bk['pix'] ? " — ".h($bk['pix']) : '')."</option>"; $qPri = 1; } ?>
            <option value="">Conta padrão do sistema (1º banco ativo)</option>
          </select>
        </label>
        <label>Tipo de conexão
          <select name="q_tipo" id="q_tipo" onchange="wsTipoConexao()">
            <option value="pppoe" <?= $tipoPre==='pppoe'?'selected':'' ?>>PPPoE (login/senha)</option>
            <option value="ipoe"  <?= $tipoPre==='ipoe'?'selected':'' ?>>IPoE (ID da ONU/ONT)</option>
          </select>
        </label>
        <label class="conc-lbl">
          <span class="conc-head">Concentrador <a href="radius.php?p=conc" class="conc-criar">criar</a></span>
          <select name="q_concentrador_id" id="q_concentrador_id">
            <option value="todos" selected>Sair por TODOS os concentradores</option>
            <?php foreach ($concs as $cc) echo "<option value='{$cc['id']}'>".h($cc['nome'])."</option>"; ?>
          </select>
        </label>
        <?php
          // Item 2: cliente ADICIONAL já nasce com o mesmo dia de vencimento do titular (segue editável).
          // Cliente normal continua com o padrão de sempre (dia de hoje).
          $vencPadrao = min(31, (int)date('j'));
          if ($ehAdic && $titularIdRef) {
              $vt = $db->prepare("SELECT dia_vencimento FROM ws_contrato WHERE cliente_id=? AND dia_vencimento IS NOT NULL AND dia_vencimento>0 ORDER BY (status='cancelado') ASC, id DESC LIMIT 1");
              $vt->execute([$titularIdRef]);
              $vtDia = (int)$vt->fetchColumn();
              if ($vtDia >= 1 && $vtDia <= 31) $vencPadrao = $vtDia;
          }
        ?>
        <label>Dia de vencimento <input name="q_venc" type="number" min="1" max="31" value="<?= $vencPadrao ?>"></label>

        <!-- PPPoE -->
        <label class="ws-pppoe">Login PPPoE <input name="q_login" id="q_login" value="<?= h($_GET['q_login'] ?? '') ?>" placeholder="usuário PPPoE"></label>
        <label class="ws-pppoe">Senha PPPoE <input name="q_senha" id="q_senha" placeholder="senha PPPoE"></label>
        <!-- ONU/ONT: PPPoE e IPoE têm ONU. No IPoE o ID vira login/senha; no PPPoE fica só o ID. -->
        <label class="ws-onu">ID da ONU/ONT <input name="q_ont" id="q_ont" value="<?= h($_GET['q_ont'] ?? '') ?>" placeholder="ONT-ID da autorização" oninput="wsQOntAuto()"></label>
        <label class="ws-ipoe">Login IPoE <input name="q_login_ipoe" placeholder="opcional, se diferente do ID"></label>
        <label class="ws-ipoe">Senha IPoE <input name="q_senha_ipoe" placeholder="opcional, se diferente do ID"></label>

        <label class="ws-onu">SN ONU / ONT <input name="q_sn" value="<?= h($_GET['q_sn'] ?? '') ?>" placeholder="serial da ONU / ONT"></label>
        <label>VLAN <input name="q_vlan" type="number" value="<?= h($_GET['q_vlan'] ?? '') ?>"></label>
        <label>Zona (OLT) <input name="q_zona" list="ws_zona" value="<?= h($_GET['q_zona'] ?? '') ?>"></label><?= ws_zonas_datalist($db) ?>
        <label class="ws-onu">Placa PON <input name="q_placa_pon" value="<?= h($_GET['q_placa_pon'] ?? '') ?>" placeholder="auto ao aprovisionar"></label>
        <label class="ws-onu">PON <input name="q_pon" value="<?= h($_GET['q_pon'] ?? '') ?>" placeholder="auto ao aprovisionar"></label>
        <label class="ws-onu">RX (sinal) <input name="q_rx" value="<?= h($_GET['q_rx'] ?? '') ?>" placeholder="dBm"></label>
        <label class="ws-onu">TX (sinal) <input name="q_tx" value="<?= h($_GET['q_tx'] ?? '') ?>" placeholder="dBm"></label>
        <label class="ws-onu">Equipamento <select name="q_equipamento">
          <?php $eqp=$_GET['q_equipamento']??''; foreach (['','ONU (Bridge)','ONT (Router)'] as $eq) echo "<option ".($eqp===$eq?'selected':'').">".($eq?:'—')."</option>"; ?>
        </select></label>
        <?php if (!$planos): ?>
          <div class="c4 ws-muted" style="font-size:13px">Nenhum plano cadastrado ainda — <a href="erp.php?p=planos">criar plano de velocidade</a>.</div>
        <?php endif; ?>
        <script>
        function wsTipoConexao(){var t=document.getElementById('q_tipo').value;
          document.querySelectorAll('.ws-pppoe').forEach(e=>e.style.display=(t==='pppoe')?'flex':'none');
          document.querySelectorAll('.ws-ipoe').forEach(e=>e.style.display=(t==='ipoe')?'flex':'none');
          // Campos da ONU valem para PPPoE E IPoE (o cliente PPPoE também tem ONU).
          document.querySelectorAll('.ws-onu').forEach(e=>e.style.display='flex');}
        wsTipoConexao();
        // ID de ONU/ONT digitado -> espelha no SN. NÃO troca o tipo nem mexe no login/senha:
        // no IPoE o login/senha = ID é aplicado ao salvar; no PPPoE o login/senha são próprios do cliente.
        function wsQOntAuto(){var v=document.getElementById('q_ont').value.trim().toLowerCase();
          if(!v) return;
          var snInp=document.querySelector('input[name="q_sn"]'); if(snInp && !snInp.value) snInp.value=v.toUpperCase();
        }
        </script>
      <?php endif; ?>

      <div class="c4"><button class="ws-btn verde" id="ws_btn_salvar_cliente">Salvar cliente</button>
        <?php if ($id): ?><a class="ws-btn danger" href="erp.php?tipo=cliente&excluir=<?= $id ?>&volta=clientes" onclick="return confirm('Excluir cliente e seus contratos?')">Excluir</a><?php endif; ?>
      </div>
    </form>
    <?php /* 18/11/2026: a checagem ao digitar vale também na ALTERAÇÃO do cadastro (antes só no cadastro novo). */ ?>
    <script>
    // Checa em tempo real se o CPF/CNPJ é válido (dígito verificador) e se já pertence a outro
    // cliente. Tudo via fetch/JSON — a página NUNCA recarrega e NUNCA perde o que já foi digitado
    // no resto do formulário; só avisa e aponta o que precisa corrigir no próprio campo.
    // Item 4: duplicidade BLOQUEIA de verdade — não existe mais "cadastrar mesmo assim". As únicas
    // exceções (CNPJ do provedor / CPF-CNPJ do próprio titular deste adicional) já vêm liberadas
    // pelo servidor (ver ajax=checar_titular), então se apareceu aqui é bloqueio de verdade.
    // Item 2: link extra "editar e reaproveitar estes dados" — manda os dados já digitados neste
    // formulário (nome, endereço, contato etc.) pra sessionStorage antes de ir pra ficha do cliente
    // já existente, que os aplica sozinha ao carregar (ver bloco "reaproveitar" logo abaixo).
    window.wsReaproveitarCliente = function(id){
      try {
        var form = document.getElementById('ws_form_cliente');
        var fd = new FormData(form);
        var dados = {};
        fd.forEach(function(v,k){ if (k !== 'acao' && k !== 'id' && v !== '') dados[k] = v; });
        sessionStorage.setItem('ws_reaproveitar_cliente', JSON.stringify(dados));
      } catch(e){}
      location = 'erp.php?p=cliente&id=' + id + '&reaproveitar=1';
    };
    (function(){
      var doc = document.querySelector('input[name="cpf_cnpj"]');
      var btn = document.getElementById('ws_btn_salvar_cliente');
      var box = document.getElementById('ws_dup_titular');
      var msg = document.getElementById('ws_dup_msg');
      var titularRef = <?= (int)($c['titular_id'] ?? $_GET['titular'] ?? 0) ?>;
      var idAtual = <?= (int)$id ?>;
      if(!doc) return;
      var t=null;
      doc.addEventListener('input', function(){
        clearTimeout(t);
        var v = doc.value.trim();
        if(!v){ box.style.display='none'; btn.disabled=false; return; }
        t=setTimeout(function(){
          fetch('erp.php?ajax=checar_titular&cpf='+encodeURIComponent(v)+'&titular='+titularRef+'&id='+idAtual)
            .then(r=>r.json()).then(function(j){
              if(j.invalido){
                box.style.display='block';
                msg.innerHTML='⚠️ CPF/CNPJ inválido — confira os números digitados. O resto do cadastro continua preenchido, só corrija este campo.';
                btn.disabled=true;
              } else if(j.duplicado){
                box.style.display='block';
                msg.innerHTML='⛔ Este CPF/CNPJ já está cadastrado com outro cliente: <b>'+j.nome+'</b> — '
                  + '<a href="erp.php?p=cliente&id='+j.id+'" target="_blank" style="color:var(--info)">abrir ficha</a> · '
                  + (idAtual ? '' : '<a href="#" onclick="wsReaproveitarCliente('+j.id+');return false;" style="color:var(--warn)">editar e reaproveitar estes dados</a> · '
                  + '<a href="erp.php?p=cliente&titular='+j.id+'" style="color:var(--ok)">cadastrar como adicional dele</a>.');
                btn.disabled=true;
              } else { box.style.display='none'; btn.disabled=false; }
            }).catch(function(){});
        },450);
      });
    })();
    </script>

    <?php if ($id && isset($_GET['reaproveitar'])): ?>
    <script>
    // Item 2: aplica no formulário de edição os dados que o usuário já tinha digitado no cadastro
    // que apontou duplicidade (ver wsReaproveitarCliente acima) — evita perder/redigitar tudo.
    // Só sobrescreve campos que vieram preenchidos; "titular_id" nunca é tocado (vínculo estrutural
    // desta própria ficha, não do formulário abandonado).
    (function(){
      try {
        var raw = sessionStorage.getItem('ws_reaproveitar_cliente');
        if (!raw) return;
        sessionStorage.removeItem('ws_reaproveitar_cliente');
        var dados = JSON.parse(raw);
        var form = document.getElementById('ws_form_cliente');
        if (!form) return;
        Object.keys(dados).forEach(function(k){
          if (k === 'titular_id' || !dados[k]) return;
          var el = form.elements[k];
          if (!el) return;
          el.value = dados[k];
        });
      } catch(e){}
    })();
    </script>
    <?php endif; ?>

    <?php if ($id):
        // Item 1: cadastro de conexão de CADA adicional agora é exibido logo ACIMA de "Títulos do
        // cliente" (antes ficava depois de "Pagos anteriormente"/boleto recebido, no fim da ficha).
        // Passado como callback pra ws_bloco_contratos, que injeta o bloco no ponto certo, entre a
        // tabela de conexão do titular e a seção de títulos. A navegação separada (ícone em
        // ws_chips_adicionais) continua existindo normalmente.
        $wsConexoesAdicCallback = null;
        if (!$ehAdic) {
            $wsConexoesAdicCallback = function() use ($db, $id) {
                $stAdicCx = $db->prepare("SELECT id, nome, nome_resumido FROM ws_cliente WHERE titular_id=? ORDER BY nome");
                $stAdicCx->execute([$id]);
                $wsListaAdicCx = $stAdicCx->fetchAll();
                if ($wsListaAdicCx) {
                    // Pedido do operador: um título fixo (preto) uma vez só, acima do PRIMEIRO
                    // cadastro de conexão de adicional — não repete por adicional, isso já é o
                    // cabeçalho roxo de cada ws_bloco_conexao_adicional() logo abaixo.
                    echo ws_conexao_assets() . '<h3 class="ws-cc-sub">Cadastro de Conexão (Adicional)</h3>';
                }
                foreach ($wsListaAdicCx as $adCx) {
                    ws_bloco_conexao_adicional($db, (int)$adCx['id'], (string)($adCx['nome_resumido'] ?: $adCx['nome']));
                }
            };
        }
        ws_bloco_contratos($db, $id, $wsConexoesAdicCallback);
        ws_bloco_adicionais($db, $id); ws_bloco_conexoes($db, $id); ws_bloco_anexos($db, $id); ws_bloco_timeline($db, $id);
    endif;
}

/* --------- COPIAR AO PASSAR O MOUSE (login, plano, SN ONU / ONT, nome do adicional) ---------
   Envolve o texto num <span> que, no hover, mostra um botãozinho 📋. Clicar copia o valor puro
   (sem ícones/HTML) para a área de transferência e mostra ✅ no próprio botão por 1s.
   $html = conteúdo exibido (ex.: um link); vazio -> exibe o próprio texto escapado.
   CSS + JS saem UMA vez por página (ws_copiavel_assets), inline — não dependem de css/ ou js/. */
function ws_copiavel(?string $txt, string $html = ''): string {
    $txt = trim((string)$txt);
    if ($txt === '') return $html !== '' ? $html : '';
    return ws_copiavel_assets() . '<span class="ws-cp">' . ($html !== '' ? $html : h($txt))
         . '<button type="button" class="ws-cp-b" data-cp="' . h($txt) . '" title="Copiar: ' . h($txt) . '" aria-label="Copiar">📋</button></span>';
}
function ws_copiavel_assets(): string {
    static $feito = false;
    if ($feito) return '';
    $feito = true;
    return '<style>
      .ws-cp{position:relative;display:inline-flex;align-items:center;gap:4px;max-width:100%}
      .ws-cp-b{border:0;background:transparent;cursor:pointer;padding:0 2px;font-size:12px;line-height:1;
               opacity:0;transition:opacity .12s;color:inherit}
      .ws-cp:hover .ws-cp-b,.ws-cp-b:focus{opacity:.85}
      .ws-cp-b.ok{opacity:1!important}
      @media (hover:none){.ws-cp-b{opacity:.55}}   /* celular não tem hover: fica sempre visível, discreto */
    </style><script>
    document.addEventListener("click",function(e){
      var b=e.target.closest?e.target.closest(".ws-cp-b"):null; if(!b)return;
      e.preventDefault(); e.stopPropagation();
      var t=b.getAttribute("data-cp")||"";
      var ok=function(){var o=b.textContent;b.textContent="✅";b.classList.add("ok");setTimeout(function(){b.textContent=o;b.classList.remove("ok");},1000);};
      var fb=function(){var a=document.createElement("textarea");a.value=t;a.style.cssText="position:fixed;left:-9999px;opacity:0";document.body.appendChild(a);a.select();try{document.execCommand("copy");ok();}catch(x){}document.body.removeChild(a);};
      if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(ok,fb);else fb();
    },true);
    </script>';
}

/* --------- COPIAR DENTRO DE UM CAMPO DO FORMULÁRIO (nome, CPF/CNPJ, nome resumido) ---------
   Recebe o <input> pronto e devolve o input com um botãozinho 📋 no canto direito, que só aparece
   ao passar o mouse (igual ao 📋 das tabelas) e copia o valor do campo. O botão de COLAR foi
   retirado a pedido do provedor — colar continua pelo Ctrl+V de sempre. Assets inline, uma vez. */
function ws_campo_cc(string $inputHtml): string {
    static $assets = false;
    $css = '';
    if (!$assets) {
        $assets = true;
        $css = '<style>
          .ws-cc-wrap{position:relative;display:block;height:38px;margin-top:auto}
          .ws-cc-wrap>input{padding-right:34px!important}
          .ws-cc-bts{position:absolute;right:6px;top:50%;transform:translateY(-50%);display:flex;gap:2px;z-index:2}
          /* Escondidos até passar o mouse no campo (igual ao 📋 das tabelas); no celular, sem hover,
             ficam sempre visíveis e discretos. */
          .ws-cc-bts{opacity:0;transition:opacity .12s;pointer-events:none}
          .ws-cc-wrap:hover .ws-cc-bts,.ws-cc-wrap:focus-within .ws-cc-bts{opacity:1;pointer-events:auto}
          @media (hover:none){.ws-cc-bts{opacity:.55;pointer-events:auto}}
          .ws-cc-bts button{border:0;background:transparent;cursor:pointer;font-size:13px;line-height:1;padding:3px;border-radius:5px;opacity:.7}
          .ws-cc-bts button:hover{opacity:1;background:rgba(0,0,0,.06)}
        </style><script>
        document.addEventListener("click",function(e){
          var b=e.target.closest?e.target.closest(".ws-cc-bts button"):null; if(!b)return;
          e.preventDefault();
          var inp=b.closest(".ws-cc-wrap").querySelector("input"); if(!inp)return;
          var marca=function(t){var o=b.textContent;b.textContent=t;setTimeout(function(){b.textContent=o;},900);};
          var v=inp.value||""; if(!v){marca("∅");return;}
          var fb=function(){inp.select();try{document.execCommand("copy");marca("✅");}catch(x){}};
          if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(v).then(function(){marca("✅");},fb);else fb();
        });
        </script>';
    }
    return $css . '<span class="ws-cc-wrap">' . $inputHtml
         . '<span class="ws-cc-bts"><button type="button" title="Copiar">📋</button></span></span>';
}

/** Larguras das colunas das tabelas de contrato (titular e adicionais) — UMA definição só, para
 *  que cada coluna de cada tabela fique exatamente abaixo da mesma coluna da tabela de cima. */
function ws_cx_colgroup(): string {
    // # Login Tipo Plano VLAN SN Venc Conexão — a coluna Ações fica SEM largura fixa: recebe todo o
    // resto da tabela, para os 5 botões (editar, boletos, derrubar, bloquear, excluir) caberem numa linha.
    $w = ['4%', '11%', '6%', '11%', '5%', '10%', '5%', '8%'];
    return '<colgroup>' . implode('', array_map(fn($x) => '<col style="width:' . $x . '">', $w)) . '<col></colgroup>';
}

/* Estilos da área de CONEXÃO na ficha (tarjas do titular/adicional). Inline, uma vez por página.
   - Tarja do TITULAR: mesma faixa colorida do adicional, na cor da marca, com o nome do cliente.
   - Tarja/títulos dos ADICIONAIS com fonte menor (pedido do provedor: só o tamanho muda).
   - Tabelas com rolagem horizontal própria no celular, sem empurrar a página. */
function ws_conexao_assets(): string {
    static $feito = false;
    if ($feito) return '';
    $feito = true;
    return '<style>
      .ws-tarja-adicional h3{font-size:11.5px!important}
      .ws-tarja-adicional h3 .ws-cc-nome{font-size:13px}   /* nome do adicional um pouco maior que o título */
      /* COLUNAS ALINHADAS: titular e todos os adicionais com a MESMA largura por coluna (table-layout
         fixed + <colgroup> igual), então cada coluna fica exatamente abaixo da de cima. */
      .ws-cx-tab{table-layout:fixed;width:100%}
      .ws-cx-tab td,.ws-cx-tab th{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:6px!important;padding-right:6px!important}
      /* Ações numa linha só (nunca quebram para baixo). Em tela estreita a tabela rola de lado
         dentro da .ws-cx-wrap em vez de empilhar os botões. */
      .ws-cx-tab td:last-child{overflow:visible}
      .ws-cx-tab .ws-acoes{flex-wrap:nowrap!important;gap:6px!important}
      .ws-cx-tab .ws-acoes a{white-space:nowrap;flex:0 0 auto;padding:4px 9px!important;font-size:12px!important}
      .ws-tarja-adicional h3 .ws-cc-nome a{color:inherit;text-decoration:none;border-bottom:1px dotted currentColor}
      .ws-tarja-adicional h3 .ws-cc-nome a:hover{border-bottom-style:solid}
      .ws-cc-sub{font-size:13px!important;color:var(--text)!important;margin:18px 0 0!important}
      .ws-tarja-titular{margin-top:26px;padding:8px 14px;
        background:linear-gradient(90deg,rgba(122,31,43,.12),rgba(122,31,43,.02));border-left:4px solid var(--brand)}
      .ws-tarja-titular h3{font-size:14px}
      .ws-tarja-titular h3 .ws-cc-nome{color:var(--info)}
      .ws-cx-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
      .ws-cx-wrap .ws-table{min-width:760px}
      .ws-cx-wrap .ws-cx-tab{min-width:1150px}   /* contratos: abaixo disso rola de lado; os botões não quebram */
    </style>';
}

/* --------- Cadastro de Conexão de um ADICIONAL, para exibir logo abaixo do cadastro de conexão
   do titular (item 1). Mesma tabela/ações de ws_bloco_contratos, só que resumida — sem repetir a
   seção pesada de Títulos/Faturas, que já aparece na página própria do adicional (erp.php?p=
   adicional&id=X) e ficaria redundante aqui dentro da ficha do titular. --------- */
function ws_bloco_conexao_adicional(PDO $db, int $clienteId, string $nomeAdicional): void {
    $st = $db->prepare("SELECT ct.*, p.nome plano, p.valor plano_valor FROM ws_contrato ct LEFT JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=? ORDER BY ct.id");
    $st->execute([$clienteId]); $rows = $st->fetchAll();
    // Nome do adicional é LINK para a ficha própria dele (erp.php?p=adicional&id=X) e copiável.
    $linkAdic = '<a href="erp.php?p=adicional&id=' . $clienteId . '" title="Abrir o cadastro deste adicional">' . h($nomeAdicional) . '</a>';
    echo ws_conexao_assets() . ws_copiavel_assets();   // antes do 1º título: <style>/<script> fora do <h3>
    ?>
    <div class="ws-head-row ws-tarja ws-tarja-adicional">
      <h3><span class="ws-cc-titulo">👥 Cadastro de Conexão</span> — <span class="ws-cc-nome"><?= ws_copiavel($nomeAdicional, $linkAdic) ?></span> <span class="ws-badge-add" style="margin-left:6px">Adicional</span></h3>
    </div>
    <div class="ws-cx-wrap"><table class="ws-table ws-cx-tab"><?= ws_cx_colgroup() ?><thead><tr>
      <th>#</th><th>Login</th><th>Tipo</th><th>Plano</th><th>VLAN</th><th>SN ONU / ONT</th><th>Venc.</th><th>Conexão</th><th style="text-align:center">Ações</th>
    </tr></thead><tbody>
    <?php foreach ($rows as $r):
      $emConf = ws_rad_em_confianca($r); $bloq = ws_rad_deve_bloquear($db, $r); ?>
      <tr><td><?= $r['id'] ?></td><td><?= ws_copiavel($r['login_pppoe']) ?></td><td><?= strtoupper(h($r['tipo_conexao'])) ?></td>
      <td><?= ws_copiavel($r['plano']) ?></td><td><?= h($r['vlan'] ?? '') ?></td><td><?= ws_copiavel($r['sn_onu']) ?></td><td><?= h($r['dia_vencimento']) ?></td>
      <td><span class="ws-tag <?= $emConf?'confianca':($bloq?'bloqueado':'ativo') ?>"><?= $emConf?'confiança':($bloq?'bloqueado':'ativo') ?></span></td>
      <td><div class="ws-acoes" style="justify-content:center">
        <a href="erp.php?p=contrato&id=<?= $r['id'] ?>" title="Editar contrato">✏️ editar</a>
        <a href="financeiro.php?p=faturas&q=<?= urlencode($r['login_pppoe']) ?>" title="Ver boletos do cliente">🧾 boletos</a>
        <?php if (!empty($r['login_pppoe'])): ?><a href="erp.php?cli_acao=derrubar&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Derrubar a conexão (disconnect) no concentrador?')" title="Enviar disconnect ao concentrador" style="color:var(--warn)">📴 derrubar</a><?php endif; ?>
        <?php if ($bloq): ?>
          <a href="erp.php?cli_acao=desbloquear&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" style="color:var(--ok)"><?= ws_icon('desbloqueio') ?> desbloquear</a>
        <?php endif; ?>
        <?php if (!$bloq): ?>
          <a href="erp.php?cli_acao=bloquear&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Bloquear a conexão?')" style="color:var(--err)">⛔ bloquear</a>
        <?php endif; ?>
        <a href="erp.php?del_contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Excluir esta conexão/contrato? (remove do RADIUS)')" style="color:var(--err)"><?= ws_icon('lixeira') ?> excluir</a>
      </div></td></tr>
    <?php endforeach; if (!$rows) echo '<tr><td colspan="9" class="ws-muted">Sem contratos.</td></tr>'; ?>
    </tbody></table></div>
    <?php
}

/* --------- Ícones compactos dos adicionais, logo abaixo do nome do titular.
   Cada ícone abre a página do adicional (erp.php?p=adicional&id=X) — página própria,
   com TODAS as mesmas funções do titular, só que vinculada a ele. Nada de adicional
   fica dentro da página do titular além destes ícones (mantém organizado). --------- */
function ws_chips_adicionais(PDO $db, int $titularId): void {
    $st = $db->prepare("SELECT id, nome, nome_resumido, status FROM ws_cliente WHERE titular_id=? ORDER BY nome");
    $st->execute([$titularId]); $rows = $st->fetchAll();
    ?>
    <div style="margin:-4px 0 18px">
      <div class="ws-muted" style="font-size:11.5px;text-transform:uppercase;letter-spacing:.03em;font-weight:700;margin-bottom:6px">
        Clientes adicionais vinculados a este titular<?= $rows ? ' ('.count($rows).')' : '' ?>
      </div>
      <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px">
        <?php foreach ($rows as $r): ?>
          <a href="erp.php?p=adicional&id=<?= $r['id'] ?>" class="ws-tag <?= h($r['status']) ?>"
             style="text-decoration:none;display:inline-flex;align-items:center;gap:5px;padding:5px 10px"
             title="Abrir a ficha própria deste adicional — cadastro, conexão e boletos 100% independentes">
            👥 <?= h($r['nome_resumido'] ?: $r['nome']) ?>
          </a>
        <?php endforeach; ?>
        <a href="erp.php?p=adicional&titular=<?= $titularId ?>" class="ws-tag inativo"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:5px;padding:5px 10px">
          ➕ Novo cliente adicional
        </a>
      </div>
    </div>
    <?php
}

/* --------- Adicionais do cliente (atrelados ao titular) --------- */
function ws_bloco_adicionais(PDO $db, int $titularId): void {
    $meu = $db->prepare("SELECT titular_id FROM ws_cliente WHERE id=?"); $meu->execute([$titularId]); $titDe = $meu->fetchColumn();
    if (!$titDe) return; // titular: os adicionais aparecem como ícones no topo (ws_chips_adicionais), não aqui.
    // este cliente É um adicional — mostra o vínculo com o titular + botão de conexão
    $tn = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $tn->execute([$titDe]);
    // Contrato/conexão próprio deste adicional (mesma lógica do titular, pra oferecer botão direto).
    $ctAdic = $db->prepare("SELECT id, status FROM ws_contrato WHERE cliente_id=? ORDER BY id DESC LIMIT 1");
    $ctAdic->execute([$titularId]); $ctAdicRow = $ctAdic->fetch();
    $temCtAdic = (bool)$ctAdicRow; ?>
    <div class="ws-alert" style="margin-top:20px;background:rgba(147,51,234,.10);color:#9333ea;border:1px solid #9333ea">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <div><b>CLIENTE ADICIONAL</b> — vinculado ao titular <a href="erp.php?p=cliente&id=<?= (int)$titDe ?>"><b><?= h($tn->fetchColumn()) ?></b></a>.</div>
        <?php if ($temCtAdic): ?>
          <a class="ws-btn" href="erp.php?p=contrato&id=<?= (int)$ctAdicRow['id'] ?>">✏️ Editar dados da conexão</a>
        <?php else: ?>
          <a class="ws-btn primary" href="erp.php?p=contrato&cliente=<?= $titularId ?>">➕ Criar dados da conexão (igual ao titular)</a>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

/* --------- Conexões do cliente (sessões do RADIUS: início, fim, consumo) --------- */
/* Tabela de sessões de UM cliente ($cab = cabeçalho já pronto). Usada pelo titular e por cada adicional. */
function ws_conexoes_de(PDO $db, int $clienteId, string $cab): void {
    // logins do cliente (todos os contratos)
    $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS login_pppoe FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
    $lg->execute([$clienteId]);
    $logins = array_column($lg->fetchAll(), 'login_pppoe');
    ?>
    <?= $cab ?>
    <?php if (!$logins): ?>
      <p class="ws-muted">Sem login PPPoE/IPoE cadastrado neste cliente.</p>
    <?php else:
      $in = implode(',', array_fill(0, count($logins), '?'));
      // sessão em aberto = online agora
      $onq = $db->prepare("SELECT username FROM radacct WHERE username IN ($in) AND acctstoptime IS NULL");
      $onq->execute($logins); $online = array_column($onq->fetchAll(), 'username');
      // + sessão lida nos concentradores (ws_conexao_viva): com o RADIUS do MK-Auth a radacct daqui
      // fica vazia e a ficha dizia "Offline" para cliente navegando. Mesma fonte do Painel.
      if (function_exists('ws_conexao_viva')) { try { $vv = ws_conexao_viva(90);
          foreach ($logins as $lgv) if (isset($vv[strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$lgv))]) && !in_array($lgv, $online, true)) $online[] = $lgv;
      } catch (Throwable $e) {} }
      $st = $db->prepare("SELECT username, nasipaddress, framedipaddress, acctstarttime, acctstoptime,
                                 acctinputoctets, acctoutputoctets, callingstationid
                          FROM radacct WHERE username IN ($in) ORDER BY acctstarttime DESC LIMIT 50");
      $st->execute($logins); $sess = $st->fetchAll();
      $mb = fn($o) => number_format(((int)$o)/1048576, 1, ',', '.') . ' MB';
      ?>
      <?php
        /* 19/11/2026: "Online agora" mostra o nome resumido (sem parênteses) e o IP público da sessão viva (CGNAT). */
        $ipPubOn = ''; $nomeOn = ''; $portaInOn = ''; $portaOutOn = '';
        try { $nq = $db->prepare('SELECT nome_resumido, nome FROM ws_cliente WHERE id=?'); $nq->execute([(int)$clienteId]); $nr = $nq->fetch(PDO::FETCH_ASSOC);
              $nomeOn = trim((string)($nr['nome_resumido'] ?? '')) !== '' ? $nr['nome_resumido'] : ($nr['nome'] ?? ''); } catch (Throwable $e) {}
        try { if (!function_exists('ws_cgnat_versao_em') && is_file(__DIR__ . '/cgnat_lib.php')) require_once __DIR__ . '/cgnat_lib.php';
              $vOn = ws_cgnat_versao_em($db, date('Y-m-d H:i:s'));
              if ($vOn && !empty($sess)) foreach ($sess as $sxOn) { if (empty($sxOn['acctstoptime']) && !empty($sxOn['framedipaddress'])) {
                  $mOn = ws_cgnat_publico($db, (int)$vOn['id'], (int)ip2long($sxOn['framedipaddress'])); if ($mOn) { $ipPubOn = long2ip($mOn['ip_publico']); $portaInOn = $mOn['porta_ini']; $portaOutOn = $mOn['porta_fim']; } break; } } } catch (Throwable $e) {}
      ?>
      <?php if ($online): ?>
      <table style="border-collapse:collapse;width:auto;font-size:13px;margin:2px 0 4px"><tbody><tr>
        <td style="padding:2px 18px 2px 0;white-space:nowrap">🟢 Online agora: <b style="color:var(--ok)"><?= h($nomeOn ?: implode(', ', $online)) ?></b></td>
        <?php if ($ipPubOn): ?>
        <td style="padding:2px 18px 2px 0;white-space:nowrap">IP Público atual: <b><?= h($ipPubOn) ?></b></td>
        <td style="padding:2px 18px 2px 0;white-space:nowrap">Porta Entrada: <b><?= (int)$portaInOn ?></b></td>
        <td style="padding:2px 0;white-space:nowrap">Porta Saída: <b><?= (int)$portaOutOn ?></b></td>
        <?php else: ?>
        <td colspan="3" class="ws-muted" style="padding:2px 0;white-space:nowrap">sem IP público no CGNAT</td>
        <?php endif; ?>
      </tr></tbody></table>
      <?php else: ?>
      <p class="ws-muted" style="font-size:13px">⚪ Offline no momento</p>
      <?php endif; ?>
      <table class="ws-table"><thead><tr>
        <th>Login</th><th>IP</th><th>Início</th><th>Fim</th><th>↓ Download</th><th>↑ Upload</th><th>MAC</th>
      </tr></thead><tbody>
      <?php $iS = 0; $vistoCx = []; foreach ($sess as $s): $aberta = empty($s['acctstoptime']); $iS++; ?>
        <tr<?= $iS > 10 ? ' class="ws-cx-smais" style="display:none"' : '' ?>>
          <td><?= h($s['username']) ?> <?php $ultCx = !isset($vistoCx[$s['username']]); $vistoCx[$s['username']] = 1; ?><?= !$ultCx ? '' : ($aberta?'<a href="mk_monitor.php?acao=trafego&login='.urlencode((string)$s['username']).'" target="_blank" class="ws-tag ativo" style="font-size:10px;text-decoration:none;cursor:pointer" title="Abrir o gráfico ao vivo desta conexão">online</a>':'<span class="ws-tag" style="font-size:10px;background:rgba(100,116,139,.14);color:#64748b;border:1px solid rgba(100,116,139,.35)">offline</span>') ?></td>
          <td><a href="#" onclick="if(typeof wsAbrirIP==='function'){wsAbrirIP('<?= h($s['framedipaddress']) ?>');}else{window.open('http://<?= h($s['framedipaddress']) ?>','_blank');}return false;" title="Acessar o equipamento" style="text-decoration:underline"><?= h($s['framedipaddress']) ?></a></td>
          <td><?= $s['acctstarttime'] ? date('d/m/Y H:i\h', strtotime($s['acctstarttime'])) : '—' ?></td>
          <td><?= $s['acctstoptime'] ? date('d/m/Y H:i\h', strtotime($s['acctstoptime'])) : '<span class="ws-muted">em curso</span>' ?></td>
          <td><?= $mb($s['acctoutputoctets']) ?></td><td><?= $mb($s['acctinputoctets']) ?></td>
          <td><?= h($s['callingstationid']) ?></td>
        </tr>
      <?php endforeach; if(!$sess) echo '<tr><td colspan="7" class="ws-muted">Nenhuma sessão registrada ainda (o FreeRADIUS grava aqui via accounting).</td></tr>'; ?>
      </tbody></table>
      <?php if (count($sess) > 10) echo '<button type="button" class="ws-btn" style="font-size:12px;margin:6px 0 0" data-rot="▾ Ver todas as sessões ('.count($sess).')" onclick="var ex=this.parentNode.querySelectorAll(\'.ws-cx-smais\'),ab=this.getAttribute(\'data-ab\')!==\'1\';ex.forEach(function(e){e.style.display=ab?(e.getAttribute(\'data-show\')||\'\'):\'none\';});this.setAttribute(\'data-ab\',ab?\'1\':\'0\');this.textContent=ab?\'▴ Recolher\':this.getAttribute(\'data-rot\');">▾ Ver todas as sessões ('.count($sess).')</button>'; ?>
    <?php endif;
}

/* --------- Conexões (sessões): do cliente e, se ele for TITULAR, também as dos ADICIONAIS na MESMA tabela ---------
   Pedido do provedor: na tabela "Conexões (sessões)" do titular, mostrar também a conexão de cada adicional e se
   está online. A linha "Online agora" lista o titular e cada adicional (🟢 online / ⚪ offline / sem login); as
   sessões do adicional entram na tabela com a etiqueta roxa do nome (link p/ a ficha dele).
   SEM ADICIONAL = exatamente como antes (ws_conexoes_de). */
function ws_bloco_conexoes(PDO $db, int $clienteId): void {
    $adics = [];
    try { $ad = $db->prepare("SELECT id, nome, nome_resumido FROM ws_cliente WHERE titular_id=? ORDER BY nome"); $ad->execute([$clienteId]); $adics = $ad->fetchAll(); } catch (Throwable $e) { $adics = []; }
    if (!$adics) { ws_conexoes_de($db, $clienteId, '<div class="ws-head-row ws-tarja" id="conexoes-sessoes"><h3>🌐 Conexões (sessões)</h3></div>'); return; }
    $loginsDe = function (int $cid) use ($db): array {
        $lg = $db->prepare("SELECT DISTINCT IF(t.k=1, ct.login_pppoe, ct.login_ipoe) AS lg FROM ws_contrato ct JOIN (SELECT 1 k UNION ALL SELECT 2) t WHERE ct.cliente_id=? AND IF(t.k=1, ct.login_pppoe, ct.login_ipoe) <> ''");
        $lg->execute([$cid]); return array_column($lg->fetchAll(), 'lg'); };
    $dono = [];                                   // login => [nome, é adicional?, id]
    foreach ($loginsDe($clienteId) as $l) $dono[$l] = ['', false, $clienteId];
    $porAdic = [];
    foreach ($adics as $a) { $nm = (string)($a['nome_resumido'] ?: $a['nome']); $ls = $loginsDe((int)$a['id']); $porAdic[] = [$a, $nm, $ls];
        foreach ($ls as $l) if (!isset($dono[$l])) $dono[$l] = [$nm, true, (int)$a['id']]; }
    $logins = array_keys($dono);
    $nmTit = ''; try { $qt = $db->prepare("SELECT nome, nome_resumido FROM ws_cliente WHERE id=?"); $qt->execute([$clienteId]); $rt = $qt->fetch(); if ($rt) $nmTit = (string)($rt['nome_resumido'] ?: $rt['nome']); } catch (Throwable $e) {}
    echo '<div class="ws-head-row ws-tarja" id="conexoes-sessoes"><h3>🌐 Conexões (sessões)</h3></div>';
    if (!$logins) { echo '<p class="ws-muted">Sem login PPPoE/IPoE cadastrado neste cliente nem nos adicionais.</p>'; return; }
    $in = implode(',', array_fill(0, count($logins), '?'));
    $onq = $db->prepare("SELECT username FROM radacct WHERE username IN ($in) AND acctstoptime IS NULL");
    $onq->execute($logins); $online = array_column($onq->fetchAll(), 'username');
    if (function_exists('ws_conexao_viva')) { try { $vv = ws_conexao_viva(90);
        foreach ($logins as $lgv) if (isset($vv[strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$lgv))]) && !in_array($lgv, $online, true)) $online[] = $lgv;
    } catch (Throwable $e) {} }
    $st = $db->prepare("SELECT username, nasipaddress, framedipaddress, acctstarttime, acctstoptime, acctinputoctets, acctoutputoctets, callingstationid
                        FROM radacct WHERE username IN ($in) ORDER BY acctstarttime DESC LIMIT 80");
    $st->execute($logins); $sess = $st->fetchAll();
    $mb = fn($o) => number_format(((int)$o)/1048576, 1, ',', '.') . ' MB';
    $tagAd = fn(string $nm, int $id) => ' <a href="' . 'erp.php?p=adicional&id=' . $id . '" class="ws-tag" style="font-size:10px;background:rgba(147,51,234,.12);color:#9333ea;border:1px solid #9333ea;text-decoration:none" title="Adicional — abrir a ficha">👥 ' . h($nm) . '</a>';
    // status: titular + cada adicional
    $tit = array_values(array_filter($logins, fn($l) => !$dono[$l][1]));
    $onTit = array_values(array_intersect($tit, $online));
    // STATUS em GRADE (1 cartão por cliente: nome · situação · login) — organizado mesmo com muitos adicionais
    $card = function (string $nome, string $sit, string $lgs, bool $adic) { return '<div style="display:flex;align-items:center;gap:6px;padding:4px 8px;border:1px solid ' . ($adic ? 'rgba(147,51,234,.35)' : 'var(--border)') . ';border-radius:8px;background:var(--surface);font-size:12px;min-width:0">'
        . '<b style="flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' . ($adic ? 'color:#9333ea' : '') . '" title="' . h($nome) . '">' . ($adic ? '👥 ' : '👤 ') . h($nome) . '</b>'
        . '<span style="white-space:nowrap">' . $sit . '</span>' . ($lgs !== '' ? '<span class="ws-muted" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:45%" title="' . h($lgs) . '">' . h($lgs) . '</span>' : '') . '</div>'; };
    // 19/11/2026: uma linha por cliente online (titular e cada adicional), com o IP público e as portas Entrada/Saída do CGNAT.
    if (!function_exists('ws_cgnat_versao_em') && is_file(__DIR__ . '/cgnat_lib.php')) require_once __DIR__ . '/cgnat_lib.php';
    $vCgOn = null; try { if (function_exists('ws_cgnat_versao_em')) $vCgOn = ws_cgnat_versao_em($db, date('Y-m-d H:i:s')); } catch (Throwable $e) {}
    $linhasOn = []; $ctOn = [];
    $ordOn = array_values(array_unique($online));
    usort($ordOn, function ($x, $y) use ($dono) { return (int)(($dono[$x][1] ?? false) ? 1 : 0) <=> (int)(($dono[$y][1] ?? false) ? 1 : 0); });
    try { $idsOn = array_merge([(int)$clienteId], array_map(fn($x) => (int)$x['id'], $adics));
          $phOn = implode(',', array_fill(0, count($idsOn), '?')); $qOn = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id IN ($phOn) AND COALESCE(status,'') <> 'cancelado'");
          $qOn->execute($idsOn); $ctOn = $qOn->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) {}
    $vistoOn = [];
    foreach ($ordOn as $lgOn) {
        $dnOn = $dono[$lgOn] ?? ['', false, 0];
        if (isset($vistoOn[$dnOn[0].'|'.(int)$dnOn[1]])) continue; $vistoOn[$dnOn[0].'|'.(int)$dnOn[1]] = 1;
        $nm1 = $dnOn[1] ? $dnOn[0] : ($nmTit !== '' ? $nmTit : 'Titular');
        $ipOn = ''; $pIn = ''; $pOut = '';
        foreach ($sess as $sxOn) { if ($sxOn['username'] === $lgOn && empty($sxOn['acctstoptime']) && !empty($sxOn['framedipaddress'])) {
            try { if ($vCgOn && function_exists('ws_cgnat_publico')) { $mOn = ws_cgnat_publico($db, (int)$vCgOn['id'], (int)ip2long($sxOn['framedipaddress']));
                if ($mOn) { $ipOn = long2ip($mOn['ip_publico']); $pIn = $mOn['porta_ini']; $pOut = $mOn['porta_fim']; } } } catch (Throwable $e) {}
            break; } }
        if ($ipOn === '') { $ipVivo = '';
            try { $fq = $db->prepare("SELECT framedipaddress FROM radacct WHERE username = ? AND acctstoptime IS NULL AND COALESCE(framedipaddress,'') NOT IN ('','0.0.0.0') ORDER BY acctstarttime DESC LIMIT 1"); $fq->execute([(string)$lgOn]); $ipVivo = (string)($fq->fetchColumn() ?: ''); } catch (Throwable $e) {}
            if ($ipVivo === '') foreach ($ctOn as $ctR) { if ((string)($ctR['login_pppoe'] ?? '') === (string)$lgOn || (string)($ctR['login_ipoe'] ?? '') === (string)$lgOn) {
                try { if (function_exists('ws_contrato_ip_vivo')) $ipVivo = (string)ws_contrato_ip_vivo($db, $ctR); } catch (Throwable $e) {}
                if ($ipVivo !== '') break; } }
            if ($ipVivo !== '') { try { if ($vCgOn && function_exists('ws_cgnat_publico')) { $mOn = ws_cgnat_publico($db, (int)$vCgOn['id'], (int)ip2long($ipVivo));
                if ($mOn) { $ipOn = long2ip($mOn['ip_publico']); $pIn = $mOn['porta_ini']; $pOut = $mOn['porta_fim']; } } } catch (Throwable $e) {} } }
        $linhasOn[] = '<tr><td style="padding:2px 18px 2px 0;white-space:nowrap">🟢 Online agora: <b' . ($dnOn[1] ? ' style="color:#9333ea"' : ' style="color:var(--ok)"') . '>' . h($nm1) . '</b></td>'
            . ($ipOn !== '' ? '<td style="padding:2px 18px 2px 0;white-space:nowrap">IP Público atual: <b>' . h($ipOn) . '</b></td><td style="padding:2px 18px 2px 0;white-space:nowrap">Porta Entrada: <b>' . (int)$pIn . '</b></td><td style="padding:2px 0;white-space:nowrap">Porta Saída: <b>' . (int)$pOut . '</b></td>'
                            : '<td colspan="3" style="padding:2px 0;white-space:nowrap" class="ws-muted">sem IP público no CGNAT</td>')
            . '</tr>';
    }
    echo $linhasOn ? '<table style="border-collapse:collapse;width:auto;font-size:13px;margin:2px 0 4px"><tbody>' . implode('', $linhasOn) . '</tbody></table>' : '<p class="ws-muted" style="font-size:13px">⚪ Offline no momento</p>';
    ?>
      <table class="ws-table"><thead><tr>
        <th>Cliente</th><th>Login</th><th>IP</th><th>Início</th><th>Fim</th><th>↓ Download</th><th>↑ Upload</th><th>MAC</th>
      </tr></thead><tbody>
      <?php $iS = 0; $vistoCx = []; foreach ($sess as $s): $aberta = empty($s['acctstoptime']); $dn = $dono[$s['username']] ?? ['', false, 0]; $iS++; ?>
        <tr<?= $iS > 10 ? ' class="ws-cx-smais" style="display:none"' : '' ?>>
          <td style="text-align:left;white-space:nowrap"><?= $dn[1] ? $tagAd($dn[0], $dn[2]) : '<b>👤 ' . h($nmTit !== '' ? $nmTit : 'Titular') . '</b>' ?></td>
          <td><?= h($s['username']) ?> <?php $ultCx = !isset($vistoCx[$s['username']]); $vistoCx[$s['username']] = 1; ?><?= !$ultCx ? '' : ($aberta?'<a href="mk_monitor.php?acao=trafego&login='.urlencode((string)$s['username']).'" target="_blank" class="ws-tag ativo" style="font-size:10px;text-decoration:none;cursor:pointer" title="Abrir o gráfico ao vivo desta conexão">online</a>':'<span class="ws-tag" style="font-size:10px;background:rgba(100,116,139,.14);color:#64748b;border:1px solid rgba(100,116,139,.35)">offline</span>') ?></td>
          <td><a href="#" onclick="if(typeof wsAbrirIP==='function'){wsAbrirIP('<?= h($s['framedipaddress']) ?>');}else{window.open('http://<?= h($s['framedipaddress']) ?>','_blank');}return false;" title="Acessar o equipamento" style="text-decoration:underline"><?= h($s['framedipaddress']) ?></a></td>
          <td><?= $s['acctstarttime'] ? date('d/m/Y H:i\h', strtotime($s['acctstarttime'])) : '—' ?></td>
          <td><?= $s['acctstoptime'] ? date('d/m/Y H:i\h', strtotime($s['acctstoptime'])) : '<span class="ws-muted">em curso</span>' ?></td>
          <td><?= $mb($s['acctoutputoctets']) ?></td><td><?= $mb($s['acctinputoctets']) ?></td>
          <td><?= h($s['callingstationid']) ?></td>
        </tr>
      <?php endforeach; if(!$sess) echo '<tr><td colspan="8" class="ws-muted">Nenhuma sessão registrada ainda (o FreeRADIUS grava aqui via accounting).</td></tr>'; ?>
      </tbody></table>
      <?php if (count($sess) > 10) echo '<button type="button" class="ws-btn" style="font-size:12px;margin:6px 0 0" data-rot="▾ Ver todas as sessões ('.count($sess).')" onclick="var ex=this.parentNode.querySelectorAll(\'.ws-cx-smais\'),ab=this.getAttribute(\'data-ab\')!==\'1\';ex.forEach(function(e){e.style.display=ab?(e.getAttribute(\'data-show\')||\'\'):\'none\';});this.setAttribute(\'data-ab\',ab?\'1\':\'0\');this.textContent=ab?\'▴ Recolher\':this.getAttribute(\'data-rot\');">▾ Ver todas as sessões ('.count($sess).')</button>'; ?>
    <?php
}

/* --------- Timeline do cliente (eventos + chamados + faturas + notificações) --------- */
function ws_bloco_timeline(PDO $db, int $clienteId): void {
    $itens = [];
    foreach ($db->query("SELECT criado_em, tipo, texto FROM ws_evento WHERE cliente_id=$clienteId ORDER BY id DESC LIMIT 60")->fetchAll() as $e)
        $itens[] = [$e['criado_em'], $e['tipo'], $e['texto']];
    foreach ($db->query("SELECT criado_em, titulo, status FROM ws_chamado WHERE cliente_id=$clienteId ORDER BY id DESC LIMIT 20")->fetchAll() as $c)
        $itens[] = [$c['criado_em'], 'chamado', 'Chamado: ' . $c['titulo'] . ' (' . str_replace('_',' ',$c['status']) . ')'];
    foreach ($db->query("SELECT criado_em, competencia, valor, status FROM ws_fatura WHERE cliente_id=$clienteId ORDER BY id DESC LIMIT 20")->fetchAll() as $f)
        $itens[] = [$f['criado_em'], 'fatura', 'Fatura ' . $f['competencia'] . ' — R$ ' . number_format($f['valor'],2,',','.') . ' (' . $f['status'] . ')'];

    usort($itens, fn($a,$b) => strcmp($b[0], $a[0]));
    $itens = array_slice($itens, 0, 40);
    $ico = ['cliente'=>'👤','contrato'=>'📄','fatura'=>'🧾','pagamento'=>'💰','bloqueio'=>'⛔','desbloqueio'=>'✅','chamado'=>'🛠️'];
    ?>
    <div class="ws-head-row ws-tarja" style="margin-top:30px;cursor:pointer" onclick="var b=document.getElementById('wsTlBox');var c=document.getElementById('wsTlChv');var h=b.style.display==='none';b.style.display=h?'':'none';if(c)c.textContent=h?'▾':'▸';" title="Clique para recolher/expandir">
      <h3 style="display:flex;align-items:center;gap:8px">🕓 Histórico (timeline)</h3><span id="wsTlChv" style="font-size:22px;line-height:1;color:var(--brand)">▾</span></div>
    <div id="wsTlBox">
    <div class="ws-timeline">
      <?php $tlLim = 8; $tlTot = count($itens); $tlI = 0;
      foreach ($itens as [$dt,$tp,$tx]): $tlI++; $extra = $tlI > $tlLim; ?>
        <div class="ws-tl-item<?= $extra ? ' ws-tl-extra' : '' ?>"<?= $extra ? ' style="display:none;cursor:pointer"' : ' style="cursor:pointer"' ?>
             onclick="wsHistVer(this)" title="Clique para ver, imprimir ou baixar"
             data-ico="<?= h($ico[$tp] ?? '•') ?>" data-tp="<?= h(ucfirst(str_replace('_',' ',$tp))) ?>"
             data-tx="<?= h($tx) ?>" data-dt="<?= date('d/m/Y H:i\h', strtotime($dt)) ?>">
          <span class="ws-tl-ico"><?= $ico[$tp] ?? '•' ?></span>
          <div><div><?= h($tx) ?></div><div class="ws-muted" style="font-size:12px"><?= date('d/m/Y H:i\h', strtotime($dt)) ?></div></div>
          <span style="margin-left:auto;color:var(--brand);font-size:13px;opacity:.6">🔎</span>
        </div>
      <?php endforeach; if(!$itens) echo '<p class="ws-muted">Sem histórico ainda.</p>'; ?>
    </div>
    <?php if ($tlTot > $tlLim): ?>
      <button type="button" class="ws-btn" style="font-size:12px;margin-top:6px" id="wsTlBtn"
        onclick="document.querySelectorAll('.ws-tl-extra').forEach(function(e){e.style.display='';});this.style.display='none';">▾ Ver todo o histórico (<?= $tlTot ?>)</button>
    <?php endif; ?>
    </div><?php // fecha #wsTlBox (recolhível pelo título) ?>

    <!-- Janela de detalhe de um evento do histórico (ver / imprimir / baixar) -->
    <div id="wsHistOv" class="ws-modal-ov" style="display:none" onclick="if(event.target===this)this.style.display='none'">
      <div class="ws-modal" style="max-width:440px">
        <div id="wsHistBody"></div>
        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px">
          <button type="button" class="ws-btn" onclick="document.getElementById('wsHistOv').style.display='none'">Fechar</button>
          <button type="button" class="ws-btn primary" onclick="wsHistImprimir()">🖨️ Imprimir / Baixar PDF</button>
        </div>
      </div>
    </div>
    <script>
    function wsHistVer(el){
      var d=window.__wsHist={ico:el.dataset.ico||'•',tp:el.dataset.tp||'',tx:el.dataset.tx||'',dt:el.dataset.dt||''};
      var esc=function(s){var t=document.createElement('div');t.textContent=s;return t.innerHTML;};
      document.getElementById('wsHistBody').innerHTML=
        '<div style="text-align:center;font-size:40px;line-height:1">'+esc(d.ico)+'</div>'+
        '<h3 style="text-align:center;color:var(--brand);margin:4px 0 14px">Detalhe do histórico</h3>'+
        '<div class="ws-hist-l"><b>Tipo</b><span>'+esc(d.tp)+'</span></div>'+
        '<div class="ws-hist-l"><b>Data e Hora</b><span>'+esc(d.dt)+'</span></div>'+
        '<div class="ws-hist-l"><b>Ação registrada</b><span>'+esc(d.tx)+'</span></div>';
      document.getElementById('wsHistOv').style.display='flex';
    }
    function wsHistImprimir(){
      var d=window.__wsHist||{},esc=function(s){var t=document.createElement('div');t.textContent=s;return t.innerHTML;};
      var w=window.open('','_blank','width=540,height=600');if(!w)return;
      w.document.write('<!doctype html><meta charset="utf-8"><title>Histórico do cliente</title>'+
        '<style>body{font-family:Segoe UI,Arial,sans-serif;color:#1f2937;max-width:460px;margin:24px auto;padding:0 18px}'+
        '.ico{text-align:center;font-size:48px}.tit{text-align:center;color:#9E2A3B;font-weight:800;font-size:19px;margin:2px 0 16px}'+
        '.l{display:flex;justify-content:space-between;gap:12px;border-bottom:1px dashed #e5e7eb;padding:8px 0}.l b{color:#374151}'+
        '.rod{text-align:center;color:#6b7280;font-size:11px;margin-top:22px}</style>'+
        '<div class="ico">'+esc(d.ico||'•')+'</div><div class="tit">Detalhe do histórico</div>'+
        '<div class="l"><b>Tipo</b><span>'+esc(d.tp||'')+'</span></div>'+
        '<div class="l"><b>Data e Hora</b><span>'+esc(d.dt||'')+'</span></div>'+
        '<div class="l"><b>Ação registrada</b><span>'+esc(d.tx||'')+'</span></div>'+
        '<div class="rod">Gerado em '+new Date().toLocaleString('pt-BR')+'</div>');
      w.document.close();w.focus();setTimeout(function(){w.print();},250);
    }
    </script>
    <?php
}

/* --------- Anexos do cliente (galeria + upload) --------- */
function ws_bloco_anexos(PDO $db, int $clienteId): void {
    if (!empty($_SESSION['ws_flash_err'])) { echo '<div class="ws-alert err">'.h($_SESSION['ws_flash_err']).'</div>'; unset($_SESSION['ws_flash_err']); }
    $st = $db->prepare("SELECT * FROM ws_anexo WHERE cliente_id=? ORDER BY id DESC"); $st->execute([$clienteId]);
    $rows = $st->fetchAll();
    $rot = ['documento'=>'Documento','foto_instalacao'=>'Foto instalação','onu'=>'ONU','contrato'=>'Contrato','outro'=>'Outro'];
    ?>
    <div class="ws-head-row ws-tarja"><h3>📎 Anexos (documentos / fotos)</h3></div>
    <form method="post" enctype="multipart/form-data" class="ws-form" style="max-width:none;flex-direction:row;flex-wrap:wrap;align-items:flex-end;gap:10px">
      <input type="hidden" name="acao" value="upload_anexo"><input type="hidden" name="cliente_id" value="<?= $clienteId ?>">
      <label style="flex:1;min-width:180px">Tipo <select name="tipo">
        <?php foreach ($rot as $k=>$v) echo "<option value='$k'>".h($v)."</option>"; ?>
      </select></label>
      <label style="flex:1;min-width:140px">Arquivo (até 8MB) <input type="file" name="arquivo" accept="image/*,application/pdf" required></label>
      <button class="ws-btn primary">Enviar</button>
      <a href="chamados.php?p=lista&cliente=<?= $clienteId ?>" class="ws-btn" title="Histórico de chamados" target="_blank" style="padding:0 12px;display:flex;align-items:center;justify-content:center;height:38px;text-decoration:none;white-space:nowrap">📋 Histórico de chamado</a>
    </form>
    <form method="post" onsubmit="return confirm('Excluir anexos marcados?')">
      <input type="hidden" name="acao" value="del_anexos_massa">
      <input type="hidden" name="cliente" value="<?= $clienteId ?>">
      <div class="ws-galeria" style="margin-top:10px">
        <?php foreach ($rows as $a): ?>
          <div class="ws-anexo" style="position:relative">
            <input type="checkbox" name="ids[]" value="<?= $a['id'] ?>" style="position:absolute;top:6px;left:6px;width:18px;height:18px;cursor:pointer">
            <a href="anexo.php?id=<?= $a['id'] ?>" target="_blank">
              <?php if (ws_anexo_eh_imagem($a['mime'])): ?>
                <img src="anexo.php?id=<?= $a['id'] ?>" alt="<?= h($a['nome_original']) ?>">
              <?php else: ?><div class="ws-anexo-pdf">PDF</div><?php endif; ?>
            </a>
            <div class="ws-anexo-meta" style="padding-left:28px"><span><?= h($rot[$a['tipo']] ?? $a['tipo']) ?></span>
              <a href="erp.php?del_anexo=<?= $a['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Excluir anexo?')" class="ws-anexo-x">✕</a></div>
          </div>
        <?php endforeach; if(!$rows) echo '<p class="ws-muted" style="margin:0">Nenhum anexo ainda.</p>'; ?>
      </div>
      <?php if ($rows): ?>
        <button class="ws-btn danger" style="margin-top:10px">Excluir marcados</button>
      <?php endif; ?>
    </form>
    <?php
}

/* --------- Contratos do cliente (dentro da ficha) --------- */
function ws_bloco_contratos(PDO $db, int $clienteId, ?callable $apósConexaoCallback = null): void {
    $st = $db->prepare("SELECT ct.*, p.nome plano, p.valor plano_valor FROM ws_contrato ct LEFT JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=? ORDER BY ct.id");
    $st->execute([$clienteId]); $rows = $st->fetchAll();
    $nq = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $nq->execute([$clienteId]); $cNome = (string)$nq->fetchColumn();
    $temAtivo = (bool)array_filter($rows, fn($r) => $r['status'] === 'ativo');
    // Vencimento padrão do botão "Gerar boleto": usa o DIA cadastrado no contrato (dia_vencimento),
    // não uma data fixa arbitrária. Pega a PRÓXIMA ocorrência desse dia a partir de hoje.
    $diaVencCad = null;
    foreach ($rows as $rr) { if (!empty($rr['dia_vencimento'])) { $diaVencCad = (int)$rr['dia_vencimento']; break; } }
    // Valor padrão do botão "Gerar boleto": usa o valor cadastrado no contrato ativo (ou o 1º), pra
    // preencher o campo sozinho — igual já acontece com a data — mas o campo continua editável.
    $valorCtPadrao = null;
    // Usa o valor do CONTRATO; se estiver vazio (contrato "puxa do plano"), cai no valor do PLANO.
    foreach ($rows as $rr) {
        $v = !empty($rr['valor']) ? (float)$rr['valor'] : (!empty($rr['plano_valor']) ? (float)$rr['plano_valor'] : 0);
        if ($v > 0) { $valorCtPadrao = $v; break; }
    }
    if ($diaVencCad) {
        $diaVencCad = max(1, min(31, $diaVencCad));
        $hoje = new DateTime('today');
        $anoF = (int)date('Y');
        $mesF = (int)date('m');
        $diaLim = (int)date('t', mktime(0, 0, 0, $mesF, 1, $anoF));
        $diaF_real = min($diaVencCad, $diaLim);
        $candidata = new DateTime(sprintf('%04d-%02d-%02d', $anoF, $mesF, $diaF_real));
        if ($candidata < $hoje) {
            $nextMes = $mesF == 12 ? 1 : $mesF + 1;
            $nextAno = $mesF == 12 ? $anoF + 1 : $anoF;
            $nextDiaLim = (int)date('t', mktime(0, 0, 0, $nextMes, 1, $nextAno));
            $diaF_real = min($diaVencCad, $nextDiaLim);
            $candidata = new DateTime(sprintf('%04d-%02d-%02d', $nextAno, $nextMes, $diaF_real));
        }
        $vencPadrao = $candidata->format('Y-m-d');
    } else {
        $vencPadrao = date('Y-m-d', strtotime('+7 days')); // sem contrato/dia cadastrado ainda: fallback antigo
    }
    /* ABRE COM A DATA DE HOJE — pedido do provedor. O campo nasce no dia de hoje; quem quiser
     * outra data muda ali mesmo. A trava de NÃO criar boleto para trás continua no servidor
     * (ws_venc_passado), nunca no campo — foi assim que o provedor pediu. */
    $vencPadrao = date('Y-m-d');
    ?>
    <?php
    // Cabeçalho do TITULAR: faixa colorida discreta (mesmo desenho da tarja do adicional, na cor da
    // marca) com o nome do cliente — assim titular e adicionais ficam na mesma "lista", distinguíveis
    // pela cor. Na página do ADICIONAL o rótulo vira "(Adicional)".
    $ehAdicCt = false;
    try { $ta = $db->prepare("SELECT titular_id FROM ws_cliente WHERE id=?"); $ta->execute([$clienteId]); $ehAdicCt = (bool)$ta->fetchColumn(); } catch (Throwable $e) {}
    echo ws_conexao_assets() . ws_copiavel_assets();   // antes do 1º título: <style>/<script> fora do <h3>
    ?>
    <div class="ws-head-row ws-tarja ws-tarja-titular" id="ws-conexao-cliente">
      <h3><span class="ws-cc-titulo">Cadastro de Conexão (<?= $ehAdicCt ? 'Adicional' : 'Titular' ?>)</span>
        <?php if ($cNome !== ''): ?> — <span class="ws-cc-nome"><?= ws_copiavel($cNome) ?></span><?php endif; ?></h3>
      <?php if ($temAtivo): ?>
        <span class="ws-btn" style="opacity:.8;cursor:not-allowed;pointer-events:none;color:var(--text);border-color:var(--muted)" title="Este cliente já tem um contrato ativo — cancele-o antes de criar outro">Novo contrato</span>
      <?php else: ?>
        <a class="ws-btn primary" href="erp.php?p=contrato&cliente=<?= $clienteId ?>">Novo contrato</a>
      <?php endif; ?>
    </div>
    <div class="ws-cx-wrap"><table class="ws-table ws-cx-tab"><?= ws_cx_colgroup() ?><thead><tr>
      <th>#</th><th>Login</th><th>Tipo</th><th>Plano</th><th>VLAN</th><th>SN ONU / ONT</th><th>Venc.</th><th>Conexão</th><th style="text-align:center">Ações</th>
    </tr></thead><tbody>
    <?php foreach ($rows as $r):
      $emConf = ws_rad_em_confianca($r); $bloq = ws_rad_deve_bloquear($db, $r); ?>
      <tr><td><?= $r['id'] ?></td><td><?= ws_copiavel($r['login_pppoe']) ?></td><td><?= strtoupper(h($r['tipo_conexao'])) ?></td>
      <td><?= ws_copiavel($r['plano']) ?></td><td><?= h($r['vlan'] ?? '') ?></td><td><?= ws_copiavel($r['sn_onu']) ?></td><td><?= h($r['dia_vencimento']) ?></td>
      <td><span class="ws-tag <?= $emConf?'confianca':($bloq?'bloqueado':'ativo') ?>"><?= $emConf?'confiança':($bloq?'bloqueado':'ativo') ?></span></td>
      <td><div class="ws-acoes" style="justify-content:center">
        <a href="erp.php?p=contrato&id=<?= $r['id'] ?>" title="Editar contrato">✏️ editar</a>
        <a href="financeiro.php?p=faturas&q=<?= urlencode($r['login_pppoe']) ?>" title="Ver boletos do cliente">🧾 boletos</a>
        <?php if (!empty($r['login_pppoe'])): ?><a href="erp.php?cli_acao=derrubar&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Derrubar a conexão (disconnect) no concentrador?')" title="Enviar disconnect ao concentrador" style="color:var(--warn)">📴 derrubar</a><?php endif; ?>
        <?php if ($bloq): ?>
          <a href="erp.php?cli_acao=desbloquear&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" style="color:var(--ok)"><?= ws_icon('desbloqueio') ?> desbloquear</a>
        <?php endif; ?>
        <?php if ($bloq || $emConf): ?><a href="#" class="fic-conf" data-cli="<?= $clienteId ?>" data-nome="<?= h($cNome) ?>" data-login="<?= h($r['login_pppoe'] ?? '') ?>" data-plano="<?= h($r['plano'] ?? '') ?>" data-emconf="<?= $emConf?1:0 ?>" data-bloq="<?= $bloq?1:0 ?>" data-ate="<?= !empty($r['confianca_ate'])?h(date('d/m/Y H:i\h',strtotime((string)$r['confianca_ate']))):'' ?>" style="color:#9333ea"><?= ws_icon('cadeado') ?> confiar</a><?php endif; ?>
        <?php if (!$bloq): ?>
          <a href="erp.php?cli_acao=bloquear&contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Bloquear a conexão?')" style="color:var(--err)">⛔ bloquear</a>
        <?php endif; ?>
        <a href="erp.php?del_contrato=<?= $r['id'] ?>&cliente=<?= $clienteId ?>" onclick="return confirm('Excluir esta conexão/contrato? (remove do RADIUS)')" style="color:var(--err)"><?= ws_icon('lixeira') ?> excluir</a>
      </div></td></tr>
    <?php endforeach; if (!$rows) echo '<tr><td colspan="9" class="ws-muted">Sem contratos.</td></tr>'; ?>
    </tbody></table></div>

    <!-- Desbloqueio em confiança na ficha: MESMO modal/calendário de Menu Clientes/Todos e do
         Painel dos Concentradores (js/ws_confianca.js) — unificado em elegant/moderno/funcional. -->
    <script>
    (function(){
      document.querySelectorAll('a.fic-conf').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();
        var d=a.dataset;
        // Cliente OK (não bloqueado e não em confiança) -> não faz sentido confiar: ERRO.
        if(d.emconf!=='1' && d.bloq!=='1'){alert('⚠️ Este cliente NÃO está bloqueado nem em desbloqueio de confiança. O desbloqueio em confiança só vale para clientes bloqueados/inadimplentes.');return;}
        // Mesmo fluxo compartilhado das outras telas (aviso de "já em confiança" + histórico).
        wsConfianca({
          login: d.login || '',
          clienteId: d.cli,
          nome: d.nome || '',
          jaEmConfiancaAte: d.emconf === '1' ? d.ate : '',
          onConfirmar: function(dias){ location = 'erp.php?cli_confiar=' + d.cli + '&aviso_ok=1&dias=' + dias + '&volta=' + encodeURIComponent(location.pathname.split('/').pop() + location.search); }
        });
      });});
    })();
    </script>

    <?php // Item 1: injeta aqui o(s) bloco(s) de "Cadastro de Conexão" dos clientes adicionais,
          // ACIMA de "Títulos do cliente" (antes ficavam só no fim da ficha). ?>
    <?php if ($apósConexaoCallback) { $apósConexaoCallback(); } ?>

    <?php // Faturas em aberto do cliente
    $fs = $db->prepare("SELECT f.*, ct.login_pppoe FROM ws_fatura f LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
                        WHERE f.cliente_id=? AND f.status IN('aberto','vencido','processando') AND (f.contrato_id IS NOT NULL OR NOT EXISTS(SELECT 1 FROM ws_cliente cc WHERE cc.id=f.cliente_id AND cc.status='cancelado')) ORDER BY f.vencimento");
    $fs->execute([$clienteId]); $fat = $fs->fetchAll(); $totAberto = array_sum(array_column($fat, 'valor')); ?>
      <div class="ws-head-row ws-tarja" id="titulos" style="margin-top:20px;scroll-margin-top:80px"><h3>💳 Títulos do cliente</h3></div>
      <script>
      /* VEIO DO NÚMERO VERDE DE BOLETOS (lista de clientes → #titulos). A ficha é longa e monta em
         partes, então o navegador às vezes fica no topo mesmo com a âncora na URL. Aqui a rolagem é
         refeita depois que a página termina de montar, e a tarja pisca uma vez para o operador ver
         onde caiu. Sem âncora na URL, nada disto roda. */
      (function(){ if (location.hash !== '#titulos') return;
        function ir(){ var el=document.getElementById('titulos'); if(!el) return;
          el.scrollIntoView({block:'start'});
          el.classList.add('ws-tarja-piscar'); setTimeout(function(){ el.classList.remove('ws-tarja-piscar'); }, 1800); }
        if (document.readyState === 'complete') { ir(); setTimeout(ir, 300); }
        else window.addEventListener('load', function(){ ir(); setTimeout(ir, 300); });
      })();
      </script>
      <?php // Títulos recém-criados nesta sessão: marca "novo" + "PIX/QR" (some ao abrir/salvar/sair — some no próximo load).
            $ws_novos = array_map('intval', (array)($_SESSION['ws_titulo_novo'] ?? [])); ?>
      <table class="ws-table ws-table-titulos"><thead><tr>
        <?php /* A caixa de marcar do cabeçalho tem que cair na MESMA vertical das caixas das linhas.
                 Ela não caía: aqui a caixa e o "+" eram centralizados JUNTOS, como um bloco, então a
                 caixa sobrava meia largura do "+" para a esquerda — nas linhas de baixo a caixa é
                 centralizada sozinha. Some 4px de espaço e ~9px do "+": dava ~6,5px de diferença,
                 pouco para chamar atenção e o bastante para a coluna parecer torta.
                 A correção tira o "+" da conta do centro (position:absolute): a caixa passa a ser o
                 único conteúdo que o flex centraliza, e o alinhamento sai exato sem número mágico —
                 continua certo se a fonte, o zoom ou a largura da coluna mudarem. */ ?>
        <th class="sel"><span style="position:relative;display:inline-flex;align-items:center;justify-content:center"><input type="checkbox" onclick="fbAll(this)"><a href="#" class="ws-mais-simples" onclick="bolAbrir();return false;" title="Atrelar" style="position:absolute;left:100%;margin-left:4px">+</a></span></th>
        <th>Título</th><th>Tipo</th><th>Status</th><th>Vencimento</th><th>Nosso número</th><th style="text-align:right">Valor</th></tr></thead><tbody>
      <?php foreach ($fat as $f): $vencido = strtotime($f['vencimento']) < strtotime('today'); $ehNovo = in_array((int)$f['id'], $ws_novos, true); ?>
        <tr>
          <td class="sel"><input type="checkbox" class="fbchk" value="<?= $f['id'] ?>"></td>
          <td><b>#<?= $f['id'] ?></b><?= $ehNovo ? ' <span class="ws-badge-novo">novo</span>' : '' ?></td>
          <td><?php
              // Categoria = o que foi apontado ao gerar (Serviço/Venda/Outros). Sem categoria, cai no padrão antigo.
              $catRot = ['servico'=>'Serviço','venda'=>'Venda','outros'=>'Outros','mensalidade'=>'Mensalidade'];
              $cat = $f['categoria'] ?? '';
              echo h($cat !== '' ? ($catRot[$cat] ?? ucfirst($cat)) : ($f['competencia'] ? 'Mensalidade' : 'Avulso'));
          ?></td>
          <td><span class="ws-tag <?= $vencido?'bloqueado':($f['status']==='pago'?'ativo':($f['status']==='aberto'?'aberto':'inativo')) ?>"><?= h(ucfirst($f['status'])) ?></span></td>
          <td><?= date('d/m/y', strtotime($f['vencimento'])) ?> <span class="ws-muted" style="font-size:11px">[ <?= (int)floor((strtotime($f['vencimento'])-strtotime('today'))/86400) ?> ]</span></td>
          <td class="ws-muted"><?php $nnC = str_pad((string)$f['id'],8,'0',STR_PAD_LEFT); $nnDvC = (array_sum(str_split($nnC))*7)%10; echo h($nnC.'-'.$nnDvC);
              echo ws_selo_titulo($f, (bool)$ehNovo);   // Lytex / gateway / próprio — nomes em Financeiro → Gateway ?></td>
          <td style="text-align:right"><b>R$ <?= number_format($f['valor'],2,',','.') ?></b></td>
        </tr>
        <tr class="ws-linha-acoes">
          <td colspan="7" style="text-align:left">
            <a href="boleto.php?fatura=<?= $f['id'] ?>" target="_blank" title="Boleto próprio com PIX/QR">Boleto</a> |
            <a href="#" class="fic-rc" data-id="<?= $f['id'] ?>" data-nome="<?= h($cNome ?? '') ?>" data-valor="<?= (float)$f['valor'] ?>" data-taxa="<?= ws_fatura_taxa_efetiva($f) ?>" data-venc="<?= h($f['vencimento']) ?>" style="color:var(--ok);font-weight:700">Receber</a> |
            <a href="financeiro.php?p=fatura&id=<?= $f['id'] ?>">Alterar</a> |
            <a href="#" onclick="fbEnviarUm(<?= (int)$f['id'] ?>);return false;" title="Enviar o boleto ao contato do cliente (emite no gateway se ainda não foi emitido)">Enviar</a> |
            <a href="financeiro.php?p=fatura&id=<?= $f['id'] ?>" title="Ver detalhes">Informações</a> |
            <a href="#" class="fic-nota" data-id="<?= $f['id'] ?>" data-obs="<?= h($f['obs'] ?? '') ?>" data-venc="<?= h($f['vencimento']) ?>"><?= !empty($f['obs']) ? '📝 ' : '' ?>Notas</a> |
            <a href="#" onclick="wsExcluirTitulo({url:'erp.php',titulo:'Excluir título #<?= $f['id'] ?>',mensagem:'Isso apaga o boleto do sistema. Esta ação não pode ser desfeita.',campos:{acao:'del_fatura_confirmado',del_fatura:'<?= $f['id'] ?>',cliente:'<?= $clienteId ?>'}});return false;" style="color:var(--err)">Excluir</a>
          </td>
        </tr>
      <?php endforeach; if (!$fat) echo '<tr><td colspan="7" class="ws-muted">Nenhuma fatura em aberto.</td></tr>';
        else echo '<tr style="font-weight:800"><td></td><td colspan="5" class="ws-th-esq">Total em aberto</td><td style="text-align:right">R$ ' . number_format($totAberto,2,',','.') . '</td></tr>';
        unset($_SESSION['ws_titulo_novo']); // consumido: ao recarregar/voltar já não mostra "novo"/"PIX/QR" ?>
      </tbody></table>
      <div class="ws-toolbar-icones">
        <button type="button" class="ico verde" onclick="bolAbrir()" title="Novo boleto/carnê"><?= ws_icon('mais') ?></button>
        <button type="button" class="ico vermelho" onclick="fbExcluirSel()" title="Excluir selecionados"><?= ws_icon('lixeira') ?></button>
        <button type="button" class="ico azul" onclick="fbBoletoSel()" title="Ver/imprimir boleto dos selecionados (abre o PDF pronto pra impressão)"><svg class="ws-ico" viewBox="0 0 24 24" fill="currentColor"><path d="M6 3h12v4H6V3zm13 6H5a3 3 0 0 0-3 3v6h4v3h12v-3h4v-6a3 3 0 0 0-3-3zm-3 10H8v-4h8v4zm3-5.2a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/></svg></button>
        <button type="button" class="ico" style="background:#0f766e;color:#fff" onclick="fbQrSel()" title="Gerar só o QR Code do boleto dos selecionados (impressão na térmica 80mm ou impressora comum)"><svg class="ws-ico" viewBox="0 0 24 24" fill="currentColor"><path d="M3 3h8v8H3V3zm2 2v4h4V5H5zm8-2h8v8h-8V3zm2 2v4h4V5h-4zM3 13h8v8H3v-8zm2 2v4h4v-4H5zm8-2h2v2h-2v-2zm2 2h2v2h-2v-2zm2-2h2v2h-2v-2zm0 4h2v2h-2v-2zm-4 2h2v2h-2v-2zm2 0h2v2h-2v-2z"/></svg></button>
        <button type="button" class="ico roxo" onclick="fbEnviarSel()" title="Enviar cobrança por WhatsApp"><svg class="ws-ico" viewBox="0 0 24 24" fill="currentColor"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg></button>
      </div>
      <script>
        function fbSelecionados(){return Array.from(document.querySelectorAll('.fbchk:checked')).map(c=>c.value);}
        function fbExcluirSel(){var s=fbSelecionados();if(!s.length){alert('Marque ao menos um título.');return;}
          wsExcluirTitulo({url:'erp.php',titulo:'Excluir '+s.length+' título(s)',mensagem:'Isso apaga os boletos selecionados do sistema. Esta ação não pode ser desfeita.',campos:{acao:'del_fatura_lote_confirmado',del_fatura_lote:s.join(','),cliente:'<?= $clienteId ?>'}});}
        function fbBoletoSel(){var s=fbSelecionados();if(!s.length){alert('Marque ao menos um título.');return;}
          window.open('boleto.php?fatura='+s.join(','),'_blank');}
        function fbQrSel(){var s=fbSelecionados();if(!s.length){alert('Marque ao menos um título.');return;}
          window.open('boleto_qr.php?fatura='+s.join(','),'_blank');}
        /* ENVIO COM CAIXA DE PROGRESSO (01/10/2026): não abre mais a página grande — envia título a título e mostra
           "Enviando 2 de 5…", depois "Concluído". Mesmo endereço e mesmas regras do envio de sempre. */
        function wsEnvEnviar(f){
          var ids=(f.ids.value||'').split(',').filter(Boolean); if(!ids.length) return false;
          var ov=document.getElementById('wsEnvOv'), box=document.getElementById('wsEnvProg');
          if(!box){ box=document.createElement('div'); box.id='wsEnvProg'; box.style.cssText='padding:6px 2px 2px;text-align:center'; f.parentNode.appendChild(box); }
          f.style.display='none'; box.style.display='block';
          var ok=0, falha=[], i=0, tot=ids.length;
          function pinta(fim){
            var pct=Math.round(i*100/tot);
            box.innerHTML=(fim?'<div style="font-size:30px;margin:4px 0">'+(falha.length&&!ok?'⚠️':'✅')+'</div><b>'+(ok?'Concluído — '+ok+' enviado(s)':'Nada enviado')+'</b>'
              :'<b>Enviando '+Math.min(i+1,tot)+' de '+tot+'…</b>')
              +'<div style="height:8px;background:var(--border);border-radius:99px;margin:12px 0;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:var(--ok,#16a34a);transition:width .3s"></div></div>'
              +(falha.length?'<div class="ws-muted" style="font-size:12.5px;text-align:left;white-space:pre-line">'+falha.join('\n')+'</div>':'')
              +(fim?'<div style="margin-top:12px"><button type="button" class="ws-btn verde" id="wsEnvFechar">Fechar</button></div>':'');
            if(fim) document.getElementById('wsEnvFechar').onclick=function(){ ov.style.display='none'; box.style.display='none'; f.style.display=''; };
          }
          function prox(){
            if(i>=tot){ pinta(true); return; }
            pinta(false);
            var fd=new FormData(f); fd.set('ids',ids[i]); fd.set('ajax','1');
            fetch(f.getAttribute('action'),{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
              if(d&&d.ok) ok+=d.n||1;
              else falha.push('#'+ids[i]+': '+(d&&d.cancelado?'cliente desativado (envio proibido)':(d&&d.sem_sms?'SMS sem gateway configurado':'sem celular/e-mail ou gateway')));
              if(d&&d.erro_emissao) falha.push('Emissão: '+d.erro_emissao);
            }).catch(function(){ falha.push('#'+ids[i]+': falha de comunicação'); }).then(function(){ i++; prox(); });
          }
          prox(); return false;
        }
        function fbEnviarUm(id){document.getElementById('wsEnvOv').style.display='flex';document.getElementById('ws_env_ids').value=String(id);
          document.getElementById('ws_env_msg').value='Olá! Segue seu boleto.\nQualquer dúvida estamos à disposição.🤝';}
        function fbEnviarSel(){var s=fbSelecionados();if(!s.length){alert('Marque ao menos um título.');return;}
          document.getElementById('wsEnvOv').style.display='flex';
          document.getElementById('ws_env_ids').value=s.join(',');
          document.getElementById('ws_env_msg').value='Olá! Segue seu boleto.\nQualquer dúvida estamos à disposição.🤝';}
      </script>

      <!-- Modal: Enviar boleto (mensagem + anexo + canal) -->
      <div id="wsEnvOv" class="ws-modal-ov" style="display:none"><div class="ws-modal" style="max-width:440px">
        <h3>✉️ Enviar boleto</h3>
        <form method="post" action="financeiro.php?p=enviar_boleto" target="_blank" data-sem-confirmar onsubmit="return wsEnvEnviar(this)">
          <input type="hidden" name="ids" id="ws_env_ids">
          <input type="hidden" name="volta" value="erp.php?p=cliente&id=<?= $clienteId ?>">
          <label style="display:block;margin-bottom:8px">Mensagem<br>
            <textarea name="mensagem" id="ws_env_msg" style="width:100%;min-height:80px;padding:8px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)"></textarea></label>
          <label class="ws-chk" style="margin-bottom:8px"><input type="checkbox" name="anexar_pdf" checked> 📎 Anexar PDF do boleto</label>
          <label style="display:block;margin-bottom:12px">Enviar por<br>
            <select name="canal" style="width:100%">
              <option value="whatsapp">WhatsApp (gateway configurado)</option>
              <option value="email">E-mail (SMTP)</option>
              <option value="sms">SMS (gateway)</option>
              <option value="sistema">Só salvar (não enviar agora)</option>
            </select></label>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button type="button" class="ws-btn" onclick="document.getElementById('wsEnvOv').style.display='none'">Cancelar</button>
            <button class="ws-btn verde">Enviar</button>
          </div>
        </form>
      </div></div>

      <!-- Modal de recebimento NA PRÓPRIA FICHA (fica aqui, não vai pro financeiro) -->
      <?php $bkr = $db->query("SELECT multa_pct,juros_pct,max_dias_recalc FROM ws_banco WHERE ativo=1 ORDER BY id LIMIT 1")->fetch(); ?>
      <script>window.WS_MULTA=<?= (float)($bkr['multa_pct'] ?? 2) ?>;window.WS_JUROS=<?= (float)($bkr['juros_pct'] ?? 1) ?>;window.WS_MAXREC=<?= (int)($bkr['max_dias_recalc'] ?? 0) ?>;</script>
      <?php /* RECEBER COMPACTO: 2 colunas (Data|Modo · Título|Taxa · Multa|Acréscimo · Desconto|Valor Pago),
               Observação, recibo e botões na largura toda. Só CSS — campos e envio são os mesmos. */ ?>
      <style>
        #ficRcOv .ws-rc{max-width:600px!important}
        #ficRcOv form{display:grid;grid-template-columns:1fr 1fr;gap:4px 12px;align-items:end;padding:12px 14px 14px!important}
        #ficRcOv form>label,#ficRcOv form>div{margin:0!important}
        #ficRcOv .ws-rc-row{padding:3px 4px}
        #ficRcOv .ws-rc-total input{font-size:15px!important;color:var(--ok)!important;-webkit-text-fill-color:var(--ok)}
        #ficRcOv form>label:has([name="obs"]),#ficRcOv form>label:has([name="pago_por"]),#ficRcOv form>label.ws-chk,#ficRcOv form>div:last-of-type{grid-column:1/-1}
        #ficRcOv form input,#ficRcOv form select{height:36px}
        @media(max-width:560px){#ficRcOv form{grid-template-columns:1fr}}
      </style>
      <div id="ficRcOv" class="ws-modal-ov" style="display:none"><div class="ws-modal ws-rc" style="max-width:420px">
        <div class="ws-rc-head"><h3 style="margin:0">💰 Receber <span id="fic_rc_tit"></span></h3>
          <p id="fic_rc_av" style="font-size:13px;margin:4px 0 0;opacity:.92"></p></div>
        <form method="post" action="financeiro.php" style="padding:14px 16px 16px">
          <input type="hidden" name="acao" value="baixa_manual"><input type="hidden" name="fatura_id" id="fic_rc_fid">
          <input type="hidden" name="volta" value="erp.php?p=cliente&id=<?= $clienteId ?>">
          <label style="display:block;margin-bottom:8px">Data e Hora <span class="ws-dt-h"><input type="datetime-local" name="data_pgto" id="fic_rc_data" min="<?= date('Y-m-d\T00:00') ?>" max="<?= date('Y-m-d\T23:59') ?>" onclick="try{this.showPicker()}catch(e){}"><b>h</b></span></label>
          <label style="display:block;margin-bottom:8px">Modo de recebimento <select name="forma" class="ws-forma-sel"><option value="pix">💠 Pix</option><option value="dinheiro" selected>💵 Dinheiro</option><option value="cartao">💳 Cartão</option><option value="cheque">🧾 Cheque</option><option value="duplicata">📄 Duplicata</option><option value="outros">➕ Outros</option></select></label>
          <?php /* VALOR DA EMISSÃO separado (só leitura) + ACRÉSCIMO com "Zerar", no modelo do MK-Auth.
                   Valor Pago = emissão + multa/mora + acréscimo − desconto, somado sozinho. Nenhum destes
                   campos tem name: o servidor continua recebendo só o valor_pago, como antes. */ ?>
          <div class="ws-rc-row"><label style="flex:1;margin:0">Valor do título (sem a taxa)<br><input id="fic_rc_base" data-ws-money="1" value="0,00" title="Editável: ajuste o valor do título se precisar" style="text-align:right"></label></div>
          <?php /* TAXA DE EMISSÃO separada (modelo B): o título é o plano e a taxa fica em taxa_emissao. Aqui ela
                   aparece à parte e já vem INCLUÍDA no valor pago — marque "Zerar" para tirar. */ ?>
          <div class="ws-rc-row"><label style="flex:1;margin:0">Taxa de emissão<br><input id="fic_rc_tx" data-ws-money="1" value="0,00"></label>
            <label class="ws-chk ws-rc-zero"><input type="checkbox" id="fic_rc_tx_zero"> Zerar</label></div>
          <div class="ws-rc-row"><label style="flex:1;margin:0">Multa+Mora<br><input id="fic_rc_mm" value="0,00"></label>
            <label class="ws-chk ws-rc-zero"><input type="checkbox" id="fic_rc_mm_zero"> Zerar</label></div>
          <div class="ws-rc-row"><label style="flex:1;margin:0">Acréscimo<br><input id="fic_rc_acr" data-ws-money="1" value="0,00"></label>
            <label class="ws-chk ws-rc-zero"><input type="checkbox" id="fic_rc_acr_zero"> Zerar</label></div>
          <div class="ws-rc-row"><label style="flex:1;margin:0">Desconto<br><input id="fic_rc_desc" value="0,00"></label>
            <label class="ws-chk ws-rc-zero"><input type="checkbox" id="fic_rc_desc_zero"> Zerar</label></div>
          <label class="ws-rc-total" style="display:block;margin:10px 0 8px">Valor Pago <input name="valor_pago" id="fic_rc_vp"></label>
          <label style="display:block;margin-bottom:8px">Observação (opcional) <input name="obs" placeholder="ex: pagou com atraso, combinado com o cliente..."></label>
          <label style="display:block;margin-bottom:8px">Pagamento Realizado por (opcional) <input name="pago_por" maxlength="120" placeholder="ex.: Maria (mãe do titular), vizinho, empresa..."></label>
          <label class="ws-chk" style="margin-bottom:12px;font-size:13px;white-space:nowrap;display:flex!important;align-items:center;justify-content:flex-start!important;gap:6px"><input type="checkbox" name="enviar_recibo" style="margin:0;width:auto;flex:0 0 auto" <?= (is_file(__DIR__.'/whatsapp.php') && function_exists('ws_recibo_config') && !empty(ws_recibo_config()['auto'])) ? 'checked' : '' ?>> 📲 Enviar recibo por WhatsApp agora</label>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button type="button" class="ws-btn" onclick="document.getElementById('ficRcOv').style.display='none'">Cancelar</button>
            <button class="ws-btn verde">Receber</button></div>
        </form>
      </div></div>
      <script>
        (function(){var ov=document.getElementById('ficRcOv');if(!ov)return;
        var mm=document.getElementById('fic_rc_mm'),desc=document.getElementById('fic_rc_desc'),acr=document.getElementById('fic_rc_acr'),tx=document.getElementById('fic_rc_tx');
        var mmZ=document.getElementById('fic_rc_mm_zero'),descZ=document.getElementById('fic_rc_desc_zero'),acrZ=document.getElementById('fic_rc_acr_zero'),txZ=document.getElementById('fic_rc_tx_zero');
        function nbr(v){return parseFloat(String(v).replace(/\./g,'').replace(',','.'))||0;}
        function fbr(v){return v.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
        // ov._base = valor do título SEM a taxa; a taxa entra pelo próprio campo (zerável).
        function calc(){document.getElementById('fic_rc_vp').value=fbr(Math.max(0,ov._base+nbr(tx.value)+nbr(mm.value)+nbr(acr.value)-nbr(desc.value)));}
        // Máscara de dinheiro: digita os números e vira valor real (1 -> 0,01 · 100 -> 1,00 · 1000 -> 10,00).
        function moneyMask(el){var d=(el.value||'').replace(/\D/g,'');el.value=(parseInt(d||'0',10)/100).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
        function toggleZero(chk,inp,memoKey){if(chk.checked){inp.dataset[memoKey]=inp.value;inp.value='0,00';inp.disabled=true;}
          else{inp.disabled=false;if(inp.dataset[memoKey]!=null)inp.value=inp.dataset[memoKey];}inp.closest('.ws-rc-row').classList.toggle('off',chk.checked);calc();}
        function toEnd(el){var n=(el.value||'').length;try{el.setSelectionRange(n,n);}catch(e){}}
        // Valor do título EDITÁVEL: o que for digitado vira a nova base da soma (ov._base).
        var bs=document.getElementById('fic_rc_base');
        if(bs){bs.setAttribute('inputmode','numeric');bs.addEventListener('input',function(){moneyMask(bs);toEnd(bs);ov._base=nbr(bs.value);calc();});
          bs.addEventListener('focus',function(){setTimeout(function(){toEnd(bs);},0);});bs.addEventListener('mouseup',function(e){e.preventDefault();toEnd(bs);});}
        [mm,desc,acr,tx].forEach(function(el){el.setAttribute('inputmode','numeric');el.style.textAlign='right';
          el.addEventListener('input',function(){moneyMask(el);toEnd(el);calc();});
          el.addEventListener('focus',function(){setTimeout(function(){toEnd(el);},0);});
          el.addEventListener('mouseup',function(e){e.preventDefault();toEnd(el);});});
        mmZ.addEventListener('change',function(){toggleZero(mmZ,mm,'memo');});
        descZ.addEventListener('change',function(){toggleZero(descZ,desc,'memo');});
        acrZ.addEventListener('change',function(){toggleZero(acrZ,acr,'memo');});
        txZ.addEventListener('change',function(){toggleZero(txZ,tx,'memo');});
        document.querySelectorAll('a.fic-rc').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();
          var d=a.dataset,val=parseFloat(d.valor)||0,venc=new Date(d.venc+'T00:00'),hoje=new Date();hoje.setHours(0,0,0,0);
          var mpct=(window.WS_MULTA||2)/100,jdia=(window.WS_JUROS||1)/100/30;
          var dias=Math.max(0,Math.round((hoje-venc)/86400000)),mmv=dias>0?val*mpct+val*jdia*dias:0;
          ov._base=val;document.getElementById('fic_rc_tit').textContent='#'+d.id+' — '+d.nome;
          document.getElementById('fic_rc_av').textContent=dias>0?('⚠️ Vencido há '+dias+' dia(s)'+((window.WS_MAXREC>0&&dias>window.WS_MAXREC)?' — passou de '+window.WS_MAXREC+' dia(s): o título é cancelado na rotina diária':'')):'✔️ Em dia.';
          document.getElementById('fic_rc_fid').value=d.id;var _ag=new Date();_ag.setMinutes(_ag.getMinutes()-_ag.getTimezoneOffset());document.getElementById('fic_rc_data').value=_ag.toISOString().slice(0,16);
          mmZ.checked=false;descZ.checked=false;acrZ.checked=false;txZ.checked=false;mm.disabled=false;desc.disabled=false;acr.disabled=false;tx.disabled=false;
          [mm,desc,acr,tx].forEach(function(el){el.closest('.ws-rc-row').classList.remove('off');});
          // Modelo B: o título É o plano; a taxa de emissão já vem INCLUÍDA no valor pago (marque "Zerar" para tirar).
          var taxa=Math.max(0,parseFloat(d.taxa)||0);
          ov._base=val; tx.value=fbr(taxa);
          document.getElementById('fic_rc_base').value=fbr(val);
          mm.value=fbr(mmv);desc.value='0,00';acr.value='0,00';calc();ov.style.display='flex';});});
        })();
      </script>

      <!-- Modal: ver/editar nota do boleto (com data) -->
      <div id="notaOv" class="ws-modal-ov" style="display:none"><div class="ws-modal" style="max-width:420px">
        <h3>📝 Nota do boleto</h3>
        <form method="post">
          <input type="hidden" name="acao" value="editar_nota"><input type="hidden" name="fatura_id" id="nota_fid"><input type="hidden" name="cliente_id" value="<?= $clienteId ?>">
          <label style="display:block;margin-bottom:8px">Anotação<br><textarea name="obs" id="nota_obs" style="width:100%;min-height:90px"></textarea></label>
          <label style="display:block;margin-bottom:12px">Vencimento<br><input type="date" name="vencimento" id="nota_venc"></label>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button type="button" class="ws-btn" onclick="document.getElementById('notaOv').style.display='none'">Cancelar</button>
            <button class="ws-btn verde">Salvar nota</button></div>
        </form>
      </div></div>
      <script>
        (function(){var ov=document.getElementById('notaOv');if(!ov)return;
        ov.addEventListener('click',function(e){if(e.target===ov)ov.style.display='none';});
        // Delegação: pega QUALQUER link .fic-nota (inclusive os da tabela "Pagos anteriormente",
        // que são renderizados depois deste script) — assim aceita nota também em boleto já recebido.
        document.addEventListener('click',function(e){
          var a=e.target.closest('a.fic-nota'); if(!a)return; e.preventDefault();
          document.getElementById('nota_fid').value=a.dataset.id;
          document.getElementById('nota_obs').value=a.dataset.obs||'';
          document.getElementById('nota_venc').value=a.dataset.venc||'';
          ov.style.display='flex';
        });
        })();
      </script>

      <?php /* ENVIO RECUSADO (data para trás): a caixa reabre com tudo o que já estava preenchido,
         o aviso dentro dela e o cursor na data. Lido UMA vez — recarregar a página não repete. */
        $bolF = [];
        if (!empty($_SESSION['ws_bol_form']) && (int)($_SESSION['ws_bol_form']['cliente_id'] ?? 0) === (int)$clienteId) {
            $bolF = $_SESSION['ws_bol_form'];
        }
        unset($_SESSION['ws_bol_form']);
        $bolV = fn(string $k, string $pad = '') => isset($bolF[$k]) && $bolF[$k] !== '' ? (string)$bolF[$k] : $pad;
      ?>
      <!-- Modal: gerar boleto/carnê deste cliente -->
      <?php /* MODAL COMPACTO (pedido do provedor: "muito grande"). Só CSS — campos, nomes e ordem do
               formulário são os mesmos. Duas colunas: Emissão|Tipo · Quantidade|1º vencimento ·
               Conta (inteira) · Plano (inteira) · Valor|Taxa · Total · Anotação · botões.
               grid-auto-flow:dense encaixa o 1º vencimento ao lado da Quantidade. As dicas verdes
               ao lado dos rótulos saem aqui; no celular volta a 1 coluna. */ ?>
      <style>
        #bolOv .ws-bol{max-width:600px!important}
        #bolOv .ws-bol-head{padding-top:12px!important;padding-bottom:10px!important}
        #bolOv form{display:grid;grid-template-columns:1fr 1fr;gap:8px 12px;grid-auto-flow:dense;padding:12px 14px 14px!important}
        #bolOv form>label,#bolOv form>div{margin:0!important}
        #bolOv form>label>span[style*="22c55e"],#bolOv #bol_qtd_w span[style*="22c55e"]{display:none}
        #bolOv form>label:has([name="banco_id"]),#bolOv form>label:has(#bol_plano),#bolOv form>div:has(#bol_total),
        #bolOv form>label:has([name="obs"]),#bolOv form>.ws-bol-erro,#bolOv form>div:last-of-type{grid-column:1/-1}
        #bolOv form input,#bolOv form select{height:36px}
        #bolOv #bol_valor,#bolOv #bol_taxa{font-size:14px!important}
        /* Taxa de Emissão à ESQUERDA; Valor do Plano e Total do título à DIREITA (pedido do provedor).
           Só a posição na grade muda — a ordem no formulário (e o envio) continua a mesma. */
        #bolOv form>label:has(#bol_taxa){grid-column:1}
        #bolOv form>label:has(#bol_valor){grid-column:2}
        #bolOv form>div:has(#bol_total){grid-column:2!important;text-align:right}
        @media(max-width:560px){#bolOv form{grid-template-columns:1fr}}
      </style>
      <div id="bolOv" class="ws-modal-ov" style="display:none"><div class="ws-modal ws-rc ws-bol" style="max-width:440px">
        <div class="ws-rc-head ws-bol-head"><h3 style="margin:0">💳 Gerar boleto / carnê</h3>
          <p style="font-size:13px;margin:4px 0 0;opacity:.92">Boleto próprio (PIX/QR) ou via gateway</p></div>
        <form method="post" onsubmit="wsProc('Gerando boleto / carnê…')" style="padding:14px 16px 16px">
          <input type="hidden" name="acao" value="gerar_boletos"><input type="hidden" name="cliente_id" value="<?= $clienteId ?>">
          <?php if (!empty($bolF['erro'])): ?>
            <div class="ws-bol-erro" id="bol_erro"><b>⚠️ Não foi gerado</b><span><?= h($bolF['erro']) ?></span>
              <small>Os dados continuam preenchidos — troque só a data e clique em Gerar.</small></div>
          <?php endif; ?>
          <?php /* EMISSÃO: com o gateway configurado (Galax ID + Hash em Financeiro → Gateway), a caixa
                   já abre no GATEWAY — quem contratou a CelCoin quer o boleto registrado dela, e abrir
                   sempre no "boleto próprio" era o motivo de sair só o PIX. Sem credencial, segue no
                   próprio, que é o que funciona. Trocável nos dois sentidos, como antes. */
                $gwPronto = false;
                if (is_file(__DIR__ . '/celcash.php')) {
                    require_once __DIR__ . '/celcash.php';
                    $cgw = ws_celcash_config();
                    $gwPronto = trim((string)$cgw['galaxId']) !== '' && trim((string)$cgw['galaxHash']) !== '';
                }
                $emiCt = ''; foreach ($rows as $rr) { if (!empty($rr['emissao_boleto'])) { $emiCt = (string)$rr['emissao_boleto']; break; } }
                /* LYTEX: cliente cuja "Conta do boleto/PIX" (ficha do contrato) é a conta com Emissão = Lytex
                   já abre em Lytex — é assim que o operador escolhe quem sai pela Lytex (lytex.php). */
                $lxPronto = false; $lxCliente = false;
                if (is_file(__DIR__ . '/lytex.php')) {
                    require_once __DIR__ . '/lytex.php';
                    $lxPronto = ws_lytex_pronto() && ws_lytex_banco_id($db) > 0;
                    foreach ($rows as $rr) { if (!empty($rr['banco_id'])) { $lxCliente = ws_lytex_eh_banco($db, $rr['banco_id']); break; } }
                }
                $emiDef = $lxCliente && $lxPronto ? 'lytex' : ($emiCt !== '' ? $emiCt : (ws_recursos()['bol_emissao_padrao'] ?: ($gwPronto ? 'gateway' : 'proprio')));
                $emiSel = $bolV('emissao') !== '' ? $bolV('emissao') : $emiDef;
                if ($emiSel === 'gateway' && !$gwPronto) $emiSel = 'proprio';
                if ($emiSel === 'lytex' && !$lxPronto) $emiSel = 'proprio'; ?>
          <label style="display:block;margin-bottom:8px;font-size:13px"><b style="color:#a3283b">Emissão</b><?= $gwPronto ? '<span style="font-weight:600;font-size:11px;color:#22c55e"> — Gateway configurado.</span>' : '' ?><br>
            <select name="emissao" onchange="if(window.wsBolSyncConta)wsBolSyncConta(this.value)">
              <option value="proprio" <?= in_array($emiSel, ['gateway', 'lytex'], true) ? '' : 'selected' ?>>Boleto próprio (PIX/QR — Baixa Manual)</option>
              <option value="gateway" <?= $emiSel === 'gateway' ? 'selected' : '' ?><?= $gwPronto ? '' : ' disabled' ?>>Gateway / API (CelCoin/GalaxPay)<?= $gwPronto ? '' : ' — configure em Financeiro → Gateway' ?></option>
              <option value="lytex" <?= $emiSel === 'lytex' ? 'selected' : '' ?><?= $lxPronto ? '' : ' disabled' ?>>API Lytex (boleto + PIX)<?= $lxPronto ? '' : ' — configure em Financeiro → Gateway' ?></option>
            </select></label>
          <label style="display:block;margin-bottom:8px;font-size:13px"><b style="color:#a3283b">Tipo</b><br>
            <select name="tipo" id="bol_tipo" onchange="var l=document.getElementById('bol_qtd_lbl');if(l)l.textContent=this.value==='carne'?'Quantidade de parcelas':'Quantidade a gerar';var q=this.form&&this.form.querySelector('[name=qtd]'),np=<?= (int)ws_recursos()['auto_parcelas_carne'] ?>;if(q&&this.value==='carne'&&np>1&&(q.value===''||q.value==='1'))q.value=np;">
              <?php foreach (['boleto'=>'Boleto único (Mensalidade)','carne'=>'Carnê (várias parcelas) — Mensalidade','servicos'=>'Serviços','vendas'=>'Vendas','outros'=>'Outros'] as $tk=>$tv): ?><option value="<?= $tk ?>" <?= $bolV('tipo','boleto') === $tk ? 'selected' : '' ?>><?= $tv ?></option><?php endforeach; ?></select></label>
          <div id="bol_qtd_w" style="margin-bottom:8px"><label style="display:block;font-size:13px"><b style="color:#a3283b" id="bol_qtd_lbl">Quantidade a gerar</b><span style="font-weight:600;font-size:11px;color:#22c55e"> — 1 título por mês.</span><br><input type="number" name="qtd" min="1" max="36" value="<?= h($bolV('qtd', '1')) ?>" style="font-weight:800;font-size:15px"></label></div>
          <?php /* CONTA DO BOLETO — abre SEMPRE na conta salva no cadastro do contrato (banco_id).
                   O boleto já saía por ela; o que faltava era mostrar qual é na hora de gerar, e poder
                   trocar num título avulso sem mexer no cadastro do cliente. */
                $bancosBol = $db->query("SELECT id,nome,pix FROM ws_banco WHERE ativo=1 ORDER BY FIELD(emissao,'gateway','lytex','proprio'), nome")->fetchAll();
                $bancoCadastro = 0; foreach ($rows as $rr) { if (!empty($rr['banco_id'])) { $bancoCadastro = (int)$rr['banco_id']; break; } }
                $bancoDef = (int)ws_recursos()['bol_banco_padrao'] ?: $bancoCadastro;
                // A Emissão escolhida manda na conta: a conta vinculada a ela (Banco / Contas → Emissão desta conta) vem marcada.
                $bancosEmi = ws_bancos_por_emissao($db);
                $bancoSel = $bolV('banco_id') !== '' ? (int)$bolV('banco_id') : (int)($bancosEmi[$emiSel] ?? $bancoDef);
                // Taxa de cobrança da conta escolhida (Sim + valor) já entra como Taxa de Emissão; segue editável.
                $taxasBol = ws_taxas_cobranca_bancos($db);
                $taxaPre  = isset($bolF['taxa_emissao']) ? (string)$bolF['taxa_emissao'] : ($taxasBol[$bancoSel] ?? ($bancoSel === 0 ? ($taxasBol[0] ?? '') : '')); ?>
          <label style="display:block;margin-bottom:8px;font-size:13px;white-space:nowrap"><b style="color:#a3283b">Conta do Boleto</b><span style="font-weight:600;font-size:11px;color:#22c55e"> — Acompanha a Emissão.</span><br>
            <select name="banco_id" id="bol_banco">
              <option value="0" <?= $bancoSel === 0 ? 'selected' : '' ?>>Conta padrão do sistema (1ª ativa)</option>
              <?php foreach ($bancosBol as $bb): ?>
                <option value="<?= (int)$bb['id'] ?>" <?= $bancoSel === (int)$bb['id'] ? 'selected' : '' ?>><?= h($bb['nome']) ?><?= $bb['pix'] ? ' — ' . h($bb['pix']) : '' ?><?= $bancoCadastro === (int)$bb['id'] ? ' (do cadastro)' : '' ?></option>
              <?php endforeach; ?>
            </select></label>
          <label style="display:block;margin-bottom:8px;font-size:13px"><b style="color:#a3283b">1º vencimento</b><br><input type="date" name="vencimento" id="bol_venc" value="<?= h($bolV('vencimento', $vencPadrao)) ?>"></label>
          <?php $planosBol = $db->query("SELECT id,nome,valor FROM ws_plano ORDER BY nome")->fetchAll();
                $planoClienteId = 0; foreach ($rows as $rr) { if (!empty($rr['plano_id'])) { $planoClienteId = (int)$rr['plano_id']; break; } } ?>
          <label style="display:block;margin-bottom:8px;font-size:13px;white-space:nowrap"><b style="color:#a3283b">Plano Padrão do Cliente</b><span style="font-weight:600;font-size:11px;color:#22c55e"> — Troque para gerar outros valores.</span><br>
            <select name="plano_id" id="bol_plano" onchange="var o=this.options[this.selectedIndex]; if(o.dataset.valor) document.getElementById('bol_valor').value=o.dataset.valor;">
              <?php foreach ($planosBol as $pb): ?>
                <option value="<?= $pb['id'] ?>" data-valor="<?= number_format((float)$pb['valor'],2,',','') ?>" <?= ($bolV('plano_id') !== '' ? (int)$bolV('plano_id') === (int)$pb['id'] : $planoClienteId===(int)$pb['id'])?'selected':'' ?>><?= h($pb['nome']) ?> (R$ <?= number_format((float)$pb['valor'],2,',','.') ?>)</option>
              <?php endforeach; ?>
            </select></label>
          <label style="display:block;margin-bottom:8px;font-size:13px;white-space:nowrap"><b style="color:#a3283b">Valor do Plano (R$)</b><span style="font-weight:600;font-size:11px;color:#22c55e"> — Editar pra outros valores.</span><br><input name="valor" id="bol_valor" value="<?= h($bolV('valor', $valorCtPadrao !== null ? number_format($valorCtPadrao,2,',','') : '')) ?>" placeholder="ex: 99,90" style="font-weight:800;font-size:15px"></label>
          <?php /* "Zerar" como CAIXA DE MARCAR (igual ao Receber): marcada, a taxa vai a 0,00 e trava
                   (readOnly — campo disabled não seria enviado); desmarcada, volta o valor anterior.
                   for="bol_taxa" faz o clique no rótulo ir para o campo, não para a caixa. */ ?>
          <label for="bol_taxa" style="display:block;margin-bottom:8px;font-size:13px;white-space:nowrap"><b style="color:#a3283b">Taxa de Emissão (R$)</b><span style="font-weight:600;font-size:11px;color:#22c55e"> — Somar ao valor final.</span>
            <span style="font-size:12px;color:var(--err);margin-left:8px;display:inline-flex;align-items:center;gap:4px;cursor:pointer;font-weight:600"
              onclick="if(event.target.tagName!=='INPUT'){event.preventDefault();var c=this.querySelector('input');c.checked=!c.checked;c.dispatchEvent(new Event('change'));}"><input type="checkbox" id="bol_taxa_zero" style="width:auto;height:auto;margin:0"
              onchange="var t=document.getElementById('bol_taxa');if(this.checked){t.dataset.memo=t.value;t.value='0,00';t.readOnly=true;t.style.opacity='.55';}else{t.readOnly=false;t.style.opacity='';if(t.dataset.memo!=null)t.value=t.dataset.memo;}t.dispatchEvent(new Event('input'));">Zerar</span><br><input name="taxa_emissao" id="bol_taxa" value="<?= h($taxaPre) ?>" placeholder="0,00" style="font-weight:800;font-size:15px"></label>
          <?php /* TOTAL DO TÍTULO = plano + taxa de emissão, somado ao digitar (é o mesmo cálculo que o
                   servidor faz ao gravar: valor = valor + taxa_emissao). Só exibição, sem name. */ ?>
          <div style="margin:-2px 0 10px;font-size:16px;font-weight:600">Total do título: <b id="bol_total" style="color:var(--ok);font-size:18px">R$ 0,00</b></div>
          <script>
          (function(){
            var v=document.getElementById('bol_valor'),t=document.getElementById('bol_taxa'),o=document.getElementById('bol_total'),p=document.getElementById('bol_plano');
            if(!v||!t||!o) return;
            var n=function(s){return parseFloat(String(s||'').replace(/\./g,'').replace(',','.'))||0;};
            var soma=function(){o.textContent='R$ '+(n(v.value)+n(t.value)).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});};
            ['input','change','keyup'].forEach(function(ev){v.addEventListener(ev,soma);t.addEventListener(ev,soma);});
            if(p) p.addEventListener('change',function(){setTimeout(soma,0);});
            setInterval(soma,800);   // a conta do boleto troca a taxa por script: mantém o total sempre certo
            soma();
          })();
          </script>
          <label style="display:block;margin-bottom:12px"><b style="color:#a3283b">Anotação (opcional)</b><br><input name="obs" value="<?= h($bolV('obs')) ?>"></label>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button type="button" class="ws-btn" onclick="document.getElementById('bolOv').style.display='none'">Cancelar</button>
            <button class="ws-btn verde">Gerar</button></div>
        </form>
      </div></div>
      <script>
        /* Conta do Boleto x Emissão x Taxa: escolher a Emissão já aponta a Conta do Boleto vinculada a ela
           (Banco / Contas → Emissão desta conta; sem vínculo, o padrão do sistema ou o cadastro) e a Taxa de Emissão acompanha a taxa de cobrança da conta — até o operador
           digitar no campo (aí o valor dele vale). */
        window.WS_BOL_TAXAS = <?= json_encode((object)$taxasBol) ?>;
        window.WS_BOL_BANCO_DEF = <?= (int)$bancoDef ?>;
        window.WS_BOL_BANCO_EMI = <?= json_encode((object)$bancosEmi) ?>;   // {"gateway":id,"proprio":id}
        (function(){
          var sel=document.getElementById('bol_banco'), tx=document.getElementById('bol_taxa'); if(!sel||!tx) return;
          function taxaDaConta(){var t=window.WS_BOL_TAXAS||{}, id=sel.value||'0'; return t[id]!=null ? t[id] : (id==='0' ? (t['0']||'') : '');}
          window.wsBolTaxa=function(){ if(tx.dataset.manual==='1') return; tx.value=taxaDaConta(); };
          window.wsBolSyncConta=function(emi){ var m=window.WS_BOL_BANCO_EMI||{}; sel.value=String(m[emi]||window.WS_BOL_BANCO_DEF||0); window.wsBolTaxa(); };
          tx.addEventListener('input',function(){ tx.dataset.manual='1'; });
          sel.addEventListener('change',window.wsBolTaxa);
        })();
        function bolAbrir(){document.getElementById('bolOv').style.display='flex';}
        /* NÃO fecha ao clicar fora: um clique no vazio apagava tudo o que já tinha sido preenchido.
           Fecha só no Cancelar, no X ou no Esc — nenhum deles é clicado sem querer. */
        document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ var o=document.getElementById('bolOv'); if(o&&o.style.display!=='none') o.style.display='none'; } });
        <?php if (!empty($_GET['gerar'])): ?>document.addEventListener('DOMContentLoaded',bolAbrir); // atalho "+ Gerar" abre o modal direto<?php endif; ?>
        <?php if (!empty($bolF['erro'])): ?>
        /* Envio recusado: a caixa volta aberta, com tudo preenchido, e o cursor já na data. */
        document.addEventListener('DOMContentLoaded',function(){ bolAbrir();
          var d=document.getElementById('bol_venc'); if(d){ d.focus(); if(d.showPicker){ try{ d.showPicker(); }catch(e){} } }
        });
        <?php endif; ?>
        function fbAll(c){document.querySelectorAll('.fbchk').forEach(function(e){e.checked=c.checked;});}
        // Overlay "processando…" — cobre a transição do POST/redirect (some sozinho ao carregar a nova página).
        function wsProc(msg){var o=document.getElementById('wsProcOv');if(!o)return;o.querySelector('.ws-proc-msg').textContent=msg||'Processando…';o.classList.add('on');}
      </script>
      <div id="wsProcOv" class="ws-proc-ov"><div class="ws-proc-card"><span class="ws-proc-spin"></span><span class="ws-proc-msg">Processando…</span></div></div>

    <?php /* "PAGAMENTO REALIZADO POR" na lista Pagos anteriormente: lápis ✏️ (aparece ao passar o mouse na linha) abre esta janela.
         Só nível 3/Root veem o lápis; o envio vai para financeiro.php (acao=alterar_pago_por: motivo + senha) e volta para a ficha. */ ?>
    <style>.ws-pp-lapis{opacity:0;transition:opacity .12s;text-decoration:none;margin-left:6px;padding:1px 4px;border-radius:5px;cursor:pointer}.ws-table tbody tr:hover .ws-pp-lapis,.ws-pp-lapis:focus{opacity:1}.ws-pp-lapis:hover{background:rgba(127,127,127,.18)}@media (hover:none){.ws-pp-lapis{opacity:.7}}</style>
    <div id="wsPPOv" class="ws-modal-ov" style="display:none"><div class="ws-modal" style="max-width:440px">
      <h3 style="margin-top:0">🙋 Pagamento realizado por</h3><div class="ws-muted" id="wsPPTit" style="font-size:13px;margin:-6px 0 10px"></div>
      <form method="post" action="financeiro.php" onsubmit="return confirm('Alterar quem realizou este pagamento?')">
        <input type="hidden" name="acao" value="alterar_pago_por"><input type="hidden" name="pagamento_id" id="wsPPpg"><input type="hidden" name="fatura_id" id="wsPPfa">
        <input type="hidden" name="volta" value="erp.php?p=cliente&id=<?= $clienteId ?>">
        <label style="display:block;margin-bottom:8px">Pagamento realizado por<br><input name="pago_por_novo" id="wsPPnome" maxlength="120" style="width:100%" placeholder="ex.: Maria (mãe do titular) — vazio = o próprio cliente"></label>
        <label style="display:block;margin-bottom:8px">Motivo<br><input name="motivo" id="wsPPmot" required minlength="5" maxlength="150" style="width:100%" placeholder="ex.: esqueceram de informar que a mãe pagou"></label>
        <label style="display:block;margin-bottom:10px">Sua senha<br><input type="password" name="senha" required autocomplete="current-password" style="width:100%"></label>
        <div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" class="ws-btn" onclick="document.getElementById('wsPPOv').style.display='none'">Cancelar</button><button class="ws-btn primary">Salvar alteração</button></div>
      </form></div></div>
    <script>
    function wsPagoPor(pg,fa,atual,tit){var o=document.getElementById('wsPPOv');if(!o)return;
      document.getElementById('wsPPpg').value=pg;document.getElementById('wsPPfa').value=fa;
      document.getElementById('wsPPnome').value=atual||'';document.getElementById('wsPPTit').textContent='Título '+(tit||'');
      o.style.display='flex';setTimeout(function(){var n=document.getElementById('wsPPnome');if(n){n.focus();n.select();}},30);}
    (function(){var o=document.getElementById('wsPPOv');if(o)o.addEventListener('click',function(e){if(e.target===o)o.style.display='none';});})();
    </script>
    <?php /* Erro (senha errada, motivo curto...): reabre a janela com o que foi digitado — só a senha fica em branco. */
    if (!empty($_SESSION['ws_pp_reabrir'])): $ppR = $_SESSION['ws_pp_reabrir']; unset($_SESSION['ws_pp_reabrir']); ?>
    <script>window.addEventListener('load',function(){wsPagoPor(<?= (int)$ppR['pg'] ?>,<?= (int)$ppR['fa'] ?>,<?= json_encode((string)$ppR['nome'], JSON_UNESCAPED_UNICODE) ?>,'#<?= (int)$ppR['fa'] ?>');document.getElementById('wsPPmot').value=<?= json_encode((string)$ppR['motivo'], JSON_UNESCAPED_UNICODE) ?>;var p=document.querySelector('#wsPPOv [name=senha]');if(p)p.focus();});</script>
    <?php endif; ?>
    <?php // Faturas pagas/recebidas — ABAIXO das em aberto (igual ao MK-Auth "Pagos anteriormente")
    $ps = $db->prepare("SELECT f.*, ct.login_pppoe,
                        (SELECT p.coletor FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) coletor,
                        (SELECT p.forma FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) forma,
                        (SELECT p.criado_em FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) pago_em,
                        (SELECT p.id FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) pg_id,
                        (SELECT p.pago_por FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) pago_por_ult,
                        (SELECT p.origem FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) pg_origem
                        FROM ws_fatura f LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
                        WHERE f.cliente_id=? AND f.status='pago' AND (f.contrato_id IS NOT NULL OR NOT EXISTS(SELECT 1 FROM ws_cliente cc WHERE cc.id=f.cliente_id AND cc.status='cancelado'))
                        ORDER BY pago_em DESC, f.data_pagamento DESC, f.id DESC LIMIT 600");
    $ps->execute([$clienteId]); $pagas = $ps->fetchAll();
    $ehRoot = function_exists('ws_eh_root') ? ws_eh_root() : false;
    /* ÚLTIMOS 12 MESES à vista; o resto vira HISTÓRICO recolhido.
       Antes a lista mostrava tudo (lista imensa) — ou cortava em 24 sem avisar que havia mais.
       Referência = data do pagamento (cai no vencimento se faltar). O corte é pelo 1º dia do mês,
       12 meses atrás, para não partir um mês ao meio. */
    /* NOVA REGRA (17/10/2026): à vista só os pagamentos do ANO ATUAL, no máximo 12 (os mais recentes); o resto — do ano atual além de 12 e de anos anteriores — fica recolhido no histórico.
       Com menos de 12 neste ano, mostra só os deste ano (não completa com anos anteriores). $prCorte vira o 1º dia do ano, só para o texto do separador. */
    $prAno = date('Y'); $prCorte = $prAno . '-01-01'; $prLim = 12;
    $prRecente = 0; $prHist = 0; $vis = []; $ocu = [];
    foreach ($pagas as $f) {
        $ref = substr((string)($f['data_pagamento'] ?: ($f['pago_em'] ?: $f['vencimento'])), 0, 10);
        if ($ref !== '' && substr($ref, 0, 4) === $prAno && $prRecente < $prLim) { $f['_hist'] = false; $prRecente++; $vis[] = $f; }
        else { $f['_hist'] = true; $prHist++; $ocu[] = $f; }
    }
    $pagas = array_merge($vis, $ocu);   // à vista primeiro, histórico depois (o separador do histórico entra antes do 1º recolhido)
    if ($pagas): ?>
      <div class="ws-head-row ws-tarja" style="margin-top:20px"><h3>✅ Pagos anteriormente <span class="ws-muted" style="font-size:12px;font-weight:400">— <?= $prAno ?> (<?= $prRecente ?><?= $prRecente >= $prLim ? ', os 12 mais recentes' : '' ?>)</span></h3>
      </div>
      <div class="ws-cx-wrap"><table class="ws-table ws-table-titulos"><thead><tr><th class="sel"><input type="checkbox" onclick="prAll(this)" title="Marcar todos (visíveis)"></th><th>Título</th><th>Vencimento</th><th>Coletor</th><th>Forma</th><th>Pagamento</th><th>Hora</th><th style="text-align:right">Valor</th><th style="text-align:right">Valor pago</th></tr></thead><tbody>
      <?php if (!$prRecente): ?><tr><td colspan="9" class="ws-muted">Nenhum pagamento em <?= $prAno ?> — veja o histórico abaixo.</td></tr><?php endif; ?>
      <?php $prSepFeito = false; foreach ($pagas as $f):
        $hc = $f['_hist'] ? ' class="pr-hist" style="display:none"' : '';
        if ($f['_hist'] && !$prSepFeito): $prSepFeito = true; ?>
        <tr class="pr-hist" style="display:none"><td colspan="9" style="background:var(--bg);font-weight:700;font-size:12px;color:var(--muted)">📜 Histórico — demais pagamentos e anos anteriores</td></tr>
      <?php endif; ?>
        <tr<?= $hc ?>>
          <td class="sel"><input type="checkbox" class="prchk" value="<?= $f['id'] ?>"></td>
          <td><b>#<?= $f['id'] ?></b></td>
          <td><?= date('d/m/y', strtotime($f['vencimento'])) ?></td>
          <td><?= h($f['coletor'] ?: '—') ?></td>
          <td><a href="financeiro.php?p=fatura&id=<?= (int)$f['id'] ?>&troca=1" title="Clique para alterar a forma deste recebimento" style="text-decoration:none"><?= ws_forma_badge((string)($f['forma'] ?? '')) ?></a></td>
          <td><span class="ws-tag ativo">Pago</span> <?= $f['data_pagamento']?date('d/m/y',strtotime($f['data_pagamento'])):'—' ?><?php /* "Pago por" na coluna Pagamento; lápis só em recebimento manual (nunca nos vindos por API/gateway/banco) */ $ppU = trim((string)($f['pago_por_ult'] ?? '')); $ppEd = ws_nivel_acesso() >= 3 && !empty($f['pg_id']) && (($f['pg_origem'] ?? 'manual') === 'manual'); if ($ppU !== '' || $ppEd): ?><br><small class="ws-muted" title="Pagamento realizado por"><?php if ($ppU !== ''): ?>🙋 <?= h($ppU) ?><?php endif; ?></small><?php if ($ppEd): ?><a href="#" class="ws-pp-lapis" title="Editar quem realizou o pagamento" onclick="wsPagoPor(<?= (int)$f['pg_id'] ?>,<?= (int)$f['id'] ?>,<?= h(json_encode($ppU, JSON_UNESCAPED_UNICODE)) ?>,'#<?= (int)$f['id'] ?>');return false">✏️</a><?php endif; ?><?php endif; ?></td>
          <td class="ws-muted"><?= !empty($f['pago_em']) ? date('H:i\h', strtotime($f['pago_em'])) : '—' ?></td>
          <td style="text-align:right" class="pr-valor" data-valor="R$ <?= number_format((float)$f['valor'],2,',','.') ?>">R$ <?= number_format((float)$f['valor'],2,',','.') ?></td>
          <td style="text-align:right" class="pr-valor" data-valor="R$ <?= number_format($f['valor_pago'] ?? $f['valor'],2,',','.') ?>"><b>R$ <?= number_format($f['valor_pago'] ?? $f['valor'],2,',','.') ?></b></td>
        </tr>
        <tr class="ws-linha-acoes<?= $f['_hist'] ? ' pr-hist' : '' ?>"<?= $f['_hist'] ? ' style="display:none"' : '' ?>>
          <td colspan="9">
            <a href="financeiro.php?p=fatura&id=<?= $f['id'] ?>">Informações</a> |
            <a href="recibo.php?fatura=<?= $f['id'] ?>&print=1" target="_blank">Recibo</a> |
            <?php $mesmoDiaPg = (substr((string)($f['data_pagamento'] ?? ''),0,10) === date('Y-m-d')); ?>
            <a href="#" onclick="prEstornar('<?= $f['id'] ?>',<?= $mesmoDiaPg ? 'true' : 'false' ?>);return false;" style="color:var(--err)" title="<?= $mesmoDiaPg ? 'Estornar (recebido hoje)' : 'Estornar (dia anterior — exige senha root se você não for root)' ?>">Estornar</a> |
            <a href="#" class="fic-nota" data-id="<?= $f['id'] ?>" data-obs="<?= h($f['obs'] ?? '') ?>" data-venc="<?= h($f['vencimento']) ?>"><?= !empty($f['obs']) ? '📝 ' : '' ?>Notas</a> |
            <a href="financeiro.php?enviar_lote=<?= $f['id'] ?>&volta=<?= urlencode('erp.php?p=cliente&id='.$clienteId) ?>">Enviar</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
      <?php if ($prHist): ?>
        <button type="button" class="ws-btn" style="font-size:12px;margin-top:6px" id="prHistBtn"
          onclick="var v=this.dataset.aberto==='1';document.querySelectorAll('.pr-hist').forEach(function(e){e.style.display=v?'none':'';});this.dataset.aberto=v?'0':'1';this.textContent=v?'📜 Ver histórico (<?= $prHist ?> título(s) anteriores)':'▴ Ocultar histórico';">📜 Ver histórico (<?= $prHist ?> título(s) anteriores)</button>
      <?php endif; ?>
      <div class="ws-toolbar-mini">
        <button type="button" class="ico retorno" onclick="prEstornarSel()" title="Estornar (retorno) dos selecionados">↩<?= '' ?></button>
        <button type="button" class="ico enviar" onclick="prEnviarSel()" title="Enviar recibo dos selecionados"><svg class="ws-ico" viewBox="0 0 24 24" fill="currentColor"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg></button>
        <button type="button" class="ico excluir" onclick="prExcluir(prSel())" title="Excluir selecionados<?= $ehRoot ? '' : ' — exige senha root' ?>"><?= ws_icon('lixeira') ?></button>
      </div>
      <script>
        var PR_ROOT = <?= $ehRoot ? 'true' : 'false' ?>;
        function prSel(){return Array.from(document.querySelectorAll('.prchk:checked')).map(function(c){return c.value;});}
        // Só marca o que está À VISTA: o histórico recolhido não entra num estorno/exclusão em massa por engano.
        function prAll(cb){document.querySelectorAll('.prchk').forEach(function(c){var tr=c.closest('tr'); if(tr&&tr.style.display==='none'){c.checked=false;return;} c.checked=cb.checked;});}

        /* ── Modal de senha + motivo para estorno ── */
        function prModalEstorno(titulo, msg, onConfirm){
          var ov = document.createElement('div');
          ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px';
          ov.innerHTML='<div style="background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px;max-width:420px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,.35)">'
            +'<h3 style="margin:0 0 6px;color:var(--err)">↩ '+titulo+'</h3>'
            +'<p style="font-size:13px;color:var(--muted);margin:0 0 16px">'+msg+'</p>'
            +'<label style="display:block;margin-bottom:10px;font-size:13px;font-weight:600">Motivo do estorno <span style="color:var(--err)">*</span>'
            +'<textarea id="pr_est_motivo" rows="2" placeholder="Descreva o motivo…" style="display:block;width:100%;margin-top:4px;border:1px solid var(--border);border-radius:8px;padding:8px;font-size:13px;resize:vertical;background:var(--surface);color:var(--text)"></textarea></label>'
            +'<label style="display:block;margin-bottom:16px;font-size:13px;font-weight:600">Senha <?= $ehRoot ? 'root' : 'de operador' ?> <span style="color:var(--err)">*</span>'
            +'<input type="password" id="pr_est_senha" placeholder="Digite a senha…" autocomplete="off" style="display:block;width:100%;margin-top:4px;border:1px solid var(--border);border-radius:8px;padding:8px;font-size:13px;background:var(--surface);color:var(--text)"></label>'
            +'<div style="display:flex;gap:8px;justify-content:flex-end">'
            +'<button onclick="this.closest(\'div[style]\').parentNode.remove()" style="padding:8px 16px;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text);cursor:pointer;font-size:13px">Cancelar</button>'
            +'<button id="pr_est_btn" style="padding:8px 18px;border:none;border-radius:8px;background:var(--err);color:#fff;cursor:pointer;font-weight:700;font-size:13px">↩ Confirmar estorno</button>'
            +'</div></div>';
          document.body.appendChild(ov);
          document.getElementById('pr_est_senha').focus();
          document.getElementById('pr_est_btn').addEventListener('click', function(){
            var motivo = (document.getElementById('pr_est_motivo').value||'').trim();
            var senha  = (document.getElementById('pr_est_senha').value||'').trim();
            if(!motivo){alert('Informe o motivo do estorno.');document.getElementById('pr_est_motivo').focus();return;}
            if(!senha){alert('Informe a senha.');document.getElementById('pr_est_senha').focus();return;}
            ov.remove();
            onConfirm(motivo, senha);
          });
        }

        function prExcluir(ids){
          if(!ids||!ids.length){alert('Marque ao menos um título recebido.');return;}
          wsExcluirTitulo({
            url: 'erp.php',
            titulo: 'Excluir ' + ids.length + ' recebido(s)',
            mensagem: 'Isso apaga boletos JÁ PAGOS do sistema e remove o pagamento registrado. ' + (!PR_ROOT ? 'Exige senha de ROOT.' : 'Esta ação não pode ser desfeita.'),
            campos: {acao: 'del_recebidos', ids: ids.join(','), cliente: '<?= $clienteId ?>'}
          });
        }

        // Estorno individual — SEMPRE pede senha + motivo antes de prosseguir com a regra original
        function prEstornar(id, mesmoDia){
          prModalEstorno(
            'Estornar pagamento',
            'O título voltará para &ldquo;aberto&rdquo; e o registro de pagamento será apagado.' + (!mesmoDia && !PR_ROOT ? ' Exige senha de ROOT.' : ''),
            function(motivo, senha){
              if(PR_ROOT || mesmoDia){
                wsProc('Estornando pagamento…');
                window.location='erp.php?estornar_fatura='+id+'&cliente=<?= $clienteId ?>&motivo='+encodeURIComponent(motivo)+'&senha_op='+encodeURIComponent(senha);
                return;
              }
              wsExcluirTitulo({
                url: 'erp.php?p=cliente&id=<?= $clienteId ?>',
                titulo: 'Estornar pagamento de dia anterior',
                mensagem: 'O título volta pra "aberto" e o registro de pagamento é apagado.',
                motivo: false, botaoTxt: '↩ Estornar', botaoCls: 'primary', processando: 'Estornando pagamento…',
                campos: {acao: 'estornar', estornar_fatura: id, cliente: '<?= $clienteId ?>', motivo_estorno: motivo, senha_op: senha}
              });
            }
          );
        }

        // Estorno em lote — SEMPRE pede senha + motivo
        function prEstornarSel(){
          var ids=prSel(); if(!ids.length){alert('Marque ao menos um recebido.');return;}
          prModalEstorno(
            'Estornar '+ids.length+' pagamento(s)',
            'Os títulos selecionados voltarão para &ldquo;aberto&rdquo;.' + (!PR_ROOT ? ' Recebidos de dia anterior exigem senha de ROOT.' : ''),
            function(motivo, senha){
              if(PR_ROOT){
                var f=document.createElement('form');f.method='post';f.action='erp.php?p=cliente&id=<?= $clienteId ?>';
                function add(n,v){var i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;f.appendChild(i);}
                add('acao','estornar_lote');add('cliente','<?= $clienteId ?>');add('ids',ids.join(','));
                add('motivo_estorno',motivo);add('senha_op',senha);
                wsProc('Estornando '+ids.length+' pagamento(s)…');document.body.appendChild(f);f.submit(); return;
              }
              wsExcluirTitulo({
                url: 'erp.php?p=cliente&id=<?= $clienteId ?>',
                titulo: 'Estornar ' + ids.length + ' pagamento(s)',
                mensagem: 'Recebidos de dia anterior exigem senha de ROOT. Voltam pra "aberto".',
                motivo: false, botaoTxt: '↩ Estornar', botaoCls: 'primary', processando: 'Estornando ' + ids.length + ' pagamento(s)…',
                campos: {acao: 'estornar_lote', cliente: '<?= $clienteId ?>', ids: ids.join(','), motivo_estorno: motivo, senha_op: senha}
              });
            }
          );
        }

        // Enviar recibo dos selecionados
        function prEnviarSel(){
          var s=prSel(); if(!s.length){alert('Marque ao menos um recebido.');return;}
          var ov=document.getElementById('wsEnvOv'); if(!ov){alert('Envio indisponível nesta tela.');return;}
          ov.style.display='flex';
          var ei=document.getElementById('ws_env_ids'); if(ei) ei.value=s.join(',');
          var em=document.getElementById('ws_env_msg'); if(em) em.value='Olá! Segue o comprovante/recibo do seu pagamento. Obrigado!';
        }
      </script>
    <?php endif; ?>
    <?php
}

/* --------- Form contrato --------- */
function ws_view_contrato(PDO $db): void {
    $id = (int)($_GET['id'] ?? 0); $ct = null;
    if ($id) { $st = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $st->execute([$id]); $ct = $st->fetch(); }
    $clienteId = (int)($ct['cliente_id'] ?? $_GET['cliente'] ?? 0);
    $cli = null; if ($clienteId) { $st=$db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $st->execute([$clienteId]); $cli=$st->fetch();
        require_once __DIR__ . "/schema_endereco.php";
        if ($cli) $cli = ws_end_enriquecer($db, $cli); }
    $planos = $db->query("SELECT id,nome,valor FROM ws_plano WHERE ativo=1 ORDER BY nome")->fetchAll();
    $conc   = $db->query("SELECT id,nome FROM ws_concentrador WHERE ativo=1 ORDER BY nome")->fetchAll();
    $bancos = $db->query("SELECT id,nome,pix,emissao FROM ws_banco WHERE ativo=1 ORDER BY FIELD(emissao,'gateway','lytex','proprio'), nome")->fetchAll();   // CelCash 1º, Lytex 2º, PIX-QR 3º (03/10/2026)
    // Novo contrato: além do que vier em $ct, aceita pré-preenchimento por GET (link vindo da OLT) e,
    // por padrão, puxa automaticamente o endereço/lat/lng já cadastrados do cliente titular.
    $g = function($k) use ($ct, $cli, $id) {
        if (isset($ct[$k]) && $ct[$k] !== null && $ct[$k] !== '') return h($ct[$k]);
        if (!$id && isset($_GET[$k])) return h($_GET[$k]);
        // Herda do cliente quando o campo do contrato está vazio — vale também na EDIÇÃO (antes só
        // preenchia em contrato novo, por isso os dados de conexão ficavam em branco ao editar).
        if ($cli) {
            $map = ['inst_cep'=>'cep','inst_logradouro'=>'logradouro','inst_numero'=>'numero','inst_complemento'=>'complemento',
                    'inst_bairro'=>'bairro','inst_cidade'=>'cidade','inst_uf'=>'uf','lat'=>'lat','lng'=>'lng'];
            if (isset($map[$k]) && !empty($cli[$map[$k]])) return h($cli[$map[$k]]);
        }
        return '';
    };
    $sel = fn($k,$v) => (($ct[$k] ?? '') == $v ? 'selected' : '');
    $concTodosPadrao = $id ? (($ct['concentradores'] ?? '')==='todos' || empty($ct['concentrador_id'])) : true; // padrão = Todos (só desmarca se houver concentrador específico)
    ?>
    <div class="ws-head-row"><h2><?= $id ? 'Editar contrato' : 'Novo contrato' ?><?= $cli ? ' — '.h($cli['nome']) : '' ?></h2>
      </div>
    <form method="post" class="ws-form grid" id="ws_form_contrato">
      <?php /* CONEXÃO / REDE EM 3 LINHAS: grade de 20 colunas só neste formulário (telas > 820px).
               Campos da conexão (.cx5) ocupam 4 colunas = 5 por linha; os demais continuam 5 colunas
               = 4 por linha, como antes. No celular vale a regra geral (2 colunas e depois 1). */ ?>
      <style>
        @media (min-width:821px){
          #ws_form_contrato{grid-template-columns:repeat(20,minmax(0,1fr))}
          #ws_form_contrato>label{grid-column:span 5}
          #ws_form_contrato>label.cx5{grid-column:span 4}
          #ws_form_contrato>.c2{grid-column:span 10}
          #ws_form_contrato>.c4{grid-column:span 20}
          /* Endereço de instalação em 3 linhas: CEP|Logradouro|Número|Complemento — Bairro|Cidade|UF|Lat|Long — Obs. */
          #ws_form_contrato>.e2{grid-column:span 2}  #ws_form_contrato>.e3{grid-column:span 3}
          #ws_form_contrato>.e4{grid-column:span 4}  #ws_form_contrato>.e5{grid-column:span 5}
          #ws_form_contrato>.e8{grid-column:span 8}
        }
      </style>
      <input type="hidden" name="acao" value="salvar_contrato">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="cliente_id" value="<?= $clienteId ?>">
      <div class="c4 ws-secao">Plano e Cobrança</div>
      <?php /* 19/11/2026: os 4 campos numa linha só, tamanho igual (desktop). */ ?>
      <div class="c4" id="ws_plano4">
      <label>Plano <span style="float:right"><a href="erp.php?p=planos" style="font-size:11px">criar</a></span>
        <select name="plano_id" id="c_plano_id" onchange="wsPlanoValor('c_plano_id','c_valor')"><option value="" data-valor="">—</option>
        <?php foreach ($planos as $pl) echo "<option value='{$pl['id']}' data-valor='".number_format((float)$pl['valor'],2,',','')."' ".$sel('plano_id',$pl['id']).">".h($pl['nome'])." (R$ ".number_format((float)$pl['valor'],2,',','.').")</option>"; ?>
        </select></label>
      <label>Valor mensal (R$) <span class="ws-auto-badge" title="<?= ws_pode_editar_valor_contrato() ? 'Preenchido automaticamente pelo plano' : 'Travado no valor do plano — só nível 2 ou superior altera' ?>">auto</span> <input name="valor" id="c_valor" value="<?= $g('valor') ?>" placeholder="puxa do plano" <?= ws_pode_editar_valor_contrato() ? '' : 'readonly title="Valor travado no do plano — fale com um administrador pra alterar"' ?>></label>
      <label>Conta do boleto/PIX <span style="float:right"><a href="provedor.php?p=bancos" style="font-size:11px">criar</a></span>
        <select name="banco_id"><option value="">Padrão (1º banco ativo)</option>
        <?php // contrato NOVO (sem conta escolhida) já vem com a 1ª da ordem (CelCash); contrato existente mantém a sua
          $bkPre = trim((string)($ct['banco_id'] ?? ($_POST['banco_id'] ?? ''))) === '' && empty($ct['id']) ? (int)($bancos[0]['id'] ?? 0) : 0;
          foreach ($bancos as $bk) echo "<option value='{$bk['id']}' ".($bkPre && $bkPre === (int)$bk['id'] ? 'selected' : $sel('banco_id',$bk['id'])).">".h($bk['nome']).($bk['pix'] ? " — ".h($bk['pix']) : '')."</option>"; ?>
        </select></label>
      <label class="conc-lbl">
        <span class="conc-head">Concentrador <a href="radius.php?p=conc" class="conc-criar">criar</a></span>
        <select name="concentrador_id" id="c_concentrador_id">
          <option value="todos" <?= $concTodosPadrao?'selected':'' ?>>Sair por TODOS os concentradores</option>
          <?php foreach ($conc as $cc) echo "<option value='{$cc['id']}' ".$sel('concentrador_id',$cc['id']).">".h($cc['nome'])."</option>"; ?>
        </select></label>
      </div>
      <style>
        #ws_form_contrato>#ws_plano4{grid-column:1 / -1!important;width:100%;box-sizing:border-box}
        #ws_plano4{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px 14px;width:100%}
        #ws_plano4>label{display:flex;flex-direction:column;position:relative;min-width:0;width:100%}
        #ws_plano4 select,#ws_plano4 input{width:100%;box-sizing:border-box}
        @media (min-width:821px){ #ws_plano4{grid-template-columns:repeat(4,minmax(0,1fr))!important} }
      </style>
      <div class="c4 ws-secao">Conexão / Rede</div>
      <?php /* 19/11/2026: os 14 campos da Conexão/Rede em 2 linhas (7 por linha, tamanho igual), em vez de 3. No celular cai pra 2 colunas. */ ?>
      <div class="c4" id="ws_rede14">
      <label class="cx5">Tipo <select name="tipo_conexao" id="c_tipo" onchange="wsCTipo()">
        <?php foreach (['pppoe','ipoe','hotspot'] as $t) echo "<option ".$sel('tipo_conexao',$t).">$t</option>"; ?>
      </select></label>
      <label class="c-pppoe cx5">Login PPPoE <input name="login_pppoe" id="c_login" value="<?= $g('login_pppoe') ?>"></label>
      <label class="c-pppoe cx5">Senha PPPoE <input name="senha_pppoe" id="c_senha" value="<?= $g('senha_pppoe') ?>"<?= ws_recursos()['mostrar_senhas'] ? '' : ' type="password" autocomplete="new-password" title="Senha escondida — dê dois cliques para ver" ondblclick="this.type=this.type===\'password\'?\'text\':\'password\'"' ?>></label>
      <label class="c-onu cx5">ID da ONU/ONT <input name="ont_id" id="c_ont" value="<?= $g('ont_id') ?>" placeholder="da autorização (PPPoE ou IPoE)" oninput="wsCOntAuto()"></label>
      <label class="c-ipoe cx5">Login IPoE <input name="login_ipoe" id="c_login_ipoe" value="<?= $g('login_ipoe') ?>" placeholder="opcional, se diferente do ID"></label>
      <label class="c-ipoe cx5">Senha IPoE <input name="senha_ipoe" id="c_senha_ipoe" value="<?= $g('senha_ipoe') ?>" placeholder="opcional, se diferente do ID"<?= ws_recursos()['mostrar_senhas'] ? '' : ' type="password" autocomplete="new-password" title="Senha escondida — dê dois cliques para ver" ondblclick="this.type=this.type===\'password\'?\'text\':\'password\'"' ?>></label>
      <?php /* IP FIXO vs IP DINÂMICO — dois papéis, um campo só para o que é gravado.
               O <input> guarda APENAS o IP fixo: ele é salvo e enviado ao concentrador para amarrar
               a navegação do cliente. O IP dinâmico entregue pelo concentrador aparece ABAIXO, como
               texto — não é campo, não vai no formulário e não é gravado. Fosse dentro do input,
               qualquer salvamento transformaria um IP emprestado em IP fixo de verdade, e o
               cliente ficaria preso a um endereço que já foi de outra pessoa.
               O valor vem de ultimo_ip (gravado por ws_conexao_registrar) e se atualiza sozinho
               enquanto a ficha estiver aberta. */
            /* 23/09/2026: "agora" só com sessão VIVA (ws_contrato_ip_vivo: concentrador → radacct aberta).
               Antes mostrava o ultimo_ip gravado como "IP dinâmico agora" até com o cliente offline, e o
               login da checagem saía de login_pppoe ?? ... — '' não é null, então o IPoE com login_pppoe
               vazio ficava sem checagem nenhuma. Agora o login vem do tipo_conexao e offline mostra
               "offline · último IP visto". */
            $ipUlt   = trim((string)($ct['ultimo_ip'] ?? ''));
            $ipUltEm = !empty($ct['ultimo_ip_em']) ? date('d/m H:i', strtotime((string)$ct['ultimo_ip_em'])) : '';
            $ipDin   = ($ct && function_exists('ws_contrato_ip_vivo')) ? ws_contrato_ip_vivo($db, $ct) : '';
            $loginNormCt = ($ct && function_exists('ws_contrato_logins_sessao')) ? implode(',', ws_contrato_logins_sessao($ct)) : '';
            $ipOffTxt = $ipUlt !== '' ? '⚪ Offline · último IP visto: <b>' . h($ipUlt) . '</b>' . ($ipUltEm !== '' ? ' em ' . h($ipUltEm) : '') : 'IP dinâmico: sem registro de conexão ainda'; ?>
      <label class="cx5"><span style="display:block;min-height:17px;font-size:11px;font-weight:600;white-space:normal;line-height:1.3">
          <small class="ws-ip-dinamico" id="c_ip_dinamico" style="border-top:0;padding-top:0" data-login="<?= h($loginNormCt) ?>" data-off="<?= h($ipOffTxt) ?>"
                 title="Endereço entregue pelo concentrador. É informativo: não é salvo nem enviado — para fixar um IP, digite-o no campo abaixo."
                 style="font-size:11px;font-weight:400">
            <?= $ipDin !== '' ? '🟢 IP dinâmico agora: <b style="color:var(--ok)">' . h($ipDin) . '</b>' : $ipOffTxt ?>
          </small></span>
        <input name="ip_fixo" value="<?= $g('ip_fixo') ?>" placeholder="IP fixo — vazio = dinâmico"></label>
      <?php /* POOL PRÓPRIA — exceção de faixa para ESTE assinante (radreply → Framed-Pool).
               Serve para bloco público, faixa de empresa, CGNAT separado, rede de teste. Antes isso
               só era possível mexendo no concentrador à mão, fora do sistema — e o que se faz fora
               do sistema se perde na próxima migração.
               O aviso de exclusão mútua está no title porque é regra que morde: mandar pool e IP
               fixo juntos deixa o resultado na mão do equipamento. O sistema resolve isso dando
               preferência ao IP fixo (ver ws_rad_sync_contrato), e o campo avisa qual vale. */ ?>
      <label class="cx5">Pool de IP própria (opcional)
        <input name="pool" value="<?= $g('pool') ?>" placeholder="vazio = pool padrão"
               title="Nome da pool NO CONCENTRADOR. O RADIUS só devolve o nome — a faixa tem de existir no equipamento com esse nome exato, senão o cliente não recebe endereço.">
        <small class="ws-muted" style="font-size:11px">
          <?php if (trim((string)($ct['ip_fixo'] ?? '')) !== '' && trim((string)($ct['pool'] ?? '')) !== ''): ?>
            <br><span style="color:#b45309">⚠️ Com IP fixo preenchido, é o <b>IP fixo</b> que vale — a pool fica sem efeito.</span>
          <?php endif; ?>
        </small>
      </label>
      <label class="cx5">SN ONU / ONT <input name="sn_onu" id="c_sn" placeholder="liga na OLT" value="<?= $g('sn_onu') ?>" oninput="wsCOntAuto()"></label>
      <?php /* obs3 — a VLAN passou a ser preenchida pela PRÓPRIA CONEXÃO: a cada leitura dos
               concentradores, ws_conexao_registrar() (radius_lib.php) grava aqui a VLAN em que o
               cliente autenticou. Continua editável: o que for digitado vale até a próxima
               conexão informar outra — e aí a rede tem razão, não o cadastro. */ ?>
      <label class="cx5">VLAN <span class="ws-auto-badge" title="Preenchida sozinha pela conexão no concentrador (e pela autorização da OLT). Editável.">auto</span> <input name="vlan" type="number" value="<?= $g('vlan') ?>"></label>
      <label class="cx5">Zona (OLT) <span class="ws-auto-badge" title="Puxado da OLT">auto</span> <input name="zona" list="ws_zonas" value="<?= $g('zona') ?>"></label><?= ws_zonas_datalist($db) ?>
      <label class="c-onu cx5">Placa PON <span class="ws-auto-badge" title="Preenchido ao aprovisionar na OLT">auto</span> <input name="placa_pon" value="<?= $g('placa_pon') ?>" placeholder="auto ao aprovisionar"></label>
      <label class="c-onu cx5">PON <span class="ws-auto-badge" title="Preenchido ao aprovisionar na OLT">auto</span> <input name="pon" value="<?= $g('pon') ?>" placeholder="auto ao aprovisionar"></label>
      <?php /* AS DUAS PONTAS DO ENLACE ÓPTICO, lado a lado e com o mesmo comportamento (badge
               "auto" + atualização a cada 45s vinda da OLT):
                 RX (sinal ONU)   = o que a ONU RECEBE  — fibra da OLT até a casa do cliente;
                 RX (retorno OLT) = o que a OLT RECEBE  — laser da ONU e emenda no caminho de volta.
               Separados de propósito, em campos próprios: juntar os dois num texto só impediria
               procurar, ordenar e comparar cada um, que é justamente o uso deles no diagnóstico. */ ?>
      <label class="c-onu cx5">RX (sinal ONU) <span class="ws-auto-badge" title="O que a ONU recebe da OLT — coletado da OLT">auto</span> <input name="rx_sinal" value="<?= $g('rx_sinal') ?>" placeholder="dBm"></label>
      <label class="c-onu cx5">RX (retorno OLT) <span class="ws-auto-badge" title="O que a OLT recebe desta ONU (upstream) — coletado da OLT">auto</span> <input name="rx_olt" value="<?= $g('rx_olt') ?>" placeholder="dBm"></label>
      <label class="c-onu cx5">TX (sinal) <span class="ws-auto-badge" title="Coletado da OLT">auto</span> <input name="tx_sinal" value="<?= $g('tx_sinal') ?>" placeholder="dBm"></label>
      </div>
      <style>
        #ws_form_contrato>#ws_rede14{grid-column:1 / -1!important;width:100%;box-sizing:border-box}
        #ws_rede14{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px 14px;width:100%}
        #ws_rede14>label{display:flex;flex-direction:column;position:relative;min-width:0;width:100%}
        #ws_rede14 select,#ws_rede14 input{width:100%;box-sizing:border-box}
        @media (min-width:821px){ #ws_rede14{grid-template-columns:repeat(7,minmax(0,1fr))!important} }
      </style>
      <div class="c4 ws-secao c-onu">Equipamento</div>
      <?php /* 19/11/2026: os 7 campos do Equipamento numa linha só, tamanho igual (desktop); no celular cai pra 2 colunas. */ ?>
      <div class="c4 c-onu" id="ws_equip7">
      <label class="c-onu cx5">
        <span style="display:flex;align-items:center;justify-content:space-between;gap:4px">Equipamento
          <button type="button" onclick="wsPuxarModoOLT()" title="Puxar da OLT — lê o modo atual da ONU pelo SN" aria-label="Puxar da OLT"
                  style="border:1px solid var(--border);background:var(--surface);border-radius:6px;width:22px;height:20px;line-height:1;cursor:pointer;color:var(--muted);flex:none">↧</button>
        </span>
        <select name="equipamento" id="c_equipamento" title="Regra do Equipamento: ONT = Router, sempre em comodato. PPPoE com ONU em bridge + roteador em comodato = ONU (Bridge) e Roteador em comodato Sim. PPPoE sem ONU com roteador = Router. ONU sem roteador (roteador do cliente) não entra no comodato. O que você escolher aqui não é trocado sozinho.">
        <?php foreach (['','ONU (Bridge)','ONT (Router)'] as $eq) echo "<option ".$sel('equipamento',$eq).">".($eq?:'—')."</option>"; ?>
        </select>
        <small id="c_modo_olt" class="ws-muted" style="display:block;font-size:11px"></small>
      </label>
      <script>
      // #4 — puxa o modo (Bridge/Router) em tempo real da OLT pelo SN da ONU e SUGERE no campo,
      // que continua editável pelo operador. Sem SN, avisa. Erro de OLT, mostra o motivo.
      function wsPuxarModoOLT(){
        var sn=(document.getElementById('c_sn')||{}).value||''; sn=sn.trim();
        var info=document.getElementById('c_modo_olt'), selE=document.getElementById('c_equipamento');
        if(!sn){ info.textContent='Preencha o SN ONU / ONT primeiro.'; info.style.color='#b45309'; return; }
        info.textContent='Consultando a OLT…'; info.style.color='';
        fetch('olt_huawei.php?acao=modo_sn&sn='+encodeURIComponent(sn),{cache:'no-store'})
          .then(function(r){return r.json();})
          .then(function(d){
            if(d.status!=='ok'){ info.textContent='OLT: '+(d.message||'sem resposta'); info.style.color='#b91c1c'; return; }
            if(d.modo){ selE.value=d.modo; info.textContent='Modo da OLT: '+d.modo+' (perfil '+(d.srvprofile||'?')+') — ajuste se quiser.'; info.style.color='#15803d'; }
            else { info.textContent='OLT respondeu, mas o perfil "'+(d.srvprofile||'?')+'" não indica bridge/router — preencha manualmente.'; info.style.color='#b45309'; }
          })
          .catch(function(){ info.textContent='Falha de comunicação com a OLT.'; info.style.color='#b91c1c'; });
      }
      </script>
      <label class="cx5">Comodato <select name="comodato">
        <?php foreach (['1'=>'Sim','0'=>'Não'] as $cv=>$cl) echo "<option value='$cv' ".(((string)($ct['comodato']??'1'))===(string)$cv?'selected':'').">$cl</option>"; /* 03/10/2026: padrão Sim */ ?>
      </select></label>
      <?php /* Roteador do cliente quando a ONU é Bridge (03/10/2026) — preenchido também na autorização da ONU */ ?>
      <label class="cx5 c-rot">Roteador em comodato? <select name="roteador_comodato"><option value="">—</option>
        <?php foreach (['1'=>'Sim','0'=>'Não (do cliente)'] as $rv=>$rl) echo "<option value='$rv' ".(((string)($ct['roteador_comodato']??''))===(string)$rv?'selected':'').">$rl</option>"; ?></select></label>
      <label class="cx5 c-rot">Modelo do roteador <input name="roteador_modelo" list="ws_dl_rot_modelo" value="<?= $g('roteador_modelo') ?>" placeholder="da lista de equipamentos">
        <datalist id="ws_dl_rot_modelo"><?php try { foreach ($db->query("SELECT DISTINCT modelo FROM ws_equipamento WHERE COALESCE(modelo,'')<>'' AND COALESCE(tipo,'') NOT IN ('ONT (Router)','ONU (Bridge)') ORDER BY modelo")->fetchAll(PDO::FETCH_COLUMN) as $mr) echo '<option value="' . h($mr) . '">'; } catch (Throwable $e) {} ?></datalist></label>
      <script>(function(){ var s=document.getElementById('c_equipamento'); function f(){ var b=s && s.value==='ONU (Bridge)'; document.querySelectorAll('.c-rot').forEach(function(l){ l.style.display=b?'':'none'; }); } if(s){ s.addEventListener('change', f); f(); } })();</script>
      <?php
        // Lista de equipamentos cadastrados (Cadastros > Equipamentos) — usada tanto na sugestão
        // (datalist, pelo serial) quanto no autopreenchimento de Modelo/MAC via JS abaixo.
        $wsEquipList = [];
        try { $wsEquipList = $db->query("SELECT modelo,serial,mac,tipo,foto FROM ws_equipamento WHERE serial IS NOT NULL AND serial<>'' ORDER BY modelo")->fetchAll(); } catch (Throwable $e) {}
        // Modelos p/ DATALIST (digitação livre) do campo "Modelo do equip.": junta o cadastro de
        // Equipamentos com os modelos já usados em contratos migrados/importados do backup.
        $wsModelos = [];
        try { $wsModelos = $db->query("SELECT modelo FROM ws_equipamento WHERE modelo<>'' UNION SELECT equip_modelo FROM ws_contrato WHERE equip_modelo IS NOT NULL AND equip_modelo<>'' ORDER BY modelo")->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
        // Modelos p/ o SELETOR de escolha do campo "Modelo do equip.": SÓ o que está cadastrado em
        // Cadastros > Equipamentos (é exatamente essa lista que aparece lá) — sem misturar com
        // texto livre de migração antiga, que fica só na digitação/datalist acima.
        $wsEquipCadastro = [];
        try { $wsEquipCadastro = $db->query("SELECT DISTINCT modelo FROM ws_equipamento WHERE modelo<>'' ORDER BY modelo")->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
        // Relação COMPLETA dos equipamentos cadastrados (Cadastros › Equipamentos = comodato):
        // modelo · tipo · serial · MAC · status. Vira a lista de BUSCA dentro do campo "Modelo do equip."
        $wsEquipRel = [];
        try { $wsEquipRel = $db->query("SELECT modelo,tipo,serial,mac,status,foto FROM ws_equipamento WHERE ativo=1 AND modelo<>'' ORDER BY (status='comodato') DESC, modelo, serial")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) {}
        foreach ($wsEquipRel as &$_er) { if (!empty($_er['foto'])) $_er['foto'] = ws_img($_er['foto']); } unset($_er);
      ?>
      <label class="cx5">Modelo do equip.
        <span style="position:relative;display:block">
          <input name="equip_modelo" id="c_equip_modelo" list="ws_dl_equip_modelo" value="<?= $g('equip_modelo') ?>" placeholder="digite ou clique na seta pra buscar no comodato" style="width:100%;padding-right:34px">
          <button type="button" id="c_equip_modelo_seta" title="Buscar na relação de equipamentos em comodato (Cadastros › Equipamentos)" aria-label="Buscar equipamentos em comodato"
                  style="position:absolute;top:0;right:0;height:100%;width:32px;border:none;background:transparent;cursor:pointer;color:var(--muted);display:flex;align-items:center;justify-content:center">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <div id="c_equip_modelo_lista" style="display:none;position:absolute;top:100%;left:0;right:0;background:var(--surface);border:1px solid var(--border);border-radius:8px;box-shadow:var(--shadow-lg);z-index:50;max-height:220px;overflow-y:auto"></div>
        </span>
      </label>
      <label class="cx5">Serial do equip. <input name="equip_serial" id="c_equip_serial" list="ws_dl_equip_serial" value="<?= $g('equip_serial') ?>" placeholder="digite ou escolha um já cadastrado" oninput="wsEquipAuto()" onchange="wsEquipAuto()"></label>
      <label class="cx5">MAC do equip. <input name="equip_mac" id="c_equip_mac" value="<?= $g('equip_mac') ?>" placeholder="AA:BB:CC:DD:EE:FF"></label>
      </div>
      <style>
        #ws_form_contrato>#ws_equip7{grid-column:1 / -1!important;width:100%;box-sizing:border-box}
        #ws_equip7{display:flex!important;flex-wrap:wrap;gap:12px 14px;width:100%}
        #ws_equip7>label{display:flex;flex-direction:column;position:relative;min-width:0;flex:1 1 calc(50% - 14px)}
        #ws_equip7 select,#ws_equip7 input{width:100%;box-sizing:border-box}
        @media (min-width:821px){ #ws_equip7>label{flex:1 1 0;min-width:0} }
      </style>
      <datalist id="ws_dl_equip_modelo"><?php foreach ($wsModelos as $md) echo '<option value="' . h($md) . '">'; ?></datalist>
      <datalist id="ws_dl_equip_serial"><?php foreach ($wsEquipList as $eq) echo '<option value="' . h($eq['serial']) . '">' . h($eq['modelo']) . ($eq['mac'] ? ' — ' . h($eq['mac']) : '') . '</option>'; ?></datalist>
      <script>
        // Busca de "Modelo do equip." (seta dentro do campo) — abre a RELAÇÃO de equipamentos em
        // comodato cadastrados (Cadastros › Equipamentos): modelo · serial · MAC · status, com um
        // campo de busca no topo. Ao clicar num item, preenche Modelo + Serial + MAC (editável).
        (function(){
          var equipRel = <?= json_encode($wsEquipRel, JSON_UNESCAPED_UNICODE) ?>;
          var campo = document.getElementById('c_equip_modelo'), seta = document.getElementById('c_equip_modelo_seta'),
              lista = document.getElementById('c_equip_modelo_lista'),
              elSerial = document.getElementById('c_equip_serial'), elMac = document.getElementById('c_equip_mac');
          function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
          function render(filtro){
            var f = (filtro||'').trim().toLowerCase();
            /* Equipamento = ONU (Bridge): ONT não aparece na relação (03/10/2026). Com ONU em bridge o que entra
               no comodato é a própria ONU ou o roteador; se não houver roteador, ele é do cliente e não entra. */
            var ehBridge = (document.getElementById('c_equipamento')||{}).value === 'ONU (Bridge)';
            var itens = equipRel.filter(function(eq){
              if(ehBridge && /\bONT\b/i.test((eq.tipo||'')+' '+(eq.modelo||''))) return false;
              if(!f) return true;
              return ((eq.modelo||'')+' '+(eq.serial||'')+' '+(eq.mac||'')+' '+(eq.tipo||'')).toLowerCase().indexOf(f) !== -1;
            });
            var html = '<div style="position:sticky;top:0;background:var(--surface);padding:6px;border-bottom:1px solid var(--border)">'
              + '<input id="c_eq_busca" type="text" placeholder="buscar modelo, serial, MAC…" value="'+esc(filtro||'')+'" style="width:100%;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--bg);color:var(--text);font-size:13px"></div>';
            if(!itens.length){ html += '<div style="padding:10px;color:var(--muted);font-size:13px">Nenhum equipamento em comodato encontrado.</div>'; }
            else html += itens.map(function(eq){
              var st = eq.status==='comodato' ? '<span style="color:var(--brand)">em comodato</span>' : esc(eq.status||'');
              return '<div class="c-eq-modelo-item" data-m="'+esc(eq.modelo)+'" data-s="'+esc(eq.serial)+'" data-mac="'+esc(eq.mac)+'" data-tipo="'+esc(eq.tipo)+'" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid var(--border);font-size:13px">'
                + '<b>'+esc(eq.modelo)+'</b>'+(eq.tipo?' · '+esc(eq.tipo):'')
                + '<div style="color:var(--muted);font-size:11px">'+(eq.serial?'SN '+esc(eq.serial):'sem serial')+(eq.mac?' · '+esc(eq.mac):'')+' · '+st+'</div></div>';
            }).join('');
            lista.innerHTML = html;
            var busca = document.getElementById('c_eq_busca');
            if(busca){ busca.addEventListener('input', function(){ render(this.value); this.focus(); this.setSelectionRange(this.value.length,this.value.length); });
              busca.addEventListener('click', function(e){ e.stopPropagation(); }); busca.focus(); }
            lista.querySelectorAll('.c-eq-modelo-item').forEach(function(it){
              it.addEventListener('click', function(){
                campo.value = it.getAttribute('data-m')||'';
                if(elSerial && it.getAttribute('data-s')) elSerial.value = it.getAttribute('data-s');
                if(elMac && it.getAttribute('data-mac')) elMac.value = it.getAttribute('data-mac');
                wsEquipModoAuto((it.getAttribute('data-tipo')||'') + ' ' + (it.getAttribute('data-m')||''), it.getAttribute('data-m')||'');
                lista.style.display='none';
              });
            });
          }
          seta.addEventListener('click', function(e){
            e.stopPropagation();
            if (lista.style.display === 'block') { lista.style.display = 'none'; return; }
            render(''); lista.style.display = 'block';
          });
          document.addEventListener('click', function(e){ if (e.target !== seta && !lista.contains(e.target)) lista.style.display = 'none'; });
        })();
      // Autopreenchimento: ao digitar/escolher um Serial já cadastrado em "Cadastros > Equipamentos",
      // preenche sozinho o Modelo e o MAC (permanece editável — o operador pode ajustar depois).
      var wsEquipMap = <?= json_encode(array_column($wsEquipList, null, 'serial'), JSON_UNESCAPED_UNICODE) ?>;
      // REGRA: equipamento ONU => (Bridge); ONT => (Router). Deriva do tipo/modelo e marca o campo
      // "Equipamento" automaticamente (continua editável — o operador pode trocar).
      // 03/10/2026 — a regra NÃO sobrepõe o que foi escolhido:
      //  • A regra de sempre continua: ONT => Router (sempre em comodato); ONU => Bridge; PPPoE sem ONU com roteador => Router.
      //  • PPPoE com ONU JÁ em bridge + roteador em comodato: não vira Router; o roteador vai em "Roteador em comodato? Sim" + modelo.
      //  • ONU sem roteador (roteador do cliente): não entra no comodato, nada é marcado.
      //  • Equipamento escolhido À MÃO nesta tela: a regra automática não troca mais.
      (function(){ var s=document.getElementById('c_equipamento'); if(s) s.addEventListener('change', function(e){ if(e.isTrusted) s.setAttribute('data-manual','1'); }); })();
      function wsEquipModoAuto(txt, modelo){
        var sel=document.getElementById('c_equipamento'); if(!sel) return;
        var t=(txt||'').toUpperCase();
        var ehOnt=/\bONT\b/.test(t), ehRot=!ehOnt && /ROUTER|ROTEADOR/.test(t), ehOnu=!ehOnt && !ehRot && /\bONU\b|BRIDGE/.test(t);
        if(!ehOnt && !ehRot && !ehOnu) return;
        var temOnu=['c_sn','c_ont'].some(function(id){ var e=document.getElementById(id); return !!(e && e.value.trim()); });
        var info=document.getElementById('c_modo_olt');
        if(ehRot && temOnu && sel.value==='ONU (Bridge)'){
          // ONU JÁ em bridge + roteador em comodato: continua Bridge e o roteador vai para "Roteador em comodato".
          var rc=document.querySelector('select[name="roteador_comodato"]'), rm=document.querySelector('input[name="roteador_modelo"]');
          if(rc && !rc.value) rc.value='1'; if(rm && !rm.value.trim() && modelo) rm.value=modelo;
          if(info){ info.textContent='ONU em bridge com roteador em comodato: o Equipamento continua "ONU (Bridge)" e o roteador fica em "Roteador em comodato".'; info.style.color='#15803d'; }
          return;
        }
        if(sel.getAttribute('data-manual')) return;   // escolhido à mão: vale o que o operador escolheu
        sel.value = ehOnu ? 'ONU (Bridge)' : 'ONT (Router)';
        sel.dispatchEvent(new Event('change'));
      }
      function wsEquipAuto(){
        var elS=document.getElementById('c_equip_serial'); if(!elS) return;
        var chave=(elS.value||'').trim().toUpperCase();
        var eq=wsEquipMap[chave] || wsEquipMap[elS.value.trim()];
        if(!eq) return;
        var elM=document.getElementById('c_equip_modelo'), elMac=document.getElementById('c_equip_mac');
        if(elM && eq.modelo) elM.value=eq.modelo;
        if(elMac && eq.mac) elMac.value=eq.mac;
        wsEquipModoAuto((eq.tipo||'') + ' ' + (eq.modelo||''), eq.modelo||'');
      }
      // Ao digitar direto no "Modelo do equip." também deriva Bridge/Router.
      (function(){ var m=document.getElementById('c_equip_modelo'); if(m) m.addEventListener('change',function(){ wsEquipModoAuto(this.value, this.value); }); })();
      // #8 — HOVER no "Modelo do equip." mostra a FOTO do equipamento (comodato) casando por serial/modelo.
      (function(){
        var rel = <?= json_encode($wsEquipRel, JSON_UNESCAPED_UNICODE) ?>;
        var contratoFoto = <?= json_encode(!empty($ct['equip_foto']) ? ws_img((string)$ct['equip_foto']) : '', JSON_UNESCAPED_UNICODE) ?>;
        var campo=document.getElementById('c_equip_modelo'), serial=document.getElementById('c_equip_serial');
        if(!campo) return;
        var box=document.createElement('div');
        box.style.cssText='display:none;position:absolute;z-index:9999;background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:6px;box-shadow:var(--shadow-lg,0 8px 28px -10px rgba(0,0,0,.35))';
        box.innerHTML='<img alt="foto do equipamento" style="max-width:230px;max-height:230px;display:block;border-radius:6px">';
        document.body.appendChild(box);
        function achaFoto(){
          if(contratoFoto) return contratoFoto;
          var m=(campo.value||"").trim().toLowerCase(), s=((serial&&serial.value)||"").trim().toLowerCase();
          for(var i=0;i<rel.length;i++){ if(rel[i].foto && s && (rel[i].serial||"").toLowerCase()===s) return rel[i].foto; }
          for(var i=0;i<rel.length;i++){ if(rel[i].foto && m && (rel[i].modelo||"").toLowerCase()===m) return rel[i].foto; }
          return "";
        }
        campo.addEventListener("mouseenter", function(){
          var f=achaFoto(); if(!f){ box.style.display="none"; return; }
          box.querySelector("img").src=f; box.style.display="block";
          var r=campo.getBoundingClientRect(); box.style.left=(window.scrollX+r.left)+"px"; box.style.top=(window.scrollY+r.bottom+6)+"px";
        });
        campo.addEventListener("mouseleave", function(){ box.style.display="none"; });
      })();
      </script>
      <?php if ($id && in_array(($ct['tipo_conexao'] ?? ''), ['ipoe','pppoe'], true) && ($ct['ont_id'] || $ct['sn_onu'])): $alvo=urlencode($ct['ont_id'] ?: $ct['sn_onu'] ?: '');
        $onuAtiva = (int)($ct['onu_ativa'] ?? 1) === 1; ?>
      <div class="c4 c-onu ws-panel ws-olt-acoes" style="margin-top:6px">
        <b style="display:block;margin-bottom:10px;font-size:13px">Ações na OLT</b>
        <?= ws_olt_acoes_html($ct, (int)$id, 'erp.php') ?>
        <?php if (!$onuAtiva): ?><p class="ws-muted" style="font-size:12px;margin:8px 0 0">⛔ Esta ONU está marcada como <b>desativada</b> — o cliente fica sem conexão até reativar.</p><?php endif; ?>
      </div>
      <?php endif; ?>
      <script>function wsCTipo(){var t=document.getElementById('c_tipo').value;
        // Login/Senha PPPoE só no PPPoE; Login/Senha IPoE só no IPoE.
        document.querySelectorAll('.c-pppoe').forEach(e=>e.style.display=(t==='pppoe')?'flex':'none');
        document.querySelectorAll('.c-ipoe').forEach(e=>e.style.display=(t==='ipoe')?'flex':'none');
        // Campos da ONU (ID, Placa/PON, RX/TX, Equipamento e as ações na OLT) valem para PPPoE E IPoE
        // — o cliente PPPoE também tem ONU. Só somem no Hotspot.
        // .ws-olt-acoes é um painel (título + grade de botões) que precisa ficar em COLUNA (block),
        // não em linha (flex) como os demais campos — senão a grade de botões fica espremida.
        document.querySelectorAll('.c-onu').forEach(e=>e.style.display=(t==='hotspot')?'none':(e.classList.contains('ws-olt-acoes')?'block':'flex'));}
        document.addEventListener('DOMContentLoaded',wsCTipo);
        // ID/SN preenche AUTOMÁTICO os campos ligados, minúsculo, só onde estiver vazio (editável).
        // IPoE: também preenche Login/Senha IPoE (que valem como login). PPPoE: NÃO mexe no login/senha
        // (o cliente PPPoE tem login/senha próprios), só espelha o ID no SN e no serial do equipamento.
        function wsCOntAuto(){
          var ont=document.getElementById('c_ont'), sn=document.getElementById('c_sn');
          var chave=((ont && ont.value.trim()) || (sn && sn.value.trim()) || '').toLowerCase();
          if(!chave) return;
          var t=document.getElementById('c_tipo').value;
          function setIf(id){var el=document.getElementById(id); if(el && !el.value.trim()) el.value=chave;}
          if(ont && !ont.value.trim()) ont.value=chave;
          if(t==='ipoe'){ setIf('c_login_ipoe'); setIf('c_senha_ipoe'); }
          setIf('c_sn');
          var eqSn=document.querySelector('input[name="equip_serial"]');
          if(eqSn && !eqSn.value.trim()) eqSn.value=chave.toUpperCase();
          if(typeof wsEquipAuto==='function') wsEquipAuto();
        }
        // Ao abrir um contrato IPoE já existente, garante os campos preenchidos (nunca em branco).
        document.addEventListener('DOMContentLoaded',function(){ if(document.getElementById('c_tipo').value==='ipoe') wsCOntAuto(); });
        // Valor mensal: se abrir vazio e já houver plano escolhido, puxa o valor do plano (auto).
        document.addEventListener('DOMContentLoaded',function(){
          var v=document.getElementById('c_valor'), p=document.getElementById('c_plano_id');
          if(v && p && !(v.value||'').trim() && p.value && typeof wsPlanoValor==='function') wsPlanoValor('c_plano_id','c_valor');
        });

        /* CAMPOS "AUTO" DA OLT AO VIVO — de 45 em 45 segundos, enquanto a ficha estiver aberta.
           Vale para TUDO que é preenchido pela OLT: sinal RX/TX, zona, VLAN, placa, PON, ONT-ID,
           equipamento/modelo e o tipo (bridge/router).

           TRÊS REGRAS, e nenhuma delas é cosmética:
             1. Só escreve quando VEIO valor. Leitura vazia (OLT fora do ar, cache velho, ONU
                offline) mantém o que está no campo — apagar sozinho seria perder dado sem
                ninguém pedir.
             2. Não toca no campo que o operador está editando naquele instante.
             3. Não toca em campo que o operador MEXEU nesta sessão de edição: se ele corrigiu a
                zona à mão, a OLT não desfaz por cima enquanto ele não salvar. */
        (function(){
          // name do campo no formulário -> é a mesma chave que o endpoint devolve.
          var CAMPOS = ['rx_sinal','tx_sinal','zona','vlan','placa_pon','pon','ont_id',
                        'equipamento','equip_modelo','equip_tipo'];
          var els = {}, temAlgum = false;
          CAMPOS.forEach(function(n){
            var el = document.querySelector('[name="' + n + '"]');
            if (el) { els[n] = el; temAlgum = true; el.addEventListener('input', function(){ el.dataset.wsMexido = '1'; }); }
          });
          if (!temAlgum) return;

          function serial(){
            var sn = document.getElementById('c_sn'), ont = document.getElementById('c_ont');
            return ((sn && sn.value.trim()) || (ont && ont.value.trim()) || '');
          }
          function aplicar(el, valor){
            if (!el || !valor) return;                       // regra 1
            if (document.activeElement === el) return;        // regra 2
            if (el.dataset.wsMexido === '1') return;          // regra 3
            if (el.value.trim() === String(valor).trim()) return;
            el.value = valor;
            el.classList.add('ws-sinal-novo');
            setTimeout(function(){ el.classList.remove('ws-sinal-novo'); }, 1400);
          }
          /* Assinatura do último retrato recebido. Vai junto na próxima pergunta; se a OLT
             continuar com os mesmos valores, o servidor responde só "igual" e este ciclo termina
             aqui mesmo — sem campos, sem comparação, sem escrita na tela. */
          var ultimaSig = '';

          function ler(){
            if (document.hidden) return;                      // aba escondida: não consulta à toa
            var sn = serial(); if (!sn) return;
            /* login vai junto porque a segunda fonte é o CONCENTRADOR, que casa por login (não
               por serial da ONU). Com os dois, a ficha se completa mesmo quando só uma das
               fontes está respondendo. */
            var lg = (document.getElementById('c_login') && document.getElementById('c_login').value.trim())
                  || (document.getElementById('c_login_ipoe') && document.getElementById('c_login_ipoe').value.trim())
                  || sn;
            fetch('erp.php?acao=onu_sinal&sn=' + encodeURIComponent(sn) +
                  '&login=' + encodeURIComponent(lg) +
                  (ultimaSig ? '&sig=' + encodeURIComponent(ultimaSig) : ''), { cache: 'no-store' })
              .then(function(r){ return r.json(); })
              .then(function(d){
                if (!d || !d.ok) return;
                if (d.sig) ultimaSig = d.sig;
                if (d.igual) return;                          // nada mudou: consulta descartada
                if (!d.campos) return;
                Object.keys(d.campos).forEach(function(k){ aplicar(els[k], d.campos[k]); });
              })
              .catch(function(){ /* silencioso de propósito: falha de leitura não muda a tela */ });
          }
          if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ler); else ler();
          setInterval(ler, 45000);
        })();

        /* IP DINÂMICO ABAIXO DO CAMPO "IP fixo" — só texto, nunca campo.
           Lê o mesmo cache de conexões do Painel (endpoint conexao_uptime) e reescreve a linha.
           Deliberadamente NÃO toca no <input name="ip_fixo">: o que está ali é decisão do
           operador e só sai de lá se ele digitar. */
        (function () {
          var el = document.getElementById('c_ip_dinamico');
          if (!el) return;
          var ks = (el.dataset.login || '').split(',').filter(Boolean);   // logins da sessão, pelo tipo de conexão
          if (!ks.length) return;

          var ipAtual = '', seg = null;   // seg = segundos de conexão; null = sem sessão conhecida

          /* Conversão do uptime ("02:38:04", "3d 02:38:04") em segundos e de volta: vive em
             js/wellsystem.js (wsUptimeSeg/wsUptimeTxt), compartilhada com a dica da lista de
             Clientes. Duas cópias da mesma regra acabariam divergindo na primeira mudança. */
          var paraSegundos = wsUptimeSeg, paraTexto = wsUptimeTxt;
          function pintar() {
            if (!ipAtual) return;
            el.innerHTML = '🟢 IP dinâmico agora: <b style="color:var(--ok)">' + ipAtual.replace(/[<&]/g, '') + '</b>'
                         + (seg !== null ? ' · conectado há ' + paraTexto(seg) : '');
          }

          // RELÓGIO: avança de segundo em segundo, para o tempo ser o de AGORA e não o da última
          // consulta. Para quando a aba sai de vista — contar o que ninguém está lendo é desperdício.
          setInterval(function () {
            if (document.hidden || seg === null) return;
            seg++; pintar();
          }, 1000);

          function ler() {
            if (document.hidden) return;
            fetch('erp.php?acao=conexao_uptime', { cache: 'no-store' })
              .then(function (r) { return r.json(); })
              .then(function (d) {
                if (!d || !d.ok) return;
                if (!d.ips || !Object.keys(d.ips).length) return;   // leitura sem nenhuma sessão = concentrador sem resposta: não afirma offline
                var ip = '', up = '';
                for (var i = 0; i < ks.length && !ip; i++) { ip = (d.ips && d.ips[ks[i]]) || ''; up = (d.uptimes && d.uptimes[ks[i]]) || ''; }
                // A leitura do servidor RESSINCRONIZA o relógio: o contador local corrige qualquer
                // desvio a cada 45s, e uma reconexão do cliente (uptime que volta a zero) aparece.
                if (ip) { ipAtual = ip; seg = paraSegundos(up); pintar(); }
                // Sem sessão na leitura = OFFLINE: nunca "agora". O último IP visto continua na tela
                // (é a informação de que o suporte precisa), marcado como histórico.
                else { ipAtual = ''; seg = null; el.innerHTML = el.dataset.off || 'IP dinâmico: sem registro de conexão ainda'; }
              })
              .catch(function () {});
          }
          if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ler); else ler();
          setInterval(ler, 45000);
          // Voltou para a aba: ressincroniza na hora, sem esperar o próximo ciclo de 45s.
          document.addEventListener('visibilitychange', function () { if (!document.hidden) ler(); });
        })();
        </script>
        <style>
          /* Pisca leve quando o sinal muda — o operador percebe a atualização sem susto. */
          .ws-sinal-novo{animation:wsSinalNovo 1.4s ease}
          @keyframes wsSinalNovo{0%{background:rgba(22,163,74,.28)}100%{background:transparent}}
        </style>
      <div class="c4 ws-secao">Sistema</div>
      <?php /* 19/11/2026: os 3 campos numa linha só, tamanho igual (desktop). */ ?>
      <div class="c4" id="ws_sis3">
      <label>Dia venc. <?= ws_venc_dia_select('dia_vencimento', $ct['dia_vencimento'] ?? 0) ?></label>
      <label>Ativação <input type="date" name="data_ativacao" value="<?= $g('data_ativacao') ?>"></label>
      <label>Status <select name="status">
        <?php foreach (['ativo','suspenso','bloqueado','cancelado'] as $s) echo "<option value=\"$s\" ".$sel('status',$s).">".ws_status_rotulo($s)."</option>"; ?>
      </select></label>
      </div>
      <style>
        #ws_form_contrato>#ws_sis3{grid-column:1 / -1!important;width:100%;box-sizing:border-box}
        #ws_sis3{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px 14px;width:100%}
        #ws_sis3>label{display:flex;flex-direction:column;position:relative;min-width:0;width:100%}
        #ws_sis3 select,#ws_sis3 input{width:100%;box-sizing:border-box}
        @media (min-width:821px){ #ws_sis3{grid-template-columns:repeat(3,minmax(0,1fr))!important} }
      </style>
      <div class="c4 ws-secao">Endereço de instalação</div>
      <?php /* 19/11/2026: os 9 campos do endereço numa linha só (desktop); Logradouro ganha mais espaço, os outros ficam mais estreitos. No celular cai pra 2 colunas. */ ?>
      <div class="c4" id="ws_inst9">
      <label class="e4">CEP inst. <input name="inst_cep" id="c_inst_cep" value="<?= $g('inst_cep') ?>"></label>
      <label>Logradouro inst. <input name="inst_logradouro" value="<?= $g('inst_logradouro') ?>"></label>
      <label class="e3">Número <input name="inst_numero" value="<?= $g('inst_numero') ?>"></label>
      <label class="e5">Complemento <input name="inst_complemento" value="<?= $g('inst_complemento') ?>"></label>
      <label class="e5">Bairro <input name="inst_bairro" list="ws_dl_bairros" value="<?= $g('inst_bairro') ?>" placeholder="digite ou escolha"></label>
      <label class="e5">Cidade <input name="inst_cidade" id="c_inst_cidade" list="ws_dl_cidades" value="<?= $g('inst_cidade') ?>" placeholder="digite ou escolha"></label>
      <?php $cidadesMapCt = $db->query("SELECT nome,uf,cep FROM ws_cidade WHERE ativo=1 ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC); ?>
      <datalist id="ws_dl_cidades"><?php foreach ($cidadesMapCt as $cm) echo '<option value="' . h($cm['nome']) . '">'; ?></datalist>
      <datalist id="ws_dl_bairros"><?php foreach ($db->query("SELECT nome FROM ws_bairro WHERE ativo=1 ORDER BY nome")->fetchAll(PDO::FETCH_COLUMN) as $bn) echo '<option value="' . h($bn) . '">'; ?></datalist>
      <label class="e2">UF <input name="inst_uf" id="c_inst_uf" maxlength="2" value="<?= $g('inst_uf') ?>"></label>
      <script>
      // Cidade → UF + CEP automáticos (do cadastro de Cidades), só onde estiver vazio (editável).
      (function(){
        var mapa = <?= json_encode(array_column(array_map(function($c){return ['k'=>mb_strtoupper($c['nome'],'UTF-8'),'uf'=>$c['uf'],'cep'=>$c['cep']];}, $cidadesMapCt), null, 'k'), JSON_UNESCAPED_UNICODE) ?>;
        var inpC=document.getElementById('c_inst_cidade'), inpU=document.getElementById('c_inst_uf'), inpCep=document.getElementById('c_inst_cep');
        function auto(){ if(!inpC) return; var d=mapa[(inpC.value||'').trim().toUpperCase()]; if(!d) return;
          if(inpU && d.uf && !inpU.value.trim()) inpU.value=d.uf;
          if(inpCep && d.cep && !inpCep.value.trim()) inpCep.value=d.cep; }
        if(inpC){ inpC.addEventListener('input',auto); inpC.addEventListener('change',auto); auto(); }
      })();
      </script>
      <label class="e4">Latitude <span class="ws-auto-badge" id="c_geo_badge" title="Preenchido pela cidade/UF ou pelo CEP">auto</span> <input name="lat" id="c_lat" value="<?= $g('lat') ?>"></label>
      <label class="e4">Longitude <input name="lng" id="c_lng" value="<?= $g('lng') ?>"></label>
      </div>
      <style>
        #ws_form_contrato>#ws_inst9{grid-column:1 / -1!important;width:100%;box-sizing:border-box}
        #ws_inst9{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px 14px;width:100%}
        #ws_inst9>label{display:flex;flex-direction:column;position:relative;min-width:0;width:100%}
        #ws_inst9 select,#ws_inst9 input{width:100%;box-sizing:border-box}
        @media (min-width:821px){ #ws_inst9{grid-template-columns:1.1fr 2.2fr .7fr 1.3fr 1.3fr 1.3fr .6fr 1.1fr 1.1fr!important} }
      </style>
      <script>
      // Geocodifica sozinho o endereço de instalação: Cidade+UF preenchidos → busca coordenadas; CEP (8 díg.) atualiza. Editável. Fonte: OpenStreetMap/Nominatim.
      (function(){
        var iC=document.getElementById('c_inst_cidade'),iU=document.getElementById('c_inst_uf'),iCep=document.getElementById('c_inst_cep'),
            iLat=document.getElementById('c_lat'),iLng=document.getElementById('c_lng'),bd=document.getElementById('c_geo_badge');
        if(!iLat||!iLng) return; var t=null,lastQ='';
        function set(la,lo){ if(la&&lo){iLat.value=(+la).toFixed(6);iLng.value=(+lo).toFixed(6);if(bd){bd.textContent='ok';bd.style.background='#16a34a';bd.style.opacity='1';/* verde sólido: o verde 18% com letra branca sumia */}} }
        function geo(q,force){ q=(q||'').trim(); if(!q||q===lastQ) return; if(window.WS_MAPA && !window.WS_MAPA.auto) return; lastQ=q;
          if(!force && (iLat.value.trim()||iLng.value.trim())) return;
          if(bd){bd.textContent='…';}
          wsGeocodificar(q)   // OpenStreet ou Google, conforme Recursos do sistema → Mapas
            .then(function(p){ if(p) set(p.lat,p.lon); else if(bd){bd.textContent='auto';} })
            .catch(function(){ if(bd){bd.textContent='auto';} }); }
        function porCidade(){ var c=(iC&&iC.value||'').trim(),u=(iU&&iU.value||'').trim();
          if(c && u.length===2){ clearTimeout(t); t=setTimeout(function(){ geo(c+', '+u+', Brasil', false); },700); } }
        function porCep(){ var cep=((iCep&&iCep.value)||'').replace(/\D/g,''); if(cep.length!==8) return;
          clearTimeout(t); t=setTimeout(function(){ lastQ=''; geo('CEP '+cep, true); },700); }
        if(iC){iC.addEventListener('change',porCidade);iC.addEventListener('input',porCidade);}
        if(iU){iU.addEventListener('change',porCidade);iU.addEventListener('input',porCidade);}
        if(iCep){iCep.addEventListener('change',porCep);iCep.addEventListener('blur',porCep);}
        porCidade();
      })();
      </script>
      <label class="c4">Observações <textarea name="obs"><?= $g('obs') ?></textarea></label>
      <div class="c4"><button class="ws-btn primary">Salvar contrato</button>
        <?php if ($id): ?><a class="ws-btn danger" href="erp.php?tipo=contrato&excluir=<?= $id ?>&volta=cliente" onclick="return confirm('Excluir contrato?')">Excluir</a><?php endif; ?>
      </div>
    </form>
    <?php
}

/* --------- Cadastros: Cidade e Ramais (cadastro unificado, multi-cidade separado por ramal) --------- */
function ws_view_cadastros(PDO $db): void {
    $t = $_GET['t'] ?? 'cidades';
    ?>
    <div class="ws-head-row"><h2>🗂️ Cadastros</h2></div>
    <div class="ws-search">
      <?php foreach (['cidades'=>'Cidade','bairros'=>'Bairro','ramais'=>'Ramais','equipamentos'=>'Equipamentos','comodatos'=>'Comodatos (por cliente)'] as $k=>$v): ?>
        <a class="ws-btn <?= $t===$k?'primary':'' ?>" href="erp.php?p=cadastros&t=<?= $k ?>"><?= h($v) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if ($t === 'comodatos'):
      /* LISTA DE EQUIPAMENTOS EM COMODATO POR CLIENTE.
         "Cadastros › Equipamentos" agora é o CATÁLOGO DE MODELOS (um registro por modelo, sem
         repetir). Quem tem qual aparelho é dado do CONTRATO — e é isso que esta aba mostra:
         uma linha por cliente, com o equipamento que está com ele. */
      $fB = trim((string)($_GET['q'] ?? ''));
      $fT = trim((string)($_GET['tipo'] ?? ''));
      // Cidade do CADASTRO normalizado (wc.nome), não da coluna de texto do cliente.
      require_once __DIR__ . '/schema_endereco.php';
      $sql = "SELECT c.id cliente_id, c.nome, c.nome_resumido, wc.nome cidade, c.celular,
                     ct.id contrato_id, ct.login_pppoe, ct.login_ipoe, ct.equip_tipo, ct.equip_modelo,
                     ct.equip_serial, ct.equip_mac, ct.sn_onu, ct.status ct_status
              FROM ws_contrato ct
              JOIN ws_cliente c ON c.id = ct.cliente_id"
              . ws_end_sql_join('c') . "
              WHERE ct.comodato = 1 AND COALESCE(ct.status,'') <> 'cancelado' AND COALESCE(c.status,'') <> 'cancelado'";   // cancelado fora da base (01/10/2026)
      $args = [];
      if ($fT === '__sem') { $sql .= " AND (ct.equip_tipo IS NULL OR TRIM(ct.equip_tipo) = '')"; }   // cartão "Sem classificação"
      elseif ($fT !== '') { $sql .= " AND ct.equip_tipo = ?"; $args[] = $fT; }
      if ($fB !== '') {
          $sql .= " AND " . ws_busca_cond(['c.nome', 'ct.login_pppoe', 'ct.equip_serial',
                                              'ct.equip_modelo', 'ct.equip_mac'], $fB, $args);
      }
      $sql .= " ORDER BY c.nome";
      $com = []; try { $q = $db->prepare($sql); $q->execute($args); $com = $q->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { $com = []; }
      // Contagem por tipo, pro operador ver a composição do parque sem exportar nada.
      $porTipo = [];
      foreach ($com as $r) { $k = trim((string)$r['equip_tipo']) ?: 'Sem classificação'; $porTipo[$k] = ($porTipo[$k] ?? 0) + 1; }
      $tiposSel = [];
      try { foreach ($db->query("SELECT DISTINCT equip_tipo FROM ws_contrato WHERE comodato=1 AND equip_tipo IS NOT NULL AND equip_tipo<>'' ORDER BY equip_tipo") as $rt) $tiposSel[] = $rt['equip_tipo']; } catch (Throwable $e) {}
    ?>
      <h3>Equipamentos em comodato por cliente</h3>
      <?php $prevU = ['alterar' => 0, 'total' => 0, 'exemplos' => []]; try { $prevU = ws_equip_unificar_catalogo($db, false); } catch (Throwable $e) {} ?>
      <?php if ($prevU['alterar'] > 0): ?>
      <form method="post" class="ws-alert" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 12px" onsubmit="return confirm('Copiar modelo e tipo (Bridge/Router) do cadastro de Equipamentos para <?= (int)$prevU['alterar'] ?> contrato(s) em comodato? O cadastro prevalece.')">
        <input type="hidden" name="acao" value="unificar_equip_catalogo">
        <span><b><?= (int)$prevU['alterar'] ?></b> contrato(s) em comodato estão com modelo/tipo diferente do cadastro de Equipamentos<?= $prevU['exemplos'] ? ' — ex.: ' . h($prevU['exemplos'][0]) : '' ?>.</span>
        <button class="ws-btn primary" type="submit">🔄 Unificar com o cadastro</button>
      </form>
      <?php endif; ?>
      <p class="ws-muted" style="font-size:13px">
        Quem está com qual aparelho. O <b>catálogo de modelos</b> fica na aba <b>Equipamentos</b> —
        aqui é a lista de <b>clientes</b>, com o serial/MAC individual de cada um.
      </p>

      <?php /* (16/10/2026) cartões = parque INTEIRO em comodato (não mudam com o filtro); cada um abre a lista filtrada por aquele tipo */
        $cardsAll = []; try { foreach ($db->query("SELECT COALESCE(NULLIF(TRIM(ct.equip_tipo),''),'Sem classificação') t, COUNT(*) n FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id WHERE ct.comodato = 1 AND COALESCE(ct.status,'') <> 'cancelado' AND COALESCE(c.status,'') <> 'cancelado' GROUP BY t ORDER BY n DESC")->fetchAll(PDO::FETCH_ASSOC) as $rc) $cardsAll[(string)$rc['t']] = (int)$rc['n']; } catch (Throwable $e) {}
        $baseC = basename($_SERVER['SCRIPT_NAME']) . '?p=cadastros&t=comodatos'; $totAll = array_sum($cardsAll); ?>
      <div class="ws-cards" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin:0 0 12px">
        <a class="ws-stat" href="<?= h($baseC) ?>" title="Todos os equipamentos em comodato"<?= ($fT === '') ? ' style="outline:2px solid var(--brand)"' : '' ?>><span><?= $totAll ?></span><label>Em comodato ↗</label></a>
        <?php foreach ($cardsAll as $tk => $tv): $vf = ($tk === 'Sem classificação') ? '__sem' : $tk; ?>
          <a class="ws-stat" href="<?= h($baseC . '&tipo=' . urlencode($vf)) ?>" title="Ver só: <?= h($tk) ?>"<?= ($fT === $vf) ? ' style="outline:2px solid var(--brand)"' : '' ?>><span><?= (int)$tv ?></span><label><?= h($tk) ?> ↗</label></a>
        <?php endforeach; ?>
      </div>

      <form method="get" class="ws-search" style="margin-bottom:10px">
        <input type="hidden" name="p" value="cadastros"><input type="hidden" name="t" value="comodatos">
        <input name="q" value="<?= h($fB) ?>" placeholder="🔎 Cliente, login, modelo, serial ou MAC">
        <select name="tipo">
          <option value="">Todos os tipos</option>
          <?php foreach ($tiposSel as $ts): ?><option value="<?= h($ts) ?>" <?= $fT===$ts?'selected':'' ?>><?= h($ts) ?></option><?php endforeach; ?>
          <option value="__sem" <?= $fT==='__sem'?'selected':'' ?>>Sem classificação</option>
        </select>
        <button class="ws-btn primary ws-btn-ico" type="submit"><span aria-hidden="true">🔎</span> Filtrar</button>
        <?php if ($fB !== '' || $fT !== ''): ?>
          <a class="ws-btn ws-btn-ico" href="erp.php?p=cadastros&t=comodatos"><span aria-hidden="true">✖</span> Limpar</a>
        <?php endif; ?>
      </form>

      <?php $ppC = isset($_GET['pp']) ? (int)$_GET['pp'] : 25; if (!in_array($ppC, [25, 50, 100, 0], true)) $ppC = 25; $totC = count($com); $pgC = max(1, (int)($_GET['pg'] ?? 1)); if ($ppC > 0 && ($pgC - 1) * $ppC >= $totC) $pgC = max(1, (int)ceil($totC / $ppC)); $comPag = $ppC > 0 ? array_slice($com, ($pgC - 1) * $ppC, $ppC) : $com; $pagExtraC = ['p' => 'cadastros', 't' => 'comodatos', 'q' => $fB, 'tipo' => $fT]; echo ws_paginacao_topo($totC, $ppC, $pgC, $pagExtraC, [25, 50, 100, 0]); ?>
      <div style="overflow-x:auto"><table class="ws-table"><thead><tr>
        <th class="ws-th-esq">Cliente</th><th>Login</th><th>Tipo</th><th>Modelo</th><th>Serial</th><th>MAC</th><th>Cidade</th><th></th>
      </tr></thead><tbody>
      <?php foreach ($comPag as $r):
        $lg = $r['login_pppoe'] ?: ($r['login_ipoe'] ?: '—');
        $sn = $r['equip_serial'] ?: ($r['sn_onu'] ?: ''); ?>
        <tr>
          <td class="ws-th-esq"><a href="erp.php?p=cliente&id=<?= (int)$r['cliente_id'] ?>"><?= h($r['nome']) ?></a></td>
          <td><code><?= h($lg) ?></code></td>
          <td><?= $r['equip_tipo'] ? h($r['equip_tipo']) : '<span class="ws-muted" title="O backup não informou o modelo — classifique na ficha do cliente">a classificar</span>' ?></td>
          <td><?= h($r['equip_modelo'] ?: '—') ?></td>
          <td><code><?= h($sn ?: '—') ?></code></td>
          <td><code><?= h($r['equip_mac'] ?: '—') ?></code></td>
          <td><?= h($r['cidade'] ?: '—') ?></td>
          <td><a class="ws-btn" style="font-size:12px;padding:4px 10px" href="erp.php?p=cliente&id=<?= (int)$r['cliente_id'] ?>">Abrir ficha</a></td>
        </tr>
      <?php endforeach; if (!$com): ?>
        <tr><td colspan="8" class="ws-muted" style="text-align:center">Nenhum contrato marcado como comodato<?= ($fB!==''||$fT!=='') ? ' para este filtro' : '' ?>.</td></tr>
      <?php endif; ?>
      </tbody></table></div>
      <?= ws_paginacao_html($totC, $ppC, $pgC, $pagExtraC + ['pp' => $ppC]) ?>

    <?php endif; ?>

    <?php if ($t === 'equipamentos'): $eid=(int)($_GET['equipamento']??0); $e=null;
        if($eid){$st=$db->prepare("SELECT * FROM ws_equipamento WHERE id=?");$st->execute([$eid]);$e=$st->fetch();}
        $rows = $db->query("SELECT * FROM ws_equipamento ORDER BY modelo,serial")->fetchAll();
        $fotoModelo = []; foreach ($rows as $r0) if (!empty($r0['foto'])) $fotoModelo[mb_strtolower((string)$r0['modelo'])] = $r0['foto'];   // (16/10/2026) unidade sem foto mostra a do modelo
        $rowsGaleria = $rows; foreach ($rows as $ri => $rr) if (empty($rr['foto']) && isset($fotoModelo[mb_strtolower((string)$rr['modelo'])])) $rows[$ri]['foto'] = $fotoModelo[mb_strtolower((string)$rr['modelo'])];
        /* (16/10/2026) PÁGINAS: 25 / 50 / 100 / Todos (padrão 25) — a lista tem uma linha por equipamento do cliente */
        $ppE = isset($_GET['pp']) ? (int)$_GET['pp'] : 25; if (!in_array($ppE, [25, 50, 100, 0], true)) $ppE = 25;
        $totE = count($rows); $pgE = max(1, (int)($_GET['pg'] ?? 1)); if ($ppE > 0 && ($pgE - 1) * $ppE >= $totE) $pgE = max(1, (int)ceil($totE / $ppE));
        $rowsPag = $ppE > 0 ? array_slice($rows, ($pgE - 1) * $ppE, $ppE) : $rows;
        $pagExtra = ['p' => 'cadastros', 't' => 'equipamentos']; ?>
      <div class="ws-two">
        <div>
          <h3>Equipamentos cadastrados</h3>
          <p class="ws-muted" style="font-size:13px">Equipamentos entregues em comodato (ONU, roteador, etc.). Ao escolher o serial no cadastro do cliente, modelo e MAC são preenchidos automaticamente.</p>
          <?php $comFoto = array_values(array_filter($rowsGaleria, fn($r)=>!empty($r['foto']) && is_file(ws_caminho_fisico($r['foto']))));
                echo ws_galeria_fotos('comodato', $comFoto); ?>
          <?= ws_paginacao_topo($totE, $ppE, $pgE, $pagExtra, [25, 50, 100, 0]) ?>
          <form method="post" onsubmit="return wsDelMassa(this,'Excluir os equipamentos marcados?')">
          <input type="hidden" name="acao" value="excluir_massa_equipamento">
          <div style="overflow-x:auto"><table class="ws-table ws-equip-tab"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"></th><th>Modelo</th><th>Tipo</th><th>Serial</th><th>MAC</th><th>Status</th><th>Ativo</th><th></th></tr></thead><tbody>
          <?php foreach ($rowsPag as $r): ?>
            <tr><td data-lb=""><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td data-lb="Modelo"><span style="display:flex;align-items:center;gap:8px"><span style="flex:0 0 40px;width:40px;height:40px;display:inline-flex;align-items:center;justify-content:center"><?php if (!empty($r['foto']) && is_file(ws_caminho_fisico($r['foto']))): ?><a href="<?= h(ws_img($r['foto'])) ?>" target="_blank" title="Ver foto"><img src="<?= h(ws_img($r['foto'])) ?>" alt="foto" style="width:40px;height:40px;object-fit:contain;background:#fff;border-radius:6px;border:1px solid var(--border)"></a><?php endif; ?></span><span><?= h($r['modelo']) ?></span></span></td><td data-lb="Tipo"><?= h($r['tipo'] ?: '—') ?></td><td data-lb="Serial"><?= h($r['serial'] ?: '—') ?></td><td data-lb="MAC"><?= h($r['mac'] ?: '—') ?></td><td data-lb="Status"><?= h($r['status']) ?></td><td data-lb="Ativo"><?= $r['ativo']?'sim':'não' ?></td>
            <td data-lb=""><div class="ws-acoes"><a href="erp.php?p=cadastros&t=equipamentos&equipamento=<?= $r['id'] ?>">editar</a>
              <a href="erp.php?del_equipamento=<?= $r['id'] ?>" onclick="return confirm('Excluir equipamento?')" style="color:var(--err)">excluir</a></div></td></tr>
          <?php endforeach; if (!$rows): ?><tr><td colspan="8" class="ws-muted">Nenhum equipamento cadastrado ainda.</td></tr><?php endif; ?>
          </tbody></table></div>
          <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px"><?= ws_icon('lixeira') ?> Excluir selecionados</button></div><?php endif; ?>
          </form>
          <?= ws_paginacao_html($totE, $ppE, $pgE, $pagExtra + ['pp' => $ppE]) ?>
        </div>
        <form method="post" class="ws-form" enctype="multipart/form-data">
          <h3><?= $eid?'Editar equipamento':'Novo equipamento' ?></h3>
          <input type="hidden" name="acao" value="salvar_equipamento"><input type="hidden" name="id" value="<?= $eid ?>">
          <label>Tipo <select name="tipo">
            <?php foreach (['','ONU (Bridge)','ONT (Router)','Roteador','Outro'] as $tp) echo "<option ".(((string)($e['tipo']??''))===$tp?'selected':'').">".($tp?:'—')."</option>"; ?>
          </select></label>
          <label>Modelo <input name="modelo" required value="<?= h($e['modelo']??'') ?>" placeholder="ex.: Huawei EG8145"></label>
          <label>Serial <input name="serial" value="<?= h($e['serial']??'') ?>" placeholder="usado no autopreenchimento"></label>
          <label>MAC <input name="mac" value="<?= h($e['mac']??'') ?>" placeholder="AA:BB:CC:DD:EE:FF"></label>
          <label>Status <select name="status">
            <?php foreach (['estoque'=>'Em estoque','comodato'=>'Em comodato (com cliente)','manutencao'=>'Em manutenção','baixado'=>'Baixado'] as $sv=>$sl) echo "<option value='$sv' ".(((string)($e['status']??'estoque'))===$sv?'selected':'').">$sl</option>"; ?>
          </select></label>
          <label class="c2">Observação <input name="obs" value="<?= h($e['obs']??'') ?>"></label>
          <label class="c2">Foto do equipamento <input type="file" name="foto" accept="image/*"></label>
          <?php if (!empty($e['foto']) && is_file(ws_caminho_fisico($e['foto']))): ?>
            <?php /* ws_img() e não o caminho cru: uploads/ pode estar fora da pasta do addon
                     (o AppArmor deste servidor proíbe escrita em /opt/mk-auth), e aí o navegador
                     pediria um endereço que não existe — imagem gravada, quadrado quebrado. */ ?>
            <div class="c2"><img src="<?= h(ws_img($e['foto'] . '?v=' . @filemtime(ws_caminho_fisico($e['foto'])))) ?>" alt="foto do equipamento" style="max-width:160px;border:1px solid var(--border);border-radius:8px"></div>
          <?php endif; ?>
          <label class="ws-chk"><input type="checkbox" name="ativo" <?= ($e['ativo']??1)?'checked':'' ?>> Ativo</label>
          <button class="ws-btn primary">Salvar equipamento</button>
        </form>
      </div>
    <?php elseif ($t === 'ramais'): $eid=(int)($_GET['ramal']??0); $e=null;
        if($eid){$st=$db->prepare("SELECT * FROM ws_ramal WHERE id=?");$st->execute([$eid]);$e=$st->fetch();}
        $cidades = $db->query("SELECT id,nome,uf FROM ws_cidade WHERE ativo=1 ORDER BY nome")->fetchAll();
        $rows = $db->query("SELECT r.*,c.nome cidade_nome FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id ORDER BY c.nome,r.nome")->fetchAll(); ?>
      <div class="ws-two">
        <div>
          <h3>Ramais cadastrados</h3>
          <p class="ws-muted" style="font-size:13px">Cada cidade pode ter vários ramais — o cadastro fica unificado no mesmo sistema, mas separado por ramal.</p>
          <form method="post" onsubmit="return wsDelMassa(this,'Excluir os ramais marcados?')">
          <input type="hidden" name="acao" value="excluir_massa_ramal">
          <table class="ws-table"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"></th><th>Cidade</th><th>Ramal</th><th>Código</th><th>Ativo</th><th></th></tr></thead><tbody>
          <?php foreach ($rows as $r): ?>
            <tr><td><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td><?= h($r['cidade_nome']) ?></td><td><?= h($r['nome']) ?></td><td><?= h($r['codigo']) ?></td><td><?= $r['ativo']?'sim':'não' ?></td>
            <td><div class="ws-acoes"><a href="erp.php?p=cadastros&t=ramais&ramal=<?= $r['id'] ?>">editar</a>
              <a href="erp.php?del_ramal=<?= $r['id'] ?>" onclick="return confirm('Excluir ramal?')" style="color:var(--err)">excluir</a></div></td></tr>
          <?php endforeach; if (!$rows): ?><tr><td colspan="6" class="ws-muted">Nenhum ramal cadastrado.</td></tr><?php endif; ?>
          </tbody></table>
          <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px"><?= ws_icon('lixeira') ?> Excluir selecionados</button></div><?php endif; ?>
          </form>
        </div>
        <form method="post" class="ws-form">
          <h3><?= $eid?'Editar ramal':'Novo ramal' ?></h3>
          <input type="hidden" name="acao" value="salvar_ramal"><input type="hidden" name="id" value="<?= $eid ?>">
          <label>Cidade <select name="cidade_id" required><option value="">—</option>
            <?php foreach ($cidades as $c) echo "<option value='{$c['id']}' ".((int)($e['cidade_id']??0)===(int)$c['id']?'selected':'').">".h($c['nome']).($c['uf']?' — '.h($c['uf']):'')."</option>"; ?>
          </select> <?php if (!$cidades): ?><span class="ws-muted" style="font-size:11px">cadastre uma cidade primeiro</span><?php endif; ?></label>
          <label>Nome do ramal <input name="nome" required value="<?= h($e['nome']??'') ?>" placeholder="ex.: Matriz, Filial Centro"></label>
          <label>Código <input name="codigo" value="<?= h($e['codigo']??'') ?>" placeholder="opcional"></label>
          <label class="ws-chk"><input type="checkbox" name="ativo" <?= ($e['ativo']??1)?'checked':'' ?>> Ativo</label>
          <?php $oltRo = ws_pode_editar_api() ? '' : ' readonly title="Conexão da OLT é de nível 3 e root — aqui você só confere"'; ?>
          <div class="ws-secao">OLT deste ramal (opcional)<?= $oltRo ? ' 🔒' : '' ?></div>
          <p class="ws-muted" style="font-size:12px;margin-top:-6px">Preencha só se este ramal tiver sua própria OLT — o painel de OLT só busca dado ao vivo de ramais com isso configurado; os demais não tentam conectar (evita erro/travamento por ramal sem OLT).</p>
          <label>Host/IP da OLT <input name="olt_host" value="<?= h($e['olt_host']??'') ?>" placeholder="ex.: 10.0.0.5"<?= $oltRo ?>></label>
          <label>Porta <input name="olt_porta" value="<?= h($e['olt_porta']??'') ?>" placeholder="23 (telnet)"<?= $oltRo ?>></label>
          <label>Usuário <input name="olt_usuario" autocomplete="off" value="<?= h($e['olt_usuario']??'') ?>"<?= $oltRo ?>></label>
          <!-- autocomplete="new-password": sem isto o gerenciador de senhas do navegador preenche
               este campo com uma senha de outro site, e o ramal é salvo com a senha errada. -->
          <label>Senha <input type="password" name="olt_senha" autocomplete="new-password" value="<?= h($e['olt_senha']??'') ?>"<?= $oltRo ?>></label>
          <button class="ws-btn primary">Salvar ramal</button>
        </form>
      </div>
    <?php elseif ($t === 'bairros'): $eid=(int)($_GET['bairro']??0); $e=null;
        if($eid){$st=$db->prepare("SELECT * FROM ws_bairro WHERE id=?");$st->execute([$eid]);$e=$st->fetch();}
        $cidades = $db->query("SELECT id,nome,uf FROM ws_cidade WHERE ativo=1 ORDER BY nome")->fetchAll();
        $rows = $db->query("SELECT b.*,c.nome cidade_nome, (SELECT COUNT(*) FROM ws_cliente cl WHERE cl.status<>'cancelado' AND TRIM(cl.bairro) COLLATE utf8mb4_unicode_ci = b.nome COLLATE utf8mb4_unicode_ci AND (c.nome IS NULL OR TRIM(cl.cidade) COLLATE utf8mb4_unicode_ci = c.nome COLLATE utf8mb4_unicode_ci)) clientes FROM ws_bairro b LEFT JOIN ws_cidade c ON c.id=b.cidade_id ORDER BY b.nome")->fetchAll(); if (is_file(__DIR__ . '/zonas_unificar_lib.php')) { require_once __DIR__ . '/zonas_unificar_lib.php'; $cntB = ws_bairro_contagem($db, $rows); foreach ($rows as $ri => $rb) $rows[$ri]['clientes'] = (int)($cntB[(int)$rb['id']] ?? 0); } else { $cntB = ['sem' => 0, 'total' => 0]; }   // (16/10/2026) clientes por bairro pelo cadastro do cliente
        $ppB = isset($_GET['pp']) ? (int)$_GET['pp'] : 25; if (!in_array($ppB, [25, 50, 100, 0], true)) $ppB = 25; $totB2 = count($rows); $pgB = max(1, (int)($_GET['pg'] ?? 1)); if ($ppB > 0 && ($pgB - 1) * $ppB >= $totB2) $pgB = max(1, (int)ceil($totB2 / $ppB)); $rowsPagB = $ppB > 0 ? array_slice($rows, ($pgB - 1) * $ppB, $ppB) : $rows; $pagExtraB = ['p' => 'cadastros', 't' => 'bairros']; ?>
      <div class="ws-two">
        <div>
          <h3>Bairros cadastrados</h3>
          <p class="ws-muted" style="font-size:13px">Usado como sugestão editável (você pode digitar um novo direto no formulário do cliente/conexão também).</p>
          <?= ws_paginacao_topo($totB2, $ppB, $pgB, $pagExtraB, [25, 50, 100, 0]) ?>
          <form method="post" onsubmit="return wsDelMassa(this,'Excluir os bairros marcados?')">
          <input type="hidden" name="acao" value="excluir_massa_bairro">
          <table class="ws-table"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"></th><th>Nome</th><th>Cidade</th><th style="text-align:right" title="Clientes ativos neste bairro">Clientes</th><th>Ativo</th><th></th></tr></thead><tbody>
          <?php foreach ($rowsPagB as $r): ?>
            <tr><td><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td><?= h($r['nome']) ?></td><td><?= h($r['cidade_nome'] ?: '—') ?></td><td style="text-align:right"><b><?= (int)$r['clientes'] ?></b></td><td><?= $r['ativo']?'sim':'não' ?></td>
            <td><div class="ws-acoes"><a href="erp.php?p=cadastros&t=bairros&bairro=<?= $r['id'] ?>">editar</a>
              <a href="erp.php?del_bairro=<?= $r['id'] ?>" onclick="return confirm('Excluir bairro?')" style="color:var(--err)">excluir</a></div></td></tr>
          <?php endforeach; if (!$rows): ?><tr><td colspan="6" class="ws-muted">Nenhum bairro cadastrado ainda — mas o campo continua aceitando digitação livre em qualquer formulário.</td></tr><?php endif; ?>
          <tr style="font-weight:800"><td></td><td>Total de clientes ativos</td><td></td><td style="text-align:right"><?= (int)($cntB['total'] ?? 0) + (int)($cntB['sem'] ?? 0) ?></td><td colspan="2" class="ws-muted" style="font-weight:400;font-size:12px"><?= !empty($cntB['sem']) ? (int)$cntB['sem'] . ' sem bairro' : '' ?></td></tr>
          </tbody></table>
          <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px"><?= ws_icon('lixeira') ?> Excluir selecionados</button></div><?php endif; ?>
          </form>
          <?= ws_paginacao_html($totB2, $ppB, $pgB, $pagExtraB + ['pp' => $ppB]) ?>
        </div>
        <form method="post" class="ws-form">
          <h3><?= $eid?'Editar bairro':'Novo bairro' ?></h3>
          <input type="hidden" name="acao" value="salvar_bairro"><input type="hidden" name="id" value="<?= $eid ?>">
          <label>Nome <input name="nome" required value="<?= h($e['nome']??'') ?>"></label>
          <label>Cidade <select name="cidade_id"><option value="">— sem cidade específica —</option>
            <?php foreach ($cidades as $c): ?><option value="<?= $c['id'] ?>" <?= (($e['cidade_id']??null)==$c['id'])?'selected':'' ?>><?= h($c['nome']) ?> <?= $c['uf']?'('.h($c['uf']).')':'' ?></option><?php endforeach; ?>
          </select></label>
          <label class="ws-chk"><input type="checkbox" name="ativo" <?= ($e['ativo']??1)?'checked':'' ?>> Ativo</label>
          <button class="ws-btn primary">Salvar bairro</button>
        </form>
      </div>
    <?php else: $eid=(int)($_GET['cidade']??0); $e=null;
        if($eid){$st=$db->prepare("SELECT * FROM ws_cidade WHERE id=?");$st->execute([$eid]);$e=$st->fetch();}
        $rows = $db->query("SELECT * FROM ws_cidade ORDER BY nome")->fetchAll(); ?>
      <div class="ws-two">
        <div>
          <h3>Cidades atendidas</h3>
          <form method="post" onsubmit="return wsDelMassa(this,'Excluir as cidades marcadas? Os ramais delas também serão excluídos.')">
          <input type="hidden" name="acao" value="excluir_massa_cidade">
          <table class="ws-table"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todas"></th><th>Nome</th><th>UF</th><th>Lat/Long</th><th>Ativo</th><th></th></tr></thead><tbody>
          <?php foreach ($rows as $r): ?>
            <tr><td><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td><?= h($r['nome']) ?></td><td><?= h($r['uf']) ?></td>
            <td class="ws-muted" style="font-size:12px"><?= ($r['latitude']!==null) ? h($r['latitude']).', '.h($r['longitude']) : '—' ?></td>
            <td><?= $r['ativo']?'sim':'não' ?></td>
            <td><div class="ws-acoes"><a href="erp.php?p=cadastros&t=cidades&cidade=<?= $r['id'] ?>">editar</a>
              <a href="erp.php?del_cidade=<?= $r['id'] ?>" onclick="return confirm('Excluir cidade? Os ramais dela também serão excluídos.')" style="color:var(--err)">excluir</a></div></td></tr>
          <?php endforeach; if (!$rows): ?><tr><td colspan="6" class="ws-muted">Nenhuma cidade cadastrada.</td></tr><?php endif; ?>
          </tbody></table>
          <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px"><?= ws_icon('lixeira') ?> Excluir selecionadas</button></div><?php endif; ?>
          </form>
        </div>
        <form method="post" class="ws-form" id="frmCidade">
          <h3><?= $eid?'Editar cidade':'Nova cidade' ?></h3>
          <input type="hidden" name="acao" value="salvar_cidade"><input type="hidden" name="id" value="<?= $eid ?>">
          <label>Nome <input name="nome" id="cid_nome" required value="<?= h($e['nome']??'') ?>"></label>
          <?php /* UF por SELEÇÃO, não por digitação: a lista das 27 é fixa, e campo livre de duas letras
                   aceita "pe", "Pe" e "PW" sem reclamar. Lida de ws_uf — se a tabela ainda não
                   existir, o campo volta a ser texto, para a tela nunca ficar sem o campo. */
            $ws_ufs = [];
            try { $ws_ufs = $db->query("SELECT sigla, nome FROM ws_uf ORDER BY sigla")->fetchAll(); } catch (Throwable $e2) {}
          ?>
          <?php if ($ws_ufs): ?>
          <label>UF <select name="uf" id="cid_uf">
            <option value="">—</option>
            <?php foreach ($ws_ufs as $u): ?>
              <option value="<?= h($u['sigla']) ?>" <?= (strtoupper((string)($e['uf'] ?? '')) === $u['sigla'] ? 'selected' : '') ?>><?= h($u['sigla']) ?> — <?= h($u['nome']) ?></option>
            <?php endforeach; ?>
          </select></label>
          <?php else: ?>
          <label>UF <input name="uf" id="cid_uf" maxlength="2" list="ws_ufs" value="<?= h($e['uf']??'') ?>"></label>
          <?php endif; ?>
          <label>CEP geral <input name="cep" id="cid_cep" value="<?= h($e['cep']??'') ?>" placeholder="auto-preenche o CEP do cliente desta cidade"></label>
          <datalist id="ws_ufs"><?php foreach (['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'] as $u) echo "<option value=\"$u\">"; ?></datalist>
          <label>Latitude <input name="latitude" id="cid_lat" value="<?= h($e['latitude']??'') ?>" placeholder="preenche sozinho ao clicar em Localizar"></label>
          <label>Longitude <input name="longitude" id="cid_lon" value="<?= h($e['longitude']??'') ?>" placeholder="preenche sozinho ao clicar em Localizar"></label>
          <button type="button" class="ws-btn" onclick="wsLocalizarCidade()">📍 Localizar automaticamente (pelo nome + UF)</button>
          <span id="cid_loc_status" class="ws-muted" style="font-size:12px"></span>
          <label class="ws-chk"><input type="checkbox" name="ativo" <?= ($e['ativo']??1)?'checked':'' ?>> Ativa</label>
          <button class="ws-btn primary">Salvar cidade</button>
        </form>
      </div>
      <script>
        function wsLocalizarCidade(){
          var nome = document.getElementById('cid_nome').value.trim();
          var uf = document.getElementById('cid_uf').value.trim();
          if (!nome) { alert('Digite o nome da cidade primeiro.'); return; }
          var st = document.getElementById('cid_loc_status'); st.textContent = 'Buscando…';
          wsGeocodificar(nome + (uf ? ', ' + uf : '') + ', Brasil')   // OpenStreet ou Google (Recursos do sistema → Mapas)
            .then(function(p){
              if (p) {
                document.getElementById('cid_lat').value = p.lat.toFixed(7);
                document.getElementById('cid_lon').value = p.lon.toFixed(7);
                st.textContent = '✅ Encontrado — confira e ajuste se precisar (o campo continua editável).';
              } else { st.textContent = '❌ Não encontrei — digite manualmente.'; }
            })
            .catch(function(){ st.textContent = '❌ Falha na busca (sem internet no navegador?) — digite manualmente.'; });
        }
      </script>
    <?php endif; ?>
    <?php
}

/* --------- Planos --------- */
function ws_view_planos(PDO $db): void {
    /* Cadeado de leitura para níveis 1 e 2: a lista e os valores continuam à vista (é com eles
       que o atendimento confere o plano do cliente), mas o formulário fica travado. */
    $travaPlano = ws_pode_editar_preco() ? '' : ws_bloqueio_leitura_html('Plano é preço do provedor: aqui você confere, quem altera é nível 3 ou root.');
    $rows = $db->query("SELECT * FROM ws_plano ORDER BY nome")->fetchAll();
    $id = (int)($_GET['id'] ?? 0); $e = null;
    if ($id) { $st=$db->prepare("SELECT * FROM ws_plano WHERE id=?"); $st->execute([$id]); $e=$st->fetch(); }
    ?>
    <h2>📶 Planos</h2>
    <?= $travaPlano ?>
    <div class="ws-two">
      <div>
      <form method="post" onsubmit="return wsDelMassa(this,'Excluir os planos marcados? (planos ligados a contratos não podem ser excluídos)')">
      <input type="hidden" name="acao" value="excluir_massa_plano">
      <table class="ws-table"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"></th><th>Nome</th><th>Down</th><th>Up</th><th>Valor</th><th>Ativo</th><th></th></tr></thead><tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td><?= h($r['nome']) ?></td><td><?= round($r['down_kbps']/1000) ?>M</td><td><?= round($r['up_kbps']/1000) ?>M</td>
        <td>R$ <?= number_format($r['valor'],2,',','.') ?></td><td><?= $r['ativo']?'sim':'não' ?></td>
        <td><a href="erp.php?p=planos&id=<?= $r['id'] ?>">editar</a></td></tr>
      <?php endforeach; if(!$rows) echo '<tr><td colspan="7" class="ws-muted">Sem planos.</td></tr>'; ?>
      </tbody></table>
      <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px"><?= ws_icon('lixeira') ?> Excluir selecionados</button></div><?php endif; ?>
      </form>
      </div>
      <form method="post" class="ws-form">
        <h3><?= $id?'Editar plano':'Novo plano' ?></h3>
        <input type="hidden" name="acao" value="salvar_plano"><input type="hidden" name="id" value="<?= $id ?>">
        <label>Nome <input name="nome" required value="<?= h($e['nome']??'') ?>"></label>
        <label>Download (kbps) <input name="down_kbps" type="number" value="<?= h($e['down_kbps']??100000) ?>" placeholder="100 Mega = 100000"></label>
        <label>Upload (kbps) <input name="up_kbps" type="number" value="<?= h($e['up_kbps']??50000) ?>" placeholder="50 Mega = 50000"></label>
        <label>Valor (R$) <input name="valor" value="<?= h($e['valor']??'') ?>"></label>
        <label>Descrição <input name="descricao" value="<?= h($e['descricao']??'') ?>"></label>
        <label class="ws-chk"><input type="checkbox" name="ativo" <?= (!$id || ($e['ativo']??1))?'checked':'' ?>> Ativo</label>
        <button class="ws-btn primary">Salvar plano</button>
        <?php if ($id): ?><a class="ws-btn" href="erp.php?p=planos">Novo</a><?php endif; ?>
      </form>
    </div>
    <?php
}

/* --------- Bloco Integração (tokens + ponte OLT) --------- */
function ws_bloco_integracao(): void {
    if (function_exists('ws_edicao_tem') && !(ws_edicao_tem('erp') && ws_edicao_tem('olt'))) return;   // tokens/ponte OLT↔ERP só existem no Completo (módulo isolado não tem o outro lado)
    $cfg = is_file(WS_DB_CFG) ? (json_decode(@file_get_contents(WS_DB_CFG), true) ?: []) : [];
    $olt = $cfg['olt_token'] ?? ''; $cron = $cfg['cron_token'] ?? '';
    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'SEU_HOST') . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    ?>
    <h3 style="margin-top:24px">Integração — tokens & ponte da OLT</h3>
    <div class="ws-card">
      <form method="post" class="ws-form" style="max-width:560px">
        <input type="hidden" name="acao" value="salvar_tokens">
        <label>olt_token <span class="ws-muted" style="font-size:11px">(usado pelo addon da OLT p/ falar com este ERP)</span>
          <input name="olt_token" value="<?= h($olt) ?>" placeholder="clique em Gerar"></label>
        <label>cron_token <span class="ws-muted" style="font-size:11px">(libera radius_sync / cobranca_run / faturar_run via URL)</span>
          <input name="cron_token" value="<?= h($cron) ?>"></label>
        <button class="ws-btn primary">Salvar tokens</button>
        <p class="ws-muted" style="font-size:12px;margin:2px 0 0">Deixe o olt_token vazio e salve — o sistema gera um forte automaticamente.</p>
      </form>
      <div style="margin-top:14px;background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:12px">
        <b>Ligar a OLT ao ERP</b> — no addon da OLT, crie o arquivo <code>cache_trafego/ws_bridge.json</code>:
        <pre style="white-space:pre-wrap;word-break:break-all;font-size:12px;margin:8px 0 0">{
  "ativo": true,
  "url": "<?= h($base) ?>/olt_bridge.php",
  "token": "<?= h($olt ?: 'SEU_olt_token') ?>"
}</pre>
        <p class="ws-muted" style="font-size:12px;margin:8px 0 0">Feito isso, autorizar uma ONU no painel da OLT já grava o <b>SN no contrato</b> do cliente (casando pelo nome).</p>
      </div>
    </div>
    <?php
}

/* --------- Bloco Marca / logo do sistema --------- */
function ws_bloco_marca(): void {
    $b = ws_branding();
    ?>
    <h3 style="margin-top:24px">Marca do sistema (logo e nome)</h3>
    <div class="ws-card">
      <form method="post" enctype="multipart/form-data" class="ws-form" style="max-width:520px">
        <input type="hidden" name="acao" value="salvar_marca">
        <label>Nome do sistema 🔒 <input name="nome_sistema" value="<?= h($b['nome']) ?>" placeholder="WellSystem"></label>
        <label>Senha root do banco <span class="ws-muted" style="font-size:11px">(só para trocar o nome — o selo e o nome são a marca de registro do sistema)</span>
          <input type="password" name="senha_root_banco" autocomplete="new-password" placeholder="deixe em branco se não for trocar o nome"></label>
        <label>Logo (PNG/JPG/WEBP/SVG, até 8MB) <input type="file" name="logo" accept="image/*"></label>
        <label>Link da logo do topo <span class="ws-muted" style="font-size:11px">(site da empresa — abre ao clicar na logo; em branco = logo sem link)</span>
          <input type="text" name="logo_url" value="<?= h($b['logo_url'] ?? '') ?>" placeholder="https://seuprovedor.com.br" inputmode="url"></label>
        <p class="ws-muted" style="font-size:12px;margin:-4px 0 0">
          🔒 O selo do <b>rodapé</b> leva ao site do dono do código (<?= h(preg_replace('#^https?://#', '', ws_dono_url())) ?>) — é marca de registro do sistema e não se altera aqui.
        </p>
        <?php $fmtAtual = $b['logo_formato'] ?? 'auto'; $fmtVisto = ws_brand_logo_formato(); ?>
        <label>Formato da logo
          <select name="logo_formato">
            <option value="auto"     <?= $fmtAtual === 'auto'     ? 'selected' : '' ?>>Automático — o sistema mede a imagem</option>
            <option value="circulo"  <?= $fmtAtual === 'circulo'  ? 'selected' : '' ?>>Círculo — mostra só o círculo (logo em selo)</option>
            <option value="original" <?= $fmtAtual === 'original' ? 'selected' : '' ?>>Original — mostra a imagem inteira (logo em faixa)</option>
          </select>
        </label>
        <p class="ws-muted" style="font-size:12px;margin:-4px 0 0">
          Logo em <b>faixa</b> (o nome na horizontal) aparece inteira. Logo em <b>selo redondo</b>
          tem os cantos do quadrado recortados, pra aparecer só o círculo.
          Hoje esta logo está sendo exibida como: <b><?= $fmtVisto === 'redonda' ? 'círculo' : 'faixa' ?></b>.
        </p>

        <?php if (!empty($b['logo']) && is_file(ws_caminho_fisico($b['logo']))): ?>
          <div style="display:flex;align-items:center;gap:14px;background:var(--surface-2);padding:10px;border-radius:8px;border:1px solid var(--border)">
            <?php /* Idem: a logo pode estar em assets/ (servida direto) ou em uploads/sistema/
                     (servida pelo img.php). ws_img() escolhe o caminho certo para cada caso. */ ?>
            <img src="<?= h(ws_img($b['logo'] . '?v=' . @filemtime(ws_caminho_fisico($b['logo'])))) ?>" alt="logo" style="max-height:44px;max-width:180px">
            <a class="ws-btn danger" href="erp.php?remover_logo=1" onclick="return confirm('Remover a logo?')">Remover logo</a>
          </div>
        <?php else: ?>
          <p class="ws-muted" style="font-size:12px">Sem logo — o sistema mostra o nome estilizado. Envie uma logo pra substituir.</p>
        <?php endif; ?>
        <button class="ws-btn primary">Salvar marca</button>
      </form>
    </div>

    <h3 style="margin-top:24px">🖼️ Fotos de fundo da tela de Login</h3>
    <div class="ws-card">
      <?php $loginBgs = ws_login_bgs(); ?>
      <p class="ws-muted" style="font-size:13px;margin:0 0 10px">Envie <b>várias fotos</b> (upload próprio, diferente das fotos da Central). A tela de <b>login</b> mostra uma aleatória a cada acesso. JPG/PNG/WEBP, até 8MB cada.</p>
      <form method="post" enctype="multipart/form-data" class="ws-form" style="max-width:520px">
        <input type="hidden" name="acao" value="salvar_login_bg">
        <label>Adicionar fotos <input type="file" name="login_bg[]" accept="image/*" multiple></label>
        <button class="ws-btn primary">Enviar fotos</button>
      </form>
      <?php if ($loginBgs): ?>
        <form method="post" onsubmit="return wsLbgDel(this)">
          <input type="hidden" name="acao" value="excluir_login_bg_sel">
          <label style="font-size:13px;display:flex;align-items:center;gap:6px;margin:12px 0 6px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todas"> Marcar todas</label>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            <?php foreach ($loginBgs as $bg): ?>
              <label style="position:relative;display:block;cursor:pointer" title="Marcar para excluir">
                <input type="checkbox" class="ws-chk-item" name="bgs[]" value="<?= h(basename($bg)) ?>" style="position:absolute;top:6px;left:6px;z-index:2">
                <img src="<?= h(ws_img($bg . '?v=' . @filemtime(ws_caminho_fisico($bg)))) ?>" alt="" style="width:120px;height:70px;object-fit:cover;border-radius:8px;border:1px solid var(--border);display:block">
              </label>
            <?php endforeach; ?>
          </div>
          <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
            <button class="ws-btn danger">🗑 Excluir selecionadas</button>
            <a class="ws-btn" style="color:var(--err)" href="erp.php?limpar_login_bg=1" onclick="return confirm('Apagar TODAS as fotos de fundo do login?')">Limpar todas</a>
          </div>
        </form>
        <script>function wsLbgDel(f){var n=f.querySelectorAll('.ws-chk-item:checked').length;if(!n){alert('Marque ao menos uma foto.');return false;}return confirm('Excluir '+n+' foto(s) do login?');}</script>
      <?php else: ?>
        <p class="ws-muted" style="font-size:12px;margin-top:8px">Sem fotos — o login usa o fundo padrão. Envie fotos para personalizar.</p>
      <?php endif; ?>
    </div>

    <h3 style="margin-top:24px">🧑‍💼 Fotos dos operadores (atendentes)</h3>
    <div class="ws-card">
      <?php
      $ops = [];
      try { $ops = ws_db()->query("SELECT id,nome FROM ws_usuario WHERE ativo=1 ORDER BY nome")->fetchAll(); } catch (Throwable $e) {}
      $opsFotos = []; foreach ($ops as $op) { if (ws_operador_foto((int)$op['id']) !== '') $opsFotos[] = (int)$op['id']; }
      ?>
      <p class="ws-muted" style="font-size:13px;margin:0 0 12px"><b>Marque</b> e <b>exclua</b> a foto de um operador (ou todas). Ao excluir, ele volta ao <b>padrão (inicial do nome)</b>. As fotos ficam separadas em <code>uploads/operadores/</code>.</p>
      <?php if ($opsFotos): ?>
      <form method="post" onsubmit="return wsOpFotoDel(this)">
        <input type="hidden" name="acao" value="excluir_foto_operador_sel">
        <label style="font-size:13px;display:flex;align-items:center;gap:6px;margin-bottom:8px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todas"> Marcar todas</label>
        <div style="display:flex;flex-wrap:wrap;gap:14px">
          <?php foreach ($ops as $op): $of = ws_operador_foto((int)$op['id']); ?>
            <div style="text-align:center;width:92px">
              <?php if ($of !== ''): ?>
                <label style="position:relative;display:block;cursor:pointer" title="Marcar para excluir a foto de <?= h($op['nome']) ?>">
                  <input type="checkbox" class="ws-chk-item" name="ops[]" value="<?= (int)$op['id'] ?>" style="position:absolute;top:4px;left:4px;z-index:2">
                  <img src="<?= h($of) ?>" alt="" style="width:76px;height:76px;object-fit:cover;border-radius:50%;border:1px solid var(--border);display:block;margin:0 auto 5px">
                </label>
              <?php else: ?>
                <span style="width:76px;height:76px;border-radius:50%;background:rgba(122,31,43,.12);color:var(--brand);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:26px;margin:0 auto 5px" title="Sem foto (padrão)"><?= h(mb_strtoupper(mb_substr((string)$op['nome'],0,1),'UTF-8')) ?></span>
              <?php endif; ?>
              <span style="font-size:12px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($op['nome']) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
        <div style="margin-top:12px"><button class="ws-btn danger">🗑 Excluir foto(s) selecionada(s)</button></div>
      </form>
      <script>function wsOpFotoDel(f){var n=f.querySelectorAll('.ws-chk-item:checked').length;if(!n){alert('Marque ao menos uma foto.');return false;}return confirm('Excluir a foto de '+n+' operador(es)? Volta para a inicial do nome.');}</script>
      <?php else: ?>
        <p class="ws-muted" style="font-size:12px">Nenhum operador tem foto no momento — todos aparecem com a inicial do nome (padrão).</p>
      <?php endif; ?>
    </div>
    <?php
}

/* --------- Bloco 2FA (verificação em 2 etapas) --------- */
function ws_bloco_2fa(PDO $db): void {
    $st = $db->prepare("SELECT twofa_enabled, twofa_secret FROM ws_usuario WHERE id=?");
    $st->execute([(int)ws_user()['id']]); $u = $st->fetch() ?: [];
    $ativo = !empty($u['twofa_enabled']);
    $setup = $_SESSION['ws_2fa_setup'] ?? '';
    $codes = $_SESSION['ws_2fa_codes'] ?? null; unset($_SESSION['ws_2fa_codes']);
    ?>
    <h3 style="margin-top:24px">Verificação em 2 etapas (2FA)</h3>
    <?php $obrig = function_exists('ws_twofa_obrigatorio_para_mim') && ws_twofa_obrigatorio_para_mim(); if ($obrig && !$ativo): ?>
      <div class="ws-alert" style="background:rgba(220,38,38,.10);border:1px solid var(--err)">🔒 <b>Para continuar, ative a verificação em 2 etapas.</b> Ela é obrigatória para o seu nível de acesso — o restante do sistema libera assim que o código for confirmado.</div>
    <?php endif; if (ws_pode_configurar()): $segOn = !empty(ws_seg_cfg()['twofa_obrigatorio']); ?>
      <form method="post" class="ws-form" style="max-width:520px;margin:0 0 10px"><input type="hidden" name="acao" value="twofa_obrigatorio">
        <label class="ws-chk" style="font-weight:400"><input type="checkbox" name="twofa_obrigatorio" value="1" <?= $segOn ? 'checked' : '' ?> onchange="if(this.checked && !confirm('Exigir 2FA de todos com nível 3 e root? Quem ainda não tem será levado para ativar no próximo acesso.')){this.checked=false;return;} this.form.submit()"> <b>Exigir 2FA para nível 3 e root</b> <span class="ws-muted">(recomendado — protege quem pode mexer em tudo)</span></label>
      </form>
    <?php endif; ?>
    <?php if ($codes): ?>
      <div class="ws-alert ok"><b>2FA ativado!</b> Guarde estes <b>códigos de recuperação</b> (aparecem só agora — cada um serve uma vez):</div>
      <div class="ws-card"><code style="font-size:15px;letter-spacing:1px;line-height:2"><?= implode('&nbsp;&nbsp; ', array_map('h', $codes)) ?></code></div>
    <?php elseif ($ativo): ?>
      <div class="ws-card">
        <p>🔒 2FA <b>ativo</b> na sua conta.</p>
        <form method="post" class="ws-form" style="max-width:320px">
          <input type="hidden" name="acao" value="twofa_desativar">
          <label>Para desativar, confirme sua senha <input type="password" name="senha" required></label>
          <button class="ws-btn danger">Desativar 2FA</button>
        </form>
      </div>
    <?php elseif ($setup): $uri = ws_totp_uri($setup, ws_user()['nome'] ?: 'operador'); ?>
      <div class="ws-card">
        <p>1) No app (Google Authenticator, Authy…), adicione uma conta e digite esta <b>chave</b>:</p>
        <p><code style="font-size:16px;letter-spacing:2px"><?= h($setup) ?></code></p>
        <?php $qrPng = ''; if (is_file(__DIR__ . '/api_chatbot.php')) { require_once __DIR__ . '/api_chatbot.php'; if (function_exists('ws_chatbot_qr_png')) $qrPng = ws_chatbot_qr_png($uri, 5); } ?>
        <?php if ($qrPng !== ''): ?><p>Ou aponte a câmera do app para o QR:</p><img src="data:image/png;base64,<?= base64_encode($qrPng) ?>" alt="QR do 2FA" style="width:180px;height:180px;background:#fff;padding:6px;border-radius:8px"><?php endif; ?>
        <p class="ws-muted" style="font-size:12px">Link: <code style="word-break:break-all"><?= h($uri) ?></code></p>
        <form method="post" class="ws-form" style="max-width:320px">
          <input type="hidden" name="acao" value="twofa_ativar">
          <label>2) Digite o código de 6 dígitos que o app mostrar <input name="codigo" inputmode="numeric" required placeholder="000000"></label>
          <button class="ws-btn primary">Ativar 2FA</button>
          <a class="ws-btn" href="erp.php?p=config">Cancelar</a>
        </form>
      </div>
    <?php else: ?>
      <p class="ws-muted">Adicione uma camada extra de segurança ao seu login com um app autenticador.</p>
      <a class="ws-btn primary" href="erp.php?twofa_init=1">Ativar 2FA</a>
    <?php endif;
}

/* --------- Config: minha senha + operadores --------- */
function ws_view_config(PDO $db): void {
    $admin = ws_user()['nivel'] === 'admin';
    $t = $_GET['t'] ?? 'geral';
    if ($t === 'operadores') $t = 'geral';   // unificado: Geral / Marca / Operadores / Login numa aba só
    ?>
    <div class="ws-head-row"><h2>Configurações</h2></div>
    <div class="ws-search">
      <?php foreach (['geral'=>'Geral · Marca · Operadores','cobranca'=>'Cobrança','seguranca'=>'Segurança','migracao'=>'Migração / Backup','licenca'=>'Licença'] as $k=>$v):
        if (!$admin && in_array($k,['migracao','cobranca','licenca'],true)) continue;
        if ($k==='licenca' && (ws_em_demo() || !ws_fornecedor_desbloqueado())) continue;   // DEMO e cliente sem desbloqueio do fornecedor não acessam Licença & Senhas ?>
        <a class="ws-btn <?= $t===$k?'primary':'' ?>" href="erp.php?p=config&t=<?= $k ?>"><?= h($v) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if ($t === 'cobranca' && $admin): ?>
      <form method="post" class="ws-form" style="max-width:420px">
        <h3>Bloqueio automático por atraso</h3>
        <input type="hidden" name="acao" value="salvar_dias_bloqueio">
        <label>Bloquear após quantos dias de atraso?
          <input type="number" name="dias_bloqueio" min="0" max="90" value="<?= (int)ws_dias_bloqueio() ?>">
        </label>
        <p class="ws-muted" style="font-size:12px">Regra geral: <b>5 dias</b>. O cliente é bloqueado automaticamente quando um título está vencido há esse número de dias ou mais (com 5: vencido há 5 dias já bloqueia), e desbloqueado sozinho quando não há mais boleto vencido nessa condição (sincronização Radius).</p>
        <label>"Liberar em confiança" dura quantos dias?
          <input type="number" name="dias_confianca" min="1" max="90" value="<?= (int)ws_dias_confianca() ?>">
        </label>
        <p class="ws-muted" style="font-size:12px">Usado em TODA liberação em confiança do sistema (ficha do cliente, ícone rápido da lista, ação em massa). Padrão: <b>1 dia</b>.</p>
        <button class="ws-btn primary">Salvar</button>
      </form>

    <?php elseif ($t === 'geral'): ?>
      <form method="post" class="ws-form" style="max-width:420px">
        <h3>Minha senha</h3>
        <input type="hidden" name="acao" value="trocar_senha">
        <label>Nova senha (mín. 4) <input type="password" name="nova" required minlength="4"></label>
        <button class="ws-btn primary">Trocar senha</button>
      </form>
      <?php if ($admin) ws_bloco_marca(); ?>
      <?php if ($admin && function_exists('ws_bloco_equip')) ws_bloco_equip(); ?>
      <?php if ($admin): $eid=(int)($_GET['u']??0); $e=null;
        // DEMONSTRAÇÃO: cada visitante só enxerga/edita a PRÓPRIA conta — nunca a de outros que estão
        // testando. Fora do demo, o admin gerencia todos os operadores normalmente.
        $ehDemoOps = ws_em_demo();
        $meuUid = (int)(ws_user()['id'] ?? 0);
        if ($ehDemoOps && $eid && $eid !== $meuUid) { $eid = $meuUid; }
        if($eid){$st=$db->prepare("SELECT * FROM ws_usuario WHERE id=?");$st->execute([$eid]);$e=$st->fetch();} ?>
      <div class="ws-head-row ws-tarja" style="margin:26px 0 10px"><h3>👥 Operadores e funcionários</h3></div>
      <div class="ws-two">
        <div>
          <h3>Operadores</h3>
          <?php if ($ehDemoOps): ?><p class="ws-muted" style="font-size:12.5px;margin-top:-4px">🔒 Modo demonstração: você vê e edita apenas a <b>sua conta</b> — as contas de outras pessoas testando ficam privadas.</p><?php endif; ?>
          <?php
          /* ATENDENTES ONLINE — quem está no sistema agora.
           * "Online" aqui é "deu sinal de vida nos últimos 5 minutos": cada tela aberta atualiza o
           * carimbo (ws_marcar_presenca, no config.php). Não existe logout confiável — o operador
           * fecha a aba, cai a internet, o computador hiberna —, então prometer mais que isso
           * seria mentir. É a mesma ideia do "visto por último" dos mensageiros. */
          $online = function_exists('ws_operadores_online') ? ws_operadores_online(5) : [];
          $onIds  = []; foreach ($online as $o) $onIds[(int)$o['id']] = (int)$o['segundos'];
          ?>
          <div class="ws-panel" style="margin:0 0 12px;padding:10px 12px">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <b style="font-size:13.5px">🟢 Atendentes online</b>
              <span class="ws-muted" style="font-size:12px">— ativos nos últimos 5 minutos</span>
              <span style="margin-left:auto;font-weight:700"><?= count($online) ?></span>
            </div>
            <?php if (!$online): ?>
              <p class="ws-muted" style="font-size:12.5px;margin:6px 0 0">Ninguém no sistema agora além de você — ou o registro de presença ainda não começou (ele passa a valer na próxima vez que cada um abrir uma tela).</p>
            <?php else: ?>
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
                <?php foreach ($online as $o):
                  $seg = (int)$o['segundos'];
                  $qdo = $seg < 90 ? 'agora' : ('há ' . (int)round($seg / 60) . ' min');
                  $fo  = ws_operador_foto((int)$o['id']);
                  $ini = mb_strtoupper(mb_substr(trim((string)$o['nome']), 0, 1)); ?>
                  <span title="<?= h($o['login']) ?> · <?= h($o['nivel']) ?> · visto <?= h($qdo) ?>"
                        style="display:inline-flex;align-items:center;gap:7px;padding:5px 10px 5px 5px;border:1px solid var(--border);border-radius:999px;background:var(--bg)">
                    <?php if ($fo): ?>
                      <img src="<?= h($fo) ?>" alt="" style="width:24px;height:24px;border-radius:50%;object-fit:cover;flex:0 0 auto">
                    <?php else: ?>
                      <span style="width:24px;height:24px;border-radius:50%;background:var(--acc);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex:0 0 auto"><?= h($ini) ?></span>
                    <?php endif; ?>
                    <span style="font-size:12.5px;font-weight:600"><?= h($o['nome']) ?></span>
                    <span class="ws-muted" style="font-size:11px"><?= h($qdo) ?></span>
                  </span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>

          <table class="ws-table"><thead><tr><th>Nome</th><th>Login</th><th>Papel</th><th>Acesso</th><th>Ativo</th><th>Ações</th></tr></thead><tbody>
          <?php
          $sqlOps = $ehDemoOps ? ("SELECT * FROM ws_usuario WHERE id=" . $meuUid . " ORDER BY nome") : "SELECT * FROM ws_usuario ORDER BY nome";
          foreach ($db->query($sqlOps)->fetchAll() as $u):
            $nAc = (int)($u['nivel_acesso'] ?? 2); $nAcTxt = $nAc>=99?'Root':($nAc>=3?'Nível 3':($nAc<=1?'Nível 1 (leitura)':'Nível 2'));
            // Bolinha ao lado do nome: verde = online agora; cinza = há quanto tempo foi visto.
            $segU = $onIds[(int)$u['id']] ?? null;
            $vis  = trim((string)($u['visto_em'] ?? ''));
            if ($segU !== null)      { $bol = '#16a34a'; $tit = 'online agora'; }
            elseif ($vis !== '')     { $bol = 'var(--muted)'; $tit = 'visto em ' . date('d/m H:i', strtotime($vis)); }
            else                     { $bol = 'var(--border)'; $tit = 'nunca acessou desde que a presença passou a ser registrada'; }
            ?>
            <tr><td><span title="<?= h($tit) ?>" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:<?= $bol ?>;margin-right:7px;vertical-align:middle"></span><?= h($u['nome']) ?></td><td><?= h($u['login']) ?></td><td><?= h($u['nivel']) ?></td>
            <td><span class="ws-tag <?= $nAc>=99?'confianca':($nAc>=3?'ativo':($nAc<=1?'inativo':'suspenso')) ?>"><?= $nAcTxt ?></span></td>
            <td><?= $u['ativo']?'sim':'não' ?></td>
            <td><div class="ws-acoes"><a href="erp.php?p=config&t=geral&u=<?= $u['id'] ?>">editar</a>
              <?php if ((int)$u['id']!==(int)ws_user()['id']): ?><a href="erp.php?del_user=<?= $u['id'] ?>" onclick="return confirm('Excluir operador?')" style="color:var(--err)">excluir</a><?php endif; ?></div>
            </td></tr>
          <?php endforeach; ?>
          </tbody></table>
        </div>
        <form method="post" class="ws-form" enctype="multipart/form-data">
          <h3><?= $eid?'Editar operador':'Novo operador' ?></h3>
          <input type="hidden" name="acao" value="salvar_usuario"><input type="hidden" name="id" value="<?= $eid ?>">
          <label>Nome <input name="nome" required value="<?= h($e['nome']??'') ?>"></label>
          <label>Foto do atendente <?= $eid?'(vazio = mantém a atual)':'' ?>
            <?php $fotoAtual = $eid ? ws_operador_foto((int)$eid) : ''; if ($fotoAtual): ?>
              <img src="<?= h($fotoAtual) ?>" alt="" style="width:46px;height:46px;border-radius:50%;object-fit:cover;border:1px solid var(--border);display:block;margin:2px 0 4px">
            <?php endif; ?>
            <input type="file" name="foto" accept="image/*"></label>
          <label>Login <input name="login" required value="<?= h($e['login']??'') ?>"></label>
          <label>Senha <?= $eid?'(vazio = mantém)':'' ?> <input name="senha" <?= $eid?'':'required' ?>></label>
          <label>Papel (usado em telas específicas, ex.: técnico do chamado) <select name="nivel">
            <?php foreach (['admin','financeiro','tecnico','atendente'] as $n) echo "<option ".(($e['nivel']??'atendente')===$n?'selected':'').">$n</option>"; ?>
          </select></label>
          <label>Nível de acesso <select name="nivel_acesso" <?= ws_eh_root() ? '' : 'disabled' ?>>
            <option value="1" <?= (int)($e['nivel_acesso']??2)===1?'selected':'' ?>>Nível 1 — só leitura</option>
            <option value="2" <?= (int)($e['nivel_acesso']??2)===2?'selected':'' ?>>Nível 2 — usa tudo, inclusive excluir títulos do cliente; não configura</option>
            <option value="3" <?= (int)($e['nivel_acesso']??2)===3?'selected':'' ?>>Nível 3 — configura o sistema (cadastros técnicos) e tudo mais</option>
            <?php if (ws_eh_root()): ?><option value="99" <?= (int)($e['nivel_acesso']??2)===99?'selected':'' ?>>Root — acesso total (só o dono do sistema)</option><?php endif; ?>
          </select>
          <?php if (!ws_eh_root()): ?><span class="ws-muted" style="font-size:11.5px">Só o usuário Root pode alterar nível de acesso de outras contas.</span><?php endif; ?></label>
          <?php /* CIDADES DESTE LOGIN (30/09/2026, regra do provedor): o atendente acessa SÓ a cidade principal do
                   login; as outras só se estiverem marcadas — aí transita entre elas pelo seletor do topo, sem
                   novo login. Sem cidade principal definida, fica preso à 1ª cidade ativa. Nível 3/Root: todas. */
          $ramOp = []; $ramMarc = []; $ramPrin = 0;
          try { $ramOp = $db->query("SELECT r.id, r.nome, c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 ORDER BY c.nome, r.nome")->fetchAll(); } catch (Throwable $ex) {}
          if ($eid) { try { $sm = $db->prepare("SELECT ramal_id, principal FROM ws_usuario_ramal WHERE usuario_id=?"); $sm->execute([$eid]);
                            foreach ($sm->fetchAll() as $rm) { $ramMarc[] = (int)$rm['ramal_id']; if (!empty($rm['principal'])) $ramPrin = (int)$rm['ramal_id']; }
                            if (!$ramPrin && $ramMarc) $ramPrin = $ramMarc[0]; } catch (Throwable $ex) {} }
          if ($ramOp): ?>
          <fieldset style="border:1px solid var(--border);border-radius:8px;padding:8px 10px"><legend style="font-size:12.5px;font-weight:700">Cidades deste login</legend>
            <input type="hidden" name="ramais_enviado" value="1">
            <label style="display:block;font-size:12.5px;margin-bottom:6px"><b>Cidade do login (principal)</b><br>
              <select name="ramal_principal"><option value="0">— escolha —</option>
                <?php foreach ($ramOp as $ro): ?><option value="<?= (int)$ro['id'] ?>" <?= $ramPrin === (int)$ro['id'] ? 'selected' : '' ?>><?= h($ro['cidade'] . ' — ' . $ro['nome']) ?></option><?php endforeach; ?>
              </select></label>
            <span style="font-size:12.5px;font-weight:700;display:block">Também pode acessar (troca pelo topo, sem novo login):</span>
            <?php foreach ($ramOp as $ro): ?><label class="ws-chk"><input type="checkbox" name="ramais[]" value="<?= (int)$ro['id'] ?>" <?= in_array((int)$ro['id'], $ramMarc, true) && $ramPrin !== (int)$ro['id'] ? 'checked' : '' ?>> <?= h($ro['cidade'] . ' — ' . $ro['nome']) ?></label><?php endforeach; ?>
            <span class="ws-muted" style="font-size:11.5px;display:block">Sem outras marcadas = só a cidade principal. Nível 3 e Root veem todas as cidades.</span>
          </fieldset>
          <?php endif; ?>
          <label class="ws-chk"><input type="checkbox" name="ativo" <?= (!$eid||($e['ativo']??1))?'checked':'' ?>> Ativo</label>
          <button class="ws-btn primary">Salvar operador</button>
          <?php if ($eid): ?><a class="ws-btn" href="erp.php?p=config&t=geral">Novo</a><?php endif; ?>
        </form>
      </div>
      <?php endif; // fim operadores (unificado na aba Geral) ?>

    <?php elseif ($t === 'seguranca'): ?>
      <?php ws_bloco_2fa($db); ?>
      <?php if ($admin) ws_bloco_integracao(); ?>

    <?php elseif ($t === 'migracao' && $admin): ?>
      <h3>Migração & Backup</h3>
      <p class="ws-muted">Vindo do MK-Auth ou de outro ERP? Importe seu backup (clientes, planos, contratos) — o sistema foi feito pra integrar com qualquer ERP, não só o MK-Auth. Backups completos ficam em <a href="backup.php">Sistema ▸ Backup</a>.</p>
      <p><a class="ws-btn primary" href="importar.php">⇩ Importar backup (MK-Auth ou outro ERP)</a>
         <a class="ws-btn" href="backup.php">Backups do sistema →</a></p>
      <table class="ws-table"><thead><tr><th>Arquivo</th><th>Tamanho</th><th>Data</th><th>Ações</th></tr></thead><tbody>
      <?php $bks = glob(ws_backup_dir().'/wellsystem_*.sql*') ?: []; rsort($bks);
        foreach (array_slice($bks,0,15) as $b): $n=basename($b); ?>
        <tr><td><?= h($n) ?></td><td><?= ws_fmt_tamanho(filesize($b)) ?></td>
        <td><?= date('d/m/Y H:i\h', filemtime($b)) ?></td>
        <td><a href="backup_download.php?arquivo=<?= h($n) ?>">baixar</a></td></tr>
      <?php endforeach; if(!$bks) echo '<tr><td colspan="4" class="ws-muted">Nenhum backup ainda.</td></tr>'; ?>
      </tbody></table>

    <?php elseif ($t === 'licenca' && $admin && !ws_em_demo() && ws_fornecedor_desbloqueado()):
      // Lê de qualquer cópia (cache/, /var/lib/wellsystem, /var/tmp) — ver ws_ativado() no config.php.
      $mk = ws_ativacao_ler('ativacao');
      $licMsg = ''; $licErr = '';
      if (($_POST['acao'] ?? '') === 'trocar_senha_ativacao') {
          [$okL, $mL] = ws_licenca_trocar_senha((string)($_POST['atual'] ?? ''), (string)($_POST['nova'] ?? ''), !empty($_POST['so_esta']));
          if ($okL) $licMsg = $mL; else $licErr = $mL;
      } elseif (($_POST['acao'] ?? '') === 'trocar_senha_banco') {
          if (!ws_ativacao_ok((string)($_POST['ativacao'] ?? ''))) $licErr = 'Senha de ativação incorreta — não autorizei trocar a senha do banco.';
          else { [$okB, $mB] = ws_banco_trocar_senha($db, (string)($_POST['nova_banco'] ?? '')); if ($okB) $licMsg = $mB; else $licErr = $mB; }
      } elseif (($_POST['acao'] ?? '') === 'trocar_senha_operador') {
          if (!ws_ativacao_ok((string)($_POST['ativacao2'] ?? ''))) $licErr = 'Senha de ativação incorreta — não autorizei trocar a senha do operador.';
          else {
              $uid = (int)($_POST['operador_id'] ?? 0); $novaOp = trim((string)($_POST['nova_op'] ?? ''));
              if ($uid <= 0 || strlen($novaOp) < 4) $licErr = 'Escolha um operador e uma senha de ao menos 4 caracteres.';
              else { $db->prepare("UPDATE ws_usuario SET senha_hash=? WHERE id=?")->execute([password_hash($novaOp, PASSWORD_DEFAULT), $uid]); $licMsg = 'Senha do operador redefinida com sucesso.'; }
          }
      }
      $operadoresLic = $db->query("SELECT id,nome,login,nivel FROM ws_usuario WHERE ativo=1 ORDER BY nome")->fetchAll();
      $exig = ws_ativacao_exigida(); $ativo = ws_ativado(); $hostAtual = ws_host_atual();
      $viaPainel = ws_licenca_via_painel(); $semRecup = ws_licenca_sem_recuperacao();
      $cfgDb = ws_db_config();
      ?>
      <h3>🔐 Licença &amp; Senhas <span class="ws-muted" style="font-size:13px;font-weight:400">(tudo pela caixa — sem terminal)</span></h3>
      <?php if ($licMsg): ?><div class="ws-alert ok"><?= h($licMsg) ?></div><?php endif; ?>
      <?php if ($licErr): ?><div class="ws-alert err"><?= h($licErr) ?></div><?php endif; ?>

      <div class="ws-cards" style="margin-bottom:14px">
        <div class="ws-stat"><span style="font-size:18px;-webkit-text-fill-color:<?= $ativo?'var(--ok)':'var(--err)' ?>;color:<?= $ativo?'var(--ok)':'var(--err)' ?>"><?= $ativo?'ATIVADO':'NÃO ATIVADO' ?></span><label>Status neste servidor</label></div>
        <div class="ws-stat"><span style="font-size:15px"><?= $ativo ? 'Todos os endereços deste servidor' : h($hostAtual) ?></span><label>Ativação vale para</label></div>
        <div class="ws-stat"><span style="font-size:14px"><?= !empty($mk['ativado_em']) ? h(date('d/m/Y H:i\h', strtotime((string)$mk['ativado_em']))) : '—' ?></span><label>Ativado em</label></div>
        <div class="ws-stat"><span style="font-size:14px"><?= $viaPainel?'Definida no painel':'Padrão (licenca.php/núcleo)' ?></span><label>Senha de ativação</label></div>
        <?php /* A SENHA DE RESERVA NÃO É IMPRESSA NA TELA — antes aparecia aqui, inteira, para
                 qualquer operador que abrisse a página. De nada adianta guardar o hash no código
                 se a tela mostra a senha. O painel diz apenas SE a recuperação está ligada; qual
                 é a senha, só quem tem o gerador de licenças sabe. */ ?>
        <div class="ws-stat"><span style="font-size:14px"><?= $semRecup?'DESLIGADA':'Ligada' ?></span><label>Recuperação de emergência</label></div>
      </div>

      <div class="ws-form grid" style="grid-template-columns:repeat(auto-fill,minmax(270px,1fr));background:none;padding:0;align-items:start">
        <!-- Caixa 1: senha de ATIVAÇÃO -->
        <div class="ws-card">
          <h4 style="margin:0 0 6px">🔑 Nível 1 — Senha de ATIVAÇÃO</h4>
          <p class="ws-muted" style="font-size:12.5px;line-height:1.55">É a senha que <b>libera o sistema em cada servidor</b> — digitada uma vez, vale para todos os endereços dele (domínio, IP interno e público). Ao migrar de servidor, a caixa de ativação reabre e você redigita esta senha. Troque-a aqui — vale na hora, sem editar arquivo.</p>
          <form method="post" class="ws-form" style="max-width:none" onsubmit="return confirm('Trocar a senha de ativação agora?')">
            <input type="hidden" name="acao" value="trocar_senha_ativacao">
            <label>Senha de ativação ATUAL <input name="atual" type="password" required autocomplete="off" placeholder="a senha de ativação em vigor"></label>
            <label>NOVA senha de ativação <input name="nova" type="password" required autocomplete="off"></label>
            <label style="display:flex;align-items:flex-start;gap:8px;font-size:12px;line-height:1.4"><input type="checkbox" name="so_esta" style="margin-top:2px;flex:none"><span>Tornar a NOVA a <b>única</b> senha (desliga a senha de recuperação de fábrica) — <b>cuidado:</b> se esquecer, não há como recuperar.</span></label>
            <button class="ws-btn primary">Trocar senha de ativação</button>
          </form>
        </div>

        <!-- Caixa 2: senha do BANCO -->
        <div class="ws-card">
          <h4 style="margin:0 0 6px">🗄️ Nível 2 — Senha do BANCO de dados</h4>
          <p class="ws-muted" style="font-size:12.5px;line-height:1.55">Muda a senha do usuário do banco (<code><?= h($cfgDb['user'] ?? 'wellsystem') ?></code>) no próprio MySQL <b>e</b> atualiza a configuração — as próximas conexões já usam a nova. Precisa da <b>senha de ativação</b> para autorizar.</p>
          <form method="post" class="ws-form" style="max-width:none" onsubmit="return confirm('Trocar a senha do BANCO de dados agora? Se der erro de permissão no MySQL, nada muda.')">
            <input type="hidden" name="acao" value="trocar_senha_banco">
            <label>Senha de ATIVAÇÃO (autoriza) <input name="ativacao" type="password" required autocomplete="off"></label>
            <label>NOVA senha do banco <input name="nova_banco" type="password" required autocomplete="off"></label>
            <button class="ws-btn danger">Trocar senha do banco</button>
          </form>
        </div>

        <!-- Caixa 3: senha de OPERADOR do sistema -->
        <div class="ws-card">
          <h4 style="margin:0 0 6px">👤 Nível 3 — Senha de OPERADOR</h4>
          <p class="ws-muted" style="font-size:12.5px;line-height:1.55">Redefine a senha de <b>login</b> de um operador do sistema (inclusive o <b>root/admin</b>) — útil quando alguém esquece a senha. Precisa da <b>senha de ativação</b> para autorizar.</p>
          <form method="post" class="ws-form" style="max-width:none" onsubmit="return confirm('Redefinir a senha deste operador agora?')">
            <input type="hidden" name="acao" value="trocar_senha_operador">
            <label>Operador <select name="operador_id" required>
              <option value="">— escolha —</option>
              <?php foreach ($operadoresLic as $u) echo "<option value='{$u['id']}'>" . h($u['nome']) . " (" . h($u['login']) . " · " . h($u['nivel']) . ")</option>"; ?>
            </select></label>
            <label>Senha de ATIVAÇÃO (autoriza) <input name="ativacao2" type="password" required autocomplete="off"></label>
            <label>NOVA senha do operador <input name="nova_op" type="password" required autocomplete="off"></label>
            <button class="ws-btn">Redefinir senha do operador</button>
          </form>
        </div>
      </div>

      <p class="ws-muted" style="font-size:12.5px;max-width:860px;line-height:1.6;margin-top:14px">
        🔒 A trava é <b>amarrada ao domínio</b> (<code><?= h($hostAtual) ?></code>): copiar a pasta para outro servidor exige <b>reativar</b> (a caixa reabre). Mesmo apagando o <code>licenca.php</code>, a trava <b>continua</b> pelo núcleo — não some deletando arquivo. A menos que você desligue a recuperação, a senha de fábrica (que fica com o fornecedor, fora do código) sempre te tira de um aperto.
      </p>
    <?php endif; ?>
    <?php
}

