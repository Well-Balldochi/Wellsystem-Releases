<?php
/**
 * WellSystem — ESPELHO: servidor PRINCIPAL + servidor RESERVA (05/11/2026).
 *
 * REGRAS (pedido do dono):
 *  1. Só UM servidor escreve no banco por vez: o PRINCIPAL. O RESERVA é réplica SOMENTE-LEITURA (MariaDB read_only=1). O usuário do sistema
 *     (wellsystem) não tem SUPER, então o próprio banco recusa qualquer gravação no reserva — não depende de o código lembrar.
 *  2. Serviço AUTOMÁTICO (cobrança, mensagens, emissão, faturamento, gateways, sincronia do RADIUS, OLT…) só roda no principal:
 *     ws_espelho_so_principal() no começo de cada rotina do cron. Depois de uma troca há QUARENTENA (quarentena_s, 180 s) sem serviço
 *     automático: a cópia termina de chegar e nada sai em dobro.
 *  3. A BAIXA vale nos dois: o principal grava, o banco replica e o reserva enxerga na hora.
 *  4. Principal fora do ar: o reserva assume (ws_espelho_promover) — sozinho só se failover_auto estiver ligado. Quando o antigo principal volta,
 *     ele sobe SOMENTE-LEITURA (my.cnf), vê que o par é o principal e vira RÉPLICA dele, puxando o que foi feito nesse tempo.
 *  5. O principal copia os arquivos de configuração e anexos (a mesma lista do backup: ws_backup_config_itens) para o reserva a cada 2 min.
 * Tudo roda como ROOT dentro de atualizar_run.php (cron de 1 min) via ws_espelho_rodar(). Arquivos por servidor (NÃO vão no backup nem na cópia):
 * cache/espelho.json (configuração), espelho_cred.json (usuário do par, 0600), espelho_estado.json, espelho_pedido.json.
 */
function ws_espelho_arq(string $n): string { return WS_CACHE . '/' . $n; }
function ws_espelho_json(string $n): array { $j = json_decode((string)@file_get_contents(ws_espelho_arq($n)), true); return is_array($j) ? $j : []; }
function ws_espelho_gravar(string $n, array $d, int $modo = 0640): void {
    @file_put_contents(ws_espelho_arq($n), json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX); @chmod(ws_espelho_arq($n), $modo);
    if ($modo !== 0600 && function_exists('posix_geteuid') && posix_geteuid() === 0) @chgrp(ws_espelho_arq($n), 'www-data');   // as rotinas do cron (www-data) leem o papel/estado; a credencial do par (0600) fica só do root
}
function ws_espelho_cfg(): array {
    return ws_espelho_json('espelho.json') + ['ativo' => false, 'par' => '', 'preferido' => 'principal', 'failover_auto' => false, 'quarentena_s' => 180, 'falhas_limite' => 3, 'chave' => '/root/.ssh/id_espelho'];
}
function ws_espelho_cred(): array { return ws_espelho_json('espelho_cred.json') + ['usuario' => 'ws_espelho', 'senha' => '']; }
function ws_espelho_estado(): array { return ws_espelho_json('espelho_estado.json'); }
function ws_espelho_estado_salvar(array $p): void { ws_espelho_gravar('espelho_estado.json', $p + ws_espelho_estado()); }
function ws_espelho_log(string $m): void { if (function_exists('ws_atu_log')) ws_atu_log('Espelho: ' . $m); }

/** Este servidor é a RÉPLICA (banco em somente-leitura)? Sem espelho configurado o banco nunca está em somente-leitura → false (comportamento de sempre). */
function ws_espelho_somente_leitura(bool $fresco = false): bool {
    static $c = null, $t = 0;
    if (!$fresco && $c !== null && time() - $t < 5) return $c;
    try { $c = (int)ws_db()->query('SELECT @@global.read_only')->fetchColumn() === 1; } catch (Throwable $e) { $c = false; }
    $t = time(); return $c;
}
/** Logo depois de assumir o papel de principal: sem serviço automático por quarentena_s (a cópia termina de chegar, nada sai em dobro). */
function ws_espelho_em_quarentena(): bool {
    $e = ws_espelho_estado(); $c = ws_espelho_cfg();
    return !empty($e['promovido_em']) && time() - (int)$e['promovido_em'] < (int)$c['quarentena_s'];
}
/** No começo de TODA rotina automática (cron): a réplica e a quarentena saem calada. */
function ws_espelho_so_principal(): void { if (ws_espelho_somente_leitura() || ws_espelho_em_quarentena()) exit(0); }

/** SQL como ROOT do banco local (socket). O SQL vai pela entrada padrão (senha nunca aparece na lista de processos). [codigo, saida] */
function ws_espelho_root_sql(string $sql, bool $vertical = false): array {
    $p = proc_open('mysql --connect-timeout=5 ' . ($vertical ? '-E' : '-B -N') . ' 2>&1', [0 => ['pipe', 'r'], 1 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) return [1, 'não abriu o mysql'];
    fwrite($pipes[0], $sql); fclose($pipes[0]); $out = stream_get_contents($pipes[1]); fclose($pipes[1]);
    return [proc_close($p), trim($out)];
}
function ws_espelho_status_replica(): array {
    [$rc, $out] = ws_espelho_root_sql('SHOW REPLICA STATUS;', true); $r = ['configurada' => false, 'io' => false, 'sql' => false, 'atraso' => null, 'erro' => ''];
    if ($rc !== 0 || $out === '') return $r;
    $v = []; foreach (explode("\n", $out) as $l) if (preg_match('/^\s*([A-Za-z_]+):\s?(.*)$/', $l, $m)) $v[$m[1]] = trim($m[2]);
    $r['configurada'] = ($v['Master_Host'] ?? '') !== ''; $r['io'] = ($v['Slave_IO_Running'] ?? '') === 'Yes'; $r['sql'] = ($v['Slave_SQL_Running'] ?? '') === 'Yes';
    $r['atraso'] = (isset($v['Seconds_Behind_Master']) && $v['Seconds_Behind_Master'] !== 'NULL') ? (int)$v['Seconds_Behind_Master'] : null;
    $r['erro'] = trim(($v['Last_IO_Error'] ?? '') . ' ' . ($v['Last_SQL_Error'] ?? '')); $r['errno'] = (int)($v['Last_IO_Errno'] ?? 0) ?: (int)($v['Last_SQL_Errno'] ?? 0);
    return $r;
}
/** Estado do OUTRO servidor, pelo banco dele (usuário ws_espelho, só leitura de status). */
function ws_espelho_par(): array {
    $c = ws_espelho_cfg(); $k = ws_espelho_cred();
    if ($c['par'] === '' || $k['senha'] === '') return ['alcancavel' => false, 'motivo' => 'sem configuração'];
    try {
        $p = new PDO('mysql:host=' . $c['par'] . ';port=3306;charset=utf8mb4', $k['usuario'], $k['senha'], [PDO::ATTR_TIMEOUT => 3, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $r = $p->query('SELECT @@global.read_only ro, @@global.gtid_binlog_pos bp')->fetch(PDO::FETCH_ASSOC);
        return ['alcancavel' => true, 'somente_leitura' => (int)$r['ro'] === 1, 'gtid_binlog' => (string)$r['bp']];
    } catch (Throwable $e) { return ['alcancavel' => false, 'motivo' => mb_substr($e->getMessage(), 0, 140)]; }
}
function ws_espelho_ssh_par(string $cmd): array {
    $c = ws_espelho_cfg(); if ($c['par'] === '' || !is_file($c['chave'])) return [1, 'sem chave ssh'];
    exec('ssh -i ' . escapeshellarg($c['chave']) . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5 root@' . escapeshellarg($c['par']) . ' ' . escapeshellarg($cmd) . ' 2>&1', $o, $rc);
    return [$rc, trim(implode("\n", $o))];
}
/** Vira RÉPLICA do par: trava a escrita local e segue o par por GTID (current_pos: se este servidor tiver gravado algo que o par não tem, o par recusa → divergente). */
function ws_espelho_virar_replica(string $motivo): bool {
    $c = ws_espelho_cfg(); $k = ws_espelho_cred(); if ($c['par'] === '' || $k['senha'] === '') return false;
    ws_espelho_root_sql("STOP REPLICA; SET GLOBAL read_only=1; RESET REPLICA ALL; CHANGE MASTER TO MASTER_HOST='" . $c['par'] . "', MASTER_PORT=3306, MASTER_USER='" . $k['usuario'] . "', MASTER_PASSWORD='" . $k['senha'] . "', MASTER_USE_GTID=current_pos, MASTER_CONNECT_RETRY=5; START REPLICA;");
    sleep(4); $s = ws_espelho_status_replica(); $ok = $s['io'] && $s['sql'];
    ws_espelho_log('virou réplica de ' . $c['par'] . ' (' . $motivo . '): ' . ($ok ? 'replicando' : 'NÃO replica — ' . $s['erro']));
    ws_espelho_estado_salvar(['divergente' => !$ok && in_array((int)($s['errno'] ?? 0), [1236, 1062, 1032, 1452], true), 'ultimo_papel' => 'reserva']);
    if ($ok) ws_espelho_apache_papel(true, $c['par']);   // réplica copiando: o painel passa a repassar ao principal
    return $ok;
}
/** Trava a escrita local (usado na troca planejada pelo par). */
function ws_espelho_travar(): bool { [$rc] = ws_espelho_root_sql('SET GLOBAL read_only=1;'); return $rc === 0; }
/** ASSUME o papel de principal. Com o par vivo e escrevendo é troca PLANEJADA (trava o par, espera a cópia chegar, assume, e o par vira réplica). Com o par fora é assunção direta. [ok, mensagem] */
function ws_espelho_promover(string $motivo): array {
    $par = ws_espelho_par(); $planejada = $par['alcancavel'] && !$par['somente_leitura'];
    if (!ws_espelho_somente_leitura(true)) return [true, 'este servidor já é o principal'];
    if ($planejada) {
        [$rc, $m] = ws_espelho_ssh_par('php ' . escapeshellarg(__DIR__ . '/espelho_cli.php') . ' travar');
        if ($rc !== 0) return [false, 'não consegui travar o principal atual (' . $m . ')'];
        $p2 = ws_espelho_par(); $pos = (string)($p2['gtid_binlog'] ?? '');
        if ($pos !== '') { [, $w] = ws_espelho_root_sql("SELECT MASTER_GTID_WAIT('" . preg_replace('/[^0-9,\-]/', '', $pos) . "', 60);"); if ($w !== '0') { ws_espelho_ssh_par('php ' . escapeshellarg(__DIR__ . '/espelho_cli.php') . ' destravar'); return [false, 'a réplica não terminou de copiar em 60 s; nada mudou (principal destravado)']; } }
    }
    [$rc, $o] = ws_espelho_root_sql('STOP REPLICA; RESET REPLICA ALL; SET GLOBAL read_only=0;');
    if ($rc !== 0) return [false, 'falhou ao abrir a escrita: ' . $o];
    ws_espelho_estado_salvar(['promovido_em' => time(), 'ultimo_papel' => 'principal', 'falhas' => 0, 'divergente' => false]);
    ws_espelho_apache_papel(false, '');   // agora este atende direto; o repasse é desligado ANTES de o outro começar a repassar para cá (nunca em laço)
    ws_espelho_log('ASSUMIU como principal (' . $motivo . ($planejada ? ', troca planejada' : ', par fora do ar') . '). Serviços automáticos voltam em ' . (int)ws_espelho_cfg()['quarentena_s'] . ' s.');
    if ($planejada) ws_espelho_ssh_par('php ' . escapeshellarg(__DIR__ . '/espelho_cli.php') . ' virar_replica');
    return [true, 'assumiu como principal' . ($planejada ? ' (troca planejada; o outro virou réplica)' : '')];
}
/** APACHE POR PAPEL (06/11/2026): no servidor RESERVA o painel repassa tudo ao PRINCIPAL (a réplica é somente-leitura; assim a ação manual funciona em qualquer endereço, em qualquer um dos dois).
 *  No principal o repasse é desligado. Troca só com `apache2ctl configtest` ok (senão desfaz). A rota /api/espelho/papel e o desafio do certbot ficam locais. Sem espelho: nada a fazer. */
function ws_espelho_apache_papel(bool $reserva, string $principal): void {
    $conf = '/etc/apache2/conf-available/wellsystem-espelho-proxy.conf'; $ligada = '/etc/apache2/conf-enabled/wellsystem-espelho-proxy.conf';
    if (!is_dir('/etc/apache2/conf-available') || (function_exists('posix_geteuid') && posix_geteuid() !== 0)) return;
    /* O repasse usa o NOME do certificado do principal (espelho_nome.json, escrito pelo principal) e o IP dele num bloco gerenciado do /etc/hosts (esta versão do Apache não tem "addr="): o certificado é VERIFICADO de verdade (autoridade pública + conferência do nome + validade).
       Nada de desligar a verificação. Sem o nome ainda (primeira cópia não chegou) ou com o certificado inválido, o painel do reserva não repassa. */
    $nome = trim((string)(ws_espelho_json('espelho_nome.json')['nome'] ?? '')); $nomeOk = (bool)preg_match('/^[a-z0-9]([a-z0-9.\-]*[a-z0-9])?$/i', $nome);
    $quer = $reserva && filter_var($principal, FILTER_VALIDATE_IP) && $nomeOk; $mudou = false;
    $texto = "# WellSystem — ESPELHO (gerado por espelho_lib.php; não edite). Neste servidor RESERVA o painel repassa tudo ao PRINCIPAL, com o certificado dele verificado.\n<IfModule proxy_module>\n  ProxyRequests Off\n  ProxyPreserveHost Off\n  SSLProxyEngine On\n  SSLProxyVerify require\n  SSLProxyVerifyDepth 5\n  SSLProxyCheckPeerName on\n  SSLProxyCheckPeerExpire on\n  SSLProxyCACertificateFile /etc/ssl/certs/ca-certificates.crt\n  ProxyTimeout 120\n  ProxyPass \"/api/espelho/papel\" \"!\"\n  ProxyPass \"/.well-known/acme-challenge\" \"!\"\n  ProxyPass \"/\" \"https://$nome/\"\n  ProxyPassReverse \"/\" \"https://$nome/\"\n  RequestHeader set X-Forwarded-Proto \"https\"\n  RequestHeader set X-Espelho-Via \"reserva\"\n</IfModule>\n";
    /* /etc/hosts: bloco entre marcas; o nome do principal aponta para o IP dele só enquanto este servidor é reserva. */
    $hosts = (string)@file_get_contents('/etc/hosts'); $ini = '# WS-ESPELHO-INICIO'; $fim = '# WS-ESPELHO-FIM';
    $semBloco = preg_replace('/
?' . preg_quote($ini, '/') . '.*?' . preg_quote($fim, '/') . '
?/s', "
", $hosts);
    $novoHosts = $quer ? rtrim($semBloco) . "
$ini
$principal $nome
$fim
" : rtrim($semBloco) . "
";
    if ($hosts !== '' && rtrim($hosts) !== rtrim($novoHosts)) { @file_put_contents('/etc/hosts', $novoHosts); }
    if ($quer) {
        if ((string)@file_get_contents($conf) !== $texto) { @file_put_contents($conf, $texto); $mudou = true; }
        if (!file_exists($ligada)) { exec('a2enmod -q proxy proxy_http ssl headers rewrite >/dev/null 2>&1; a2enconf -q wellsystem-espelho-proxy >/dev/null 2>&1'); $mudou = true; }
    } elseif (file_exists($ligada)) { exec('a2disconf -q wellsystem-espelho-proxy >/dev/null 2>&1'); $mudou = true; }
    if (!$mudou) return;
    exec('apache2ctl configtest >/dev/null 2>&1', $o, $rc);
    if ($rc === 0) { exec('systemctl reload apache2 2>&1'); ws_espelho_log('Apache: ' . ($quer ? 'painel passa a repassar ao principal ' . $principal : 'repasse ao principal desligado (este servidor atende direto)') . '.'); }
    else { exec('a2disconf -q wellsystem-espelho-proxy >/dev/null 2>&1'); ws_espelho_log('configuração do repasse inválida — desfeita (nada mudou no Apache).'); }
}
/** Copia para o par (só quando mudou) os certificados do Let's Encrypt e os sites do Apache DESTE servidor, para o par poder atender também os nomes daqui se assumir. Os arquivos do par ficam à parte (espelho-par-*.conf);
 *  cada troca só vale com configtest ok no par (senão remove). */
function ws_espelho_sincronizar_apache(): void {
    $c = ws_espelho_cfg(); $e = ws_espelho_estado();
    if ($c['par'] === '' || !is_file($c['chave']) || !is_dir('/etc/apache2/sites-enabled') || time() - (int)($e['apache_em'] ?? 0) < 300) return;
    $ssh = 'ssh -i ' . escapeshellarg($c['chave']) . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5 root@' . escapeshellarg($c['par']);
    $assin = []; $nomeSsl = '';
    foreach (glob('/etc/apache2/sites-enabled/*.conf') ?: [] as $f) {
        if (strpos(basename($f), 'espelho-par-') === 0) continue; $assin[basename($f)] = md5_file($f);
        $tx = (string)@file_get_contents($f); if ($nomeSsl === '' && preg_match('/<VirtualHost[^>]*:443>.*?ServerName\s+([A-Za-z0-9.\-]+)/s', $tx, $mn)) $nomeSsl = strtolower($mn[1]);
    }
    if ($nomeSsl !== '' && (ws_espelho_json('espelho_nome.json')['nome'] ?? '') !== $nomeSsl) ws_espelho_gravar('espelho_nome.json', ['nome' => $nomeSsl, 'em' => time()]);   // o reserva usa este nome para conferir o certificado do principal (copiado junto com a configuração)
    $hash = md5(json_encode($assin) . (is_dir('/etc/letsencrypt/live') ? implode(',', array_map(fn($d) => basename($d) . '@' . (int)@filemtime($d), glob('/etc/letsencrypt/live/*', GLOB_ONLYDIR) ?: [])) : ''));
    if (($e['apache_hash'] ?? '') === $hash) { ws_espelho_estado_salvar(['apache_em' => time()]); return; }
    $rc1 = 0; if (is_dir('/etc/letsencrypt')) exec('rsync -a -e ' . escapeshellarg('ssh -i ' . $c['chave'] . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5') . ' /etc/letsencrypt/ root@' . escapeshellarg($c['par']) . ':/etc/letsencrypt/ 2>&1', $o1, $rc1);
    $ok = ($rc1 === 0); $nomes = [];
    foreach ($assin as $nome => $md) {   // -aL: copia o CONTEÚDO do site (sites-enabled é link; sem isso o par recebia um link para o próprio arquivo dele e nunca atendia os nomes de cá)
        $dest = 'espelho-par-' . $nome; $nomes[] = $dest;
        exec('rsync -aL -e ' . escapeshellarg('ssh -i ' . $c['chave'] . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5') . ' ' . escapeshellarg('/etc/apache2/sites-enabled/' . $nome) . ' ' . escapeshellarg('root@' . $c['par'] . ':/etc/apache2/sites-available/' . $dest) . ' 2>&1', $o2, $rc2); if ($rc2 !== 0) $ok = false;
    }
    if ($ok && $nomes) {   // liga os sites copiados no par; se a configuração do par ficar inválida, remove e avisa
        $cmd = 'a2enmod -q ssl rewrite headers >/dev/null 2>&1; for s in ' . implode(' ', array_map('escapeshellarg', $nomes)) . '; do a2ensite -q "${s%.conf}" >/dev/null 2>&1; done; if apache2ctl configtest >/dev/null 2>&1; then systemctl reload apache2 && echo RECARREGADO; else for s in ' . implode(' ', array_map('escapeshellarg', $nomes)) . '; do a2dissite -q "${s%.conf}" >/dev/null 2>&1; done; echo INVALIDO; fi';
        exec($ssh . ' ' . escapeshellarg($cmd) . ' 2>&1', $o3, $rc3); $r = trim(implode(' ', $o3));
        if (strpos($r, 'INVALIDO') !== false) { $ok = false; ws_espelho_log('sites do Apache copiados para o par deixariam a configuração dele inválida — removidos (nada mudou lá).'); }
        elseif (strpos($r, 'RECARREGADO') !== false) ws_espelho_log('sites e certificados do Apache copiados para o par (' . count($nomes) . ' arquivo(s)).');
    }
    ws_espelho_estado_salvar(['apache_em' => time(), 'apache_hash' => $ok ? $hash : '', 'apache_erro' => $ok ? '' : 'falhou (veja o histórico)']);
}
/** Batimento: o principal grava 1 linha por rodada; a réplica mostra há quanto tempo o batimento chegou (mede o atraso real da cópia). */
function ws_espelho_pulso(): void {
    try {
        $db = ws_db();
        $db->exec("CREATE TABLE IF NOT EXISTS ws_espelho_pulso (id TINYINT UNSIGNED NOT NULL PRIMARY KEY, ts DATETIME NOT NULL, servidor VARCHAR(60) NOT NULL DEFAULT '') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->prepare('REPLACE INTO ws_espelho_pulso (id, ts, servidor) VALUES (1, NOW(), ?)')->execute([php_uname('n')]);
    } catch (Throwable $e) {}
}
function ws_espelho_pulso_idade(): ?int { try { $v = ws_db()->query('SELECT TIMESTAMPDIFF(SECOND, ts, NOW()) FROM ws_espelho_pulso WHERE id = 1')->fetchColumn(); return $v === false || $v === null ? null : (int)$v; } catch (Throwable $e) { return null; } }
/** O principal copia configuração e anexos (lista do backup) para o par, no máximo a cada 2 min. rsync por ssh, mesmos caminhos nos dois. */
function ws_espelho_sincronizar_arquivos(): void {
    $c = ws_espelho_cfg(); $e = ws_espelho_estado();
    if ($c['par'] === '' || !is_file($c['chave']) || time() - (int)($e['arquivos_em'] ?? 0) < 120) return;
    require_once __DIR__ . '/backup_lib.php';
    $lista = []; foreach (ws_backup_config_itens() as $abs) { $abs = str_replace(chr(92), '/', (string)$abs); if ($abs !== '' && $abs[0] === '/' && is_file($abs)) $lista[] = substr($abs, 1); }
    if (!$lista) { ws_espelho_estado_salvar(['arquivos_em' => time()]); return; }
    $tmp = tempnam(sys_get_temp_dir(), 'esp'); file_put_contents($tmp, implode("\n", $lista) . "\n");
    exec('rsync -a --files-from=' . escapeshellarg($tmp) . ' -e ' . escapeshellarg('ssh -i ' . $c['chave'] . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5') . ' / root@' . $c['par'] . ':/ 2>&1', $o, $rc);
    @unlink($tmp);
    /* XML das notas fiscais (13/11/2026): a pasta cache/notas_xml é ESPELHADA por inteiro, inclusive a EXCLUSÃO — apagou um XML na tela Arquivos XML do principal, some no reserva
       em até 2 min. Travas: só roda se a pasta existe no principal (nunca esvazia o reserva por pasta ausente) e no máximo 500 exclusões por passada. */
    $nx = rtrim(str_replace(chr(92), '/', WS_CACHE), '/') . '/notas_xml';
    if ($rc === 0 && is_dir($nx) && $nx[0] === '/') {
        exec('rsync -a --delete --max-delete=500 -e ' . escapeshellarg('ssh -i ' . $c['chave'] . ' -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5') . ' ' . escapeshellarg($nx . '/') . ' ' . escapeshellarg('root@' . $c['par'] . ':' . $nx . '/') . ' 2>&1', $o2, $rc2);
        if ($rc2 !== 0) { $rc = $rc2; $o = $o2; }
    }
    ws_espelho_estado_salvar(['arquivos_em' => time(), 'arquivos_qtd' => count($lista), 'arquivos_erro' => $rc === 0 ? '' : mb_substr(implode(' ', array_slice($o, -2)), 0, 200)]);
    if ($rc !== 0) ws_espelho_log('cópia de arquivos para o par falhou: ' . mb_substr(implode(' ', array_slice($o, -2)), 0, 160));
}
/** Rotina de 1 min (root, dentro do atualizar_run.php). Sem espelho ligado não faz nada. */
function ws_espelho_rodar(): void {
    if (PHP_SAPI !== 'cli' || (function_exists('posix_geteuid') && posix_geteuid() !== 0)) return;
    $c = ws_espelho_cfg(); $e = ws_espelho_estado(); $agora = time();
    $ped = ws_espelho_json('espelho_pedido.json');   // pedido da tela da Manutenção (vale também com o espelho ainda desligado: configurar e ligar)
    if ($ped) {
        @unlink(ws_espelho_arq('espelho_pedido.json'));
        if ($agora - (int)($ped['em'] ?? 0) < 600) {
            if (($ped['acao'] ?? '') === 'configurar') {   // campos da tela: IP do outro servidor, papel, minutos sem resposta, quarentena (só valida e grava; não liga nada)
                $ip = trim((string)($ped['par'] ?? '')); $pref = (string)($ped['preferido'] ?? $c['preferido']);
                if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($pref, ['principal', 'reserva'], true)) {
                    $c['par'] = $ip; $c['preferido'] = $pref; $c['falhas_limite'] = max(1, min(30, (int)($ped['falhas_limite'] ?? $c['falhas_limite']))); $c['quarentena_s'] = max(60, min(900, (int)($ped['quarentena_s'] ?? $c['quarentena_s'])));
                    ws_espelho_gravar('espelho.json', $c); ws_espelho_estado_salvar(['ultimo_pedido' => 'OK: configuração salva', 'ultimo_pedido_em' => $agora]); ws_espelho_log('configuração salva por ' . (string)($ped['por'] ?? '?') . ' (par ' . $ip . ', ' . $pref . ').');
                } else ws_espelho_estado_salvar(['ultimo_pedido' => 'FALHOU: IP ou papel inválido', 'ultimo_pedido_em' => $agora]);
            }
            if (($ped['acao'] ?? '') === 'instalar') {   // liga o espelho (copia o banco para o outro servidor e começa a replicar). Roda em segundo plano; o passo a passo fica em cache/espelho_instalar.log
                $ip = trim((string)($ped['par'] ?? $c['par'])); $busy = trim((string)@shell_exec('pgrep -f "[e]spelho_cli.php instalar" 2>/dev/null'));
                if (!filter_var($ip, FILTER_VALIDATE_IP)) ws_espelho_estado_salvar(['ultimo_pedido' => 'FALHOU: informe o IP do outro servidor', 'ultimo_pedido_em' => $agora]);
                elseif ($busy !== '') ws_espelho_estado_salvar(['ultimo_pedido' => 'Já há uma instalação em andamento', 'ultimo_pedido_em' => $agora]);
                elseif (ws_espelho_somente_leitura(true)) ws_espelho_estado_salvar(['ultimo_pedido' => 'FALHOU: este servidor está em somente-leitura; rode a instalação no servidor de PRODUÇÃO (principal)', 'ultimo_pedido_em' => $agora]);
                else {
                    $log = ws_espelho_arq('espelho_instalar.log'); @file_put_contents($log, "[" . date('d/m H:i:s') . "] Instalação pedida por " . (string)($ped['por'] ?? '?') . " (outro servidor: $ip)\n"); @chmod($log, 0644);
                    exec('nohup php ' . escapeshellarg(__DIR__ . '/espelho_cli.php') . ' instalar ' . escapeshellarg($ip) . ' principal >> ' . escapeshellarg($log) . ' 2>&1 &');
                    ws_espelho_estado_salvar(['ultimo_pedido' => 'Instalação iniciada: acompanhe o passo a passo abaixo', 'ultimo_pedido_em' => $agora, 'instalando_em' => $agora]); ws_espelho_log('instalação do espelho iniciada (outro servidor ' . $ip . ').');
                }
            }
            $c = ws_espelho_cfg();
            if (!empty($c['ativo']) && ($ped['acao'] ?? '') === 'promover') { [$ok, $m] = ws_espelho_promover('pedido de ' . (string)($ped['por'] ?? '?')); ws_espelho_estado_salvar(['ultimo_pedido' => ($ok ? 'OK: ' : 'FALHOU: ') . $m, 'ultimo_pedido_em' => $agora]); }
            if (!empty($c['ativo']) && (($ped['acao'] ?? '') === 'auto_on' || ($ped['acao'] ?? '') === 'auto_off')) { $c['failover_auto'] = ($ped['acao'] === 'auto_on'); ws_espelho_gravar('espelho.json', $c); ws_espelho_log('troca automática ' . ($c['failover_auto'] ? 'LIGADA' : 'desligada') . ' por ' . (string)($ped['por'] ?? '?')); }
            if (!empty($c['ativo']) && ($ped['acao'] ?? '') === 'virar_replica') { $ok = ws_espelho_virar_replica('pedido de ' . (string)($ped['por'] ?? '?')); ws_espelho_estado_salvar(['ultimo_pedido' => $ok ? 'OK: virou réplica' : 'FALHOU ao virar réplica', 'ultimo_pedido_em' => $agora]); }
            $e = ws_espelho_estado();
        }
    }
    $c = ws_espelho_cfg(); if (empty($c['ativo']) || $c['par'] === '') { ws_espelho_apache_papel(false, ''); return; }   // espelho desligado (instalação com 1 servidor só): nada mais a fazer — o sistema trabalha normalmente
    $ro = ws_espelho_somente_leitura(true); $par = ws_espelho_par(); $rep = ws_espelho_status_replica();
    ws_espelho_apache_papel($ro && $par['alcancavel'] && !$par['somente_leitura'], $c['par']);   // réplica com o principal no ar: o painel repassa ao principal
    /* Desempenho da cópia: no RESERVA o banco grava o log com flush por segundo (a cópia contínua acompanha o principal sem atraso; o dado de verdade está no principal). Ao virar principal, volta ao padrão seguro (1). */
    if ($ro) { ws_espelho_root_sql('SET GLOBAL innodb_flush_log_at_trx_commit=2'); if (empty($e['durab_reserva'])) ws_espelho_estado_salvar(['durab_reserva' => 1]); }
    elseif (!$ro && !empty($e['durab_reserva'])) { ws_espelho_root_sql('SET GLOBAL innodb_flush_log_at_trx_commit=1'); ws_espelho_estado_salvar(['durab_reserva' => 0]); }
    $p = ['verificado_em' => $agora, 'papel' => $ro ? 'reserva' : 'principal', 'par_alcancavel' => $par['alcancavel'], 'par_papel' => $par['alcancavel'] ? ($par['somente_leitura'] ? 'reserva' : 'principal') : '?',
          'replica_io' => $rep['io'], 'replica_sql' => $rep['sql'], 'atraso_s' => $rep['atraso'], 'replica_erro' => $rep['erro'], 'pulso_idade_s' => ws_espelho_pulso_idade(), 'alerta' => ''];
    if ($ro) {
        if ($par['alcancavel']) {
            $p['falhas'] = 0;
            if (!$par['somente_leitura']) {   // o par é o principal: garante que estamos copiando dele
                $p['sem_principal_desde'] = 0;
                if (!($rep['configurada'] && $rep['io'] && $rep['sql']) && $agora - (int)($e['tentou_replica_em'] ?? 0) >= 120) { $p['tentou_replica_em'] = $agora; ws_espelho_virar_replica('replicação parada'); $e = ws_espelho_estado(); }
                if (!empty($e['divergente'])) $p['alerta'] = 'DIVERGENTE: este servidor tem gravações que o principal não tem. Ressincronize: php espelho_cli.php ressincronizar';
            } else {   // os dois estão somente-leitura (partida a frio ou reinício): decide quem escreve
                $desde = (int)($e['sem_principal_desde'] ?? 0) ?: $agora; $p['sem_principal_desde'] = $desde;
                $volta = ($e['ultimo_papel'] ?? '') === 'principal';   // quem era o principal e só reiniciou volta direto
                $espera = $volta ? 0 : ($c['preferido'] === 'principal' ? 60 : 180);
                if ($agora - $desde >= $espera) { [$ok, $m] = ws_espelho_promover('sem principal ativo'); $p['ultimo_pedido'] = ($ok ? 'OK: ' : 'FALHOU: ') . $m; }
                else $p['alerta'] = 'nenhum servidor está escrevendo; decisão em ' . ($espera - ($agora - $desde)) . ' s';
            }
        } else {   // o par não responde
            $f = (int)($e['falhas'] ?? 0) + 1; $p['falhas'] = $f;
            if (($e['ultimo_papel'] ?? '') === 'principal') { [$ok, $m] = ws_espelho_promover('reinício do principal com o par fora do ar'); $p['ultimo_pedido'] = ($ok ? 'OK: ' : 'FALHOU: ') . $m; }   // quem era o principal e só reiniciou volta a escrever (nunca fica todo mundo parado)
            elseif (!empty($c['failover_auto']) && $f >= (int)$c['falhas_limite']) { [$ok, $m] = ws_espelho_promover('principal sem resposta há ' . $f . ' verificações'); $p['ultimo_pedido'] = ($ok ? 'OK: ' : 'FALHOU: ') . $m; }
            else $p['alerta'] = 'o principal não responde (' . $f . ' verificação(ões)); ' . (!empty($c['failover_auto']) ? 'assume em ' . max(0, (int)$c['falhas_limite'] - $f) . ' min' : 'troca automática desligada');
        }
    } else {   // este é o principal
        $p['sem_principal_desde'] = 0; $p['falhas'] = 0; $p['ultimo_papel'] = 'principal';
        if ($par['alcancavel'] && !$par['somente_leitura']) $p['alerta'] = 'DOIS PRINCIPAIS ao mesmo tempo (divergência). Decida: php espelho_cli.php rebaixar';
        ws_espelho_pulso();
        if ($par['alcancavel']) { ws_espelho_sincronizar_arquivos(); ws_espelho_sincronizar_apache(); }
    }
    ws_espelho_estado_salvar($p);
}
