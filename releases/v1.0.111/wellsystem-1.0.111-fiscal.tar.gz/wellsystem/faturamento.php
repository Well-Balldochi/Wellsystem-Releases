<?php
/**
 * WellSystem — Faturamento recorrente (gera a fatura mensal dos contratos ativos).
 * Usado pelo cron (faturar_run.php) e pelo botão "Gerar faturas do mês" (financeiro.php).
 * Idempotente: nunca duplica a fatura de um contrato na mesma competência.
 */
require_once __DIR__ . '/config.php';

/**
 * Gera UMA fatura para um contrato específico (usado pelo botão na ficha do cliente).
 * @return int id da fatura criada (ou a já existente da competência).
 */
function ws_faturar_um(PDO $db, array $ct, ?string $competencia = null): int {
    $competencia = $competencia && preg_match('/^\d{4}-\d{2}$/', $competencia) ? $competencia : date('Y-m');
    $ja = $db->prepare("SELECT id FROM ws_fatura WHERE contrato_id=? AND competencia=?");
    $ja->execute([$ct['id'], $competencia]);
    if ($fid = $ja->fetchColumn()) return (int)$fid;

    [$ano, $mes] = array_map('intval', explode('-', $competencia));
    $dia = min((int)($ct['dia_vencimento'] ?: 10), (int)date('t', mktime(0, 0, 0, $mes, 1, $ano)));
    $venc = ws_venc_ajustar(sprintf('%04d-%02d-%02d', $ano, $mes, $dia));   // "Vence aos sábados" (Recursos do sistema)
    if (ws_venc_passado($venc)) $venc = date('Y-m-d');   // o dia do mês já passou: vence hoje, nunca nasce vencido
    if (empty($ct['valor'])) {
        $p = $db->prepare("SELECT valor FROM ws_plano WHERE id=?"); $p->execute([$ct['plano_id']]);
        $ct['valor'] = $p->fetchColumn() ?: 0;
    }
    $myId = 'ws-' . $ct['id'] . '-' . str_replace('-', '', $competencia) . '-' . substr(uniqid(), -4);
    $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,status,celcash_my_id)
                  VALUES (?,?,?,?,?, 'aberto', ?)")
       ->execute([$ct['id'], $ct['cliente_id'], $competencia, $venc, (float)$ct['valor'], $myId]);
    $fid = (int)$db->lastInsertId();
    ws_evento($db, (int)$ct['cliente_id'], 'fatura', "Fatura $competencia gerada (ficha) — R$ " . number_format((float)$ct['valor'], 2, ',', '.'));
    return $fid;
}

/**
 * Gera as faturas de uma competência (AAAA-MM) para todos os contratos ativos.
 * @param bool $autoEmit  se true, já emite boleto+PIX no CelCash (gera cobrança REAL).
 * @return array resumo [criadas, puladas, emitidas, erros]
 */
function ws_faturar_mes(PDO $db, string $competencia, bool $autoEmit = false, ?array $somenteContratos = null, ?array $excluirContratos = null): array {
    $r = ['criadas' => 0, 'puladas' => 0, 'emitidas' => 0, 'erros' => 0];
    if (!preg_match('/^\d{4}-\d{2}$/', $competencia)) $competencia = date('Y-m');
    [$ano, $mes] = array_map('intval', explode('-', $competencia));
    $ultimoDia = (int)date('t', mktime(0, 0, 0, $mes, 1, $ano));

    $contratos = $db->query("SELECT ct.*, p.valor pvalor FROM ws_contrato ct
                             LEFT JOIN ws_plano p ON p.id=ct.plano_id
                             WHERE ct.status='ativo'")->fetchAll();

    foreach ($contratos as $ct) {
        if ($somenteContratos !== null && !in_array((int)$ct['id'], $somenteContratos, true)) continue;
        if ($excluirContratos && in_array((int)$ct['id'], $excluirContratos, true)) continue;   // adicionais fora do auto lançamento
        // dedupe por contrato+competência
        $ja = $db->prepare("SELECT COUNT(*) FROM ws_fatura WHERE contrato_id=? AND competencia=?");
        $ja->execute([$ct['id'], $competencia]);
        if ((int)$ja->fetchColumn() > 0) { $r['puladas']++; continue; }

        $valor = (float)($ct['valor'] ?: $ct['pvalor'] ?: 0);
        if ($valor <= 0) { $r['puladas']++; continue; }

        $dia = min((int)($ct['dia_vencimento'] ?: 10), $ultimoDia);
        $venc = ws_venc_ajustar(sprintf('%04d-%02d-%02d', $ano, $mes, $dia));   // "Vence aos sábados"
        if (ws_venc_passado($venc)) $venc = date('Y-m-d');   // o dia do mês já passou: vence hoje, nunca nasce vencido
        $myId = 'ws-' . $ct['id'] . '-' . str_replace('-', '', $competencia) . '-' . substr(uniqid(), -4);

        $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,status,celcash_my_id)
                      VALUES (?,?,?,?,?, 'aberto', ?)")
           ->execute([$ct['id'], $ct['cliente_id'], $competencia, $venc, $valor, $myId]);
        $fid = (int)$db->lastInsertId();
        $r['criadas']++;
        ws_evento($db, (int)$ct['cliente_id'], 'fatura', "Fatura $competencia gerada (recorrente) — R$ " . number_format($valor, 2, ',', '.'));

        /* LYTEX: contrato cuja "Conta do boleto/PIX" é a conta com Emissão = Lytex sai pela Lytex — foi o
           operador que escolheu esse cliente para ela (lytex.php). Os demais seguem o fluxo de sempre. */
        $ehLytex = !empty($ct['banco_id']) && is_file(__DIR__ . '/lytex.php')
                   && (require_once __DIR__ . '/lytex.php') && ws_lytex_pronto() && ws_lytex_eh_banco($db, $ct['banco_id']);
        if ($ehLytex) {
            try { $db->prepare("UPDATE ws_fatura SET banco_id=? WHERE id=?")->execute([(int)$ct['banco_id'], $fid]); } catch (Throwable $e) {}
            try { $rL = ws_lytex_emitir_fatura($db, $fid); if (!empty($rL['ok'])) $r['emitidas']++; else $r['erros']++; } catch (Throwable $e) { $r['erros']++; }
        } elseif ($autoEmit) {
            require_once __DIR__ . '/celcash.php';
            $cli = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $cli->execute([$ct['cliente_id']]); $cliente = $cli->fetch();
            /* Endereço do CADASTRO normalizado. O gateway de cobrança recebe rua/número/bairro/
             * cidade/UF/CEP daqui — é o endereço que sai no boleto registrado, então ele não pode
             * vir de texto solto que cada cliente digitou à sua maneira. */
            require_once __DIR__ . '/schema_endereco.php';
            if ($cliente) $cliente = ws_end_enriquecer($db, $cliente);
            $fatura = ['id' => $fid, 'valor' => $valor, 'vencimento' => $venc, 'competencia' => $competencia, 'celcash_my_id' => $myId];
            $e = ws_celcash_criar_cobranca($fatura, $cliente);
            if ($e['ok']) {
                // Emissão é síncrona (já volta com linha digitável/PIX prontos) — título já nasce
                // 'aberto'. 'processando' ficava travado pra sempre (nada o tirava de lá além do
                // pagamento via webhook), sumindo da aba "Abertas" sem motivo.
                $db->prepare("UPDATE ws_fatura SET status='aberto', celcash_charge_id=?, linha_digitavel=?, boleto_url=?, pix_emv=?, pix_qr_url=?, gateway_raw=? WHERE id=?")
                   ->execute([$e['charge_id'], $e['linha_digitavel'], $e['boleto_url'], $e['pix_emv'], $e['pix_qr_url'], $e['raw'], $fid]);
                $r['emitidas']++;
            } else $r['erros']++;
        }
    }
    return $r;
}

/**
 * FATURAMENTO AUTOMÁTICO conforme Provedor → Recursos do sistema (usado pelo cron faturar_run.php).
 *
 *   Auto lançamentos de títulos = N  → deixa geradas as faturas do mês atual e dos N-1 seguintes
 *                                      (N = 1 é exatamente o que o cron sempre fez; N = 0 não gera nada).
 *   Manter número de títulos = Não   → só gera para contrato que ainda NÃO tem nenhuma fatura (os
 *                                      primeiros títulos); quem já tem não é completado.
 *   Manter carnês = Sim              → (quando os títulos automáticos estão em 0) contrato ativo que ficou
 *                                      sem nenhuma parcela em aberto ganha um carnê novo de
 *                                      "Auto parcelas de carnê" meses, a partir do mês seguinte.
 *   Auto lançamento para adicionais   → Não (padrão) = títulos e carnês automáticos só do titular;
 *                                      Sim = gera também para os clientes adicionais.
 * Nunca duplica: a mesma competência de um contrato não é gerada duas vezes.
 */
function ws_faturar_automatico(PDO $db, bool $autoEmit = false): array {
    $rc = ws_recursos();
    $r = ['criadas' => 0, 'puladas' => 0, 'emitidas' => 0, 'erros' => 0, 'meses' => [], 'carnes' => 0];
    $n = (int)$rc['auto_titulos'];
    /* Auto lançamento para adicionais = Não (padrão): cliente ADICIONAL (titular_id apontando para outro
     * cliente) fica fora do lançamento automático de títulos e carnês — só o titular é gerado. */
    $semAdic = empty($rc['auto_adicionais']);
    if ($n > 0) {
        $somente = null;
        $excluir = $semAdic ? ws_contratos_adicionais($db) : null;
        if (!$rc['manter_titulos']) {
            $somente = array_map('intval', $db->query("SELECT ct.id FROM ws_contrato ct WHERE ct.status='ativo'
                                                      AND NOT EXISTS(SELECT 1 FROM ws_fatura f WHERE f.contrato_id=ct.id)")->fetchAll(PDO::FETCH_COLUMN));
        }
        for ($i = 0; $i < $n; $i++) {
            $comp = date('Y-m', strtotime(date('Y-m-01') . " +$i month"));
            $ri = ws_faturar_mes($db, $comp, $autoEmit, $somente, $excluir);
            foreach (['criadas', 'puladas', 'emitidas', 'erros'] as $k) $r[$k] += $ri[$k];
            $r['meses'][] = $comp;
        }
    } elseif ($rc['manter_carne'] && (int)$rc['auto_parcelas_carne'] > 0) {
        $r['carnes'] = ws_manter_carnes($db, (int)$rc['auto_parcelas_carne'], $semAdic);
    }
    return $r;
}

/** TROCA DO DIA DE VENCIMENTO DO CONTRATO (15/10/2026): os títulos em ABERTO (mensalidade, vencimento de hoje em diante) passam para o novo dia, no mês de cada um (dia limitado ao fim do mês e ajustado por "Vence aos sábados"), como
 *  já acontece na troca de plano. Vencidos, pagos e títulos cuja nova data já passou não mudam. Os já emitidos no CelCash entram numa fila (cache/redata_fila.json): o cron altera a data lá (PUT payDay) e atualiza linha digitável/PIX.
 *  Título emitido na Lytex só muda aqui (a Lytex é alterada no painel dela) e o aviso fica no Log. Devolve ['alterados','fila','mantidos','lytex']. */
function ws_contrato_redatar_titulos(PDO $db, int $contratoId, int $novoDia): array {
    $r = ['alterados' => 0, 'fila' => 0, 'mantidos' => 0, 'lytex' => 0]; if ($contratoId <= 0 || $novoDia < 1 || $novoDia > 31) return $r;
    $q = $db->prepare("SELECT id, cliente_id, competencia, vencimento, celcash_charge_id, lytex_id, celcash_my_id FROM ws_fatura WHERE contrato_id=? AND status='aberto' AND (categoria IS NULL OR categoria='' OR categoria='mensalidade') AND vencimento >= CURDATE() ORDER BY vencimento, id");
    $q->execute([$contratoId]); $fila = [];
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $f) {
        $mes = preg_match('/^\d{4}-\d{2}$/', (string)$f['competencia']) ? (string)$f['competencia'] : substr((string)$f['vencimento'], 0, 7);
        [$a, $m] = array_map('intval', explode('-', $mes)); $dia = min($novoDia, (int)date('t', mktime(0, 0, 0, $m, 1, $a)));
        $nova = ws_venc_ajustar(sprintf('%04d-%02d-%02d', $a, $m, $dia));
        if ($nova === substr((string)$f['vencimento'], 0, 10)) continue;
        if ($nova < date('Y-m-d')) { $r['mantidos']++; continue; }
        $db->prepare("UPDATE ws_fatura SET vencimento=? WHERE id=? AND status='aberto'")->execute([$nova, (int)$f['id']]); $r['alterados']++;
        $ch = trim((string)$f['celcash_charge_id']);
        if (trim((string)$f['lytex_id']) !== '') { $r['lytex']++; ws_evento($db, (int)$f['cliente_id'], 'fatura', 'Vencimento do título #' . (int)$f['id'] . ' mudou para ' . date('d/m/Y', strtotime($nova)) . ' — o boleto já emitido na Lytex continua com a data antiga: altere/reemita no painel da Lytex.'); }
        elseif ($ch !== '' && ctype_digit($ch)) { $fila[] = ['fid' => (int)$f['id'], 'cid' => (int)$f['cliente_id'], 'charge' => $ch, 'my' => (string)$f['celcash_my_id'], 'nova' => $nova, 'tent' => 0]; $r['fila']++; }
    }
    if ($fila) {
        $arq = WS_CACHE . '/redata_fila.json'; $fh = @fopen($arq, 'c+');
        if ($fh && flock($fh, LOCK_EX)) { $cur = json_decode((string)stream_get_contents($fh), true); if (!is_array($cur)) $cur = [];
            foreach ($fila as $x) { $cur = array_values(array_filter($cur, fn($y) => (int)$y['fid'] !== $x['fid'])); $cur[] = $x; }   // nova troca no mesmo título substitui a anterior
            ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($cur)); flock($fh, LOCK_UN); }
        if ($fh) fclose($fh); @chmod($arq, 0640);
    }
    return $r;
}
/** Contratos de clientes ADICIONAIS (titular_id aponta para outro cliente). */
function ws_contratos_adicionais(PDO $db): array {
    try {
        return array_map('intval', $db->query("SELECT ct.id FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                                                 WHERE c.titular_id IS NOT NULL AND c.titular_id > 0 AND c.titular_id <> c.id")->fetchAll(PDO::FETCH_COLUMN));
    } catch (Throwable $e) { return []; }   // banco sem titular_id: ninguém é adicional
}

/** Gera carnê novo (N parcelas) para contrato ativo que já teve fatura e ficou sem nenhuma em aberto.
 *  $semAdicionais = true → cliente adicional fica de fora (Auto lançamento para adicionais = Não). */
function ws_manter_carnes(PDO $db, int $parcelas, bool $semAdicionais = false): int {
    $excluir = $semAdicionais ? ws_contratos_adicionais($db) : [];
    $cts = $db->query("SELECT ct.*, p.valor pvalor FROM ws_contrato ct LEFT JOIN ws_plano p ON p.id=ct.plano_id
                       WHERE ct.status='ativo'
                         AND EXISTS(SELECT 1 FROM ws_fatura f WHERE f.contrato_id=ct.id)
                         AND NOT EXISTS(SELECT 1 FROM ws_fatura f WHERE f.contrato_id=ct.id AND f.status IN('aberto','vencido','processando'))")->fetchAll();
    $carnes = 0;
    $ins = $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,status,celcash_my_id) VALUES (?,?,?,?,?, 'aberto', ?)");
    $ja  = $db->prepare("SELECT COUNT(*) FROM ws_fatura WHERE contrato_id=? AND competencia=?");
    foreach ($cts as $ct) {
        if ($excluir && in_array((int)$ct['id'], $excluir, true)) continue;
        $valor = (float)($ct['valor'] ?: $ct['pvalor'] ?: 0);
        if ($valor <= 0) continue;
        $dia = (int)($ct['dia_vencimento'] ?: 10);
        $base = strtotime(date('Y-m-01') . ' +1 month');       // começa no mês seguinte
        $geradas = 0;
        for ($i = 0; $i < $parcelas; $i++) {
            $m = strtotime(date('Y-m-01', $base) . " +$i month");
            $comp = date('Y-m', $m);
            $ja->execute([$ct['id'], $comp]); if ((int)$ja->fetchColumn() > 0) continue;
            $venc = ws_venc_ajustar(sprintf('%s-%02d', $comp, min($dia, (int)date('t', $m))));
            $ins->execute([$ct['id'], $ct['cliente_id'], $comp, $venc, $valor, 'ws-' . $ct['id'] . '-' . str_replace('-', '', $comp) . '-' . substr(uniqid(), -4)]);
            $geradas++;
        }
        if ($geradas) { $carnes++; ws_evento($db, (int)$ct['cliente_id'], 'fatura', "Carnê automático: $geradas parcela(s) geradas (Manter carnês)"); }
    }
    return $carnes;
}