<?php
/**
 * WellSystem — Fiscal / NFSe. Cadastro do emissor (qualquer cidade), emissão e histórico.
 * Reaproveita a sessão do erp.php.
 */
require __DIR__ . '/config.php';
require __DIR__ . '/nfse.php';

if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
if (!ws_pode_configurar()) { http_response_code(403); exit('Sem permissão. O Fiscal é só para nível 3 ou root.'); }   // 14/11/2026: nível 1 e 2 não usam o Fiscal
$db = ws_db();
if (empty($_SESSION['ws_fiscal_heal'])) { try { ws_selfheal($db); } catch (Throwable $e) {} $_SESSION['ws_fiscal_heal'] = 1; }   // 13/11/2026: colunas/tabelas novas do Fiscal (ex.: ws_nota.regime) nascem sozinhas, uma vez por sessão
$p  = $_GET['p'] ?? 'notas';
require_once __DIR__ . '/fiscal_produtos.php';   // 13/11/2026: cadastro de produtos + NCM oficial (NF-e)
require_once __DIR__ . '/fiscal_tomadores.php';   // 13/11/2026: cadastro de tomadores + busca das notas (ações de POST rodam no include)

/* ------------------------------------------------------------- ACTIONS */
require_once __DIR__ . '/pix.php';   // QR do PIX pela chave da conta (sem API)
if (($_POST['acao'] ?? '') === 'salvar_conta_pix') {   // 18/11/2026: conta do PIX cadastrada no próprio Fiscal (edição isolada)
    $id = (int)($_POST['id'] ?? 0); $nome = trim((string)($_POST['nome'] ?? ''));
    if ($nome === '') { $_SESSION['ws_flash'] = 'Informe o nome da conta.'; header('Location: fiscal.php?p=contas' . ($id ? '&id=' . $id : '')); exit; }
    $tp = in_array($_POST['tipo_chave'] ?? '', ['aleatoria', 'telefone', 'cpf', 'cnpj', 'email'], true) ? $_POST['tipo_chave'] : 'aleatoria';
    $v = [$nome, trim((string)($_POST['titular'] ?? '')), trim((string)($_POST['pix'] ?? '')), $tp, isset($_POST['ativo']) ? 1 : 0];
    try {
        if ($id) { $v[] = $id; $db->prepare("UPDATE ws_banco SET nome=?, titular=?, pix=?, tipo_chave=?, ativo=? WHERE id=?")->execute($v); }
        else { $db->prepare("INSERT INTO ws_banco (nome, titular, pix, tipo_chave, ativo, emissao) VALUES (?,?,?,?,?, 'proprio')")->execute($v); $id = (int)$db->lastInsertId(); }
        $_SESSION['ws_flash'] = 'Conta salva.';
    } catch (Throwable $ex) { $_SESSION['ws_flash'] = 'Erro ao salvar a conta: ' . $ex->getMessage(); }
    header('Location: fiscal.php?p=contas&id=' . $id); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_api_cobranca') {   // 18/11/2026: API de cobrança (CelCoin/GalaxPay) cadastrada no próprio Fiscal
    require_once __DIR__ . '/celcash.php';
    $cfgN = ['ambiente' => (($_POST['ambiente'] ?? 'sandbox') === 'producao') ? 'producao' : 'sandbox', 'galaxId' => trim((string)($_POST['galaxId'] ?? '')), 'galaxHash' => trim((string)($_POST['galaxHash'] ?? ''))];
    if ($cfgN['galaxHash'] === '') unset($cfgN['galaxHash']);   // campo de senha em branco = manter o que já está salvo
    ws_celcash_salvar($cfgN);
    try {   // a nota escolhe a conta de emissão por API entre as contas cadastradas: garante uma, se a API ficou configurada
        $c = ws_celcash_config();
        if (trim((string)$c['galaxId']) !== '' && trim((string)$c['galaxHash']) !== '') {
            $ex = (int)$db->query("SELECT COUNT(*) FROM ws_banco WHERE emissao='gateway'")->fetchColumn();
            if (!$ex) $db->prepare("INSERT INTO ws_banco (nome, titular, pix, tipo_chave, ativo, emissao) VALUES ('CelCoin/GalaxPay (API)', '', '', 'aleatoria', 1, 'gateway')")->execute();
        }
    } catch (Throwable $ex) {}
    $_SESSION['ws_flash'] = 'API de cobrança salva.';
    if (($_POST['testar'] ?? '') !== '') {
        try { ws_celcash_token(); $_SESSION['ws_flash'] = 'Conexão com a CelCoin OK (' . ws_celcash_config()['ambiente'] . '): as credenciais autenticaram.'; }
        catch (Throwable $ex) { $_SESSION['ws_flash'] = 'Erro: a CelCoin recusou — ' . $ex->getMessage() . ' (confira Galax ID/Hash, o ambiente e se o IP deste servidor está liberado no painel da CelCoin).'; }
    }
    header('Location: fiscal.php?p=contas'); exit;
}
if (($_POST['acao'] ?? '') === 'excluir_conta_pix') {
    try { $db->prepare('DELETE FROM ws_banco WHERE id=?')->execute([(int)($_POST['id'] ?? 0)]); $_SESSION['ws_flash'] = 'Conta excluída.'; }
    catch (Throwable $ex) { $_SESSION['ws_flash'] = 'Erro ao excluir: ' . $ex->getMessage(); }
    header('Location: fiscal.php?p=contas'); exit;
}
if (($_POST['acao'] ?? '') === 'upload_logo_fiscal' && !empty($_FILES['logo']['tmp_name'])) {   // 11/11/2026: mesma logo do boleto/carnê (uploads/sistema/doc-logo.*), usada também no DANFE/DANFSe
    ws_api_exigir_edicao('fiscal.php?p=emissor');
    $f = $_FILES['logo']; $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp'], true)) { $_SESSION['ws_flash'] = '❌ Use PNG, JPG ou WEBP.'; }
    elseif ($f['size'] > 2 * 1024 * 1024) { $_SESSION['ws_flash'] = '❌ Logo maior que 2 MB.'; }
    elseif (!@getimagesize($f['tmp_name'])) { $_SESSION['ws_flash'] = '❌ Arquivo não é uma imagem válida.'; }
    else {
        if (!is_dir(WS_UP_SISTEMA)) @mkdir(WS_UP_SISTEMA, 0775, true);
        foreach (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: [] as $old) @unlink($old);
        $_SESSION['ws_flash'] = ws_mover_upload($f['tmp_name'], WS_UP_SISTEMA . '/doc-logo.' . $ext) ? '✅ Logo salva (vale para boleto, carnê e DANFE/DANFSe).' : '❌ Não consegui gravar em uploads/sistema/.';
    }
    header('Location: fiscal.php?p=emissor'); exit;
}
if (($_POST['acao'] ?? '') === 'remover_logo_fiscal') {
    ws_api_exigir_edicao('fiscal.php?p=emissor');
    foreach (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: [] as $old) @unlink($old);
    $_SESSION['ws_flash'] = '✅ Logo removida (os documentos voltam a usar a logo da marca do sistema).';
    header('Location: fiscal.php?p=emissor'); exit;
}
if (($_POST['acao'] ?? '') === 'enviar_cert') {
    ws_api_exigir_edicao('fiscal.php?p=emissor');
    require_once __DIR__ . '/nfse_nacional.php';
    $e = (!empty($_FILES['pfx']['tmp_name']) && is_uploaded_file($_FILES['pfx']['tmp_name'])) ? ws_nfsen_salvar_certificado($_FILES['pfx']['tmp_name'], (string)($_POST['cert_senha'] ?? '')) : 'Escolha o arquivo do certificado (.pfx).';
    $_SESSION['ws_flash'] = $e === '' ? 'Certificado salvo e conferido.' : $e;
    header('Location: fiscal.php?p=emissor'); exit;
}
if (($_POST['acao'] ?? '') === 'cancelar_nfse') {   // 11/11/2026: cancelamento da NFS-e Nacional (só nível 3+)
    if (!ws_pode_configurar()) { $_SESSION['ws_flash'] = 'Cancelar nota fiscal é só para nível 3 ou root.'; header('Location: fiscal.php?p=notas'); exit; }
    if (fs_prazo_cancelamento_vencido($db, 'ws_nfse', (int)($_POST['nfse_id'] ?? 0))) { $_SESSION['ws_flash'] = 'Prazo de cancelamento encerrado (vai até o último dia do mês da autorização).'; header('Location: fiscal.php?p=notas'); exit; }
    require_once __DIR__ . '/nfse_nacional.php';
    $r = ws_nfsen_cancelar($db, (int)($_POST['nfse_id'] ?? 0), (int)($_POST['c_motivo'] ?? 0), (string)($_POST['x_motivo'] ?? ''));
    $_SESSION['ws_flash'] = $r['ok'] ? 'Nota cancelada na Sefin Nacional.' : ('Erro: ' . $r['erro']);
    header('Location: fiscal.php?p=notas'); exit;
}
if (($_POST['acao'] ?? '') === 'cancelar_nfe55') {   // 11/11/2026: cancelamento da NF-e modelo 55 (evento 110111; só nível 3+)
    if (!ws_pode_configurar()) { $_SESSION['ws_flash'] = 'Cancelar nota fiscal é só para nível 3 ou root.'; header('Location: fiscal.php?p=notas'); exit; }
    if (fs_prazo_cancelamento_vencido($db, 'ws_nfe55', (int)($_POST['nfe55_id'] ?? 0))) { $_SESSION['ws_flash'] = 'Prazo de cancelamento encerrado (vai até o último dia do mês da autorização).'; header('Location: fiscal.php?p=notas'); exit; }
    require_once __DIR__ . '/nfe55.php';
    $r = ws_nfe55_cancelar($db, (int)($_POST['nfe55_id'] ?? 0), (string)($_POST['x_motivo'] ?? ''));
    $_SESSION['ws_flash'] = $r['ok'] ? 'NF-e cancelada na SEFAZ.' : ('Erro: ' . $r['erro']);
    header('Location: fiscal.php?p=notas'); exit;
}
if (($_POST['acao'] ?? '') === 'cancelar_nfcom') {   // 13/11/2026: cancelamento da NFCom modelo 62 (evento 110111; só nível 3+)
    if (!ws_pode_configurar()) { $_SESSION['ws_flash'] = 'Cancelar nota fiscal é só para nível 3 ou root.'; header('Location: fiscal.php?p=notas&aba=nfcom'); exit; }
    require_once __DIR__ . '/nfcom.php';
    $r = ws_nfcom_cancelar($db, (int)($_POST['nfcom_id'] ?? 0), (string)($_POST['x_motivo'] ?? ''));
    $_SESSION['ws_flash'] = $r['ok'] ? 'NFCom cancelada na SEFAZ.' : ('Erro: ' . $r['erro']);
    header('Location: fiscal.php?p=notas&aba=nfcom'); exit;
}
if (($_POST['acao'] ?? '') === 'excluir_nota') {   // 11/11/2026: só rascunho/erro (nota já enviada não se apaga, se cancela)
    ws_api_exigir_edicao('fiscal.php?p=notas');
    $r = ws_nota_excluir($db, (int)($_POST['nota_id'] ?? 0));
    $_SESSION['ws_flash'] = $r['ok'] ? 'Nota excluída.' : ('Erro: ' . $r['erro']);
    header('Location: fiscal.php?p=notas'); exit;
}
if (($_POST['acao'] ?? '') === 'enviar_email_nota') {   // 11/11/2026: manda o PDF (DANFE ou PDF do provedor) por e-mail ao cliente
    require_once __DIR__ . '/mailer.php'; require_once __DIR__ . '/nfe55_danfe.php';
    $nid = (int)($_POST['nota_id'] ?? 0);
    $st = $db->prepare("SELECT nt.*, c.nome, c.email FROM ws_nota nt JOIN ws_cliente c ON c.id=nt.cliente_id WHERE nt.id=?"); $st->execute([$nid]); $nota = $st->fetch();
    $destino = trim((string)($_POST['email_destino'] ?? '')) ?: trim((string)($nota['email'] ?? ''));
    if (!$nota) { $_SESSION['ws_flash'] = 'Nota não encontrada.'; }
    elseif ($destino === '' || !filter_var($destino, FILTER_VALIDATE_EMAIL)) { $_SESSION['ws_flash'] = 'Informe um e-mail válido (o cliente não tem e-mail cadastrado).'; }
    else {
        $pdfBytes = ''; $nomeArq = 'nota-' . $nid . '.pdf';
        if (!empty($nota['nfe55_id'])) { $r = ws_danfe_pdf($db, (int)$nota['nfe55_id']); if ($r) { $pdfBytes = $r['pdf']; $nomeArq = $r['nome']; } }
        elseif ($nota['tipo'] !== 'nfe') { $r = ws_nota_servico_pdf($db, $nid); if ($r) { $pdfBytes = $r['pdf']; $nomeArq = $r['nome']; } }
        if ($pdfBytes === '') { $_SESSION['ws_flash'] = 'Esta nota ainda não tem PDF para enviar (precisa estar autorizada).'; header('Location: fiscal.php?p=editar&id=' . $nid); exit; }
        [$ok, $info] = ws_email_anexo($destino, 'Nota fiscal — ' . ($nota['nome'] ?? ''), 'Segue em anexo a nota fiscal referente ao atendimento.', $nomeArq, $pdfBytes, 'application/pdf');
        $_SESSION['ws_flash'] = $ok ? ('E-mail enviado para ' . $destino . '.') : ('Falha ao enviar e-mail: ' . $info);
    }
    header('Location: fiscal.php?p=editar&id=' . $nid); exit;
}
/** Envia a nota (PDF) por WhatsApp — SEMPRE pela Wellnet-02 (API). @return array [ok, mensagem] */
function ws_nota_enviar_whatsapp(PDO $db, int $nid): array {
    require_once __DIR__ . '/whatsapp.php'; require_once __DIR__ . '/nfe55_danfe.php';
    $st = $db->prepare("SELECT nt.*, c.nome, c.telefone FROM ws_nota nt JOIN ws_cliente c ON c.id=nt.cliente_id WHERE nt.id=?"); $st->execute([$nid]); $nota = $st->fetch();
    if (!$nota) return [false, 'Nota não encontrada.'];
    if (trim((string)($nota['telefone'] ?? '')) === '') return [false, 'Cliente sem telefone cadastrado.'];
    if (!ws_msg_cliente_permitido($db, (int)$nota['cliente_id'])) return [false, 'Mensagem automática proibida para este cliente (desativado/cancelado).'];
    $pdfBytes = ''; $nomeArq = 'nota-' . $nid . '.pdf';
    if (!empty($nota['nfe55_id'])) { $r = ws_danfe_pdf($db, (int)$nota['nfe55_id']); if ($r) { $pdfBytes = $r['pdf']; $nomeArq = $r['nome']; } }
    elseif ($nota['tipo'] !== 'nfe') { $r = ws_nota_servico_pdf($db, $nid); if ($r) { $pdfBytes = $r['pdf']; $nomeArq = $r['nome']; } }
    if ($pdfBytes === '') return [false, 'Esta nota ainda não tem PDF para enviar (precisa estar autorizada).'];
    $r = ws_wa_documento((string)$nota['telefone'], $nomeArq, base64_encode($pdfBytes), ['evento' => 'nota_fiscal']);
    return ($r['ok'] ?? false) ? [true, 'Nota enviada pelo WhatsApp (Wellnet-02).'] : [false, 'Falha ao enviar pelo WhatsApp: ' . ($r['raw'] ?? 'erro desconhecido')];
}
if (($_POST['acao'] ?? '') === 'enviar_whatsapp_nota') {   // 11/11/2026: documento SEMPRE pela Wellnet-02 (API) — nunca pela 01
    $nid = (int)($_POST['nota_id'] ?? 0); [, $msg] = ws_nota_enviar_whatsapp($db, $nid);
    $_SESSION['ws_flash'] = $msg; header('Location: fiscal.php?p=editar&id=' . $nid); exit;
}
if (($_POST['acao'] ?? '') === 'notas_lote') {   // 12/11/2026: ações em lote na lista (WhatsApp, XML em ZIP, excluir) sobre as notas marcadas
    $ids = array_values(array_filter(array_map('intval', (array)($_POST['ids'] ?? []))));
    $volta = 'fiscal.php?p=notas&aba=' . urlencode((string)($_POST['aba'] ?? 'nfse'));
    $a = (string)($_POST['lote_acao'] ?? '');
    if (!$ids) { $_SESSION['ws_flash'] = 'Marque ao menos uma nota.'; header('Location: ' . $volta); exit; }
    if ($a === 'whatsapp') {
        $ok = 0; $falhas = [];
        foreach ($ids as $i) { [$o, $m] = ws_nota_enviar_whatsapp($db, $i); if ($o) $ok++; else $falhas[] = '#' . $i . ': ' . $m; }
        $_SESSION['ws_flash'] = $ok . ' nota(s) enviada(s) por WhatsApp.' . ($falhas ? ' Não enviadas — ' . implode(' | ', array_slice($falhas, 0, 3)) : '');
    } elseif ($a === 'excluir') {
        ws_api_exigir_edicao($volta); $ok = 0; $falhas = [];
        foreach ($ids as $i) { $r = ws_nota_excluir($db, $i); if ($r['ok']) $ok++; else $falhas[] = '#' . $i . ': ' . $r['erro']; }
        $_SESSION['ws_flash'] = $ok . ' nota(s) excluída(s).' . ($falhas ? ' Não excluídas — ' . implode(' | ', array_slice($falhas, 0, 3)) : '');
    } elseif ($a === 'xml') {
        $in = implode(',', $ids); $arqs = [];
        foreach ($db->query("SELECT nfe55_id, nfse_id, nfcom_id FROM ws_nota WHERE id IN ($in)")->fetchAll() as $n) {
            foreach ([['ws_nfe55', 'nfe55_id'], ['ws_nfse', 'nfse_id'], ['ws_nfcom', 'nfcom_id']] as [$tb, $col]) if (!empty($n[$col])) {
                $u = $db->query("SELECT url_xml FROM $tb WHERE id=" . (int)$n[$col])->fetchColumn(); $p = $u ? __DIR__ . '/' . ltrim((string)$u, '/') : '';
                if ($p && is_file($p)) $arqs[] = $p;
            }
        }
        if (!$arqs) { $_SESSION['ws_flash'] = 'As notas marcadas não têm XML autorizado para baixar.'; }
        else {
            $tmp = tempnam(sys_get_temp_dir(), 'wsx'); $zip = new ZipArchive();
            if ($zip->open($tmp, ZipArchive::OVERWRITE) === true) { foreach ($arqs as $p) $zip->addFile($p, basename($p)); $zip->close();
                header('Content-Type: application/zip'); header('Content-Disposition: attachment; filename="xml-notas-' . date('Ymd-His') . '.zip"'); readfile($tmp); @unlink($tmp); exit; }
            $_SESSION['ws_flash'] = 'Não consegui compactar os XML.';
        }
    }
    header('Location: ' . $volta); exit;
}
/* --------------------------------------------- ARQUIVOS XML (12/11/2026): pasta própria por tipo, seleção, baixar/excluir/enviar --------------------------------------------- */
function ws_arquivos_tipos(): array { return ['nfse' => '🧾 NFS-e · Serviço', 'nfcom' => '📡 NFCom · Internet (mod. 62)', 'nfe' => '📦 NF-e · Venda (mod. 55)']; }
/** Caminho seguro dentro de cache/notas_xml/<tipo>/<arquivo> — nunca sai da pasta (sem ../). */
function ws_arquivo_xml_caminho(string $tipo, string $arquivo): ?string {
    if (!array_key_exists($tipo, ws_arquivos_tipos())) return null;
    $arquivo = basename($arquivo);   // tira qualquer path traversal
    if ($arquivo === '' || !preg_match('/^[A-Za-z0-9_.\-]+\.(xml|json)$/', $arquivo)) return null;
    $full = WS_CACHE . "/notas_xml/$tipo/$arquivo";
    return is_file($full) ? $full : null;
}
if (($_POST['acao'] ?? '') === 'arquivos_excluir') {
    if (!ws_pode_configurar()) { $_SESSION['ws_flash'] = 'Excluir arquivo fiscal é só para nível 3 ou root.'; }
    else {
        $tipo = (string)($_POST['tipo'] ?? ''); $n = 0;
        foreach ((array)($_POST['arq'] ?? []) as $a) { $f = ws_arquivo_xml_caminho($tipo, (string)$a); if ($f && @unlink($f)) $n++; }
        $_SESSION['ws_flash'] = $n > 0 ? ($n . ' arquivo(s) excluído(s).') : 'Nenhum arquivo foi excluído.';
    }
    header('Location: fiscal.php?p=arquivos&tipo=' . urlencode((string)($_POST['tipo'] ?? ''))); exit;
}
if (($_POST['acao'] ?? '') === 'arquivos_enviar_email') {
    require_once __DIR__ . '/mailer.php';
    $tipo = (string)($_POST['tipo'] ?? ''); $destino = trim((string)($_POST['email_destino'] ?? ''));
    if ($destino === '' || !filter_var($destino, FILTER_VALIDATE_EMAIL)) { $_SESSION['ws_flash'] = 'Informe um e-mail válido.'; }
    else {
        $arquivos = []; foreach ((array)($_POST['arq'] ?? []) as $a) { $f = ws_arquivo_xml_caminho($tipo, (string)$a); if ($f) $arquivos[] = $f; }
        if (!$arquivos) { $_SESSION['ws_flash'] = 'Selecione ao menos um arquivo.'; }
        elseif (count($arquivos) === 1) {
            [$ok, $info] = ws_email_anexo($destino, 'XML fiscal — ' . basename($arquivos[0]), 'Segue em anexo o arquivo XML solicitado.', basename($arquivos[0]), (string)file_get_contents($arquivos[0]), 'application/xml');
            $_SESSION['ws_flash'] = $ok ? ('E-mail enviado para ' . $destino . '.') : ('Falha ao enviar e-mail: ' . $info);
        } else {
            $tmp = tempnam(sys_get_temp_dir(), 'wsx'); $zip = new ZipArchive();
            if ($zip->open($tmp, ZipArchive::OVERWRITE) === true) {
                foreach ($arquivos as $f) $zip->addFile($f, basename($f));
                $zip->close();
                [$ok, $info] = ws_email_anexo($destino, 'XMLs fiscais — ' . count($arquivos) . ' arquivo(s)', 'Seguem em anexo (compactados) os arquivos XML selecionados.', 'xmls-' . date('Ymd-His') . '.zip', (string)file_get_contents($tmp), 'application/zip');
                $_SESSION['ws_flash'] = $ok ? ('E-mail enviado para ' . $destino . '.') : ('Falha ao enviar e-mail: ' . $info);
            } else { $_SESSION['ws_flash'] = 'Não consegui compactar os arquivos.'; }
            @unlink($tmp);
        }
    }
    header('Location: fiscal.php?p=arquivos&tipo=' . urlencode($tipo)); exit;
}
if (($_POST['acao'] ?? '') === 'arquivos_enviar_whatsapp') {   // 12/11/2026: XML selecionado vai ao cliente da nota, SEMPRE pela Wellnet-02 (API)
    require_once __DIR__ . '/whatsapp.php';
    $tipo = (string)($_POST['tipo'] ?? ''); $ok = 0; $falhas = [];
    foreach ((array)($_POST['arq'] ?? []) as $a) {
        $f = ws_arquivo_xml_caminho($tipo, (string)$a); if (!$f || substr($f, -4) !== '.xml') { $falhas[] = basename((string)$a) . ': arquivo inválido'; continue; }
        $chave = preg_replace('/\D/', '', basename($f, '.xml'));
        $q = $db->prepare("SELECT c.id cid, c.telefone FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id
            WHERE n.nfe55_id IN (SELECT id FROM ws_nfe55 WHERE chave_acesso=?) OR n.nfcom_id IN (SELECT id FROM ws_nfcom WHERE chave_acesso=?) OR n.nfse_id IN (SELECT id FROM ws_nfse WHERE codigo_verificacao=?) LIMIT 1");
        $q->execute([$chave, $chave, $chave]); $cl = $q->fetch();
        if (!$cl) { $falhas[] = basename($f) . ': nota/cliente não encontrado'; continue; }
        if (trim((string)$cl['telefone']) === '') { $falhas[] = basename($f) . ': cliente sem telefone'; continue; }
        if (!ws_msg_cliente_permitido($db, (int)$cl['cid'])) { $falhas[] = basename($f) . ': cliente desativado/cancelado'; continue; }
        $r = ws_wa_documento((string)$cl['telefone'], basename($f), base64_encode((string)file_get_contents($f)), ['evento' => 'nota_fiscal']);
        if ($r['ok'] ?? false) $ok++; else $falhas[] = basename($f) . ': falha no envio';
    }
    $_SESSION['ws_flash'] = $ok . ' arquivo(s) enviado(s) por WhatsApp (Wellnet-02).' . ($falhas ? ' Não enviados — ' . implode(' | ', array_slice($falhas, 0, 3)) : '');
    header('Location: fiscal.php?p=arquivos&tipo=' . urlencode($tipo)); exit;
}
if (($_POST['acao'] ?? '') === 'arquivos_baixar_zip') {
    $tipo = (string)($_POST['tipo'] ?? ''); $arquivos = [];
    foreach ((array)($_POST['arq'] ?? []) as $a) { $f = ws_arquivo_xml_caminho($tipo, (string)$a); if ($f) $arquivos[] = $f; }
    if (!$arquivos) { $_SESSION['ws_flash'] = 'Selecione ao menos um arquivo.'; header('Location: fiscal.php?p=arquivos&tipo=' . urlencode($tipo)); exit; }
    if (count($arquivos) === 1) { header('Content-Type: application/xml'); header('Content-Disposition: attachment; filename="' . basename($arquivos[0]) . '"'); readfile($arquivos[0]); exit; }
    $tmp = tempnam(sys_get_temp_dir(), 'wsx'); $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) === true) {
        foreach ($arquivos as $f) $zip->addFile($f, basename($f));
        $zip->close();
        header('Content-Type: application/zip'); header('Content-Disposition: attachment; filename="xmls-' . $tipo . '-' . date('Ymd-His') . '.zip"');
        readfile($tmp); @unlink($tmp); exit;
    }
    $_SESSION['ws_flash'] = 'Não consegui compactar os arquivos.'; header('Location: fiscal.php?p=arquivos&tipo=' . urlencode($tipo)); exit;
}
if (($_POST['acao'] ?? '') === 'arquivos_baixar_txt') {   // 13/11/2026: cópia LEGÍVEL do XML para abrir no Bloco de Notas (.txt, UTF-8 com BOM, indentado). Só para leitura: o XML original (assinado) continua em "Baixar selecionados".
    $tipo = (string)($_POST['tipo'] ?? ''); $arquivos = [];
    foreach ((array)($_POST['arq'] ?? []) as $a) { $f = ws_arquivo_xml_caminho($tipo, (string)$a); if ($f) $arquivos[] = $f; }
    if (!$arquivos) { $_SESSION['ws_flash'] = 'Selecione ao menos um arquivo.'; header('Location: fiscal.php?p=arquivos&tipo=' . urlencode($tipo)); exit; }
    $nl = chr(13) . chr(10); $txt = chr(239) . chr(187) . chr(191);   // BOM UTF-8 + CRLF: o Bloco de Notas lê acento certo e quebra linha
    foreach ($arquivos as $f) {
        $bruto = (string)file_get_contents($f); $dom = new DOMDocument('1.0', 'UTF-8'); $dom->preserveWhiteSpace = false; $dom->formatOutput = true;
        $leg = @$dom->loadXML($bruto) ? (string)$dom->saveXML() : $bruto;
        $txt .= '===== ' . basename($f) . ' =====' . $nl . str_replace([chr(13) . chr(10), chr(10)], $nl, $leg) . $nl . $nl;
    }
    header('Content-Type: text/plain; charset=utf-8'); header('Content-Disposition: attachment; filename="' . (count($arquivos) === 1 ? basename($arquivos[0], '.xml') : 'xmls-' . $tipo . '-' . date('Ymd-His')) . '.txt"'); header('Content-Length: ' . strlen($txt));
    echo $txt; exit;
}
if (($_GET['p'] ?? '') === 'clientes_json') {   // 12/11/2026: busca rápida de cliente ATIVO para o formulário de nota (lista com nome, CPF/CNPJ e ID)
    $q = trim((string)($_GET['q'] ?? '')); $dig = preg_replace('/\D/', '', $q); $lista = [];
    try {
        $st = $db->prepare("SELECT id, nome, cpf_cnpj FROM ws_cliente WHERE status='ativo' AND (? = '' OR nome LIKE ? OR id = ? OR (? <> '' AND REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/','') LIKE ?)) ORDER BY nome LIMIT 12");
        $st->execute([$q, '%' . $q . '%', ctype_digit($q) ? (int)$q : -1, $dig, '%' . $dig . '%']);
        $lista = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
    header('Content-Type: application/json; charset=utf-8'); echo json_encode($lista, JSON_UNESCAPED_UNICODE); exit;
}
if (($_GET['p'] ?? '') === 'danfse') {
    require_once __DIR__ . '/nfse_nacional.php';
    [$ok, $erro, $pdf] = ws_nfsen_danfse($db, (int)($_GET['id'] ?? 0));
    if ($ok) { header('Content-Type: application/pdf'); header('Content-Disposition: inline; filename="nfse-' . (int)$_GET['id'] . '.pdf"'); echo $pdf; exit; }
    $_SESSION['ws_flash'] = 'PDF: ' . $erro; header('Location: fiscal.php?p=notas'); exit;
}
if (($_GET['p'] ?? '') === 'notapdf') {   // 12/11/2026: documento auxiliar (NFS-e/NFCom) no leiaute do DANFE
    require_once __DIR__ . '/nfe55_danfe.php';
    $r = ws_nota_servico_pdf($db, (int)($_GET['id'] ?? 0));
    if ($r) { header('Content-Type: application/pdf'); header('Content-Disposition: inline; filename="' . $r['nome'] . '"'); echo $r['pdf']; exit; }
    $_SESSION['ws_flash'] = 'Documento indisponível para esta nota.'; header('Location: fiscal.php?p=notas'); exit;
}
if (($_GET['p'] ?? '') === 'danfe') {   // 11/11/2026: DANFE (NF-e modelo 55) em PDF, gerado no próprio servidor
    require_once __DIR__ . '/nfe55_danfe.php';
    $r = ws_danfe_pdf($db, (int)($_GET['id'] ?? 0));
    if ($r) { header('Content-Type: application/pdf'); header('Content-Disposition: inline; filename="' . $r['nome'] . '"'); echo $r['pdf']; exit; }
    $_SESSION['ws_flash'] = 'DANFE indisponível para esta nota (só nota de NF-e autorizada tem DANFE).'; header('Location: fiscal.php?p=notas'); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_emissor') {
    ws_api_exigir_edicao('fiscal.php?p=emissor');   // níveis 1 e 2: consultam, não gravam
    $campos = ['provider','ambiente','api_url','api_token','razao_social','cnpj','inscricao_municipal','inscricao_estadual','regime',
               'cidade','uf','cod_ibge','cep','logradouro','numero','bairro','telefone','email',
               'cod_servico','cnae','aliquota_iss','descricao_padrao','nfsen_ctribnac','nfsen_cnbs','nfsen_serie','nfsen_algoritmo',
               'nfe_serie','nfe_cfop','nfe_csosn','nfe_ncm_padrao','nfe_cest_padrao','nfe_natureza','pct_trib_nfe','pct_trib_nfse','pct_trib_nfcom','nfcom_icms_pct','nfcom_pis_pct','nfcom_cofins_pct','nfcom_fust_pct','nfcom_funttel_pct'];
    $cfg = [];
    foreach ($campos as $c) $cfg[$c] = trim($_POST[$c] ?? '');
    $cfg['regime'] = ws_regime_valido((string)($cfg['regime'] ?? 'simples'));   // 13/11/2026: simples (padrão) | mei | presumido | real
    foreach (['nfcom_icms_pct', 'nfcom_pis_pct', 'nfcom_cofins_pct', 'nfcom_fust_pct', 'nfcom_funttel_pct'] as $kp) $cfg[$kp] = (string)max(0, min(100, (float)str_replace(',', '.', (string)$cfg[$kp])));
    $cfg['iss_retido'] = isset($_POST['iss_retido']);
    ws_nfse_salvar($cfg);
    header('Location: fiscal.php?p=emissor&ok=1'); exit;
}
if (($_POST['acao'] ?? '') === 'ajustar_numeracao') {   // 12/11/2026: corrigir o PRÓXIMO número (produção) quando já existe histórico real emitido fora do WellSystem — só nível 3+/root, é dado fiscal sensível
    if (!ws_pode_configurar()) { $_SESSION['ws_flash'] = 'Ajustar numeração fiscal é só para nível 3 ou root.'; header('Location: fiscal.php?p=emissor'); exit; }
    $cfg = [];
    foreach (['nfe_proximo', 'nfsen_proximo', 'nfcom_proximo'] as $k) if (trim((string)($_POST[$k] ?? '')) !== '') $cfg[$k] = max(1, (int)$_POST[$k]);
    if ($cfg) { ws_nfse_salvar($cfg); $_SESSION['ws_flash'] = 'Numeração ajustada.'; } else { $_SESSION['ws_flash'] = 'Nada para ajustar.'; }
    header('Location: fiscal.php?p=emissor'); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_obs_interna') {   // 11/11/2026: pode salvar mesmo com a nota já enviada (é só anotação do time, não altera o documento fiscal)
    ws_api_exigir_edicao('fiscal.php?p=editar&id=' . (int)($_POST['nota_id'] ?? 0));
    require_once __DIR__ . '/nfse.php';
    ws_nota_obs_interna_salvar($db, (int)($_POST['nota_id'] ?? 0), trim((string)($_POST['observacao_interna'] ?? '')));
    $_SESSION['ws_flash'] = 'Observação interna salva.'; header('Location: fiscal.php?p=editar&id=' . (int)($_POST['nota_id'] ?? 0)); exit;
}
if (($_GET['emitir'] ?? '') !== '') {
    $fid = (int)$_GET['emitir'];
    $st = $db->prepare("SELECT f.*, c.* , f.id fid FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE f.id=?");
    $st->execute([$fid]); $row = $st->fetch();
    if ($row) {
        /* Endereço do TOMADOR vem do cadastro normalizado. Endereço errado ou em branco numa
         * NFS-e é problema com a prefeitura, não detalhe de tela — por isso não pode sair de texto
         * digitado livremente, uma vez por cliente. */
        require_once __DIR__ . '/schema_endereco.php';
        $r = ws_nfse_emitir($db, ['id' => $row['fid'], 'valor' => $row['valor']], ws_end_enriquecer($db, $row));
        $_SESSION['ws_flash'] = $r['ok'] ? 'NFSe enviada ao provedor.' : ('Erro: ' . $r['erro']);
    }
    header('Location: fiscal.php?p=notas'); exit;
}

if (($_POST['acao'] ?? '') === 'emitir_rascunho') {   // 13/11/2026: emitir o rascunho direto da lista (a confirmação com os dados aparece antes, no navegador)
    ws_api_exigir_edicao('fiscal.php?p=notas');
    $nidE = (int)($_POST['nota_id'] ?? 0); $r = ws_nota_emitir($db, $nidE);
    $_SESSION['ws_flash'] = $r['ok'] ? 'Nota tramitada com sucesso.' : ('Erro: ' . $r['erro']);
    $tp = (string)$db->query("SELECT tipo FROM ws_nota WHERE id=" . $nidE)->fetchColumn();
    header('Location: fiscal.php?p=notas&aba=' . ($tp ?: 'nfse')); exit;
}
if (($_POST['acao'] ?? '') === 'duplicar_nota') {   // 13/11/2026: usa uma nota salva como modelo — copia cliente, tipo, observação e itens para um RASCUNHO novo (nunca copia a fatura nem os dados de emissão)
    ws_api_exigir_edicao('fiscal.php?p=notas');
    $orig = (int)($_POST['nota_id'] ?? 0); $qn = $db->prepare("SELECT * FROM ws_nota WHERE id=?"); $qn->execute([$orig]); $on = $qn->fetch();
    if (!$on) { $_SESSION['ws_flash'] = 'Nota não encontrada.'; header('Location: fiscal.php?p=notas'); exit; }
    $qa = $db->prepare("SELECT status FROM ws_cliente WHERE id=?"); $qa->execute([(int)$on['cliente_id']]); $stCli = (string)$qa->fetchColumn();
    $cliCopia = ($stCli === '' || $stCli === 'ativo') ? (int)$on['cliente_id'] : 0;
    if ($cliCopia <= 0) { $_SESSION['ws_flash'] = 'O cliente desta nota não está mais ativo: escolha outro cliente na nota nova.'; }
    $novo = ws_nota_salvar($db, null, $cliCopia > 0 ? $cliCopia : (int)$on['cliente_id'], null, (string)$on['tipo'], (string)$on['observacao'], ws_nota_itens($db, $orig), (string)($_SESSION['ws_user']['nome'] ?? $_SESSION['ws_user']['usuario'] ?? ''));
    if ($cliCopia > 0) $_SESSION['ws_flash'] = 'Nota #' . $orig . ' copiada para o rascunho #' . $novo . '. Altere o que precisar e use "Salvar e emitir" quando estiver certo.';
    header('Location: fiscal.php?p=editar&id=' . $novo); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_nota' || ($_POST['acao'] ?? '') === 'emitir_nota') {
    ws_api_exigir_edicao('fiscal.php?p=notas');   // níveis 1 e 2: consultam, não gravam
    $nid = (int)($_POST['nota_id'] ?? 0) ?: null;
    /* cliente: ID, nome ou CPF/CNPJ digitado; precisa achar UM só */
    $busca = trim((string)($_POST['cliente_busca'] ?? '')); $cid = (int)($_POST['cliente_id'] ?? 0);
    if ($cid <= 0 && $busca !== '') {
        if (ctype_digit($busca) && strlen($busca) < 9) $cid = (int)$busca;
        else {
            $q = $db->prepare("SELECT id FROM ws_cliente WHERE status='ativo' AND (nome LIKE ? OR REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/','') = ?) LIMIT 3");
            $q->execute(['%' . $busca . '%', preg_replace('/\D/', '', $busca)]); $ach = $q->fetchAll(PDO::FETCH_COLUMN);
            if (count($ach) === 1) $cid = (int)$ach[0];
            else { $_SESSION['ws_flash'] = count($ach) ? 'Mais de um cliente ATIVO com esse nome: digite o ID ou o CPF/CNPJ.' : 'Cliente não encontrado (ou não está ativo — nota fiscal é só para cliente ativo).'; header('Location: fiscal.php?p=' . ($nid ? 'editar&id=' . $nid : 'nova')); exit; }
        }
    }
    // Nota fiscal é só para cliente ATIVO (cancelado/desativado fica fora, como em todo o sistema).
    if ($cid > 0) {
        $qa = $db->prepare("SELECT status FROM ws_cliente WHERE id=?"); $qa->execute([$cid]); $stCli = (string)$qa->fetchColumn();
        if ($stCli !== '' && $stCli !== 'ativo') { $_SESSION['ws_flash'] = 'Este cliente não está ativo: nota fiscal só pode ser emitida para cliente ativo.'; header('Location: fiscal.php?p=' . ($nid ? 'editar&id=' . $nid : 'nova')); exit; }
    }
    $itens = []; foreach ((array)($_POST['it_descricao'] ?? []) as $k => $d)
        $itens[] = ['descricao' => $d, 'tipo' => $_POST['it_tipo'][$k] ?? 'servico', 'qtd' => $_POST['it_qtd'][$k] ?? 1, 'valor_unit' => $_POST['it_valor'][$k] ?? 0, 'desconto' => $_POST['it_desc_valor'][$k] ?? 0,
                     'ncm' => $_POST['it_ncm'][$k] ?? '', 'cfop' => $_POST['it_cfop'][$k] ?? '', 'csosn' => $_POST['it_csosn'][$k] ?? '', 'cest' => $_POST['it_cest'][$k] ?? '', 'unidade' => $_POST['it_unid'][$k] ?? 'UN'];
    if ($cid <= 0) { $_SESSION['ws_flash'] = 'Informe o cliente.'; header('Location: fiscal.php?p=' . ($nid ? 'editar&id=' . $nid : 'nova')); exit; }
    $nid = ws_nota_salvar($db, $nid, $cid, (int)($_POST['fatura_id'] ?? 0) ?: null, (string)($_POST['tipo'] ?? 'nfse'), trim((string)($_POST['observacao'] ?? '')), $itens, (string)($_SESSION['ws_user']['nome'] ?? $_SESSION['ws_user']['usuario'] ?? ''));
    if (isset($_POST['regime'])) ws_nota_definir_regime($db, $nid, (string)$_POST['regime']);
    if (isset($_POST['banco_id'])) ws_nota_definir_banco($db, $nid, (int)$_POST['banco_id']);   // conta do PIX (0 = automático)
    if (isset($_POST['cobranca_campo'])) ws_nota_definir_cobranca($db, $nid, !isset($_POST['gerar_cobranca']));   // caixa 'Gerar cobrança no GalaxPay'   // 13/11/2026: regime próprio da nota (padrão = o do emissor)
    if ($_POST['acao'] === 'emitir_nota') {
        $r = ws_nota_emitir($db, $nid);
        $_SESSION['ws_flash'] = $r['ok'] ? 'Nota tramitada com sucesso.' : ('Erro: ' . $r['erro']);
    } else $_SESSION['ws_flash'] = 'Nota salva (rascunho).';
    header('Location: fiscal.php?p=editar&id=' . $nid); exit;
}

/** 13/11/2026: título que identifica a nota em qualquer página: "NFCom nº 2 · Nota #43 · CLIENTE" (sem número ainda = rascunho). Devolve texto puro (escapar na saída). */
function fs_titulo_nota(PDO $db, int $notaId): string {
    try { $q = $db->prepare("SELECT n.id, n.tipo, n.status, n.nfse_id, n.nfe55_id, n.nfcom_id, c.nome FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id WHERE n.id=?"); $q->execute([$notaId]); $n = $q->fetch(); } catch (Throwable $e) { return 'Nota #' . $notaId; }
    if (!$n) return 'Nota #' . $notaId;
    $rot = ['nfse' => 'NFS-e', 'nfcom' => 'NFCom', 'nfe' => 'NF-e'][$n['tipo']] ?? strtoupper((string)$n['tipo']); $num = '';
    try { foreach ([['nfcom', 'ws_nfcom', 'nfcom_id'], ['nfe', 'ws_nfe55', 'nfe55_id'], ['nfse', 'ws_nfse', 'nfse_id']] as [$tp, $tb, $col]) if ($n['tipo'] === $tp && !empty($n[$col])) { $r = $db->prepare("SELECT numero FROM $tb WHERE id=?"); $r->execute([(int)$n[$col]]); $num = (string)$r->fetchColumn(); } } catch (Throwable $e) {}
    return $rot . ($num !== '' ? ' nº ' . $num : ' (rascunho)') . ' · Nota #' . $n['id'] . ' · ' . $n['nome'];
}

/** 13/11/2026: descobre a qual nota pertence um arquivo XML guardado (pela chave no nome do arquivo). @return array{titulo:string,nota_id:int} */
function fs_nota_do_arquivo(PDO $db, string $tipo, string $nomeArq): array {
    $chave = preg_replace('/\D/', '', basename($nomeArq, '.xml')); $vazio = ['titulo' => '—', 'nota_id' => 0];
    $mapa = ['nfcom' => ['ws_nfcom', 'chave_acesso', 'nfcom_id'], 'nfe' => ['ws_nfe55', 'chave_acesso', 'nfe55_id'], 'nfse' => ['ws_nfse', 'codigo_verificacao', 'nfse_id']][$tipo] ?? null;
    if (!$mapa || $chave === '') return $vazio;
    try {
        $q = $db->prepare("SELECT d.numero, n.id nota_id FROM {$mapa[0]} d LEFT JOIN ws_nota n ON n.{$mapa[2]}=d.id WHERE REPLACE(d.{$mapa[1]}, ' ', '')=? LIMIT 1"); $q->execute([$chave]); $r = $q->fetch();
        if (!$r) return $vazio;
        if (!empty($r['nota_id'])) { $tt = fs_titulo_nota($db, (int)$r['nota_id']); $bs = '';
            try { $qb = $db->prepare("SELECT c.codigo, c.cpf_cnpj, n.total FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id WHERE n.id=?"); $qb->execute([(int)$r['nota_id']]); $b = $qb->fetch();
                  if ($b) $bs = $b['codigo'] . ' ' . $b['cpf_cnpj'] . ' ' . preg_replace('/[^0-9]/', '', (string)$b['cpf_cnpj']) . ' ' . number_format((float)$b['total'], 2, ',', '.') . ' ' . number_format((float)$b['total'], 2, '.', ''); } catch (Throwable $e) {}
            return ['titulo' => $tt, 'nota_id' => (int)$r['nota_id'], 'busca' => $bs]; }
        return ['titulo' => ['nfcom' => 'NFCom', 'nfe' => 'NF-e', 'nfse' => 'NFS-e'][$tipo] . ' nº ' . $r['numero'], 'nota_id' => 0];
    } catch (Throwable $e) { return $vazio; }
}

/** 13/11/2026: botão ENVIAR por linha (nota emitida): e-mail (com o e-mail do cliente já preenchido) ou WhatsApp pela Wellnet-02. */
function fs_enviar_html(PDO $db, int $notaId): string {
    try { $q = $db->prepare("SELECT nt.id, nt.status, c.email, c.telefone FROM ws_nota nt JOIN ws_cliente c ON c.id=nt.cliente_id WHERE nt.id=?"); $q->execute([$notaId]); $n = $q->fetch(); } catch (Throwable $e) { return ''; }
    if (!$n || !in_array($n['status'], ['enviada', 'autorizada'], true)) return '';
    $h = '<details style="display:inline-block;margin-left:8px"><summary class="ws-btn">📤 Enviar</summary><div class="ws-form" style="margin-top:4px">';
    $h .= '<form method="post" style="display:inline"><input type="hidden" name="acao" value="enviar_email_nota"><input type="hidden" name="nota_id" value="' . $notaId . '"><input type="email" name="email_destino" value="' . h((string)$n['email']) . '" placeholder="e-mail do cliente" style="width:220px"> <button class="ws-btn primary">Enviar e-mail</button></form> ';
    $h .= '<form method="post" style="display:inline" data-msg="Enviar esta nota por WhatsApp (Wellnet-02) ao cliente?" onsubmit="return confirm(this.getAttribute(&quot;data-msg&quot;))"><input type="hidden" name="acao" value="enviar_whatsapp_nota"><input type="hidden" name="nota_id" value="' . $notaId . '"><button class="ws-btn">WhatsApp</button></form>';
    return $h . '</div></details>';
}

/** 13/11/2026: prazo de cancelamento IGUAL para as 3 notas (regra do dono): vai até o último dia do mês em que a nota foi autorizada. true = já passou (botão Cancelar some e o status vira "Finalizada e Tramitada"). $tabela: ws_nfcom | ws_nfe55 | ws_nfse. */
function fs_prazo_cancelamento_vencido(PDO $db, string $tabela, int $id): bool {
    if (!in_array($tabela, ['ws_nfcom', 'ws_nfe55', 'ws_nfse'], true) || $id <= 0) return false;
    try { $q = $db->prepare("SELECT criado_em FROM $tabela WHERE id=?"); $q->execute([$id]); $cr = (string)$q->fetchColumn(); } catch (Throwable $e) { return false; }
    if ($cr === '') return false;
    require_once __DIR__ . '/nfcom.php';
    return new DateTime('now', new DateTimeZone('America/Sao_Paulo')) > ws_nfcom_prazo_cancelamento($cr);
}

/** 13/11/2026: rótulo do status na lista (só texto; o valor interno não muda). Nota enviada/autorizada = "Enviada e Tramitada" enquanto ainda dá para cancelar; quando o prazo de cancelamento acaba vira "Finalizada e Tramitada" (e o botão Cancelar desativa). */
function fs_status_rotulo(PDO $db, array $r, string $status, string $tipo): string {
    if (!in_array($status, ['enviada', 'autorizada'], true)) return $status;
    $tb = ['nfcom' => ['ws_nfcom', 'nfcom_id'], 'nfe' => ['ws_nfe55', 'nfe55_id'], 'nfse' => ['ws_nfse', 'nfse_id']][$tipo] ?? null;
    if ($tb && ($r['origem'] ?? '') === 'nota') {
        try { $q = $db->prepare("SELECT $tb[1] FROM ws_nota WHERE id=?"); $q->execute([(int)$r['id']]); $idDoc = (int)$q->fetchColumn(); if (fs_prazo_cancelamento_vencido($db, $tb[0], $idDoc)) return 'Finalizada e Tramitada'; } catch (Throwable $e) {}
    }
    return 'Enviada e Tramitada';
}

/** 13/11/2026: botão Cancelar ÚNICO para os 3 documentos (lista e tela da nota). Só nível 3+; só nota autorizada; NFCom trava depois do prazo. $notaId = ws_nota.id. */
function fs_cancelar_html(PDO $db, int $notaId): string {
    if (!ws_pode_configurar()) return '';
    try { $q = $db->prepare("SELECT * FROM ws_nota WHERE id=?"); $q->execute([$notaId]); $n = $q->fetch(); } catch (Throwable $e) { return ''; }
    if (!$n) return '';
    $campo = fn(string $nm, string $v) => '<input type="hidden" name="' . $nm . '" value="' . h($v) . '">';
    $motivo = '<input name="x_motivo" required minlength="15" maxlength="255" placeholder="Motivo (mínimo 15 caracteres)" style="width:260px"> <button class="ws-btn primary">Confirmar cancelamento</button>';
    $caixa = fn(string $aviso, string $acao, string $extra) => '<details style="display:inline-block;margin-left:8px"><summary class="ws-btn">⛔ Cancelar</summary><form method="post" class="ws-form" data-msg="' . h($aviso . ' Não tem volta.') . '" onsubmit="return confirm(this.getAttribute(&quot;data-msg&quot;))">'
        . '<input type="hidden" name="acao" value="' . $acao . '">' . $extra . '</form></details>';
    try {
        if ($n['tipo'] === 'nfcom' && !empty($n['nfcom_id'])) {
            $q = $db->prepare("SELECT id, status, protocolo, criado_em FROM ws_nfcom WHERE id=?"); $q->execute([(int)$n['nfcom_id']]); $f = $q->fetch();
            if (!$f || $f['status'] !== 'autorizada' || trim((string)$f['protocolo']) === '') return '';
            if (fs_prazo_cancelamento_vencido($db, 'ws_nfcom', (int)$f['id'])) return '';   // virou o mês: o botão some junto com a virada do status
            return $caixa('Cancelar esta NFCom na SEFAZ?', 'cancelar_nfcom', $campo('nfcom_id', (string)$f['id']) . $motivo);
        }
        if ($n['tipo'] === 'nfe' && !empty($n['nfe55_id'])) {
            $q = $db->prepare("SELECT id, status FROM ws_nfe55 WHERE id=?"); $q->execute([(int)$n['nfe55_id']]); $f = $q->fetch();
            if (!$f || $f['status'] !== 'autorizada' || fs_prazo_cancelamento_vencido($db, 'ws_nfe55', (int)$f['id'])) return '';
            return $caixa('Cancelar esta NF-e na SEFAZ?', 'cancelar_nfe55', $campo('nfe55_id', (string)$f['id']) . $motivo);
        }
        if ($n['tipo'] === 'nfse' && !empty($n['nfse_id']) && (ws_nfse_config()['provider'] ?? '') === 'nacional') {
            $q = $db->prepare("SELECT id, status, codigo_verificacao FROM ws_nfse WHERE id=?"); $q->execute([(int)$n['nfse_id']]); $f = $q->fetch();
            if (!$f || $f['status'] !== 'autorizada' || strlen(preg_replace('/\D/', '', (string)$f['codigo_verificacao'])) !== 50 || fs_prazo_cancelamento_vencido($db, 'ws_nfse', (int)$f['id'])) return '';
            require_once __DIR__ . '/nfse_nacional.php'; $opt = '';
            foreach (ws_nfsen_motivos_cancelamento() as $mk => $mv) $opt .= '<option value="' . $mk . '">' . h($mv) . '</option>';
            return $caixa('Cancelar esta NFS-e na Sefin Nacional?', 'cancelar_nfse', $campo('nfse_id', (string)$f['id']) . '<select name="c_motivo">' . $opt . '</select> ' . $motivo);
        }
    } catch (Throwable $e) { return ''; }
    return '';
}

/* --------------------------------------------------------------- LAYOUT */
function fs_header(string $p): void { ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title><?= h(function_exists('ws_sistema_nome') ? ws_sistema_nome() : 'WellSystem') ?> — Fiscal</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('fiscal') ?></header><main class="ws-main">
<div class="ws-search">
  <a class="ws-btn <?= $p==='notas'?'primary':'' ?>" href="fiscal.php?p=notas">🧾 Notas emitidas</a>
  <a class="ws-btn <?= in_array($p, ['nova','editar','ver'], true)?'primary':'' ?>" href="fiscal.php?p=nova">➕ Nova nota</a>
  <a class="ws-btn <?= in_array($p, ['tomadores', 'tomador'], true)?'primary':'' ?>" href="fiscal.php?p=tomadores">👤 Tomadores</a>
  <a class="ws-btn <?= in_array($p, ['produtos', 'produto'], true)?'primary':'' ?>" href="fiscal.php?p=produtos">📦 Produtos</a>
  <a class="ws-btn <?= $p==='emissor'?'primary':'' ?>" href="fiscal.php?p=emissor">⚙️ Emissor (config)</a>
  <a class="ws-btn <?= $p==='contas'?'primary':'' ?>" href="fiscal.php?p=contas">💳 Conta do PIX</a>
  <a class="ws-btn <?= $p==='arquivos'?'primary':'' ?>" href="fiscal.php?p=arquivos">🗂️ Arquivos XML</a>
</div>
<?php /* 14/11/2026: VOLTAR em todas as páginas do Fiscal, no canto direito (acima do botão Buscar). Mesmo modelo de "voltar" do resto do sistema (ws-busca-voltar, seta ↺ vermelha); volta à página anterior, ou às Notas emitidas se não houver. */ ?>
<div class="ws-fiscal-voltar" style="display:flex;justify-content:flex-end;margin:4px 0 0"><a class="ws-busca-voltar" href="fiscal.php?p=notas" title="Voltar" aria-label="Voltar" style="margin-left:0" onclick="if (history.length > 1) { history.back(); return false; }">↺</a></div>
<?php
  if (isset($_GET['ok'])) echo '<div class="ws-alert ok">Salvo.</div>';
  if (!empty($_SESSION['ws_flash'])) {   // 13/11/2026: aviso de SUCESSO some sozinho em 3 segundos; erro/alerta fica na tela até a pessoa sair
      $msgF = (string)$_SESSION['ws_flash']; unset($_SESSION['ws_flash']);
      $ehErro = (bool)preg_match('/^(Erro|Falha|Selecione|Informe|Cliente|Mais de|Este |Esta |Só |Prazo|Descreva|Nota não|Mensagem automática|Cancelar|Não )|erro|falha|recusad|não encontrad/iu', $msgF);
      echo '<div class="ws-alert ok" id="ws-flash-fiscal">' . h($msgF) . '</div>';
      if (!$ehErro) echo '<script>setTimeout(function(){var e=document.getElementById("ws-flash-fiscal"); if(e){e.style.transition="opacity .4s"; e.style.opacity="0"; setTimeout(function(){e.style.display="none";},450);}},3000);</script>';
  }
}
function fs_footer(): void { echo '</main>' . ws_footer_bar() . '<script src="js/wellsystem.js?v=' . ws_ver('js/wellsystem.js') . '"></script></body></html>'; }

fs_header($p);
if ($p === 'emissor') fs_emissor(); elseif ($p === 'nova' || $p === 'editar') fs_nota_form($db); elseif ($p === 'ver') fs_nota_ver($db); elseif ($p === 'tomadores') fs_tomadores($db); elseif ($p === 'tomador') fs_tomador_form($db); elseif ($p === 'produtos') fs_produtos($db); elseif ($p === 'produto') fs_produto_form($db); elseif ($p === 'arquivos') fs_arquivos_xml(); elseif ($p === 'contas') fs_contas($db); else fs_notas($db);
fs_footer();


/* ------------------------------------------------- CONTA DO PIX (recebimento) — 18/11/2026
 * Edição Fiscal ISOLADA: não existe o cadastro de bancos do ERP nem API de gateway. A conta do PIX é cadastrada AQUI (ws_banco, mesma tabela
 * que o ERP usa) e o QR do DANFE/DANFSe sai pela chave da conta (QR estático, pix.php), sem depender de nenhuma API. No Completo/ERP o cadastro
 * continua em Provedor → Bancos; esta aba também funciona lá (mesma tabela). */
function fs_contas(PDO $db): void {
    $eid = (int)($_GET['id'] ?? 0); $e = null;
    if ($eid) { $st = $db->prepare('SELECT * FROM ws_banco WHERE id=?'); $st->execute([$eid]); $e = $st->fetch(PDO::FETCH_ASSOC) ?: null; }
    $lista = []; try { $lista = $db->query('SELECT * FROM ws_banco ORDER BY nome')->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $ex) {}
    $tipos = ['aleatoria' => 'Aleatória', 'telefone' => 'Telefone', 'cpf' => 'CPF', 'cnpj' => 'CNPJ', 'email' => 'E-mail'];
    $prov = []; $cfg = ws_nfse_config();
    ?>
    <div class="ws-head-row"><h2>💳 Conta do PIX (recebimento)</h2></div>
    <div class="ws-panel" style="margin-bottom:12px">
      <p style="margin:0 0 6px">Cadastre a conta que recebe o pagamento das notas. O <b>QR do PIX</b> que sai na nota (DANFE/DANFSe) é gerado direto pela <b>chave</b> da conta, com o valor da nota — não precisa de API nem de outro sistema.</p>
      <p style="margin:0;font-size:12.5px" class="ws-muted">Use a chave EXATA registrada no banco e escolha o tipo certo (o aplicativo do banco só lê o QR se a chave e o tipo conferem). Para receber só por transferência, deixe a chave em branco: a nota sai sem QR.</p>
    </div>
    <div style="overflow-x:auto"><table class="ws-table"><thead><tr><th>Conta</th><th>Titular</th><th>Tipo</th><th>Chave PIX</th><th>Ativa</th><th></th></tr></thead><tbody>
    <?php foreach ($lista as $b): ?>
      <tr><td><?= h($b['nome']) ?></td><td><?= h($b['titular']) ?></td><td><?= h($tipos[$b['tipo_chave'] ?? ''] ?? '—') ?></td><td><code><?= h($b['pix']) ?></code></td><td><?= !empty($b['ativo']) ? 'sim' : 'não' ?></td>
      <td><div class="ws-acoes"><a href="fiscal.php?p=contas&id=<?= (int)$b['id'] ?>">editar</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Excluir esta conta?')"><input type="hidden" name="acao" value="excluir_conta_pix"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button class="ws-btn" style="padding:2px 8px;color:var(--err)">excluir</button></form></div></td></tr>
    <?php endforeach; if (!$lista) echo '<tr><td colspan="6" class="ws-muted">Nenhuma conta cadastrada. Cadastre abaixo para a nota sair com o QR do PIX.</td></tr>'; ?>
    </tbody></table></div>
    <div class="ws-panel" style="margin-top:16px">
      <h3><?= $eid ? 'Editar conta' : 'Nova conta' ?></h3>
      <form method="post" class="ws-form grid">
        <input type="hidden" name="acao" value="salvar_conta_pix"><input type="hidden" name="id" value="<?= $eid ?>">
        <label class="c2">Nome da conta / banco <input name="nome" required value="<?= h($e['nome'] ?? '') ?>" placeholder="ex.: Sicoob, Banco do Brasil, Nubank PJ"></label>
        <label class="c2">Titular (nome que aparece no PIX) <input name="titular" value="<?= h($e['titular'] ?? '') ?>"></label>
        <label>Tipo da chave PIX <select name="tipo_chave">
          <?php foreach ($tipos as $k => $v) echo '<option value="' . $k . '"' . ((($e['tipo_chave'] ?? '') === $k) ? ' selected' : '') . '>' . $v . '</option>'; ?>
        </select></label>
        <label class="c2">Chave PIX <input name="pix" value="<?= h($e['pix'] ?? '') ?>" placeholder="e-mail, CPF/CNPJ, telefone ou chave aleatória"></label>
        <label class="ws-chk"><input type="checkbox" name="ativo" <?= (!$eid || ($e['ativo'] ?? 1)) ? 'checked' : '' ?>> Ativa</label>
        <div class="c4"><button class="ws-btn verde">Salvar conta</button> <?php if ($eid): ?><a class="ws-btn" href="fiscal.php?p=contas">Nova conta</a><?php endif; ?></div>
      </form>
    </div>
    <?php
    // API de cobrança (opcional) — cliente que tem CelCoin/GalaxPay cadastra aqui; sem a API, nada muda (PIX pela conta própria)
    require_once __DIR__ . '/celcash.php'; $cc = ws_celcash_config(); $apiOn = trim((string)$cc['galaxId']) !== '' && trim((string)$cc['galaxHash']) !== '';
    ?>
    <div class="ws-panel" style="margin-top:16px">
      <h3>🔌 Cobrança por API (opcional) — CelCoin / GalaxPay <?= $apiOn ? '<span class="ws-tag" style="font-size:11px">configurada</span>' : '' ?></h3>
      <p class="ws-muted" style="font-size:12.5px;margin:0 0 8px">Só se você tem conta de cobrança na CelCoin/GalaxPay. Com a API cadastrada, a nota passa a oferecer <b>"Gerar cobrança (PIX e boleto)"</b>: o PIX/boleto sai pela API e o QR da nota usa o da cobrança. Sem a API, tudo segue pela conta do PIX acima. A baixa do pagamento, neste módulo isolado, é manual.</p>
      <form method="post" class="ws-form grid">
        <input type="hidden" name="acao" value="salvar_api_cobranca">
        <label>Ambiente <select name="ambiente"><option value="sandbox" <?= ($cc['ambiente'] ?? '') !== 'producao' ? 'selected' : '' ?>>Testes (sandbox)</option><option value="producao" <?= ($cc['ambiente'] ?? '') === 'producao' ? 'selected' : '' ?>>Produção</option></select></label>
        <label class="c2">Galax ID <input name="galaxId" value="<?= h((string)$cc['galaxId']) ?>" placeholder="ID da conta CelCoin/GalaxPay"></label>
        <label class="c2">Galax Hash <input type="password" name="galaxHash" value="" placeholder="<?= $apiOn ? '•••••• (deixe em branco para manter)' : 'hash da conta' ?>" autocomplete="new-password"></label>
        <div class="c4"><button class="ws-btn verde">Salvar API</button> <button class="ws-btn" name="testar" value="1">Salvar e testar a conexão</button></div>
      </form>
    </div>
    <?php
    // Prova de que o QR sai: mostra o "copia e cola" que a nota vai usar para a conta escolhida (valor de exemplo R$ 10,00)
    if ($e && trim((string)($e['pix'] ?? '')) !== '' && function_exists('ws_pix_chave')) {
        $ch = ws_pix_chave((string)$e['pix'], (string)($e['tipo_chave'] ?? ''));
        if ($ch !== '') { $emv = ws_pix_emv($ch, (string)($cfg['razao_social'] ?? ($e['titular'] ?? 'EMISSOR')), (string)($cfg['cidade'] ?? 'CIDADE'), 10.0, 'TESTE'); ?>
        <div class="ws-panel" style="margin-top:16px"><h3>Teste do QR</h3>
          <p class="ws-muted" style="font-size:12.5px;margin:0 0 6px">PIX "copia e cola" que a nota gera com esta conta (exemplo de R$ 10,00). Cole no aplicativo do banco para conferir o recebedor.</p>
          <textarea readonly rows="3" style="width:100%;font-family:monospace;font-size:12px"><?= h($emv) ?></textarea></div>
    <?php } }
}

/* ---------------------------------------------------------------- VIEWS */
function fs_emissor(): void {
    $c = ws_nfse_config();
    $g = fn($k) => h($c[$k] ?? '');
    ?>
    <div class="ws-head-row"><h2>Emissor de NFSe</h2></div>
    <?= ws_api_bloqueio_html() ?>
    <div class="ws-alert">
      Provedor <b>nacional</b> = emissão direta na Sefin Nacional (gov.br/nfse), <b>sem intermediário pago</b>: precisa do certificado digital <b>A1</b> (arquivo .pfx) da empresa, enviado abaixo.
      Os outros provedores (PlugNotas, Focus…) seguem disponíveis para quem preferir. Comece em <b>homologação</b> (produção restrita do governo).
    </div>
    <?php $logoAtual = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? null; ?>
    <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;max-width:620px;background:#fff;border:1px solid #e3e3e8;border-radius:10px;padding:12px 16px;margin-bottom:14px">
      <div style="width:120px;min-height:56px;display:flex;align-items:center;justify-content:center">
        <?php if ($logoAtual): ?><img src="<?= h(ws_img("uploads/sistema/" . basename($logoAtual) . "?v=" . @filemtime($logoAtual))) ?>" alt="Logo" style="max-width:100%;max-height:56px;object-fit:contain">
        <?php else: ?><span class="ws-muted" style="font-size:12px">Sem logo própria</span><?php endif; ?>
      </div>
      <div style="flex:1;min-width:240px">
        <div style="font-size:13px;margin-bottom:6px"><b>Logo dos documentos</b> — vale para boleto, carnê, DANFE e DANFSe.</div>
        <form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0">
          <input type="hidden" name="acao" value="upload_logo_fiscal">
          <input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp" style="max-width:230px;font-size:12px">
          <button class="ws-btn">📤 Enviar logo</button>
          <?php if ($logoAtual): ?><button class="ws-btn" type="submit" name="acao" value="remover_logo_fiscal" formnovalidate onclick="return confirm('Remover a logo? Os documentos voltam a usar a logo da marca do sistema.')">🗑️ Remover</button><?php endif; ?>
        </form>
      </div>
    </div>
    <?php if (true): require_once __DIR__ . '/nfse_nacional.php'; [$okC, $erroC, , , $infoC] = ws_nfsen_certificado($c); ?>
    <form method="post" enctype="multipart/form-data" class="ws-form grid" style="margin-bottom:14px">
      <input type="hidden" name="acao" value="enviar_cert">
      <div class="c4"><b>Certificado A1:</b> <?= $okC ? '✅ ' . h(($infoC['titular'] ?? '') . ' — válido até ' . ($infoC['valido_ate'] ?? '')) : '⚠️ ' . h($erroC) ?></div>
      <label class="c2">Arquivo do certificado (.pfx / .p12) <input type="file" name="pfx" accept=".pfx,.p12"></label>
      <label>Senha do certificado <input type="password" name="cert_senha" autocomplete="new-password"></label>
      <div><button class="ws-btn">🔐 Enviar certificado</button></div>
    </form>
    <?php endif; ?>
    <form method="post" class="ws-form grid">
      <input type="hidden" name="acao" value="salvar_emissor">
      <label>Provedor <select name="provider">
        <?php foreach (['nacional','plugnotas','focus','enotas','generico'] as $pv) echo "<option ".($c['provider']===$pv?'selected':'').">$pv</option>"; ?>
      </select></label>
      <label>Ambiente <select name="ambiente">
        <option value="homologacao" <?= $c['ambiente']==='homologacao'?'selected':'' ?>>Homologação</option>
        <option value="producao" <?= $c['ambiente']==='producao'?'selected':'' ?>>Produção</option>
      </select></label>
      <label class="c2">URL da API <input name="api_url" value="<?= $g('api_url') ?>" placeholder="https://api.plugnotas.com.br"></label>
      <label class="c4">Token da API <input name="api_token" value="<?= $g('api_token') ?>"></label>
      <label class="c2">Razão social <input name="razao_social" value="<?= $g('razao_social') ?>"></label>
      <label>CNPJ <input name="cnpj" value="<?= $g('cnpj') ?>"></label>
      <label>Inscrição Municipal <input name="inscricao_municipal" value="<?= $g('inscricao_municipal') ?>"></label>
      <label>Inscrição Estadual (NF-e, produto) <input name="inscricao_estadual" value="<?= $g('inscricao_estadual') ?>"></label>
      <label>Regime tributário <select name="regime" id="selRegime" onchange="document.getElementById('boxRegimeNormal').style.display = (this.value==='simples'||this.value==='mei') ? 'none' : 'contents'">
        <?php $regAtual = ws_regime_valido((string)($c['regime'] ?? 'simples')); foreach (ws_regime_lista() as $rk => $rv): ?>
        <option value="<?= h($rk) ?>" <?= $regAtual === $rk ? 'selected' : '' ?>><?= h($rv) ?><?= $rk === 'simples' ? ' (padrão)' : '' ?></option>
        <?php endforeach; ?>
        <?php if ($regAtual === 'normal'): ?><option value="normal" selected>Regime normal (antigo)</option><?php endif; ?>
      </select></label>
      <div id="boxRegimeNormal" style="display:<?= ws_regime_simples($c) ? 'none' : 'contents' ?>">
        <label>ICMS NFCom (%) <input name="nfcom_icms_pct" value="<?= h((string)($c['nfcom_icms_pct'] ?? 0)) ?>" inputmode="decimal" data-ws-no-money="1"></label>
        <label>PIS NFCom (%) <input name="nfcom_pis_pct" value="<?= h((string)($c['nfcom_pis_pct'] ?? 0)) ?>" inputmode="decimal" data-ws-no-money="1"></label>
        <label>COFINS NFCom (%) <input name="nfcom_cofins_pct" value="<?= h((string)($c['nfcom_cofins_pct'] ?? 0)) ?>" inputmode="decimal" data-ws-no-money="1"></label>
        <label>FUST NFCom (%) <input name="nfcom_fust_pct" value="<?= h((string)($c['nfcom_fust_pct'] ?? 0)) ?>" inputmode="decimal" data-ws-no-money="1"></label>
        <label>FUNTTEL NFCom (%) <input name="nfcom_funttel_pct" value="<?= h((string)($c['nfcom_funttel_pct'] ?? 0)) ?>" inputmode="decimal" data-ws-no-money="1"></label>
      </div>
      <label>Cidade <input name="cidade" value="<?= $g('cidade') ?>"></label>
      <label>UF <input name="uf" maxlength="2" value="<?= $g('uf') ?>"></label>
      <label>Cód. IBGE do município <input name="cod_ibge" value="<?= $g('cod_ibge') ?>" placeholder="ex: 3106200"></label>
      <label>CEP <input name="cep" value="<?= $g('cep') ?>"></label>
      <label class="c2">Logradouro <input name="logradouro" value="<?= $g('logradouro') ?>"></label>
      <label>Número <input name="numero" value="<?= $g('numero') ?>"></label>
      <label>Bairro <input name="bairro" value="<?= $g('bairro') ?>"></label>
      <label>Telefone <input name="telefone" value="<?= $g('telefone') ?>"></label>
      <label>E-mail <input name="email" value="<?= $g('email') ?>"></label>
      <label>Cód. serviço (LC 116) <input name="cod_servico" value="<?= $g('cod_servico') ?>" placeholder="ex: 1.07"></label>
      <label>CNAE <input name="cnae" value="<?= $g('cnae') ?>"></label>
      <label>Alíquota ISS (%) <input name="aliquota_iss" value="<?= $g('aliquota_iss') ?>"></label>
      <label class="ws-chk"><input type="checkbox" name="iss_retido" <?= !empty($c['iss_retido'])?'checked':'' ?>> ISS retido</label>
      <label>Código de tributação nacional (cTribNac, 6 dígitos) <input name="nfsen_ctribnac" value="<?= $g('nfsen_ctribnac') ?>" placeholder="ex: 010701"></label>
      <label>Código NBS (opcional) <input name="nfsen_cnbs" value="<?= $g('nfsen_cnbs') ?>"></label>
      <label>Série da DPS <input name="nfsen_serie" value="<?= $g('nfsen_serie') ?>" placeholder="1"></label>
      <label>Assinatura <select name="nfsen_algoritmo"><option value="sha256" <?= ($c['nfsen_algoritmo'] ?? 'sha256') === 'sha256' ? 'selected' : '' ?>>RSA-SHA256</option><option value="sha1" <?= ($c['nfsen_algoritmo'] ?? '') === 'sha1' ? 'selected' : '' ?>>RSA-SHA1</option></select></label>
      <label class="c4">Descrição padrão do serviço <textarea name="descricao_padrao"><?= $g('descricao_padrao') ?></textarea></label>
      <div class="c4" style="border-top:1px solid #ddd;margin-top:8px;padding-top:8px"><b>NF-e (modelo 55) — venda de produto/equipamento</b></div>
      <label>Série da NF-e <input name="nfe_serie" value="<?= $g('nfe_serie') ?: '1' ?>"></label>
      <label>CFOP padrão <input name="nfe_cfop" value="<?= $g('nfe_cfop') ?: '5102' ?>" placeholder="5102 = venda dentro do estado"></label>
      <label>CSOSN padrão (Simples) <input name="nfe_csosn" value="<?= $g('nfe_csosn') ?: '400' ?>"></label>
      <label>NCM padrão <input name="nfe_ncm_padrao" value="<?= $g('nfe_ncm_padrao') ?>" placeholder="8 dígitos, ex: 85176241"></label>
      <label>CEST padrão (se houver) <input name="nfe_cest_padrao" value="<?= $g('nfe_cest_padrao') ?>"></label>
      <label class="c2">Natureza da operação <input name="nfe_natureza" value="<?= $g('nfe_natureza') ?: 'VENDA' ?>"></label>
      <div class="c4" style="border-top:1px solid #ddd;margin-top:8px;padding-top:8px"><b>Percentual aproximado de tributos</b> (Lei da Transparência — informativo na nota; vale o que o contador passou)</div>
      <label>Venda NF-e (%) <input name="pct_trib_nfe" value="<?= h((string)($c['pct_trib_nfe'] ?? 4)) ?>"></label>
      <label>Serviço NFS-e (%) <input name="pct_trib_nfse" value="<?= h((string)($c['pct_trib_nfse'] ?? 6)) ?>"></label>
      <label>Internet NFCom (%) <input name="pct_trib_nfcom" value="<?= h((string)($c['pct_trib_nfcom'] ?? 6)) ?>"></label>
      <div class="c4"><button class="ws-btn primary">💾 Salvar emissor</button></div>
    </form>
    <?php if (ws_pode_configurar()): ?>
    <form method="post" class="ws-form grid" style="margin-top:14px;border-top:1px solid #ddd;padding-top:10px">
      <input type="hidden" name="acao" value="ajustar_numeracao">
      <div class="c4"><b>Numeração em PRODUÇÃO (nível 3+/root)</b> — mexa só se a empresa já emitiu nota fiscal real por OUTRO sistema antes do WellSystem, pra não repetir número. Deixe em branco o que não quiser mudar. Testes em homologação usam contador separado e nunca entram aqui.</div>
      <label>Próximo nº NF-e (série <?= $g('nfe_serie') ?: '1' ?>) <input name="nfe_proximo" type="number" min="1" placeholder="atual: <?= (int)($c['nfe_proximo'] ?? 1) ?>"></label>
      <label>Próximo nº NFS-e (DPS) <input name="nfsen_proximo" type="number" min="1" placeholder="atual: <?= (int)($c['nfsen_proximo'] ?? 1) ?>"></label>
      <label>Próximo nº NFCom (série <?= $g('nfcom_serie') ?: '1' ?>) <input name="nfcom_proximo" type="number" min="1" placeholder="atual: <?= (int)($c['nfcom_proximo'] ?? 1) ?>"></label>
      <div class="c4"><button class="ws-btn" onclick="return confirm('Confirma o novo número? Isso vale pra próxima nota emitida DE VERDADE (produção).')">Ajustar numeração</button></div>
    </form>
    <?php endif; ?>
    <?php
}

/** Lista TODAS as notas: as feitas pela tela de nota (ws_nota: NFS-e/NF-e/NFCom) E as emitidas direto de
 *  uma fatura em Financeiro (ws_nfse "avulsa", sem passar pela tela de nota — fluxo mais antigo, mantido). */
/** PADRÃO ÚNICO das abas de tipo de nota (12/11/2026): mesma ordem, mesmos ícones e mesmo texto em TODAS as telas do Fiscal. */
function fs_abas_tipos(string $pagina, string $param, string $atual, array $qtd): void {
    $abas = ['nfse' => '🧾 NFS-e · Serviço', 'nfcom' => '📡 NFCom · Internet (mod. 62)', 'nfe' => '📦 NF-e · Venda (mod. 55)'];
    echo '<div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap">';
    foreach ($abas as $k => $rot) echo '<a class="ws-btn ' . ($atual === $k ? 'primary' : '') . '" href="fiscal.php?p=' . $pagina . '&' . $param . '=' . $k . (trim((string)($_GET['q'] ?? '')) !== '' ? '&q=' . urlencode((string)$_GET['q']) : '') . '">' . h($rot) . ' · ' . (int)($qtd[$k] ?? 0) . '</a>';
    echo '</div>';
}
/** Arquivos XML organizados em pasta própria por tipo (cache/notas_xml/{nfe,nfse,nfcom}), com seleção para baixar/excluir/enviar. */
function fs_arquivos_xml(): void {
    $tipos = ws_arquivos_tipos();
    $tipo = (string)($_GET['tipo'] ?? 'nfse'); if (!array_key_exists($tipo, $tipos)) $tipo = 'nfse';
    $podeExcluir = ws_pode_configurar();
    ?>
    <div class="ws-head-row"><h2>🗂️ Arquivos XML</h2></div>
    <p class="ws-muted">XML autorizado de cada nota, guardado por tipo. Marque os arquivos para ⬇️ baixar, 💬 enviar por WhatsApp, ✉️ enviar por e-mail ou 🗑️ excluir.</p>
    <?php $qtdArq = []; foreach (array_keys($tipos) as $tk) { $d = WS_CACHE . "/notas_xml/$tk"; $qtdArq[$tk] = is_dir($d) ? count(glob("$d/*.xml") ?: []) : 0; } fs_abas_tipos('arquivos', 'tipo', $tipo, $qtdArq); ?>
    <?php
    $dir = WS_CACHE . "/notas_xml/$tipo"; $arquivos = is_dir($dir) ? glob("$dir/*.xml") ?: [] : [];
    usort($arquivos, fn($a, $b) => filemtime($b) <=> filemtime($a));
    $q = trim((string)($_GET['q'] ?? ''));   // 13/11/2026: busca nos XML por nº da nota, nome/trecho, código, CPF/CNPJ, valor ou chave
    if ($q !== '') { $db0 = ws_db(); $toks = preg_split('/[[:space:]]+/u', mb_strtolower($q), -1, PREG_SPLIT_NO_EMPTY);
        $arquivos = array_values(array_filter($arquivos, function ($f) use ($db0, $tipo, $toks) { $nm = basename($f); $na = fs_nota_do_arquivo($db0, $tipo, $nm); $hay = mb_strtolower($nm . ' ' . $na['titulo'] . ' ' . ($na['busca'] ?? ''));
            foreach ($toks as $tk) if (mb_strpos($hay, $tk) === false) return false; return true; })); }
    $totalArq = count($arquivos); [$pp, $pg] = ws_paginar($totalArq);
    if ($pp > 0) $arquivos = array_slice($arquivos, ($pg - 1) * $pp, $pp);
    ?>
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><input type="hidden" name="p" value="arquivos"><input type="hidden" name="tipo" value="<?= h($tipo) ?>">
      <input name="q" value="<?= h($q) ?>" placeholder="Buscar XML: nº da nota, nome ou trecho, código, CPF/CNPJ, valor, chave…" style="min-width:min(340px,100%);flex:1"><button class="ws-btn primary">🔎 Buscar</button><?php if ($q !== ''): ?> <a class="ws-btn" href="fiscal.php?p=arquivos&tipo=<?= h($tipo) ?>">Limpar</a><?php endif; ?></form>
    <?= ws_paginacao_topo($totalArq, $pp, $pg, ['p' => 'arquivos', 'tipo' => $tipo, 'q' => $q]) ?>
    <form method="post" id="farq">
      <input type="hidden" name="tipo" value="<?= h($tipo) ?>">
      <?php if (!$arquivos): ?><div class="ws-alert">Nenhum arquivo XML de <?= h($tipos[$tipo]) ?> nesta pasta ainda.</div>
      <?php else: ?>
      <table class="ws-table"><thead><tr><th style="width:28px"><input type="checkbox" onclick="document.querySelectorAll('.ws-arq-chk').forEach(c=>c.checked=this.checked)"></th><th>Nota</th><th>Arquivo (chave de acesso)</th><th>Tamanho</th><th>Gravado em</th></tr></thead><tbody>
        <?php foreach ($arquivos as $f): $nome = basename($f); ?>
        <tr><td><input class="ws-arq-chk" type="checkbox" name="arq[]" value="<?= h($nome) ?>"></td>
          <?php $na = fs_nota_do_arquivo(ws_db(), $tipo, $nome); ?><td><b><?= $na['nota_id'] ? '<a href="fiscal.php?p=ver&id=' . (int)$na['nota_id'] . '">' . h($na['titulo']) . '</a>' : h($na['titulo']) ?></b></td>
          <td><?= h($nome) ?></td><td><?= number_format(filesize($f) / 1024, 1, ',', '.') ?> KB</td><td><?= date('d/m/Y H:i', filemtime($f)) ?></td></tr>
        <?php endforeach; ?>
      </tbody></table>
      <?= ws_paginacao_html($totalArq, $pp, $pg, ['p' => 'arquivos', 'tipo' => $tipo, 'q' => $q]) ?>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px">
        <button class="ws-btn primary" type="button" onclick="if(ws_arq_marcados())ws_arq_enviar('arquivos_baixar_zip')">⬇️ Baixar selecionados</button>
        <button class="ws-btn" type="button" title="Cópia legível, indentada, que abre direto no Bloco de Notas (só para leitura; o XML original é o do botão ao lado)" onclick="if(ws_arq_marcados())ws_arq_enviar('arquivos_baixar_txt')">📝 Bloco de Notas (.txt)</button>
        <?php if (ws_edicao_tem('erp')): /* WhatsApp = integração do ERP; Fiscal isolado envia por e-mail */ ?><button class="ws-btn" type="button" onclick="if(ws_arq_marcados() && confirm('Enviar os XML marcados por WhatsApp (Wellnet-02) ao cliente de cada nota?'))ws_arq_enviar('arquivos_enviar_whatsapp')">💬 Enviar WhatsApp</button><?php endif; ?>
        <details style="display:inline-block"><summary class="ws-btn">✉️ Enviar por e-mail</summary>
          <div style="margin-top:4px;display:flex;gap:6px">
            <input type="email" placeholder="e-mail de destino" style="width:220px" id="emailArq">
            <button class="ws-btn primary" type="button" onclick="if(!ws_arq_marcados())return; document.getElementById('farq').email_destino.value=document.getElementById('emailArq').value; ws_arq_enviar('arquivos_enviar_email')">Enviar</button>
          </div>
        </details>
        <?php if ($podeExcluir): ?>
        <button class="ws-btn" type="button" onclick="if(ws_arq_marcados() && confirm('Excluir os arquivos selecionados? Não tem volta. O XML continua valendo na SEFAZ/Sefin; isto apaga a cópia deste servidor e, em até 2 minutos, a do servidor reserva.'))ws_arq_enviar('arquivos_excluir')">🗑️ Excluir selecionados</button>
        <?php endif; ?>
      </div>
      <input type="hidden" name="email_destino"><input type="hidden" name="acao">
      <script>
        function ws_arq_marcados(){ if(!document.querySelectorAll('.ws-arq-chk:checked').length){ alert('Selecione ao menos um arquivo.'); return false; } return true; }
        function ws_arq_enviar(acao){ document.getElementById('farq').acao.value = acao; document.getElementById('farq').submit(); }
      </script>
      <?php endif; ?>
    </form>
    <?php
}

function fs_notas(PDO $db): void {
    $sql = "SELECT nt.id, nt.tipo, c.nome cnome, nt.total, nt.status, s.status status_nfse, s.numero numero_nfse, s.url_pdf, s.codigo_verificacao,
                   e.status status_nfe55, e.numero numero_nfe55, nt.nfse_id, nt.nfe55_id, nt.criado_em, 'nota' origem, c.id cliente_id, c.codigo ccodigo, c.cpf_cnpj cdoc, nt.observacao obs, f.numero numero_nfcom, f.chave_acesso chave_nfcom, f.status status_nfcom, e.chave_acesso chave_nfe55
            FROM ws_nota nt JOIN ws_cliente c ON c.id=nt.cliente_id
            LEFT JOIN ws_nfse s ON s.id=nt.nfse_id LEFT JOIN ws_nfe55 e ON e.id=nt.nfe55_id LEFT JOIN ws_nfcom f ON f.id=nt.nfcom_id
            UNION ALL
            SELECT s.id, 'nfse', c.nome, s.valor, s.status, s.status, s.numero, s.url_pdf, s.codigo_verificacao, NULL, NULL, s.id, NULL, s.criado_em, 'legado', c.id, c.codigo, c.cpf_cnpj, NULL, NULL, NULL, NULL, NULL
            FROM ws_nfse s JOIN ws_cliente c ON c.id=s.cliente_id WHERE s.id NOT IN (SELECT nfse_id FROM ws_nota WHERE nfse_id IS NOT NULL)";
    // 12/11: TRÊS abas separadas — NFS-e (serviço), NFCom (internet, modelo 62) e NF-e (venda, modelo 55)
    $aba = $_GET['aba'] ?? 'nfse'; if ($aba === 'venda') $aba = 'nfe'; if ($aba === 'servico') $aba = 'nfse'; if (!in_array($aba, ['nfse', 'nfcom', 'nfe'], true)) $aba = 'nfse';
    $filtroAba = "t.tipo = '" . $aba . "'";
    $q = trim((string)($_GET['q'] ?? '')); $bq = ws_notas_where_busca($db, $q);   // 13/11/2026: busca por nº, nome/trecho, código, CPF/CNPJ, valor, conteúdo, chave
    $qtdAba = []; foreach (['nfse', 'nfcom', 'nfe'] as $k) $qtdAba[$k] = (int)$db->query("SELECT COUNT(*) FROM ($sql) t WHERE t.tipo = '$k' AND $bq")->fetchColumn();
    $total = (int)$db->query("SELECT COUNT(*) FROM ($sql) t WHERE $filtroAba AND $bq")->fetchColumn();
    [$pp, $pg, $lim] = ws_paginar($total);
    $rows = $db->query("SELECT * FROM ($sql) t WHERE $filtroAba AND $bq ORDER BY criado_em DESC, id DESC$lim")->fetchAll();
    $podeCancelar = ws_pode_configurar() && (ws_nfse_config()['provider'] ?? '') === 'nacional';
    if ($podeCancelar) { require_once __DIR__ . '/nfse_nacional.php'; require_once __DIR__ . '/nfe55.php'; }
    $rotulo = ['nfse' => 'NFS-e', 'nfe' => 'NF-e', 'nfcom' => 'NFCom'];
    ?>
    <div class="ws-head-row"><h2>Notas fiscais</h2></div>
    <p class="ws-muted">Emita uma nota nova em <a href="fiscal.php?p=nova">➕ Nova nota</a><?= ws_edicao_tem('erp') ? ', ou a partir de uma fatura em <a href="financeiro.php?p=faturas">Financeiro</a> (botão "Emitir NFSe")' : '' ?>.</p>
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><input type="hidden" name="p" value="notas"><input type="hidden" name="aba" value="<?= h($aba) ?>">
      <input name="q" value="<?= h($q) ?>" placeholder="Buscar nota: número, nome ou trecho do nome, código, CPF/CNPJ, valor, conteúdo da nota, chave…" style="min-width:min(360px,100%);flex:1">
      <button class="ws-btn primary">🔎 Buscar</button><?php if ($q !== ''): ?> <a class="ws-btn" href="fiscal.php?p=notas&aba=<?= h($aba) ?>">Limpar</a><?php endif; ?></form>
    <?php if ($q !== ''): ?><p class="ws-muted" style="margin:0 0 6px">Resultado da busca por <b><?= h($q) ?></b> — <?= (int)$total ?> nota(s) na aba atual (os números das abas já refletem a busca).</p><?php endif; ?>
    <?php fs_abas_tipos('notas', 'aba', $aba, $qtdAba); ?>
    <form method="post" id="flote"><input type="hidden" name="acao" value="notas_lote"><input type="hidden" name="aba" value="<?= h($aba) ?>"><input type="hidden" name="lote_acao" value=""></form>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0 10px">
      <span class="ws-muted" style="font-size:13px">Marcadas:</span>
      <button type="button" class="ws-btn" onclick="wsLote('xml')">⬇️ Baixar XML</button>
      <?php if (ws_edicao_tem('erp')): /* WhatsApp = integração do ERP; Fiscal isolado envia por e-mail */ ?><button type="button" class="ws-btn" onclick="wsLote('whatsapp','Enviar as notas marcadas por WhatsApp (Wellnet-02) aos clientes?')">💬 Enviar WhatsApp</button><?php endif; ?>
      <button type="button" class="ws-btn" onclick="wsLote('imprimir')">🖨️ Imprimir</button>
      <button type="button" class="ws-btn" onclick="wsLote('excluir','Excluir as notas marcadas? Só rascunho/erro podem ser excluídas.')">🗑️ Excluir</button>
    </div>
    <script>
    function wsLote(acao, msg){
      var m=document.querySelectorAll('.ws-nota-chk:checked'); if(!m.length){ alert('Marque ao menos uma nota.'); return; }
      if(acao==='imprimir'){ m.forEach(function(c){ window.open(c.getAttribute('data-pdf'),'_blank'); }); return; }
      if(msg && !confirm(msg)) return;
      var f=document.getElementById('flote'); f.lote_acao.value=acao;
      f.querySelectorAll('input[name="ids[]"]').forEach(function(e){e.remove();});
      m.forEach(function(c){ var i=document.createElement('input'); i.type='hidden'; i.name='ids[]'; i.value=c.value; f.appendChild(i); });
      f.submit();
    }
    </script>
    <?= ws_paginacao_topo($total, $pp, $pg, ['p' => 'notas', 'aba' => $aba, 'q' => $q]) ?>
    <table class="ws-table"><thead><tr><th style="width:28px"><input type="checkbox" onclick="document.querySelectorAll('.ws-nota-chk').forEach(function(c){c.checked=this.checked}.bind(this))"></th><th>#</th><th>Cliente</th><th>Valor</th><th>Número</th><th>Status</th><th>Ações</th></tr></thead><tbody>
    <?php foreach ($rows as $r):
        $tipo = $r['tipo'] ?? 'nfse';
        $status = $tipo === 'nfe' ? ($r['status_nfe55'] ?: $r['status']) : ($tipo === 'nfse' ? ($r['status_nfse'] ?: $r['status']) : $r['status']);
        $numero = $tipo === 'nfe' ? $r['numero_nfe55'] : ($tipo === 'nfse' ? $r['numero_nfse'] : ($tipo === 'nfcom' ? $r['numero_nfcom'] : null));
        $classe = in_array($status, ['autorizada', 'enviada'], true) ? 'ativo' : (in_array($status, ['erro', 'rejeitada', 'denegada'], true) ? 'bloqueado' : 'suspenso');
    ?>
      <?php $urlPdfLinha = !empty($r['nfe55_id']) && in_array($r['status_nfe55'], ['autorizada', 'cancelada'], true) ? 'fiscal.php?p=danfe&id=' . (int)$r['nfe55_id'] : ($r['origem'] === 'nota' ? 'fiscal.php?p=notapdf&id=' . (int)$r['id'] : ''); ?>
      <tr><td><?php if ($r['origem'] === 'nota'): ?><input class="ws-nota-chk" type="checkbox" value="<?= (int)$r['id'] ?>" data-pdf="<?= h($urlPdfLinha) ?>"><?php endif; ?></td><td><?= (int)$r['id'] ?></td><td><?= h($r['cnome']) ?> <a href="fiscal.php?p=tomador&id=<?= (int)$r['cliente_id'] ?>" title="Tomador desta nota: ver e completar o cadastro" style="text-decoration:none">👤</a></td><td>R$ <?= number_format((float)$r['total'], 2, ',', '.') ?></td>
      <td><?= h($numero ?: '—') ?></td>
      <td><span class="ws-tag <?= $classe ?>" style="text-transform:none"><?= h(fs_status_rotulo($db, $r, (string)$status, (string)$tipo)) ?></span></td>   <?php /* 13/11/2026: só o rótulo — o valor/lógica seguem enviada/autorizada */ ?>
      <td><?php if ($r['origem'] === 'nota' && in_array($status, ['rascunho', 'erro'], true)): ?><a class="ws-btn" title="Espelho: como a nota vai ficar quando for emitida" href="fiscal.php?p=notapdf&id=<?= (int)$r['id'] ?>" target="_blank">👁️ Espelho</a> <a class="ws-btn" title="Editar o rascunho" href="fiscal.php?p=editar&id=<?= (int)$r['id'] ?>">✏️ Editar</a>
      <?php elseif ($r['origem'] === 'nota'): ?><a class="ws-btn" title="Abrir a nota" href="fiscal.php?p=ver&id=<?= (int)$r['id'] ?>">👁️ Abrir</a><?php endif; ?>
      <?php if ($r['url_pdf']): ?> <a href="<?= h($r['url_pdf']) ?>" target="_blank" title="DANFSe oficial do governo">📄 Oficial</a><?php endif; ?>
      <?php if ($r['origem'] === 'nota' && ($tipo !== 'nfe' || in_array($r['status'], ['rascunho', 'erro'], true))): ?> <a href="fiscal.php?p=notapdf&id=<?= (int)$r['id'] ?>" target="_blank" title="Nota em PDF">🖨️ PDF</a><?php endif; ?>
      <?php if ($tipo === 'nfe' && in_array($r['status_nfe55'], ['autorizada', 'cancelada'], true)): ?> <a href="fiscal.php?p=danfe&id=<?= (int)$r['nfe55_id'] ?>" target="_blank" title="DANFE em PDF">🖨️ DANFE</a><?php endif; ?>
      <?php if ($tipo === 'nfse' && $r['origem'] === 'nota') echo fs_cancelar_html($db, (int)$r['id']);   // 13/11/2026: mesmo botão (e mesma regra do mês) para as 3 notas ?>
      <?php if ($tipo === 'nfse' && $r['origem'] !== 'nota' && $status === 'autorizada' && $podeCancelar && strlen(preg_replace('/\D/', '', (string)$r['codigo_verificacao'])) === 50 && !fs_prazo_cancelamento_vencido($db, 'ws_nfse', (int)$r['nfse_id'])): ?>
        <details style="display:inline-block;margin-left:8px"><summary class="ws-btn">⛔ Cancelar</summary>
          <form method="post" class="ws-form" onsubmit="return confirm('Cancelar esta NFS-e na Sefin Nacional? Não tem volta.')">
            <input type="hidden" name="acao" value="cancelar_nfse"><input type="hidden" name="nfse_id" value="<?= (int)$r['nfse_id'] ?>">
            <select name="c_motivo"><?php foreach (ws_nfsen_motivos_cancelamento() as $mk => $mv) echo '<option value="' . $mk . '">' . h($mv) . '</option>'; ?></select>
            <input name="x_motivo" required minlength="15" maxlength="255" placeholder="Motivo (mínimo 15 caracteres)" style="width:260px">
            <button class="ws-btn primary">Confirmar cancelamento</button>
          </form></details>
      <?php endif; ?>
      <?php if ($tipo === 'nfcom' && $r['origem'] === 'nota') echo fs_cancelar_html($db, (int)$r['id']); ?>
      <?php if ($tipo === 'nfe' && $r['origem'] === 'nota') echo fs_cancelar_html($db, (int)$r['id']); ?>
      <?php if ($r['origem'] === 'nota' && in_array($status, ['enviada', 'autorizada'], true)) echo fs_enviar_html($db, (int)$r['id']); ?>
      <?php if ($r['origem'] === 'nota' && in_array($status, ['rascunho', 'erro'], true)): ?>
        <form method="post" style="display:inline" data-msg="<?= h('CONFIRME ANTES DE EMITIR' . "

" . 'Tipo: ' . ($rotulo[$tipo] ?? $tipo) . "
" . 'Cliente: ' . $r['cnome'] . "
" . 'Total: R$ ' . number_format((float)$r['total'], 2, ',', '.') . "

" . 'Ambiente: ' . ((ws_nfse_config()['ambiente'] ?? '') === 'producao' ? 'PRODUÇÃO — vale como documento fiscal de verdade' : 'HOMOLOGAÇÃO — teste, sem valor fiscal') . "

Emitir esta nota agora?") ?>" onsubmit="return confirm(this.getAttribute('data-msg'))">
          <input type="hidden" name="acao" value="emitir_rascunho"><input type="hidden" name="nota_id" value="<?= (int)$r['id'] ?>">
          <button class="ws-btn" type="submit" title="Emite esta nota (pede confirmação com os dados)">🧾 Emitir</button>
        </form>
      <?php endif; ?>
      <?php if ($r['origem'] === 'nota'): ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Criar um rascunho novo com os dados desta nota? Você poderá alterar antes de emitir.')">
          <input type="hidden" name="acao" value="duplicar_nota"><input type="hidden" name="nota_id" value="<?= (int)$r['id'] ?>">
          <button class="ws-btn" type="submit" title="Copia cliente, itens e observação para um rascunho novo">📋 Usar como modelo</button>
        </form>
      <?php endif; ?>
      <?php if ($r['origem'] === 'nota' && in_array($status, ['rascunho', 'erro'], true)): ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Excluir esta nota (rascunho)? Não tem volta.')">
          <input type="hidden" name="acao" value="excluir_nota"><input type="hidden" name="nota_id" value="<?= (int)$r['id'] ?>">
          <button class="ws-btn" type="submit" title="Excluir rascunho/erro">🗑️ Excluir</button>
        </form>
      <?php endif; ?></td></tr>
    <?php endforeach; if(!$rows) echo '<tr><td colspan="7" class="ws-muted">Nenhuma nota emitida.</td></tr>'; ?>
    </tbody></table>
    <?= ws_paginacao_html($total, $pp, $pg, ['p'=>'notas', 'aba'=>$aba, 'q'=>$q]) ?>
    <?php
}

/** Formulário da nota: vários itens (serviço ou produto), editável enquanto for rascunho. */
function fs_nota_form(PDO $db): void {
    $id = (int)($_GET['id'] ?? 0); $nota = null; $itens = [];
    if ($id) { $st = $db->prepare("SELECT n.*, c.nome cnome, c.email email FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id WHERE n.id=?"); $st->execute([$id]); $nota = $st->fetch(); if ($nota) $itens = ws_nota_itens($db, $id); }
    $cfg = ws_nfse_config(); $fat = (int)($_GET['fatura'] ?? 0); $cli = (int)($_GET['cliente'] ?? 0);
    if (!$nota && $fat) {   // nota nova a partir de uma fatura: já vem com o cliente e o valor, e dá para editar tudo
        $q = $db->prepare("SELECT f.id, f.valor, f.cliente_id, c.nome FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE f.id=?"); $q->execute([$fat]); $f = $q->fetch();
        if ($f) { $cli = (int)$f['cliente_id']; $itens = [['tipo' => 'servico', 'descricao' => (string)$cfg['descricao_padrao'], 'qtd' => 1, 'valor_unit' => $f['valor'], 'desconto' => 0]]; }
    }
    if (!$itens) $itens = [['tipo' => 'servico', 'descricao' => '', 'qtd' => 1, 'valor_unit' => 0, 'desconto' => 0]];
    $cnome = $nota['cnome'] ?? ''; if (!$nota && $cli) { $q = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $q->execute([$cli]); $cnome = (string)$q->fetchColumn(); }
    $trava = $nota && !in_array($nota['status'], ['rascunho', 'erro'], true);
    ?>
    <div class="ws-head-row"><h2><?= $nota ? h(fs_titulo_nota($db, (int)$nota['id'])) : 'Nova nota' ?></h2></div>
    <?= ws_api_bloqueio_html() ?>
    <?php if ($trava): $nidT = (int)$nota['id']; ?><div class="ws-alert">Esta nota já foi enviada ao provedor e não pode mais ser editada.</div>
      <div id="nv-botoes" style="margin:8px 0 14px;display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start">   <?php /* 13/11/2026: mesmos botões da tela da nota em TODAS as páginas (depois de enviar/emitir o sistema cai aqui) */ ?>
        <a class="ws-btn" href="fiscal.php?p=ver&id=<?= $nidT ?>">👁️ Ver / imprimir</a>
        <?php if ($nota['tipo'] !== 'nfe'): ?><a class="ws-btn primary" href="fiscal.php?p=notapdf&id=<?= $nidT ?>" target="_blank">🖨️ Baixar/Imprimir nota (PDF)</a><?php elseif (!empty($nota['nfe55_id'])): ?><a class="ws-btn primary" href="fiscal.php?p=danfe&id=<?= (int)$nota['nfe55_id'] ?>" target="_blank">🖨️ Baixar/Imprimir DANFE (PDF)</a><?php endif; ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Criar um rascunho novo com os dados desta nota? Você poderá alterar antes de emitir.')"><input type="hidden" name="acao" value="duplicar_nota"><input type="hidden" name="nota_id" value="<?= $nidT ?>"><button class="ws-btn" type="submit">📋 Usar como modelo</button></form>
        <details style="display:inline-block"><summary class="ws-btn">✉️ Enviar por e-mail</summary>
          <form method="post" class="ws-form" style="margin-top:4px"><input type="hidden" name="acao" value="enviar_email_nota"><input type="hidden" name="nota_id" value="<?= $nidT ?>">
            <input type="email" name="email_destino" value="<?= h((string)($nota['email'] ?? '')) ?>" placeholder="e-mail do cliente" style="width:220px"> <button class="ws-btn primary">Enviar</button></form></details>
        <?php if (ws_edicao_tem('erp')): /* WhatsApp = integração do ERP; Fiscal isolado envia por e-mail */ ?><form method="post" style="display:inline" onsubmit="return confirm('Enviar esta nota por WhatsApp (Wellnet-02) ao cliente?')"><input type="hidden" name="acao" value="enviar_whatsapp_nota"><input type="hidden" name="nota_id" value="<?= $nidT ?>"><button class="ws-btn" type="submit">💬 Enviar WhatsApp</button></form><?php endif; ?>
        <a class="ws-btn" href="fiscal.php?p=tomador&id=<?= (int)$nota['cliente_id'] ?>" title="Dados do tomador desta nota">👤 Tomador</a>
        <?= fs_cancelar_html($db, $nidT) ?>
      </div><?php endif; ?>
    <form method="post" class="ws-form grid" id="fnota">
      <input type="hidden" name="acao" value="salvar_nota">
      <input type="hidden" name="nota_id" value="<?= (int)($nota['id'] ?? 0) ?>">
      <input type="hidden" name="fatura_id" value="<?= (int)($nota['fatura_id'] ?? $fat) ?>">
      <input type="hidden" name="cliente_id" value="<?= (int)($nota['cliente_id'] ?? $cli) ?>">
      <label class="c2" style="position:relative">Cliente (clique e escolha, ou digite nome, ID ou CPF/CNPJ — só cliente ativo)
        <input name="cliente_busca" id="cliBusca" autocomplete="off" value="<?= h($cnome) ?>" <?= $trava ? 'disabled' : '' ?> placeholder="Clique para listar os clientes ativos">
        <div id="cliLista" style="display:none;position:absolute;left:0;right:0;top:100%;z-index:50;background:#fff;border:1px solid #d9d9e0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.12);max-height:320px;overflow:auto;margin-top:4px"></div>
        <span style="font-size:12px;display:block;margin-top:4px"><a class="ws-btn" href="fiscal.php?p=tomador&id=0" style="padding:2px 10px">➕ Tomador</a> <a href="fiscal.php?p=tomadores">👤 ver tomadores</a><?php if ((int)($nota['cliente_id'] ?? $cli) > 0): ?> · <a href="fiscal.php?p=tomador&id=<?= (int)($nota['cliente_id'] ?? $cli) ?>">✏️ completar/editar dados deste tomador</a><?php endif; ?></span>
        <div id="tmCard" style="display:none;margin-top:8px;padding:10px 12px;border:1px solid #e3e3ea;border-radius:10px;background:#fafafc;font-size:13px;line-height:1.5"></div>
      </label>
      <style>.cli-it{padding:9px 14px;cursor:pointer;border-bottom:1px solid #f0f0f4;display:flex;justify-content:space-between;gap:12px;align-items:center}.cli-it:hover,.cli-it.on{background:#f8eaee}.cli-it b{font-weight:600}.cli-it small{color:#777;white-space:nowrap}</style>
      <script>
      (function(){
        var inp=document.getElementById('cliBusca'), box=document.getElementById('cliLista'), hid=document.querySelector('input[name="cliente_id"]'), t=null, sel=-1, itens=[];
        if(!inp||inp.disabled) return;
        function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
        function desenha(){ box.innerHTML=itens.length?itens.map(function(c,i){return '<div class="cli-it'+(i===sel?' on':'')+'" data-i="'+i+'"><b>'+esc(c.nome)+'</b><small>'+esc(c.cpf_cnpj||'')+' · ID '+c.id+'</small></div>';}).join(''):'<div class="cli-it" style="cursor:default;color:#777">Nenhum cliente ativo encontrado</div>'; box.style.display='block'; }
        function busca(){ fetch('fiscal.php?p=clientes_json&q='+encodeURIComponent(inp.value),{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(l){itens=l;sel=-1;desenha();}).catch(function(){}); }
        function escolhe(i){ var c=itens[i]; if(!c) return; inp.value=c.nome; hid.value=c.id; box.style.display='none'; if(window.tmCard) tmCard(c.id); }
        inp.addEventListener('focus',busca); inp.addEventListener('click',busca);
        inp.addEventListener('input',function(){ hid.value='0'; clearTimeout(t); t=setTimeout(busca,200); });
        inp.addEventListener('keydown',function(e){ if(box.style.display==='none') return; if(e.key==='ArrowDown'){sel=Math.min(itens.length-1,sel+1);desenha();e.preventDefault();} else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);desenha();e.preventDefault();} else if(e.key==='Enter'&&sel>=0){escolhe(sel);e.preventDefault();} else if(e.key==='Escape'){box.style.display='none';} });
        box.addEventListener('mousedown',function(e){ var d=e.target.closest('.cli-it'); if(d&&d.getAttribute('data-i')!==null){ escolhe(+d.getAttribute('data-i')); e.preventDefault(); } });
        document.addEventListener('click',function(e){ if(!box.contains(e.target)&&e.target!==inp) box.style.display='none'; });
      })();
      </script>
      <label>Tipo <select name="tipo" <?= $trava ? 'disabled' : '' ?>>
        <option value="nfcom" <?= ($nota['tipo'] ?? ($fat ? 'nfcom' : '')) === 'nfcom' ? 'selected' : '' ?>>NFCom (modelo 62) — plano de internet / comunicação (ICMS)</option>
        <option value="nfse" <?= ($nota['tipo'] ?? ($fat ? 'nfcom' : 'nfse')) === 'nfse' ? 'selected' : '' ?>>NFS-e — outros serviços (manutenção, suporte, instalação; ISS)</option>
        <option value="nfe" <?= ($nota['tipo'] ?? '') === 'nfe' ? 'selected' : '' ?>>NF-e (modelo 55) — venda de produto/equipamento (ICMS)</option>
      </select></label>
      <label>Regime tributário <select name="regime" <?= $trava ? 'disabled' : '' ?>>
        <?php $regNota = ws_regime_valido((string)(($nota['regime'] ?? '') !== '' ? $nota['regime'] : ($cfg['regime'] ?? 'simples'))); foreach (ws_regime_lista() as $rk => $rv): ?>
        <option value="<?= h($rk) ?>" <?= $regNota === $rk ? 'selected' : '' ?>><?= h($rv) ?><?= $rk === ws_regime_valido((string)($cfg['regime'] ?? 'simples')) ? ' (padrão do emissor)' : '' ?></option>
        <?php endforeach; ?>
        <?php if ($regNota === 'normal'): ?><option value="normal" selected>Regime normal (antigo)</option><?php endif; ?>
      </select></label>
      <label>Conta do PIX <select name="banco_id" <?= $trava ? 'disabled' : '' ?>>
        <?php $bancoNota = (int)($nota['banco_id'] ?? 0); ?>
        <option value="0" <?= $bancoNota === 0 ? 'selected' : '' ?>><?= ws_nota_cobranca_api_ok() ? 'Automático — PIX da API da fatura; sem ele, a conta própria' : 'Automático — primeira conta ativa com chave PIX' ?></option>
        <?php try { foreach ($db->query("SELECT id, nome, emissao FROM ws_banco WHERE ativo=1 ORDER BY nome")->fetchAll() as $bk): ?>
        <option value="<?= (int)$bk['id'] ?>" <?= $bancoNota === (int)$bk['id'] ? 'selected' : '' ?>><?= h((string)$bk['nome']) ?><?= ($bk['emissao'] ?? '') === 'proprio' ? ' (conta própria)' : ' (API)' ?></option>
        <?php endforeach; } catch (Throwable $e) {} ?>
      </select> <a href="<?= ws_edicao_tem('erp') ? 'provedor.php?p=bancos' : 'fiscal.php?p=contas' ?>" style="font-size:12px">cadastrar conta</a></label>
      <?php if (empty($nota['fatura_id']) && empty($fat) && !$trava && ws_nota_cobranca_api_ok()): ?>
      <label class="c2" style="display:flex;gap:8px;align-items:center"><input type="hidden" name="cobranca_campo" value="1"><input type="checkbox" name="gerar_cobranca" value="1" <?= empty($nota['sem_cobranca']) ? 'checked' : '' ?> style="width:auto">
        Gerar cobrança no GalaxPay (PIX e boleto com baixa automática) — desmarque se já foi pago</label>
      <?php endif; ?>
      <div class="c4">
        <style>#itens{width:100%;table-layout:auto}#itens th{text-align:center}#itens td.sub{text-align:center;white-space:nowrap}#itens td:nth-child(2){width:42%}#itens select{min-width:120px;width:100%;padding:8px 28px 8px 12px;text-align:center;text-align-last:center}#itens td:first-child{width:140px;text-align:center}#itens td{vertical-align:middle}#itens input[name="it_descricao[]"]{text-align:left;width:100%}</style>
        <table class="ws-table" id="itens"><thead><tr><th>Tipo</th><th>Descrição</th><th class="ws-item-produto">NCM</th><th class="ws-item-produto">CFOP</th><th class="ws-item-produto">Unid.</th><th>Qtd</th><th>Valor unit. (R$)</th><th>Desconto (R$)</th><th>Subtotal</th><th></th></tr></thead><tbody>
        <?php foreach ($itens as $it): $prodRow = ($it['tipo'] ?? '') === 'produto'; ?>
          <tr class="<?= $prodRow ? 'ws-item-eh-produto' : '' ?>">
            <td><select name="it_tipo[]" onchange="fnTipoMudou(this)" <?= $trava ? 'disabled' : '' ?>><option value="servico" <?= !$prodRow ? 'selected' : '' ?>>Serviço</option><option value="produto" <?= $prodRow ? 'selected' : '' ?>>Produto</option></select></td>
            <td><input name="it_descricao[]" placeholder="Descrição do item" value="<?= h((string)$it['descricao']) ?>" style="width:100%" <?= $trava ? 'disabled' : '' ?>></td>
            <td class="ws-item-produto"><input name="it_ncm[]" value="<?= h((string)($it['ncm'] ?? '')) ?>" size="8" placeholder="8 dígitos" <?= $trava ? 'disabled' : '' ?>></td>
            <td class="ws-item-produto"><input name="it_cfop[]" value="<?= h((string)($it['cfop'] ?? '')) ?>" size="4" <?= $trava ? 'disabled' : '' ?>></td>
            <td class="ws-item-produto"><input name="it_unid[]" value="<?= h((string)($it['unidade'] ?? 'UN')) ?>" size="3" <?= $trava ? 'disabled' : '' ?>>
              <input type="hidden" name="it_csosn[]" value="<?= h((string)($it['csosn'] ?? '')) ?>"><input type="hidden" name="it_cest[]" value="<?= h((string)($it['cest'] ?? '')) ?>"></td>
            <td><input name="it_qtd[]" value="<?= h(rtrim(rtrim(number_format((float)$it['qtd'], 3, ',', ''), '0'), ',')) ?>"  size="5" class="calc" inputmode="decimal" autocomplete="off" style="width:78px;min-width:78px;text-align:right" <?= $trava ? 'disabled' : '' ?>></td>
            <td><input name="it_valor[]" value="<?= number_format((float)$it['valor_unit'], 2, ',', '') ?>" size="9" class="calc" data-ws-no-money="1" inputmode="decimal" autocomplete="off" placeholder="0,00" style="text-align:right" <?= $trava ? 'disabled' : '' ?>></td>
            <td><input name="it_desc_valor[]" value="<?= number_format((float)$it['desconto'], 2, ',', '') ?>" size="8" class="calc" data-ws-no-money="1" inputmode="decimal" autocomplete="off" placeholder="0,00" style="text-align:right" <?= $trava ? 'disabled' : '' ?>></td>
            <td class="sub">—</td>
            <td><?php if (!$trava): ?><button type="button" class="ws-btn" onclick="fnDel(this)" title="Remover item">✕</button><?php endif; ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody><tfoot><tr><td colspan="8" style="text-align:right"><b>Total</b></td><td id="tot"><b>—</b></td><td></td></tr></tfoot></table>
        <style>.ws-item-produto{display:none}#itens:has(.ws-item-eh-produto) .ws-item-produto{display:table-cell}</style>
        <p class="ws-muted" style="font-size:12px">NCM/CFOP/Unidade só valem para item do tipo Produto (nota NF-e). CSOSN/CEST usam o padrão do emissor (Fiscal → Emissor).</p>
        <?php if (!$trava): ?><button type="button" class="ws-btn" onclick="fnAdd()">➕ Adicionar item</button><?php endif; ?>
      </div>
      <label class="c4">Observações da nota (vai no documento fiscal) <textarea name="observacao" <?= $trava ? 'disabled' : '' ?>><?= h((string)($nota['observacao'] ?? '')) ?></textarea></label>
      <?php if (!$trava): ?>
      <div class="c4" style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ws-btn primary">💾 Salvar rascunho</button>
        <button class="ws-btn" name="acao" value="emitir_nota" onclick="return fnConfirmaEmitir()">✅ Salvar e emitir</button>
        <?php if ($nota): ?><a class="ws-btn" href="fiscal.php?p=ver&id=<?= (int)$nota['id'] ?>" target="_blank">👁️ Pré-visualizar / imprimir</a> <a class="ws-btn primary" href="fiscal.php?p=notapdf&id=<?= (int)$nota['id'] ?>" target="_blank">📄 Rascunho em PDF (layout da nota)</a><?php endif; ?>
      </div>
      <?php endif; ?>
    </form>
    <?php if ($nota): ?>
    <form method="post" class="ws-form grid" style="margin-top:6px">
      <input type="hidden" name="acao" value="salvar_obs_interna"><input type="hidden" name="nota_id" value="<?= (int)$nota['id'] ?>">
      <label class="c4">Observação interna (só para o time — NÃO vai no documento fiscal; pode anotar mesmo depois de enviada)
        <textarea name="observacao_interna"><?= h((string)($nota['observacao_interna'] ?? '')) ?></textarea></label>
      <div class="c4"><button class="ws-btn">Salvar observação interna</button></div>
    </form>
    <?php endif; ?>
    <script>
    function fnNum(v){v=String(v||'').trim(); if(v.indexOf(',')>=0) v=v.replace(/\./g,'').replace(',','.'); return parseFloat(v)||0;}
    function fnCalc(){var t=0; document.querySelectorAll('#itens tbody tr').forEach(function(tr){var i=tr.querySelectorAll('input.calc'); var s=Math.max(0,Math.round((fnNum(i[0].value)*fnNum(i[1].value)-fnNum(i[2].value))*100)/100); t+=s; tr.querySelector('.sub').textContent=s.toLocaleString('pt-BR',{minimumFractionDigits:2});}); document.getElementById('tot').innerHTML='<b>R$ '+t.toLocaleString('pt-BR',{minimumFractionDigits:2})+'</b>';}
    /* 13/11/2026: NF-e (modelo 55) vende PRODUTO: ao escolher esse tipo (e ao abrir a nota) todos os itens passam para Produto e mostram NCM/CFOP/Unidade; nos outros tipos o item vazio volta para Serviço */
    function fnTipoNota(){ var s=document.querySelector('#fnota select[name="tipo"]'); return s?s.value:''; }
    function fnAplicaTipoNota(){ var nfe=fnTipoNota()==='nfe'; document.querySelectorAll('#itens tbody tr').forEach(function(tr){ var s=tr.querySelector('select[name="it_tipo[]"]'); if(!s||s.disabled) return; var d=tr.querySelector('[name="it_descricao[]"]');
        if(nfe){ s.value='produto'; } else if(s.value==='produto' && d && d.value.trim()===''){ s.value='servico'; } tr.classList.toggle('ws-item-eh-produto', s.value==='produto'); }); }
    (function(){ var s=document.querySelector('#fnota select[name="tipo"]'); if(s){ s.addEventListener('change',fnAplicaTipoNota); fnAplicaTipoNota(); } })();
    function fnTipoMudou(sel){sel.closest('tr').classList.toggle('ws-item-eh-produto', sel.value==='produto');}
    function fnAdd(){var tb=document.querySelector('#itens tbody'); var n=tb.rows[0].cloneNode(true); n.classList.remove('ws-item-eh-produto'); n.querySelectorAll('input').forEach(function(e){ if(e.name==='it_qtd[]') e.value='1'; else if(e.name==='it_descricao[]'||e.name==='it_ncm[]'||e.name==='it_cfop[]'||e.name==='it_csosn[]'||e.name==='it_cest[]') e.value=''; else if(e.name==='it_unid[]') e.value='UN'; else e.value='0,00';}); var sel=n.querySelector('select[name="it_tipo[]"]'); if(sel) sel.value=fnTipoNota()==='nfe'?'produto':'servico'; n.classList.toggle('ws-item-eh-produto', fnTipoNota()==='nfe'); tb.appendChild(n); fnCalc();}
    function fnDel(b){var tb=document.querySelector('#itens tbody'); if(tb.rows.length>1){b.closest('tr').remove(); fnCalc();}}
    /* 13/11/2026: item tipo Produto — ao digitar a descrição a lista FILTRA os produtos cadastrados (exato primeiro, depois os parecidos, "aproximado" no fim); setas + Enter ou clique escolhem e preenchem NCM, CFOP, unidade, CSOSN, CEST e valor */
    (function(){ var box=document.createElement('div'), alvo=null, campo=null, t=null, sel=-1; box.style.cssText='display:none;position:absolute;z-index:60;background:#fff;border:1px solid #d9d9e0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.14);max-height:300px;overflow:auto;min-width:min(380px,100%)'; document.body.appendChild(box);
      function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}
      function setv(tr,n,v){var e=tr.querySelector('[name="'+n+'"]'); if(e) e.value=v;}
      function marca(i){ var its=box.querySelectorAll('.pj-it'); sel=its.length?(i+its.length)%its.length:-1; its.forEach(function(d,k){ d.style.background=k===sel?'#eef2ff':''; if(k===sel) d.scrollIntoView({block:'nearest'}); }); }
      function escolhe(d){ if(!d||!alvo) return; var x=JSON.parse(d.getAttribute('data-j')); setv(alvo,'it_descricao[]',x.descricao); setv(alvo,'it_ncm[]',x.ncm); setv(alvo,'it_cfop[]',x.cfop); setv(alvo,'it_unid[]',x.unidade); setv(alvo,'it_csosn[]',x.csosn); setv(alvo,'it_cest[]',x.cest||'');
        if(parseFloat(x.preco)>0){ var v=alvo.querySelector('[name="it_valor[]"]'); if(v&&!parseFloat(String(v.value).replace(',','.'))) v.value=parseFloat(x.preco).toFixed(2).replace('.',','); } box.style.display='none'; fnCalc(); }
      function realce(s,q){ var h=esc(s), lo=h.toLowerCase(); q.toLowerCase().split(' ').forEach(function(w){ if(w.length<2) return; var o='', i=0, k; while((k=lo.indexOf(w,i))>=0){ o+=h.slice(i,k)+'<mark style="background:#fff3a3;padding:0">'+h.slice(k,k+w.length)+'</mark>'; i=k+w.length; } if(i>0){ h=o+h.slice(i); lo=h.toLowerCase().replace(/<[^>]*>/g,function(m){ return m.replace(/./g,'~'); }); } }); return h; }
      document.addEventListener('input',function(ev){ var i=ev.target; if(!i||i.name!=='it_descricao[]') return; var tr=i.closest('tr'); if(!tr||!tr.classList.contains('ws-item-eh-produto')){ box.style.display='none'; return; }
        alvo=tr; campo=i; clearTimeout(t); t=setTimeout(function(){ var q=i.value.trim(); if(q.length<2){ box.style.display='none'; return; }
          fetch('fiscal.php?p=produto_json&q='+encodeURIComponent(q),{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(l){ var r=i.getBoundingClientRect(), ap=false;
            box.style.left=(r.left+window.scrollX)+'px'; box.style.top=(r.bottom+window.scrollY+2)+'px'; box.style.minWidth=Math.max(380,r.width)+'px';
            box.innerHTML=(l.length?l.map(function(x){ var h=''; if(x.aprox&&!ap){ ap=true; h='<div style="padding:4px 12px;background:#f6f6f9;color:#777;font-size:11px;text-transform:uppercase">Aproximados</div>'; }
              return h+'<div class="pj-it" data-j="'+esc(JSON.stringify(x))+'" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #f0f0f4"><b>'+realce(x.descricao,q)+'</b><br><span style="color:#777;font-size:12px">NCM '+esc(x.ncm)+' · CFOP '+esc(x.cfop)+' · '+esc(x.unidade)+(parseFloat(x.preco)>0?' · R$ '+parseFloat(x.preco).toLocaleString('pt-BR',{minimumFractionDigits:2}):'')+'</span></div>';}).join(''):'<div style="padding:8px 12px;color:#777">Nenhum produto cadastrado com esse nome.</div>')+'<div style="padding:8px 12px"><a href="fiscal.php?p=produto&id=0" target="_blank">➕ Cadastrar produto novo (NCM)</a></div>'; box.style.display='block'; marca(l.length?0:-1); }).catch(function(){}); },200); });
      document.addEventListener('keydown',function(e){ if(box.style.display==='none'||e.target!==campo) return; if(e.key==='ArrowDown'){ e.preventDefault(); marca(sel+1); } else if(e.key==='ArrowUp'){ e.preventDefault(); marca(sel-1); } else if(e.key==='Enter'&&sel>=0){ e.preventDefault(); escolhe(box.querySelectorAll('.pj-it')[sel]); } else if(e.key==='Escape'){ box.style.display='none'; } });
      box.addEventListener('mousedown',function(e){ var d=e.target.closest('.pj-it'); if(d){ escolhe(d); e.preventDefault(); } });
      document.addEventListener('click',function(e){ if(!box.contains(e.target)) box.style.display='none'; }); })();
    /* 13/11/2026: confirmação ao emitir, mostrando os dados que vão no documento fiscal (cliente, tipo, itens, total e ambiente) */
    function fnConfirmaEmitir(){ fnCalc(); var f=document.getElementById('fnota'), s=f.querySelector('select[name="tipo"]'), tipo=s?s.options[s.selectedIndex].text.split(' — ')[0]:'', cli=(document.getElementById('cliBusca')||{}).value||'(sem cliente)',
        n=0, tot=(document.getElementById('tot')||{}).textContent||'', amb=<?= json_encode(($cfg['ambiente'] ?? '') === 'producao') ?>;
      f.querySelectorAll('input[name="it_descricao[]"]').forEach(function(i){ if(i.value.trim()!=='') n++; });
      return confirm('CONFIRME OS DADOS ANTES DE EMITIR\n\nTipo: '+tipo+'\nCliente: '+cli+'\nItens: '+n+'\nTotal: '+tot+'\n\nAmbiente: '+(amb?'PRODUÇÃO — vale como documento fiscal de verdade':'HOMOLOGAÇÃO — teste, sem valor fiscal')+'\n\nSalvar e emitir esta nota?'); }
    /* 13/11/2026: valor digitado ou COLADO entra do jeito que a pessoa escreve ("305", "305,50", "1.250,50", "R$ 1250.5", copiado de planilha/e-mail); formata ao sair do campo.
       Antes valia a máscara de centavos do sistema (digitar 305 virava 3,05) e a colagem era remontada. */
    /* cartão do tomador: mostra nome, documento, endereço e se os dados estão completos para a nota (ou o que falta) */
    function tmEsc(x){ return String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;'); }
    function tmCard(id){ var box=document.getElementById('tmCard'); if(!box) return; id=parseInt(id)||0; if(id<=0){ box.style.display='none'; return; }
      fetch('fiscal.php?p=tomador_json&id='+id,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){ if(!d.ok){ box.style.display='none'; return; }
        var ok=!d.faltas.length, sel=d.status!=='ativo';
        box.innerHTML='<b>'+tmEsc(d.nome)+'</b> <span style="color:#777">· '+tmEsc(d.doc)+' · cód. '+tmEsc(d.codigo)+'</span><br>'+tmEsc(d.endereco)+' · CEP '+tmEsc(d.cep)+(d.email?'<br>'+tmEsc(d.email):'')+(d.fone?' · '+tmEsc(d.fone):'')+'<br>'
          +(sel?'<span class="ws-tag bloqueado" style="text-transform:none">Cliente não está ativo</span> ':'')
          +(ok?'<span class="ws-tag ativo" style="text-transform:none">Dados completos para a nota</span>':'<span class="ws-tag suspenso" style="text-transform:none">Falta: '+tmEsc(d.faltas.join(', '))+'</span> <a href="fiscal.php?p=tomador&id='+d.id+'">completar agora</a>');
        box.style.display='block'; }).catch(function(){ box.style.display='none'; }); }
    tmCard(document.querySelector('input[name="cliente_id"]').value);
    function fnLerNum(t){ t=String(t==null?'':t).replace(/R\$/gi,'').replace(/[^0-9.,]/g,''); if(t==='') return ''; var p=t.lastIndexOf('.'), v=t.lastIndexOf(',');
      if(p>=0&&v>=0){ t = v>p ? t.replace(/\./g,'').replace(',','.') : t.replace(/,/g,''); }
      else if(v>=0){ t=t.replace(/\./g,'').replace(',','.'); }
      else if(p>=0){ if(/^\d{1,3}(\.\d{3})+$/.test(t)) t=t.replace(/\./g,''); }
      var n=parseFloat(t); return isNaN(n)?'':n; }
    function fnFormata(el){ var n=fnLerNum(el.value); if(n==='') { el.value=''; return; } var q=el.name==='it_qtd[]'; el.value=n.toLocaleString('pt-BR',{minimumFractionDigits:q?0:2,maximumFractionDigits:q?3:2}); }
    document.getElementById('itens').addEventListener('paste',function(e){ var el=e.target; if(!el||!el.classList||!el.classList.contains('calc')) return; var cd=e.clipboardData||window.clipboardData; if(!cd) return;
      e.preventDefault(); var n=fnLerNum(cd.getData('text')); if(n===''){ return; } el.value=String(n).replace('.',','); fnFormata(el); fnCalc(); });
    document.getElementById('itens').addEventListener('blur',function(e){ var el=e.target; if(el&&el.classList&&el.classList.contains('calc')){ fnFormata(el); fnCalc(); } },true);
    document.getElementById('itens').addEventListener('input',fnCalc); fnCalc();
    </script>
    <?php
}

/** Pré-visualização / impressão da nota (documento auxiliar). Quando a nota foi emitida, o PDF oficial do provedor é o documento válido. */
function fs_nota_ver(PDO $db): void {
    $id = (int)($_GET['id'] ?? 0);
    $st = $db->prepare("SELECT n.*, c.nome, c.cpf_cnpj, c.email FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id WHERE n.id=?"); $st->execute([$id]); $n = $st->fetch();
    if (!$n) { echo '<div class="ws-alert err">Nota não encontrada.</div>'; return; }
    $itens = ws_nota_itens($db, $id); $c = ws_nfse_config();
    $pdf = ''; $xmlNfe = ''; $chaveNfe = '';
    if (!empty($n['nfse_id'])) { $q = $db->prepare("SELECT numero, url_pdf, status FROM ws_nfse WHERE id=?"); $q->execute([(int)$n['nfse_id']]); $r = $q->fetch(); $pdf = $r['url_pdf'] ?? ''; }
    $nfe55Autorizada = false; $nfe55Cancelada = false;
    if (!empty($n['nfe55_id'])) { $q = $db->prepare("SELECT numero, url_xml, chave_acesso, status FROM ws_nfe55 WHERE id=?"); $q->execute([(int)$n['nfe55_id']]); $r = $q->fetch(); $xmlNfe = $r['url_xml'] ?? ''; $chaveNfe = $r['chave_acesso'] ?? ''; $nfe55Autorizada = ($r['status'] ?? '') === 'autorizada'; $nfe55Cancelada = ($r['status'] ?? '') === 'cancelada'; }
    $temDoc = $pdf || $nfe55Autorizada || $nfe55Cancelada || ($n['tipo'] !== 'nfe' && !in_array($n['status'], ['rascunho', 'erro'], true));
    $urlPdf = !empty($n['nfe55_id']) && ($nfe55Autorizada || $nfe55Cancelada) ? 'fiscal.php?p=danfe&id=' . (int)$n['nfe55_id'] : (($n['tipo'] !== 'nfe') ? 'fiscal.php?p=notapdf&id=' . $id : '');
    ?>
    <style>@media print{.ws-top-wrap,.ws-search,.ws-bar,#nv-botoes,#nv-titulo{display:none!important} body{background:#fff} .nv{border:0!important}} .nv{max-width:820px;margin:0 auto;background:#fff;color:#111;border:1px solid #ccc;padding:22px;border-radius:6px} .nv table{width:100%;border-collapse:collapse} .nv th,.nv td{border-bottom:1px solid #ddd;padding:6px;text-align:left;font-size:13px} .nv h3{margin:0 0 4px}</style>
    <div class="ws-head-row" id="nv-titulo"><h2><?= h(fs_titulo_nota($db, (int)$id)) ?></h2></div>
    <div id="nv-botoes" style="margin-bottom:10px"><button class="ws-btn primary" onclick="window.print()">🖨️ Imprimir</button>
      <?php if (in_array($n['status'], ['rascunho', 'erro'], true)): ?><a class="ws-btn" href="fiscal.php?p=editar&id=<?= $id ?>">Editar</a><?php endif; ?>
      <form method="post" style="display:inline" onsubmit="return confirm('Criar um rascunho novo com os dados desta nota? Você poderá alterar antes de emitir.')"><input type="hidden" name="acao" value="duplicar_nota"><input type="hidden" name="nota_id" value="<?= $id ?>"><button class="ws-btn" type="submit">📋 Usar como modelo</button></form>
      <a class="ws-btn" href="fiscal.php?p=tomador&id=<?= (int)$n['cliente_id'] ?>" title="Dados do tomador desta nota">👤 Tomador</a>
      <?= fs_cancelar_html($db, (int)$id) ?>
      <?php if ($pdf): ?><a class="ws-btn" href="<?= h($pdf) ?>" target="_blank">PDF oficial do provedor</a><?php endif; ?>
      <?php if ($n['tipo'] !== 'nfe' || in_array($n['status'], ['rascunho', 'erro'], true)): ?><a class="ws-btn primary" href="fiscal.php?p=notapdf&id=<?= $id ?>" target="_blank">🖨️ Baixar/Imprimir nota (PDF)</a><?php endif; ?>
      <?php if ($nfe55Autorizada || $nfe55Cancelada): ?><a class="ws-btn primary" href="fiscal.php?p=danfe&id=<?= (int)$n['nfe55_id'] ?>" target="_blank">🖨️ Baixar/Imprimir DANFE (PDF)</a><?php endif; ?>
      <?php if ($xmlNfe): ?><a class="ws-btn" href="<?= h($xmlNfe) ?>" target="_blank">XML autorizado (chave <?= h($chaveNfe) ?>)</a><?php endif; ?>
      <?php if ($temDoc): ?>
        <details style="display:inline-block"><summary class="ws-btn">✉️ Enviar por e-mail</summary>
          <form method="post" class="ws-form" style="margin-top:4px">
            <input type="hidden" name="acao" value="enviar_email_nota"><input type="hidden" name="nota_id" value="<?= $id ?>">
            <input type="email" name="email_destino" value="<?= h((string)($n['email'] ?? '')) ?>" placeholder="e-mail do cliente" style="width:220px">
            <button class="ws-btn primary">Enviar</button>
          </form></details>
        <form method="post" style="display:inline" onsubmit="return confirm('Enviar esta nota pelo WhatsApp (Wellnet-02)?')">
          <input type="hidden" name="acao" value="enviar_whatsapp_nota"><input type="hidden" name="nota_id" value="<?= $id ?>">
          <button class="ws-btn" type="submit">Enviar por WhatsApp</button>
        </form>
      <?php endif; ?>
      <?php if (in_array($n['status'], ['rascunho', 'erro'], true)): ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Excluir esta nota (rascunho)? Não tem volta.')">
          <input type="hidden" name="acao" value="excluir_nota"><input type="hidden" name="nota_id" value="<?= $id ?>">
          <button class="ws-btn" type="submit" title="Excluir rascunho/erro">🗑️ Excluir</button>
        </form>
      <?php endif; ?>
    </div>
    <?php if ($urlPdf): ?><iframe src="<?= h($urlPdf) ?>#toolbar=1&view=FitH" style="width:100%;max-width:820px;height:70vh;display:block;margin:0 auto 12px;border:1px solid #ccc;border-radius:6px;background:#fff" title="Nota fiscal"></iframe><?php endif; ?>
    <details <?= $urlPdf ? '' : 'open' ?> style="max-width:820px;margin:0 auto"><summary class="ws-btn" style="margin-bottom:8px">Dados da nota (resumo)</summary>
    <div class="nv">
      <h3><?= $n['tipo'] === 'nfcom' ? 'NFCom — Nota Fiscal Fatura de Serviço de Comunicação' : ($n['tipo'] === 'nfe' ? 'NF-e — Nota Fiscal de Produto (modelo 55)' : 'NFS-e — Nota Fiscal de Serviço') ?> <span style="font-size:12px;font-weight:400">(<?= ($pdf || $xmlNfe) ? 'enviada ao provedor' : 'documento auxiliar, sem valor fiscal' ?>) #<?= (int)$n['id'] ?></span></h3>
      <p style="font-size:13px;margin:6px 0"><b>Prestador:</b> <?= h($c['razao_social']) ?> — CNPJ <?= h($c['cnpj']) ?> — IM <?= h($c['inscricao_municipal']) ?> — <?= h($c['cidade']) ?>/<?= h($c['uf']) ?> — <?= $c['regime'] === 'simples' ? 'Optante pelo Simples Nacional' : 'Regime normal' ?></p>
      <p style="font-size:13px;margin:6px 0"><b>Tomador:</b> <?= h($n['nome']) ?> — <?= h($n['cpf_cnpj']) ?> <?= $n['email'] ? '— ' . h($n['email']) : '' ?></p>
      <table><thead><tr><th>#</th><th>Tipo</th><th>Descrição</th><th>Qtd</th><th>Unit.</th><th>Desc.</th><th>Subtotal</th></tr></thead><tbody>
      <?php foreach ($itens as $i => $it): $sub = max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2)); ?>
        <tr><td><?= $i + 1 ?></td><td><?= $it['tipo'] === 'produto' ? 'Produto' : 'Serviço' ?></td><td><?= h($it['descricao']) ?></td><td><?= h(rtrim(rtrim(number_format((float)$it['qtd'], 3, ',', ''), '0'), ',')) ?></td><td><?= number_format((float)$it['valor_unit'], 2, ',', '.') ?></td><td><?= number_format((float)$it['desconto'], 2, ',', '.') ?></td><td><?= number_format($sub, 2, ',', '.') ?></td></tr>
      <?php endforeach; ?>
      </tbody><tfoot><tr><td colspan="6" style="text-align:right"><b>Total</b></td><td><b>R$ <?= number_format((float)$n['total'], 2, ',', '.') ?></b></td></tr></tfoot></table>
      <?php if (trim((string)$n['observacao']) !== ''): ?><p style="font-size:12px;margin-top:10px"><b>Observações:</b> <?= nl2br(h($n['observacao'])) ?></p><?php endif; ?>
    </div>
    </details>
    <?php
}
