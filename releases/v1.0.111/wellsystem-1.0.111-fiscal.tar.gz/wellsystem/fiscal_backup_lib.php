<?php
/**
 * WellSystem — BACKUP DO FISCAL (12/11/2026). Rotina própria, no mesmo modelo do backup da OLT:
 * agendamento por horário, pasta própria no servidor de backup ("Sistema Fiscal"), lista com baixar/restaurar/excluir.
 *
 * Um arquivo (.zip) com TUDO do menu de nota fiscal:
 *   manifest.json            — versão, data, contagens (conferência antes de restaurar)
 *   db/<tabela>.json         — ws_nota, ws_nota_item, ws_nfe55, ws_nfse, ws_nfcom, ws_tomador + ws_banco, ws_evento fiscal, clientes tomadores e o endereço deles (só entram os que faltam)
 *   config/nfse.json         — configuração do emissor (numeração, percentuais, ambiente)
 *   config/nfse_cert.pfx     — certificado A1
 *   xml/{nfe,nfse,nfcom}/    — XML autorizados (+ -cancelamento.json)
 *   logo/doc-logo.*          — logo dos documentos
 *
 * Restaurar MESCLA (13/11/2026): servidor do zero recebe tudo; servidor que já existe recebe só o que ainda não tem (nada é apagado nem alterado). Só o módulo fiscal. Os dados vão em JSON (não em SQL),
 * validados contra as colunas reais da tabela: um arquivo adulterado não consegue rodar comando nenhum no banco.
 * O que SAI do servidor (FTP/e-mail/WhatsApp) vai cifrado (.wsbk) quando há senha em Backup → Destinos de envio; sem senha,
 * o certificado e a senha dele NÃO são enviados (a cópia guardada no servidor continua completa).
 */
require_once __DIR__ . '/backup_lib.php';

function ws_fbk_tabelas(): array { return ['ws_nota', 'ws_nota_item', 'ws_nfe55', 'ws_nfse', 'ws_nfcom', 'ws_tomador', 'ws_produto', 'ws_ncm']; }   // ws_produto e ws_ncm (tabela oficial de NCM): 13/11/2026 — tudo do módulo fiscal vai no backup fiscal   // ws_tomador (13/11/2026): lista de Fiscal → Tomadores
function ws_fbk_tipos_xml(): array { return ['nfe', 'nfse', 'nfcom']; }
/** Tabelas de APOIO que o DANFE/histórico usam (bancos/PIX e o log de eventos das notas). Na restauração só ENTRAM os registros que faltam (nunca apagam nem sobrescrevem o que já existe no servidor). */
function ws_fbk_tabelas_extra(): array {
    // 13/11/2026: Fiscal → Tomadores leva junto os CLIENTES que são tomadores (os que ganharam nota ou foram cadastrados lá) e o endereço deles no cadastro normalizado
    // (rua → bairro → cidade → UF → CEP), para o backup do menu de nota fiscal ficar completo sozinho. Só ENTRAM os que faltam (nunca sobrescreve cliente existente).
    $cli = "(id IN (SELECT cliente_id FROM ws_tomador) OR id IN (SELECT cliente_id FROM ws_nota))";
    $log = "id IN (SELECT logradouro_id FROM ws_cliente WHERE $cli AND logradouro_id IS NOT NULL)";
    return ['ws_banco' => '', 'ws_evento' => "tipo IN ('nfe','nfse','nfcom')", 'ws_cliente' => $cli, 'ws_logradouro' => $log,
            'ws_bairro' => "id IN (SELECT bairro_id FROM ws_logradouro WHERE $log)", 'ws_cidade' => '', 'ws_uf' => '', 'ws_cep' => '',
            'ws_fatura' => "id IN (SELECT fatura_id FROM ws_nota WHERE fatura_id IS NOT NULL)"];   // 13/11/2026: cobrança avulsa/fatura ligada a cada nota
}

function ws_fbk_dir(): string {
    $d = WS_BACKUP_DIR . '/fiscal';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d;
}
function ws_fbk_config(): array {
    $def = ['ativo' => 1, 'hora' => '03:30', 'manter' => 30, 'pasta_ftp' => '/Sistema Fiscal 01', 'pasta_ftp_reserva' => '/Sistema Fiscal 02'];   // na RAIZ do servidor de backup, ao lado de /Wellsystem-01 e /Wellsystem-OLT
    $f = WS_CACHE . '/backup_fiscal.json';
    if (is_file($f)) { $c = json_decode((string)@file_get_contents($f), true); if (is_array($c)) return array_merge($def, $c); }
    return $def;
}
function ws_fbk_salvar(array $c): bool {
    ws_dir(WS_CACHE);
    $ok = @file_put_contents(WS_CACHE . '/backup_fiscal.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/backup_fiscal.json', 0640);
    return $ok !== false;
}
function ws_fbk_lista(): array {
    $a = array_merge(glob(ws_fbk_dir() . '/fiscal-*.zip') ?: []);
    usort($a, fn($x, $y) => filemtime($y) <=> filemtime($x));
    return $a;
}
function ws_fbk_nome_ok(string $n): bool { return (bool)preg_match('/^fiscal-\d{8}-\d{6}\.zip$/', $n); }

/** Monta o .zip do Fiscal. @return array [caminho, manifest] — lança exceção se algo essencial falhar. */
function ws_fbk_gerar(PDO $db, string $origem = 'manual'): array {
    @set_time_limit(0); @ini_set('memory_limit', '1024M');
    if (!class_exists('ZipArchive')) throw new RuntimeException('A extensão ZipArchive não está habilitada neste PHP.');
    if (!ws_dir_realmente_gravavel(ws_fbk_dir())) throw new RuntimeException('A pasta ' . ws_fbk_dir() . ' não tem permissão de escrita.');
    $path = ws_fbk_dir() . '/fiscal-' . date('Ymd-His') . '.zip';
    $zip = new ZipArchive();
    if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Não consegui criar o arquivo do backup.');
    $cont = ['notas' => 0, 'xml' => 0, 'tabelas' => []];
    foreach (array_merge(array_fill_keys(ws_fbk_tabelas(), ''), ws_fbk_tabelas_extra()) as $t => $onde) {
        try {
            $create = $db->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM);
            $linhas = $db->query("SELECT * FROM `$t`" . ($onde !== '' ? " WHERE $onde" : ''))->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { continue; }   // tabela ainda não existe nesta instalação
        $zip->addFromString("db/$t.json", json_encode(['create' => $create[1] ?? '', 'modo' => isset(ws_fbk_tabelas_extra()[$t]) ? 'faltantes' : 'substituir', 'rows' => $linhas], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE));
        $cont['tabelas'][$t] = count($linhas);
    }
    $cont['notas'] = (int)($cont['tabelas']['ws_nota'] ?? 0);
    foreach (['nfse.json' => 'config/nfse.json', 'nfse_cert.pfx' => 'config/nfse_cert.pfx', 'provedor.json' => 'config/provedor.json'] as $o => $d) { $f = WS_CACHE . '/' . $o; if (is_file($f)) $zip->addFile($f, $d); }
    foreach (ws_fbk_tipos_xml() as $tp) {
        foreach (array_merge(glob(WS_CACHE . "/notas_xml/$tp/*.xml") ?: [], glob(WS_CACHE . "/notas_xml/$tp/*-cancelamento.json") ?: []) as $f) {
            if (filesize($f) <= 2 * 1048576) { $zip->addFile($f, "xml/$tp/" . basename($f)); if (substr($f, -4) === '.xml') $cont['xml']++; }
        }
    }
    if (defined('WS_UP_SISTEMA')) foreach (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: [] as $f) if (filesize($f) <= 3 * 1048576) $zip->addFile($f, 'logo/' . basename($f));
    $man = ['formato' => 'wellsystem-fiscal', 'versao' => 1, 'gerado_em' => date('c'), 'origem' => $origem, 'contagem' => $cont];
    $zip->addFromString('manifest.json', json_encode($man, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $zip->addFromString('LEIAME.txt', "Backup do módulo FISCAL do WellSystem.\nRestaurar: Backup → Backup do Fiscal → Subir/Restaurar. Devolve as notas, faturas/cobranças ligadas às notas, produtos e tabela de NCM, XML, emissor, certificado, logo, a lista de Tomadores e os clientes que são tomadores (com endereço).\nSó entra o que ainda não existe no servidor; para o restante do WellSystem use o backup completo.\n");
    $zip->close();
    if (!is_file($path) || filesize($path) < 100) throw new RuntimeException('O arquivo do backup saiu vazio.');
    @chmod($path, 0640);
    // retenção
    $manter = max(3, (int)(ws_fbk_config()['manter'] ?? 30)); $todos = array_reverse(ws_fbk_lista());   // mais antigos primeiro
    while (count($todos) > $manter) @unlink(array_shift($todos));
    return [$path, $man];
}

/** Cópia para ENVIAR: sem senha de criptografia, tira o certificado e a senha dele. Com senha, cifra tudo (.wsbk). @return array [nome, bytes, mime] */
function ws_fbk_pacote_envio(string $path): array {
    $senha = (string)(ws_backup_dest_config()['cripto_senha'] ?? '');
    $bytes = (string)file_get_contents($path); $nome = basename($path);
    if ($senha !== '' && function_exists('openssl_encrypt')) return [$nome . '.wsbk', ws_backup_cifrar($bytes, $senha), 'application/octet-stream'];
    // sem senha: refaz o zip sem o certificado e sem a senha dele
    $tmp = tempnam(sys_get_temp_dir(), 'fbk'); $in = new ZipArchive(); $out = new ZipArchive();
    if ($in->open($path) === true && $out->open($tmp, ZipArchive::OVERWRITE) === true) {
        for ($i = 0; $i < $in->numFiles; $i++) {
            $n = $in->getNameIndex($i); if ($n === 'config/nfse_cert.pfx') continue;
            $c = $in->getFromIndex($i);
            if ($n === 'config/nfse.json') { $j = json_decode($c, true); if (is_array($j)) { unset($j['cert_senha'], $j['api_token']); $c = json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); } }
            $out->addFromString($n, $c);
        }
        $out->addFromString('SEM-CERTIFICADO.txt', "Enviado sem senha de criptografia: o certificado A1 e a senha dele NÃO estão neste arquivo.\n");
        $out->close(); $in->close(); $bytes = (string)file_get_contents($tmp); $nome = 'fiscal-sem-certificado-' . substr($nome, 7);
    }
    @unlink($tmp);
    return [$nome, $bytes, 'application/zip'];
}

/** Envia UM backup do Fiscal aos destinos (servidor de backup por FTP em pasta própria, e-mail, WhatsApp). @return array resultado por canal */
function ws_fbk_enviar(string $path, array $pular = []): array {
    @set_time_limit(0);
    if (!is_file($path)) return ['erro' => 'arquivo não encontrado'];
    $d = ws_backup_dest_config(); $cfg = ws_fbk_config(); $res = [];
    [$nome, $bytes, $mime] = ws_fbk_pacote_envio($path);
    $tmp = sys_get_temp_dir() . '/' . $nome; @file_put_contents($tmp, $bytes);
    if (!in_array('ftp', $pular, true) && ws_backup_canal_on($d, 'ftp') && trim((string)$d['ftp_host']) !== '' && function_exists('ftp_connect')) {
        if (!function_exists('ws_espelho_somente_leitura') && is_file(__DIR__ . '/espelho_lib.php')) require_once __DIR__ . '/espelho_lib.php';
        $ehReserva = function_exists('ws_espelho_somente_leitura') && ws_espelho_somente_leitura();   // o servidor reserva (Wellsystem-02) manda o SEU backup numa pasta própria
        $pasta = trim((string)($ehReserva ? ($cfg['pasta_ftp_reserva'] ?? '/Sistema Fiscal 02') : $cfg['pasta_ftp'])); if ($pasta === '') $pasta = $ehReserva ? '/Sistema Fiscal 02' : '/Sistema Fiscal 01'; if ($pasta[0] !== '/') $pasta = '/' . $pasta;   // sempre a partir da raiz do FTP (pasta própria, irmã das outras)
        $res['ftp'] = ws_backup_ftp_put($d, $tmp, $nome, $pasta);
    }
    $mail = trim((string)($d['email'] ?? '')) !== '' ? trim((string)$d['email']) : trim((string)(ws_backup_config()['email'] ?? ''));
    if (!in_array('email', $pular, true) && ws_backup_canal_on($d, 'email') && $mail !== '' && is_file(__DIR__ . '/mailer.php')) {
        require_once __DIR__ . '/mailer.php';
        [$ok, $m] = ws_email_anexo_partes($mail, 'Backup do Fiscal — ' . date('d/m/Y'), 'Backup do módulo fiscal em anexo (' . $nome . ', ' . round(strlen($bytes) / 1024) . ' KB).', $nome, $bytes, $mime);
        $res['email'] = $ok ? 'ok' : $m;
    }
    if (!in_array('whatsapp', $pular, true) && ws_backup_canal_on($d, 'whatsapp') && trim((string)$d['whatsapp']) !== '' && is_file(__DIR__ . '/whatsapp.php')) {
        require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_wa_documento')) { $r = ws_wa_documento($d['whatsapp'], $nome, base64_encode($bytes), ['evento' => 'backup', 'interna' => true]); $res['whatsapp'] = !empty($r['ok']) ? 'ok' : ($r['raw'] ?? 'falha'); }
    }
    @unlink($tmp);
    @file_put_contents(WS_CACHE . '/backup_fiscal.log', date('Y-m-d H:i:s') . ' ' . basename($path) . ': ' . json_encode($res ?: ['aviso' => 'nenhum destino configurado'], JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
    return $res ?: ['aviso' => 'nenhum destino configurado'];
}

/** Lê o manifesto de um .zip do Fiscal (ou devolve erro). @return array [manifest|null, erro] */
function ws_fbk_manifesto(string $zipPath): array {
    $z = new ZipArchive(); if ($z->open($zipPath) !== true) return [null, 'Arquivo inválido (não é um .zip).'];
    $m = json_decode((string)$z->getFromName('manifest.json'), true); $z->close();
    if (!is_array($m) || ($m['formato'] ?? '') !== 'wellsystem-fiscal') return [null, 'Este arquivo não é um backup do Fiscal do WellSystem.'];
    return [$m, ''];
}

/** RESTAURA / ATUALIZA o módulo fiscal a partir de um .zip — MESCLA (13/11/2026): servidor do ZERO recebe tudo; servidor que JÁ EXISTE recebe só o que ainda não tem.
 *  Nada existente é apagado nem alterado. Mesmo número com conteúdo diferente = "conflito": fica o do servidor e é contado no resultado.
 *  (O backup GERAL é que restaura tudo por cima; este aqui só acrescenta.) @return array [ok, mensagem] */
function ws_fbk_restaurar(PDO $db, string $zipPath): array {
    @set_time_limit(0); @ini_set('memory_limit', '1024M');
    [$man, $erro] = ws_fbk_manifesto($zipPath); if (!$man) return [false, $erro];
    $z = new ZipArchive(); $z->open($zipPath);
    $r = ['novos' => 0, 'iguais' => 0, 'conflitos' => 0, 'xml_novos' => 0, 'xml_iguais' => 0, 'xml_conflitos' => 0, 'arq_novos' => 0, 'arq_mantidos' => 0];
    $notasConflito = [];
    try {
        $db->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach (array_merge(ws_fbk_tabelas(), array_keys(ws_fbk_tabelas_extra())) as $t) {
            $j = json_decode((string)$z->getFromName("db/$t.json"), true); if (!is_array($j)) continue;
            $existe = (bool)$db->query("SHOW TABLES LIKE " . $db->quote($t))->fetchColumn();
            if (!$existe) { if (strncmp(ltrim((string)($j['create'] ?? '')), 'CREATE TABLE', 12) !== 0) continue; $db->exec($j['create']); }
            $cols = array_column($db->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_ASSOC), 'Field');
            $chv = $t === 'ws_ncm' ? 'codigo' : 'id';   // ws_ncm não tem id: a chave é o código
            $busca = $db->prepare("SELECT * FROM `$t` WHERE `$chv`=?");
            $db->beginTransaction();
            foreach ((array)($j['rows'] ?? []) as $linha) {
                if (!is_array($linha)) continue; $linha = array_intersect_key($linha, array_flip($cols)); if (!$linha || !isset($linha[$chv])) continue;
                if ($t === 'ws_nota_item' && in_array((int)($linha['nota_id'] ?? 0), $notasConflito, true)) { $r['conflitos']++; continue; }   // item de nota que ficou com a versão do servidor
                $busca->execute([$linha[$chv]]); $atual = $busca->fetch(PDO::FETCH_ASSOC);
                if (!$atual) {
                    $db->prepare((in_array($t, ['ws_tomador', 'ws_ncm'], true) ? 'INSERT IGNORE' : 'INSERT') . " INTO `$t` (`" . implode('`,`', array_keys($linha)) . "`) VALUES (" . implode(',', array_fill(0, count($linha), '?')) . ")")->execute(array_values($linha));
                    $r['novos']++; continue;
                }
                $dif = false; foreach ($linha as $k => $v) { if ($k === 'atualizado_em') continue; if ((string)$v !== (string)($atual[$k] ?? '')) { $dif = true; break; } }
                if ($dif) { $r['conflitos']++; if ($t === 'ws_nota') $notasConflito[] = (int)$linha['id']; } else $r['iguais']++;
            }
            $db->commit();
        }
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); $db->exec('SET FOREIGN_KEY_CHECKS=1'); return [false, 'Falha ao restaurar as tabelas: ' . $e->getMessage()]; }
    $db->exec('SET FOREIGN_KEY_CHECKS=1');
    ws_dir(WS_CACHE);
    $logoJaTem = defined('WS_UP_SISTEMA') && (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: []) !== [];
    for ($i = 0; $i < $z->numFiles; $i++) {   // arquivos: só nomes seguros, só nas pastas esperadas, e SÓ o que ainda não existe
        $n = $z->getNameIndex($i); $c = $z->getFromIndex($i); if ($c === false) continue;
        if (in_array($n, ['config/nfse.json', 'config/nfse_cert.pfx', 'config/provedor.json'], true)) {
            $dest = WS_CACHE . '/' . basename($n);
            if (substr($n, -5) === '.json' && !is_array(json_decode($c, true))) continue;
            if (is_file($dest)) { $r['arq_mantidos']++; continue; }   // o servidor já tem a sua (numeração, certificado, empresa): não mexe
            if (@file_put_contents($dest, $c) !== false) { @chmod($dest, $n === 'config/nfse_cert.pfx' ? 0600 : 0640); $r['arq_novos']++; }
        } elseif (preg_match('#^xml/(nfe|nfse|nfcom)/([A-Za-z0-9_.\-]+\.(xml|json))$#', $n, $m)) {
            $dd = WS_CACHE . '/notas_xml/' . $m[1]; if (!is_dir($dd)) @mkdir($dd, 0750, true); $dest = $dd . '/' . $m[2];
            if (is_file($dest)) { if (md5_file($dest) === md5($c)) $r['xml_iguais']++; else $r['xml_conflitos']++; continue; }
            if (@file_put_contents($dest, $c) !== false && $m[3] === 'xml') $r['xml_novos']++;
        } elseif (preg_match('#^logo/(doc-logo\.(png|jpg|jpeg|webp))$#', $n, $m) && defined('WS_UP_SISTEMA')) {
            if ($logoJaTem) { $r['arq_mantidos']++; continue; }
            ws_dir(WS_UP_SISTEMA); if (@file_put_contents(WS_UP_SISTEMA . '/' . $m[1], $c) !== false) { @chmod(WS_UP_SISTEMA . '/' . $m[1], 0644); $r['arq_novos']++; }
        }
    }
    $z->close();
    $msg = 'Registros: ' . $r['novos'] . ' novo(s) adicionado(s), ' . $r['iguais'] . ' já existiam iguais' . ($r['conflitos'] ? ', ' . $r['conflitos'] . ' em CONFLITO (mesmo número, conteúdo diferente — ficou o do servidor)' : '')
         . '. XML: ' . $r['xml_novos'] . ' novo(s), ' . $r['xml_iguais'] . ' já existiam' . ($r['xml_conflitos'] ? ', ' . $r['xml_conflitos'] . ' em conflito (mantido o do servidor)' : '')
         . '. Configuração/certificado/logo: ' . $r['arq_novos'] . ' adicionado(s), ' . $r['arq_mantidos'] . ' mantido(s) do servidor.'
         . ($r['novos'] > 0 ? ' Confira o próximo número das notas em Fiscal → Emissor.' : '');
    return [true, $msg];
}

/** Rotina do cron (junto do radius_sync, a cada 2 min): no horário marcado, gera e envia. Mesmo modelo do backup automático. */
function ws_fbk_auto_check(PDO $db): void {
    if (function_exists('ws_edicao_tem') && !ws_edicao_tem('fiscal')) return;   // edicao sem o modulo Fiscal (OLT/ERP): nao roda a rotina de backup do Fiscal
    $cfg = ws_fbk_config(); $diag = WS_CACHE . '/backup_fiscal_diag.txt';
    $dg = function (string $m) use ($diag) { @file_put_contents($diag, date('d/m H:i') . ' — ' . $m); };
    if (empty($cfg['ativo'])) { $dg('Backup do Fiscal DESATIVADO.'); return; }
    ws_dir(WS_CACHE); $marca = WS_CACHE . '/backup_fiscal_ultimo.txt';
    if (is_file($marca) && !is_writable($marca)) @chmod($marca, 0640);
    [$pend, $slot, $why] = ws_agenda_slot($marca, (string)($cfg['hora'] ?? '03:30'));
    if (!$pend) { $dg($why === 'antes' ? 'Ainda não deu o horário (agendado ' . $cfg['hora'] . ').' : 'Horário de hoje (' . $slot . ') já cumprido.'); return; }
    $tryF = WS_CACHE . '/backup_fiscal_try.json'; $tp = is_file($tryF) ? (json_decode((string)@file_get_contents($tryF), true) ?: []) : [];
    $n = ($tp['slot'] ?? '') === $slot ? (int)($tp['n'] ?? 0) : 0;
    $jaOk = ($tp['slot'] ?? '') === $slot ? array_values((array)($tp['ok'] ?? [])) : [];
    if ($n > 0 && (time() - (int)($tp['ts'] ?? 0)) < 300) { $dg('Aguardando nova tentativa (' . $n . '/3).'); return; }
    /* 14/11/2026: trava contra duas passadas ao mesmo tempo (no servidor reserva o cron chama esta rotina SEM a trava do radius_sync) e, na nova
       tentativa, só refaz o canal que FALHOU — antes, se o e-mail falhava, o FTP que já tinha recebido o arquivo recebia de novo a cada tentativa
       (mesmo modelo do backup geral, ws_backup_auto_check). */
    $lock = @fopen(WS_CACHE . '/backup_fiscal_auto.lock', 'c');
    if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) { fclose($lock); $dg('Outra passada já está gerando o backup do Fiscal agora.'); return; }
    try {
        [$pend2] = ws_agenda_slot($marca, (string)($cfg['hora'] ?? '03:30'));
        if (!$pend2) { $dg('Horário de hoje (' . $slot . ') já cumprido (outra passada concluiu primeiro).'); return; }
        try {
            [$path] = (!empty($tp['path']) && ($tp['slot'] ?? '') === $slot && is_file($tp['path'])) ? [$tp['path']] : ws_fbk_gerar($db, 'automatico');
            $env = ws_fbk_enviar($path, $jaOk);
        } catch (Throwable $e) { $env = ['erro' => $e->getMessage()]; $path = ''; }
        $falhou = false;
        foreach ($env as $k => $v) { if ($k === 'aviso') continue; if ($v === 'ok') $jaOk[] = $k; else $falhou = true; }
        if ($falhou && $n + 1 < 3) { @file_put_contents($tryF, json_encode(['slot' => $slot, 'n' => $n + 1, 'ts' => time(), 'path' => $path, 'ok' => array_values(array_unique($jaOk))])); $dg('Falha ao enviar — nova tentativa em 5 min (' . ($n + 1) . '/3): ' . json_encode($env, JSON_UNESCAPED_UNICODE)); return; }
        @file_put_contents($marca, $slot); @unlink($tryF);
        $dg('Backup do Fiscal feito e enviado (' . $slot . '): ' . json_encode($env, JSON_UNESCAPED_UNICODE));
    } finally { if ($lock) { flock($lock, LOCK_UN); fclose($lock); } }
}
