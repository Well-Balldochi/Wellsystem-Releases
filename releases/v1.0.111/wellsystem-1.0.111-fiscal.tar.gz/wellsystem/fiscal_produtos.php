<?php
/** WellSystem - Fiscal: pagina Produtos (acoes e JSON). Funcoes em fiscal_produtos_lib.php. Carregado por fiscal.php. */
require_once __DIR__ . '/fiscal_produtos_lib.php';

/* ------------------------------------------------------------- JSON (busca de NCM e de produto) */
if (($_GET['p'] ?? '') === 'ncm_json') {
    header('Content-Type: application/json; charset=utf-8'); ws_produto_tabelas($db);
    $q = trim((string)($_GET['q'] ?? '')); $out = [];
    if (mb_strlen($q) >= 2) {
        $dig = preg_replace('/\D/', '', $q); $conds = []; $par = [];
        foreach (preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY) as $tk) { $conds[] = "descricao LIKE ?"; $par[] = '%' . addcslashes($tk, '%_') . '%'; }
        $sql = "SELECT codigo, descricao FROM ws_ncm WHERE " . ($dig !== '' && $dig === preg_replace('/\D/', '', str_replace(' ', '', $q)) ? "codigo LIKE ?" : implode(' AND ', $conds)) . " ORDER BY codigo LIMIT 25";
        $st = $db->prepare($sql); $st->execute($dig !== '' && $dig === preg_replace('/\D/', '', str_replace(' ', '', $q)) ? [$dig . '%'] : $par); $out = $st->fetchAll(PDO::FETCH_ASSOC);
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
}
if (($_GET['p'] ?? '') === 'produto_json') {   // 13/11/2026: busca filtrando ao digitar: exato primeiro, depois começa com, depois contém tudo; se sobrar vaga, aproximados (qualquer palavra)
    header('Content-Type: application/json; charset=utf-8'); ws_produto_tabelas($db);
    $q = trim((string)($_GET['q'] ?? '')); $toks = preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY) ?: []; $cols = 'id, codigo, descricao, ncm, cest, cfop, csosn, origem, unidade, preco';
    $conds = ['ativo=1']; $par = [];
    foreach ($toks as $tk) { $conds[] = "(descricao LIKE ? OR codigo LIKE ? OR ncm LIKE ?)"; $l = '%' . addcslashes($tk, '%_') . '%'; array_push($par, $l, $l, $l); }
    $ord = "(descricao = ?) DESC, (descricao LIKE ?) DESC, (codigo = ?) DESC, descricao";
    $st = $db->prepare("SELECT $cols FROM ws_produto WHERE " . implode(' AND ', $conds) . " ORDER BY $ord LIMIT 15"); $st->execute(array_merge($par, [$q, addcslashes($q, '%_') . '%', $q]));
    $out = $st->fetchAll(PDO::FETCH_ASSOC); foreach ($out as &$o) $o['aprox'] = 0; unset($o);
    if (count($out) < 8 && count($toks) > 0) {
        $ids = array_map(fn($o) => (int)$o['id'], $out) ?: [0]; $or = []; $p2 = [];
        foreach ($toks as $tk) { if (mb_strlen($tk) < 3) continue; $or[] = "descricao LIKE ?"; $p2[] = '%' . addcslashes(mb_substr($tk, 0, max(3, mb_strlen($tk) - 1)), '%_') . '%'; }
        if ($or) { $st = $db->prepare("SELECT $cols FROM ws_produto WHERE ativo=1 AND id NOT IN (" . implode(',', $ids) . ") AND (" . implode(' OR ', $or) . ") ORDER BY descricao LIMIT " . (15 - count($out))); $st->execute($p2);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $o) { $o['aprox'] = 1; $out[] = $o; } }
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
}

/* ------------------------------------------------------------- AÇÕES (POST) */
if (($_POST['acao'] ?? '') === 'produto_salvar') {
    ws_api_exigir_edicao('fiscal.php?p=produtos');
    $idP = (int)($_POST['produto_id'] ?? 0); $r = ws_produto_gravar($db, $idP, $_POST);
    $_SESSION['ws_flash'] = $r['ok'] ? 'Produto salvo.' : ('Erro: ' . $r['erro']);
    if ($r['ok']) { header('Location: fiscal.php?p=produtos'); exit; }
    $_SESSION['ws_produto_form'] = $_POST; header('Location: fiscal.php?p=produto&id=' . $idP); exit;
}
if (($_POST['acao'] ?? '') === 'produto_ativar') {
    ws_api_exigir_edicao('fiscal.php?p=produtos'); ws_produto_tabelas($db);
    $db->prepare("UPDATE ws_produto SET ativo = 1 - ativo WHERE id=?")->execute([(int)($_POST['produto_id'] ?? 0)]); header('Location: fiscal.php?p=produtos&q=' . urlencode((string)($_POST['q'] ?? ''))); exit;
}
if (($_POST['acao'] ?? '') === 'catalogo_importar') {
    ws_api_exigir_edicao('fiscal.php?p=produtos'); ws_produto_tabelas($db); [$okC, $msgC] = ws_produto_catalogo_importar($db);
    $_SESSION['ws_flash'] = $okC ? $msgC : ('Erro: ' . $msgC); header('Location: fiscal.php?p=produtos'); exit;
}
if (($_POST['acao'] ?? '') === 'ncm_atualizar') {
    ws_api_exigir_edicao('fiscal.php?p=produtos'); [$okN, $msgN] = ws_ncm_atualizar($db);
    $_SESSION['ws_flash'] = $okN ? $msgN : ('Erro: ' . $msgN); header('Location: fiscal.php?p=produtos'); exit;
}

/* ------------------------------------------------------------- PÁGINAS */
function fs_produtos(PDO $db): void {
    ws_produto_tabelas($db);
    $nNcm = (int)$db->query("SELECT COUNT(*) FROM ws_ncm")->fetchColumn(); $infoNcm = is_file(WS_CACHE . '/ncm_atualizada.txt') ? trim((string)@file_get_contents(WS_CACHE . '/ncm_atualizada.txt')) : '';
    if ($nNcm === 0) { [$okA, $msgA] = ws_ncm_atualizar($db); $nNcm = (int)$db->query("SELECT COUNT(*) FROM ws_ncm")->fetchColumn(); $infoNcm = is_file(WS_CACHE . '/ncm_atualizada.txt') ? trim((string)@file_get_contents(WS_CACHE . '/ncm_atualizada.txt')) : ''; if (!$okA) echo '<div class="ws-alert err">' . h($msgA) . '</div>'; }
    $q = trim((string)($_GET['q'] ?? '')); $conds = ['1=1']; $par = [];
    foreach (preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY) as $tk) { $conds[] = "(p.descricao LIKE ? OR p.codigo LIKE ? OR p.ncm LIKE ? OR p.cest LIKE ? OR n.descricao LIKE ?)"; $l = '%' . addcslashes($tk, '%_') . '%'; array_push($par, $l, $l, $l, $l, $l); }
    $cnt = $db->prepare("SELECT COUNT(*) FROM ws_produto p LEFT JOIN ws_ncm n ON n.codigo=p.ncm WHERE " . implode(' AND ', $conds)); $cnt->execute($par); $total = (int)$cnt->fetchColumn(); [$pp, $pg, $lim] = ws_paginar($total);
    $st = $db->prepare("SELECT p.*, n.descricao ncm_desc FROM ws_produto p LEFT JOIN ws_ncm n ON n.codigo=p.ncm WHERE " . implode(' AND ', $conds) . " ORDER BY p.ativo DESC, (p.fonte='catalogo') ASC, p.descricao$lim"); $st->execute($par); $rows = $st->fetchAll();
    ?>
    <div class="ws-head-row"><h2>📦 Produtos · classificação fiscal (NF-e)</h2></div>
    <p class="ws-muted" style="font-size:11.5px;line-height:1.35;margin:4px 0;color:#1f8a3b">NF-e sem NCM válido não é emitida. NCM da tabela oficial da Receita (<?= (int)$nNcm ?> códigos<?= $infoNcm !== '' ? ' · atualizada em ' . h(substr($infoNcm, 0, 10)) : '' ?>).</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0;align-items:center">
      <a class="ws-btn primary" href="fiscal.php?p=produto&id=0">➕ Cadastrar produto</a>
      <form method="post" style="display:inline" onsubmit="return confirm('Baixar a tabela de NCM atualizada da Receita Federal (Siscomex)? Leva alguns segundos.')"><input type="hidden" name="acao" value="ncm_atualizar"><button class="ws-btn" type="submit">⬇️ Atualizar tabela NCM (Receita)</button></form>
      <form method="post" style="display:inline" onsubmit="return confirm('Importar para o cadastro os produtos ligados aos CNAEs do CNPJ (informática, telecom, papelaria, construção, eletrodomésticos, móveis, armarinho, cosméticos, joias, saneantes etc.) da tabela oficial de NCM? Produtos já cadastrados não são alterados.')"><input type="hidden" name="acao" value="catalogo_importar"><button class="ws-btn" type="submit">📚 Importar catálogo (CNAE do CNPJ)</button></form>
      <form method="get" style="display:flex;gap:8px;flex:1;min-width:min(300px,100%)"><input type="hidden" name="p" value="produtos"><input name="q" value="<?= h($q) ?>" placeholder="Buscar: produto, código, NCM, CEST ou texto da classificação…" style="flex:1"><button class="ws-btn primary">🔎 Buscar</button><?php if ($q !== ''): ?><a class="ws-btn" href="fiscal.php?p=produtos">Limpar</a><?php endif; ?></form>
    </div>
    <?= ws_paginacao_topo($total, $pp, $pg, ['p' => 'produtos', 'q' => $q]) ?>
    <?php if (!$rows): ?><div class="ws-alert">Nenhum produto<?= $q !== '' ? ' para "' . h($q) . '"' : ' cadastrado' ?>.</div><?php else: ?>
    <style>.pr-wrap{overflow-x:auto}.pr-tab{table-layout:fixed;width:100%;min-width:1100px}.pr-tab th,.pr-tab td{font-size:12.5px;padding:8px 6px;white-space:normal!important;overflow-wrap:anywhere;word-break:normal;vertical-align:middle;text-align:left}.pr-tab th{text-align:center}
.pr-tab td.c{text-align:center}.pr-tab td.pr-ncmd{font-size:12px;line-height:1.35;color:#444}.pr-tab td.pr-ncmd div{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.pr-tab td.pr-ac{text-align:center}.pr-tab td.pr-ac .ws-btn{padding:3px 8px;font-size:12px;margin:2px}.pr-tab td.pr-ac form{display:inline}</style>
    <div class="pr-wrap"><table class="ws-table pr-tab"><colgroup><col style="width:17%"><col style="width:7%"><col style="width:30%"><col style="width:6%"><col style="width:5%"><col style="width:6%"><col style="width:4%"><col style="width:4%"><col style="width:8%"><col style="width:13%"></colgroup><thead><tr><th>Produto</th><th>NCM</th><th>Classificação oficial</th><th>CEST</th><th>CFOP</th><th>CSOSN</th><th>Orig.</th><th>Un.</th><th>Preço</th><th>Ações</th></tr></thead><tbody>
    <?php foreach ($rows as $r): ?>
      <tr style="<?= (int)$r['ativo'] ? '' : 'opacity:.5' ?>"><td><b><?= h($r['descricao']) ?></b><?= $r['codigo'] ? '<br><span class="ws-muted">cód. ' . h($r['codigo']) . '</span>' : '' ?><?= $r['fonte'] === 'padrao' ? ' <span class="ws-tag suspenso" style="text-transform:none" title="Sugestão inicial: conferir com o contador">sugestão</span>' : '' ?></td>
        <td class="c"><?= h(substr($r['ncm'], 0, 4) . '.' . substr($r['ncm'], 4, 2) . '.' . substr($r['ncm'], 6, 2)) ?></td><td class="pr-ncmd" title="<?= h((string)$r['ncm_desc']) ?>"><?= $r['ncm_desc'] ? '<div>' . h((string)$r['ncm_desc']) . '</div>' : '<span class="ws-tag bloqueado" style="text-transform:none">NCM fora da tabela</span>' ?></td>
        <td class="c"><?= h((string)$r['cest']) ?></td><td class="c"><?= h($r['cfop']) ?></td><td class="c"><?= h($r['csosn']) ?></td><td class="c"><?= h($r['origem']) ?></td><td class="c"><?= h($r['unidade']) ?></td><td class="c">R$ <?= number_format((float)$r['preco'], 2, ',', '.') ?></td>
        <td class="pr-ac"><a class="ws-btn" href="fiscal.php?p=produto&id=<?= (int)$r['id'] ?>">✏️ Editar</a><form method="post"><input type="hidden" name="acao" value="produto_ativar"><input type="hidden" name="produto_id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="q" value="<?= h($q) ?>"><button class="ws-btn" type="submit"><?= (int)$r['ativo'] ? '⏸️ Desativar' : '▶️ Ativar' ?></button></form></td></tr>
    <?php endforeach; ?></tbody></table></div>
    <?= ws_paginacao_html($total, $pp, $pg, ['p' => 'produtos', 'q' => $q]) ?>
    <?php endif;
}

function fs_produto_form(PDO $db): void {
    ws_produto_tabelas($db); $id = (int)($_GET['id'] ?? 0);
    $v = ['codigo' => '', 'descricao' => '', 'ncm' => '', 'cest' => '', 'cfop' => '5102', 'csosn' => '400', 'origem' => '0', 'unidade' => 'UN', 'preco' => '', 'obs' => '', 'ativo' => 1];
    if ($id > 0) { $q = $db->prepare("SELECT * FROM ws_produto WHERE id=?"); $q->execute([$id]); $p = $q->fetch(PDO::FETCH_ASSOC); if (!$p) { echo '<div class="ws-alert err">Produto não encontrado.</div>'; return; }
        foreach ($v as $k => $_) if (isset($p[$k])) $v[$k] = (string)$p[$k]; $v['preco'] = number_format((float)$p['preco'], 2, ',', '.'); }
    if (!empty($_SESSION['ws_produto_form']) && is_array($_SESSION['ws_produto_form'])) { $v = array_merge($v, array_intersect_key($_SESSION['ws_produto_form'], $v)); unset($_SESSION['ws_produto_form']); }
    $in = fn(string $k, string $rot, string $extra = '', string $cls = '') => '<label class="' . $cls . '">' . h($rot) . ' <input name="' . $k . '" id="pf_' . $k . '" value="' . h((string)$v[$k]) . '" ' . $extra . '></label>';
    ?>
    <div class="ws-head-row"><h2><?= $id > 0 ? '✏️ Editar produto' : '➕ Cadastrar produto' ?></h2></div>
    <p class="ws-muted" style="font-size:11.5px;line-height:1.35;margin:4px 0"><a href="fiscal.php?p=produtos">← voltar para Produtos</a> · A classificação (NCM) sai da tabela oficial da Receita: digite o nome do produto ou o código na busca do NCM e escolha. Confirme com o contador.</p>
    <?= ws_api_bloqueio_html() ?>
    <form method="post" class="ws-form grid" autocomplete="off">
      <input type="hidden" name="acao" value="produto_salvar"><input type="hidden" name="produto_id" value="<?= $id ?>"><input type="hidden" name="ativo_campo" value="1">
      <?= $in('descricao', 'Descrição do produto *', 'required maxlength="120"', 'c3') ?><?= $in('codigo', 'Código interno', 'maxlength="30"') ?>
      <label class="c4" style="position:relative">NCM * — digite o nome do produto ou o código para buscar na tabela oficial
        <input name="ncm" id="pf_ncm" value="<?= h($v['ncm']) ?>" required maxlength="10" inputmode="numeric" placeholder="ex.: roteador, 85176241" autocomplete="off">
        <div id="ncmBox" style="display:none;position:absolute;left:0;right:0;top:100%;z-index:50;background:#fff;border:1px solid #d9d9e0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.12);max-height:300px;overflow:auto;margin-top:4px"></div>
        <span id="ncmDesc" class="ws-muted" style="font-size:12px;display:block;margin-top:4px"></span></label>
      <?= $in('cest', 'CEST (se o NCM tiver substituição tributária)', 'maxlength="7" inputmode="numeric"') ?><?= $in('cfop', 'CFOP *', 'required maxlength="4" inputmode="numeric"') ?><?= $in('csosn', 'CSOSN (Simples) *', 'required maxlength="4" inputmode="numeric"') ?>
      <?= $in('origem', 'Origem (0 a 8) *', 'required maxlength="1" inputmode="numeric"') ?><?= $in('unidade', 'Unidade *', 'required maxlength="6" style="text-transform:uppercase"') ?><?= $in('preco', 'Preço de venda (R$)', 'inputmode="decimal" data-ws-no-money="1" placeholder="0,00"') ?>
      <?= $in('obs', 'Observação', 'maxlength="255"', 'c4') ?>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="ativo" value="1" <?= (int)$v['ativo'] ? 'checked' : '' ?> style="width:auto"> Ativo (aparece na busca da nota)</label>
      <div class="c4" style="display:flex;gap:8px"><button class="ws-btn primary">💾 Salvar produto</button><a class="ws-btn" href="fiscal.php?p=produtos">Cancelar</a></div>
    </form>
    <script>
    (function(){ var inp=document.getElementById('pf_ncm'), box=document.getElementById('ncmBox'), dsc=document.getElementById('ncmDesc'), t=null;
      function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}
      function fmt(c){return c.slice(0,4)+'.'+c.slice(4,6)+'.'+c.slice(6,8);}
      function descreve(){ var c=inp.value.replace(/\D/g,''); if(c.length!==8){ dsc.textContent=''; return; } fetch('fiscal.php?p=ncm_json&q='+c,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(l){ dsc.textContent = l.length&&l[0].codigo===c ? '✔ '+fmt(c)+' — '+l[0].descricao : '⚠ NCM não encontrado na tabela oficial vigente'; }).catch(function(){}); }
      function busca(){ var q=inp.value.trim(); if(q.length<2){ box.style.display='none'; return; } fetch('fiscal.php?p=ncm_json&q='+encodeURIComponent(q),{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(l){
          box.innerHTML=l.length?l.map(function(x){return '<div class="ncm-it" data-c="'+x.codigo+'" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #f0f0f4"><b>'+fmt(x.codigo)+'</b> — '+esc(x.descricao.length>170?x.descricao.slice(0,170)+'…':x.descricao)+'</div>';}).join(''):'<div style="padding:8px 12px;color:#777">Nada encontrado — tente outra palavra ou o código</div>'; box.style.display='block'; }).catch(function(){}); }
      inp.addEventListener('input',function(){ clearTimeout(t); t=setTimeout(function(){ busca(); descreve(); },250); });
      box.addEventListener('mousedown',function(e){ var d=e.target.closest('.ncm-it'); if(d){ inp.value=d.getAttribute('data-c'); box.style.display='none'; descreve(); e.preventDefault(); } });
      document.addEventListener('click',function(e){ if(!box.contains(e.target)&&e.target!==inp) box.style.display='none'; }); descreve(); })();
    </script>
    <?php
}
