<?php
/** WellSystem - Fiscal: funcoes do cadastro de produtos/NCM (sem saida e sem acoes de POST; pode ser incluido de qualquer lugar). A pagina esta em fiscal_produtos.php. */
/**
 * WellSystem — Fiscal: cadastro de PRODUTOS com classificação fiscal (13/11/2026).
 * Página única (fiscal.php?p=produtos) para cadastrar cada produto com NCM, CEST, CFOP, CSOSN, origem, unidade e preço, e puxar o NCM da tabela
 * OFICIAL (Siscomex / Receita Federal, baixada pela internet — botão "Atualizar tabela NCM"). Na nota (NF-e), ao digitar a descrição do produto o sistema
 * oferece os cadastrados e já preenche a classificação. NF-e SEM NCM válido não é emitida (antes caía no NCM padrão do emissor, que é de roteador).
 * Vem com uma lista inicial de produtos de provedor (roteador, ONU/ONT, switch, cabos, conectores, fonte, antena, informática) — SUGESTÕES de classificação:
 * o contador do provedor deve conferir cada uma. Carregado por fiscal.php (ações de POST/JSON rodam no include).
 */

define('WS_NCM_URL', 'https://portalunico.siscomex.gov.br/classif/api/publico/nomenclatura/download/json');

/** Cria as tabelas (idempotente) e, na 1ª vez, carrega a lista inicial de produtos de provedor. Collation explícita (regra do projeto). */
function ws_produto_tabelas(PDO $db): void {
    static $feito = false; if ($feito) return; $feito = true;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS ws_ncm (codigo CHAR(8) NOT NULL PRIMARY KEY, descricao TEXT NOT NULL, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->exec("CREATE TABLE IF NOT EXISTS ws_produto (id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(30) DEFAULT NULL, descricao VARCHAR(120) NOT NULL, ncm CHAR(8) NOT NULL DEFAULT '',
                   cest VARCHAR(7) DEFAULT NULL, cfop CHAR(4) NOT NULL DEFAULT '5102', csosn VARCHAR(4) NOT NULL DEFAULT '400', origem CHAR(1) NOT NULL DEFAULT '0', unidade VARCHAR(6) NOT NULL DEFAULT 'UN',
                   preco DECIMAL(12,2) NOT NULL DEFAULT 0, ativo TINYINT(1) NOT NULL DEFAULT 1, obs VARCHAR(255) DEFAULT NULL, fonte VARCHAR(10) NOT NULL DEFAULT 'manual',
                   criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                   INDEX idx_prod_desc (descricao), INDEX idx_prod_ncm (ncm)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        if ((int)$db->query("SELECT COUNT(*) FROM ws_produto")->fetchColumn() === 0) ws_produto_semear($db);
    } catch (Throwable $e) {}
}

/** Lista inicial (SUGESTÕES para provedor de internet; NCM conferido na tabela oficial vigente). [descrição, NCM, unidade, observação] */
function ws_produto_padrao(): array {
    $c = 'Sugestão de classificação — conferir com o contador';
    return [
        ['Roteador Wi-Fi', '85176241', 'UN', $c], ['Roteador sem Wi-Fi (cabeado)', '85176249', 'UN', $c], ['Switch (comutador de pacotes de dados)', '85176234', 'UN', $c],
        ['Modem', '85176255', 'UN', $c], ['ONU / ONT GPON (terminal de fibra óptica)', '85176259', 'UN', $c . ' (há quem use 85176241 quando tem Wi-Fi)'],
        ['Cabo de rede UTP (Cat5e/Cat6)', '85444200', 'MT', $c], ['Patch cord / cordão de rede', '85444200', 'UN', $c], ['Cabo de mouse / USB', '85444200', 'UN', $c],
        ['Cabo de fibra óptica drop', '85447010', 'MT', $c], ['Cordão óptico / pigtail', '85447010', 'UN', $c],
        ['Conector RJ45', '85366990', 'UN', $c], ['Conector óptico (SC/APC)', '85367000', 'UN', $c], ['Fonte de alimentação / adaptador', '85044090', 'UN', $c], ['Antena', '85291090', 'UN', $c],
        ['Mouse', '84716053', 'UN', $c], ['Teclado', '84716052', 'UN', $c], ['SSD', '84717040', 'UN', $c], ['HD (disco rígido)', '84717010', 'UN', $c],
        ['Placa-mãe', '84733041', 'UN', $c], ['Memória RAM (módulo)', '84733042', 'UN', $c], ['Fone de ouvido', '85183000', 'UN', $c],
    ];
}
function ws_produto_semear(PDO $db): int {
    $n = 0; $ins = $db->prepare("INSERT INTO ws_produto (descricao, ncm, unidade, obs, fonte) VALUES (?,?,?,?, 'padrao')");
    foreach (ws_produto_padrao() as [$d, $ncm, $un, $ob]) { try { $ins->execute([$d, $ncm, $un, $ob]); $n++; } catch (Throwable $e) {} }
    return $n;
}

/**
 * Baixa a tabela OFICIAL de NCM (Siscomex/Receita) e grava só os códigos de 8 dígitos VIGENTES, com a descrição completa (posição > subposição > item).
 * @return array [ok, mensagem, quantidade, vigencia]
 */
function ws_ncm_atualizar(PDO $db): array {
    ws_produto_tabelas($db); @set_time_limit(180); @ini_set('memory_limit', '512M');
    $ch = curl_init(WS_NCM_URL); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 120, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_USERAGENT => 'Mozilla/5.0 WellSystem', CURLOPT_ENCODING => '']);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if (!is_string($raw) || $code !== 200) return [false, 'Não consegui baixar a tabela de NCM da Receita (HTTP ' . $code . ($err ? ': ' . $err : '') . ').', 0, ''];
    $j = json_decode($raw, true); if (!is_array($j) || empty($j['Nomenclaturas'])) return [false, 'A resposta da Receita veio em formato inesperado.', 0, ''];
    $mapa = []; $hoje = date('Ymd');
    foreach ($j['Nomenclaturas'] as $x) {
        $cod = preg_replace('/\D/', '', (string)($x['Codigo'] ?? '')); if ($cod === '') continue;
        $fim = (string)($x['Data_Fim'] ?? ''); if (preg_match('#^(\d{2})/(\d{2})/(\d{4})$#', $fim, $m) && $m[3] . $m[2] . $m[1] < $hoje) continue;   // não vigente
        $mapa[$cod] = trim(ltrim(trim(strip_tags(html_entity_decode((string)($x['Descricao'] ?? ''), ENT_QUOTES, 'UTF-8'))), "- "));
    }
    $db->beginTransaction();
    try {
        $db->exec("DELETE FROM ws_ncm"); $ins = $db->prepare("INSERT INTO ws_ncm (codigo, descricao) VALUES (?, ?)"); $n = 0;
        foreach ($mapa as $cod => $d) {
            if (strlen($cod) !== 8) continue; $partes = [];
            foreach ([4, 5, 6, 7] as $k) if (isset($mapa[substr($cod, 0, $k)]) && $mapa[substr($cod, 0, $k)] !== '') $partes[] = $mapa[substr($cod, 0, $k)];
            $partes[] = $d; $ins->execute([$cod, mb_substr(implode(' > ', $partes), 0, 4000)]); $n++;
        }
        $db->commit();
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); return [false, 'Falha ao gravar a tabela de NCM: ' . $e->getMessage(), 0, '']; }
    $vig = (string)($j['Data_Ultima_Atualizacao_NCM'] ?? ''); @file_put_contents(WS_CACHE . '/ncm_atualizada.txt', date('c') . ' | ' . $vig . ' | ' . $n . " códigos\n");
    return [true, 'Tabela de NCM atualizada: ' . $n . ' códigos de 8 dígitos (' . $vig . ').', $n, $vig];
}

/** NCM existe na tabela oficial? Se a tabela ainda não foi baixada, aceita qualquer NCM de 8 dígitos. */
function ws_ncm_valido(PDO $db, string $ncm): bool {
    $ncm = preg_replace('/\D/', '', $ncm); if (strlen($ncm) !== 8) return false;
    try { if (!(int)$db->query("SELECT COUNT(*) FROM ws_ncm")->fetchColumn()) return true; $q = $db->prepare("SELECT 1 FROM ws_ncm WHERE codigo=?"); $q->execute([$ncm]); return (bool)$q->fetchColumn(); } catch (Throwable $e) { return true; }
}

/** Valida e grava (cria/edita) um produto. @return array ['ok','erro','id'] */
function ws_produto_gravar(PDO $db, int $id, array $d): array {
    ws_produto_tabelas($db);
    $desc = trim(preg_replace('/\s+/u', ' ', (string)($d['descricao'] ?? ''))); $ncm = preg_replace('/\D/', '', (string)($d['ncm'] ?? '')); $cest = preg_replace('/\D/', '', (string)($d['cest'] ?? ''));
    $cfop = preg_replace('/\D/', '', (string)($d['cfop'] ?? '')) ?: '5102'; $csosn = preg_replace('/\D/', '', (string)($d['csosn'] ?? '')) ?: '400'; $orig = preg_replace('/\D/', '', (string)($d['origem'] ?? '0')) ?: '0';
    $un = strtoupper(trim((string)($d['unidade'] ?? 'UN'))) ?: 'UN'; $preco = (float)str_replace(',', '.', str_replace('.', '', (string)($d['preco'] ?? '0')));
    if (strpos((string)($d['preco'] ?? ''), ',') === false && is_numeric($d['preco'] ?? null)) $preco = (float)$d['preco'];
    $fail = fn(string $m) => ['ok' => false, 'erro' => $m, 'id' => $id];
    if ($desc === '') return $fail('Informe a descrição do produto.');
    if (strlen($ncm) !== 8) return $fail('O NCM precisa ter 8 dígitos.');
    if (!ws_ncm_valido($db, $ncm)) return $fail('NCM ' . $ncm . ' não existe na tabela oficial vigente. Use a busca ao lado do campo.');
    if ($cest !== '' && strlen($cest) !== 7) return $fail('O CEST, quando informado, tem 7 dígitos.');
    if (strlen($cfop) !== 4) return $fail('O CFOP precisa ter 4 dígitos.');
    if (!preg_match('/^[0-8]$/', $orig)) return $fail('Origem da mercadoria: de 0 a 8.');
    $vals = ['codigo' => trim((string)($d['codigo'] ?? '')) ?: null, 'descricao' => mb_substr($desc, 0, 120), 'ncm' => $ncm, 'cest' => $cest ?: null, 'cfop' => $cfop, 'csosn' => $csosn, 'origem' => $orig,
             'unidade' => mb_substr($un, 0, 6), 'preco' => round($preco, 2), 'obs' => trim((string)($d['obs'] ?? '')) ?: null, 'ativo' => !empty($d['ativo']) || !isset($d['ativo_campo']) ? 1 : 0];
    try {
        if ($id > 0) { $set = implode(',', array_map(fn($k) => "$k=:$k", array_keys($vals))); $db->prepare("UPDATE ws_produto SET $set, fonte=IF(fonte IN ('padrao','catalogo'),'manual',fonte) WHERE id=:id")->execute($vals + ['id' => $id]); }
        else { $db->prepare("INSERT INTO ws_produto (" . implode(',', array_keys($vals)) . ") VALUES (:" . implode(',:', array_keys($vals)) . ")")->execute($vals); $id = (int)$db->lastInsertId(); }
    } catch (Throwable $e) { return $fail('Não consegui gravar: ' . $e->getMessage()); }
    return ['ok' => true, 'erro' => '', 'id' => $id];
}

/** A NF-e só sai com NCM válido em TODO produto. @return string '' se ok, senão a mensagem. */
function ws_nfe_exige_classificacao(PDO $db, array $itens): string {
    foreach ($itens as $i => $it) {
        if (($it['tipo'] ?? '') !== 'produto') continue; $n = $i + 1;
        $ncm = preg_replace('/\D/', '', (string)($it['ncm'] ?? ''));
        if ($ncm === '') return 'Item ' . $n . ' (' . mb_substr((string)$it['descricao'], 0, 40) . '): falta o NCM — a classificação fiscal do produto. Escolha o produto cadastrado ou cadastre em Fiscal → Produtos.';
        if (!ws_ncm_valido($db, $ncm)) return 'Item ' . $n . ' (' . mb_substr((string)$it['descricao'], 0, 40) . '): o NCM ' . $ncm . ' não existe na tabela oficial vigente.';
    }
    return '';
}


/** Famílias de NCM (posições de 4 dígitos) importadas por "Importar catálogo": informática, material de expediente/escritório, telecom/fibra, elétrica e material de instalação. */
function ws_produto_catalogo_posicoes(): array {
    // Base: CNAE principal 6110-8/03 (SCM) + secundários do CNPJ do emitente (6190-6/01, 4751-2/01, 4751-2/02, 4752-1/00, 4753-9/00, 4744-0/99, 4530-7/03 e /05, 4754-7/01 e /02, 4755-5/02 e /03, 4756-3/00, 4761-0/01 e /03, 4772-5/00, 4783-1/01 e /02, 4789-0/05, /06 e /07, 9511-8/00)
    return ['8471', '8472', '8473', '8443', '8517', '8518', '8519', '8523', '8525', '8528', '8529', '8504', '8506', '8507', '8531', '8535', '8536', '8537', '8538', '8539', '8544', '8547', '9001', '9405', '8205', '8467', '8302', '7318', '3917',
            '4802', '4810', '4817', '4820', '4821', '4909', '4911', '9608', '9609', '9610', '9611', '9612', '8305', '8213', '8214', '3919', '3215', '9017', '3926', '4016', '8304', '3213',
            // 4744-0/99 materiais de construção · 4530-7/03 e /05 peças e pneus
            '2523', '3208', '3209', '3210', '3214', '6907', '6908', '6910', '8301', '8481', '7317', '4418', '3922', '3925', '7306', '8212', '4011', '4013', '8708', '8511', '8512', '8421',
            // 4753-9/00 eletrodomésticos e áudio/vídeo · 4754-7 móveis e colchoaria · 4755-5 armarinho, cama, mesa e banho
            '8418', '8450', '8508', '8509', '8510', '8516', '8521', '8527', '9401', '9403', '9404', '5401', '5806', '6217', '9605', '9606', '9607', '9615', '6301', '6302', '6303', '6304',
            // 4756-3 instrumentos musicais · 4761-0 livros e papelaria · 4772-5 cosméticos/higiene · 4783-1 joalheria e relojoaria · 4789-0 saneantes, fogos, escritório
            '9201', '9202', '9205', '9207', '9208', '9209', '4901', '4903', '3303', '3304', '3305', '3306', '3307', '3401', '9603', '7113', '7114', '7117', '9101', '9102', '9105', '9111', '9113', '3402', '3808', '3405', '3604'];
}

/** Importa para ws_produto um produto por NCM de 8 dígitos das famílias acima (fonte='catalogo'). Não altera nem duplica o que já existe. @return array [ok, mensagem] */
function ws_produto_catalogo_importar(PDO $db): array {
    ws_produto_tabelas($db);
    if (!(int)$db->query("SELECT COUNT(*) FROM ws_ncm")->fetchColumn()) { [$o, $m] = ws_ncm_atualizar($db); if (!$o) return [false, $m]; }
    $ex = []; foreach ($db->query("SELECT ncm, descricao FROM ws_produto")->fetchAll(PDO::FETCH_NUM) as [$n, $d]) $ex[$n . '|' . mb_strtolower($d)] = 1;
    $novos = 0; $ins = $db->prepare("INSERT INTO ws_produto (descricao, ncm, unidade, obs, fonte) VALUES (?,?,'UN','Catálogo da tabela oficial de NCM — conferir CEST/CFOP/CSOSN com o contador','catalogo')");
    $db->beginTransaction();
    try {
        foreach (ws_produto_catalogo_posicoes() as $pos) {
            $st = $db->prepare("SELECT codigo, descricao FROM ws_ncm WHERE codigo LIKE ? ORDER BY codigo"); $st->execute([$pos . '%']);
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$cod, $desc]) {
                $seg = array_values(array_filter(array_map('trim', explode(' > ', (string)$desc)), 'strlen')); if (!$seg) continue;
                $nome = rtrim((string)array_pop($seg), ' :;.');
                if ($seg && (mb_strlen($nome) < 28 || preg_match('/^(outr[oa]s?|os demais|as demais|demais)\b/iu', $nome) || preg_match('/^(de|do|da|dos|das|para|com|sem|em|que|tipo|cuj[oa]s?|concebid[oa]s?|próprios?)\s/iu', $nome))) $nome = rtrim((string)end($seg), ' :;.') . ' — ' . $nome;
                $nome = mb_strimwidth(preg_replace('/\s+/u', ' ', $nome), 0, 120, '…'); $k = $cod . '|' . mb_strtolower($nome); if (isset($ex[$k])) continue;
                $ins->execute([$nome, $cod]); $ex[$k] = 1; $novos++;
            }
        }
        $db->commit();
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); return [false, 'Falha ao importar o catálogo: ' . $e->getMessage()]; }
    return [true, 'Catálogo importado: ' . $novos . ' produtos novos (CNAEs do CNPJ: informática, telecom, papelaria, construção, eletrodomésticos, móveis, armarinho, cosméticos, joias, saneantes…). Os que você já tinha ficaram como estavam.'];
}
