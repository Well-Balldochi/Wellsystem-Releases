<?php
/**
 * WellSystem — Fiscal: cadastro de TOMADORES (13/11/2026).
 * Página única (fiscal.php?p=tomadores) que reúne os clientes do WellSystem com os dados que a nota fiscal precisa
 * (nome, CPF/CNPJ, endereço completo, CEP, e-mail, telefone) e diz o que falta em cada um. Todo cliente que ganha uma nota
 * entra sozinho na lista "Cadastrados para nota" (ws_tomador); também dá para cadastrar um tomador novo ali.
 * Não existe cadastro paralelo: o tomador É o cliente (ws_cliente) — o endereço passa pelo cadastro normalizado (ws_end_resolver).
 * Carregado por fiscal.php (ações de POST rodam no include, antes de qualquer saída).
 */

/** Cria a tabela (idempotente) e traz para a lista quem já tem nota. Collation explícita (regra do projeto). */
function ws_tomador_tabela(PDO $db): void {
    static $feito = false; if ($feito) return; $feito = true;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS ws_tomador (id INT AUTO_INCREMENT PRIMARY KEY, cliente_id INT NOT NULL, origem VARCHAR(10) NOT NULL DEFAULT 'nota',
                   criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_tomador_cliente (cliente_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->exec("INSERT IGNORE INTO ws_tomador (cliente_id, origem) SELECT DISTINCT cliente_id, 'nota' FROM ws_nota");
    } catch (Throwable $e) {}
}

/** O que falta para a nota fiscal sair completa. Aceita a linha do cliente já com o endereço do cadastro normalizado. @return string[] */
function ws_tomador_faltas(array $c): array {
    $f = []; $doc = preg_replace('/\D/', '', (string)($c['cpf_cnpj'] ?? ''));
    if (trim((string)($c['nome'] ?? '')) === '') $f[] = 'nome';
    if (!in_array(strlen($doc), [11, 14], true) || !ws_cpf_cnpj_valido($doc)) $f[] = 'CPF/CNPJ válido';
    foreach (['logradouro' => 'rua', 'bairro' => 'bairro', 'cidade' => 'cidade', 'uf' => 'UF'] as $k => $rot) if (trim((string)($c[$k] ?? '')) === '') $f[] = $rot;
    if (strlen(preg_replace('/\D/', '', (string)($c['cep'] ?? ''))) !== 8) $f[] = 'CEP';
    return $f;
}

/** Texto de busca: cada palavra precisa aparecer em algum campo (nome, código, documento, e-mail, telefone, rua, bairro, cidade, CEP). */
function ws_tomador_where_busca(PDO $db, string $q): string {
    $partes = [];
    foreach (preg_split('/\s+/u', trim($q), -1, PREG_SPLIT_NO_EMPTY) as $tk) {
        $like = $db->quote('%' . addcslashes($tk, '%_') . '%'); $dig = preg_replace('/\D/', '', $tk);
        $c = ["c.nome LIKE $like", "c.codigo LIKE $like", "c.email LIKE $like", "c.telefone LIKE $like", "c.celular LIKE $like", "wl.nome LIKE $like", "wb.nome LIKE $like", "wc.nome LIKE $like"];
        if (strlen($dig) >= 4) { $ld = $db->quote('%' . $dig . '%'); $c[] = "REPLACE(REPLACE(REPLACE(c.cpf_cnpj,'.',''),'-',''),'/','') LIKE $ld"; $c[] = "wp.cep LIKE $ld"; }
        $partes[] = '(' . implode(' OR ', $c) . ')';
    }
    return $partes ? implode(' AND ', $partes) : '1=1';
}

/**
 * Grava (cria ou atualiza) um tomador = cliente. Valida o que a nota exige e passa o endereço pelo cadastro normalizado.
 * @param array $d nome, cpf_cnpj, rg_ie, email, telefone, cep, logradouro, numero, complemento, bairro, cidade, uf
 * @return array ['ok'=>bool,'erro'=>string,'id'=>int,'codigo'=>string]
 */
function ws_tomador_gravar(PDO $db, int $id, array $d): array {
    $nome = trim(preg_replace('/\s+/u', ' ', (string)($d['nome'] ?? ''))); $doc = preg_replace('/\D/', '', (string)($d['cpf_cnpj'] ?? ''));
    $email = trim((string)($d['email'] ?? '')); $fone = trim((string)($d['telefone'] ?? '')); $cep = preg_replace('/\D/', '', (string)($d['cep'] ?? ''));
    $log = trim(preg_replace('/\s+/u', ' ', (string)($d['logradouro'] ?? ''))); $bai = trim(preg_replace('/\s+/u', ' ', (string)($d['bairro'] ?? '')));
    $cid = trim(preg_replace('/\s+/u', ' ', (string)($d['cidade'] ?? ''))); $uf = strtoupper(trim((string)($d['uf'] ?? '')));
    $num = trim((string)($d['numero'] ?? '')); $cpl = trim((string)($d['complemento'] ?? '')); $ie = trim((string)($d['rg_ie'] ?? '')); $im = trim((string)($d['inscricao_municipal'] ?? ''));
    $fail = fn(string $m) => ['ok' => false, 'erro' => $m, 'id' => $id, 'codigo' => ''];
    /* 14/11/2026 (nota 57): a NFCom/NF-e só aceita Latin-1 nos textos; travessão (—), emoji etc. fazem a SEFAZ rejeitar a nota (215). Barra na hora de salvar, dizendo qual campo e qual caractere. */
    foreach (['nome' => ['Nome / razão social', $nome], 'logradouro' => ['Rua / logradouro', $log], 'bairro' => ['Bairro', $bai], 'cidade' => ['Cidade', $cid], 'complemento' => ['Complemento', $cpl], 'numero' => ['Número', $num]] as [$rot, $val]) {
        if (preg_match('/[^\x{20}-\x{7E}\x{A0}-\x{FF}]/u', (string)$val, $mm)) return $fail('Campo "' . $rot . '" tem o caractere "' . $mm[0] . '", que a nota fiscal não aceita. Troque por letra, número ou hífen comum (-).');
    }
    if ($nome === '') return $fail('Informe o nome / razão social.');
    if (!in_array(strlen($doc), [11, 14], true) || !ws_cpf_cnpj_valido($doc)) return $fail('CPF/CNPJ inválido.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) return $fail('E-mail inválido.');
    if (strlen($cep) !== 8) return $fail('CEP precisa ter 8 dígitos.');
    if ($log === '' || $bai === '' || $cid === '' || !preg_match('/^[A-Z]{2}$/', $uf)) return $fail('Preencha rua, bairro, cidade e UF (2 letras).');
    $q = $db->prepare("SELECT id, codigo FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/','') = ? AND id <> ? LIMIT 1"); $q->execute([$doc, $id]); $dup = $q->fetch();
    if ($dup) return $fail('Já existe cliente com este CPF/CNPJ (código ' . $dup['codigo'] . '). Use o botão Editar dele.');
    require_once __DIR__ . '/schema_endereco.php';
    $e = ws_end_resolver($db, ['cep' => substr($cep, 0, 5) . '-' . substr($cep, 5), 'logradouro' => $log, 'bairro' => $bai, 'cidade' => $cid, 'uf' => $uf]);
    $tipo = strlen($doc) === 14 ? 'PJ' : 'PF';
    $docFmt = strlen($doc) === 14 ? preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $doc) : preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $doc);
    $comuns = ['tipo' => $tipo, 'nome' => $nome, 'cpf_cnpj' => $docFmt, 'rg_ie' => $ie, 'inscricao_municipal' => $im, 'email' => $email, 'telefone' => $fone, 'numero' => $num, 'complemento' => $cpl,
               'cep' => $e['cep'], 'logradouro' => $e['logradouro'], 'bairro' => $e['bairro'], 'cidade' => $e['cidade'], 'uf' => $e['uf'], 'logradouro_id' => $e['logradouro_id'], 'uf_id' => $e['uf_id']];
    try {
        if ($id > 0) {
            $set = implode(',', array_map(fn($k) => "$k=:$k", array_keys($comuns)));
            $db->prepare("UPDATE ws_cliente SET $set, atualizado_em=NOW() WHERE id=:id")->execute($comuns + ['id' => $id]);
            $codigo = (string)$db->query("SELECT codigo FROM ws_cliente WHERE id=" . $id)->fetchColumn();
            if (function_exists('ws_evento')) ws_evento($db, $id, 'cliente', 'Cadastro do tomador atualizado (Fiscal): ' . $nome);
        } else {
            $cols = array_merge(array_keys($comuns), ['status', 'data_cadastro']); $ph = implode(',', array_map(fn($k) => ":$k", $cols));
            $db->prepare("INSERT INTO ws_cliente (" . implode(',', $cols) . ") VALUES ($ph)")->execute($comuns + ['status' => 'ativo', 'data_cadastro' => date('Y-m-d')]);
            $id = (int)$db->lastInsertId(); $codigo = ws_cliente_codigo($db, $id);
            if (function_exists('ws_evento')) ws_evento($db, $id, 'cliente', 'Cliente cadastrado como tomador (Fiscal): ' . $nome);
        }
        ws_tomador_tabela($db);
        $db->prepare("INSERT INTO ws_tomador (cliente_id, origem) VALUES (?, 'manual') ON DUPLICATE KEY UPDATE cliente_id = cliente_id")->execute([$id]);
    } catch (Throwable $ex) { return $fail('Não consegui gravar: ' . $ex->getMessage()); }
    return ['ok' => true, 'erro' => '', 'id' => $id, 'codigo' => $codigo];
}

/** Valor digitado ("100", "100,00", "R$ 1.250,50") → número; null se não parece valor. */
function ws_busca_valor(string $tk): ?float {
    $t = trim(str_ireplace('R$', '', $tk));
    if (preg_match('/^\d{1,3}(\.\d{3})+,\d{1,2}$/', $t)) return (float)str_replace(',', '.', str_replace('.', '', $t));
    if (preg_match('/^\d+([.,]\d{1,2})?$/', $t)) return (float)str_replace(',', '.', $t);
    return null;
}

/**
 * Busca das notas (lista de Notas fiscais). Cada palavra digitada precisa casar em ALGUM destes campos: nº da nota (interno, NFS-e, NF-e, NFCom),
 * nome ou trecho do nome do cliente, código do cliente, CPF/CNPJ, valor, conteúdo (descrição dos itens), observação e chave de acesso.
 * $t é a consulta com as colunas do UNION de fs_notas.
 */
function ws_notas_where_busca(PDO $db, string $q): string {
    $partes = [];
    foreach (preg_split('/\s+/u', trim($q), -1, PREG_SPLIT_NO_EMPTY) as $tk) {
        $like = $db->quote('%' . addcslashes($tk, '%_') . '%'); $eq = $db->quote($tk); $dig = preg_replace('/\D/', '', $tk);
        $c = ["t.cnome LIKE $like", "t.ccodigo LIKE $like", "t.obs LIKE $like",
              "(t.origem = 'nota' AND EXISTS (SELECT 1 FROM ws_nota_item i WHERE i.nota_id = t.id AND i.descricao LIKE $like))"];
        if ($dig !== '' && $dig === $tk) { $c[] = "CAST(t.id AS CHAR) = $eq"; $c[] = "t.numero_nfse = $eq"; $c[] = "t.numero_nfe55 = $eq"; $c[] = "t.numero_nfcom = $eq"; }
        if (strlen($dig) >= 5) { $ld = $db->quote('%' . $dig . '%'); $c[] = "REPLACE(REPLACE(REPLACE(t.cdoc,'.',''),'-',''),'/','') LIKE $ld"; }   // documento só com 5+ dígitos (senão "3" casava com quase todo CNPJ)
        if (strlen($tk) >= 6) { $c[] = "t.chave_nfcom LIKE $like"; $c[] = "t.chave_nfe55 LIKE $like"; $c[] = "t.codigo_verificacao LIKE $like"; }
        $vl = ws_busca_valor($tk); if ($vl !== null) $c[] = "ABS(t.total - " . (float)$vl . ") < 0.005";
        $partes[] = '(' . implode(' OR ', $c) . ')';
    }
    return $partes ? implode(' AND ', $partes) : '1=1';
}

/** JSON do tomador (usado pelo cartão do formulário da nota: mostra na hora se os dados estão completos para a nota). */
if (($_GET['p'] ?? '') === 'tomador_json') {
    header('Content-Type: application/json; charset=utf-8'); require_once __DIR__ . '/schema_endereco.php';
    $idJ = (int)($_GET['id'] ?? 0); $qJ = $db->prepare("SELECT id, codigo, nome, cpf_cnpj, email, telefone, celular, numero, status FROM ws_cliente WHERE id=?"); $qJ->execute([$idJ]); $cJ = $qJ->fetch();
    if (!$cJ) { echo json_encode(['ok' => false]); exit; }
    $eJ = ws_end_cliente($db, $idJ); $lin = $cJ + $eJ; $falt = ws_tomador_faltas($lin);
    echo json_encode(['ok' => true, 'id' => (int)$cJ['id'], 'codigo' => $cJ['codigo'], 'nome' => $cJ['nome'], 'doc' => $cJ['cpf_cnpj'], 'email' => (string)$cJ['email'], 'fone' => trim((string)($cJ['telefone'] ?: $cJ['celular'])),
        'endereco' => trim($eJ['logradouro'] . (trim((string)$cJ['numero']) !== '' ? ', ' . trim((string)$cJ['numero']) : ', S/N') . ' - ' . $eJ['bairro'] . ' - ' . $eJ['cidade'] . '/' . $eJ['uf']), 'cep' => $eJ['cep'], 'status' => $cJ['status'], 'faltas' => $falt], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ------------------------------------------------------------- AÇÕES (POST) */
if (($_POST['acao'] ?? '') === 'tomador_salvar') {
    ws_api_exigir_edicao('fiscal.php?p=tomadores');
    $idT = (int)($_POST['cliente_id'] ?? 0);
    $r = ws_tomador_gravar($db, $idT, $_POST);
    $_SESSION['ws_flash'] = $r['ok'] ? ('Tomador salvo (código ' . $r['codigo'] . ').') : ('Erro: ' . $r['erro']);
    if ($r['ok']) { header('Location: fiscal.php?p=tomadores&aba=cadastrados&q=' . urlencode($r['codigo'])); exit; }
    $_SESSION['ws_tomador_form'] = $_POST; header('Location: fiscal.php?p=tomador&id=' . $idT); exit;
}
if (($_POST['acao'] ?? '') === 'tomador_adicionar') {   // põe um cliente do WellSystem na lista de tomadores cadastrados
    ws_api_exigir_edicao('fiscal.php?p=tomadores');
    ws_tomador_tabela($db); $cidT = (int)($_POST['cliente_id'] ?? 0);
    if ($cidT > 0) { $db->prepare("INSERT INTO ws_tomador (cliente_id, origem) VALUES (?, 'manual') ON DUPLICATE KEY UPDATE cliente_id = cliente_id")->execute([$cidT]); $_SESSION['ws_flash'] = 'Cliente adicionado à lista de tomadores.'; }
    header('Location: fiscal.php?p=tomadores&aba=cadastrados'); exit;
}

/* ------------------------------------------------------------- PÁGINAS */
function fs_tomadores(PDO $db): void {
    ws_tomador_tabela($db); require_once __DIR__ . '/schema_endereco.php';
    $aba = (string)($_GET['aba'] ?? 'cadastrados'); if (!in_array($aba, ['cadastrados', 'todos'], true)) $aba = 'cadastrados';
    $q = trim((string)($_GET['q'] ?? '')); $busca = ws_tomador_where_busca($db, $q);
    $base = "FROM ws_cliente c" . ws_end_sql_join('c') . " LEFT JOIN ws_tomador tm ON tm.cliente_id=c.id";
    $cont = [];
    foreach (['cadastrados' => "tm.id IS NOT NULL AND c.status<>'cancelado'", 'todos' => "c.status<>'cancelado'"] as $k => $w) $cont[$k] = (int)$db->query("SELECT COUNT(*) $base WHERE $w AND $busca")->fetchColumn();
    $total = $cont[$aba]; [$pp, $pg, $lim] = ws_paginar($total);
    $filtro = $aba === 'cadastrados' ? "tm.id IS NOT NULL AND c.status<>'cancelado'" : "c.status<>'cancelado'";   // 14/11/2026: cliente desativado (cancelado) nunca aparece nos Tomadores
    $rows = $db->query("SELECT c.id, c.codigo, c.nome, c.cpf_cnpj, c.email, c.telefone, c.celular, c.numero, c.complemento, c.status," . ws_end_sql_campos() . ",
                        tm.id tomador_id, tm.origem, (SELECT COUNT(*) FROM ws_nota n WHERE n.cliente_id=c.id AND n.status IN ('enviada','autorizada')) qtd_notas
                        $base WHERE $filtro AND $busca ORDER BY c.nome$lim")->fetchAll();
    $podeEditar = true; if (function_exists('ws_nivel_edita')) { try { $podeEditar = (bool)ws_nivel_edita(); } catch (Throwable $e) {} }
    ?>
    <div class="ws-head-row"><h2>👤 Tomadores · cadastro para nota fiscal</h2></div>
    <p class="ws-muted">O tomador é o cliente do WellSystem. Todo cliente que ganha uma nota entra sozinho em <b>Cadastrados para nota</b>; em <b>Todos os clientes</b> estão todos os cadastrados. A coluna "Dados para nota" diz o que falta para a nota sair completa.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
      <a class="ws-btn <?= $aba === 'cadastrados' ? 'primary' : '' ?>" href="fiscal.php?p=tomadores&aba=cadastrados&q=<?= urlencode($q) ?>">📋 Cadastrados para nota · <?= (int)$cont['cadastrados'] ?></a>
      <a class="ws-btn <?= $aba === 'todos' ? 'primary' : '' ?>" href="fiscal.php?p=tomadores&aba=todos&q=<?= urlencode($q) ?>">👥 Todos os clientes · <?= (int)$cont['todos'] ?></a>
      <a class="ws-btn" href="fiscal.php?p=tomador&id=0">➕ Cadastrar tomador</a>
    </div>
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;margin:6px 0 10px"><input type="hidden" name="p" value="tomadores"><input type="hidden" name="aba" value="<?= h($aba) ?>">
      <input name="q" value="<?= h($q) ?>" placeholder="Buscar: nome ou trecho, código, CPF/CNPJ, e-mail, telefone, rua, bairro, CEP…" style="min-width:min(340px,100%);flex:1">
      <button class="ws-btn primary">🔎 Buscar</button><?php if ($q !== ''): ?> <a class="ws-btn" href="fiscal.php?p=tomadores&aba=<?= h($aba) ?>">Limpar</a><?php endif; ?></form>
    <?= ws_paginacao_topo($total, $pp, $pg, ['p' => 'tomadores', 'aba' => $aba, 'q' => $q]) ?>
    <?php if (!$rows): ?><div class="ws-alert">Nenhum tomador encontrado<?= $q !== '' ? ' para "' . h($q) . '"' : '' ?>.</div><?php else: ?>
    <style>   /* 13/11/2026: ações na MESMA linha, sem estourar a página: fonte menor nesta tabela, ações sem quebra e rolagem lateral só se a tela for muito estreita */
      .tm-wrap{overflow-x:auto} .tm-tab td,.tm-tab th{font-size:12.5px;padding:8px 6px} .tm-tab td{word-break:break-word}
      .tm-tab td.tm-acoes{white-space:nowrap;width:1%} .tm-tab td.tm-acoes .ws-btn{padding:3px 9px;font-size:12px;margin-right:3px;display:inline-block} .tm-tab td.tm-acoes form{display:inline}
    </style>
    <div class="tm-wrap"><table class="ws-table tm-tab"><thead><tr><th>Código</th><th>Nome</th><th>CPF/CNPJ</th><th>E-mail</th><th>Telefone</th><th>Endereço</th><th>CEP</th><th>Dados para nota</th><th>Notas</th><th>Ações</th></tr></thead><tbody>
    <?php foreach ($rows as $r):
        $faltas = ws_tomador_faltas($r); $fone = trim((string)($r['telefone'] ?: $r['celular']));
        $end = trim(($r['logradouro'] ?? '') . (trim((string)$r['numero']) !== '' ? ', ' . trim((string)$r['numero']) : ', S/N') . ' - ' . ($r['bairro'] ?? '') . ' - ' . ($r['cidade'] ?? '') . '/' . ($r['uf'] ?? '')); ?>
      <tr><td><?= h($r['codigo']) ?></td><td><b><?= h($r['nome']) ?></b><?= $r['status'] !== 'ativo' ? ' <span class="ws-tag bloqueado" style="text-transform:none">' . h($r['status'] === 'cancelado' ? 'desativado' : $r['status']) . '</span>' : '' ?></td>
        <td><?= h($r['cpf_cnpj']) ?></td><td><?= h((string)$r['email']) ?></td><td><?= h($fone) ?></td><td><?= h($end) ?></td><td><?= h((string)$r['cep']) ?></td>
        <td><?php if (!$faltas): ?><span class="ws-tag ativo" style="text-transform:none">Completo</span><?php else: ?><span class="ws-tag suspenso" style="text-transform:none" title="<?= h(implode(', ', $faltas)) ?>">Falta: <?= h(implode(', ', $faltas)) ?></span><?php endif; ?></td>
        <td><?= (int)$r['qtd_notas'] ?></td>
        <td class="tm-acoes">
          <a class="ws-btn" href="fiscal.php?p=tomador&id=<?= (int)$r['id'] ?>">✏️ Editar</a>
          <?php if ($r['status'] === 'ativo'): ?><a class="ws-btn" href="fiscal.php?p=nova&cliente=<?= (int)$r['id'] ?>">🧾 Nova nota</a><?php endif; ?>
          <?php if ((int)$r['qtd_notas'] > 0): ?><a class="ws-btn" href="fiscal.php?p=notas&aba=nfcom&q=<?= urlencode((string)$r['codigo']) ?>">📋 Notas</a><?php endif; ?>
          <?php if (!$r['tomador_id']): ?><form method="post" style="display:inline"><input type="hidden" name="acao" value="tomador_adicionar"><input type="hidden" name="cliente_id" value="<?= (int)$r['id'] ?>"><button class="ws-btn" type="submit" title="Colocar na lista de cadastrados para nota">➕ Adicionar</button></form><?php endif; ?>
        </td></tr>
    <?php endforeach; ?></tbody></table></div>
    <?= ws_paginacao_html($total, $pp, $pg, ['p' => 'tomadores', 'aba' => $aba, 'q' => $q]) ?>
    <?php endif;
}

function fs_tomador_form(PDO $db): void {
    require_once __DIR__ . '/schema_endereco.php';
    $id = (int)($_GET['id'] ?? 0); $v = ['nome' => '', 'cpf_cnpj' => '', 'rg_ie' => '', 'inscricao_municipal' => '', 'email' => '', 'telefone' => '', 'cep' => '', 'logradouro' => '', 'numero' => '', 'complemento' => '', 'bairro' => '', 'cidade' => (string)(ws_nfse_config()['cidade'] ?? ''), 'uf' => strtoupper((string)(ws_nfse_config()['uf'] ?? ''))];   // padrão = cidade/UF do emissor (produto genérico: nada da Wellnet embutido)
    if ($id > 0) {
        $q = $db->prepare("SELECT id, codigo, nome, cpf_cnpj, rg_ie, inscricao_municipal, email, telefone, celular, numero, complemento FROM ws_cliente WHERE id=?"); $q->execute([$id]); $c = $q->fetch();
        if (!$c) { echo '<div class="ws-alert err">Cliente não encontrado.</div>'; return; }
        $e = ws_end_cliente($db, $id);
        $v = ['nome' => $c['nome'], 'cpf_cnpj' => $c['cpf_cnpj'], 'rg_ie' => (string)$c['rg_ie'], 'inscricao_municipal' => (string)($c['inscricao_municipal'] ?? ''), 'email' => (string)$c['email'], 'telefone' => trim((string)($c['telefone'] ?: $c['celular'])),
              'cep' => $e['cep'], 'logradouro' => $e['logradouro'], 'numero' => (string)$c['numero'], 'complemento' => (string)($c['complemento'] ?? ''), 'bairro' => $e['bairro'], 'cidade' => $e['cidade'], 'uf' => $e['uf']];
    }
    if (!empty($_SESSION['ws_tomador_form']) && is_array($_SESSION['ws_tomador_form'])) { $v = array_merge($v, array_intersect_key($_SESSION['ws_tomador_form'], $v)); unset($_SESSION['ws_tomador_form']); }
    $in = fn(string $k, string $rot, string $extra = '', string $cls = '') => '<label class="' . $cls . '">' . h($rot) . ' <input name="' . $k . '" value="' . h((string)$v[$k]) . '" ' . $extra . '></label>';
    ?>
    <div class="ws-head-row"><h2><?= $id > 0 ? '✏️ Editar tomador' : '➕ Cadastrar tomador' ?></h2></div>
    <p class="ws-muted">Estes são os dados que vão na nota fiscal. O tomador é o próprio cliente do WellSystem: o que for salvo aqui vale no cadastro do cliente também. <a href="fiscal.php?p=tomadores">← voltar para Tomadores</a></p>
    <?= ws_api_bloqueio_html() ?>
    <form method="post" class="ws-form grid">
      <input type="hidden" name="acao" value="tomador_salvar"><input type="hidden" name="cliente_id" value="<?= $id ?>">
      <?= $in('nome', 'Nome / razão social *', 'required maxlength="120"', 'c2') ?>
      <?= $in('cpf_cnpj', 'CPF ou CNPJ *', 'required maxlength="18" placeholder="somente números ou com pontuação"') ?>
      <?= $in('rg_ie', 'RG / Inscrição estadual (opcional)', 'maxlength="30"') ?>
      <?= $in('inscricao_municipal', 'Inscrição municipal (opcional)', 'maxlength="30"') ?>
      <?= $in('email', 'E-mail', 'type="email" maxlength="60"') ?>
      <?= $in('telefone', 'Telefone / WhatsApp', 'maxlength="20"') ?>
      <?= $in('cep', 'CEP *', 'required maxlength="9" placeholder="00000-000"') ?>
      <?= $in('logradouro', 'Rua / logradouro *', 'required maxlength="120"', 'c2') ?>
      <?= $in('numero', 'Número', 'maxlength="20" placeholder="vazio = S/N"') ?>
      <?= $in('complemento', 'Complemento', 'maxlength="60"') ?>
      <?= $in('bairro', 'Bairro *', 'required maxlength="80"') ?>
      <?= $in('cidade', 'Cidade *', 'required maxlength="80"') ?>
      <?= $in('uf', 'UF *', 'required maxlength="2" style="text-transform:uppercase"') ?>
      <script>
      /* 14/11/2026: avisa NA HORA, ao digitar, se o campo tem caractere que a nota fiscal não aceita (travessão, emoji...) e impede salvar até ajustar. */
      (function () {
        var f = document.currentScript.closest('form'), ruim = /[^\x20-\x7E\xA0-\xFF]/;
        ['nome', 'logradouro', 'numero', 'complemento', 'bairro', 'cidade'].forEach(function (n) {
          var el = f.elements[n]; if (!el) return;
          var av = document.createElement('small'); av.style.cssText = 'display:none;color:#b00020;font-weight:600'; el.parentNode.appendChild(av);
          function conferir() {
            var m = ruim.exec(el.value);
            if (m) { av.textContent = '⚠️ O caractere "' + m[0] + '" não é aceito na nota fiscal. Ajuste (use hífen comum - ou apague).'; av.style.display = 'block'; el.style.borderColor = '#b00020'; el.setCustomValidity('Caractere inválido para nota fiscal: ' + m[0]); }
            else { av.style.display = 'none'; el.style.borderColor = ''; el.setCustomValidity(''); }
          }
          el.addEventListener('input', conferir); el.addEventListener('blur', conferir); conferir();
        });
      })();
      </script>
      <div class="c4" style="display:flex;gap:8px"><button class="ws-btn primary">💾 Salvar tomador</button><a class="ws-btn" href="fiscal.php?p=tomadores">Cancelar</a>
        <?php if ($id > 0): ?><a class="ws-btn" href="fiscal.php?p=nova&cliente=<?= $id ?>">🧾 Nova nota para este tomador</a><?php endif; ?></div>
    </form>
    <?php
}
