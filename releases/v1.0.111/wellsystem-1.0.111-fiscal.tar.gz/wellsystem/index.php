<?php
/**
 * WellSystem — entrada. Decide instalador x painel testando a CONEXÃO real com o banco (não um
 * arquivo em caminho fixo — que sumia quando o AppArmor mandava a config pro fallback ou o painel
 * recriava o addon). Se conecta, o config.php já auto-grava a config (cache/ + espelho /var/tmp).
 * Se o HOST acessado for o da "Central do assinante", mostra a central pública em vez do painel.
 */
require __DIR__ . '/config.php';

// Gate de ATIVAÇÃO (anti-cópia amarrada ao domínio): sem ativação válida neste servidor, vai pra
// tela de ativação (que, ao acertar a senha, segue pro instalador).
if (function_exists('ws_ativacao_exigida') && ws_ativacao_exigida() && !ws_ativado()) { header('Location: ativacao.php'); exit; }

// Sem conexão = instalação nova -> instalador. Com conexão = segue normal (config auto-persistida).
try { ws_db(); }
catch (Throwable $e) { header('Location: install.php'); exit; }

// Host da central do assinante, configurado em Central do assinante (central.php).
$centralCfgFile = WS_CACHE . '/central.json';
/* ROTEAMENTO POR DOMÍNIO — vários domínios, um sistema.
 * Um provedor usa mais de um endereço para o mesmo servidor: erp.dominio / financeiro.dominio
 * para o painel, assinante.dominio para a central. A regra é simples e não precisa de lista dupla:
 * quem está na lista da CENTRAL vai para a central; TODO O RESTO vai para o painel. Assim, para
 * atender outro provedor, muda-se só a configuração — nenhuma linha de código.
 * Aceita os dois formatos: "hosts" (lista) e "host" (texto, podendo ter vírgulas). */
$hostsCentral = [];
if (is_file($centralCfgFile)) {
    $j = json_decode((string)@file_get_contents($centralCfgFile), true);
    if (is_array($j)) {
        foreach ((array)($j['hosts'] ?? []) as $h) {
            $h = strtolower(trim((string)$h)); if ($h !== '') $hostsCentral[] = $h;
        }
        // Formato antigo (um host em texto) — e também aceita "a.com, b.com" digitado de uma vez.
        foreach (explode(',', (string)($j['host'] ?? '')) as $h) {
            $h = strtolower(trim($h)); if ($h !== '') $hostsCentral[] = $h;
        }
    }
}
$hostAtual = strtolower(explode(':', (string)($_SERVER['HTTP_HOST'] ?? ''), 2)[0]);
if ($hostsCentral && in_array($hostAtual, $hostsCentral, true)) {
    header('Location: central_pub.php'); exit;
}
header('Location: erp.php');
exit;
