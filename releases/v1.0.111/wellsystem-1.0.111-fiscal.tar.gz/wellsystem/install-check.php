<?php
/**
 * WellSystem — Diagnóstico do servidor (o que está pronto / o que falta).
 * Abra no navegador: .../wellsystem/install-check.php
 * Não altera nada — só verifica PHP, extensões, permissões, banco, tabelas e binários.
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/celcash.php';
require_once __DIR__ . '/whatsapp.php';

/** Cada item: [rótulo, ok(bool|null), detalhe]. null = aviso (opcional). */
$checks = [];
$add = function ($label, $ok, $detalhe = '') use (&$checks) { $checks[] = [$label, $ok, $detalhe]; };

// PHP
$add('PHP ≥ 7.4', version_compare(PHP_VERSION, '7.4.0', '>='), 'Versão: ' . PHP_VERSION);
foreach (['pdo_mysql' => true, 'curl' => true, 'mbstring' => true, 'openssl' => true, 'snmp' => null, 'json' => true] as $ext => $obrig) {
    $ok = extension_loaded($ext);
    $add("Extensão $ext" . ($obrig === null ? ' (opcional, p/ SNMP da OLT)' : ''), $obrig === null ? ($ok ? true : null) : $ok);
}

/* PASTAS GRAVÁVEIS — o próprio verificador CONSERTA antes de reclamar.
   Antes ele só apontava o problema e mandava rodar mkdir/chmod por SSH: numa instalação nova
   ninguém faz isso, e o sistema subia sem conseguir gravar logo, fundo de login nem foto. Agora
   ws_garantir_pastas() cria e ajusta a permissão de todas elas; só sobra na tela o que resistiu
   — e aí o comando manual é o último recurso, não a rotina. */
$pastasRuins = function_exists('ws_garantir_pastas') ? ws_garantir_pastas() : [];

$grav = is_dir(WS_CACHE) && is_writable(WS_CACHE);
$detalheCache = WS_CACHE;
if (!$grav) {
    $detalheCache .= ' — RODE NO SERVIDOR (via SSH/terminal): mkdir -p ' . WS_CACHE . ' && chmod 775 ' . WS_CACHE;
    if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
        $me = @posix_getpwuid(posix_geteuid());
        if ($me) $detalheCache .= ' && chown ' . $me['name'] . ' ' . WS_CACHE . ' (o PHP roda como "' . $me['name'] . '" neste servidor)';
    }
}
$add('Pasta cache/ gravável', $grav, $detalheCache);

// Pastas de imagem/upload: logo, fundos do login, imagens da central, fotos e anexos.
/* O config.php do servidor é o atual?
   Quando as pastas do addon não aceitam escrita, o ws_resolver_uploads_dir() do config.php novo
   MUDA a pasta de uploads sozinho (para dentro da pasta de cache, que comprovadamente grava).
   Se esta linha disser que a função não existe, o arquivo no servidor é uma versão anterior — e
   nenhuma correção de upload vai valer, por mais que o resto esteja certo. */
$temResolver = function_exists('ws_resolver_uploads_dir');
$add('config.php com o resolvedor de uploads', $temResolver,
     $temResolver
        ? ('pasta de uploads em uso: ' . WS_UPLOADS
           . (defined('WS_UPLOADS_FALLBACK') ? ' (plano B automático ativo — a pasta do addon não aceita escrita)' : ' (pasta do addon)'))
        : 'ws_resolver_uploads_dir() NÃO existe — o config.php deste servidor é uma versão ANTIGA. Envie o config.php novo.');

$upOk = !in_array(WS_UPLOADS, $pastasRuins, true) && is_dir(WS_UPLOADS) && is_writable(WS_UPLOADS);
$detalheUp = WS_UPLOADS
    . (defined('WS_UPLOADS_FALLBACK') ? ' (a pasta uploads/ do addon não aceita escrita; o sistema passou a usar este caminho sozinho)' : '');
if ($pastasRuins) $detalheUp .= ' — ainda sem escrita: ' . implode(', ', $pastasRuins);
$add('Pastas de upload graváveis (logo, login, central, fotos)', $upOk && !$pastasRuins, $detalheUp);

/* -------------------------------------------------------------------------------------------
 * UPLOAD DE IMAGEM — TESTE DE VERDADE, não só "a pasta parece gravável".
 *
 * is_writable() diz "sim" e a gravação falha assim mesmo em pelo menos quatro situações comuns
 * num MK-Auth: open_basedir separando a pasta temporária do PHP da de destino, funções
 * desativadas em disable_functions, disco cheio e file_uploads desligado. Nenhuma delas aparece
 * numa checagem de permissão — e todas quebram o envio de logo, fundo de login e foto de
 * equipamento exatamente do mesmo jeito. Aqui cada uma é verificada pelo nome.
 * ------------------------------------------------------------------------------------------- */
$upIni = [];
/* O usuário do PHP é o dado que faltava: dar chown para o usuário errado deixa a pasta com
   permissão perfeita e "Permission denied" mesmo assim. */
$phpUsu = function_exists('ws_php_usuario') ? ws_php_usuario() : '';
if ($phpUsu !== '') $upIni[] = 'PHP roda como "' . $phpUsu . '"';
/* AppArmor aparece como item PRÓPRIO: é a causa que se disfarça de permissão e faz o operador
   rodar chmod/chown à toa. Não é erro — só precisa estar escrito. */
$aaPerfil = function_exists('ws_apparmor_perfil') ? ws_apparmor_perfil() : '';
if ($aaPerfil !== '') {
    $add('AppArmor confinando este PHP', null,
         $aaPerfil . ' — quem decide onde o PHP pode escrever é este perfil, não o chmod. '
         . 'Se o envio de imagem falhar com "Permission denied", use Manutenção → "Liberar AppArmor p/ gravar imagens". '
         . 'O sistema já contorna sozinho gravando na pasta de cache.');
}
$upIni[] = 'file_uploads=' . (ini_get('file_uploads') ? 'On' : 'OFF (bloqueia TODO envio)');
$upIni[] = 'upload_max_filesize=' . ini_get('upload_max_filesize');
$upIni[] = 'post_max_size=' . ini_get('post_max_size');
$tmpUp = ini_get('upload_tmp_dir') ?: sys_get_temp_dir();
$upIni[] = 'upload_tmp_dir=' . $tmpUp . (is_writable($tmpUp) ? '' : ' (SEM escrita!)');
$ob = trim((string)ini_get('open_basedir'));
if ($ob !== '') $upIni[] = 'open_basedir=' . $ob;
$add('Envio de arquivos (PHP)', (bool)ini_get('file_uploads') && is_writable($tmpUp), implode(' · ', $upIni));

// Funções que o envio usa — se estiverem em disable_functions, nada grava e o erro não diz isso.
$fnFalta = [];
foreach (['move_uploaded_file', 'rename', 'copy', 'mkdir', 'chmod', 'file_put_contents'] as $fn) {
    if (!function_exists($fn)) $fnFalta[] = $fn;
}
$add('Funções de gravação disponíveis', !$fnFalta,
     $fnFalta ? 'DESATIVADAS em disable_functions: ' . implode(', ', $fnFalta) . ' — é isto que impede o envio de imagens.'
              : 'move_uploaded_file, rename, copy, mkdir, chmod, file_put_contents');

// Gravação REAL nas duas pastas que recebem imagem, com o motivo do PHP quando falha.
foreach (['assets/' => WS_DIR . '/assets', 'uploads/sistema/' => WS_UPLOADS . '/sistema'] as $rot => $dirTeste) {
    if (!is_dir($dirTeste)) @mkdir($dirTeste, 0775, true);
    $arqT = rtrim($dirTeste, '/') . '/.ws_teste_' . getmypid() . '.txt';
    error_clear_last();
    $bytes = @file_put_contents($arqT, 'teste');
    if ($bytes !== false) {
        @unlink($arqT);
        $livre = @disk_free_space($dirTeste);
        $add('Gravar imagem em ' . $rot, true, $dirTeste
             . ($livre !== false ? ' · livre no disco: ' . round($livre / 1048576) . ' MB' : ''));
    } else {
        $e = error_get_last();
        $add('Gravar imagem em ' . $rot, false, $dirTeste . ' — ' . trim((string)($e['message'] ?? 'o PHP não informou o motivo')));
    }
}

// Banco + tabelas
$tabelasEsperadas = ['ws_usuario','ws_cliente','ws_plano','ws_contrato','ws_fatura','ws_pagamento',
                     'ws_regua','ws_notificacao','ws_anexo','ws_online_hist',
                     'ws_chamado','ws_chamado_msg','ws_evento','ws_nfse','ws_lead','ws_banco',
                     'radcheck','radreply','radgroupreply','radusergroup','radacct','nas'];
$dbOk = false; $faltando = [];
try {
    $db = ws_db();
    $dbOk = true;
    $existentes = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $faltando = array_diff($tabelasEsperadas, array_map('strtolower', $existentes));
    $add('Conexão com o banco', true, ws_db_config()['dbname'] . ' @ ' . ws_db_config()['host']);
    $add('Tabelas criadas (' . (count($tabelasEsperadas) - count($faltando)) . '/' . count($tabelasEsperadas) . ')',
         empty($faltando), $faltando ? ('Faltam: ' . implode(', ', $faltando) . ' → rode install.php') : 'todas ok');
} catch (Throwable $e) {
    $add('Conexão com o banco', false, $e->getMessage() . ' → rode install.php');
}

/* SENHA DO ADMINISTRADOR — três estados, e cada um exige uma resposta diferente.
 *
 * Este teste só sabia comparar com 'admin123'. Como o instalador deixou de criar senha de fábrica,
 * ele passava sempre — virou um ✅ que não verificava nada, o pior tipo de item num diagnóstico:
 * dá segurança sem dar informação.
 *
 *   vazio          -> instalação nova; a senha ainda vai ser criada no primeiro acesso. Não é
 *                     erro nem sucesso: é uma etapa pendente, e o operador precisa saber que ela
 *                     existe (senão abre o sistema sem entender por que pede senha nova).
 *   ainda admin123 -> instalação ANTIGA, de antes desta mudança, com a senha pública em uso.
 *                     Isso é falha de verdade e tem que aparecer em vermelho.
 *   qualquer outra -> senha própria definida.
 */
if ($dbOk && empty($faltando)) {
    try {
        $u = (string)$db->query("SELECT senha_hash FROM ws_usuario WHERE login='admin'")->fetchColumn();
        if ($u === '') {
            $add('Senha do administrador', null,
                 'ainda não definida — ao abrir o sistema, a primeira tela pede que você crie a senha do usuário "admin". '
               . 'Não existe senha de fábrica: ninguém entra antes disso.');
        } elseif (password_verify('admin123', $u)) {
            $add('Senha do administrador', false,
                 '⚠️ ainda é a senha antiga "admin123", que já foi pública na documentação — '
               . 'troque AGORA em Clientes → Config → Operadores.');
        } else {
            $add('Senha do administrador', true, 'definida pelo operador (não é senha de fábrica)');
        }
    } catch (Throwable $e) {}
}

// radclient (CoA)
$radclient = trim((string)@shell_exec('command -v radclient 2>/dev/null'));
$add('radclient p/ corte imediato (CoA)', $radclient !== '' ? true : null, $radclient ?: 'instale freeradius-utils (senão o corte cai só no próximo sync)');

// Configs de integração
$cc = ws_celcash_config();
$add('CelCash configurado', $cc['galaxId'] !== '' ? true : null, $cc['galaxId'] !== '' ? ('ambiente: ' . $cc['ambiente']) : 'configure em Financeiro → Gateway');
$wa = ws_wa_config();
$add('WhatsApp/Evolution configurado', $wa['url'] !== '' ? true : null, $wa['url'] !== '' ? ('instância: ' . $wa['instance']) : 'configure em Cobrança → WhatsApp');

// Tokens de automação
$cfg = ws_db_config();
$add('cron_token definido (HTTP p/ crons)', !empty($cfg['cron_token']) ? true : null, empty($cfg['cron_token']) ? 'opcional — só necessário se rodar crons via URL' : 'ok');
$add('olt_token definido (ponte OLT)', !empty($cfg['olt_token']) ? true : null, empty($cfg['olt_token']) ? 'opcional — necessário p/ o addon da OLT chamar olt_bridge.php' : 'ok');

$falhas = array_filter($checks, fn($c) => $c[1] === false);
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Diagnóstico</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body class="ws-install">
<div class="ws-card" style="max-width:720px;margin:5vh auto">
  <?= ws_brand_big() ?>
  <p class="ws-muted">Diagnóstico do servidor</p>
  <div class="ws-alert <?= $falhas ? 'err' : 'ok' ?>">
    <?= $falhas ? ('Faltam ' . count($falhas) . ' item(ns) obrigatório(s).') : 'Tudo certo nos itens obrigatórios! 🎉' ?>
  </div>
  <table class="ws-table"><tbody>
  <?php foreach ($checks as [$label, $ok, $det]):
      $ico = $ok === true ? '✅' : ($ok === false ? '❌' : '⚠️'); ?>
    <tr>
      <td style="width:34px;font-size:18px"><?= $ico ?></td>
      <td><b><?= h($label) ?></b><?= $det ? '<br><span class="ws-muted" style="font-size:13px">'.h($det).'</span>' : '' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table>
  <p style="margin-top:16px"><a class="ws-btn primary" href="erp.php">Abrir o WellSystem →</a>
     <a class="ws-btn" href="install.php">Instalar / recriar tabelas</a></p>
</div><script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script></body></html>
