<?php
/**
 * WellSystem — Instalação pelo navegador, AUTOMÁTICA.
 *
 * Chega-se aqui depois da tela de ativação (ou quando o sistema não consegue abrir o banco).
 * O operador NÃO precisa digitar nada de banco de dados. Ao abrir, esta página:
 *
 *   1. usa a configuração que já existe (gravada pelo INSTALAR.sh / ws-instalar-addon.sh / Docker);
 *   2. se ela não conecta, procura sozinha outras credenciais válidas deste servidor:
 *      as cópias da configuração (cache/, /var/lib/wellsystem, /var/tmp) e as do MK-Auth;
 *   3. com uma conexão válida, cria o banco (se faltar), as tabelas e o usuário admin;
 *   4. grava a configuração que funcionou e segue direto para o sistema (erp.php).
 *
 * Se NADA conectar, a tela explica o motivo e mostra UM comando para rodar no terminal do servidor
 * (com o caminho real desta instalação). O formulário manual continua existindo, recolhido, só para
 * quem precisar apontar um banco em outro servidor.
 *
 * Idempotente: pode abrir de novo sem apagar dados (CREATE ... IF NOT EXISTS).
 * Com ?manual=1 abre direto o formulário, sem a tentativa automática.
 */
require __DIR__ . '/config.php';
// ATIVAÇÃO (anti-cópia): se há senha de ativação definida (licenca.php) e o servidor ainda não foi
// ativado, exige a senha ANTES de deixar instalar/criar tabelas.
if (function_exists('ws_ativacao_exigida') && ws_ativacao_exigida() && !ws_ativado()) { header('Location: ativacao.php'); exit; }
require_once __DIR__ . '/schema.php';   // tabelas/migrações (tem que carregar ANTES dos handlers)

$msg = ''; $erro = ''; $feito = false;

/* Garante TODAS as pastas graváveis já na instalação, sem terminal. */
if (function_exists('ws_garantir_pastas')) ws_garantir_pastas();
if (!is_dir(WS_CACHE)) @mkdir(WS_CACHE, 0775, true);
@chmod(WS_CACHE, 0775);

/** As tabelas do sistema já existem nesta conexão (com o banco selecionado)? */
function ws_inst_tabelas_ok(PDO $db): bool {
    try { $db->query("SELECT 1 FROM ws_usuario LIMIT 1"); return true; } catch (Throwable $e) { return false; }
}

/** Cria (se faltar) o banco, as tabelas e os dados iniciais. $srv = conexão SEM banco selecionado. */
function ws_inst_criar_estrutura(PDO $srv, string $dbname): void {
    $dbname = str_replace('`', '', $dbname);
    try {
        $srv->exec("CREATE DATABASE IF NOT EXISTS `{$dbname}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    } catch (Throwable $e) {
        // Conta sem permissão de CRIAR banco ainda serve, se o banco já existe e ela tem acesso a
        // ele (é o caso do usuário próprio criado pelo instalador). O USE abaixo é quem decide.
    }
    $srv->exec("USE `{$dbname}`");
    foreach (ws_schema_sql() as $sql) $srv->exec($sql);
    ws_migracoes($srv);   // colunas novas em tabelas já existentes (idempotente)

    if ((int)$srv->query("SELECT COUNT(*) FROM ws_usuario")->fetchColumn() === 0) {
        // Sem senha de fábrica: quem define é o cliente, na tela obrigatória do 1º acesso.
        $srv->prepare("INSERT INTO ws_usuario (nome,login,senha_hash,nivel,ativo) VALUES (?,?,?,?,1)")
            ->execute(['Administrador', 'admin', '', 'admin']);
    }
    if ((int)$srv->query("SELECT COUNT(*) FROM ws_plano")->fetchColumn() === 0) {
        $srv->prepare("INSERT INTO ws_plano (nome,down_kbps,up_kbps,valor,ativo) VALUES (?,?,?,?,1)")
            ->execute(['Plano 100 MEGA', 100000, 50000, 99.90]);
    }
    if ((int)$srv->query("SELECT COUNT(*) FROM ws_regua")->fetchColumn() === 0) {
        $ins = $srv->prepare("INSERT INTO ws_regua (nome,dias,usar_template,texto,ativo) VALUES (?,?,?,?,1)");
        $ins->execute(['Aviso 3 dias antes', -3, 0, "Olá {nome}! Sua fatura de {valor} vence em {vencimento}. PIX copia-e-cola:\n{pix}\n2ª via: {link}"]);
        $ins->execute(['No vencimento', 0, 0, "Olá {nome}, sua fatura de {valor} vence hoje ({vencimento}). Pague pelo PIX:\n{pix}\n2ª via: {link}"]);
        $ins->execute(['Vencida 3 dias', 3, 0, "Olá {nome}, sua fatura de {valor} venceu em {vencimento} e está em aberto. Evite o bloqueio pagando o PIX:\n{pix}\n2ª via: {link}"]);
        $ins->execute(['Aviso de bloqueio', 5, 1, "{nome}, sua conexão pode ser bloqueada por falta de pagamento da fatura vencida em {vencimento}."]);
    }
}

/**
 * Conecta ao SERVIDOR de banco (sem selecionar banco), tentando os nomes equivalentes da máquina
 * (localhost / 127.0.0.1 / ::1). Rápido de propósito: timeout curto e sem as esperas longas do
 * ws_pdo_conectar(), porque aqui várias credenciais podem ser testadas em sequência.
 * Devolve [PDO, hostQueConectou] ou lança a exceção do primeiro nome.
 */
function ws_inst_conectar(array $c): array {
    $hosts = array_merge([(string)$c['host']], ws_pdo_hosts_equivalentes((string)$c['host']));
    $primeiro = null;
    foreach ($hosts as $h) {
        try {
            $pdo = new PDO("mysql:host={$h};port=" . (int)($c['porta'] ?? 3306) . ";charset=utf8mb4",
                (string)$c['user'], (string)$c['pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 4]);
            return [$pdo, $h];
        } catch (Throwable $e) { if (!$primeiro) $primeiro = $e; }
    }
    throw $primeiro;
}

/**
 * Tenta deixar tudo pronto SEM o operador. Devolve true quando o sistema está pronto para abrir.
 * $tentativas recebe o que foi testado (sem senha), para a tela explicar se não der certo.
 */
function ws_inst_automatico(array &$tentativas): bool {
    $atual = ws_db_config();
    $fila = [['origem' => 'configuração atual', 'cfg' => $atual]];
    if (!getenv('WS_DB_HOST')) {   // em Docker quem manda é a variável de ambiente, nada de palpite
        foreach (ws_db_config_candidatos() as $arq) {
            if (!@is_file($arq)) continue;
            $j = json_decode((string)@file_get_contents($arq), true);
            if (is_array($j) && !empty($j['host']) && !empty($j['user'])) $fila[] = ['origem' => $arq, 'cfg' => array_merge($atual, $j)];
        }
        if ($mk = ws_mkauth_credenciais()) $fila[] = ['origem' => 'credenciais do MK-Auth deste servidor', 'cfg' => array_merge($mk, ['dbname' => $atual['dbname'] ?: 'wellsystem'])];
    }
    $vistos = [];
    foreach ($fila as $item) {
        $c = array_merge(['porta' => 3306, 'dbname' => 'wellsystem', 'pass' => ''], $item['cfg']);
        if (empty($c['host']) || empty($c['user'])) continue;
        $chave = $c['host'] . "\0" . $c['user'] . "\0" . $c['pass'] . "\0" . $c['dbname'];
        if (isset($vistos[$chave])) continue;
        $vistos[$chave] = true;
        $rotulo = $c['user'] . '@' . $c['host'] . ' → banco ' . $c['dbname'] . ' (' . $item['origem'] . ')';
        try {
            [$srv, $hostOk] = ws_inst_conectar($c);
            ws_inst_criar_estrutura($srv, (string)$c['dbname']);
            if (!getenv('WS_DB_HOST')) {
                // Grava o que FUNCIONOU (mantendo campos extras como radius_db) em todos os lugares.
                ws_db_config_salvar(array_merge($atual, $item['cfg'], ['host' => $hostOk, 'porta' => (int)$c['porta'],
                    'user' => $c['user'], 'pass' => $c['pass'], 'dbname' => $c['dbname']]));
            }
            $tentativas[] = ['ok' => true, 'txt' => $rotulo];
            return true;
        } catch (Throwable $e) {
            $tentativas[] = ['ok' => false, 'txt' => $rotulo . ': ' . $e->getMessage()];
        }
    }
    return false;
}

/** Comando de terminal que resolve o banco NESTE servidor, com o caminho real desta instalação. */
function ws_inst_comando_terminal(): string {
    $dir = __DIR__;
    $q = "'" . str_replace("'", "'\\''", $dir) . "'";
    if (@is_file('/.dockerenv')) return 'docker compose up -d --build   (na pasta do projeto, no servidor host)';
    return "bash {$q}/ws-reparar-banco.sh";   // servidor direto, MK-Auth ou outro ERP: o script detecta
}

// --- Manual (último recurso): salvar credenciais digitadas ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'salvar_db') {
    $cfg = [
        'host'   => trim($_POST['host'] ?? '127.0.0.1'),
        'porta'  => (int)($_POST['porta'] ?? 3306),
        'user'   => trim($_POST['user'] ?? ''),
        'pass'   => (string)($_POST['pass'] ?? ''),
        'dbname' => trim($_POST['dbname'] ?? 'wellsystem'),
    ];
    try {
        [$srv, $hostOk] = ws_inst_conectar($cfg);
        ws_inst_criar_estrutura($srv, $cfg['dbname']);
        ws_db_config_salvar(array_merge(ws_db_config(), $cfg, ['host' => $hostOk]));
        header('Location: erp.php?ws_inst=1'); exit;
    } catch (Throwable $e) {
        $erro = 'Não conectou com esses dados: ' . h($e->getMessage());
    }
}

// --- Automático: toda vez que a página abre (menos quando pediram o formulário) ---
$tentativas = [];
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && empty($_GET['manual'])) {
    if (ws_inst_automatico($tentativas)) { header('Location: erp.php?ws_inst=1'); exit; }
}
$comando = ws_inst_comando_terminal();
$c = ws_db_config();
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WellSystem — Instalação</title><?= ws_favicon_tags() ?>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
  .ws-inst-cmd{display:flex;gap:8px;align-items:stretch;flex-wrap:wrap;margin:8px 0}
  .ws-inst-cmd code{flex:1 1 260px;display:block;padding:10px 12px;border-radius:8px;background:rgba(127,127,127,.12);word-break:break-all;font-size:13px}
  .ws-inst-lista{margin:6px 0 0;padding-left:18px;font-size:12.5px;word-break:break-word}
  .ws-inst-lista li{margin:3px 0}
</style>
</head>
<body class="ws-install">
<div class="ws-card" style="max-width:640px;margin:5vh auto;width:calc(100% - 32px)">
    <?= ws_brand_big() ?>

    <?php if ($erro): ?><div class="ws-alert err"><?= $erro ?></div><?php endif; ?>

    <?php if ($_SERVER['REQUEST_METHOD'] !== 'POST' && empty($_GET['manual'])): ?>
    <div class="ws-alert err">
        <b>Não consegui abrir o banco de dados sozinho.</b><br>
        O sistema testou todas as credenciais que existem neste servidor e nenhuma conectou.
        Isso acontece quando a instalação foi feita só copiando os arquivos (sem o instalador),
        ou quando a configuração do banco foi apagada.
    </div>

    <h3>Resolver em um passo</h3>
    <p>No terminal do servidor (PuTTY/SSH), como <b>root</b>, rode:</p>
    <div class="ws-inst-cmd">
        <code id="wsCmd"><?= h($comando) ?></code>
        <button type="button" class="ws-btn" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('wsCmd').textContent).then(function(){this.textContent='Copiado ✔'}.bind(this))">Copiar</button>
    </div>
    <p class="ws-muted" style="font-size:13px">Ele cria o banco, o usuário próprio do WellSystem e as tabelas, sem tocar no que já existe.
       Quando terminar, <a href="install.php">recarregue esta página</a> — ela segue direto para o sistema.</p>

    <details style="margin-top:12px"><summary style="cursor:pointer">O que foi testado</summary>
        <ul class="ws-inst-lista">
        <?php foreach ($tentativas as $t): ?><li><?= $t['ok'] ? '✅' : '❌' ?> <?= h($t['txt']) ?></li><?php endforeach; ?>
        <?php if (!$tentativas): ?><li>Nenhuma configuração encontrada.</li><?php endif; ?>
        </ul>
    </details>
    <?php endif; ?>

    <details style="margin-top:12px" <?= ($_SERVER['REQUEST_METHOD'] === 'POST' || !empty($_GET['manual'])) ? 'open' : '' ?>>
        <summary style="cursor:pointer">Informar o banco manualmente (banco em outro servidor)</summary>
        <form method="post" class="ws-form" style="margin-top:10px" autocomplete="off">
            <input type="hidden" name="acao" value="salvar_db">
            <label>Host <input name="host" value="<?= h($_POST['host'] ?? $c['host']) ?>" required></label>
            <label>Porta <input name="porta" value="<?= h($_POST['porta'] ?? $c['porta']) ?>" inputmode="numeric"></label>
            <label>Usuário <input name="user" value="<?= h($_POST['user'] ?? '') ?>" placeholder="wellsystem" required></label>
            <label>Senha <input name="pass" type="password" value="" autocomplete="new-password"></label>
            <label>Nome do banco <input name="dbname" value="<?= h($_POST['dbname'] ?? $c['dbname']) ?>" required></label>
            <button class="ws-btn primary">Conectar e instalar</button>
        </form>
    </details>
</div>
</body>
</html>
