<?php
/**
 * WellSystem — Instalador por LINHA DE COMANDO (usado pelo Docker/entrypoint).
 * Cria o banco, as tabelas (ws_ e radius) e o admin, a partir das variáveis WS_DB_*
 * (ou de cache/wellsystem_db.json). Idempotente — pode rodar toda vez que o container sobe.
 *
 *   php install_cli.php
 */
if (php_sapi_name() !== 'cli') { http_response_code(403); exit("somente CLI\n"); }
require __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';   // require_once: o schema.php agora carrega schema_radius/endereco, que não podem ser incluídos duas vezes

try {
    $c = ws_db_config();
    // conecta sem selecionar o banco e cria se faltar
    $dsn = "mysql:host={$c['host']};port={$c['porta']};charset=utf8mb4";
    // ws_pdo_conectar() tenta de novo com backoff se vier "Connection refused" (2002) — o
    // MariaDB/MySQL oficial reinicia o mysqld internamente na 1ª subida (init scripts), e essa
    // é a PRIMEIRA conexão do container logo após o wait-loop do entrypoint.sh, a mais exposta
    // a pegar exatamente essa janela de restart.
    $root = ws_pdo_conectar($dsn, $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $root->exec("CREATE DATABASE IF NOT EXISTS `{$c['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $root->exec("USE `{$c['dbname']}`");
    foreach (ws_schema_sql() as $sql) $root->exec($sql);
    ws_migracoes($root);

    $db = ws_db();
    if ((int)$db->query("SELECT COUNT(*) FROM ws_usuario")->fetchColumn() === 0) {
        /* ADMIN NASCE SEM SENHA UTILIZÁVEL — senha_hash vazio.
         * Antes nascia com 'admin123', publicado na documentação: toda instalação do mundo subia
         * com a mesma senha conhecida, e bastava alguém chegar à tela de login antes do dono.
         * Vazio não é "senha em branco": password_verify() contra hash vazio SEMPRE falha, então
         * ninguém entra por aqui. Quem define a senha é o cliente, na tela obrigatória do primeiro
         * acesso (erp.php) — que só é alcançável depois da ativação. */
        $db->prepare("INSERT INTO ws_usuario (nome,login,senha_hash,nivel,ativo) VALUES (?,?,?,?,1)")
           ->execute(['Administrador', 'admin', '', 'admin']);
        echo "Admin criado: login 'admin', SEM senha — defina no primeiro acesso pelo navegador.\n";
    }
    if ((int)$db->query("SELECT COUNT(*) FROM ws_plano")->fetchColumn() === 0)
        $db->prepare("INSERT INTO ws_plano (nome,down_kbps,up_kbps,valor,ativo) VALUES (?,?,?,?,1)")->execute(['Plano 100 MEGA', 100000, 50000, 99.90]);

    echo "WellSystem: banco `{$c['dbname']}` pronto em {$c['host']}.\n";
} catch (Throwable $e) {
    fwrite(STDERR, "ERRO: " . $e->getMessage() . "\n");
    exit(1);
}
