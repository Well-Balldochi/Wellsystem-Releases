<?php
/**
 * WellSystem — LICENÇA (instalador único).
 * ============================================================================
 * Este instalador é IGUAL para todos os clientes e NÃO leva licença de ninguém. A primeira tela do sistema pede a
 * CHAVE DE ATIVAÇÃO (gerada pelo fornecedor); ela é conferida pela assinatura (chave pública em config.php) e ativa SÓ o
 * servidor onde foi digitada. Copiar a instalação para outro servidor pede a chave de novo.
 * ============================================================================
 */
define('WS_ATIVACAO_HASH',  '');
define('WS_ATIVACAO_TEXTO', '');
define('WS_WA_LINK_PADRAO', '');
