<?php
/**
 * WellSystem — Cliente Lytex Pagamentos (boleto + PIX), API v2.
 *
 * Fluxo: POST /v2/auth/obtain_token {clientId, clientSecret} → accessToken (dura ~5 min, cacheado)
 *        → POST /v2/invoices (fatura com boleto+PIX) → GET /v2/invoices/{id}/payment-detail
 *          (linha digitável e PIX copia-e-cola — a emissão é assíncrona, podem demorar segundos).
 * Baixa: webhook_lytex.php recebe o aviso e CONFERE na API (GET /v2/invoices/{id}); o formato do
 *        aviso não é documentado, então a verdade é sempre a consulta. ws_lytex_sincronizar() confere
 *        de tempos em tempos (radius_sync.php) — cobre aviso perdido e completa PIX/linha atrasados.
 *
 * QUEM SAI PELA LYTEX: o título cuja CONTA (ws_banco) tem Emissão = "lytex". O operador escolhe o
 * cliente pela "Conta do boleto/PIX" da ficha do contrato; os demais seguem na CelCash/próprio.
 *
 * SEGREDO NUNCA NO CÓDIGO: credenciais em cache/lytex.json (bloqueado para a web), gravado pela tela
 * Financeiro → Gateway. Especificação: https://api-pay.lytex.com.br/v2/open-api-v3-spec.json
 */
require_once __DIR__ . '/config.php';

define('WS_LYTEX_CFG', WS_CACHE . '/lytex.json');
define('WS_LYTEX_TOKEN', WS_CACHE . '/lytex_token.json');

/** Config: ambiente (sandbox|producao), clientId, clientSecret, webhookToken, webhookUrl. */
function ws_lytex_config(): array {
    $def = ['ambiente' => 'producao', 'clientId' => '', 'clientSecret' => '', 'webhookToken' => '', 'webhookUrl' => '', 'cartao' => 0];
    if (is_file(WS_LYTEX_CFG)) {
        $c = json_decode((string)@file_get_contents(WS_LYTEX_CFG), true);
        if (is_array($c)) return array_merge($def, $c);
    }
    return $def;
}

function ws_lytex_salvar(array $cfg): void {
    $novo = array_merge(ws_lytex_config(), $cfg);
    if (trim((string)$novo['webhookToken']) === '') $novo['webhookToken'] = bin2hex(random_bytes(16));
    @file_put_contents(WS_LYTEX_CFG, json_encode($novo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_LYTEX_CFG, 0640);
    @unlink(WS_LYTEX_TOKEN);   // credencial/ambiente novos: token novo
}

/** Credenciais preenchidas? */
function ws_lytex_pronto(): bool {
    $c = ws_lytex_config();
    return trim((string)$c['clientId']) !== '' && trim((string)$c['clientSecret']) !== '';
}

function ws_lytex_base(): string {
    return ws_lytex_config()['ambiente'] === 'sandbox' ? 'https://sandbox-api-pay.lytex.com.br' : 'https://api-pay.lytex.com.br';
}

/** HTTP JSON. Retorna [http_code, array|null, raw]. Log em cache/lytex_debug.txt SEM o token. */
function ws_lytex_http(string $metodo, string $caminho, $body = null, bool $autenticar = true): array {
    $headers = ['Accept: application/json', 'Content-Type: application/json'];
    if ($autenticar) {
        try { $headers[] = 'Authorization: Bearer ' . ws_lytex_token(); }
        catch (Throwable $e) { return [0, null, $e->getMessage()]; }
    }
    $ch = curl_init(ws_lytex_base() . $caminho);
    $bodyStr = $body !== null ? json_encode($body, JSON_UNESCAPED_UNICODE) : null;
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30,
                            CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_HTTPHEADER => $headers]);
    if ($bodyStr !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyStr);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) $raw = 'curl err: ' . $err;
    // O corpo do obtain_token leva o clientSecret e a resposta leva o token: não vão para o log.
    $logBody = strpos($caminho, '/auth/') !== false ? '[credenciais ocultas]' : (string)$bodyStr;
    $logResp = strpos($caminho, '/auth/') !== false ? '[token oculto]' : mb_substr((string)$raw, 0, 4000);
    $arq = WS_CACHE . '/lytex_debug.txt';
    if (is_file($arq) && filesize($arq) > 2000000) @rename($arq, $arq . '.1');
    @file_put_contents($arq, '[' . date('c') . "] $metodo $caminho -> HTTP $code\n" . ($logBody !== '' ? "BODY: $logBody\n" : '') . "RESP: $logResp\n\n", FILE_APPEND);
    return [$code, json_decode((string)$raw, true), (string)$raw];
}

/** accessToken (cacheado até 30 s antes de expirar). @throws RuntimeException */
function ws_lytex_token(): string {
    if (is_file(WS_LYTEX_TOKEN)) {
        $t = json_decode((string)@file_get_contents(WS_LYTEX_TOKEN), true);
        if (is_array($t) && !empty($t['t']) && ($t['exp'] ?? 0) > time() + 30) return (string)$t['t'];
    }
    $c = ws_lytex_config();
    if (!ws_lytex_pronto()) throw new RuntimeException('Lytex sem credenciais (configure em Financeiro → Gateway).');
    [$code, $resp, $raw] = ws_lytex_http('POST', '/v2/auth/obtain_token',
        ['grantType' => 'clientCredentials', 'clientId' => trim($c['clientId']), 'clientSecret' => trim($c['clientSecret'])], false);
    if ($code < 200 || $code >= 300 || empty($resp['accessToken'])) {
        throw new RuntimeException('Lytex recusou as credenciais (HTTP ' . $code . '): ' . mb_substr(strip_tags((string)$raw), 0, 300));
    }
    $exp = strtotime((string)($resp['expireAt'] ?? '')) ?: (time() + 240);
    @file_put_contents(WS_LYTEX_TOKEN, json_encode(['t' => $resp['accessToken'], 'exp' => $exp]));
    @chmod(WS_LYTEX_TOKEN, 0640);
    return (string)$resp['accessToken'];
}

/** Testa só a autenticação (não cria cobrança). [ok, msg] */
function ws_lytex_testar(): array {
    @unlink(WS_LYTEX_TOKEN);
    try { ws_lytex_token(); return [true, 'Conexão OK — a Lytex aceitou as credenciais (' . ws_lytex_config()['ambiente'] . ').']; }
    catch (Throwable $e) { return [false, $e->getMessage()]; }
}

/** Conta (ws_banco) com Emissão = Lytex; 0 se não houver. */
function ws_lytex_banco_id(PDO $db): int {
    try { return (int)$db->query("SELECT id FROM ws_banco WHERE ativo=1 AND emissao='lytex' ORDER BY id LIMIT 1")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}

/** A conta $bancoId é a da Lytex? */
function ws_lytex_eh_banco(PDO $db, $bancoId): bool {
    $bancoId = (int)$bancoId;
    if ($bancoId <= 0) return false;
    try { $st = $db->prepare("SELECT emissao FROM ws_banco WHERE id=?"); $st->execute([$bancoId]); return $st->fetchColumn() === 'lytex'; }
    catch (Throwable $e) { return false; }
}

/** Linha digitável / PIX / código de barras de uma fatura já criada (payment-detail). */
function ws_lytex_detalhe(string $id): array {
    [$code, $resp] = ws_lytex_http('GET', '/v2/invoices/' . rawurlencode($id) . '/payment-detail');
    if ($code >= 200 && $code < 300 && is_array($resp) && !empty($resp['boleto']['digitableLine'] ?? $resp['pix']['qrcode'] ?? null))
        return ['linha_digitavel' => (string)($resp['boleto']['digitableLine'] ?? ''), 'barcode' => (string)($resp['boleto']['barcode'] ?? ''),
                'pix_emv' => (string)($resp['pix']['qrcode'] ?? '')];
    /* 30/09/2026: com a fatura AGUARDANDO pagamento o payment-detail responde 400 ("não está em um status que permite
       esta operação"), e o boleto saía sem linha digitável e sem PIX — a impressão caía no layout do boleto próprio.
       Os mesmos dados vêm na própria fatura, em transactions[].boleto/pix. */
    $inv = ws_lytex_consultar($id); if (!$inv) return [];
    $out = ['linha_digitavel' => '', 'barcode' => '', 'pix_emv' => ''];
    foreach ((array)($inv['transactions'] ?? []) as $t) {
        if (!is_array($t)) continue;
        if ($out['linha_digitavel'] === '') $out['linha_digitavel'] = (string)($t['boleto']['digitableLine'] ?? '');
        if ($out['barcode'] === '')         $out['barcode']         = (string)($t['boleto']['barcode'] ?? '');
        if ($out['pix_emv'] === '')         $out['pix_emv']         = (string)($t['pix']['qrcode'] ?? ($t['pix']['emv'] ?? ''));
    }
    return array_filter($out, fn($v) => $v !== '') ? $out : [];
}

/** Fatura na Lytex (GET /v2/invoices/{id}); null se falhar. */
function ws_lytex_consultar(string $id): ?array {
    [$code, $resp] = ws_lytex_http('GET', '/v2/invoices/' . rawurlencode($id));
    return ($code >= 200 && $code < 300 && is_array($resp)) ? $resp : null;
}

/** Cancela na Lytex. [ok, msg] */
function ws_lytex_cancelar(string $id): array {
    [$code, , $raw] = ws_lytex_http('PUT', '/v2/invoices/cancel/' . rawurlencode($id));
    return [$code >= 200 && $code < 300, 'HTTP ' . $code . ': ' . mb_substr((string)$raw, 0, 200)];
}

/**
 * Cria a cobrança (boleto+PIX) na Lytex. Mesmo formato de retorno de ws_celcash_criar_cobranca():
 * [ok, charge_id, linha_digitavel, boleto_url, pix_emv, pix_qr_url, barcode, raw, erro].
 */
function ws_lytex_criar_cobranca(array $fatura, array $cliente): array {
    $num = fn($s) => preg_replace('/\D/', '', (string)$s);
    $doc = $num($cliente['cpf_cnpj'] ?? '');
    if (strlen($doc) !== 11 && strlen($doc) !== 14) return ['ok' => false, 'erro' => 'CPF/CNPJ do cliente inválido ou vazio — a Lytex exige o documento.', 'raw' => null];
    // centavos; cobrança = plano + taxa de emissão; VENCIDA = + multa e juros até hoje (ws_fatura_encargos, mesma conta da baixa)
    $valor = (int)round((function_exists('ws_fatura_valor_atualizado') && !empty($fatura['vencimento']) ? ws_fatura_valor_atualizado($fatura) : ((float)$fatura['valor'] + (float)($fatura['taxa_emissao'] ?? 0))) * 100);
    if ($valor < 200) return ['ok' => false, 'erro' => 'A Lytex só aceita cobrança a partir de R$ 2,00.', 'raw' => null];
    $tel = $num($cliente['celular'] ?? $cliente['telefone'] ?? '');
    $cli = ['type' => strlen($doc) === 14 ? 'pj' : 'pf', 'name' => (string)$cliente['nome'], 'treatmentPronoun' => 'you', 'cpfCnpj' => $doc,
            'referenceId' => 'cli-' . (int)($cliente['cliente_id'] ?? $cliente['id'] ?? 0),
            'address' => array_filter(['street' => (string)($cliente['logradouro'] ?? ''), 'number' => (string)($cliente['numero'] ?? '') ?: 'S/N',
                'complement' => (string)($cliente['complemento'] ?? ''), 'zone' => (string)($cliente['bairro'] ?? ''), 'city' => (string)($cliente['cidade'] ?? ''),
                'state' => strtoupper((string)($cliente['uf'] ?? '')), 'zip' => $num($cliente['cep'] ?? '')], fn($v) => $v !== '')];
    if (!empty($cliente['email'])) $cli['email'] = (string)$cliente['email'];
    if ($tel !== '') $cli['cellphone'] = $tel;
    $body = [
        'client' => $cli,
        'items' => [['name' => 'Mensalidade ' . ($fatura['competencia'] ?? '') . (!empty($fatura['login']) ? ' - ' . $fatura['login'] : ''), 'quantity' => 1, 'value' => $valor]],
        // vencida: a Lytex também não aceita data passada — boleto com vencimento de hoje (a fatura no sistema mantém a original)
        'dueDate' => max(date('Y-m-d'), date('Y-m-d', strtotime((string)$fatura['vencimento']))),
        // Cartão de crédito à vista (01/10/2026, opcional em Financeiro → Gateway → Lytex): o cliente paga na página segura da
        // Lytex (linkCheckout) — o número do cartão nunca passa pelo WellSystem.
        'paymentMethods' => ['pix' => ['enable' => true], 'boleto' => ['enable' => true], 'creditCard' => !empty(ws_lytex_config()['cartao']) ? ['enable' => true, 'maxParcels' => 1] : ['enable' => false]],
        'referenceId' => (string)($fatura['celcash_my_id'] ?? ('ws-fat-' . $fatura['id'])),
    ];
    [$code, $resp, $raw] = ws_lytex_http('POST', '/v2/invoices', $body);
    if ($code < 200 || $code >= 300 || !is_array($resp) || empty($resp['_hashId'] ?? $resp['_id'] ?? null)) {
        $msg = is_array($resp) ? (string)($resp['message'] ?? $resp['error'] ?? '') : '';
        if (is_array($resp['message'] ?? null)) $msg = implode('; ', array_map('strval', $resp['message']));
        return ['ok' => false, 'erro' => 'Lytex HTTP ' . $code . ': ' . ($msg !== '' ? $msg : mb_substr((string)$raw, 0, 300)), 'raw' => $raw];
    }
    $id = (string)($resp['_id'] ?? $resp['_hashId']);   // 30/09/2026: a API (cancelar/consultar) só aceita o _id; com o _hashId dava HTTP 500
    // Emissão assíncrona: linha digitável e PIX podem levar alguns segundos. Tenta um pouco; o que faltar
    // o ws_lytex_sincronizar() completa depois (o boleto nunca sai com PIX de outra conta).
    $det = [];
    for ($i = 0; $i < 4; $i++) { $det = ws_lytex_detalhe($id); if (!empty($det['pix_emv']) && !empty($det['linha_digitavel'])) break; usleep(1500000); }
    return ['ok' => true, 'charge_id' => $id, 'linha_digitavel' => $det['linha_digitavel'] ?? null, 'barcode' => $det['barcode'] ?? null,
            'boleto_url' => (string)($resp['linkBoleto'] ?? ''), 'pix_emv' => $det['pix_emv'] ?? null, 'pix_qr_url' => null, 'raw' => $raw];
}

/**
 * Emite UMA fatura do WellSystem na Lytex e grava o resultado. Não reemite fatura que já tem lytex_id.
 * @return array [ok, erro]
 */
function ws_lytex_emitir_fatura(PDO $db, int $fid): array {
    $st = $db->prepare("SELECT f.*, c.*, f.id fid, f.status fstatus, ct.login_pppoe, f.banco_id fbanco
                        FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?");
    $st->execute([$fid]); $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) return ['ok' => false, 'erro' => 'Fatura não encontrada.'];
    if (!empty($row['lytex_id'])) return ['ok' => true, 'erro' => ''];
    if (in_array($row['fstatus'], ['pago', 'cancelado'], true)) return ['ok' => false, 'erro' => 'Fatura já está ' . $row['fstatus'] . '.'];
    if (is_file(__DIR__ . '/schema_endereco.php')) { require_once __DIR__ . '/schema_endereco.php'; if (function_exists('ws_end_enriquecer')) $row = ws_end_enriquecer($db, $row); }
    $fatura = ['id' => $row['fid'], 'valor' => $row['valor'], 'taxa_emissao' => (float)($row['taxa_emissao'] ?? 0), 'vencimento' => $row['vencimento'],
               'competencia' => $row['competencia'], 'celcash_my_id' => $row['celcash_my_id'], 'login' => $row['login_pppoe']];
    $r = ws_lytex_criar_cobranca($fatura, $row);
    if (empty($r['ok'])) return ['ok' => false, 'erro' => (string)($r['erro'] ?? 'falha na Lytex')];
    $banco = (int)$row['fbanco'] ?: ws_lytex_banco_id($db);
    $db->prepare("UPDATE ws_fatura SET status='aberto', lytex_id=?, linha_digitavel=?, boleto_url=?, pix_emv=?, pix_qr_url=NULL, gateway_raw=?,
                  banco_id=COALESCE(NULLIF(banco_id,0), ?) WHERE id=?")
       ->execute([$r['charge_id'], $r['linha_digitavel'] ?: null, $r['boleto_url'] ?: null, $r['pix_emv'] ?: null, $r['raw'], $banco ?: null, $fid]);
    ws_evento($db, (int)$row['cliente_id'], 'fatura', "Fatura #$fid emitida na Lytex (boleto + PIX).");
    return ['ok' => true, 'erro' => ''];
}

/** Baixa de uma fatura paga na Lytex — mesmos passos da baixa do webhook da CelCash. */
function ws_lytex_baixar(PDO $db, array $f, array $inv): bool {
    if (($f['status'] ?? '') === 'pago') return false;
    $pd = is_array($inv['paymentData'] ?? null) ? $inv['paymentData'] : [];
    $lp = is_array($inv['lastPayment'] ?? null) ? $inv['lastPayment'] : [];
    $centavos = $pd['payedValue'] ?? $lp['payedValue'] ?? null;
    $valor = (is_numeric($centavos) && $centavos > 0) ? round((float)$centavos / 100, 2) : ws_fatura_valor_cobrado($f);
    /* 30/09/2026: a Lytex manda payedAt em UTC ("2026-10-01T01:56:00Z" = 30/09 22:56 em Recife). Cortar os 10 primeiros
       caracteres gravava o DIA SEGUINTE nos pagamentos da noite (caixa e recibo no dia errado). Converte para o fuso local. */
    $tsPg = strtotime((string)($pd['payedAt'] ?? $lp['payedAt'] ?? ''));
    $data = $tsPg ? date('Y-m-d', $tsPg) : date('Y-m-d');
    $forma = stripos((string)($pd['method'] ?? $lp['method'] ?? ''), 'pix') !== false ? 'pix' : 'boleto';
    $db->beginTransaction();
    try {
        $up = $db->prepare("UPDATE ws_fatura SET status='pago', data_pagamento=?, valor_pago=? WHERE id=? AND status<>'pago'");
        $up->execute([$data, $valor, $f['id']]);
        if ($up->rowCount() === 0) { $db->rollBack(); return false; }   // outra baixa chegou antes: não duplica
        $db->prepare("INSERT INTO ws_pagamento (fatura_id,data_pgto,valor_pago,forma,origem,obs,coletor) VALUES (?,?,?,?, 'webhook', ?, 'Lytex')")
           ->execute([$f['id'], $data, $valor, $forma, 'Lytex: ' . (string)($inv['status'] ?? 'paid')]);
        ws_evento($db, (int)$f['cliente_id'], 'fatura', "Baixa automática (Lytex): Fatura #{$f['id']} paga via {$forma} (R$ " . number_format($valor, 2, ',', '.') . ").");
        $db->commit();
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
    if (is_file(__DIR__ . '/radius_lib.php')) {   // pagou → desbloqueia se não deve mais nada (mesma regra das outras baixas)
        require_once __DIR__ . '/radius_lib.php';
        try { ws_rad_apos_pagamento($db, (int)$f['contrato_id']); } catch (Throwable $e) {}
    }
    if (is_file(__DIR__ . '/whatsapp.php')) {   // recibo automático, se ativado
        require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_recibo_config') && !empty(ws_recibo_config()['auto']) && function_exists('ws_recibo_enviar')) { try { ws_recibo_enviar($db, (int)$f['id'], 'gateway'); } catch (Throwable $e) {} }
    }
    @file_put_contents(WS_CACHE . '/webhook_lytex.log', '[' . date('c') . "] [BAIXA Fatura #{$f['id']}] R$ $valor ($forma)\n", FILE_APPEND);
    return true;
}

/**
 * Confere na Lytex as faturas em aberto emitidas por ela: dá baixa nas pagas e completa PIX/linha que
 * ainda não tinham chegado. Chamado pelo radius_sync.php a cada ~10 min. Devolve [baixas, completadas].
 */
/**
 * BAIXA RÁPIDA (30/09/2026, pedido do provedor: "não ficar esperando"). Roda A CADA MINUTO (lytex_run.php no cron).
 * Leve de propósito: em vez de consultar título por título, pega a LISTA das faturas que ainda estão em aberto na
 * Lytex (waitingPayment + overdue, 100 por página, ~0,3 s cada). Título nosso em aberto que SAIU dessa lista mudou
 * de situação (pago/cancelado) → só ele é consultado e, se pago, recebe a baixa na hora. Com o webhook configurado
 * no painel da Lytex a baixa é instantânea; isto é a garantia quando o aviso não chega.
 */
function ws_lytex_rapido(PDO $db): array {
    $res = ['abertas' => 0, 'mudaram' => 0, 'baixas' => 0];
    if (!ws_lytex_pronto()) return $res;
    try { $nossos = $db->query("SELECT * FROM ws_fatura WHERE lytex_id IS NOT NULL AND lytex_id<>'' AND status IN('aberto','vencido','processando')")->fetchAll(PDO::FETCH_ASSOC); }
    catch (Throwable $e) { return $res; }
    if (!$nossos) return $res;
    $abertasLx = [];
    foreach (['waitingPayment', 'overdue'] as $stLx) {
        for ($pg = 1; $pg <= 30; $pg++) {
            [$code, $r] = ws_lytex_http('GET', '/v2/invoices?status=' . $stLx . '&perPage=100&page=' . $pg);
            if ($code < 200 || $code >= 300 || !is_array($r)) return $res;   // lista falhou: não arrisca (o ciclo de 2 min confere)
            foreach ((array)($r['results'] ?? []) as $i) if (!empty($i['_id'])) $abertasLx[(string)$i['_id']] = 1;
            if ($pg >= (int)($r['paginate']['pages'] ?? 1)) break;
        }
    }
    $res['abertas'] = count($abertasLx);
    foreach ($nossos as $f) {
        if (isset($abertasLx[(string)$f['lytex_id']])) continue;
        $res['mudaram']++;
        $inv = ws_lytex_consultar((string)$f['lytex_id']);
        if ($inv && strtolower((string)($inv['status'] ?? '')) === 'paid') { try { if (ws_lytex_baixar($db, $f, $inv)) $res['baixas']++; } catch (Throwable $e) {} }
    }
    return $res;
}

function ws_lytex_sincronizar(PDO $db, int $max = 40): array {
    $res = ['baixas' => 0, 'completadas' => 0];
    if (!ws_lytex_pronto()) return $res;
    try {
        $rows = $db->query("SELECT * FROM ws_fatura WHERE lytex_id IS NOT NULL AND lytex_id<>'' AND status IN('aberto','vencido','processando')
                            ORDER BY (pix_emv IS NULL OR pix_emv='') DESC, vencimento ASC LIMIT " . (int)$max)->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return $res; }
    foreach ($rows as $f) {
        $inv = ws_lytex_consultar((string)$f['lytex_id']);
        if (!$inv) continue;
        if (strtolower((string)($inv['status'] ?? '')) === 'paid') { try { if (ws_lytex_baixar($db, $f, $inv)) $res['baixas']++; } catch (Throwable $e) {} continue; }
        if (trim((string)$f['pix_emv']) === '' || trim((string)$f['linha_digitavel']) === '') {
            $d = ws_lytex_detalhe((string)$f['lytex_id']);
            if (!empty($d['pix_emv']) || !empty($d['linha_digitavel'])) {
                $db->prepare("UPDATE ws_fatura SET pix_emv=COALESCE(NULLIF(pix_emv,''),?), linha_digitavel=COALESCE(NULLIF(linha_digitavel,''),?) WHERE id=?")
                   ->execute([$d['pix_emv'] ?: null, $d['linha_digitavel'] ?: null, $f['id']]);
                $res['completadas']++;
            }
        }
    }
    return $res;
}

/** URL do webhook para colar no painel da Lytex (Configurações → Integrações → API). */
function ws_lytex_webhook_url(): string {
    $c = ws_lytex_config();
    $url = trim((string)$c['webhookUrl']);
    if ($url === '') {
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        $corte = strrpos($script, '/');
        $dir = ($script !== '' && $script[0] === '/' && $corte !== false) ? substr($script, 0, $corte) : '';
        $url = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . $host . $dir . '/webhook_lytex.php';
    }
    if ($c['webhookToken'] !== '' && strpos($url, 'token=') === false) $url .= (strpos($url, '?') === false ? '?' : '&') . 'token=' . rawurlencode($c['webhookToken']);
    return $url;
}

function ws_lytex_webhook_valido(string $token): bool {
    $c = ws_lytex_config();
    return $c['webhookToken'] !== '' && hash_equals((string)$c['webhookToken'], $token);
}

/** Link da página de pagamento da Lytex (cartão de crédito) de uma fatura emitida lá, ou '' (opção desligada / sem link).
 *  A página é da Lytex: o cartão é digitado lá, nunca no WellSystem. */
function ws_lytex_link_cartao(array $f): string {
    if (empty(ws_lytex_config()['cartao']) || trim((string)($f['lytex_id'] ?? '')) === '') return '';
    $raw = json_decode((string)($f['gateway_raw'] ?? ''), true);
    $u = is_array($raw) ? (string)($raw['linkCheckout'] ?? '') : '';
    return preg_match('#^https://[a-z0-9.\-]*lytex\.com\.br/#i', $u) ? $u : '';
}
