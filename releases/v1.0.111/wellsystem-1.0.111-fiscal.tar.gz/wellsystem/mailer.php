<?php
/**
 * WellSystem — envio de e-mail por SMTP (fsockopen puro, sem PHPMailer).
 * Portado do wellsystem_olt (olt_smtp_enviar). Segurança: ssl(465) / tls(587 STARTTLS) / none.
 * Config em cache/smtp.json — NUNCA no código.
 */
require_once __DIR__ . '/config.php';

function ws_smtp_config(): array {
    $def = ['smtp_host' => '', 'smtp_port' => 587, 'smtp_seg' => 'tls', 'smtp_user' => '', 'smtp_pass' => '', 'smtp_from' => ''];
    $f = WS_CACHE . '/smtp.json';
    if (is_file($f)) { $c = json_decode(@file_get_contents($f), true); if (is_array($c)) return array_merge($def, $c); }
    return $def;
}
function ws_smtp_salvar(array $c): bool {
    ws_dir(WS_CACHE);
    $ok = @file_put_contents(WS_CACHE . '/smtp.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/smtp.json', 0640);
    return $ok !== false;
}

/** Codifica um cabeçalho (aqui, o Subject) em RFC 2047 quando tiver acento/caractere especial.
 *  Cabeçalho de e-mail só aceita ASCII puro — mandando UTF-8 cru (ex.: "Backup WellSystem — 27/09/2026",
 *  com "—" e sem essa codificação) muita caixa de entrada corrige sozinha, mas boa parte dos servidores
 *  rejeita ou classifica como spam/malformado sem avisar ninguém — daí o "some e não chega por e-mail"
 *  sem nenhum erro aparecer no envio (o SMTP responde 250 OK do mesmo jeito). */
function ws_mime_header(string $s): string {
    return preg_match('/[^\x20-\x7E]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
}

/** Cliente SMTP mínimo. Retorna [bool ok, string msg]. */
function ws_smtp_enviar_raw(array $s, string $to, string $subject, string $mimeHeaders, string $body): array {
    $host = trim($s['smtp_host'] ?? ''); $port = (int)($s['smtp_port'] ?? 0);
    $seg = strtolower($s['smtp_seg'] ?? 'tls'); $user = $s['smtp_user'] ?? ''; $pass = $s['smtp_pass'] ?? '';
    $from = trim($s['smtp_from'] ?? '') ?: ($user ?: 'no-reply@wellsystem');
    if ($host === '' || $port === 0) return [false, 'SMTP sem host/porta.'];
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true, 'SNI_enabled' => true, 'peer_name' => $host]]);
    $alvo = ($seg === 'ssl') ? "ssl://$host:$port" : "tcp://$host:$port";
    $fp = @stream_socket_client($alvo, $eno, $estr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return [false, "Não conectou no SMTP $host:$port ($estr)."];
    stream_set_timeout($fp, 15);
    $ler = function () use ($fp) { $d = ''; while (($ln = fgets($fp, 515)) !== false) { $d .= $ln; if (isset($ln[3]) && $ln[3] === ' ') break; } return $d; };
    $cmd = function ($c) use ($fp, $ler) { if ($c !== null) fputs($fp, $c . "\r\n"); return $ler(); };
    $ler();
    $cmd("EHLO wellsystem");
    if ($seg === 'tls') {
        $r = $cmd("STARTTLS");
        if ($r === '' || $r[0] !== '2') { fclose($fp); return [false, 'Servidor recusou STARTTLS: ' . trim($r)]; }
        $cr = STREAM_CRYPTO_METHOD_TLS_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) $cr |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
        if (!@stream_socket_enable_crypto($fp, true, $cr)) { fclose($fp); return [false, 'Falha no STARTTLS. Tente SSL na porta 465.']; }
        $cmd("EHLO wellsystem");
    }
    if ($user !== '') {
        $cmd("AUTH LOGIN"); $cmd(base64_encode($user)); $r = $cmd(base64_encode($pass));
        if (strpos($r, '235') === false) { fclose($fp); return [false, 'Login SMTP recusado (usuário/senha).']; }
    }
    $r = $cmd("MAIL FROM:<$from>");
    if ($r === '' || $r[0] !== '2') { fclose($fp); return [false, 'Remetente recusado pelo SMTP: ' . trim($r)]; }
    $r = $cmd("RCPT TO:<$to>");
    if ($r === '' || ($r[0] !== '2' && $r[0] !== '3')) { fclose($fp); return [false, 'Destinatário recusado pelo SMTP: ' . trim($r)]; }
    $r = $cmd("DATA");
    if ($r === '' || $r[0] !== '3') { fclose($fp); return [false, 'SMTP não aceitou iniciar a mensagem (DATA): ' . trim($r)]; }
    /* "." no começo de linha precisa ser duplicado (dot-stuffing) — sem isso o SMTP encerra a mensagem no meio. */
    $msg = "Date: " . date('r') . "\r\nFrom: $from\r\nTo: $to\r\nSubject: " . ws_mime_header($subject) . "\r\n" . $mimeHeaders . "\r\n" . $body;
    $msg = preg_replace('/^\./m', '..', $msg) . "\r\n.\r\n";
    /* Mensagem grande (backup): escreve em blocos até o fim (fputs de uma vez só pode gravar só uma parte,
     * principalmente em conexão TLS) e espera a resposta com prazo maior — o servidor só responde o "250"
     * depois de receber e conferir o anexo, e 15 s não bastavam: caía em "não aceitou" mesmo tendo aceitado. */
    stream_set_timeout($fp, 180);
    $tot = strlen($msg); $ini = 0;
    while ($ini < $tot) { $n = @fwrite($fp, substr($msg, $ini, 16384)); if ($n === false || $n === 0) break; $ini += $n; }
    if ($ini < $tot) { fclose($fp); return [false, 'Conexão SMTP caiu no meio do envio do anexo (' . round($ini / 1024) . ' de ' . round($tot / 1024) . ' KB enviados).']; }
    $r = $ler(); $cmd("QUIT"); fclose($fp);
    return (isset($r[0]) && $r[0] === '2') ? [true, 'Enviado via SMTP.'] : [false, 'SMTP não aceitou a mensagem: ' . ($r === '' ? 'sem resposta em 180 s (anexo grande demais ou servidor lento)' : trim($r))];
}

/** E-mail simples (texto). */
function ws_email_texto(string $to, string $subject, string $texto): array {
    $s = ws_smtp_config();
    $mime = "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    if (trim($s['smtp_host'] ?? '') !== '') return ws_smtp_enviar_raw($s, $to, $subject, $mime, $texto);
    if (!function_exists('mail')) return [false, 'Sem SMTP e mail() desabilitado.'];
    $from = trim($s['smtp_from'] ?? '') ?: 'no-reply@wellsystem';
    return [@mail($to, ws_mime_header($subject), $texto, "From: $from\r\n" . $mime) ? true : false, 'via mail()'];
}

/** E-mail com um anexo (conteúdo em memória). */
function ws_email_anexo(string $to, string $subject, string $corpo, string $nomeArq, string $conteudo, string $tipoArq = 'application/sql'): array {
    $s = ws_smtp_config();
    $bnd = 'ws' . md5(uniqid());
    $mime = "MIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"$bnd\"\r\n";
    $body = "--$bnd\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$corpo\r\n\r\n"
          . "--$bnd\r\nContent-Type: $tipoArq; name=\"$nomeArq\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"$nomeArq\"\r\n\r\n"
          . chunk_split(base64_encode($conteudo)) . "\r\n--$bnd--";
    if (trim($s['smtp_host'] ?? '') !== '') return ws_smtp_enviar_raw($s, $to, $subject, $mime, $body);
    if (!function_exists('mail')) return [false, 'Sem SMTP e mail() desabilitado.'];
    $from = trim($s['smtp_from'] ?? '') ?: 'no-reply@wellsystem';
    return [@mail($to, ws_mime_header($subject), $body, "From: $from\r\n" . $mime) ? true : false, 'via mail()'];
}

/** E-MAIL COM ANEXO GRANDE (17/10/2026): o Gmail recusa mensagem acima de 25 MB (o anexo vira ~1,37x em base64) — o backup compactado passou de 30 MB e deixou de chegar desde 16/10 ("552 5.3.4 message size").
 *  Até ~14 MB vai como sempre; acima disso o anexo é dividido em PARTES e cada parte vai num e-mail ("parte 1 de 3"). Para juntar: Linux/Mac `cat arquivo.part* > arquivo`; Windows `copy /b arquivo.part001+arquivo.part002 arquivo`. */
function ws_email_anexo_partes(string $to, string $subject, string $corpo, string $nomeArq, string $conteudo, string $tipoArq = 'application/sql', int $limite = 17825792): array {   // 17 MB (o e-mail leva ~37% a mais com a codificação; limite do Gmail = 25 MB). Antes 14 MB: o backup .xz de ~15 MB saía em 2 partes.
    if (strlen($conteudo) <= $limite) return ws_email_anexo($to, $subject, $corpo, $nomeArq, $conteudo, $tipoArq);
    /* 24/10/2026: arquivo grande = LINK SEGURO com o arquivo inteiro (sem dividir, sem retirar nada do backup). Sem como criar o link, cai nas partes como antes. */
    if (function_exists('ws_backup_link_criar') && ($lk = ws_backup_link_criar($nomeArq, $conteudo)) !== null) {
        $txt = $corpo . "\n\n📥 O arquivo é grande (" . number_format($lk['tam'] / 1048576, 1, ',', '') . " MB) para anexar, então vai por link seguro — o arquivo inteiro, sem dividir:\n" . $lk['url']
             . "\n\nVálido até " . date('d/m/Y H:i', $lk['exp']) . " (até 10 downloads).\nConferência SHA-256 do arquivo:\n" . $lk['sha']
             . (preg_match('/\.xz$/', $nomeArq) ? "\n\nArquivo .xz: abra com o 7-Zip (Windows) ou 'xz -d' (Linux/Mac); depois use Backup → Restaurar com o .sql." : '');
        return ws_email_texto($to, $subject . ' (link)', $txt);
    }
    $partes = str_split($conteudo, $limite); $n = count($partes); $falhas = [];
    foreach ($partes as $i => $p) {
        $k = $i + 1; $nome = $nomeArq . '.part' . str_pad((string)$k, 3, '0', STR_PAD_LEFT);
        $c = $corpo . "\n\nARQUIVO DIVIDIDO: parte $k de $n (o anexo é grande demais para um e-mail só).\nPara juntar as partes:\n  Linux/Mac:  cat $nomeArq.part* > $nomeArq\n  Windows:    copy /b " . implode('+', array_map(fn($j) => $nomeArq . '.part' . str_pad((string)$j, 3, '0', STR_PAD_LEFT), range(1, $n))) . " $nomeArq";
        [$ok, $msg] = ws_email_anexo($to, $subject . " (parte $k de $n)", $c, $nome, $p, 'application/octet-stream');
        if (!$ok) $falhas[] = "parte $k: " . (is_string($msg) ? mb_substr($msg, 0, 120) : 'falhou');
    }
    return $falhas ? [false, 'e-mail em ' . $n . ' partes, falhou: ' . implode(' | ', $falhas)] : [true, "enviado em $n partes"];
}
