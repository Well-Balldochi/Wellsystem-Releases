<?php
/**
 * WellSystem — DIAGNÓSTICOS da página Manutenção (só leitura; só root). Usado por manutencao.php.
 *   mnt_diag_nas()      concentradores: o RADIUS os conhece? quantos pedidos ignorados na última hora? sessões abertas?
 *   mnt_diag_internet() DNS e acesso a Evolution, n8n, GitHub e gateways
 * Nada aqui grava, reinicia ou apaga coisa alguma.
 */

/** Concentradores (NAS) × FreeRADIUS. */
function mnt_diag_nas(PDO $db): array {
    $nas = [];
    try { foreach ($db->query("SELECT nasname, shortname FROM nas ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $r) $nas[(string)$r['nasname']] = ['nome' => (string)$r['shortname'], 'ignorados' => 0, 'ok' => 0, 'sessoes' => 0]; } catch (Throwable $e) {}
    $desc = [];
    $log = '/var/log/freeradius/radius.log';
    if (is_file($log) && is_readable($log)) {
        $tam = (int)@filesize($log); $fh = @fopen($log, 'rb');
        if ($fh) {
            fseek($fh, max(0, $tam - 4 * 1048576)); $bloco = (string)fread($fh, 4 * 1048576); fclose($fh);
            $corte = time() - 3600;
            foreach (explode("\n", $bloco) as $ln) {
                if (!preg_match('/^\w{3} (\w{3}) +(\d+) (\d\d:\d\d:\d\d) (\d{4}) : /', $ln, $m)) continue;
                $ts = strtotime("$m[2] $m[1] $m[4] $m[3]"); if (!$ts || $ts < $corte) continue;
                if (strpos($ln, 'unknown client') !== false && preg_match('/from unknown client (\S+) port/', $ln, $k)) {
                    if (isset($nas[$k[1]])) $nas[$k[1]]['ignorados']++; else $desc[$k[1]] = ($desc[$k[1]] ?? 0) + 1;
                } elseif (strpos($ln, 'Login OK') !== false && preg_match('/from client (\S+) port/', $ln, $c)) {
                    foreach ($nas as $ip => $_) if ($nas[$ip]['nome'] === $c[1]) { $nas[$ip]['ok']++; break; }
                }
            }
        }
    }
    try { foreach ($db->query("SELECT nasipaddress ip, COUNT(*) n FROM radacct WHERE acctstoptime IS NULL GROUP BY nasipaddress")->fetchAll(PDO::FETCH_ASSOC) as $r) if (isset($nas[$r['ip']])) $nas[$r['ip']]['sessoes'] = (int)$r['n']; } catch (Throwable $e) {}
    arsort($desc);
    return ['nas' => $nas, 'desconhecidos' => $desc, 'log_lido' => is_file($log) && is_readable($log)];
}

/** DNS e saída para os serviços que o sistema usa. */
function mnt_diag_internet(): array {
    $alvos = ['GitHub (atualizações)' => 'https://github.com', 'Debian (pacotes)' => 'https://deb.debian.org', 'Let\'s Encrypt (certificado)' => 'https://acme-v02.api.letsencrypt.org/directory'];
    $wa = json_decode((string)@file_get_contents(WS_CACHE . '/whatsapp.json'), true) ?: [];
    if (!empty($wa['url'])) $alvos['Evolution (WhatsApp)'] = (string)$wa['url'];
    $at = json_decode((string)@file_get_contents(WS_CACHE . '/atendimento.json'), true) ?: [];
    if (!empty($at['n8n_url'])) $alvos['n8n'] = (string)$at['n8n_url'];
    $alvos['CelCash/CelCoin (cobrança)'] = 'https://api-celcash.celcoin.com.br'; $alvos['Lytex (cobrança)'] = 'https://api-pay.lytex.com.br';
    $out = [];
    foreach ($alvos as $nome => $url) {
        $host = (string)parse_url($url, PHP_URL_HOST); $t0 = microtime(true); $ip = $host !== '' ? @gethostbyname($host) : '';
        $dnsOk = ($ip !== '' && $ip !== $host);
        $cod = 0;
        if ($dnsOk) { $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_NOBODY => 1, CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0]); curl_exec($ch); $cod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); }
        $out[] = ['nome' => $nome, 'host' => $host, 'dns' => $dnsOk, 'http' => $cod, 'ms' => (int)round((microtime(true) - $t0) * 1000)];
    }
    return $out;
}
