<?php
/**
 * WellSystem — Mensagens automáticas (cobrança/avisos) por WhatsApp/e-mail/SMS.
 * Config e modelos em cache/mensagens.json. Disparo diário pelo cron (radius_sync/cobranca).
 *
 * Quem dispara o quê:
 *   - ws_msg_cobranca_run()      → 1x por dia, no horário do "Automático": lembretes de vencimento
 *                                  (antes, no dia, 5/10/15 dias depois) e ANIVERSÁRIO.
 *   - ws_msg_eventos_estado_run() → a cada passada do cron (radius_sync.php): AVISO DE BLOQUEIO
 *                                  quando o contrato é bloqueado e AVISO DE DESBLOQUEIO ("ONLINE")
 *                                  quando é liberado. Só de 08h (horário do Automático) às 21h.
 * Os dois passam por ws_msg_cliente_permitido(): PROIBIDO enviar para cliente desativado/cancelado.
 */
require_once __DIR__ . '/config.php';

/** DATA DO ENVIO DA COBRANÇA APÓS O VENCIMENTO (regra de 15/10/2026): DIAS REAIS depois do vencimento — 5, 15 e 25 —, e se a data cair num DOMINGO ou FERIADO o aviso vai no próximo dia útil (segunda, ou o primeiro dia sem feriado).
 *  Feriados: nacionais + móveis + os locais cadastrados em Horário de atendimento (ws_feriados_ano). Sábado conta como dia de envio. Devolve 'Y-m-d'. */
function ws_msg_dia_util(string $ymd): bool {
    $ts = strtotime($ymd); if (!$ts) return true;
    if ((int)date('w', $ts) === 0) return false;   // domingo
    if (!function_exists('ws_feriados_ano') && is_file(__DIR__ . '/api_chatbot.php')) { try { require_once __DIR__ . '/api_chatbot.php'; } catch (Throwable $e) {} }
    if (function_exists('ws_feriados_ano')) { try { if (isset(ws_feriados_ano((int)date('Y', $ts))[$ymd])) return false; } catch (Throwable $e) {} }
    return true;
}
function ws_msg_data_envio(string $vencimento, int $off): string {
    $ts = strtotime($vencimento); if (!$ts) return '';
    $d = date('Y-m-d', strtotime(date('Y-m-d', $ts) . " +{$off} days"));
    for ($i = 0; $i < 7 && !ws_msg_dia_util($d); $i++) $d = date('Y-m-d', strtotime("$d +1 day"));
    return $d;
}
/** Eventos suportados: chave => [rótulo, offset em dias em relação ao vencimento | null p/ evento]. */
function ws_msg_eventos(): array {
    return [
        'venc_5antes'  => ['5 dias ANTES de vencer', -5],
        'venc_dia'     => ['No dia do vencimento', 0],
        'venc_5apos'   => ['5 dias após o vencimento', 5],
        'venc_10dias'  => ['10 dias após o vencimento (desativada — a régua atual é 5, 15 e 25)', 10],   /* (15/10/2026) opção de 10 dias mantida na tela, DESATIVADA por padrão */
        'venc_10apos'  => ['15 dias após o vencimento', 15],   /* (15/10/2026) REGRA DA COBRANÇA: 1ª rodada 5 dias, 2ª 15 dias, 3ª 30 dias após o vencimento, para todos os vencimentos. A chave 'venc_10apos' é só o nome interno (guarda o texto já configurado) */
        'venc_15apos'  => ['25 dias após o vencimento', 25],   /* 3ª e última rodada automática (nome interno antigo mantido) */
        'bloqueio'     => ['Aviso de bloqueio', null],
        'desbloqueio'  => ['Aviso de desbloqueio', null],
        'boas_vindas'  => ['Boas-vindas (ativação concluída: cliente conectado ou instalação validada)', null],
        'aniversario'  => ['Aniversário do cliente', null],
        'manutencao'   => ['Aviso de manutenção (manual)', null],
    ];
}
/** Eventos que têm fatura ligada e, por isso, podem levar o boleto/carnê em PDF. */
function ws_msg_eventos_com_boleto(): array {
    return ['venc_5antes', 'venc_dia', 'venc_5apos', 'venc_10dias', 'venc_10apos', 'venc_15apos', 'bloqueio'];
}
function ws_msg_config(): array {
    $f = WS_CACHE . '/mensagens.json';
    $def = ['canal' => 'whatsapp', 'wa_versao' => '2', 'itens' => []];
    if (is_file($f)) {
        $c = json_decode(@file_get_contents($f), true);
        if (is_array($c)) {
            $c = array_merge($def, $c);
            /* MODELOS DO PROVEDOR: quem nunca mexeu no texto (vazio ou ainda o texto antigo de fábrica)
             * passa a ver o modelo novo. Texto que o operador escreveu nunca é trocado. */
            $antigos = ws_msg_textos_antigos();
            foreach ($antigos as $k => $txtAntigo) {
                if (!isset($c['itens'][$k])) continue;
                $atual = trim((string)($c['itens'][$k]['texto'] ?? ''));
                if ($atual === '' || $atual === trim($txtAntigo)) $c['itens'][$k]['texto'] = ws_msg_texto_padrao($k);
            }
            return $c;
        }
    }
    // modelos padrão
    foreach (ws_msg_eventos() as $k => $ev) $def['itens'][$k] = ['tipo' => 'desativado', 'ativo' => 0, 'texto' => ws_msg_texto_padrao($k), 'anexo' => 'nao'];
    return $def;
}
/** Caminho do anexo (foto/PDF) de um evento de mensagem, se existir. */
function ws_msg_anexo_arquivo(string $evento): ?string {
    $arq = glob(WS_UP_SISTEMA . "/msg-$evento.*")[0] ?? null;
    return $arq ?: null;
}
function ws_msg_salvar(array $c): void {
    @file_put_contents(WS_CACHE . '/mensagens.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); @chmod(WS_CACHE . '/mensagens.json', 0640);
}
/** Textos de fábrica ANTERIORES aos modelos do provedor (só para saber quem nunca editou). */
function ws_msg_textos_antigos(): array {
    return [
        'venc_5apos'  => "Olá %nome%, sua fatura de R$ %valor% venceu em %vencimento% (há %dias% dias). Regularize para evitar bloqueio.",
        'venc_10apos' => "%nome%, sua fatura segue em aberto há %dias% dias (R$ %valor%). Entre em contato para regularizar.",
        'venc_15apos' => "%nome%, sua conexão pode ser suspensa. Fatura de R$ %valor% vencida há %dias% dias.",
        'bloqueio'    => "Olá %nome%, sua conexão foi bloqueada por falta de pagamento. Pague para reativar automaticamente.",
        'desbloqueio' => "Olá %nome%, pagamento confirmado! Sua conexão foi liberada. Obrigado 🙌",
        'aniversario' => "Feliz aniversário, %nome%! 🎉 A %provedor% deseja tudo de bom pra você!",
    ];
}
function ws_msg_texto_padrao(string $k): string {
    $p = [
        'venc_5antes' => "Olá %nome%! Seu plano vence em %vencimento% no valor de R$ %valor%. Evite o corte pagando em dia. 😉",
        'venc_dia'    => "Olá %nome%, hoje (%vencimento%) vence sua mensalidade de R$ %valor%. PIX/boleto disponível. Obrigado!",
        // Modelos do provedor (Wellnet Telecom) — 17/09/2026
        'venc_5apos'  => "Olá !!\n%nomecliente%\nCPF: %cpfcliente%\nInformamos que sua fatura no valor de R$ %valortitulo% , encontra-se em atraso há (cinco dias).\nO serviço poderá ser suspenso em até 24h automaticamente.\nSolicite atendimento para regularizar seu débito.\n\nAtt:. %empresa%",
        'venc_10dias' => "Olá !!\n%nomecliente%\nCPF: %cpfcliente%\nAinda não identificamos o pagamento da sua fatura no valor de R$ %valortitulo% vencida há ( dez dias ),\nreferente a prestação de serviço %empresa%.\nSolicite atendimento para regularizar seu débito.\n\nAtt:. %empresa%",
        'venc_10apos' => "Olá !!\n%nomecliente%\nCPF: %cpfcliente%\nAinda não identificamos o pagamento da sua fatura no valor de R$ %valortitulo% vencida há ( Quinze dias ),\nreferente a prestação de serviço %empresa%.\nSolicite atendimento para regularizar seu débito.\n\nAtt:. %empresa%",
        'venc_15apos' => "Olá !!\n%nomecliente%\nCPF: %cpfcliente%\nInformamos que seu CPF poderá ser negativado nos Registros dos Orgãos, SPC e SERASA.\nExistem débito vencido no valor de R$ %valortitulo% , não pago referente à utilização dos serviços %empresa%.\nSolicite atendimento para regularizar seu débito.\n\nAtt:. %empresa%",
        'aniversario' => "Olá !!\n%nomecliente%\n\nFeliz aniversário!\nDesejamos que neste novo ciclo, seja repleto de conquistas e felicidades.\nAgradecemos sua confiança e parceria ao longo de mais um ano!\nParabéns.. 👋👋\n\nAtt:. %empresa%",
        'bloqueio'    => "Olá !!\n%nomecliente%\nCPF: %cpfcliente%\nInformamos que sua fatura no valor R$ %valortitulo% , encontra-se em atraso em nosso sistema.\nPodendo ocorrer suspensão temporária dos serviços automaticamente.\nSolicite atendimento para regularizar seu débito.\n\n* Desbloqueio ocorrerá automaticamente após pagamento.\n\nAtt:. %empresa%",
        'desbloqueio' => "Olá!!\n%nomecliente%\nCPF: %cpfcliente%\n\nTemos ótima notícia! 🚀\nSua conexão com a internet encontra-se 🟢ONLINE.👋\n\nAtt:. %empresa%",
        'manutencao'  => "Aviso %provedor%: haverá manutenção na sua região. Pode haver instabilidade no período informado.",
        // Modelo do provedor (Wellnet Telecom) — 03/10/2026
        'boas_vindas' => "Olá !!\n\nBem-vindo(a) à %empresa%🚀\n\nAgradecemos imensamente pela confiança em nossos serviços e por escolher nosso PROVEDOR.\n\nA sua conexão já está ATIVA!\n\nSe precisar de ajuda com sua conexão ou outras solicitações, estamos à disposição nos canais de atendimento e suporte aos clientes.\n\nÉ um prazer ter você conosco! 👋\n\nAtt:. %empresa%",
    ];
    return $p[$k] ?? '';
}
/** Troca variáveis simples pelos dados reais. Aceita tanto os nomes curtos (compatibilidade com
 *  modelos já salvos) quanto o conjunto completo, no mesmo padrão de %variável% usado em Documentos. */
function ws_msg_render(string $texto, array $ctx): string {
    $prov = [];
    if (is_file(WS_CACHE . '/provedor.json')) { $j = json_decode(@file_get_contents(WS_CACHE . '/provedor.json'), true); if (is_array($j)) $prov = $j; }
    $venc = !empty($ctx['vencimento']) ? date('d/m/Y', strtotime($ctx['vencimento'])) : '';
    // CPF/CNPJ com pontuação (095.811.074-36), como o cliente reconhece o próprio documento.
    $cpf = (string)($ctx['cpf'] ?? ''); $cpfD = preg_replace('/\D/', '', $cpf);
    if (strlen($cpfD) === 11) $cpf = preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cpfD);
    elseif (strlen($cpfD) === 14) $cpf = preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cpfD);
    $map = [
        // nomes curtos (compatibilidade com o que já existia)
        '%nome%' => $ctx['nome'] ?? '', '%valor%' => isset($ctx['valor']) ? number_format((float)$ctx['valor'], 2, ',', '.') : '',
        '%vencimento%' => $venc, '%login%' => $ctx['login'] ?? '', '%dias%' => (string)($ctx['dias'] ?? ''),
        '%provedor%' => ($prov['razao'] ?? '') ?: ($prov['fantasia'] ?? 'Provedor'),
        '%empresa%' => function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: (($prov['razao'] ?? '') ?: 'Provedor')),   // nome curto (fantasia) para assinar as mensagens
        // conjunto completo (mesmo padrão de Documentos → Banco de variáveis)
        '%nomecliente%' => $ctx['nome'] ?? '', '%cpfcliente%' => $cpf, '%logincliente%' => $ctx['login'] ?? '',
        '%enderecocliente%' => $ctx['endereco'] ?? '', '%bairrocliente%' => $ctx['bairro'] ?? '', '%cidadecliente%' => $ctx['cidade'] ?? '',
        '%celularcliente%' => $ctx['celular'] ?? '', '%emailcliente%' => $ctx['email'] ?? '',
        '%valortitulo%' => isset($ctx['valor']) ? number_format((float)$ctx['valor'], 2, ',', '.') : '',
        '%diavencimento%' => $venc, '%datavencimento%' => $venc, '%data%' => date('d/m/Y'),
        '%planocliente%' => $ctx['plano'] ?? '', '%velocidadeplano%' => $ctx['plano'] ?? '',
        '%provedornome%' => ($prov['razao'] ?? '') ?: ($prov['fantasia'] ?? 'Provedor'),
        '%provedorfone%' => $prov['telefone'] ?? '', '%provedorendereco%' => $prov['endereco'] ?? '',
        '%provedorcidade%' => $prov['cidade'] ?? '', '%provedorsite%' => $prov['site'] ?? '',
    ];
    return strtr($texto, $map);
}

/** Dados do cliente/contrato usados no texto das mensagens (endereço normalizado, plano, login). */
function ws_msg_contexto_cliente(PDO $db, int $clienteId, ?int $contratoId = null): ?array {
    require_once __DIR__ . '/schema_endereco.php';
    try {
        $sql = "SELECT c.id cliente_id, c.nome, c.celular, c.cpf_cnpj, c.email, c.data_nasc,
                       ct.id contrato_id, ct.login_pppoe, ct.login_ipoe, p.nome plano,
                       wl.nome endereco, wb.nome bairro, wc.nome cidade
                FROM ws_cliente c
                LEFT JOIN ws_contrato ct ON ct.id = " . ($contratoId ? (int)$contratoId : "(SELECT MIN(x.id) FROM ws_contrato x WHERE x.cliente_id=c.id AND x.status<>'cancelado')") . "
                LEFT JOIN ws_plano p ON p.id=ct.plano_id"
             . ws_end_sql_join('c') . " WHERE c.id=?";
        $st = $db->prepare($sql); $st->execute([$clienteId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    } catch (Throwable $e) { return null; }
}

/**
 * ENVIA UMA MENSAGEM A UM CLIENTE — o único caminho das mensagens automáticas.
 *   1) PROIBIDO para cliente desativado/cancelado (ws_msg_cliente_permitido) — conferido aqui, sempre;
 *   2) tipo "foto"/"pdf": manda o arquivo fixo do evento com o texto como legenda;
 *   3) anexo "boleto"/"carne": manda o PDF gerado no servidor (boleto_pdf.php) com o texto como
 *      legenda (se já foi um arquivo fixo, o PDF vai logo depois, sem repetir o texto);
 *   4) se o PDF não puder ser gerado, o texto vai do mesmo jeito — o aviso nunca deixa de sair;
 *   5) toda tentativa fica no log (Recibos → Log de envios), com o motivo quando falha.
 * $faturaIds: faturas do assunto (para o PDF). Retorna o resultado do gateway.
 */
function ws_msg_enviar_cliente(PDO $db, string $k, array $it, array $cli, string $msg, array $faturaIds = [], string $origem = 'automatico', array $logExtra = []): array {
    require_once __DIR__ . '/whatsapp.php';
    $log = function (bool $ok, ?string $erro, string $tel = '') use ($db, $k, $cli, $origem, $logExtra, $faturaIds) {
        if (!function_exists('ws_recibo_log_gravar')) return;
        ws_recibo_log_gravar($db, 'mensagem', $logExtra + [
            'fatura_id' => $faturaIds ? (int)$faturaIds[0] : null, 'cliente_nome' => $cli['nome'] ?? null,
            'login' => ($cli['login_pppoe'] ?? '') ?: ($cli['login_ipoe'] ?? null), 'telefone' => $tel ?: ($cli['celular'] ?? null),
            'forma' => 'msg: ' . $k, 'enviado' => $ok ? 1 : 0, 'origem' => $origem, 'erro' => $erro,
        ]);
    };
    if (!ws_msg_cliente_permitido($db, (int)($cli['cliente_id'] ?? 0), !empty($cli['contrato_id']) ? (int)$cli['contrato_id'] : null)) {
        $log(false, 'Cliente desativado — envio proibido.');
        return ['ok' => false, 'raw' => 'proibido'];
    }
    $tel = trim((string)($cli['celular'] ?? ''));
    if ($tel === '') { $log(false, 'Cliente sem celular cadastrado.'); return ['ok' => false, 'raw' => 'sem celular']; }

    $tipo = $it['tipo'] ?? 'texto';
    $anexoFixo = ($tipo === 'foto' || $tipo === 'pdf') ? ws_msg_anexo_arquivo($k) : null;
    $modoPdf = in_array($it['anexo'] ?? 'nao', ['boleto', 'carne'], true) && in_array($k, ws_msg_eventos_com_boleto(), true) ? $it['anexo'] : '';
    $pdf = null; $avisoPdf = null;
    if ($modoPdf !== '' && $faturaIds) {
        if (is_file(__DIR__ . '/boleto_pdf.php')) {
            require_once __DIR__ . '/boleto_pdf.php';
            try { $pdf = ws_pdf_faturas($db, $faturaIds, $modoPdf); } catch (Throwable $e) { $pdf = null; }
        }
        if (!$pdf) $avisoPdf = 'PDF do boleto não pôde ser gerado — enviado só o texto.';
    }
    /* Contexto do envio: qual evento é (para o template aprovado da Meta, quando a conta for oficial
     * e a janela de 24 h estiver fechada) e que é mensagem AUTOMÁTICA (marca invisível). */
    /* VARIÁVEL DO MODELO DA META POR CLIENTE (10/10/2026): com a janela de 24 h fechada só sai modelo aprovado. Cada mensagem pode ter o SEU modelo ("Template da Meta")
       e a variável {{1}} aceita %nome% (primeiro nome) e %nomecliente% (completo) — ex.: "Olá {{1}}, sua fatura está vencida há 5 dias… toque em Sim". */
    $parM = (string)($it['meta_par'] ?? '');
    /* %texto% (10/10/2026): a variável do modelo carrega o TEXTO desta mensagem (o de Mensagens automáticas, com os dias de cada data), numa linha só — a Meta não aceita
       quebra de linha nem mais de 4 espaços seguidos numa variável. Assim UM modelo aprovado ("Olá! Aviso da Wellnet Telecom: {{1}} Toque em Sim…") serve a todas as datas. */
    if (strpos($parM, '%texto%') !== false) { $flat = trim(preg_replace('/[━─]{3,}/u', ' — ', (string)$msg)); $flat = trim(preg_replace('/\s+/u', ' ', $flat)); $parM = str_replace('%texto%', mb_substr($flat, 0, 900), $parM); }
    if ($parM !== '' && strpos($parM, '%') !== false) { $pn = trim((string)($cli['nome'] ?? '')); $p1 = $pn !== '' ? mb_convert_case(mb_strtolower(explode(' ', $pn)[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8') : '';
        $parM = ws_msg_render($parM, ['nome' => $p1, 'login' => (string)($cli['login_pppoe'] ?? '')]); $parM = str_replace('%nomecliente%', $pn, $parM); }
    $ctx = ['evento' => $k, 'automatica' => true, 'tpl' => (string)($it['meta_tpl'] ?? ''), 'par' => $parM];
    $r = ['ok' => false, 'raw' => ''];
    if ($anexoFixo && function_exists('ws_wa_midia')) {
        $r = ws_wa_midia($tel, $tipo === 'foto' ? 'image' : 'document', basename($anexoFixo), base64_encode((string)@file_get_contents($anexoFixo)), $msg, $ctx);
        if (!empty($r['ok']) && $pdf) ws_wa_midia($tel, 'document', $pdf['nome'], base64_encode($pdf['pdf']), '', $ctx);
    } elseif ($pdf && function_exists('ws_wa_midia')) {
        $r = ws_wa_midia($tel, 'document', $pdf['nome'], base64_encode($pdf['pdf']), $msg, $ctx);
    } else {
        $r = ws_wa_enviar($tel, $msg, false, $ctx);
    }
    $ok = !empty($r['ok']);
    /* QR CODE DO PIX (24/09/2026, opção "Enviar QR Code do PIX" da mensagem): imagem do QR + copia-e-cola na
       legenda, da fatura mais antiga do assunto — o MESMO PIX do boleto. Só depois que a mensagem principal saiu
       e só se ela NÃO foi template: com a janela de 24 h fechada o QR viraria um 2º template, cobrado e repetido. */
    if ($ok && !empty($it['qr_pix']) && in_array($k, ws_msg_eventos_com_boleto(), true) && $faturaIds
        && empty($r['template']) && function_exists('ws_wa_midia') && is_file(__DIR__ . '/api_chatbot.php')) {
        require_once __DIR__ . '/api_chatbot.php';
        $pixQr = ws_fatura_pix_png($db, (int)$faturaIds[0]);
        if ($pixQr) {
            $rq = ws_wa_midia($tel, 'image', 'pix.png', base64_encode($pixQr['png']), "PIX copia e cola:\n" . $pixQr['emv'], $ctx);
            if (empty($rq['ok'])) $avisoPdf = trim(($avisoPdf ?? '') . ' QR do PIX não enviado: ' . mb_substr((string)($rq['raw'] ?? ''), 0, 120));
        } else {
            $avisoPdf = trim(($avisoPdf ?? '') . ' QR do PIX não enviado: fatura sem PIX.');
        }
    }
    /* SAIU SÓ O MODELO (janela fechada, 10/10/2026): o texto fica no n8n, mas boleto e QR/PIX não — guarda aqui para entregar quando o cliente responder
       (whatsapp.php → ws_wa_pendente_*; api/index.php dispara pendente_entregar_run.php). */
    if ($ok && !empty($r['template']) && function_exists('ws_wa_pendente_guardar')) {
        try {
            $anex = [];
            if ($anexoFixo) $anex[] = ['tipo' => $tipo === 'foto' ? 'image' : 'document', 'nome' => basename($anexoFixo), 'b64' => base64_encode((string)@file_get_contents($anexoFixo)), 'legenda' => ''];
            if ($pdf) $anex[] = ['tipo' => 'document', 'nome' => $pdf['nome'], 'b64' => base64_encode($pdf['pdf']), 'legenda' => ''];
            if (!empty($it['qr_pix']) && in_array($k, ws_msg_eventos_com_boleto(), true) && $faturaIds && is_file(__DIR__ . '/api_chatbot.php')) {
                require_once __DIR__ . '/api_chatbot.php';
                $pixQr = ws_fatura_pix_png($db, (int)$faturaIds[0]);
                if ($pixQr) $anex[] = ['tipo' => 'image', 'nome' => 'pix.png', 'b64' => base64_encode($pixQr['png']), 'legenda' => "PIX copia e cola:\n" . $pixQr['emv']];
            }
            if ($anex) { ws_wa_pendente_guardar($tel, $anex, (array)($faturaIds ?? [])); $avisoPdf = trim(($avisoPdf ?? '') . ' Modelo enviado; boleto/PIX guardados para entregar quando o cliente responder.'); }
        } catch (Throwable $e) {}
    }
    if (function_exists('ws_evento') && !empty($cli['cliente_id'])) { try { ws_evento($db, (int)$cli['cliente_id'], 'robo', 'Mensagem automática (' . $k . ') ' . ($ok ? (!empty($r['template']) ? 'enviada como modelo — aguardando o cliente responder' : 'enviada') : 'NÃO enviada') . '.'); } catch (Throwable $e) {} }
    $log($ok, $ok ? $avisoPdf : (is_string($r['raw'] ?? null) ? mb_substr($r['raw'], 0, 250) : 'falha no envio'), $tel);
    return $r;
}

/** Faturas da mensagem para o PDF: a própria fatura (boleto) ou todas as em aberto do contrato (carnê). */
function ws_msg_faturas_pdf(PDO $db, string $modo, int $contratoId, array $faturaIds): array {
    if ($modo !== 'carne' || $contratoId <= 0) return $faturaIds;
    try {
        $st = $db->prepare("SELECT id FROM ws_fatura WHERE contrato_id=? AND status IN('aberto','vencido','processando') ORDER BY vencimento, id");
        $st->execute([$contratoId]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        return $ids ?: $faturaIds;
    } catch (Throwable $e) { return $faturaIds; }
}

/**
 * COBRANÇA INTELIGENTE (10/10/2026) — o cliente NÃO recebe cobrança automática quando a conversa já resolveu o assunto.
 * Antes só havia trava "1x por fatura": cliente com 2-3 faturas vencidas recebia 2-3 cobranças com boletos no mesmo dia, e
 * quem já tinha mandado o comprovante (identificado, "será conferido", agradecimento/avaliação) continuava sendo cobrado.
 * Devolve o MOTIVO de não enviar ('' = pode enviar). Vale para os dois caminhos automáticos (lembretes e régua).
 *  - comprovante recebido nos últimos 5 dias (pelo cliente ou pelo WhatsApp dele; inclui reenvio barrado): ciclo fechado;
 *  - já recebeu cobrança automática HOJE (qualquer fatura): uma por cliente por dia.
 */
function ws_msg_cobranca_suprimida(PDO $db, int $clienteId, string $celular = '', bool $soComprovante = false): string {
    $dig = preg_replace('/\D/', '', $celular);
    try {
        $sql = "SELECT COUNT(*) FROM ws_comprovante WHERE criado_em > NOW() - INTERVAL 5 DAY
                  AND (status IN ('novo','conferido','baixado') OR conferido_por='Automático (reenvio)')
                  AND (cliente_id=?" . (strlen($dig) >= 8 ? " OR RIGHT(telefone,8)=?" : "") . ")";
        $a = [$clienteId]; if (strlen($dig) >= 8) $a[] = substr($dig, -8);
        $q = $db->prepare($sql); $q->execute($a);
        if ((int)$q->fetchColumn() > 0) return 'comprovante já recebido';
    } catch (Throwable $e) {}
    if ($soComprovante) return '';
    $m = json_decode((string)@file_get_contents(WS_CACHE . '/cobranca_cliente_dia.json'), true) ?: [];
    if (($m['_dia'] ?? '') === date('Y-m-d') && isset($m['c' . $clienteId])) return 'já cobrado hoje';
    return '';
}
function ws_msg_cobranca_marcar_cliente(int $clienteId): void {
    $f = WS_CACHE . '/cobranca_cliente_dia.json';
    $m = json_decode((string)@file_get_contents($f), true) ?: [];
    if (($m['_dia'] ?? '') !== date('Y-m-d')) $m = ['_dia' => date('Y-m-d')];
    $m['c' . $clienteId] = 1;
    @file_put_contents($f, json_encode($m), LOCK_EX); @chmod($f, 0640);
}

/**
 * Cron diário: manda os lembretes de vencimento devidos (1x/dia por fatura) e o aniversário.
 *
 * QUATRO REGRAS, nesta ordem, e nenhuma delas é opcional:
 *  1) PROIBIDO enviar para cliente CANCELADO ou DESATIVADO (inativo), ou contrato cancelado —
 *     em hipótese alguma. Filtrado na própria consulta E confirmado de novo linha a linha,
 *     porque um JOIN mal lido nunca pode ser a única barreira para isso.
 *  2) Só envia se a MENSAGEM daquele evento estiver habilitada (tipo ≠ desativado / ativo=1).
 *  3) Só envia se a opção de ENVIO (gateway do WhatsApp, em Mensagens → Servidor) estiver
 *     habilitada — checado uma vez, antes de tudo, então nada roda à toa com o envio desligado.
 *  4) O disparo AUTOMÁTICO (checkbox "Automático" + horário) só decide QUANDO chamar esta
 *     função (ver radius_sync.php) — ele nunca pula as regras 1-3 acima: automático ligado
 *     com a mensagem desabilitada continua sem enviar nada, porque a regra 2 é checada aqui
 *     dentro, e é a mesma função usada tanto pelo cron quanto pelo botão "Enviar agora".
 * Recebem: cliente ativo, bloqueado, em confiança, em observação e suspenso.
 */
function ws_msg_cobranca_run(PDO $db): void {
    $lkCob = @fopen(WS_CACHE . '/msg_cobranca.lock', 'c');   // 10/10/2026: uma execução por vez (disparo manual + cron não se sobrepõem)
    if ($lkCob && !flock($lkCob, LOCK_EX | LOCK_NB)) return;
    $cfg = ws_msg_config();
    if (empty($cfg['itens'])) return;
    if (!is_file(__DIR__ . '/whatsapp.php')) return;
    require_once __DIR__ . '/whatsapp.php';
    require_once __DIR__ . '/schema_endereco.php';

    // REGRA 3 — gateway de envio desligado: nada é disparado, nem sequer consulta o banco.
    $wa = ws_wa_config();
    if (($wa['gateway'] ?? 'evolution') === 'desativado') return;

    $marcaFile = WS_CACHE . '/mensagens_enviadas.json';
    $marca = is_file($marcaFile) ? (json_decode(@file_get_contents($marcaFile), true) ?: []) : [];
    $hoje = date('Y-m-d');
    if (($marca['_dia'] ?? '') !== $hoje) $marca = ['_dia' => $hoje];   // reinicia por dia

    /* COBRANÇA AUTOMÁTICA (regra de 15/10/2026): 3 rodadas, todas com boleto + PIX — 5, 15 e 25 dias após o vencimento (venc_5apos, venc_10apos = 15, venc_15apos = 25); domingo/feriado passa para o próximo dia útil. Sem repetição; depois da 3ª não envia mais nada. */
    $eventosRun = [];
    foreach (ws_msg_eventos() as $k0 => $ev0) { if ($ev0[1] === null) continue; $eventosRun[] = [$k0, $ev0, $ev0[1]]; }   /* (15/10/2026) sem repetição semanal: a cobrança automática é 5, 15 e 30 dias após o vencimento, e passou de 30 dias não envia mais nada */
    foreach ($eventosRun as [$k, $ev, $off]) {                      // só os de vencimento
        $it = $cfg['itens'][$k] ?? null;
        // REGRA 2 — mensagem deste evento desabilitada: pula o evento inteiro.
        if (!$it || empty($it['ativo']) || trim($it['texto'] ?? '') === '') continue;
        /* (15/10/2026) 'após o vencimento' (off > 0): todos os vencimentos cuja data de envio (ws_msg_data_envio) é HOJE; antes/no dia: vencimento = hoje - offset, como sempre. */
        if ($off > 0) { $alvos = []; for ($i = 1; $i <= 75; $i++) { $v = date('Y-m-d', strtotime("$hoje -$i days")); if (ws_msg_data_envio($v, $off) === $hoje) $alvos[] = $v; } if (!$alvos) continue; }
        else $alvos = [date('Y-m-d', strtotime("$hoje " . (-$off) . " days"))];
        /* Endereço do CADASTRO normalizado (schema_endereco.php). O apelido `endereco` é mantido porque
         é o nome que o modelo de mensagem usa em %enderecocliente%.
         REGRA 1 — c.status e ct.status entram no SELECT e no WHERE: cliente cancelado/inativo e
         contrato cancelado já saem filtrados aqui, antes mesmo de chegar no PHP. */
        $q = $db->prepare("SELECT f.id, f.cliente_id, f.contrato_id, f.valor, f.taxa_emissao, f.vencimento, c.nome, c.celular, c.cpf_cnpj, c.email,
                                  c.status cli_status, ct.status ct_status,
                                  wl.nome endereco, wb.nome bairro, wc.nome cidade,
                                  ct.login_pppoe, ct.login_ipoe, p.nome plano
                           FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id JOIN ws_contrato ct ON ct.id=f.contrato_id
                           LEFT JOIN ws_plano p ON p.id=ct.plano_id"
                           . ws_end_sql_join('c') . "
                           WHERE f.status IN('aberto','vencido','processando') AND f.vencimento IN (" . implode(',', array_fill(0, count($alvos), '?')) . ")
                             AND c.status NOT IN ('cancelado','inativo')
                             AND ct.status <> 'cancelado' ORDER BY f.vencimento, f.id");
        $q->execute($alvos);
        foreach ($q->fetchAll() as $f) {
            $chave = $k . '-' . $f['id']; if (isset($marca[$chave])) continue;
            // REGRA 1 (segunda trava, redundante de propósito) — nunca confia só no WHERE: se por
            // qualquer motivo a linha chegou com cliente cancelado/desativado ou contrato
            // cancelado, pula em hipótese alguma, sem marcar como enviada (não conta como "já
            // tentou hoje", então nada é perdido se o status voltar a ficar ativo depois).
            if (in_array((string)($f['cli_status'] ?? ''), ['cancelado', 'inativo'], true)) continue;
            if ((string)($f['ct_status'] ?? '') === 'cancelado') continue;
            if (trim((string)$f['celular']) === '') continue;
            if (ws_msg_cobranca_suprimida($db, (int)$f['cliente_id'], (string)$f['celular']) !== '') { $marca[$chave] = 1; continue; }   // comprovante já enviado / já cobrado hoje
            $msg = ws_msg_render($it['texto'], ['nome' => $f['nome'], 'valor' => ws_fatura_valor_cobrado($f), 'vencimento' => $f['vencimento'],
                'login' => $f['login_pppoe'], 'dias' => max(abs($off), (int)floor((strtotime($hoje) - strtotime((string)$f['vencimento'])) / 86400)), 'cpf' => $f['cpf_cnpj'], 'email' => $f['email'],
                'endereco' => $f['endereco'], 'bairro' => $f['bairro'], 'cidade' => $f['cidade'], 'celular' => $f['celular'], 'plano' => $f['plano']]);
            $ids = ws_msg_faturas_pdf($db, (string)($it['anexo'] ?? 'nao'), (int)$f['contrato_id'], [(int)$f['id']]);
            $r = ws_msg_enviar_cliente($db, $k, $it, $f, $msg, $ids, 'automatico', ['vencimento' => $f['vencimento'], 'valor_boleto' => $f['valor']]);
            if (!empty($r['ok'])) { $marca[$chave] = 1; ws_msg_cobranca_marcar_cliente((int)$f['cliente_id']); @file_put_contents($marcaFile, json_encode($marca)); }
        }
    }

    /* ANIVERSÁRIO — clientes que fazem aniversário hoje (29/02 comemora no dia 28 em ano não bissexto).
     * Uma mensagem por cliente no dia; mesma regra de status de todas as outras. */
    $itA = $cfg['itens']['aniversario'] ?? null;
    if ($itA && !empty($itA['ativo']) && trim($itA['texto'] ?? '') !== '') {
        $dias = [date('m-d')];
        if (date('m-d') === '02-28' && !checkdate(2, 29, (int)date('Y'))) $dias[] = '02-29';
        try {
            $in = implode(',', array_fill(0, count($dias), '?'));
            $qa = $db->prepare("SELECT c.id FROM ws_cliente c WHERE c.data_nasc IS NOT NULL AND DATE_FORMAT(c.data_nasc,'%m-%d') IN ($in)
                                  AND c.status NOT IN ('cancelado','inativo') AND c.celular IS NOT NULL AND c.celular<>''");
            $qa->execute($dias);
            $telJa = [];
            foreach ($qa->fetchAll(PDO::FETCH_COLUMN) as $cid) {
                $chave = 'aniversario-' . (int)$cid; if (isset($marca[$chave])) continue;
                $cli = ws_msg_contexto_cliente($db, (int)$cid); if (!$cli) continue;
                $num = function_exists('ws_wa_numero') ? ws_wa_numero((string)$cli['celular']) : (string)$cli['celular'];
                if (isset($telJa[$num])) { $marca[$chave] = 1; continue; }   // mesma pessoa com dois cadastros: 1 mensagem
                $msg = ws_msg_render($itA['texto'], ['nome' => $cli['nome'], 'cpf' => $cli['cpf_cnpj'], 'login' => $cli['login_pppoe'],
                    'email' => $cli['email'], 'endereco' => $cli['endereco'], 'bairro' => $cli['bairro'], 'cidade' => $cli['cidade'],
                    'celular' => $cli['celular'], 'plano' => $cli['plano']]);
                $r = ws_msg_enviar_cliente($db, 'aniversario', $itA, $cli, $msg);
                if (!empty($r['ok'])) { $marca[$chave] = 1; $telJa[$num] = 1; }
            }
        } catch (Throwable $e) {}
    }
    @file_put_contents($marcaFile, json_encode($marca)); @chmod($marcaFile, 0640);
}

/**
 * BOAS-VINDAS (03/10/2026) — mensagem de boas-vindas quando a ATIVAÇÃO do cliente é concluída.
 *
 * Quem chama: chamados.php, quando um chamado de INSTALAÇÃO é fechado (resolvido). O cliente entra na fila
 * (cache/msg_boas_vindas_fila.json) e ws_msg_boas_vindas_run() — a cada passada do cron — envia:
 *   - instalação VALIDADA pelo provedor (botão "Validar e fechar"): envia sem esperar;
 *   - instalação fechada de outro jeito: envia quando o cliente estiver CONECTADO (sessão aberta). Sem como
 *     conferir a conexão (addon do MK-Auth, sem radacct), envia assim mesmo. Não conectou em 3 dias: desiste.
 * Uma vez só por cliente (cache/msg_boas_vindas_enviados.json). Mesmas regras das outras automáticas:
 * mensagem ativada, Automático ligado, gateway ligado, janela de horário (08h–21h) e PROIBIDO para cliente
 * desativado/cancelado (ws_msg_enviar_cliente). Mensagem desligada no fechamento = cliente não entra na fila.
 */
function ws_msg_boas_vindas_marcar(PDO $db, int $chamadoId, bool $validado = false): void {
    try {
        $it = ws_msg_config()['itens']['boas_vindas'] ?? null;
        if (!$it || empty($it['ativo']) || trim((string)($it['texto'] ?? '')) === '') return;
        $st = $db->prepare("SELECT cliente_id, contrato_id, tipo FROM ws_chamado WHERE id=?"); $st->execute([$chamadoId]);
        $ch = $st->fetch(PDO::FETCH_ASSOC);
        if (!$ch || (string)$ch['tipo'] !== 'instalacao') return;
        $cid = (int)$ch['cliente_id'];
        $arqEnv = WS_CACHE . '/msg_boas_vindas_enviados.json';
        $env = is_file($arqEnv) ? (json_decode((string)@file_get_contents($arqEnv), true) ?: []) : [];
        if (isset($env[$cid])) return;   // já recebeu as boas-vindas
        $arqFila = WS_CACHE . '/msg_boas_vindas_fila.json';
        $fila = is_file($arqFila) ? (json_decode((string)@file_get_contents($arqFila), true) ?: []) : [];
        $achou = false;
        foreach ($fila as $i => $e) if ((int)$e['cli'] === $cid) { $achou = true; if ($validado) $fila[$i]['validado'] = 1; }
        if (!$achou) $fila[] = ['cli' => $cid, 'ct' => (int)($ch['contrato_id'] ?? 0), 'em' => time(), 'validado' => $validado ? 1 : 0, 'tent' => 0];
        @file_put_contents($arqFila, json_encode(array_values($fila))); @chmod($arqFila, 0640);
    } catch (Throwable $e) { /* aviso de boas-vindas nunca pode impedir o fechamento do chamado */ }
}
function ws_msg_boas_vindas_run(PDO $db): array {
    $res = ['enviados' => 0, 'fila' => 0];
    $arqFila = WS_CACHE . '/msg_boas_vindas_fila.json';
    $arqEnv  = WS_CACHE . '/msg_boas_vindas_enviados.json';
    $fila = is_file($arqFila) ? (json_decode((string)@file_get_contents($arqFila), true) ?: []) : [];
    if (!$fila) return $res;
    $it = ws_msg_config()['itens']['boas_vindas'] ?? null;
    $on = $it && !empty($it['ativo']) && trim((string)($it['texto'] ?? '')) !== '';
    $autoCfg = is_file(WS_CACHE . '/msg_auto.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/msg_auto.json'), true) ?: []) : [];
    $auto = (int)($autoCfg['ativo'] ?? 1) === 1;
    if (!is_file(__DIR__ . '/whatsapp.php')) return $res;
    require_once __DIR__ . '/whatsapp.php';
    $gatewayOn = (ws_wa_config()['gateway'] ?? 'evolution') !== 'desativado';
    // Desligou a mensagem, o Automático ou o gateway: a fila é descartada (ligar depois não dispara o acumulado).
    if (!$on || !$auto || !$gatewayOn) { @file_put_contents($arqFila, '[]'); return $res; }
    $hora = date('H:i'); $ini = (string)($autoCfg['horario'] ?? '08:00'); $fim = (string)($autoCfg['fim'] ?? '21:00');
    if ($hora < $ini || $hora >= $fim) { $res['fila'] = count($fila); return $res; }   // fora da janela: espera
    $env = is_file($arqEnv) ? (json_decode((string)@file_get_contents($arqEnv), true) ?: []) : [];
    $nova = [];
    foreach ($fila as $e) {
        $cid = (int)$e['cli'];
        if (isset($env[$cid]) || (int)$e['em'] < time() - 3 * 86400) continue;
        $ct = null;
        try {
            $sc = (int)$e['ct'] > 0
                ? $db->prepare("SELECT id, cliente_id, login_pppoe, login_ipoe FROM ws_contrato WHERE id=? AND status<>'cancelado'")
                : $db->prepare("SELECT id, cliente_id, login_pppoe, login_ipoe FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado' ORDER BY id LIMIT 1");
            $sc->execute([(int)$e['ct'] > 0 ? (int)$e['ct'] : $cid]); $ct = $sc->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Throwable $ex) {}
        if (empty($e['validado'])) {
            // "A sua conexão já está ATIVA!": só vai com o cliente conectado (sessão aberta, de qualquer hora).
            $online = $ct ? ws_msg_contrato_online($db, $ct, (int)$e['em'] - 30 * 86400) : false;
            if ($online === false) { $nova[] = $e; continue; }
        }
        $cli = ws_msg_contexto_cliente($db, $cid, $ct ? (int)$ct['id'] : null);
        if (!$cli || trim((string)$cli['celular']) === '') continue;
        $msg = ws_msg_render($it['texto'], ['nome' => $cli['nome'], 'cpf' => $cli['cpf_cnpj'], 'login' => $cli['login_pppoe'],
            'email' => $cli['email'], 'endereco' => $cli['endereco'], 'bairro' => $cli['bairro'], 'cidade' => $cli['cidade'],
            'celular' => $cli['celular'], 'plano' => $cli['plano']]);
        $r = ws_msg_enviar_cliente($db, 'boas_vindas', $it, $cli, $msg, [], 'automatico');
        if (!empty($r['ok'])) { $env[$cid] = date('c'); $res['enviados']++; }
        elseif (($r['raw'] ?? '') !== 'proibido' && ($r['raw'] ?? '') !== 'sem celular' && ++$e['tent'] < 3) $nova[] = $e;
    }
    @file_put_contents($arqEnv, json_encode($env)); @chmod($arqEnv, 0640);
    @file_put_contents($arqFila, json_encode(array_values($nova))); @chmod($arqFila, 0640);
    $res['fila'] = count($nova);
    return $res;
}

/** O login do contrato está conectado agora, numa sessão aberta DEPOIS de $desde?
 *  true/false; null = não dá para saber aqui (sem radacct neste banco, ex.: addon do MK-Auth). */
function ws_msg_contrato_online(PDO $db, array $ct, int $desde): ?bool {
    $logins = array_values(array_filter([trim((string)($ct['login_pppoe'] ?? '')), trim((string)($ct['login_ipoe'] ?? ''))]));
    if (!$logins) return null;
    try {
        $uso = (int)$db->query("SELECT COUNT(*) FROM radacct WHERE acctstarttime >= NOW() - INTERVAL 1 DAY")->fetchColumn();
        if ($uso === 0) return null;
        $in = implode(',', array_fill(0, count($logins), '?'));
        /* A janela é medida pelo relógio do BANCO (segundos atrás), não por uma data montada no PHP:
         * PHP e MySQL podem estar em fusos diferentes, e aí a sessão nova nunca "entraria" na janela. */
        $segs = max(120, time() - $desde + 120);
        $st = $db->prepare("SELECT 1 FROM radacct WHERE username IN ($in) AND acctstoptime IS NULL AND acctstarttime >= NOW() - INTERVAL " . (int)$segs . " SECOND LIMIT 1");
        $st->execute($logins);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return null; }
}

/**
 * AVISO DE BLOQUEIO e AVISO DE DESBLOQUEIO — por mudança de situação do contrato.
 *
 * Roda a cada passada do cron. Compara a situação de cada contrato com a da passada anterior
 * (cache/msg_estado_bloqueio.json): passou a bloqueado/suspenso → aviso de bloqueio; voltou a
 * liberado → aviso de desbloqueio. Pega TODO caminho de bloqueio (automático, manual, titular que
 * leva os adicionais) sem precisar de gancho em cada tela.
 *
 *  - Na PRIMEIRA execução só fotografa a situação: ninguém recebe aviso de algo que já era assim.
 *  - Mensagem desligada, gateway desligado ou Automático desligado: só atualiza a foto (ligar depois
 *    não dispara o acumulado).
 *  - Fila (cache/msg_eventos_fila.json): só envia das 08h (horário do Automático) às 21h. Bloqueou de
 *    madrugada → aviso às 08h, SE ainda estiver bloqueado. Bloqueou e liberou antes do envio → nada.
 *  - Desbloqueio diz "ONLINE": espera o cliente conectar de novo (até 6 h); sem como conferir a
 *    conexão (addon MK-Auth), envia assim que liberado.
 *  - Titular e adicionais com o mesmo celular: 1 mensagem por celular por dia, por tipo.
 *  - PROIBIDO para cliente desativado/cancelado (ws_msg_enviar_cliente).
 */
function ws_msg_eventos_estado_run(PDO $db): array {
    $res = ['novos' => 0, 'enviados' => 0, 'fila' => 0];
    /* 10/10/2026 — TRAVA: o cron roda a cada 2 min e uma passada com 40 envios dura mais que isso; sem trava a passada
     * seguinte começava antes de a anterior gravar o "já avisado" e o cliente recebia o MESMO aviso 2x (bloqueio 40 s depois). */
    $lkEv = @fopen(WS_CACHE . '/msg_eventos.lock', 'c');
    if ($lkEv && !flock($lkEv, LOCK_EX | LOCK_NB)) return $res;
    $arqEstado = WS_CACHE . '/msg_estado_bloqueio.json';
    $arqFila   = WS_CACHE . '/msg_eventos_fila.json';
    $arqEnv    = WS_CACHE . '/msg_eventos_enviados.json';
    try {
        $atual = [];
        foreach ($db->query("SELECT id, status FROM ws_contrato WHERE status<>'cancelado'")->fetchAll(PDO::FETCH_ASSOC) as $c)
            $atual[(int)$c['id']] = in_array((string)$c['status'], ['bloqueado', 'suspenso'], true) ? 1 : 0;
    } catch (Throwable $e) { return $res; }

    $existe = is_file($arqEstado);
    $antes = $existe ? (json_decode((string)@file_get_contents($arqEstado), true)['c'] ?? []) : [];
    @file_put_contents($arqEstado, json_encode(['em' => date('c'), 'c' => $atual])); @chmod($arqEstado, 0640);
    if (!$existe) return $res;   // primeira vez: só a foto

    $cfg = ws_msg_config();
    $itB = $cfg['itens']['bloqueio'] ?? null;    $onB = $itB && !empty($itB['ativo']) && trim($itB['texto'] ?? '') !== '';
    $itD = $cfg['itens']['desbloqueio'] ?? null; $onD = $itD && !empty($itD['ativo']) && trim($itD['texto'] ?? '') !== '';
    $autoCfg = is_file(WS_CACHE . '/msg_auto.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/msg_auto.json'), true) ?: []) : [];
    $auto = (int)($autoCfg['ativo'] ?? 1) === 1;
    if (!is_file(__DIR__ . '/whatsapp.php')) return $res;
    require_once __DIR__ . '/whatsapp.php';
    $gatewayOn = (ws_wa_config()['gateway'] ?? 'evolution') !== 'desativado';

    $fila = is_file($arqFila) ? (json_decode((string)@file_get_contents($arqFila), true) ?: []) : [];
    if (!$auto || !$gatewayOn || (!$onB && !$onD)) {
        if ($fila) @file_put_contents($arqFila, '[]');
        return $res;
    }
    // Mudanças desta passada → fila
    foreach ($atual as $id => $bloq) {
        if (!array_key_exists($id, $antes) || (int)$antes[$id] === $bloq) continue;
        $tipo = $bloq ? 'bloqueio' : 'desbloqueio';
        $oposto = $bloq ? 'desbloqueio' : 'bloqueio';
        $tinhaOposto = false;
        foreach ($fila as $i => $e) if ((int)$e['ct'] === $id && $e['tipo'] === $oposto) { unset($fila[$i]); $tinhaOposto = true; }
        if ($tinhaOposto) continue;   // mudou e desfez antes do aviso sair: nenhum aviso
        if (($tipo === 'bloqueio' && !$onB) || ($tipo === 'desbloqueio' && !$onD)) continue;
        $fila[] = ['tipo' => $tipo, 'ct' => $id, 'em' => time(), 'tent' => 0];
        $res['novos']++;
    }
    $fila = array_values(array_filter($fila, fn($e) => $e['em'] > time() - 2 * 86400));

    // Janela de envio do dia: do horário do Automático (padrão 08:00) até o fim (padrão 21:00).
    // Ninguém recebe aviso de bloqueio de madrugada: fora da janela o aviso espera na fila.
    $hora = date('H:i'); $ini = (string)($autoCfg['horario'] ?? '08:00'); $fim = (string)($autoCfg['fim'] ?? '21:00');
    if ($hora >= $ini && $hora < $fim && $fila) {
        $env = is_file($arqEnv) ? (json_decode((string)@file_get_contents($arqEnv), true) ?: []) : [];
        if (($env['_dia'] ?? '') !== date('Y-m-d')) $env = ['_dia' => date('Y-m-d')];
        $nova = [];
        foreach ($fila as $e) {
            $it = $e['tipo'] === 'bloqueio' ? $itB : $itD;
            if (!(($e['tipo'] === 'bloqueio') ? $onB : $onD)) continue;
            // a situação ainda é a do aviso?
            $estado = $atual[(int)$e['ct']] ?? null;
            if ($estado === null || ($e['tipo'] === 'bloqueio' && $estado !== 1) || ($e['tipo'] === 'desbloqueio' && $estado !== 0)) continue;
            try {
                $sc = $db->prepare("SELECT id, cliente_id, login_pppoe, login_ipoe FROM ws_contrato WHERE id=?");
                $sc->execute([(int)$e['ct']]); $ct = $sc->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable $ex) { $ct = null; }
            if (!$ct) continue;
            if ($e['tipo'] === 'desbloqueio') {
                $on = ws_msg_contrato_online($db, $ct, (int)$e['em']);
                if ($on === false) { if ($e['em'] > time() - 6 * 3600) $nova[] = $e; continue; }   // espera conectar
            }
            $cli = ws_msg_contexto_cliente($db, (int)$ct['cliente_id'], (int)$ct['id']);
            if (!$cli || trim((string)$cli['celular']) === '') continue;
            $num = function_exists('ws_wa_numero') ? ws_wa_numero((string)$cli['celular']) : (string)$cli['celular'];
            $chave = $e['tipo'] . '-' . $num;
            $envF = is_file($arqEnv) ? (json_decode((string)@file_get_contents($arqEnv), true) ?: []) : [];
            if (($envF['_dia'] ?? '') === date('Y-m-d')) $env = $envF + $env;   // o que outra passada já gravou
            if (isset($env[$chave])) continue;   // já avisado hoje neste celular (titular + adicionais)
            // Cliente que já mandou o comprovante (conferência em andamento/feita) não recebe aviso de bloqueio de novo.
            if ($e['tipo'] === 'bloqueio' && ws_msg_cobranca_suprimida($db, (int)$ct['cliente_id'], (string)$cli['celular'], true) !== '') { $env[$chave] = 1; continue; }
            $valor = null; $venc = null; $ids = [];
            if ($e['tipo'] === 'bloqueio') {
                try {
                    $sf = $db->prepare("SELECT id, valor, taxa_emissao, vencimento FROM ws_fatura WHERE contrato_id=? AND status IN('aberto','vencido','processando') AND vencimento < CURDATE() ORDER BY vencimento, id");
                    $sf->execute([(int)$ct['id']]);
                    foreach ($sf->fetchAll(PDO::FETCH_ASSOC) as $fx) { $valor = (float)$valor + ws_fatura_valor_cobrado($fx); $venc = $venc ?: $fx['vencimento']; $ids[] = (int)$fx['id']; }
                    if (!$ids) {   // bloqueio manual, sem título vencido: usa o que estiver em aberto
                        $sf2 = $db->prepare("SELECT id, valor, taxa_emissao, vencimento FROM ws_fatura WHERE contrato_id=? AND status IN('aberto','vencido','processando') ORDER BY vencimento, id");
                        $sf2->execute([(int)$ct['id']]);
                        foreach ($sf2->fetchAll(PDO::FETCH_ASSOC) as $fx) { $valor = (float)$valor + ws_fatura_valor_cobrado($fx); $venc = $venc ?: $fx['vencimento']; $ids[] = (int)$fx['id']; }
                    }
                    $valor = (float)$valor;
                } catch (Throwable $ex) {}
                $ids = ws_msg_faturas_pdf($db, (string)($it['anexo'] ?? 'nao'), (int)$ct['id'], $ids);
            }
            $msg = ws_msg_render($it['texto'], ['nome' => $cli['nome'], 'cpf' => $cli['cpf_cnpj'], 'login' => $cli['login_pppoe'],
                'valor' => $valor, 'vencimento' => $venc, 'email' => $cli['email'], 'endereco' => $cli['endereco'],
                'bairro' => $cli['bairro'], 'cidade' => $cli['cidade'], 'celular' => $cli['celular'], 'plano' => $cli['plano']]);
            // Já recebeu hoje a cobrança (boleto + PIX, e a cobrança já avisa da suspensão): nada de 2ª mensagem igual no mesmo dia (com a janela fechada seria outro modelo da Meta, pago).
            if ($e['tipo'] === 'bloqueio' && ws_msg_cobranca_suprimida($db, (int)$ct['cliente_id'], '', false) === 'já cobrado hoje') { $env[$chave] = 1; continue; }
            $r = ws_msg_enviar_cliente($db, $e['tipo'], $it, $cli, $msg, $ids, 'automatico', ['vencimento' => $venc, 'valor_boleto' => $valor]);
            if (!empty($r['ok'])) { $env[$chave] = 1; $res['enviados']++; @file_put_contents($arqEnv, json_encode($env)); }   // grava a cada envio, não só no fim
            elseif (($r['raw'] ?? '') !== 'proibido' && ($r['raw'] ?? '') !== 'sem celular' && ++$e['tent'] < 3) $nova[] = $e;
        }
        $fila = $nova;
        @file_put_contents($arqEnv, json_encode($env)); @chmod($arqEnv, 0640);
    }
    @file_put_contents($arqFila, json_encode(array_values($fila))); @chmod($arqFila, 0640);
    $res['fila'] = count($fila);
    return $res;
}
