<?php
/* =================================================================================================
 * IMPORTAÇÃO DE CONTAS E TÍTULOS DO MK-AUTH   (sis_boleto -> ws_banco, sis_lanc -> ws_fatura)
 * -------------------------------------------------------------------------------------------------
 * POR QUE ESTE ARQUIVO EXISTE
 *
 * O importador de backup só lia sis_plano / sis_cliente / sis_adicional. Ou seja: migrava o
 * cadastro e deixava para trás TODA a cobrança — nenhum boleto, nenhuma numeração, nenhuma conta.
 * O efeito colateral era pior do que parece: sem conta em ws_banco, o import gravava banco_id=NULL
 * em todo contrato, e nenhum cliente saía da migração com conta de cobrança configurada.
 *
 * ESTRUTURA REAL desta instalação (levantada do banco de produção, não presumida):
 *   sis_boleto : banco, cedente, nome, agencia/ag_digito, conta/ct_digito, carteira, convenio,
 *                multa, juros, diasatraso, localpag, cpf_cnpj, instr_linha1..5, titulo_inicial,
 *                delconta('s'|'n')
 *   sis_lanc   : login, datavenc, datapag, valor, valorpag, nossonum, linhadig, codigo_barras,
 *                referencia, uuid_lanc, deltitulo(0|1), tipo, obs,
 *                status('aberto'|'pago'|'vencido'|'cancelado')
 *
 * O status do MK-Auth casa 1:1 com ws_fatura.status — não precisa tradução.
 * ============================================================================================== */

/** Valor do MK-Auth ("123,45", "1.234,56", "123.45" ou "") -> float. */
function mk_valor($v): float {
    $v = trim((string)$v);
    if ($v === '') return 0.0;
    $v = str_replace(['R$', ' '], '', $v);
    // "1.234,56" -> "1234.56"; "1234.56" fica como está.
    if (strpos($v, ',') !== false) $v = str_replace('.', '', $v);
    $v = str_replace(',', '.', $v);
    return is_numeric($v) ? (float)$v : 0.0;
}

/** Data do MK-Auth -> 'Y-m-d' ou null (trata '0000-00-00' e vazio). */
function mk_data($v): ?string {
    $v = trim((string)$v);
    if ($v === '' || strpos($v, '0000') === 0) return null;
    $t = strtotime($v);
    return $t ? date('Y-m-d', $t) : null;
}

/**
 * Importa a CONTA de cobrança (sis_boleto -> ws_banco). Só a conta em uso (delconta <> 's').
 * Não duplica: se já existir conta com o mesmo nome, atualiza em vez de criar outra.
 * Também traz multa/juros/dias de atraso e os textos do boleto para cache/*.json, que é de onde
 * o WellSystem lê na hora de imprimir.
 *
 * @return int|null id da conta em ws_banco (vira o banco_id padrão dos contratos importados)
 */
function mk_importar_conta(PDO $imp, PDO $db, array &$res): ?int {
    if (!mk_tab($imp, 'sis_boleto')) return null;

    $cDel = mk_col($imp, 'sis_boleto', ['delconta']);
    /* TODAS as contas, não só uma.
     *
     * Isto trazia a primeira conta e parava (`break`). Provedor com mais de uma conta — e é o
     * normal: uma para boleto registrado, outra para PIX, outra de um banco que está saindo —
     * perdia as demais na migração, e ninguém percebia, porque UMA conta apareceu e a tela ficou
     * com cara de certa. Depois o operador ia emitir num banco que "sumiu".
     *
     * A ordem importa: a conta marcada como EM USO no MK-Auth (`utilizar='sim'`) vem primeiro e
     * vira a conta padrão dos contratos. As outras entram como cadastro, ativas, prontas para uso.
     * O teto de 5 é proposital — sis_boleto às vezes acumula lixo de teste, e 5 contas bancárias
     * já é mais do que qualquer provedor usa de verdade. */
    $cUso = mk_col($imp, 'sis_boleto', ['utilizar']);
    $sql  = "SELECT * FROM sis_boleto" . ($cDel ? " WHERE `$cDel` <> 's'" : '')
          . " ORDER BY " . ($cUso ? "(`$cUso`='sim') DESC, " : '') . "id ASC LIMIT 5";

    $contaId = null;
    foreach ($imp->query($sql) as $b) {
        // O "cedente" costuma vir como "RAZAO SOCIAL - CNPJ: 00.000.000/0001-00".
        // Para o titular interessa só a parte antes do " - CNPJ".
        $cedente = trim((string)($b['cedente'] ?? ''));
        $razao   = trim((string)preg_replace('/\s*-\s*CNPJ.*$/i', '', $cedente));
        $nome    = trim((string)($b['nome'] ?? '')) ?: ($razao ?: 'Conta importada do MK-Auth');
        $nome    = mb_substr(trim(preg_replace('/\s*-{2,}\s*/', ' ', $nome)), 0, 80);

        $agencia = trim((string)($b['agencia'] ?? ''));
        if (trim((string)($b['ag_digito'] ?? '')) !== '') $agencia .= '-' . trim((string)$b['ag_digito']);
        $conta = trim((string)($b['conta'] ?? ''));
        if (trim((string)($b['ct_digito'] ?? '')) !== '') $conta .= '-' . trim((string)$b['ct_digito']);

        // Chave PIX: o MK-Auth não tem campo próprio — costuma estar escrita numa linha de
        // instrução ("CHAVE PIX : 04154749000144"). Tenta extrair; senão usa o CNPJ do cedente.
        $pix = '';
        for ($i = 1; $i <= 5; $i++) {
            $l = (string)($b["instr_linha$i"] ?? '');
            if (preg_match('/PIX\s*:?\s*([A-Za-z0-9@._+\-]{6,})/i', $l, $m)) { $pix = $m[1]; break; }
        }
        if ($pix === '') $pix = preg_replace('/\D/', '', (string)($b['cpf_cnpj'] ?? ''));

        $codigo = mb_substr((string)($b['codbanco'] ?? ''), 0, 10);

        $e = $db->prepare("SELECT id FROM ws_banco WHERE nome=? LIMIT 1");
        $e->execute([$nome]);
        $id = (int)$e->fetchColumn();
        if ($id) {
            $db->prepare("UPDATE ws_banco SET codigo=?, agencia=?, conta=?, titular=?, pix=?, ativo=1 WHERE id=?")
               ->execute([$codigo, mb_substr($agencia, 0, 20), mb_substr($conta, 0, 30),
                          mb_substr($razao, 0, 120), mb_substr($pix, 0, 140), $id]);
        } else {
            $db->prepare("INSERT INTO ws_banco (nome, codigo, agencia, conta, titular, pix, ativo)
                          VALUES (?,?,?,?,?,?,1)")
               ->execute([$nome, $codigo, mb_substr($agencia, 0, 20), mb_substr($conta, 0, 30),
                          mb_substr($razao, 0, 120), mb_substr($pix, 0, 140)]);
            $id = (int)$db->lastInsertId();
        }
        /* Demais campos da conta (por conta, não globais): forma de emissão, taxa de cobrança, multa/juros e local de pagamento.
           Em try/catch: colunas novas podem não existir em instalação antiga. */
        try {
            $bnc = strtolower((string)($b['banco'] ?? '') . ' ' . (string)($b['gateway'] ?? '') . ' ' . $nome);
            $emi = strpos($bnc, 'lytex') !== false ? 'lytex'
                 : ((strpos($bnc, 'galax') !== false || strpos($bnc, 'celcash') !== false || strpos($bnc, 'celcoin') !== false) ? 'gateway' : 'proprio');
            $taxa = mk_valor($b['taxa'] ?? 0);
            $tAtiva = (strtolower(trim((string)($b['add_taxa'] ?? ''))) === 's' && $taxa > 0) ? 1 : 0;
            $db->prepare("UPDATE ws_banco SET emissao=?, taxa_cobranca_ativa=?, taxa_cobranca_valor=?, multa_pct=?, juros_pct=?, local_pgto=COALESCE(NULLIF(?,''),local_pgto) WHERE id=?")
               ->execute([$emi, $tAtiva, $taxa, mk_valor($b['multa'] ?? 0), mk_valor($b['juros'] ?? 0), trim((string)($b['localpag'] ?? '')), $id]);
        } catch (Throwable $e) {}
        // Conta o que VEIO DO BACKUP, não só o que era inédito. Contando só as novas, reimportar
        // mostrava "0 contas" mesmo tendo lido e atualizado todas — e "0" numa tela de resultado
        // se lê como "não veio nada", que é o oposto do que aconteceu.
        $res['contas'] = ($res['contas'] ?? 0) + 1;
        /* Daqui para baixo é CONFIGURAÇÃO DO SISTEMA (multa, juros, textos do boleto), e ela é
         * uma só — não uma por conta. Vale a da conta PADRÃO, que é a primeira desta lista.
         * Sem este corte, a última conta lida sobrescreveria a multa e as instruções da conta que
         * o provedor realmente usa: a configuração certa entraria e seria substituída em seguida
         * pela de uma conta velha, dentro do mesmo laço. */
        if ($contaId !== null) continue;
        $contaId = $id;

        // Regras de cobrança: multa, juros e dias de tolerância vêm do próprio backup.
        $multa = mk_valor($b['multa'] ?? 0);
        $juros = mk_valor($b['juros'] ?? 0);
        $cob = WS_CACHE . '/cobranca.json';
        $j = is_file($cob) ? (json_decode((string)@file_get_contents($cob), true) ?: []) : [];
        if ($multa > 0) $j['multa_pct'] = $multa;
        if ($juros > 0) $j['juros_pct'] = $juros;
        /* NÃO importa 'diasatraso' para dias_bloqueio. No MK-Auth esse campo é o prazo do boleto após o
         * vencimento (aqui veio 59) e NÃO os dias para bloquear o cliente; importá-lo fazia o
         * WellSystem só bloquear com 60 dias de atraso. Os dias de bloqueio ficam em Config → Cobrança. */
        @file_put_contents($cob, json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        // Textos impressos no boleto (instruções, local de pagamento, numeração inicial).
        $instr = [];
        for ($i = 1; $i <= 5; $i++) {
            $l = trim((string)($b["instr_linha$i"] ?? ''));
            if ($l !== '') $instr[] = $l;
        }
        $bt = WS_CACHE . '/boleto_textos.json';
        $t = is_file($bt) ? (json_decode((string)@file_get_contents($bt), true) ?: []) : [];
        if ($instr) $t['instrucoes'] = implode("\n", $instr);
        if (!empty($b['localpag']))       $t['local_pgto'] = (string)$b['localpag'];
        if (!empty($b['titulo_inicial'])) $t['nosso_numero_inicial'] = (int)$b['titulo_inicial'];
        @file_put_contents($bt, json_encode($t, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        // (sem break: o laço segue para cadastrar as demais contas — só a configuração do sistema
        //  acima é exclusiva da conta padrão, e o `continue` lá em cima garante isso.)
    }
    return $contaId;
}

/**
 * Importa os TÍTULOS (sis_lanc -> ws_fatura).
 *
 * @param array $statusOk    situações a trazer; vazio = todas. Ex.: ['aberto','vencido']
 * @param int   $mesesPagos  quantos meses de títulos PAGOS trazer (0 = nenhum; 999 = todos).
 *                           Existe porque esta base tem ~32 mil lançamentos: arrastar anos de
 *                           histórico pago estoura tempo/memória e não serve para cobrança.
 *                           Títulos em aberto/vencidos entram SEMPRE — são cobrança viva.
 */
function mk_importar_titulos(PDO $imp, PDO $db, array &$res, array $statusOk = [], int $mesesPagos = 12, ?array $soLogins = null, array $statusClienteWs = []): void {   // $soLogins / $statusClienteWs (09/10/2026, mk_complemento_lib.php): só esses logins do MK-Auth e só contratos de clientes do WellSystem nessa situação; vazios = comportamento de sempre
    $res['boletos'] = 0;
    $res['boletos_pulados'] = 0;
    $res['boletos_id_gateway'] = 0;   // faturas que receberam o ID do gateway (celcash_charge_id)
    /* POR QUE ZERO? — o motivo tem que sair daqui.
     * Esta função tinha três saídas silenciosas. Quando nenhuma delas era o caso, a tela também
     * não dizia nada, porque o card de boletos só aparecia com total > 0. Resultado prático:
     * importação sem boletos e sem NENHUMA pista do motivo. Agora todo caminho grava um recado. */
    $res['boletos_motivo'] = '';

    /* "sis_lanc não existe" e "sis_lanc está vazia" quase nunca são verdade num backup de provedor
     * em operação: o normal é o dump ter chegado e a RESTAURAÇÃO ter falhado (dump grande demais
     * para um único comando). $res['restore'] guarda o que cada arquivo virou de fato — se houver
     * erro registrado ali, é ELE que o operador precisa ler, não "o backup não tem títulos". */
    $erroRestore = trim((string)($res['restore']['sis_lanc']['erro'] ?? ''));
    $pista = $erroRestore !== ''
        ? ' O arquivo sis_lanc.sql veio no backup, mas a carga no banco temporário falhou: '
          . $erroRestore . ' — este é o motivo real.'
        : '';

    if (!mk_tab($imp, 'sis_lanc')) {
        $res['boletos_motivo'] = 'O backup não tem a tabela sis_lanc — não há títulos neste arquivo.' . $pista;
        return;
    }
    try { $totalLanc = (int)$imp->query("SELECT COUNT(*) FROM sis_lanc")->fetchColumn(); }
    catch (Throwable $e) { $totalLanc = -1; }
    if ($totalLanc === 0) {
        $res['boletos_motivo'] = 'A tabela sis_lanc do backup está vazia (0 títulos).' . $pista;
        return;
    }
    $res['boletos_no_backup'] = $totalLanc;

    // Mapa login -> contrato, montado UMA vez (evita um SELECT por título; são dezenas de milhares).
    $mapa = [];
    $sqlMapa = "SELECT id, cliente_id, login_pppoe, login_ipoe, ont_id FROM ws_contrato";
    if ($statusClienteWs) $sqlMapa = "SELECT ct.id, ct.cliente_id, ct.login_pppoe, ct.login_ipoe, ct.ont_id FROM ws_contrato ct JOIN ws_cliente cl ON cl.id=ct.cliente_id WHERE cl.status IN (" . implode(',', array_map(fn($x) => $db->quote((string)$x), $statusClienteWs)) . ")";
    $soLoginsSet = $soLogins === null ? null : array_flip(array_map('strtolower', $soLogins));
    foreach ($db->query($sqlMapa) as $ct) {
        foreach ([$ct['login_pppoe'], $ct['login_ipoe'], $ct['ont_id']] as $lg) {
            $lg = strtolower(trim((string)$lg));
            if ($lg !== '' && !isset($mapa[$lg])) {
                $mapa[$lg] = ['ct' => (int)$ct['id'], 'cli' => (int)$ct['cliente_id']];
            }
        }
    }
    if (!$mapa) {
        $res['boletos_motivo'] = 'Nenhum contrato com login no WellSystem para casar com os títulos. '
                               . 'Os títulos são ligados ao contrato PELO LOGIN — sem contrato importado, não há onde pendurá-los.';
        return;
    }

    $statusOk   = array_values(array_intersect($statusOk, ['aberto', 'pago', 'vencido', 'cancelado']));
    $limitePago = ($mesesPagos >= 999) ? null : date('Y-m-d', strtotime('-' . max(0, $mesesPagos) . ' months'));

    // Dedupe de reimportação: contrato + vencimento + nosso número.
    $jaTem = $db->prepare("SELECT COUNT(*) FROM ws_fatura
                           WHERE contrato_id=? AND vencimento=? AND COALESCE(nosso_numero,'')=?");
    $ins = $db->prepare("INSERT INTO ws_fatura
        (contrato_id, cliente_id, competencia, vencimento, valor, status,
         nosso_numero, linha_digitavel, data_pagamento, valor_pago, celcash_charge_id, criado_em)
        VALUES (?,?,?,?,?,?,?,?,?,?,?, NOW())");
    /* ID DO GATEWAY (Galax) — sis_lanc.chave_galaxpay = galaxPayId da cobrança (confirmado no MK-Auth:
     * chave_galaxpay=31892 é o Charge.galaxPayId que o webhook devolve). É por ele que o webhook_celcash.php
     * acha a fatura e dá a baixa. Só aceita valor numérico; título já importado sem ID é completado aqui. */
    $updGal = $db->prepare("UPDATE ws_fatura SET celcash_charge_id=?
                            WHERE contrato_id=? AND vencimento=? AND COALESCE(nosso_numero,'')=?
                              AND (celcash_charge_id IS NULL OR celcash_charge_id='')");

    /* ---------------------------------------------------------------------------------------
     * A BAIXA — por que uma fatura marcada "pago" não bastava.
     *
     * Marcar ws_fatura.status='pago' conta a situação do TÍTULO. O DINHEIRO é outra coisa: ele
     * vive em ws_pagamento, e é de lá — não da fatura — que saem três telas:
     *
     *   Financeiro → Caixa do dia ....... SUM(valor_pago) FROM ws_pagamento
     *   Relatórios → Caixa (movimento) .. o recebido mês a mês
     *   Fatura → histórico de pagamentos. as baixas daquele título
     *
     * Sem esta linha, a migração trazia o histórico pela metade: o cliente aparecia quitado, e o
     * caixa de todos os meses anteriores aparecia ZERADO. Não era relatório errado — era dinheiro
     * que nunca foi registrado como recebido.
     *
     * Traz também COLETOR e FORMA DE PAGAMENTO, que o MK-Auth guarda no próprio lançamento: sem
     * eles não há como fechar o acerto de quem recebeu em campo.
     *
     * Não há dedupe aqui de propósito — a baixa só é gravada junto de uma fatura RECÉM-inserida,
     * e a fatura já tem o dedupe acima. Reimportar não duplica dinheiro.
     * ------------------------------------------------------------------------------------- */
    $temColetor = (bool)mk_col($db, 'ws_pagamento', ['coletor']);
    $insPag = $db->prepare($temColetor
        ? "INSERT INTO ws_pagamento (fatura_id, data_pgto, valor_pago, forma, origem, obs, coletor)
           VALUES (?,?,?,?, 'manual', ?, ?)"
        : "INSERT INTO ws_pagamento (fatura_id, data_pgto, valor_pago, forma, origem, obs)
           VALUES (?,?,?,?, 'manual', ?)");
    $res['baixas'] = 0;

    /* ---------------------------------------------------------------------------------------
     * DE ONDE SAEM A FORMA DE PAGAMENTO E O ATENDENTE QUE RECEBEU.
     *
     * Estes dois campos eram lidos por NOME FIXO de coluna — $t['formapag'] e $t['coletor'].
     * O nome muda conforme a versão do MK-Auth (e mais ainda quando o backup vem de outro ERP):
     * numa base onde a coluna se chama outra coisa, o campo vinha sempre vazio, TODA baixa era
     * gravada como "dinheiro" e sem atendente nenhum — e a tela não dizia nada, porque o número
     * de baixas continuava certo. O dado não estava faltando no backup: estava sendo procurado
     * com o nome errado.
     *
     * Agora a coluna é DESCOBERTA no próprio backup, entre os nomes conhecidos, e o que foi
     * encontrado (ou não) vai no resultado da migração, para aparecer na tela.
     * ------------------------------------------------------------------------------------- */
    $colForma = mk_col($imp, 'sis_lanc', ['formapag', 'forma_pag', 'formapagamento', 'forma_pagamento',
                                          'tipo_pag', 'tipopag', 'forma', 'meio_pag', 'meiopag',
                                          'modo_pag', 'modalidade', 'tipo_recebimento', 'recebimento']);
    $colColetor = mk_col($imp, 'sis_lanc', ['coletor', 'atendente', 'recebedor', 'operador', 'usuario_baixa',
                                            'baixado_por', 'recebido_por', 'caixa', 'vendedor', 'usuario', 'login_user']);
    /* ÚLTIMO RECURSO para a forma: a coluna `tipo`. Em parte das versões ela guarda o tipo do
     * LANÇAMENTO (mensalidade, avulso, multa) e em outras a forma do recebimento. Por isso o
     * valor dela só é aceito quando o próprio conteúdo é reconhecível como forma de pagamento —
     * palpite que não se confirma é descartado, não gravado torto. */
    $colTipo = $colForma ? null : mk_col($imp, 'sis_lanc', ['tipo']);

    $res['baixas_forma_col']   = $colForma ?: ($colTipo ? $colTipo . ' (deduzido)' : '');
    $res['baixas_coletor_col'] = $colColetor ?: '';
    $res['baixas_com_forma']   = 0;
    $res['baixas_com_coletor'] = 0;

    /* O MK-Auth grava a forma num campo livre e com nomes próprios. Traduz para o vocabulário do
     * WellSystem — é o que os filtros e o fechamento de caixa esperam ver.
     * Devolve '' quando NÃO reconhece: é o que permite validar o palpite da coluna `tipo` acima. */
    $formaConhecida = static function ($v): string {
        $f = strtolower(trim((string)$v));
        if ($f === '') return '';
        if (strpos($f, 'pix') !== false)                                   return 'pix';
        if (strpos($f, 'boleto') !== false || strpos($f, 'bancar') !== false) return 'boleto';
        if (strpos($f, 'carne') !== false || strpos($f, 'carnê') !== false) return 'boleto';
        if (strpos($f, 'credito') !== false || strpos($f, 'crédito') !== false) return 'cartao';
        if (strpos($f, 'debito')  !== false || strpos($f, 'débito')  !== false) return 'cartao';
        if (strpos($f, 'cart') !== false)                                  return 'cartao';
        if (strpos($f, 'transf') !== false || strpos($f, 'ted') !== false || strpos($f, 'doc') !== false) return 'transferencia';
        if (strpos($f, 'deposit') !== false)                               return 'transferencia';
        if (strpos($f, 'dinheiro') !== false || strpos($f, 'especie') !== false || strpos($f, 'espécie') !== false) return 'dinheiro';
        return '';
    };
    /* O que não for reconhecido passa COMO VEIO (em minúsculas), porque perder a informação é
     * pior que guardá-la torta; campo vazio continua caindo em "dinheiro", como antes. */
    $forma = static function ($v) use ($formaConhecida): string {
        $ok = $formaConhecida($v);
        if ($ok !== '') return $ok;
        $f = strtolower(trim((string)$v));
        return $f === '' ? 'dinheiro' : mb_substr($f, 0, 20);
    };

    foreach ($imp->query("SELECT * FROM sis_lanc") as $t) {
        // Título apagado no MK-Auth não pode reaparecer aqui.
        if (!empty($t['deltitulo'])) { $res['boletos_pulados']++; continue; }

        $login = strtolower(trim((string)($t['login'] ?? '')));
        if ($login === '' || !isset($mapa[$login]) || ($soLoginsSet !== null && !isset($soLoginsSet[$login]))) { $res['boletos_pulados']++; continue; }

        $st = strtolower(trim((string)($t['status'] ?? 'aberto')));
        if (!in_array($st, ['aberto', 'pago', 'vencido', 'cancelado'], true)) $st = 'aberto';
        if ($statusOk && !in_array($st, $statusOk, true)) { $res['boletos_pulados']++; continue; }

        $venc = mk_data($t['datavenc'] ?? '');
        if (!$venc) { $res['boletos_pulados']++; continue; }

        // Corta histórico antigo de PAGOS; aberto/vencido/cancelado não são cortados por data.
        if ($st === 'pago' && $limitePago !== null && $venc < $limitePago) { $res['boletos_pulados']++; continue; }

        $nosso = mb_substr(trim((string)($t['nossonum'] ?? '')), 0, 20);
        $m = $mapa[$login];

        $galId = trim((string)($t['chave_galaxpay'] ?? ''));
        if (!preg_match('/^\d{1,20}$/', $galId)) $galId = '';

        $jaTem->execute([$m['ct'], $venc, $nosso]);
        if ((int)$jaTem->fetchColumn() > 0) {
            if ($galId !== '') { try { $updGal->execute([$galId, $m['ct'], $venc, $nosso]); $res['boletos_id_gateway'] += $updGal->rowCount(); } catch (Throwable $e) {} }
            $res['boletos_pulados']++; continue;
        }

        $valor = mk_valor($t['valor'] ?? 0);
        // Taxa de emissão: o MK-Auth só soma na impressão; a linha digitável traz o valor real cobrado no banco.
        $taxaLinha = function_exists('ws_taxa_pela_linha') ? ws_taxa_pela_linha((string)($t['linhadig'] ?? ''), $valor) : 0.0;
        // Modelo B (igual ao MK-Auth): o título fica com o valor do PLANO; a taxa só é anotada (taxa_emissao) e entra na cobrança.
        $pago  = mk_valor($t['valorpag'] ?? 0);
        $dtPag = mk_data($t['datapag'] ?? '');

        // "referencia" é a competência (varchar curto: "09/2026" ou "2026-09"); sem ela, usa o
        // ano-mês do vencimento.
        $ref = trim((string)($t['referencia'] ?? ''));
        if (preg_match('#^(\d{2})/(\d{4})$#', $ref, $mm)) {
            $ref = $mm[2] . '-' . $mm[1];
        } elseif (!preg_match('/^\d{4}-\d{2}$/', $ref)) {
            $ref = substr($venc, 0, 7);
        }

        try {
            $ins->execute([
                $m['ct'], $m['cli'], $ref, $venc, $valor, $st,
                ($nosso !== '' ? $nosso : null),
                (mb_substr(trim((string)($t['linhadig'] ?? '')), 0, 80) ?: null),
                $dtPag,
                ($pago > 0 ? $pago : null),
                ($galId !== '' ? $galId : null),
            ]);
            $res['boletos']++;
            /* (09/10/2026) o id da fatura nova é guardado AGORA: depois do UPDATE da taxa o lastInsertId() do PDO volta 0 e a baixa do título pago era gravada com fatura_id=0 — falhava calada e o pago ficava SEM baixa (no backup real: 2.123 de 3.395 pagos de desativados sem baixa). */
            $novoId = (int)$db->lastInsertId();
            if ($taxaLinha > 0) { try { $db->prepare("UPDATE ws_fatura SET taxa_emissao=? WHERE id=?")->execute([$taxaLinha, $novoId]); } catch (Throwable $e) {} }
            if ($galId !== '') $res['boletos_id_gateway']++;

            // Título quitado no MK-Auth => a baixa correspondente aqui, senão o dinheiro não
            // existe para a Caixa nem para o relatório mensal (veja o comentário lá em cima).
            if ($st === 'pago') {
                /* RECIBO DE FATURA PAGA QUE VEIO DE OUTRO SISTEMA NÃO É "PENDENTE DE ENVIO".
                   O backup do MK-Auth NÃO guarda quais recibos foram enviados (imp='nao', recibo vazio e num_recibos=0 em todas as faturas),
                   então não dá para saber pela marca. Pagamento ANTIGO (mais de 3 dias) já teve o recibo tratado lá: entra com recibo_em
                   = data do pagamento, senão milhares de recibos velhos aparecem como pendentes e podem ir em lote para os clientes.
                   Só pagamento RECENTE (últimos 3 dias) fica pendente, para ainda poder ser enviado. As marcas do MK-Auth, quando
                   existem (recibo/num_recibos/imp), também valem. */
                $limiteRecibo = date('Y-m-d', strtotime('-3 days'));
                $jaRecibo = ($dtPag && substr($dtPag, 0, 10) < $limiteRecibo)
                    || (!$dtPag && $venc < $limiteRecibo)
                    || trim((string)($t['recibo'] ?? '')) !== '' || (int)($t['num_recibos'] ?? 0) > 0 || strtolower(trim((string)($t['imp'] ?? ''))) === 'sim';
                if ($jaRecibo) { try { $db->prepare("UPDATE ws_fatura SET recibo_em=? WHERE id=?")->execute([($dtPag ?: $venc) . ' 12:00:00', $novoId]); } catch (Throwable $e) {} }
                // Quanto entrou: o valor pago quando o MK-Auth registrou; senão o valor do título.
                $vPago = ($pago > 0) ? $pago : $valor;
                // Quando entrou: a data do pagamento; sem ela, o vencimento. data_pgto é NOT NULL,
                // e jogar a baixa para hoje inflaria o caixa DESTE mês com dinheiro de anos atrás.
                $dPago = $dtPag ?: $venc;
                if ($vPago > 0) {
                    // Forma: a coluna descoberta no backup. Só cai no `tipo` quando o conteúdo
                    // dele é mesmo uma forma de pagamento (ver o bloco de detecção acima).
                    $valForma = $colForma !== null ? (string)($t[$colForma] ?? '') : '';
                    if (trim($valForma) === '' && $colTipo !== null) {
                        $cand = (string)($t[$colTipo] ?? '');
                        if ($formaConhecida($cand) !== '') $valForma = $cand;
                    }
                    // Atendente que recebeu (vai para ws_pagamento.coletor — é o "Recebido por"
                    // do recibo, da Caixa e do fechamento de quem recebeu em campo).
                    $col = $colColetor !== null ? mb_substr(trim((string)($t[$colColetor] ?? '')), 0, 80) : '';
                    $args = [
                        $novoId,
                        $dPago,
                        $vPago,
                        $forma($valForma),
                        'Importado do MK-Auth',
                    ];
                    if ($temColetor) $args[] = ($col !== '' ? $col : null);
                    try {
                        $insPag->execute($args);
                        $res['baixas']++;
                        if (trim($valForma) !== '') $res['baixas_com_forma']++;
                        if ($col !== '') $res['baixas_com_coletor']++;
                    } catch (Throwable $e) {}
                }
            }
        } catch (Throwable $e) {
            $res['boletos_pulados']++;
        }
    }

    /* O QUE DIZER SOBRE FORMA E ATENDENTE — decidido só agora, com o resultado real na mão.
     * A coluna `tipo` é um palpite: ela existe em praticamente todo backup, mas na maioria guarda
     * o tipo do lançamento, não a forma. Anunciar "a forma veio da coluna tipo" quando nenhuma
     * baixa aproveitou o valor dela seria pior do que dizer que não veio nada — o operador iria
     * procurar defeito num dado que nunca esteve lá. */
    if (!$colForma && (int)$res['baixas_com_forma'] === 0) $res['baixas_forma_col'] = '';

    /* Faltou algum dos dois? A tela mostra as colunas que a sis_lanc DESTE backup tem. É o que
     * permite reconhecer o nome usado por esta versão sem precisar abrir o banco por fora. */
    if ($res['baixas_forma_col'] === '' || $res['baixas_coletor_col'] === '') {
        try {
            $cols = $imp->query("SELECT column_name FROM information_schema.columns
                                 WHERE table_schema=DATABASE() AND table_name='sis_lanc'
                                 ORDER BY ordinal_position")->fetchAll(PDO::FETCH_COLUMN);
            $res['baixas_colunas'] = array_map('strval', (array)$cols);
        } catch (Throwable $e) {}
    }

    /* Leu tudo e não gravou nenhum? O motivo é sempre um filtro ou o casamento por login.
     * Sem esta mensagem, a tela mostrava só "0" — e 0 por filtro é MUITO diferente de 0 por erro. */
    if ($res['boletos'] === 0) {
        $res['boletos_motivo'] = 'Li ' . $totalLanc . ' título(s) no backup e nenhum entrou. '
            . 'Os ' . $res['boletos_pulados'] . ' pulados caem em: título apagado no MK-Auth (deltitulo), '
            . 'login sem contrato correspondente aqui, vencimento inválido, '
            . ($statusOk ? 'situação fora do filtro escolhido (' . implode(', ', $statusOk) . ')' : 'nenhum filtro de situação')
            . ($limitePago !== null ? ', ou PAGO com vencimento anterior a ' . $limitePago . ' (corte de histórico).' : '.');
    }
}
