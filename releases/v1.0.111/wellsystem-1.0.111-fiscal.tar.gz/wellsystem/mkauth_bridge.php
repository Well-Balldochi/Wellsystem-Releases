<?php
/**
 * PONTE WELLSYSTEM <-> MK-AUTH  (só faz sentido quando o WellSystem roda como addon do MK-Auth)
 * =============================================================================================
 * POR QUE ESTE ARQUIVO EXISTE
 *
 * O FreeRADIUS desta instalação lê o banco `mkradius` (do MK-Auth), e o WellSystem grava no
 * banco `wellsystem`. São bancos diferentes no mesmo MySQL. Resultado: o "desbloqueio em
 * confiança" era gravado corretamente em ws_contrato.confianca_ate, aparecia na tela — e não
 * tinha efeito nenhum na conexão, porque o FreeRADIUS nunca lê esse banco. O cliente reconectava
 * e continuava caindo na faixa 100.100.x.
 *
 * COMO O MK-AUTH BLOQUEIA (levantado do banco de produção, comparando um bloqueado e um liberado)
 *   - NÃO é por grupo: bloqueado e liberado ficam no MESMO radusergroup (o grupo do plano).
 *   - O bloqueio são DUAS linhas em mkradius.radreply para o username:
 *         Framed-Pool                  =  pgcorte
 *         Mikrotik-Delegated-IPv6-Pool =  pgcorte
 *     É o pool `pgcorte` que entrega o IP 100.100.x.
 *   - Um cliente liberado simplesmente NÃO tem linhas em radreply.
 *   - sis_cliente.bloqueado    = 'sim' | 'nao'
 *   - sis_cliente.tit_vencidos = quantidade de títulos vencidos (0 = em dia)
 *   - sis_cliente.observacao='sim' + sis_cliente.rem_obs=<data limite> é a convenção NATIVA de
 *     "desbloqueio em confiança" do MK-Auth — a mesma que o servidores.php já LIA.
 *
 * PRINCÍPIO DAS ALTERAÇÕES: mudança mínima e reversível. Só mexe no login informado, só nas
 * linhas/colunas listadas acima, nunca apaga cadastro. Toda função aceita $simular = true, que
 * devolve exatamente o que FARIA, sem executar nada.
 */

require_once __DIR__ . '/config.php';

/** Pool de bloqueio do MK-Auth (o que entrega 100.100.x). Editável em cache/mkauth.json. */
/**
 * Nome da pool de bloqueio no concentrador.
 *
 * O PADRÃO AGORA É `bloqueio`, e não mais `pgcorte`.
 * `pgcorte` era o nome que o MK-Auth usa. Copiá-lo para cá não trazia benefício nenhum: é um nome
 * que não diz o que é, e repetir o vocabulário de outro sistema no nosso só espalha a herança dele.
 * Instalação nova nasce com `bloqueio` — que qualquer pessoa lê e entende.
 *
 * MAS ESTE NOME NÃO É NOSSO PARA ESCOLHER SOZINHOS, e isso muda como a mudança foi feita.
 * A pool existe NO CONCENTRADOR (Mikrotik/accel-ppp). O RADIUS só devolve `Framed-Pool = <nome>`;
 * quem entrega o IP preso é o equipamento, e ele só conhece a pool que está configurada nele.
 * Trocar o padrão num parque que tem `pgcorte` configurado faria o RADIUS pedir uma pool que não
 * existe — e o resultado seria o inadimplente recebendo IP NORMAL, navegando de graça, com o
 * sistema registrando o bloqueio como feito. Silencioso e caro.
 *
 * Por isso a mudança é só no PADRÃO de instalação nova. Quem já tem parque configurado tem o nome
 * gravado em cache/mkauth.json, e continua com o dele — o ws_configs_garantir() escreve `pgcorte`
 * nesse arquivo em instalação que já existia, justamente para o padrão novo não mudar nada em quem
 * está rodando. Para adotar `bloqueio`, primeiro se cria a pool com esse nome no concentrador e só
 * depois se troca aqui (Servidores → Configuração).
 */
function ws_mk_pool_corte(): string {
    $f = WS_CACHE . '/mkauth.json';
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (!empty($j['pool_corte'])) return (string)$j['pool_corte'];
    }
    return 'bloqueio';
}

/** Atributos de radreply que compõem o bloqueio. */
function ws_mk_attrs_bloqueio(): array {
    return ['Framed-Pool', 'Mikrotik-Delegated-IPv6-Pool'];
}

/**
 * Conexão com o banco do MK-Auth, ou null se não existir (instalação standalone).
 * Usa as MESMAS credenciais do WellSystem (mesmo servidor MySQL). O nome do banco pode ser
 * trocado em cache/mkauth.json  ->  {"dbname":"mkradius"}
 */
function ws_mk_db(): ?PDO {
    static $pdo = null, $tentou = false;
    if ($tentou) return $pdo;
    $tentou = true;

    $c = ws_db_config();
    $nome = 'mkradius';
    $f = WS_CACHE . '/mkauth.json';
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (!empty($j['dbname'])) $nome = (string)$j['dbname'];
    }
    try {
        $p = new PDO("mysql:host={$c['host']};port={$c['porta']};dbname={$nome};charset=utf8mb4",
                     $c['user'], $c['pass'],
                     [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        // Só vale se as tabelas do MK-Auth estiverem mesmo lá.
        $n = (int)$p->query("SELECT COUNT(*) FROM information_schema.tables
                             WHERE table_schema=DATABASE() AND table_name IN ('sis_cliente','radreply')")->fetchColumn();
        $pdo = ($n >= 2) ? $p : null;
    } catch (Throwable $e) {
        $pdo = null;
    }
    return $pdo;
}

/** Existe MK-Auth ao lado? (evita tentar qualquer coisa numa instalação standalone) */
function ws_mk_presente(): bool { return ws_mk_db() !== null; }

/**
 * Estado atual do login no MK-Auth, ou null se não houver MK-Auth / o login não existir.
 * Campos: bloqueado, tit_vencidos, observacao, rem_obs, plano, em_corte (bool).
 */
function ws_mk_estado(string $login): ?array {
    $mk = ws_mk_db();
    if (!$mk) return null;
    try {
        $st = $mk->prepare("SELECT bloqueado, tit_vencidos, observacao, rem_obs, plano
                            FROM sis_cliente WHERE login=? LIMIT 1");
        $st->execute([$login]);
        $r = $st->fetch();
        if (!$r) return null;

        $q = $mk->prepare("SELECT COUNT(*) FROM radreply
                           WHERE username=? AND attribute IN ('Framed-Pool','Mikrotik-Delegated-IPv6-Pool')");
        $q->execute([$login]);
        $r['em_corte']     = ((int)$q->fetchColumn() > 0);
        $r['tit_vencidos'] = (int)($r['tit_vencidos'] ?? 0);
        return $r;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * LIBERA o login no MK-Auth por confiança, até $ate ('Y-m-d H:i:s').
 *
 * O que faz, e só isso:
 *   1. apaga de radreply as linhas Framed-Pool / Mikrotik-Delegated-IPv6-Pool do username
 *      — é o que tira o cliente do pool pgcorte e devolve IP de navegação;
 *   2. em sis_cliente: bloqueado='nao', data_desbloq=NOW(), observacao='sim', rem_obs=<limite>
 *      — marcação NATIVA de confiança do MK-Auth, para o próprio MK-Auth não re-bloquear
 *        o cliente dentro do prazo.
 *
 * NÃO mexe em radusergroup (bloqueado e liberado usam o mesmo grupo), não mexe em radcheck,
 * não altera plano e não apaga nada do cadastro.
 */
function ws_mk_confiar(string $login, string $ate, bool $simular = false): array {
    $out = ['ok' => false, 'acoes' => [], 'erro' => null];
    $login = trim($login);
    if ($login === '') { $out['erro'] = 'login vazio'; return $out; }

    $mk = ws_mk_db();
    if (!$mk) {
        // Standalone: não é erro, simplesmente não há MK-Auth para sincronizar.
        $out['ok'] = true;
        $out['erro'] = null;
        $out['acoes'][] = 'sem MK-Auth nesta instalação — nada a fazer';
        return $out;
    }

    $attrs = ws_mk_attrs_bloqueio();
    $in = "'" . implode("','", $attrs) . "'";
    try {
        $q = $mk->prepare("SELECT attribute, value FROM radreply WHERE username=? AND attribute IN ($in)");
        $q->execute([$login]);
        foreach ($q->fetchAll() as $r) {
            $out['acoes'][] = "radreply: APAGAR {$r['attribute']} = {$r['value']}";
        }
        $out['acoes'][] = "sis_cliente: bloqueado='nao', data_desbloq=NOW(), observacao='sim', rem_obs='{$ate}'";

        if ($simular) { $out['ok'] = true; return $out; }

        $mk->beginTransaction();
        $mk->prepare("DELETE FROM radreply WHERE username=? AND attribute IN ($in)")->execute([$login]);
        $mk->prepare("UPDATE sis_cliente SET bloqueado='nao', data_desbloq=NOW(), observacao='sim', rem_obs=?
                      WHERE login=?")->execute([$ate, $login]);
        $mk->commit();
        $out['ok'] = true;

        // Derruba a sessão AQUI, com os dados do MK-Auth. Sem isto o cliente continua na sessão
        // antiga e mantém o IP de bloqueio, porque o endereço é entregue na autenticação.
        $d = ws_mk_desconectar($login);
        $out['acoes'][] = 'sessão: ' . ($d['ok'] ? ('derrubada — ' . ($d['detalhe'] ?: $d['via'])) : ('NÃO derrubada — ' . $d['detalhe']));
    } catch (Throwable $e) {
        if ($mk->inTransaction()) $mk->rollBack();
        $out['erro'] = $e->getMessage();
    }
    return $out;
}

/**
 * REVOGA a confiança no MK-Auth quando o prazo vence.
 *
 * Só devolve ao bloqueio quem AINDA tem título vencido (tit_vencidos > 0). Se o cliente pagou,
 * ele apenas sai da marcação de confiança e continua navegando — que é o comportamento pedido:
 * "sem boleto vencido, ou pago, deve sair na hora automaticamente".
 */
function ws_mk_revogar(string $login, bool $simular = false): array {
    $out = ['ok' => false, 'acoes' => [], 'rebloqueou' => false, 'erro' => null];

    $mk = ws_mk_db();
    if (!$mk) { $out['ok'] = true; $out['acoes'][] = 'sem MK-Auth nesta instalação'; return $out; }

    $est = ws_mk_estado($login);
    if (!$est) { $out['erro'] = 'login não existe no MK-Auth'; return $out; }

    $pool = ws_mk_pool_corte();
    $deveBloquear = ($est['tit_vencidos'] > 0);
    $out['rebloqueou'] = $deveBloquear;

    $out['acoes'][] = "sis_cliente: observacao='nao'" . ($deveBloquear ? ", bloqueado='sim', data_bloq=NOW()" : '');
    if ($deveBloquear) {
        foreach (ws_mk_attrs_bloqueio() as $a) $out['acoes'][] = "radreply: INSERIR {$a} = {$pool}";
    } else {
        $out['acoes'][] = 'tit_vencidos=0 (em dia): NÃO re-bloqueia, só tira a marcação de confiança';
    }

    if ($simular) { $out['ok'] = true; return $out; }

    try {
        $mk->beginTransaction();
        if ($deveBloquear) {
            $ins = $mk->prepare("INSERT INTO radreply (username,attribute,op,value) VALUES (?,?,'=',?)");
            $ja  = $mk->prepare("SELECT COUNT(*) FROM radreply WHERE username=? AND attribute=?");
            foreach (ws_mk_attrs_bloqueio() as $a) {
                $ja->execute([$login, $a]);
                if (!(int)$ja->fetchColumn()) $ins->execute([$login, $a, $pool]);
            }
            $mk->prepare("UPDATE sis_cliente SET bloqueado='sim', data_bloq=NOW(), observacao='nao'
                          WHERE login=?")->execute([$login]);
        } else {
            $mk->prepare("UPDATE sis_cliente SET observacao='nao' WHERE login=?")->execute([$login]);
        }
        $mk->commit();
        $out['ok'] = true;
    } catch (Throwable $e) {
        if ($mk->inTransaction()) $mk->rollBack();
        $out['erro'] = $e->getMessage();
    }
    return $out;
}

/**
 * Passa por TODAS as confianças vigentes no WellSystem e resolve as que já devem terminar,
 * mantendo o MK-Auth em sincronia. Duas situações encerram a confiança:
 *
 *   1. VENCEU o prazo do calendário -> ws_mk_revogar() devolve ao pool de corte se ainda houver
 *      título vencido; se o cliente pagou nesse meio tempo, ele só perde a marcação e segue
 *      navegando (o MK-Auth não tem motivo para bloquear).
 *   2. O cliente PAGOU antes do prazo (tit_vencidos = 0 no MK-Auth) -> sai da confiança na hora,
 *      exatamente como pedido. Este é o sinal certo: o ws_fatura do banco do WellSystem está
 *      vazio numa base migrada, e foi justamente ele que, usado como critério, apagava a
 *      confiança recém-concedida.
 *
 * Só encosta em contratos que ESTÃO em confiança. Retorna o resumo do que foi feito.
 */
function ws_mk_sincronizar_confiancas(PDO $db): array {
    $res = ['vencidas' => 0, 'pagas' => 0, 'rebloqueadas' => 0, 'erros' => 0];
    if (!ws_mk_presente()) return $res;

    try {
        $rows = $db->query("SELECT id, login_pppoe, login_ipoe, ont_id, confianca_ate
                            FROM ws_contrato
                            WHERE confianca_ate IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return $res; }

    $limpar = $db->prepare("UPDATE ws_contrato SET confianca_ate = NULL WHERE id = ?");

    foreach ($rows as $ct) {
        $login = trim((string)($ct['login_pppoe'] ?: ($ct['login_ipoe'] ?: $ct['ont_id'])));
        if ($login === '') continue;

        $venceu = strtotime((string)$ct['confianca_ate']) <= time();
        $est    = ws_mk_estado($login);
        $pagou  = ($est !== null && $est['tit_vencidos'] === 0);

        if (!$venceu && !$pagou) continue;   // confiança vigente e ainda em atraso: não toca

        $r = ws_mk_revogar($login);
        if (!$r['ok']) { $res['erros']++; continue; }
        if (!empty($r['rebloqueou'])) $res['rebloqueadas']++;

        $limpar->execute([(int)$ct['id']]);
        if ($venceu) $res['vencidas']++; else $res['pagas']++;
    }
    return $res;
}

/**
 * NOME RESUMIDO NO CONCENTRADOR (IPoE) — cenário addon MK-Auth.
 *
 * Quem autentica aqui é o FreeRADIUS do MK-Auth, e a regra dele (post-auth, só NAS-Port-Type
 * Ethernet) manda em SRouter-IPoE-Alias o `nome_res` de sis_cliente (login) ou de sis_adicional
 * (username). O FreeRADIUS do MK-Auth não é alterado: o WellSystem só grava o nome resumido do
 * cadastro nesse campo, e o concentrador passa a exibir o nome no lugar do ID.
 *
 *   $sobrescrever = true   cadastro salvo agora pelo operador: grava o nome do WellSystem mesmo
 *                          que o MK-Auth tenha outro (é a edição que ele acabou de fazer).
 *   $sobrescrever = false  rotina automática: só PREENCHE nome_res vazio. Nunca troca em massa um
 *                          nome que o MK-Auth já exibe nos concentradores.
 *
 * Só contrato não cancelado com nome resumido preenchido. Lê o que o MK-Auth tem numa consulta e
 * grava só o que difere — rodar de novo não altera nada.
 *
 * @return int linhas alteradas no MK-Auth
 */
function ws_mk_sincronizar_nome_res(PDO $db, ?int $clienteId = null, bool $sobrescrever = false): int {
    $mk = ws_mk_db();
    if (!$mk) return 0;

    static $cols = null;   // tabela => tamanho máximo de nome_res (só as que têm a coluna)
    if ($cols === null) {
        $cols = [];
        try {
            foreach ($mk->query("SELECT table_name t, character_maximum_length n FROM information_schema.columns
                                 WHERE table_schema=DATABASE() AND column_name='nome_res'
                                   AND table_name IN ('sis_cliente','sis_adicional')") as $r) {
                $cols[strtolower((string)$r['t'])] = (int)($r['n'] ?? 0);
            }
        } catch (Throwable $e) {}
    }
    if (!$cols) return 0;

    $sql = "SELECT c.nome_resumido, ct.login_pppoe, ct.login_ipoe
              FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
             WHERE ct.status <> 'cancelado' AND c.nome_resumido IS NOT NULL AND c.nome_resumido <> ''";
    $par = [];
    if ($clienteId !== null) { $sql .= " AND c.id = ?"; $par[] = $clienteId; }
    $st = $db->prepare($sql);
    $st->execute($par);
    $mapa = [];   // login (minúsculo) => nome resumido
    foreach ($st->fetchAll() as $r) {
        $nome = trim((string)$r['nome_resumido']);
        foreach (['login_ipoe', 'login_pppoe'] as $k) {
            $lg = mb_strtolower(trim((string)($r[$k] ?? '')), 'UTF-8');
            if ($lg !== '') $mapa[$lg] = $nome;
        }
    }
    if (!$mapa) return 0;

    $n = 0;
    foreach (['sis_cliente' => 'login', 'sis_adicional' => 'username'] as $tab => $chave) {
        if (!isset($cols[$tab])) continue;
        try {
            $atual = [];   // login (minúsculo) => [login como está no MK-Auth, nome_res de hoje]
            if ($clienteId !== null) {
                $q = $mk->prepare("SELECT $chave k, nome_res v FROM $tab WHERE $chave IN ("
                                  . implode(',', array_fill(0, count($mapa), '?')) . ")");
                $q->execute(array_map('strval', array_keys($mapa)));
            } else {
                $q = $mk->query("SELECT $chave k, nome_res v FROM $tab");
            }
            foreach ($q->fetchAll() as $r) {
                $atual[mb_strtolower((string)$r['k'], 'UTF-8')] = [(string)$r['k'], trim((string)($r['v'] ?? ''))];
            }
            $up = $mk->prepare("UPDATE $tab SET nome_res = ? WHERE $chave = ?");
            foreach ($mapa as $lg => $nome) {
                if (!isset($atual[(string)$lg])) continue;
                [$loginMk, $hoje] = $atual[(string)$lg];
                $novo = $cols[$tab] > 0 ? mb_substr($nome, 0, $cols[$tab], 'UTF-8') : $nome;
                if ($hoje === $novo || (!$sobrescrever && $hoje !== '')) continue;
                $up->execute([$novo, $loginMk]);
                $n += $up->rowCount();
            }
        } catch (Throwable $e) {}
    }
    return $n;
}

/**
 * DERRUBA a sessão do cliente usando os dados do MK-AUTH.
 *
 * Por que existe: ws_rad_disconnect() do radius_lib.php procura a sessão ativa em `radacct` e o
 * segredo do NAS em `nas` — mas no BANCO DO WELLSYSTEM, que nesta instalação está vazio. As
 * sessões reais vivem em mkradius.radacct. Resultado: a desconexão simplesmente não acontecia,
 * o cliente continuava na MESMA sessão e, como o IP é entregue na autenticação, seguia com o
 * endereço de bloqueio (100.100.x) mesmo já liberado. Era este o elo que faltava.
 *
 * Dois caminhos, nesta ordem:
 *   1. accel-ppp — "terminate username X hard" no socket de gerência (porta 2000) do próprio
 *      concentrador que atende a sessão. É o método que o painel já usa e o que funciona aqui.
 *   2. CoA/Disconnect via radclient (porta 3799), para instalação com Mikrotik ou outro NAS
 *      que aceite Disconnect-Request.
 *
 * O IP do concentrador vem do nasipaddress da sessão ATIVA — não é chute nem configuração fixa.
 *
 * @return array{ok:bool,via:string,detalhe:string}
 */
function ws_mk_desconectar(string $login): array {
    $out = ['ok' => false, 'via' => '', 'detalhe' => ''];
    $mk = ws_mk_db();
    if (!$mk) { $out['detalhe'] = 'sem MK-Auth'; return $out; }

    try {
        $st = $mk->prepare("SELECT nasipaddress, acctsessionid, framedipaddress, callingstationid
                            FROM radacct
                            WHERE username=? AND acctstoptime IS NULL
                            ORDER BY acctstarttime DESC LIMIT 1");
        $st->execute([$login]);
        $s = $st->fetch();
        if (!$s || empty($s['nasipaddress'])) {
            // Não é erro: sem sessão ativa não há o que derrubar, e o próximo login já vem certo.
            $out['ok'] = true;
            $out['detalhe'] = 'sem sessão ativa (nada a derrubar)';
            return $out;
        }
        $nasIp = (string)$s['nasipaddress'];

        /* ---- 0) accel-ppp com CONFIRMAÇÃO (radius_lib.php): terminate por username, confere se
         *         a sessão saiu e, se não saiu, derruba pelo Acct-Session-Id. Não confirmou?
         *         Segue para os caminhos abaixo, como antes. ---- */
        if (function_exists('ws_rad_disconnect_accel')
            && ws_rad_disconnect_accel($nasIp, $login, (string)($s['acctsessionid'] ?? ''))) {
            if (function_exists('ws_rad_fechar_sessao_derrubada')) ws_rad_fechar_sessao_derrubada($mk, $login);   // sessão/IP não ficam presos
            $out['ok'] = true;
            $out['via'] = "accel-ppp {$nasIp} (confirmado)";
            $out['detalhe'] = 'sessão encerrada e conferida no concentrador';
            return $out;
        }

        /* ---- 1) accel-ppp: terminate no socket de gerência do concentrador ---- */
        $porta = (int)(getenv('WS_ACCEL_PORT') ?: 2000);
        /* SSL primeiro, TCP depois — ver ws_accel_conectar() em radius_lib.php.
         * O accel-ppp costuma atender a gerência sobre TLS. Com socket cru a conexão estabelece,
         * o servidor espera o handshake que não vem, e o "terminate" nunca chega: a conexão do
         * cliente não cai e a tela diz que caiu. Aqui isso é pior que na leitura — lá falta
         * informação, aqui a ação simplesmente não acontece. */
        if (function_exists('ws_accel_conectar')) {
            $sk = ws_accel_conectar($nasIp, $porta, 3);
        } else {
            $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]]);
            $sk = @stream_socket_client("ssl://{$nasIp}:{$porta}", $en, $es, 3, STREAM_CLIENT_CONNECT, $ctx)
               ?: @stream_socket_client("tcp://{$nasIp}:{$porta}", $en, $es, 3, STREAM_CLIENT_CONNECT);
        }
        if ($sk) {
            stream_set_timeout($sk, 3);
            @fread($sk, 2048);                                   // consome o banner
            fputs($sk, "terminate username " . $login . " hard\r\n");
            $resp = '';
            $fim = time() + 3;
            while (!feof($sk) && time() < $fim) {
                $l = fgets($sk, 4096);
                if ($l === false) break;
                $resp .= $l;
                if (preg_match('/accel-ppp#\s*$/', $l)) break;
            }
            fclose($sk);
            $out['via'] = "accel-ppp {$nasIp}:{$porta}";
            $out['detalhe'] = trim(str_replace("\x00", '', $resp)) ?: 'comando enviado';
            // accel-ppp não confirma com mensagem própria; ausência de erro já vale como enviado.
            if (stripos($resp, 'not found') === false && stripos($resp, 'error') === false) {
                $out['ok'] = true;
                usleep(700000);
                if (function_exists('ws_rad_fechar_sessao_derrubada')) ws_rad_fechar_sessao_derrubada($mk, $login);
                return $out;
            }
        } else {
            $out['detalhe'] = "accel-ppp {$nasIp}:{$porta} não respondeu ({$es})";
        }

        /* ---- 2) CoA/Disconnect via radclient ---- */
        $n = $mk->prepare("SELECT secret, COALESCE(coa_port,3799) coa_port FROM nas WHERE nasname=? LIMIT 1");
        $n->execute([$nasIp]);
        $nas = $n->fetch();
        if (!$nas || empty($nas['secret'])) {
            $out['detalhe'] .= " | NAS {$nasIp} sem secret em mkradius.nas";
            return $out;
        }
        $bin = trim((string)@shell_exec('command -v radclient 2>/dev/null'));
        if ($bin === '') { $out['detalhe'] .= ' | radclient ausente (instale freeradius-utils)'; return $out; }

        $attrs = "User-Name={$login},Acct-Session-Id={$s['acctsessionid']}";
        if (!empty($s['framedipaddress']))  $attrs .= ",Framed-IP-Address={$s['framedipaddress']}";
        if (!empty($s['callingstationid'])) $attrs .= ",Calling-Station-Id={$s['callingstationid']}";

        $cmd = sprintf('printf %s | %s -x %s:%d disconnect %s 2>&1',
            escapeshellarg($attrs), escapeshellcmd($bin),
            escapeshellarg($nasIp), (int)$nas['coa_port'], escapeshellarg((string)$nas['secret']));
        $res = (string)@shell_exec($cmd);

        $out['via']     = "CoA {$nasIp}:{$nas['coa_port']}";
        $out['detalhe'] = trim($res);
        $out['ok']      = (stripos($res, 'Disconnect-ACK') !== false);
        if ($out['ok']) { usleep(700000); if (function_exists('ws_rad_fechar_sessao_derrubada')) ws_rad_fechar_sessao_derrubada($mk, $login); }
    } catch (Throwable $e) {
        $out['detalhe'] = $e->getMessage();
    }
    return $out;
}

/**
 * Conexão MYSQLI com o banco do MK-Auth (ou null quando não existe).
 *
 * O painel dos concentradores foi escrito em mysqli e depende de uma variável `$link` para
 * consultar sis_cliente/sis_adicional — nome, plano e, principalmente, o uuid_cliente que abre o
 * cadastro no ERP antigo. Só que essa variável NUNCA era criada naquele arquivo: as 29 consultas
 * ficavam atrás de `if (isset($link) && $link ...)` e simplesmente não rodavam. O efeito era
 * silencioso e enganoso — o uuid caía no md5(login), o link montava um endereço válido, o MK-Auth
 * abria e não achava ninguém: "página vazia".
 *
 * Mesmas credenciais e mesmo banco de ws_mk_db() (que é PDO); aqui é mysqli só porque é isso que
 * o código daquela página usa. Conexão única por requisição.
 */
function ws_mk_mysqli() {
    static $link = null, $tentou = false;
    if ($tentou) return $link;
    $tentou = true;
    if (!function_exists('mysqli_connect')) return null;

    $c = ws_db_config();
    $nome = 'mkradius';
    $f = WS_CACHE . '/mkauth.json';
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (!empty($j['dbname'])) $nome = (string)$j['dbname'];
    }
    $m = @mysqli_connect($c['host'], $c['user'], $c['pass'], $nome, (int)$c['porta']);
    if (!$m) return null;
    @mysqli_set_charset($m, 'utf8mb4');
    // Só serve se as tabelas do MK-Auth estiverem mesmo neste banco — senão é melhor devolver
    // null e deixar o sistema seguir só com o banco do WellSystem, sem erro em tela.
    $r = @mysqli_query($m, "SHOW TABLES LIKE 'sis_cliente'");
    if (!$r || !mysqli_num_rows($r)) { @mysqli_close($m); return null; }
    $link = $m;
    return $link;
}
