<?php
/**
 * CONFIGURAÇÕES DO SISTEMA VINDAS DO BACKUP DO MK-AUTH.
 *
 * O ws_configs_garantir() (config.php) já CRIA os arquivos de configuração quando faltam — mas
 * vazios. Esta rotina os PREENCHE com o que o MK-Auth tinha, para a instalação nova subir pronta
 * em vez de pronta-e-vazia. Tudo continua editável nas telas normais do sistema.
 *
 * REGRA: só escreve em campo que está VAZIO. Rodar de novo é inofensivo e nunca desfaz um ajuste
 * feito à mão — o backup informa, não manda.
 *
 * DE ONDE VEM (conferido na estrutura real do backup, não suposto):
 *   sis_boleto    → conta, instruções, multa/juros/atraso, "nosso número" e os TOKENS dos
 *                   gateways. galax_id/galax_hash/galax_tokenwebhook são o CelCash/GalaxPay que
 *                   o WellSystem integra; lytex, iugu, juno e gerencianet ficam guardados em
 *                   gateways_mkauth.json — não são usados hoje, mas só existem neste backup.
 *   sis_configmsg → chave/valor com a mensageria (SMTP/WhatsApp).
 *   sis_contato   → NÃO entra: é a caixa do formulário de contato do site, não configuração.
 */

/** Lê um JSON de configuração do cache (ou [] se não existir). */
function mk_cfg_ler(string $arq): array {
    $f = WS_CACHE . '/' . $arq;
    $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : [];
    return is_array($j) ? $j : [];
}

/**
 * Grava SÓ os campos que estão vazios no arquivo atual. Devolve quantos preencheu.
 * "Vazio" = ausente, string vazia, null, ou zero — o valor que ws_configs_garantir() deixa.
 */
function mk_cfg_completar(string $arq, array $novos): int {
    $atual = mk_cfg_ler($arq);
    $mudou = 0;
    foreach ($novos as $k => $v) {
        if ($v === null || $v === '' || $v === []) continue;              // nada a oferecer
        $tem = $atual[$k] ?? '';
        if ($tem !== '' && $tem !== null && $tem !== 0 && $tem !== '0') continue;   // já preenchido
        $atual[$k] = $v;
        $mudou++;
    }
    if ($mudou) {
        $f = WS_CACHE . '/' . $arq;
        $j = json_encode($atual, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (@file_put_contents($f, $j) !== false) @chmod($f, 0640);
    }
    return $mudou;
}

/** Importa as configurações do backup para os arquivos do WellSystem. */
function mk_importar_configs(PDO $imp, PDO $db, array &$res): void {
    $res['configs'] = 0;
    $res['configs_detalhe'] = [];
    $reg = function (string $arq, int $n) use (&$res) {
        if ($n > 0) {
            $res['configs'] += $n;
            $res['configs_detalhe'][] = $arq . ': ' . $n . ' campo(s)';
        }
    };

    // ------------------------------------------------------------------ sis_boleto --------
    if (function_exists('mk_tab') && mk_tab($imp, 'sis_boleto')) {
        $cDel = mk_col($imp, 'sis_boleto', ['delconta']);
        // "utilizar" marca a conta em uso; sem ela, a primeira não apagada.
        $sql = "SELECT * FROM sis_boleto" . ($cDel ? " WHERE `" . $cDel . "` <> 's'" : '')
             . " ORDER BY (utilizar='sim') DESC, id ASC LIMIT 1";
        $b = null;
        try { $b = $imp->query($sql)->fetch(PDO::FETCH_ASSOC); } catch (Throwable $e) { $b = null; }

        if ($b) {
            $g = function (string $k) use ($b) { return trim((string)($b[$k] ?? '')); };

            // Identidade do provedor. O cedente costuma vir "RAZAO - CNPJ: 00.000.000/0001-00".
            $cedente = $g('cedente');
            $razao   = trim(preg_replace('/\s*-\s*CNPJ.*$/i', '', $cedente));
            $reg('provedor.json', mk_cfg_completar('provedor.json', [
                'razao'    => ($razao !== '' ? $razao : $g('nome')),
                'fantasia' => $g('nome'),
                'cnpj'     => preg_replace('/\D/', '', $g('cpf_cnpj')),
            ]));

            // Textos e numeração do boleto.
            $instr = [];
            for ($i = 1; $i <= 5; $i++) { $l = $g('instr_linha' . $i); if ($l !== '') $instr[] = $l; }
            $obs = [];
            for ($i = 1; $i <= 4; $i++) { $l = $g('obs_linha' . $i);  if ($l !== '') $obs[] = $l; }
            $inicial = (int)($g('titulo_inicial') !== '' ? $g('titulo_inicial') : $g('nosso'));
            $reg('boleto_textos.json', mk_cfg_completar('boleto_textos.json', [
                'instrucoes'           => implode("\n", $instr),
                'demonstrativo'        => implode("\n", $obs),
                'local_pgto'           => $g('localpag'),
                'nosso_numero_inicial' => ($inicial > 0 ? $inicial : null),
            ]));

            // Regras de cobrança (multa/juros em percentual no MK-Auth).
            $reg('cobranca.json', mk_cfg_completar('cobranca.json', [
                'multa_pct'     => ($g('multa') !== '' ? (float)str_replace(',', '.', $g('multa')) : null),
                'juros_pct'     => ($g('juros') !== '' ? (float)str_replace(',', '.', $g('juros')) : null),
                'dias_bloqueio' => ((int)$g('diasatraso') > 0 ? (int)$g('diasatraso') : null),
            ]));

            // CelCash / GalaxPay — o gateway que o WellSystem integra.
            // galax_tokenwebhook do MK-Auth corresponde ao webhook_secret daqui.
            if ($g('galax_id') !== '' || $g('galax_hash') !== '') {
                $reg('celcash.json', mk_cfg_completar('celcash.json', [
                    'ativo'          => 1,
                    'galax_id'       => $g('galax_id'),
                    'galax_hash'     => $g('galax_hash'),
                    'webhook_secret' => $g('galax_tokenwebhook'),
                ]));
            }

            /* Demais gateways: GUARDADOS, não descartados. O WellSystem hoje integra o CelCash,
               mas jogar fora as credenciais dos outros seria perder informação que só existe
               neste backup — e que faz falta se um dia o provedor voltar a usá-los. */
            $outros = [];
            foreach ([
                'lytex_id'       => 'lytex_id',        'lytex_secret'   => 'lytex_secret',
                'iugu_token'     => 'iugu_token',      'iugu_url'       => 'iugu_url',
                'juno_token'     => 'token_juno',      'juno_sandbox'   => 'token_sjuno',
                'juno_email'     => 'email_juno',      'bfacil_token'   => 'token_bfacil',
                'bfacil_email'   => 'email_bfacil',    'pagseguro'      => 'token_pagseguro',
                'gnet_conta'     => 'id_conta_gnet',   'gnet_client_id' => 'cliente_id_gnet',
                'gnet_secret'    => 'cliente_secret_gnet', 'gnet_url'   => 'url_gnet',
                'gateway_ativo'  => 'gateway',
            ] as $destino => $origem) {
                $v = $g($origem);
                if ($v !== '') $outros[$destino] = $v;
            }
            if ($outros) $reg('gateways_mkauth.json', mk_cfg_completar('gateways_mkauth.json', $outros));
        }
    }

    /* --------------------------------------------------------------- sis_configmsg -------
     * Tabela chave/valor. As chaves mudam entre versões do MK-Auth, então o casamento é por
     * PADRÃO no nome (contém "smtp", "whats"...) em vez de lista fixa — lista fixa quebra em
     * silêncio na primeira versão diferente, e ninguém descobre. */
    if (function_exists('mk_tab') && mk_tab($imp, 'sis_configmsg')) {
        $kv = [];
        try {
            foreach ($imp->query("SELECT item, valor FROM sis_configmsg") as $r) {
                $kv[strtolower(trim((string)$r['item']))] = trim((string)$r['valor']);
            }
        } catch (Throwable $e) { $kv = []; }

        if ($kv) {
            $achar = function (array $padroes) use ($kv) {
                foreach ($padroes as $p) {
                    foreach ($kv as $k => $v) {
                        if ($v !== '' && strpos($k, $p) !== false) return $v;
                    }
                }
                return '';
            };
            $porta = (int)$achar(['smtp_port', 'porta_smtp', 'smtpport']);
            $reg('smtp.json', mk_cfg_completar('smtp.json', [
                'host'      => $achar(['smtp_host', 'smtphost', 'servidor_smtp', 'smtp']),
                'porta'     => ($porta > 0 ? $porta : null),
                'usuario'   => $achar(['smtp_user', 'usuario_smtp', 'smtplogin', 'email_user']),
                'senha'     => $achar(['smtp_pass', 'senha_smtp', 'smtppass']),
                'remetente' => $achar(['smtp_from', 'remetente', 'email_from', 'mail_from']),
            ]));
            $reg('whatsapp.json', mk_cfg_completar('whatsapp.json', [
                'url'       => $achar(['whats_url', 'whatsapp_url', 'url_whats', 'api_whats']),
                'token'     => $achar(['whats_token', 'whatsapp_token', 'token_whats']),
                'instancia' => $achar(['whats_inst', 'instancia', 'whatsapp_inst']),
            ]));
            /* O que não casou fica registrado como veio. Nada do backup se perde por eu não ter
               previsto o nome da chave — o operador abre o arquivo e vê tudo. */
            mk_cfg_completar('configmsg_mkauth.json', $kv);
        }
    }
}

/* =================================================================================================
 * CONCENTRADORES (NAS), API E HISTÓRICO DE CONEXÃO VINDOS DO BACKUP
 * -------------------------------------------------------------------------------------------------
 * Estes dados NUNCA chegaram na migração por um motivo simples: os arquivos correspondentes não
 * eram sequer extraídos do .maz — a extração pegava só 5 tabelas. Corrigido isso, falta o que está
 * aqui: transformar o que veio no cadastro equivalente do WellSystem.
 *
 * REGRA, a mesma do resto deste arquivo: completa o que falta, nunca desfaz o que já existe.
 * Rodar de novo é inofensivo e não duplica nada.
 * ============================================================================================== */

/**
 * NAS / concentradores. Duas saídas, porque o WellSystem usa as duas:
 *   1) tabela `nas`             -> é o que o FreeRADIUS consulta (IP + segredo);
 *   2) wellsystem_config.json   -> é a lista que o Painel dos Concentradores usa para abrir sessão.
 */
function mk_importar_nas(PDO $imp, PDO $db, array &$res): void {
    $res['nas'] = 0;
    $tab = mk_tab($imp, 'nas') ? 'nas' : (mk_tab($imp, 'sis_nas') ? 'sis_nas' : '');
    if ($tab === '') return;

    try { $linhas = $imp->query("SELECT * FROM " . $tab)->fetchAll(PDO::FETCH_ASSOC); }
    catch (Throwable $e) { return; }
    if (!$linhas) return;

    /* `nas` recebe só o que é do FreeRADIUS. A porta do CoA vem do backup do MK-Auth (onde ela
     * existia dentro de `nas`), mas é gravada em ws_concentrador — a nossa tabela. Ver o comentário
     * de `nas` no schema_radius.php: a porta do CoA nunca foi campo do FreeRADIUS. */
    $existe = $db->prepare("SELECT id FROM nas WHERE nasname = ? LIMIT 1");
    $ins    = $db->prepare("INSERT INTO nas (nasname, shortname, type, secret, description)
                            VALUES (?,?,?,?,?)");
    $cncCfg = [];

    foreach ($linhas as $n) {
        $ip = trim((string)($n['nasname'] ?? $n['ip'] ?? ''));
        if ($ip === '') continue;
        $apelido = trim((string)($n['shortname'] ?? $n['nome'] ?? ''));
        $segredo = trim((string)($n['secret'] ?? $n['senha'] ?? ''));
        if ($segredo === '') $segredo = 'secret';
        $tipo = trim((string)($n['type'] ?? ''));
        if ($tipo === '') $tipo = 'other';
        $coa = (int)($n['coa_port'] ?? 0);
        if ($coa <= 0) $coa = 3799;
        /* MikroTik (RouterBoard) x accel-ppp: o MK-Auth guarda tudo como "other". MikroTik fala pela API (porta 8728); accel-ppp pelo telnet (porta 2000).
           Reconhece pelo tipo do NAS ou pelo nome/descrição (RB_…, CCR…, CRS…, "mikrotik", "routerboard"); o resto é accel-ppp. Dá para trocar em Servidores. */
        $ehMk = strtolower($tipo) === 'mikrotik' || (bool)preg_match('/^(rb|ccr|crs|hap|hex)[\s_\-0-9]/i', $apelido) || (bool)preg_match('/mikrotik|routerboard/i', $apelido . ' ' . trim((string)($n['description'] ?? '')));
        $tipoCnc = $ehMk ? 'mikrotik' : 'accel'; $portaCnc = $ehMk ? 8728 : 2000;

        $existe->execute([$ip]);
        if (!$existe->fetchColumn()) {
            try {
                $ins->execute([mb_substr($ip, 0, 128), mb_substr($apelido, 0, 32), mb_substr($tipo, 0, 30),
                               mb_substr($segredo, 0, 60),
                               mb_substr(trim((string)($n['description'] ?? '')), 0, 200)]);
                $res['nas']++;
            } catch (Throwable $e) { /* NAS é complemento: nunca trava a migração */ }
        }

        // Porta do CoA -> ws_concentrador (nossa tabela), casada pelo IP.
        try {
            $ec = $db->prepare("SELECT id FROM ws_concentrador WHERE host=? LIMIT 1");
            $ec->execute([$ip]); $cid = (int)$ec->fetchColumn();
            if ($cid) $db->prepare("UPDATE ws_concentrador SET coa_port=? WHERE id=?")->execute([$coa, $cid]);
            else      $db->prepare("INSERT INTO ws_concentrador (nome,tipo,host,porta,coa_port,ativo) VALUES (?,?,?,?,?,1)")
                         ->execute([($apelido !== '' ? mb_substr($apelido, 0, 120) : $ip), $tipoCnc, $ip, $portaCnc, $coa]);
        } catch (Throwable $e) { /* coluna ainda não criada: o CoA cai nos 3799 do padrão */ }

        /* Só entra na lista do Painel quem é concentrador de verdade. O MK-Auth cadastra o próprio
           servidor como NAS (127.0.0.1) para o FreeRADIUS falar consigo mesmo — pôr isso na lista
           faria o Painel tentar abrir sessão contra ele mesmo e ficar esperando resposta. */
        if ($ip !== '127.0.0.1' && strtolower($ip) !== 'localhost') {
            $nomeCnc = $apelido;
            if ($nomeCnc === '' && function_exists('ws_cnc_curto')) $nomeCnc = ws_cnc_curto($ip);
            if ($nomeCnc === '') $nomeCnc = $ip;
            $cncCfg[] = ['nome' => $nomeCnc, 'ip' => $ip, 'porta' => $portaCnc, 'tipo' => $tipoCnc];
        }
    }

    /* Lista do Painel: só preenche quando ainda NÃO há concentrador configurado à mão.
       Sobrescrever a lista de quem já configurou seria trocar uma configuração que funciona por
       uma vinda de backup — e ninguém pediu isso. */
    if ($cncCfg && function_exists('ws_cache_dir')) {
        $arq   = ws_cache_dir() . '/wellsystem_config.json';
        $atual = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
        if (empty($atual['concentradores'])) {
            $atual['concentradores'] = $cncCfg;
            $js = json_encode($atual, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (@file_put_contents($arq, $js) !== false) {
                @chmod($arq, 0664);
                $res['configs'] = ($res['configs'] ?? 0) + count($cncCfg);
                $res['configs_detalhe'][] = 'concentradores: ' . count($cncCfg) . ' do backup';
            }
        }
    }
}

/**
 * sis_config — parâmetros gerais e CHAVES DE API do MK-Auth.
 * O nome das chaves muda entre versões, então nada é descartado: o que não casa com um campo
 * conhecido do WellSystem fica guardado inteiro em config_mkauth.json, onde o operador enxerga.
 */
function mk_importar_api(PDO $imp, PDO $db, array &$res): void {
    if (!mk_tab($imp, 'sis_config')) return;
    $kv = [];
    try {
        foreach ($imp->query("SELECT * FROM sis_config") as $r) {
            // Aceita os dois formatos: chave/valor (item|valor) e linha única com muitas colunas.
            if (isset($r['item'])) {
                $kv[strtolower(trim((string)$r['item']))] = trim((string)($r['valor'] ?? ''));
                continue;
            }
            foreach ($r as $k => $v) {
                if (is_scalar($v) && trim((string)$v) !== '') $kv[strtolower((string)$k)] = trim((string)$v);
            }
        }
    } catch (Throwable $e) { return; }
    if (!$kv) return;

    $achar = function (array $padroes) use ($kv) {
        foreach ($padroes as $p) {
            foreach ($kv as $k => $v) { if ($v !== '' && strpos($k, $p) !== false) return $v; }
        }
        return '';
    };
    $n = mk_cfg_completar('api.json', [
        'token'    => $achar(['token_api', 'api_token', 'apitoken', 'token']),
        'chave'    => $achar(['chave_api', 'api_key', 'apikey']),
        'url_base' => $achar(['url_api', 'api_url', 'endpoint']),
    ]);
    if ($n) {
        $res['configs'] = ($res['configs'] ?? 0) + $n;
        $res['configs_detalhe'][] = 'api.json: ' . $n . ' campo(s)';
    }
    // Nada do backup se perde por eu não ter previsto o nome da chave.
    mk_cfg_completar('config_mkauth.json', $kv);
}

/**
 * HISTÓRICO DE CONEXÃO DO CLIENTE (radacct do backup -> radacct do WellSystem).
 * É o que alimenta o relatório de conexão da ficha. Traz só a janela recente: o histórico completo
 * desta base passa de milhões de linhas, e conexão de dois anos atrás não ajuda no suporte —
 * só enche o banco e deixa a consulta lenta.
 *
 * @param int $meses janela a importar (padrão: 3 meses).
 */
function mk_importar_conexoes(PDO $imp, PDO $db, array &$res, int $meses = 3): void {
    $res['conexoes'] = 0;
    if (!mk_tab($imp, 'radacct')) return;

    $desde = date('Y-m-d 00:00:00', strtotime('-' . max(1, $meses) . ' months'));
    try {
        $st = $imp->prepare("SELECT username, nasipaddress, framedipaddress, callingstationid,
                                    acctstarttime, acctstoptime, acctinputoctets, acctoutputoctets,
                                    acctsessiontime, acctsessionid
                               FROM radacct
                              WHERE acctstarttime >= ? OR acctstoptime IS NULL
                              ORDER BY acctstarttime");
        $st->execute([$desde]);
    } catch (Throwable $e) {
        $res['conexoes_motivo'] = 'radacct do backup em formato inesperado: ' . $e->getMessage();
        return;
    }

    // Dedupe por sessão + início: reimportar o mesmo backup não duplica conexão nenhuma.
    $ja  = $db->prepare("SELECT COUNT(*) FROM radacct WHERE acctsessionid = ? AND acctstarttime <=> ?");
    $ins = $db->prepare("INSERT INTO radacct (acctsessionid, username, nasipaddress, framedipaddress,
                             callingstationid, acctstarttime, acctstoptime, acctinputoctets,
                             acctoutputoctets, acctsessiontime)
                         VALUES (?,?,?,?,?,?,?,?,?,?)");
    while ($s = $st->fetch(PDO::FETCH_ASSOC)) {
        $sid = (string)($s['acctsessionid'] ?? '');
        $ini = $s['acctstarttime'] ?: null;
        try {
            $ja->execute([$sid, $ini]);
            if ((int)$ja->fetchColumn() > 0) continue;
            $ins->execute([$sid, (string)$s['username'], (string)$s['nasipaddress'],
                           (string)$s['framedipaddress'], (string)$s['callingstationid'],
                           $ini, ($s['acctstoptime'] ?: null),
                           (int)$s['acctinputoctets'], (int)$s['acctoutputoctets'],
                           (int)$s['acctsessiontime']]);
            $res['conexoes']++;
        } catch (Throwable $e) { /* linha ruim não interrompe o histórico inteiro */ }
    }
}
