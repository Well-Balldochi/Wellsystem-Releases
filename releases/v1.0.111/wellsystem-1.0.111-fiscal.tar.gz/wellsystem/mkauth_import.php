<?php
/**
 * WellSystem — Importador do backup do MK-Auth (.maz = bzip2+tar, .sql ou .sql.gz).
 * Extrai sis_plano/sis_cliente, importa num banco temporário e mapeia para ws_plano/ws_cliente/ws_contrato.
 * Sem guard/HTML aqui — a UI fica em importar.php (assim dá para testar por CLI).
 */
require_once __DIR__ . '/config.php';
// Contas e títulos (sis_boleto -> ws_banco, sis_lanc -> ws_fatura). Antes a migração trazia só o
// cadastro e deixava a cobrança inteira para trás.
require_once __DIR__ . '/mkauth_boletos.php';

/** Primeira coluna existente (defensivo entre versões). */
function mk_col(PDO $db, string $tab, array $cand): ?string {
    $in = implode(',', array_fill(0, count($cand), '?'));
    $st = $db->prepare("SELECT column_name FROM information_schema.columns
                        WHERE table_schema=DATABASE() AND table_name=? AND column_name IN ($in)
                        ORDER BY FIELD(column_name,$in) LIMIT 1");
    $st->execute(array_merge([$tab], $cand, $cand));
    return $st->fetchColumn() ?: null;
}
function mk_tab(PDO $db, string $tab): bool {
    $st = $db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
    $st->execute([$tab]); return (int)$st->fetchColumn() > 0;
}



/* ==============================================================================================
 * DADOS DA OLT NA MIGRAÇÃO — zona, VLAN, placa/PON, ONT-ID e equipamento.
 *
 * O backup do MK-Auth NÃO tem esses campos: ele guarda login, senha e, quando muito, o serial da
 * ONU. Quem sabe em que placa/PON a ONU está, em que VLAN e em que zona é a OLT. Como o módulo da
 * OLT agora fica ao lado do código raiz, dá para casar os dois pelo SERIAL e trazer o resto.
 *
 * FONTES (o olt_link.php lê a mais recente entre as pastas de cache do módulo):
 *   olt_onus_cache.json  -> retrato ATUAL da OLT: fsp, VLAN, zona, tipo/modelo de cada ONU
 *   olt_autorizacoes.json -> o que foi gravado ao LIBERAR a ONU (zona/VLAN escolhidas pelo operador)
 * A autorização vence o retrato quando as duas têm o campo: ela é a intenção registrada.
 *
 * REGRA AO GRAVAR: nunca sobrescreve o que já está preenchido no contrato — a OLT só COMPLETA.
 * Assim a migração não desfaz nada que o backup tenha trazido, e rodar de novo é inofensivo.
 * ============================================================================================ */

/**
 * Grava o prazo do desbloqueio em confiança no contrato recém-criado.
 *
 * No MK-Auth a confiança é `observacao='sim'` + `rem_obs=<data-limite>`. No WellSystem é a coluna
 * ws_contrato.confianca_ate — a MESMA que o botão "Desbloqueio em confiança" do painel preenche.
 * Gravando aqui, o cliente migrado chega no sistema no mesmo estado em que estava: aparece na
 * lista de BLOQUEADOS, marcado como em confiança, e o cron re-bloqueia quando a data passar.
 */
function mk_confianca_gravar(PDO $db, int $contratoId, ?string $ate): bool {
    if ($contratoId <= 0 || !$ate) return false;
    if (!mk_col($db, 'ws_contrato', ['confianca_ate'])) return false;   // banco antigo, sem a coluna
    try {
        $db->prepare("UPDATE ws_contrato SET confianca_ate = ? WHERE id = ?")->execute([$ate, $contratoId]);
        return true;
    } catch (Throwable $e) { return false; }
}

/** Normaliza serial para comparação (maiúsculas, sem separadores). */

function mk_olt_sn(string $s): string { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $s)); }

/** Serial no formato HEXADECIMAL (HWTC09D792AC -> 4857544309D792AC). O cadastro e a OLT usam o hex;
 *  o SmartOLT costuma usar o formato com as 4 letras do fabricante. '' se não for serial GPON. */
function mk_olt_sn_hex(string $s): string {
    $s = mk_olt_sn($s);
    if (preg_match('/^([A-Z]{4})([0-9A-F]{8})$/', $s, $m)) {
        $p = ''; for ($i = 0; $i < 4; $i++) $p .= sprintf('%02X', ord($m[1][$i]));
        return $p . $m[2];
    }
    return preg_match('/^[0-9A-F]{16}$/', $s) ? $s : '';
}

/** ONU/ONT a partir do que a OLT/SmartOLT informa (tipo, modo ou nome do perfil de serviço). */
function mk_olt_tipo(array $o): string {
    foreach ([$o['tipo'] ?? '', $o['modo'] ?? ''] as $v) {
        $v = strtoupper(trim((string)$v));
        if ($v === 'ONT' || strpos($v, 'ROUT') !== false) return 'ONT';
        if ($v === 'ONU' || strpos($v, 'BRIDG') !== false) return 'ONU';
    }
    $srv = strtoupper(trim((string)($o['srv'] ?? '')));
    if ($srv !== '') return (strpos($srv, 'ONT-') === 0 || strpos($srv, 'ONT ') === 0) ? 'ONT' : 'ONU';
    return '';
}

/** Traduz um registro da OLT (cache ou autorização) para as colunas de ws_contrato. */
function mk_olt_registro(array $o): array {
    $fsp = (string)($o['fsp'] ?? '');
    $p = explode('/', $fsp);                       // "0/5/8" -> frame 0, placa 5, PON 8
    $placa = (count($p) === 3) ? trim($p[1]) : '';
    $pon   = (count($p) === 3) ? trim($p[2]) : '';
    $tipo  = mk_olt_tipo($o);                      // ONU (bridge) / ONT (router)
    $mod   = trim((string)($o['modelo'] ?? ''));
    return [
        'vlan'        => (int)($o['vlan'] ?? 0) ?: null,
        'zona'        => mb_strtoupper(trim((string)($o['zona'] ?? '')), 'UTF-8') ?: null,   // a ficha grava zona em maiúsculo
        'placa_pon'   => $placa !== '' ? $placa : null,
        'pon'         => $pon   !== '' ? $pon   : null,
        'ont_id'      => trim((string)($o['ont_id'] ?? ($o['id'] ?? ''))) !== '' ? trim((string)($o['ont_id'] ?? $o['id'])) : null,
        /* EQUIPAMENTO é o MODO (o campo da ficha é a lista "ONU (Bridge)" / "ONT (Router)").
           Antes ia o MODELO aqui (ex.: HG8145V5), que não é opção da lista: o modo nunca aparecia.
           O modelo vai para equip_modelo, que é o campo dele. */
        'equipamento' => ($tipo === 'ONT' ? 'ONT (Router)' : ($tipo === 'ONU' ? 'ONU (Bridge)' : null)),
        'equip_modelo'=> $mod !== '' ? $mod : null,
        // Potência óptica medida na ONU: rx = o que a ONU recebe, tx = o que ela transmite.
        // Vinha sendo descartada aqui — era o pendente "sinal da OLT, o tx e rx não puxou".
        'rx_sinal'    => trim((string)($o['rx'] ?? '')) ?: null,
        'tx_sinal'    => trim((string)($o['tx'] ?? '')) ?: null,
        // Retorno: o que a OLT recebe DESTA ONU (upstream). A OLT publica como "rx_olt".
        'rx_olt'      => trim((string)($o['rx_olt'] ?? '')) ?: null,
    ];
}

/** Mapa SERIAL -> dados da OLT. Montado uma vez por execução (o backup tem milhares de linhas). */
function mk_olt_mapa(): array {
    static $mapa = null;
    if ($mapa !== null) return $mapa;
    $mapa = [];
    if (!function_exists('ws_olt_ler_json')) {
        $f = __DIR__ . '/olt_link.php';
        if (!is_file($f)) return $mapa;            // sem módulo da OLT: segue sem enriquecer
        require_once $f;
    }
    /* O SINAL mora em outro cache, com outra chave.
     * olt_onus_cache.json é indexado por SERIAL; olt_sinal_cache.json (o que o coletor SNMP
     * atualiza a cada varredura, e é o mais recente que existe) é indexado por "fsp|ont_id".
     * Sem juntar os dois, rx/tx nunca chegavam ao cadastro mesmo com a OLT acessível. A junção
     * é feita aqui, na montagem do mapa, e não em cada chamada. */
    $sinal = function_exists('ws_olt_ler_json') ? ws_olt_ler_json('olt_sinal_cache.json') : [];
    if (!is_array($sinal)) $sinal = [];

    // 1) retrato atual da OLT
    $c = ws_olt_ler_json('olt_onus_cache.json');
    $slots = (is_array($c) && isset($c['slots']) && is_array($c['slots'])) ? $c['slots'] : [];
    foreach ($slots as $arr) {
        if (!is_array($arr)) continue;
        foreach ($arr as $o) {
            if (!is_array($o)) continue;
            $k = mk_olt_sn((string)($o['serial'] ?? ''));
            if ($k === '') continue;
            $reg = mk_olt_registro($o);
            // Completa rx/tx pelo cache de sinal quando a linha da ONU não trouxe.
            $chaveSinal = trim((string)($o['fsp'] ?? '')) . '|' . trim((string)($o['ont_id'] ?? ($o['id'] ?? '')));
            if (isset($sinal[$chaveSinal]) && is_array($sinal[$chaveSinal])) {
                foreach (['rx' => 'rx_sinal', 'tx' => 'tx_sinal', 'rx_olt' => 'rx_olt'] as $de => $para) {
                    if (($reg[$para] ?? null) === null && !empty($sinal[$chaveSinal][$de])) {
                        $reg[$para] = trim((string)$sinal[$chaveSinal][$de]);
                    }
                }
            }
            $mapa[$k] = $reg;
        }
    }
    // 2) autorizações — completam/vencem onde tiverem valor
    if (function_exists('ws_olt_autorizacoes')) {
        foreach (ws_olt_autorizacoes() as $a) {
            $k = mk_olt_sn((string)($a['sn'] ?? ''));
            if ($k === '') continue;
            $novo = array_filter(mk_olt_registro($a), fn($v) => $v !== null && $v !== '');
            $mapa[$k] = array_merge($mapa[$k] ?? [], $novo);
        }
    }
    /* 3) SmartOLT — ZONA e MODO de TODAS as ONUs (renovado pelo cron da OLT a cada 10 min).
     * O cache da OLT só conhece a zona escrita na descrição e o modo das ONUs que alguém abriu na
     * tela; o SmartOLT tem os dois para o parque inteiro. Zona e modo: o SmartOLT vence. Sinal: só
     * completa o que o coletor da OLT não trouxe (o da OLT é mais recente). */
    $smart = function_exists('ws_olt_ler_json') ? ws_olt_ler_json('smartolt_map.json') : null;
    if (is_array($smart)) {
        foreach ($smart as $chave => $rec) {
            $chave = (string)$chave;
            if (!is_array($rec) || $chave === '__v' || strpos($chave, ':') !== false) continue;
            $k = mk_olt_sn($chave);
            $kh = mk_olt_sn_hex($chave);
            $alvo = ($kh !== '' && isset($mapa[$kh])) ? $kh : $k;
            $base = $mapa[$alvo] ?? [];
            $z = mb_strtoupper(trim((string)($rec['zona'] ?? '')), 'UTF-8');
            if ($z !== '') $base['zona'] = $z;
            $t = mk_olt_tipo($rec);
            if ($t !== '') $base['equipamento'] = ($t === 'ONT' ? 'ONT (Router)' : 'ONU (Bridge)');
            if (empty($base['vlan']) && (int)($rec['vlan'] ?? 0) > 0) $base['vlan'] = (int)$rec['vlan'];
            if (empty($base['rx_sinal']) && trim((string)($rec['sinal'] ?? '')) !== '')    $base['rx_sinal'] = trim((string)$rec['sinal']);
            if (empty($base['tx_sinal']) && trim((string)($rec['sinal_tx'] ?? '')) !== '') $base['tx_sinal'] = trim((string)$rec['sinal_tx']);
            if ($base) {
                $mapa[$alvo] = $base;
                if ($kh !== '' && $kh !== $alvo) $mapa[$kh] = $base;
            }
        }
    }
    return $mapa;
}

/** Dados da OLT de um serial (ou null). Tenta o valor cru e o normalizado. */
function mk_olt_dados(?string $serial): ?array {
    $k = mk_olt_sn((string)$serial);
    if ($k === '') return null;
    $m = mk_olt_mapa();
    if (isset($m[$k])) return $m[$k];
    $kh = mk_olt_sn_hex((string)$serial);          // cadastro em HWTC… e OLT em hexadecimal (ou o contrário)
    return ($kh !== '' && isset($m[$kh])) ? $m[$kh] : null;
}

/**
 * Completa um contrato com o que a OLT sabe. Devolve quantas colunas foram preenchidas.
 *
 * COALESCE/NULLIF garante o combinado: só grava onde está NULL ou vazio. Se o contrato já tem
 * zona vinda do backup, ela fica; se está em branco, entra a da OLT.
 */
function mk_olt_aplicar(PDO $db, int $contratoId, ?string $serial): int {
    if ($contratoId <= 0) return 0;
    $d = mk_olt_dados($serial);
    if (!$d) return 0;

    static $cols = null;
    if ($cols === null) {                          // quais dessas colunas existem neste banco
        $cols = [];
        foreach (['vlan', 'zona', 'placa_pon', 'pon', 'equipamento', 'equip_modelo', 'rx_sinal', 'tx_sinal', 'rx_olt'] as $c) {
            if (mk_col($db, 'ws_contrato', [$c])) $cols[] = $c;
        }
    }
    $sets = []; $args = [];
    foreach ($cols as $c) {
        if (($d[$c] ?? null) === null || $d[$c] === '') continue;
        $sets[] = ($c === 'vlan')
            ? "vlan = COALESCE(vlan, ?)"                       // INT: só se estiver NULL
            : "$c = COALESCE(NULLIF($c,''), ?)";               // texto: NULL ou vazio
        $args[] = $d[$c];
    }
    if (!$sets) return 0;
    $args[] = $contratoId;
    try {
        $db->prepare("UPDATE ws_contrato SET " . implode(', ', $sets) . " WHERE id = ?")->execute($args);
        /* Contadores por TIPO de dado, não só "mexi em N colunas": é o que a tela precisa para
           dizer "zona: 412, sinal: 388" em vez de um número que não prova nada. */
        foreach (['zona', 'vlan', 'rx_sinal', 'equipamento'] as $c) {
            if (($d[$c] ?? null) !== null && $d[$c] !== '') {
                $GLOBALS['ws_mig_olt'][$c] = ($GLOBALS['ws_mig_olt'][$c] ?? 0) + 1;
            }
        }
        return count($sets);
    } catch (Throwable $e) { return 0; }
}

/**
 * O login/senha identificam uma conexão IPoE (ID/serial da ONU) ou PPPoE (usuário e senha)?
 *
 * REGRA DO PROVEDOR: PPPoE tem usuário e senha — nome ou número curto, escolhidos por pessoa.
 * Se o que veio é um **ID** (o serial/ID da ONU), é obrigatoriamente IPoE. No MK-Auth o ID da
 * ONU costuma vir no campo da SENHA (só dígitos, 6+) ou no próprio LOGIN (alfanumérico de
 * 12 a 16, formato GPON: 4857544309d792ac).
 *
 * Esta função existe porque a regra estava escrita SOLTA dentro do import de titulares, e o
 * import de ADICIONAIS gravava 'pppoe' fixo no código — então adicional com ID de ONU entrava
 * como PPPoE e nunca autenticava como devia. Agora os dois caminhos usam exatamente o mesmo
 * critério.
 *
 * @param string $login     login/username do backup
 * @param string $senha     senha do backup (no IPoE do MK-Auth é aqui que vem o ID da ONU)
 * @param string $tipoBackup valor da coluna "tipo" do backup, quando existir ('ipoe'/'pppoe')
 */
function mk_eh_ipoe(string $login, string $senha = '', string $tipoBackup = ''): bool {
    $login = trim($login);
    $senha = trim($senha);

    // 1. O backup diz explicitamente.
    if (strtolower(trim($tipoBackup)) === 'ipoe') return true;

    // 2. Senha é um ID numérico da ONU (6 dígitos ou mais). PPPoE usa senha curta —
    //    "1056", "8429" — então o piso de 6 dígitos é o que separa os dois casos.
    if ($senha !== '' && preg_match('/^\d{6,}$/', $senha)) return true;

    // 3. O login É o serial da ONU. TEM QUE SER HEXADECIMAL — e é aqui que a primeira
    //    versão desta regra errou: ela aceitava [0-9A-Za-z]{12,16}, o que casa com nome de
    //    usuário comum de 12 a 16 letras ("cooperativalagoa", "lucianosilva",
    //    "monicatracun") e convertia PPPoE legítimo em IPoE.
    //    Serial de ONU é hex porque os 4 primeiros bytes são o fabricante em ASCII:
    //        485754432dc46fae -> 48 57 54 43 = "HWTC"  (Huawei)
    //        47504f4e00a37dd8 -> 47 50 4f 4e = "GPON"
    //        50524b5300d20027 -> 50 52 4b 53 = "PRKS"
    //    Exige ainda ao menos um dígito, para nunca casar com palavra formada só por
    //    letras que por acaso sejam todas hex (ex.: "acedebacedba").
    if (preg_match('/^[0-9a-fA-F]{12,16}$/', $login) && preg_match('/\d/', $login)) return true;

    // 4. Login puramente numérico e longo também é ID, não usuário PPPoE.
    if (preg_match('/^\d{8,}$/', $login)) return true;

    return false;
}

/** O ID/serial da ONU a usar, dado login e senha (o MK-Auth guarda ora num, ora noutro). */
function mk_id_onu(string $login, string $senha = ''): string {
    $senha = trim($senha);
    return $senha !== '' ? $senha : trim($login);
}
/** Nome normalizado para comparação: maiúsculo, sem acento, sem pontuação, espaço único.
 *  Serve para casar "Acme Telecom Ltda." com "ACME TELECOM LTDA". */
/**
 * =================================================================================================
 * REGISTRO DO QUE NÃO ENTROU — um arquivo, com nome, login e MOTIVO de cada descarte.
 * =================================================================================================
 * POR QUE ISTO EXISTE
 * A importação contava os descartes ("pulados: N", "fora do filtro: N") mas não guardava QUEM. E um
 * comentário no próprio código dizia que era de propósito: "o que ficou de fora nem entra na fila".
 *
 * O custo disso apareceu na prática: um cliente real, com contrato e pagando, não estava no sistema.
 * Para descobrir o motivo foram necessárias seis consultas ao banco, uma leitura do código e a
 * extração do backup original — e ainda assim por eliminação. Enquanto isso, a resposta ("a
 * situação dela estava fora do filtro escolhido no upload") era uma linha que o importador sabia e
 * jogou fora.
 *
 * Contador diz QUANTOS. Só o registro diz QUAL — e é "qual" que o operador precisa quando um
 * cliente específico não aparece.
 *
 * O arquivo é CSV com ponto e vírgula e BOM, para abrir direto no Excel: quem confere migração
 * confere em planilha, comparando com a lista do sistema antigo.
 *
 * É reescrito a cada importação (interessa o resultado da última) e tem teto de 20 mil linhas, para
 * um backup gigante não encher o disco.
 */
function mk_fora_registrar(string $motivo, string $nome, string $login, string $doc = '', string $situacao = '', string $cidade = ''): void {
    static $n = 0;
    if ($n >= 20000) return;
    $arq = WS_CACHE . '/importacao_fora.csv';
    if ($n === 0) {
        // Primeira linha da execução: recria o arquivo com o cabeçalho.
        @file_put_contents($arq, "\xEF\xBB\xBF" . "Motivo;Nome;Login;CPF/CNPJ;Situacao;Cidade\n");
        @chmod($arq, 0640);
    }
    $lp = function ($v) { return str_replace(["\r", "\n", ';'], [' ', ' ', ','], (string)$v); };
    @file_put_contents($arq, implode(';', array_map($lp, [$motivo, $nome, $login, $doc, $situacao, $cidade])) . "\n", FILE_APPEND);
    $n++;
}

/**
 * =================================================================================================
 * SUBSTITUIR A BASE — o backup sobe num banco de clientes ZERADO.
 * =================================================================================================
 * A regra, dita pelo dono do provedor e adotada aqui: BACKUP É PONTO DE RESTAURAÇÃO, NÃO MESCLAGEM.
 * Restaurar um backup é voltar a base para aquele instante — não é aproveitar o que já existia e
 * encaixar o resto por cima. Mesclando, as duas bases divergem um pouco a cada importação e nunca
 * mais fecham com o sistema de origem: foi exatamente o que aconteceu (774 aqui, 733 lá).
 *
 * O QUE ISTO APAGA — e é irreversível sem o backup que ele mesmo grava antes:
 *     ws_pagamento · ws_fatura · ws_contrato · ws_cliente
 *     e toda tabela que tenha cliente_id ou contrato_id (anexos, comodatos, chamados do cliente…)
 *
 * O QUE ISTO NÃO APAGA, de propósito, porque não vem do backup e perder isso quebraria o sistema:
 *     operadores e senhas · configurações · dados do provedor · bancos/PIX
 *     cidades, bairros, ramais, zonas · planos · conexão da OLT · modelos de documento
 *
 * ATENÇÃO, E ESTÁ ESCRITO AQUI PARA NÃO SER DESCOBERTO DEPOIS: cliente cadastrado DIRETO no
 * WellSystem (que nunca existiu no sistema de origem) é apagado junto, assim como fatura gerada e
 * pagamento recebido aqui. Isso não é defeito — é o significado de "restaurar". Quem precisa dos
 * dois mundos não deve usar esta opção.
 *
 * O BACKUP AUTOMÁTICO ANTES NÃO É OPCIONAL. Uma operação irreversível numa base financeira sem
 * cópia anterior é um acidente esperando acontecer; com a cópia, é uma decisão reversível.
 *
 * @return array ['ok'=>bool, 'backup'=>caminho, 'apagados'=>[tabela=>linhas], 'erro'=>string]
 */
function ws_importar_zerar_base(PDO $db, int $ramalId = 0): array {
    $res = ['ok' => false, 'backup' => '', 'apagados' => [], 'erro' => ''];
    /* $ramalId > 0: backup de UMA cidade. Apaga só os clientes deste ramal (e o que é deles) —
     * as outras cidades já importadas ficam intactas. 0 = a base inteira, como sempre foi. */
    $ramalId = max(0, $ramalId);

    /* 1) CÓPIA DE SEGURANÇA PRIMEIRO. Falhou a cópia, não apaga nada. */
    try {
        if (!function_exists('ws_backup_gravar')) require_once WS_DIR . '/backup_lib.php';
        $res['backup'] = ws_backup_gravar($db);
        if ($res['backup'] === '' || !is_file($res['backup'])) {
            $res['erro'] = 'Não consegui gravar o backup de segurança — nada foi apagado.';
            return $res;
        }
    } catch (Throwable $e) {
        $res['erro'] = 'Não consegui gravar o backup de segurança (' . $e->getMessage() . ') — nada foi apagado.';
        return $res;
    }

    /* 2) QUEM DEPENDE DE CLIENTE/CONTRATO É DESCOBERTO NO BANCO, não escrito à mão.
     *    Lista fixa envelhece: basta uma tabela nova com cliente_id para ficar lixo órfão para
     *    sempre. Perguntando ao catálogo, tabela nova entra sozinha. */
    $dependentes = [];
    try {
        $st = $db->query("SELECT DISTINCT table_name tn FROM information_schema.columns
                          WHERE table_schema = DATABASE()
                            AND column_name IN ('cliente_id','contrato_id')
                            AND table_name LIKE 'ws\\_%'");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $t = (string)($r['tn'] ?? $r['TABLE_NAME'] ?? '');
            if ($t !== '' && !in_array($t, ['ws_cliente', 'ws_contrato'], true)) $dependentes[] = $t;
        }
    } catch (Throwable $e) { /* sem catálogo, segue com as tabelas do núcleo */ }

    /* Ordem: filhos primeiro, pais depois. Com as FKs desligadas a ordem não quebraria, mas
       mantê-la certa faz a operação funcionar mesmo se o desligamento for negado. */
    $ordem = array_merge($dependentes, ['ws_pagamento', 'ws_fatura', 'ws_contrato', 'ws_cliente']);
    $ordem = array_values(array_unique($ordem));
    // Escopo de um ramal: pagamento é achado pela fatura, então sai ANTES dela (as FKs estão desligadas, sem cascata).
    if ($ramalId) $ordem = array_values(array_unique(array_merge(['ws_pagamento'], $ordem)));

    try {
        $db->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach ($ordem as $t) {
            try {
                $onde = $ramalId ? ws_importar_zerar_onde($db, $t, $ramalId) : '';
                if ($onde === null) continue;   // tabela sem vínculo com cliente: no escopo de um ramal, não mexe
                $n = (int)$db->query("SELECT COUNT(*) FROM `$t`" . $onde)->fetchColumn();
                if ($n > 0) { $db->exec("DELETE FROM `$t`" . $onde); $res['apagados'][$t] = $n; }
            } catch (Throwable $e) { /* tabela que não existe nesta instalação: ignora */ }
        }
        /* Numeração recomeça: a base restaurada fica igual a uma instalação nova com aquele
           backup, sem ids altos herdados do que foi apagado. */
        if (!$ramalId) foreach (['ws_cliente', 'ws_contrato', 'ws_fatura', 'ws_pagamento'] as $t) {
            try { $db->exec("ALTER TABLE `$t` AUTO_INCREMENT = 1"); } catch (Throwable $e) {}
        }
        $db->exec('SET FOREIGN_KEY_CHECKS=1');
        $res['ok'] = true;
    } catch (Throwable $e) {
        try { $db->exec('SET FOREIGN_KEY_CHECKS=1'); } catch (Throwable $e2) {}
        $res['erro'] = $e->getMessage();
    }
    return $res;
}

/** WHERE do "substituir a base" limitado a um ramal (null = tabela sem vínculo com cliente). */
function ws_importar_zerar_onde(PDO $db, string $t, int $ramalId): ?string {
    $r = (int)$ramalId;
    $cli = "SELECT id FROM ws_cliente WHERE ramal_id=$r";
    if ($t === 'ws_cliente')   return " WHERE ramal_id=$r";
    if ($t === 'ws_pagamento') return " WHERE fatura_id IN (SELECT f.id FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE c.ramal_id=$r)";
    static $cols = [];
    if (!isset($cols[$t])) {
        $cols[$t] = [];
        try {
            $st = $db->prepare("SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name IN ('cliente_id','contrato_id')");
            $st->execute([$t]); $cols[$t] = array_map('strtolower', $st->fetchAll(PDO::FETCH_COLUMN));
        } catch (Throwable $e) {}
    }
    if (in_array('cliente_id', $cols[$t], true))  return " WHERE cliente_id IN ($cli)";
    if (in_array('contrato_id', $cols[$t], true)) return " WHERE contrato_id IN (SELECT ct.id FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE c.ramal_id=$r)";
    return null;
}

/**
 * ÍNDICE DO BACKUP — a identidade de TODO registro que veio no arquivo, sem exceção.
 *
 * Isto responde, de forma definitiva, a pergunta que se repetia a cada migração: "a tela mostra
 * 774 clientes e o sistema antigo mostra 773 — QUEM está sobrando?".
 *
 * Sem o índice só dava para contar, e contagem não tem nome. Com ele, basta comparar: o cliente
 * do WellSystem cuja identidade não aparece aqui NÃO veio deste backup. Pode ser cadastro feito à
 * mão, sobra de uma importação anterior ou duplicata — mas deixa de ser mistério e passa a ser
 * uma lista com nome e número de ficha.
 *
 * GRAVA TODA LINHA DO ARQUIVO, inclusive as que serão descartadas depois (situação não marcada no
 * upload, duplicada, sem cidade). Isso é proposital e é o ponto todo: o critério é "existia no
 * backup", não "entrou no sistema". Registrar só quem entrou faria o cliente legitimamente
 * filtrado parecer sobra — e a lista acusaria inocente.
 *
 * Mesmo formato do importacao_fora.csv: ponto e vírgula, BOM, reescrito a cada importação.
 */
function mk_index_registrar(string $nome, string $login, string $doc, string $situacao = ''): void {
    static $n = 0;
    if ($n >= 200000) return;                 // teto de segurança para backup gigante
    $arq = WS_CACHE . '/importacao_index.csv';
    if ($n === 0) {
        @file_put_contents($arq, "\xEF\xBB\xBF" . "Nome;NomeNormalizado;Login;Documento;Situacao\n");
        @chmod($arq, 0640);
    }
    $lp = fn($v) => str_replace(["\r", "\n", ';'], [' ', ' ', ','], (string)$v);
    @file_put_contents($arq, implode(';', array_map($lp, [
        $nome, mk_norm_nome($nome), $login, preg_replace('/\D/', '', $doc), $situacao,
    ])) . "\n", FILE_APPEND);
    $n++;
}
function mk_norm_nome($s): string {
    $s = (string)$s;
    $s = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s) ?: $s;
    $s = preg_replace('/[^A-Za-z0-9 ]/', ' ', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return mb_strtoupper(trim($s), 'UTF-8');
}

/**
 * Quem é o PROVEDOR (o dono do sistema), para não importar o cadastro dele como cliente.
 * Junta duas fontes, porque nenhuma das duas existe sempre:
 *   1. cache/provedor.json — só existe se o provedor já foi configurado nesta instalação;
 *   2. sis_empresa do PRÓPRIO backup — é onde o MK-Auth guarda os dados da empresa, e vem
 *      junto com o arquivo importado, então funciona até numa instalação zerada.
 * Retorna ['cnpjs' => [...só dígitos...], 'nomes' => [...normalizados...]].
 */
function mk_provedor_identidade(PDO $imp): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cnpjs = []; $nomes = [];

    $pf = WS_CACHE . '/provedor.json';
    if (is_file($pf)) {
        $j = @json_decode((string)@file_get_contents($pf), true);
        if (is_array($j)) {
            if (!empty($j['cnpj']))     $cnpjs[] = preg_replace('/\D/', '', (string)$j['cnpj']);
            if (!empty($j['razao']))    $nomes[] = mk_norm_nome($j['razao']);
            if (!empty($j['fantasia'])) $nomes[] = mk_norm_nome($j['fantasia']);
        }
    }

    // sis_empresa do backup (nomes de coluna variam entre versões do MK-Auth).
    try {
        if (mk_tab($imp, 'sis_empresa')) {
            $cCnpj  = mk_col($imp, 'sis_empresa', ['cnpj', 'cnpj_cpf', 'cpf_cnpj', 'documento']);
            $cRazao = mk_col($imp, 'sis_empresa', ['razaosocial', 'razao_social', 'razao', 'nome']);
            $cFant  = mk_col($imp, 'sis_empresa', ['fantasia', 'nome_fantasia', 'nomefantasia']);
            foreach ($imp->query("SELECT * FROM sis_empresa") as $e) {
                if ($cCnpj  && !empty($e[$cCnpj]))  $cnpjs[] = preg_replace('/\D/', '', (string)$e[$cCnpj]);
                if ($cRazao && !empty($e[$cRazao])) $nomes[] = mk_norm_nome($e[$cRazao]);
                if ($cFant  && !empty($e[$cFant]))  $nomes[] = mk_norm_nome($e[$cFant]);
            }
        }
    } catch (Throwable $ex) { /* backup sem sis_empresa: segue só com o provedor.json */ }

    // sis_boleto do backup: o cedente do boleto É o provedor. Numa base MK-Auth esta é a fonte
    // mais confiável que existe — sis_empresa às vezes vem vazia, mas quem emite boleto tem a
    // conta preenchida. O cedente costuma vir "RAZAO SOCIAL - CNPJ: 00.000.000/0001-00".
    try {
        if (mk_tab($imp, 'sis_boleto')) {
            foreach ($imp->query("SELECT cedente, cpf_cnpj, nome FROM sis_boleto") as $b) {
                if (!empty($b['cpf_cnpj'])) $cnpjs[] = preg_replace('/\D/', '', (string)$b['cpf_cnpj']);
                $ced = (string)($b['cedente'] ?? '');
                if ($ced !== '') {
                    if (preg_match('/CNPJ\s*:?\s*([\d.\/\-]{14,})/i', $ced, $m)) $cnpjs[] = preg_replace('/\D/', '', $m[1]);
                    $nomes[] = mk_norm_nome(preg_replace('/\s*-\s*CNPJ.*$/i', '', $ced));
                }
                if (!empty($b['nome'])) $nomes[] = mk_norm_nome(preg_replace('/\s*-{2,}\s*/', ' ', (string)$b['nome']));
            }
        }
    } catch (Throwable $ex) { /* sem sis_boleto: segue com as outras fontes */ }

    // Nome muito curto vira falso positivo (casaria com meio mundo) — descarta.
    $nomes = array_values(array_unique(array_filter($nomes, fn($n) => strlen($n) >= 6)));
    $cnpjs = array_values(array_unique(array_filter($cnpjs, fn($c) => strlen($c) >= 11)));

    // NÚCLEO = as duas primeiras palavras do nome do provedor ("WELLNET TELECOM ME" -> "WELLNET
    // TELECOM"). É o que permite reconhecer o cadastro do provedor mesmo quando ele aparece com
    // sufixo diferente ("WELLNET TELECOM PROVEDOR"), sem depender de igualdade exata — e sem
    // recorrer ao CNPJ, que aqui é compartilhado por dezenas de clientes reais.
    // Palavras genéricas de razão social ficam de fora do núcleo: sozinhas casariam demais.
    $ignorar = ['LTDA','ME','EPP','EIRELI','SA','S A','MEI','COMERCIO','SERVICOS','TELECOM','PROVEDOR','INTERNET','BOLETOS'];
    $nucleos = [];
    foreach ($nomes as $n) {
        $palavras = preg_split('/\s+/', $n, -1, PREG_SPLIT_NO_EMPTY);
        if (count($palavras) < 2) { if (strlen($n) >= 8) $nucleos[] = $n; continue; }
        $nuc = $palavras[0] . ' ' . $palavras[1];
        // Núcleo curto demais, ou formado só por termo genérico, seria perigoso.
        if (strlen($nuc) < 8) continue;
        if (in_array($palavras[0], $ignorar, true)) continue;
        $nucleos[] = $nuc;
    }
    $nucleos = array_values(array_unique($nucleos));

    /* GUARDA OS CNPJs DO PROVEDOR PARA O RESTO DO SISTEMA.
     *
     * Esta função só consegue descobrir o CNPJ porque tem o BACKUP aberto (sis_empresa, cedente do
     * boleto). A tela de importação, na hora de salvar um registro da conferência, não tem mais o
     * backup — e antes consultava só o cache/provedor.json, que numa instalação nova está vazio.
     * Resultado: a importação aceitava o cliente cadastrado com o CNPJ da empresa e o salvamento
     * o mandava de volta para conferência. Gravando aqui, os dois lados passam a decidir igual.
     * Ver ws_import_provedor_cnpjs() no importar.php. */
    if ($cnpjs && defined('WS_CACHE')) {
        $arq = WS_CACHE . '/provedor_cnpjs.json';
        $ant = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
        $novo = array_values(array_unique(array_merge(is_array($ant) ? $ant : [], $cnpjs)));
        if ($novo !== $ant) { @file_put_contents($arq, json_encode($novo)); @chmod($arq, 0640); }
    }

    $cache = ['cnpjs' => $cnpjs, 'nomes' => $nomes, 'nucleos' => $nucleos];
    return $cache;
}
/** Velocidade MK-Auth ('10M','10240','1024k') → kbps. */
function mk_vel($v): int {
    $v = trim((string)$v); if ($v === '') return 0;
    if (preg_match('/([\d.]+)\s*([mkMK]?)/', $v, $m)) {
        $n = (float)$m[1]; $u = strtolower($m[2]);
        if ($u === 'm') return (int)round($n * 1024);
        if ($u === 'k') return (int)round($n);
        return $n < 1000 ? (int)round($n * 1024) : (int)round($n);
    }
    return 0;
}

/** Geocodifica uma cidade (nome, sem UF) pelo Nominatim/OpenStreetMap — MESMA fonte usada no
 *  botão "📍 Localizar automaticamente" do cadastro manual (Cadastros › Cidades). Usada aqui pra
 *  auto-preencher latitude/longitude de cidades criadas na migração. Nunca lança exceção: se a
 *  internet do servidor falhar ou a API não responder, devolve [null,null] e o campo fica
 *  editável na tela de Cidades — a migração nunca trava por causa disso. */
function ws_geocode_cidade(string $nomeCidade, string $uf = ''): array {
    try {
        $q = trim($nomeCidade . ($uf !== '' ? ", $uf" : '') . ', Brasil');
        // Recursos do sistema → Mapas: Google com chave primeiro; sem resposta, segue no OpenStreet.
        $rcM = function_exists('ws_recursos') ? ws_recursos() : [];
        if (($rcM['mapa_servidor'] ?? '') === 'google' && !empty($rcM['google_key'])) {
            $gb = @file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?region=br&address=' . rawurlencode($q) . '&key=' . rawurlencode($rcM['google_key']),
                                     false, stream_context_create(['http' => ['timeout' => 4]]));
            $gj = $gb ? json_decode($gb, true) : null;
            $gl = $gj['results'][0]['geometry']['location'] ?? null;
            if (is_array($gl) && isset($gl['lat'], $gl['lng'])) return [round((float)$gl['lat'], 7), round((float)$gl['lng'], 7)];
        }
        $url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' . rawurlencode($q);
        $ctx = stream_context_create(['http' => [
            'method' => 'GET', 'timeout' => 4,
            'header' => "User-Agent: WellSystem-ERP/1.0 (importador de migração)\r\nAccept-Language: pt-BR\r\n",
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false || $body === '') return [null, null];
        $j = json_decode($body, true);
        if (!is_array($j) || empty($j[0]['lat']) || empty($j[0]['lon'])) return [null, null];
        return [round((float)$j[0]['lat'], 7), round((float)$j[0]['lon'], 7)];
    } catch (Throwable $e) { return [null, null]; }
}

/** Classifica o equipamento pelo MODELO/serial vindo do backup: ONT (roteador óptico), ROUTER
 *  (roteador comum) ou ONU (bridge). Retorna '' quando não dá pra afirmar — e "não dá pra
 *  afirmar" é o caso mais comum num backup MK-Auth, que não guarda o modelo do CPE.
 *  Antes TODO equipamento migrado entrava como "ONU" bridge, o que deixava a lista de
 *  Cadastros › Equipamentos inteira errada e sem como separar ONT de ROUTER. */
function ws_equip_tipo_por_modelo(?string $modelo, ?string $serial = null): string {
    $t = mb_strtoupper(trim((string)$modelo), 'UTF-8');
    if ($t === '') $t = mb_strtoupper(trim((string)$serial), 'UTF-8');
    if ($t === '') return '';

    /* MODELOS GPON REAIS — é o que a OLT devolve, e é o que separa bridge de router.
     * Sem estas regras a classificação dependia das palavras "ONU"/"ONT"/"BRIDGE" aparecerem
     * escritas no texto, o que não acontece: a OLT informa "HG8546M", "EG8145V5", "F670L".
     * Por isso a lista de comodato ficava inteira sem tipo — o pedido "não puxou equipamento
     * bridge ou router".
     *
     * Huawei: HG8310M / HG8010 / HG8110 / HS8010 são SFU (bridge, sem WiFi).
     *         HG8245, HG8546M, HS8545M, EG8145 e afins são HGU (roteador com WiFi).
     * ZTE:    F601 / F612 / F401 são SFU; F660 / F670 / F680 são HGU.
     * O "M" final do HG8310M NÃO significa roteador — daí a checagem do bridge vir primeiro. */
    if (preg_match('/\b(HG80\d{2}|HG81\d{2}|HG83\d{2}|HS80\d{2}|EG80\d{2}|F[46]0\d|F412|OP\d{2}1[SB])\b/u', $t)) return 'ONU (Bridge)';
    if (preg_match('/\b(HG8[24-9]\d{2}|HS85\d{2}|EG81\d{2}|F6[6-8]\d|AX3\d|ZXHN)\b/u', $t))                    return 'ONT (Router)';

    // Palavras explícitas — valem para modelos escritos por extenso pelo operador.
    if (preg_match('/\b(ONT|HGU|GPON\s*ROUTER|WIFI|WI-FI|DUAL\s*BAND|AC\d{3,})\b/u', $t)) return 'ONT (Router)';
    if (preg_match('/\b(ROUTER|ROTEADOR|RB\d|HAP|ARCHER|TL-WR|TP-?LINK|INTELBRAS\s*W|MIKROTIK)\b/u', $t)) return 'Roteador';
    if (preg_match('/\b(ONU|BRIDGE|SFU)\b/u', $t)) return 'ONU (Bridge)';
    return '';   // sem informação suficiente: em branco pro operador classificar, nunca chutado
}

/** Marca o contrato recém-criado como EM COMODATO quando existe serial/ONU do backup.
 *
 *  O QUE VAI PRA ONDE (era o ponto errado antes):
 *   - O EQUIPAMENTO DO CLIENTE (serial, MAC, modelo, tipo) fica no CONTRATO — é dado da ficha
 *     do cliente, individual. Antes cada serial virava também uma linha em ws_equipamento,
 *     então "Cadastros › Equipamentos" virava uma cópia da lista de clientes.
 *   - Em "Cadastros › Equipamentos" entra só o MODELO, uma única vez. Modelos iguais são
 *     unificados; não repete.
 *   - O tipo NÃO é mais chutado como ONU/bridge: sem informação no backup, fica em branco
 *     pro operador classificar (ONT/ROUTER/ONU) em vez de nascer errado.
 *  Nunca lança exceção (equipamento é "extra": se falhar, o contrato já foi salvo). */
function ws_equipamento_registrar_comodato(PDO $db, int $contratoId, ?string $serial, ?string $mac = null, ?string $modelo = null): void {
    $serial = trim((string)$serial); if ($serial === '') return;
    $modelo = trim((string)$modelo);

    /* MODELO E TIPO VÊM DA OLT quando o backup não os tem — e o backup do MK-Auth NUNCA os tem:
     * ele guarda o serial da ONU e mais nada sobre o aparelho. Era esta a origem dos três
     * pendentes juntos: "não puxou equipamento bridge/router", "não puxou o equipamento em
     * comodato" e "modelo em comodato". Quem sabe o modelo é a OLT (o mesmo mapa que preenche
     * zona/VLAN/placa/PON), e ela é consultada aqui, no ÚNICO lugar que grava comodato — assim
     * titular e adicional recebem o mesmo tratamento sem duplicar regra. */
    if ($modelo === '') {
        $d = mk_olt_dados($serial);
        if ($d && !empty($d['equip_modelo'])) $modelo = trim((string)$d['equip_modelo']);
    }
    $tipo = ws_equip_tipo_por_modelo($modelo, $serial);
    try {
        // 1) Ficha do cliente (contrato): é aqui que mora o equipamento DAQUELE cliente.
        $db->prepare("UPDATE ws_contrato SET comodato=1, equip_serial=?,
                        equip_mac=COALESCE(NULLIF(?,''),equip_mac),
                        equip_modelo=COALESCE(NULLIF(?,''),equip_modelo),
                        equip_tipo=COALESCE(NULLIF(?,''),equip_tipo)
                      WHERE id=?")
           ->execute([mb_substr($serial, 0, 60), (string)$mac, $modelo, $tipo, $contratoId]);
        $GLOBALS['ws_mig_olt']['comodato'] = ($GLOBALS['ws_mig_olt']['comodato'] ?? 0) + 1;
        if ($modelo !== '') $GLOBALS['ws_mig_olt']['modelo'] = ($GLOBALS['ws_mig_olt']['modelo'] ?? 0) + 1;
        if ($tipo   !== '') $GLOBALS['ws_mig_olt']['tipo_equip'] = ($GLOBALS['ws_mig_olt']['tipo_equip'] ?? 0) + 1;

        // 2) Catálogo de modelos: uma linha por MODELO, sem repetir. Sem modelo no backup não
        //    há o que catalogar — não inventa registro.
        if ($modelo === '') return;
        $ex = $db->prepare("SELECT id FROM ws_equipamento WHERE UPPER(TRIM(modelo))=UPPER(TRIM(?)) LIMIT 1");
        $ex->execute([$modelo]);
        if (!$ex->fetchColumn()) {
            $db->prepare("INSERT INTO ws_equipamento (tipo,modelo,serial,mac,status,ativo) VALUES (?,?,NULL,NULL,'comodato',1)")
               ->execute([$tipo ?: 'ONU (Bridge)', $modelo]);
            $GLOBALS['ws_mig_criados']['equipamento'] = ($GLOBALS['ws_mig_criados']['equipamento'] ?? 0) + 1;
        }
    } catch (Throwable $e) { /* equipamento é extra — nunca trava a migração */ }
}

/** RAMAL DE DESTINO DO BACKUP (Migração → "Cidade / ramal deste backup").
 *  $GLOBALS['ws_import_ramal_id']:  null = como sempre foi (ramal em que o operador está, ou automático);
 *                                    0    = AUTOMÁTICO: cada cliente vai para o ramal da cidade dele
 *                                           (cidade e ramal são criados se não existirem);
 *                                    >0   = todo o backup entra NESTE ramal (backup de uma cidade só).
 *  Retorna ['id','nome','cidade'] ou null (automático). */
function mk_ramal_destino(): ?array {
    $esc = $GLOBALS['ws_import_ramal_id'] ?? null;
    if ($esc === null) return ws_ramal_atual();
    if ((int)$esc <= 0) return null;
    static $cache = [];
    if (!array_key_exists((int)$esc, $cache)) {
        $cache[(int)$esc] = null;
        try {
            $st = ws_db()->prepare("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.id=?");
            $st->execute([(int)$esc]); $cache[(int)$esc] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Throwable $e) {}
    }
    return $cache[(int)$esc];
}

/** Garante que a cidade tenha ao menos 1 RAMAL (filial) ativo — cria um padrão ("Matriz — NOME
 *  DA CIDADE") se ainda não existir nenhum. Antes disso o cliente importado ficava sem ramal_id
 *  (some do filtro por filial em Servidores/Clientes até alguém criar o ramal manualmente).
 *  Retorna o id do ramal (existente ou recém-criado), ou null se a cidade for inválida. */
function ws_ramal_garantir(PDO $db, int $cidadeId, string $nomeCidade): ?int {
    if ($cidadeId <= 0) return null;
    try {
        $r = $db->prepare("SELECT id FROM ws_ramal WHERE cidade_id=? AND ativo=1 ORDER BY id LIMIT 1");
        $r->execute([$cidadeId]);
        if ($rid = $r->fetchColumn()) return (int)$rid;
        $db->prepare("INSERT INTO ws_ramal (cidade_id, nome, ativo) VALUES (?, ?, 1)")
           ->execute([$cidadeId, 'Matriz — ' . mb_strtoupper(trim($nomeCidade), 'UTF-8')]);
        $GLOBALS['ws_mig_criados']['ramal'] = ($GLOBALS['ws_mig_criados']['ramal'] ?? 0) + 1;
        return (int)$db->lastInsertId();
    } catch (Throwable $e) { return null; }
}

/** Registra em cache/migracao_bairros_cidades_revisar.csv toda vez que o casamento foi por
 *  SEMELHANÇA (não exato) — ex.: "Cemtro" casou com "Centro" já cadastrado. O sistema não tem como
 *  saber sozinho qual das duas grafias é a certa (poderia ser o contrário: o cadastro antigo é que
 *  está errado), então a escolha de qual manter/renomear fica com quem conhece a operação — aqui só
 *  fica visível que aconteceu, sem que a importação pare ou pergunte nada. */
function ws_mig_log_fuzzy(string $tipo, string $novo, string $usado, int $distancia): void {
    try {
        $f = (defined('WS_CACHE') ? WS_CACHE : sys_get_temp_dir()) . '/migracao_bairros_cidades_revisar.csv';
        $novoArq = !is_file($f);
        $fp = @fopen($f, 'a');
        if (!$fp) return;
        if ($novoArq) fputcsv($fp, ['quando', 'tipo', 'valor_do_backup', 'ficou_registrado_como', 'distancia']);
        fputcsv($fp, [date('Y-m-d H:i:s'), $tipo, $novo, $usado, $distancia]);
        fclose($fp);
    } catch (Throwable $e) {}
}

/** Padroniza nome de cidade/bairro/zona (maiúscula, sem acento pra comparar, espaços normalizados)
 *  e, se não existir cadastrado, CRIA na hora — assim toda importação já alimenta os cadastros
 *  de Cidades/Bairros automaticamente, sem duplicar por causa de "Nazare da Mata" x "NAZARÉ DA MATA". */
function ws_padronizar_e_criar(PDO $db, string $tabela, string $valorBruto, ?int $cidadeId = null): ?string {
    $valorBruto = trim($valorBruto); if ($valorBruto === '') return null;
    /* $tira(): só pra COMPARAR (nunca pra gravar) — maiúscula, sem acento, sem hífen/pontuação e sem
     * as palavras de ligação (DA/DE/DO/DOS/DAS). Duas correções aqui:
     *   1. Palavra de ligação por SUBSTRING quebrava nome que só por acaso contém "DA"/"DE"/"DO" no
     *      meio — "CIDADE" virava "CIE", "PADRE" virava "PRE". Agora só remove como PALAVRA inteira
     *      (\b...\b), separada por espaço.
     *   2. Hífen/ponto/underscore agora viram espaço ANTES de comparar — sem isso "JUÁ-1" e "JUA1"
     *      ficavam como "JUA-1" x "JUA1" (strings diferentes) e dependiam só da tolerância do
     *      Levenshtein pra casar; agora "JUA 1" e "JUA1" (depois de tirar o espaço na comparação)
     *      são a MESMA string — casam sempre, não só quando a diferença for pequena o bastante. */
    $tira = function (string $s): string {
        $s = mb_strtoupper($s, 'UTF-8');
        $s = strtr($s, ['Á'=>'A','À'=>'A','Ã'=>'A','Â'=>'A','É'=>'E','Ê'=>'E','Í'=>'I','Ó'=>'O','Õ'=>'O','Ô'=>'O','Ú'=>'U','Ç'=>'C']);
        $s = preg_replace('/[\-_.\/]+/', ' ', $s);                 // hífen/ponto/underscore -> espaço
        $s = preg_replace('/\bD[\']?(A|E|O|AS|OS)\b/', '', $s);     // DA/DE/DO/DAS/DOS/D' só como palavra
        $s = preg_replace('/\s+/', '', $s);                         // ignora espaço na comparação final
        return $s;
    };
    $padrao = mb_strtoupper(preg_replace('/\s+/', ' ', $valorBruto), 'UTF-8');
    $semAcento = $tira($padrao);
    
    if ($tabela === 'ws_cidade') {
        $cidades = $db->query("SELECT nome FROM ws_cidade WHERE ativo=1")->fetchAll(PDO::FETCH_COLUMN);
        // 1. Exact match (accent/case insensitive)
        foreach ($cidades as $c) {
            if ($tira($c) === $semAcento) return $c;
        }
        // 2. Similarity match (Levenshtein)
        $bestMatch = null; $bestDist = 999;
        foreach ($cidades as $c) {
            $tc = $tira($c);
            $dist = levenshtein($semAcento, $tc);
            $maxAllowed = max(3, floor(strlen($tc) * 0.4));
            if ($dist <= $maxAllowed && $dist < $bestDist) {
                $bestDist = $dist; $bestMatch = $c;
            }
        }
        if ($bestMatch) { ws_mig_log_fuzzy('cidade', $padrao, $bestMatch, $bestDist); return $bestMatch; }
        // NINGUÉM parecido cadastrado ainda: CRIA a cidade agora, já padronizada — é o que o
        // comentário desta função sempre prometeu, mas faltava o INSERT de verdade.
        try {
            // Geocodifica sozinho (mesma fonte — Nominatim/OpenStreetMap — usada no botão
            // "Localizar automaticamente" do cadastro manual de cidades). Nunca trava a
            // migração se a internet/API falhar: fica NULL e continua 100% editável depois
            // em Cadastros › Cidades.
            [$lat, $lng] = ws_geocode_cidade($padrao);
            $db->prepare("INSERT INTO ws_cidade (nome, ativo, latitude, longitude) VALUES (?, 1, ?, ?)")->execute([$padrao, $lat, $lng]);
            $novaCidadeId = (int)$db->lastInsertId();
            $GLOBALS['ws_mig_criados']['cidade'] = ($GLOBALS['ws_mig_criados']['cidade'] ?? 0) + 1;
            // Já cria o RAMAL (filial) padrão desta cidade — sem isso o cliente ficava sem
            // ramal_id e sumia dos filtros por filial em Servidores/Clientes.
            ws_ramal_garantir($db, $novaCidadeId, $padrao);
            return $padrao;
        } catch (Throwable $e) { return null; }
    }
    
    if ($tabela === 'ws_bairro') {
        $sql = "SELECT nome FROM ws_bairro WHERE ativo=1" . ($cidadeId ? " AND (cidade_id=$cidadeId OR cidade_id IS NULL)" : "");
        $bairros = $db->query($sql)->fetchAll(PDO::FETCH_COLUMN);
        // 1. Exact match
        foreach ($bairros as $b) {
            if ($tira($b) === $semAcento) return $b;
        }
        // 2. Similarity
        $bestMatch = null; $bestDist = 999;
        foreach ($bairros as $b) {
            $tb = $tira($b);
            $dist = levenshtein($semAcento, $tb);
            $maxAllowed = max(3, floor(strlen($tb) * 0.4));
            if ($dist <= $maxAllowed && $dist < $bestDist) {
                $bestDist = $dist; $bestMatch = $b;
            }
        }
        if ($bestMatch) { ws_mig_log_fuzzy('bairro', $padrao, $bestMatch, $bestDist); return $bestMatch; }
        // Cria o bairro agora, já vinculado à cidade (quando conhecida).
        try {
            $db->prepare("INSERT INTO ws_bairro (nome, cidade_id, ativo) VALUES (?, ?, 1)")->execute([$padrao, $cidadeId]);
            $GLOBALS['ws_mig_criados']['bairro'] = ($GLOBALS['ws_mig_criados']['bairro'] ?? 0) + 1;
            return $padrao;
        } catch (Throwable $e) { return null; }
    }
    
    if ($tabela === 'ws_zona') {
        $zonas = [];
        try { $zonas = $db->query("SELECT nome FROM ws_zona WHERE ativo=1")->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
        // 1. Exact match
        foreach ($zonas as $z) {
            if ($tira($z) === $semAcento) return $z;
        }
        // 2. Similarity
        $bestMatch = null; $bestDist = 999;
        foreach ($zonas as $z) {
            $tz = $tira($z);
            $dist = levenshtein($semAcento, $tz);
            $maxAllowed = max(3, floor(strlen($tz) * 0.4));
            if ($dist <= $maxAllowed && $dist < $bestDist) {
                $bestDist = $dist; $bestMatch = $z;
            }
        }
        if ($bestMatch) return $bestMatch;
        // Cria a zona agora — mesma padronização, mesma tabela usada pelo contrato/OLT/SmartOLT.
        try {
            $db->prepare("INSERT INTO ws_zona (nome, ativo) VALUES (?, 1)")->execute([$padrao]);
            $GLOBALS['ws_mig_criados']['zona'] = ($GLOBALS['ws_mig_criados']['zona'] ?? 0) + 1;
            return $padrao;
        } catch (Throwable $e) { return null; }
    }
    
    return null;
}

/** Nome reduzido automático (nome+sobrenome; se repetir, junta nomes do meio; senão +número). */
function mk_nome_resumido(PDO $db, string $nome, array &$usados): string {
    $slug = function ($s) { $t = @iconv('UTF-8', 'ASCII//TRANSLIT', $s); if ($t !== false) $s = $t; return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $s)); };
    $parts = array_values(array_filter(preg_split('/\s+/', trim($nome))));
    $cands = [];
    if (count($parts) >= 2) {
        $cands[] = $slug($parts[0] . end($parts));
        $acc = $parts[0]; for ($i = 1; $i < count($parts); $i++) { $acc .= $parts[$i]; $cands[] = $slug($acc); }
    } else $cands[] = $slug($parts[0] ?? 'cliente');
    $existe = function ($nr) use ($db, &$usados) {
        if (isset($usados[$nr])) return true;
        $st = $db->prepare("SELECT 1 FROM ws_cliente WHERE nome_resumido=? LIMIT 1"); $st->execute([$nr]); return (bool)$st->fetchColumn();
    };
    foreach ($cands as $c) { if ($c !== '' && !$existe($c)) { $usados[$c] = 1; return substr($c, 0, 60); } }
    $base = substr($cands[0] ?: 'cliente', 0, 55); $i = 2;
    while ($existe($base . $i)) $i++;
    $usados[$base . $i] = 1; return $base . $i;
}

/** Confere se um "nome resumido" já trazido do backup está DE ACORDO com o critério do sistema
 *  (minúsculo, só letras/números, sem espaço/acento, e começando com o slug do primeiro nome —
 *  o mesmo padrão que mk_nome_resumido() gera). Se já está conforme, NÃO mexe (mantém como veio,
 *  respeita apelido que a pessoa já tinha configurado). Se não está, troca pelo gerado automático. */
function mk_nome_resumido_conforme(string $nr, string $nomeCompleto): bool {
    $nr = trim($nr); if ($nr === '') return false;
    if ($nr !== strtolower($nr)) return false; // tem maiúscula -> não é o padrão
    if (preg_match('/[^a-z0-9]/', $nr)) return false; // tem espaço/acento/símbolo -> não é o padrão
    $slug = function ($s) { $t = @iconv('UTF-8', 'ASCII//TRANSLIT', $s); if ($t !== false) $s = $t; return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $s)); };
    $primeiro = $slug(explode(' ', trim($nomeCompleto))[0] ?? '');
    if ($primeiro === '') return true; // sem nome pra comparar, aceita o que veio
    return strpos($nr, $primeiro) === 0; // tem que começar com o slug do primeiro nome
}

/** Usa o nome_resumido que veio do backup SE já estiver conforme; senão gera de novo do zero
 *  (mesma regra de sempre: nome+sobrenome, ou junta nomes do meio se repetir). */
function mk_nome_resumido_ajustar(PDO $db, string $nrBackup, string $nomeCompleto, array &$usados): string {
    if ($nrBackup !== '' && mk_nome_resumido_conforme($nrBackup, $nomeCompleto)) {
        $chave = strtolower($nrBackup); $usados[$chave] = 1; return substr($nrBackup, 0, 60);
    }
    return mk_nome_resumido($db, $nomeCompleto, $usados);
}

/**
 * Prepara os arquivos .sql a importar a partir do backup enviado.
 * @return array lista de caminhos .sql (sis_plano, sis_cliente, ...) OU 1 arquivo (dump inteiro).
 * @throws RuntimeException
 */
function mk_preparar(string $arquivo, string $nome): array {
    if (!is_file($arquivo)) throw new RuntimeException('Arquivo não encontrado.');
    $magic = (string)@file_get_contents($arquivo, false, null, 0, 3);

    // .maz = tar do MK-Auth (compressão pode variar: bzip2 "clássico", mas versões mais novas do
    // MK-Auth também geram gzip/xz mantendo a extensão .maz). Detecta pelos magic bytes e deixa o
    // tar auto-detectar quando não reconhecer, em vez de forçar -j (bzip2) sempre.
    $ehMaz = substr($nome, -4) === '.maz';
    $ehBz  = substr($magic, 0, 3) === "BZh";
    $magic4 = (string)@file_get_contents($arquivo, false, null, 0, 6);
    $ehGz  = substr($magic4, 0, 2) === "\x1f\x8b";
    $ehXz  = substr($magic4, 0, 6) === "\xFD7zXZ\x00";
    if ($ehBz || $ehGz || $ehXz || $ehMaz) {
        $tar = trim((string)@shell_exec('command -v tar 2>/dev/null'));
        if ($tar === '') throw new RuntimeException('Para ler .maz é preciso o utilitário "tar" no servidor (padrão no Linux/MK-Auth).');
        $dir = WS_CACHE . '/mkimp_' . bin2hex(random_bytes(4));
        if (!ws_dir_realmente_gravavel($dir)) {
            throw new RuntimeException('Não consegui criar a pasta temporária de extração (' . $dir . ')' . (function_exists('ws_diag_permissao') ? ws_diag_permissao(WS_CACHE) : '') . '.');
        }
        // Flag de compressão pelo conteúdo real do arquivo (não pela extensão) — se não reconhecer
        // nenhum magic conhecido, usa "-x" puro e deixa o próprio tar auto-detectar o formato.
        $flag = $ehBz ? 'j' : ($ehGz ? 'z' : ($ehXz ? 'J' : ''));
        // extrai só as tabelas que importam (leve); wildcard sem "/" fixo pra casar em QUALQUER
        // profundidade de subpasta, já que a estrutura interna do backup pode mudar de versão pra versão.
        // sis_lanc  = títulos/boletos (é o que faltava: a migração nunca trouxe boleto nenhum).
        // sis_boleto = conta bancária que imprime o boleto (cedente/carteira/convênio).
        /* TABELAS EXTRAÍDAS DO .maz.
         * Esta lista era a explicação de "não veio a configuração dos concentradores / NAS / API".
         * Não era o importador que ignorava: os arquivos nunca chegavam a ser extraídos, então
         * mk_tab() respondia "tabela não existe" e o import passava batido, calado.
         *   nas / sis_nas   -> concentradores (IP, segredo, apelido) — vira o cadastro de NAS
         *   sis_config      -> parâmetros gerais e chaves de API do MK-Auth
         *   sis_configmsg   -> SMTP / WhatsApp
         *   sis_empresa     -> identidade do provedor (também confirma o CNPJ do provedor)
         *   sis_ramal/cidade/bairro -> filiais e locais já cadastrados
         *   radacct         -> histórico de conexão do cliente (o "relatório de conexão")
         * Continua sendo extração SELETIVA: nada de descompactar o backup inteiro à toa. */
        $tabelas = ['sis_plano.sql', 'sis_cliente.sql', 'sis_adicional.sql', 'sis_lanc.sql', 'sis_boleto.sql',
                    'nas.sql', 'sis_nas.sql', 'sis_config.sql', 'sis_configmsg.sql', 'sis_empresa.sql',
                    'sis_ramal.sql', 'sis_cidade.sql', 'sis_bairro.sql', 'radacct.sql'];
        $curingas = implode(' ', array_map(fn($t) => "'*$t'", $tabelas));
        $cmd = sprintf('%s -x%sf %s -C %s --wildcards %s 2>/dev/null',
            escapeshellcmd($tar ?: 'tar'), $flag, escapeshellarg($arquivo), escapeshellarg($dir), $curingas);
        @shell_exec($cmd);
        $achados = mk_glob_rec($dir, $tabelas);
        // Se a extração seletiva não achou nada (ex.: flag de compressão errada), tenta de novo
        // extraindo o arquivo INTEIRO com auto-detecção do tar antes de desistir.
        if (!$achados) {
            @shell_exec(sprintf('%s -xaf %s -C %s 2>/dev/null', escapeshellcmd($tar ?: 'tar'), escapeshellarg($arquivo), escapeshellarg($dir)));
            $achados = mk_glob_rec($dir, $tabelas);
        }
        if (!$achados) throw new RuntimeException('Não encontrei sis_cliente.sql/sis_plano.sql dentro do .maz. Verifique se o arquivo não está corrompido ou se a estrutura do backup mudou de versão do MK-Auth.');
        // Ordem de carga: plano -> cliente -> adicional -> lanc/boleto (os títulos dependem do
        // cliente já existir, e o restore roda na ordem desta lista).
        // As tabelas de configuração são pequenas e não dependem de ninguém: entram primeiro.
        // radacct fica por último — é a maior de todas e só alimenta o histórico de conexão.
        $peso = function (string $f): int {
            foreach (['config' => -3, 'empresa' => -3, 'nas' => -2, 'cidade' => -2, 'bairro' => -2, 'ramal' => -2,
                      'plano' => 0, 'cliente' => 1, 'adicional' => 2, 'boleto' => 3, 'lanc' => 4,
                      'radacct' => 8] as $k => $p)
                if (strpos($f, $k) !== false) return $p;
            return 9;
        };
        usort($achados, fn($a, $b) => $peso($a) <=> $peso($b));
        return ['files' => $achados, 'dir' => $dir];
    }

    // .gz
    if (substr($magic, 0, 2) === "\x1f\x8b" || substr($nome, -3) === '.gz') {
        $sql = @gzdecode((string)file_get_contents($arquivo));
        if ($sql === false) throw new RuntimeException('Falha ao descompactar o .gz.');
        $f = WS_CACHE . '/mkimp_' . bin2hex(random_bytes(4)) . '.sql';
        file_put_contents($f, $sql);
        return ['files' => [$f], 'dir' => null, 'tmpfile' => $f];
    }

    // .sql puro
    return ['files' => [$arquivo], 'dir' => null];
}

/** Busca recursiva simples por nomes de arquivo. */
function mk_glob_rec(string $dir, array $nomes): array {
    if (!is_dir($dir)) return []; // pasta pode não existir (falha de mkdir/permissão) — evita fatal do RecursiveDirectoryIterator
    $out = [];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) { if (in_array($f->getFilename(), $nomes, true)) $out[] = $f->getPathname(); }
    return $out;
}

/**
 * Importa o backup e mapeia para ws_*. @return array resumo.
 */
/**
 * @param array $statusFiltro Situações a importar ('ativo','bloqueado','confianca','cancelado').
 *                           Vazio = todas. Serve para separar o upload por situação.
 */
function ws_importar_mkauth(string $arquivo, string $nome, array $statusFiltro = [], array $boletoStatus = ['aberto','vencido','pago'], int $boletoMeses = 12): array {
    $prep = mk_preparar($arquivo, $nome);
    /* NOME DERIVADO DO BANCO PRINCIPAL, e não fixo em "wellsystem_import".
     * Duas razões. A primeira é que o banco principal pode se chamar outra coisa (o .env deixa
     * escolher), e um nome fixo criaria um banco órfão, sem relação com a instalação. A segunda é
     * permissão: no Docker o usuário do sistema nasce com direito APENAS sobre o banco principal, e
     * a liberação dos bancos auxiliares é feita por padrão — "<banco>\_%" — na primeira subida do
     * MariaDB. Derivando o nome, o banco de importação cai dentro desse padrão automaticamente.
     * O mesmo vale para o banco do ambiente demo, que já era derivado (ws_demo_dbname). */
    $c = ws_db_config(); $tmpDb = $c['dbname'] . '_import';

    /* MYSQLI EM MODO "DEVOLVE FALSE", NÃO "LANÇA EXCEÇÃO".
     * A partir do PHP 8.1 o mysqli lança exceção a cada erro. Todo o restaurador abaixo foi
     * escrito para o comportamento anterior: ele TESTA o retorno de cada comando, anota o erro
     * daquela tabela e SEGUE para a próxima — é o que permite importar um backup com uma tabela
     * problemática em vez de perder tudo. Com exceção, a primeira falha derruba a importação
     * inteira e a tela mostra só a mensagem crua do banco ("Unknown option 'compression'"),
     * sem dizer em que tabela nem quanto já tinha entrado.
     * Desligar aqui devolve o comportamento que o código espera. O tratamento de erro não some —
     * ele passa a ser o que já existia: por tabela, visível no resumo da importação. */
    $reportAnterior = mysqli_report(MYSQLI_REPORT_OFF);

    $m = @mysqli_connect($c['host'], $c['user'], $c['pass'], '', (int)$c['porta']);
    if (!$m) { mysqli_report($reportAnterior); throw new RuntimeException('Sem conexão MySQL: ' . mysqli_connect_error()); }
    mysqli_query($m, "DROP DATABASE IF EXISTS `$tmpDb`");

    /* ERRO DE PERMISSÃO EXPLICADO NA HORA.
     * Sem esta verificação, o CREATE falhava calado e o erro só aparecia mais adiante como
     * "Access denied ... to database '<banco>_import'" — que parece problema do arquivo de backup,
     * quando na verdade é o banco recusando criar. Dizer o que fazer, aqui, economiza a caçada. */
    if (!mysqli_query($m, "CREATE DATABASE `$tmpDb` CHARACTER SET utf8mb4")) {
        $err = mysqli_error($m);
        if (stripos($err, 'denied') !== false) {
            throw new RuntimeException(
                "O usuário do banco não tem permissão para criar o banco temporário `$tmpDb`, "
                . "usado para restaurar o backup antes de virar cadastro.\n\n"
                . "Libere uma vez, como root do MySQL:\n"
                . "    GRANT ALL PRIVILEGES ON `" . str_replace('_', '\\_', $c['dbname']) . "\\_%`.* "
                . "TO '{$c['user']}'@'%'; FLUSH PRIVILEGES;\n\n"
                . "(Instalações novas em Docker já sobem com essa liberação feita.)\n\n"
                . "Mensagem do banco: $err"
            );
        }
        throw new RuntimeException("Não consegui criar o banco temporário `$tmpDb`: $err");
    }
    mysqli_select_db($m, $tmpDb);
    mysqli_query($m, "SET FOREIGN_KEY_CHECKS=0");
    mysqli_query($m, "SET SESSION innodb_strict_mode=0");
    /* RESTAURAÇÃO DOS DUMPS — a etapa que falhava CALADA.
     * Antes era um mysqli_multi_query() por arquivo, com o retorno ignorado. Em dump grande isso
     * quebra: sis_lanc desta base tem dezenas de milhares de INSERTs e passa de max_allowed_packet,
     * então o multi_query volta false, o código seguia em frente e a tabela ficava VAZIA ou nem
     * era criada. Lá na frente o importador dizia "o backup não tem títulos" — e o backup tinha.
     * Foi exatamente o "boletos: não veio nada, absolutamente nada".
     *
     * Agora: cada arquivo é executado em LOTES (o multi_query recebe pedaços, não o dump inteiro),
     * todo erro é registrado, e no fim conferimos quantas linhas cada tabela realmente ganhou. */
    $res_restore = [];
    foreach ($prep['files'] as $f) {
        $tab  = preg_replace('/\.sql$/i', '', basename($f));
        $erro = '';
        $fh = @fopen($f, 'r');
        if (!$fh) { $res_restore[$tab] = ['linhas' => null, 'erro' => 'não consegui abrir o arquivo']; continue; }

        $enviar = function (string $s) use ($m, &$erro) {
            $s = trim($s); if ($s === '') return;
            if (!mysqli_multi_query($m, $s)) { if ($erro === '') $erro = mysqli_error($m); return; }
            do { if ($r = mysqli_store_result($m)) mysqli_free_result($r); }
            while (mysqli_more_results($m) && mysqli_next_result($m));
            if ($erro === '' && mysqli_errno($m)) $erro = mysqli_error($m);
        };

        /* LEITURA EM FLUXO, LINHA A LINHA — nunca o arquivo inteiro na memória.
         * radacct (histórico de conexão) passa fácil de centenas de MB; um file_get_contents ali
         * mata o PHP por memória antes de qualquer INSERT. Assim o consumo é do tamanho do lote,
         * não do tamanho do backup.
         * O mysqldump sempre fecha o comando no fim da linha, então "linha terminada em ;" é um
         * corte seguro — não é preciso um parser de SQL. */
        $lote = '';
        while (($ln = fgets($fh)) !== false) {
            // sis_cliente tem ~140 colunas → ROW_FORMAT=DYNAMIC evita "Row size too large".
            // A condição pega as duas formas em que as opções da tabela aparecem num dump: a linha
            // com ENGINE, e a linha que apenas FECHA o CREATE TABLE e já traz opções (") ... = ..."),
            // que é como alguns servidores geram. Fora desses dois casos nada é tocado.
            if (stripos($ln, 'ENGINE') !== false || preg_match('/^\s*\)\s*[^;]*=/', $ln)) {
                /* OPÇÕES DE TABELA QUE O MARIADB NÃO CONHECE.
                 * Backup gerado num MySQL 5.7/8 traz COMPRESSION='...' e ENCRYPTION='...' no fim do
                 * CREATE TABLE. O MariaDB recusa o comando inteiro com "Unknown option
                 * 'compression'" — a tabela não é criada, e lá na frente o importador diz que o
                 * backup "não tem clientes", quando o que houve foi o CREATE ser rejeitado.
                 * São opções de ARMAZENAMENTO: removê-las não muda um dado sequer do que é
                 * importado, muda só como aquele servidor guardava os bytes em disco.
                 * A limpeza acontece só nesta linha — a das opções da tabela, que é a que tem
                 * ENGINE. Assim um INSERT cujo TEXTO contenha a palavra não é tocado. */
                $ln = preg_replace('/\s*(COMPRESSION|ENCRYPTION)\s*=\s*(\'[^\']*\'|"[^"]*"|\w+)/i', '', $ln);
                $ln = preg_replace('/ENGINE\s*=\s*InnoDB\b(?![^;]*ROW_FORMAT)/i', 'ENGINE=InnoDB ROW_FORMAT=DYNAMIC', $ln);
            }
            $lote .= $ln;
            // Só corta em fim de comando; e só envia quando o lote já valeu a viagem (~512 KB).
            if (strlen($lote) > 512 * 1024 && preg_match('/;\s*$/', rtrim($ln, "\r\n"))) {
                $enviar($lote); $lote = '';
            }
        }
        fclose($fh);
        if (trim($lote) !== '') $enviar($lote);
        while (mysqli_more_results($m)) mysqli_next_result($m);

        // Confere o resultado real: tabela criada? com quantas linhas?
        $n = null;
        if ($q = @mysqli_query($m, "SELECT COUNT(*) n FROM `" . str_replace('`', '', $tab) . "`")) {
            $row = mysqli_fetch_assoc($q); $n = (int)($row['n'] ?? 0); mysqli_free_result($q);
        }
        $res_restore[$tab] = ['linhas' => $n, 'erro' => $erro];
    }
    mysqli_close($m);
    mysqli_report($reportAnterior);   // devolve o modo de erro que o resto do sistema usa

    $imp = new PDO("mysql:host={$c['host']};port={$c['porta']};dbname=$tmpDb;charset=utf8mb4", $c['user'], $c['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $db = ws_db();
    $res = ['planos' => 0, 'clientes' => 0, 'contratos' => 0, 'pulados' => 0, 'filtrados' => 0, 'duplicados' => []];
    // O que cada dump do backup realmente virou dentro do banco temporário (tabela => linhas/erro).
    // É a prova de que o arquivo chegou inteiro — e o primeiro lugar a olhar quando algo "não veio".
    $res['restore']  = $res_restore;
    $res['arquivos'] = array_map('basename', (array)$prep['files']);
    $GLOBALS['ws_mig_olt'] = [];   // contadores por tipo de dado trazido da OLT/backup
    $statusFiltro = array_values(array_intersect($statusFiltro, ['ativo','bloqueado','confianca','cancelado']));

    // ---- PLANOS (sis_plano) ----
    // Conta (banco) padrão que vai imprimir os boletos/PIX dos clientes importados (1º banco ativo).
    $bancoPadraoId = null; try { $bancoPadraoId = (int)$db->query("SELECT id FROM ws_banco WHERE ativo=1 ORDER BY id LIMIT 1")->fetchColumn() ?: null; } catch (Throwable $e) {}
    $mapaPlano = [];
    if (mk_tab($imp, 'sis_plano')) {
        $cN = mk_col($imp, 'sis_plano', ['nome']); $cV = mk_col($imp, 'sis_plano', ['valor']);
        $cD = mk_col($imp, 'sis_plano', ['veldown', 'maxdown', 'download']);
        $cU = mk_col($imp, 'sis_plano', ['velup', 'maxup', 'upload']);
        foreach ($imp->query("SELECT * FROM sis_plano") as $p) {
            $nome = trim((string)($p[$cN] ?? '')); if ($nome === '') continue;
            $e = $db->prepare("SELECT id FROM ws_plano WHERE nome=?"); $e->execute([$nome]);
            if ($pid = $e->fetchColumn()) { $mapaPlano[mb_strtolower($nome)] = (int)$pid; continue; }
            $db->prepare("INSERT INTO ws_plano (nome,down_kbps,up_kbps,valor,ativo) VALUES (?,?,?,?,1)")
               ->execute([$nome, mk_vel($p[$cD] ?? 0), mk_vel($p[$cU] ?? 0), (float)str_replace(',', '.', (string)($p[$cV] ?? 0))]);
            $mapaPlano[mb_strtolower($nome)] = (int)$db->lastInsertId(); $res['planos']++;
        }
    }

    // ---- CLIENTES + CONTRATOS (sis_cliente) ----
    // MK-Auth costuma ter dados "sujos" (campos maiores que a coluna) → trunca no tamanho certo.
    $cut = fn($v, $n) => ($v === null || $v === '') ? null : mb_substr((string)$v, 0, $n);
    if (mk_tab($imp, 'sis_cliente')) {
        $col = fn($cands) => mk_col($imp, 'sis_cliente', $cands);
        $cNome=$col(['nome']); $cResumo=$col(['resumo','nome_resumido','apelido']); $cDoc=$col(['cpf_cnpj','cpf','cnpj']); $cEmail=$col(['email']);
        $cCel=$col(['celular','zap']); $cFone=$col(['fone','telefone']); $cCep=$col(['cep']);
        $cLograd=$col(['endereco','logradouro']); $cNum=$col(['numero']); $cCompl=$col(['complemento']);
        $cBairro=$col(['bairro']); $cCidade=$col(['cidade']); $cUf=$col(['estado','uf']);
        $cLat=$col(['lat','latitude']); $cLng=$col(['lng','longitude']); $cCoord=$col(['coordenadas']);
        $cLogin=$col(['login']); $cSenha=$col(['senha']); $cPlano=$col(['plano']); $cVenc=$col(['venc']);
        $cSn=$col(['onu_ont','mac_serial']); $cBloq=$col(['bloqueado']); $cAtivo=$col(['cli_ativado']);
        $cTipo=$col(['tipo','conexao','tipo_conexao','tipo_login']);   // pppoe/ipoe no backup, se existir
        $cDesat=$col(['data_desativacao']);   // cliente cancelado/desativado no MK-Auth
        // Desbloqueio em confiança do MK-Auth: flag 'sim' em observacao + data-limite em rem_obs.
        $cObsFlag=$col(['observacao']); $cRemObs=$col(['rem_obs']);
        $cZona=$col(['zona','pop','olt','nap','caixa']);   // zona/POP/OLT do MK-Auth (padroniza + cria em ws_zona)
        // Datas e observações do MK-Auth — coletadas e autopreenchidas no cadastro WellSystem.
        $cCad=$col(['cli_cadastro','data_cadastro','cadastro','datacadastro','cli_datacadastro','dtcadastro']);
        $cAtivData=$col(['cli_ativado_data','data_ativacao','data_ativado','ativacao','dtativacao','cli_dtativado']);
        /* NOTAS DO CLIENTE (item "não puxou as notas do cliente").
         * Cuidado com o nome 'observacao': no MK-Auth ele NÃO é a anotação — é a FLAG do
         * desbloqueio em confiança ('sim'/'nao'), com a data em rem_obs. Escolhê-lo gravava a
         * palavra "sim" no campo de notas de todo mundo e deixava a anotação verdadeira para
         * trás. Por isso 'observacao' só é aceito quando NÃO existe rem_obs (base sem o recurso
         * de confiança), e mesmo assim o valor é filtrado abaixo. */
        $cObs = $col(['obs','observacoes','anotacao','anotacoes','notas','nota','descricao','info','historico']);
        if (!$cObs && !$cRemObs) $cObs = $col(['observacao']);
        /* DATA DE NASCIMENTO (25/09/2026): não era importada, e a Central do Assinante (portal.php) pede CPF + data de
           nascimento — todo importado ficava sem conseguir entrar. Aceita AAAA-MM-DD, DD/MM/AAAA e DD-MM-AAAA. */
        $cNasc = $col(['nascimento','data_nascimento','dt_nascimento','datanasc','nasc']);
        $nascIso = function ($v): ?string {
            $v = trim((string)$v);
            if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $v, $m) && $m[1] > 1900 && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) return "$m[1]-$m[2]-$m[3]";
            if (preg_match('#^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})#', $v, $m) && $m[3] > 1900 && checkdate((int)$m[2], (int)$m[1], (int)$m[3])) return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
            return null;
        };
        /* Coleta as notas COMPLEMENTARES de todas as colunas de texto livre que a base tiver.
         * Versões diferentes do MK-Auth guardam a anotação com nomes diferentes; pegar só uma
         * significa perder a das outras — e o operador não tem como saber que perdeu. */
        $cObsExtra = [];
        foreach (['obs','observacoes','anotacao','anotacoes','notas','nota','descricao','info','historico','obs_cliente','obs2'] as $cand) {
            $cc = $col([$cand]);
            if ($cc && $cc !== $cObs && !in_array($cc, $cObsExtra, true)) $cObsExtra[] = $cc;
        }

        $usadosNR = [];
        /* MEMÓRIA DESTA EXECUÇÃO — o segundo buraco por onde passou duplicata.
         *
         * Todas as verificações de duplicidade consultam ws_cliente, ou seja, enxergam só o que
         * JÁ ESTAVA SALVO antes desta importação começar. Quando o próprio backup traz a mesma
         * pessoa duas vezes (dois cadastros dela no sistema antigo), as duas linhas passam: na
         * hora em que cada uma é conferida, a outra ainda não existe no banco.
         *
         * Esta lista guarda quem já foi aceito NESTA execução, e fecha essa porta. */
        $jaNesteArquivo = [];
        foreach ($imp->query("SELECT * FROM sis_cliente") as $r) {
            // Autocorreção de acentuação corrompida (mojibake) em TODOS os campos de texto da linha —
            // limpeza GENÉRICA (qualquer coluna string), já deixa limpo pra exibir e pra gravar.
            foreach ($r as $kk => $vv) if (is_string($vv) && $vv !== '') $r[$kk] = ws_fix_mojibake($vv);
            $nome = trim((string)($r[$cNome] ?? ''));
            // SEM NOME nao ha o que cadastrar — e o unico descarte que sobrou, alem de nome+documento
            // iguais. Contado a parte para o resumo poder dizer QUANTOS e POR QUE.
            if ($nome === '') { $res['pulados']++; $res['sem_nome'] = ($res['sem_nome'] ?? 0) + 1;
                mk_fora_registrar('Registro sem nome no backup — nao ha o que cadastrar', '(sem nome)', ($cLogin ? trim((string)($r[$cLogin] ?? '')) : ''));
                continue; }
            $nr = mk_nome_resumido_ajustar($db, $cResumo ? trim((string)$r[$cResumo]) : '', $nome, $usadosNR);
            $doc = $cDoc ? preg_replace('/\D/', '', (string)$r[$cDoc]) : '';

            /* SEM CPF/CNPJ: entra com o CNPJ DO PROVEDOR. Regra do operador, e ela tem lógica.
             *
             * No MK-Auth é prática corrente cadastrar com o CNPJ da empresa quem não tinha CPF na
             * hora da instalação — dezenas de clientes desta base estão assim. Deixar o campo vazio
             * criava dois problemas: a ficha nasce incompleta (e boleto registrado e NFS-e exigem
             * documento), e o cliente sem documento E sem login não tinha por onde ser comparado
             * numa reimportação, então duplicava sempre.
             *
             * Preencher com o CNPJ do provedor não confunde nada, porque esse documento já é
             * EXPRESSAMENTE isento da regra de duplicidade logo abaixo (`!$ehCnpjProvedor`): vários
             * clientes com ele não são tratados como o mesmo cliente. O operador corrige o
             * documento de cada um quando tiver o dado — e enquanto não tiver, o cadastro funciona.
             */
            if ($doc === '') {
                $identProvDoc = mk_provedor_identidade($imp);
                if (!empty($identProvDoc['cnpjs'][0])) {
                    $doc = (string)$identProvDoc['cnpjs'][0];
                    $res['doc_do_provedor'] = ($res['doc_do_provedor'] ?? 0) + 1;
                }
            }
            $login = $cLogin ? trim((string)$r[$cLogin]) : '';
            // Registro completo (para o operador editar/corrigir e salvar na tela de importação).
            $gv = fn($c) => $c ? trim((string)($r[$c] ?? '')) : '';
            // Status (regra MK-Auth): CANCELADO se desativado (data_desativacao preenchida OU
            // cli_ativado='nao'); senão EM CONFIANÇA se o desbloqueio de confiança do MK-Auth
            // (observacao='sim' + rem_obs com data futura) ainda está valendo; senão BLOQUEADO
            // se bloqueado='sim'; senão ATIVO. (Não existe "inativo" no MK-Auth.)
            // A confiança não era detectada aqui: esses clientes entravam como "bloqueado" e
            // não dava pra separar o upload por situação.
            $desat = ($cDesat && !empty($r[$cDesat]) && !preg_match('/^0000|^0$|^$/', (string)$r[$cDesat]))
                     || ($cAtivo && strtolower((string)$r[$cAtivo]) === 'nao');
            $emConf = false;
            if ($cObsFlag && $cRemObs) {
                $flag = strtolower(trim((string)($r[$cObsFlag] ?? '')));
                $ate  = trim((string)($r[$cRemObs] ?? ''));
                $emConf = ($flag === 'sim' && preg_match('/^\d{4}-\d{2}-\d{2}/', $ate)
                           && strtotime(substr($ate, 0, 10) . ' 23:59:59') > time());
            }
            $confAte = null;
            if ($emConf) $confAte = substr(trim((string)$r[$cRemObs]), 0, 10) . ' 23:59:59';
            if ($desat) $status = 'cancelado';
            elseif ($emConf) $status = 'confianca';
            elseif ($cBloq && strtolower((string)$r[$cBloq]) === 'sim') $status = 'bloqueado';
            else $status = 'ativo';

            /* "confianca" NAO e' um status de banco — e' um bloqueado com prazo.
             *
             * ws_cliente.status e' ENUM('ativo','inativo','bloqueado','cancelado') e ws_contrato.status
             * e' ENUM('ativo','suspenso','bloqueado','cancelado'): nenhum dos dois tem 'confianca'.
             * Gravar essa palavra ali fazia o INSERT do cliente falhar (modo estrito) ou entrar com o
             * campo vazio — era por isso que cliente em confianca NAO subia na migracao, e por isso
             * que a contagem fechava com um a menos.
             *
             * No WellSystem a confianca e' representada por ws_contrato.confianca_ate (a data-limite),
             * exatamente como o desbloqueio feito pelo painel: o cliente continua BLOQUEADO na lista e
             * o prazo e' que o libera. Entao $status segue valendo 'confianca' para o filtro de
             * situacoes da tela, e $statusBanco e' o que vai para o banco. */
            $statusBanco = ($status === 'confianca') ? 'bloqueado' : $status;

            // SEPARAR O UPLOAD POR SITUAÇÃO: quando o operador escolhe quais situações importar,
            // o que ficou de fora nem entra na fila — não vira pendente nem infla contador.
            /* ÍNDICE: registra que esta pessoa EXISTIA no backup — antes de qualquer filtro.
             * Tem de vir aqui em cima: logo abaixo o filtro de situação já descarta linhas, e
             * quem for descartado continua tendo existido no arquivo. */
            mk_index_registrar($nome, $login, $doc, $status);

            if ($statusFiltro && !in_array($status, $statusFiltro, true)) {
                $res['filtrados']++;
                /* REGISTRA QUEM ficou fora, e não só quantos.
                 * Este era o descarte mais invisível de todos: o comentário acima dizia que ele
                 * "nem entra na fila", de propósito. O efeito prático foi um cliente real, com
                 * contrato e pagando, ausente do sistema — e a única forma de descobrir o motivo
                 * foi extrair o backup original e comparar campo a campo.
                 * Agora o motivo fica escrito em cache/importacao_fora.csv na hora. */
                mk_fora_registrar('Fora do filtro de situação escolhido no upload', $nome, $login,
                    $doc, $status, ($cCidade ? (string)($r[$cCidade] ?? '') : ''));
                continue;
            }

            // Registro completo (para o operador editar/corrigir e salvar na tela de importação).
            $gv = fn($c) => $c ? trim((string)($r[$c] ?? '')) : '';
            // Datas do backup (cadastro/ativação), normalizadas — autopreenchidas no cadastro.
            $mkData = function($c) use ($r) { $v = $c ? trim((string)($r[$c] ?? '')) : ''; return (preg_match('/^\d{4}-\d{2}-\d{2}/', $v) && strpos($v,'0000')!==0) ? substr($v,0,10) : ''; };
            $dataCad = $mkData($cCad); $dataAtiv = $mkData($cAtivData); $dataDesat = $mkData($cDesat);
            $uid = md5($nome . $doc . $login . microtime());
            // coordenadas: lat/lng próprios OU campo "coordenadas" = "lat,lng" (mesma lógica do
            // caminho direto abaixo) — ANTES ficava de fora do registro pendente e se perdia
            // se o cadastro caísse na fila de correção.
            $recLat = $cLat ? ($r[$cLat] ?: '') : ''; $recLng = $cLng ? ($r[$cLng] ?: '') : '';
            if (($recLat === '' || $recLng === '') && $cCoord && !empty($r[$cCoord]) && strpos((string)$r[$cCoord], ',') !== false) {
                [$rla, $rln] = array_map('trim', explode(',', (string)$r[$cCoord], 2)); if ($rla && $rln) { $recLat = $rla; $recLng = $rln; }
            }
            /* NOTA DO CLIENTE — junta as colunas de texto livre da base, descarta o que é flag
             * ('sim'/'nao'/'0'/'1') e não repete o mesmo texto duas vezes. Uma coluna só nunca
             * dava conta: a anotação real muda de nome entre versões do MK-Auth. */
            $notas = [];
            foreach (array_merge([$cObs], $cObsExtra) as $colNota) {
                if (!$colNota) continue;
                $v = trim((string)($r[$colNota] ?? ''));
                if ($v === '') continue;
                if (in_array(mb_strtolower($v), ['sim','nao','não','s','n','0','1'], true)) continue;
                $v = ws_fix_mojibake($v);
                if (!in_array($v, $notas, true)) $notas[] = $v;
            }
            $obsCliente = implode("\n", $notas);
            if ($obsCliente !== '') $GLOBALS['ws_mig_olt']['notas'] = ($GLOBALS['ws_mig_olt']['notas'] ?? 0) + 1;

            $rec = [
                '_uid' => $uid,
                'nome' => $nome, 'nome_resumido' => $nr, 'cpf_cnpj' => $cDoc ? (string)$r[$cDoc] : '',
                'email' => $gv($cEmail), 'celular' => $gv($cCel), 'telefone' => $gv($cFone),
                'cep' => $gv($cCep), 'logradouro' => $gv($cLograd), 'numero' => $gv($cNum),
                'complemento' => $gv($cCompl), 'bairro' => $gv($cBairro), 'cidade' => $gv($cCidade), 'uf' => $gv($cUf),
                'latitude' => is_numeric($recLat) ? $recLat : '', 'longitude' => is_numeric($recLng) ? $recLng : '',
                'login' => $login, 'senha' => $gv($cSenha), 'plano' => $gv($cPlano),
                'venc' => $cVenc ? (int)preg_replace('/\D/', '', (string)$r[$cVenc]) : 10,
                'status' => $status,
                'data_cadastro' => $dataCad, 'data_ativacao' => $dataAtiv, 'data_desativacao' => $dataDesat, 'obs' => $obsCliente,
                'equip_serial' => $gv($cSn),
            ];

            // ---- CADASTRO DO PRÓPRIO PROVEDOR ----------------------------------------------
            // O critério é o NOME. O CNPJ sozinho NÃO serve: neste provedor (e é prática comum)
            // dezenas de clientes reais estão cadastrados com o CNPJ da empresa, porque na hora
            // do cadastro o cliente não tinha CPF. Uma versão anterior desta regra usou "mesmo
            // CNPJ basta" e marcou 35 registros, dos quais 34 eram clientes de verdade.
            // Então: bate pelo NÚCLEO do nome do provedor (as duas primeiras palavras da razão
            // social / do cedente do boleto). "WELLNET TELECOM PROVEDOR" casa com o núcleo
            // "WELLNET TELECOM"; "MANOEL JOAQUIM DA SILVA" não casa com nada.
            // O CNPJ entra só como REFORÇO na mensagem, nunca como gatilho sozinho.
            $identProv = mk_provedor_identidade($imp);
            $nomeNorm  = mk_norm_nome($nome);
            $ehCnpjProvedor = ($doc !== '' && in_array($doc, $identProv['cnpjs'], true));

            $ehNomeProvedor = false;
            foreach ($identProv['nucleos'] as $nuc) {
                if ($nuc === '' || $nomeNorm === '') continue;
                // Nome do registro COMEÇA pelo núcleo do provedor (ou é exatamente ele).
                if ($nomeNorm === $nuc || strpos($nomeNorm, $nuc . ' ') === 0) { $ehNomeProvedor = true; break; }
            }
            /* O CADASTRO DO PROVEDOR É IMPORTADO COMO QUALQUER OUTRO.
             *
             * Antes ele era PULADO: a ideia era evitar "um cliente a mais", tratando o registro da
             * própria empresa como cadastro interno do sistema antigo. Só que no MK-Auth o provedor
             * costuma ser assinante de verdade — tem conexão, login e contrato como qualquer
             * cliente. Pulando, a migração terminava com um cliente A MENOS, e justamente o que o
             * operador procurava quando conferia a contagem contra o sistema antigo.
             *
             * A detecção continua existindo, mas mudou de papel: em vez de barrar, ela apenas
             * CONTA, para o resumo poder dizer que aquele registro foi reconhecido e importado.
             * Decidir o que fazer com ele é do operador, que conhece a própria operação — não de
             * uma regra adivinhando pelo nome.
             *
             * (A isenção de CNPJ continua valendo logo abaixo: clientes cadastrados com o CNPJ da
             * empresa — prática comum para quem não tem CPF — não são tratados como duplicados.) */
            if ($ehNomeProvedor) $res['provedor_importado'] = ($res['provedor_importado'] ?? 0) + 1;

            /* Esta pessoa já entrou AGORA, nesta mesma importação? */
            $identRun = ($doc !== '' && !$ehCnpjProvedor)
                      ? 'doc:' . $doc . '|' . mk_norm_nome($nome)
                      : 'nome:' . mk_norm_nome($nome);
            if (mk_norm_nome($nome) !== '' && isset($jaNesteArquivo[$identRun])) {
                $res['pulados']++;
                mk_fora_registrar('A mesma pessoa já foi trazida por outra linha DESTE backup — evita cliente duplicado',
                    $nome, $login, $doc, $status, ($cCidade ? (string)($r[$cCidade] ?? '') : ''));
                continue;
            }

            if ($doc !== '' && !$ehCnpjProvedor) {
                /* MESMO CPF/CNPJ: o NOME é quem decide, igual à regra de salvar.
                 *
                 * Antes, todo documento repetido ia para a conferência. Só que a tela de salvar
                 * (ws_import_salvar_registro, no importar.php) já seguia outra regra, mais certa:
                 *   · mesmo documento e MESMO nome  -> é o mesmo cliente: unifica, não duplica;
                 *   · mesmo documento e nome DIFERENTE -> são pessoas distintas: salva normal.
                 * Documento repetido com nome diferente é corriqueiro — filho no CPF do pai,
                 * adicional no CNPJ da empresa, ponto extra no mesmo documento. A importação
                 * mandava todos esses para a fila, e o operador tinha de confirmar um a um aquilo
                 * que a própria tela de salvar aceitaria sem perguntar.
                 *
                 * Agora os dois lados decidem igual. Vai para conferência só o que é de fato
                 * ambíguo — mesmo documento E mesmo nome —, que é o caso em que importar cegamente
                 * criaria um cliente duplicado. */
                /* SEM "LIMIT 1" — e este era um buraco por onde passou cliente duplicado.
                 *
                 * A consulta pegava UM cadastro daquele documento (o de menor id) e comparava só o
                 * nome dele. Mas documento repetido com nome diferente é permitido de propósito
                 * (filho no CPF do pai, ponto extra no CNPJ da empresa). Então, quando o mesmo CPF
                 * já tinha DOIS cadastros e o de menor id era o do filho, o titular — que é
                 * exatamente quem casaria pelo nome — nunca era olhado, e entrava de novo.
                 *
                 * Agora compara com TODOS os cadastros daquele documento. Basta um casar. */
                /* PREFERE O CADASTRO ATIVO ENTRE OS QUE CASAM PELO NOME.
                 *
                 * Um documento pode ter mais de um cadastro com o MESMO nome: quando um adicional é
                 * promovido a titular ao cancelar o titular anterior, o WellSystem passa a ter um
                 * cadastro CANCELADO e outro ATIVO com o nome igual (o do adicional promovido). Antes,
                 * o "ORDER BY id" pegava o de menor id — normalmente o cancelado, por ser o mais
                 * antigo — e a importação unificava com a ficha errada: o cliente ativo no mk-auth
                 * entrava aqui como "duplicado" da ficha cancelada, e a ficha ativa de verdade nunca
                 * recebia o contrato. Isso também explica contagens diferentes entre os dois sistemas
                 * (mk-auth mostrando "ativo" para quem a WellSystem tem como cancelado).
                 * Agora, entre os cadastros que casam pelo nome, o ATIVO (status <> 'cancelado') tem
                 * prioridade; só cai no cancelado se não houver nenhum ativo com aquele nome. */
                $e = $db->prepare("SELECT id,nome,status FROM ws_cliente
                                   WHERE REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/',''),' ','')=?
                                   ORDER BY id");
                $e->execute([$doc]);
                $ex = null; $exCancelado = null;
                foreach ($e->fetchAll(PDO::FETCH_ASSOC) as $candDup) {
                    if (mk_norm_nome((string)$candDup['nome']) !== mk_norm_nome($nome)) continue;
                    if ((string)$candDup['status'] !== 'cancelado') { $ex = $candDup; break; }
                    if ($exCancelado === null) $exCancelado = $candDup;
                }
                if (!$ex) $ex = $exCancelado;
                if ($ex) {
                    $res['pulados']++;
                    // No arquivo SEMPRE; na fila da tela, até o teto de 500. Passando do teto, o
                    // registro continuaria existindo no CSV — nenhum descarte fica sem rastro.
                    mk_fora_registrar('Mesmo CPF/CNPJ e mesmo nome da ficha #' . (int)$ex['id'] . ' — é o mesmo cliente',
                        $nome, $login, $doc, $status, ($cCidade ? (string)($r[$cCidade] ?? '') : ''));
                    if (count($res['duplicados']) < 500) {
                        $res['duplicados'][] = ['uid' => $uid, 'nome' => $nome, 'login' => $login,
                            'motivo' => 'Mesmo CPF/CNPJ e mesmo nome de um cadastro já existente — provavelmente o mesmo cliente.',
                            'ficha' => (int)$ex['id'], 'rec' => $rec];
                    }
                    continue;
                }
            }

            /* LOGIN REPETIDO — verificação INDEPENDENTE da do documento.
             * Isto era um "elseif" da checagem acima, e portanto só rodava em quem NÃO tinha
             * documento. Enquanto todo documento repetido era barrado antes, o defeito não
             * aparecia. Ao passar a aceitar "mesmo documento, nome diferente" (que é o certo —
             * filho no CPF do pai, adicional no CNPJ da empresa), esses registros seguiram adiante
             * sem nunca conferir o login, e a importação morria no índice único do banco:
             * "Duplicate entry '<login>' for key 'login_pppoe'".
             * Documento e login são chaves diferentes, com donos diferentes: cada uma precisa da
             * sua verificação. */
            /* AS TRÊS IDENTIDADES, e não só o login_pppoe.
             *
             * Esta verificação olhava apenas `login_pppoe`. Num parque PPPoE puro, funcionava. Num
             * parque com IPoE — que é a regra, não a exceção — o cliente IPoE tem a identidade em
             * `login_ipoe` (e o ID da ONU em `ont_id`), e nunca era encontrado aqui. Reimportar o
             * mesmo backup criava um cliente NOVO para cada IPoE, silenciosamente: o total de
             * clientes subia sem ninguém entender de onde, e os dois cadastros do mesmo assinante
             * passavam a disputar a mesma conexão.
             *
             * Identidade é identidade, em qualquer uma das três colunas. */
            /* LOGIN JÁ EXISTENTE: o CLIENTE entra; só o login não é repetido.
             *
             * Descartar o registro inteiro aqui perdia uma PESSOA por causa de um campo. E note que
             * chegar até este ponto já significa que NÃO é o mesmo cliente: a verificação de
             * documento+nome, acima, barrou esse caso. Login igual com nome e documento diferentes
             * é conflito de dado no sistema de origem — dois cadastros apontando para a mesma
             * conexão —, e o jeito de resolver é importar os dois e deixar o operador decidir, não
             * escolher um e apagar o outro em silêncio.
             *
             * O login fica VAZIO neste cadastro (o índice único do banco não aceitaria o repetido) e
             * o motivo vai para a fila de revisão junto do link da ficha que já tem aquele login. */
            /* MAS ANTES: É A MESMA PESSOA?  — o buraco que inflava a contagem.
             *
             * O comentário acima afirmava que "chegar até este ponto já significa que NÃO é o
             * mesmo cliente, porque a verificação de documento+nome barrou esse caso". A
             * afirmação está ERRADA em dois casos, e foi ela que deixou passar cliente duplicado:
             *
             *   · a verificação de documento+nome só roda quando há documento de verdade
             *     (if ($doc !== '' && !$ehCnpjProvedor)). Quem veio sem CPF, ou com o CNPJ do
             *     provedor, nunca passou por ela;
             *   · e ela exige o nome IGUAL. "JOSE DA SILVA" e "JOSE DA SILVA (LOT. X)" são a
             *     mesma pessoa com o mesmo documento, e eram tratados como duas.
             *
             * Nos dois casos o registro caía aqui, o login era esvaziado e nascia um cliente NOVO
             * sem login — a mesma pessoa, duas vezes. O MK-Auth conta por login e enxerga uma; o
             * WellSystem passava a mostrar duas. É a origem de "774 aqui e 773 lá".
             *
             * Agora o dono do login é consultado por inteiro. Se for a mesma pessoa — mesmo
             * documento OU mesmo nome —, este registro é OUTRO CONTRATO dela, não outro cliente:
             * não se cria ficha nova. Login igual é a mesma conexão; com documento ou nome
             * batendo junto, não há dúvida razoável.
             *
             * Nada some em silêncio: o motivo vai para cache/importacao_fora.csv e aparece na
             * tela "O que ficou de fora na importação", com nome e número da ficha. */
            $loginConflito = '';
            if ($login !== '') {
                /* Mesmo cuidado do bloco de documento acima: se o login aparece em mais de um
                 * cliente (titular cancelado + adicional promovido que herdou a conexão), o dono
                 * "de verdade" é o cadastro ATIVO, não o de menor id. */
                $e = $db->prepare("SELECT ct.cliente_id, c.nome, c.cpf_cnpj, c.status
                                   FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                                   WHERE ct.login_pppoe=? OR ct.login_ipoe=? OR ct.ont_id=?
                                   ORDER BY (c.status='cancelado') ASC, ct.id LIMIT 1");
                $e->execute([$login, $login, $login]);
                $donoLogin = $e->fetch(PDO::FETCH_ASSOC);
                if ($donoLogin) {
                    $dupCid  = (int)$donoLogin['cliente_id'];
                    $docDono = preg_replace('/\D/', '', (string)$donoLogin['cpf_cnpj']);

                    // O documento do dono só identifica se NÃO for o CNPJ do provedor (vários o usam).
                    $donoEhCnpjProv = ($docDono !== '' && in_array($docDono, $identProv['cnpjs'], true));
                    $mesmoDoc  = ($doc !== '' && !$ehCnpjProvedor && !$donoEhCnpjProv && $docDono === $doc);
                    $mesmoNome = (mk_norm_nome((string)$donoLogin['nome']) === mk_norm_nome($nome));

                    if ($mesmoDoc || $mesmoNome) {
                        $res['pulados']++;
                        mk_fora_registrar(
                            'O login "' . $login . '" já é da ficha #' . $dupCid . ', que é a MESMA pessoa ('
                            . ($mesmoDoc ? 'mesmo CPF/CNPJ' : 'mesmo nome') . ') — criar outra ficha seria cliente duplicado',
                            $nome, $login, $doc, $status, ($cCidade ? (string)($r[$cCidade] ?? '') : ''));
                        continue;                   // não cria cliente: é contrato da ficha que já existe
                    }

                    // Pessoa DIFERENTE com o mesmo login: conflito real do sistema de origem.
                    $loginConflito = $login;
                    $login = '';                    // não cria contrato com login repetido
                    $res['login_conflito'] = ($res['login_conflito'] ?? 0) + 1;
                    if (count($res['duplicados']) < 2000) {
                        $res['duplicados'][] = ['uid' => $uid, 'nome' => $nome, 'login' => $loginConflito,
                            'motivo' => 'IMPORTADO SEM O LOGIN: "' . $loginConflito . '" já pertence a outra ficha. Confira qual dos dois é o dono e ajuste a conexão.',
                            'ficha' => $dupCid, 'rec' => $rec, 'importado' => 1];
                    }
                }
            }

            /* SEM DOCUMENTO E SEM LOGIN: última rede, pelo NOME.
             *
             * Um cadastro sem CPF/CNPJ e sem login não é pego por nenhuma das duas verificações
             * acima — e passa. Toda vez. Reimportar o mesmo backup criava outro, e outro: é assim
             * que a contagem de clientes cresce a cada migração sem ninguém ter cadastrado nada.
             *
             * A comparação usa o nome normalizado (a mesma função que a tela de salvar usa), e é
             * restrita ao RAMAL quando há um selecionado — homônimo em cidades diferentes é
             * plausível e não deve ser barrado. Com nome, documento e login todos vazios não há o
             * que comparar, e aí o registro segue: é melhor um cadastro a mais do que descartar em
             * silêncio um cliente que existe. */
            /* A condição inclui o CNPJ DO PROVEDOR, e não só o documento vazio.
             *
             * Desde que o cadastro sem CPF passou a entrar com o CNPJ do provedor, o campo nunca
             * mais fica vazio — e esse documento é EXPRESSAMENTE isento da regra de duplicidade
             * (vários clientes o compartilham de propósito). Ou seja: sem esta linha, quem entrou
             * com o CNPJ do provedor e não tem login voltaria a duplicar a cada reimportação, e o
             * remédio da regra nova teria criado o problema que ela vinha resolver.
             *
             * Aqui, "documento que não identifica ninguém" e "documento vazio" valem o mesmo. */
            if (($doc === '' || $ehCnpjProvedor) && $login === '') {
                $nn = mk_norm_nome($nome);
                if ($nn !== '') {
                    /* O ramal vem de ws_ramal_atual(), e NÃO de $ramalId.
                     *
                     * $ramalId só é calculado mais abaixo, depois desta verificação — aqui ele
                     * ainda guardaria o valor da volta ANTERIOR do laço, e o filtro compararia o
                     * cliente novo com os cadastros do ramal do cliente passado. Um erro que só
                     * apareceria em base com mais de uma cidade, e como duplicata inexplicável.
                     * ws_ramal_atual() é o ramal em que o operador está importando, que é
                     * exatamente o escopo que esta comparação quer. */
                    $ramalAtualDedup = mk_ramal_destino();   // ramal escolhido para o backup (ou o da sessão)
                    $ramalIdDedup = $ramalAtualDedup ? (int)$ramalAtualDedup['id'] : 0;
                    $sqlN = "SELECT id, nome FROM ws_cliente WHERE 1=1";
                    $parN = [];
                    if ($ramalIdDedup) { $sqlN .= " AND ramal_id = ?"; $parN[] = $ramalIdDedup; }
                    $eN = $db->prepare($sqlN);
                    $eN->execute($parN);
                    foreach ($eN->fetchAll(PDO::FETCH_ASSOC) as $cand) {
                        if (mk_norm_nome((string)$cand['nome']) !== $nn) continue;
                        $res['pulados']++;
                        mk_fora_registrar('Mesmo nome da ficha #' . (int)$cand['id'] . ' e sem CPF/CNPJ nem login para diferenciar',
                            $nome, '', $doc, $status, ($cCidade ? (string)($r[$cCidade] ?? '') : ''));
                        if (count($res['duplicados']) < 500) {
                            $res['duplicados'][] = ['uid' => $uid, 'nome' => $nome, 'login' => '',
                                'motivo' => 'Mesmo nome de um cadastro já existente, e sem CPF/CNPJ nem login para diferenciar.',
                                'ficha' => (int)$cand['id'], 'rec' => $rec];
                        }
                        continue 2;   // pula o cliente inteiro, não só este candidato
                    }
                }
            }

            // Passou por todas as verificações: fica registrado para as próximas linhas do arquivo.
            if (mk_norm_nome($nome) !== '') $jaNesteArquivo[$identRun] = true;

            // coordenadas: lat/lng próprios OU campo "coordenadas" = "lat,lng"
            $lat = $cLat ? ($r[$cLat] ?: null) : null; $lng = $cLng ? ($r[$cLng] ?: null) : null;
            if ((!$lat || !$lng) && $cCoord && !empty($r[$cCoord]) && strpos($r[$cCoord], ',') !== false) {
                [$la, $ln] = array_map('trim', explode(',', $r[$cCoord], 2)); if ($la && $ln) { $lat = $la; $lng = $ln; }
            }

            // Cidade padronizada (corrige acento/grafia p/ casar com o cadastro) + RAMAL automático da cidade.
            $ramalLogado = mk_ramal_destino();   // escolhido no upload; sem escolha = automático pela cidade
            if ($ramalLogado) {
                $ramalId = $ramalLogado['id'];
                $cidadeNome = $ramalLogado['cidade'];
                $cidadeId = (int)$db->query("SELECT cidade_id FROM ws_ramal WHERE id=" . (int)$ramalId)->fetchColumn() ?: null;
            } else {
                $cidadeNome = $cCidade ? ws_padronizar_e_criar($db, 'ws_cidade', (string)$r[$cCidade]) : null;
                $cidadeId = null; $ramalId = null;
                if ($cidadeNome) {
                    $cst=$db->prepare("SELECT id FROM ws_cidade WHERE nome=? LIMIT 1"); $cst->execute([$cidadeNome]); $cidadeId=((int)$cst->fetchColumn()) ?: null;
                    // Garante o ramal (cria "Matriz — CIDADE" se a cidade ainda não tiver nenhum ramal ativo).
                    if ($cidadeId) $ramalId = ws_ramal_garantir($db, $cidadeId, $cidadeNome);
                }
            }

            /* CIDADE QUE NÃO CASOU COM O CADASTRO OFICIAL: o cliente ENTRA. Não é mais descartado.
             *
             * Isto DESCARTAVA o cliente, e era a explicação de "cliente que existe no MK-Auth e não
             * aparece no WellSystem". O caso real: um cadastro cujo campo de cidade traz um
             * loteamento, um distrito ou uma abreviação que não bate com nenhuma cidade cadastrada.
             * O cliente é de verdade, tem contrato e paga — e desaparecia por causa do texto de UM
             * campo de endereço.
             *
             * Pior: a fila de revisão tinha teto de 200 registros aqui. Passando de 200, o cliente
             * era descartado SEM NENHUM registro. Perda silenciosa, que é o que não se pode ter.
             *
             * A REGRA DO OPERADOR é explícita: só NÃO se salva quando nome E documento são iguais a
             * um cadastro existente — aí sim são o mesmo cliente. Qualquer outra pendência é
             * correção a fazer depois, não motivo para o cliente não existir.
             *
             * Então: importa sem ramal (fica em "Todas as cidades"), guarda a cidade como TEXTO
             * para não perder o dado, e marca na observação o que precisa de conferência. O teto
             * também subiu, e o que passar dele ainda é CONTADO por motivo — ninguém sai sem rastro.
             */
            if (!$ramalLogado && $cCidade && trim((string)$r[$cCidade]) !== '' && !$cidadeNome) {
                $cidadeTexto = trim((string)$r[$cCidade]);
                $cidadeNome  = mb_strtoupper($cidadeTexto, 'UTF-8');   // entra como texto; ramal fica vazio
                $res['cidade_nao_oficial'] = ($res['cidade_nao_oficial'] ?? 0) + 1;
                $avisoCidade = 'Cidade "' . $cidadeTexto . '" não está no cadastro oficial — confira em Cadastros → Cidades e ajuste o ramal deste cliente.';
                $obsCliente = trim($obsCliente . ($obsCliente !== '' ? "\n" : '') . '[MIGRAÇÃO] ' . $avisoCidade);
                if (count($res['duplicados']) < 2000) {
                    $res['duplicados'][] = [
                        'nome' => $nome,
                        'login' => $login,
                        'motivo' => 'IMPORTADO, mas confira a cidade: "' . $cidadeTexto . '" não está no cadastro oficial.',
                        'ficha' => 0,
                        'rec' => $rec,
                        'importado' => 1,
                    ];
                }
            }

            $bairroNome = $cBairro ? ws_padronizar_e_criar($db, 'ws_bairro', (string)$r[$cBairro], $cidadeId) : null;
            // Zona padronizada (maiúscula, sem acento duplicando) e criada em ws_zona se não existir.
            $zonaNome = ($cZona && trim((string)($r[$cZona] ?? '')) !== '') ? ws_padronizar_e_criar($db, 'ws_zona', (string)$r[$cZona]) : null;

            $db->prepare("INSERT INTO ws_cliente (tipo,nome,nome_resumido,cpf_cnpj,email,celular,telefone,cep,logradouro,numero,complemento,bairro,cidade,uf,lat,lng,status,ramal_id,data_cadastro,data_desativacao,obs)
                          VALUES ('PF',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$cut($nome,160), $cut($nr,60), $cut(ws_so_numeros($cDoc?$r[$cDoc]:null),20), $cut($cEmail?$r[$cEmail]:null,160), $cut(ws_so_numeros($cCel?$r[$cCel]:null),20),
                          $cut(ws_so_numeros($cFone?$r[$cFone]:null),20), $cut($cCep?$r[$cCep]:null,10), $cut($cLograd?$r[$cLograd]:null,160),
                          $cut($cNum?$r[$cNum]:null,20), $cut($cCompl?$r[$cCompl]:null,80),
                          $cut($bairroNome,80), $cut($cidadeNome,80), $cut($cUf?$r[$cUf]:null,2),
                          is_numeric($lat)?$lat:null, is_numeric($lng)?$lng:null, $statusBanco, $ramalId,
                          ($dataCad ?: null), ($dataDesat ?: null), ($obsCliente !== '' ? $obsCliente : null)]);
            $cid = (int)$db->lastInsertId(); $res['clientes']++;
            // data de nascimento do MK-Auth (a Central do Assinante precisa dela para o login)
            if ($cNasc && ($dn = $nascIso($r[$cNasc] ?? '')) !== null) { try { $db->prepare("UPDATE ws_cliente SET data_nasc=? WHERE id=?")->execute([$dn, $cid]); } catch (Throwable $e) {} }

            /* ENDEREÇO DO IMPORTADO PASSA PELO RESOLVEDOR — senão a migração era a maior fábrica
             * de endereço duplicado do sistema.
             *
             * É o caminho por onde entram 1.600 endereços de uma vez, cada um escrito como o
             * operador do sistema antigo escreveu naquele dia. Sem o resolvedor, a base nasceria
             * com "AV. BRASIL", "AVENIDA BRASIL" e "Av Brasil" como três ruas — e normalizar depois
             * seria consertar o que acabou de ser criado torto.
             *
             * O resolvedor devolve o código da rua e a grafia CADASTRADA, então o texto gravado
             * acima é substituído pela forma canônica. Um endereço que não dê para interpretar fica
             * como veio, sem vínculo — o cliente entra de qualquer forma. */
            try {
                require_once __DIR__ . '/schema_endereco.php';
                $eIm = ws_end_resolver($db, [
                    'cep'        => (string)($cCep    ? ($r[$cCep]    ?? '') : ''),
                    'logradouro' => (string)($cLograd ? ($r[$cLograd] ?? '') : ''),
                    'bairro'     => (string)$bairroNome,
                    'cidade'     => (string)$cidadeNome,
                    'uf'         => (string)($cUf     ? ($r[$cUf]     ?? '') : ''),
                ]);
                if ($eIm['logradouro_id']) {
                    $db->prepare("UPDATE ws_cliente SET logradouro_id=?, logradouro=?, bairro=?, cidade=?, uf=?, cep=?, uf_id=? WHERE id=?")
                       ->execute([$eIm['logradouro_id'], $eIm['logradouro'], $eIm['bairro'], $eIm['cidade'], $eIm['uf'], $eIm['cep'], $eIm['uf_id'], $cid]);
                }
            } catch (Throwable $e) { /* endereço ilegível não pode fazer o cliente deixar de entrar */ }

            if ($login !== '') {
                $planoId = $cPlano ? ($mapaPlano[mb_strtolower(trim((string)$r[$cPlano]))] ?? null) : null;
                $venc = $cVenc ? (int)preg_replace('/\D/', '', (string)$r[$cVenc]) : 10; if ($venc < 1 || $venc > 31) $venc = 10;
                // Em confianca o contrato fica BLOQUEADO: quem libera e' o confianca_ate, gravado
                // logo apos a insercao. Antes caia em 'ativo' e o cliente entrava liberado sem prazo.
                $statusCt = (in_array($status, ['cancelado'], true) ? 'cancelado'
                           : (in_array($status, ['bloqueado', 'confianca'], true) ? 'bloqueado' : 'ativo'));
                // MK-Auth: no IPoE o ID da ONU vem NA SENHA. Se a senha é um ID (só dígitos) OU o login é um ID/Serial (12-16 chars) OU o backup
                // marca tipo=ipoe, migra p/ IPoE: joga o ID no login_ipoe, senha_ipoe e S/N da ONU.
                // Fora isso continua PPPoE (comportamento anterior).
                $senhaVal = $cSenha ? trim((string)$r[$cSenha]) : '';
                $tipoBk = $cTipo ? strtolower(trim((string)$r[$cTipo])) : '';
                // Mesma regra usada nos ADICIONAIS: se veio ID de ONU, é IPoE (ver mk_eh_ipoe).
                $ehIpoe = mk_eh_ipoe($login, $senhaVal, $tipoBk);
                if ($ehIpoe) {
                    $idOnu = $senhaVal !== '' ? $senhaVal : $login;
                    $db->prepare("INSERT INTO ws_contrato (cliente_id,plano_id,banco_id,login_pppoe,senha_pppoe,tipo_conexao,ont_id,login_ipoe,senha_ipoe,sn_onu,zona,dia_vencimento,status,data_ativacao)
                                  VALUES (?,?,?,?,?, 'ipoe', ?,?,?,?, ?, ?, ?, ?)")
                       ->execute([$cid, $planoId, $bancoPadraoId, $cut($login,80), null, $cut($idOnu,80), $cut($idOnu,80), $cut($idOnu,120), $cut($idOnu,40), $cut($zonaNome,60), $venc, $statusCt, ($dataAtiv ?: date('Y-m-d'))]);
                    $ctNovo = (int)$db->lastInsertId();
                    ws_equipamento_registrar_comodato($db, $ctNovo, $idOnu);
                    // Completa com o que a OLT sabe (zona, VLAN, placa/PON, ONT-ID, equipamento),
                    // casando pelo SERIAL. So' preenche o que ficou vazio — ver mk_olt_aplicar().
                    if (mk_olt_aplicar($db, $ctNovo, $idOnu) > 0) $res['olt_dados'] = ($res['olt_dados'] ?? 0) + 1;
                    if (mk_confianca_gravar($db, $ctNovo, $confAte)) $res['confianca'] = ($res['confianca'] ?? 0) + 1;
                } else {
                    $snEscolhido = preg_match('/^[0-9A-Za-z]{12,16}$/', $login) ? $login : ($cSn ? $r[$cSn] : null);
                    $db->prepare("INSERT INTO ws_contrato (cliente_id,plano_id,banco_id,login_pppoe,senha_pppoe,tipo_conexao,sn_onu,zona,dia_vencimento,status,data_ativacao)
                                  VALUES (?,?,?,?,?, 'pppoe', ?, ?, ?, ?, ?)")
                       ->execute([$cid, $planoId, $bancoPadraoId, $cut($login,80), $cut($senhaVal !== '' ? $senhaVal : null,120),
                                  // SN da ONU: no MK-Auth o login costuma SER o serial (GPON). Usa o login se parecer serial; senão o onu_ont.
                                  $cut($snEscolhido, 40),
                                  $cut($zonaNome,60), $venc, $statusCt, ($dataAtiv ?: date('Y-m-d'))]);
                    $ctNovo = (int)$db->lastInsertId();
                    ws_equipamento_registrar_comodato($db, $ctNovo, $snEscolhido);
                    // Mesmo enriquecimento do IPoE: em PPPoE o serial costuma ser o proprio login.
                    if (mk_olt_aplicar($db, $ctNovo, $snEscolhido) > 0) $res['olt_dados'] = ($res['olt_dados'] ?? 0) + 1;
                    if (mk_confianca_gravar($db, $ctNovo, $confAte)) $res['confianca'] = ($res['confianca'] ?? 0) + 1;
                }
                $res['contratos']++;
            }
        }
    }

    // ---- ADICIONAIS (sis_adicional) — atrelados ao TITULAR ----
    $res['adicionais'] = 0;
    if (mk_tab($imp, 'sis_adicional')) {
        $aCol = fn($cands) => mk_col($imp, 'sis_adicional', $cands);
        $aUser=$aCol(['username','login_adicional','usuario']); $aTit=$aCol(['login','titular']);
        $aNome=$aCol(['nome']); $aResumo=$aCol(['nome_res','resumo','nome_resumido']); $aPlano=$aCol(['plano']);
        $aSenha=$aCol(['senha','password']);
        // Celular/WhatsApp e cidade PRÓPRIOS do adicional, se o backup tiver essas colunas na
        // tabela sis_adicional (raro, mas alguns backups trazem) — quando não tiver, herda do
        // titular logo abaixo. ANTES o cadastro do Adicional ficava sempre sem celular e cidade.
        $aCel=$aCol(['celular','whatsapp','zap','fone']); $aCidadeCol=$aCol(['cidade']);
        if ($aUser && $aTit && $aNome) {
            $usadosA = [];
            foreach ($imp->query("SELECT * FROM sis_adicional") as $a) {
                $user = trim((string)$a[$aUser]); $tit = trim((string)$a[$aTit]); $nomeA = trim((string)$a[$aNome]);
                if ($user === '' || $nomeA === '') continue;
                // acha o TITULAR: cliente cujo contrato tem login = login do titular
                $t = $db->prepare("SELECT cliente_id FROM ws_contrato WHERE login_pppoe=? LIMIT 1"); $t->execute([$tit]);
                $titId = $t->fetchColumn() ?: null;
                // dedupe: adicional já existe?
                $ex = $db->prepare("SELECT 1 FROM ws_contrato WHERE login_pppoe=? LIMIT 1"); $ex->execute([$user]);
                if ($ex->fetchColumn()) { continue; }
                $nrA = mk_nome_resumido_ajustar($db, $aResumo ? trim((string)$a[$aResumo]) : '', $nomeA, $usadosA);
                // Adicional herda do TITULAR o que é do mesmo núcleo: CPF/CNPJ (mesma família/
                // empresa), telefones e ramal. ENDEREÇO não — ver o comentário abaixo.
                $cpfA = null; $tit_row = null;
                if ($titId) {
                    $tc = $db->prepare("SELECT cpf_cnpj,celular,telefone,cep,logradouro,numero,complemento,bairro,cidade,uf,lat,lng,ramal_id FROM ws_cliente WHERE id=?");
                    $tc->execute([$titId]); $tit_row = $tc->fetch(PDO::FETCH_ASSOC) ?: null;
                    $cpfA = $tit_row['cpf_cnpj'] ?? null;
                }
                $celA = ws_so_numeros(($aCel && trim((string)($a[$aCel] ?? '')) !== '') ? trim((string)$a[$aCel]) : ($tit_row['celular'] ?? '')) ?: null;
                // ENDEREÇO DO ADICIONAL NÃO É HERDADO. O adicional quase nunca mora no mesmo
                // endereço do titular (é outra casa/ponto), então copiar CEP, logradouro, número,
                // complemento, bairro, cidade, UF e coordenadas do titular gerava cadastro errado
                // — e errado de um jeito difícil de perceber, porque vinha "preenchido".
                // Endereço do adicional é preenchido MANUALMENTE na ficha do cliente.
                // Continua herdando o que de fato é do mesmo núcleo: CPF/CNPJ, telefones e ramal.
                $db->prepare("INSERT INTO ws_cliente (tipo,nome,nome_resumido,cpf_cnpj,celular,telefone,status,ramal_id,titular_id)
                              VALUES ('PF',?,?,?,?,?, 'ativo', ?,?)")
                   ->execute([$cut($nomeA,160), $cut($nrA,60), $cpfA ? ws_so_numeros($cpfA) : null, $cut($celA,20), $cut(ws_so_numeros($tit_row['telefone'] ?? '') ?: null,20),
                              $tit_row['ramal_id'] ?? null, $titId]);
                $acid = (int)$db->lastInsertId();
                $planoIdA = $aPlano ? ($mapaPlano[mb_strtolower(trim((string)$a[$aPlano]))] ?? null) : null;
                // CONEXÃO DO ADICIONAL: PPPoE ou IPoE pela MESMA regra dos titulares.
                // Antes este INSERT tinha 'pppoe' fixo no código — adicional com ID de ONU
                // entrava como PPPoE, com o ID no campo de usuário, e nunca autenticava certo.
                $senhaA = $aSenha ? trim((string)($a[$aSenha] ?? '')) : '';
                if (mk_eh_ipoe($user, $senhaA)) {
                    // IPoE: o ID da ONU vai para ont_id / login_ipoe / senha_ipoe / sn_onu —
                    // os mesmos campos que o import de titular preenche.
                    $idOnuA = mk_id_onu($user, $senhaA);
                    $db->prepare("INSERT INTO ws_contrato
                        (cliente_id,plano_id,login_pppoe,senha_pppoe,tipo_conexao,ont_id,login_ipoe,senha_ipoe,sn_onu,status,data_ativacao)
                        VALUES (?,?,?,NULL,'ipoe',?,?,?,?, 'ativo', CURDATE())")
                       ->execute([$acid, $planoIdA, $cut($user, 80), $cut($idOnuA, 80),
                                  $cut($idOnuA, 80), $cut($idOnuA, 120), $cut($idOnuA, 40)]);
                    $res['adicionais_ipoe'] = ($res['adicionais_ipoe'] ?? 0) + 1;
                    // O adicional tambem tem ONU propria — mesma consulta a' OLT pelo serial.
                    $ctAdd = (int)$db->lastInsertId();
                    if (mk_olt_aplicar($db, $ctAdd, $idOnuA) > 0) $res['olt_dados'] = ($res['olt_dados'] ?? 0) + 1;
                    /* O adicional também recebe ONU em comodato — antes só o titular era
                       registrado, então a lista "Comodatos (por cliente)" nascia incompleta. */
                    ws_equipamento_registrar_comodato($db, $ctAdd, $idOnuA);
                } else {
                    $db->prepare("INSERT INTO ws_contrato
                        (cliente_id,plano_id,login_pppoe,senha_pppoe,tipo_conexao,status,data_ativacao)
                        VALUES (?,?,?,?, 'pppoe', 'ativo', CURDATE())")
                       ->execute([$acid, $planoIdA, $cut($user, 80), $cut($senhaA !== '' ? $senhaA : null, 120)]);
                    // Adicional em PPPoE: se o login for o serial da ONU, a OLT completa o resto.
                    if (mk_olt_aplicar($db, (int)$db->lastInsertId(), $user) > 0) $res['olt_dados'] = ($res['olt_dados'] ?? 0) + 1;
                }
                $res['adicionais']++;
            }
        }
    }

    // ---- CONTA DE COBRANÇA + TÍTULOS (sis_boleto -> ws_banco, sis_lanc -> ws_fatura) ----
    // Roda DEPOIS de clientes/contratos: os títulos precisam do contrato já existir para casar
    // pelo login. A conta entra antes dos títulos porque vira o banco_id padrão.
    $res['contas'] = 0;
    // O erro NÃO pode ser engolido: antes, uma falha aqui deixava 0 boletos e nenhuma explicação
    // na tela — indistinguível de "o backup não tinha títulos".
    // Configurações do sistema (conta, gateways, boleto, SMTP/WhatsApp) vindas do backup.
    // Vem ANTES da conta: preenche provedor/boleto/cobrança que a conta e os títulos usam.
    if (is_file(__DIR__ . '/mkauth_configs.php')) {
        require_once __DIR__ . '/mkauth_configs.php';
        if (function_exists('ws_configs_garantir')) ws_configs_garantir();   // cria o que faltar
        try { mk_importar_configs($imp, $db, $res); }
        catch (Throwable $e) { $res['configs_erro'] = $e->getMessage(); }
        /* Concentradores/NAS, chaves de API e histórico de conexão. Cada um em seu try: uma base
           sem sis_config não pode impedir os concentradores de entrarem, e vice-versa. */
        try { mk_importar_nas($imp, $db, $res); }        catch (Throwable $e) { $res['nas_erro'] = $e->getMessage(); }
        try { mk_importar_api($imp, $db, $res); }        catch (Throwable $e) { $res['api_erro'] = $e->getMessage(); }
        try { mk_importar_conexoes($imp, $db, $res, 3); } catch (Throwable $e) { $res['conexoes_motivo'] = $e->getMessage(); }
    }
    // Guarda QUAL conta é a padrão. Ela é a que estava marcada como em uso no MK-Auth, e é a
    // única que o mk_importar_conta sabe identificar — a escolha "menor id" logo abaixo erraria
    // sempre que já houvesse uma conta cadastrada à mão, ou quando o backup trouxer várias.
    $contaPadrao = null;
    try { $contaPadrao = mk_importar_conta($imp, $db, $res); }
    catch (Throwable $e) { $res['contas_erro'] = $e->getMessage(); }
    try { mk_importar_titulos($imp, $db, $res, $boletoStatus, $boletoMeses); }
    catch (Throwable $e) {
        $res['boletos'] = $res['boletos'] ?? 0;
        $res['boletos_motivo'] = 'Erro ao importar os títulos: ' . $e->getMessage();
    }

    // Contratos que ficaram sem conta de cobrança (banco_id NULL) passam a apontar para a conta
    // recém-importada — antes TODO contrato saía da migração sem conta nenhuma.
    try {
        // A conta que o backup marcava como EM USO manda. Só se o backup não tiver dito nada é
        // que cai no antigo "a primeira ativa" — que é um palpite, e agora é claramente o último
        // recurso, não a regra.
        $bp = (int)($contaPadrao ?: 0);
        if (!$bp) $bp = (int)$db->query("SELECT id FROM ws_banco WHERE ativo=1 ORDER BY id LIMIT 1")->fetchColumn();
        if ($bp) $db->prepare("UPDATE ws_contrato SET banco_id=? WHERE banco_id IS NULL")->execute([$bp]);
    } catch (Throwable $e) {}

    /* Pendentes (conferência) guardam o ramal escolhido para ESTE backup: salvos depois, vão para a
     * mesma cidade/ramal — mesmo que outro backup, de outra cidade, suba no meio. */
    $rdest = mk_ramal_destino();
    if ($rdest && !empty($GLOBALS['ws_import_ramal_id'])) {
        foreach ($res['duplicados'] as $i => $d) $res['duplicados'][$i]['ramal_destino'] = (int)$rdest['id'];
        $res['ramal_destino'] = $rdest;
    }

    // Detalhamento do que foi trazido além do cadastro básico — vira o card "O que veio da OLT".
    $res['olt_detalhe'] = $GLOBALS['ws_mig_olt'] ?? [];

    ws_evento($db, null, 'importacao', "Backup importado (MK-Auth ou outro ERP): {$res['clientes']} clientes, {$res['contratos']} contratos, {$res['planos']} planos, {$res['adicionais']} adicionais, " . (int)($res['boletos'] ?? 0) . " boletos");

    // limpeza
    $imp = null;
    $m2 = @mysqli_connect($c['host'], $c['user'], $c['pass'], '', (int)$c['porta']);
    if ($m2) { mysqli_query($m2, "DROP DATABASE IF EXISTS `$tmpDb`"); mysqli_close($m2); }
    if (!empty($prep['dir']) && is_dir($prep['dir'])) @shell_exec('rm -rf ' . escapeshellarg($prep['dir']));
    if (!empty($prep['tmpfile'])) @unlink($prep['tmpfile']);
    return $res;
}