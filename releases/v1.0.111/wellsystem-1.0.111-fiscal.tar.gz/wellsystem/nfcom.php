<?php
/**
 * WellSystem — NFCom (Nota Fiscal Fatura de Serviço de Comunicação Eletrônica, modelo 62) — 12/11/2026.
 * Serviço de internet (SCM) é serviço de comunicação: ICMS, não ISS. Autorização na SVRS (webservice SOAP 1.2,
 * envio síncrono, mesmo certificado A1 e mesma raiz ICP-Brasil da NF-e). Modelo de tributação conferido na nota de
 * outro provedor do mesmo serviço (CFOP 5307, unidade MB, ICMS/PIS/COFINS/FUST/FUNTTEL zerados no Simples).
 * Reaproveita nfe55.php (chave, DV, UF) e nfse_nacional.php (certificado, assinatura, HTTP mTLS).
 */
require_once __DIR__ . '/nfe55.php';

function ws_nfcom_urls(array $c): array {
    $h = (($c['ambiente'] ?? '') === 'producao') ? 'nfcom.svrs.rs.gov.br' : 'nfcom-homologacao.svrs.rs.gov.br';
    return ['recepcao' => "https://$h/WS/NFComRecepcao/NFComRecepcao.asmx", 'consulta' => "https://$h/WS/NFComConsulta/NFComConsulta.asmx",
            'evento' => "https://$h/WS/NFComRecepcaoEvento/NFComRecepcaoEvento.asmx", 'status' => "https://$h/WS/NFComStatusServico/NFComStatusServico.asmx"];
}

/** 12/11/2026: contador SEPARADO por ambiente (mesmo risco da NF-e: testar em homologação não pode colidir com produção). */
function ws_nfcom_proximo_numero(): int {
    $c = ws_nfse_config(); $prod = (($c['ambiente'] ?? '') === 'producao');
    $chave = $prod ? 'nfcom_proximo' : 'nfcom_proximo_homolog';
    $arq = WS_CACHE . '/nfcom_seq_' . ($prod ? 'prod' : 'homolog') . '.lock'; $fp = @fopen($arq, 'c+'); if (!$fp) return (int)(microtime(true) * 10) % 999999999;
    flock($fp, LOCK_EX); $n = max(1, (int)($c[$chave] ?? 1));
    ws_nfse_salvar([$chave => $n + 1]); flock($fp, LOCK_UN); fclose($fp); return $n;
}

/** Impostos de UM item no regime normal (Lucro Presumido/Real). Soma nos totais (por referência). Percentuais vêm do Emissor; 0% vira CST de "sem imposto". */
function ws_nfcom_imposto_normal(float $vp, float $pI, float $pP, float $pC, float $pF, float $pN, float &$tBC, float &$tICMS, float &$tPIS, float &$tCOF, float &$tFUST, float &$tFUN): string {
    $f2 = fn($v) => number_format((float)$v, 2, '.', ''); $f4 = fn($v) => number_format((float)$v, 4, '.', '');
    $vi = round($vp * $pI / 100, 2); $vpis = round($vp * $pP / 100, 2); $vcof = round($vp * $pC / 100, 2); $vfu = round($vp * $pF / 100, 2); $vfn = round($vp * $pN / 100, 2);
    if ($pI > 0) { $tBC += $vp; $tICMS += $vi; }
    $tPIS += $vpis; $tCOF += $vcof; $tFUST += $vfu; $tFUN += $vfn;
    return '<imposto>' . ($pI > 0 ? '<ICMS00><CST>00</CST><vBC>' . $f2($vp) . '</vBC><pICMS>' . $f2($pI) . '</pICMS><vICMS>' . $f2($vi) . '</vICMS></ICMS00>' : '<ICMS40><CST>40</CST></ICMS40>')
         . '<PIS><CST>' . ($pP > 0 ? '01' : '49') . '</CST><vBC>' . $f2($pP > 0 ? $vp : 0) . '</vBC><pPIS>' . $f4($pP) . '</pPIS><vPIS>' . $f2($vpis) . '</vPIS></PIS>'
         . '<COFINS><CST>' . ($pC > 0 ? '01' : '49') . '</CST><vBC>' . $f2($pC > 0 ? $vp : 0) . '</vBC><pCOFINS>' . $f4($pC) . '</pCOFINS><vCOFINS>' . $f2($vcof) . '</vCOFINS></COFINS>'
         . '<FUST><vBC>' . $f2($pF > 0 ? $vp : 0) . '</vBC><pFUST>' . $f4($pF) . '</pFUST><vFUST>' . $f2($vfu) . '</vFUST></FUST>'
         . '<FUNTTEL><vBC>' . $f2($pN > 0 ? $vp : 0) . '</vBC><pFUNTTEL>' . $f4($pN) . '</pFUNTTEL><vFUNTTEL>' . $f2($vfn) . '</vFUNTTEL></FUNTTEL>';
}

/** Monta e ASSINA a NFCom. @return array [xml, chave, numero] */
/** 14/11/2026: código de barras do boleto para o gFat/codBarras da NFCom. Aceita a linha digitável (47 dígitos, boleto bancário; 48, arrecadação) ou o próprio
 *  código de barras (44). Qualquer outra coisa = '' (a nota sai com 44 zeros, como antes). Mesma conversão do carnê (ws_pdf_linha_para_barras). */
function ws_nfcom_cod_barras(string $linha): string {
    $d = preg_replace('/\D/', '', $linha);
    if (strlen($d) === 47) return substr($d, 0, 4) . substr($d, 32, 1) . substr($d, 33, 14) . substr($d, 4, 5) . substr($d, 10, 10) . substr($d, 21, 10);
    if (strlen($d) === 48 && $d[0] === '8') return substr($d, 0, 11) . substr($d, 12, 11) . substr($d, 24, 11) . substr($d, 36, 11);
    return strlen($d) === 44 ? $d : '';
}
/** 14/11/2026 (nota 57): texto do XML da NFCom só aceita Latin-1 (a SEFAZ rejeitou o bairro "Centro —" com travessão, cStat 215). Troca travessões por hífen, tira o que está fora do Latin-1, junta espaços e corta pontuação solta nas pontas. */
function ws_nfcom_txt($s, int $max = 60): string {
    $s = str_replace(["\u{2013}", "\u{2014}", "\u{2212}"], '-', (string)$s);
    $s = preg_replace('/[^\x{20}-\x{7E}\x{A0}-\x{FF}]/u', ' ', $s) ?? '';
    $s = trim(preg_replace('/\s+/u', ' ', $s));
    $s = trim($s, " -,;.");
    return rtrim(mb_substr($s, 0, $max));
}

function ws_nfcom_montar(array $c, array $itens, array $cli, string $obs, string $certPem, string $pkeyPem, ?string $vencimento = null, ?int $numeroReusar = null): array {
    $obs = preg_replace('/[^\x{20}-\x{7E}\x{A0}-\x{FF}]/u', ' ', str_replace(["\u{2013}", "\u{2014}", "\u{2212}"], '-', $obs)) ?? $obs;   // 14/11/2026: só Latin-1 (nota 57)
    $cnpj = ws_nfse_so_num($c['cnpj']); $mun = ws_nfse_so_num($c['cod_ibge']); $numero = ($numeroReusar !== null && $numeroReusar > 0) ? $numeroReusar : ws_nfcom_proximo_numero();   // 14/11/2026: nota rejeitada reenvia com o MESMO número
    $cNF = str_pad((string)random_int(1000000, 9999999), 7, '0', STR_PAD_LEFT);
    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2; $serie = (int)(ws_nfse_so_num($c['nfcom_serie'] ?? '1') ?: 1);
    $chave43 = ws_nfe55_cuf((string)$c['uf']) . $agora->format('ym') . $cnpj . '62' . str_pad((string)$serie, 3, '0', STR_PAD_LEFT) . str_pad((string)$numero, 9, '0', STR_PAD_LEFT) . '1' . '0' . $cNF;
    $chave = $chave43 . ws_nfe55_dv($chave43);
    $f2 = fn($v) => number_format((float)$v, 2, '.', '');
    $doc = ws_nfse_so_num($cli['cpf_cnpj'] ?? ''); $tagDoc = strlen($doc) === 14 ? 'CNPJ' : 'CPF';
    $cMunT = ws_nfse_so_num($cli['cod_ibge'] ?? ($cli['ibge'] ?? '')) ?: $mun; $cepT = ws_nfse_so_num($cli['cep'] ?? '') ?: ws_nfse_so_num($c['cep']);
    $ufT = strtoupper(trim((string)($cli['uf'] ?? ''))) ?: (string)$c['uf'];
    // 13/11/2026: telefone e e-mail do tomador também vão no documento (só se válidos: fone 6–14 dígitos, e-mail bem formado); antes saíam só nome/documento/endereço
    $foneDig = ws_nfse_so_num($cli['telefone'] ?? ''); $foneDest = (strlen($foneDig) >= 6 && strlen($foneDig) <= 14) ? '<fone>' . $foneDig . '</fone>' : '';
    $mailT = trim((string)($cli['email'] ?? '')); $mailDest = ($mailT !== '' && filter_var($mailT, FILTER_VALIDATE_EMAIL) && strlen($mailT) <= 60) ? '<email>' . ws_nfsen_x($mailT) . '</email>' : '';
    /* 14/11/2026 (nota 57): tomador CNPJ contribuinte do ICMS — a SEFAZ rejeitou com 430 "IE do Destinatário não informada" quando saiu indIEDest=9 sem IE. Com IE cadastrada (rg_ie, só dígitos, até 14) sai indIEDest=1 + <IE>; sem IE, segue 9 como antes (notas 2 a 7 foram autorizadas assim). */
    $ieT = ws_nfse_so_num($cli['rg_ie'] ?? ''); $indIE = (strlen($doc) === 14 && $ieT !== '' && strlen($ieT) <= 14) ? '<indIEDest>1</indIEDest><IE>' . $ieT . '</IE>' : '<indIEDest>9</indIEDest>';
    $imT = trim((string)($cli['inscricao_municipal'] ?? '')); $imDest = ($imT !== '' && strlen($imT) <= 15) ? '<IM>' . ws_nfsen_x($imT) . '</IM>' : '';   // 13/11/2026: inscrição municipal do tomador (campo opcional do dest)
    $det = ''; $totProd = 0.0; $totDesc = 0.0; $n = 0;
    // 13/11/2026: tributação por REGIME. Simples Nacional e MEI: ICMSSN e grupos zerados (padrão). Lucro Presumido/Real ("normal"): ICMS, PIS, COFINS, FUST e FUNTTEL calculados pelos
    // percentuais do Emissor (nfcom_*_pct); ICMS 0% sai como ICMS40 (CST 40, isenta). Os percentuais DEVEM ser conferidos com o contador.
    $simp = ws_regime_simples($c); $tBC = $tICMS = $tPIS = $tCOF = $tFUST = $tFUN = 0.0;
    $pI = (float)str_replace(',', '.', (string)($c['nfcom_icms_pct'] ?? 0)); $pP = (float)str_replace(',', '.', (string)($c['nfcom_pis_pct'] ?? 0)); $pC = (float)str_replace(',', '.', (string)($c['nfcom_cofins_pct'] ?? 0));
    $pF = (float)str_replace(',', '.', (string)($c['nfcom_fust_pct'] ?? 0)); $pN = (float)str_replace(',', '.', (string)($c['nfcom_funttel_pct'] ?? 0));
    foreach ($itens as $it) {
        $n++; $q = (float)$it['qtd']; $vu = (float)$it['valor_unit']; $vd = (float)$it['desconto']; $vp = max(0, round($q * $vu - $vd, 2));
        $totProd += round($q * $vu, 2); $totDesc += $vd;
        $det .= '<det nItem="' . $n . '"><prod><cProd>' . $n . '</cProd><xProd>' . ws_nfsen_x(ws_nfcom_txt($it['descricao'] ?? '', 120) ?: 'Servico') . '</xProd>'
              . '<cClass>' . ws_nfsen_x($c['nfcom_cclass'] ?? '0100401') . '</cClass><CFOP>' . ws_nfse_so_num($c['nfcom_cfop'] ?? '5307') . '</CFOP><uMed>' . ws_nfsen_x($c['nfcom_umed'] ?? '2') . '</uMed>'
              . '<qFaturada>' . rtrim(rtrim(number_format($q, 4, '.', ''), '0'), '.') . '</qFaturada><vItem>' . number_format($vu, 8, '.', '') . '</vItem>'
              . ($vd > 0 ? '<vDesc>' . $f2($vd) . '</vDesc>' : '') . '<vProd>' . $f2($vp) . '</vProd></prod>'
              . ($simp ? '<imposto><ICMSSN><CST>90</CST><indSN>1</indSN></ICMSSN>'
                    . '<PIS><CST>49</CST><vBC>0.00</vBC><pPIS>0.00</pPIS><vPIS>0.00</vPIS></PIS><COFINS><CST>49</CST><vBC>0.00</vBC><pCOFINS>0.00</pCOFINS><vCOFINS>0.00</vCOFINS></COFINS>'
                    . '<FUST><vBC>0.00</vBC><pFUST>0.00</pFUST><vFUST>0.00</vFUST></FUST><FUNTTEL><vBC>0.00</vBC><pFUNTTEL>0.00</pFUNTTEL><vFUNTTEL>0.00</vFUNTTEL></FUNTTEL>'
                    : ws_nfcom_imposto_normal($vp, $pI, $pP, $pC, $pF, $pN, $tBC, $tICMS, $tPIS, $tCOF, $tFUST, $tFUN))
              . '<retTrib><vRetPIS>0.00</vRetPIS><vRetCofins>0.00</vRetCofins><vRetCSLL>0.00</vRetCSLL><vBCIRRF>0.00</vBCIRRF><vIRRF>0.00</vIRRF></retTrib></imposto></det>';
    }
    $vNF = round($totProd - $totDesc, 2); $codBarras = ws_nfcom_cod_barras((string)($cli['codigo_barras'] ?? '')) ?: str_repeat('0', 44);   // código de barras do boleto da fatura quando houver; senão zeros (14/11/2026: antes o filtro era '/D/' e o código nunca chegava aqui)
    $venc = $vencimento ?: $agora->modify('+10 days')->format('Y-m-d'); $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $nomeDest = $amb === 2 ? 'NFCOM EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL' : (string)$cli['nome'];
    $qr = 'https://dfe-portal.svrs.rs.gov.br/nfcom/qrCode?chNFCom=' . $chave . '&tpAmb=' . $amb;
    $fonR = ws_nfse_so_num($c['telefone'] ?? ''); $mailR = trim((string)($c['email'] ?? ''));
    $xml = '<NFCom xmlns="http://www.portalfiscal.inf.br/nfcom"><infNFCom versao="1.00" Id="NFCom' . $chave . '">'
        . '<ide><cUF>' . ws_nfe55_cuf((string)$c['uf']) . '</cUF><tpAmb>' . $amb . '</tpAmb><mod>62</mod><serie>' . $serie . '</serie><nNF>' . $numero . '</nNF><cNF>' . $cNF . '</cNF><cDV>' . substr($chave, -1) . '</cDV>'
        . '<dhEmi>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEmi><tpEmis>1</tpEmis><nSiteAutoriz>0</nSiteAutoriz><cMunFG>' . $mun . '</cMunFG><finNFCom>0</finNFCom><tpFat>0</tpFat><verProc>WellSystem</verProc></ide>'
        . '<emit><CNPJ>' . $cnpj . '</CNPJ><IE>' . ws_nfse_so_num($c['inscricao_estadual']) . '</IE><CRT>' . ws_regime_crt($c) . '</CRT><xNome>' . ws_nfsen_x($c['razao_social']) . '</xNome>'
        . '<enderEmit><xLgr>' . ws_nfsen_x($c['logradouro']) . '</xLgr><nro>' . ws_nfsen_x($c['numero'] ?: 'S/N') . '</nro><xBairro>' . ws_nfsen_x($c['bairro']) . '</xBairro><cMun>' . $mun . '</cMun><xMun>' . ws_nfsen_x($c['cidade']) . '</xMun><CEP>' . ws_nfse_so_num($c['cep']) . '</CEP><UF>' . ws_nfsen_x($c['uf']) . '</UF>'
        . (strlen($fonR) >= 6 ? '<fone>' . substr($fonR, 0, 14) . '</fone>' : '') . ($mailR !== '' ? '<email>' . ws_nfsen_x($mailR) . '</email>' : '') . '</enderEmit></emit>'
        . '<dest><xNome>' . ws_nfsen_x(ws_nfcom_txt($nomeDest)) . '</xNome><' . $tagDoc . '>' . $doc . '</' . $tagDoc . '>' . $indIE . $imDest
        . '<enderDest><xLgr>' . ws_nfsen_x(ws_nfcom_txt($cli['logradouro'] ?? '') ?: 'NAO INFORMADO') . '</xLgr><nro>' . ws_nfsen_x(trim((string)($cli['numero'] ?? '')) !== '' ? trim((string)$cli['numero']) : 'S/N') . '</nro><xBairro>' . ws_nfsen_x(ws_nfcom_txt($cli['bairro'] ?? '') ?: 'Centro') . '</xBairro><cMun>' . $cMunT . '</cMun><xMun>' . ws_nfsen_x(ws_nfcom_txt(preg_replace('/\s*[,\/-]\s*[A-Za-z]{2}$/', '', (string)($cli['cidade'] ?? '')) ?: $c['cidade'])) . '</xMun><CEP>' . $cepT . '</CEP><UF>' . ws_nfsen_x($ufT) . '</UF>' . $foneDest . $mailDest . '</enderDest></dest>'
        . '<assinante><iCodAssinante>' . (int)($cli['id'] ?? 1) . '</iCodAssinante><tpAssinante>' . (strlen($doc) === 14 ? '1' : '3') . '</tpAssinante><tpServUtil>4</tpServUtil>'
        . '<nContrato>' . (int)($cli['id'] ?? 1) . '</nContrato><dContratoIni>' . $agora->format('Y-m-01') . '</dContratoIni><dContratoFim>' . $agora->modify('+1 year')->format('Y-m-d') . '</dContratoFim></assinante>'
        . $det
        . '<total><vProd>' . $f2($vNF) . '</vProd><ICMSTot><vBC>' . $f2($tBC) . '</vBC><vICMS>' . $f2($tICMS) . '</vICMS><vICMSDeson>0.00</vICMSDeson><vFCP>0.00</vFCP></ICMSTot><vCOFINS>' . $f2($tCOF) . '</vCOFINS><vPIS>' . $f2($tPIS) . '</vPIS><vFUNTTEL>' . $f2($tFUN) . '</vFUNTTEL><vFUST>' . $f2($tFUST) . '</vFUST>'
        . '<vRetTribTot><vRetPIS>0.00</vRetPIS><vRetCofins>0.00</vRetCofins><vRetCSLL>0.00</vRetCSLL><vIRRF>0.00</vIRRF></vRetTribTot><vDesc>' . $f2($totDesc) . '</vDesc><vOutro>0.00</vOutro><vNF>' . $f2($vNF) . '</vNF></total>'
        . '<gFat><CompetFat>' . (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Ym') . '</CompetFat><dVencFat>' . $venc . '</dVencFat><dPerUsoIni>' . (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-01') . '</dPerUsoIni><dPerUsoFim>' . (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-t') . '</dPerUsoFim><codBarras>' . ws_nfsen_x($codBarras) . '</codBarras></gFat>'
        . '<infAdic><infCpl>' . ws_nfsen_x(mb_substr(trim((mb_strlen(trim((string)($cli['nome'] ?? ''))) > 60 ? 'Tomador: ' . trim((string)$cli['nome']) . '. ' : '') . (trim($obs) !== '' ? trim($obs) . ' ' : '') . 'Valor aproximado dos tributos: R$ ' . number_format($vNF * (float)($c['pct_trib_nfcom'] ?? 6) / 100, 2, ',', '.') . ' (' . number_format((float)($c['pct_trib_nfcom'] ?? 6), 2, ',', '.') . '%).' . (($ctt = ws_nota_contato_linhas()) ? ' ' . implode(' | ', $ctt) : '')), 0, 700)) . '</infCpl></infAdic>'
        . (strlen($fonR) >= 7 && $mailR !== '' ? '<gRespTec><CNPJ>' . $cnpj . '</CNPJ><xContato>' . ws_nfsen_x(mb_substr(trim((string)$c['razao_social']), 0, 60)) . '</xContato><email>' . ws_nfsen_x($mailR) . '</email><fone>' . substr($fonR, 0, 12) . '</fone></gRespTec>' : '')
        . '</infNFCom><infNFComSupl><qrCodNFCom>' . ws_nfsen_x($qr) . '</qrCodNFCom></infNFComSupl></NFCom>';
    $algo = ($c['nfcom_algoritmo'] ?? 'sha1');
    return [ws_nfsen_assinar_pedido($xml, 'infNFCom', 'NFCom' . $chave, array_merge($c, ['nfsen_algoritmo' => $algo]), $certPem, $pkeyPem), $chave, $numero];
}

/** Envia (síncrono) ao webservice. XML compactado em gzip+base64 dentro de nfcomDadosMsg. */
function ws_nfcom_enviar(string $xml, array $c, string $cert, string $pkey): array {
    $u = ws_nfcom_urls($c); $ns = 'http://www.portalfiscal.inf.br/nfcom/wsdl/NFComRecepcao';
    $payload = ($c['nfcom_envio'] ?? 'gzip') === 'texto' ? htmlspecialchars($xml, ENT_XML1) : base64_encode(gzencode($xml));
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfcomDadosMsg xmlns="' . $ns . '">' . $payload . '</nfcomDadosMsg></soap12:Body></soap12:Envelope>';
    return ws_nfsen_http('POST', $u['recepcao'], $soap, $cert, $pkey, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "' . $ns . '/nfcomRecepcao"']);
}

/** Emite a NFCom. Contrato: ['ok','erro','raw','nfcom_id']. */
function ws_nfcom_emitir(PDO $db, array $notaRef, array $cliente, array $itens, string $obs = '', ?string $vencimento = null): array {   // $vencimento (Y-m-d): da fatura ligada à nota; sem ele vale hoje+10
    $c = ws_nfse_config();
    foreach (['cnpj' => 'CNPJ', 'inscricao_estadual' => 'Inscrição Estadual', 'cod_ibge' => 'código IBGE', 'uf' => 'UF'] as $k => $rot)
        if (trim((string)($c[$k] ?? '')) === '') return ['ok' => false, 'erro' => 'Configure a ' . $rot . ' em Fiscal → Emissor.'];
    [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['ok' => false, 'erro' => $erroC];
    /* 14/11/2026 (nota 57): REJEIÇÃO da SEFAZ (schema, IE, endereço...) NÃO consome o número — a nota nunca foi autorizada. Reenviar a mesma nota refaz a tentativa com o MESMO número e a MESMA linha
       (antes cada reenvio pegava um número novo: a nota 57 gastou 8 e 9 e saiu como 10, deixando buracos na numeração). Não reaproveita: duplicidade (204/539), denegação (110/301/302),
       tentativa sem resposta (codigo_status vazio — a SEFAZ pode ter autorizado; quem trata é ws_nota_tentativa_pendente) nem número que aparece em outra linha autorizada/processando/cancelada. */
    $reId = 0; $reNum = null;
    if (!empty($notaRef['id'])) { try {
        $qa = $db->prepare("SELECT id, numero FROM ws_nfcom WHERE nota_id=? AND status='erro' AND codigo_status IS NOT NULL AND codigo_status NOT IN ('100','110','150','204','301','302','539') AND numero > 0 ORDER BY id DESC LIMIT 1");
        $qa->execute([(int)$notaRef['id']]); $ant = $qa->fetch(PDO::FETCH_ASSOC);
        if ($ant) { $qb = $db->prepare("SELECT COUNT(*) FROM ws_nfcom WHERE numero=? AND id<>? AND status IN ('autorizada','processando','cancelada')"); $qb->execute([(int)$ant['numero'], (int)$ant['id']]);
            if ((int)$qb->fetchColumn() === 0) { $reId = (int)$ant['id']; $reNum = (int)$ant['numero']; } }
    } catch (Throwable $e) {} }
    /* 14/11/2026: NÚMERO FORÇADO (uso do dono, só por script: $GLOBALS['ws_nfcom_numero_forcado']) — preenche número livre da sequência (ex.: 8 e 9 rejeitados na nota 57). Só vale se nenhuma linha
       autorizada/processando/cancelada-com-protocolo usa o número; aproveita a linha antiga sem protocolo (erro/cancelada) para o número não repetir na tabela. */
    if (!empty($GLOBALS['ws_nfcom_numero_forcado'])) {
        $nf = (int)$GLOBALS['ws_nfcom_numero_forcado'];
        $qf = $db->prepare("SELECT COUNT(*) FROM ws_nfcom WHERE numero=? AND (status IN ('autorizada','processando') OR protocolo IS NOT NULL)"); $qf->execute([$nf]);
        if ((int)$qf->fetchColumn() > 0) return ['ok' => false, 'erro' => 'O número ' . $nf . ' já foi usado por uma NFCom autorizada ou em processamento.'];
        $qg = $db->prepare("SELECT id FROM ws_nfcom WHERE numero=? AND protocolo IS NULL AND status IN ('erro','cancelada') ORDER BY id DESC LIMIT 1"); $qg->execute([$nf]);
        $reId = (int)$qg->fetchColumn(); $reNum = $nf;
    }
    [$xml, $chave, $numero] = ws_nfcom_montar($c, $itens, $cliente, $obs, $cert, $pkey, $vencimento, $reNum);
    $valor = 0.0; foreach ($itens as $it) $valor += max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
    if ($reId > 0) {
        $db->prepare("UPDATE ws_nfcom SET nota_id=?, cliente_id=?, valor=?, status='processando', numero=?, chave_acesso=?, protocolo=NULL, codigo_status=NULL, motivo=NULL, url_xml=NULL, retorno_raw=NULL WHERE id=?")->execute([$notaRef['id'] ?? null, $cliente['id'], round($valor, 2), $numero, $chave, $reId]);
        $id = $reId;
    } else {
        $db->prepare("INSERT INTO ws_nfcom (nota_id,cliente_id,valor,status,numero,chave_acesso) VALUES (?,?,?,'processando',?,?)")->execute([$notaRef['id'] ?? null, $cliente['id'], round($valor, 2), $numero, $chave]);
        $id = (int)$db->lastInsertId();
    }
    [$code, $raw, $err] = ws_nfcom_enviar($xml, $c, $cert, $pkey);
    $ok = false; $cStat = ''; $motivo = ''; $prot = '';
    if ($code >= 200 && $code < 300 && is_string($raw)) {
        $alvo = $raw; if (preg_match('#<infProt[^>]*>.*?</infProt>#s', $raw, $mp)) $alvo = $mp[0];
        if (preg_match('#<cStat>(\d+)</cStat>#', $alvo, $m)) $cStat = $m[1];
        if (preg_match('#<xMotivo>([^<]*)</xMotivo>#', $alvo, $m)) $motivo = html_entity_decode($m[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
        if (preg_match('#<nProt>([^<]*)</nProt>#', $alvo, $m)) $prot = $m[1];
        $ok = ($cStat === '100');
    } elseif ($code === 0) $motivo = 'Sem conexão com a SEFAZ: ' . $err;
    else $motivo = 'HTTP ' . $code . ': ' . mb_substr(strip_tags((string)$raw), 0, 200);
    $motivo = mb_substr($motivo, 0, 250);
    @mkdir(WS_CACHE . '/notas_xml/nfcom', 0750, true); @file_put_contents(WS_CACHE . '/notas_xml/nfcom/' . $chave . '.xml', $xml);
    $db->prepare("UPDATE ws_nfcom SET status=?, codigo_status=?, protocolo=?, motivo=?, url_xml=?, retorno_raw=? WHERE id=?")
       ->execute([$ok ? 'autorizada' : 'erro', $cStat ?: null, $prot ?: null, $motivo ?: null, $ok ? 'cache/notas_xml/nfcom/' . $chave . '.xml' : null, (string)$raw, $id]);
    return ['ok' => $ok, 'erro' => $ok ? '' : ($motivo ?: 'falha ao emitir'), 'raw' => $raw, 'nfcom_id' => $id];
}

/* ------------------------------------------------------------------------------------------------------------------
 * CANCELAMENTO da NFCom (evento 110111) — 13/11/2026. Leiaute da NT 2024.001: eventoNFCom > infEvento (Id = "ID"+110111+chNFCom(44)+nSeqEvento(3)),
 * detEvento > evCancNFCom (descEvento, nProt, xJust 15..255). Envio igual ao da recepção (SOAP 1.2, gzip+base64 em nfcomDadosMsg) ao
 * NFComRecepcaoEvento. Só marca 'cancelada' se a SEFAZ aceitar (cStat 135/136). O prazo de cancelamento é da SEFAZ (ela recusa fora do prazo).
 * ------------------------------------------------------------------------------------------------------------------ */
function ws_nfcom_montar_cancelamento(array $c, string $chave, string $nProt, string $xJust, string $certPem, string $pkeyPem): array {
    $cnpj = ws_nfse_so_num($c['cnpj']); $chave = ws_nfse_so_num($chave); $id = 'ID110111' . $chave . '001';
    $xJust = trim(preg_replace('/\s+/u', ' ', (string)preg_replace('/[\x00-\x1F\x7F]/u', ' ', $xJust)));
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2; $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $xml = '<eventoNFCom xmlns="http://www.portalfiscal.inf.br/nfcom" versao="1.00"><infEvento Id="' . $id . '">'
         . '<cOrgao>' . ws_nfe55_cuf((string)$c['uf']) . '</cOrgao><tpAmb>' . $amb . '</tpAmb><CNPJ>' . $cnpj . '</CNPJ><chNFCom>' . $chave . '</chNFCom>'
         . '<dhEvento>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEvento><tpEvento>110111</tpEvento><nSeqEvento>1</nSeqEvento>'
         . '<detEvento versaoEvento="1.00"><evCancNFCom><descEvento>Cancelamento</descEvento><nProt>' . ws_nfse_so_num($nProt) . '</nProt><xJust>' . ws_nfsen_x($xJust) . '</xJust></evCancNFCom></detEvento>'
         . '</infEvento></eventoNFCom>';
    return [ws_nfsen_assinar_pedido($xml, 'infEvento', $id, array_merge($c, ['nfsen_algoritmo' => ($c['nfcom_algoritmo'] ?? 'sha1')]), $certPem, $pkeyPem), $id];
}

/** Envia o evento ao webservice (mesmo formato do envio da nota). */
function ws_nfcom_enviar_evento(string $xml, array $c, string $cert, string $pkey): array {
    $u = ws_nfcom_urls($c); $ns = 'http://www.portalfiscal.inf.br/nfcom/wsdl/NFComRecepcaoEvento';
    $payload = preg_replace('/^<\?xml[^>]*\?>\s*/', '', $xml);   // evento: o XML vai como filho direto de nfcomDadosMsg (o servidor recusa gzip/base64 aqui)
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfcomDadosMsg xmlns="' . $ns . '">' . $payload . '</nfcomDadosMsg></soap12:Body></soap12:Envelope>';
    return ws_nfsen_http('POST', $u['evento'], $soap, $cert, $pkey, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "' . $ns . '/nfcomRecepcaoEvento"']);
}

/** Núcleo (sem banco): monta, envia e interpreta. @return array ['ok','cStat','motivo','raw','code'] */
function ws_nfcom_cancelar_chave(array $c, string $chave, string $nProt, string $xJust): array {
    [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['ok' => false, 'cStat' => '', 'motivo' => $erroC, 'raw' => '', 'code' => 0];
    [$xml] = ws_nfcom_montar_cancelamento($c, $chave, $nProt, $xJust, $cert, $pkey);
    [$code, $raw, $err] = ws_nfcom_enviar_evento($xml, $c, $cert, $pkey);
    $cStat = ''; $motivo = '';
    if ($code >= 200 && $code < 300 && is_string($raw)) {
        $alvo = $raw; if (preg_match('#<infEvento[^>]*>.*?</infEvento>#s', $raw, $mp)) $alvo = $mp[0];   // retorno do evento (não o cStat do lote)
        if (preg_match('#<cStat>(\d+)</cStat>#', $alvo, $m)) $cStat = $m[1];
        if (preg_match('#<xMotivo>([^<]*)</xMotivo>#', $alvo, $m)) $motivo = html_entity_decode($m[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
    } elseif ($code === 0) $motivo = 'Sem conexão com a SEFAZ: ' . $err;
    else $motivo = 'HTTP ' . $code . ': ' . mb_substr(strip_tags((string)$raw), 0, 200);
    return ['ok' => in_array($cStat, ['135', '136'], true), 'cStat' => $cStat, 'motivo' => mb_substr($motivo, 0, 250), 'raw' => (string)$raw, 'code' => $code];
}

/** Cancela uma NFCom AUTORIZADA do sistema. Devolve ['ok','erro','raw']. */
function ws_nfcom_cancelar(PDO $db, int $idNf, string $xJust): array {
    $st = $db->prepare("SELECT * FROM ws_nfcom WHERE id=?"); $st->execute([$idNf]); $n = $st->fetch();
    if (!$n) return ['ok' => false, 'erro' => 'Registro não encontrado.'];
    if ($n['status'] === 'cancelada') return ['ok' => false, 'erro' => 'Esta NFCom já está cancelada.'];
    if ($n['status'] !== 'autorizada') return ['ok' => false, 'erro' => 'Só NFCom autorizada pode ser cancelada.'];
    if (strlen((string)$n['chave_acesso']) !== 44) return ['ok' => false, 'erro' => 'Esta NFCom não tem chave de acesso válida.'];
    $prazoFim = ws_nfcom_prazo_cancelamento((string)$n['criado_em']);
    if (new DateTime('now', new DateTimeZone('America/Sao_Paulo')) > $prazoFim) return ['ok' => false, 'erro' => 'Prazo de cancelamento encerrado em ' . $prazoFim->format('d/m/Y H:i') . '.'];
    if (trim((string)$n['protocolo']) === '') return ['ok' => false, 'erro' => 'Esta NFCom não tem protocolo de autorização gravado — não dá para cancelar.'];
    $xJust = trim(preg_replace('/\s+/u', ' ', $xJust));
    if (mb_strlen($xJust) < 15) return ['ok' => false, 'erro' => 'Descreva o motivo com pelo menos 15 caracteres.'];
    if (mb_strlen($xJust) > 255) $xJust = mb_substr($xJust, 0, 255);
    $lock = @fopen(WS_CACHE . '/nfcom_cancel_' . $idNf . '.lock', 'c');
    if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) return ['ok' => false, 'erro' => 'O cancelamento desta NFCom já está em andamento.'];
    $r = ws_nfcom_cancelar_chave(ws_nfse_config(), $n['chave_acesso'], $n['protocolo'], $xJust);
    @mkdir(WS_CACHE . '/notas_xml/nfcom', 0750, true);
    @file_put_contents(WS_CACHE . '/notas_xml/nfcom/' . $n['chave_acesso'] . '-cancelamento.json', json_encode(['quando' => date('c'), 'http' => $r['code'], 'cStat' => $r['cStat'], 'justificativa' => $xJust, 'resposta' => $r['raw']], JSON_UNESCAPED_UNICODE));
    if ($r['ok']) {
        $db->prepare("UPDATE ws_nfcom SET status='cancelada', motivo=? WHERE id=?")->execute([mb_substr('Cancelada: ' . $xJust, 0, 250), $idNf]);
        $db->prepare("UPDATE ws_nota SET status='cancelada' WHERE nfcom_id=?")->execute([$idNf]);
        ws_evento($db, (int)$n['cliente_id'], 'nfcom', 'NFCom cancelada');
    }
    if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    return ['ok' => $r['ok'], 'erro' => $r['ok'] ? '' : ($r['motivo'] ?: 'falha ao cancelar'), 'raw' => $r['raw']];
}

/* 14/11/2026: CONSULTA da NFCom pela chave (NFComConsulta, consSitNFCom 1.00; XML como filho direto de nfcomDadosMsg, como o evento). Conferida na SVRS de
   produção: NFCom nº 7 → cStat 100 + nProt; chave inexistente → cStat 217 ("não consta na base"). Usada antes de emitir de novo uma nota cuja tentativa
   anterior ficou sem resposta, para não autorizar duas NFCom da mesma venda. @return array ['code','cStat','motivo','prot','raw'] */
function ws_nfcom_consultar_chave(array $c, string $chave): array {
    [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['code' => 0, 'cStat' => '', 'motivo' => $erroC, 'prot' => '', 'raw' => ''];
    $u = ws_nfcom_urls($c); $ns = 'http://www.portalfiscal.inf.br/nfcom/wsdl/NFComConsulta'; $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $x = '<consSitNFCom xmlns="http://www.portalfiscal.inf.br/nfcom" versao="1.00"><tpAmb>' . $amb . '</tpAmb><xServ>CONSULTAR</xServ><chNFCom>' . ws_nfse_so_num($chave) . '</chNFCom></consSitNFCom>';
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfcomDadosMsg xmlns="' . $ns . '">' . $x . '</nfcomDadosMsg></soap12:Body></soap12:Envelope>';
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['consulta'], $soap, $cert, $pkey, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "' . $ns . '/nfcomConsultaNF"']);
    $cStat = ''; $motivo = ''; $prot = '';
    if ($code >= 200 && $code < 300 && is_string($raw)) {
        $alvo = preg_match('#<retConsSitNFCom[^>]*>.*?(?=<protNFCom|<procEventoNFCom|</retConsSitNFCom>)#s', $raw, $mp) ? $mp[0] : $raw;   // cStat da CONSULTA (não o do protocolo/evento embutido)
        if (preg_match('#<cStat>(\d+)</cStat>#', $alvo, $m)) $cStat = $m[1];
        if (preg_match('#<xMotivo>([^<]*)</xMotivo>#', $alvo, $m)) $motivo = trim(html_entity_decode($m[1], ENT_QUOTES | ENT_XML1, 'UTF-8'));
        if (preg_match('#<nProt>(\d+)</nProt>#', $raw, $m)) $prot = $m[1];
    } elseif ($code === 0) $motivo = 'Sem conexão com a SEFAZ: ' . $err;
    else $motivo = 'HTTP ' . $code;
    return ['code' => $code, 'cStat' => $cStat, 'motivo' => mb_substr($motivo, 0, 250), 'prot' => $prot, 'raw' => (string)$raw];
}
/** Atualiza UMA tentativa de NFCom pela consulta. @return array ['ok' (autorizada),'erro','sem_resposta' (SEFAZ não respondeu: não dá para decidir)] */
function ws_nfcom_consultar(PDO $db, int $idNf): array {
    $st = $db->prepare("SELECT * FROM ws_nfcom WHERE id=?"); $st->execute([$idNf]); $n = $st->fetch(PDO::FETCH_ASSOC);
    if (!$n || strlen((string)$n['chave_acesso']) !== 44) return ['ok' => false, 'erro' => 'Tentativa sem chave de acesso.', 'sem_resposta' => false];
    $r = ws_nfcom_consultar_chave(ws_nfse_config(), (string)$n['chave_acesso']);
    if ($r['cStat'] === '') return ['ok' => false, 'erro' => $r['motivo'] ?: 'a SEFAZ não respondeu', 'sem_resposta' => true];
    $ok = $r['cStat'] === '100'; $arq = 'cache/notas_xml/nfcom/' . $n['chave_acesso'] . '.xml';
    $db->prepare("UPDATE ws_nfcom SET status=?, codigo_status=?, protocolo=COALESCE(?, protocolo), motivo=?, url_xml=COALESCE(?, url_xml), retorno_raw=? WHERE id=?")
       ->execute([$ok ? 'autorizada' : 'erro', $r['cStat'], $r['prot'] !== '' ? $r['prot'] : null, $r['motivo'] ?: null, ($ok && is_file(__DIR__ . '/' . $arq)) ? $arq : null, $r['raw'], $idNf]);
    if ($ok) ws_evento($db, (int)$n['cliente_id'], 'nfcom', 'NFCom autorizada (confirmada por consulta à SEFAZ)');
    return ['ok' => $ok, 'erro' => $ok ? '' : ($r['cStat'] . ' ' . $r['motivo']), 'sem_resposta' => false];
}

/** 13/11/2026: prazo para cancelar NFCom = ATÉ O ÚLTIMO DIA DO MÊS da autorização, 23:59:59 (regra definida pelo dono; as fontes públicas consultadas falam em até 120 horas depois do fim do mês — a SEFAZ continua sendo quem decide, então esta regra é a mais conservadora). Devolve o instante final. */
function ws_nfcom_prazo_cancelamento(string $autorizadaEm): DateTime {
    $d = new DateTime($autorizadaEm ?: 'now', new DateTimeZone('America/Sao_Paulo'));
    return new DateTime($d->format('Y-m-t') . ' 23:59:59', new DateTimeZone('America/Sao_Paulo'));
}
