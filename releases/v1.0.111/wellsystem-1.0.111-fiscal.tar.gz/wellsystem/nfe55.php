<?php
/**
 * WellSystem — NF-e MODELO 55 (venda de produto/equipamento), emissão DIRETA na SEFAZ autorizadora
 * do emissor (sem intermediário pago). Reaproveita o MESMO certificado A1 do NFS-e (nfse_nacional.php):
 * uma empresa, um certificado, duas finalidades.
 *
 * Como funciona:
 *   1. monta o XML da NFe (grupos ide/emit/dest/det/total/transp/pag/infAdic), leiaute 4.00;
 *   2. calcula a chave de acesso (44 dígitos, com dígito verificador módulo 11);
 *   3. assina o grupo infNFe com o certificado do emissor (XMLDSig enveloped, igual ao NFS-e);
 *   4. envia por SOAP 1.2, com mTLS (o mesmo certificado), ao webservice NFeAutorizacao4 da UF do emissor;
 *   5. lê o retorno: cStat 100 = autorizada na hora (síncrono); 103/105 = em lote, precisa consultar depois.
 *
 * Nada aqui é fixo de uma empresa: CFOP, CSOSN, NCM e a natureza da operação vêm da configuração do
 * emissor (Fiscal → Emissor) ou do próprio item da nota — nunca gravados no código.
 *
 * COBERTURA DE UF: hoje só Pernambuco (cUF 26) tem a URL do webservice cadastrada (ws_nfe55_urls).
 * Outra UF cai em erro claro, pedindo para completar a tabela — não falha em silêncio.
 *
 * ATENÇÃO — conferir em HOMOLOGAÇÃO antes de produção: nome exato do elemento de retorno (retEnviNFe x
 * retNFe, conforme indSinc), content-type do SOAP 1.2 aceito pela SEFAZ-PE e se o ambiente de
 * homologação está mesmo nas URLs abaixo (confirmado em consulta à página oficial em 11/11/2026, mas a
 * própria SEFAZ já teve período com link fora do ar).
 */
require_once __DIR__ . '/nfse_nacional.php';   // reaproveita ws_nfsen_certificado(), ws_nfsen_x(), ws_nfsen_assinar_pedido(), ws_nfsen_http()

/** Código da UF (IBGE, 2 dígitos) usado na chave de acesso e para achar o webservice. */
function ws_nfe55_cuf(string $uf): string {
    $t = ['RO'=>'11','AC'=>'12','AM'=>'13','RR'=>'14','PA'=>'15','AP'=>'16','TO'=>'17','MA'=>'21','PI'=>'22','CE'=>'23','RN'=>'24',
          'PB'=>'25','PE'=>'26','AL'=>'27','SE'=>'28','BA'=>'29','MG'=>'31','ES'=>'32','RJ'=>'33','SP'=>'35','PR'=>'41','SC'=>'42',
          'RS'=>'43','MS'=>'50','MT'=>'51','GO'=>'52','DF'=>'53'];
    return $t[strtoupper(trim($uf))] ?? '';
}

/** URLs do webservice NFeAutorizacao4/NFeConsultaProtocolo4 da UF do emissor. SÓ Pernambuco cadastrado (conferido 11/11/2026). */
function ws_nfe55_urls(array $c): array {
    $uf = strtoupper(trim((string)($c['uf'] ?? ''))); $prod = ($c['ambiente'] ?? '') === 'producao';
    $base = ['PE' => ['producao' => 'https://nfe.sefaz.pe.gov.br/nfe-service/services', 'homologacao' => 'https://nfehomolog.sefaz.pe.gov.br/nfe-service/services']];
    if (!isset($base[$uf])) return ['ok' => false, 'erro' => "UF $uf ainda não tem o webservice da NF-e cadastrado nesta instalação (só Pernambuco). Complete em ws_nfe55_urls()."];
    $b = $base[$uf][$prod ? 'producao' : 'homologacao'];
    return ['ok' => true, 'autorizacao' => $b . '/NFeAutorizacao4', 'consulta' => $b . '/NFeConsultaProtocolo4', 'status' => $b . '/NFeStatusServico4', 'evento' => $b . '/NFeRecepcaoEvento4'];
}

/** Dígito verificador módulo 11 (pesos 2..9, da direita para a esquerda; resto 0/1 vira dígito 0). */
function ws_nfe55_dv(string $chave43): int {
    $peso = 2; $soma = 0;
    for ($i = strlen($chave43) - 1; $i >= 0; $i--) { $soma += ((int)$chave43[$i]) * $peso; $peso = $peso === 9 ? 2 : $peso + 1; }
    $r = $soma % 11; return ($r < 2) ? 0 : 11 - $r;
}

/** Monta a chave de acesso de 44 dígitos (cUF+AAMM+CNPJ+mod+serie+nNF+tpEmis+cNF+cDV). */
function ws_nfe55_chave(array $c, int $numero, int $cNF): array {
    $cuf = ws_nfe55_cuf((string)($c['uf'] ?? '')); $cnpj = ws_nfse_so_num($c['cnpj']); $serie = str_pad(ws_nfse_so_num($c['nfe_serie'] ?: '1'), 3, '0', STR_PAD_LEFT);
    $aamm = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('ym');
    $cNFs = str_pad((string)$cNF, 8, '0', STR_PAD_LEFT);
    $chave43 = $cuf . $aamm . $cnpj . '55' . $serie . str_pad((string)$numero, 9, '0', STR_PAD_LEFT) . '1' . $cNFs;
    return [$chave43 . ws_nfe55_dv($chave43), $serie];
}

/** Próximo número de NF-e (contador com trava, guardado na configuração — mesmo padrão do nfsen_proximo). */
/** 12/11/2026: contador SEPARADO por ambiente — testar em homologação nunca pode consumir (nem colidir com) número de produção.
 *  'nfe_proximo' (produção) e 'nfe_proximo_homolog' (homologação) são independentes. */
function ws_nfe55_proximo_numero(): int {
    $c = ws_nfse_config(); $prod = (($c['ambiente'] ?? '') === 'producao');
    $chave = $prod ? 'nfe_proximo' : 'nfe_proximo_homolog';
    $arq = WS_CACHE . '/nfe55_seq_' . ($prod ? 'prod' : 'homolog') . '.lock'; $fp = @fopen($arq, 'c+'); if (!$fp) return (int)(microtime(true) * 10) % 999999999;
    flock($fp, LOCK_EX); $n = max(1, (int)($c[$chave] ?? 1));
    ws_nfse_salvar([$chave => $n + 1]); flock($fp, LOCK_UN); fclose($fp); return $n;
}

/** 14/11/2026 (nota 57 da NFCom, vale igual na NF-e): texto do XML só aceita Latin-1 — travessão (—), emoji etc. fazem a SEFAZ rejeitar (cStat 215). Troca travessão por hífen, tira o que está fora do Latin-1, junta espaços e corta pontuação solta nas pontas. */
function ws_nfe55_txt($s, int $max = 60): string {
    $s = str_replace(["\u{2013}", "\u{2014}", "\u{2212}"], '-', (string)$s);
    $s = preg_replace('/[^\x{20}-\x{7E}\x{A0}-\x{FF}]/u', ' ', $s) ?? '';
    $s = trim(preg_replace('/\s+/u', ' ', $s));
    $s = trim($s, " -,;.");
    return rtrim(mb_substr($s, 0, $max));
}

/** Monta e ASSINA a NFe. @return array [xml, chave, id] */
function ws_nfe55_montar(array $c, array $itens, array $cli, string $obs, string $certPem, string $pkeyPem, ?int $numeroReusar = null): array {
    $cnpj = ws_nfse_so_num($c['cnpj']); $mun = ws_nfse_so_num($c['cod_ibge']); $numero = ($numeroReusar !== null && $numeroReusar > 0) ? $numeroReusar : ws_nfe55_proximo_numero();   // 14/11/2026: nota rejeitada reenvia com o MESMO número
    $cNF = random_int(10000000, 99999999);
    [$chave, $serie] = ws_nfe55_chave($c, $numero, $cNF);
    $id = 'NFe' . $chave;
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $simples = ws_regime_simples($c);   // simples e MEI

    $ide = '<ide><cUF>' . ws_nfe55_cuf((string)$c['uf']) . '</cUF><cNF>' . str_pad((string)$cNF, 8, '0', STR_PAD_LEFT) . '</cNF>'
         . '<natOp>' . ws_nfsen_x($c['nfe_natureza'] ?: 'VENDA') . '</natOp><mod>55</mod><serie>' . ltrim($serie, '0') . '</serie><nNF>' . $numero . '</nNF>'
         . '<dhEmi>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEmi><tpNF>1</tpNF><idDest>' . (strtoupper(trim((string)(($cli['uf'] ?? '') !== '' ? $cli['uf'] : $c['uf']))) === strtoupper(trim((string)$c['uf'])) ? '1' : '2') . '</idDest>'
         . '<cMunFG>' . $mun . '</cMunFG><tpImp>1</tpImp><tpEmis>1</tpEmis><cDV>' . substr($chave, -1) . '</cDV><tpAmb>' . $amb . '</tpAmb>'
         . '<finNFe>1</finNFe><indFinal>1</indFinal><indPres>1</indPres><indIntermed>0</indIntermed><procEmi>0</procEmi><verProc>WellSystem</verProc></ide>';

    $endEmit = '<enderEmit><xLgr>' . ws_nfsen_x($c['logradouro']) . '</xLgr><nro>' . ws_nfsen_x($c['numero'] ?: 'S/N') . '</nro><xBairro>' . ws_nfsen_x($c['bairro'] ?: 'Centro') . '</xBairro>'
         . '<cMun>' . $mun . '</cMun><xMun>' . ws_nfsen_x($c['cidade']) . '</xMun><UF>' . ws_nfsen_x($c['uf']) . '</UF><CEP>' . ws_nfse_so_num($c['cep']) . '</CEP>'
         . '<cPais>1058</cPais><xPais>BRASIL</xPais>' . (trim((string)$c['telefone']) !== '' ? '<fone>' . ws_nfse_so_num($c['telefone']) . '</fone>' : '') . '</enderEmit>';
    $emit = '<emit><CNPJ>' . $cnpj . '</CNPJ><xNome>' . ws_nfsen_x($c['razao_social']) . '</xNome>' . $endEmit
          . '<IE>' . ws_nfse_so_num($c['inscricao_estadual']) . '</IE><CRT>' . ($simples ? '1' : '3') . '</CRT></emit>';

    $docT = ws_nfse_so_num($cli['cpf_cnpj'] ?? ''); $tagDoc = strlen($docT) === 14 ? 'CNPJ' : 'CPF';
    $cMunT = ws_nfse_so_num($cli['cod_ibge'] ?? ($cli['ibge'] ?? '')) ?: $mun; $cepT = ws_nfse_so_num($cli['cep'] ?? '');
    $endDest = ($cepT !== '' && trim((string)($cli['logradouro'] ?? '')) !== '')
        ? '<enderDest><xLgr>' . ws_nfsen_x(ws_nfe55_txt($cli['logradouro'], 60) ?: 'NAO INFORMADO') . '</xLgr><nro>' . ws_nfsen_x(ws_nfe55_txt($cli['numero'] ?? '', 60) !== '' ? ws_nfe55_txt($cli['numero'], 60) : 'S/N') . '</nro>'
          . '<xBairro>' . ws_nfsen_x(ws_nfe55_txt($cli['bairro'] ?? '', 60) ?: 'Centro') . '</xBairro><cMun>' . $cMunT . '</cMun><xMun>' . ws_nfsen_x(ws_nfe55_txt(preg_replace('/\s*[,\/-]\s*[A-Za-z]{2}$/', '', (string)($cli['cidade'] ?? '')) ?: $c['cidade'], 60)) . '</xMun>'
          . '<UF>' . ws_nfsen_x($cli['uf'] ?? $c['uf']) . '</UF><CEP>' . $cepT . '</CEP><cPais>1058</cPais><xPais>BRASIL</xPais></enderDest>' : '';
    /* 14/11/2026 (nota 57 da NFCom): destinatário CNPJ com IE cadastrada (rg_ie, só dígitos, até 14) sai indIEDest=1 + <IE> (sem ela a SEFAZ rejeita contribuinte: "IE do destinatário não informada"); sem IE segue 9. */
    $ieN = ws_nfse_so_num($cli['rg_ie'] ?? ''); $indIEnfe = (strlen($docT) === 14 && $ieN !== '' && strlen($ieN) <= 14) ? '<indIEDest>1</indIEDest><IE>' . $ieN . '</IE>' : '<indIEDest>9</indIEDest>';
    $dest = '<dest><' . $tagDoc . '>' . $docT . '</' . $tagDoc . '><xNome>' . ws_nfsen_x($amb === 2 ? 'NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL' : ws_nfe55_txt($cli['nome'], 60)) . '</xNome>' . $endDest
          . $indIEnfe . (trim((string)($cli['email'] ?? '')) !== '' ? '<email>' . ws_nfsen_x($cli['email']) . '</email>' : '') . '</dest>';

    $pctTrib = (float)($c['pct_trib_nfe'] ?? 4); $vTotTrib = 0.0;   // 12/11: percentual aproximado de tributos informado pelo contador (venda = 4%); só informativo, o ICMS segue zerado no Simples
    $det = ''; $vProd = 0.0; $vDesc = 0.0; $n = 0;
    foreach ($itens as $it) {
        $n++; $qtd = (float)$it['qtd']; $unit = (float)$it['valor_unit']; $sub = round($qtd * $unit, 2); $vProd += $sub; $vDesc += (float)$it['desconto'];
        $ncm = ws_nfse_so_num($it['ncm'] ?? '') ?: ws_nfse_so_num($c['nfe_ncm_padrao'] ?? '');
        $cfop = ws_nfse_so_num($it['cfop'] ?? '') ?: ws_nfse_so_num($c['nfe_cfop'] ?? '5102');
        $csosn = ws_nfse_so_num($it['csosn'] ?? '') ?: ws_nfse_so_num($c['nfe_csosn'] ?? '400');
        $cest = ws_nfse_so_num($it['cest'] ?? '') ?: ws_nfse_so_num($c['nfe_cest_padrao'] ?? '');
        $un = ws_nfsen_x($it['unidade'] ?? 'UN');
        $vtItem = round($sub * $pctTrib / 100, 2); $vTotTrib += $vtItem;
        $icmsXml = $simples
            ? '<ICMS><ICMSSN102><orig>0</orig><CSOSN>' . $csosn . '</CSOSN></ICMSSN102></ICMS>'
            : '<ICMS><ICMS00><orig>0</orig><CST>00</CST><modBC>3</modBC><vBC>' . ws_nfsen_dec($sub) . '</vBC><pICMS>0.00</pICMS><vICMS>0.00</vICMS></ICMS00></ICMS>';
        $det .= '<det nItem="' . $n . '"><prod><cProd>' . $n . '</cProd><cEAN>SEM GTIN</cEAN><xProd>' . ws_nfsen_x(ws_nfe55_txt($it['descricao'] ?? '', 120) ?: 'Produto') . '</xProd>'
              . '<NCM>' . ($ncm ?: '00000000') . '</NCM>' . ($cest !== '' ? '<CEST>' . $cest . '</CEST>' : '') . '<CFOP>' . $cfop . '</CFOP>'
              . '<uCom>' . $un . '</uCom><qCom>' . ws_nfe55_dec3($qtd) . '</qCom><vUnCom>' . ws_nfe55_dec4($unit) . '</vUnCom><vProd>' . ws_nfsen_dec($sub) . '</vProd>'
              . '<cEANTrib>SEM GTIN</cEANTrib><uTrib>' . $un . '</uTrib><qTrib>' . ws_nfe55_dec3($qtd) . '</qTrib><vUnTrib>' . ws_nfe55_dec4($unit) . '</vUnTrib><indTot>1</indTot></prod>'
              . '<imposto><vTotTrib>' . ws_nfsen_dec($vtItem) . '</vTotTrib>' . $icmsXml
              . '<PIS><PISOutr><CST>49</CST><vBC>0.00</vBC><pPIS>0.00</pPIS><vPIS>0.00</vPIS></PISOutr></PIS>'
              . '<COFINS><COFINSOutr><CST>49</CST><vBC>0.00</vBC><pCOFINS>0.00</pCOFINS><vCOFINS>0.00</vCOFINS></COFINSOutr></COFINS>'
              . '</imposto></det>';
    }
    $vNF = max(0, round($vProd - $vDesc, 2));
    $total = '<total><ICMSTot><vBC>0.00</vBC><vICMS>0.00</vICMS><vICMSDeson>0.00</vICMSDeson><vFCP>0.00</vFCP><vBCST>0.00</vBCST><vST>0.00</vST>'
           . '<vFCPST>0.00</vFCPST><vFCPSTRet>0.00</vFCPSTRet><vProd>' . ws_nfsen_dec($vProd) . '</vProd><vFrete>0.00</vFrete><vSeg>0.00</vSeg>'
           . '<vDesc>' . ws_nfsen_dec($vDesc) . '</vDesc><vII>0.00</vII><vIPI>0.00</vIPI><vIPIDevol>0.00</vIPIDevol><vPIS>0.00</vPIS><vCOFINS>0.00</vCOFINS>'
           . '<vOutro>0.00</vOutro><vNF>' . ws_nfsen_dec($vNF) . '</vNF><vTotTrib>' . ws_nfsen_dec($vTotTrib) . '</vTotTrib></ICMSTot></total>';
    $transp = '<transp><modFrete>9</modFrete></transp>';
    $pag = '<pag><detPag><indPag>0</indPag><tPag>99</tPag><xPag>Outros</xPag><vPag>' . ws_nfsen_dec($vNF) . '</vPag></detPag></pag>';
    $txtTrib = 'Valor aproximado dos tributos: R$ ' . number_format($vTotTrib, 2, ',', '.') . ' (' . number_format($pctTrib, 2, ',', '.') . '%).';
    $info = '<infAdic><infCpl>' . ws_nfsen_x(mb_substr(trim(trim($obs) !== '' ? trim($obs) . ' ' . $txtTrib : $txtTrib), 0, 2000)) . '</infCpl></infAdic>';

    // Responsável técnico (SEFAZ-PE rejeita sem ele, cStat 972): o próprio emissor, com os dados do cadastro do Emissor.
    $fonR = ws_nfse_so_num($c['telefone'] ?? ''); $mailR = trim((string)($c['email'] ?? ''));
    $respTec = '<infRespTec><CNPJ>' . $cnpj . '</CNPJ><xContato>' . ws_nfsen_x(mb_substr(trim((string)$c['razao_social']), 0, 60)) . '</xContato>' . ($mailR !== '' ? '<email>' . ws_nfsen_x($mailR) . '</email>' : '') . (strlen($fonR) >= 6 ? '<fone>' . substr($fonR, 0, 14) . '</fone>' : '') . '</infRespTec>';
    $xml = '<NFe xmlns="http://www.portalfiscal.inf.br/nfe"><infNFe Id="' . $id . '" versao="4.00">'
         . $ide . $emit . $dest . $det . $total . $transp . $pag . $info . $respTec . '</infNFe></NFe>';
    return [ws_nfsen_assinar_pedido($xml, 'infNFe', $id, array_merge($c, ['nfsen_algoritmo' => 'sha1']), $certPem, $pkeyPem), $chave, $id];
}

function ws_nfe55_dec3($v): string { return number_format((float)$v, 4, '.', ''); }   // qCom/qTrib: até 4 casas (NFe aceita menos; 4 cobre tudo)
function ws_nfe55_dec4($v): string { return number_format((float)$v, 4, '.', ''); }   // vUnCom/vUnTrib: até 10 casas; 4 é o comum em venda de equipamento

/** Envelopa em SOAP 1.2 e envia ao webservice (mTLS com o mesmo A1). */
function ws_nfe55_enviar(string $xmlNFeAssinada, string $chave, array $c, string $certPem, string $pkeyPem): array {
    $u = ws_nfe55_urls($c); if (!$u['ok']) return [0, null, $u['erro']];
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $envi = '<enviNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00"><idLote>' . substr(str_replace('.', '', (string)microtime(true)), 0, 15) . '</idLote><indSinc>1</indSinc>' . $xmlNFeAssinada . '</enviNFe>';
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">'
          . '<soap12:Header><nfeCabecMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4"><cUF>' . ws_nfe55_cuf((string)$c['uf']) . '</cUF><versaoDados>4.00</versaoDados></nfeCabecMsg></soap12:Header>'
          . '<soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4">' . $envi . '</nfeDadosMsg></soap12:Body></soap12:Envelope>';
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['autorizacao'], $soap, $certPem, $pkeyPem, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4/nfeAutorizacaoLote"']);
    return [$code, $raw, $err];
}

/** Emite a NF-e 55. Mesmo contrato das demais: ['ok','erro','raw','nfe55_id']. */
function ws_nfe55_emitir(PDO $db, array $notaRef, array $cliente, array $itens, string $obs = ''): array {
    $c = ws_nfse_config();
    foreach ($itens as $it) if (($it['tipo'] ?? 'servico') !== 'produto')
        return ['ok' => false, 'erro' => 'NF-e é só para PRODUTO. Há item de serviço na nota: separe o serviço (precisa de NFS-e) ou remova-o.'];
    if (!$itens) return ['ok' => false, 'erro' => 'Inclua ao menos um item.'];
    foreach (['cnpj' => 'CNPJ', 'inscricao_estadual' => 'Inscrição Estadual', 'cod_ibge' => 'código IBGE do município', 'uf' => 'UF'] as $k => $rot)
        if (trim((string)($c[$k] ?? '')) === '') return ['ok' => false, 'erro' => 'Configure a ' . $rot . ' em Fiscal → Emissor.'];
    if (ws_nfe55_cuf((string)$c['uf']) === '') return ['ok' => false, 'erro' => 'UF do emissor inválida: ' . $c['uf']];
    $u = ws_nfe55_urls($c); if (!$u['ok']) return ['ok' => false, 'erro' => $u['erro']];
    [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c);
    if (!$okC) return ['ok' => false, 'erro' => $erroC];
    /* 14/11/2026 (nota 57 da NFCom, vale igual aqui): REJEIÇÃO da SEFAZ não consome o número. Reenviar a mesma nota refaz a tentativa com o MESMO número e a MESMA linha. Não reaproveita:
       duplicidade (204/539), denegação (110/301/302), lote em processamento (103/105), tentativa sem resposta (codigo_status vazio: quem trata é ws_nota_tentativa_pendente) nem número
       que aparece em outra linha autorizada/processando/cancelada. */
    $reId = 0; $reNum = null;
    if (!empty($notaRef['id'])) { try {
        $qa = $db->prepare("SELECT id, numero FROM ws_nfe55 WHERE nota_id=? AND status='erro' AND codigo_status IS NOT NULL AND codigo_status NOT IN ('100','103','105','110','150','204','301','302','539') AND numero > 0 ORDER BY id DESC LIMIT 1");
        $qa->execute([(int)$notaRef['id']]); $ant = $qa->fetch(PDO::FETCH_ASSOC);
        if ($ant) { $qb = $db->prepare("SELECT COUNT(*) FROM ws_nfe55 WHERE numero=? AND id<>? AND status IN ('autorizada','processando','cancelada')"); $qb->execute([(int)$ant['numero'], (int)$ant['id']]);
            if ((int)$qb->fetchColumn() === 0) { $reId = (int)$ant['id']; $reNum = (int)$ant['numero']; } }
    } catch (Throwable $e) {} }
    [$xml, $chave] = ws_nfe55_montar($c, $itens, $cliente, $obs, $cert, $pkey, $reNum);
    $valor = 0.0; foreach ($itens as $it) $valor += max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
    if ($reId > 0) {
        $db->prepare("UPDATE ws_nfe55 SET cliente_id=?, valor=?, status='processando', serie=?, chave_acesso=?, protocolo=NULL, codigo_status=NULL, motivo=NULL, url_xml=NULL, retorno_raw=NULL WHERE id=?")
           ->execute([$cliente['id'], round($valor, 2), ws_nfse_so_num($c['nfe_serie'] ?: '1'), $chave, $reId]);
        $id55 = $reId;
    } else {
        $db->prepare("INSERT INTO ws_nfe55 (nota_id,cliente_id,valor,status,serie,chave_acesso) VALUES (?,?,?, 'processando', ?, ?)")
           ->execute([$notaRef['id'] ?? null, $cliente['id'], round($valor, 2), ws_nfse_so_num($c['nfe_serie'] ?: '1'), $chave]);
        $id55 = (int)$db->lastInsertId();
    }
    [$code, $raw, $err] = ws_nfe55_enviar($xml, $chave, $c, $cert, $pkey);
    $ok = false; $cStat = ''; $motivo = ''; $protocolo = '';
    if ($code >= 200 && $code < 300 && is_string($raw)) {
        $alvo = $raw; if (preg_match('#<infProt[^>]*>.*?</infProt>#s', $raw, $mp)) $alvo = $mp[0];   // resposta do lote (104) traz o resultado da NOTA dentro de protNFe/infProt
        if (preg_match('#<cStat>(\d+)</cStat>#', $alvo, $m)) $cStat = $m[1];
        if (preg_match('#<xMotivo>([^<]*)</xMotivo>#', $alvo, $m)) $motivo = html_entity_decode($m[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
        if (preg_match('#<nProt>([^<]*)</nProt>#', $alvo, $m)) $protocolo = $m[1];
        $ok = ($cStat === '100');   // 100 = Autorizado o uso da NF-e (resposta síncrona, indSinc=1)
        if (!$ok && in_array($cStat, ['103', '105'], true)) $motivo = 'Lote em processamento (' . $cStat . ' ' . $motivo . '): consulte o protocolo depois (ws_nfe55_consultar).';
    } elseif ($code === 0) $motivo = 'Sem conexão com a SEFAZ: ' . $err;
    else $motivo = 'HTTP ' . $code . ': ' . substr((string)$raw, 0, 300);
    $numero = null; if (preg_match('#<nNF>(\d+)</nNF>#', $xml, $m)) $numero = (int)$m[1];
    $motivo = mb_substr((string)$motivo, 0, 250);   // coluna é VARCHAR(255): resposta longa da SEFAZ derrubava a gravação
    @mkdir(WS_CACHE . '/notas_xml/nfe', 0750, true);
    @file_put_contents(WS_CACHE . '/notas_xml/nfe/' . $chave . '.xml', $xml);
    $db->prepare("UPDATE ws_nfe55 SET status=?, numero=?, codigo_status=?, protocolo=?, motivo=?, url_xml=?, retorno_raw=? WHERE id=?")
       ->execute([$ok ? 'autorizada' : (in_array($cStat, ['103', '105'], true) ? 'processando' : 'erro'), $numero, $cStat ?: null, $protocolo ?: null, $motivo ?: null,
                  $ok ? 'cache/notas_xml/nfe/' . $chave . '.xml' : null, (string)$raw, $id55]);
    ws_evento($db, (int)$cliente['id'], 'nfe', $ok ? 'NF-e autorizada' : 'NF-e: ' . ($motivo ?: 'falha ao emitir'));
    return ['ok' => $ok, 'erro' => $ok ? '' : $motivo, 'raw' => $raw, 'nfe55_id' => $id55];
}

/** Consulta o protocolo de uma NF-e enviada em lote (cStat 103/105) que ainda não voltou síncrona. */
function ws_nfe55_consultar(PDO $db, int $id55): array {
    $st = $db->prepare("SELECT * FROM ws_nfe55 WHERE id=?"); $st->execute([$id55]); $n = $st->fetch();
    if (!$n) return ['ok' => false, 'erro' => 'Registro não encontrado.'];
    $c = ws_nfse_config(); [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['ok' => false, 'erro' => $erroC];
    $u = ws_nfe55_urls($c); if (!$u['ok']) return ['ok' => false, 'erro' => $u['erro']];
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $cons = '<consSitNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00"><tpAmb>' . $amb . '</tpAmb><xServ>CONSULTAR</xServ><chNFe>' . $n['chave_acesso'] . '</chNFe></consSitNFe>';
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">'
          . '<soap12:Header><nfeCabecMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4"><cUF>' . ws_nfe55_cuf((string)$c['uf']) . '</cUF><versaoDados>4.00</versaoDados></nfeCabecMsg></soap12:Header>'
          . '<soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4">' . $cons . '</nfeDadosMsg></soap12:Body></soap12:Envelope>';
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['consulta'], $soap, $cert, $pkey, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4/nfeConsultaNF"']);
    if ($code < 200 || $code >= 300 || !is_string($raw)) return ['ok' => false, 'erro' => $code === 0 ? ('Sem conexão: ' . $err) : ('HTTP ' . $code)];
    $cStat = ''; $motivo = ''; $protocolo = '';
    if (preg_match('#<cStat>(\d+)</cStat>#', $raw, $m)) $cStat = $m[1];
    if (preg_match('#<xMotivo>([^<]*)</xMotivo>#', $raw, $m)) $motivo = $m[1];
    if (preg_match('#<nProt>([^<]*)</nProt>#', $raw, $m)) $protocolo = $m[1];
    $ok = ($cStat === '100');
    $arqXml = 'cache/notas_xml/nfe/' . $n['chave_acesso'] . '.xml';   // 14/11/2026: autorizada pela consulta também aponta o XML (sem isso o DANFE não abria)
    $db->prepare("UPDATE ws_nfe55 SET status=?, codigo_status=?, protocolo=?, motivo=?, retorno_raw=?, url_xml=COALESCE(?, url_xml) WHERE id=?")
       ->execute([$ok ? 'autorizada' : ($cStat === '101' || $cStat === '151' ? 'cancelada' : 'erro'), $cStat ?: null, $protocolo ?: null, $motivo ?: null, (string)$raw, ($ok && is_file(__DIR__ . '/' . $arqXml)) ? $arqXml : null, $id55]);
    return ['ok' => $ok, 'erro' => $ok ? '' : $motivo, 'raw' => $raw];
}

/* ------------------------------------------------------------------------------------------------------------------
 * CANCELAMENTO da NF-e 55 (evento 110111) — 11/11/2026. Leiaute conferido contra 2 exemplos independentes de
 * bibliotecas abertas: Id = "ID" + tpEvento(110111) + chNFe(44) + nSeqEvento(2 dígitos); ordem dos campos:
 * cOrgao, tpAmb, CNPJ, chNFe, dhEvento, tpEvento, nSeqEvento, verEvento, detEvento(versao=1.00)>descEvento,nProt,xJust.
 * Envio: POST {sefaz}/NFeRecepcaoEvento4 com envEvento (idLote + evento assinado). Só pode cancelar até o prazo
 * da SEFAZ (normalmente 24h; a própria Sefaz recusa se passou do prazo — não verificamos isso aqui).
 * ------------------------------------------------------------------------------------------------------------------ */

/** Monta e ASSINA o evento de cancelamento da NF-e. @return array [xml, id] */
function ws_nfe55_montar_cancelamento(array $c, string $chave, string $nProt, string $xJust, string $certPem, string $pkeyPem): array {
    $cnpj = ws_nfse_so_num($c['cnpj']); $chave = ws_nfse_so_num($chave); $nSeq = '01';
    $id = 'ID' . '110111' . $chave . $nSeq;
    $xJust = trim(preg_replace('/\s+/u', ' ', (string)preg_replace('/[\x00-\x1F\x7F]/u', ' ', $xJust)));
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    // "evento" é a raiz: a Signature (enveloped) entra como IRMà de infEvento, dentro de evento — nunca filha de infEvento (schema oficial).
    $xml = '<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00"><infEvento Id="' . $id . '">'
         . '<cOrgao>' . ws_nfe55_cuf((string)$c['uf']) . '</cOrgao><tpAmb>' . $amb . '</tpAmb><CNPJ>' . $cnpj . '</CNPJ><chNFe>' . $chave . '</chNFe>'
         . '<dhEvento>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEvento><tpEvento>110111</tpEvento><nSeqEvento>' . (int)$nSeq . '</nSeqEvento><verEvento>1.00</verEvento>'
         . '<detEvento versao="1.00"><descEvento>Cancelamento</descEvento><nProt>' . ws_nfse_so_num($nProt) . '</nProt><xJust>' . ws_nfsen_x($xJust) . '</xJust></detEvento>'
         . '</infEvento></evento>';
    return [ws_nfsen_assinar_pedido($xml, 'infEvento', $id, array_merge($c, ['nfsen_algoritmo' => 'sha1']), $certPem, $pkeyPem), $id];
}

/** Cancela uma NF-e AUTORIZADA. Devolve ['ok','erro','raw']. Só marca 'cancelada' se a Sefaz aceitar (cStat 135/136). */
function ws_nfe55_cancelar(PDO $db, int $id55, string $xJust): array {
    $st = $db->prepare("SELECT * FROM ws_nfe55 WHERE id=?"); $st->execute([$id55]); $n = $st->fetch();
    if (!$n) return ['ok' => false, 'erro' => 'Registro não encontrado.'];
    if ($n['status'] === 'cancelada') return ['ok' => false, 'erro' => 'Esta NF-e já está cancelada.'];
    if ($n['status'] !== 'autorizada') return ['ok' => false, 'erro' => 'Só NF-e autorizada pode ser cancelada.'];
    if (strlen((string)$n['chave_acesso']) !== 44) return ['ok' => false, 'erro' => 'Esta NF-e não tem chave de acesso válida.'];
    if (trim((string)$n['protocolo']) === '') return ['ok' => false, 'erro' => 'Esta NF-e não tem número de protocolo de autorização gravado — não dá para cancelar.'];
    $xJust = trim(preg_replace('/\s+/u', ' ', $xJust));
    if (mb_strlen($xJust) < 15) return ['ok' => false, 'erro' => 'Descreva o motivo com pelo menos 15 caracteres.'];
    if (mb_strlen($xJust) > 255) $xJust = mb_substr($xJust, 0, 255);
    $c = ws_nfse_config(); [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['ok' => false, 'erro' => $erroC];
    $u = ws_nfe55_urls($c); if (!$u['ok']) return ['ok' => false, 'erro' => $u['erro']];
    $lock = @fopen(WS_CACHE . '/nfe55_cancel_' . $id55 . '.lock', 'c');
    if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) return ['ok' => false, 'erro' => 'O cancelamento desta NF-e já está em andamento.'];
    [$xmlAssinado, $idEvt] = ws_nfe55_montar_cancelamento($c, $n['chave_acesso'], $n['protocolo'], $xJust, $cert, $pkey);
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $envi = '<envEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00"><idLote>' . substr(str_replace('.', '', (string)microtime(true)), 0, 15) . '</idLote>'
          . $xmlAssinado . '</envEvento>';   // $xmlAssinado já é o <evento>...</evento> completo (infEvento + Signature como irmãos)
    $soap = '<?xml version="1.0" encoding="UTF-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">'
          . '<soap12:Header><nfeCabecMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4"><cUF>' . ws_nfe55_cuf((string)$c['uf']) . '</cUF><versaoDados>1.00</versaoDados></nfeCabecMsg></soap12:Header>'
          . '<soap12:Body><nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4">' . $envi . '</nfeDadosMsg></soap12:Body></soap12:Envelope>';
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['evento'], $soap, $cert, $pkey, ['Content-Type: application/soap+xml; charset=utf-8', 'SOAPAction: "http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4/nfeRecepcaoEvento"']);
    $ok = false; $cStat = ''; $motivo = '';
    if ($code >= 200 && $code < 300 && is_string($raw)) {
        if (preg_match('#<cStat>(\d+)</cStat>(?!.*<cStat>)#s', $raw, $m)) $cStat = $m[1];   // cStat do retEvento (o último da resposta)
        if (preg_match('#<xMotivo>([^<]*)</xMotivo>(?!.*<xMotivo>)#s', $raw, $m)) $motivo = $m[1];
        $ok = in_array($cStat, ['135', '136'], true);   // 135 = evento registrado e vinculado; 136 = registrado mas não vinculado (mesmo assim é cancelamento aceito)
    } elseif ($code === 0) $motivo = 'Sem conexão com a SEFAZ: ' . $err;
    else $motivo = 'HTTP ' . $code . ': ' . substr((string)$raw, 0, 300);
    @file_put_contents(WS_CACHE . '/notas_xml/nfe/' . $n['chave_acesso'] . '-cancelamento.json', json_encode(['quando' => date('c'), 'http' => $code, 'justificativa' => $xJust, 'resposta' => (string)$raw], JSON_UNESCAPED_UNICODE));
    if ($ok) {
        $db->prepare("UPDATE ws_nfe55 SET status='cancelada', motivo=? WHERE id=?")->execute(['Cancelada: ' . $xJust, $id55]);
        $db->prepare("UPDATE ws_nota SET status='cancelada' WHERE nfe55_id=?")->execute([$id55]);
        ws_evento($db, (int)$n['cliente_id'], 'nfe', 'NF-e cancelada');
    }
    if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    return ['ok' => $ok, 'erro' => $ok ? '' : $motivo, 'raw' => $raw];
}
