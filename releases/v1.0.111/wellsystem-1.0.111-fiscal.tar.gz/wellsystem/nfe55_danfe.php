<?php
/**
 * WellSystem — DANFE (documento auxiliar da NF-e modelo 55) em PDF, gerado no próprio servidor.
 * Reaproveita o mesmo motor de PDF e QR Code do boleto (boleto_pdf.php: classe WsPdf, ws_qr_matriz) —
 * sem lib nova, sem Composer, sem nada instalado no Linux.
 *
 * O código de barras exigido no DANFE modelo 55 é o CODE 128 subset C (numérico, 2 dígitos por
 * símbolo) com a chave de acesso de 44 dígitos. A tabela de larguras abaixo é a tabela padrão
 * ISO/IEC 15417 (conferida em 11/11/2026 contra a Wikipédia em inglês, com checagem cruzada
 * binário→largura em 4 valores de amostra — NÃO foi impressa e lida por leitor de código de
 * barras de verdade ainda: ISSO FICA PENDENTE antes de confiar no documento em produção).
 *
 * O leiaute (caixas, textos, posições) segue o padrão GERAL do "DANFE Normal" retrato (manual do
 * contribuinte), mas NÃO foi conferido milímetro a milímetro contra o manual oficial — é um
 * documento auxiliar funcional e legível, não uma cópia certificada do leiaute. Para a nota que
 * vale de verdade perante o Fisco, o que importa é a NF-e autorizada (XML); o DANFE só facilita o
 * transporte/conferência da mercadoria.
 */
require_once __DIR__ . '/boleto_pdf.php';
require_once __DIR__ . '/nfse_nacional.php';
require_once __DIR__ . '/pix.php';
require_once __DIR__ . '/nfse.php';

/** Banco/PIX a usar: o do contrato da fatura vinculada à nota; sem fatura, o banco padrão com PIX ativo (mesma regra do boleto). */
function ws_danfe_banco(PDO $db, ?int $faturaId): ?array {
    if ($faturaId) {
        $st = $db->prepare("SELECT b.* FROM ws_fatura f JOIN ws_contrato ct ON ct.id=f.contrato_id JOIN ws_banco b ON b.id=ct.banco_id WHERE f.id=? AND b.ativo=1 AND b.pix<>''");
        $st->execute([$faturaId]); $b = $st->fetch(PDO::FETCH_ASSOC); if ($b) return $b;
    }
    $b = $db->query("SELECT * FROM ws_banco WHERE ativo=1 AND pix IS NOT NULL AND pix<>'' ORDER BY id LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    return $b ?: null;
}

/** Tabela ISO/IEC 15417 — valor (0..106) => largura de 6 elementos (barra,espaço,barra,espaço,barra,espaço), em módulos 1..4. */
function ws_c128_larguras(): array {
    static $t = null; if ($t !== null) return $t;
    $t = [
        '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213',
        '221312','231212','112232','122132','122231','113222','123122','123221','223211','221132',
        '221231','213212','223112','312131','311222','321122','321221','312212','322112','322211',
        '212123','212321','232121','111323','131123','131321','112313','132113','132311','211313',
        '231113','231311','112133','112331','132131','113123','113321','133121','313121','211331',
        '231131','213113','213311','213131','311123','311321','331121','312113','312311','332111',
        '314111','221411','431111','111224','111422','121124','121421','141122','141221','112214',
        '112412','122114','122411','142112','142211','241211','221114','413111','241112','134111',
        '111242','121142','121241','114212','124112','124211','411212','421112','421211','212141',
        '214121','412121','111143','111341','131141','114113','114311','411113','411311','113141',
        '114131','311141','411131','211412','211214','211232','233111',
    ];
    return $t;
}

/** Monta os VALORES (0..102) do Code 128 Subset C a partir de uma string de dígitos PARES; completa com zero à esquerda se for ímpar. */
function ws_c128c_valores(string $digitos): array {
    $d = preg_replace('/\D/', '', $digitos); if (strlen($d) % 2) $d = '0' . $d;
    $v = []; for ($i = 0; $i < strlen($d); $i += 2) $v[] = (int)substr($d, $i, 2);
    return $v;
}

/** Desenha o código de barras Code128C (Start C + dados + checksum mod 103 + Stop) usando retângulos (igual ao barras_i25 do boleto). */
function ws_c128c_desenhar(WsPdf $pdf, float $x, float $y, float $altura, string $digitos, float $modulo = 0.33): void {
    $larg = ws_c128_larguras();
    $valores = ws_c128c_valores($digitos);
    $START_C = 105; $STOP = 106;
    $soma = $START_C; foreach ($valores as $i => $v) $soma += $v * ($i + 1);
    $checksum = $soma % 103;
    $simbolos = array_merge([$START_C], $valores, [$checksum]);
    $xAtual = $x;
    foreach ($simbolos as $s) {
        $w = $larg[$s]; $escuro = true;
        for ($k = 0; $k < 6; $k++) {
            $mod = (int)$w[$k];
            if ($escuro) $pdf->retangulo($xAtual, $y, $mod * $modulo, $altura, true, 0);
            $xAtual += $mod * $modulo; $escuro = !$escuro;
        }
    }
    // STOP: 233111 (6 elementos) + barra final de 2 módulos (13 módulos no total do stop)
    $w = $larg[$STOP]; $escuro = true;
    for ($k = 0; $k < 6; $k++) { $mod = (int)$w[$k]; if ($escuro) $pdf->retangulo($xAtual, $y, $mod * $modulo, $altura, true, 0); $xAtual += $mod * $modulo; $escuro = !$escuro; }
    $pdf->retangulo($xAtual, $y, 2 * $modulo, $altura, true, 0);
}

/** Lê o XML autorizado da NF-e e devolve os dados já organizados para o DANFE. */
function ws_danfe_ler_xml(string $caminhoRelativo): ?array {
    $fis = __DIR__ . '/' . ltrim($caminhoRelativo, '/');
    if (!is_file($fis)) return null;
    $d = new DOMDocument(); if (!@$d->load($fis)) return null;
    $g = function (string $tag, ?DOMElement $ctx = null) use ($d) { $ctx = $ctx ?: $d->documentElement; $l = $ctx->getElementsByTagName($tag); return $l->length ? $l->item(0)->textContent : ''; };
    $inf = $d->getElementsByTagName('infNFe')->item(0); if (!$inf) return null;
    $emit = $d->getElementsByTagName('emit')->item(0); $dest = $d->getElementsByTagName('dest')->item(0);
    $ide = $d->getElementsByTagName('ide')->item(0); $tot = $d->getElementsByTagName('ICMSTot')->item(0);
    $itens = [];
    foreach ($d->getElementsByTagName('det') as $det) {
        $prod = $det->getElementsByTagName('prod')->item(0);
        $imp = $det->getElementsByTagName('imposto')->item(0);   // 13/11/2026: situação tributária, base, alíquota e valor do ICMS de cada item
        $itens[] = ['nItem' => $det->getAttribute('nItem'), 'xProd' => $g('xProd', $prod), 'NCM' => $g('NCM', $prod), 'CFOP' => $g('CFOP', $prod),
                    'uCom' => $g('uCom', $prod), 'qCom' => $g('qCom', $prod), 'vUnCom' => $g('vUnCom', $prod), 'vProd' => $g('vProd', $prod),
                    'cst' => ($imp ? ($g('CSOSN', $imp) ?: $g('CST', $imp)) : ''), 'pICMS' => ($imp ? $g('pICMS', $imp) : ''), 'vICMS' => ($imp ? $g('vICMS', $imp) : ''), 'cEAN' => $g('cEAN', $prod)];
    }
    $transp = $d->getElementsByTagName('transp')->item(0);
    return [
        'chave' => preg_replace('/\D/', '', $inf->getAttribute('Id')),
        'nNF' => $g('nNF', $ide), 'serie' => $g('serie', $ide), 'dhEmi' => $g('dhEmi', $ide), 'natOp' => $g('natOp', $ide), 'tpAmb' => $g('tpAmb', $ide),
        'tpNF' => $g('tpNF', $ide), 'finNFe' => $g('finNFe', $ide), 'crt' => $g('CRT', $emit),
        'emit' => ['CNPJ' => $g('CNPJ', $emit), 'xNome' => $g('xNome', $emit), 'IE' => $g('IE', $emit), 'IM' => $g('IM', $emit), 'fone' => $g('fone', $emit), 'email' => $g('email', $emit), 'cMun' => $g('cMun', $emit),
                   'end' => trim($g('xLgr', $emit) . ', ' . $g('nro', $emit) . ' - ' . $g('xBairro', $emit)), 'xMun' => $g('xMun', $emit), 'UF' => $g('UF', $emit), 'CEP' => $g('CEP', $emit)],
        'dest' => ['doc' => $g('CNPJ', $dest) ?: $g('CPF', $dest), 'xNome' => $g('xNome', $dest), 'email' => $g('email', $dest), 'IE' => $g('IE', $dest), 'fone' => $g('fone', $dest), 'cMun' => $g('cMun', $dest), 'xCpl' => $g('xCpl', $dest),
                   'end' => trim($g('xLgr', $dest) . ', ' . $g('nro', $dest) . ' - ' . $g('xBairro', $dest)), 'xMun' => $g('xMun', $dest), 'UF' => $g('UF', $dest), 'CEP' => $g('CEP', $dest)],
        'itens' => $itens,
        'vBC' => $g('vBC', $tot), 'vICMS' => $g('vICMS', $tot), 'vBCST' => $g('vBCST', $tot), 'vST' => $g('vST', $tot),
        'vProd' => $g('vProd', $tot), 'vFrete' => $g('vFrete', $tot), 'vSeg' => $g('vSeg', $tot), 'vDesc' => $g('vDesc', $tot),
        'vOutro' => $g('vOutro', $tot), 'vIPI' => $g('vIPI', $tot), 'vNF' => $g('vNF', $tot),
        'modFrete' => $g('modFrete', $transp), 'infCpl' => $g('infCpl'),
    ];
}

/** Monta o DANFE em PDF (A4, retrato). @return array{pdf:string,nome:string}|null */
function ws_danfe_pdf(PDO $db, int $id55): ?array {
    $st = $db->prepare("SELECT n.*, c.nome cnome, nt.fatura_id, nt.banco_id FROM ws_nfe55 n LEFT JOIN ws_cliente c ON c.id=n.cliente_id LEFT JOIN ws_nota nt ON nt.id=n.nota_id WHERE n.id=?");
    $st->execute([$id55]); $n = $st->fetch();
    if (!$n || !in_array($n['status'], ['autorizada', 'cancelada'], true) || empty($n['url_xml'])) return null;   // cancelada também abre (com a tarja), para consulta e reenvio
    $x = ws_danfe_ler_xml((string)$n['url_xml']); if (!$x) return null;
    $cfg = ws_nfse_config(); $logo = ws_pdf_logo();
    $prov = is_file(WS_CACHE . '/provedor.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: []) : [];
    // 14/11/2026: PIX do DANFE = MESMA regra das outras notas (ws_nota_pix): PIX da API/gateway da fatura por padrão; sem ele, a chave da conta própria; ou a conta escolhida na nota
    $px = ws_nota_pix($db, $n, $prov, $cfg, (float)$x['vNF'], (string)$x['nNF']);
    $bk = $px['bk']; $pixChave = $px['chave']; $pixEmv = $px['emv'];
    $rotuloPix = $pixChave !== '' ? 'Chave PIX' : 'PIX desta cobrança'; $txtPix = $pixChave !== '' ? $pixChave : 'Escaneie o QR Code com o app do seu banco';

    $vinho = [158, 42, 59];   // mesma identidade visual do boleto (ws_pdf_faturas)
    $pdf = new WsPdf(); $pdf->pagina(); $M = 10; $Lw = $pdf->W - 2 * $M; $y = 14;

    // barra fina de identidade no topo
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 1.2, true, 0); $pdf->cor(0, 0, 0); $y += 3;

    $pdf->retangulo($M, $y, $Lw, 26, false, 0.3);
    $cxDir = $M + $Lw - 72;
    $xTexto = $M + 10;
    if ($logo !== '') { $largLogo = 50; ws_danfe_imagem_proporcional($pdf, $logo, $M + 3, $y + 3, $largLogo, 19); $xTexto = $M + 3 + $largLogo + 6; }
    $pdf->cor(...$vinho); $largDisp = $cxDir - $xTexto - 2; $nomeEmit = ws_pdf_ansi($x['emit']['xNome']);
    $fonteNome = 10; $pdf->fonte($fonteNome, true);
    while ($fonteNome > 7 && $pdf->largura($nomeEmit) > $largDisp) { $fonteNome -= 0.5; $pdf->fonte($fonteNome, true); }
    $pdf->texto($xTexto, $y + 8, ws_danfe_caber($pdf, $nomeEmit, $largDisp)); $pdf->cor(0, 0, 0);
    $pdf->fonte(7, false);
    $pdf->texto($xTexto, $y + 13, ws_danfe_caber($pdf, 'CNPJ ' . ws_fmt_cnpj($x['emit']['CNPJ']) . '   IE ' . $x['emit']['IE'], $cxDir - $xTexto - 2));
    $pdf->texto($xTexto, $y + 17.5, ws_danfe_caber($pdf, $x['emit']['end'], $cxDir - $xTexto - 2));
    $pdf->texto($xTexto, $y + 22, $x['emit']['xMun'] . '/' . $x['emit']['UF']);
    $pdf->linha($cxDir, $y, $cxDir, $y + 26, 0.3);
    $pdf->cor(...$vinho); $pdf->retangulo($cxDir, $y, 72, 6, true, 0); $pdf->cor(255, 255, 255);
    $pdf->fonte(9, true); $pdf->texto($cxDir + 36, $y + 4.3, 'DANFE', 'C'); $pdf->cor(0, 0, 0);
    $pdf->fonte(6, false);
    $pdf->paragrafo($cxDir + 2, $y + 10, 'Documento Auxiliar da Nota Fiscal Eletrônica — modelo 55. Entrada=1 Saída=1 (conforme XML).', 68, 3);
    $pdf->linha($cxDir + 2, $y + 16.3, $cxDir + 70, $y + 16.3, 0.2);
    $pdf->fonte(7.5, true); $pdf->texto($cxDir + 36, $y + 20.5, 'Nº ' . $x['nNF'] . '   Série ' . ltrim($x['serie'], '0'), 'C');
    $pdf->fonte(6, false); $pdf->cor(...($x['tpAmb'] === '2' ? [180, 30, 30] : [60, 60, 60]));
    $pdf->texto($cxDir + 36, $y + 24.5, (($x['tpAmb'] === '2') ? 'AMBIENTE DE HOMOLOGAÇÃO — SEM VALOR FISCAL' : 'EMITIDA EM AMBIENTE DE PRODUÇÃO'), 'C'); $pdf->cor(0, 0, 0);

    if ($n['status'] === 'cancelada') {   // tarja de cancelamento no topo do documento
        $pdf->cor(180, 30, 30); $pdf->retangulo($M, $y - 3.2, $Lw, 3.2, true, 0); $pdf->cor(255, 255, 255); $pdf->fonte(6.5, true);
        $pdf->texto($M + $Lw / 2, $y - 0.8, 'NF-e CANCELADA — SEM VALIDADE PARA CIRCULAÇÃO', 'C'); $pdf->cor(0, 0, 0);
    }
    $y += 29;
    $pdf->retangulo($M, $y, $Lw, 20, false, 0.3);
    ws_c128c_desenhar($pdf, $M + 3, $y + 3, 12, $x['chave']);
    $pdf->fonte(7, true); $pdf->texto($M + 3, $y + 18, ws_fmt_chave($x['chave']));
    $cxCons = $M + 102; $pdf->linha($cxCons, $y, $cxCons, $y + 20, 0.3);
    $pdf->fonte(6, false);
    $pdf->paragrafo($cxCons + 3, $y + 6, 'Consulta de autenticidade no portal nacional da NF-e (www.nfe.fazenda.gov.br) ou no site da Sefaz autorizadora, informando a chave de acesso acima.', $Lw - 105, 3);

    $y += 24;
    // 13/11/2026: DANFE COMPLETO — identificação, emitente e destinatário com todos os dados (inscrições, telefone, e-mail, endereço, município, IBGE, CEP)
    $fmtDocD = fn(string $d) => strlen($d) === 14 ? ws_fmt_cnpj($d) : (strlen($d) === 11 ? ws_fmt_cpf($d) : $d);
    $crtRot = ['1' => 'Simples Nacional', '2' => 'Simples Nacional — excesso de sublimite', '3' => 'Regime normal (Lucro Presumido/Real)', '4' => 'MEI'][$x['crt']] ?? $x['crt'];
    ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'IDENTIFICAÇÃO DA NF-e', $vinho); $y += 5;
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['NÚMERO / SÉRIE', $x['nNF'] . ' / ' . $x['serie']], ['DATA E HORA DA EMISSÃO', date('d/m/Y H:i:s', strtotime($x['dhEmi']) ?: time())], ['TIPO DE OPERAÇÃO', $x['tpNF'] === '0' ? '0 - Entrada' : '1 - Saída'],
        ['TIPO DE AMBIENTE', $x['tpAmb'] === '1' ? 'Produção' : 'Homologação (sem valor fiscal)'], ['NATUREZA DA OPERAÇÃO', $x['natOp'], 2], ['PROTOCOLO DE AUTORIZAÇÃO', (string)($n['protocolo'] ?? ''), 2]], 4) + 2;
    $y += 3; ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'EMITENTE', $vinho); $y += 5;   // 14/11/2026: respiro entre os blocos (títulos não ficam espremidos nas colunas)
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['NOME / RAZÃO SOCIAL', $x['emit']['xNome'], 2], ['CNPJ', ws_fmt_cnpj($x['emit']['CNPJ'])], ['INSCRIÇÃO ESTADUAL', $x['emit']['IE']],
        ['INSCRIÇÃO MUNICIPAL', (string)($x['emit']['IM'] !== '' ? $x['emit']['IM'] : ($cfg['inscricao_municipal'] ?? ''))], ['TELEFONE', $x['emit']['fone']], ['E-MAIL', $x['emit']['email'] !== '' ? $x['emit']['email'] : (string)($cfg['email'] ?? ''), 2],
        ['ENDEREÇO', $x['emit']['end'], 2], ['MUNICÍPIO / UF', $x['emit']['xMun'] . ' / ' . $x['emit']['UF']], ['CÓDIGO IBGE / CEP', $x['emit']['cMun'] . ' / ' . $x['emit']['CEP']],
        ['REGIME TRIBUTÁRIO (CRT)', $x['crt'] . ' - ' . $crtRot, 4]], 4) + 2;
    $y += 3; ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'DESTINATÁRIO / REMETENTE', $vinho); $y += 5;
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['NOME / RAZÃO SOCIAL', $x['dest']['xNome'], 2], [strlen($x['dest']['doc']) === 14 ? 'CNPJ' : 'CPF', $fmtDocD($x['dest']['doc'])], ['INSCRIÇÃO ESTADUAL', $x['dest']['IE'] !== '' ? $x['dest']['IE'] : (strlen($x['dest']['doc']) === 11 ? 'Não se aplica (pessoa física)' : 'Não informada')],
        ['TELEFONE', $x['dest']['fone']], ['E-MAIL', $x['dest']['email'], 3],
        ['ENDEREÇO', $x['dest']['end'] . ($x['dest']['xCpl'] !== '' ? ' - ' . $x['dest']['xCpl'] : ''), 2], ['MUNICÍPIO / UF', $x['dest']['xMun'] . ' / ' . $x['dest']['UF']], ['CÓDIGO IBGE / CEP', $x['dest']['cMun'] . ' / ' . $x['dest']['CEP']]], 4);
    $y += 6;
    ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'DADOS DOS PRODUTOS / SERVIÇOS', $vinho); $y += 5;
    $cols = [['Descrição', $M, 66], ['NCM', $M + 66, 16], ['CST/CSOSN', $M + 82, 16], ['CFOP', $M + 98, 12], ['Unid.', $M + 110, 10], ['Qtd.', $M + 120, 14], ['Vl. Unit.', $M + 134, 16], ['ICMS %', $M + 150, 14], ['Vl. Total', $M + 164, 16]];
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 5.5, true, 0); $pdf->cor(255, 255, 255); $pdf->fonte(6, true);
    foreach ($cols as [$t, $cx, $cw]) $pdf->texto($cx + 1, $y + 3.7, $t);
    $pdf->cor(0, 0, 0);
    $y += 5.5; $alturaLinha = 5.3; $pdf->fonte(6.5, false); $zebra = false;
    foreach ($x['itens'] as $it) {
        if ($zebra) { $pdf->cor(244, 244, 246); $pdf->retangulo($M, $y, $Lw, $alturaLinha, true, 0); $pdf->cor(0, 0, 0); }
        $pdf->retangulo($M, $y, $Lw, $alturaLinha, false, 0.15);
        $pdf->texto($M + 1, $y + 3.6, ws_danfe_caber($pdf, ws_pdf_ansi($it['xProd']), 64));
        $pdf->texto($M + 67, $y + 3.6, $it['NCM']); $pdf->texto($M + 83, $y + 3.6, $it['cst']); $pdf->texto($M + 99, $y + 3.6, $it['CFOP']); $pdf->texto($M + 111, $y + 3.6, $it['uCom']);
        $pdf->texto($M + 121, $y + 3.6, number_format((float)$it['qCom'], 2, ',', '.'));
        $pdf->texto($M + 135, $y + 3.6, number_format((float)$it['vUnCom'], 2, ',', '.'));
        $pdf->texto($M + 151, $y + 3.6, $it['pICMS'] !== '' ? number_format((float)$it['pICMS'], 2, ',', '.') : '0,00');
        $pdf->texto($M + 165, $y + 3.6, number_format((float)$it['vProd'], 2, ',', '.'));
        $y += $alturaLinha; $zebra = !$zebra;
    }
    $pdf->linha($M, $y, $M + $Lw, $y, 0.3);

    // CÁLCULO DO IMPOSTO — 2 linhas de colunas (padrão do DANFE), com os valores reais do XML (ICMSTot).
    $y += 6; ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'CÁLCULO DO IMPOSTO', $vinho); $y += 5;
    $alturaCalc = 16; $pdf->retangulo($M, $y, $Lw, $alturaCalc, false, 0.3);
    $meio = $y + $alturaCalc / 2; $pdf->linha($M, $meio, $M + $Lw, $meio, 0.15);
    $linha1 = [['BASE DE CÁLC. DO ICMS', ws_fmt_dinheiro($x['vBC'])], ['VALOR DO ICMS', ws_fmt_dinheiro($x['vICMS'])],
               ['BASE DE CÁLC. ICMS ST', ws_fmt_dinheiro($x['vBCST'])], ['VALOR DO ICMS ST', ws_fmt_dinheiro($x['vST'])], ['VALOR DO IPI', ws_fmt_dinheiro($x['vIPI'])]];
    $linha2 = [['VALOR DOS PRODUTOS', ws_fmt_dinheiro($x['vProd'])], ['VALOR DO FRETE', ws_fmt_dinheiro($x['vFrete'])], ['VALOR DO SEGURO', ws_fmt_dinheiro($x['vSeg'])],
               ['DESCONTO', ws_fmt_dinheiro($x['vDesc'])], ['OUTRAS DESP. ACESSÓRIAS', ws_fmt_dinheiro($x['vOutro'])]];
    $colW = $Lw / 5;
    foreach ([[$linha1, $y], [$linha2, $meio]] as [$linha, $topo]) {
        foreach ($linha as $i => [$rot, $val]) {
            $cx = $M + $i * $colW;
            if ($i > 0) $pdf->linha($cx, $topo, $cx, $topo + $alturaCalc / 2, 0.15);
            $pdf->fonte(4.6, false); $pdf->cor(90, 90, 90); $pdf->texto($cx + 1.5, $topo + 2.8, ws_danfe_caber($pdf, $rot, $colW - 3)); $pdf->cor(0, 0, 0);
            $pdf->fonte(7, true); $pdf->texto($cx + $colW - 1.5, $topo + 6.5, ws_danfe_caber($pdf, $val, $colW - 3), 'R');
        }
    }
    $y += $alturaCalc + 3;
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 7, true, 0); $pdf->cor(255, 255, 255);
    $pdf->fonte(10, true); $pdf->texto($M + $Lw - 3, $y + 5, 'VALOR TOTAL DA NOTA: R$ ' . ws_fmt_dinheiro($x['vNF']), 'R'); $pdf->cor(0, 0, 0);
    $y += 10;

    // DADOS DO TRANSPORTE — presente mesmo sem transportadora cadastrada (padrão do DANFE)
    $y += 3; ws_danfe_titulo_secao($pdf, $M, $y, $Lw, 'DADOS DO TRANSPORTE', $vinho); $y += 5;
    $alturaTransp = 18; $divTransp = 9; $pdf->retangulo($M, $y, $Lw, $alturaTransp, false, 0.3);
    $freteTxt = ['0' => '0 — Contratação por conta do Remetente (CIF)', '1' => '1 — Contratação por conta do Destinatário (FOB)',
                 '2' => '2 — Contratação por conta de Terceiros', '9' => '9 — Sem transporte'][$x['modFrete'] ?: '9'] ?? ($x['modFrete'] . ' — não informado');
    $pdf->fonte(5, false); $pdf->cor(90, 90, 90); $pdf->texto($M + 1.5, $y + 3, 'FRETE POR CONTA'); $pdf->cor(0, 0, 0);
    $pdf->fonte(6.5, false); $pdf->texto($M + 1.5, $y + 6.5, $freteTxt);
    $pdf->linha($M, $y + $divTransp, $M + $Lw, $y + $divTransp, 0.15);
    $cols2 = ['NOME/RAZÃO SOCIAL' => 55, 'PLACA/UF' => 22, 'CNPJ/CPF' => 38, 'MUNICÍPIO' => 38, 'QTD./ESPÉCIE/PESO' => $Lw - 153];
    $cx = $M; foreach ($cols2 as $rot => $w) { $pdf->fonte(5, false); $pdf->cor(90, 90, 90); $pdf->texto($cx + 1.5, $y + $divTransp + 3.3, $rot); $pdf->cor(0, 0, 0); if ($cx > $M) $pdf->linha($cx, $y + $divTransp, $cx, $y + $alturaTransp, 0.15); $cx += $w; }

    $y += $alturaTransp + 4;
    $alt = min(max($pdf->H - 14 - $y, 42), 78);   // até 78mm: alto o bastante p/ caber tudo, sem esticar e deixar vazio quando a nota tem poucos itens
    $largPag = $pixEmv !== '' ? 78 : 0; $largAdic = $Lw - $largPag - ($largPag ? 3 : 0);

    ws_danfe_titulo_secao($pdf, $M, $y, $largAdic, 'DADOS ADICIONAIS', $vinho);
    $pdf->retangulo($M, $y + 5, $largAdic, $alt - 5, false, 0.3);
    if (trim((string)$x['infCpl']) !== '') { $pdf->fonte(6.5, false); $pdf->paragrafo($M + 3, $y + 9, $x['infCpl'], $largAdic - 6, 3.2, (int)(($alt - 16) / 3.2)); }
    $ctt = ws_nota_contato_linhas();   // 13/11/2026: padronização — mesmo bloco CONTATO das notas de serviço
    if ($ctt) { $nInf = trim((string)$x['infCpl']) !== '' ? min(count($pdf->quebrar((string)$x['infCpl'], $largAdic - 6)), (int)(($alt - 16) / 3.2)) * 3.2 + 4 : 0; $cy = $y + 11 + $nInf;
        if ($cy + 4.5 + 4.4 * count($ctt) < $y + $alt - 5) ws_nota_pdf_contatos($pdf, $M + 3, $cy, $ctt, $vinho); }
    $pdf->fonte(7, true); $pdf->cor(70, 70, 70);
    $pdf->texto($M + 3, $y + $alt - 2, ws_danfe_caber($pdf, 'Emissão: ' . date('d/m/Y H:i', strtotime((string)$x['dhEmi']) ?: time()) . '   Natureza da operação: ' . ws_pdf_ansi($x['natOp']), $largAdic - 6));
    $pdf->cor(0, 0, 0);

    if ($pixEmv !== '') {
        $xp = $M + $largAdic + 3;
        ws_danfe_titulo_secao($pdf, $xp, $y, $largPag, 'PAGAMENTO VIA PIX', $vinho);
        $topoCx = $y + 5; $alturaCx = $alt - 5;
        $pdf->retangulo($xp, $topoCx, $largPag, $alturaCx, false, 0.3);
        $temFavorecido = trim((string)($bk['titular'] ?? '')) !== '';
        $ladoQr = min(38, $alturaCx - 18); $linhasChave = count($pdf->quebrar($txtPix, $largPag - 6));
        $altConteudo = $ladoQr + 4 + 4 + $linhasChave * 2.8;   // QR + respiro + rótulo "Chave PIX" + linhas da chave
        $margem = max(3, ($alturaCx - $altConteudo - ($temFavorecido ? 5 : 0)) / 2);
        $yy = $topoCx + $margem;
        if ($m = ws_qr_matriz($pixEmv)) $pdf->qr($xp + ($largPag - $ladoQr) / 2, $yy, $ladoQr, $m);
        $yy += $ladoQr + 4;
        $pdf->fonte(6, true); $pdf->texto($xp + $largPag / 2, $yy, $rotuloPix, 'C'); $yy += 3.5;
        $pdf->fonte(5.6, false); ws_danfe_texto_centralizado($pdf, $xp + 3, $yy, $txtPix, $largPag - 6, 2.8);
        if ($temFavorecido) { $pdf->fonte(6.5, true); $pdf->cor(70, 70, 70); $pdf->texto($xp + $largPag / 2, $topoCx + $alturaCx - 2, ws_danfe_caber($pdf, 'Favorecido: ' . trim($bk['titular']) . (preg_match('/\bME$/i', trim($bk['titular'])) ? '' : ' ME'), $largPag - 4), 'C'); $pdf->cor(0, 0, 0); }
    }
    $y += $alt + 3;

    $pdf->fonte(6, false); $pdf->cor(140, 140, 140);
    $pdf->texto($M + $Lw / 2, $pdf->H - 7, 'Documento gerado pelo WellSystem', 'C');
    $pdf->cor(0, 0, 0);

    return ['pdf' => $pdf->saida(), 'nome' => 'nfe-' . $x['nNF'] . '-' . substr($x['chave'], -8) . '.pdf'];
}

function ws_fmt_dinheiro($v): string { return number_format((float)$v, 2, ',', '.'); }

/** Desenha a imagem respeitando a proporção real (sem achatar), centralizada dentro da caixa $w x $h. */
function ws_danfe_imagem_proporcional(WsPdf $pdf, string $bytes, float $x, float $y, float $w, float $h): void {
    $inf = @getimagesizefromstring($bytes); if (!$inf || !$inf[0] || !$inf[1]) { $pdf->imagem($bytes, $x, $y, $w, $h); return; }
    $propImg = $inf[0] / $inf[1]; $propCaixa = $w / $h;
    if ($propImg > $propCaixa) { $wf = $w; $hf = $w / $propImg; } else { $hf = $h; $wf = $h * $propImg; }
    $pdf->imagem($bytes, $x + ($w - $wf) / 2, $y + ($h - $hf) / 2, $wf, $hf);
}

/** Grade de campos no estilo da DANFSe nacional: rótulo pequeno + valor, em N colunas, com borda. $campos: [rótulo, valor, colunas que ocupa (padrão 1)]. Valor vazio = "—". Devolve o novo Y. */
function ws_danfe_grade(WsPdf $pdf, float $x, float $y, float $w, array $campos, int $cols, float $linhaH = 6.4): float {
    $cw = $w / $cols; $linhas = []; $lin = []; $col = 0;
    foreach ($campos as $c) {
        $span = max(1, min($cols, (int)($c[2] ?? 1)));
        if ($col + $span > $cols) { $linhas[] = $lin; $lin = []; $col = 0; }
        $lin[] = [(string)$c[0], trim((string)$c[1]), $span, $col]; $col += $span;
        if ($col >= $cols) { $linhas[] = $lin; $lin = []; $col = 0; }
    }
    if ($lin) $linhas[] = $lin;
    foreach ($linhas as $lin) {
        $h = $linhaH;
        foreach ($lin as [$r, $v, $sp, $cl]) { $pdf->fonte(7, false); $nl = max(1, min(4, count($pdf->quebrar($v === '' ? '—' : $v, $cw * $sp - 3)))); $h = max($h, 3.4 + $nl * 3.0); }
        $usado = 0;
        foreach ($lin as [$r, $v, $sp, $cl]) {
            $cx = $x + $cl * $cw; $usado = $cl + $sp; $pdf->retangulo($cx, $y, $cw * $sp, $h, false, 0.15);
            $pdf->fonte(5.2, false); $pdf->cor(110, 110, 110); $pdf->texto($cx + 1.2, $y + 2.4, $r); $pdf->cor(0, 0, 0);
            $pdf->fonte(7, false); $yy = $y + 5.4;
            foreach (array_slice($pdf->quebrar($v === '' ? '—' : $v, $cw * $sp - 3), 0, 4) as $ln) { $pdf->texto($cx + 1.2, $yy, $ln); $yy += 3.0; }
        }
        if ($usado < $cols) $pdf->retangulo($x + $usado * $cw, $y, $cw * ($cols - $usado), $h, false, 0.15);   // completa a linha
        $y += $h;
    }
    return $y;
}

/**
 * PIX da nota (13/11/2026) — MESMAS regras do boleto: conta "própria" → chave da conta; senão o PIX do gateway/API gravado na fatura (pix_emv);
 * sem ele → chave da conta padrão. A conta escolhida na nota (ws_nota.banco_id) tem prioridade sobre a da fatura. Sem fatura: a conta escolhida ou a padrão (chave própria).
 * @return array ['emv','chave' (só quando é chave própria),'bk' (conta, p/ favorecido),'origem' => 'api'|'conta'|'']
 */
function ws_nota_pix(PDO $db, array $n, array $prov, array $cfg, float $total, string $numero): array {
    $r = ['emv' => '', 'chave' => '', 'bk' => null, 'origem' => ''];
    try {
        $bancos = []; foreach ($db->query("SELECT * FROM ws_banco WHERE ativo=1")->fetchAll(PDO::FETCH_ASSOC) as $b) $bancos[(int)$b['id']] = $b;
        $bancoPad = null; foreach ($bancos as $b) if (trim((string)$b['pix']) !== '') { $bancoPad = $b; break; }
        $esc = (int)($n['banco_id'] ?? 0); $escolhida = ($esc > 0 && isset($bancos[$esc])) ? $bancos[$esc] : null;
        $fid = (int)($n['fatura_id'] ?? 0);
        if ($fid > 0) {
            $q = $db->prepare("SELECT f.*, COALESCE(NULLIF(f.banco_id,0), ct.banco_id) banco_id FROM ws_fatura f LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?"); $q->execute([$fid]); $f = $q->fetch(PDO::FETCH_ASSOC);
            if ($f) {
                if ($escolhida) $f['banco_id'] = (int)$escolhida['id'];
                if (!function_exists('ws_chatbot_pix') && is_file(__DIR__ . '/api_chatbot.php')) require_once __DIR__ . '/api_chatbot.php';
                if (function_exists('ws_chatbot_pix')) {
                    $emv = ''; [$emv] = ws_chatbot_pix($db, $f, $bancos, $bancoPad, $prov);
                    $bid = (int)($f['banco_id'] ?? 0); $bk = ($bid && isset($bancos[$bid])) ? $bancos[$bid] : $bancoPad;
                    if ($emv !== '') {
                        $api = trim((string)($f['pix_emv'] ?? '')) !== '' && trim((string)$f['pix_emv']) === $emv;
                        return ['emv' => $emv, 'chave' => $api ? '' : ws_pix_chave((string)($bk['pix'] ?? ''), (string)($bk['tipo_chave'] ?? '')), 'bk' => $bk, 'origem' => $api ? 'api' : 'conta'];
                    }
                }
            }
        }
        $bk = ($escolhida && trim((string)$escolhida['pix']) !== '') ? $escolhida : $bancoPad;   // sem fatura (ou sem PIX nela): chave da conta
        if ($bk) {
            $chave = ws_pix_chave((string)$bk['pix'], (string)($bk['tipo_chave'] ?? ''));
            if ($chave !== '') return ['emv' => ws_pix_emv($chave, ($prov['razao'] ?? '') ?: $cfg['razao_social'], (string)($prov['cidade'] ?? $cfg['cidade']), $total, ws_pix_txid_nome((string)$n['cnome'], $numero)), 'chave' => $chave, 'bk' => $bk, 'origem' => 'conta'];
        }
    } catch (Throwable $e) {}
    return $r;
}

/** Nome de arquivo seguro do PDF da nota: tipo-62/55, número e começo do nome do cliente, sem acento nem símbolo. Ex.: nfcom-62-n3-grupo-escolar-municipal-manoel.pdf */
function ws_nota_nome_arquivo_pdf(string $tipo, string $numero, string $cliente): string {
    $tp = ['nfcom' => 'nfcom-62', 'nfe' => 'nfe-55', 'nfse' => 'nfse'][$tipo] ?? 'nota';
    $cli = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $cliente); $cli = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', (string)$cli), '-'));
    $cli = trim(substr($cli, 0, 40), '-');
    return $tp . '-' . preg_replace('/[^a-z0-9-]+/i', '', $numero) . ($cli !== '' ? '-' . $cli : '') . '.pdf';
}

/** 13/11/2026: ícone discreto do WhatsApp (JPEG 96x96 embutido; sem arquivo externo). */
function ws_icone_whatsapp_jpeg(): string { return base64_decode('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCABgAGADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKZLLHDG00zqiICzMxwFA6knsKAbtqx9cX44+L3gT4fgw67rCvegZFlbDzbg/VR936sQK8U+L/AO0peX8s/hz4c3TW9qpKTaqn+sm7EQ/3V/2+p7YHJ+f5JHlkeWV2eSRizuxJZiepJPJPua8LGZzGm+Sgrvv0/wCCfkvEvibSwU5YbKYqclo5v4V6JfF63S7XR9A+If2utZmdo/CvhS1to+QJb+UyuffYm0D/AL6NcXdftJfF64YmPxBa2yn+GHT4sD/voMf1rzGivFnmGKqO7m/lp+R+X4rjLPsZLmqYqa/wvlX/AJLY9Otv2kvi/bsDJ4htbgDnbNp8WD/3yFP612Xh79rrW4HWPxT4UtLqPgGWwlaJx77H3A/mK+f6KIZhiabupv56/mLC8Y57g5c1PFTf+J8y/wDJrn3V4H+MPgPx/tg0TWFjvSMmxuh5U/4KeH+qk121fnAjvG6yRuyOhDKynBUjoQRyD71778If2k77TJYPDvxFunurJiEh1RuZYPQTf30/2/vDvkcj2sHnMajUK6s+/T/gH6hw14m0sZOOGzeKhJ6Ka+H/ALeX2fW7XeyPqKimQzRXESTwSLJHIodHQgqykZBBHUYp9e6frSaaugr5g/aU+L8t9eT/AA58OXRW1tzt1WaNv9dJ/wA8AR/Cv8Xqfl6A59s+L3jgfD/wJqGuxMovGUW1iD3uH4U/8B5Y+y18JySSSyNLLI0kjsWd2OWZickk+pPNeFnOMdOKoQ3e/p/wT8n8TeJZ4KlHKcNK0pq82ukdkv8At7W/krbMSiivRPg78IdQ+KGrO80klpolkwF5dKPmduoijzxuI5J6KDnqQK+dpUp1pqEFds/FMvy/EZpiYYTCx5py2X6vsl1ZxWieH9d8S3o07w/pF3qNyefLt4i5UerHoo9yQK9L0v8AZf8AinqEYkuodK07Iztubzcw+ojVh+tew+K/ih8NPgRp6+EfDGlQ3Goxrk2NqwXaT0eeU5O4++5j6AV47rH7T3xU1GdnsLvTtKiPSO3tFkIHu0m4n8hXpyw+Dwvu15OUu0eh9zVyXhnIH7HNsROtWXxRpWtF9m3u16p90h2p/svfFOwjMlrFpOo4GdtvebWP0EiqP1rzTXPDuveGb06d4h0e70656iO4iKbh6qejD3BIr0jSP2nfirp0yvfXun6pGOsdxZqmR7NHtI/WvY/CfxU+G/xzsD4Q8V6PFbahMvFjdMGWQgctBKMHcOuPlYe9KOHweK92hJxl2kFLJeGc/fscqrzo1n8MatrSfZNbN+rfZM+RKK9H+Mvwev8A4YaolxaySXehXrkWlyw+eNuvlSY43YyQejAHuCK84rzatKdCbpzVmj4fMMvxOVYmWExceWcd1+q7p9Ge+/s2fF+XS76D4d+IrotY3TbNLmdv9RKf+WJP9xv4fRuOhGPqOvzgVnRg8bsjKQyspwVI5BB9Qa+6Pg345PxA8BWGtXDg30INpfAf8948At/wIFX/AOBV9Fk2MdROhN6rb07fI/aPDLiWeMpyyjEyvKCvBv8Al2cf+3dLeTtsjxj9rrxC82saF4Vjf93bQPqEoB6u52Jn6BX/AO+q+fa9O/aTumuPi9qsZJItre1hX2HlBv5ua8xrxcwm6mKm33t92h+YcZYuWMz3FVJdJuPyj7v6E1lZXWpXtvp1jH5lzdypBCn953YKo/MivrrxrrFj8APhHaaNoBj/ALSkUWdo5UZe4YFpbhh3x8zfXaOlfPfwJsI9S+LfhuCUArFcPcYPrHE7j9QK7n9rvUp5fFmi6QHYxWumPcKv+3JIQT+UYrqwb+r4WpiI/F8KPe4aqPJuHsbnNL+K2qUX1V7Ntfff1ij1f4QeAvC978L9NuNa0C0v7vXbb7ZqM93EJZbh5SSWZ256EYwePrzXx7qsFtbarfW1mWNvDdTRwljk7FdguT64Ar71+HxsT4E8Prptwk9sumWyRyxnIYCNRn8weOxr5U+NvwWv/h3qD63pQluvD13KSsp+Z7V2P+rkPcE/dbv0PPXqzPDP6vTlBaRWv4H0HHeRTWS4OvhKacaUffaSvZqNm7bq9233d+rZ5XTopZbeVLiCV4pYmDxyIxVkYHIYEdCDyDTaK+fPxtNp3R9f+ANcsvj58JrzQvEZRtRiX7FeOF5EwG6K4UdieG+oYdK+SNR0+70nULrSr+Py7myme3mX0dGKt+or2r9knUpoPG2r6SHbybzTPOKg8b4pFAP5SNXHfH7T49N+L3iGGIALNJDc4HrJCjN+uT+Neti39YwlPES+Je6z9E4jqPOeHcHnFbWrGTpSfWVrtN/df1kzz6vff2R/EL2/iDW/C0kn7q8tkvogT0kjYI2Pqrr/AN814FXpX7Od01r8X9FUE7biO5gb3BhY/wA1FcuAm6eJg13t9+h8/wAH4uWDz3C1I9ZqPyl7r/Mk/aStWt/i/q0hBAube1mXPceUF/mhrzGvoH9rrw88Ot6H4pjT93dW72EpA6Ojb0z9Vd/++a+fqMwg6eKmn3v9+o+McLLB59iqcus3L5S979Tsfg5rEehfFDw3qEzhIvtq27sTgASqY8n8XFepftd6FOmq6B4nVSYZbeTT5GA4V1beoP1DP/3zXz4CykMrFWByGBwQexHvX1/4cv8ARv2iPhHJo2qTrHqkKJFdEDLW92g/dzgf3Wxn3BZexrqwKWIoVML1eq9Ue/wmo51lOL4fTtUlapTv1lG119yXybfQ+UNL8Ra/oksE2ka1e2jWswuIRFOwRJB/FsztJ9cjnJzX1z8KPivoPxf0Gbw74itbZdWWAx31jIoMV1ERgyID1U916qfbBr5M8U+Fdd8Ga1PoHiGya2u4Dx/clTPDo38SnsfwODxVfQdUuNE1uw1e1vJ7SS0uI5fOgOJEUMNxX1O3Ix0OcGsMJi6mCqcsttmmeTw7xHjeF8Y6VVN02+WcJfds9mvx2Z6L8avgnffDm+bV9GjluvDtzJiN+We0c9I5D3H91u/Q89fMnsb6OD7VLY3KQZC+a0LBM+m4jGa++x468ESafDqT+K9HFpcIHilkvI1Vx17n9O1YOs+OfAXjHTdQ8JaNqun+ILy+tpIVsbaTzt+4YDMRkIgOCXPAx64FeniMqoSk5U6iV9l/lqfdZx4e5VWrzr4PFxpqSvGGj1fSPvJ2fRJN9r6I8b/ZG0KeXXdd8TMmIbe1SwRiOskjB2A+iov/AH0K82+NesR678VPEd9C4aNLv7KjA5BEKLGcfipr6J1i70f9nT4Qx6XYzpNq0qNHAxGGur5x88xH91evsqqOpFfILM7szyOzuxLMzHlieST7k1x45fV8PTwv2t2fN8VRjkuT4TIG71VepUt0bvZfc39yfUSvSv2c7Vrr4v6KwB226XM7ewELD+bCvNa98/ZH8PPc+Ita8USR/urK1SyjJ/56SsGbH0VB/wB9Vy4CDqYmCXe/3anz/B+FljM9wtOPSal8o+8/yPb/AIw+B/8AhYHgPUNEgQG9jAurEntPHkqP+BDK/wDAq+FXR43aOVGR0JVlYYKkcEEdiDxX6P18u/tKfCGXTL6f4i+HbUtZXTbtUhRf9RKf+W4A/hb+L0bnoTj2s5wbqRVeG639P+AfqXidw1PGUo5vho3lBWml/Lupf9u638nfZHjXg3wtfeNfFGneF9PyJb+YRs4GfKjHLyH/AHVBP5V9j2vwb8PeHdSt9e8Byy+H9SgiWFzFl7e7jGPlniJw2cZ3KVbPOc15J+zzY+GfAPh68+KPjbU7XTxf7rTTvPb52gVv3jIv3mLOAPlB4T3qTx3+1hcy+ZYfD7SfJXlf7Qv0y31SLoPq5/4DWGCWGwdD2mI+J6pdbdLdjx+F4ZJw3lSxucNe2q2lGK1mor4XG2sW9XzXSaaVz2zxh4c8HeKdHg0/4h2Wm/O2yFpJwhWU/wDPKQ7WBPoPxBrybV/2Q9FnmaXQPGV7axHlY7q2WfH/AAJSh/OvnPX/ABDrvim+bUvEerXOo3Lfx3D7to9FHRR7AAVY0vxl4w0RBFo3ivWLJB0SC9kRR+AOKyq5jhsRL97Sv531/D/M4cx41yTOa7lj8v5ktpc1p28+VL7uayPoHSP2QNDgnWbXvGF3dRg5aO1tEgz/AMDYuf0rodT8ffB34FaTLo/ha2trrUSPmtLKQSTSOBwZ5jnb+JJHZa+XdT8aeMdbjMWseLNYvYz1Se+kZT+GcVjAADAAA9qy/tClQX+y01F93qzhXGOX5VF/2Dgo0pv7cnzyXpe9vva7pnQ+OfHXiD4g67Jr3iC4DSEbIYI8iK3jzwiA9vU9SeTXP0UV5kpynJyk7tnweIxFXF1ZV68nKcndt7tgqszBUVmZiAFUZJJ6AD1r7n+DPgU+APAVho9zGFv583l9/wBd3AJX/gICr/wGvEf2bfhDLrGoQfELxDaldPs336ZE4/4+Jh/y2x/cQ9PVuei8/U9fSZNg3TTrzW+3p3P27wx4anhKcs3xMbSmrQT/AJesv+3unlrswpk0MVxE8E8ayRyKUdHAKspGCCD1GKfRXun620noz5g+Mv7OurWk0niTwGk9/ZIuG0wsXltUHaDJ+aMdkHI7ZHT5/ZWR2jdSrISrKwwVI6gg9D7V+j9cP45+DfgL4gFrjWdIEN+wwL60PlT/APAiBh/+BA14WMydVG50HZ9uh+TcTeGVPG1JYrKZKEnq4P4X/hf2fTVdrI+F6K998Q/sj+IbZ2k8L+KLK9i6iO9jaGQe25dyn8hXGXX7OfxftWIXwxFcL2aC+hIP5sD+leLPAYmm7OD+Wv5H5biuD89wcuWphZv/AArmX3xuea0V6Ta/s5/F+5YBvC8cA7tNfQqB+TE/pXZ+Hv2R/Edy6SeJ/E9lZRdWjso2nk+m5tqj8jRDAYmo7KD+en5hheEM9xkuWnhZr/EuVffKx4GoZmVFUszEKoAyST0AHc17z8If2bdQ1iWDxF8QrWSz04EPFpr/ACzXHp5vdE/2fvHvgdfbvAvwY8BeAClzpGki4v1H/H9eESz/APASRhP+AgV3Nezg8mUGp13fy6fM/UOGvDGnhJxxObyU5LVQXw/9vP7Xpa3e6GQww20MdvbxJFFEoRERQqqoGAABwAB2p9FFe8fraSSsj//Z'); }

/** Bloco CONTATO padrão das notas: título, uma linha por contato; a linha do WhatsApp leva o ícone. Devolve o Y seguinte. */
function ws_nota_pdf_contatos(WsPdf $pdf, float $x, float $y, array $linhas, array $corTitulo): float {
    $pdf->fonte(7, true); $pdf->cor(...$corTitulo); $pdf->texto($x, $y, 'CONTATO'); $y += 4.5; $pdf->cor(40, 40, 40); $pdf->fonte(7.5, false);
    foreach ($linhas as $ln) {
        if (strncmp($ln, 'WhatsApp', 8) === 0) { $pdf->imagem(ws_icone_whatsapp_jpeg(), $x, $y - 3.0, 3.6, 3.6); $pdf->fonte(7.5, false); $pdf->cor(40, 40, 40); $pdf->texto($x + 5, $y, $ln); }
        else $pdf->texto($x, $y, $ln);
        $y += 4.4;
    }
    $pdf->cor(0, 0, 0); return $y;
}

/** Texto centralizado dentro de uma caixa de largura $larg, quebrando em várias linhas se precisar. */
function ws_danfe_texto_centralizado(WsPdf $pdf, float $x, float $y, string $txt, float $larg, float $entre): float {
    foreach ($pdf->quebrar($txt, $larg) as $linha) { $pdf->texto($x + $larg / 2, $y, $linha, 'C'); $y += $entre; }
    return $y;
}

/** Corta o texto (com "…") até caber na largura dada, na fonte/tamanho ATUAIS do $pdf — nunca estoura a caixa. */
function ws_danfe_caber(WsPdf $pdf, string $txt, float $larg): string {
    if ($pdf->largura($txt) <= $larg) return $txt;
    $k = mb_strlen($txt);
    while ($k > 1 && $pdf->largura(mb_substr($txt, 0, $k) . '…') > $larg) $k--;
    return mb_substr($txt, 0, $k) . '…';
}

/** Título de seção no padrão do DANFE: texto em caixa alta na cor da marca + linha fina por baixo. */
function ws_danfe_titulo_secao(WsPdf $pdf, float $x, float $y, float $largura, string $titulo, array $cor): void {
    $pdf->fonte(7, true); $pdf->cor(...$cor); $pdf->texto($x + $largura / 2, $y, $titulo, 'C'); $pdf->cor(0, 0, 0);
    $pdf->linha($x, $y + 1, $x + $largura, $y + 1, 0.2);
}

function ws_fmt_cnpj(string $v): string { $v = preg_replace('/\D/', '', $v); return strlen($v) === 14 ? preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $v) : $v; }
function ws_fmt_cpf(string $v): string { $v = preg_replace('/\D/', '', $v); return strlen($v) === 11 ? preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $v) : $v; }
function ws_fmt_chave(string $v): string { return trim(chunk_split($v, 4, ' ')); }

/**
 * 12/11/2026: documento auxiliar em PDF das notas de SERVIÇO (NFS-e e NFCom) no MESMO leiaute do DANFE
 * (logo proporcional, vinho, títulos centralizados, tomador, itens, total, observações, PIX com favorecido).
 * Não substitui o PDF oficial do governo (continua disponível no botão "PDF oficial"); serve para imprimir,
 * mandar por e-mail/WhatsApp e ter a mesma cara da NF-e.
 * @return array{pdf:string,nome:string}|null
 */
function ws_nota_servico_pdf(PDO $db, int $notaId): ?array {
    $st = $db->prepare("SELECT n.*, c.nome cnome, c.cpf_cnpj ccpf, c.email cemail FROM ws_nota n JOIN ws_cliente c ON c.id=n.cliente_id WHERE n.id=?");
    $st->execute([$notaId]); $n = $st->fetch();
    if (!$n || ($n['tipo'] === 'nfe' && !in_array($n['status'], ['rascunho', 'erro'], true))) return null;
    $itens = ws_nota_itens($db, $notaId);
    $numero = ''; $chave = ''; $emitidaEm = (string)($n['criado_em'] ?? '');
    if (!empty($n['nfse_id'])) {
        try { $q = $db->prepare("SELECT * FROM ws_nfse WHERE id=?"); $q->execute([(int)$n['nfse_id']]); $r = $q->fetch() ?: [];
              $numero = (string)($r['numero'] ?? ''); $chave = preg_replace('/\D/', '', (string)($r['codigo_verificacao'] ?? '')); } catch (Throwable $e) {}
    }
    $protocolo = '';
    if (!empty($n['nfcom_id'])) {   // 13/11/2026: NFCom emitida mostra número, chave de acesso e protocolo (antes só a NFS-e mostrava)
        try { $q = $db->prepare("SELECT numero, chave_acesso, protocolo, status, criado_em FROM ws_nfcom WHERE id=?"); $q->execute([(int)$n['nfcom_id']]); $r = $q->fetch() ?: [];
              if (in_array($r['status'] ?? '', ['autorizada', 'cancelada'], true)) { $numero = (string)($r['numero'] ?? ''); $chave = preg_replace('/\D/', '', (string)($r['chave_acesso'] ?? '')); $protocolo = (string)($r['protocolo'] ?? ''); $emitidaEm = (string)($r['criado_em'] ?? $emitidaEm); } } catch (Throwable $e) {}
    }
    $cfg = ws_nfse_config_raw(); if (trim((string)($n['regime'] ?? '')) !== '') $cfg['regime'] = ws_regime_valido((string)$n['regime']);   // regime próprio da nota; senão o do emissor
    $logo = ws_pdf_logo();
    $prov = is_file(WS_CACHE . '/provedor.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: []) : [];
    $total = (float)$n['total'];
    // 13/11/2026: PIX da nota = o da API (gateway) da fatura por padrão; sem ele, a chave da conta própria; ou a conta escolhida na própria nota (ws_nota.banco_id)
    $px = ws_nota_pix($db, $n, $prov, $cfg, $total, $numero ?: (string)$notaId);
    $bk = $px['bk']; $pixChave = $px['chave']; $pixEmv = $px['emv'];
    $tituloDoc = $n['tipo'] === 'nfcom' ? 'NFCom — Modelo 62 · ICMS' : ($n['tipo'] === 'nfe' ? 'NF-e' : 'NFS-e · ISS');   // 13/11/2026: sempre diz o modelo e o imposto (NFCom 62 = ICMS; NFS-e = ISS)
    $subDoc = $n['tipo'] === 'nfcom' ? 'Documento Auxiliar da Nota Fiscal Fatura de Serviço de Comunicação Eletrônica (modelo 62). Imposto: ICMS.' : 'Documento Auxiliar da Nota Fiscal de Serviço Eletrônica. Imposto: ISS.';
    $vinho = [158, 42, 59];
    $pdf = new WsPdf(); $pdf->pagina(); $M = 10; $Lw = $pdf->W - 2 * $M; $y = 14;
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 1.2, true, 0); $pdf->cor(0, 0, 0); $y += 3;

    // Cabeçalho: logo + prestador | caixa do documento
    $hh = 31;   // 13/11/2026: cabeçalho mais alto — "Optante pelo Simples Nacional" ganhou linha própria (antes era cortado com reticências)
    $pdf->retangulo($M, $y, $Lw, $hh, false, 0.3);
    $cxDir = $M + $Lw - 72; $xTexto = $M + 10;
    if ($logo !== '') { $largLogo = 50; ws_danfe_imagem_proporcional($pdf, $logo, $M + 3, $y + 3, $largLogo, 19); $xTexto = $M + 3 + $largLogo + 6; }
    $pdf->cor(...$vinho); $largDisp = $cxDir - $xTexto - 2; $nomeEmit = ws_pdf_ansi((string)$cfg['razao_social']);
    $fonteNome = 10; $pdf->fonte($fonteNome, true);
    while ($fonteNome > 7 && $pdf->largura($nomeEmit) > $largDisp) { $fonteNome -= 0.5; $pdf->fonte($fonteNome, true); }
    $pdf->texto($xTexto, $y + 8, ws_danfe_caber($pdf, $nomeEmit, $largDisp)); $pdf->cor(0, 0, 0);
    $pdf->fonte(7, false);
    $pdf->texto($xTexto, $y + 13, ws_danfe_caber($pdf, 'CNPJ ' . ws_fmt_cnpj((string)$cfg['cnpj']) . '   IM ' . $cfg['inscricao_municipal'], $largDisp));
    $pdf->texto($xTexto, $y + 17.5, ws_danfe_caber($pdf, trim($cfg['logradouro'] . ', ' . $cfg['numero'] . ' - ' . $cfg['bairro']), $largDisp));
    $pdf->texto($xTexto, $y + 22, ws_danfe_caber($pdf, $cfg['cidade'] . '/' . $cfg['uf'] . (trim((string)($cfg['cep'] ?? '')) !== '' ? '   CEP ' . $cfg['cep'] : ''), $largDisp));
    $pdf->texto($xTexto, $y + 26.5, ws_danfe_caber($pdf, ws_regime_simples($cfg) ? ($cfg['regime'] === 'mei' ? 'Optante pelo Simples Nacional — MEI' : 'Optante pelo Simples Nacional') : 'Regime: ' . ws_regime_rotulo((string)$cfg['regime']), $largDisp));
    $pdf->linha($cxDir, $y, $cxDir, $y + $hh, 0.3);
    $pdf->cor(...$vinho); $pdf->retangulo($cxDir, $y, 72, 6, true, 0); $pdf->cor(255, 255, 255);
    $pdf->fonte(9, true); $pdf->texto($cxDir + 36, $y + 4.3, $tituloDoc, 'C'); $pdf->cor(0, 0, 0);
    $pdf->fonte(6, false); $pdf->paragrafo($cxDir + 2, $y + 10, $subDoc, 68, 3);
    $pdf->linha($cxDir + 2, $y + 16.3, $cxDir + 70, $y + 16.3, 0.2);
    $pdf->fonte(7.5, true); $pdf->texto($cxDir + 36, $y + 20.5, $numero !== '' ? ('Nº ' . $numero) : ('Controle nº ' . $notaId), 'C');
    $pdf->fonte(6, false); $pdf->cor(60, 60, 60);
    $pdf->texto($cxDir + 36, $y + 26, $numero !== '' ? 'EMITIDA' : (in_array($n['status'], ['rascunho', 'erro'], true) ? 'RASCUNHO — SEM VALOR FISCAL' : 'DOCUMENTO AUXILIAR — SEM VALOR FISCAL'), 'C'); $pdf->cor(0, 0, 0);
    $y += $hh + 3;

    if (strlen($chave) === 44 && $n['tipo'] === 'nfcom') {   // 13/11/2026: NFCom emitida leva o QR Code de consulta no portal da SEFAZ (mesmo endereço que vai no XML)
        $qrUrl = 'https://dfe-portal.svrs.rs.gov.br/nfcom/qrCode?chNFCom=' . $chave . '&tpAmb=' . (($cfg['ambiente'] ?? '') === 'producao' ? 1 : 2);
        $pdf->retangulo($M, $y, $Lw, 21, false, 0.3); $cxT = $M + ($Lw - 24) / 2;
        $pdf->fonte(5, false); $pdf->cor(90, 90, 90); $pdf->texto($M + 3, $y + 3.2, 'CHAVE DE ACESSO'); $pdf->cor(0, 0, 0);
        $pdf->fonte(8, true); $pdf->texto($cxT, $y + 8.5, ws_fmt_chave($chave), 'C');
        $pdf->fonte(6.5, false); if ($protocolo !== '') $pdf->texto($cxT, $y + 13, 'Protocolo de autorização: ' . $protocolo, 'C');
        $pdf->fonte(5.6, false); $pdf->cor(90, 90, 90); $pdf->texto($cxT, $y + 17.5, 'Consulte a autenticidade pelo QR Code ou pela chave no portal da NFCom (dfe-portal.svrs.rs.gov.br/nfcom).', 'C'); $pdf->cor(0, 0, 0);
        if ($m = ws_qr_matriz($qrUrl)) $pdf->qr($M + $Lw - 20.5, $y + 1.8, 17.4, $m);
        $y += 23;
    } elseif (strlen($chave) === 50 || strlen($chave) === 44) {
        $pdf->retangulo($M, $y, $Lw, $protocolo !== '' ? 16 : 12, false, 0.3);
        $pdf->fonte(5, false); $pdf->cor(90, 90, 90); $pdf->texto($M + 3, $y + 3.5, 'CHAVE DE ACESSO'); $pdf->cor(0, 0, 0);
        $pdf->fonte(8, true); $pdf->texto($M + $Lw / 2, $y + 8.5, ws_fmt_chave($chave), 'C');
        if ($protocolo !== '') { $pdf->fonte(6.5, false); $pdf->texto($M + $Lw / 2, $y + 13.5, 'Protocolo de autorização: ' . $protocolo, 'C'); }
        $y += $protocolo !== '' ? 19 : 15;
    }

    // ===== 13/11/2026: documento COMPLETO (como a DANFSe nacional): identificação, prestador, tomador, itens, serviço/tributação, totais e fatura — tudo em qualquer estado da nota =====
    $esp = in_array($n['status'], ['rascunho', 'erro'], true);
    $ehNfcom = $n['tipo'] === 'nfcom';
    $cl = []; try { $qc = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $qc->execute([(int)$n['cliente_id']]); $cl = $qc->fetch() ?: []; require_once __DIR__ . '/schema_endereco.php'; $cl = ws_end_enriquecer($db, $cl); } catch (Throwable $e) {}
    $docRaw = preg_replace('/\D/', '', (string)$n['ccpf']); $docT = strlen($docRaw) === 14 ? ws_fmt_cnpj($docRaw) : (strlen($docRaw) === 11 ? ws_fmt_cpf($docRaw) : (string)$n['ccpf']);
    $numT = trim((string)($cl['numero'] ?? '')); $foneT = trim((string)(($cl['telefone'] ?? '') ?: ($cl['celular'] ?? '')));
    $cidT = trim((string)($cl['cidade'] ?? '')); $ibgeT = (mb_strtoupper($cidT, 'UTF-8') === mb_strtoupper(trim((string)$cfg['cidade']), 'UTF-8')) ? (string)$cfg['cod_ibge'] : '';
    $agoraTs = new DateTime('now', new DateTimeZone('America/Sao_Paulo')); $emTs = strtotime($emitidaEm) ?: time();
    // dados do XML autorizado (NFCom): ambiente, vencimento, competência, período e contrato exatamente como foram enviados
    $xmlD = [];
    if ($ehNfcom && strlen($chave) === 44) { $fx = WS_CACHE . '/notas_xml/nfcom/' . $chave . '.xml'; if (is_file($fx)) { $xx = (string)@file_get_contents($fx);
        foreach (['tpAmb', 'dVencFat', 'CompetFat', 'dPerUsoIni', 'dPerUsoFim', 'nContrato', 'serie'] as $tg) if (preg_match('#<' . $tg . '>([^<]*)</' . $tg . '>#', $xx, $mm)) $xmlD[$tg] = $mm[1]; } }
    $ambProd = isset($xmlD['tpAmb']) ? $xmlD['tpAmb'] === '1' : (($cfg['ambiente'] ?? '') === 'producao');
    $vencIso = $xmlD['dVencFat'] ?? '';
    if ($vencIso === '' && $ehNfcom) { $vencIso = (clone $agoraTs)->modify('+10 days')->format('Y-m-d');
        if (!empty($n['fatura_id'])) { try { $qv = $db->prepare("SELECT vencimento FROM ws_fatura WHERE id=?"); $qv->execute([(int)$n['fatura_id']]); $vv = (string)$qv->fetchColumn(); if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $vv)) $vencIso = $vv; } catch (Throwable $e) {} } }
    $fmtD = fn(string $iso) => preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $iso, $mm) ? $mm[3] . '/' . $mm[2] . '/' . $mm[1] : '—';
    $competencia = isset($xmlD['CompetFat']) && strlen($xmlD['CompetFat']) === 6 ? substr($xmlD['CompetFat'], 4, 2) . '/' . substr($xmlD['CompetFat'], 0, 4) : date('m/Y', $emTs);
    $situacao = $n['status'] === 'cancelada' ? 'Cancelada' : ($esp ? 'Rascunho — sem valor fiscal' : 'Autorizada');
    $serieN = (string)($xmlD['serie'] ?? ($ehNfcom ? ($cfg['nfcom_serie'] ?? '1') : ($cfg['nfsen_serie'] ?? '1')));
    $simp = ws_regime_simples($cfg); $pct = (float)($cfg[$ehNfcom ? 'pct_trib_nfcom' : 'pct_trib_nfse'] ?? 6);
    $moeda = fn($v) => 'R$ ' . ws_fmt_dinheiro((float)$v);

    // Identificação
    ws_danfe_titulo_secao($pdf, $M, $y + 3, $Lw, 'IDENTIFICAÇÃO DA NOTA', $vinho); $y += 5;
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['NÚMERO DA NOTA', $numero !== '' ? $numero : 'Controle ' . $notaId], ['SÉRIE', $serieN], ['DATA E HORA DA EMISSÃO', date('d/m/Y H:i:s', $emTs)], ['COMPETÊNCIA', $competencia],
        ['SITUAÇÃO', $situacao], ['TIPO DE AMBIENTE', $ambProd ? 'Produção' : 'Homologação (sem valor fiscal)'], ['PROTOCOLO DE AUTORIZAÇÃO', $protocolo !== '' ? $protocolo : '—', 2]], 4);
    // Prestador (nome, CNPJ, IM e endereço já estão no cabeçalho: aqui o que falta)
    ws_danfe_titulo_secao($pdf, $M, $y + 3, $Lw, 'PRESTADOR / EMITENTE', $vinho); $y += 5;
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['INSCRIÇÃO ESTADUAL', (string)($cfg['inscricao_estadual'] ?? '')], ['TELEFONE', (string)($cfg['telefone'] ?? '')], ['E-MAIL', (string)($cfg['email'] ?? ''), 2],
        ['REGIME TRIBUTÁRIO', ws_regime_rotulo((string)$cfg['regime']), 2], ['CÓDIGO IBGE / CEP', $cfg['cod_ibge'] . ' / ' . $cfg['cep']], ['CNAE', (string)($cfg['cnae'] ?? '')]], 4);
    // Tomador
    ws_danfe_titulo_secao($pdf, $M, $y + 3, $Lw, 'TOMADOR / ADQUIRENTE', $vinho); $y += 5;
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, [
        ['NOME / RAZÃO SOCIAL', trim((string)$n['cnome']), 3], ['CÓDIGO DO CLIENTE', (string)($cl['codigo'] ?? '')],
        [strlen($docRaw) === 14 ? 'CNPJ' : 'CPF', $docT], [strlen($docRaw) === 11 ? 'RG / INSCRIÇÃO ESTADUAL' : 'INSCRIÇÃO ESTADUAL', trim((string)($cl['rg_ie'] ?? '')) !== '' ? trim((string)$cl['rg_ie']) : (strlen($docRaw) === 11 ? 'Não se aplica (pessoa física)' : 'Não informada')], ['INSCRIÇÃO MUNICIPAL', trim((string)($cl['inscricao_municipal'] ?? '')) !== '' ? trim((string)$cl['inscricao_municipal']) : (strlen($docRaw) === 11 ? 'Não se aplica (pessoa física)' : 'Não informada')], ['TELEFONE', $foneT],
        ['E-MAIL', (string)($n['cemail'] ?? ''), 2], ['ENDEREÇO', trim(($cl['logradouro'] ?? '') . ', ' . ($numT !== '' ? $numT : 'S/N') . (trim((string)($cl['complemento'] ?? '')) !== '' ? ' - ' . trim((string)$cl['complemento']) : '') . ' - ' . ($cl['bairro'] ?? '')), 2],
        ['MUNICÍPIO / UF', $cidT . ' / ' . ($cl['uf'] ?? ''), 2], ['CÓDIGO IBGE', $ibgeT], ['CEP', (string)($cl['cep'] ?? '')]], 4);
    $y += 1;

    // Itens
    ws_danfe_titulo_secao($pdf, $M, $y + 3, $Lw, 'DISCRIMINAÇÃO DOS SERVIÇOS', $vinho); $y += 8;
    $cols = [['Descrição', $M, 108], ['Qtd.', $M + 108, 18], ['Vl. Unit.', $M + 126, 20], ['Desc.', $M + 146, 16], ['Vl. Total', $M + 162, 18]];
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 5.5, true, 0); $pdf->cor(255, 255, 255); $pdf->fonte(6, true);
    foreach ($cols as [$t, $cx, $cw]) $pdf->texto($cx + 1, $y + 3.7, $t);
    $pdf->cor(0, 0, 0); $y += 5.5; $pdf->fonte(6.5, false); $zebra = false;
    foreach ($itens as $it) {
        $sub = max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
        $descAnsi = (string)$it['descricao']; $longo = $pdf->largura($descAnsi) > 106; $hL = $longo ? 8.8 : 5.3;   // descrição longa quebra em 2 linhas (antes era cortada com "…")
        if ($zebra) { $pdf->cor(244, 244, 246); $pdf->retangulo($M, $y, $Lw, $hL, true, 0); $pdf->cor(0, 0, 0); }
        $pdf->retangulo($M, $y, $Lw, $hL, false, 0.15);
        if ($longo) $pdf->paragrafo($M + 1, $y + 3.6, $descAnsi, 106, 3.2, 2); else $pdf->texto($M + 1, $y + 3.6, $descAnsi);
        $pdf->texto($M + 109, $y + 3.6, rtrim(rtrim(number_format((float)$it['qtd'], 3, ',', ''), '0'), ','));
        $pdf->texto($M + 127, $y + 3.6, ws_fmt_dinheiro($it['valor_unit'])); $pdf->texto($M + 147, $y + 3.6, ws_fmt_dinheiro($it['desconto']));
        $pdf->texto($M + 163, $y + 3.6, ws_fmt_dinheiro($sub));
        $y += $hL; $zebra = !$zebra;
    }
    $pdf->linha($M, $y, $M + $Lw, $y, 0.3); $y += 3;

    // Serviço e tributação
    ws_danfe_titulo_secao($pdf, $M, $y + 3, $Lw, $ehNfcom ? 'SERVIÇO E TRIBUTAÇÃO · ICMS' : 'SERVIÇO E TRIBUTAÇÃO · ISSQN', $vinho); $y += 5;
    if ($ehNfcom) {
        $cc = (string)($cfg['nfcom_cclass'] ?? '0100401'); $ccRot = ['0100401' => 'Assinatura de serviços de comunicação multimídia', '0400401' => 'Serviço não medido — provimento à internet'][$cc] ?? '';
        $pI = (float)($cfg['nfcom_icms_pct'] ?? 0); $pP = (float)($cfg['nfcom_pis_pct'] ?? 0); $pC = (float)($cfg['nfcom_cofins_pct'] ?? 0); $pF = (float)($cfg['nfcom_fust_pct'] ?? 0); $pN = (float)($cfg['nfcom_funttel_pct'] ?? 0);
        $imp = fn(float $p, string $nome) => $simp ? 'Simples Nacional — sem destaque (R$ 0,00)' : number_format($p, 2, ',', '.') . '% sobre ' . $moeda($total) . ' = ' . $moeda(round($total * $p / 100, 2));
        $zer = 'R$ 0,00 · Simples';
        $camposT = [['CLASSIFICAÇÃO DO ITEM (cClass)', $cc . ($ccRot !== '' ? ' — ' . $ccRot : ''), 2], ['CFOP', (string)($cfg['nfcom_cfop'] ?? '5307')], ['UNIDADE', 'MB'], ['RETENÇÕES', 'R$ 0,00'],
            ['ICMS', $simp ? 'CST 90 · ' . $zer : ($pI > 0 ? 'CST 00 · ' : 'CST 40 · ') . number_format($pI, 2, ',', '.') . '% = ' . $moeda(round($total * $pI / 100, 2))], ['PIS', $simp ? $zer : number_format($pP, 2, ',', '.') . '% = ' . $moeda(round($total * $pP / 100, 2))],
            ['COFINS', $simp ? $zer : number_format($pC, 2, ',', '.') . '% = ' . $moeda(round($total * $pC / 100, 2))], ['FUST', $simp ? $zer : number_format($pF, 2, ',', '.') . '% = ' . $moeda(round($total * $pF / 100, 2))],
            ['FUNTTEL', $simp ? $zer : number_format($pN, 2, ',', '.') . '% = ' . $moeda(round($total * $pN / 100, 2))]];
        $colsT = 5;
    } else {
        $colsT = 4; $iss = (float)($cfg['aliquota_iss'] ?? 0); $issRet = !empty($cfg['iss_retido']);
        $camposT = [['CÓDIGO DE TRIBUTAÇÃO NACIONAL', (string)($cfg['nfsen_ctribnac'] ?? '')], ['CÓDIGO DO SERVIÇO (LC 116)', (string)($cfg['cod_servico'] ?? '')], ['LOCAL DA PRESTAÇÃO', $cfg['cidade'] . ' / ' . $cfg['uf']], ['MUNICÍPIO DE INCIDÊNCIA DO ISSQN', $cfg['cidade'] . ' / ' . $cfg['uf']],
            ['TIPO DE TRIBUTAÇÃO DO ISSQN', 'Operação tributável'], ['BASE DE CÁLCULO', $moeda($total)], ['ALÍQUOTA APLICADA', number_format($iss, 2, ',', '.') . '%'], ['ISSQN APURADO', $moeda(round($total * $iss / 100, 2))],
            ['RETENÇÃO DO ISSQN', $issRet ? 'Retido' : 'Não retido'], ['REGIME ESPECIAL DE TRIBUTAÇÃO', 'Nenhum'], ['PIS / COFINS / IRRF / CONTRIB. SOCIAIS', '—', 2]];
    }
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, $camposT, $colsT) + 2;

    // Totais
    $pdf->cor(...$vinho); $pdf->retangulo($M, $y, $Lw, 7, true, 0); $pdf->cor(255, 255, 255);
    $pdf->fonte(10, true); $pdf->texto($M + $Lw - 3, $y + 5, 'VALOR TOTAL DA NOTA: R$ ' . ws_fmt_dinheiro($total), 'R'); $pdf->cor(0, 0, 0);
    $y += 7;
    $camposTot = [['VALOR DA OPERAÇÃO / SERVIÇO', $moeda($total)], ['DESCONTO INCONDICIONADO', $moeda(array_sum(array_map(fn($i) => (float)$i['desconto'], $itens)))], ['TOTAL DAS RETENÇÕES', 'R$ 0,00'], ['VALOR LÍQUIDO DA NOTA', $moeda($total)],
        ['VALOR APROXIMADO DOS TRIBUTOS (LEI 12.741/2012)', $moeda(round($total * $pct / 100, 2)) . ' (' . number_format($pct, 2, ',', '.') . '%)', 2]];
    if ($ehNfcom) { $camposTot[] = ['VENCIMENTO DA FATURA', $fmtD($vencIso)]; $camposTot[] = ['COMPETÊNCIA DA FATURA', $competencia];
        $pi = $xmlD['dPerUsoIni'] ?? date('Y-m-01', $emTs); $pf = $xmlD['dPerUsoFim'] ?? date('Y-m-t', $emTs);
        $camposTot[] = ['PERÍODO DE USO', $fmtD($pi) . ' a ' . $fmtD($pf), 2]; $camposTot[] = ['ASSINANTE / CONTRATO', '#' . (int)($xmlD['nContrato'] ?? $n['cliente_id']), 2]; }
    $y = ws_danfe_grade($pdf, $M, $y, $Lw, $camposTot, 4) + 4;

    // Observações + PIX (estica até perto do rodapé, igual ao DANFE)
    $alt = min(max($pdf->H - 14 - $y, 42), $esp ? 100 : 78);   // mesmo teto do DANFE: não deixa a caixa (e o QR dentro dela) esticada e vazia
    $largPag = $pixEmv !== '' ? 78 : 0; $largAdic = $Lw - $largPag - ($largPag ? 3 : 0);
    $obsMostrar = trim((string)$n['observacao']);   // o nome completo do tomador já sai no quadro do tomador
    if ($n['tipo'] === 'nfcom') {   // 13/11/2026: as observações do PDF espelham o texto adicional (infCpl) do XML da NFCom: observação digitada + valor aproximado dos tributos (contatos saem no bloco CONTATO)
        $pctT = (float)($cfg['pct_trib_nfcom'] ?? 6);
        $obsMostrar = trim(($obsMostrar !== '' ? $obsMostrar . ' ' : '') . 'Valor aproximado dos tributos: R$ ' . number_format($total * $pctT / 100, 2, ',', '.') . ' (' . number_format($pctT, 2, ',', '.') . '%).');
    }
    ws_danfe_titulo_secao($pdf, $M, $y, $largAdic, 'OBSERVAÇÕES', $vinho);
    $pdf->retangulo($M, $y + 5, $largAdic, $alt - 5, false, 0.3);
    if (trim($obsMostrar) !== '') { $pdf->fonte(6.5, false); $pdf->paragrafo($M + 3, $y + 9, $obsMostrar, $largAdic - 6, 3.2, (int)(($alt - 16) / 3.2)); }
    $ctt = ws_nota_contato_linhas();   // 13/11/2026: contatos do provedor logo abaixo das observações
    if ($ctt) { $nObs = trim($obsMostrar) !== '' ? count($pdf->quebrar($obsMostrar, $largAdic - 6)) * 3.2 + 4 : 0; ws_nota_pdf_contatos($pdf, $M + 3, $y + 11 + $nObs, $ctt, $vinho); }
    $pdf->fonte(7, true); $pdf->cor(70, 70, 70);
    $pdf->texto($M + 3, $y + $alt - 2, 'Emissão: ' . date('d/m/Y H:i', strtotime($emitidaEm) ?: time()));
    $pdf->cor(0, 0, 0);
    if ($pixEmv !== '') {
        $xp = $M + $largAdic + 3;
        ws_danfe_titulo_secao($pdf, $xp, $y, $largPag, 'PAGAMENTO VIA PIX', $vinho);
        $topoCx = $y + 5; $alturaCx = $alt - 5; $pdf->retangulo($xp, $topoCx, $largPag, $alturaCx, false, 0.3);
        $temFav = trim((string)($bk['titular'] ?? '')) !== '';
        $rotuloPix = $pixChave !== '' ? 'Chave PIX' : 'PIX desta cobrança'; $txtPix = $pixChave !== '' ? $pixChave : 'Escaneie o QR Code com o app do seu banco';   // PIX da API não tem "chave" para mostrar
        $ladoQr = min(38, $alturaCx - 18); $linhasChave = count($pdf->quebrar($txtPix, $largPag - 6));
        $altConteudo = $ladoQr + 4 + 4 + $linhasChave * 2.8;
        $yy = $topoCx + max(3, ($alturaCx - $altConteudo - ($temFav ? 5 : 0)) / 2);
        if ($m = ws_qr_matriz($pixEmv)) $pdf->qr($xp + ($largPag - $ladoQr) / 2, $yy, $ladoQr, $m);
        $yy += $ladoQr + 4;
        $pdf->fonte(6, true); $pdf->texto($xp + $largPag / 2, $yy, $rotuloPix, 'C'); $yy += 3.5;
        $pdf->fonte(5.6, false); ws_danfe_texto_centralizado($pdf, $xp + 3, $yy, $txtPix, $largPag - 6, 2.8);
        if ($temFav) { $pdf->fonte(6.5, true); $pdf->cor(70, 70, 70); $pdf->texto($xp + $largPag / 2, $topoCx + $alturaCx - 2, ws_danfe_caber($pdf, 'Favorecido: ' . trim($bk['titular']) . (preg_match('/\bME$/i', trim($bk['titular'])) ? '' : ' ME'), $largPag - 4), 'C'); $pdf->cor(0, 0, 0); }
    }
    $pdf->fonte(6, false); $pdf->cor(140, 140, 140); $pdf->texto($M + $Lw / 2, $pdf->H - 7, 'Documento gerado pelo WellSystem', 'C'); $pdf->cor(0, 0, 0);
    return ['pdf' => $pdf->saida(), 'nome' => ws_nota_nome_arquivo_pdf((string)$n['tipo'], $numero !== '' ? 'n' . $numero : 'rascunho-' . $notaId, (string)$n['cnome'])];   // 13/11/2026: nome SÓ com letras/números/hífen (antes saía com travessão e ponto médio quebrados: "nfcom â€” modelo 62 Â· icms-3.pdf")
}
