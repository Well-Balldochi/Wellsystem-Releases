<?php
/**
 * WellSystem — NFSe (nota fiscal de serviço) via AGREGADOR multi-cidade.
 *
 * Suporta qualquer cidade porque usa um agregador (PlugNotas / Focus NFe / eNotas / NFE.io):
 * uma API REST só, todas as prefeituras. O certificado digital (e-CNPJ A1) fica no agregador.
 *
 * Config do emissor em cache/nfse.json (NUNCA no código). O corpo é montado de forma genérica
 * e a resposta é guardada crua (ws_nfse.retorno_raw) — no 1º teste em homologação travamos o
 * mapeamento exato do provedor escolhido.
 */
require_once __DIR__ . '/config.php';

define('WS_NFSE_CFG', WS_CACHE . '/nfse.json');

/** Config do emissor + provedor. */
function ws_nfse_config_raw(): array {
    $def = [
        'provider' => 'nacional',             // nacional (direto na Sefin, sem intermediário) | plugnotas | focus | enotas | generico
        'ambiente' => 'homologacao',          // homologacao | producao
        'api_url'  => '', 'api_token' => '',
        // Prestador (emissor)
        'razao_social' => '', 'cnpj' => '', 'inscricao_municipal' => '', 'regime' => 'simples',
        'nfcom_icms_pct' => '0', 'nfcom_pis_pct' => '0', 'nfcom_cofins_pct' => '0', 'nfcom_fust_pct' => '0', 'nfcom_funttel_pct' => '0',   // só valem fora do Simples/MEI (13/11/2026)
        'cidade' => '', 'uf' => '', 'cod_ibge' => '', 'cep' => '',
        'logradouro' => '', 'numero' => '', 'bairro' => '', 'telefone' => '', 'email' => '',
        // Serviço
        'cod_servico' => '', 'cnae' => '', 'aliquota_iss' => '0', 'iss_retido' => false,
        'descricao_padrao' => 'Prestação de serviço de provimento de acesso à internet (banda larga).',
        // NFS-e Nacional direta (nfse_nacional.php)
        'nfsen_ctribnac' => '', 'nfsen_cnbs' => '', 'nfsen_serie' => '1', 'nfsen_proximo' => 1,
        'nfsen_algoritmo' => 'sha256', 'nfsen_url_sefin' => '', 'nfsen_url_danfse' => '', 'cert_senha' => '',
        // NF-e modelo 55 direta na SEFAZ (nfe55.php) — produto (venda de equipamento)
        'inscricao_estadual' => '', 'nfe_serie' => '1', 'nfe_proximo' => 1, 'nfe_cfop' => '5102', 'nfe_csosn' => '400',
        'nfe_ncm_padrao' => '', 'nfe_cest_padrao' => '', 'nfe_natureza' => 'VENDA',
    ];
    if (is_file(WS_NFSE_CFG)) {
        $c = json_decode(@file_get_contents(WS_NFSE_CFG), true);
        if (is_array($c)) return array_merge($def, $c);
    }
    return $def;
}

/** Configuração do emissor. Durante a emissão de UMA nota com regime próprio (ws_nota.regime), o regime dela vale no lugar do padrão do emissor — só em memória: nunca é gravado na configuração. */
function ws_nfse_config(): array {
    $c = ws_nfse_config_raw();
    if (!empty($GLOBALS['ws_regime_da_nota'])) $c['regime'] = ws_regime_valido((string)$GLOBALS['ws_regime_da_nota']);
    return $c;
}

function ws_nfse_salvar(array $cfg): void {
    @file_put_contents(WS_NFSE_CFG, json_encode(array_merge(ws_nfse_config_raw(), $cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_NFSE_CFG, 0640);
}

function ws_nfse_http(string $metodo, string $url, array $headers, $body = null): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 40,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) return [0, null, 'curl: ' . $err];
    return [$code, json_decode($raw, true), $raw];
}

function ws_nfse_so_num($s): string { return preg_replace('/\D/', '', (string)$s); }

/**
 * Emite uma NFSe para uma fatura/cliente. Cria o registro em ws_nfse e chama o agregador.
 * @return array [ok, erro, raw]
 */
function ws_nfse_emitir(PDO $db, array $fatura, array $cliente, array $itens = [], string $obs = ''): array {
    $c = ws_nfse_config();
    if ($c['api_url'] === '' || $c['api_token'] === '' || $c['cnpj'] === '')
        return ['ok' => false, 'erro' => 'NFSe não configurada (Fiscal → Emissor).'];

    /* VÁRIOS ITENS POR NOTA (06/11/2026): com $itens, o valor é a soma dos itens (qtd x unitário - desconto) e cada item vira uma linha de serviço. */
    $valor = (float)$fatura['valor'];
    if ($itens) { $valor = 0.0; foreach ($itens as $it) $valor += max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2)); $valor = round($valor, 2); }
    $myId = 'nfse-' . ($fatura['id'] ?? '0') . '-' . substr(uniqid(), -5);

    // registro local (pendente)
    $db->prepare("INSERT INTO ws_nfse (fatura_id,cliente_id,valor,status,provider_id) VALUES (?,?,?, 'processando', ?)")
       ->execute([$fatura['id'] ?? null, $cliente['id'], $valor, $myId]);
    $nfseId = (int)$db->lastInsertId();

    // Payload genérico (padrão PlugNotas-like). Ajustável por provedor no 1º teste.
    $body = [
        'idIntegracao' => $myId,
        'prestador' => ['cpfCnpj' => ws_nfse_so_num($c['cnpj']), 'inscricaoMunicipal' => $c['inscricao_municipal']],
        'tomador' => [
            'cpfCnpj' => ws_nfse_so_num($cliente['cpf_cnpj'] ?? ''),
            'razaoSocial' => $cliente['nome'],
            'email' => $cliente['email'] ?? '',
            'endereco' => [
                'logradouro' => $cliente['logradouro'] ?? '', 'numero' => $cliente['numero'] ?? 'S/N',
                'bairro' => $cliente['bairro'] ?? '', 'codigoCidade' => '', 'cidade' => $cliente['cidade'] ?? '',
                'estado' => $cliente['uf'] ?? '', 'cep' => ws_nfse_so_num($cliente['cep'] ?? ''),
            ],
        ],
        'servico' => $itens ? array_map(function ($it) use ($c) {
            $v = max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
            $q = (float)$it['qtd'];
            return [
                'codigo' => $c['cod_servico'], 'cnae' => $c['cnae'],
                'discriminacao' => trim((string)$it['descricao']) . ($q != 1.0 ? ' (' . rtrim(rtrim(number_format($q, 3, ',', ''), '0'), ',') . ' x ' . number_format((float)$it['valor_unit'], 2, ',', '.') . ')' : ''),
                'cidadePrestacao' => $c['cod_ibge'],
                'valor' => ['servico' => $v],
                'iss' => ['aliquota' => (float)$c['aliquota_iss'], 'tipoTributacao' => 6],
            ];
        }, array_values($itens)) : [[
            'codigo' => $c['cod_servico'], 'cnae' => $c['cnae'],
            'discriminacao' => $c['descricao_padrao'],
            'cidadePrestacao' => $c['cod_ibge'],
            'valor' => ['servico' => $valor],
            'iss' => ['aliquota' => (float)$c['aliquota_iss'], 'tipoTributacao' => 6],
        ]],
    ];

    if ($obs !== '') $body['informacoesAdicionais'] = $obs;
    $url = rtrim($c['api_url'], '/') . '/nfse';
    $headers = ['Content-Type: application/json', 'X-API-KEY: ' . $c['api_token'], 'Authorization: Bearer ' . $c['api_token']];
    [$code, $resp, $raw] = ws_nfse_http('POST', $url, $headers, $body);

    // Parse defensivo
    $achar = function ($chaves) use ($resp) {
        $pilha = [$resp];
        while ($pilha) { $n = array_pop($pilha); if (!is_array($n)) continue;
            foreach ($n as $k => $v) { if (in_array((string)$k, (array)$chaves, true) && (is_string($v) || is_numeric($v)) && $v !== '') return (string)$v; if (is_array($v)) $pilha[] = $v; } }
        return null;
    };
    $ok = ($code >= 200 && $code < 300);
    $db->prepare("UPDATE ws_nfse SET status=?, provider_id=?, numero=?, codigo_verificacao=?, url_pdf=?, url_xml=?, retorno_raw=? WHERE id=?")
       ->execute([
           $ok ? 'processando' : 'erro',
           $achar(['id', 'idIntegracao', 'protocolo']) ?: $myId,
           $achar(['numeroNfse', 'numero', 'nfseNumber']),
           $achar(['codigoVerificacao', 'codigoAutenticidade']),
           $achar(['linkPdf', 'urlPdf', 'pdf']),
           $achar(['linkXml', 'urlXml', 'xml']),
           $raw, $nfseId,
       ]);
    ws_evento($db, (int)$cliente['id'], 'nfse', $ok ? 'NFSe enviada ao provedor' : 'Falha ao emitir NFSe');
    return ['ok' => $ok, 'erro' => $ok ? '' : ('HTTP ' . $code . ': ' . substr((string)$raw, 0, 300)), 'raw' => $raw, 'nfse_id' => $nfseId];
}


/* ---------------------------------------------------------------- NOTA EDITÁVEL COM VÁRIOS ITENS (06/11/2026)
 * A nota nasce como RASCUNHO (ws_nota + ws_nota_item): dá para editar, somar itens de serviço E de produto, e só depois emitir.
 * Nada aqui é fixo de uma empresa: prestador, regime (Simples Nacional por padrão), código de serviço e alíquota vêm da configuração
 * do emissor de CADA instalação. */
function ws_nota_num($v): float {
    $s = trim((string)$v); if ($s === '') return 0.0;
    if (strpos($s, ',') !== false) $s = str_replace(',', '.', str_replace('.', '', $s));
    return (float)$s;
}
function ws_nota_total(array $itens): float {
    $t = 0.0; foreach ($itens as $it) $t += max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
    return round($t, 2);
}
/** Observação INTERNA da nota (11/11/2026): só para o time, NUNCA entra no XML nem no impresso/DANFE/DANFSe. */
function ws_nota_obs_interna_salvar(PDO $db, int $notaId, string $texto): void {
    $db->prepare("UPDATE ws_nota SET observacao_interna=? WHERE id=?")->execute([$texto !== '' ? mb_substr($texto, 0, 2000) : null, $notaId]);
}
/** Exclui uma nota NUNCA enviada (rascunho/erro) — nota já enviada/autorizada não se apaga, SE CANCELA.
 *  14/11/2026: a COBRANÇA AVULSA que a própria nota criou no GalaxPay (ws_nota_cobranca_propria) sai junto — antes a nota em "erro" era excluída e a cobrança
 *  continuava ATIVA no gateway, cobrando o cliente por uma nota que não existe mais. Ela é excluída pelo caminho padrão de exclusão de título
 *  (ws_fatura_log_exclusao: registra em Boletos excluídos e cancela no gateway se não paga). Cobrança já PAGA trava a exclusão (o dinheiro entrou). */
function ws_nota_excluir(PDO $db, int $notaId): array {
    $st = $db->prepare("SELECT status FROM ws_nota WHERE id=?"); $st->execute([$notaId]); $status = $st->fetchColumn();
    if ($status === false) return ['ok' => false, 'erro' => 'Nota não encontrada.'];
    if (!in_array($status, ['rascunho', 'erro'], true)) return ['ok' => false, 'erro' => 'Esta nota já foi enviada: não dá para excluir, só cancelar.'];
    $fp = ws_nota_cobranca_propria($db, $notaId);
    if ($fp && in_array((string)$fp['status'], ['pago', 'processando'], true)) return ['ok' => false, 'erro' => 'A cobrança avulsa desta nota (título #' . (int)$fp['id'] . ') já foi paga: corrija e emita a nota em vez de excluir.'];
    if ($fp) {
        ws_fatura_log_exclusao($db, (int)$fp['id'], 'Nota fiscal #' . $notaId . ' excluída (rascunho/erro)');
        $db->prepare("UPDATE ws_nota SET fatura_id=NULL WHERE id=?")->execute([$notaId]);
        $db->prepare("DELETE FROM ws_fatura WHERE id=?")->execute([(int)$fp['id']]);
    }
    $db->prepare("DELETE FROM ws_nota_item WHERE nota_id=?")->execute([$notaId]);
    $db->prepare("DELETE FROM ws_nota WHERE id=?")->execute([$notaId]);
    return ['ok' => true, 'erro' => ''];
}
/** 14/11/2026: a fatura AVULSA criada pela própria nota (ws_nota_gerar_cobranca: sem contrato, obs "Nota fiscal #<id>") — null se a nota não tem fatura ou se a
 *  fatura é de outra origem (mensalidade, avulsa lançada no Financeiro): essas nunca são mexidas pelo Fiscal. */
function ws_nota_cobranca_propria(PDO $db, int $notaId): ?array {
    $q = $db->prepare("SELECT f.* FROM ws_nota n JOIN ws_fatura f ON f.id=n.fatura_id WHERE n.id=? AND f.contrato_id IS NULL AND f.obs=?");
    $q->execute([$notaId, 'Nota fiscal #' . $notaId]); $f = $q->fetch(PDO::FETCH_ASSOC);
    return $f ?: null;
}
function ws_nota_itens(PDO $db, int $notaId): array {
    $st = $db->prepare("SELECT * FROM ws_nota_item WHERE nota_id=? ORDER BY ordem, id"); $st->execute([$notaId]); return $st->fetchAll();
}
/** Grava (cria ou atualiza) a nota e SUBSTITUI os itens. $itens: [{tipo,descricao,qtd,valor_unit,desconto}]. Linhas sem descrição são ignoradas. */
function ws_nota_salvar(PDO $db, ?int $id, int $clienteId, ?int $faturaId, string $tipo, string $obs, array $itens, string $usuario = ''): int {
    $limpos = []; $o = 0;
    foreach ($itens as $it) {
        $d = trim(mb_substr((string)($it['descricao'] ?? ''), 0, 255)); if ($d === '') continue;
        $limpos[] = ['ordem' => ++$o, 'tipo' => (($it['tipo'] ?? 'servico') === 'produto') ? 'produto' : 'servico', 'descricao' => $d,
                     'qtd' => max(0.001, ws_nota_num($it['qtd'] ?? 1)), 'valor_unit' => max(0, ws_nota_num($it['valor_unit'] ?? 0)), 'desconto' => max(0, ws_nota_num($it['desconto'] ?? 0)),
                     'ncm' => preg_replace('/\D/', '', (string)($it['ncm'] ?? '')), 'cfop' => preg_replace('/\D/', '', (string)($it['cfop'] ?? '')),
                     'csosn' => preg_replace('/\D/', '', (string)($it['csosn'] ?? '')), 'cest' => preg_replace('/\D/', '', (string)($it['cest'] ?? '')),
                     'unidade' => mb_substr(trim((string)($it['unidade'] ?? 'UN')) ?: 'UN', 0, 6)];
    }
    $tipo = in_array($tipo, ['nfcom', 'nfe'], true) ? $tipo : 'nfse'; $total = ws_nota_total($limpos);
    $db->beginTransaction();
    try {
        if ($id) {
            /* 14/11/2026: nota JÁ ENVIADA (enviada/autorizada/cancelada) não se altera. Antes o UPDATE respeitava o status, mas os itens eram apagados e
               regravados SEMPRE — um segundo envio do formulário (clique duplo em "Salvar e emitir", aba antiga) trocava os itens de uma nota autorizada. */
            $sa = $db->prepare("SELECT status FROM ws_nota WHERE id=? FOR UPDATE"); $sa->execute([$id]); $stAtual = $sa->fetchColumn();
            if ($stAtual === false || !in_array((string)$stAtual, ['rascunho', 'erro'], true)) { $db->rollBack(); return (int)$id; }
            $db->prepare("UPDATE ws_nota SET cliente_id=?, fatura_id=?, tipo=?, observacao=?, total=? WHERE id=? AND status IN ('rascunho','erro')")->execute([$clienteId, $faturaId, $tipo, $obs, $total, $id]);
            $db->prepare("DELETE FROM ws_nota_item WHERE nota_id=?")->execute([$id]);
        } else {
            $db->prepare("INSERT INTO ws_nota (cliente_id,fatura_id,tipo,observacao,total,usuario) VALUES (?,?,?,?,?,?)")->execute([$clienteId, $faturaId, $tipo, $obs, $total, $usuario]);
            $id = (int)$db->lastInsertId();
        }
        $ins = $db->prepare("INSERT INTO ws_nota_item (nota_id,ordem,tipo,descricao,qtd,valor_unit,desconto,ncm,cfop,csosn,cest,unidade) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        foreach ($limpos as $it) $ins->execute([$id, $it['ordem'], $it['tipo'], $it['descricao'], $it['qtd'], $it['valor_unit'], $it['desconto'],
            $it['ncm'] ?: null, $it['cfop'] ?: null, $it['csosn'] ?: null, $it['cest'] ?: null, $it['unidade'] ?: 'UN']);
        $db->commit();
    } catch (Throwable $e) { $db->rollBack(); throw $e; }
    ws_tomador_garantir($db, $clienteId);   // 13/11/2026: quem ganha nota entra sozinho em Fiscal → Tomadores
    return $id;
}
/** Põe o cliente na lista de tomadores cadastrados (idempotente; nunca derruba a gravação da nota). */
function ws_tomador_garantir(PDO $db, int $clienteId, string $origem = 'nota'): void {
    if ($clienteId <= 0) return;
    try { $db->prepare("INSERT INTO ws_tomador (cliente_id, origem) VALUES (?, ?) ON DUPLICATE KEY UPDATE cliente_id = cliente_id")->execute([$clienteId, $origem]); }
    catch (Throwable $e) { try { require_once __DIR__ . '/fiscal_tomadores.php'; ws_tomador_tabela($db); $db->prepare("INSERT IGNORE INTO ws_tomador (cliente_id, origem) VALUES (?, ?)")->execute([$clienteId, $origem]); } catch (Throwable $e2) {} }
}
/** Emite uma nota já gravada. NFS-e vai pelo provedor configurado; NF-e (modelo 55) emite direto na SEFAZ do emissor;
 *  NFCom (modelo 62) só quando o provedor tiver o mapeamento confirmado em homologação. */
/** 13/11/2026: grava o regime tributário PRÓPRIO da nota (select do formulário). Igual ao padrão do emissor = NULL (segue o emissor). */
function ws_nota_definir_regime(PDO $db, int $notaId, string $regime): void {
    try {
        $r = ws_regime_valido($regime); $padrao = ws_regime_valido((string)ws_nfse_config_raw()['regime']);
        $db->prepare("UPDATE ws_nota SET regime=? WHERE id=? AND status IN ('rascunho','erro')")->execute([$r === $padrao ? null : $r, $notaId]);
    } catch (Throwable $e) {}   // coluna ainda não existe: a nota segue o regime do emissor
}
/** 13/11/2026: conta escolhida na nota para o PIX/cobrança (0 = automático: PIX da API da fatura; sem ele, conta própria). */
function ws_nota_definir_banco(PDO $db, int $notaId, int $bancoId): void {
    try {
        if ($bancoId > 0) { $q = $db->prepare("SELECT COUNT(*) FROM ws_banco WHERE id=? AND ativo=1"); $q->execute([$bancoId]); if (!(int)$q->fetchColumn()) $bancoId = 0; }
        $db->prepare("UPDATE ws_nota SET banco_id=? WHERE id=? AND status IN ('rascunho','erro')")->execute([$bancoId > 0 ? $bancoId : null, $notaId]);
    } catch (Throwable $e) {}   // coluna ainda não existe: a nota segue a regra automática
}
/** 13/11/2026: caixa "Gerar cobrança no GalaxPay" da nota (1 = NÃO gerar). Só vale enquanto a nota é rascunho/erro e não tem fatura. */
/** Cobrança por API vale? ERP/Completo: sempre (como antes). Fiscal isolado: só depois de cadastrar a API de cobrança em Fiscal → Conta do PIX. */
function ws_nota_cobranca_api_ok(): bool {
    if (!function_exists('ws_edicao_tem') || ws_edicao_tem('erp')) return true;
    try { require_once __DIR__ . '/celcash.php'; $c = ws_celcash_config(); return trim((string)($c['galaxId'] ?? '')) !== '' && trim((string)($c['galaxHash'] ?? '')) !== ''; } catch (Throwable $e) { return false; }
}
function ws_nota_definir_cobranca(PDO $db, int $notaId, bool $semCobranca): void {
    try { $db->prepare("UPDATE ws_nota SET sem_cobranca=? WHERE id=? AND status IN ('rascunho','erro')")->execute([$semCobranca ? 1 : 0, $notaId]); } catch (Throwable $e) {}
}

/**
 * 13/11/2026: nota SEM fatura ganha uma COBRANÇA AVULSA no GalaxPay/CelCoin (boleto + PIX, baixa automática) na hora de emitir, e passa a usar o PIX DELA no QR.
 * Valor = total da nota; vencimento = hoje + 10 dias; título avulso, sem contrato (não entra em corte de conexão), categoria venda/servico/outros. Se o gateway recusar,
 * o título criado é APAGADO (nada de dívida fantasma) e a nota segue com a chave da conta própria. Não faz nada se a nota já tem fatura, se a caixa foi desmarcada
 * (ws_nota.sem_cobranca) ou se não há conta de gateway ativa. @return array ['ok'=>bool,'acao'=>'criada|ja|pulada|erro','fatura_id'=>int,'erro'=>string]
 */
function ws_nota_gerar_cobranca(PDO $db, int $notaId): array {
    $r = ['ok' => true, 'acao' => 'pulada', 'fatura_id' => 0, 'erro' => ''];
    try {
        $q = $db->prepare("SELECT * FROM ws_nota WHERE id=?"); $q->execute([$notaId]); $n = $q->fetch(PDO::FETCH_ASSOC);
        if (!$n || !in_array($n['status'], ['rascunho', 'erro'], true)) return $r;
        /* 14/11/2026: cobrança avulsa criada por uma tentativa anterior (nota que voltou em "erro") e o TOTAL da nota mudou depois (item/valor corrigido):
           antes ficava valendo a cobrança velha, com o valor errado. Não paga = sai pelo caminho padrão (cancela no gateway) e nasce outra com o total certo;
           já paga com valor diferente = a emissão para e avisa (dinheiro já entrou, quem decide é o operador). */
        $fp = !empty($n['fatura_id']) ? ws_nota_cobranca_propria($db, $notaId) : null;
        if ($fp && abs((float)$fp['valor'] - round((float)$n['total'], 2)) >= 0.01) {
            if (in_array((string)$fp['status'], ['pago', 'processando'], true))
                return ['ok' => false, 'acao' => 'divergente', 'fatura_id' => (int)$fp['id'], 'erro' => 'O total da nota (R$ ' . number_format((float)$n['total'], 2, ',', '.') . ') é diferente da cobrança avulsa já paga (título #' . (int)$fp['id'] . ', R$ ' . number_format((float)$fp['valor'], 2, ',', '.') . '). Ajuste os itens para o valor pago antes de emitir.'];
            ws_fatura_log_exclusao($db, (int)$fp['id'], 'Total da nota fiscal #' . $notaId . ' mudou: cobrança refeita');
            $db->prepare("UPDATE ws_nota SET fatura_id=NULL WHERE id=?")->execute([$notaId]);
            $db->prepare("DELETE FROM ws_fatura WHERE id=?")->execute([(int)$fp['id']]);
            $n['fatura_id'] = null;
        }
        if (!empty($n['fatura_id'])) { $r['acao'] = 'ja'; $r['fatura_id'] = (int)$n['fatura_id']; return $r; }
        if (!empty($n['sem_cobranca']) || (float)$n['total'] <= 0 || !ws_nota_cobranca_api_ok()) return $r;   // Fiscal isolado: só gera cobrança se o cliente cadastrou a API (Conta do PIX); senão o PIX sai pela conta própria
        $bk = null; $esc = (int)($n['banco_id'] ?? 0);
        if ($esc > 0) { $s = $db->prepare("SELECT * FROM ws_banco WHERE id=? AND ativo=1 AND emissao='gateway'"); $s->execute([$esc]); $bk = $s->fetch(PDO::FETCH_ASSOC) ?: null; }
        if (!$bk) $bk = $db->query("SELECT * FROM ws_banco WHERE ativo=1 AND emissao='gateway' ORDER BY id LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$bk || !is_file(__DIR__ . '/celcash.php')) return $r;
        if ($esc > 0 && !$bk) return $r;
        require_once __DIR__ . '/celcash.php'; require_once __DIR__ . '/schema_endereco.php';
        if (!function_exists('ws_celcash_criar_cobranca')) return $r;
        $cs = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $cs->execute([(int)$n['cliente_id']]); $cli = $cs->fetch(PDO::FETCH_ASSOC); if (!$cli) return $r;
        $cat = ['nfe' => 'venda', 'nfse' => 'servico'][$n['tipo']] ?? 'outros';
        $venc = date('Y-m-d', strtotime('+10 days')); $comp = date('Y-m'); $myId = 'wsn-' . $notaId . '-' . substr(uniqid(), -5); $valor = round((float)$n['total'], 2);
        $db->prepare("INSERT INTO ws_fatura (contrato_id,cliente_id,competencia,vencimento,valor,taxa_emissao,status,celcash_my_id,obs,categoria,banco_id) VALUES (NULL,?,?,?,?,0,'aberto',?,?,?,?)")
           ->execute([(int)$n['cliente_id'], $comp, $venc, $valor, $myId, 'Nota fiscal #' . $notaId, $cat, (int)$bk['id']]);
        $fid = (int)$db->lastInsertId();
        $g = ws_celcash_criar_cobranca(['id' => $fid, 'valor' => $valor, 'taxa_emissao' => 0.0, 'vencimento' => $venc, 'competencia' => $comp, 'celcash_my_id' => $myId], ws_end_enriquecer($db, $cli));
        if (empty($g['ok'])) { $db->prepare("DELETE FROM ws_fatura WHERE id=?")->execute([$fid]); return ['ok' => false, 'acao' => 'erro', 'fatura_id' => 0, 'erro' => mb_substr((string)($g['erro'] ?? 'o gateway não respondeu'), 0, 300)]; }
        $db->prepare("UPDATE ws_fatura SET status='aberto', celcash_charge_id=?, linha_digitavel=?, boleto_url=?, pix_emv=?, pix_qr_url=?, gateway_raw=? WHERE id=?")
           ->execute([$g['charge_id'] ?? null, $g['linha_digitavel'] ?? null, $g['boleto_url'] ?? null, $g['pix_emv'] ?? null, $g['pix_qr_url'] ?? null, $g['raw'] ?? null, $fid]);
        $db->prepare("UPDATE ws_nota SET fatura_id=? WHERE id=?")->execute([$fid, $notaId]);
        if (function_exists('ws_evento')) ws_evento($db, (int)$n['cliente_id'], 'fatura', 'Cobrança avulsa criada no GalaxPay para a nota #' . $notaId . ' (R$ ' . number_format($valor, 2, ',', '.') . ', vence ' . date('d/m/Y', strtotime($venc)) . ')');
        return ['ok' => true, 'acao' => 'criada', 'fatura_id' => $fid, 'erro' => ''];
    } catch (Throwable $e) { return ['ok' => false, 'acao' => 'erro', 'fatura_id' => 0, 'erro' => $e->getMessage()]; }
}

/** Emite a nota usando o regime dela (se tiver um próprio), senão o do emissor. */
function ws_nota_emitir(PDO $db, int $notaId): array {
    /* 14/11/2026: UMA emissão por nota de cada vez. Sem a trava, dois envios ao mesmo tempo (clique duplo em "Salvar e emitir", dois operadores, aba
       repetida) passavam juntos pelo "status = rascunho" e cada um tirava um NÚMERO e mandava à SEFAZ — duas notas fiscais autorizadas para a mesma venda. */
    ws_dir(WS_CACHE);
    $lk = @fopen(WS_CACHE . '/nota_emitir_' . $notaId . '.lock', 'c');
    if ($lk && !flock($lk, LOCK_EX | LOCK_NB)) { fclose($lk); return ['ok' => false, 'erro' => 'Esta nota já está sendo emitida agora (outro clique ou outro usuário). Aguarde alguns segundos e atualize a página.']; }
    try {
        $rg = ''; try { $q = $db->prepare("SELECT regime FROM ws_nota WHERE id=?"); $q->execute([$notaId]); $rg = (string)$q->fetchColumn(); } catch (Throwable $e) {}
        $tpN = $db->prepare("SELECT tipo, status FROM ws_nota WHERE id=?"); $tpN->execute([$notaId]); $tN = $tpN->fetch(PDO::FETCH_ASSOC);
        if (!$tN) return ['ok' => false, 'erro' => 'Nota não encontrada.'];
        if (!in_array($tN['status'], ['rascunho', 'erro'], true)) return ['ok' => false, 'erro' => 'Esta nota já foi enviada.'];
        /* 14/11/2026: tentativa anterior SEM RESPOSTA (queda de conexão, HTTP sem resultado, NF-e em lote 103/105) pode ter sido AUTORIZADA lá. Antes de tirar
           outro número, consulta essa tentativa (NF-e e NFCom pela chave; NFS-e Nacional pelo identificador da DPS): autorizada = a nota passa a ser ela, nada é
           reenviado; ainda sem resposta = espera; não consta = segue com número novo. Vale para as TRÊS modalidades. */
        $pendente = ws_nota_tentativa_pendente($db, $notaId, (string)$tN['tipo']);
        if ($pendente !== null) return $pendente;
        if ($tN['tipo'] === 'nfe') {
            try {   // 13/11/2026: NF-e só sai com a classificação fiscal (NCM) de TODO produto — antes caía no NCM padrão do emissor (de roteador). Vale ANTES de criar cobrança.
                require_once __DIR__ . '/fiscal_produtos_lib.php';
                $msgNcm = ws_nfe_exige_classificacao($db, ws_nota_itens($db, $notaId)); if ($msgNcm !== '') return ['ok' => false, 'erro' => $msgNcm];
            } catch (Throwable $e) {}
        }
        $cob = ws_nota_gerar_cobranca($db, $notaId);   // 13/11/2026: sem fatura = cria a cobrança no GalaxPay e usa o PIX dela (falha não impede a emissão)
        if (($cob['acao'] ?? '') === 'divergente') return ['ok' => false, 'erro' => $cob['erro']];   // 14/11/2026: cobrança já paga com valor diferente do total da nota
        $GLOBALS['ws_regime_da_nota'] = $rg !== '' ? $rg : null;
        try { return ws_nota_emitir_interno($db, $notaId); } finally { unset($GLOBALS['ws_regime_da_nota']); }
    } finally { if ($lk) { flock($lk, LOCK_UN); fclose($lk); } }
}
/** 14/11/2026: tentativa anterior da nota que ficou SEM RESPOSTA da autoridade. @return array|null — null = pode emitir com número novo;
 *  ['ok'=>true,...] = a tentativa anterior estava autorizada (a nota foi ligada a ela); ['ok'=>false,'erro'] = ainda sem resultado, não emitir agora. */
function ws_nota_tentativa_pendente(PDO $db, int $notaId, string $tipo): ?array {
    $espera = ' Tente de novo em alguns minutos — nenhum número novo foi usado.';
    try {
        if ($tipo === 'nfe') {
            require_once __DIR__ . '/nfe55.php';
            $q = $db->prepare("SELECT id FROM ws_nfe55 WHERE nota_id=? AND (status='processando' OR (status='erro' AND codigo_status IS NULL)) ORDER BY id DESC LIMIT 1"); $q->execute([$notaId]); $idP = (int)$q->fetchColumn();
            if ($idP <= 0) return null;
            $cons = ws_nfe55_consultar($db, $idP);
            if (!empty($cons['ok'])) { $db->prepare("UPDATE ws_nota SET status='enviada', nfe55_id=? WHERE id=?")->execute([$idP, $notaId]); return ['ok' => true, 'erro' => '', 'nfe55_id' => $idP]; }
            $s = $db->prepare("SELECT status FROM ws_nfe55 WHERE id=?"); $s->execute([$idP]); $stP = (string)$s->fetchColumn(); $er = (string)($cons['erro'] ?? '');
            if ($stP === 'processando' || strpos($er, 'Sem conexão') === 0 || strpos($er, 'HTTP ') === 0)
                return ['ok' => false, 'erro' => 'A tentativa anterior desta NF-e ainda não tem resultado na SEFAZ (' . ($er ?: 'em processamento') . ').' . $espera];
            return null;
        }
        if ($tipo === 'nfcom') {
            require_once __DIR__ . '/nfcom.php';
            $q = $db->prepare("SELECT id FROM ws_nfcom WHERE nota_id=? AND (status='processando' OR (status='erro' AND codigo_status IS NULL)) ORDER BY id DESC LIMIT 1"); $q->execute([$notaId]); $idP = (int)$q->fetchColumn();
            if ($idP <= 0) return null;
            $cons = ws_nfcom_consultar($db, $idP);
            if (!empty($cons['ok'])) { $db->prepare("UPDATE ws_nota SET status='enviada', nfcom_id=? WHERE id=?")->execute([$idP, $notaId]); return ['ok' => true, 'erro' => '', 'nfcom_id' => $idP]; }
            if (!empty($cons['sem_resposta'])) return ['ok' => false, 'erro' => 'A tentativa anterior desta NFCom ainda não tem resultado na SEFAZ (' . $cons['erro'] . ').' . $espera];
            return null;
        }
        if ((ws_nfse_config()['provider'] ?? '') !== 'nacional') return null;
        require_once __DIR__ . '/nfse_nacional.php';
        $q = $db->prepare("SELECT s.id FROM ws_nota n JOIN ws_nfse s ON s.id=n.nfse_id WHERE n.id=? AND s.status IN ('processando','erro') AND s.provider_id LIKE 'DPS%' AND COALESCE(s.retorno_raw,'') NOT LIKE '%\"erro%'");
        $q->execute([$notaId]); $idP = (int)$q->fetchColumn();
        if ($idP <= 0) return null;
        $cons = ws_nfsen_consultar($db, $idP);
        if (!empty($cons['ok'])) { $db->prepare("UPDATE ws_nota SET status='enviada', nfse_id=? WHERE id=?")->execute([$idP, $notaId]); return ['ok' => true, 'erro' => '', 'nfse_id' => $idP]; }
        if (!empty($cons['sem_resposta'])) return ['ok' => false, 'erro' => 'A tentativa anterior desta NFS-e ainda não tem resultado na Sefin Nacional (' . $cons['erro'] . ').' . $espera];
    } catch (Throwable $e) {}
    return null;
}
function ws_nota_emitir_interno(PDO $db, int $notaId): array {
    $st = $db->prepare("SELECT * FROM ws_nota WHERE id=?"); $st->execute([$notaId]); $nota = $st->fetch();
    if (!$nota) return ['ok' => false, 'erro' => 'Nota não encontrada.'];
    if (!in_array($nota['status'], ['rascunho', 'erro'], true)) return ['ok' => false, 'erro' => 'Esta nota já foi enviada.'];
    $itens = ws_nota_itens($db, $notaId); if (!$itens) return ['ok' => false, 'erro' => 'Inclua ao menos um item.'];
    require_once __DIR__ . '/schema_endereco.php';
    $cs = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $cs->execute([(int)$nota['cliente_id']]); $cli = $cs->fetch();
    if (!$cli) return ['ok' => false, 'erro' => 'Cliente não encontrado.'];
    $clienteEnriquecido = ws_end_enriquecer($db, $cli);
    if ($nota['tipo'] === 'nfcom') {   // 12/11: NFCom (modelo 62) direto na SVRS
        require_once __DIR__ . '/nfcom.php';
        $vencFat = null; if (!empty($nota['fatura_id'])) { try { $qv = $db->prepare("SELECT vencimento, linha_digitavel FROM ws_fatura WHERE id=?"); $qv->execute([(int)$nota['fatura_id']]); $fv = $qv->fetch(PDO::FETCH_ASSOC) ?: []; $vv = (string)($fv['vencimento'] ?? ''); if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $vv)) $vencFat = $vv;
            $clienteEnriquecido['codigo_barras'] = ws_nfcom_cod_barras((string)($fv['linha_digitavel'] ?? '')); } catch (Throwable $e) {} }   // 13/11/2026: nota ligada a fatura leva o vencimento DA FATURA (antes sempre hoje+10)   // 14/11/2026: e o código de barras do boleto dela (gFat/codBarras; antes saía sempre 44 zeros)
        $r = ws_nfcom_emitir($db, ['id' => $notaId], $clienteEnriquecido, $itens, (string)$nota['observacao'], $vencFat);
        $db->prepare("UPDATE ws_nota SET status=?, nfcom_id=? WHERE id=?")->execute([$r['ok'] ? 'enviada' : 'erro', $r['nfcom_id'] ?? null, $notaId]);
        return $r;
    }
    if ($nota['tipo'] === 'nfe') {
        require_once __DIR__ . '/nfe55.php';
        $r = ws_nfe55_emitir($db, ['id' => $notaId], $clienteEnriquecido, $itens, (string)$nota['observacao']);
        $db->prepare("UPDATE ws_nota SET status=?, nfe55_id=? WHERE id=?")->execute([$r['ok'] ? 'enviada' : 'erro', $r['nfe55_id'] ?? null, $notaId]);
        return $r;
    }
    $nacional = (ws_nfse_config()['provider'] ?? '') === 'nacional';
    if ($nacional) { require_once __DIR__ . '/nfse_nacional.php'; $r = ws_nfsen_emitir($db, ['id' => $nota['fatura_id'], 'valor' => $nota['total'], 'nota_id' => $notaId], $clienteEnriquecido, $itens, (string)$nota['observacao']); }
    else $r = ws_nfse_emitir($db, ['id' => $nota['fatura_id'], 'valor' => $nota['total']], $clienteEnriquecido, $itens, (string)$nota['observacao']);
    $db->prepare("UPDATE ws_nota SET status=?, nfse_id=? WHERE id=?")->execute([$r['ok'] ? 'enviada' : 'erro', $r['nfse_id'] ?? null, $notaId]);
    return $r;
}

/** 13/11/2026: contatos do provedor que vão na nota (e-mail, WhatsApp, site, Anatel) — vêm do cadastro do provedor (cache/provedor.json). Só devolve o que existir. */
function ws_nota_contato_linhas(): array {   // 13/11/2026: os dois números do provedor (whatsapp e telefone) são WhatsApp 1 e 2
    $prov = is_file(WS_CACHE . '/provedor.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: []) : [];
    $l = [];
    foreach (['email' => 'E-mail', 'whatsapp' => 'WhatsApp 1', 'telefone' => 'WhatsApp 2', 'site' => 'Site', 'anatel' => 'Anatel'] as $k => $rot) { $v = trim((string)($prov[$k] ?? '')); if ($v !== '') $l[] = $rot . ': ' . $v; }
    return $l;
}

/** 13/11/2026: regimes tributários do emissor. Simples Nacional é o PADRÃO; MEI se comporta como Simples; Lucro Presumido/Real usam a tributação "normal". 'normal' (antigo) continua valendo. */
function ws_regime_lista(): array { return ['simples' => 'Simples Nacional', 'mei' => 'MEI (Microempreendedor Individual)', 'presumido' => 'Lucro Presumido', 'real' => 'Lucro Real']; }
function ws_regime_valido(string $r): string { $r = strtolower(trim($r)); return (array_key_exists($r, ws_regime_lista()) || $r === 'normal') ? $r : 'simples'; }
function ws_regime_simples(array $c): bool { return in_array(ws_regime_valido((string)($c['regime'] ?? 'simples')), ['simples', 'mei'], true); }
function ws_regime_rotulo(string $r): string { $r = ws_regime_valido($r); return $r === 'normal' ? 'Regime normal' : ws_regime_lista()[$r]; }
/** CRT do documento (NFCom só aceita 1, 2 ou 3): Simples Nacional e MEI = 1; regime normal = 3. */
function ws_regime_crt(array $c): string { $r = ws_regime_valido((string)($c['regime'] ?? 'simples')); return in_array($r, ['simples', 'mei'], true) ? '1' : '3'; }
