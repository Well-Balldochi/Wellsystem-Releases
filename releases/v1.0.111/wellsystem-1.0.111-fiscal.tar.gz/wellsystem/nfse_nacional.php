<?php
/**
 * WellSystem — NFS-e PADRÃO NACIONAL, emissão DIRETA na Sefin Nacional (sem intermediário pago).
 *
 * Como funciona (fonte: manual "Guia para utilização das APIs do Emissor Público Nacional" e XSD/leiaute DPS v1.01 do gov.br/nfse):
 *   1. monta a DPS (Declaração de Prestação de Serviços) em XML;
 *   2. assina com o certificado A1 (ICP-Brasil, com CNPJ) do PRESTADOR — assinatura obrigatória na API;
 *   3. envia por POST /nfse, XML compactado (GZip) em Base64 dentro de um JSON, com conexão mTLS usando o mesmo certificado;
 *   4. a Sefin devolve a NFS-e (XML) e a chave de acesso; o PDF (DANFSe) é baixado do ADN.
 *
 * Nada aqui é fixo de uma empresa: o prestador, o município, o código de serviço, a série e o certificado vêm da configuração
 * do emissor DE CADA instalação (Fiscal → Emissor). O certificado A1 (.pfx) fica em cache/nfse_cert.pfx (modo 0600) e a senha
 * em cache/nfse.json; ambos entram no backup (arquivo da lista de configuração) e na cópia do espelho.
 *
 * Itens da nota: a DPS nacional tem UM serviço por documento. Vários itens da nota viram UMA linha de serviço com a discriminação
 * item a item e o valor total; descontos viram desconto incondicionado. NFS-e é só para SERVIÇO — nota com produto precisa de NF-e.
 *
 * ATENÇÃO — conferir em PRODUÇÃO RESTRITA antes de produção: nome do campo do JSON (dpsXmlGZipB64), algoritmo da assinatura
 * (padrão sha256, ajustável em 'nfsen_algoritmo') e as URLs base (ajustáveis em 'nfsen_url_sefin' / 'nfsen_url_danfse').
 */
require_once __DIR__ . '/nfse.php';

define('WS_NFSEN_PFX', WS_CACHE . '/nfse_cert.pfx');

function ws_nfsen_urls(array $c): array {
    $rest = ($c['ambiente'] ?? 'homologacao') !== 'producao';
    return [
        'sefin'  => rtrim((string)($c['nfsen_url_sefin'] ?: ($rest ? 'https://sefin.producaorestrita.nfse.gov.br/API/SefinNacional' : 'https://sefin.nfse.gov.br/SefinNacional')), '/'),
        'danfse' => rtrim((string)($c['nfsen_url_danfse'] ?: ($rest ? 'https://adn.producaorestrita.nfse.gov.br/danfse' : 'https://adn.nfse.gov.br/danfse')), '/'),
    ];
}

/** Lê o certificado A1 gravado. @return array [ok, erro, cert(PEM), pkey(PEM), info[]] */
function ws_nfsen_certificado(array $c): array {
    if (!is_file(WS_NFSEN_PFX)) return [false, 'Certificado A1 (.pfx) ainda não enviado (Fiscal → Emissor).', null, null, []];
    $bin = (string)@file_get_contents(WS_NFSEN_PFX); [$certs] = ws_nfsen_ler_pfx($bin, (string)($c['cert_senha'] ?? ''));
    if (!$certs)
        return [false, 'Não consegui abrir o certificado: senha incorreta ou formato antigo (reexporte o .pfx com criptografia moderna).', null, null, []];
    $x = @openssl_x509_parse($certs['cert']); $cnpj = '';
    if ($x && preg_match('/(\d{14})/', json_encode($x['extensions'] ?? [], JSON_UNESCAPED_UNICODE) . ' ' . ($x['subject']['CN'] ?? ''), $m)) $cnpj = $m[1];
    $info = ['titular' => $x['subject']['CN'] ?? '', 'cnpj' => $cnpj, 'valido_ate' => isset($x['validTo_time_t']) ? date('d/m/Y', $x['validTo_time_t']) : '', 'expirado' => isset($x['validTo_time_t']) && $x['validTo_time_t'] < time()];
    if ($info['expirado']) return [false, 'Certificado vencido em ' . $info['valido_ate'] . '.', null, null, $info];
    return [true, '', $certs['cert'], $certs['pkey'], $info];
}

/**
 * Lê um .pfx; se o OpenSSL 3 recusar (certificado antigo RC2/3DES, comum em A1 exportado pelo Windows),
 * converte pelo comando `openssl pkcs12 -legacy` para o formato moderno. A senha vai por variável de
 * ambiente (nunca na linha de comando). @return array [certs|null, binário utilizável, erro]
 */
function ws_nfsen_ler_pfx(string $bin, string $senha): array {
    $certs = [];
    if ($bin !== '' && @openssl_pkcs12_read($bin, $certs, $senha)) return [$certs, $bin, ''];
    while (openssl_error_string() !== false) {}
    if ($bin === '' || !function_exists('proc_open')) return [null, $bin, 'Arquivo vazio ou ilegível.'];
    $d = sys_get_temp_dir(); $in = tempnam($d, 'wsp'); $pem = tempnam($d, 'wsq'); $out = tempnam($d, 'wsr');
    file_put_contents($in, $bin); $env = ['WSP' => $senha, 'PATH' => '/usr/bin:/bin:/usr/local/bin'];
    $run = function (array $cmd) use ($env) { $p = @proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pp, null, $env); if (!is_resource($p)) return [1, '']; $o = stream_get_contents($pp[1]); $e = stream_get_contents($pp[2]); fclose($pp[1]); fclose($pp[2]); return [proc_close($p), $e]; };
    [$rc1, $e1] = $run(['openssl', 'pkcs12', '-legacy', '-in', $in, '-nodes', '-passin', 'env:WSP', '-out', $pem]);
    $res = [null, $bin, 'Senha incorreta ou arquivo que não é um certificado A1 (.pfx).'];
    if ($rc1 === 0 && filesize($pem) > 0) {
        [$rc2] = $run(['openssl', 'pkcs12', '-export', '-in', $pem, '-passout', 'env:WSP', '-out', $out]);
        $novo = $rc2 === 0 ? (string)@file_get_contents($out) : '';
        if ($novo !== '' && @openssl_pkcs12_read($novo, $certs, $senha)) $res = [$certs, $novo, ''];
    }
    foreach ([$in, $pem, $out] as $f) @unlink($f);
    return $res;
}

/** Grava o .pfx enviado pela tela, depois de conferir a senha. @return string erro ('' = ok) */
function ws_nfsen_salvar_certificado(string $tmpFile, string $senha): string {
    [$certs, $bin, $err] = ws_nfsen_ler_pfx((string)@file_get_contents($tmpFile), $senha);
    if (!$certs) return 'Não consegui abrir o certificado: ' . $err;
    $x = @openssl_x509_parse($certs['cert']);
    if (!$x || ($x['validTo_time_t'] ?? 0) < time()) return 'Certificado vencido.';
    if (@file_put_contents(WS_NFSEN_PFX, $bin) === false) return 'O servidor não conseguiu gravar o certificado em ' . basename(WS_CACHE) . '/ (permissão da pasta).';
    @chmod(WS_NFSEN_PFX, 0600);
    ws_nfse_salvar(['cert_senha' => $senha]);
    return '';
}

function ws_nfsen_x($s): string { return htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }
function ws_nfsen_dec($v): string { return number_format((float)$v, 2, '.', ''); }

/** Próximo número de DPS da série (contador com trava, guardado na configuração). */
/** 12/11/2026: contador SEPARADO por ambiente (mesmo risco da NF-e: testar em homologação não pode colidir com produção). */
function ws_nfsen_proximo_numero(): int {
    $c = ws_nfse_config(); $prod = (($c['ambiente'] ?? '') === 'producao');
    $chave = $prod ? 'nfsen_proximo' : 'nfsen_proximo_homolog';
    $arq = WS_CACHE . '/nfsen_seq_' . ($prod ? 'prod' : 'homolog') . '.lock'; $fp = @fopen($arq, 'c+'); if (!$fp) return (int)(microtime(true) * 10) % 999999999;
    flock($fp, LOCK_EX); $n = max(1, (int)($c[$chave] ?? 1));
    ws_nfse_salvar([$chave => $n + 1]); flock($fp, LOCK_UN); fclose($fp); return $n;
}

/** Texto da discriminação com TODOS os itens (a DPS nacional tem um serviço só). */
function ws_nfsen_descricao(array $itens): string {
    $l = []; foreach ($itens as $i => $it) {
        $q = (float)$it['qtd']; $sub = max(0, round($q * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
        $l[] = ($i + 1) . ') ' . trim((string)$it['descricao']) . ($q != 1.0 ? ' - ' . rtrim(rtrim(number_format($q, 3, ',', ''), '0'), ',') . ' x R$ ' . number_format((float)$it['valor_unit'], 2, ',', '.') : '') . ' = R$ ' . number_format($sub, 2, ',', '.');
    }
    return mb_substr(implode('; ', $l), 0, 2000);
}

/** Monta e ASSINA a DPS. @return array [xml, id, nDps] */
function ws_nfsen_montar_dps(array $c, array $itens, array $cli, string $obs, string $certPem, string $pkeyPem, ?int $numeroReusar = null): array {
    $cnpj = ws_nfse_so_num($c['cnpj']); $mun = ws_nfse_so_num($c['cod_ibge']); $serie = str_pad(substr(ws_nfse_so_num($c['nfsen_serie'] ?: '1') ?: '1', 0, 5), 5, '0', STR_PAD_LEFT);
    $n = ($numeroReusar !== null && $numeroReusar > 0) ? $numeroReusar : ws_nfsen_proximo_numero(); $nDps = (string)$n;   // 14/11/2026: nota rejeitada reenvia com o MESMO número da DPS
    $id = 'DPS' . $mun . '2' . $cnpj . $serie . str_pad($nDps, 15, '0', STR_PAD_LEFT);
    $bruto = 0.0; $desc = 0.0; foreach ($itens as $it) { $bruto += round((float)$it['qtd'] * (float)$it['valor_unit'], 2); $desc += (float)$it['desconto']; }
    $tz = new DateTimeZone('America/Sao_Paulo'); $agora = new DateTime('now', $tz);
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $doc = ws_nfse_so_num($cli['cpf_cnpj'] ?? '');
    $tomaId = strlen($doc) === 14 ? '<CNPJ>' . $doc . '</CNPJ>' : (strlen($doc) === 11 ? '<CPF>' . $doc . '</CPF>' : '');
    $cMunT = ws_nfse_so_num($cli['cod_ibge'] ?? ($cli['ibge'] ?? '')); $cepT = ws_nfse_so_num($cli['cep'] ?? '');
    $endT = ($cMunT !== '' && strlen($cepT) === 8 && trim((string)($cli['logradouro'] ?? '')) !== '')
        ? '<end><endNac><cMun>' . $cMunT . '</cMun><CEP>' . $cepT . '</CEP></endNac><xLgr>' . ws_nfsen_x($cli['logradouro']) . '</xLgr><nro>' . ws_nfsen_x(($cli['numero'] ?? '') !== '' ? $cli['numero'] : 'S/N') . '</nro><xBairro>' . ws_nfsen_x(($cli['bairro'] ?? '') !== '' ? $cli['bairro'] : 'Centro') . '</xBairro></end>' : '';
    $desc2000 = ws_nfsen_descricao($itens);
    $info = trim($obs) !== '' ? '<infoCompl><xInfComp>' . ws_nfsen_x(mb_substr(trim($obs), 0, 2000)) . '</xInfComp></infoCompl>' : '';
    $regimeSel = ws_regime_valido((string)($c['regime'] ?? 'simples'));   // 13/11/2026: simples (ME/EPP) = 3, MEI = 2, demais = 1 (não optante)
    $regime = $regimeSel === 'simples'
        ? '<regTrib><opSimpNac>3</opSimpNac><regApTribSN>1</regApTribSN><regEspTrib>0</regEspTrib></regTrib>'
        : ($regimeSel === 'mei' ? '<regTrib><opSimpNac>2</opSimpNac><regEspTrib>0</regEspTrib></regTrib>' : '<regTrib><opSimpNac>1</opSimpNac><regEspTrib>0</regEspTrib></regTrib>');
    $simples = ws_regime_simples($c);
    $tribMun = '<tribMun><tribISSQN>1</tribISSQN><tpRetISSQN>' . (!empty($c['iss_retido']) ? '2' : '1') . '</tpRetISSQN>' . ((!$simples && (float)$c['aliquota_iss'] > 0) ? '<pAliq>' . ws_nfsen_dec($c['aliquota_iss']) . '</pAliq>' : '') . '</tribMun>';
    $totTrib = $simples ? '<totTrib><pTotTribSN>' . ws_nfsen_dec($c['pct_trib_nfse'] ?? 6) . '</pTotTribSN></totTrib>'   // ME/EPP: indTotTrib é PROIBIDO (E0712); usa pTotTribSN (percentual aprox. da Lei da Transparência)
                       : '<totTrib><indTotTrib>0</indTotTrib></totTrib>';
    $xml = '<DPS xmlns="http://www.sped.fazenda.gov.br/nfse" versao="1.01"><infDPS Id="' . $id . '">'
        . '<tpAmb>' . $amb . '</tpAmb><dhEmi>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEmi><verAplic>WellSystem</verAplic><serie>' . ltrim($serie, '0') . '</serie><nDPS>' . $nDps . '</nDPS>'
        . '<dCompet>' . $agora->format('Y-m-d') . '</dCompet><tpEmit>1</tpEmit><cLocEmi>' . $mun . '</cLocEmi>'
        . '<prest><CNPJ>' . $cnpj . '</CNPJ>' . (trim((string)$c['inscricao_municipal']) !== '' ? '<IM>' . ws_nfsen_x($c['inscricao_municipal']) . '</IM>' : '') . $regime . '</prest>'
        . ($tomaId !== '' ? '<toma>' . $tomaId . (trim((string)($cli['inscricao_municipal'] ?? '')) !== '' ? '<IM>' . ws_nfsen_x(trim((string)$cli['inscricao_municipal'])) . '</IM>' : '') . '<xNome>' . ws_nfsen_x($cli['nome']) . '</xNome>' . $endT . (trim((string)($cli['email'] ?? '')) !== '' ? '<email>' . ws_nfsen_x($cli['email']) . '</email>' : '') . '</toma>' : '')
        . '<serv><locPrest><cLocPrestacao>' . $mun . '</cLocPrestacao></locPrest><cServ><cTribNac>' . ws_nfse_so_num($c['nfsen_ctribnac']) . '</cTribNac>' . (trim((string)$c['nfsen_cnbs']) !== '' ? '' : '') . '<xDescServ>' . ws_nfsen_x($desc2000) . '</xDescServ>' . (trim((string)$c['nfsen_cnbs']) !== '' ? '<cNBS>' . ws_nfse_so_num($c['nfsen_cnbs']) . '</cNBS>' : '') . '</cServ>' . $info . '</serv>'
        . '<valores><vServPrest><vServ>' . ws_nfsen_dec($bruto) . '</vServ></vServPrest>' . ($desc > 0 ? '<vDescCondIncond><vDescIncond>' . ws_nfsen_dec($desc) . '</vDescIncond></vDescCondIncond>' : '')
        . '<trib>' . $tribMun . $totTrib . '</trib></valores>'
        . '</infDPS></DPS>';
    return [ws_nfsen_assinar($xml, $id, $c, $certPem, $pkeyPem), $id, $nDps];
}

/** Assinatura XMLDSig (enveloped) sobre infDPS, no formato dos documentos fiscais brasileiros. */
function ws_nfsen_assinar(string $xml, string $id, array $c, string $certPem, string $pkeyPem): string {
    $alg = (($c['nfsen_algoritmo'] ?? 'sha256') === 'sha1') ? ['sha1', 'http://www.w3.org/2000/09/xmldsig#rsa-sha1', 'http://www.w3.org/2000/09/xmldsig#sha1', OPENSSL_ALGO_SHA1]
                                                            : ['sha256', 'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256', 'http://www.w3.org/2001/04/xmlenc#sha256', OPENSSL_ALGO_SHA256];
    $dom = new DOMDocument('1.0', 'UTF-8'); $dom->preserveWhiteSpace = true; $dom->loadXML($xml);
    $inf = $dom->getElementsByTagName('infDPS')->item(0);
    $inf->setIdAttribute('Id', true);
    $digest = base64_encode(hash($alg[0], $inf->C14N(false, false), true));
    $dsig = 'http://www.w3.org/2000/09/xmldsig#';
    $signedInfo = '<SignedInfo xmlns="' . $dsig . '"><CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></CanonicalizationMethod>'
        . '<SignatureMethod Algorithm="' . $alg[1] . '"></SignatureMethod><Reference URI="#' . $id . '"><Transforms><Transform Algorithm="' . $dsig . 'enveloped-signature"></Transform>'
        . '<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></Transform></Transforms><DigestMethod Algorithm="' . $alg[2] . '"></DigestMethod><DigestValue>' . $digest . '</DigestValue></Reference></SignedInfo>';
    $sd = new DOMDocument(); $sd->loadXML($signedInfo); $canon = $sd->documentElement->C14N(false, false);
    $sig = ''; openssl_sign($canon, $sig, $pkeyPem, $alg[3]);
    $b64 = preg_replace('/-----[^-]+-----|\s+/', '', $certPem);
    $signature = '<Signature xmlns="' . $dsig . '">' . $signedInfo . '<SignatureValue>' . base64_encode($sig) . '</SignatureValue><KeyInfo><X509Data><X509Certificate>' . $b64 . '</X509Certificate></X509Data></KeyInfo></Signature>';
    $frag = $dom->createDocumentFragment(); $frag->appendXML($signature); $dom->documentElement->appendChild($frag);
    return $dom->saveXML($dom->documentElement);
}

/** Chamada à Sefin/ADN com mTLS (o mesmo certificado do prestador). */
function ws_nfsen_http(string $metodo, string $url, $corpo, string $certPem, string $pkeyPem, array $hdr = []): array {
    $d = WS_CACHE; $cf = tempnam($d, 'nc'); $kf = tempnam($d, 'nk'); @chmod($cf, 0600); @chmod($kf, 0600);
    file_put_contents($cf, $certPem); file_put_contents($kf, $pkeyPem);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60, CURLOPT_SSLCERT => $cf, CURLOPT_SSLKEY => $kf,
        CURLOPT_HTTPHEADER => array_merge(['Accept: application/json'], $hdr)]);
    // Webservices das SEFAZ (NF-e) usam a cadeia ICP-Brasil, que não vem no pacote de CAs do Debian: raiz oficial do ITI embutida no código (conferida com a raiz servida pela SEFAZ-PE).
    if (preg_match('/\.sefaz\.[a-z]{2}\.gov\.br|\.fazenda\.gov\.br|\.svrs\.rs\.gov\.br/i', (string)parse_url($url, PHP_URL_HOST)) && is_file(__DIR__ . '/ca_icpbrasil_v10.pem')) curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/ca_icpbrasil_v10.pem');
    if ($corpo !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($corpo) ? $corpo : json_encode($corpo)); }
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    @unlink($cf); @unlink($kf);
    return [$raw === false ? 0 : $code, $raw === false ? null : $raw, $err];
}

/** Emite a NFS-e Nacional. Mesmo contrato de ws_nfse_emitir(): registra em ws_nfse e devolve [ok, erro, raw, nfse_id]. */
function ws_nfsen_emitir(PDO $db, array $fatura, array $cliente, array $itens, string $obs = ''): array {
    $c = ws_nfse_config();
    foreach ($itens as $it) if (($it['tipo'] ?? 'servico') === 'produto')
        return ['ok' => false, 'erro' => 'NFS-e é só para SERVIÇO. Há item de produto na nota: separe o produto (precisa de NF-e) ou remova-o.'];
    if (!$itens) return ['ok' => false, 'erro' => 'Inclua ao menos um item.'];
    foreach (['cnpj' => 'CNPJ', 'cod_ibge' => 'código IBGE do município', 'nfsen_ctribnac' => 'código de tributação nacional (cTribNac)'] as $k => $rot)
        if (trim((string)($c[$k] ?? '')) === '') return ['ok' => false, 'erro' => 'Configure o ' . $rot . ' em Fiscal → Emissor.'];
    [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c);
    if (!$okC) return ['ok' => false, 'erro' => $erroC];
    /* 14/11/2026 (nota 57 da NFCom, vale igual aqui): DPS REJEITADA pela Sefin (resposta com "erros", ou E2404 = a Sefin nunca gerou NFS-e para ela) não consome o número. Reenviar a mesma nota
       refaz a tentativa com o MESMO número de DPS e a MESMA linha. Não reaproveita: erro de duplicidade, tentativa sem resposta (sem JSON de erro: pode ter sido gerada, quem trata é
       ws_nota_tentativa_pendente) nem número de DPS que aparece em outra linha autorizada/processando/cancelada. */
    $reId = 0; $reNum = null;
    if (!empty($fatura['nota_id'])) { try {
        $qa = $db->prepare("SELECT s.id, s.provider_id FROM ws_nota n JOIN ws_nfse s ON s.id=n.nfse_id WHERE n.id=? AND s.status='erro' AND s.provider_id LIKE 'DPS%' AND (s.retorno_raw LIKE '%\"erro%' OR s.retorno_raw LIKE '%E2404%') AND LOWER(s.retorno_raw) NOT LIKE '%duplicidade%' LIMIT 1");
        $qa->execute([(int)$fatura['nota_id']]); $ant = $qa->fetch(PDO::FETCH_ASSOC);
        if ($ant && preg_match('/^DPS\d{7}\d\d{14}\d{5}(\d{15})$/', (string)$ant['provider_id'], $mm) && (int)$mm[1] > 0) {
            $qb = $db->prepare("SELECT COUNT(*) FROM ws_nfse WHERE id<>? AND provider_id=? AND status IN ('autorizada','processando','cancelada')"); $qb->execute([(int)$ant['id'], (string)$ant['provider_id']]);
            if ((int)$qb->fetchColumn() === 0) { $reId = (int)$ant['id']; $reNum = (int)$mm[1]; }
        }
    } catch (Throwable $e) {} }
    [$xml, $id, $nDps] = ws_nfsen_montar_dps($c, $itens, $cliente, $obs, $cert, $pkey, $reNum);
    $valor = 0.0; foreach ($itens as $it) $valor += max(0, round((float)$it['qtd'] * (float)$it['valor_unit'] - (float)$it['desconto'], 2));
    if ($reId > 0) {
        $db->prepare("UPDATE ws_nfse SET fatura_id=?, cliente_id=?, valor=?, status='processando', provider_id=?, numero=NULL, codigo_verificacao=NULL, url_pdf=NULL, url_xml=NULL, retorno_raw=NULL WHERE id=?")
           ->execute([$fatura['id'] ?? null, $cliente['id'], round($valor, 2), $id, $reId]);
        $nfseId = $reId;
    } else {
        $db->prepare("INSERT INTO ws_nfse (fatura_id,cliente_id,valor,status,provider_id) VALUES (?,?,?, 'processando', ?)")->execute([$fatura['id'] ?? null, $cliente['id'], round($valor, 2), $id]);
        $nfseId = (int)$db->lastInsertId();
    }
    $u = ws_nfsen_urls($c);
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['sefin'] . '/nfse', ['dpsXmlGZipB64' => base64_encode(gzencode('<?xml version="1.0" encoding="UTF-8"?>' . $xml))], $cert, $pkey, ['Content-Type: application/json']);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    $chave = is_array($j) ? (string)($j['chaveAcesso'] ?? '') : ''; $numero = null; $cod = null; $urlXml = null;
    if (is_array($j) && !empty($j['nfseXmlGZipB64'])) {
        $nx = @gzdecode((string)base64_decode($j['nfseXmlGZipB64'])); if ($nx !== false && preg_match('#<nNFSe>(\d+)</nNFSe>#', $nx, $m)) $numero = $m[1];
        if ($nx !== false) {
            @mkdir(WS_CACHE . '/notas_xml/nfse', 0750, true);
            $nomeArq = preg_replace('/\D/', '', $chave ?: $id) . '.xml';
            @file_put_contents(WS_CACHE . '/notas_xml/nfse/' . $nomeArq, $nx);
            $urlXml = 'cache/notas_xml/nfse/' . $nomeArq;
        }
    }
    $ok = ($code >= 200 && $code < 300 && $chave !== '');
    $msg = '';
    if (!$ok) {
        if ($code === 0) $msg = 'Sem conexão com a Sefin Nacional: ' . $err;
        elseif (is_array($j) && !empty($j['erros'])) { $p = []; foreach ((array)$j['erros'] as $e) $p[] = (is_array($e) ? trim(($e['codigo'] ?? '') . ' ' . ($e['descricao'] ?? ($e['mensagem'] ?? ''))) : (string)$e); $msg = implode(' | ', $p); }
        else $msg = 'HTTP ' . $code . ': ' . substr((string)$raw, 0, 300);
    }
    $db->prepare("UPDATE ws_nfse SET status=?, provider_id=?, numero=?, codigo_verificacao=?, url_pdf=?, url_xml=?, retorno_raw=? WHERE id=?")
       ->execute([$ok ? 'autorizada' : 'erro', $chave ?: $id, $numero, $chave ?: null, $ok ? 'fiscal.php?p=danfse&id=' . $nfseId : null, $urlXml, (string)$raw, $nfseId]);
    ws_evento($db, (int)$cliente['id'], 'nfse', $ok ? 'NFS-e Nacional autorizada' : 'Falha ao emitir NFS-e Nacional');
    return ['ok' => $ok, 'erro' => $msg, 'raw' => $raw, 'nfse_id' => $nfseId];
}

/* 14/11/2026: CONSULTA de uma tentativa pelo identificador da DPS (GET {sefin}/dps/{id}). Conferida na Sefin de produção: DPS da NFS-e nº 2 → HTTP 200 com
   "chaveAcesso"; DPS inexistente → HTTP 404 E2404 ("Não foi gerada uma NFS-e com o identificador de DPS informado"). Usada antes de emitir de novo uma nota cuja
   tentativa anterior ficou sem resposta: se a Sefin gerou a NFS-e, ela é registrada (XML baixado de GET {sefin}/nfse/{chave}) e nada é reenviado.
   @return array ['ok' (autorizada),'erro','sem_resposta' (Sefin não respondeu: não dá para decidir)] */
function ws_nfsen_consultar(PDO $db, int $nfseId): array {
    $st = $db->prepare("SELECT * FROM ws_nfse WHERE id=?"); $st->execute([$nfseId]); $n = $st->fetch(PDO::FETCH_ASSOC);
    $dps = (string)($n['provider_id'] ?? '');
    if (!$n || strncmp($dps, 'DPS', 3) !== 0) return ['ok' => false, 'erro' => 'Tentativa sem identificador de DPS.', 'sem_resposta' => false];
    $c = ws_nfse_config(); [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return ['ok' => false, 'erro' => $erroC, 'sem_resposta' => true];
    $u = ws_nfsen_urls($c);
    [$code, $raw, $err] = ws_nfsen_http('GET', $u['sefin'] . '/dps/' . rawurlencode($dps), null, $cert, $pkey);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    if ($code === 404 && is_array($j)) {   // a Sefin não gerou NFS-e para esta DPS: a tentativa fica resolvida (não é consultada de novo) e a nota pode ir com número novo
        $db->prepare("UPDATE ws_nfse SET status='erro', retorno_raw=? WHERE id=?")->execute([(string)$raw, $nfseId]);
        return ['ok' => false, 'erro' => 'A Sefin não gerou NFS-e para a tentativa anterior.', 'sem_resposta' => false];
    }
    $chave = is_array($j) ? preg_replace('/\D/', '', (string)($j['chaveAcesso'] ?? '')) : '';
    if ($code < 200 || $code >= 300 || $chave === '') return ['ok' => false, 'erro' => $code === 0 ? ('Sem conexão com a Sefin Nacional: ' . $err) : ('HTTP ' . $code), 'sem_resposta' => true];
    $numero = null; $urlXml = null; $raw2 = '';
    [$code2, $raw2] = ws_nfsen_http('GET', $u['sefin'] . '/nfse/' . rawurlencode($chave), null, $cert, $pkey);
    $j2 = is_string($raw2) ? json_decode($raw2, true) : null;
    if (is_array($j2) && !empty($j2['nfseXmlGZipB64'])) {
        $nx = @gzdecode((string)base64_decode($j2['nfseXmlGZipB64']));
        if ($nx !== false) {
            if (preg_match('#<nNFSe>(\d+)</nNFSe>#', $nx, $m)) $numero = $m[1];
            @mkdir(WS_CACHE . '/notas_xml/nfse', 0750, true); @file_put_contents(WS_CACHE . '/notas_xml/nfse/' . $chave . '.xml', $nx); $urlXml = 'cache/notas_xml/nfse/' . $chave . '.xml';
        }
    }
    $db->prepare("UPDATE ws_nfse SET status='autorizada', provider_id=?, numero=?, codigo_verificacao=?, url_pdf=?, url_xml=?, retorno_raw=? WHERE id=?")
       ->execute([$chave, $numero, $chave, 'fiscal.php?p=danfse&id=' . $nfseId, $urlXml, is_string($raw2) && $raw2 !== '' ? $raw2 : (string)$raw, $nfseId]);
    ws_evento($db, (int)$n['cliente_id'], 'nfse', 'NFS-e Nacional autorizada (confirmada por consulta à Sefin)');
    return ['ok' => true, 'erro' => '', 'sem_resposta' => false];
}

/** Baixa o DANFSe (PDF) da NFS-e pela chave. @return array [ok, erro, pdf] */
function ws_nfsen_danfse(PDO $db, int $nfseId): array {
    $st = $db->prepare("SELECT codigo_verificacao chave FROM ws_nfse WHERE id=?"); $st->execute([$nfseId]); $chave = (string)$st->fetchColumn();
    if ($chave === '') return [false, 'Nota sem chave de acesso.', ''];
    $c = ws_nfse_config(); [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c); if (!$okC) return [false, $erroC, ''];
    $u = ws_nfsen_urls($c); [$code, $raw, $err] = ws_nfsen_http('GET', $u['danfse'] . '/' . rawurlencode($chave), null, $cert, $pkey, ['Accept: application/pdf']);
    if ($code >= 200 && $code < 300 && is_string($raw) && strncmp($raw, '%PDF', 4) === 0) return [true, '', $raw];
    return [false, 'DANFSe indisponível (HTTP ' . $code . ') ' . $err, ''];
}

/* ------------------------------------------------------------------------------------------------------------------
 * CANCELAMENTO da NFS-e Nacional (evento 101101) — 11/11/2026.
 * Pedido de registro de evento: POST {sefin}/nfse/{chaveAcesso}/eventos com {"pedidoRegistroEventoXmlGZipB64": gzip+base64 do
 * <pedRegEvento> ASSINADO com o A1 do prestador}. Id do infPedReg = "PRE" + chave (50) + "101101". Motivos (cMotivo): 1 erro na
 * emissão, 2 serviço não prestado, 9 outros; xMotivo de 15 a 255 caracteres. Só o NÍVEL 3+ cancela (a tela já esconde o botão).
 * ATENÇÃO — conferir em PRODUÇÃO RESTRITA, como o resto do módulo: formato do Id, nPedRegEvento e nome do campo do JSON.
 * A resposta da Sefin fica em cache/nfse_xml/<chave>-cancelamento.json (a tabela ws_nfse não ganha coluna nova).
 * ------------------------------------------------------------------------------------------------------------------ */
function ws_nfsen_motivos_cancelamento(): array { return [1 => 'Erro na emissão', 2 => 'Serviço não prestado', 9 => 'Outros']; }

/** Assinatura XMLDSig (enveloped) sobre o elemento $tag (Id = $id) — igual à da DPS, para qualquer pedido assinado. */
function ws_nfsen_assinar_pedido(string $xml, string $tag, string $id, array $c, string $certPem, string $pkeyPem): string {
    $alg = (($c['nfsen_algoritmo'] ?? 'sha256') === 'sha1') ? ['sha1', 'http://www.w3.org/2000/09/xmldsig#rsa-sha1', 'http://www.w3.org/2000/09/xmldsig#sha1', OPENSSL_ALGO_SHA1]
                                                            : ['sha256', 'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256', 'http://www.w3.org/2001/04/xmlenc#sha256', OPENSSL_ALGO_SHA256];
    $dom = new DOMDocument('1.0', 'UTF-8'); $dom->preserveWhiteSpace = true; $dom->loadXML($xml);
    $inf = $dom->getElementsByTagName($tag)->item(0);
    $inf->setIdAttribute('Id', true);
    $digest = base64_encode(hash($alg[0], $inf->C14N(false, false), true));
    $dsig = 'http://www.w3.org/2000/09/xmldsig#';
    $signedInfo = '<SignedInfo xmlns="' . $dsig . '"><CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></CanonicalizationMethod>'
        . '<SignatureMethod Algorithm="' . $alg[1] . '"></SignatureMethod><Reference URI="#' . $id . '"><Transforms><Transform Algorithm="' . $dsig . 'enveloped-signature"></Transform>'
        . '<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"></Transform></Transforms><DigestMethod Algorithm="' . $alg[2] . '"></DigestMethod><DigestValue>' . $digest . '</DigestValue></Reference></SignedInfo>';
    $sd = new DOMDocument(); $sd->loadXML($signedInfo); $canon = $sd->documentElement->C14N(false, false);
    $sig = ''; openssl_sign($canon, $sig, $pkeyPem, $alg[3]);
    $b64 = preg_replace('/-----[^-]+-----|\s+/', '', $certPem);
    $signature = '<Signature xmlns="' . $dsig . '">' . $signedInfo . '<SignatureValue>' . base64_encode($sig) . '</SignatureValue><KeyInfo><X509Data><X509Certificate>' . $b64 . '</X509Certificate></X509Data></KeyInfo></Signature>';
    $frag = $dom->createDocumentFragment(); $frag->appendXML($signature); $dom->documentElement->appendChild($frag);
    return $dom->saveXML($dom->documentElement);
}

/** Monta e ASSINA o pedido de cancelamento. @return array [xml, id] */
function ws_nfsen_montar_cancelamento(array $c, string $chave, int $cMotivo, string $xMotivo, string $certPem, string $pkeyPem): array {
    $cnpj = ws_nfse_so_num($c['cnpj']); $chave = ws_nfse_so_num($chave);
    $id = 'PRE' . $chave . '101101';
    $xMotivo = trim(preg_replace('/\s+/u', ' ', (string)preg_replace('/[\x00-\x1F\x7F]/u', ' ', $xMotivo)));
    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $amb = (($c['ambiente'] ?? '') === 'producao') ? 1 : 2;
    $xml = '<pedRegEvento xmlns="http://www.sped.fazenda.gov.br/nfse" versao="1.01"><infPedReg Id="' . $id . '">'
        . '<tpAmb>' . $amb . '</tpAmb><verAplic>WellSystem</verAplic><dhEvento>' . $agora->format('Y-m-d\TH:i:sP') . '</dhEvento>'
        . '<CNPJAutor>' . $cnpj . '</CNPJAutor><chNFSe>' . $chave . '</chNFSe><nPedRegEvento>1</nPedRegEvento>'
        . '<e101101><xDesc>Cancelamento de NFS-e</xDesc><cMotivo>' . $cMotivo . '</cMotivo><xMotivo>' . ws_nfsen_x($xMotivo) . '</xMotivo></e101101>'
        . '</infPedReg></pedRegEvento>';
    return [ws_nfsen_assinar_pedido($xml, 'infPedReg', $id, $c, $certPem, $pkeyPem), $id];
}

/** Cancela uma NFS-e Nacional AUTORIZADA. Devolve ['ok','erro','raw']. Marca ws_nfse e a nota (ws_nota) como 'cancelada' só se a Sefin aceitar. */
function ws_nfsen_cancelar(PDO $db, int $nfseId, int $cMotivo, string $xMotivo): array {
    $st = $db->prepare("SELECT * FROM ws_nfse WHERE id=?"); $st->execute([$nfseId]); $n = $st->fetch();
    if (!$n) return ['ok' => false, 'erro' => 'Nota não encontrada.'];
    if ($n['status'] === 'cancelada') return ['ok' => false, 'erro' => 'Esta nota já está cancelada.'];
    if ($n['status'] !== 'autorizada') return ['ok' => false, 'erro' => 'Só nota autorizada pode ser cancelada.'];
    $chave = ws_nfse_so_num($n['codigo_verificacao'] ?? '');
    if (strlen($chave) !== 50) return ['ok' => false, 'erro' => 'Esta nota não tem a chave de acesso de 50 dígitos da Sefin Nacional (só NFS-e emitida pelo provedor nacional pode ser cancelada aqui).'];
    if (!isset(ws_nfsen_motivos_cancelamento()[$cMotivo])) return ['ok' => false, 'erro' => 'Escolha o motivo do cancelamento.'];
    $xMotivo = trim(preg_replace('/\s+/u', ' ', $xMotivo));
    if (mb_strlen($xMotivo) < 15) return ['ok' => false, 'erro' => 'Descreva o motivo com pelo menos 15 caracteres.'];
    if (mb_strlen($xMotivo) > 255) $xMotivo = mb_substr($xMotivo, 0, 255);
    $c = ws_nfse_config(); [$okC, $erroC, $cert, $pkey] = ws_nfsen_certificado($c);
    if (!$okC) return ['ok' => false, 'erro' => $erroC];
    $lock = @fopen(WS_CACHE . '/nfse_cancel_' . $nfseId . '.lock', 'c');   // clique duplo não manda o pedido duas vezes
    if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) return ['ok' => false, 'erro' => 'O cancelamento desta nota já está em andamento.'];
    [$xml] = ws_nfsen_montar_cancelamento($c, $chave, $cMotivo, $xMotivo, $cert, $pkey);
    $u = ws_nfsen_urls($c);
    [$code, $raw, $err] = ws_nfsen_http('POST', $u['sefin'] . '/nfse/' . $chave . '/eventos', ['pedidoRegistroEventoXmlGZipB64' => base64_encode(gzencode('<?xml version="1.0" encoding="UTF-8"?>' . $xml))], $cert, $pkey, ['Content-Type: application/json']);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    $ok = ($code >= 200 && $code < 300);
    $msg = '';
    if (!$ok) {
        if ($code === 0) $msg = 'Sem conexão com a Sefin Nacional: ' . $err;
        else {
            $lista = is_array($j) ? ($j['erros'] ?? ($j['erro'] ?? null)) : null;
            if (is_array($lista)) { $p = []; foreach ($lista as $e) $p[] = (is_array($e) ? trim(($e['codigo'] ?? '') . ' ' . ($e['descricao'] ?? ($e['mensagem'] ?? ''))) : (string)$e); $msg = implode(' | ', array_filter($p)); }
            if ($msg === '') $msg = 'HTTP ' . $code . ': ' . substr((string)$raw, 0, 300);
        }
    }
    @mkdir(WS_CACHE . '/notas_xml/nfse', 0750, true);
    @file_put_contents(WS_CACHE . '/notas_xml/nfse/' . $chave . '-cancelamento.json', json_encode(['quando' => date('c'), 'http' => $code, 'motivo' => [$cMotivo, $xMotivo], 'resposta' => $j ?: (string)$raw], JSON_UNESCAPED_UNICODE));
    if ($ok) {
        $db->prepare("UPDATE ws_nfse SET status='cancelada' WHERE id=?")->execute([$nfseId]);
        $db->prepare("UPDATE ws_nota SET status='cancelada' WHERE nfse_id=?")->execute([$nfseId]);
        ws_evento($db, (int)$n['cliente_id'], 'nfse', 'NFS-e Nacional cancelada (' . ws_nfsen_motivos_cancelamento()[$cMotivo] . ')');
    }
    if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    return ['ok' => $ok, 'erro' => $msg, 'raw' => $raw];
}
