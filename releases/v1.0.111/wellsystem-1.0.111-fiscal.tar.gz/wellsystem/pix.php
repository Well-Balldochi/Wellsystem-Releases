<?php
/**
 * WellSystem — PIX copia-e-cola (BR Code / EMV estático) padrão BACEN.
 * Sem dependência externa: monta o payload e calcula o CRC16-CCITT.
 */
function ws_pix_tlv(string $id, string $val): string { return $id . sprintf('%02d', strlen($val)) . $val; }

function ws_pix_crc16(string $str): string {
    $crc = 0xFFFF;
    $len = strlen($str);
    for ($i = 0; $i < $len; $i++) {
        $crc ^= (ord($str[$i]) << 8);
        for ($j = 0; $j < 8; $j++) {
            $crc = ($crc & 0x8000) ? (($crc << 1) ^ 0x1021) : ($crc << 1);
            $crc &= 0xFFFF;
        }
    }
    return strtoupper(sprintf('%04X', $crc));
}

/**
 * Normaliza a chave PIX conforme o tipo (evita QR que não lê no banco).
 *  - telefone: +55DDD9NNNNNNNN   - cpf/cnpj: só dígitos   - email/aleatoria: como está.
 * Se $tipo vazio, tenta detectar (email tem @, 32 chars/hífen = aleatória, dígitos = telefone/CPF).
 */
function ws_pix_chave(string $chave, string $tipo = ''): string {
    $chave = trim($chave);
    $dig = preg_replace('/\D/', '', $chave);
    if ($tipo === '') {
        if (strpos($chave, '@') !== false) $tipo = 'email';
        elseif (preg_match('/[a-z\-]/i', $chave) && strlen($dig) < 11) $tipo = 'aleatoria';
        elseif (strlen($dig) === 11 || strlen($dig) === 10) $tipo = 'telefone';
        elseif (strlen($dig) === 14) $tipo = 'cnpj';
        else $tipo = 'aleatoria';
    }
    switch ($tipo) {
        case 'telefone':
            if (strpos($chave, '+55') === 0) return $chave;
            if (strlen($dig) === 11 || strlen($dig) === 10) return '+55' . $dig;
            return $chave;
        case 'cpf': case 'cnpj': return $dig ?: $chave;
        default: return $chave;   // email, aleatória
    }
}

/** Monta o PIX copia-e-cola. $chave = chave PIX; $valor 0 = sem valor fixo. */
function ws_pix_emv(string $chave, string $nome, string $cidade, float $valor = 0, string $txid = '***'): string {
    $chave  = trim($chave);
    $nome   = substr(preg_replace('/[^A-Za-z0-9 ]/', '', strtoupper($nome)), 0, 25) ?: 'RECEBEDOR';
    $cidade = substr(preg_replace('/[^A-Za-z0-9 ]/', '', strtoupper($cidade)), 0, 15) ?: 'CIDADE';
    $txid   = substr(preg_replace('/[^A-Za-z0-9]/', '', $txid), 0, 25) ?: '***';

    $mai = ws_pix_tlv('00', 'br.gov.bcb.pix') . ws_pix_tlv('01', $chave);
    $p  = ws_pix_tlv('00', '01');
    $p .= ws_pix_tlv('26', $mai);
    $p .= ws_pix_tlv('52', '0000');
    $p .= ws_pix_tlv('53', '986');
    if ($valor > 0) $p .= ws_pix_tlv('54', number_format($valor, 2, '.', ''));
    $p .= ws_pix_tlv('58', 'BR');
    $p .= ws_pix_tlv('59', $nome);
    $p .= ws_pix_tlv('60', $cidade);
    $p .= ws_pix_tlv('62', ws_pix_tlv('05', $txid));
    $p .= '6304';
    return $p . ws_pix_crc16($p);
}

/**
 * Monta o txid do Pix a partir do NOME do cliente em "CamelCase" — iniciais maiúsculas de cada palavra,
 * sem espaço e sem acento — ex.: "MARIA DA SILVA" -> "MariaDaSilva". Continua alfanumérico puro (exigência
 * do BR Code, campo 62-05) e no máximo 25 caracteres, então o QR permanece válido. Sem nome, cai em "WS<id>".
 */
function ws_pix_txid_nome($nome, $fallbackId): string {
    $nn = @iconv('UTF-8', 'ASCII//TRANSLIT', (string)$nome);
    if ($nn === false || $nn === '') $nn = (string)$nome;
    $txid = '';
    foreach (preg_split('/\s+/', trim($nn), -1, PREG_SPLIT_NO_EMPTY) as $pal) {
        $pal = preg_replace('/[^A-Za-z0-9]/', '', $pal);
        if ($pal !== '') $txid .= ucfirst(strtolower($pal));
    }
    return $txid !== '' ? substr($txid, 0, 25) : ('WS' . (int)$fallbackId);
}
