<?php
/**
 * EMERGÊNCIA DO RADIUS — "Qualquer login".
 *
 * Cópia fiel do que existe no módulo da OLT (olt_huawei.php: radius_panel_get / radius_panel_set /
 * radius_emergencia), trazida para o código raiz para aparecer em Manutenção do WellSystem.
 *
 * O QUE FAZ: fala DIRETO com o painel de cada concentrador — não passa pelo Radius, de propósito.
 * É justamente para quando o Radius está fora. Posta `rad=3` (Qualquer login: todo cliente
 * autentica, inclusive bloqueado) ou `rad=0` (volta ao Radius normal).
 *
 * CONFIGURAÇÃO COMPARTILHADA: lê e grava o MESMO arquivo que a tela da OLT usa
 * (cache_trafego/olt_radpanel.json). Configurar num lugar vale no outro — duas cópias da mesma
 * credencial seriam duas chances de ficarem diferentes na hora do aperto.
 *
 * SEGURANÇA: é ação de emergência que libera cliente bloqueado. Quem chama decide a permissão;
 * na Manutenção do WellSystem está atrás do nível 3 + senha, como o resto daquela tela.
 */

if (!defined('WS_DIR')) require_once __DIR__ . '/config.php';

/**
 * Onde está o olt_radpanel.json. Procura nas mesmas pastas que o módulo da OLT usa e devolve a
 * PRIMEIRA que já tem o arquivo; se nenhuma tiver, devolve a primeira gravável (para criar).
 */
function ws_radpanel_file(): string {
    $cands = [];
    if (function_exists('ws_olt_cache_dirs')) {
        $cands = ws_olt_cache_dirs();                       // olt_link.php: olt/, raiz e /tmp
    } else {
        $cands = [__DIR__ . '/olt/cache_trafego', __DIR__ . '/cache_trafego',
                  sys_get_temp_dir() . '/acellApp_cache_trafego'];
    }
    foreach ($cands as $d) { if (is_file($d . '/olt_radpanel.json')) return $d . '/olt_radpanel.json'; }
    foreach ($cands as $d) { if (is_dir($d) && is_writable($d)) return $d . '/olt_radpanel.json'; }
    return (WS_CACHE ?: sys_get_temp_dir()) . '/olt_radpanel.json';
}

/** Painéis configurados. Estrutura: [['nome','base','user','pass','dmco','inter','defrat','on'], ...] */
function ws_radpanel_load(): array {
    $f = ws_radpanel_file();
    $c = is_file($f) ? json_decode((string)@file_get_contents($f), true) : [];
    if (!is_array($c)) $c = [];
    $ps = $c['paineis'] ?? [];
    return is_array($ps) ? array_values($ps) : [];
}

/**
 * Grava os painéis. A senha em branco NÃO apaga a que já existe — a tela nunca devolve a senha
 * gravada (só um marcador), então um "salvar" sem digitar de novo apagaria a credencial.
 */
function ws_radpanel_save(array $paineis): bool {
    $antigos = ws_radpanel_load();
    foreach ($paineis as $i => &$p) {
        if ((string)($p['pass'] ?? '') === '' && isset($antigos[$i]['pass'])) $p['pass'] = $antigos[$i]['pass'];
    }
    unset($p);
    $f = ws_radpanel_file();
    $r = @file_put_contents($f, json_encode(['paineis' => array_values($paineis)], JSON_UNESCAPED_UNICODE));
    if ($r !== false) @chmod($f, 0666);
    return $r !== false;
}

/**
 * Aplica o modo num painel. $rad = 3 (Qualquer login) ou 0 (Radius).
 *
 * A sequência de chamadas imita EXATAMENTE o que o navegador faz ao operar o painel — inclusive
 * abrir a página de login antes, para pegar o PHPSESSID. Uma única conexão cURL guarda o cookie
 * de sessão entre as chamadas; conexões separadas perdem o cookie e o painel devolve erro.
 * Isto é cópia fiel de olt_radpanel_aplicar(); qualquer mudança tem que ser feita nos dois.
 */
function ws_radpanel_aplicar(array $p, int $rad): array {
    $base = trim((string)($p['base'] ?? ''));
    $base = preg_replace('#/[^/]*\.php.*$#i', '', $base);   // tira /index.php do fim, se vier
    $base = rtrim($base, '/');
    $nome = trim((string)($p['nome'] ?? '')) !== '' ? $p['nome'] : $base;
    if ($base === '')                 return ['nome' => $nome, 'ok' => false, 'msg' => 'sem URL'];
    if (!function_exists('curl_init')) return ['nome' => $nome, 'ok' => false, 'msg' => 'cURL indisponível no PHP'];

    $origin = preg_replace('#^(https?://[^/]+).*$#i', '$1', $base);
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/150 Safari/537.36',
        CURLOPT_COOKIEFILE => '',   // cookies na memória desta conexão
    ]);
    $post = function ($url, $fields, $to = 12, $ref = null) use ($ch, $base, $origin) {
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_TIMEOUT => $to, CURLOPT_REFERER => ($ref ?: $base . '/main.php'),
            CURLOPT_HTTPHEADER => ['X-Requested-With: XMLHttpRequest',
                'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
                'Origin: ' . $origin, 'Accept: */*', 'Accept-Language: pt-BR,pt;q=0.9'],
        ]);
        $r = curl_exec($ch); $e = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        return [$r, $e, $code];
    };

    $post($base . '/index.php', []);                                   // página de login (pega o PHPSESSID)
    $u = (string)($p['user'] ?? ''); $pw = (string)($p['pass'] ?? '');
    // db_read.php É o login: valida E cria a sessão, igual ao navegador.
    list($lr, $le, $lc) = $post($base . '/php/db_read.php', [
        'select' => 'id|name|email|level|acces', 'table' => 'auth',
        'colun'  => 'login =|and|passwd =|and|acces =', 'search' => $u . '|' . $pw . '|1', 'crypt' => '1',
    ], 12, $base . '/index.php');
    if ($le) { curl_close($ch); return ['nome' => $nome, 'ok' => false, 'msg' => 'login: ' . $le]; }

    $post($base . '/main.php', [], 12, $base . '/index.php');          // entra no painel
    $post($base . '/frm_pppoe.php', [], 12, $base . '/main.php');       // abre PPPoE/IPoE
    $post($base . '/tab_radius.php', [], 12, $base . '/main.php');      // abre a aba Radius
    $post($base . '/php/read_radiusdb.php', [], 12, $base . '/main.php'); // carrega a config atual

    // Só o campo `rad` muda; dmco/inter/defrat vão como configurados para não alterar o resto.
    $campos = [
        'dmco'   => (((string)($p['dmco']  ?? '') !== '') ? $p['dmco']  : '3799'),
        'inter'  => (((string)($p['inter'] ?? '') !== '') ? $p['inter'] : '300'),
        'rad'    => $rad,
        'defrat' => (((string)($p['defrat'] ?? '') !== '') ? $p['defrat'] : '3'),
    ];
    list($r1, $e1, $c1) = $post($base . '/php/update_radiusdb.php', $campos);
    usleep(500000);                                                     // deixa o banco gravar
    list($r2, $e2, $c2) = $post($base . '/php/update_radfile.php', $campos, 40);  // regen do accel-ppp demora
    curl_close($ch);

    $corte = fn($s) => mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags((string)$s))), 0, 120);
    $ok = ($c1 >= 200 && $c1 < 400 && !$e1);
    return [
        'nome' => $nome, 'ok' => $ok,
        'msg'  => ($ok ? 'aplicado (rad=' . $rad . ')' : 'não aplicou'),
        'diag' => 'login[' . $lc . ']=' . $corte($lr) . ' · db[' . $c1 . ']=' . $corte($r1) . ' · file[' . $c2 . ']=' . $corte($r2),
    ];
}

/**
 * Aplica o modo em todos os painéis marcados ("aplicar"). Sem nenhum marcado, aplica em todos —
 * é emergência: o padrão tem que ser abrangente, não restritivo.
 * $modo: 'emergencia' (rad=3) ou 'radius' (rad=0).
 */
function ws_radpanel_acionar(string $modo): array {
    $rad = ($modo === 'emergencia') ? 3 : 0;
    $ps  = ws_radpanel_load();
    if (!$ps) return ['ok' => false, 'msg' => 'Nenhum painel configurado.', 'itens' => []];
    $alvo = array_values(array_filter($ps, fn($p) => !empty($p['on'])));
    if ($alvo) $ps = $alvo;
    $itens = [];
    foreach ($ps as $p) $itens[] = ws_radpanel_aplicar($p, $rad);
    $bons = count(array_filter($itens, fn($i) => !empty($i['ok'])));
    return ['ok' => $bons > 0, 'msg' => $bons . ' de ' . count($itens) . ' painel(is) aplicado(s)', 'itens' => $itens];
}
