<?php
/**
 * WellSystem Radius — biblioteca de sincronização com o FreeRADIUS.
 *
 * O WellSystem é a FONTE DA VERDADE: escreve nas tabelas padrão do FreeRADIUS
 * (radcheck/radusergroup/radgroupreply/radreply) a partir de ws_contrato e ws_plano.
 * O FreeRADIUS (módulo sql) apenas LÊ para autenticar o PPPoE.
 *
 *   ws_plano     → grupo "plano_{id}"  (radgroupreply: Mikrotik-Rate-Limit)
 *   ws_contrato  → radcheck (senha) + radusergroup (grupo do plano OU 'bloqueado')
 *   inadimplente → grupo 'bloqueado' + desconexão CoA imediata
 */
require_once __DIR__ . '/config.php';

const WS_GRUPO_BLOQUEIO = 'bloqueado';
// Velocidade do cliente bloqueado (pedido do provedor). kbit inteiro: o accel trata 0 como "sem limite".
const WS_RATE_BLOQUEIO = '10k/10k';

/* ---------------------------------------------------------- helpers rad */

/** Nome do grupo RADIUS de um plano. */
function ws_rad_grupo_plano(int $planoId): string { return 'plano_' . $planoId; }

/**
 * Valor Mikrotik-Rate-Limit ("rx/tx" = upload/download do cliente).
 *
 * MEGA FECHADO: o accel-ppp conta 1 Mega = 1024k. Plano de 50 Mega enviado como 50000k (ou "50M",
 * que ele converte para 50000k) aparecia e entregava 48,83; 500 virava 488,28; 300 virava 292,97.
 * Confirmado no painel do concentrador. Agora vai Mega × 1024: 50 Mega = 51200k, 500 Mega = 512000k —
 * o concentrador mostra e entrega exatamente 50 e 500. (No Mikrotik fica 2,4% acima do nominal,
 * nunca abaixo.) O cadastro do plano continua em kbps (50 Mega = 50000).
 */
function ws_rad_rate_limit(int $upKbps, int $downKbps): string {
    $fmt = function (int $k): string { return ($k > 0 ? (int)round($k * 1.024) : 0) . 'k'; };
    return $fmt($upKbps) . '/' . $fmt($downKbps);
}

/** Substitui (delete+insert) um atributo simples numa tabela username-based. */
function ws_rad_set_attr(PDO $db, string $tabela, string $username, string $attr, string $value, string $op = ':='): void {
    /* (06/11/2026) SÓ GRAVA O QUE MUDOU. O cron radius_sync (a cada 2 min) refazia DELETE+INSERT de TODOS os logins em
     * autocommit: milhares de gravações com fsync por passada, o que travava o banco (baixa manual levou 89 s, gerar boleto 13 s)
     * e enchia o binlog do espelho. Linha já igual = nada a fazer; o resultado final no banco é o mesmo de antes. */
    $q = $db->prepare("SELECT op, value FROM $tabela WHERE username=? AND attribute=?");
    $q->execute([$username, $attr]); $atuais = $q->fetchAll(PDO::FETCH_NUM);
    if ($value === '' && !$atuais) return;
    if ($value !== '' && count($atuais) === 1 && (string)$atuais[0][0] === $op && (string)$atuais[0][1] === $value) return;
    $db->prepare("DELETE FROM $tabela WHERE username=? AND attribute=?")->execute([$username, $attr]);
    if ($value !== '')
        $db->prepare("INSERT INTO $tabela (username,attribute,op,value) VALUES (?,?,?,?)")->execute([$username, $attr, $op, $value]);
}

/* ---------------------------------------------------------- sync plano */

/** Reflete um plano no grupo RADIUS (rate-limit). Chame ao salvar/alterar plano.
 *  @return bool true quando a velocidade gravada MUDOU (quem está conectado precisa recebê-la). */
function ws_rad_sync_plano(PDO $db, array $plano): bool {
    $grp = ws_rad_grupo_plano((int)$plano['id']);
    $rate = ws_rad_rate_limit((int)$plano['up_kbps'], (int)$plano['down_kbps']);
    $at = $db->prepare("SELECT value FROM radgroupreply WHERE groupname=? AND attribute='Mikrotik-Rate-Limit'");
    $at->execute([$grp]);
    $atual = $at->fetchAll(PDO::FETCH_COLUMN);
    if (count($atual) === 1 && (string)$atual[0] === $rate) return false;   // já está certo: nada a fazer
    $db->prepare("DELETE FROM radgroupreply WHERE groupname=? AND attribute='Mikrotik-Rate-Limit'")->execute([$grp]);
    $db->prepare("INSERT INTO radgroupreply (groupname,attribute,op,value) VALUES (?, 'Mikrotik-Rate-Limit', ':=', ?)")
       ->execute([$grp, $rate]);
    return true;
}

/** Garante o grupo de bloqueio (pool de corte; ver o porquê no comentário abaixo). */
/**
 * Garante o grupo de bloqueio com os atributos que REALMENTE bloqueiam.
 *
 * O QUE ESTAVA ERRADO (1ª correção)
 * O grupo nascia só com "Mikrotik-Rate-Limit 256k/256k". Num parque Mikrotik isso é uma redução
 * severa de velocidade; num accel-ppp não é bloqueio nenhum — o inadimplente continuava navegando,
 * devagar. E o sistema registrava o bloqueio como feito.
 *
 * O QUE BLOQUEIA DE VERDADE
 * A pool de corte: o cliente recebe um endereço da faixa presa (100.100.x no padrão do MK-Auth) e
 * só alcança a página de aviso. É assim que o parque já funciona hoje — ver ws_mk_pool_corte() no
 * mkauth_bridge.php, que lê o nome da pool de cache/mkauth.json e assume "pgcorte" por padrão.
 *
 * ITEM 8 — O "REFORÇO" TAMBÉM SAIU
 * A 1ª correção manteve "Mikrotik-Rate-Limit 256k/256k" ao lado do Framed-Pool, como reforço para
 * quem tem concentrador Mikrotik. Na prática isso reintroduz o MESMO problema que a correção
 * resolveu: um cliente em 256k/256k não está bloqueado, está lento — ele liga reclamando de
 * internet ruim, não de bloqueio, e o suporte perde tempo até descobrir que é bloqueio mesmo. Só
 * o Framed-Pool bloqueia de verdade; reduzir velocidade não deve fazer parte do bloqueio nunca
 * mais. Mikrotik-Address-List continua — é para o walled garden (página de aviso), não é throttle.
 */
function ws_rad_garantir_grupo_bloqueio(PDO $db): void {
    $pool = function_exists('ws_mk_pool_corte') ? ws_mk_pool_corte() : 'pgcorte';

    $desejado = [
        'Framed-Pool'           => $pool,        // o que prende o cliente — o bloqueio de verdade
        'Mikrotik-Address-List' => 'bloqueado',  // walled garden (página de aviso), não é throttle
    ];

    $tem = $db->prepare("SELECT COUNT(*) FROM radgroupreply WHERE groupname=? AND attribute=?");
    $ins = $db->prepare("INSERT INTO radgroupreply (groupname,attribute,op,value) VALUES (?,?,':=',?)");
    foreach ($desejado as $attr => $valor) {
        $tem->execute([WS_GRUPO_BLOQUEIO, $attr]);
        if ((int)$tem->fetchColumn() === 0) $ins->execute([WS_GRUPO_BLOQUEIO, $attr, $valor]);
    }
    /* BLOQUEADO AUTENTICA COM 10k/10k (pedido do provedor), preso na pool de corte (página de aviso).
     * Por que não 0M/0M: o accel-ppp trata velocidade 0 como "sem limitador" e deixa a coluna de
     * velocidade vazia — o painel do concentrador mostrava "0 b / NaN undefined". Ele só aceita
     * kbit inteiro (0,1k ou 0,01M viram 0). 10k é o valor escolhido. Garantido com o valor exato — um
     * valor antigo diferente é trocado, e quem está bloqueado e conectado recebe na hora. */
    $vb = $db->prepare("SELECT value FROM radgroupreply WHERE groupname=? AND attribute='Mikrotik-Rate-Limit'");
    $vb->execute([WS_GRUPO_BLOQUEIO]);
    $vbAt = $vb->fetchAll(PDO::FETCH_COLUMN);
    if (!(count($vbAt) === 1 && $vbAt[0] === WS_RATE_BLOQUEIO)) {
        $db->prepare("DELETE FROM radgroupreply WHERE groupname=? AND attribute='Mikrotik-Rate-Limit'")->execute([WS_GRUPO_BLOQUEIO]);
        $ins->execute([WS_GRUPO_BLOQUEIO, 'Mikrotik-Rate-Limit', WS_RATE_BLOQUEIO]);
        try { ws_rad_vel_marcar_grupo($db, WS_GRUPO_BLOQUEIO); } catch (Throwable $e) {}
    }
}

/* -------------------------------------------------------- sync contrato */

/**
 * Reflete um contrato no RADIUS. Define senha, grupo (plano ou bloqueio) e IP fixo.
 * @param bool $bloqueado força o grupo de bloqueio (inadimplente/suspenso).
 */
/**
 * Reflete UM contrato no RADIUS — cobrindo PPPoE **e** IPoE.
 *
 * POR QUE AS DUAS IDENTIDADES
 * Parque misto é a regra, não a exceção (concentradores costumam se chamar "IPOE-PPPOE" justamente
 * por isso). Um contrato pode ter login PPPoE, login IPoE, ou os dois — e cada um é um usuário
 * diferente para o FreeRADIUS.
 *
 * Esta função olhava só o login_pppoe. O efeito era invisível no resumo e grave na prática: a
 * sincronização dizia "772 contratos", e o radcheck ficava com 85, porque os outros eram IPoE e
 * nunca chegavam lá. Nenhum erro em lugar nenhum — os clientes simplesmente não autenticavam, e o
 * número no resumo parecia certo.
 *
 * SENHA DO IPoE
 * No IPoE quem identifica o assinante é a porta/circuito (circuit-id ou MAC), não uma senha
 * digitada. Por isso: havendo senha_ipoe cadastrada, ela é usada como Cleartext-Password; não
 * havendo, o usuário entra com "Auth-Type := Accept" — o FreeRADIUS aceita a identidade e deixa a
 * validação com o concentrador, que é quem sabe de qual porta o pacote veio. Sem isso, o IPoE sem
 * senha ficaria de fora de novo, que é exatamente o problema que esta mudança resolve.
 */
function ws_rad_sync_contrato(PDO $db, array $ct, bool $bloqueado = false): void {
    $derrubarBloqueado = false;
    // Grupo: bloqueio tem prioridade; senão o grupo do plano. Vale para as duas identidades.
    $grupo = $bloqueado ? WS_GRUPO_BLOQUEIO : ws_rad_grupo_plano((int)($ct['plano_id'] ?? 0));

    $identidades = [
        ['login' => trim((string)($ct['login_pppoe'] ?? '')), 'senha' => (string)($ct['senha_pppoe'] ?? ''), 'ipoe' => false],
        ['login' => trim((string)($ct['login_ipoe']  ?? '')), 'senha' => (string)($ct['senha_ipoe']  ?? ''), 'ipoe' => true],
    ];

    foreach ($identidades as $id) {
        $login = $id['login'];
        if ($login === '') continue;

        /* SESSÕES SIMULTÂNEAS — impede o mesmo login em dois lugares ao mesmo tempo.
         *
         * Sem isto, uma senha vazada vira internet compartilhada entre vizinhos: o provedor
         * entrega banda para dois (ou dez) e cobra de um. É o tipo de perda que não aparece em
         * relatório nenhum, porque tudo parece normal.
         *
         * COMO O FREERADIUS DECIDE: ele conta as sessões ABERTAS em radacct para aquele login. Daí
         * uma consequência que precisa ser dita: sessão presa na tabela (concentrador reiniciado
         * sem enviar o "stop") faz o cliente LEGÍTIMO ser recusado com "já está conectado". Duas
         * proteções contra isso — "delete_stale_sessions = yes" no módulo sql, que limpa a sessão
         * velha ao ver a nova, e o limite abaixo, que pode ser afrouxado sem mexer em código.
         *
         * Configurável em cache/radius.json -> {"simultaneas": 1}. Zero desliga a verificação,
         * para quem tem parque com roteador que reconecta antes de fechar a sessão anterior. */
        $simult = 1;
        $arqR = WS_CACHE . '/radius.json';
        if (is_file($arqR)) {
            $jr = json_decode((string)@file_get_contents($arqR), true);
            if (is_array($jr) && isset($jr['simultaneas'])) $simult = max(0, (int)$jr['simultaneas']);
        }
        if ($simult > 0) ws_rad_set_attr($db, 'radcheck', $login, 'Simultaneous-Use', (string)$simult, ':=');
        else             $db->prepare("DELETE FROM radcheck WHERE username=? AND attribute='Simultaneous-Use'")->execute([$login]);

        if ($id['senha'] !== '') {
            // Com senha: autenticação normal por credencial.
            ws_rad_set_attr($db, 'radcheck', $login, 'Cleartext-Password', $id['senha'], ':=');
            $db->prepare("DELETE FROM radcheck WHERE username=? AND attribute='Auth-Type'")->execute([$login]);
        } elseif ($id['ipoe']) {
            // IPoE sem senha: aceita pela identidade (a porta do concentrador é a credencial).
            ws_rad_set_attr($db, 'radcheck', $login, 'Auth-Type', 'Accept', ':=');
            $db->prepare("DELETE FROM radcheck WHERE username=? AND attribute='Cleartext-Password'")->execute([$login]);
        } else {
            // PPPoE sem senha não existe: não inventa credencial, limpa o que houver.
            ws_rad_remover($db, $login);
            continue;
        }

        $qg = $db->prepare("SELECT groupname, priority FROM radusergroup WHERE username=?"); $qg->execute([$login]); $gAtual = $qg->fetchAll(PDO::FETCH_NUM);
        if (!(count($gAtual) === 1 && (string)$gAtual[0][0] === (string)$grupo && (int)$gAtual[0][1] === 1)) {   // só regrava se mudou (06/11/2026)
            $db->prepare("DELETE FROM radusergroup WHERE username=?")->execute([$login]);
            $db->prepare("INSERT INTO radusergroup (username,groupname,priority) VALUES (?,?,1)")->execute([$login, $grupo]);
        }

        /* Velocidade nunca por usuário: liberado recebe a do grupo do plano; bloqueado, a do grupo de
         * bloqueio (10k/10k — ver ws_rad_garantir_grupo_bloqueio). Sobra de versão anterior sai aqui. */
        $delVel = $db->prepare("DELETE FROM radreply WHERE username=? AND attribute='Mikrotik-Rate-Limit'");
        $delVel->execute([$login]);
        // Bloqueado que ainda estava com a velocidade do plano (versão anterior) e está conectado: cai UMA
        // vez e volta com 10k/10k na pool de corte. Não perde serviço — já está bloqueado.
        if ($bloqueado && $delVel->rowCount() > 0) $derrubarBloqueado = true;

        /* ------------------------------------------------------------------------------------
         * RETORNO POR CLIENTE (radreply) — o que este assinante recebe, e só ele.
         *
         * radgroupreply diz o que vale para o GRUPO (a velocidade do plano). radreply diz o que
         * vale para UM login, e vence o grupo. É onde entra tudo que é exceção do assinante:
         *
         *   IP FIXO      -> Framed-IP-Address. O cliente sempre recebe o mesmo endereço. Necessário
         *                   para quem tem câmera, servidor, VPN ou port-forward — sem isso o
         *                   endereço muda a cada reconexão e o acesso remoto para de funcionar.
         *   POOL PRÓPRIA -> Framed-Pool. Tira este cliente da pool geral e o põe numa faixa
         *                   específica: bloco público, faixa de empresa, CGNAT separado, rede de
         *                   teste. Sem isso, a única forma de separar um cliente de faixa era
         *                   mexer no concentrador à mão, fora do sistema — e o que é feito à mão
         *                   fora do sistema se perde na próxima migração.
         *
         * IP FIXO E POOL SÃO EXCLUDENTES, e isto precisa ser tratado e não só documentado: mandar
         * os dois juntos deixa o comportamento na mão do equipamento (a maioria ignora a pool e usa
         * o IP, mas não todos). Havendo os dois preenchidos, o IP FIXO ganha — é a configuração
         * mais específica, e foi ela que alguém digitou para aquele cliente.
         *
         * Bloqueado não recebe pool própria: a pool de bloqueio vem do grupo e tem de prevalecer,
         * senão o inadimplente com pool própria continuaria navegando.
         * -------------------------------------------------------------------------------------- */
        $ipFixo = trim((string)($ct['ip_fixo'] ?? ''));
        $pool   = trim((string)($ct['pool'] ?? ''));

        // BLOQUEADO NÃO RECEBE O IP FIXO: o IP fixo vence a pool de corte no concentrador, e o cliente
        // bloqueado com IP fixo continuava navegando. Desbloqueado, o IP fixo volta sozinho.
        if ($ipFixo !== '' && !$bloqueado) {
            ws_rad_set_attr($db, 'radreply', $login, 'Framed-IP-Address', $ipFixo, ':=');
            $db->prepare("DELETE FROM radreply WHERE username=? AND attribute='Framed-Pool'")->execute([$login]);
        } elseif ($pool !== '' && !$bloqueado) {
            ws_rad_set_attr($db, 'radreply', $login, 'Framed-Pool', $pool, ':=');
            $db->prepare("DELETE FROM radreply WHERE username=? AND attribute='Framed-IP-Address'")->execute([$login]);
        } else {
            $db->prepare("DELETE FROM radreply WHERE username=? AND attribute IN('Framed-IP-Address','Framed-Pool')")->execute([$login]);
        }
    }
    /* NÃO derruba AO VIVO aqui dentro (antes chamava ws_rad_derrubar_contrato direto): esta função
     * roda dentro de requisições da tela (estorno, pagamento, edição de contrato...), e derrubar ao
     * vivo abre conexão com CADA concentrador Mikrotik cadastrado, um a um — se um só estiver fora
     * do ar/lento, a página inteira fica esperando (é o que prendia a tela no estorno até dar F5).
     * Só MARCA como pendente; quem derruba de verdade é o cron (ws_rad_pendentes_processar, a cada
     * 2 min), que já existe pra isso e não trava ninguém olhando a tela. */
    if (!empty($derrubarBloqueado)) {
        foreach ([(string)($ct['login_pppoe'] ?? ''), (string)($ct['login_ipoe'] ?? '')] as $lgB) {
            $lgB = trim($lgB);
            if ($lgB !== '' && ws_rad_sessao_aberta($db, $lgB)) { ws_rad_pendente_marcar($lgB); }
        }
    }
}

/**
 * Remove totalmente um login do RADIUS (contrato cancelado/excluído).
 *
 * @return int quantas linhas foram REALMENTE apagadas. Devolver a contagem não é detalhe: é o que
 *             permite ao resumo da sincronização dizer "apaguei 40 linhas" em vez de "removidos:
 *             896" em toda passagem do cron, mesmo quando não havia nada para apagar. Número que
 *             não muda quando o trabalho já foi feito é número que engana quem tenta conferir.
 */
function ws_rad_remover(PDO $db, string $login): int {
    $n = 0;
    foreach (['radcheck', 'radreply', 'radusergroup'] as $t) {
        $st = $db->prepare("DELETE FROM $t WHERE username=?");
        $st->execute([$login]);
        $n += $st->rowCount();
    }
    return $n;
}

/**
 * GRAVÍSSIMO SE ACONTECER: apaga do RADIUS todo login que autentica (tem senha em `radcheck`) sem
 * ter NENHUM contrato correspondente em `ws_contrato` — nem ativo, nem cancelado, nenhum.
 *
 * ws_rad_sync_tudo() só visita quem está listado em ws_contrato: contrato cancelado é removido do
 * RADIUS (linha 1104), contrato ativo é mantido/atualizado. O que nunca foi tratado era o caso de o
 * `radcheck` ter uma linha para um username que ws_contrato NUNCA conheceu — sobra de importação
 * antiga, teste feito direto no banco, contrato apagado de verdade (DELETE, não cancelado) sem
 * limpar o RADIUS junto, ou qualquer inserção fora do fluxo do sistema. Essa linha nunca aparece no
 * laço de cima, então nunca é removida: o login autentica pra sempre, sem NENHUM cadastro de
 * cliente por trás — exatamente o "ID conectando sem ter cadastro" relatado.
 *
 * Roda dentro de ws_rad_sync_tudo() (cron a cada 2 min) — fica sendo verificado sempre, não só uma
 * vez. Cada remoção fica registrada em cache/radius_orfaos_removidos.csv (quem, quando, de onde
 * veio a sessão se estava conectado na hora) — é uma remoção de acesso, não um ajuste de cadastro,
 * então fica um rastro de auditoria em vez de desaparecer sem aviso.
 */
function ws_rad_remover_orfaos(PDO $db): array {
    $validos = [];
    foreach ($db->query("SELECT login_pppoe, login_ipoe FROM ws_contrato")->fetchAll(PDO::FETCH_NUM) as $row) {
        foreach ($row as $lg) { $lg = trim((string)$lg); if ($lg !== '') $validos[$lg] = true; }
    }
    $usados = $db->query("SELECT username FROM radcheck
                           UNION SELECT username FROM radusergroup
                           UNION SELECT username FROM radreply")->fetchAll(PDO::FETCH_COLUMN);
    $orfaos = [];
    foreach (array_unique($usados) as $u) {
        $u = trim((string)$u);
        if ($u === '' || $u === 'DEFAULT' || isset($validos[$u])) continue;
        $orfaos[] = $u;
    }
    $removidos = 0;
    if ($orfaos) {
        $linhaLog = [];
        foreach ($orfaos as $u) {
            // Sessão aberta AGORA com esse login órfão? Registra de qual IP/NAS, pra investigar
            // por onde essa credencial entrou (OLT liberou sem passar pelo cadastro, teste manual…).
            $sess = null;
            try {
                $s = $db->prepare("SELECT nasipaddress, framedipaddress, callingstationid FROM radacct
                                    WHERE username=? AND acctstoptime IS NULL ORDER BY radacctid DESC LIMIT 1");
                $s->execute([$u]); $sess = $s->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable $e) {}
            $removidos += ws_rad_remover($db, $u);
            $linhaLog[] = [date('Y-m-d H:i:s'), $u, $sess['nasipaddress'] ?? '', $sess['framedipaddress'] ?? '', $sess['callingstationid'] ?? ''];
        }
        try {
            $f = (defined('WS_CACHE') ? WS_CACHE : sys_get_temp_dir()) . '/radius_orfaos_removidos.csv';
            $novoArq = !is_file($f);
            $fp = @fopen($f, 'a');
            if ($fp) {
                if ($novoArq) fputcsv($fp, ['quando', 'login', 'nas_ip', 'ip_do_cliente', 'mac', 'motivo']);
                foreach ($linhaLog as $l) fputcsv($fp, array_merge($l, ['sem contrato em ws_contrato']));
                fclose($fp);
            }
        } catch (Throwable $e) {}
    }
    return ['orfaos' => count($orfaos), 'removidos' => $removidos, 'logins' => $orfaos];
}

/* --------------------------------------------------- bloqueio / desbloqueio */

/** Um contrato está inadimplente? (tem fatura vencida em aberto). */
/** Dias de atraso em que o cliente é bloqueado (padrão 5; editável em Config → Cobrança).
 *  Com 5: título vencido há 5 dias OU MAIS bloqueia (vencido há 4 ainda não). */
function ws_dias_bloqueio(): int {
    $f = WS_CACHE . '/cobranca.json';
    if (is_file($f)) { $j = json_decode(@file_get_contents($f), true); if (is_array($j) && isset($j['dias_bloqueio'])) return max(0, (int)$j['dias_bloqueio']); }
    return 5;
}

/** Quantos dias dura o "liberar em confiança" — editável (Clientes → Config → Regras), não fixo
 *  em 3 dias feito antes. Usado em TODOS os lugares que liberam confiança (ficha, lista, ícone rápido). */
function ws_dias_confianca(): int {
    $f = WS_CACHE . '/cobranca.json';
    if (is_file($f)) { $j = json_decode(@file_get_contents($f), true); if (is_array($j) && isset($j['dias_confianca'])) return max(1, (int)$j['dias_confianca']); }
    return 1;   // padrão: 1 dia
}

function ws_rad_inadimplente(PDO $db, int $contratoId): bool {
    $dias = ws_dias_bloqueio();
    $st = $db->prepare("SELECT COUNT(*) FROM ws_fatura
                        WHERE contrato_id=? AND status IN('aberto','vencido','processando') AND vencimento <= DATE_SUB(CURDATE(), INTERVAL ? DAY)");   // <= : vencido há N dias JÁ bloqueia
    $st->execute([$contratoId, $dias]);
    return (int)$st->fetchColumn() > 0;
}

/** Contrato está com desbloqueio EM CONFIANÇA válido (data futura)? */
function ws_rad_em_confianca(array $ct): bool {
    return !empty($ct['confianca_ate']) && strtotime((string)$ct['confianca_ate']) > time();
}

/** Formato aceito no campo "observação" de confiança (legado MK-Auth: sis_cliente.rem_obs, e
 *  também usado pelo painel dos concentradores): uma data (YYYY-MM-DD...) no futuro significa
 *  "liberado em confiança até aquela data". ÚNICO ponto desta checagem em todo o sistema —
 *  antes existiam 2 cópias divergentes (servidores.php tinha um fallback inline duplicado
 *  porque esta função nunca existia de verdade). */
function eh_desbloqueio_confianca(?string $obs): bool {
    $obs = trim((string)$obs);
    if ($obs === '' || !preg_match('/^\d{4}-\d{2}-\d{2}/', $obs)) return false;
    return strtotime(substr($obs, 0, 10) . ' 23:59:59') > time();
}

/** Segundos restantes de confiança, a partir do mesmo formato de eh_desbloqueio_confianca(). */
function obter_tempo_restante_confianca(?string $obs): int {
    $obs = trim((string)$obs);
    if ($obs === '' || !preg_match('/^\d{4}-\d{2}-\d{2}/', $obs)) return 0;
    $fim = strtotime(substr($obs, 0, 10) . ' 23:59:59');
    return max(0, $fim - time());
}

/** ADICIONAL COM BOLETO PRÓPRIO? (14/10/2026) — regra híbrida: adicional SEM boleto próprio acompanha o titular (bloqueia/libera junto); adicional COM boleto próprio segue a regra convencional (as próprias faturas).
 *  "Tem boleto próprio" = fatura não cancelada no nome dele, em aberto/vencida ou com vencimento nos últimos 120 dias (ou futuro). Falha de consulta = false (segue o titular, como sempre foi). */
function ws_rad_adicional_boleto_proprio(PDO $db, int $clienteId): bool {
    static $memo = [];
    if ($clienteId <= 0) return false;
    if (isset($memo[$clienteId])) return $memo[$clienteId];
    try {
        $q = $db->prepare("SELECT 1 FROM ws_fatura WHERE cliente_id=? AND status<>'cancelado' AND (status IN ('aberto','vencido') OR vencimento >= CURDATE() - INTERVAL 120 DAY) LIMIT 1");
        $q->execute([$clienteId]); return $memo[$clienteId] = (bool)$q->fetchColumn();
    } catch (Throwable $e) { return false; }
}
/**
 * REGRA DE OURO — TITULAR E ADICIONAIS ANDAM JUNTOS.
 *   titular bloqueado  → TODOS os adicionais bloqueados;
 *   titular liberado   → TODOS os adicionais liberados (pagamento, confiança, desbloqueio).
 * O adicional segue o TITULAR — as faturas são do titular. Antes cada adicional era julgado pelas
 * próprias faturas (que não existem): o cron nunca o bloqueava junto, e pagamento/confiança do
 * titular não o liberavam.
 * Continuam valendo NO ADICIONAL só: bloqueio manual feito nele individualmente (bloqueio_manual=1),
 * contrato suspenso e cancelado. Bloqueio que veio do titular fica marcado como herdado
 * (bloqueio_manual=2) e sai junto com o do titular.
 * Titular sem contrato ativo: o adicional segue a própria regra.
 * Esta é a função que TODO o sistema chama (cron, telas, pagamento, portal).
 */
function ws_rad_deve_bloquear(PDO $db, array $ct): bool {
    if (($ct['status'] ?? '') === 'cancelado') return true;
    try {
        $st = $db->prepare("SELECT titular_id FROM ws_cliente WHERE id=?");
        $st->execute([(int)($ct['cliente_id'] ?? 0)]);
        $tid = (int)$st->fetchColumn();
    } catch (Throwable $e) { $tid = 0; }
    if ($tid > 0 && $tid !== (int)($ct['cliente_id'] ?? 0) && !ws_rad_adicional_boleto_proprio($db, (int)($ct['cliente_id'] ?? 0))) {   // (14/10) adicional com boleto próprio NÃO segue o titular: regra convencional (abaixo)
        $tcs = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado'");
        $tcs->execute([$tid]);
        $doTitular = $tcs->fetchAll();
        if ($doTitular) {
            if ((int)($ct['bloqueio_manual'] ?? 0) === 1) return true;          // bloqueio individual do adicional
            if (($ct['status'] ?? '') === 'suspenso') return true;
            foreach ($doTitular as $tc) { if (ws_rad_deve_bloquear_proprio($db, $tc)) return true; }
            return false;                                                        // titular liberado: adicional liberado
        }
    }
    return ws_rad_deve_bloquear_proprio($db, $ct);
}

/** Decisão pelo próprio contrato (faturas, confiança, manual, corte). Use ws_rad_deve_bloquear(). */
function ws_rad_deve_bloquear_proprio(PDO $db, array $ct): bool {
    if ($ct['status'] === 'cancelado') return true;
    if (ws_rad_em_confianca($ct)) return false;                 // confiança vale: liberado
    if (!empty($ct['bloqueio_manual'])) return true;            // bloqueio MANUAL persiste mesmo sem dívida
    if ($ct['status'] === 'suspenso') return true;
    // REGRA GERAL: sem boleto aberto vencido, fica DESBLOQUEADO — inclusive quem estava
    // "bloqueado" por inadimplência e já pagou (o bloqueio automático se desfaz sozinho).
    /* Provedor → Recursos do sistema (padrões = o comportamento acima, sem mudança):
     *   Corte automático = Não        → o sistema não bloqueia ninguém por atraso; quem já estava
     *                                   bloqueado continua como está.
     *   Dias de corte                 → fora dos dias marcados o corte não acontece (fica para o
     *                                   próximo dia permitido); quem já estava bloqueado continua.
     *   Desbloqueio automático = Não  → quem pagou continua bloqueado até o operador liberar
     *                                   (o botão Desbloquear grava status "ativo", e aí vale). */
    $rc = function_exists('ws_recursos') ? ws_recursos() : ['corte_auto' => 1, 'dias_corte' => [0,1,2,3,4,5,6], 'desbloqueio_auto' => 1];
    $jaBloqueado = (($ct['status'] ?? '') === 'bloqueado');
    if (ws_rad_inadimplente($db, (int)$ct['id'])) {
        if (!$rc['corte_auto']) return $jaBloqueado;
        if (!in_array((int)date('w'), (array)$rc['dias_corte'], true)) return $jaBloqueado;
        return true;
    }
    if (!$rc['desbloqueio_auto'] && $jaBloqueado) return true;
    return false;
}

/** Aviso da última chamada de ws_rad_confiar() que foi recusada ('' quando foi concedida). */
function ws_rad_confiar_aviso(?string $set = null): string {
    static $m = '';
    if ($set !== null) $m = $set;
    return $m;
}

/** CONFIANÇA: 1 VEZ POR MÊS (15/10/2026, caso José Roberto: o atendente liberou em confiança em 12/10 e de novo em 15/10, sem nenhum aviso de que já tinha usado no mês). O robô e o portal já respeitam a regra; as telas
 *  (ficha e lista de Clientes) agora AVISAM antes: se o cliente já foi liberado em confiança neste mês, a 1ª tentativa só mostra o aviso (data e dias da liberação anterior) e NÃO libera; quem quiser liberar mesmo assim clica em
 *  Confiança de novo em até 3 minutos (fica registrado quem fez). Devolve '' (pode liberar) ou a mensagem de aviso. */
function ws_confianca_aviso_mes(PDO $db, int $clienteId, string $botao = 'Confiança'): string {
    try {
        /* (16/10/2026, caso José Roberto: 2 liberações no mês e o aviso não aparecia) conta TODAS as liberações do mês, de qualquer origem (ficha, lista, robô, portal), e mostra data e dias de cada uma. */
        $q = $db->prepare("SELECT criado_em, texto FROM ws_evento WHERE cliente_id=? AND tipo='confianca' AND (texto LIKE 'Liberado em confiança%' OR texto LIKE 'Desbloqueio%confian%' OR texto LIKE 'Desbloqueio de confiança%') AND criado_em >= DATE_FORMAT(CURDATE(), '%Y-%m-01') ORDER BY id ASC");
        $q->execute([$clienteId]); $evs = $q->fetchAll(PDO::FETCH_ASSOC); if (!$evs) return '';
        if (!empty($_SESSION['ws_conf_aviso'][$clienteId]) && time() - (int)$_SESSION['ws_conf_aviso'][$clienteId] <= 180) { unset($_SESSION['ws_conf_aviso'][$clienteId]); return ''; }   // 2º clique: confirmou
        $_SESSION['ws_conf_aviso'][$clienteId] = time();
        $n = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $n->execute([$clienteId]); $nome = (string)$n->fetchColumn();
        $lista = [];
        foreach ($evs as $e) { $d = preg_match('/por (\d+) dia/u', (string)$e['texto'], $m) ? ', por ' . (int)$m[1] . ' dia(s)' : (preg_match('/(\d+) dia/u', (string)$e['texto'], $m2) ? ', ' . (int)$m2[1] . ' dia(s)' : ''); $lista[] = date('d/m', strtotime((string)$e['criado_em'])) . $d; }
        $qt = count($evs);
        return '⚠️ ' . $nome . ' JÁ foi liberado em confiança ' . ($qt === 1 ? '1 vez' : $qt . ' vezes') . ' neste mês (' . implode('; ', $lista) . '). A regra é 1 vez por mês — nada foi liberado agora. Se quiser liberar de novo mesmo assim, clique em ' . $botao . ' mais uma vez (em até 3 minutos).';
    } catch (Throwable $e) { return ''; }
}
/** DESBLOQUEAR (cadeado) = liberar na prática (16/10/2026): se o cliente está bloqueado COM boleto em atraso e já foi liberado em confiança neste mês, o 1º clique em Desbloquear só AVISA (quantas liberações e quando); clicar de novo em até 3 min confirma. Sem dívida (bloqueio manual) não avisa. */
function ws_desbloqueio_aviso(PDO $db, int $clienteId): string {
    try {
        $q = $db->prepare("SELECT id FROM ws_contrato WHERE cliente_id=? AND status='bloqueado'"); $q->execute([$clienteId]); $divida = false;
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $cid) if (ws_rad_inadimplente($db, (int)$cid)) { $divida = true; break; }
        return $divida ? ws_confianca_aviso_mes($db, $clienteId, 'Desbloquear') : '';
    } catch (Throwable $e) { return ''; }
}
/** Cliente ADICIONAL? Devolve o id do titular (que tem contrato não cancelado); senão 0. */
function ws_rad_titular_do_contrato(PDO $db, array $ct): int {
    try {
        $cid = (int)($ct['cliente_id'] ?? 0);
        $st = $db->prepare("SELECT titular_id FROM ws_cliente WHERE id=?");
        $st->execute([$cid]);
        $tid = (int)$st->fetchColumn();
        if ($tid <= 0 || $tid === $cid) return 0;
        if (ws_rad_adicional_boleto_proprio($db, $cid)) return 0;   // (14/10) boleto próprio: tratado como cliente comum
        $q = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado'");
        $q->execute([$tid]);
        return ((int)$q->fetchColumn() > 0) ? $tid : 0;
    } catch (Throwable $e) { return 0; }
}

/** O titular tem boleto em atraso (a ponto de bloquear) ou já está liberado em confiança por causa dele? */
function ws_rad_titular_em_atraso(PDO $db, int $titularId): bool {
    $q = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado'");
    $q->execute([$titularId]);
    foreach ($q->fetchAll() as $tc) {
        if (ws_rad_em_confianca($tc) || ws_rad_inadimplente($db, (int)$tc['id'])) return true;
    }
    return false;
}

/**
 * A CONFIANÇA DO ADICIONAL É SEMPRE A DO TITULAR (espelho).
 * O adicional não tem faturas próprias e o bloqueio dele já segue o titular; a confiança também:
 *   - titular em confiança vigente → adicionais mostram a mesma data;
 *   - titular sem confiança (pagou, venceu ou nunca teve) → confiança do adicional SAI na hora.
 * Barato: só olha adicionais de quem tem confiança gravada ou de titular em confiança.
 * @return int adicionais ajustados
 */
function ws_rad_espelhar_confianca_adicionais(PDO $db): int {
    $n = 0;
    try {
        $tit = [];   // titular_id => maior confianca_ate vigente
        foreach ($db->query("SELECT cliente_id, MAX(confianca_ate) FROM ws_contrato
                             WHERE status<>'cancelado' AND confianca_ate IS NOT NULL AND confianca_ate > NOW()
                             GROUP BY cliente_id")->fetchAll(PDO::FETCH_NUM) as $r) $tit[(int)$r[0]] = (string)$r[1];
        $sql = "SELECT ct.id, ct.confianca_ate, c.titular_id FROM ws_contrato ct
                  JOIN ws_cliente c ON c.id = ct.cliente_id
                 WHERE c.titular_id IS NOT NULL AND c.titular_id <> c.id AND ct.status <> 'cancelado'
                   AND EXISTS (SELECT 1 FROM ws_contrato x WHERE x.cliente_id = c.titular_id AND x.status <> 'cancelado')
                   AND (ct.confianca_ate IS NOT NULL";
        if ($tit) $sql .= " OR c.titular_id IN (" . implode(',', array_map('intval', array_keys($tit))) . ")";
        $sql .= ")";
        $up = $db->prepare("UPDATE ws_contrato SET confianca_ate=? WHERE id=?");
        foreach ($db->query($sql)->fetchAll() as $a) {
            $quer = $tit[(int)$a['titular_id']] ?? null;
            $tem  = $a['confianca_ate'] !== null ? (string)$a['confianca_ate'] : null;
            if ($quer === $tem) continue;
            $up->execute([$quer, (int)$a['id']]);
            $n++;
        }
    } catch (Throwable $e) {}
    return $n;
}

/**
 * Libera o contrato EM CONFIANÇA por N dias: grava a validade, desbloqueia e derruba a sessão.
 * Devolve false (e deixa o motivo em ws_rad_confiar_aviso()) quando foi RECUSADO:
 *   ADICIONAL só entra em confiança se o TITULAR da conta tem boleto em atraso. Estando o titular
 *   em atraso, o adicional segue o titular — a liberação vale para a conta toda.
 */
function ws_rad_confiar(PDO $db, array $ct, int $dias): bool {
    ws_rad_confiar_aviso('');
    $tid = ws_rad_titular_do_contrato($db, $ct);
    if ($tid > 0) {
        if (!ws_rad_titular_em_atraso($db, $tid)) {
            // Tira qualquer confiança que tenha ficado no adicional (acidente, dado antigo, importação).
            $db->prepare("UPDATE ws_contrato SET confianca_ate=NULL WHERE id=? AND confianca_ate IS NOT NULL")->execute([(int)$ct['id']]);
            ws_rad_confiar_aviso('O titular da conta não tem boleto em atraso — não é possível solicitar desbloqueio em confiança para o adicional.');
            return false;
        }
        $tcs = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado'");
        $tcs->execute([$tid]);
        foreach ($tcs->fetchAll() as $tc) ws_rad_confiar($db, $tc, $dias);   // titular tem tid=0: não volta aqui
        return true;
    }
    $ate = date('Y-m-d H:i:s', strtotime("+$dias days"));
    $db->prepare("UPDATE ws_contrato SET confianca_ate=?, status='ativo' WHERE id=?")->execute([$ate, (int)$ct['id']]);
    $ct['confianca_ate'] = $ate; $ct['status'] = 'ativo';
    ws_rad_sync_contrato($db, $ct, false);
    ws_rad_derrubar_contrato($db, $ct);   // PPPoE e IPoE — senão o IPoE segue preso na pool de corte
    // Regra de ouro: titular liberado em confiança libera os adicionais NA HORA (bloqueio herdado sai).
    try { ws_rad_reavaliar_adicionais($db, (int)$ct['cliente_id'], true); } catch (Throwable $e) {}
    ws_rad_espelhar_confianca_adicionais($db);
    return true;
}

/**
 * Expiração automática da confiança.
 * Zera confianca_ate em UM único caso: a data do desbloqueio VENCEU.
 * Confiança vigente NUNCA é tocada — nem quando o cliente já pagou, nem quando o contrato não
 * tem faturas (base migrada). Retorna quantos foram revogados.
 */
function ws_rad_expirar_confianca(PDO $db): int {
    // REVOGA SÓ QUANDO VENCE A DATA. Nada mais.
    //
    // Existia aqui uma segunda regra: "cliente sem fatura vencida em aberto sai da confiança na
    // hora, mesmo antes da data" — a ideia era o card parar de mostrar confiança assim que a
    // pessoa pagasse. Na prática ela destruía a função inteira, e o diagnóstico mostrou o passo
    // a passo: conceder confiança grava confianca_ate E faz status='ativo'; a página roda esta
    // expiração a cada requisição; o contrato não tinha fatura vencida (base migrada, sem
    // faturas importadas) — então a confiança recém-concedida era apagada segundos depois, o
    // card voltava a zero e o cliente voltava bloqueado. "Sem fatura vencida" não quer dizer
    // "pagou": quer dizer também "nunca teve fatura aqui", que é o caso de toda base migrada.
    //
    // Regra atual, previsível: liberou por N dias, vale N dias. Quem paga antes é liberado pelo
    // ws_rad_sync_* normalmente (a confiança vigente não atrapalha — ela só impede o bloqueio),
    // e o registro some sozinho quando a data vence.
    $sql = "UPDATE ws_contrato
            SET confianca_ate = NULL
            WHERE confianca_ate IS NOT NULL
              AND confianca_ate < NOW()";
    $n = $db->exec($sql);
    // Adicional espelha o titular: saiu/venceu/pagou no titular → sai do adicional também.
    ws_rad_espelhar_confianca_adicionais($db);
    return (int)$n;
}

/**
 * Derruba TODAS as identidades do contrato (PPPoE e IPoE).
 *
 * Trocar o grupo no banco só muda o que o cliente recebe na PRÓXIMA autenticação — a sessão que
 * já está de pé continua com os atributos antigos. Por isso bloquear, desbloquear e dar confiança
 * terminam sempre aqui: é a derrubada que faz a decisão valer na hora.
 *
 * Só o login PPPoE era derrubado. Num parque em que a maioria é IPoE, isso significava que o
 * bloqueio não prendia e o desbloqueio não soltava — para 732 dos 772 contratos — até a sessão
 * cair sozinha, o que pode levar horas. E a tela já mostrava a mudança como feita.
 */
function ws_rad_derrubar_contrato(PDO $db, array $ct): void {
    foreach ([(string)($ct['login_pppoe'] ?? ''), (string)($ct['login_ipoe'] ?? '')] as $lg) {
        $lg = trim($lg);
        if ($lg === '') continue;
        $ok = false;
        try { $ok = ws_rad_disconnect($db, $lg); } catch (Throwable $e) { ws_rad_log("falha ao derrubar $lg: " . $e->getMessage()); }
        // Não caiu e a sessão continua aberta? Fica PENDENTE: o cron tenta de novo a cada passada
        // até a sessão antiga sair. Sem isto, uma falha (concentrador ocupado, rede) prendia o
        // cliente na situação anterior até a sessão cair sozinha — horas ou dias.
        // "Continua aberta" = radacct OU concentrador ao vivo (a radacct pode dizer "fechada" com a
        // sessão de pé — caso WAGNER AUGUSTO, 30/09/2026). Nunca deixar cliente preso sem pendência.
        if (!$ok) {
            $viva = ws_rad_sessao_aberta($db, $lg);
            if (!$viva && function_exists('ws_conexao_viva')) { try { $vv = ws_conexao_viva(0, true); $viva = !empty($vv[ws_conexao_norm($lg)]); } catch (Throwable $e) {} }
            if ($viva) ws_rad_pendente_marcar($lg);
        }
    }
}

/* ===========================================================================================
   DERRUBADA CONFIÁVEL — accel-ppp pela gerência, com confirmação e nova tentativa
   =========================================================================================== */

/** Porta de gerência do accel-ppp do NAS; null se o NAS é Mikrotik (esse cai pela API/CoA). */
function ws_rad_accel_porta(string $nasIp): ?int {
    $cfg = function_exists('ws_cfg') ? ws_cfg() : [];
    foreach ((array)($cfg['concentradores'] ?? []) as $cc) {
        if (!is_array($cc) || trim((string)($cc['ip'] ?? '')) !== $nasIp) continue;
        if (strtolower(trim((string)($cc['tipo'] ?? 'accel'))) === 'mikrotik') return null;
        $p = (int)($cc['porta'] ?? 0);
        return ($p > 0 && $p !== 8728) ? $p : 2000;
    }
    try {   // cadastrado como Mikrotik na tela de concentradores?
        $st = ws_db()->prepare("SELECT tipo FROM ws_concentrador WHERE host=? AND ativo=1 LIMIT 1");
        $st->execute([$nasIp]);
        if ($st->fetchColumn() === 'mikrotik') return null;
    } catch (Throwable $e) {}
    return (int)(getenv('WS_ACCEL_PORT') ?: 2000);
}

/** Um comando na gerência do accel, numa conexão própria (o mesmo jeito da leitura do painel,
 *  que funciona em produção). Devolve a resposta, ou null se não conectou. */
function ws_rad_accel_exec(string $ip, int $porta, string $cmd): ?string {
    $sk = ws_accel_conectar($ip, $porta, 2);
    if (!$sk) return null;
    // Descarta o que o concentrador manda ao conectar (negociação telnet/banner/prompt), para a
    // resposta lida abaixo ser a do comando — e não parar no primeiro prompt do banner.
    stream_set_blocking($sk, false);
    $fim = microtime(true) + 0.15;
    while (microtime(true) < $fim) { if ((string)@fread($sk, 8192) === '') usleep(20000); }
    stream_set_blocking($sk, true);
    stream_set_timeout($sk, 3);
    fwrite($sk, $cmd . "\r\n");
    // Lê em blocos até o prompt — o prompt vem sem quebra de linha, então ler por linha ficaria
    // esperando o tempo-limite a cada comando.
    $buf = ''; $fim = microtime(true) + 4;
    while (!feof($sk) && microtime(true) < $fim) {
        $c = fread($sk, 8192);
        if ($c === false) break;
        if ($c === '') { if (!empty(stream_get_meta_data($sk)['timed_out'])) break; continue; }
        $buf .= $c;
        if (preg_match('/accel-ppp#\s*$/', $buf)) break;
    }
    @fwrite($sk, "exit\r\n");
    fclose($sk);
    return str_replace("\x00", '', $buf);
}

/**
 * Derruba a sessão no accel-ppp e CONFIRMA que saiu.
 *   1. terminate username <login> hard      (o username da sessão é o ID/login — o nome resumido
 *                                            do IPoE fica em user-alias e não interfere)
 *   2. confere com "show sessions"; ainda está lá → terminate sid <Acct-Session-Id> hard
 *   3. confere de novo.
 * Conferência sem resposta válida (sem o cabeçalho da tabela) NÃO vale como "caiu": devolve
 * false, e a derrubada fica pendente para nova tentativa.
 * @return bool true só quando a sessão comprovadamente não está mais no concentrador.
 */
function ws_rad_disconnect_accel(string $nasIp, string $login, string $sid = ''): bool {
    if (!filter_var($nasIp, FILTER_VALIDATE_IP)) return false;
    if (!preg_match('/^[A-Za-z0-9@._:\/+-]{1,64}$/', $login)) return false;   // nada de espaço/quebra no comando
    $sid = preg_match('/^[A-Za-z0-9]{1,64}$/', $sid) ? $sid : '';
    $porta = ws_rad_accel_porta($nasIp);
    if (!$porta || !function_exists('ws_accel_conectar')) return false;

    // true = ainda está, false = saiu, null = não deu para saber
    $presente = function () use ($nasIp, $porta, $login): ?bool {
        $out = ws_rad_accel_exec($nasIp, $porta, 'show sessions username match username ^' . preg_quote($login, '/') . '$');
        if ($out === null || stripos($out, 'username') === false) return null;
        $linhas = preg_replace('/^.*(show sessions|username\s*$).*$/mi', '', $out);
        return (bool)preg_match('/(^|[\s|])' . preg_quote($login, '/') . '([\s|]|$)/m', $linhas);
    };

    if (ws_rad_accel_exec($nasIp, $porta, "terminate username $login hard") === null) return false;
    usleep(500000);
    $ainda = $presente();
    if ($ainda === true && $sid !== '') {
        ws_rad_accel_exec($nasIp, $porta, "terminate sid $sid hard");
        usleep(500000);
        $ainda = $presente();
    }
    return $ainda === false;
}

/** Um comando na gerência do accel numa conexão JÁ ABERTA (lê até o prompt). Base da derrubada em lote. */
function ws_rad_accel_cmd_aberta($sk, string $cmd, float $limite = 4.0): string {
    fwrite($sk, $cmd . "\r\n");
    $buf = ''; $fim = microtime(true) + $limite;
    while (!feof($sk) && microtime(true) < $fim) {
        $c = fread($sk, 8192);
        if ($c === false) break;
        if ($c === '') { if (!empty(stream_get_meta_data($sk)['timed_out'])) break; continue; }
        $buf .= $c;
        if (preg_match('/accel-ppp#\s*$/', $buf)) break;
    }
    return str_replace("\x00", '', $buf);
}

/** Lê a resposta de "show sessions sid,username" → [sid => username]. null = resposta sem o cabeçalho
 *  da tabela (não dá para confiar nela: quem chama trata como "não confirmado"). */
function ws_rad_accel_sessoes_sid(string $out): ?array {
    $r = []; $temCab = false;
    foreach (preg_split('/\r?\n/', $out) as $ln) {
        if (strpos($ln, '|') === false) continue;
        $c = array_map('trim', explode('|', $ln));
        if (count($c) < 2) continue;
        if (strcasecmp($c[0], 'sid') === 0) { $temCab = true; continue; }
        if ($c[0] === '' || $c[1] === '') continue;
        $r[$c[0]] = $c[1];
    }
    return $temCab ? $r : null;
}

/**
 * Derruba VÁRIOS logins no MESMO accel-ppp com UMA conexão de gerência (em vez de abrir 3-4 conexões
 * e esperar por cada cliente, ~5 s cada — 650 clientes levavam ~50 min). Lista as sessões uma vez,
 * manda "terminate sid <sid> hard" para as dos logins pedidos e CONFIRMA pelo SID antigo (quem
 * reconectou já tem SID novo e não atrapalha a conferência). O que não for confirmado NÃO entra no
 * retorno — quem chamou manda esses pelo caminho de sempre, um a um.
 * @return string[] logins cuja sessão antiga comprovadamente saiu deste concentrador.
 */
function ws_rad_disconnect_accel_lote(string $nasIp, array $logins): array {
    $saiu = [];
    if (!$logins || !filter_var($nasIp, FILTER_VALIDATE_IP)) return $saiu;
    if (!function_exists('ws_accel_conectar')) return $saiu;
    $porta = ws_rad_accel_porta($nasIp);
    if (!$porta) return $saiu;                       // Mikrotik: outro caminho
    $sk = ws_accel_conectar($nasIp, $porta, 2);
    if (!$sk) return $saiu;
    try {
        // Descarta o banner/prompt inicial (mesmo cuidado de ws_rad_accel_exec).
        stream_set_blocking($sk, false);
        $fim = microtime(true) + 0.15;
        while (microtime(true) < $fim) { if ((string)@fread($sk, 8192) === '') usleep(20000); }
        stream_set_blocking($sk, true);
        stream_set_timeout($sk, 3);

        $alvo = [];
        foreach ($logins as $lg) $alvo[(string)$lg] = true;
        $antes = ws_rad_accel_sessoes_sid(ws_rad_accel_cmd_aberta($sk, 'show sessions sid,username'));
        if (!$antes) return $saiu;                   // nada lido / ninguém deste concentrador
        $sids = []; $porLogin = [];
        foreach ($antes as $sid => $u) {
            $sid = (string)$sid; $u = (string)$u;
            if (!isset($alvo[$u]) || !preg_match('/^[A-Za-z0-9]{1,64}$/', $sid)) continue;
            $sids[$sid] = $u; $porLogin[$u][] = $sid;
        }
        if (!$sids) return $saiu;

        foreach ($sids as $sid => $u) ws_rad_accel_cmd_aberta($sk, "terminate sid $sid hard");

        $fora = [];                                  // sid => true quando comprovadamente saiu
        for ($t = 0; $t < 3; $t++) {
            usleep($t === 0 ? 700000 : 1200000);
            $cur = ws_rad_accel_sessoes_sid(ws_rad_accel_cmd_aberta($sk, 'show sessions sid,username'));
            if ($cur === null) continue;             // resposta inválida: tenta conferir de novo
            $restam = [];
            foreach ($sids as $sid => $u) { if (isset($cur[$sid])) $restam[$sid] = $u; else $fora[$sid] = true; }
            if (!$restam) break;
            foreach ($restam as $sid => $u) ws_rad_accel_cmd_aberta($sk, "terminate sid $sid hard");
        }
        foreach ($porLogin as $u => $lista) {
            $todos = true;
            foreach ($lista as $sid) { if (empty($fora[$sid])) { $todos = false; break; } }
            if ($todos) $saiu[] = (string)$u;
        }
    } catch (Throwable $e) {
        ws_rad_log("derrubada em lote @ $nasIp falhou: " . $e->getMessage());
    } finally {
        @fwrite($sk, "exit\r\n");
        @fclose($sk);
    }
    return $saiu;
}

/**
 * SESSÃO E IP NÃO FICAM PRESOS DEPOIS DE UMA DERRUBADA CONFIRMADA.
 *
 * O concentrador manda o Accounting-Stop ao encerrar a sessão — quando o pacote se perde, a linha do
 * radacct fica aberta. Com 1 conexão por login, o FreeRADIUS conta essa sessão fantasma e RECUSA o
 * cliente ao reconectar ("já está conectado"), e o IP reservado na pool do RADIUS não volta. Era a
 * demora para "cair e voltar": o cliente só entrava depois da limpeza de sessão presa.
 *
 * Aqui a derrubada JÁ FOI CONFIRMADA (a sessão saiu do concentrador), então fechar a linha é seguro.
 * Se o Stop verdadeiro chegar depois, o FreeRADIUS atualiza a mesma linha com os valores reais.
 * O IP é liberado só onde a pool é do RADIUS (tabela radippool, ex.: MK-Auth); pool do concentrador
 * já é liberada por ele ao encerrar a sessão.
 */
function ws_rad_fechar_sessao_derrubada(PDO $rad, string $login, ?string $iniciadaAte = null): int {
    $n = 0;
    try {
        // $iniciadaAte (derrubada em lote): só fecha a sessão que já existia ANTES da derrubada — quem
        // reconectou logo em seguida tem sessão nova e não pode ser fechada por engano.
        $sql = "UPDATE radacct
                   SET acctstoptime = NOW(), acctterminatecause = 'Ws-Derrubada',
                       acctsessiontime = COALESCE(acctsessiontime, GREATEST(0, TIMESTAMPDIFF(SECOND, acctstarttime, NOW())))
                 WHERE username = ? AND acctstoptime IS NULL";
        $par = [$login];
        if ($iniciadaAte !== null) { $sql .= " AND acctstarttime <= ?"; $par[] = $iniciadaAte; }
        $st = $rad->prepare($sql);
        $st->execute($par);
        $n = $st->rowCount();
    } catch (Throwable $e) {}
    try {
        static $temPool = null;
        if ($temPool === null) {
            $temPool = (int)$rad->query("SELECT COUNT(*) FROM information_schema.columns
                                          WHERE table_schema = DATABASE() AND table_name = 'radippool'
                                            AND column_name IN ('username','expiry_time')")->fetchColumn() === 2;
        }
        if ($temPool) {
            $rad->prepare("UPDATE radippool SET expiry_time = NOW() WHERE username = ? AND expiry_time > NOW()")->execute([$login]);
        }
    } catch (Throwable $e) {}
    if ($n > 0) ws_rad_log("sessao de $login fechada no radacct apos derrubada confirmada (o Stop nao tinha chegado)");
    return $n;
}

/** Há sessão aberta (radacct) para o login? */
function ws_rad_sessao_aberta(PDO $db, string $login, ?string $iniciadaAte = null): bool {
    try {
        $sql = "SELECT 1 FROM radacct WHERE username=? AND acctstoptime IS NULL";
        $par = [$login];
        if ($iniciadaAte !== null) { $sql .= " AND acctstarttime <= ?"; $par[] = $iniciadaAte; }
        $st = $db->prepare($sql . " LIMIT 1");
        $st->execute($par);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return false; }
}

/** Lê/grava as derrubadas pendentes (cache/derrubar_pendente.json) com trava de arquivo. */
function ws_rad_pendentes(?callable $alterar = null): array {
    $arq = WS_CACHE . '/derrubar_pendente.json';
    $fh = @fopen($arq, 'c+');
    if (!$fh) return [];
    @flock($fh, LOCK_EX);
    $j = json_decode((string)stream_get_contents($fh), true);
    $lista = is_array($j) ? $j : [];
    if ($alterar) {
        $lista = $alterar($lista);
        ftruncate($fh, 0); rewind($fh);
        fwrite($fh, json_encode($lista, JSON_UNESCAPED_UNICODE));
        fflush($fh);
    }
    @flock($fh, LOCK_UN); fclose($fh);
    return $lista;
}

/** Concentrador ao vivo mostra sessão deste login que COMEÇOU antes de $desde? (pelo uptime:
 *  "8d 22:06:30", "22:06:30", "1.02:03:04"). Sem leitura ou uptime ilegível = false (não inventa). */
function ws_rad_sessao_antiga_viva(string $login, string $desde): bool {
    if (!function_exists('ws_conexao_viva')) return false;
    try { $vv = ws_conexao_viva(0, true); } catch (Throwable $e) { return false; }
    $v = $vv[ws_conexao_norm($login)] ?? null;
    if (!is_array($v)) return false;
    $u = trim((string)($v['uptime'] ?? ''));
    if (!preg_match('/^(?:(\d+)\s*[d.]\s*)?(\d{1,3}):(\d{2}):(\d{2})$/', $u, $m)) return false;
    $seg = (int)$m[1] * 86400 + (int)$m[2] * 3600 + (int)$m[3] * 60 + (int)$m[4];
    return (time() - $seg) < strtotime($desde);
}

function ws_rad_pendente_marcar(string $login): void {
    ws_rad_pendentes(function (array $l) use ($login) {
        if (!isset($l[$login])) $l[$login] = ['desde' => date('Y-m-d H:i:s'), 'tentativas' => 0];
        return $l;
    });
    ws_rad_log("derrubada PENDENTE de $login (sessao nao saiu) — nova tentativa no proximo sync");
}

/**
 * Tenta de novo cada derrubada pendente. Resolve quando a sessão ANTIGA (iniciada antes da
 * marcação) sai — pela derrubada ou porque caiu sozinha. Reconectou depois? A sessão nova já
 * nasceu com a regra certa: resolvido. Desiste após 30 passadas (~1 h) e registra no log.
 * @return array{resolvidas:int, pendentes:int}
 */
function ws_rad_pendentes_processar(PDO $db): array {
    $res = ['resolvidas' => 0, 'pendentes' => 0];
    $lista = ws_rad_pendentes();
    if (!$lista) return $res;
    $feitos = []; $tentou = [];
    foreach ($lista as $lg => $p) {
        $lg = (string)$lg;
        $desde = (string)($p['desde'] ?? date('Y-m-d H:i:s'));
        // "Resolvida" só se a sessão ANTIGA saiu de verdade: radacct fechada E o concentrador não
        // mostra sessão desse login iniciada antes da marcação (a radacct pode dizer "fechada" com a
        // sessão de pé — caso WAGNER AUGUSTO, 30/09/2026). Sessão nova (depois da marcação) é a certa.
        if (!ws_rad_sessao_aberta($db, $lg, $desde) && !ws_rad_sessao_antiga_viva($lg, $desde)) { $feitos[] = $lg; continue; }
        $ok = false;
        try { $ok = ws_rad_disconnect($db, $lg); } catch (Throwable $e) {}
        if ($ok) { $feitos[] = $lg; ws_rad_log("derrubada pendente de $lg: resolvida"); continue; }
        $tentou[] = $lg;
    }
    $final = ws_rad_pendentes(function (array $l) use ($feitos, $tentou) {
        foreach ($feitos as $lg) unset($l[$lg]);
        foreach ($tentou as $lg) {
            if (!isset($l[$lg])) continue;
            $l[$lg]['tentativas'] = (int)($l[$lg]['tentativas'] ?? 0) + 1;
            if ($l[$lg]['tentativas'] >= 30) {
                ws_rad_log("derrubada pendente de $lg: DESISTI apos 30 tentativas — confira o concentrador");
                unset($l[$lg]);
            }
        }
        return $l;
    });
    $res['resolvidas'] = count($feitos);
    $res['pendentes']  = count($final);
    return $res;
}

/**
 * Depois de um PAGAMENTO — mesma regra em todas as baixas (manual, lista, conciliação, webhook):
 *   1. sai da confiança na hora (pagou: a confiança cumpriu o papel);
 *   2. recalcula: sem outro boleto em atraso além da tolerância → desbloqueia AGORA e derruba a
 *      sessão, para o cliente voltar já liberado (sem esperar o cron); ainda devendo → bloqueia;
 *   3. bloqueio MANUAL também sai com o pagamento (pedido do provedor): pagou e não deve mais nada
 *      em atraso → liberado, seja o bloqueio automático ou manual. Suspenso/cancelado não mudam.
 */
function ws_rad_apos_pagamento(PDO $db, int $contratoId): void {
    if ($contratoId <= 0) return;
    $db->prepare("UPDATE ws_contrato SET confianca_ate=NULL WHERE id=? AND confianca_ate IS NOT NULL")->execute([$contratoId]);
    $st = $db->prepare("SELECT * FROM ws_contrato WHERE id=?");
    $st->execute([$contratoId]);
    $ct = $st->fetch();
    if (!$ct || in_array($ct['status'], ['cancelado', 'suspenso'], true)) return;
    $ct['confianca_ate'] = null;
    if (!empty($ct['bloqueio_manual'])) {
        $db->prepare("UPDATE ws_contrato SET bloqueio_manual=0 WHERE id=?")->execute([$contratoId]);
        $ct['bloqueio_manual'] = 0;
    }
    ws_rad_reavaliar_contrato($db, $ct);
    // Regra de ouro: titular pagou → adicionais liberados junto (o bloqueio herdado sai).
    ws_rad_reavaliar_adicionais($db, (int)$ct['cliente_id'], true);
    ws_rad_espelhar_confianca_adicionais($db);
}

/**
 * Aplica AGORA a decisão de bloqueio de um contrato: RADIUS, status do contrato e do cliente e
 * derrubada da sessão quando a situação muda. Bloqueio manual individual (1) não é desfeito aqui.
 * @return bool true se a situação mudou
 */
function ws_rad_reavaliar_contrato(PDO $db, array $ct): bool {
    if (in_array($ct['status'] ?? '', ['cancelado', 'suspenso'], true)) return false;
    $bloq = ws_rad_deve_bloquear($db, $ct);
    ws_rad_sync_contrato($db, $ct, $bloq);
    $era = (($ct['status'] ?? '') === 'bloqueado');
    if ($bloq === $era) return false;
    if (!$bloq && (int)($ct['bloqueio_manual'] ?? 0) === 1) return false;
    $novo = $bloq ? 'bloqueado' : 'ativo';
    $db->prepare("UPDATE ws_contrato SET status=? WHERE id=?")->execute([$novo, (int)$ct['id']]);
    if ($bloq) {
        $db->prepare("UPDATE ws_cliente SET status='bloqueado' WHERE id=? AND status NOT IN('cancelado','observacao')")->execute([(int)$ct['cliente_id']]);
    } else {
        $o = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=? AND id<>? AND status='bloqueado'");
        $o->execute([(int)$ct['cliente_id'], (int)$ct['id']]);
        if ((int)$o->fetchColumn() === 0)
            $db->prepare("UPDATE ws_cliente SET status='ativo' WHERE id=? AND status='bloqueado'")->execute([(int)$ct['cliente_id']]);
    }
    ws_rad_derrubar_contrato($db, $ct);
    return true;
}

/**
 * REGRA DE OURO aplicada na hora aos adicionais de um titular (pagamento, confiança, desbloqueio).
 * $limparHerdado: tira o bloqueio que veio do titular (bloqueio_manual=2). O bloqueio individual do
 * adicional (1) continua.
 * @return int adicionais cuja situação mudou
 */
function ws_rad_reavaliar_adicionais(PDO $db, int $titularId, bool $limparHerdado = false): int {
    if ($titularId <= 0) return 0;
    $n = 0;
    $st = $db->prepare("SELECT ct.* FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                         WHERE c.titular_id = ? AND c.id <> ? AND ct.status <> 'cancelado'");
    $st->execute([$titularId, $titularId]);
    foreach ($st->fetchAll() as $act) {
        if ($limparHerdado && (int)$act['bloqueio_manual'] === 2) {
            $db->prepare("UPDATE ws_contrato SET bloqueio_manual=0 WHERE id=?")->execute([(int)$act['id']]);
            $act['bloqueio_manual'] = 0;
        }
        try { if (ws_rad_reavaliar_contrato($db, $act)) $n++; } catch (Throwable $e) {}
    }
    return $n;
}

/** Bloqueia o login: joga no grupo de bloqueio e derruba a sessão (CoA). */
function ws_rad_bloquear(PDO $db, array $ct): void {
    ws_rad_garantir_grupo_bloqueio($db);
    ws_rad_sync_contrato($db, $ct, true);
    ws_rad_derrubar_contrato($db, $ct);
}

/** Desbloqueia: volta pro grupo do plano e derruba a sessão (reconecta já liberado). */
function ws_rad_desbloquear(PDO $db, array $ct): void {
    ws_rad_sync_contrato($db, $ct, false);
    ws_rad_derrubar_contrato($db, $ct);
}

/**
 * Remove UMA sessão ativa (PPPoE ou hotspot) de UM concentrador já conectado, CONFERINDO de
 * verdade se saiu — não só disparando o comando e torcendo.
 *
 * POR QUE ISTO EXISTE — "sessão presa": até aqui, o código lia /ppp/active/print, pegava o .id do
 * registro e mandava /ppp/active/remove com aquele .id, sem checar a resposta. Se o Mikrotik
 * RECUSA o remove (registra um "!trap" — típico quando a lista mudou entre o print e o remove, ou
 * quando aquele .id específico está numa situação que o RouterOS não deixa remover direto), a
 * classe da API JOGAVA FORA o erro (ver routeros_api.class.php) e devolvia array vazio — igual a
 * um comando que funcionou sem nada pra listar. O código achava que tinha derrubado, marcava
 * sucesso, e a sessão de verdade CONTINUAVA ATIVA — o cliente bloqueado seguia navegando
 * normalmente, e "Derrubar conexões"/"Reparar dados" relatavam sucesso sem terem feito nada.
 *
 * Agora: depois do remove, CONFERE de novo se o registro ainda está lá. Se ainda estiver (recusado
 * ou não), e for PPPoE, tenta um SEGUNDO caminho — derrubar a interface pppoe-server do mesmo
 * usuário (/interface/pppoe-server/print + remove), que é o método de emergência de quem mexe em
 * Mikrotik quando o /ppp/active/remove não pega. Tudo que falhar fica registrado em radius.log com
 * a mensagem de erro exata do Mikrotik — é o que falta pra investigar o caso que ainda resistir.
 *
 * @return bool true SÓ quando confirmado que a sessão não está mais na lista.
 */
function ws_rad_remover_ativo(RouterosAPI $api, string $print, string $login, string $host): bool {
    $recs = @$api->comm($print, ['?name' => $login]);
    if (!is_array($recs)) return false;
    $tinhaAlgo = false;
    foreach ($recs as $r) {
        if (empty($r['.id'])) continue; // ignora registro de erro (__trap__) e afins
        $tinhaAlgo = true;
        $rem = str_replace('/print', '/remove', $print);
        $resp = @$api->comm($rem, ['.id' => $r['.id']]);
        $erro = is_array($resp) ? RouterosAPI::trapMsg($resp) : 'sem resposta da API';
        if ($erro !== null) ws_rad_log("routeros REMOVE RECUSADO $login @ $host ($print, .id={$r['.id']}): $erro");
    }
    if (!$tinhaAlgo) return false; // não achou sessão nenhuma pra esse login neste concentrador

    // CONFERE de verdade: some da lista?
    $depois = @$api->comm($print, ['?name' => $login]);
    $sumiu = true;
    if (is_array($depois)) foreach ($depois as $r) { if (!empty($r['.id'])) { $sumiu = false; break; } }
    if ($sumiu) return true;

    // AINDA ESTÁ LÁ ("sessão presa"). Para PPPoE, tenta o segundo método: derrubar a interface
    // pppoe-server do usuário — às vezes o /ppp/active some sozinho, às vezes só cai assim.
    if ($print === '/ppp/active/print') {
        $ifaces = @$api->comm('/interface/pppoe-server/print', ['?user' => $login]);
        $tentouIface = false;
        if (is_array($ifaces)) foreach ($ifaces as $if) {
            if (empty($if['.id'])) continue;
            $tentouIface = true;
            $resp = @$api->comm('/interface/pppoe-server/remove', ['.id' => $if['.id']]);
            $erro = is_array($resp) ? RouterosAPI::trapMsg($resp) : 'sem resposta da API';
            if ($erro !== null) ws_rad_log("routeros pppoe-server REMOVE RECUSADO $login @ $host (.id={$if['.id']}): $erro");
        }
        if ($tentouIface) {
            $depois2 = @$api->comm($print, ['?name' => $login]);
            $sumiu2 = true;
            if (is_array($depois2)) foreach ($depois2 as $r) { if (!empty($r['.id'])) { $sumiu2 = false; break; } }
            if ($sumiu2) { ws_rad_log("routeros disconnect $login @ $host (sessao presa — derrubada pela interface pppoe-server)"); return true; }
        }
    }
    ws_rad_log("routeros SESSAO PRESA $login @ $host ($print): Mikrotik recusou o(s) remove(s) e a sessao continua ativa mesmo depois da tentativa de reforco.");
    return false;
}

/**
 * Desconecta o cliente NO EQUIPAMENTO (Mikrotik/accel via RouterOS API) — lógica portada do
 * wellsystem_crm. Percorre os concentradores, acha a sessão /ppp/active do login e remove.
 * @return bool true se removeu em algum concentrador.
 */
function ws_rad_disconnect_routeros(PDO $db, string $login): bool {
    if (!class_exists('RouterosAPI') && is_file(__DIR__ . '/routeros_api.class.php')) @require_once __DIR__ . '/routeros_api.class.php';
    if (!class_exists('RouterosAPI')) return false;
    $conc = $db->query("SELECT host,porta,usuario,senha FROM ws_concentrador WHERE tipo='mikrotik' AND ativo=1")->fetchAll();
    $ok = false;
    foreach ($conc as $c) {
        $api = new RouterosAPI();
        if (!@$api->connect($c['host'], (string)$c['usuario'], (string)$c['senha'], (int)($c['porta'] ?: 8728))) { @$api->disconnect(); continue; }
        foreach (['/ppp/active/print', '/ip/hotspot/active/print'] as $print) {
            if (ws_rad_remover_ativo($api, $print, $login, (string)$c['host'])) $ok = true;
        }
        @$api->disconnect();
    }
    if ($ok) ws_rad_log("routeros disconnect $login (removido no concentrador, confirmado)");
    return $ok;
}


/**
 * Desconexão imediata. Tenta PRIMEIRO no equipamento via RouterOS (Mikrotik);
 * se não houver concentrador Mikrotik, cai no CoA/Disconnect via radclient (porta 3799).
 * @return bool true se enviou.
 */
function ws_rad_disconnect(PDO $db, string $login): bool {
    if (ws_rad_disconnect_routeros($db, $login)) return true;   // equipamento do cliente (wellsystem_crm)
    $st = $db->prepare("SELECT nasipaddress, acctsessionid, framedipaddress, callingstationid
                        FROM radacct WHERE username=? AND acctstoptime IS NULL
                        ORDER BY acctstarttime DESC LIMIT 1");
    $st->execute([$login]); $s = $st->fetch();
    /* SESSÃO VIVA SEM LINHA ABERTA NA RADACCT (30/09/2026, cliente WAGNER AUGUSTO): o cliente
     * autenticou nos DOIS concentradores ao mesmo tempo; a regra "mesmo MAC" do FreeRADIUS fechou no
     * banco a sessão do .21 — que seguiu VIVA, com o IP de bloqueio. Pagou, desbloqueou, e a derrubada
     * olhava só a radacct: "não há sessão" -> nada derrubado, nem pendência. Agora, sem linha aberta,
     * pergunta aos concentradores (mesma leitura do Painel) e derruba onde a sessão estiver de pé. */
    if (!$s || empty($s['nasipaddress'])) {
        $vivos = [];
        if (function_exists('ws_conexao_viva')) { try { $vivos = ws_conexao_viva(0, true); } catch (Throwable $e) {} }
        $v = $vivos[ws_conexao_norm($login)] ?? null;
        $nasViva = is_array($v) ? trim((string)($v['cnc'] ?? '')) : '';
        if ($nasViva !== '' && ws_rad_accel_porta($nasViva) !== null && ws_rad_disconnect_accel($nasViva, $login)) {
            ws_rad_log("disconnect $login @ $nasViva via gerencia do accel-ppp (sessao viva sem linha aberta na radacct)");
            return true;
        }
        return false;
    }

    /* accel-ppp: derruba pela GERÊNCIA do concentrador (o mesmo "terminate" do botão Derrubar do
     * painel) e CONFIRMA que a sessão saiu. Antes só havia o CoA na porta 3799 — que o accel só
     * atende com dae-server configurado. Sem ele o pacote ia, ninguém respondia, e o cliente
     * bloqueado seguia navegando na sessão antiga: a "conexão presa". */
    if (ws_rad_disconnect_accel((string)$s['nasipaddress'], $login, (string)($s['acctsessionid'] ?? ''))) {
        ws_rad_log("disconnect $login @ {$s['nasipaddress']} via gerencia do accel-ppp");
        ws_rad_fechar_sessao_derrubada($db, $login);   // não deixa sessão/IP presos se o Stop se perder
        return true;
    }

    /* SECRET vem de `nas` (é do FreeRADIUS); PORTA DO CoA vem de ws_concentrador (é nossa).
     *
     * A porta do CoA nunca foi campo do FreeRADIUS — ele não a lê em lugar nenhum. Estava dentro de
     * `nas` por cópia do MK-Auth, sujando a tabela que o FreeRADIUS espera encontrar no formato
     * padrão. Agora mora em ws_concentrador, casada pelo IP.
     *
     * O COALESCE garante que a mudança não derruba o CoA de ninguém: concentrador que ainda não
     * esteja cadastrado em ws_concentrador cai nos 3799 do padrão, que é o valor que praticamente
     * todo equipamento usa. */
    $n = $db->prepare("SELECT secret FROM nas WHERE nasname=? LIMIT 1");
    $n->execute([$s['nasipaddress']]); $nas = $n->fetch();
    if (!$nas) return false;
    $secret = (string)$nas['secret'];

    $porta = 3799;
    try {
        $p = $db->prepare("SELECT coa_port FROM ws_concentrador WHERE host=? LIMIT 1");
        $p->execute([$s['nasipaddress']]);
        $porta = (int)($p->fetchColumn() ?: 3799);
    } catch (Throwable $e) { $porta = 3799; }   // coluna ainda não criada: o padrão serve

    // Atributos que identificam a sessão pro NAS
    $attrs  = "User-Name=$login,Acct-Session-Id={$s['acctsessionid']}";
    if (!empty($s['framedipaddress']))  $attrs .= ",Framed-IP-Address={$s['framedipaddress']}";
    if (!empty($s['callingstationid'])) $attrs .= ",Calling-Station-Id={$s['callingstationid']}";

    // Descobre o radclient
    $bin = trim((string)@shell_exec('command -v radclient 2>/dev/null'));
    if ($bin === '') { ws_rad_log("radclient ausente — instale freeradius-utils p/ CoA ($login)"); return false; }

    $cmd = sprintf('printf %s | %s -x %s:%d disconnect %s 2>&1',
        escapeshellarg($attrs), escapeshellcmd($bin),
        escapeshellarg($s['nasipaddress']), $porta, escapeshellarg($secret));
    $out = (string)@shell_exec($cmd);
    ws_rad_log("disconnect $login @ {$s['nasipaddress']}:$porta => " . trim($out));
    $ack = stripos($out, 'Received Disconnect-ACK') !== false || stripos($out, 'Disconnect-ACK') !== false;
    if ($ack) { usleep(700000); ws_rad_fechar_sessao_derrubada($db, $login); }   // dá tempo ao Stop real; o que sobrar, fecha
    return $ack;
}

/**
 * Derruba VÁRIOS logins de uma vez — usado pelo "Derrubar/reiniciar conexões" em massa
 * (manutencao.php). Existe porque ws_rad_disconnect() sozinho, chamado um login por vez num
 * foreach, abre e fecha uma conexão Mikrotik NOVA em CADA concentrador PARA CADA login: com N
 * logins e M concentradores isso é N×M conexões completas (TCP+login na API), uma de cada vez —
 * por isso a "derrubada em massa" saía devagar, um cliente a cada tanto tempo, em vez de imediata
 * pra todos juntos, mesmo pedindo "todos" ou um filtro com muitos resultados.
 *
 * Aqui a ordem se inverte: conecta em CADA concentrador Mikrotik só UMA VEZ e, com essa mesma
 * conexão já aberta, verifica e derruba TODOS os logins pendentes antes de passar pro próximo
 * concentrador (e para cedo se já achou todo mundo). O protocolo/comandos usados são os MESMOS de
 * ws_rad_disconnect_routeros() — só a forma de percorrer é diferente (login pendente x concentrador,
 * em vez de concentrador x login repetido). Quem não é Mikrotik (ou não foi achado em nenhum) cai no
 * caminho de sempre, um por um, via ws_rad_disconnect() (accel-ppp/CoA) — esse caminho já é por
 * login individual (cada um fala só com O SEU próprio NAS, não com todos), então não tinha o mesmo
 * problema de N×M e não precisa mudar.
 *
 * @return int quantos logins foram efetivamente derrubados (Mikrotik em massa + o restante 1-a-1).
 */
function ws_rad_disconnect_muitos(PDO $db, array $logins): int {
    $logins = array_values(array_unique(array_filter(array_map('strval', $logins), fn($l) => $l !== '')));
    if (!$logins) return 0;
    $pendentes = array_fill_keys($logins, true); // ainda não confirmados como derrubados
    $n = 0;

    if (!class_exists('RouterosAPI') && is_file(__DIR__ . '/routeros_api.class.php')) @require_once __DIR__ . '/routeros_api.class.php';
    if (class_exists('RouterosAPI')) {
        try { $conc = $db->query("SELECT host,porta,usuario,senha FROM ws_concentrador WHERE tipo='mikrotik' AND ativo=1")->fetchAll(); }
        catch (Throwable $e) { $conc = []; }
        foreach ($conc as $c) {
            if (!$pendentes) break; // já achou todo mundo — nem precisa abrir os concentradores que sobraram
            $api = new RouterosAPI();
            if (!@$api->connect($c['host'], (string)$c['usuario'], (string)$c['senha'], (int)($c['porta'] ?: 8728))) { @$api->disconnect(); continue; }
            // UMA conexão aberta aqui, reaproveitada para TODOS os logins ainda pendentes.
            foreach (array_keys($pendentes) as $login) {
                $achou = false;
                foreach (['/ppp/active/print', '/ip/hotspot/active/print'] as $print) {
                    if (ws_rad_remover_ativo($api, $print, $login, (string)$c['host'])) $achou = true;
                }
                if ($achou) { unset($pendentes[$login]); $n++; ws_rad_log("routeros disconnect $login (em massa, concentrador {$c['host']}, confirmado)"); }
            }
            @$api->disconnect();
        }
    }

    /* accel-ppp: UMA conexão de gerência por concentrador para TODOS os logins pendentes (antes era
     * 1 a 1, ~5 s por cliente). O que o lote não confirmar cai no caminho de sempre logo abaixo. */
    if ($pendentes && function_exists('ws_rad_disconnect_accel_lote')) {
        try { $nasList = $db->query("SELECT DISTINCT nasipaddress FROM radacct WHERE acctstoptime IS NULL AND nasipaddress <> ''")->fetchAll(PDO::FETCH_COLUMN); }
        catch (Throwable $e) { $nasList = []; }
        $antesDerrubar = date('Y-m-d H:i:s');
        foreach ($nasList as $nasIp) {
            if (!$pendentes) break;
            try { $ok = ws_rad_disconnect_accel_lote((string)$nasIp, array_map('strval', array_keys($pendentes))); }
            catch (Throwable $e) { $ok = []; }
            foreach ($ok as $lg) {
                unset($pendentes[$lg]); $n++;
                ws_rad_fechar_sessao_derrubada($db, (string)$lg, $antesDerrubar);
            }
            if ($ok) ws_rad_log("accel-ppp @ $nasIp: " . count($ok) . " sessao(oes) derrubada(s) em lote (confirmadas pelo SID)");
        }
    }

    // O que sobrou (não é Mikrotik, ou não foi achado em nenhum): caminho de sempre, 1 a 1.
    foreach (array_keys($pendentes) as $login) {
        try { if (ws_rad_disconnect($db, $login)) $n++; } catch (Throwable $e) {}
    }
    return $n;
}

/* ------------------------------------------------------------ sync geral */

/**
 * Sincroniza TUDO: planos → grupos; contratos ativos → RADIUS; inadimplentes → bloqueio.
 * Ideal rodar no cron a cada poucos minutos. Retorna um resumo.
 */
function ws_rad_sync_tudo(PDO $db): array {
    ws_rad_garantir_grupo_bloqueio($db);
    /* O QUE CADA NÚMERO SIGNIFICA — e por que agora são dois, e não um.
     *
     *   contratos  contratos ATIVOS que foram escritos no RADIUS (é o número que bate com
     *              radusergroup, e cuja metade dobrada bate com radcheck: cada login grava a
     *              senha e o Simultaneous-Use).
     *   cancelados contratos CANCELADOS que têm login. São verificados em toda passagem, para o
     *              caso de alguém ter voltado para o RADIUS por outro caminho.
     *   removidos  linhas REALMENTE apagadas nesta passagem.
     *
     * Antes havia só "removidos", e ele contava os cancelados VERIFICADOS, não as linhas apagadas.
     * Resultado: o resumo dizia "removidos: 896" em toda execução do cron, inclusive quando não
     * havia uma linha para apagar — e quem tentava conferir a base com esse número não fechava
     * conta nenhuma. Separar os dois é o que torna o resumo conferível: `cancelados` é estável,
     * `removidos` cai para zero quando o trabalho está em dia. */
    $r = ['planos' => 0, 'contratos' => 0, 'bloqueados' => 0, 'cancelados' => 0, 'removidos' => 0];
    // Regra de corte em vigor, à vista no radius.log: "bloqueados: 0" sem isto não diz se ninguém deve nada
    // ou se a regra (dias / dia da semana) está impedindo o corte.
    $rcCorte = function_exists('ws_recursos') ? ws_recursos() : [];
    $r['dias_bloqueio'] = ws_dias_bloqueio();
    $r['corte_hoje'] = (!empty($rcCorte['corte_auto']) && in_array((int)date('w'), (array)($rcCorte['dias_corte'] ?? []), true)) ? 1 : 0;

    // Revoga a confiança vencida/paga ANTES de decidir bloqueio (loop abaixo re-bloqueia se preciso).
    $r['confianca_revogada'] = ws_rad_expirar_confianca($db);

    // Derrubadas que falharam em passadas anteriores: tenta de novo antes de tudo.
    $pd = ws_rad_pendentes_processar($db);
    if ($pd['resolvidas'] || $pd['pendentes']) $r['derrubadas_pendentes'] = $pd;

    // GRAVÍSSIMO SE ACONTECER: login que autentica no RADIUS sem NENHUM contrato correspondente.
    // Roda em toda passagem — ver ws_rad_remover_orfaos() para o porquê disso ser crítico.
    try {
        $orf = ws_rad_remover_orfaos($db);
        if ($orf['orfaos'] > 0) $r['orfaos_removidos'] = $orf;
    } catch (Throwable $e) { $r['orfaos_erro'] = $e->getMessage(); }

    $planosMudaram = [];
    foreach ($db->query("SELECT * FROM ws_plano")->fetchAll() as $pl) {
        if (ws_rad_sync_plano($db, $pl)) $planosMudaram[] = (int)$pl['id'];
        $r['planos']++;
    }
    foreach ($planosMudaram as $pid) ws_rad_vel_marcar_plano($db, $pid);

    /* Bloqueio que veio do titular em versões anteriores ficou gravado como manual (1) no adicional —
     * e prendia o adicional depois que o titular pagava. Marca como herdado (2) quando o titular
     * também está com bloqueio manual. */
    try {
        $db->exec("UPDATE ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                      JOIN ws_contrato tc ON tc.cliente_id = c.titular_id
                    SET ct.bloqueio_manual = 2
                    WHERE c.titular_id IS NOT NULL AND c.titular_id <> c.id AND ct.bloqueio_manual = 1 AND tc.bloqueio_manual = 1");
    } catch (Throwable $e) {}
    // Titulares primeiro: o adicional segue a situação do titular (regra de ouro).
    $cts = $db->query("SELECT ct.* FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                        ORDER BY (c.titular_id IS NOT NULL AND c.titular_id <> c.id), ct.id")->fetchAll();
    foreach ($cts as $ct) {
        /* AS DUAS IDENTIDADES DO CONTRATO — PPPoE e IPoE.
         * Antes o laço parava no primeiro "login_pppoe vazio", e o contrato IPoE nem era
         * considerado: nunca entrava no RADIUS e, quando cancelado, nunca era removido dele. */
        $loginP = trim((string)($ct['login_pppoe'] ?? ''));
        $loginI = trim((string)($ct['login_ipoe']  ?? ''));
        if ($loginP === '' && $loginI === '') continue;

        if (in_array($ct['status'], ['cancelado'], true)) {
            foreach ([$loginP, $loginI] as $lg) if ($lg !== '') $r['removidos'] += ws_rad_remover($db, $lg);
            $r['cancelados']++; continue;
        }

        $bloq = ws_rad_deve_bloquear($db, $ct);   // respeita confiança, bloqueio manual e a regra do titular
        if ((int)($ct['bloqueio_manual'] ?? 0) === 2 && !$bloq) {   // herdado do titular, que foi liberado: sai junto
            $db->prepare("UPDATE ws_contrato SET bloqueio_manual=0 WHERE id=?")->execute([(int)$ct['id']]);
            $ct['bloqueio_manual'] = 0;
        }
        ws_rad_sync_contrato($db, $ct, $bloq);
        $r['contratos']++;
        if ($bloq) $r['bloqueados']++;

        /* BLOQUEIO VALE NA HORA — derruba a sessão de quem ACABOU de ser bloqueado.
         * Trocar o grupo no banco só muda o que o cliente recebe na PRÓXIMA autenticação. Sem
         * derrubar, o inadimplente continua navegando com a sessão antiga até ela cair sozinha —
         * podem ser horas ou dias, e o sistema já mostrando "bloqueado". O mesmo vale ao
         * desbloquear: quem pagou continuaria preso na pool de corte até reconectar.
         * Só age na TRANSIÇÃO (o status guardado ainda é o de antes), então não há derrubada
         * repetida a cada passagem do cron — e é por isso que esta verificação vem ANTES da
         * reconciliação de status logo abaixo. */
        // "suspenso" também é bloqueio: sem contar aqui, o suspenso era derrubado a CADA passada
        // do cron (o status nunca vira "bloqueado", então a transição se repetia para sempre).
        $eraBloqueado = in_array($ct['status'], ['bloqueado', 'suspenso'], true);
        if ($bloq !== $eraBloqueado && empty($ct['bloqueio_manual'])) {
            ws_rad_derrubar_contrato($db, $ct);   // confirma a queda; se não cair, fica pendente
        }
        // Reconcilia o STATUS visível com a regra automática (sem tocar em cancelado/observação/
        // confiança nem em bloqueio MANUAL): assim o cliente que pagou volta a "ativo" sozinho.
        if (empty($ct['bloqueio_manual']) && $ct['status'] !== 'suspenso'
            && !in_array($ct['status'], ['cancelado', 'observacao'], true) && !ws_rad_em_confianca($ct)) {
            $novo = $bloq ? 'bloqueado' : 'ativo';
            if ($ct['status'] !== $novo) {
                $db->prepare("UPDATE ws_contrato SET status=? WHERE id=?")->execute([$novo, (int)$ct['id']]);
                // Reflete no cliente só se ele não tiver OUTRO contrato que justifique estado diferente.
                if ($novo === 'bloqueado') {
                    $db->prepare("UPDATE ws_cliente SET status='bloqueado' WHERE id=? AND status NOT IN('cancelado','observacao')")->execute([(int)$ct['cliente_id']]);
                } else {
                    $outros = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=? AND id<>? AND status='bloqueado'");
                    $outros->execute([(int)$ct['cliente_id'], (int)$ct['id']]);
                    if ((int)$outros->fetchColumn() === 0)
                        $db->prepare("UPDATE ws_cliente SET status='ativo' WHERE id=? AND status='bloqueado'")->execute([(int)$ct['cliente_id']]);
                }
            }
        }
    }
    /* CLIENTE PRESO EM "BLOQUEADO": o status do cliente só voltava a "ativo" na TRANSIÇÃO do contrato
       (bloqueado -> ativo). Se o contrato já estava ativo por outro caminho (desbloqueio na tela, confiança,
       pagamento processado antes), o cliente ficava "bloqueado" para sempre na lista (e nos contadores),
       mesmo pago e navegando. Aqui: cliente "bloqueado" com contrato e SEM nenhum contrato bloqueado/suspenso
       volta a "ativo". Regra do provedor: sem título vencido em aberto, não fica bloqueado nem na lista.
       Cliente sem contrato (bloqueio decidido à mão) não é tocado. NÃO REMOVER. */
    try {
        $dz = $db->exec("UPDATE ws_cliente c SET c.status='ativo'
                         WHERE c.status='bloqueado'
                           AND EXISTS (SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id)
                           AND NOT EXISTS (SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.status IN ('bloqueado','suspenso'))");
        if ($dz) $r['clientes_destravados'] = (int)$dz;
    } catch (Throwable $e) {}
    // Velocidade nova nas sessões vivas (plano alterado), em lotes, sem derrubar ninguém.
    $vel = ws_rad_vel_processar($db, 50);
    if ($vel['aplicadas'] || $vel['pendentes']) $r['velocidade_ao_vivo'] = $vel;
    return $r;
}

/* ===========================================================================================
   VELOCIDADE NOVA SEM DERRUBAR — accel-ppp pela gerência (shaper change), CoA como reserva
   -------------------------------------------------------------------------------------------
   Quando a velocidade de um plano muda, o RADIUS só vale na próxima autenticação. Aqui, quem está
   conectado recebe a velocidade nova NA SESSÃO VIVA: o cliente não cai, não reconecta.
   Fila em cache/velocidade_pendente.json, processada por lotes em cada sincronismo (a cada 2 min)
   com tempo limitado — um parque inteiro converge em poucos minutos sem pesar no concentrador.
   Cada sessão é conferida no próprio concentrador: aplicada e confirmada sai da fila; não
   confirmada tenta de novo; depois de 3 tentativas vale no próximo login.
   =========================================================================================== */

/** Lê/grava a fila de velocidade com trava de arquivo. */
function ws_rad_vel_fila(?callable $alterar = null): array {
    $arq = WS_CACHE . '/velocidade_pendente.json';
    $fh = @fopen($arq, 'c+');
    if (!$fh) return [];
    @flock($fh, LOCK_EX);
    $j = json_decode((string)stream_get_contents($fh), true);
    $lista = is_array($j) ? $j : [];
    if ($alterar) { $lista = $alterar($lista); ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($lista)); fflush($fh); }
    @flock($fh, LOCK_UN); fclose($fh);
    return $lista;
}

/** Põe na fila todo mundo conectado no plano (chamado quando a velocidade do plano muda). */
function ws_rad_vel_marcar_plano(PDO $db, int $planoId): int {
    return ws_rad_vel_marcar_grupo($db, ws_rad_grupo_plano($planoId));
}

/** Põe na fila todo mundo conectado num grupo do RADIUS (plano ou bloqueio). */
function ws_rad_vel_marcar_grupo(PDO $db, string $grupo): int {
    try {
        $q = $db->prepare("SELECT DISTINCT a.username FROM radacct a
                             JOIN radusergroup g ON g.username = a.username
                            WHERE g.groupname = ? AND a.acctstoptime IS NULL");
        $q->execute([$grupo]);
        $logins = $q->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) { return 0; }
    if (!$logins) return 0;
    ws_rad_vel_fila(function (array $l) use ($logins) { foreach ($logins as $lg) $l[(string)$lg] = ['n' => 0]; return $l; });
    ws_rad_log('velocidade ao vivo: ' . count($logins) . ' sessao(oes) na fila (grupo ' . $grupo . ')');
    return count($logins);
}

/** Números em kbit de um valor de velocidade ("51200k/102400k", "51200/102400", "50M/50M"). */
function ws_rad_vel_numeros(string $v): array {
    $out = [];
    if (preg_match_all('/(\d+(?:\.\d+)?)\s*([kKmMgG]?)/', $v, $m, PREG_SET_ORDER)) {
        foreach ($m as $x) {
            $n = (float)$x[1]; $u = strtolower($x[2]);
            if ($u === 'm') $n *= 1000; elseif ($u === 'g') $n *= 1000000;
            $out[] = (int)round($n);
        }
    }
    return $out;
}

/**
 * Processa a fila por até $segundos. Por concentrador: 1 leitura da lista de sessões (ifname,
 * username, rate-limit) → quem já está com a velocidade certa sai da fila → aos demais,
 * "shaper change <interface> <velocidade>". A confirmação vem na leitura da passada seguinte.
 * @return array{aplicadas:int, confirmadas:int, pendentes:int}
 */
function ws_rad_vel_processar(PDO $db, int $segundos = 50): array {
    $res = ['aplicadas' => 0, 'confirmadas' => 0, 'pendentes' => 0];
    $fila = ws_rad_vel_fila();
    if (!$fila) return $res;
    $fim = microtime(true) + max(5, $segundos);

    // Sessão viva e velocidade certa de cada login da fila.
    $porNas = []; $remover = []; $tentou = [];
    $sess = $db->prepare("SELECT nasipaddress FROM radacct WHERE username=? AND acctstoptime IS NULL ORDER BY acctstarttime DESC LIMIT 1");
    $plano = $db->prepare("SELECT p.up_kbps, p.down_kbps, ct.status FROM ws_contrato ct JOIN ws_plano p ON p.id = ct.plano_id
                           WHERE ct.login_pppoe = ? OR ct.login_ipoe = ? ORDER BY (ct.status='ativo') DESC LIMIT 1");
    $grp = $db->prepare("SELECT groupname FROM radusergroup WHERE username=? ORDER BY priority LIMIT 1");
    foreach ($fila as $lg => $info) {
        $lg = (string)$lg;
        $sess->execute([$lg]); $nas = (string)$sess->fetchColumn();
        $plano->execute([$lg, $lg]); $pl = $plano->fetch();
        if ($nas === '' || !$pl || $pl['status'] === 'cancelado') { $remover[] = $lg; continue; }   // offline ou cancelado: nada a aplicar
        // Bloqueado (grupo de bloqueio no RADIUS) recebe a velocidade do bloqueio; liberado, a do plano.
        $grp->execute([$lg]);
        $porNas[$nas][$lg] = ($grp->fetchColumn() === WS_GRUPO_BLOQUEIO)
            ? WS_RATE_BLOQUEIO
            : ws_rad_rate_limit((int)$pl['up_kbps'], (int)$pl['down_kbps']);
    }

    foreach ($porNas as $nas => $alvos) {
        if (microtime(true) >= $fim) break;
        $porta = function_exists('ws_rad_accel_porta') ? ws_rad_accel_porta($nas) : null;
        $lista = $porta ? ws_rad_accel_exec($nas, $porta, 'show sessions ifname,username,rate-limit') : null;
        $vivas = [];   // login => [ifname, rate]
        if ($lista !== null) {
            foreach (explode("\n", $lista) as $ln) {
                $c = array_map('trim', explode('|', $ln));
                if (count($c) >= 3 && $c[0] !== '' && strcasecmp($c[0], 'ifname') !== 0) $vivas[mb_strtolower($c[1], 'UTF-8')] = [$c[0], $c[2]];
            }
        }
        foreach ($alvos as $lg => $rate) {
            if (microtime(true) >= $fim) break;
            $chave = mb_strtolower($lg, 'UTF-8');
            $alvoNums = ws_rad_vel_numeros($rate);
            if (isset($vivas[$chave])) {
                [$ifn, $rateAtual] = $vivas[$chave];
                $atualNums = ws_rad_vel_numeros($rateAtual);
                if ($atualNums && !array_diff($alvoNums, $atualNums)) { $remover[] = $lg; $res['confirmadas']++; continue; }   // já está certa
                if (preg_match('/^[A-Za-z0-9._:\-]{1,32}$/', $ifn)) {
                    ws_rad_accel_exec($nas, $porta, "shaper change $ifn $rate");
                    $res['aplicadas']++; $tentou[] = $lg;
                    continue;
                }
            } elseif ($lista !== null && $vivas) {
                $remover[] = $lg; continue;   // não está mais no concentrador: pega a velocidade nova ao reconectar
            }
            // Sem gerência do accel (Mikrotik, porta fechada): CoA de velocidade.
            $pl = null;
            $plano->execute([$lg, $lg]); $pl = $plano->fetch();
            if ($pl && function_exists('ws_rad_coa_plano') && ws_rad_coa_plano($db, $lg, (int)$pl['up_kbps'], (int)$pl['down_kbps'])) {
                $remover[] = $lg; $res['aplicadas']++;
            } else {
                $tentou[] = $lg;
            }
        }
    }

    $final = ws_rad_vel_fila(function (array $l) use ($remover, $tentou) {
        foreach ($remover as $lg) unset($l[$lg]);
        foreach ($tentou as $lg) {
            if (!isset($l[$lg])) continue;
            $l[$lg]['n'] = (int)($l[$lg]['n'] ?? 0) + 1;
            if ($l[$lg]['n'] > 3) unset($l[$lg]);   // vale no próximo login
        }
        return $l;
    });
    $res['pendentes'] = count($final);
    if ($res['aplicadas'] || $res['confirmadas']) ws_rad_log("velocidade ao vivo: {$res['aplicadas']} aplicada(s), {$res['confirmadas']} confirmada(s), {$res['pendentes']} na fila");
    return $res;
}

/** Sessões online (radacct em aberto). */
function ws_rad_online(PDO $db): array {
    return $db->query("SELECT username, nasipaddress, framedipaddress, acctstarttime,
                              acctinputoctets, acctoutputoctets, callingstationid
                       FROM radacct WHERE acctstoptime IS NULL ORDER BY acctstarttime DESC")->fetchAll();
}

/** Log simples do módulo Radius. */
/** ACESSOS INVÁLIDOS PELO REGISTRO DO FREERADIUS (14/10/2026) — a tabela radpostauth não recebia as recusas, então a tela "Acessos inválidos" ficava vazia. Aqui lê o radius.log (só leitura, sem mexer na autenticação),
 *  pega o que é NOVO desde a última leitura e grava em radpostauth (reply='Access-Reject', class='ws:motivo|origem|concentrador'). NUNCA grava senha. Só entra tentativa de CLIENTE: origem com MAC (PPPoE local) ou login que existe
 *  no cadastro — varredura de robôs da internet (origem = IP, login qualquer) só vira contador. Mesmo login+motivo em 10 min = atualiza a hora (não repete). Guarda só as últimas 300: as novas empurram as velhas, sozinho. */
function ws_rad_recusa_texto(string $c): string {
    return ['S' => 'senha incorreta', 'N' => 'login não cadastrado (provável erro de digitação)', 'C' => 'login cadastrado, mas sem senha no RADIUS', 'O' => 'recusado pelo RADIUS', 'K' => 'concentrador desconhecido pelo RADIUS — todos os clientes dele ficam sem conectar (confira a lista de concentradores e reinicie o FreeRADIUS)'][$c] ?? 'recusado pelo RADIUS';
}
function ws_rad_recusas_coletar(PDO $db): array {
    $res = ['lidas' => 0, 'novas' => 0, 'externas' => 0];
    /* Instalação nova (ISO/Debian) não traz radpostauth — o schema do RADIUS não a cria. Sem ela esta coleta falhava em silêncio e a tela
       "Acessos inválidos" ficava vazia (21/10/2026). Cria no banco do WellSystem, com as colunas de sempre. */
    try { $db->exec("CREATE TABLE IF NOT EXISTS radpostauth (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(190) NOT NULL DEFAULT '', pass VARCHAR(190) NOT NULL DEFAULT '', reply VARCHAR(32) NOT NULL DEFAULT '', authdate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, class VARCHAR(64) NULL, KEY ix_user (username), KEY ix_class (class)) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
    $log = is_file('/var/log/freeradius/radius.log') ? '/var/log/freeradius/radius.log' : '';
    if ($log === '' || !is_readable($log)) return $res;
    $posF = WS_CACHE . '/radius_recusas_pos.json'; $pos = json_decode((string)@file_get_contents($posF), true) ?: [];
    $st = @stat($log); if (!$st) return $res; $ino = (int)$st['ino']; $size = (int)$st['size'];
    $off = (isset($pos['ino']) && (int)$pos['ino'] === $ino && (int)($pos['off'] ?? 0) <= $size) ? (int)$pos['off'] : max(0, $size - 3000000);   // 1ª leitura (ou log novo/rotacionado): pega o dia todo (o log gira por dia)
    $fh = @fopen($log, 'rb'); if (!$fh) return $res; fseek($fh, $off); $bloco = (string)fread($fh, 3 * 1048576); fclose($fh);
    $fim = strrpos($bloco, "\n"); if ($fim === false) return $res; $bloco = substr($bloco, 0, $fim + 1); $novoOff = $off + strlen($bloco);
    $conhecidos = null;
    $ehCliente = function (string $u) use ($db, &$conhecidos): array {
        if ($conhecidos === null) { $conhecidos = [];
            try { foreach ($db->query("SELECT cliente_id, LOWER(login_pppoe) a, LOWER(login_ipoe) b FROM ws_contrato WHERE status<>'cancelado'") as $r) { if ($r['a'] !== '' && $r['a'] !== null) $conhecidos[$r['a']] = (int)$r['cliente_id']; if ($r['b'] !== '' && $r['b'] !== null) $conhecidos[$r['b']] = (int)$r['cliente_id']; } } catch (Throwable $e) {} }
        $k = strtolower($u); return isset($conhecidos[$k]) ? [true, $conhecidos[$k]] : [false, 0];
    };
    $sel = $db->prepare("SELECT id FROM radpostauth WHERE username=? AND reply='Access-Reject' AND class LIKE ? AND authdate >= (? - INTERVAL 10 MINUTE) LIMIT 1");
    $upd = $db->prepare("UPDATE radpostauth SET authdate=? WHERE id=?");
    $ins = $db->prepare("INSERT INTO radpostauth (username, pass, reply, authdate, class) VALUES (?, '', 'Access-Reject', ?, ?)");
    foreach (explode("\n", $bloco) as $ln) {
        /* CONCENTRADOR DESCONHECIDO (21/10/2026): o RADIUS ignora em silêncio quem não está na lista de NAS ("unknown client") — nem chega a
           "Login incorrect", então nenhum cliente desse concentrador aparecia na tela. Agora vira um aviso (1 por concentrador a cada 10 min). */
        if (strpos($ln, 'unknown client') !== false) {
            if (preg_match('/^\w{3} (\w{3}) +(\d+) (\d\d:\d\d:\d\d) (\d{4}) : Error: Ignoring request to (?:auth|acct) .* from unknown client (\S+) port \d+/', $ln, $k)) {
                $quando = strtotime("$k[2] $k[1] $k[4] $k[3]"); if (!$quando || $quando < time() - 86400) continue;
                /* Só vale como aviso o IP da NOSSA rede (privado/CGNAT ou da mesma faixa /24 de um concentrador cadastrado). Varredura de robôs da internet na porta do RADIUS é ruído. */
                static $faixasNas = null;
                if ($faixasNas === null) { $faixasNas = []; try { foreach ($db->query("SELECT nasname FROM nas")->fetchAll(PDO::FETCH_COLUMN) as $nn) { $o = explode('.', (string)$nn); if (count($o) === 4) $faixasNas[$o[0] . '.' . $o[1] . '.' . $o[2]] = 1; } } catch (Throwable $e) {} }
                $io = explode('.', (string)$k[5]); $faixa = count($io) === 4 ? $io[0] . '.' . $io[1] . '.' . $io[2] : '';
                $nossa = $faixa !== '' && (isset($faixasNas[$faixa]) || $io[0] === '10' || ($io[0] === '172' && (int)$io[1] >= 16 && (int)$io[1] <= 31) || ($io[0] === '192' && $io[1] === '168') || ($io[0] === '100' && (int)$io[1] >= 64 && (int)$io[1] <= 127));
                if (!$nossa) { $res['externas']++; continue; }
                $res['lidas']++; $user = 'concentrador ' . $k[5]; $quandoSql = date('Y-m-d H:i:s', $quando); $classe = mb_substr('ws:K|-|' . $k[5], 0, 64);
                try {
                    $sel->execute([$user, 'ws:K|%', $quandoSql]); $ex = $sel->fetchColumn();
                    if ($ex) { $upd->execute([$quandoSql, (int)$ex]); continue; }
                    $ins->execute([$user, $quandoSql, $classe]); $res['novas']++;
                    if ($quando >= time() - 3600 && function_exists('ws_evento')) ws_evento($db, null, 'radius', 'RADIUS ignorando o concentrador ' . $k[5] . ' — ' . ws_rad_recusa_texto('K'));
                } catch (Throwable $e) {}
            }
            continue;
        }
        if (strpos($ln, 'Login incorrect') === false) continue;
        if (!preg_match('/^\w{3} (\w{3}) +(\d+) (\d\d:\d\d:\d\d) (\d{4}) : Auth: \(\d+\) Login incorrect \((.*?)\): \[(.*)\] \(from client (\S+) port \d+(?: cli (\S+))?\)/', $ln, $m)) continue;
        $res['lidas']++;
        $quando = strtotime("$m[2] $m[1] $m[4] $m[3]"); if (!$quando || $quando < time() - 86400) continue;
        $user = trim($m[6]); $bruto = $m[5]; $nas = $m[7]; $cli = $m[8] ?? '';
        $mac = (bool)preg_match('/^[0-9a-f]{2}([:-][0-9a-f]{2}){5}$/i', $cli);
        [$conhecido, $cid] = $ehCliente($user);
        if (!$mac && !$conhecido) { $res['externas']++; continue; }
        if (stripos($bruto, 'does not match') !== false || stripos($bruto, 'MS-CHAP2-Response is incorrect') !== false) $motivo = 'S';
        elseif (stripos($bruto, 'No Auth-Type found') !== false || stripos($bruto, 'No NT/LM-Password') !== false) $motivo = $conhecido ? 'C' : 'N';
        else $motivo = 'O';   // (a coluna class tem só 64 caracteres: guarda o CÓDIGO do motivo; a tela traduz — ver ws_rad_recusa_texto)
        $classe = mb_substr('ws:' . $motivo . '|' . ($cli !== '' ? $cli : '-') . '|' . $nas, 0, 64); $quandoSql = date('Y-m-d H:i:s', $quando);
        try {
            $sel->execute([$user, 'ws:' . $motivo . '|%', $quandoSql]); $ex = $sel->fetchColumn();
            if ($ex) { $upd->execute([$quandoSql, (int)$ex]); continue; }
            $ins->execute([$user, $quandoSql, $classe]); $res['novas']++;
            if ($quando >= time() - 3600 && function_exists('ws_evento')) ws_evento($db, $cid ?: null, 'radius', 'Tentativa de conexão recusada: login ' . $user . ' — ' . ws_rad_recusa_texto($motivo));
        } catch (Throwable $e) {}
    }
    try { $db->exec("DELETE FROM radpostauth WHERE class LIKE 'ws:%' AND id < COALESCE((SELECT m FROM (SELECT id m FROM radpostauth WHERE class LIKE 'ws:%' ORDER BY id DESC LIMIT 1 OFFSET 299) t), 0)"); } catch (Throwable $e) {}   // só as últimas 300
    @file_put_contents($posF, json_encode(['ino' => $ino, 'off' => $novoOff]));
    if ($res['externas'] > 0) { $cf = WS_CACHE . '/radius_recusas_externas.json'; $c = json_decode((string)@file_get_contents($cf), true) ?: []; $dia = date('Y-m-d'); $c[$dia] = (int)($c[$dia] ?? 0) + $res['externas']; $c = array_slice($c, -7, 7, true); @file_put_contents($cf, json_encode($c)); }
    return $res;
}
function ws_rad_log(string $msg): void {
    @file_put_contents(WS_CACHE . '/radius.log', '[' . date('c') . '] ' . $msg . "\n", FILE_APPEND);
}

/* ===========================================================================================
   CONEXÃO VISTA NO CONCENTRADOR  →  CADASTRO
   -------------------------------------------------------------------------------------------
   Uma única implementação para dois pedidos que são o mesmo dado visto de dois ângulos:

     obs2 — o IP do cliente precisa continuar visível DEPOIS que ele cai (o último IP, em cinza),
            e precisa acompanhar a troca de concentrador sem ninguém digitar nada.
     obs3 — a VLAN do cadastro deve ser preenchida pela própria conexão, não à mão.

   Ambos saem da MESMA leitura de sessões que o painel já faz. Não há coleta extra: quem chama
   passa o que acabou de ler.

   REGRA DE ESCRITA — só grava o que MUDOU:
     ultimo_ip / ultimo_cnc → sempre que a sessão trouxer IP válido (é fato observado, e o IP é
                              dinâmico por natureza; sobrescrever é o comportamento correto).
     vlan                   → idem, quando a sessão trouxer VLAN numérica. A VLAN também é fato
                              da rede; um valor digitado errado no cadastro se corrige sozinho
                              na primeira conexão, e o campo continua editável na ficha.
   Linha sem mudança não gera UPDATE — o painel recarrega a cada 60s e não pode virar escrita
   contínua no banco.
   =========================================================================================== */

/** Normaliza login para casar cadastro × concentrador (mesma regra do resto do sistema). */
function ws_conexao_norm(?string $s): string {
    return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s));
}

/**
 * Grava no contrato a conexão observada agora.
 *
 * @param PDO   $db      banco raiz do WellSystem.
 * @param array $vistos  [ loginNormalizado => ['ip'=>?, 'vlan'=>?, 'cnc'=>?] ]
 * @return int           quantos contratos foram atualizados.
 */
function ws_conexao_registrar(PDO $db, array $vistos): int {
    if (!$vistos) return 0;

    // Throttle: o painel atualiza a cada 60s e pode haver várias abas abertas. Sem isto, cada
    // aba dispararia a mesma varredura. 45s deixa passar o ciclo normal e barra a enxurrada.
    $marca = WS_CACHE . '/ws_conexao_reg.txt';
    $agora = time();
    if (is_file($marca) && ($agora - (int)@file_get_contents($marca)) < 45) return 0;
    @file_put_contents($marca, (string)$agora);

    try {
        $rows = $db->query(
            "SELECT id, login_pppoe, login_ipoe, ultimo_ip, ultimo_cnc, vlan
               FROM ws_contrato
              WHERE (login_pppoe IS NOT NULL AND login_pppoe <> '')
                 OR (login_ipoe  IS NOT NULL AND login_ipoe  <> '')"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return 0; }   // coluna ainda não criada: schema.php resolve no próximo load

    $n = 0;
    foreach ($rows as $r) {
        $s = null;
        foreach ([$r['login_pppoe'] ?? '', $r['login_ipoe'] ?? ''] as $lg) {
            $k = ws_conexao_norm($lg);
            if ($k !== '' && isset($vistos[$k])) { $s = $vistos[$k]; break; }
        }
        if ($s === null) continue;   // não está conectado agora: mantém o último visto

        $ip   = trim((string)($s['ip'] ?? ''));
        $cnc  = trim((string)($s['cnc'] ?? ''));
        $vlan = preg_replace('/\D/', '', (string)($s['vlan'] ?? ''));
        if ($ip === '' || $ip === '0.0.0.0') $ip = '';

        $campos = []; $val = [];
        if ($ip !== '' && $ip !== (string)$r['ultimo_ip']) {
            $campos[] = 'ultimo_ip = :ip'; $campos[] = 'ultimo_ip_em = NOW()'; $val[':ip'] = $ip;
        }
        if ($cnc !== '' && $cnc !== (string)$r['ultimo_cnc']) { $campos[] = 'ultimo_cnc = :cnc'; $val[':cnc'] = $cnc; }
        if ($vlan !== '' && (int)$vlan > 0 && (int)$vlan !== (int)$r['vlan']) { $campos[] = 'vlan = :vl'; $val[':vl'] = (int)$vlan; }
        if (!$campos) continue;

        $sql = "UPDATE ws_contrato SET " . implode(', ', $campos) . " WHERE id = " . (int)$r['id'];
        try { $st = $db->prepare($sql); $st->execute($val); $n++; } catch (Throwable $e) {}
    }
    return $n;
}

/* ===========================================================================================
   CONFIGURAÇÃO CENTRAL + LEITURA DOS CONCENTRADORES
   -------------------------------------------------------------------------------------------
   Estas funções nasceram dentro do servidores.php, que só é carregado no Painel dos
   Concentradores. Resultado: qualquer outra tela que precisasse saber quem está conectado
   (a lista de Clientes, por exemplo) não tinha como perguntar — e acabava inventando a própria
   fonte, que dava outro número. Moradia definitiva é aqui, no radius_lib.php, que TODAS as telas
   já carregam. O servidores.php continua usando exatamente as mesmas funções.
   =========================================================================================== */


// =============================================================================
// CONFIGURAÇÃO CENTRAL DO WELLSYSTEM (editável pela tela "Configurações")
// -----------------------------------------------------------------------------
// NADA de IP fixo no código: os concentradores, o servidor web e os timeouts
// vivem em cache_trafego/wellsystem_config.json. Se o arquivo não existir, valem
// os padrões abaixo (que são os valores atuais desta instalação).
// =============================================================================
function ws_cache_dir() {
    static $dir = null; if ($dir !== null) return $dir;
    /* ORDEM QUE SOBREVIVE A REBOOT.
     * O plano B era sys_get_temp_dir() — /tmp na maioria dos servidores, que é APAGADO no
     * reinício. Quando a pasta do addon não aceita escrita (acontece: o painel do MK-Auth
     * recria o addon com outro dono), a lista de concentradores e o resto da configuração desta
     * página iam para lá e desapareciam no próximo boot, sem aviso e sem culpado aparente.
     * Agora, antes do temporário volátil, entram WS_CACHE (já resolvido pelo config.php, e
     * persistente) e /var/tmp, que o sistema não limpa no reinício. */
    $hash  = substr(md5(__DIR__), 0, 10);
    $cands = [__DIR__ . '/cache_trafego'];
    if (defined('WS_CACHE')) $cands[] = WS_CACHE . '/trafego';
    $cands[] = '/var/tmp/wellsystem_trafego_' . $hash;
    $cands[] = sys_get_temp_dir() . '/acellApp_cache_trafego';
    foreach ($cands as $d) {
        if ($d === '' ) continue;
        if (!is_dir($d)) @mkdir($d, 0777, true);
        @chmod($d, 0777);
        $t = $d . '/.__wtest';
        if (@file_put_contents($t, 'ok') !== false) { @unlink($t); $dir = $d; return $dir; }
    }
    $dir = $cands[0]; return $dir;
}
function ws_cfg_padrao() {
    return [
        /* NASCE VAZIA. Havia dois IPs desta instalação escritos aqui — numa instalação em outro
           provedor eles apontam para máquinas que não existem, e o painel abre "sem ninguém
           conectado" sem dizer por quê. A lista é DESCOBERTA em ws_cfg(), a partir dos NAS já
           cadastrados (ws_concentradores_auto). */
        'concentradores' => [],
        // Host do outro ERP (link do cadastro do cliente). NASCE VAZIO de propósito: o valor é
        // DETECTADO em ws_cfg() a partir do próprio servidor. Um IP escrito aqui só estaria certo
        // nesta instalação e errado em todas as outras — ver ws_servidor_web_auto().
        'servidor_web' => '',
        'timeout'      => 2,               // segundos p/ conectar/ler o concentrador
        'logo'         => '',              // logomarca (data URI) exibida nas tarjas do topo
        'cnc_modo'     => 'global',        // 'global' (lista única) OU 'por_radius' (cada radius tem os seus)
        'radius'       => [],              // lista de radius: {nome,host,porta,user,pass,dbname,concentradores[]}. Vazio = conexão local padrão.
        'radius_ativo' => 0,               // índice do radius selecionado (o que a página exibe)
    ];
}

/** Lê a lista GLOBAL de concentradores direto da tabela `ws_concentrador` — a MESMA tabela usada
 *  em Cadastros → Concentradores e nas derrubadas do RADIUS. Antes, o painel (Config →
 *  Concentradores) guardava a lista separada em cache/wellsystem_config.json: cadastrar/editar um
 *  concentrador num lugar não refletia no outro, e um tipo (accel/mikrotik) desatualizado numa das
 *  duas cópias fazia o nome exibido não bater com o que estava realmente configurado. Agora as duas
 *  telas leem e gravam na mesma tabela — só existe UM cadastro de concentrador no sistema. */
function ws_concentradores_db(): array {
    $out = [];
    if (!function_exists('ws_db')) return $out;
    try {
        $rs = ws_db()->query("SELECT nome, tipo, host, porta, usuario, senha FROM ws_concentrador WHERE ativo=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return $out; }
    foreach ($rs as $r) {
        $out[] = ['tipo' => ((string)$r['tipo'] === 'mikrotik' ? 'mikrotik' : 'accel'),
                  'nome' => (string)$r['nome'], 'ip' => (string)$r['host'], 'porta' => (int)$r['porta'],
                  'user' => (string)$r['usuario'], 'pass' => (string)$r['senha']];
    }
    return $out;
}

/** Grava a lista GLOBAL de concentradores em `ws_concentrador` (upsert por host; quem sair da
 *  lista fica ativo=0, NUNCA é apagado — contratos/logs que referenciam o concentrador continuam
 *  válidos). Chamada tanto pelo salvamento de Config → Concentradores quanto pela semeadura
 *  automática de instalação nova — é o único caminho de escrita da lista global, então as duas
 *  telas (Cadastros e Config) sempre enxergam o mesmo cadastro. */
function ws_concentradores_salvar_global(array $lista): void {
    if (!function_exists('ws_db')) return;
    try {
        $db = ws_db();
        $vistos = [];
        foreach ($lista as $x) {
            if (!is_array($x)) continue;
            $ip = trim((string)($x['ip'] ?? '')); if ($ip === '') continue;
            $tipo = (($x['tipo'] ?? 'accel') === 'mikrotik') ? 'mikrotik' : 'accel';
            $nome = substr(trim((string)($x['nome'] ?? '')), 0, 80) ?: $ip;
            $porta = (int)($x['porta'] ?? ($tipo === 'mikrotik' ? 8728 : 2000));
            $user  = substr(trim((string)($x['user'] ?? '')), 0, 80);
            $pass  = (string)($x['pass'] ?? '');
            $st = $db->prepare("SELECT id FROM ws_concentrador WHERE host=? LIMIT 1");
            $st->execute([$ip]);
            $id = $st->fetchColumn();
            if ($id) {
                $db->prepare("UPDATE ws_concentrador SET nome=?,tipo=?,porta=?,usuario=?,senha=?,ativo=1 WHERE id=?")
                   ->execute([$nome, $tipo, $porta, $user, $pass, (int)$id]);
                $vistos[] = (int)$id;
            } else {
                $db->prepare("INSERT INTO ws_concentrador (nome,tipo,host,porta,usuario,senha,ativo) VALUES (?,?,?,?,?,?,1)")
                   ->execute([$nome, $tipo, $ip, $porta, $user, $pass]);
                $vistos[] = (int)$db->lastInsertId();
            }
        }
        if ($vistos) {
            $ph = implode(',', array_fill(0, count($vistos), '?'));
            $db->prepare("UPDATE ws_concentrador SET ativo=0 WHERE ativo=1 AND id NOT IN ($ph)")->execute($vistos);
        }
    } catch (Throwable $e) {}
}

function ws_cfg() {
    static $c = null; if ($c !== null) return $c;
    $f = ws_cache_dir() . '/wellsystem_config.json';
    $j = is_file($f) ? json_decode(@file_get_contents($f), true) : null;
    $c = is_array($j) ? array_merge(ws_cfg_padrao(), $j) : ws_cfg_padrao();
    /* FONTE ÚNICA: a lista GLOBAL de concentradores agora vem da tabela `ws_concentrador`, não mais
     * do JSON — ver ws_concentradores_db(). O que ainda estiver gravado em 'concentradores' dentro
     * de wellsystem_config.json (config antiga) é ignorado a partir daqui, de propósito.
     * CONCENTRADORES DESCOBERTOS SOZINHOS só quando a tabela está VAZIA (instalação nova, ninguém
     * cadastrou nada ainda): a descoberta usa os NAS que o próprio sistema já conhece e JÁ GRAVA
     * o resultado no cadastro (ws_concentradores_salvar_global), pra virar dado durável e editável
     * em Cadastros → Concentradores — em vez de uma lista fantasma só em memória. */
    $c['concentradores'] = ws_concentradores_db();
    if (!$c['concentradores']) {
        /* MIGRAÇÃO DE QUEM JÁ TINHA CONCENTRADOR SÓ NO JSON ANTIGO (o caso mais comum: quem só
         * usava a tela Config → Concentradores e nunca tinha mexido em Cadastros → Concentradores).
         * Sem isto, a unificação apagava na prática a lista de quem estava assim — a tabela nasce
         * vazia, e o painel para de mostrar cliente nenhum. Migra UMA VEZ (grava na tabela) e a
         * tabela passa a mandar dali em diante, como o resto do código já espera. */
        $legado = is_array($j) && !empty($j['concentradores']) && is_array($j['concentradores']) ? $j['concentradores'] : [];
        if ($legado) {
            ws_concentradores_salvar_global($legado);
            $c['concentradores'] = ws_concentradores_db();
        }
    }
    if (!$c['concentradores']) {
        // Ainda vazio (nem tabela, nem JSON antigo tinham nada): descobre pelos NAS já conhecidos
        // e JÁ GRAVA o resultado no cadastro, pra virar dado durável e editável em Cadastros →
        // Concentradores — em vez de uma lista fantasma só em memória.
        $auto = ws_concentradores_auto();
        if ($auto) { ws_concentradores_salvar_global($auto); $c['concentradores'] = ws_concentradores_db(); }
        $c['concentradores_auto'] = true;
    }
    // MODO "por radius": os concentradores efetivos passam a ser os do radius ATIVO
    // (cai na lista global se aquele radius não tiver concentrador próprio). Este modo continua
    // guardado no JSON — não tem tabela própria por radius; só a lista GLOBAL foi unificada.
    if (($c['cnc_modo'] ?? 'global') === 'por_radius' && !empty($c['radius']) && is_array($c['radius'])) {
        $ra = (int)($c['radius_ativo'] ?? 0);
        $rd = $c['radius'][$ra] ?? ($c['radius'][0] ?? null);
        if (is_array($rd) && !empty($rd['concentradores']) && is_array($rd['concentradores'])) $c['concentradores'] = $rd['concentradores'];
    }
    /* SERVIDOR WEB DETECTADO SOZINHO quando ninguém configurou.
       O WellSystem roda DENTRO do painel do outro ERP: o host que está servindo esta página é,
       por definição, o host dele. Não há o que adivinhar nem o que digitar numa instalação nova.
       O valor detectado NÃO é gravado no arquivo — fica só valendo em memória, para acompanhar o
       servidor se ele mudar de IP/domínio. Configurou à mão? O configurado manda, sempre. */
    if (trim((string)($c['servidor_web'] ?? '')) === '') {
        $c['servidor_web'] = ws_servidor_web_auto();
        $c['servidor_web_auto'] = true;   // a tela de Configurações mostra que veio da detecção
    }
    return $c;
}

/**
 * Host do servidor onde este painel está rodando — usado como "servidor web" quando o campo de
 * Configurações está vazio.
 *
 * HTTP_HOST é o endereço que o operador digitou no navegador, então é o que a máquina dele
 * consegue alcançar — melhor que SERVER_ADDR, que costuma ser um IP interno inacessível de fora.
 * Higienizado porque HTTP_HOST vem do cliente: só letras, números, ponto, hífen, dois-pontos
 * (porta) e colchetes (IPv6) passam.
 */
/**
 * Descobre os concentradores a partir dos NAS já cadastrados — instalação nova sobe com a lista
 * certa sem ninguém digitar IP.
 *
 * Fonte: a tabela `nas`, que é a MESMA que o FreeRADIUS consulta para aceitar requisição de um
 * concentrador. Se um equipamento autentica clientes, ele está ali; e a migração do MK-Auth agora
 * preenche essa tabela a partir do backup (mk_importar_nas). Ou seja: importou o backup, o painel
 * já sabe quais são os concentradores.
 *
 * O resultado NÃO é gravado no arquivo de configuração — fica valendo em memória, para acompanhar
 * o cadastro de NAS. Assim que o operador salvar a lista na tela de Configurações, a lista dele
 * passa a mandar e esta descoberta sai de cena.
 */
function ws_concentradores_auto(): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    if (!function_exists('ws_db')) return $cache;
    try {
        $rs = ws_db()->query("SELECT nasname, shortname FROM nas ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return $cache; }   // sem tabela ainda (instalação em andamento)

    foreach ($rs as $n) {
        $ip = trim((string)($n['nasname'] ?? ''));
        // 127.0.0.1 é o próprio servidor falando com o FreeRADIUS dele mesmo — não é
        // concentrador de cliente, e colocá-lo na lista faria o painel esperar resposta de si.
        if ($ip === '' || $ip === '127.0.0.1' || strtolower($ip) === 'localhost') continue;
        $nome = trim((string)($n['shortname'] ?? ''));
        if ($nome === '') $nome = ws_cnc_curto($ip);
        // porta 2000 = accel-ppp, o padrão do parque. Mikrotik é escolhido na tela quando for o caso.
        $cache[] = ['tipo' => 'accel', 'nome' => $nome, 'ip' => $ip, 'porta' => 2000];
    }
    return $cache;
}

function ws_servidor_web_auto(): string {
    foreach (['HTTP_HOST', 'SERVER_NAME', 'SERVER_ADDR'] as $k) {
        $v = trim((string)($_SERVER[$k] ?? ''));
        if ($v === '') continue;
        $v = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $v);
        if ($v !== '' && $v !== 'localhost' && $v !== '127.0.0.1') return $v;
        if ($v !== '') return $v;   // localhost é melhor que nada (instalação de teste)
    }
    return '';
}
// Config de conexão do RADIUS ATIVO (host/user/senha/banco) — usada pelo config.php.
// Sem radius cadastrado, devolve vazio (aí vale a conexão local padrão do config.php).
function ws_radius_ativo() {
    $c = ws_cfg();
    if (empty($c['radius']) || !is_array($c['radius'])) return [];
    $ra = (int)($c['radius_ativo'] ?? 0);
    $rd = $c['radius'][$ra] ?? ($c['radius'][0] ?? null);
    return (is_array($rd) && !empty($rd['host'])) ? $rd : [];
}

// --- FUNÇÃO DE LEITURA DO CONCENTRADOR ---
// LEITOR UNIFICADO DE SESSÕES — escolhe o driver pelo campo "tipo" do concentrador:
//   'accel' (padrão) -> socket accel-ppp na porta 2000 + "show sessions ..."
//   'mikrotik'        -> RouterOS API na porta 8728 + /ppp/active e /ip/hotspot/active
// Devolve linhas no MESMO formato (10 posições, como o split do accel por "|"), então o
// resto da página não muda: [ifname, user, alias, mac, ip, rate, type, state, called, uptime].
/**
 * Abre a CLI do accel-ppp tentando SSL/TLS primeiro e TCP puro depois.
 *
 * POR QUE NESTA ORDEM
 * Boa parte dos concentradores accel-ppp atende a porta de gerência sobre TLS. Com um socket TCP
 * cru a conexão até ESTABELECE — o aperto de mão do TCP acontece normalmente —, mas o servidor
 * fica esperando o handshake TLS que nunca vem: nenhum banner, nenhuma resposta, e a leitura
 * retorna vazia depois do tempo limite. O sintoma engana, porque "a porta 2000 está aberta" e
 * mesmo assim não vem sessão nenhuma; parece problema de comando ou de permissão, e é de protocolo.
 *
 * Esta é a mesma estratégia que o socket_telnet.php já usava (e por isso a tela de Servidores
 * funcionava enquanto o painel dos concentradores e a coluna de IP da lista de clientes vinham
 * vazios — dois caminhos diferentes para o mesmo concentrador).
 *
 * A tentativa TLS usa verificação de certificado desligada de propósito: concentrador usa
 * certificado próprio, e exigir cadeia válida aqui significaria não conectar em lugar nenhum.
 * O canal continua cifrado; o que não se faz é autenticar o outro lado — aceitável numa rede de
 * gerência interna, e é o que todo cliente de CLI faz nesse cenário.
 */
function ws_accel_conectar(string $ip, int $porta, int $timeout) {
    $ctx = stream_context_create(['ssl' => [
        'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true,
    ]]);
    /* TCP PRIMEIRO, TLS DEPOIS.
     * A maioria dos accel-ppp atende em texto puro; TLS é a exceção. Tentando TLS primeiro, toda
     * leitura num parque comum pagaria uma tentativa fracassada antes da que funciona — e são
     * várias leituras por página, por concentrador. Nesta ordem, o caso comum não perde nada e o
     * caso com TLS passa a funcionar, que era o objetivo. */
    $sk = @stream_socket_client("tcp://{$ip}:{$porta}", $en, $es, $timeout, STREAM_CLIENT_CONNECT);
    if (!$sk) $sk = @stream_socket_client("ssl://{$ip}:{$porta}", $en, $es, $timeout, STREAM_CLIENT_CONNECT, $ctx);
    return $sk ?: null;
}

/** Igual a ws_ler_sessoes(), mas diz também se REALMENTE conseguiu falar com o concentrador —
 *  "zero sessão" (respondeu, ninguém conectado) e "não respondeu" (fora do ar, timeout, IP/senha
 *  errado) parecem a mesma coisa ([]) pra quem só olha a lista, mas são bem diferentes pra quem vai
 *  usar isso pra FECHAR sessão no radacct: fechar todo mundo porque o concentrador estava fora do
 *  ar por 2 segundos apagaria o "Online" na hora errada. ws_ler_sessoes() continua devolvendo só a
 *  lista, pros lugares que já usam ela hoje. */
function ws_ler_sessoes_status($cc, $timeout = 2): array {
    if (!is_array($cc)) return ['ok' => false, 'linhas' => []];
    $tipo = strtolower(trim((string)($cc['tipo'] ?? 'accel')));
    $ip   = trim((string)($cc['ip'] ?? '')); if ($ip === '') return ['ok' => false, 'linhas' => []];
    $porta = (int)($cc['porta'] ?? ($tipo === 'mikrotik' ? 8728 : 2000));
    $timeout = max(2, (int)$timeout);
    if ($tipo === 'mikrotik') {
        /* 31/10/2026: cada leitura da API do MikroTik vira 2 linhas no log da RB ("logged in/out ... via api"). Uma rodada do cron lia a mesma RB 4-5 vezes
           (sincronizar, sessões presas, retrato online...). Resultado BOM de até 25 s é reaproveitado dentro do mesmo processo; falha nunca é guardada. */
        static $memo = [];
        $mk = $ip . ':' . $porta;
        if (isset($memo[$mk]) && time() - $memo[$mk][0] < 25) return $memo[$mk][1];
        $res = (function () use ($cc, $ip, $porta, $timeout) {
        if (!class_exists('RouterosAPI') && is_file(__DIR__ . '/routeros_api.class.php')) @require_once __DIR__ . '/routeros_api.class.php';
        if (!class_exists('RouterosAPI')) return ['ok' => false, 'linhas' => []];
        $api = new RouterosAPI();
        if (!$api->connect($ip, (string)($cc['user'] ?? 'admin'), (string)($cc['pass'] ?? ''), $porta ?: 8728, $timeout)) return ['ok' => false, 'linhas' => []];
        $rows = [];
        foreach (['/ppp/active/print', '/ip/hotspot/active/print'] as $cmd) {
            $recs = $api->comm($cmd); if (!is_array($recs)) continue;
            foreach ($recs as $r) {
                $user = $r['name'] ?? ($r['user'] ?? ''); if ($user === '') continue;
                $rows[] = ['<' . ($r['service'] ?? 'ppp') . '-' . $user . '>', $user, '',
                    $r['caller-id'] ?? ($r['mac-address'] ?? ''), $r['address'] ?? '0.0.0.0', '',
                    $r['service'] ?? 'pppoe', 'active', '', $r['uptime'] ?? '00:00:00'];
            }
        }
        $api->disconnect();
        return ['ok' => true, 'linhas' => $rows];
        })();
        if (!empty($res['ok'])) $memo[$mk] = [time(), $res];
        return $res;
    }
    // accel-ppp (padrão)
    $sk = ws_accel_conectar($ip, $porta ?: 2000, $timeout); if (!$sk) return ['ok' => false, 'linhas' => []];
    stream_set_timeout($sk, $timeout);
    fwrite($sk, "show sessions ifname,username,user-alias,calling-sid,ip,rate-limit,type,state,called-sid,uptime match state active\r\n");
    /* LÊ EM BLOCOS e para no PROMPT FINAL (24/09/2026 — medido: toda leitura levava exatamente o timeout,
       3 s por concentrador). Com fgets, o prompt "accel-ppp# " — que não termina em quebra de linha — deixava
       a última leitura esperando o timeout mesmo com todas as sessões já recebidas. Só para depois de ter
       visto o CABEÇALHO da tabela ("ifname"): um prompt que chegue antes da resposta não corta a leitura.
       Prompt = última linha sem "|" terminando em "#" (vale para accel-ppp# e para nome de host). */
    $buf = '';
    while (!feof($sk)) {
        $l = fread($sk, 8192);
        if ($l === false || ($l === '' && !empty(stream_get_meta_data($sk)['timed_out']))) break;
        $buf .= $l;
        if (strpos($buf, 'ifname') !== false && preg_match('/(^|\n)[^\n|]*#\s*$/', $buf)) break;
    }
    fclose($sk);
    $rows = [];
    foreach (explode("\n", $buf) as $ln) {
        $ln = trim(str_replace("\x00", '', $ln));
        if ($ln === '' || strpos($ln, 'ifname') !== false || strpos($ln, '|') === false) continue;
        $rows[] = array_map('trim', explode('|', $ln));
    }
    return ['ok' => true, 'linhas' => $rows];
}

function ws_ler_sessoes($cc, $timeout = 2) {
    return ws_ler_sessoes_status($cc, $timeout)['linhas'];
}

/** Lê TODOS os concentradores ao vivo, grava um retrato único em cache/sessoes_online.json e fecha
 *  no radacct as sessões que já não existem mais no equipamento — sessão que caiu sem o concentrador
 *  avisar o RADIUS (queda de energia, reboot, cabo) fica com acctstoptime NULL pra sempre, contando
 *  online no card "Online" do Painel enquanto o "Total Conectado" da página de Concentradores (que
 *  lê o equipamento ao vivo) já não a mostra mais. Essa é a causa mais comum dos dois cards não
 *  baterem. Só fecha sessão de concentrador que RESPONDEU (ws_ler_sessoes_status ok=true) — um
 *  concentrador fora do ar não fecha nada dos clientes dele, pra não apagar o "Online" à toa.
 *  Chamada pelo cron (radius_sync.php, a cada 2 min). O Painel lê 'total' (sessões vivas) daqui;
 *  a página de Concentradores lê os equipamentos ao vivo, então os dois podem diferir em 1–2 sessões
 *  no intervalo entre duas rodadas do cron. */
function ws_sessoes_sincronizar(): array {
    $em = time();
    $vivos = []; $porConcentrador = []; $ipsOk = []; $linhasTotal = 0;
    foreach (ws_concentradores_db() as $cc) {
        $r = ws_ler_sessoes_status($cc, 2);
        $nome = (string)($cc['nome'] ?: $cc['ip']);
        if (!$r['ok']) { $porConcentrador[$nome] = null; continue; }   // null = não respondeu agora
        $ipsOk[] = $cc['ip'];
        $n = 0;
        foreach ($r['linhas'] as $l) { $u = trim((string)($l[1] ?? '')); if ($u !== '') { $vivos[$u] = true; $n++; } }
        $porConcentrador[$nome] = $n;
        $linhasTotal += $n;
    }
    $ret = ['em' => $em, 'total' => count($vivos), 'sessoes_linhas' => $linhasTotal, 'por_concentrador' => $porConcentrador, 'concentradores_ok' => count($ipsOk)];

    // Reconciliação do radacct — só nos NAS que responderam agora.
    if ($ipsOk && function_exists('ws_db')) {
        try {
            $db = ws_db();
            $ph = implode(',', array_fill(0, count($ipsOk), '?'));
            /* CORRIGIDO 01/10/2026 — fechava SESSÃO VIVA. Bastava a leitura do concentrador vir incompleta (Telnet
               cortado) para o cliente sumir da lista e a sessão dele ser "encerrada" aqui, sem motivo, enquanto
               continuava navegando (caso real: sessão de 21/09 marcada "fim 24/09" e ainda online em 01/10). Com o
               registro fechado, a derrubada do BLOQUEIO não achava sessão aberta — e 23 bloqueados seguiram navegando.
               Agora só fecha o que, além de não aparecer no equipamento, PAROU de mandar atualização ao RADIUS há
               15 min+ (sessão viva manda interim a cada 5 min — nunca é fechada). Fecha na hora da última
               atualização, com motivo, para o histórico mostrar a verdade. */
            $velha = "(COALESCE(acctupdatetime, acctstarttime) < NOW() - INTERVAL 15 MINUTE)";
            $fecha = "SET acctstoptime = COALESCE(acctupdatetime, acctstarttime), acctterminatecause = 'Ws-Sem-Atualizacao'";
            if ($vivos) {
                $usuarios = array_keys($vivos);
                $phu = implode(',', array_fill(0, count($usuarios), '?'));
                $stFechar = $db->prepare("UPDATE radacct $fecha WHERE acctstoptime IS NULL AND $velha AND nasipaddress IN ($ph) AND username NOT IN ($phu)");
                $stFechar->execute(array_merge($ipsOk, $usuarios));
            } else {
                $stFechar = $db->prepare("UPDATE radacct $fecha WHERE acctstoptime IS NULL AND $velha AND nasipaddress IN ($ph)");
                $stFechar->execute($ipsOk);
            }
            $ret['radacct_fechados'] = $stFechar->rowCount();
            $ret['radacct_reabertos'] = ws_radacct_reabrir_vivas($db);
        } catch (Throwable $e) { $ret['radacct_erro'] = $e->getMessage(); }
    }

    // Contagem "Online" do jeito que o card do Painel precisa: contrato ATIVO cujo login (PPPoE OU
    // IPoE) apareceu vivo em algum concentrador agora — a MESMA fonte do "Total Conectado", pra os
    // dois cards nunca mais divergirem por causa de dois caminhos diferentes de contagem.
    $ret['contratos_online'] = 0;
    if ($vivos && function_exists('ws_db')) {
        try {
            $db = ws_db();
            $usuarios = array_keys($vivos);
            $phu = implode(',', array_fill(0, count($usuarios), '?'));
            $sql = "SELECT COUNT(DISTINCT ct.id) FROM ws_contrato ct WHERE ct.status<>'cancelado'
                    AND (ct.login_pppoe IN ($phu) OR ct.login_ipoe IN ($phu))";
            $st = $db->prepare($sql); $st->execute(array_merge($usuarios, $usuarios));
            $ret['contratos_online'] = (int)$st->fetchColumn();
        } catch (Throwable $e) {}
    }

    /* POR RAMAL (cidade) — o Painel, com um ramal selecionado, precisa do "Online" só daquela cidade.
     *   por_ramal                   sessões vivas cujo login pertence a cliente do ramal (chave "r<id>")
     *   contratos_online_por_ramal  contratos não cancelados com sessão viva, por ramal (alimenta o Offline)
     * Sessão sem cadastro não pertence a ramal nenhum: só entra no total de "todas as cidades". */
    $ret['por_ramal'] = []; $ret['contratos_online_por_ramal'] = [];
    if ($vivos && function_exists('ws_db')) {
        try {
            $db = ws_db();
            $usuarios = array_keys($vivos);
            $phu = implode(',', array_fill(0, count($usuarios), '?'));
            $sql = "SELECT c.ramal_id rid, COUNT(DISTINCT ct.id) n FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                    WHERE ct.status<>'cancelado' AND (ct.login_pppoe IN ($phu) OR ct.login_ipoe IN ($phu))
                    GROUP BY c.ramal_id";
            $st = $db->prepare($sql); $st->execute(array_merge($usuarios, $usuarios));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) {
                if ($x['rid'] !== null) $ret['contratos_online_por_ramal']['r' . (int)$x['rid']] = (int)$x['n'];
            }
        } catch (Throwable $e) {}
    }

    /* DIAGNÓSTICO do "Online" — separa as sessões vivas em quem o card do Painel enxerga como contrato
     * e quem ele não enxerga, e diz POR QUÊ (lista de logins, até 300 por grupo):
     *   sessoes_login_exato   login da sessão = login_pppoe/login_ipoe de contrato NÃO cancelado (conta no Painel)
     *   so_formato_ou_ont     casa com contrato ativo só depois de normalizar (maiúscula/pontuação) ou pelo ont_id
     *   contrato_cancelado    o login pertence a contrato CANCELADO, mas a sessão ainda está de pé no concentrador
     *   sem_cadastro          login que não existe em ws_contrato (ex.: cliente que só está no MK-Auth)
     * Só leitura no banco. A contagem por cidade (por_ramal) sai deste mesmo laço e é o que o Painel usa
     * quando um ramal está selecionado. */
    if ($vivos && function_exists('ws_db')) {
        try {
            $norm  = function ($x) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$x)); };
            $lower = function ($x) { return function_exists('mb_strtolower') ? mb_strtolower((string)$x, 'UTF-8') : strtolower((string)$x); };
            $exato = []; $nAtivo = []; $nCanc = []; $mapaRamal = []; $porRamal = [];
            /* Mesma consulta e mesma regra "o 1º contrato vence" de ws_mapa_raiz_por_login() (servidores.php):
             * é o que garante que a cidade de cada sessão aqui seja a MESMA que a página de Concentradores usa. */
            $rsC = ws_db()->query("SELECT ct.status, ct.login_pppoe, ct.login_ipoe, ct.ont_id, c.ramal_id
                                   FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                                   LEFT JOIN ws_plano p ON p.id = ct.plano_id
                                   WHERE (ct.login_pppoe IS NOT NULL AND ct.login_pppoe <> '')
                                      OR (ct.login_ipoe  IS NOT NULL AND ct.login_ipoe  <> '')
                                      OR (ct.ont_id      IS NOT NULL AND ct.ont_id      <> '')")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rsC as $rc) {
                $canc = ((string)$rc['status'] === 'cancelado');
                foreach (['login_pppoe', 'login_ipoe', 'ont_id'] as $col) {
                    $v = trim((string)($rc[$col] ?? '')); if ($v === '') continue;
                    $k = $norm($v); if ($k === '') continue;
                    if (!isset($mapaRamal[$k])) $mapaRamal[$k] = ($rc['ramal_id'] === null ? 0 : (int)$rc['ramal_id']);
                    if ($canc) $nCanc[$k] = true; else $nAtivo[$k] = true;
                    if (!$canc && $col !== 'ont_id') $exato[$lower($v)] = true;
                }
            }
            $dg = ['sessoes_login_exato' => 0, 'so_formato_ou_ont' => 0, 'contrato_cancelado' => 0, 'sem_cadastro' => 0,
                   'lista_so_formato_ou_ont' => [], 'lista_contrato_cancelado' => [], 'lista_sem_cadastro' => []];
            $cap = 300;
            foreach (array_keys($vivos) as $u) {
                $u = (string)$u; $k = $norm($u);
                if ($k !== '' && !empty($mapaRamal[$k])) { $rk = 'r' . $mapaRamal[$k]; $porRamal[$rk] = ($porRamal[$rk] ?? 0) + 1; }
                if (isset($exato[$lower($u)]))                 { $dg['sessoes_login_exato']++; }
                elseif ($k !== '' && isset($nAtivo[$k]))       { $dg['so_formato_ou_ont']++;   if (count($dg['lista_so_formato_ou_ont']) < $cap)  $dg['lista_so_formato_ou_ont'][]  = $u; }
                elseif ($k !== '' && isset($nCanc[$k]))        { $dg['contrato_cancelado']++;  if (count($dg['lista_contrato_cancelado']) < $cap) $dg['lista_contrato_cancelado'][] = $u; }
                else                                           { $dg['sem_cadastro']++;        if (count($dg['lista_sem_cadastro']) < $cap)       $dg['lista_sem_cadastro'][]       = $u; }
            }
            $ret['diag_online'] = $dg;
            $ret['por_ramal'] = $porRamal;
        } catch (Throwable $e) { $ret['diag_online_erro'] = $e->getMessage(); unset($ret['por_ramal']); }   // sem por_ramal o Painel cai no cálculo antigo por ramal
    }

    @file_put_contents(WS_CACHE . '/sessoes_online.json', json_encode($ret, JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/sessoes_online.json', 0640);
    return $ret;
}

/** ADICIONAL HERDA A CIDADE DO TITULAR. Cliente adicional (titular_id preenchido) vindo de importação/
 *  migração chega sem cidade/UF — e sem cidade ele some dos filtros e das contagens por cidade. Aqui, para
 *  cada adicional, copia do titular o que estiver EM BRANCO: cidade, UF, uf_id (só quando a UF final é a
 *  mesma do titular) e ramal_id. Nunca sobrescreve o que já foi preenchido no adicional. Idempotente e
 *  barata (poucas linhas) — roda no cron (radius_sync.php) e pode ser chamada de qualquer outro ponto.
 *  Devolve quantos adicionais foram atualizados. */
function ws_adicionais_herdar_cidade(PDO $db): int {
    $vazio = function ($v) { return $v === null || trim((string)$v) === ''; };
    $rs = $db->query("SELECT a.id, a.cidade, a.uf, a.uf_id, a.ramal_id,
                             t.cidade t_cidade, t.uf t_uf, t.uf_id t_uf_id, t.ramal_id t_ramal_id
                      FROM ws_cliente a JOIN ws_cliente t ON t.id = a.titular_id
                      WHERE a.titular_id IS NOT NULL
                        AND (a.cidade IS NULL OR TRIM(a.cidade) = '' OR a.uf IS NULL OR TRIM(a.uf) = ''
                             OR a.uf_id IS NULL OR a.ramal_id IS NULL)")->fetchAll(PDO::FETCH_ASSOC);
    $n = 0;
    foreach ($rs as $r) {
        $set = []; $par = [];
        if ($vazio($r['cidade']) && !$vazio($r['t_cidade'])) { $set[] = 'cidade=?'; $par[] = $r['t_cidade']; }
        $ufFinal = $r['uf'];
        if ($vazio($r['uf']) && !$vazio($r['t_uf'])) { $set[] = 'uf=?'; $par[] = $r['t_uf']; $ufFinal = $r['t_uf']; }
        if ($r['uf_id'] === null && $r['t_uf_id'] !== null && strtoupper(trim((string)$ufFinal)) === strtoupper(trim((string)$r['t_uf']))) {
            $set[] = 'uf_id=?'; $par[] = (int)$r['t_uf_id'];
        }
        if ($r['ramal_id'] === null && $r['t_ramal_id'] !== null) { $set[] = 'ramal_id=?'; $par[] = (int)$r['t_ramal_id']; }
        if (!$set) continue;
        $par[] = (int)$r['id'];
        $db->prepare('UPDATE ws_cliente SET ' . implode(', ', $set) . ' WHERE id=?')->execute($par);
        $n++;
    }
    return $n;
}

/** Lê o retrato gravado por ws_sessoes_sincronizar() — instantâneo (sem Telnet/API), é o que os
 *  cards "Online" (Painel) e "Total Conectado" (Concentradores) devem usar no dia a dia. $max_idade
 *  em segundos: se o retrato estiver mais velho que isso (cron parado, por exemplo), devolve null
 *  pra quem chamar decidir se quer ler ao vivo como reserva — nunca mostra um número muito velho
 *  como se fosse atual sem avisar. */
function ws_sessoes_cache(int $max_idade = 300): ?array {
    $f = WS_CACHE . '/sessoes_online.json';
    if (!is_file($f)) return null;
    $j = json_decode((string)@file_get_contents($f), true);
    if (!is_array($j) || empty($j['em'])) return null;
    if ((time() - (int)$j['em']) > $max_idade) return null;
    return $j;
}

/* ===========================================================================================
   CONEXÕES VIVAS — FONTE ÚNICA DE "QUEM ESTÁ ONLINE E COM QUAL IP"
   -------------------------------------------------------------------------------------------
   Antes cada tela respondia isso de um jeito: o Painel dos Concentradores lia os concentradores
   ao vivo, a lista de Clientes lia a tabela radacct e o Total Radius lia só o cadastro. Como o
   RADIUS que autentica é o do MK-Auth, a radacct do banco do WellSystem costuma estar VAZIA —
   por isso o IP do cliente conectado simplesmente não aparecia na lista de Clientes.

   Agora todas perguntam aqui. A leitura real dos concentradores é cara (socket + timeout), então
   o resultado fica num cache curto compartilhado por todas as telas e por todas as abas.
   =========================================================================================== */

/** Caminho do cache das conexões vivas. */
function ws_conexao_cache_arq(): string {
    return (function_exists('ws_cache_dir') ? ws_cache_dir() : WS_CACHE) . '/conexao_viva.json';
}

/**
 * Mapa das conexões ativas: [ loginNormalizado => ['login','ip','vlan','cnc','em'] ].
 *
 * @param int  $validade  segundos que o cache vale. Dentro disso, devolve o que está gravado e
 *                        NÃO fala com concentrador nenhum — é o caminho normal de quem só quer
 *                        exibir (lista de Clientes).
 * @param bool $forcar    ignora o cache e lê os concentradores agora (o painel usa isto).
 */
function ws_conexao_viva(int $validade = 90, bool $forcar = false): array {
    /* PÁGINA SEM ESPERAR CONCENTRADOR (24/09/2026 — medido no servidor: 2 leituras de ~2 s por abertura da
     * lista, porque um concentrador parou de responder e o cache ficou 3 h sem atualizar).
     *   1) uma leitura por requisição: a lista e o contador do "Online" pediam as duas;
     *   2) leitura que falhou há menos de $validade s não é repetida a cada página;
     *   3) telas de EXIBIÇÃO ($validade >= 30) mostram o guardado na hora e atualizam DEPOIS de entregar a
     *      página (PHP-FPM). Quem pede o status "agora" ($validade < 30, ex.: depois de derrubar) lê na hora. */
    static $memo = null, $agendado = false;
    if (!$forcar && $memo !== null && time() - $memo['em'] < $validade) return $memo['itens'];

    $arq = ws_conexao_cache_arq();
    $cache = []; $emCache = 0; $tentou = 0;
    if (is_file($arq)) {
        $j = json_decode((string)@file_get_contents($arq), true);
        if (is_array($j) && isset($j['itens']) && is_array($j['itens'])) {
            $emCache = (int)($j['em'] ?? 0);
            $idade = time() - $emCache;
            if (!$forcar && $idade >= 0 && $idade < $validade) { $memo = ['em' => $emCache, 'itens' => $j['itens']]; return $j['itens']; }
            $cache = $j['itens'];   // guardado para devolver se a leitura falhar
            $tentou = (int)($j['tentou'] ?? 0);
        }
    }
    if (!$forcar && $cache) {
        if (time() - $tentou < $validade) return $cache;   // (2) acabou de tentar e o concentrador não respondeu
        if ($validade >= 30 && PHP_SAPI === 'fpm-fcgi' && function_exists('fastcgi_finish_request')) {   // (3)
            if (!$agendado) {
                $agendado = true;
                register_shutdown_function(function () {
                    @fastcgi_finish_request();   // a página já foi entregue; daqui em diante ninguém espera
                    try { ws_conexao_viva_ler(false); } catch (Throwable $e) {}
                });
            }
            return $cache;
        }
    }
    $itens = ws_conexao_viva_ler($forcar);
    $memo = ['em' => time(), 'itens' => $itens];
    return $itens;
}

/** Leitura REAL dos concentradores + gravação do cache e do último IP/VLAN. Devolve o cache antigo quando
 *  nenhum concentrador respondeu — e marca a tentativa ("tentou"), para as próximas páginas não repetirem. */
function ws_conexao_viva_ler(bool $forcar = false): array {
    $arq = ws_conexao_cache_arq();
    $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    $cache = (is_array($j) && isset($j['itens']) && is_array($j['itens'])) ? $j['itens'] : [];

    /* Trava simples: se outra requisição já está lendo os concentradores, esta devolve o cache
       velho em vez de abrir mais sockets. Sem isto, várias abas abertas multiplicariam a
       leitura e o painel ficaria lento por culpa dele mesmo. */
    $lock = $arq . '.lock';
    if (is_file($lock) && (time() - (int)@filemtime($lock)) < 30 && !$forcar) return $cache;
    @touch($lock);

    $itens = [];
    if (function_exists('ws_cfg') && function_exists('ws_ler_sessoes_status')) {
        $cfg = ws_cfg();
        $to  = (int)($cfg['timeout'] ?? 2);
        /* CONCENTRADOR QUE NÃO RESPONDE FICA 2 MIN DE FORA (24/09/2026). Os Mikrotik de gerência da rede ficam
           na lista mas não atendem a API (sem PPPoE neles hoje): cada leitura esperava ~3 s por um deles. Falhou →
           não é consultado por 2 min; depois tenta de novo sozinho (quando a API for ativada, volta a ser lido).
           O forçado (botão Atualizar do Painel) tenta todos. */
        $arqF = dirname($arq) . '/concentrador_falha.json';
        $falha = is_file($arqF) ? (json_decode((string)@file_get_contents($arqF), true) ?: []) : [];
        $mudouF = false;
        foreach (($cfg['concentradores'] ?? []) as $cc) {
            $ipCnc = is_array($cc) ? (string)($cc['ip'] ?? '') : (string)$cc;
            $nmCnc = is_array($cc) ? (string)($cc['nome'] ?? '') : '';
            $chF = $ipCnc . ':' . (is_array($cc) ? (string)($cc['porta'] ?? '') : '');
            /* Só sai depois de 3 FALHAS SEGUIDAS: uma oscilação de um concentrador de cliente (CNC) não pode
               tirá-lo da leitura — o online ficaria parado. Quem falha sempre (Mikrotik de gerência
               sem API) sai na 3ª e só volta a ser tentado 2 min depois. */
            $fl = is_array($falha[$chF] ?? null) ? $falha[$chF] : null;
            if (!$forcar && $fl && (int)$fl['n'] >= 3 && time() - (int)$fl['em'] < 120) continue;
            $rs = ws_ler_sessoes_status($cc, $to);
            if (empty($rs['ok'])) { $falha[$chF] = ['n' => (int)($fl['n'] ?? 0) + 1, 'em' => time()]; $mudouF = true; continue; }
            if ($fl) { unset($falha[$chF]); $mudouF = true; }
            foreach ($rs['linhas'] as $p) {
                $login = trim((string)($p[1] ?? '')); if ($login === '') continue;
                $k = ws_conexao_norm($login);
                $ip = trim((string)($p[4] ?? ''));
                if ($ip === '0.0.0.0') $ip = '';
                $vlan = preg_replace('/\D/', '', (string)($p[8] ?? ''));
                // uptime da sessão (posição 9 do accel-ppp) — é o "tempo de conexão" que a lista
                // de Clientes mostra ao passar o mouse na situação do cliente.
                $upt = trim((string)($p[9] ?? ''));
                $itens[$k] = ['login' => $login, 'ip' => $ip, 'vlan' => $vlan, 'uptime' => $upt,
                              'cnc' => $ipCnc, 'cnc_nome' => $nmCnc, 'em' => time()];
            }
        }
        if ($mudouF && @file_put_contents($arqF, json_encode($falha)) !== false) @chmod($arqF, 0666);
    }
    @unlink($lock);

    // Leitura vazia com cache cheio = concentrador fora do ar, não "todo mundo caiu".
    // Devolver o cache evita a tela piscar "ninguém online" a cada instabilidade de rede. A tentativa fica
    // anotada ("tentou") SEM mexer no "em": o dado continua marcado com a idade verdadeira.
    if (!$itens && $cache) {
        $j['tentou'] = time();
        if (@file_put_contents($arq, json_encode($j, JSON_UNESCAPED_UNICODE)) !== false) @chmod($arq, 0666);
        return $cache;
    }

    $j = json_encode(['em' => time(), 'tentou' => time(), 'itens' => $itens], JSON_UNESCAPED_UNICODE);
    if (@file_put_contents($arq, $j) !== false) @chmod($arq, 0666);

    // Grava último IP/VLAN no cadastro (obs2/obs3) na mesma passada — sem coleta extra.
    if (function_exists('ws_db')) {
        try { ws_conexao_registrar(ws_db(), $itens); } catch (Throwable $e) {}
    }
    return $itens;
}

/** IDs dos clientes com sessão ONLINE agora — fonte única dos filtros Online/Offline da lista.
 *  1) conexões vivas lidas nos concentradores (ws_conexao_viva, cache 90s — mesma do Painel);
 *  2) sessões abertas na radacct (quando o RADIUS é o do próprio WellSystem).
 *  Casa por login_pppoe E login_ipoe, normalizados (maiúscula, sem separador). */
function ws_clientes_online_ids(PDO $db): array {
    // Memorizado por requisição: a lista de Clientes pede isto 2x (filtro + contador do botão) e o
    // mapa, o Painel etc. podem pedir de novo — a varredura dos contratos roda uma vez só por página.
    static $memo = null;
    if ($memo !== null) return $memo;
    $vivos = [];
    if (function_exists('ws_conexao_viva')) { try { $vivos = ws_conexao_viva(90); } catch (Throwable $e) {} }
    $ids = [];
    try {
        $rs = $db->query("SELECT cliente_id, login_pppoe, login_ipoe FROM ws_contrato WHERE status<>'cancelado'
                          AND (COALESCE(login_pppoe,'')<>'' OR COALESCE(login_ipoe,'')<>'')");
        $norm = function ($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); };
        foreach ($rs as $r) {
            foreach (['login_pppoe', 'login_ipoe'] as $c) {
                $k = $norm($r[$c] ?? '');
                if ($k !== '' && isset($vivos[$k])) { $ids[(int)$r['cliente_id']] = 1; break; }
            }
        }
    } catch (Throwable $e) {}
    try {
        $rs = $db->query("SELECT DISTINCT ct.cliente_id FROM ws_contrato ct JOIN radacct r
                          ON (r.username=ct.login_pppoe OR r.username=ct.login_ipoe) AND r.acctstoptime IS NULL");
        foreach ($rs as $r) $ids[(int)$r['cliente_id']] = 1;
    } catch (Throwable $e) {}
    return $memo = array_keys($ids);
}

/** OFFLINE = cliente ATIVO, com contrato ATIVO, sem sessão viva — a MESMA regra do filtro
 *  "Offline" da lista de Clientes (erp.php/crm.php), para card e lista nunca divergirem.
 *  Antes o card fazia "contratos ativos − contratos online", e o "online" incluía cliente
 *  BLOQUEADO conectado na faixa de bloqueio: o card mostrava 41 e a lista 77 (30/09/2026).
 *  $ramalAtivo: mesmo critério da lista (cidade selecionada OU sem ramal). */
function ws_clientes_offline_count(PDO $db, $ramalAtivo = null): int {
    $idsOn = ws_clientes_online_ids($db);
    $inOn  = $idsOn ? implode(',', array_map('intval', $idsOn)) : '0';
    $sql = "SELECT COUNT(*) FROM ws_cliente c WHERE c.status='ativo'
            AND EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.status='ativo')
            AND c.id NOT IN ($inOn)";
    if ($ramalAtivo) $sql .= " AND (c.ramal_id=" . (int)$ramalAtivo['id'] . " OR c.ramal_id IS NULL)";
    try { return (int)$db->query($sql)->fetchColumn(); } catch (Throwable $e) { return 0; }
}

/** Logins de sessão de UM contrato, pelo tipo de conexão (tipo_conexao manda — login_pppoe pode
 *  ser lixo antigo num contrato IPoE). IPoE: login_ipoe, senão o ID da ONU/ONT, senão o SN.
 *  PPPoE: login_pppoe. Devolve os logins já normalizados (ws_conexao_norm), sem repetição. */
function ws_contrato_logins_sessao(array $ct): array {
    $tipo = strtolower(trim((string)($ct['tipo_conexao'] ?? '')));
    $cols = $tipo === 'ipoe'  ? ['login_ipoe', 'ont_id', 'sn_onu']
          : ($tipo === 'pppoe' ? ['login_pppoe'] : ['login_pppoe', 'login_ipoe', 'ont_id']);
    $out = [];
    foreach ($cols as $c) { $k = ws_conexao_norm($ct[$c] ?? ''); if ($k !== '') $out[$k] = 1; }
    return array_keys($out);
}

/** IP da sessão VIVA do contrato: concentradores (ws_conexao_viva, mesmo cache do Painel) e depois
 *  radacct com acctstoptime IS NULL. Offline = '' — nunca o ultimo_ip gravado, que é só histórico. */
function ws_contrato_ip_vivo(PDO $db, array $ct): string {
    $logins = ws_contrato_logins_sessao($ct);
    if (!$logins) return '';
    $vivos = [];
    if (function_exists('ws_conexao_viva')) { try { $vivos = ws_conexao_viva(90); } catch (Throwable $e) {} }
    foreach ($logins as $k) if (!empty($vivos[$k]['ip'])) return (string)$vivos[$k]['ip'];
    // Concentradores responderam e o cliente não está lá = OFFLINE. A radacct só vale quando não há
    // leitura de concentrador: sessão presa (acctstoptime vazio) não pode fazer cliente caído parecer online.
    if ($vivos) return '';
    try {
        $tipo = strtolower(trim((string)($ct['tipo_conexao'] ?? '')));
        $cols = $tipo === 'ipoe' ? ['login_ipoe', 'ont_id', 'sn_onu'] : ($tipo === 'pppoe' ? ['login_pppoe'] : ['login_pppoe', 'login_ipoe', 'ont_id']);
        $us = [];
        foreach ($cols as $c) { $v = trim((string)($ct[$c] ?? '')); if ($v !== '') $us[$v] = 1; }
        if ($us) {
            $ph = implode(',', array_fill(0, count($us), '?'));
            $st = $db->prepare("SELECT framedipaddress FROM radacct WHERE username IN ($ph) AND acctstoptime IS NULL
                                AND COALESCE(framedipaddress,'') NOT IN ('','0.0.0.0') ORDER BY acctstarttime DESC LIMIT 1");
            $st->execute(array_keys($us));
            $ip = (string)($st->fetchColumn() ?: '');
            if ($ip !== '') return $ip;
        }
    } catch (Throwable $e) {}
    return '';
}

/* ===========================================================================================
   NOME CURTO DO CONCENTRADOR — "Concentrador 1" vira "CNC-1"
   -------------------------------------------------------------------------------------------
   O resto do sistema (Painel dos Concentradores, cadastro de NAS, Radius) sempre chamou de
   CNC-1 / CNC-2. Só a etiqueta abaixo do nome do cliente escrevia por extenso, porque pegava o
   "apelido" da configuração cru — e num espaço de duas linhas "Concentrador 1" ocupa o dobro
   sem dizer nada a mais. A conversão fica aqui, num lugar só, para não haver duas grafias.
   =========================================================================================== */

/** "Concentrador 1", "concentrador-02", "CNC 1" -> "CNC-1". Sem número, devolve o nome como veio. */
function ws_cnc_curto(?string $nome): string {
    $n = trim((string)$nome);
    if ($n === '') return '';
    if (preg_match('/(?:concentrador|cnc|nas|pop)\D{0,3}(\d+)/i', $n, $m)) return 'CNC-' . (int)$m[1];
    // Só o IP (quando o apelido está vazio): usa o último octeto, que é como o operador se refere.
    if (preg_match('/^\d{1,3}(?:\.\d{1,3}){3}$/', $n) && preg_match('/(\d+)$/', $n, $m)) return 'CNC-' . (int)$m[1];
    return $n;
}

/** Índice do concentrador (1, 2, 3…) para escolher a cor da etiqueta. 0 = desconhecido. */
function ws_cnc_indice(?string $nome): int {
    return preg_match('/(\d+)\s*$/', ws_cnc_curto($nome), $m) ? (int)$m[1] : 0;
}

/* ===========================================================================================
   SINCRONIZAÇÃO DOS DADOS DE REDE NO CONTRATO
   -------------------------------------------------------------------------------------------
   Um contrato tem campos que NINGUÉM deveria digitar, porque a rede já sabe a resposta:

     da OLT            -> zona, VLAN, placa, PON, sinal RX da ONU, RX de retorno na OLT,
                          TX e o modelo/tipo do equipamento;
     do CONCENTRADOR   -> VLAN em que o cliente autenticou, IP entregue e em qual concentrador.

   Até aqui isso só acontecia com a ficha ABERTA na tela (a cada 45s). Quem nunca abre a ficha
   ficava com o cadastro velho para sempre — e é justamente o cliente que ninguém olha que dá
   trabalho quando aparece um problema. Esta função faz a mesma coisa para a base INTEIRA, e é a
   mesma regra dos dois lados, num lugar só.

   AS TRÊS REGRAS (as mesmas da tela, e elas importam):
     1. Valor IGUAL ao que já está gravado -> não escreve. Menos escrita no banco e o
        atualizado_em do contrato não muda à toa.
     2. Campo VAZIO -> preenche.
     3. Campo PREENCHIDO com valor diferente -> só é trocado quando o dado é MEDIÇÃO (sinal, IP,
        VLAN da conexão), que muda de verdade com o tempo. Zona, placa e PON são CADASTRO: se o
        operador escreveu algo diferente, ele tinha um motivo, e a sincronização não desfaz.

   Não depende de nada fora do código: sem OLT acessível ou sem concentrador, cada fonte
   simplesmente não contribui, e o que já está gravado permanece.
   =========================================================================================== */

/**
 * Sincroniza os campos de rede dos contratos.
 *
 * @param PDO   $db     banco raiz.
 * @param array $logins limita a estes logins (vazio = todos os contratos).
 * @return array ['contratos'=>lidos, 'atualizados'=>n, 'campos'=>n, 'olt'=>n, 'conexao'=>n]
 */
function ws_contrato_sincronizar_olt(PDO $db, array $logins = []): array {
    $res = ['contratos' => 0, 'atualizados' => 0, 'campos' => 0, 'olt' => 0, 'conexao' => 0];

    // mk_olt_dados() vive no importador (é lá que o cache da OLT é interpretado). Carrega sob
    // demanda: instalação sem o módulo da OLT continua funcionando, só sem essa fonte.
    if (!function_exists('mk_olt_dados') && is_file(__DIR__ . '/mkauth_import.php')) {
        try { require_once __DIR__ . '/mkauth_import.php'; } catch (Throwable $e) {}
    }
    $temOlt = function_exists('mk_olt_dados');
    $vivos  = function_exists('ws_conexao_viva') ? ws_conexao_viva(60) : [];

    try {
        $rows = $db->query(
            "SELECT id, login_pppoe, login_ipoe, ont_id, sn_onu, vlan, zona, placa_pon, pon,
                    rx_sinal, tx_sinal, rx_olt, equipamento, equip_modelo, ultimo_ip, ultimo_cnc
               FROM ws_contrato
              WHERE COALESCE(status,'') <> 'cancelado'"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return $res; }

    // Medição muda sozinha com o tempo -> pode substituir valor diferente.
    // Cadastro é decisão de gente -> só preenche quando está vazio.
    /* O que vem da OLT/SmartOLT é a FONTE: zona, modo (Bridge/Router), placa, PON e modelo seguem a
     * OLT quando ela traz valor diferente (pedido do provedor — antes só preenchiam campo vazio e a
     * ficha ficava com a zona/modo antigos para sempre). Valor igual é descartado; leitura vazia
     * nunca apaga o que está gravado. */
    $medicao  = ['rx_sinal' => 1, 'tx_sinal' => 1, 'rx_olt' => 1, 'vlan' => 1, 'ultimo_ip' => 1, 'ultimo_cnc' => 1,
                 'zona' => 1, 'equipamento' => 1, 'placa_pon' => 1, 'pon' => 1, 'equip_modelo' => 1];

    $filtro = [];
    foreach ($logins as $lg) { $k = ws_conexao_norm((string)$lg); if ($k !== '') $filtro[$k] = 1; }

    foreach ($rows as $r) {
        $chaves = [];
        foreach ([$r['login_pppoe'], $r['login_ipoe'], $r['ont_id']] as $lg) {
            $k = ws_conexao_norm((string)$lg); if ($k !== '') $chaves[$k] = 1;
        }
        if ($filtro && !array_intersect_key($chaves, $filtro)) continue;
        $res['contratos']++;

        $novo = [];

        // ---- FONTE 1: OLT (casa pelo SERIAL da ONU) ------------------------------------
        if ($temOlt) {
            $serial = trim((string)($r['sn_onu'] ?? '')) ?: trim((string)($r['ont_id'] ?? ''));
            $d = $serial !== '' ? mk_olt_dados($serial) : null;
            if ($d) {
                foreach (['zona', 'vlan', 'placa_pon', 'pon', 'rx_sinal', 'tx_sinal', 'rx_olt', 'equipamento', 'equip_modelo'] as $c) {
                    $v = trim((string)($d[$c] ?? ''));
                    /* (16/10/2026) ZONA DA OLT chega com espaço repetido/acento diferente ("TAMATAUPE  1"): grava SEMPRE o nome do CADASTRO (ws_zona), com a mesma chave da unificação.
                       Antes o texto cru da OLT sobrescrevia o do contrato a cada ciclo e a zona "perdia" os clientes (contagem errada, repetida). */
                    if ($c === 'zona' && $v !== '') {
                        static $zonaCanon = null;
                        if ($zonaCanon === null) { $zonaCanon = []; try { require_once __DIR__ . '/zonas_unificar_lib.php'; foreach ($db->query("SELECT nome FROM ws_zona ORDER BY id DESC")->fetchAll(PDO::FETCH_COLUMN) as $zn) $zonaCanon[ws_zb_chave((string)$zn)] = (string)$zn; } catch (Throwable $e) {} }
                        $v = function_exists('ws_zb_chave') ? ($zonaCanon[ws_zb_chave(ws_zona_alias($v))] ?? ws_zb_limpo(ws_zona_alias($v))) : $v;
                    }
                    if ($v !== '') $novo[$c] = $v;
                }
                if ($novo) $res['olt']++;
            }
        }

        // ---- FONTE 2: CONCENTRADOR (casa pelo LOGIN) -----------------------------------
        // Vem DEPOIS da OLT de propósito: para VLAN e IP, quem manda é onde o cliente
        // autenticou agora, não o retrato da OLT.
        foreach (array_keys($chaves) as $k) {
            if (empty($vivos[$k])) continue;
            $s = $vivos[$k];
            if (!empty($s['ip']))   $novo['ultimo_ip']  = (string)$s['ip'];
            if (!empty($s['cnc']))  $novo['ultimo_cnc'] = (string)$s['cnc'];
            if (!empty($s['vlan'])) $novo['vlan']       = (string)$s['vlan'];
            $res['conexao']++;
            break;
        }
        /* (16/10/2026) REGRA DE VLAN: a VLAN do cliente (a que acabou de ser lida ou a do cadastro) define a zona (259 ALTO DA SANTA 1, 260 ALTO DA SANTA 2, 253 TAMATAUPE 1, 254 TAMATAUPE 2, 354 7 SETEMBRO). */
        if (function_exists('ws_vlan_zona') || is_file(__DIR__ . '/zonas_unificar_lib.php')) {
            require_once __DIR__ . '/zonas_unificar_lib.php';
            $zv = ws_vlan_zona($novo['vlan'] ?? ($r['vlan'] ?? 0), (int)($r['id'] ?? 0));
            if ($zv !== null) { $kz = ws_zb_chave($zv); $novo['zona'] = $zonaCanon[$kz] ?? ws_zb_limpo($zv); }
            /* (17/10/2026) contrato em EXCEÇÃO (zona decidida à mão, ex.: CHAN DE PILOTO): a leitura da OLT não troca a zona dele — antes a zona voltava para o texto da OLT a cada ciclo. */
            if (isset($novo['zona']) && function_exists('ws_vlan_excecoes') && in_array((int)($r['id'] ?? 0), ws_vlan_excecoes(), true)) unset($novo['zona']);
        }
        if (!$novo) continue;

        // ---- APLICA AS TRÊS REGRAS ------------------------------------------------------
        $sets = []; $args = [];
        foreach ($novo as $c => $v) {
            $atual = trim((string)($r[$c] ?? ''));
            if ($c === 'vlan') {                     // VLAN é número: compara como número
                if ((int)$v === (int)$atual) continue;
            } elseif ($atual === (string)$v || (in_array($c, ['zona', 'equipamento', 'equip_modelo'], true) && mb_strtoupper($atual, 'UTF-8') === mb_strtoupper((string)$v, 'UTF-8'))) {
                continue;                            // regra 1: igual (zona/modo sem diferenciar maiúscula), descarta
            }
            if ($atual !== '' && empty($medicao[$c])) continue;   // regra 3: cadastro preenchido fica
            $sets[] = "$c = ?"; $args[] = $v;        // regra 2 (vazio) e medição
        }
        if (!$sets) continue;
        if (isset($novo['ultimo_ip'])) $sets[] = 'ultimo_ip_em = NOW()';

        $args[] = (int)$r['id'];
        try {
            $db->prepare("UPDATE ws_contrato SET " . implode(', ', $sets) . " WHERE id = ?")->execute($args);
            $res['atualizados']++;
            $res['campos'] += count($sets);
        } catch (Throwable $e) { /* um contrato com problema não interrompe os outros */ }
    }
    return $res;
}

/**
 * =================================================================================================
 * SESSÃO PRESA — o conserto de verdade.
 * =================================================================================================
 * O QUE É
 * Cada sessão viva é uma linha em radacct com acctstoptime NULL. O concentrador fecha a linha
 * enviando um Accounting-Stop quando o cliente cai. Quando esse pacote NÃO chega — concentrador
 * reiniciado, enlace derrubado, queda de energia, pacote perdido — a linha fica aberta para sempre.
 *
 * POR QUE INCOMODA
 * Duas consequências, e a segunda é a que gera chamado:
 *   1. A contagem de "online" fica inflada: o painel mostra gente conectada que não está.
 *   2. Com Simultaneous-Use ligado, o FreeRADIUS conta as sessões abertas daquele login e RECUSA
 *      o cliente LEGÍTIMO com "já está conectado". O cliente não consegue voltar justamente porque
 *      a sessão anterior nunca foi fechada.
 *
 * O QUE NÃO RESOLVE
 * Separar o banco do RADIUS do banco do sistema. A linha órfã ficaria órfã do mesmo jeito — o
 * problema é um pacote que não chegou, não o lugar onde a tabela mora.
 *
 * O QUE RESOLVE, e são três camadas
 *   1. delete_stale_sessions = yes no módulo sql (já configurado no INSTALAR.sh): ao ver a sessão
 *      NOVA do mesmo login, o FreeRADIUS apaga a velha. Cobre o caso comum, na hora.
 *   2. Esta função, no cron: fecha o que a camada 1 não alcança — a sessão de quem simplesmente
 *      não voltou. Sem ela, a linha fica aberta indefinidamente e o "online" nunca desce.
 *   3. Interim-Update no concentrador: com o concentrador mandando atualização periódica,
 *      acctupdatetime revela em segundos quem parou de responder. É config de equipamento, não de
 *      código — mas é o que torna a camada 2 precisa.
 *
 * COMO ELA DECIDE, e por que é conservadora
 * Fecha apenas a sessão cujo ÚLTIMO SINAL DE VIDA é mais antigo que o limite. Último sinal é
 * acctupdatetime quando existe (o Interim-Update), senão acctstarttime. O limite padrão são 24
 * horas: bem acima de qualquer intervalo de Interim-Update usado na prática, para nunca fechar a
 * sessão de quem está realmente conectado — fechar sessão viva derrubaria a contagem e poderia
 * liberar uma segunda conexão indevida.
 *
 * O fechamento preenche acctstoptime com o último sinal (não com "agora": a sessão terminou lá
 * atrás, e datar no presente inflaria o tempo de conexão do relatório) e marca
 * acctterminatecause = 'Ws-Stale-Timeout', para que essas linhas sejam distinguíveis de um
 * encerramento normal em qualquer auditoria futura.
 *
 * Ajustável em cache/radius.json -> {"horas_sessao_presa": 24}. Zero desliga a limpeza.
 */
function ws_rad_limpar_sessoes_presas(PDO $db): int {
    $horas = 24;
    $arq = WS_CACHE . '/radius.json';
    if (is_file($arq)) {
        $j = json_decode((string)@file_get_contents($arq), true);
        if (is_array($j) && isset($j['horas_sessao_presa'])) $horas = max(0, (int)$j['horas_sessao_presa']);
    }
    if ($horas <= 0) return 0;   // desligado de propósito

    try {
        $st = $db->prepare("UPDATE radacct
                               SET acctstoptime = COALESCE(acctupdatetime, acctstarttime),
                                   acctterminatecause = 'Ws-Stale-Timeout',
                                   acctsessiontime = COALESCE(acctsessiontime,
                                       TIMESTAMPDIFF(SECOND, acctstarttime, COALESCE(acctupdatetime, acctstarttime)))
                             WHERE acctstoptime IS NULL
                               AND acctstarttime IS NOT NULL
                               AND COALESCE(acctupdatetime, acctstarttime) < (NOW() - INTERVAL ? HOUR)");
        $st->execute([$horas]);
        $n = $st->rowCount();
        if ($n > 0) ws_rad_log("sessoes presas fechadas: $n (sem sinal ha mais de {$horas}h)");

        /* SESSÃO QUE PAROU DE DAR SINAL — sem esperar 24 h.
         * Quando o concentrador manda Interim-Update, a sessão viva tem acctupdatetime renovado a
         * cada poucos minutos (acctupdatetime > acctstarttime prova que ele manda). Se a atualização
         * parou há mais de 30 min, a sessão morreu sem Stop: fica fechada agora, e o cliente não é
         * recusado ao voltar. Sessão que nunca recebeu atualização (concentrador sem Interim) continua
         * só na regra das 24 h acima — assim nunca se fecha conexão viva.
         * Ajustável em cache/radius.json -> {"minutos_sem_atualizacao": 30}. Zero desliga. */
        $min = 30;
        if (is_file($arq)) {
            $j = json_decode((string)@file_get_contents($arq), true);
            if (is_array($j) && isset($j['minutos_sem_atualizacao'])) $min = max(0, (int)$j['minutos_sem_atualizacao']);
        }
        if ($min > 0) {
            $st2 = $db->prepare("UPDATE radacct
                                     SET acctstoptime = acctupdatetime,
                                         acctterminatecause = 'Ws-Sem-Atualizacao',
                                         acctsessiontime = COALESCE(acctsessiontime, GREATEST(0, TIMESTAMPDIFF(SECOND, acctstarttime, acctupdatetime)))
                                   WHERE acctstoptime IS NULL
                                     AND acctupdatetime IS NOT NULL AND acctstarttime IS NOT NULL
                                     AND acctupdatetime > acctstarttime
                                     AND acctupdatetime < (NOW() - INTERVAL ? MINUTE)");
            $st2->execute([max(10, $min)]);
            $n2 = $st2->rowCount();
            if ($n2 > 0) ws_rad_log("sessoes sem atualizacao fechadas: $n2 (sem Interim-Update ha mais de {$min} min)");
            $n += $n2;
        }
        $n += ws_rad_fechar_presa_mesmo_mac($db);
        return $n;
    } catch (Throwable $e) {
        ws_rad_log('ERRO ao limpar sessoes presas: ' . $e->getMessage());
        return 0;
    }
}

/**
 * MESMO EQUIPAMENTO, SESSÃO ANTIGA PRESA — fecha a velha e deixa a nova em paz.
 *
 * O cliente cai (energia, reboot do roteador, oscilação) e o concentrador não manda o
 * Accounting-Stop: a linha antiga fica aberta. Quando o MESMO equipamento volta, passa a haver
 * DUAS linhas abertas do mesmo login com o MESMO MAC — e é isso que faz o "1 conexão por cliente"
 * recusar o cliente legítimo ("já está conectado") ou inflar o painel de online.
 *
 * Mesmo login + mesmo MAC não é segunda conexão: é a mesma, reconectando. Aqui a ANTIGA é fechada
 * (hora de término no último sinal de vida, causa 'Ws-Mesmo-MAC') e a MAIS NOVA fica intacta.
 * Sessão de MAC diferente não é tocada: o limite de uma conexão por cliente continua valendo.
 *
 * No FreeRADIUS do próprio WellSystem isso já é evitado na autenticação (ws-radius-sessao-mac.sh,
 * que fecha a presa antes da contagem). Esta função é a rede de segurança para todo o resto:
 * RADIUS de outro ERP, MK-Auth, configuração antiga ou pacote que ainda não chegou ao servidor.
 *
 * @return int quantas linhas antigas foram fechadas
 */
function ws_rad_fechar_presa_mesmo_mac(PDO $db): int {
    try {
        /* Em dois passos de propósito: primeiro descobre QUAIS linhas fechar, depois fecha por id.
         * UPDATE lendo a própria radacct numa subconsulta é recusado/instável dependendo da versão
         * do MySQL/MariaDB — e esta rotina roda a cada 2 minutos, em produção. */
        $sel = $db->query("SELECT a.radacctid
                             FROM radacct a
                             JOIN (SELECT username, callingstationid, MAX(acctstarttime) ultima
                                     FROM radacct
                                    WHERE acctstoptime IS NULL
                                      AND callingstationid IS NOT NULL AND callingstationid <> ''
                                    GROUP BY username, callingstationid
                                   HAVING COUNT(*) > 1) d
                               ON d.username = a.username AND d.callingstationid = a.callingstationid
                            WHERE a.acctstoptime IS NULL
                              AND a.acctstarttime < d.ultima
                            LIMIT 500");
        $ids = array_map('intval', $sel->fetchAll(PDO::FETCH_COLUMN));
        if (!$ids) return 0;
        $in = implode(',', $ids);
        $db->exec("UPDATE radacct
                      SET acctstoptime = COALESCE(acctupdatetime, acctstarttime),
                          acctterminatecause = 'Ws-Mesmo-MAC',
                          acctsessiontime = COALESCE(acctsessiontime,
                              GREATEST(0, TIMESTAMPDIFF(SECOND, acctstarttime, COALESCE(acctupdatetime, acctstarttime))))
                    WHERE radacctid IN ($in) AND acctstoptime IS NULL");
        $n = count($ids);
        ws_rad_log("sessoes presas do mesmo equipamento (MAC) fechadas: $n — a conexao nova do cliente fica");
        return $n;
    } catch (Throwable $e) {
        ws_rad_log('ERRO ao fechar sessao presa do mesmo MAC: ' . $e->getMessage());
        return 0;
    }
}

/**
 * =================================================================================================
 * TROCAR O PLANO SEM DERRUBAR O CLIENTE — CoA de atualização.
 * =================================================================================================
 * O grupo RADIUS de um plano é `plano_{id}` — o CÓDIGO do plano, nunca o nome. É o que permite
 * renomear um plano, ou mudar a velocidade dele, sem que nenhum cliente perca o vínculo. (Com o
 * nome no meio, renomear "100 Mega" para "100 Mega Fibra" deixaria todo mundo apontando para um
 * grupo que não existe mais — o cliente sem velocidade, sem erro em lugar nenhum.)
 *
 * Mas o vínculo em banco só vale no PRÓXIMO login. Quem já está conectado continua com a velocidade
 * antiga até reconectar — e "reconectar" significa derrubar o cliente.
 *
 * Esta função resolve isso: manda um CoA-Request (não um Disconnect) com o novo Mikrotik-Rate-Limit
 * para a sessão em curso. O concentrador aplica a velocidade nova na hora, sem quebrar a sessão: o
 * cliente não perde a conexão, não reconecta, e o download em andamento não cai.
 *
 * DIFERENÇA ENTRE OS DOIS PACOTES, porque confundir custa caro:
 *   Disconnect-Request -> encerra a sessão. O cliente cai e reconecta.
 *   CoA-Request        -> altera atributos da sessão viva. O cliente não sente nada.
 *
 * Quando o concentrador não entende CoA (ou o segredo está errado), a função devolve false e quem
 * chamou decide: pode cair para o disconnect, que aplica do mesmo jeito, com a queda como preço.
 */
function ws_rad_coa_plano(PDO $db, string $login, int $upKbps, int $downKbps): bool {
    $login = trim($login);
    if ($login === '' || $upKbps <= 0 || $downKbps <= 0) return false;

    // Sessão viva daquele login — sem sessão, não há o que atualizar (o banco já basta).
    $st = $db->prepare("SELECT acctsessionid, nasipaddress, framedipaddress, callingstationid
                        FROM radacct WHERE username=? AND acctstoptime IS NULL
                        ORDER BY acctstarttime DESC LIMIT 1");
    $st->execute([$login]);
    $s = $st->fetch();
    if (!$s || empty($s['nasipaddress'])) return false;

    $n = $db->prepare("SELECT secret FROM nas WHERE nasname=? LIMIT 1");
    $n->execute([$s['nasipaddress']]);
    $nas = $n->fetch();
    if (!$nas) return false;
    $secret = (string)$nas['secret'];

    $porta = 3799;
    try {
        $p = $db->prepare("SELECT coa_port FROM ws_concentrador WHERE host=? LIMIT 1");
        $p->execute([$s['nasipaddress']]);
        $porta = (int)($p->fetchColumn() ?: 3799);
    } catch (Throwable $e) { $porta = 3799; }

    /* Identifica a sessão e manda o atributo NOVO. Os identificadores são os mesmos do disconnect —
     * o concentrador precisa saber QUAL sessão alterar, e User-Name sozinho não basta num parque
     * onde o mesmo login pode ter tido sessões em nós diferentes. */
    $attrs  = "User-Name=$login,Acct-Session-Id={$s['acctsessionid']}";
    if (!empty($s['framedipaddress']))  $attrs .= ",Framed-IP-Address={$s['framedipaddress']}";
    if (!empty($s['callingstationid'])) $attrs .= ",Calling-Station-Id={$s['callingstationid']}";
    $attrs .= ',Mikrotik-Rate-Limit=' . ws_rad_rate_limit($upKbps, $downKbps);

    $bin = trim((string)@shell_exec('command -v radclient 2>/dev/null'));
    if ($bin === '') { ws_rad_log("radclient ausente — sem CoA de plano ($login)"); return false; }

    $cmd = sprintf('printf %s | %s -x %s:%d coa %s 2>&1',
        escapeshellarg($attrs), escapeshellcmd($bin),
        escapeshellarg($s['nasipaddress']), $porta, escapeshellarg($secret));
    $out = (string)@shell_exec($cmd);
    ws_rad_log("coa plano $login @ {$s['nasipaddress']}:$porta => " . trim($out));
    return stripos($out, 'CoA-ACK') !== false;
}

/**
 * Reflete um plano no RADIUS **e** aplica a velocidade nova em quem está conectado agora.
 *
 * Chame ao salvar um plano. Sem a segunda metade, mudar a velocidade de um plano só teria efeito no
 * próximo login de cada cliente — o que, na prática, é "só depois que derrubar todo mundo".
 *
 * @return int quantas sessões vivas receberam a velocidade nova.
 */
function ws_rad_aplicar_plano_ao_vivo(PDO $db, array $plano): int {
    $grp = ws_rad_grupo_plano((int)$plano['id']);
    $up   = (int)$plano['up_kbps'];
    $down = (int)$plano['down_kbps'];
    if ($up <= 0 || $down <= 0) return 0;

    $n = 0;
    try {
        // Quem está no grupo desse plano E com sessão aberta. Cliente offline não precisa de CoA:
        // ele já vai entrar com a velocidade nova no próximo login.
        $q = $db->prepare("SELECT DISTINCT a.username FROM radacct a
                           JOIN radusergroup g ON g.username = a.username
                           WHERE g.groupname = ? AND a.acctstoptime IS NULL");
        $q->execute([$grp]);
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $login) {
            if (ws_rad_coa_plano($db, (string)$login, $up, $down)) $n++;
        }
    } catch (Throwable $e) { ws_rad_log('ERRO CoA em massa do plano: ' . $e->getMessage()); }
    return $n;
}

/* =====================================================================================================================
 * ROBÔ: REINÍCIO DA ONU E "ROTA PRESA" (01/10/2026)
 * ws_olt_robo_key()        → chave secreta do robô para a OLT (gerada sozinha, 0600, dona www-data). Só vale para
 *                            chamadas do PRÓPRIO servidor e só para localizar/reiniciar/ressincronizar (olt_auth.php).
 * ws_onu_robo($sn, $tipo)  → localiza a ONU pelo SN e executa 'reboot' (ont reset) ou 'resync' (deactivate+activate).
 * ws_conexao_faixa_corte() → prefixos /24 em que estão hoje os clientes BLOQUEADOS conectados = faixa de corte real do
 *                            concentrador (aprendida sozinha, sem configurar nada). Contrato ATIVO com IP nessa faixa,
 *                            ou com sessão iniciada antes da liberação, está com a ROTA PRESA → derrubar a sessão resolve.
 * ================================================================================================================== */
function ws_olt_robo_key(): string {
    $kf = WS_CACHE . '/olt_robo_key.txt';
    $k = trim((string)@file_get_contents($kf));
    if (strlen($k) >= 32) return $k;
    $k = bin2hex(random_bytes(24));
    if (@file_put_contents($kf, $k) === false) return '';
    @chmod($kf, 0600);
    if (function_exists('posix_geteuid') && posix_geteuid() === 0) { @chown($kf, 'www-data'); @chgrp($kf, 'www-data'); }
    return $k;
}

function ws_onu_robo(string $sn, string $tipo = 'reboot'): array {
    if (!in_array($tipo, ['reboot', 'resync', 'localizar'], true)) return ['ok' => false, 'msg' => 'ação não permitida'];
    $sn = preg_replace('/[^0-9A-Za-z]/', '', $sn);
    if ($sn === '') return ['ok' => false, 'msg' => 'contrato sem SN da ONU'];
    if (!is_file(dirname(__FILE__) . '/olt_huawei.php')) return ['ok' => false, 'msg' => 'módulo OLT ausente'];
    $key = ws_olt_robo_key();
    if ($key === '') return ['ok' => false, 'msg' => 'sem chave do robô'];
    $http = function (string $qs, int $tempo) {
        foreach (['http://127.0.0.1/olt_huawei.php', 'http://127.0.0.1/wellsystem/olt_huawei.php'] as $u) {
            $ch = curl_init($u . '?' . $qs);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $tempo, CURLOPT_CONNECTTIMEOUT => 3]);
            $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($c === 404) continue;
            $j = json_decode((string)$r, true);
            return is_array($j) ? $j : ['status' => 'error', 'message' => 'OLT não respondeu (HTTP ' . $c . ')'];
        }
        return ['status' => 'error', 'message' => 'módulo OLT não encontrado no servidor'];
    };
    $loc = $http(http_build_query(['acao' => 'onu_localizar', 'sn' => $sn, 'robo_key' => $key]), 15);
    if (($loc['status'] ?? '') !== 'ok' || ($loc['fsp'] ?? '') === '') return ['ok' => false, 'msg' => (string)($loc['message'] ?? 'ONU não localizada')];
    $base = ['ok' => true, 'fsp' => (string)$loc['fsp'], 'id' => (string)$loc['id'], 'estado' => (string)($loc['estado'] ?? '')];
    if ($tipo === 'localizar') return $base;
    $r = $http(http_build_query(['acao' => 'onu_acao', 'tipo' => $tipo, 'fsp' => $loc['fsp'], 'id' => $loc['id'], 'robo_key' => $key]), 60);
    $ok = ($r['status'] ?? '') === 'ok' && !empty($r['sucesso']);
    $msg = $ok ? ($tipo === 'reboot' ? 'ONU reiniciada' : 'ONU ressincronizada') : (string)($r['message'] ?? 'a OLT recusou o comando');
    /* 21/10/2026: "HTTP 0" no passo do COMANDO = a OLT achou a ONU mas passou de 60 s sem responder (fila do Telnet). O comando pode ter sido aplicado:
       não é "falha" — quem lê o histórico não deve repetir às cegas. */
    if (!$ok && strpos($msg, '(HTTP 0)') !== false) $msg = 'a OLT demorou mais de 60 s para responder — o comando pode ter sido aplicado; confira a ONU antes de repetir';
    return $base + ['feito' => $ok, 'msg' => $msg];
}

function ws_conexao_faixa_corte(PDO $db, array $vivos): array {
    $fx = [];
    try {
        $rs = $db->query("SELECT login_pppoe, login_ipoe FROM ws_contrato WHERE status='bloqueado'")->fetchAll(PDO::FETCH_NUM);
        foreach ($rs as $l) foreach ($l as $lg) {
            $v = $vivos[ws_conexao_norm((string)$lg)] ?? null;
            if (is_array($v) && preg_match('/^(\d+\.\d+\.\d+)\.\d+$/', (string)($v['ip'] ?? ''), $m)) $fx[$m[1]] = ($fx[$m[1]] ?? 0) + 1;
        }
    } catch (Throwable $e) {}
    // Faixa de corte = /24 com 2+ bloqueados E onde quase todos (80%+) os conectados são bloqueados. Assim um bloqueado
    // que ainda segura IP da faixa normal (a própria rota presa ao contrário) não transforma a faixa normal em "corte".
    $tot = [];
    foreach ($vivos as $v) if (is_array($v) && preg_match('/^(\d+\.\d+\.\d+)\.\d+$/', (string)($v['ip'] ?? ''), $m)) $tot[$m[1]] = ($tot[$m[1]] ?? 0) + 1;
    $out = [];
    foreach ($fx as $p => $n) if ($n >= 2 && $n >= 0.8 * ($tot[$p] ?? $n)) $out[] = $p;
    return $out;
}

/** Dispara ws_onu_robo() em segundo plano (robo_onu_run.php) — o robô responde na hora; o resultado vai ao histórico. */
function ws_onu_robo_bg(string $sn, string $tipo, int $clienteId, string $login): bool {
    $sn = preg_replace('/[^0-9A-Za-z]/', '', $sn);
    if ($sn === '' || !in_array($tipo, ['reboot', 'resync'], true) || !function_exists('exec')) return false;
    $php = is_file(PHP_BINDIR . '/php') ? PHP_BINDIR . '/php' : 'php';
    @exec('nohup ' . escapeshellarg($php) . ' ' . escapeshellarg(__DIR__ . '/robo_onu_run.php') . ' ' . escapeshellarg($sn) . ' ' . $tipo . ' '
        . $clienteId . ' ' . escapeshellarg($login) . ' > /dev/null 2>&1 &', $o, $rc);
    return $rc === 0;
}

/** PONs em QUEDA TOTAL agora, segundo o detector da OLT (olt_pon_estado.json: {"0/1/4":"los"|"energia"}). */
function ws_olt_pon_quedas(): array {
    foreach ([WS_DIR . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'] as $d) {
        $f = $d . '/olt_pon_estado.json';
        if (is_file($f) && filemtime($f) > time() - 86400 * 3) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) return $j; }
    }
    return [];
}

/**
 * BLOQUEIO EFETIVO (01/10/2026): contrato BLOQUEADO que segue navegando com endereço NORMAL (sessão aberta antes do
 * bloqueio e que nunca caiu — achados 23 casos com sessão de 10 dias) é derrubado: reconecta já na faixa de corte.
 *   Faixa de corte conhecida (ws_conexao_faixa_corte) → derruba quem está FORA dela.
 *   Faixa ainda desconhecida (instalação nova, ninguém no corte) → derruba 1 vez a cada 24 h por contrato.
 * Respeita confiança vigente, no máximo $max por passada, intervalo de 15 min por contrato (não fica derrubando em
 * laço se o concentrador não aplicar a pool). Cada derrubada vai ao Monitor do robô/Central e ao histórico do cliente.
 * Devolve quantos derrubou.
 */
function ws_rad_bloqueio_efetivar(PDO $db, int $max = 30): int {
    if (!function_exists('ws_conexao_viva')) return 0;
    try { $vivos = ws_conexao_viva(0, true); } catch (Throwable $e) { return 0; }
    if (!$vivos) return 0;
    $faixa = ws_conexao_faixa_corte($db, $vivos);
    $arq = WS_CACHE . '/bloqueio_efetivar.json';
    $mem = json_decode((string)@file_get_contents($arq), true) ?: [];
    $n = 0;
    foreach ($db->query("SELECT * FROM ws_contrato WHERE status='bloqueado'")->fetchAll(PDO::FETCH_ASSOC) as $ct) {
        if ($n >= $max) break;
        if (ws_rad_em_confianca($ct)) continue;
        $v = null; foreach ([$ct['login_pppoe'], $ct['login_ipoe']] as $l) { $v = $vivos[ws_conexao_norm((string)$l)] ?? null; if ($v) break; }
        if (!is_array($v) || !preg_match('/^(\d+\.\d+\.\d+)\.\d+$/', (string)($v['ip'] ?? ''), $m)) continue;
        if ($faixa && in_array($m[1], $faixa, true)) continue;                  // já está no corte
        $ult = (int)($mem[$ct['id']] ?? 0);
        if (time() - $ult < ($faixa ? 900 : 86400)) continue;
        $mem[$ct['id']] = time(); $n++;
        ws_rad_derrubar_contrato($db, $ct);
        if (function_exists('ws_evento')) ws_evento($db, (int)$ct['cliente_id'], 'bloqueio', 'Bloqueio efetivado: contrato ' . $ct['id'] . ' bloqueado ainda navegava (IP ' . $v['ip'] . ') — sessão derrubada para entrar no corte.');
    }
    /* DESBLOQUEIO EFETIVO (o inverso): contrato ATIVO (pagou / liberado / em confiança) que segue preso na faixa de corte
       é derrubado e volta com endereço normal. Só com a faixa de corte conhecida. */
    if ($faixa) foreach ($db->query("SELECT * FROM ws_contrato WHERE status='ativo'")->fetchAll(PDO::FETCH_ASSOC) as $ct) {
        if ($n >= $max) break;
        $v = null; foreach ([$ct['login_pppoe'], $ct['login_ipoe']] as $l) { $v = $vivos[ws_conexao_norm((string)$l)] ?? null; if ($v) break; }
        if (!is_array($v) || !preg_match('/^(\d+\.\d+\.\d+)\.\d+$/', (string)($v['ip'] ?? ''), $m) || !in_array($m[1], $faixa, true)) continue;
        if (function_exists('ws_rad_deve_bloquear') && ws_rad_deve_bloquear($db, $ct)) continue;   // status desatualizado: não libera por aqui
        $k = 'a' . $ct['id']; if (time() - (int)($mem[$k] ?? 0) < 900) continue;
        $mem[$k] = time(); $n++;
        ws_rad_derrubar_contrato($db, $ct);
        if (function_exists('ws_evento')) ws_evento($db, (int)$ct['cliente_id'], 'desbloqueio', 'Desbloqueio efetivado: contrato ' . $ct['id'] . ' liberado ainda estava na faixa de corte (IP ' . $v['ip'] . ') — sessão derrubada para voltar com endereço normal.');
    }
    foreach ($mem as $k => $t) if ($t < time() - 172800) unset($mem[$k]);
    @file_put_contents($arq, json_encode($mem)); @chmod($arq, 0640);
    return $n;
}

/**
 * REABRE no radacct a sessão que foi dada como encerrada mas CONTINUA VIVA: o concentrador seguiu mandando atualização
 * (acctupdatetime) depois do "fim" registrado. Só a sessão mais recente de cada login, e só fechamentos sem motivo ou
 * feitos pelo próprio WellSystem (Ws-*) — o "fim" verdadeiro do concentrador (User-Request, Lost-Carrier…) não é tocado.
 * É o que faz a ficha mostrar "em uso" e a derrubada (bloqueio/desbloqueio) enxergar a sessão. Devolve quantas reabriu.
 */
function ws_radacct_reabrir_vivas(PDO $db): int {
    try {
        return (int)$db->exec("UPDATE radacct r
            JOIN (SELECT username, MAX(radacctid) mx FROM radacct GROUP BY username) u ON u.mx = r.radacctid
            SET r.acctstoptime = NULL, r.acctterminatecause = ''
            WHERE r.acctstoptime IS NOT NULL
              AND r.acctupdatetime > r.acctstoptime + INTERVAL 60 SECOND
              AND r.acctupdatetime > NOW() - INTERVAL 15 MINUTE
              AND (r.acctterminatecause = '' OR r.acctterminatecause IS NULL OR r.acctterminatecause LIKE 'Ws-%')");
    } catch (Throwable $e) { return 0; }
}
