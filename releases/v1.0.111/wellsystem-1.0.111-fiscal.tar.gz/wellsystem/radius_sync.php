<?php
/**
 * WellSystem Radius — sincronização automática (cron / CLI).
 *
 * Reflete planos e contratos no FreeRADIUS e bloqueia inadimplentes.
 * Rode a cada 2–5 min. Também expira faturas vencidas (aberto → vencido).
 *
 * CLI:   php radius_sync.php
 * HTTP:  radius_sync.php?token=SEGREDO   (defina o token em cache/wellsystem_db.json → "cron_token")
 */
require __DIR__ . '/config.php'; require_once __DIR__ . '/espelho_lib.php';
if (ws_espelho_somente_leitura() && !ws_espelho_em_quarentena()) {   // 12/11/2026: o RESERVA (Wellsystem-02) só roda o backup do Fiscal (lê a réplica, grava arquivo e envia); o resto da rotina é do principal
    if (is_file(__DIR__ . '/fiscal_backup_lib.php')) { require_once __DIR__ . '/fiscal_backup_lib.php'; try { ws_fbk_auto_check(ws_db()); } catch (Throwable $e) {} }
    exit(0);
}
ws_espelho_so_principal();   // ESPELHO (05/11/2026): rotina autom�tica - s� o servidor PRINCIPAL roda (a r�plica e a quarentena saem calados)
require __DIR__ . '/radius_lib.php';
/* (06/11/2026) UMA PASSADA POR VEZ: o cron roda a cada 2 min e uma passada lenta empilhava dezenas de processos disputando o banco
   (chegaram a 25 ao mesmo tempo). Passada em andamento = esta sai calada; a próxima tenta de novo. Se a trava não abrir, segue sem ela. */
$wsLk = @fopen(WS_CACHE . '/radius_sync.lock', 'c');
if ($wsLk && !@flock($wsLk, LOCK_EX | LOCK_NB)) exit(0);

$cli = (php_sapi_name() === 'cli');
if (!$cli) {
    $cfg = ws_db_config();
    $tok = $cfg['cron_token'] ?? '';
    if ($tok === '' || ($_GET['token'] ?? '') !== $tok) { http_response_code(403); exit('forbidden'); }
    header('Content-Type: application/json; charset=utf-8');
}

try {
    $db = ws_db();

    // 1) Marca faturas vencidas
    $venc = $db->exec("UPDATE ws_fatura SET status='vencido'
                       WHERE status='aberto' AND vencimento < CURDATE()");
    // (16/10/2026) vencimento prorrogado para o futuro: 'vencido' volta a 'aberto' (o status acompanha a data)
    $db->exec("UPDATE ws_fatura SET status='aberto' WHERE status='vencido' AND vencimento >= CURDATE()");

    // 2) Sincroniza RADIUS (inclui bloqueio de inadimplentes + rate-limit por plano)
    $r = ws_rad_sync_tudo($db);

    /* 2c) RETRATO DAS SESSÕES — lê todos os concentradores ao vivo, fecha no radacct quem já caiu
     * sem avisar, e grava cache/sessoes_online.json. É o que os cards "Online" (Painel) e "Total
     * Conectado" (Concentradores) passam a ler, em vez de cada um contar do seu próprio jeito. */
    if (function_exists('ws_sessoes_sincronizar')) {
        try { $r['sessoes'] = ws_sessoes_sincronizar(); } catch (Throwable $e) { $r['sessoes_erro'] = $e->getMessage(); }
    }

    /* 2c-bis) ADICIONAL HERDA A CIDADE DO TITULAR — completa cidade/UF/ramal em branco dos adicionais
     * (importados ou cadastrados antes desta regra). Só preenche o que está vazio; ver
     * ws_adicionais_herdar_cidade() no radius_lib.php. */
    if (function_exists('ws_adicionais_herdar_cidade')) {
        try { $ac = ws_adicionais_herdar_cidade($db); if ($ac > 0) $r['adicionais_cidade'] = $ac; } catch (Throwable $e) { $r['adicionais_cidade_erro'] = $e->getMessage(); }
    }

    /* 2d) CADASTRO SEGUE A OLT — zona, modo Bridge/Router, placa/PON, modelo e sinais em todos os
     * contratos, a cada passada (2 min). Lê só os caches (OLT, coletor de sinal e SmartOLT), nunca a
     * OLT por Telnet; grava só o que mudou. Antes isso só rodava pela tela de Manutenção. */
    if (is_file(__DIR__ . '/olt_link.php') && function_exists('ws_contrato_sincronizar_olt')) {
        try { $oc = ws_contrato_sincronizar_olt($db); if (!empty($oc['atualizados'])) $r['cadastro_olt'] = $oc; } catch (Throwable $e) {}
    }
    /* (16/10/2026) SERIAL e MAC dos equipamentos: MAC da sessão no RADIUS -> contrato, e uma linha por unidade em Cadastros > Equipamentos. A cada ~10 min. */
    if (is_file(__DIR__ . '/equipamentos_sync_lib.php')) {
        try { require_once __DIR__ . '/equipamentos_sync_lib.php'; $ef = WS_CACHE . '/equip_sync_ts'; if (!is_file($ef) || time() - (int)@filemtime($ef) > 600) { @touch($ef); $eq = ws_equip_sincronizar($db); if ($eq['macs'] + $eq['unidades_novas'] + $eq['unidades_atualizadas'] > 0) $r['equipamentos'] = $eq; } } catch (Throwable $e) {}
    }
    $r['faturas_vencidas'] = (int)$venc;

    /* 1b) INTERNET DO SERVIDOR — verificada AQUI, no cron, e nunca na página.
     *
     * A barra de status do topo mostra ONLINE / SEM INTERNET lendo o resultado de um arquivo.
     * Testar rede durante o carregamento de uma tela é a receita da página que passa a demorar
     * segundos quando o enlace cai — e é exatamente na queda que o operador mais precisa que o
     * sistema responda, porque é quando o telefone começa a tocar.
     *
     * O cron roda de 2 em 2 minutos, então o indicador tem no máximo 2 minutos de atraso, e o
     * título dele na tela mostra o horário da verificação para ninguém confundir com tempo real. */
    if (function_exists('ws_internet_verificar')) { try { ws_internet_verificar(); } catch (Throwable $e) {} }

    /* 2a) ENDEREÇOS: normaliza em LOTES o que ainda está só em texto.
     *
     * Aqui e não no carregamento de página: é um resolve por cliente, e com 1.600 clientes isso é
     * tempo que o operador sentiria na tela. Em lotes de 300 a cada rodada (o cron roda de 2 em 2
     * minutos), uma base desse tamanho converge em poucos minutos, sem ninguém esperando nada.
     *
     * A consulta que alimenta a migração filtra por `logradouro_id IS NULL`, então quando tudo
     * estiver vinculado ela não faz mais nada — custa uma consulta vazia por rodada. */
    if (is_file(__DIR__ . '/schema_endereco.php')) {
        require_once __DIR__ . '/schema_endereco.php';
        try {
            $end = ws_end_migrar($db, 300);
            if (($end['clientes'] + $end['contratos']) > 0) $r['enderecos'] = $end;
        } catch (Throwable $e) {}
    }

    /* 2b) SESSÕES PRESAS — fecha antes de contar o "online".
     * A ordem importa: contar primeiro e limpar depois deixaria o gráfico com o número inflado por
     * sessões que já foram encerradas nesta mesma execução. Ver ws_rad_limpar_sessoes_presas(). */
    $r['sessoes_presas'] = ws_rad_limpar_sessoes_presas($db);

    /* 2c) NOME IPoE NO MK-AUTH — addon ao lado do MK-Auth: o FreeRADIUS de lá manda nome_res ao
     * concentrador. Preenche o nome_res vazio com o nome resumido do cadastro (nunca troca um
     * nome que já exista). Sem MK-Auth ao lado, ws_mk_db() devolve null e nada acontece. */
    if (is_file(__DIR__ . '/mkauth_bridge.php')) {
        require_once __DIR__ . '/mkauth_bridge.php';
        try { if (ws_mk_presente()) $r['nome_res_mkauth'] = ws_mk_sincronizar_nome_res($db); } catch (Throwable $e) {}
    }

    // 3) Snapshot de online p/ o gráfico do painel (mantém ~7 dias)
    $online = (int)$db->query("SELECT COUNT(*) FROM radacct WHERE acctstoptime IS NULL")->fetchColumn();
    $db->prepare("INSERT INTO ws_online_hist (online) VALUES (?)")->execute([$online]);
    $db->exec("DELETE FROM ws_online_hist WHERE ts < (NOW() - INTERVAL 7 DAY)");
    $r['online'] = $online;
    $r['quando'] = date('c');

    // 4) Backup diário agendado (envia por e-mail no horário marcado) — best-effort.
    if (is_file(__DIR__ . '/backup_lib.php')) { require_once __DIR__ . '/backup_lib.php'; try { ws_backup_auto_check($db); } catch (Throwable $e) {} }
    if (is_file(__DIR__ . '/fiscal_backup_lib.php')) { require_once __DIR__ . '/fiscal_backup_lib.php'; try { ws_fbk_auto_check($db); } catch (Throwable $e) {} }   // 12/11/2026: backup do Fiscal (horário próprio, pasta própria)
    // 5) Mensagens automáticas de cobrança (lembretes de vencimento) — 1x/dia por fatura.
    if (is_file(__DIR__ . '/mensagens_lib.php')) { require_once __DIR__ . '/mensagens_lib.php';
        $autoCfg = is_file(WS_CACHE.'/msg_auto.json') ? (json_decode((string)@file_get_contents(WS_CACHE.'/msg_auto.json'),true) ?: []) : [];
        $autoMsg = $autoCfg['ativo'] ?? 1; $horarioAgendado = $autoCfg['horario'] ?? '08:00';
        $marcaFile = WS_CACHE . '/msg_auto_ultima.txt'; $hoje = date('Y-m-d');
        $jaRodouHoje = is_file($marcaFile) && trim((string)@file_get_contents($marcaFile)) === $hoje;
        $horaAtual = date('H:i');
        if ($autoMsg && !$jaRodouHoje && $horaAtual >= $horarioAgendado) {
            try { ws_msg_cobranca_run($db); @file_put_contents($marcaFile, $hoje); } catch (Throwable $e) {}
        }
        /* 5b) AVISO DE BLOQUEIO / DESBLOQUEIO — por mudança de situação do contrato, a cada passada
         * (não 1x por dia): quem foi bloqueado agora recebe o aviso hoje, e quem pagou recebe o
         * "ONLINE" assim que a conexão volta. A própria função respeita a janela de horário, o
         * Automático, o gateway e a proibição de enviar para cliente desativado/cancelado. */
        try { $ev = ws_msg_eventos_estado_run($db); if (($ev['novos'] ?? 0) || ($ev['enviados'] ?? 0) || ($ev['fila'] ?? 0)) $r['avisos_bloqueio'] = $ev; } catch (Throwable $e) {}
        // BOAS-VINDAS (03/10/2026): instalação concluída → mensagem quando o cliente conectar (ou já validada).
        if (function_exists('ws_msg_boas_vindas_run')) { try { $bv = ws_msg_boas_vindas_run($db); if (($bv['enviados'] ?? 0) || ($bv['fila'] ?? 0)) $r['boas_vindas'] = $bv; } catch (Throwable $e) {} }
        }
    /* 5b1) RECIBOS QUE CHEGAM FORA DO ROBÔ (10/10/2026): todo comprovante enviado ao atendente humano tem de ir para Financeiro → Comprovantes PIX (é de lá que o
     * atendente pede a confirmação a quem tem acesso ao banco). Antes a fila só andava quando OUTRA mensagem chegava; agora este cron (2 em 2 min) dispara o
     * registro em segundo plano sempre que há mídia esperando. */
    if (is_file(__DIR__ . '/comprovantes_lib.php') && is_file(__DIR__ . '/comprovantes_orfas_run.php')) {
        try { require_once __DIR__ . '/comprovantes_lib.php';
            if (ws_comp_pendentes_prontos()) { $phpBin = is_executable('/usr/bin/php') ? '/usr/bin/php' : 'php'; @exec('nohup ' . $phpBin . ' ' . escapeshellarg(__DIR__ . '/comprovantes_orfas_run.php') . ' >/dev/null 2>&1 &'); $r['comprovantes_orfas'] = 'disparado'; }
        } catch (Throwable $e) {}
    }
    /* 5b1b) CONCLUSÃO POR INATIVIDADE (10/10/2026): conversa do robô parada há ROBO_SESSAO_MIN min no pedido de PIX/2ª via/atendimento → o sistema faz o que foi pedido e encerra. */
    if (is_file(__DIR__ . '/api_chatbot.php')) { try { require_once __DIR__ . '/api_chatbot.php'; if (function_exists('ws_sessoes_idle_run')) { $ns = ws_sessoes_idle_run($db); if ($ns) $r['robo_concluido'] = $ns; } } catch (Throwable $e) {} }
    /* 5b2) EQUIPAMENTO/COMODATO AUTOMÁTICO (03/10/2026): contrato com ONU/ONT sem tipo definido → Bridge/Router pelo cadastro da OLT, comodato Sim. */
    if (function_exists('ws_equip_auto')) { try { $ne = ws_equip_auto($db); if ($ne) $r['equip_auto'] = $ne; } catch (Throwable $e) {} }
    /* 5c) RESUMO DE PAGAMENTOS DO DIA — automático, 1x por dia a partir do horário da tela Recibos →
     * Configuração ("Enviar o resumo do dia automaticamente"). Antes só existia o botão manual. */
    if (is_file(__DIR__ . '/whatsapp.php')) { require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_resumo_auto_run')) { try { $rs = ws_resumo_auto_run($db); if (!empty($rs['rodou'])) $r['resumo_auto'] = $rs; } catch (Throwable $e) {} }
    }
    /* 5d) CERTIFICADO HTTPS AUTOMÁTICO — a cada 10 min confere se os domínios da tela Manutenção → Domínio &
     * HTTPS já apontam para cá e se o certificado cobre todos; faltando algum com o DNS certo, emite sozinho. */
    if (is_file(__DIR__ . '/certificado_lib.php')) { require_once __DIR__ . '/certificado_lib.php';
        try { $ce = ws_cert_auto_run(); if (!empty($ce['rodou'])) $r['certificado'] = $ce; } catch (Throwable $e) {}
    }

    // 6) Zipar Logs antigos (mais de 30 dias)
    try {
        $logDir = __DIR__ . '/backups/logs';
        if (!is_dir($logDir)) { @mkdir($logDir, 0777, true); @chmod($logDir, 0777); }
        // Pegar logs do mês retrasado (deixando os 30 dias mais recentes intactos ou algo assim)
        // O pedido foi "a cada 30 dias realizar um zipar de todos os Log limpado a relação"
        // Vamos arquivar logs mais antigos que 30 dias:
        $st = $db->query("SELECT e.*, c.nome cliente, u.nome usuario FROM ws_evento e LEFT JOIN ws_cliente c ON c.id=e.cliente_id LEFT JOIN ws_usuario u ON u.id=e.usuario_id WHERE e.criado_em < (CURDATE() - INTERVAL 30 DAY) ORDER BY e.id ASC");
        $oldLogs = $st->fetchAll(PDO::FETCH_ASSOC);
        if (count($oldLogs) > 0) {
            $primeiro = substr($oldLogs[0]['criado_em'] ?? date('Y-m-d'), 0, 10);
            $ultimo = substr(end($oldLogs)['criado_em'] ?? date('Y-m-d'), 0, 10);
            $fileName = "logs_{$primeiro}_a_{$ultimo}.csv";
            $zipName = "logs_{$primeiro}_a_{$ultimo}_gerado_" . date('Ymd_Hi') . ".zip";
            
            $csv = "ID;Tipo;Texto;Data;Cliente;Usuário\n";
            $idsToDelete = [];
            foreach ($oldLogs as $lg) {
                $csv .= $lg['id'] . ";" . $lg['tipo'] . ";" . str_replace(";", ",", $lg['texto']) . ";" . $lg['criado_em'] . ";" . str_replace(";", ",", $lg['cliente'] ?? '') . ";" . str_replace(";", ",", $lg['usuario'] ?? '') . "\n";
                $idsToDelete[] = $lg['id'];
            }
            
            $zip = new ZipArchive();
            if ($zip->open("$logDir/$zipName", ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
                $zip->addFromString($fileName, $csv);
                $zip->close();
                
                // Limpar do banco
                if (count($idsToDelete) > 0) {
                    $ph = implode(',', array_fill(0, count($idsToDelete), '?'));
                    $db->prepare("DELETE FROM ws_evento WHERE id IN ($ph)")->execute($idsToDelete);
                }
            }
        }
    } catch (Throwable $e) {}

    /* SELO ANTIFRAUDE: comprovantes com arquivo que ainda não foram lidos (chegaram antes do OCR, ou o arquivo veio
       depois). Poucos por ciclo — OCR leva alguns segundos por imagem. */
    try {
        if (is_file(__DIR__ . '/comprovantes_lib.php')) { require_once __DIR__ . '/comprovantes_lib.php'; if (function_exists('ws_comp_selo_pendentes')) ws_comp_selo_pendentes($db, 3); }
    } catch (Throwable $e) {}

    /* LYTEX (lytex.php): a cada ~2 min (todo ciclo deste cron) confere as faturas em aberto emitidas na Lytex — dá baixa nas
       pagas (se o webhook se perdeu) e completa PIX/linha digitável que chegaram depois. Só roda com a
       Lytex configurada; sem ela, nada acontece. */
    try {
        $lxMarca = WS_CACHE . '/lytex_sync.ts';
        if (is_file(__DIR__ . '/lytex.php') && (!is_file($lxMarca) || filemtime($lxMarca) < time() - 110)) {
            require_once __DIR__ . '/lytex.php';
            if (ws_lytex_pronto()) { @touch($lxMarca); $r['lytex'] = ws_lytex_sincronizar($db); }
        }
    } catch (Throwable $e) {}

    /* BLOQUEIO EFETIVO: bloqueado que ainda navega com endereço normal é derrubado (entra no corte). Ver ws_rad_bloqueio_efetivar(). */
    try { if (function_exists('ws_rad_bloqueio_efetivar')) $r['bloqueio_efetivado'] = ws_rad_bloqueio_efetivar($db); } catch (Throwable $e) {}

    /* PESQUISA DE SATISFAÇÃO pós-atendimento (satisfacao_lib.php): chamados finalizados recebem o link das estrelas. */
    try { if (is_file(__DIR__ . '/satisfacao_lib.php')) { require_once __DIR__ . '/satisfacao_lib.php'; $r['pesquisas'] = ws_satisf_enviar($db); } } catch (Throwable $e) {}

    /* ACESSOS INVÁLIDOS (14/10): tentativas recusadas de cliente entram na tela Acessos inválidos e no Log do sistema. */
    try { $r['recusas'] = ws_rad_recusas_coletar($db); } catch (Throwable $e) {}

    @touch(WS_CACHE . '/radius_sync.ts');   // marca de "rodou" para a Saúde do sistema (saude_lib.php)
    ws_rad_log('sync_tudo => ' . json_encode($r, JSON_UNESCAPED_UNICODE));
    echo $cli ? ("OK " . json_encode($r, JSON_UNESCAPED_UNICODE) . "\n") : json_encode(['ok' => true] + $r);
} catch (Throwable $e) {
    ws_rad_log('ERRO sync: ' . $e->getMessage());
    if (!$cli) http_response_code(500);
    echo $cli ? ('ERRO: ' . $e->getMessage() . "\n") : json_encode(['ok' => false, 'erro' => $e->getMessage()]);
}
