<?php
/**
 * DIAGNÓSTICO TEMPORÁRIO — sem isto, um erro fatal aqui vira só uma tela branca "HTTP ERROR 500"
 * (o Apache engole a mensagem real do PHP). Com isto, se acontecer de novo, a PRÓPRIA página
 * mostra o erro exato (arquivo/linha) em vez de branco — só pra quem já passou pelo gate de root
 * logo abaixo, então não vaza nada pra quem não devia ver. Pode remover depois que o item 3
 * estiver realmente resolvido; não afeta o funcionamento normal da tela.
 */
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        http_response_code(500);
        echo '<pre style="white-space:pre-wrap;font:13px monospace;padding:20px;color:#900;background:#fff">'
           . 'Erro fatal em rede_servidor.php — copie este texto pro suporte:' . "\n\n"
           . htmlspecialchars($e['message'] . "\nem " . $e['file'] . ':' . $e['line']) . '</pre>';
    }
});
/**
 * =================================================================================================
 * WellSystem — REDE DO SERVIDOR (configuração de IP / máscara / gateway / DNS)
 * =================================================================================================
 * Tela para responder "qual é a rede deste servidor?" sem precisar abrir SSH, e para CONFIGURAR
 * essa rede quando o servidor ainda não tem uma definida (instalação nova) ou precisa trocar
 * (mudança de provedor de internet, de faixa de IP, de gateway).
 *
 * Existe porque o WellSystem, na instalação recomendada (INSTALL.md), roda DIRETO no sistema
 * operacional do servidor — não em container — então a rede que aparece aqui é a rede de
 * verdade da máquina, a mesma que o FreeRADIUS e o Apache escutam.
 *
 * MÉTODO DE REDE: detectado automaticamente, porque Debian/Ubuntu mudaram isso com o tempo:
 *     netplan ............. Ubuntu 18.04+  (arquivos .yaml em /etc/netplan)
 *     interfaces .......... Debian clássico (/etc/network/interfaces, ifupdown)
 *     nmcli ............... quando o NetworkManager está no comando da interface
 * Sem nenhum dos três, a tela só EXIBE o que existe — não tenta escrever configuração que não
 * sabe aplicar.
 *
 * SEGURANÇA DE QUEM MEXE NA PRÓPRIA REDE: trocar IP/gateway erra fácil e tranca o acesso ao
 * próprio servidor (inclusive o acesso a ESTA tela). Por isso APLICAR NÃO É O FIM DO PROCESSO:
 *
 *   1. Antes de aplicar, a config atual é copiada para uma pasta de backups com data/hora.
 *   2. A configuração é aplicada — inevitável, porque não há como testar de verdade sem aplicar —
 *      e fica PENDENTE, não concluída.
 *   3. A interface assenta (4s) e roda o TESTE DE CONEXÃO: ping no gateway, ping em 8.8.8.8 e
 *      resolução de nome no(s) DNS informado(s). Ver wsrede_testar_conexao().
 *   4. Passou → selo verde com o que foi testado e o botão "OK, concluir a troca de rede". É esse
 *      clique, e só ele, que cancela a reversão: quem sabe se a tela continua acessível de onde o
 *      operador está é o operador, não o ping.
 *      Falhou → alerta apontando o item exato, com "Reverter agora" (desfaz na hora) ou "Manter
 *      mesmo assim" (para rede interna sem saída para a internet, por exemplo).
 *   5. Por baixo dos dois casos, um temporizador em segundo plano DESFAZ a mudança sozinho se
 *      ninguém confirmar em 3 minutos — a camada que cobre justamente o caso em que nenhum botão
 *      pode ser clicado, porque a página ficou inacessível pelo endereço novo.
 *   6. Restrita ao administrador (nível root) — é configuração de infraestrutura, não de rotina.
 *
 * O fluxo completo está no README, seção "Rede do servidor".
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$h    = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$root = function_exists('ws_eh_root') ? ws_eh_root() : (($_SESSION['ws_user']['nivel'] ?? '') === 'admin');

if (!$root) {
    http_response_code(403);
    ?><!doctype html><html lang="pt-br"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Rede do servidor</title>
    <link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
    <header class="ws-top-wrap"><?= ws_topo_completo('rede') ?></header>
    <main class="ws-main">
      <div class="ws-card"><h2>🌐 Rede do servidor</h2>
      <p class="ws-muted">Esta tela mexe na configuração de rede da máquina (IP, máscara,
      gateway) e é restrita ao administrador principal.</p>
      <a class="ws-btn" href="erp.php?p=dashboard">Voltar ao painel</a></div>
    </main></body></html><?php
    exit;
}

/* =================================================================================================
 * EXECUÇÃO DE COMANDOS NO SISTEMA — mesmo padrão do terminal.php (proc_open, com fallback para
 * shell_exec e mensagem clara quando o PHP deste servidor tem essas funções desabilitadas).
 * ============================================================================================== */
function wsrede_disponivel(): bool { return function_exists('proc_open') || function_exists('shell_exec'); }
function wsrede_sh(string $cmd): string {
    if (function_exists('proc_open')) {
        $p = @proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (is_resource($p)) {
            $out = stream_get_contents($pipes[1]); fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
            return $out;
        }
    }
    if (function_exists('shell_exec')) return (string)@shell_exec($cmd . ' 2>&1');
    return '';
}
function wsrede_cmd_existe(string $bin): bool {
    $r = wsrede_sh('command -v ' . escapeshellarg($bin) . ' 2>/dev/null');
    return trim($r) !== '';
}

/* =================================================================================================
 * LEITURA DO ESTADO ATUAL — interfaces, IP/CIDR, MAC, status, gateway padrão e DNS.
 * Só LÊ (ip, cat) — nada aqui escreve no sistema.
 * ============================================================================================== */
function wsrede_mask_to_cidr(string $mask): int {
    $partes = array_map('intval', explode('.', $mask));
    if (count($partes) !== 4) return 24;
    $bin = ''; foreach ($partes as $p) $bin .= str_pad(decbin(max(0, min(255, $p))), 8, '0', STR_PAD_LEFT);
    return substr_count($bin, '1');
}
function wsrede_cidr_to_mask(int $cidr): string {
    $cidr = max(0, min(32, $cidr));
    $bin = str_repeat('1', $cidr) . str_repeat('0', 32 - $cidr);
    $partes = str_split($bin, 8);
    return implode('.', array_map(fn($b) => bindec($b), $partes));
}

function wsrede_interfaces(): array {
    $out = [];
    if (!wsrede_disponivel()) return $out;
    // "ip -o addr show" — uma linha por endereço, já sem precisar parsear bloco.
    $linhas = explode("\n", trim(wsrede_sh('ip -o addr show')));
    $macs   = [];
    foreach (explode("\n", trim(wsrede_sh('ip -o link show'))) as $l) {
        if (preg_match('/^\d+:\s+([^:@]+).*link\/\w+\s+([0-9a-f:]{17})/i', $l, $m)) $macs[$m[1]] = $m[2];
        if (preg_match('/^\d+:\s+([^:@]+).*state\s+(\S+)/i', $l, $m2)) $out[$m2[1]]['estado'] = $m2[2];
    }
    foreach ($linhas as $l) {
        // ex.: "2: eth0    inet 192.168.1.10/24 brd ... scope global eth0"
        if (!preg_match('/^\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $l, $m)) continue;
        $ifn = $m[1];
        if ($ifn === 'lo') continue;
        $out[$ifn]['ip']   = $m[2];
        $out[$ifn]['cidr'] = (int)$m[3];
        $out[$ifn]['mask'] = wsrede_cidr_to_mask((int)$m[3]);
        $out[$ifn]['mac']  = $macs[$ifn] ?? '';
        $out[$ifn]['nome'] = $ifn;
    }
    // Interfaces que existem mas não têm IPv4 (cabo desconectado, ou nunca configurada) — ainda
    // aparecem na tela, só que como "sem configuração", para dar a opção de configurar.
    foreach (explode("\n", trim(wsrede_sh('ip -o link show'))) as $l) {
        if (!preg_match('/^\d+:\s+([^:@]+):/', $l, $m)) continue;
        $ifn = trim($m[1]);
        if ($ifn === 'lo' || isset($out[$ifn]['ip'])) continue;
        $out[$ifn]['nome']  = $ifn;
        $out[$ifn]['mac']   = $macs[$ifn] ?? '';
        $out[$ifn]['ip']    = '';
        $out[$ifn]['mask']  = '';
        $out[$ifn]['cidr']  = null;
    }
    ksort($out);
    return $out;
}
function wsrede_gateway_padrao(): string {
    $r = wsrede_sh('ip route show default');
    return preg_match('/default via (\d+\.\d+\.\d+\.\d+)/', $r, $m) ? $m[1] : '';
}
function wsrede_dns(): array {
    $dns = [];
    $conteudo = @file_get_contents('/etc/resolv.conf');
    if ($conteudo) foreach (explode("\n", $conteudo) as $l) {
        if (preg_match('/^\s*nameserver\s+(\S+)/', $l, $m)) $dns[] = $m[1];
    }
    return $dns;
}
function wsrede_metodo(): string {
    if (is_dir('/etc/netplan') && glob('/etc/netplan/*.yaml')) return 'netplan';
    if (wsrede_cmd_existe('nmcli') && trim(wsrede_sh('nmcli -t -f RUNNING general 2>/dev/null')) === 'running') return 'nmcli';
    if (is_file('/etc/network/interfaces')) return 'interfaces';
    if (is_dir('/etc/netplan')) return 'netplan'; // netplan instalado, mas ainda sem .yaml nenhum
    return 'desconhecido';
}

/* =================================================================================================
 * BACKUP — cada aplicação guarda a config anterior, com data/hora, antes de sobrescrever.
 * ============================================================================================== */
define('WS_REDE_BACKUPS', WS_CACHE . '/rede_backups');
define('WS_REDE_PENDENTE', WS_CACHE . '/rede_pendente.json');
function wsrede_backup_agora(string $metodo): ?string {
    if (!is_dir(WS_REDE_BACKUPS)) @mkdir(WS_REDE_BACKUPS, 0750, true);
    $carimbo = date('Ymd-His');
    $origem  = $metodo === 'interfaces' ? '/etc/network/interfaces' : null;
    $destino = WS_REDE_BACKUPS . "/backup-$carimbo";
    if ($metodo === 'netplan') {
        @mkdir($destino, 0750, true);
        foreach (glob('/etc/netplan/*.yaml') ?: [] as $f) @copy($f, $destino . '/' . basename($f));
        return $destino;
    }
    if ($metodo === 'interfaces' && is_file($origem)) {
        @copy($origem, $destino . '.interfaces');
        return $destino . '.interfaces';
    }
    return null; // nmcli guarda a conexão anterior no próprio NetworkManager — não precisa arquivo
}

/* =================================================================================================
 * ESCRITA + APLICAÇÃO — uma função por método. Cada uma devolve [ok(bool), msg(string)].
 * ============================================================================================== */
function wsrede_aplicar_netplan(string $ifn, string $ip, int $cidr, string $gw, array $dns): array {
    $arq = '/etc/netplan/99-wellsystem.yaml';
    $dnsYaml = $dns ? ("      nameservers:\n        addresses: [" . implode(', ', $dns) . "]\n") : '';
    $rotaYaml = $gw ? ("      routes:\n        - to: default\n          via: $gw\n") : '';
    $yaml = "network:\n  version: 2\n  ethernets:\n    $ifn:\n      dhcp4: no\n"
          . "      addresses: [$ip/$cidr]\n" . $rotaYaml . $dnsYaml;
    if (@file_put_contents($arq, $yaml) === false) return [false, "Não consegui gravar $arq (permissão do PHP no servidor)."];
    @chmod($arq, 0600);
    $teste = wsrede_sh('netplan try --timeout 1 2>&1'); // "try" já teria auto-revert do próprio netplan, mas nem toda versão tem
    $saida = wsrede_sh('netplan apply 2>&1');
    return [true, trim($saida) !== '' ? $saida : 'Aplicado com netplan.'];
}
function wsrede_aplicar_interfaces(string $ifn, string $ip, string $mask, string $gw, array $dns): array {
    $arq = '/etc/network/interfaces';
    $atual = @file_get_contents($arq) ?: '';
    // Remove um bloco anterior dessa MESMA interface (entre "iface $ifn" e a próxima linha "auto/iface"), se existir.
    $atual = preg_replace('/auto\s+' . preg_quote($ifn, '/') . '\s*\niface\s+' . preg_quote($ifn, '/') . '\s+inet[^\n]*\n(?:^\s+.+\n)*/m', '', $atual);
    $dnsLinha = $dns ? ('    dns-nameservers ' . implode(' ', $dns) . "\n") : '';
    $bloco = "\nauto $ifn\niface $ifn inet static\n    address $ip\n    netmask $mask\n"
           . ($gw ? "    gateway $gw\n" : '') . $dnsLinha;
    if (@file_put_contents($arq, rtrim($atual) . "\n" . $bloco) === false) return [false, "Não consegui gravar $arq (permissão do PHP no servidor)."];
    $saida = wsrede_sh('(ifdown ' . escapeshellarg($ifn) . '; ifup ' . escapeshellarg($ifn) . ') 2>&1 '
                      . '|| systemctl restart networking 2>&1');
    return [true, trim($saida) !== '' ? $saida : "Aplicado em $ifn (ifupdown)."];
}
function wsrede_aplicar_nmcli(string $ifn, string $ip, int $cidr, string $gw, array $dns): array {
    $con = trim(wsrede_sh('nmcli -t -f NAME,DEVICE con show | grep ":' . escapeshellcmd($ifn) . '$" | head -1 | cut -d: -f1'));
    if ($con === '') $con = $ifn;
    $dnsStr = $dns ? implode(' ', $dns) : '';
    $cmd = 'nmcli con mod ' . escapeshellarg($con)
         . ' ipv4.addresses ' . escapeshellarg("$ip/$cidr")
         . ' ipv4.gateway ' . escapeshellarg($gw)
         . ' ipv4.dns ' . escapeshellarg($dnsStr)
         . ' ipv4.method manual 2>&1 && nmcli con up ' . escapeshellarg($con) . ' 2>&1';
    $saida = wsrede_sh($cmd);
    return [true, trim($saida) !== '' ? $saida : "Aplicado em $con (NetworkManager)."];
}

/* =================================================================================================
 * REDE DE SEGURANÇA — desfaz sozinho se ninguém confirmar em 3 minutos. Melhor esforço: usa
 * "at" quando existe; senão um processo em segundo plano com sleep. Se nenhum dos dois estiver
 * disponível, a tela avisa e segue sem a rede de segurança (aplica mesmo assim).
 * ============================================================================================== */
function wsrede_agendar_revert(string $backupPath, string $metodo, string $ifn): array {
    $flag = WS_CACHE . '/rede_confirmar.flag';
    @unlink($flag);
    $script = WS_CACHE . '/rede_revert.sh';
    $restauraCmd = $metodo === 'netplan'
        ? "rm -f /etc/netplan/99-wellsystem.yaml; cp -f " . escapeshellarg($backupPath) . "/*.yaml /etc/netplan/ 2>/dev/null; netplan apply"
        : ($metodo === 'interfaces'
            ? "cp -f " . escapeshellarg($backupPath) . " /etc/network/interfaces; (ifdown " . escapeshellarg($ifn) . "; ifup " . escapeshellarg($ifn) . ") || systemctl restart networking"
            : "true # nmcli: sem arquivo de reversão automática");
    $conteudo = "#!/bin/sh\nsleep 180\nif [ -f " . escapeshellarg($flag) . " ]; then rm -f " . escapeshellarg($flag) . "; exit 0; fi\n$restauraCmd\n";
    @file_put_contents($script, $conteudo); @chmod($script, 0700);
    /* O MESMO comando de restauração, porém SEM a espera — é o que o botão "Reverter agora" roda
     * quando o teste de conexão falha. Gravado aqui, junto do agendado, para que os dois desfaçam
     * exatamente a mesma coisa: se um dia a forma de restaurar mudar, muda para os dois de uma vez. */
    @file_put_contents(WS_CACHE . '/rede_revert_agora.sh', "#!/bin/sh\n$restauraCmd\n");
    @chmod(WS_CACHE . '/rede_revert_agora.sh', 0700);
    if (wsrede_cmd_existe('nohup')) {
        wsrede_sh("nohup sh " . escapeshellarg($script) . " > " . escapeshellarg(WS_CACHE . '/rede_revert.log') . " 2>&1 & disown 2>/dev/null");
        return [true, 'Se ninguém confirmar em 3 minutos, a rede anterior volta sozinha.'];
    }
    return [false, 'Não achei como agendar a reversão automática ("nohup" indisponível) — confirme o acesso manualmente após aplicar.'];
}

/* =================================================================================================
 * TESTE DE CONEXÃO — o que decide se a configuração aplicada realmente FUNCIONA.
 *
 * POR QUE ISTO EXISTE: aplicar a configuração sempre "dá certo" do ponto de vista do comando —
 * o netplan aceita, o ifup sobe a interface, o nmcli responde OK. Nada disso prova que o servidor
 * fala com o gateway, que chega na internet ou que resolve nome. Quem descobria isso era o
 * operador, minutos depois, quando alguma coisa parava de funcionar.
 *
 * As três perguntas, na ordem em que uma explica a outra:
 *   1. o gateway responde?  -> se não, IP/máscara/gateway não fecham entre si
 *   2. a internet responde? -> se o gateway responde e isto não, o problema está além do servidor
 *   3. o DNS resolve?       -> se os dois acima passam e isto falha, é só o servidor de nomes
 *
 * O executor de comandos entra por parâmetro para esta função poder ser testada sem mexer na rede
 * da máquina: em produção é o wsrede_sh(); no teste, uma função que devolve saídas conhecidas.
 *
 * @return array lista de ['nome'=>, 'ok'=>bool, 'detalhe'=>]
 * ============================================================================================== */
/** Um ping "passou"? Considera o resumo do ping, que é igual em Debian/Ubuntu. */
function wsrede_ping_ok(string $saida): bool {
    if (trim($saida) === '') return false;                      // sem saída = comando não rodou
    if (preg_match('/(\d+)\s*(?:packets\s+)?received/i', $saida, $m)) return (int)$m[1] > 0;
    if (preg_match('/100%\s*packet loss/i', $saida)) return false;
    return (bool)preg_match('/bytes from/i', $saida);
}
/** Uma resolução de nome "passou"? Aceita as saídas de dig, nslookup e getent. */
function wsrede_dns_ok(string $saida): bool {
    $s = trim($saida);
    if ($s === '') return false;
    if (preg_match('/NXDOMAIN|SERVFAIL|connection timed out|no servers could be reached/i', $s)) return false;
    // dig +short devolve o IP puro; nslookup/getent trazem "Address:"/o IP no começo da linha.
    return (bool)preg_match('/\b\d{1,3}(\.\d{1,3}){3}\b/', $s);
}

function wsrede_testar_conexao(string $gw, array $dns, ?callable $exec = null): array {
    $sh = $exec ?: 'wsrede_sh';
    $itens = [];

    // 1) Gateway — só faz sentido testar se o operador informou um.
    if ($gw !== '') {
        $saida = (string)$sh('ping -c 2 -W 2 ' . escapeshellarg($gw) . ' 2>&1');
        $itens[] = ['nome' => 'Gateway (' . $gw . ')', 'ok' => wsrede_ping_ok($saida),
                    'detalhe' => wsrede_ping_ok($saida) ? 'responde' : 'não respondeu ao ping'];
    }

    // 2) Saída para a internet — IP fixo de propósito: se o DNS estiver errado, este teste ainda
    //    diz a verdade sobre o caminho até a internet.
    $saida = (string)$sh('ping -c 2 -W 2 8.8.8.8 2>&1');
    $itens[] = ['nome' => 'Internet (8.8.8.8)', 'ok' => wsrede_ping_ok($saida),
                'detalhe' => wsrede_ping_ok($saida) ? 'responde' : 'sem resposta'];

    // 3) DNS — pergunta a CADA servidor informado; sem nenhum, usa o resolvedor do sistema.
    $alvo = 'google.com';
    if ($dns) {
        foreach ($dns as $srv) {
            $saida = (string)$sh('dig +short +time=2 +tries=1 @' . escapeshellarg($srv) . ' ' . escapeshellarg($alvo) . ' 2>&1');
            if (trim($saida) === '') {   // servidor sem o dig instalado: tenta o nslookup
                $saida = (string)$sh('nslookup ' . escapeshellarg($alvo) . ' ' . escapeshellarg($srv) . ' 2>&1');
            }
            $ok = wsrede_dns_ok($saida);
            $itens[] = ['nome' => 'DNS ' . $srv, 'ok' => $ok,
                        'detalhe' => $ok ? 'resolveu ' . $alvo : 'não resolveu ' . $alvo];
        }
    } else {
        $saida = (string)$sh('getent hosts ' . escapeshellarg($alvo) . ' 2>&1');
        $ok = wsrede_dns_ok($saida);
        $itens[] = ['nome' => 'DNS do sistema', 'ok' => $ok,
                    'detalhe' => $ok ? 'resolveu ' . $alvo : 'não resolveu ' . $alvo];
    }
    return $itens;
}
/** Todos os itens do teste passaram? */
function wsrede_teste_passou(array $itens): bool {
    foreach ($itens as $i) if (empty($i['ok'])) return false;
    return $itens !== [];
}

/* =================================================================================================
 * AÇÕES (POST)
 * ============================================================================================== */
$demo = function_exists('ws_em_demo') && ws_em_demo();
$msg = null; $erro = null;

if (!$demo && ($_POST['acao'] ?? '') === 'aplicar' && wsrede_disponivel()) {
    $ifn  = preg_replace('/[^a-zA-Z0-9_.@-]/', '', (string)($_POST['interface'] ?? ''));
    $ip   = trim((string)($_POST['ip'] ?? ''));
    $mask = trim((string)($_POST['mascara'] ?? ''));
    $gw   = trim((string)($_POST['gateway'] ?? ''));
    $dns  = array_values(array_filter([trim((string)($_POST['dns1'] ?? '')), trim((string)($_POST['dns2'] ?? ''))]));
    $filtroIp = fn($v) => (bool)filter_var($v, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);

    if ($ifn === '') $erro = 'Escolha uma interface de rede.';
    elseif (!$filtroIp($ip)) $erro = 'IP inválido.';
    elseif (!$filtroIp($mask)) $erro = 'Máscara inválida.';
    elseif ($gw !== '' && !$filtroIp($gw)) $erro = 'Gateway inválido.';
    elseif ($dns && !array_reduce($dns, fn($ok, $d) => $ok && $filtroIp($d), true)) $erro = 'DNS inválido.';

    if (!$erro) {
        $metodo = wsrede_metodo();
        $cidr   = wsrede_mask_to_cidr($mask);
        $backup = wsrede_backup_agora($metodo);
        /* IMPORTANTE — "match" é sintaxe do PHP 8.0+. Este arquivo, como todo o resto do
           sistema, precisa continuar funcionando em servidores com PHP 7.4 (comum em painéis
           MK-Auth — é por isso que config.php tem os polyfills de str_contains/str_starts_with/
           str_ends_with logo no topo). Um "match" aqui é ERRO FATAL DE SINTAXE (parse error) em
           7.4: o arquivo INTEIRO deixa de compilar e a página para de abrir — tela branca/HTTP
           ERROR 500 para QUALQUER acesso a rede_servidor.php, inclusive o simples GET que só
           mostra a tela (não precisa nem clicar em "Aplicar"). Era exatamente este o motivo do
           menu Rede → Rede do servidor não abrir. Trocado por if/elseif, compatível com 7.4+. */
        if ($metodo === 'netplan') {
            [$ok, $saida] = wsrede_aplicar_netplan($ifn, $ip, $cidr, $gw, $dns);
        } elseif ($metodo === 'interfaces') {
            [$ok, $saida] = wsrede_aplicar_interfaces($ifn, $ip, $mask, $gw, $dns);
        } elseif ($metodo === 'nmcli') {
            [$ok, $saida] = wsrede_aplicar_nmcli($ifn, $ip, $cidr, $gw, $dns);
        } else {
            [$ok, $saida] = [false, 'Não identifiquei o gerenciador de rede deste servidor (nem netplan, nem /etc/network/interfaces, nem NetworkManager). Nada foi alterado — configure manualmente pelo terminal.'];
        }
        if ($ok) {
            $revert = ($backup && $metodo !== 'nmcli') ? wsrede_agendar_revert($backup, $metodo, $ifn) : [false, ''];
            /* A INTERFACE PRECISA ASSENTAR ANTES DO TESTE.
             * Logo depois do netplan/ifup, a placa ainda está subindo: o gateway pode não
             * responder por um instante e o teste acusaria uma falha que não existe. Quatro
             * segundos é o bastante na prática e é uma espera que o operador aceita numa ação
             * que ele mesmo acabou de disparar — ele está olhando para a tela esperando resposta. */
            sleep(4);
            $teste = wsrede_testar_conexao($gw, $dns);
            /* Fica PENDENTE mesmo quando o teste passa. A configuração já está no ar (não há como
             * testar de verdade sem aplicar), mas a troca só vira definitiva quando o operador
             * confirma — é ele, e não o ping, quem sabe se a tela continua acessível de onde ele
             * está. Até lá a reversão automática segue armada. */
            @file_put_contents(WS_REDE_PENDENTE, json_encode([
                'em' => date('c'), 'interface' => $ifn, 'metodo' => $metodo, 'revert_agendado' => $revert[0],
                'teste' => $teste, 'teste_ok' => wsrede_teste_passou($teste),
                'gateway' => $gw, 'dns' => $dns,
            ]));
            $msg = "Configuração aplicada em $ifn. " . $saida . ($revert[0] ? ' ' . $revert[1] : ($backup ? ' ' . ($revert[1] ?: '') : ''));
        } else {
            $erro = $saida;
        }
    }
}
if (!$demo && ($_POST['acao'] ?? '') === 'confirmar') {
    @file_put_contents(WS_CACHE . '/rede_confirmar.flag', '1');
    @unlink(WS_REDE_PENDENTE);
    header('Location: rede_servidor.php?confirmado=1'); exit;
}
/* REVERTER AGORA — desfaz na hora, sem esperar os 3 minutos.
 * Existe porque, quando o teste falha, esperar é o pior dos mundos: o operador já SABE que não
 * funcionou e fica com o servidor fora do ar até o temporizador disparar. A flag é criada antes
 * de restaurar para o agendamento não restaurar de novo em cima do que já foi restaurado. */
if (!$demo && ($_POST['acao'] ?? '') === 'reverter') {
    $script = WS_CACHE . '/rede_revert_agora.sh';
    @file_put_contents(WS_CACHE . '/rede_confirmar.flag', '1');   // cancela o agendado
    if (is_file($script) && wsrede_disponivel()) {
        wsrede_sh('sh ' . escapeshellarg($script) . ' > ' . escapeshellarg(WS_CACHE . '/rede_revert.log') . ' 2>&1');
        @unlink(WS_REDE_PENDENTE);
        header('Location: rede_servidor.php?revertido=1'); exit;
    }
    @unlink(WS_REDE_PENDENTE);
    header('Location: rede_servidor.php?revertido=0'); exit;
}

$pendente = is_file(WS_REDE_PENDENTE) ? json_decode((string)@file_get_contents(WS_REDE_PENDENTE), true) : null;
$interfaces = wsrede_interfaces();
$gwAtual    = wsrede_gateway_padrao();
$dnsAtual   = wsrede_dns();
$metodo     = wsrede_metodo();
$metodoTxt  = ['netplan' => 'netplan (Ubuntu)', 'interfaces' => '/etc/network/interfaces (Debian/ifupdown)',
               'nmcli' => 'NetworkManager', 'desconhecido' => 'não identificado'][$metodo];
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Rede do servidor</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('rede') ?></header>
<main class="ws-main" style="max-width:900px">
<div class="ws-head-row"><h2>🌐 Rede do servidor</h2></div>
<p class="ws-muted" style="font-size:12.5px">Mostra e configura a rede da própria máquina onde o
WellSystem roda (IP, máscara, gateway, DNS) — não é a rede dos clientes/concentradores, que fica
em <a href="radius.php?p=nas">Rede → NAS</a>. Gerenciador de rede detectado:
<b><?= $h($metodoTxt) ?></b>.</p>

<?php if (!wsrede_disponivel()): ?>
  <div class="ws-alert err">Este servidor tem <code>proc_open</code> e <code>shell_exec</code>
  desabilitados no PHP — a tela não consegue ler nem alterar a rede daqui. Configure pelo terminal
  do servidor (<code>ip addr</code>, <code>netplan</code> ou <code>/etc/network/interfaces</code>).</div>
<?php endif; ?>
<?php if ($demo): ?><div class="ws-alert err">Modo demonstração: alterações de rede estão desativadas aqui.</div><?php endif; ?>
<?php if ($msg): ?><div class="ws-alert ok"><?= $h($msg) ?></div><?php endif; ?>
<?php if ($erro): ?><div class="ws-alert err"><?= $h($erro) ?></div><?php endif; ?>
<?php if (isset($_GET['confirmado'])): ?><div class="ws-alert ok">Confirmado — a reversão automática foi cancelada, a configuração atual fica valendo.</div><?php endif; ?>
<?php if (isset($_GET['revertido'])): ?>
  <div class="ws-alert <?= $_GET['revertido'] === '1' ? 'ok' : 'err' ?>">
    <?= $_GET['revertido'] === '1'
        ? 'Revertido — a configuração anterior foi restaurada agora.'
        : 'Não encontrei o arquivo de reversão deste servidor. Se a rede estiver fora, aguarde: a reversão automática ainda dispara em até 3 minutos da aplicação.' ?>
  </div>
<?php endif; ?>

<?php if ($pendente && !isset($_GET['confirmado'])): ?>
  <?php
  /* O QUE A TELA MOSTRA DEPOIS DE APLICAR.
   * A configuração já está no ar (não dá para testar sem aplicar), mas a troca ainda NÃO está
   * concluída: o resultado do teste automático decide qual das duas caixas aparece, e só o
   * clique do operador encerra o assunto. A reversão dos 3 minutos continua armada por baixo
   * das duas — ela é a rede de segurança para o caso de esta página ficar inacessível. */
  $teste   = isset($pendente['teste']) && is_array($pendente['teste']) ? $pendente['teste'] : [];
  $testeOk = !empty($pendente['teste_ok']);
  $falhas  = array_values(array_filter($teste, fn($i) => empty($i['ok'])));
  ?>
  <?php if ($teste && $testeOk): ?>
    <div class="ws-alert ok">
      <b>✅ Configuração aceita — teste de conexão OK</b>
      <div class="ws-muted" style="font-size:12.5px;margin:4px 0 8px">
        Aplicada em <b><?= $h($pendente['interface']) ?></b> · <?= $h($pendente['em']) ?>. Testado agora:
      </div>
      <ul class="ws-rede-teste">
        <?php foreach ($teste as $i): ?>
          <li><span class="ok">✅</span> <?= $h($i['nome']) ?> — <?= $h($i['detalhe']) ?></li>
        <?php endforeach; ?>
      </ul>
      <p class="ws-muted" style="font-size:12.5px;margin:8px 0">
        A troca <b>ainda não está concluída</b>: até você confirmar, a rede anterior volta sozinha
        em até 3 minutos. Confirme se esta página continua acessível para você.
      </p>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="confirmar">
        <button class="ws-btn verde">✔ OK, concluir a troca de rede</button></form>
    </div>
  <?php elseif ($teste): ?>
    <div class="ws-alert err">
      <b>⚠️ A configuração foi aplicada, mas o teste de conexão falhou</b>
      <div class="ws-muted" style="font-size:12.5px;margin:4px 0 8px">
        Aplicada em <b><?= $h($pendente['interface']) ?></b> · <?= $h($pendente['em']) ?>. O que foi testado:
      </div>
      <ul class="ws-rede-teste">
        <?php foreach ($teste as $i): ?>
          <li><span class="<?= !empty($i['ok']) ? 'ok' : 'falhou' ?>"><?= !empty($i['ok']) ? '✅' : '❌' ?></span>
              <?= $h($i['nome']) ?> — <?= $h($i['detalhe']) ?></li>
        <?php endforeach; ?>
      </ul>
      <p class="ws-muted" style="font-size:12.5px;margin:8px 0">
        <?php if (count($falhas) === count($teste)): ?>
          Nada respondeu: confira IP, máscara e gateway — os três precisam pertencer à mesma rede.
        <?php elseif (!empty($falhas[0]['nome']) && strpos($falhas[0]['nome'], 'DNS') === 0): ?>
          Gateway e internet respondem: o problema está apenas no servidor de DNS informado.
        <?php else: ?>
          Veja acima o ponto exato que falhou. Se o teste não se aplica aqui (rede interna sem
          saída para a internet, por exemplo), você pode manter mesmo assim.
        <?php endif; ?>
      </p>
      <form method="post" style="display:inline;margin-right:6px"><input type="hidden" name="acao" value="reverter">
        <button class="ws-btn danger" onclick="return confirm('Desfazer agora e voltar a configuração de rede anterior?')">↩️ Reverter agora</button></form>
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="confirmar">
        <button class="ws-btn" onclick="return confirm('Manter esta configuração mesmo com o teste falhando?')">Manter mesmo assim</button></form>
    </div>
  <?php else: ?>
    <?php /* Aplicação anterior a este fluxo (ou teste que não pôde rodar): mantém o aviso antigo,
             que continua correto — a reversão automática é a mesma. */ ?>
    <div class="ws-alert err">
      Mudança aplicada em <b><?= $h($pendente['interface']) ?></b> em <?= $h($pendente['em']) ?>.
      <?php if (!empty($pendente['revert_agendado'])): ?>
        Se esta página não estiver acessível pelo endereço novo, <b>não faça nada</b>: a rede
        anterior volta sozinha em até 3 minutos da aplicação.
      <?php endif; ?>
      Se está tudo funcionando, confirme para cancelar a reversão automática:
      <form method="post" style="display:inline"><input type="hidden" name="acao" value="confirmar">
        <button class="ws-btn verde" style="padding:4px 10px;font-size:12.5px">✔ Está funcionando, manter</button></form>
    </div>
  <?php endif; ?>
<?php endif; ?>

<div class="ws-panel">
  <h3>Interfaces deste servidor</h3>
  <div style="overflow-x:auto"><table class="ws-table">
    <thead><tr><th class="ws-th-esq">Interface</th><th>Estado</th><th>IP</th><th>Máscara</th><th>MAC</th></tr></thead>
    <tbody>
      <?php if (!$interfaces): ?>
        <tr><td colspan="5" class="ws-muted"><?= wsrede_disponivel() ? 'Nenhuma interface de rede encontrada.' : 'Sem leitura disponível.' ?></td></tr>
      <?php else: foreach ($interfaces as $ifn => $i): ?>
        <tr>
          <td class="ws-th-esq"><?= $h($ifn) ?></td>
          <td><span class="ws-tag <?= (($i['estado'] ?? '') === 'UP') ? 'ativo' : 'inativo' ?>"><?= $h($i['estado'] ?? '—') ?></span></td>
          <td><?= $h(($i['ip'] ?? '') ?: '— sem configuração —') ?></td>
          <td><?= $h(($i['mask'] ?? '') ?: '—') ?></td>
          <td><code style="font-size:12px"><?= $h($i['mac'] ?? '—') ?></code></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <p class="ws-muted" style="margin-top:10px;font-size:13px">
    Gateway padrão atual: <b><?= $h($gwAtual ?: '—') ?></b> ·
    DNS atual: <b><?= $h($dnsAtual ? implode(', ', $dnsAtual) : '—') ?></b>
  </p>
</div>

<div class="ws-panel" style="margin-top:16px">
  <h3>Criar / alterar configuração de rede</h3>
  <p class="ws-muted" style="font-size:12.5px">Use para dar um IP fixo a uma interface que ainda
  não tem (servidor novo) ou para trocar a rede atual (novo link de internet, nova faixa de IP).
  Antes de aplicar, a configuração de agora é salva em backup automaticamente.<br>
  Depois de aplicar, o sistema <b>testa a conexão</b> (gateway, internet e DNS) e mostra o
  resultado aqui: a troca só fica definitiva quando você confirmar, e a rede anterior volta
  sozinha em 3 minutos se ninguém confirmar.</p>
  <form method="post" class="ws-form grid" onsubmit="return wsRedeConfirmar(this)">
    <input type="hidden" name="acao" value="aplicar">
    <label>Interface
      <select name="interface" required>
        <option value="">Selecione…</option>
        <?php foreach ($interfaces as $ifn => $i): ?>
          <option value="<?= $h($ifn) ?>"><?= $h($ifn) ?><?= !empty($i['ip']) ? ' (atual: ' . $h($i['ip']) . ')' : ' (sem configuração)' ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Endereço IP <input name="ip" placeholder="192.168.1.10" required pattern="^(\d{1,3}\.){3}\d{1,3}$"></label>
    <label>Máscara de sub-rede <input name="mascara" placeholder="255.255.255.0" required pattern="^(\d{1,3}\.){3}\d{1,3}$" list="wsMascaras">
      <datalist id="wsMascaras">
        <option value="255.255.255.0">/24</option><option value="255.255.0.0">/16</option>
        <option value="255.255.255.128">/25</option><option value="255.255.255.192">/26</option>
        <option value="255.255.255.240">/28</option><option value="255.0.0.0">/8</option>
      </datalist>
    </label>
    <label>Gateway <input name="gateway" placeholder="192.168.1.1" pattern="^(\d{1,3}\.){3}\d{1,3}$"></label>
    <label>DNS primário <input name="dns1" placeholder="8.8.8.8" pattern="^(\d{1,3}\.){3}\d{1,3}$"></label>
    <label>DNS secundário <input name="dns2" placeholder="1.1.1.1" pattern="^(\d{1,3}\.){3}\d{1,3}$"></label>
    <div class="c4">
      <button class="ws-btn primary" <?= ($demo || !wsrede_disponivel()) ? 'disabled' : '' ?>>🌐 Aplicar configuração de rede</button>
      <span class="ws-muted" style="font-size:12px;margin-left:8px">Isto pode derrubar o acesso atual ao servidor se os dados estiverem errados.</span>
    </div>
  </form>
</div>

<?php $backups = is_dir(WS_REDE_BACKUPS) ? array_reverse(glob(WS_REDE_BACKUPS . '/*') ?: []) : []; ?>
<?php if ($backups): ?>
<div class="ws-panel" style="margin-top:16px">
  <h3>Backups de configuração anteriores</h3>
  <p class="ws-muted" style="font-size:12.5px">Guardados automaticamente a cada aplicação. Para
  restaurar um deles, copie o conteúdo pelo <a href="terminal.php">WebTerminal</a> — restauração
  por aqui foi deixada de fora de propósito, para não criar um segundo caminho de mudar rede sem
  o backup/confirmação de cima.</p>
  <ul style="font-size:13px;color:var(--muted);margin:0;padding-left:18px">
    <?php foreach (array_slice($backups, 0, 10) as $b): ?><li><code><?= $h(basename($b)) ?></code></li><?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

</main>
<script>
function wsRedeConfirmar(f){
  // O texto diz o que REALMENTE vai acontecer: aplica, testa e só então pergunta se conclui.
  return confirm('Aplicar esta configuração de rede agora?\n\nEla é aplicada e o sistema testa a conexão em seguida (gateway, internet e DNS). A troca só fica definitiva quando você confirmar na tela — se ninguém confirmar em 3 minutos, a rede anterior volta sozinha.');
}
</script>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>