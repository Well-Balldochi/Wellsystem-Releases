<?php
// ============================================================================
//  Cliente mínimo da RouterOS API (Mikrotik) — porta 8728 (API), texto binário.
//  Suporta o login NOVO (RouterOS 6.43+) e o desafio MD5 antigo. Usado pela
//  página do Radius pra ler /ppp/active e /ip/hotspot/active quando o
//  concentrador for do tipo "mikrotik" (em vez do accel-ppp na porta 2000).
//  Base: implementação pública de RouterOS API (Denis Basta), enxugada.
// ============================================================================
class RouterosAPI {
    public $error = '';
    public $connected = false;
    private $sock = null;

    public function connect($ip, $user, $pass, $port = 8728, $timeout = 4) {
        $this->error = ''; $this->connected = false;
        $this->sock = @fsockopen($ip, (int)$port, $en, $es, $timeout);
        if (!$this->sock) { $this->error = "Conexão falhou: $es"; return false; }
        stream_set_timeout($this->sock, $timeout);
        // 1) login NOVO (plain) — RouterOS 6.43+
        $this->write('/login', false);
        $this->write('=name=' . $user, false);
        $this->write('=password=' . $pass);
        $r = $this->read(false);
        if (isset($r[0]) && $r[0] === '!done') { $this->connected = true; return true; }
        // 2) login ANTIGO (desafio MD5)
        $ret = '';
        foreach ((array)$r as $line) { if (is_string($line) && strpos($line, '=ret=') === 0) { $ret = substr($line, 5); break; } }
        if ($ret !== '') {
            $chal = pack('H*', $ret);
            $md5 = md5(chr(0) . $pass . $chal);
            $this->write('/login', false);
            $this->write('=name=' . $user, false);
            $this->write('=response=00' . $md5);
            $r = $this->read(false);
            if (isset($r[0]) && $r[0] === '!done') { $this->connected = true; return true; }
        }
        $this->error = 'Login recusado (usuário/senha/porta).'; $this->disconnect(); return false;
    }

    public function disconnect() { if ($this->sock) { @fclose($this->sock); $this->sock = null; } $this->connected = false; }

    private function encodeLength($length) {
        if ($length < 0x80) return chr($length);
        if ($length < 0x4000) { $length |= 0x8000; return chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        if ($length < 0x200000) { $length |= 0xC00000; return chr(($length >> 16) & 0xFF) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        if ($length < 0x10000000) { $length |= 0xE0000000; return chr(($length >> 24) & 0xFF) . chr(($length >> 16) & 0xFF) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF); }
        return chr(0xF0) . chr(($length >> 24) & 0xFF) . chr(($length >> 16) & 0xFF) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF);
    }

    public function write($command, $param2 = true) {
        if (!$this->sock) return false;
        $data = $this->encodeLength(strlen($command)) . $command;
        @fwrite($this->sock, $data);
        if ($param2 === true) @fwrite($this->sock, chr(0));           // fim do sentence
        return true;
    }

    private function readLen() {
        $b = ord(fread($this->sock, 1));
        if ($b & 0x80) {
            if (($b & 0xC0) == 0x80) { $b &= ~0x80; $b = ($b << 8) + ord(fread($this->sock, 1)); }
            elseif (($b & 0xE0) == 0xC0) { $b &= ~0xC0; $b = ($b << 8) + ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); }
            elseif (($b & 0xF0) == 0xE0) { $b &= ~0xE0; $b = ($b << 8) + ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); }
            else { $b = ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); $b = ($b << 8) + ord(fread($this->sock, 1)); }
        }
        return $b;
    }

    // Lê a resposta. $parse=true agrupa em registros (array de assoc); false devolve linhas cruas.
    public function read($parse = true) {
        $response = []; $lastReply = '';
        while (true) {
            $len = $this->readLen();
            if ($len <= 0) { // fim de sentence
                if ($lastReply === '!done') break;
                if ($lastReply === '!re' || $lastReply === '!trap' || $lastReply === '!fatal') { $lastReply = ''; continue; }
                $lastReply = ''; continue;
            }
            $word = '';
            while (strlen($word) < $len) { $chunk = fread($this->sock, $len - strlen($word)); if ($chunk === '' || $chunk === false) break; $word .= $chunk; }
            if ($word !== '' && $word[0] === '!') { $lastReply = $word; }
            $response[] = $word;
            $info = stream_get_meta_data($this->sock); if ($info['timed_out']) break;
        }
        if (!$parse) return $response;
        /* AGRUPA: cada "!re" inicia um registro normal; "=k=v" são campos.
         *
         * "!trap" É UM ERRO DO MIKROTIK — o comando foi RECUSADO (ex.: remover uma sessão cujo
         * .id já não existe mais, porque a lista mudou entre o /print e o /remove — o típico
         * "cliente com sessão presa"). Antes, "!trap" não entrava aqui: as palavras "=message=..."
         * do erro eram lidas e jogadas fora porque $cur continuava null (nenhum "!re" abriu
         * registro), e comm() devolvia [] — EXATAMENTE o mesmo retorno de um comando que funcionou
         * sem nada para listar. Quem chamava (ex.: derrubar sessão) não tinha como saber se o
         * Mikrotik aceitou ou recusou, e tratava os dois casos como sucesso — por isso um comando
         * recusado "não servia pra nada" mas o sistema seguia achando que tinha derrubado a sessão.
         * Agora "!trap" vira um registro com a chave especial __trap__ (e a mensagem de erro do
         * Mikrotik, se houver, no campo "message") — quem chama pode e deve conferir isso antes de
         * assumir sucesso. Código antigo que só olha ".id" (ex.: leitura de /ppp/active/print) não
         * quebra: um registro de trap não tem ".id", então é ignorado como antes. */
        $out = []; $cur = null;
        foreach ($response as $w) {
            if ($w === '!re') { if ($cur !== null) $out[] = $cur; $cur = []; }
            elseif ($w === '!trap' || $w === '!fatal') { if ($cur !== null) $out[] = $cur; $cur = ['__trap__' => true]; }
            elseif ($w === '!done') { if ($cur !== null) { $out[] = $cur; $cur = null; } }
            elseif ($cur !== null && strlen($w) > 1 && $w[0] === '=') { $eq = strpos($w, '=', 1); if ($eq !== false) { $cur[substr($w, 1, $eq - 1)] = substr($w, $eq + 1); } }
        }
        if ($cur !== null) $out[] = $cur;
        return $out;
    }

    /** true se a resposta de comm() contém algum erro (!trap/!fatal) do Mikrotik. */
    public static function trapMsg(array $recs): ?string {
        foreach ($recs as $r) if (is_array($r) && !empty($r['__trap__'])) return (string)($r['message'] ?? 'erro sem mensagem do Mikrotik');
        return null;
    }

    // Executa um comando (ex.: "/ppp/active/print") e devolve os registros.
    public function comm($command, $args = []) {
        $this->write($command, count($args) === 0);
        $keys = array_keys($args); $i = 0; $n = count($args);
        foreach ($args as $k => $v) { $i++; $this->write('=' . $k . '=' . $v, $i === $n); }
        return $this->read(true);
    }
}
