<?php
/**
 * WellSystem — PESQUISA DE SATISFAÇÃO pós-atendimento (01/10/2026).
 * Chamado FINALIZADO (resolvido) há 30 min+ e sem nota → o cliente recebe no WhatsApp um link com 5 estrelas
 * (avaliar.php, sem login, assinado). A nota cai no próprio chamado (as mesmas colunas da avaliação pela Central:
 * avaliacao / avaliacao_comentario / avaliacao_em) e aparece no Painel e na ficha do chamado.
 *   · Só envia com a conversa do WhatsApp ABERTA (cliente falou nas últimas 24 h): sem custo de template e sem
 *     mensagem "do nada". Fora disso, marca e não insiste.
 *   · Das 8h às 20h, no máximo 20 por passada, 1 pesquisa por chamado, chamados dos últimos 3 dias.
 *   · Nota 1 ou 2 → a equipe é avisada na hora (Notificações de chamado) para recuperar o cliente.
 *   · Chamado aberto pela URA telefônica: a pesquisa sai pela Wellnet-01 (exceção do dono, 15/11/2026), sem exigir janela de 24 h, se o número tiver WhatsApp.
 * Liga/desliga: cache/satisfacao.json {"ativo":1} (padrão ligado). Rodada pelo cron do radius_sync.php.
 */

function ws_satisf_cfg(): array {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/satisfacao.json'), true);
    return (is_array($j) ? $j : []) + ['ativo' => 1];
}

/** Segredo próprio deste servidor para assinar os links públicos (criado sozinho, fora do alcance da web). */
function ws_link_segredo(): string {
    $f = WS_CACHE . '/link_segredo.txt';
    $k = trim((string)@file_get_contents($f));
    if (strlen($k) < 32) { $k = bin2hex(random_bytes(24)); @file_put_contents($f, $k); @chmod($f, 0600);
        if (function_exists('posix_geteuid') && posix_geteuid() === 0) { @chown($f, 'www-data'); @chgrp($f, 'www-data'); } }   // rodou como root: o site precisa ler
    return $k;
}
function ws_satisf_sig(int $chamadoId): string { return substr(hash_hmac('sha256', 'avaliar|' . $chamadoId, ws_link_segredo()), 0, 16); }

/** Endereço público do sistema: o mesmo usado pelo robô (link do PIX) ou o domínio salvo da última visita. */
function ws_satisf_base(): string {
    if (function_exists('ws_url_publica')) return ws_url_publica();   // sempre o domínio, nunca o IP
    $f = WS_CACHE . '/url_publica.txt';
    if (!empty($_SERVER['HTTP_HOST'])) {
        $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $u = ($https ? 'https' : 'http') . '://' . preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)$_SERVER['HTTP_HOST']);
        if (!preg_match('#//(127\.|localhost|10\.|192\.168\.)#', $u)) @file_put_contents($f, $u);
        return $u;
    }
    return trim((string)@file_get_contents($f));
}

/** Chamado aberto PELA URA telefônica (o relato do chamado traz "Pedido pela URA telefônica"). */
function ws_satisf_chamado_da_ura(string $descricao): bool { return strpos($descricao, 'Pedido pela URA telefônica') !== false; }

/** Pesquisa de chamado da URA: sai pela Wellnet-01 (WhatsApp comum), só se o número tiver WhatsApp e a instância estiver no ar; NUNCA cai para a 02.
 *  EXCEÇÃO autorizada pelo dono em 15/11/2026 à regra "automático só pela Wellnet-02" (a outra é o menu do chat da URA, ws_ura_chat_menu). */
function ws_satisf_enviar_comum(string $num, string $txt, array $c): array {
    $in = ws_wa_instancia_comum_conversa($c);
    if ($in === '' || (string)($c['url'] ?? '') === '' || !ws_wa_instancia_online($in, $c)) return ['ok' => false];
    if (ws_wa_eh_numero_da_empresa($num, $c) !== '') return ['ok' => false];
    if (!function_exists('ws_at_evo')) require_once WS_DIR . '/atendimento_lib.php';
    [$s, $j] = ws_at_evo('POST', '/chat/whatsappNumbers/' . rawurlencode($in), ['numbers' => [$num]], $in);   // devolve o jid certo (com ou sem o 9)
    if ($s < 200 || $s >= 300 || !is_array($j) || empty($j[0]['exists'])) return ['ok' => false];
    $dest = preg_replace('/\D/', '', explode('@', (string)($j[0]['jid'] ?? $num))[0]) ?: $num;
    return ws_wa_evo_um('texto', $in, $dest, $txt, $c);
}

/** Envia as pesquisas pendentes. Devolve quantas enviou. */
function ws_satisf_enviar(PDO $db, int $max = 20): int {
    $cfg = ws_satisf_cfg(); if (empty($cfg['ativo'])) return 0;
    // Vale a partir da 1ª vez que roda: chamados finalizados ANTES disso não recebem pesquisa retroativa.
    if (empty($cfg['desde'])) { $cfg['desde'] = date('Y-m-d H:i:s'); @file_put_contents(WS_CACHE . '/satisfacao.json', json_encode($cfg)); return 0; }
    $h = (int)date('G'); if ($h < 8 || $h >= 20) return 0;
    $base = ws_satisf_base(); if ($base === '' || !is_file(WS_DIR . '/whatsapp.php')) return 0;
    require_once WS_DIR . '/whatsapp.php';
    $wc = ws_wa_config();
    $prov = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
    $provNome = (function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: ($prov['razao'] ?? '')));
    $rs = $db->query("SELECT ch.id, ch.titulo, ch.descricao, c.nome, c.celular FROM ws_chamado ch JOIN ws_cliente c ON c.id=ch.cliente_id
                      WHERE ch.status='resolvido' AND ch.avaliacao IS NULL AND ch.pesquisa_em IS NULL
                        AND ch.fechado_em BETWEEN NOW() - INTERVAL 3 DAY AND NOW() - INTERVAL 30 MINUTE AND ch.fechado_em >= " . $db->quote((string)$cfg['desde']) . "
                        AND c.status NOT IN ('cancelado','desativado') AND COALESCE(c.celular,'')<>''
                      ORDER BY ch.fechado_em LIMIT " . (int)$max)->fetchAll(PDO::FETCH_ASSOC);
    $n = 0;
    foreach ($rs as $r) {
        $db->prepare("UPDATE ws_chamado SET pesquisa_em=NOW() WHERE id=?")->execute([(int)$r['id']]);   // 1 vez só, mesmo se falhar
        $num = ws_wa_numero((string)$r['celular']);
        $ura = ws_satisf_chamado_da_ura((string)($r['descricao'] ?? ''));   // chamado da URA: o cliente ligou (não escreveu), então não há janela de 24 h — vai pela 01
        if ($num === '' || (!$ura && !ws_wa_janela_aberta($num, $wc))) continue;
        $link = $base . '/avaliar.php?c=' . (int)$r['id'] . '-' . ws_satisf_sig((int)$r['id']);
        $txt = "⭐ Olá, " . explode(' ', trim((string)$r['nome']))[0] . "!\nSeu atendimento (chamado nº {$r['id']}) foi concluído.\n\n"
             . "Pode nos dizer como foi? Leva 5 segundos:\n$link\n\nObrigado! " . $provNome;
        try { $res = $ura ? ws_satisf_enviar_comum($num, $txt, $wc) : ws_wa_enviar((string)$r['celular'], $txt, false, ['evento' => 'chamado', 'automatica' => true]); if (!empty($res['ok'])) $n++; } catch (Throwable $e) {}
    }
    return $n;
}
