<?php
/**
 * WellSystem — rotina da SAÚDE DO SISTEMA (cron, a cada minuto). Regras em saude_lib.php.
 * Só linha de comando. Grava cache/saude_estado.json (lido pela tela saude.php) e avisa a equipe no WhatsApp
 * quando algo cai (3 falhas seguidas) e quando volta.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php'; require_once __DIR__ . '/espelho_lib.php'; ws_espelho_so_principal();   // ESPELHO (05/11/2026): rotina autom�tica - s� o servidor PRINCIPAL roda (a r�plica e a quarentena saem calados)
foreach (['radius_lib.php', 'bb_pix.php', 'saude_lib.php'] as $f) if (is_file(__DIR__ . '/' . $f)) require_once __DIR__ . '/' . $f;
$trava = fopen(WS_CACHE . '/saude.lock', 'c');
if (!$trava || !flock($trava, LOCK_EX | LOCK_NB)) exit(0);   // a anterior ainda está rodando
ws_saude_rodar(true);
if (function_exists('ws_lic_tick')) ws_lic_tick();   // licença online: 1 consulta por dia; falha de rede nunca bloqueia (licenca_online.php)

/* ENTREGA DA MÍDIA RECEBIDA PELA EVOLUTION (02/10/2026) — automática, sem passo manual: com o WhatsApp e a API do robô
   configurados, liga (e confere a cada 6 h, ou na hora se o endereço do sistema mudar) o webhook só de mídia em cada
   instância. Sem isso, no número oficial da Meta o áudio e o comprovante do cliente nunca chegam ao sistema.
   Instância que já tem webhook de OUTRO sistema não é tocada (ws_midia_webhook_registrar). */
try {
    if (is_file(__DIR__ . '/api_chatbot.php')) {
        require_once __DIR__ . '/api_chatbot.php';
        $cbM = ws_chatbot_cfg(); $urlM = ws_midia_webhook_url();
        $mf = WS_CACHE . '/midia_webhook.json'; $mj = json_decode((string)@file_get_contents($mf), true) ?: [];
        if (!empty($cbM['ativo']) && $urlM !== '' && (($mj['url'] ?? '') !== $urlM || time() - (int)($mj['em'] ?? 0) > 21600)) {
            $resM = ws_midia_webhook_registrar();
            @file_put_contents($mf, json_encode(['url' => $urlM, 'em' => time(), 'res' => $resM], JSON_UNESCAPED_UNICODE)); @chmod($mf, 0640);
        }
    }
} catch (Throwable $e) {}

/* ROBÔ DA WELLNET-02 SEMPRE DESLIGADO (17/10/2026) — fora a emergência. O número oficial (API da Meta) não guarda a sessão do robô na Evolution: com o robô ligado ali, cada mensagem do cliente (inclusive o "8" do menu)
   reiniciava o fluxo e o robô da Wellnet-01 também era iniciado — dois robôs, menu repetido, comprovante respondido 2x. Quem atende o cliente, dentro e fora do expediente, é o robô da Wellnet-01 (o fluxo Atendimento já
   confere o horário em /api/horario e mostra o aviso de fora do horário). Se algo religar o robô da 02 fora do modo emergência, aqui ele é desligado de novo (a cada minuto). */
try {
    if (!function_exists('ws_wa_modo_api')) require_once __DIR__ . '/whatsapp.php';
    $waG = ws_wa_config(); $apiG = ws_wa_modo_api($waG);   // '' = sem API definida OU emergência ligada (aí o robô da 02 deve ficar ligado)
    // só no perfil de DOIS números (API + WhatsApp comum). Empresa que tem só o número oficial usa o robô na própria API e não pode ser desligada aqui.
    $outrasG = array_diff(array_unique(array_merge(ws_wa_instancias($waG), ws_wa_instancias_comum($waG))), [$apiG]);
    if ($apiG !== '' && $outrasG && trim((string)($waG['url'] ?? '')) !== '') {
        $kG = ws_wa_chave($waG, $apiG); $chG = curl_init(rtrim((string)$waG['url'], '/') . '/typebot/find/' . rawurlencode($apiG));
        curl_setopt_array($chG, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_HTTPHEADER => ['apikey: ' . $kG], CURLOPT_TIMEOUT => 10]);
        $jG = json_decode((string)curl_exec($chG), true); curl_close($chG);
        $bG = isset($jG[0]) ? $jG[0] : (is_array($jG) && isset($jG['typebot']) ? $jG : null);
        if (is_array($bG) && !empty($bG['enabled'])) {
            $resG = ws_wa_robo_ligar($apiG, false);
            @error_log('[saude_run] robô da ' . $apiG . ' estava ligado fora da emergência — desligado' . ($resG === '' ? '' : ' (falhou: ' . $resG . ')'));
        }
    }
} catch (Throwable $e) {}
