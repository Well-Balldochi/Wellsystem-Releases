<?php
/**
 * =================================================================================================
 * WellSystem — ENDEREÇO NORMALIZADO
 * =================================================================================================
 * O PROBLEMA QUE ISTO RESOLVE
 * O endereço estava guardado como TEXTO dentro do cliente: cep, logradouro, numero, complemento,
 * bairro, cidade, uf — sete campos digitados livremente, uma vez por cliente. Com 1.600 clientes,
 * a mesma rua aparece escrita de todas as formas possíveis:
 *
 *     "AV. BRASIL"   "AVENIDA BRASIL"   "Av Brasil"   "AV BRASIL "   "AVENIDA  BRASIL"
 *
 * São cinco coisas diferentes para o banco e uma só na vida real. As consequências não são
 * estéticas: filtrar clientes por rua não fecha, agrupar por bairro dá números errados, corrigir o
 * nome de uma rua exige achar e editar cliente por cliente, e o relatório por região mente. É o
 * mesmo defeito que o MK-Auth tem, e copiá-lo não traria benefício nenhum.
 *
 * O MODELO
 * Cada nível é uma tabela, e o de baixo aponta para o de cima pelo CÓDIGO:
 *
 *     ws_uf          sigla do estado                       (27 linhas, fixas)
 *     ws_cep         o código do CEP, uma vez só
 *     ws_cidade      nome + uf_id + cep_id (CEP geral)
 *     ws_bairro      nome + cidade_id
 *     ws_logradouro  nome + tipo (Rua/Av.) + bairro_id + cep_id
 *
 *     ws_cliente     logradouro_id + numero + complemento
 *     ws_contrato    inst_logradouro_id + inst_numero + inst_complemento   (endereço de instalação)
 *
 * Assim: a rua existe UMA vez. Corrigir o nome dela corrige para todos os clientes de uma vez.
 * Trocar o nome ou o CEP não desvincula ninguém, porque o vínculo é pelo código — o mesmo
 * raciocínio do grupo de plano no RADIUS (`plano_{id}`, nunca o nome).
 *
 * O QUE ACONTECE COM O TEXTO ANTIGO
 * As colunas de texto (cliente.cidade, cliente.logradouro…) NÃO são mais a origem de nada. Toda
 * ESCRITA passa pelo resolvedor, e toda LEITURA do sistema passa pelo cadastro — foram migradas:
 *
 *     boleto.php ............. sacado do boleto e do PIX          -> ws_end_sql_campos()
 *     portal.php ............. "Meus dados" e o recibo do portal  -> ws_end_sql_campos()
 *     mensagens_lib.php ...... %enderecocliente% nas cobranças    -> JOIN normalizado
 *     documentos.php ......... contrato e recibo em modelo        -> ws_end_enriquecer()
 *     faturamento.php ........ endereço enviado ao gateway        -> ws_end_enriquecer()
 *     financeiro.php ......... emissão manual no gateway          -> ws_end_enriquecer()
 *     fiscal.php ............. TOMADOR da NFS-e                   -> ws_end_enriquecer()
 *     erp.php ................ ficha, contrato, comodato, gateway -> os dois caminhos
 *
 * E toda ENTRADA de endereço passa pelo resolvedor: cadastro manual, contrato, importação do
 * MK-Auth, importação por planilha e conversão de lead em cliente. Não sobrou porta sem filtro —
 * era por elas que a duplicata nascia.
 *
 * As colunas continuam no banco apenas até alguém acionar **Manutenção → 🗂️ Colunas de texto do
 * endereço**, que as APOSENTA (renomeia, não apaga — reversível em um clique). A aposentadoria é um
 * botão, e não parte da atualização, porque mudança de estrutura num banco que fatura não deve
 * acontecer sozinha no meio do expediente. Ver ws_end_texto_aposentar() no fim deste arquivo.
 */

/* ---------------------------------------------------------------------------- normalização */

/**
 * Forma canônica de um nome de lugar, usada para COMPARAR (não para exibir).
 *
 * É o coração do antiduplicata. Sem isto, "AV. BRASIL" e "Avenida Brasil" seguiriam sendo dois
 * cadastros. Tudo que é variação de escrita é achatado aqui: caixa, acento, pontuação, espaço
 * repetido e as abreviaturas de tipo de via, que são a origem da maioria das duplicatas.
 */
function ws_end_chave(string $nome): string {
    $s = trim($nome);
    if ($s === '') return '';
    // Acento fora: "AVENIDA JOSÉ" e "AVENIDA JOSE" são a mesma avenida.
    $s = strtr($s, [
        'á'=>'a','à'=>'a','ã'=>'a','â'=>'a','ä'=>'a','é'=>'e','ê'=>'e','ë'=>'e','í'=>'i','ï'=>'i',
        'ó'=>'o','õ'=>'o','ô'=>'o','ö'=>'o','ú'=>'u','ü'=>'u','ç'=>'c','ñ'=>'n',
        'Á'=>'A','À'=>'A','Ã'=>'A','Â'=>'A','Ä'=>'A','É'=>'E','Ê'=>'E','Ë'=>'E','Í'=>'I','Ï'=>'I',
        'Ó'=>'O','Õ'=>'O','Ô'=>'O','Ö'=>'O','Ú'=>'U','Ü'=>'U','Ç'=>'C','Ñ'=>'N',
    ]);
    $s = mb_strtoupper($s, 'UTF-8');
    // Abreviaturas de tipo de via -> forma cheia. É de longe a maior fonte de duplicata.
    $s = preg_replace('/^(AV|AVN|AVEN)\.?\s+/u',        'AVENIDA ',   $s);
    $s = preg_replace('/^(R|RU)\.?\s+/u',               'RUA ',       $s);
    $s = preg_replace('/^(TV|TRV)\.?\s+/u',             'TRAVESSA ',  $s);
    $s = preg_replace('/^(PC|PÇ|PRC)\.?\s+/u',          'PRACA ',     $s);
    $s = preg_replace('/^(RDV|ROD)\.?\s+/u',            'RODOVIA ',   $s);
    $s = preg_replace('/^(AL)\.?\s+/u',                 'ALAMEDA ',   $s);
    $s = preg_replace('/^(EST)\.?\s+/u',                'ESTRADA ',   $s);
    $s = preg_replace('/^(LT|LOT)\.?\s+/u',             'LOTEAMENTO ',$s);
    // Pontuação virou espaço, espaço repetido virou um só.
    $s = preg_replace('/[^A-Z0-9 ]+/u', ' ', $s);
    $s = trim(preg_replace('/\s+/', ' ', $s));
    return $s;
}

/** Só os dígitos do CEP. "55.000-000" e "55000000" são o mesmo CEP. */
function ws_end_cep_limpo(string $cep): string {
    $d = preg_replace('/\D/', '', $cep);
    return (strlen($d) === 8) ? $d : '';
}

/* ------------------------------------------------------------------------------- estrutura */

/**
 * Cria as tabelas de endereço e semeia as UFs. Idempotente.
 *
 * As restrições UNIQUE são o que garante a unicidade no BANCO, e não só no código: mesmo que duas
 * requisições simultâneas tentem criar a mesma rua, o banco recusa a segunda. Regra de unicidade
 * que vive apenas no PHP é regra que falha no dia de movimento.
 */
function ws_endereco_preparar(PDO $db): void {
    $x = function (string $sql) use ($db) { try { $db->exec($sql); } catch (Throwable $e) {} };

    $x("CREATE TABLE IF NOT EXISTS ws_uf (
        id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        sigla CHAR(2) NOT NULL,
        nome VARCHAR(40) NOT NULL,
        UNIQUE KEY uq_sigla (sigla)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* O CEP numa tabela só, guardado UMA vez.
     * Antes ele era retrodigitado em cada cliente e em cada cidade — a mesma sequência de oito
     * dígitos repetida milhares de vezes, com erro de digitação em algumas delas. Aqui o código
     * existe uma vez e quem precisa dele aponta. */
    $x("CREATE TABLE IF NOT EXISTS ws_cep (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        cep CHAR(8) NOT NULL,
        UNIQUE KEY uq_cep (cep)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // ws_cidade e ws_bairro já existem (criadas antes); aqui entram só as colunas de vínculo.
    $x("ALTER TABLE ws_cidade ADD COLUMN uf_id TINYINT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_cidade ADD COLUMN cep_id INT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_cidade ADD COLUMN ibge INT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_cidade ADD COLUMN chave VARCHAR(120) DEFAULT NULL");
    $x("ALTER TABLE ws_cidade ADD UNIQUE KEY uq_cidade_uf (chave, uf_id)");

    /* UF DIRETO no cliente/contrato, e não só pela cadeia logradouro->bairro->cidade->uf_id.
     * O resolvedor (ws_end_resolver) já CALCULA o uf_id da UF digitada em toda gravação — mas até
     * aqui esse valor era jogado fora, porque não existia coluna para guardá-lo. Sem ela, saber a
     * UF de um cliente sem rua cadastrada (só cidade/UF, comum em cadastro rápido) dependia do
     * texto solto (CHAR(2), sem garantia nenhuma contra "pe"/"Pe"/"PW"). Com a coluna, é ID —
     * mesmo ganho que ws_cidade.uf_id já tem, sem depender do restante do endereço estar completo. */
    $x("ALTER TABLE ws_cliente ADD COLUMN uf_id TINYINT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_contrato ADD COLUMN inst_uf_id TINYINT UNSIGNED DEFAULT NULL");

    $x("CREATE TABLE IF NOT EXISTS ws_bairro (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cidade_id INT DEFAULT NULL,
        nome VARCHAR(120) NOT NULL,
        ativo TINYINT(1) NOT NULL DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $x("ALTER TABLE ws_bairro ADD COLUMN chave VARCHAR(120) DEFAULT NULL");
    $x("ALTER TABLE ws_bairro ADD UNIQUE KEY uq_bairro_cidade (chave, cidade_id)");

    /* LOGRADOURO — a rua, uma vez só.
     * `nome` é como se escreve (vai para o boleto). `chave` é a forma canônica, que serve para
     * comparar. Guardar as duas é o que permite exibir "Av. Brasil" e ainda assim reconhecer que
     * "AVENIDA BRASIL" é a mesma — sem isso, ou a exibição fica feia, ou a duplicata volta. */
    $x("CREATE TABLE IF NOT EXISTS ws_logradouro (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(160) NOT NULL,
        chave VARCHAR(160) NOT NULL,
        tipo VARCHAR(20) DEFAULT NULL,
        bairro_id INT DEFAULT NULL,
        cep_id INT UNSIGNED DEFAULT NULL,
        ativo TINYINT(1) NOT NULL DEFAULT 1,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_log_bairro (chave, bairro_id),
        KEY idx_bairro (bairro_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Vínculo no cliente e no contrato. O texto continua ao lado, como cópia de leitura.
    $x("ALTER TABLE ws_cliente  ADD COLUMN logradouro_id INT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_cliente  ADD KEY idx_logradouro (logradouro_id)");
    $x("ALTER TABLE ws_contrato ADD COLUMN inst_logradouro_id INT UNSIGNED DEFAULT NULL");
    $x("ALTER TABLE ws_contrato ADD KEY idx_inst_logradouro (inst_logradouro_id)");

    // As 27 UFs. Lista fixa: não muda, e depender de digitação para isso é pedir "SP" e "Sp".
    $ufs = [
        'AC'=>'Acre','AL'=>'Alagoas','AP'=>'Amapá','AM'=>'Amazonas','BA'=>'Bahia','CE'=>'Ceará',
        'DF'=>'Distrito Federal','ES'=>'Espírito Santo','GO'=>'Goiás','MA'=>'Maranhão',
        'MT'=>'Mato Grosso','MS'=>'Mato Grosso do Sul','MG'=>'Minas Gerais','PA'=>'Pará',
        'PB'=>'Paraíba','PR'=>'Paraná','PE'=>'Pernambuco','PI'=>'Piauí','RJ'=>'Rio de Janeiro',
        'RN'=>'Rio Grande do Norte','RS'=>'Rio Grande do Sul','RO'=>'Rondônia','RR'=>'Roraima',
        'SC'=>'Santa Catarina','SP'=>'São Paulo','SE'=>'Sergipe','TO'=>'Tocantins',
    ];
    try {
        $ins = $db->prepare("INSERT IGNORE INTO ws_uf (sigla, nome) VALUES (?,?)");
        foreach ($ufs as $sigla => $nome) $ins->execute([$sigla, $nome]);
    } catch (Throwable $e) {}
}

/* ------------------------------------------------------------------------------ resolvedores */

/** UF pela sigla. Não cria: a lista das 27 é fixa e completa. */
function ws_end_uf_id(PDO $db, string $sigla): ?int {
    $s = mb_strtoupper(trim($sigla), 'UTF-8');
    if (!preg_match('/^[A-Z]{2}$/', $s)) return null;
    try {
        $q = $db->prepare("SELECT id FROM ws_uf WHERE sigla=? LIMIT 1");
        $q->execute([$s]);
        return ($id = (int)$q->fetchColumn()) ? $id : null;
    } catch (Throwable $e) { return null; }
}

/** Código do CEP — acha o que existe, cria se for novo. */
function ws_end_cep_id(PDO $db, string $cep): ?int {
    $c = ws_end_cep_limpo($cep);
    if ($c === '') return null;
    try {
        $q = $db->prepare("SELECT id FROM ws_cep WHERE cep=? LIMIT 1");
        $q->execute([$c]);
        if ($id = (int)$q->fetchColumn()) return $id;
        $db->prepare("INSERT IGNORE INTO ws_cep (cep) VALUES (?)")->execute([$c]);
        $q->execute([$c]);
        return ($id = (int)$q->fetchColumn()) ? $id : null;
    } catch (Throwable $e) { return null; }
}

/**
 * Cidade pelo nome + UF. Acha a que existe (ignorando grafia) ou cria.
 *
 * A busca é pela CHAVE, não pelo nome: é o que faz "São josé" encontrar a "SAO JOSE" já cadastrada
 * em vez de criar a segunda. Quando encontra uma cidade antiga sem chave gravada, grava — assim a
 * base se limpa sozinha conforme é usada, sem precisar de uma passada geral.
 */
function ws_end_cidade_id(PDO $db, string $nome, string $uf = '', string $cep = ''): ?int {
    /* (16/10/2026) texto colado do WhatsApp ("1️⃣- Nazaré da Mata-PE"): tira emoji/número do início e o "-UF" do fim, e aproveita a UF do sufixo se não veio uma. */
    if (preg_match('/-\s*([A-Za-z]{2})\s*$/u', $nome, $mUf) && $uf === '') $uf = strtoupper($mUf[1]);
    $nome = (string)preg_replace('/\s*-\s*[A-Za-z]{2}\s*$/u', '', (string)preg_replace('/^[^\p{L}]+/u', '', trim($nome)));
    $chave = ws_end_chave($nome);
    if ($chave === '') return null;
    $ufId = ws_end_uf_id($db, $uf);
    try {
        // Primeiro dentro da UF informada; sem UF, aceita a cidade de mesmo nome que exista.
        if ($ufId) {
            $q = $db->prepare("SELECT id FROM ws_cidade WHERE chave=? AND uf_id=? LIMIT 1");
            $q->execute([$chave, $ufId]);
        } else {
            $q = $db->prepare("SELECT id FROM ws_cidade WHERE chave=? LIMIT 1");
            $q->execute([$chave]);
        }
        $id = (int)$q->fetchColumn();

        if (!$id) {
            // Cidade que já existia só com o nome em texto: adota, gravando a chave.
            $q2 = $db->prepare("SELECT id FROM ws_cidade WHERE (chave IS NULL OR chave='') AND UPPER(nome)=? LIMIT 1");
            $q2->execute([mb_strtoupper(trim($nome), 'UTF-8')]);
            $id = (int)$q2->fetchColumn();
        }

        if ($id) {
            // Completa o que estiver faltando; nunca sobrescreve o que já está preenchido.
            $sets = []; $par = [];
            $sets[] = "chave=COALESCE(NULLIF(chave,''), ?)"; $par[] = $chave;
            if ($ufId) { $sets[] = "uf_id=COALESCE(uf_id, ?)"; $par[] = $ufId; }
            if ($cepId = ws_end_cep_id($db, $cep)) { $sets[] = "cep_id=COALESCE(cep_id, ?)"; $par[] = $cepId; }
            $par[] = $id;
            $db->prepare("UPDATE ws_cidade SET " . implode(',', $sets) . " WHERE id=?")->execute($par);
            return $id;
        }

        $db->prepare("INSERT INTO ws_cidade (nome, chave, uf_id, cep_id, ativo) VALUES (?,?,?,?,1)")
           ->execute([mb_substr(trim($nome), 0, 120), $chave, $ufId, ws_end_cep_id($db, $cep)]);
        return (int)$db->lastInsertId() ?: null;
    } catch (Throwable $e) { return null; }
}

/** Bairro pelo nome + cidade. Mesma lógica de chave da cidade. */
function ws_end_bairro_id(PDO $db, string $nome, ?int $cidadeId): ?int {
    $chave = ws_end_chave($nome);
    if ($chave === '') return null;
    try {
        $q = $db->prepare("SELECT id FROM ws_bairro WHERE chave=? AND cidade_id " . ($cidadeId ? "=?" : "IS NULL") . " LIMIT 1");
        $q->execute($cidadeId ? [$chave, $cidadeId] : [$chave]);
        $id = (int)$q->fetchColumn();

        if (!$id) {
            $q2 = $db->prepare("SELECT id FROM ws_bairro WHERE (chave IS NULL OR chave='') AND UPPER(nome)=?
                                AND cidade_id " . ($cidadeId ? "=?" : "IS NULL") . " LIMIT 1");
            $q2->execute($cidadeId ? [mb_strtoupper(trim($nome), 'UTF-8'), $cidadeId] : [mb_strtoupper(trim($nome), 'UTF-8')]);
            $id = (int)$q2->fetchColumn();
        }

        if ($id) {
            $db->prepare("UPDATE ws_bairro SET chave=COALESCE(NULLIF(chave,''), ?) WHERE id=?")->execute([$chave, $id]);
            return $id;
        }
        $db->prepare("INSERT INTO ws_bairro (nome, chave, cidade_id, ativo) VALUES (?,?,?,1)")
           ->execute([mb_substr(trim($nome), 0, 120), $chave, $cidadeId]);
        return (int)$db->lastInsertId() ?: null;
    } catch (Throwable $e) { return null; }
}

/** Logradouro pelo nome + bairro. É aqui que a duplicata de rua morre. */
function ws_end_logradouro_id(PDO $db, string $nome, ?int $bairroId, string $cep = ''): ?int {
    $chave = ws_end_chave($nome);
    if ($chave === '') return null;
    // Tipo de via (RUA, AVENIDA…) sai da própria chave, já desabreviado.
    $tipo = null;
    if (preg_match('/^(RUA|AVENIDA|TRAVESSA|PRACA|RODOVIA|ALAMEDA|ESTRADA|LOTEAMENTO|VILA|CONJUNTO)\b/', $chave, $m)) $tipo = $m[1];
    $cepId = ws_end_cep_id($db, $cep);
    try {
        $q = $db->prepare("SELECT id FROM ws_logradouro WHERE chave=? AND bairro_id " . ($bairroId ? "=?" : "IS NULL") . " LIMIT 1");
        $q->execute($bairroId ? [$chave, $bairroId] : [$chave]);
        if ($id = (int)$q->fetchColumn()) {
            if ($cepId) $db->prepare("UPDATE ws_logradouro SET cep_id=COALESCE(cep_id, ?) WHERE id=?")->execute([$cepId, $id]);
            return $id;
        }
        $db->prepare("INSERT INTO ws_logradouro (nome, chave, tipo, bairro_id, cep_id, ativo) VALUES (?,?,?,?,?,1)")
           ->execute([mb_substr(trim($nome), 0, 160), $chave, $tipo, $bairroId, $cepId]);
        return (int)$db->lastInsertId() ?: null;
    } catch (Throwable $e) { return null; }
}

/**
 * Resolve um endereço digitado inteiro e devolve os CÓDIGOS + o texto canônico.
 *
 * É o único ponto por onde endereço deve entrar no sistema. Chamado ao salvar cliente e contrato.
 *
 * @param array $t ['cep','logradouro','bairro','cidade','uf']
 * @return array ['logradouro_id','bairro_id','cidade_id','uf_id','cep_id','logradouro','bairro','cidade','uf','cep']
 *               Os campos de texto voltam na grafia CADASTRADA (a da tabela), não na digitada — é
 *               assim que a segunda pessoa a digitar "av brasil" vê "Av. Brasil" gravado, e a base
 *               converge para uma escrita só em vez de acumular variações.
 */
function ws_end_resolver(PDO $db, array $t): array {
    $out = ['logradouro_id'=>null,'bairro_id'=>null,'cidade_id'=>null,'uf_id'=>null,'cep_id'=>null,
            'logradouro'=>trim((string)($t['logradouro'] ?? '')),
            'bairro'=>trim((string)($t['bairro'] ?? '')),
            'cidade'=>trim((string)($t['cidade'] ?? '')),
            'uf'=>mb_strtoupper(trim((string)($t['uf'] ?? '')), 'UTF-8'),
            'cep'=>trim((string)($t['cep'] ?? ''))];

    $out['cidade_id'] = ws_end_cidade_id($db, $out['cidade'], $out['uf'], $out['cep']);
    $out['uf_id']     = ws_end_uf_id($db, $out['uf']);
    $out['cep_id']    = ws_end_cep_id($db, $out['cep']);
    $out['bairro_id'] = ws_end_bairro_id($db, $out['bairro'], $out['cidade_id']);
    $out['logradouro_id'] = ws_end_logradouro_id($db, $out['logradouro'], $out['bairro_id'], $out['cep']);

    // Texto canônico: o que está na tabela manda, para a base convergir para uma grafia só.
    try {
        if ($out['logradouro_id']) {
            $r = $db->prepare("SELECT l.nome logradouro, b.nome bairro, ci.nome cidade, u.sigla uf, ce.cep
                               FROM ws_logradouro l
                               LEFT JOIN ws_bairro b   ON b.id = l.bairro_id
                               LEFT JOIN ws_cidade ci  ON ci.id = b.cidade_id
                               LEFT JOIN ws_uf u       ON u.id = ci.uf_id
                               LEFT JOIN ws_cep ce     ON ce.id = COALESCE(l.cep_id, ci.cep_id)
                               WHERE l.id=?");
            $r->execute([$out['logradouro_id']]);
            if ($c = $r->fetch()) {
                foreach (['logradouro','bairro','cidade','uf'] as $k)
                    if (!empty($c[$k])) $out[$k] = (string)$c[$k];
                if (!empty($c['cep'])) $out['cep'] = substr($c['cep'],0,5) . '-' . substr($c['cep'],5);
            }
        }
    } catch (Throwable $e) {}
    return $out;
}

/**
 * Preenche as tabelas normalizadas a partir do texto que já está nos clientes e contratos.
 *
 * Roda uma vez (e é idempotente: rodar de novo não duplica, porque tudo passa pelos resolvedores).
 * Não apaga e não altera o texto existente — só cria os vínculos que faltavam. Um cliente cujo
 * endereço não dê para interpretar simplesmente fica sem vínculo, e continua funcionando pelo
 * texto, como antes.
 *
 * @return array contagens, para a tela de manutenção mostrar o que foi feito.
 */
function ws_end_migrar(PDO $db, int $limite = 100000): array {
    $r = ['clientes'=>0,'contratos'=>0,'logradouros'=>0,'bairros'=>0,'cidades'=>0];
    ws_endereco_preparar($db);

    try {
        $antes = function (string $t) use ($db): int {
            try { return (int)$db->query("SELECT COUNT(*) FROM $t")->fetchColumn(); } catch (Throwable $e) { return 0; }
        };
        $l0 = $antes('ws_logradouro'); $b0 = $antes('ws_bairro'); $c0 = $antes('ws_cidade');

        // CLIENTES sem vínculo, mas com rua escrita.
        $q = $db->query("SELECT id, cep, logradouro, bairro, cidade, uf FROM ws_cliente
                         WHERE logradouro_id IS NULL AND COALESCE(logradouro,'')<>'' LIMIT $limite");
        $upd = $db->prepare("UPDATE ws_cliente SET logradouro_id=?, cidade=?, bairro=?, logradouro=?, uf=?, cep=?, uf_id=? WHERE id=?");
        foreach ($q as $c) {
            $e = ws_end_resolver($db, $c);
            if (!$e['logradouro_id']) continue;
            $upd->execute([$e['logradouro_id'], $e['cidade'], $e['bairro'], $e['logradouro'], $e['uf'], $e['cep'], $e['uf_id'], (int)$c['id']]);
            $r['clientes']++;
        }

        // CONTRATOS: endereço de INSTALAÇÃO, que pode ser diferente do endereço de cobrança.
        $q2 = $db->query("SELECT id, inst_cep cep, inst_logradouro logradouro, inst_bairro bairro,
                                 inst_cidade cidade, inst_uf uf FROM ws_contrato
                          WHERE inst_logradouro_id IS NULL AND COALESCE(inst_logradouro,'')<>'' LIMIT $limite");
        $upd2 = $db->prepare("UPDATE ws_contrato SET inst_logradouro_id=?, inst_cidade=?, inst_bairro=?,
                              inst_logradouro=?, inst_uf=?, inst_cep=?, inst_uf_id=? WHERE id=?");
        foreach ($q2 as $c) {
            $e = ws_end_resolver($db, $c);
            if (!$e['logradouro_id']) continue;
            $upd2->execute([$e['logradouro_id'], $e['cidade'], $e['bairro'], $e['logradouro'], $e['uf'], $e['cep'], $e['uf_id'], (int)$c['id']]);
            $r['contratos']++;
        }

        $r['logradouros'] = $antes('ws_logradouro') - $l0;
        $r['bairros']     = $antes('ws_bairro')     - $b0;
        $r['cidades']     = $antes('ws_cidade')     - $c0;
    } catch (Throwable $e) { $r['erro'] = $e->getMessage(); }
    return $r;
}

/* =================================================================================================
 * LEITURA DO ENDEREÇO A PARTIR DAS TABELAS NORMALIZADAS
 * -------------------------------------------------------------------------------------------------
 * Um gerador de SQL, usado por TODAS as leituras de endereço do sistema.
 *
 * POR QUE UM GERADOR, E NÃO O JOIN ESCRITO EM CADA CONSULTA
 * São sete lugares que leem endereço de cliente: boleto, NFS-e, gateway de cobrança, documentos,
 * mensagens, portal do assinante e a ficha. Escrever a mesma cadeia de cinco LEFT JOIN em sete
 * consultas é garantia de que elas vão divergir: alguém acrescenta o CEP num lugar e esquece nos
 * outros seis, e o boleto sai sem CEP sem ninguém saber por quê. Com o gerador, corrigir a cadeia
 * num ponto corrige as sete.
 *
 * POR QUE LEFT JOIN, e não JOIN
 * Cliente sem endereço vinculado (cadastro incompleto, importação que não deu para interpretar)
 * TEM de continuar aparecendo, com o endereço vazio. Com JOIN, ele desapareceria da lista, da
 * cobrança e do portal — um cliente que some do sistema é infinitamente pior que um endereço em
 * branco.
 *
 * OS APELIDOS (wl, wb, wc, wu, wp) têm prefixo `w` de propósito: as consultas do sistema já usam
 * c, ct, f, p, e reaproveitar um deles quebraria a consulta de quem chamar.
 */

/** A cadeia de LEFT JOIN que resolve o endereço a partir de <alias>.<coluna com o código>. */
function ws_end_sql_join(string $alias = 'c', string $coluna = 'logradouro_id'): string {
    return " LEFT JOIN ws_logradouro wl ON wl.id = $alias.$coluna"
         . " LEFT JOIN ws_bairro     wb ON wb.id = wl.bairro_id"
         . " LEFT JOIN ws_cidade     wc ON wc.id = wb.cidade_id"
         . " LEFT JOIN ws_uf         wu ON wu.id = wc.uf_id"
         . " LEFT JOIN ws_cep        wp ON wp.id = COALESCE(wl.cep_id, wc.cep_id)";
}

/**
 * Os campos de endereço, com os MESMOS nomes que as colunas de texto tinham.
 *
 * Isto é o que permite migrar as sete leituras sem reescrever o que vem depois delas: o código que
 * usava `$f['logradouro']` e `$f['cidade']` continua valendo, porque o apelido da coluna é igual.
 * Só a origem do dado mudou — antes era texto copiado no cliente, agora é o cadastro.
 *
 * O CEP é remontado com o traço (55000-000) porque é assim que ele é impresso em boleto e nota.
 * Guardar só os oito dígitos e formatar na leitura evita ter "55000000" e "55000-000" como dois
 * CEPs diferentes, que era parte do mesmo problema.
 *
 * @param string $prefixo 'inst_' para o endereço de instalação do contrato.
 */
function ws_end_sql_campos(string $prefixo = ''): string {
    $p = $prefixo;
    return " wl.nome AS {$p}logradouro,"
         . " wb.nome AS {$p}bairro,"
         . " wc.nome AS {$p}cidade,"
         . " wu.sigla AS {$p}uf,"
         . " CASE WHEN wp.cep IS NULL THEN NULL ELSE CONCAT(SUBSTRING(wp.cep,1,5),'-',SUBSTRING(wp.cep,6,3)) END AS {$p}cep";
}

/**
 * Endereço de um cliente já montado, para quem não está fazendo consulta própria.
 *
 * Devolve sempre as sete chaves (logradouro, numero, complemento, bairro, cidade, uf, cep), mesmo
 * quando o cliente não tem vínculo — aí vêm vazias. Quem chama nunca precisa testar se a chave
 * existe, o que é a origem de metade dos avisos de "índice indefinido".
 */
function ws_end_cliente(PDO $db, int $clienteId): array {
    $vazio = ['logradouro'=>'','numero'=>'','complemento'=>'','bairro'=>'','cidade'=>'','uf'=>'','cep'=>''];
    if ($clienteId <= 0) return $vazio;
    try {
        $st = $db->prepare("SELECT c.numero, c.complemento," . ws_end_sql_campos()
                         . " FROM ws_cliente c" . ws_end_sql_join('c') . " WHERE c.id=?");
        $st->execute([$clienteId]);
        $r = $st->fetch();
        if (!$r) return $vazio;
        foreach ($vazio as $k => $_) $vazio[$k] = (string)($r[$k] ?? '');
        return $vazio;
    } catch (Throwable $e) { return $vazio; }
}

/** Uma linha: "RUA X, 123 - CENTRO - CIDADE/UF". Usada em recibo, portal e mensagem. */
function ws_end_uma_linha(array $e): string {
    $rua = trim(($e['logradouro'] ?? '') . (!empty($e['numero']) ? ', ' . $e['numero'] : ''));
    $partes = array_filter([$rua, trim((string)($e['bairro'] ?? '')),
        trim(($e['cidade'] ?? '') . (!empty($e['uf']) ? '/' . $e['uf'] : ''))]);
    return implode(' - ', $partes);
}

/**
 * Completa uma linha de cliente com o endereço vindo do CADASTRO normalizado.
 *
 * POR QUE ESTA FUNÇÃO EXISTE
 * Três consumidores críticos — gateway de cobrança (celcash), nota fiscal (nfse) e os modelos de
 * documento — não fazem consulta própria: recebem a linha do cliente pronta de quem os chamou. São
 * sete pontos no sistema que carregam essa linha. Reescrever a consulta de cada um espalharia a
 * cadeia de JOIN por sete lugares que fatalmente iriam divergir.
 *
 * Aqui é um só: quem carregou a linha chama isto, e o endereço entra com as MESMAS chaves de antes
 * (logradouro, numero, complemento, bairro, cidade, uf, cep). Nada do que vem depois muda.
 *
 * PRESERVA O QUE JÁ ESTIVER PREENCHIDO na linha recebida: durante a transição, um cliente ainda
 * sem vínculo continua com o endereço que tinha, em vez de ficar em branco no boleto. Endereço em
 * branco numa nota fiscal é problema com a prefeitura, não detalhe de tela.
 */
function ws_end_enriquecer(PDO $db, array $cliente): array {
    $cid = (int)($cliente['id'] ?? $cliente['cliente_id'] ?? 0);
    if ($cid <= 0) return $cliente;
    $e = ws_end_cliente($db, $cid);
    foreach (['logradouro','numero','complemento','bairro','cidade','uf','cep'] as $k) {
        if ($e[$k] !== '') $cliente[$k] = $e[$k];
        elseif (!array_key_exists($k, $cliente)) $cliente[$k] = '';
    }
    return $cliente;
}

/* =================================================================================================
 * APOSENTAR AS COLUNAS DE TEXTO
 * -------------------------------------------------------------------------------------------------
 * Fechado o item: nenhuma leitura do sistema depende mais de ws_cliente.logradouro / .bairro /
 * .cidade / .uf / .cep — todas passam pelo cadastro normalizado. As colunas podem sair.
 *
 * POR QUE RENOMEAR E NÃO APAGAR
 * `DROP COLUMN` num banco com 1.600 clientes é irreversível: o dado sai e só volta de backup.
 * `RENAME` tira a coluna de circulação e mantém o conteúdo intacto — e tem duas vantagens que o
 * DROP não tem:
 *
 *   1. VOLTA EM UM CLIQUE. Se alguma leitura escapou da varredura, é só restaurar.
 *   2. FALHA ALTO. Uma consulta que ainda use a coluna passa a dar erro de SQL — que hoje APARECE
 *      na tela, porque as páginas mostram o erro em vez de sumir. Com DROP o comportamento seria o
 *      mesmo erro, mas sem caminho de volta. Falhar alto e reversível é o par certo.
 *
 * POR QUE É UM BOTÃO E NÃO PARTE DA ATUALIZAÇÃO
 * Mudança de estrutura irreversível não deve acontecer sozinha durante uma atualização, no meio do
 * expediente, num banco que fatura. Quem aciona escolhe a hora.
 */

/** Quais colunas de texto de endereço ainda estão em circulação. */
function ws_end_colunas_texto(): array {
    return [
        'ws_cliente'  => ['cep', 'logradouro', 'bairro', 'cidade', 'uf'],
        'ws_contrato' => ['inst_cep', 'inst_logradouro', 'inst_bairro', 'inst_cidade', 'inst_uf'],
    ];
}

/** Sufixo das colunas aposentadas. O nome diz o que é e por que está ali. */
const WS_END_SUFIXO = '_txt_aposentado';

/**
 * A coluna de texto ainda existe (e portanto ainda deve ser gravada)?
 *
 * Consultado pelas telas de gravação: enquanto existir, continua sendo mantida como cópia de
 * leitura; aposentada, deixa de ser escrita. É o que permite aposentar sem alterar mais nada, e
 * restaurar do mesmo jeito.
 */
function ws_end_texto_ativo(PDO $db): bool {
    static $ativo = null;
    if ($ativo !== null) return $ativo;
    try {
        $n = (int)$db->query("SELECT COUNT(*) FROM information_schema.columns
                              WHERE table_schema=DATABASE() AND table_name='ws_cliente' AND column_name='cidade'")->fetchColumn();
        return $ativo = ($n > 0);
    } catch (Throwable $e) { return $ativo = true; }   // na dúvida, continua gravando
}

/** Aposenta (renomeia) as colunas de texto. Reversível por ws_end_texto_restaurar(). */
function ws_end_texto_aposentar(PDO $db): array {
    $r = ['renomeadas' => 0, 'erros' => []];
    foreach (ws_end_colunas_texto() as $tab => $cols) {
        foreach ($cols as $c) {
            $novo = $c . WS_END_SUFIXO;
            try {
                $q = $db->prepare("SELECT COLUMN_TYPE FROM information_schema.columns
                                   WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
                $q->execute([$tab, $c]);
                $tipo = (string)$q->fetchColumn();
                if ($tipo === '') continue;               // já aposentada
                // CHANGE (e não RENAME COLUMN) porque o MariaDB 10.2 do Debian antigo não tem o RENAME.
                $db->exec("ALTER TABLE `$tab` CHANGE `$c` `$novo` $tipo NULL DEFAULT NULL");
                $r['renomeadas']++;
            } catch (Throwable $e) { $r['erros'][] = "$tab.$c: " . $e->getMessage(); }
        }
    }
    return $r;
}

/** Devolve as colunas de texto à circulação, com o conteúdo que tinham. */
function ws_end_texto_restaurar(PDO $db): array {
    $r = ['restauradas' => 0, 'erros' => []];
    foreach (ws_end_colunas_texto() as $tab => $cols) {
        foreach ($cols as $c) {
            $velho = $c . WS_END_SUFIXO;
            try {
                $q = $db->prepare("SELECT COLUMN_TYPE FROM information_schema.columns
                                   WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
                $q->execute([$tab, $velho]);
                $tipo = (string)$q->fetchColumn();
                if ($tipo === '') continue;
                $db->exec("ALTER TABLE `$tab` CHANGE `$velho` `$c` $tipo NULL DEFAULT NULL");
                $r['restauradas']++;
            } catch (Throwable $e) { $r['erros'][] = "$tab.$velho: " . $e->getMessage(); }
        }
    }
    return $r;
}
