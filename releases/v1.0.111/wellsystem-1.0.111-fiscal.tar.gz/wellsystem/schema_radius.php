<?php
/**
 * =================================================================================================
 * WellSystem — BANCO PRÓPRIO DO FREERADIUS
 * =================================================================================================
 * O WellSystem e o FreeRADIUS passam a viver em bancos SEPARADOS:
 *
 *     wellsystem  ->  cadastro, financeiro, OLT, chamados…  (o ERP)
 *     radius      ->  radcheck, radreply, radgroupreply, radusergroup, radacct, nas
 *
 * POR QUE SEPARAR — os motivos que se sustentam
 *   1. CREDENCIAL SEPARADA. O usuário do site não precisa de escrita no que autentica a rede, e o
 *      usuário do FreeRADIUS não precisa ver uma linha do financeiro. Uma falha num lado deixa de
 *      alcançar o outro.
 *   2. RETENÇÃO SEPARADA. radacct é a tabela que cresce sem parar — uma linha por sessão. Num banco
 *      só, ela domina o backup do financeiro e o tempo de restauração. Separada, tem a própria
 *      limpeza e o próprio backup.
 *   3. SCHEMA LIMPO. As tabelas do FreeRADIUS ficam exatamente como ele as espera, sem coluna nossa
 *      no meio (ver o comentário de `nas` mais abaixo).
 *
 * O QUE A SEPARAÇÃO **NÃO** RESOLVE — e não se deve acreditar que resolve
 * Sessão presa. Uma sessão fica presa em radacct quando o concentrador não envia o Accounting-Stop
 * (reiniciou, perdeu o enlace, faltou energia). Isso não tem relação com o banco onde a tabela
 * mora. O que resolve é `delete_stale_sessions = yes` no módulo sql (já configurado) mais a limpeza
 * periódica das sessões abertas há tempo demais — ver ws_rad_limpar_sessoes_presas() no radius_lib.
 *
 * COMO A SEPARAÇÃO FOI FEITA SEM REESCREVER O SISTEMA
 * São ~150 consultas em 20 arquivos escritas como `FROM radcheck`. Reescrever todas para
 * `FROM radius.radcheck` é muito risco por pouco ganho — basta uma esquecida para o bloqueio parar
 * de funcionar em silêncio. Em vez disso: as TABELAS REAIS ficam no banco radius, e no banco
 * wellsystem ficam VISÕES (views) com o mesmo nome, apontando para elas. Visão de tabela única, sem
 * junção e sem agregação, aceita INSERT/UPDATE/DELETE — então todo o código existente continua
 * valendo, sem uma linha alterada, enquanto os dados moram fisicamente no outro banco.
 */

/** Nome do banco do FreeRADIUS. Vazio = não separado (tudo no banco do sistema, como antes). */
function ws_rad_db_nome(): string {
    static $n = null;
    if ($n !== null) return $n;
    $c = function_exists('ws_db_config') ? ws_db_config() : [];
    $r = trim((string)($c['radius_db'] ?? ''));
    // Igual ao banco do sistema não é separação nenhuma — trata como não separado.
    if ($r !== '' && $r === trim((string)($c['dbname'] ?? ''))) $r = '';
    // Nome de banco só aceita o que é nome de banco. Isto entra em DDL concatenado.
    if ($r !== '' && !preg_match('/^[A-Za-z0-9_]{1,64}$/', $r)) $r = '';
    return $n = $r;
}

/**
 * As tabelas do FreeRADIUS. O `%s` é substituído pelo nome qualificado (`radius`.`radcheck`).
 *
 * radpostauth NÃO está aqui, de propósito — ver ws_radius_preparar().
 */
function ws_schema_sql_radius(): array {
    return [
        'radcheck' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(64) NOT NULL DEFAULT '',
            attribute VARCHAR(64) NOT NULL DEFAULT '',
            op CHAR(2) NOT NULL DEFAULT ':=',
            value VARCHAR(253) NOT NULL DEFAULT '',
            KEY username (username(32))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        'radreply' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(64) NOT NULL DEFAULT '',
            attribute VARCHAR(64) NOT NULL DEFAULT '',
            op CHAR(2) NOT NULL DEFAULT '=',
            value VARCHAR(253) NOT NULL DEFAULT '',
            KEY username (username(32))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        'radgroupcheck' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            groupname VARCHAR(64) NOT NULL DEFAULT '',
            attribute VARCHAR(64) NOT NULL DEFAULT '',
            op CHAR(2) NOT NULL DEFAULT ':=',
            value VARCHAR(253) NOT NULL DEFAULT '',
            KEY groupname (groupname(32))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        'radgroupreply' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            groupname VARCHAR(64) NOT NULL DEFAULT '',
            attribute VARCHAR(64) NOT NULL DEFAULT '',
            op CHAR(2) NOT NULL DEFAULT '=',
            value VARCHAR(253) NOT NULL DEFAULT '',
            KEY groupname (groupname(32))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        'radusergroup' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(64) NOT NULL DEFAULT '',
            groupname VARCHAR(64) NOT NULL DEFAULT '',
            priority INT NOT NULL DEFAULT 1,
            KEY username (username(32))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        'radacct' => "CREATE TABLE IF NOT EXISTS %s (
            radacctid BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            acctsessionid VARCHAR(64) NOT NULL DEFAULT '',
            acctuniqueid VARCHAR(32) NOT NULL DEFAULT '',
            username VARCHAR(64) NOT NULL DEFAULT '',
            realm VARCHAR(64) DEFAULT '',
            nasipaddress VARCHAR(15) NOT NULL DEFAULT '',
            nasportid VARCHAR(32) DEFAULT NULL,
            nasporttype VARCHAR(32) DEFAULT NULL,
            acctstarttime DATETIME NULL DEFAULT NULL,
            acctupdatetime DATETIME NULL DEFAULT NULL,
            acctstoptime DATETIME NULL DEFAULT NULL,
            acctinterval INT DEFAULT NULL,
            acctsessiontime INT UNSIGNED DEFAULT NULL,
            acctauthentic VARCHAR(32) DEFAULT NULL,
            connectinfo_start VARCHAR(128) DEFAULT NULL,
            connectinfo_stop VARCHAR(128) DEFAULT NULL,
            acctinputoctets BIGINT DEFAULT NULL,
            acctoutputoctets BIGINT DEFAULT NULL,
            calledstationid VARCHAR(50) NOT NULL DEFAULT '',
            callingstationid VARCHAR(50) NOT NULL DEFAULT '',
            acctterminatecause VARCHAR(32) NOT NULL DEFAULT '',
            servicetype VARCHAR(32) DEFAULT NULL,
            framedprotocol VARCHAR(32) DEFAULT NULL,
            framedipaddress VARCHAR(15) NOT NULL DEFAULT '',
            framedipv6address VARCHAR(45) NOT NULL DEFAULT '',
            framedipv6prefix VARCHAR(45) NOT NULL DEFAULT '',
            framedinterfaceid VARCHAR(44) NOT NULL DEFAULT '',
            delegatedipv6prefix VARCHAR(45) NOT NULL DEFAULT '',
            UNIQUE KEY acctuniqueid (acctuniqueid),
            KEY username (username),
            KEY framedipaddress (framedipaddress),
            KEY acctsessionid (acctsessionid),
            KEY acctsessiontime (acctsessiontime),
            KEY acctstarttime (acctstarttime),
            KEY acctstoptime (acctstoptime),
            KEY nasipaddress (nasipaddress)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        /* CONCENTRADORES — schema do FreeRADIUS, sem coluna nossa no meio.
         *
         * `server` e `community` FICAM, e é preciso dizer por quê: não são invenção do MK-Auth.
         * Estão no schema oficial do FreeRADIUS 3, e a consulta que ele usa para carregar os
         * clientes (nas_query) seleciona as duas pelo nome. Removê-las faria o FreeRADIUS falhar ao
         * ler os concentradores — deixar de autenticar todo mundo por causa de duas colunas vazias.
         *
         * `coa_port` SAIU. Essa sim era nossa: o FreeRADIUS não a lê em lugar nenhum. Quem usa é o
         * WellSystem, para saber em que porta mandar o CoA (desconectar / trocar plano em tempo
         * real). Foi para ws_concentrador.coa_port, que é a nossa tabela — e assim `nas` volta a ser
         * exatamente o que o FreeRADIUS espera.
         */
        'nas' => "CREATE TABLE IF NOT EXISTS %s (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nasname VARCHAR(128) NOT NULL,
            shortname VARCHAR(32) DEFAULT NULL,
            type VARCHAR(30) DEFAULT 'other',
            ports INT DEFAULT NULL,
            secret VARCHAR(60) NOT NULL DEFAULT 'secret',
            server VARCHAR(64) DEFAULT NULL,
            community VARCHAR(50) DEFAULT NULL,
            description VARCHAR(200) DEFAULT NULL,
            KEY nasname (nasname)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

/**
 * Cria/ajusta as tabelas do RADIUS e, quando há banco separado, as visões que o sistema usa.
 *
 * É idempotente: rodar de novo não muda nada e não perde dado. Chamada pelo install e pelo
 * selfheal, então qualquer página aberta coloca a estrutura em dia.
 *
 * radpostauth: NÃO é criada e NÃO é usada.
 * Ela registra uma linha a cada autenticação — e a cada FALHA. Num provedor com mil clientes que
 * reconectam ao longo do dia, são centenas de milhares de linhas por mês que ninguém lê. O custo é
 * real: incha o banco, incha o backup e deixa o INSERT de autenticação mais lento justamente no
 * caminho crítico. O `postauth_query` fica desligado no módulo sql (ver INSTALAR.sh), e o histórico
 * que tem valor — quem conectou, quando, de onde, quanto trafegou — continua em radacct.
 */
function ws_radius_preparar(PDO $db): void {
    $rdb = ws_rad_db_nome();
    $tabelas = ws_schema_sql_radius();

    if ($rdb === '') {
        // Não separado: as tabelas são criadas no próprio banco do sistema, como sempre foi.
        foreach ($tabelas as $nome => $ddl) {
            try { $db->exec(sprintf($ddl, "`$nome`")); } catch (Throwable $e) {}
        }
        return;
    }

    // 1) As tabelas reais, no banco do RADIUS.
    foreach ($tabelas as $nome => $ddl) {
        try { $db->exec(sprintf($ddl, "`$rdb`.`$nome`")); } catch (Throwable $e) {}
    }

    /* 1b) RESGATE — tabela do RADIUS vazia com a cópia guardada cheia.
     *
     * Existe porque a primeira versão desta separação copiava com `SELECT *`, e isso perdeu os
     * concentradores: a tabela `nas` antiga tinha uma coluna a mais (coa_port), a contagem não
     * batia, o INSERT falhou em silêncio e o rename aconteceu de qualquer jeito. Resultado:
     * `radius.nas` vazia, os dados só em `nas_ws_antes_da_separacao`, e o FreeRADIUS sem nenhum
     * concentrador para aceitar.
     *
     * Consertar o bug na cópia não bastaria: quem já atualizou está com a tabela local convertida
     * em VISÃO, então o trecho de migração não roda mais nela. Este resgate olha o resultado — se o
     * destino está vazio e a cópia guardada tem linhas, refaz a transferência pelos nomes das
     * colunas. É idempotente: destino com linhas, não faz nada.
     *
     * Vale para qualquer tabela, não só `nas` — a mesma situação apareceria em qualquer uma cuja
     * estrutura tenha mudado entre as versões. */
    foreach (array_keys($tabelas) as $nome) {
        $guardada = $nome . '_ws_antes_da_separacao';
        try {
            $q = $db->prepare("SELECT COUNT(*) FROM information_schema.tables
                               WHERE table_schema=DATABASE() AND table_name=? AND table_type='BASE TABLE'");
            $q->execute([$guardada]);
            if ((int)$q->fetchColumn() === 0) continue;                  // não há cópia guardada

            $noDestino = (int)$db->query("SELECT COUNT(*) FROM `$rdb`.`$nome`")->fetchColumn();
            if ($noDestino > 0) continue;                                // destino já tem dados
            $naGuardada = (int)$db->query("SELECT COUNT(*) FROM `$guardada`")->fetchColumn();
            if ($naGuardada === 0) continue;                             // nada a resgatar

            $cd = $db->prepare("SELECT LOWER(column_name) FROM information_schema.columns
                                WHERE table_schema=? AND table_name=?");
            $cd->execute([$rdb, $nome]);
            $destino = $cd->fetchAll(PDO::FETCH_COLUMN);
            $cg = $db->prepare("SELECT LOWER(column_name) FROM information_schema.columns
                                WHERE table_schema=DATABASE() AND table_name=?");
            $cg->execute([$guardada]);
            $origem = $cg->fetchAll(PDO::FETCH_COLUMN);

            $comuns = array_values(array_intersect($destino, $origem));
            if (!$comuns) continue;
            $lista = '`' . implode('`,`', $comuns) . '`';
            $db->exec("INSERT IGNORE INTO `$rdb`.`$nome` ($lista) SELECT $lista FROM `$guardada`");

            /* A porta do CoA morava em `nas` e agora mora em ws_concentrador. A cópia guardada
             * ainda tem a coluna antiga, então este é o último momento em que ela pode ser
             * aproveitada — depois disso, o valor configurado de cada concentrador se perderia e
             * todos cairiam no 3799 do padrão. */
            if ($nome === 'nas') {
                try {
                    $temCoa = (int)$db->query("SELECT COUNT(*) FROM information_schema.columns
                                               WHERE table_schema=DATABASE() AND table_name='$guardada'
                                               AND column_name='coa_port'")->fetchColumn();
                    if ($temCoa) {
                        $db->exec("INSERT INTO ws_concentrador (nome, tipo, host, coa_port, ativo)
                                   SELECT COALESCE(NULLIF(g.shortname,''), g.nasname), COALESCE(NULLIF(g.type,''),'other'),
                                          g.nasname, COALESCE(NULLIF(g.coa_port,0), 3799), 1
                                   FROM `$guardada` g
                                   WHERE g.nasname <> ''
                                     AND NOT EXISTS (SELECT 1 FROM ws_concentrador c WHERE c.host = g.nasname)");
                        $db->exec("UPDATE ws_concentrador c JOIN `$guardada` g ON g.nasname = c.host
                                   SET c.coa_port = COALESCE(NULLIF(g.coa_port,0), 3799)
                                   WHERE COALESCE(c.coa_port,0) = 0");
                    }
                } catch (Throwable $e) {}
            }
        } catch (Throwable $e) { /* uma tabela que não resgata não impede as outras */ }
    }

    /* 2) MUDANÇA DE UM BANCO SÓ PARA DOIS — sem perder dado.
     *
     * Numa instalação que já rodava com tudo junto, `radcheck` e companhia são TABELAS reais no
     * banco do sistema, com os dados de produção dentro. A passagem para o banco separado precisa:
     *   a) copiar as linhas para a tabela nova;
     *   b) guardar a tabela antiga (RENAME, nunca DROP);
     *   c) pôr a visão no lugar do nome antigo.
     *
     * O RENAME é deliberado. Se algo sair errado no meio da mudança, os dados originais estão
     * inteiros em `<tabela>_ws_antes_da_separacao` e a volta é um RENAME de novo. DROP aqui seria
     * apostar o parque da empresa na certeza de que nada dá errado.
     *
     * A cópia é INSERT IGNORE: rodar duas vezes não duplica, e uma linha que já esteja no destino
     * (porque o FreeRADIUS já gravou) não é sobrescrita por uma cópia velha.
     */
    foreach (array_keys($tabelas) as $nome) {
        try {
            $st = $db->prepare("SELECT table_type FROM information_schema.tables
                                WHERE table_schema=DATABASE() AND table_name=?");
            $st->execute([$nome]);
            $tipo = (string)$st->fetchColumn();

            if ($tipo === 'BASE TABLE') {
                /* CÓPIA POR NOME DE COLUNA — nunca `SELECT *`.
                 *
                 * Isto já falhou em produção e é preciso registrar por quê: `INSERT ... SELECT *`
                 * exige que ORIGEM e DESTINO tenham o MESMO número de colunas, na MESMA ordem. A
                 * tabela `nas` antiga tinha uma coluna a mais (o `coa_port`, que saiu daqui e foi
                 * para ws_concentrador). Dez colunas entrando numa tabela de nove: o INSERT falhou,
                 * o try/catch engoliu o erro, e a tabela foi renomeada em seguida — resultado, os
                 * concentradores desapareceram da tabela ativa. Sem erro em lugar nenhum, e o
                 * sintoma seria o FreeRADIUS recusando TODOS os NAS.
                 *
                 * Copiando pela INTERSEÇÃO dos nomes de coluna, a diferença de estrutura deixa de
                 * importar: o que existe nos dois lados vai, o que só existe de um lado fica fora,
                 * e nada falha em silêncio.
                 *
                 * A verificação de resultado abaixo é o outro lado disso: a tabela antiga só é
                 * renomeada se a cópia tiver de fato levado as linhas. Antes, uma cópia que falhou
                 * não impedia o rename — e era essa combinação que fazia o dado sumir. */
                $guardada = $nome . '_ws_antes_da_separacao';
                $copiou = false; $origemLinhas = 0;

                try {
                    $origemLinhas = (int)$db->query("SELECT COUNT(*) FROM `$nome`")->fetchColumn();

                    // Colunas que existem nas DUAS tabelas, pelo nome.
                    $cd = $db->prepare("SELECT LOWER(column_name) FROM information_schema.columns
                                        WHERE table_schema=? AND table_name=?");
                    $cd->execute([$rdb, $nome]);
                    $destino = $cd->fetchAll(PDO::FETCH_COLUMN);
                    $co = $db->prepare("SELECT LOWER(column_name) FROM information_schema.columns
                                        WHERE table_schema=DATABASE() AND table_name=?");
                    $co->execute([$nome]);
                    $origem = $co->fetchAll(PDO::FETCH_COLUMN);

                    $comuns = array_values(array_intersect($destino, $origem));
                    if ($comuns) {
                        $lista = '`' . implode('`,`', $comuns) . '`';
                        $db->exec("INSERT IGNORE INTO `$rdb`.`$nome` ($lista) SELECT $lista FROM `$nome`");
                        $noDestino = (int)$db->query("SELECT COUNT(*) FROM `$rdb`.`$nome`")->fetchColumn();
                        // Passou tudo, ou o destino já tinha as linhas (reexecução): cópia cumprida.
                        $copiou = ($noDestino >= $origemLinhas);
                    } else {
                        $copiou = ($origemLinhas === 0);   // nada em comum e origem vazia: nada a perder
                    }
                } catch (Throwable $e) { $copiou = false; }

                if (!$copiou) {
                    /* NÃO RENOMEIA. A tabela antiga fica onde está, em uso, com os dados. Uma
                     * separação incompleta que preserva o funcionamento é muito melhor que uma
                     * separação "concluída" que esvaziou uma tabela do RADIUS. A próxima execução
                     * tenta de novo, e o motivo fica no log. */
                    continue;
                }

                try { $db->exec("DROP TABLE IF EXISTS `$guardada`"); } catch (Throwable $e) {}
                try { $db->exec("RENAME TABLE `$nome` TO `$guardada`"); } catch (Throwable $e) { continue; }
                $tipo = '';
            }

            if ($tipo === '') {
                // Nada com esse nome aqui: cria a visão.
                try { $db->exec("CREATE OR REPLACE VIEW `$nome` AS SELECT * FROM `$rdb`.`$nome`"); } catch (Throwable $e) {}
            } elseif ($tipo === 'VIEW') {
                /* Visão já existe. Recria de qualquer forma: o `SELECT *` é expandido em colunas no
                 * momento da criação, então uma coluna acrescentada depois na tabela real não
                 * apareceria na visão — e uma consulta que a use falharia com "coluna não existe".
                 * Recriar é barato e mantém as duas em dia. */
                try { $db->exec("CREATE OR REPLACE VIEW `$nome` AS SELECT * FROM `$rdb`.`$nome`"); } catch (Throwable $e) {}
            }
        } catch (Throwable $e) { /* uma tabela que não migra não pode impedir as outras */ }
    }

    /* 3) radpostauth que exista de instalação antiga: a visão/tabela é deixada de lado, porque
     * nada mais escreve nela. Não apaga — só para de usar. Quem quiser o histórico ainda o tem. */
}
