<?php
/**
 * WellSystem — Segurança/BI: score de inadimplência do cliente e helpers de backup.
 */
require_once __DIR__ . '/config.php';

/**
 * Score de crédito/inadimplência do cliente (0–100) a partir do histórico de faturas.
 * @return array [score, label, cor(classe da tag)]
 */
function ws_score_cliente(PDO $db, int $clienteId): array {
    $st = $db->prepare("SELECT
            SUM(status='pago' AND data_pagamento IS NOT NULL AND data_pagamento <= vencimento) em_dia,
            SUM(status='pago' AND data_pagamento IS NOT NULL AND data_pagamento >  vencimento) atraso,
            SUM(status IN('aberto','vencido') AND vencimento < CURDATE()) vencidas_abertas,
            COUNT(*) total
        FROM ws_fatura WHERE cliente_id=?");
    $st->execute([$clienteId]); $f = $st->fetch();

    $total = (int)($f['total'] ?? 0);
    if ($total === 0) return [100, 'sem histórico', 'inativo'];

    $emDia = (int)$f['em_dia']; $atraso = (int)$f['atraso']; $abertasVenc = (int)$f['vencidas_abertas'];
    $pagas = $emDia + $atraso;

    $score = 100;
    if ($pagas > 0) $score -= (int)round(($atraso / $pagas) * 35);   // % de pagamentos em atraso
    $score -= min(45, $abertasVenc * 15);                            // faturas vencidas em aberto
    $score = max(0, min(100, $score));

    if ($score >= 80) return [$score, 'bom pagador', 'ativo'];
    if ($score >= 50) return [$score, 'regular', 'suspenso'];
    return [$score, 'risco', 'bloqueado'];
}

/** Diretório de backups (criado e protegido pelo próprio código). */
function ws_backup_dir(): string {
    $d = WS_CACHE . '/backups';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    $ht = $d . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    return $d;
}

/**
 * Gera um backup do banco. Usa mysqldump se disponível; senão, dump em PHP (INSERTs).
 * @return array [ok, arquivo, erro]
 */
function ws_backup_gerar(bool $enviar = true): array {
    $c = ws_db_config();
    $dir = ws_backup_dir();
    $nome = 'wellsystem_' . date('Ymd_His') . '.sql';
    $caminho = $dir . '/' . $nome;

    $dump = trim((string)@shell_exec('command -v mysqldump 2>/dev/null'));
    if ($dump !== '') {
        $cmd = sprintf('%s --no-tablespaces -h%s -P%d -u%s %s %s > %s 2>/dev/null',
            escapeshellcmd($dump), escapeshellarg($c['host']), (int)$c['porta'],
            escapeshellarg($c['user']),
            $c['pass'] !== '' ? '-p' . escapeshellarg($c['pass']) : '',
            escapeshellarg($c['dbname']), escapeshellarg($caminho));
        @shell_exec($cmd);
        if (is_file($caminho) && filesize($caminho) > 0) {
            ws_backup_gzip($caminho);
            $arquivo = basename($caminho) . '.gz';
            return ['ok' => true, 'arquivo' => $arquivo, 'envio' => $enviar ? ws_backup_gerar_enviar($dir . '/' . $arquivo) : []];
        }
    }

    // Fallback: dump em PHP (estrutura + dados)
    try {
        $db = ws_db();
        $fh = fopen($caminho, 'w');
        fwrite($fh, "-- WellSystem backup " . date('c') . "\nSET FOREIGN_KEY_CHECKS=0;\n");
        foreach ($db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN) as $t) {
            $create = $db->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1] ?? '';
            fwrite($fh, "\nDROP TABLE IF EXISTS `$t`;\n$create;\n");
            $rows = $db->query("SELECT * FROM `$t`");
            while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                $cols = '`' . implode('`,`', array_keys($row)) . '`';
                $vals = implode(',', array_map(fn($v) => $v === null ? 'NULL' : $db->quote($v), array_values($row)));
                fwrite($fh, "INSERT INTO `$t` ($cols) VALUES ($vals);\n");
            }
        }
        fwrite($fh, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);
        ws_backup_gzip($caminho);
        $arquivo = basename($caminho) . '.gz';
        return ['ok' => true, 'arquivo' => $arquivo, 'envio' => $enviar ? ws_backup_gerar_enviar($dir . '/' . $arquivo) : []];
    } catch (Throwable $e) {
        return ['ok' => false, 'erro' => $e->getMessage()];
    }
}

/** Envia o backup gerado por ws_backup_gerar() pelos MESMOS destinos (e-mail/WhatsApp/Telegram/FTP)
 *  do backup "novo" (tela Backup → Destinos de envio / SMTP). ANTES, esta função (usada pelo cron
 *  de backup_run.php — o mesmo cron sugerido em INSTALACAO.md/README.md — e pelos botões "Gerar
 *  backup agora" de Provedor e Manutenção) só gravava o arquivo em disco e NUNCA tentava mandar por
 *  WhatsApp ou e-mail: o backup existia, mas ninguém era avisado — era exatamente isto que estava
 *  fazendo o envio "não ir" quando o cron rodava por aqui em vez de pelo radius_sync.php. */
function ws_backup_gerar_enviar(string $caminho): array {
    if (!is_file(__DIR__ . '/backup_lib.php')) return ['aviso' => 'backup_lib.php ausente — não deu para tentar o envio.'];
    require_once __DIR__ . '/backup_lib.php';
    if (!function_exists('ws_backup_enviar_padrao')) return ['aviso' => 'ws_backup_enviar_padrao ausente — não deu para tentar o envio.'];
    try {
        return ws_backup_enviar_padrao($caminho, 'legado(backup_run/gerar)');
    } catch (Throwable $e) {
        @file_put_contents(WS_CACHE . '/backup.log', date('Y-m-d H:i:s') . ' legado FALHOU: ' . $e->getMessage() . "\n", FILE_APPEND);
        return ['erro' => $e->getMessage()];
    }
}

/** Compacta e apaga o .sql cru; mantém os últimos 15 backups. */
function ws_backup_gzip(string $caminho): void {
    if (function_exists('gzopen')) {
        $gz = gzopen($caminho . '.gz', 'wb9'); $in = fopen($caminho, 'rb');
        while (!feof($in)) gzwrite($gz, fread($in, 1 << 16));
        gzclose($gz); fclose($in); @unlink($caminho);
    }
    // rotação
    $arqs = glob(ws_backup_dir() . '/wellsystem_*.sql*') ?: [];
    rsort($arqs);
    foreach (array_slice($arqs, 15) as $velho) @unlink($velho);
}
