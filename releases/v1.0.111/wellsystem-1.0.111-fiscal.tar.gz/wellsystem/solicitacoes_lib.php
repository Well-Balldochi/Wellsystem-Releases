<?php
/**
 * WellSystem — SOLICITAÇÕES DA CENTRAL (fila de validação).
 *
 * Regra de negócio: o assinante NUNCA altera sozinho login, senha (PPPoE/IPoE), titularidade, endereço, CPF,
 * nascimento, e-mail ou telefone. Na Central ele só PEDE. O pedido cai aqui, aparece como aviso no topo do
 * WellSystem (🔔) e em Suporte → Solicitações da Central. Quem tem permissão APROVA ou RECUSA:
 *   - aprovou  -> a troca é aplicada automaticamente (cadastro e, nos logins/senhas, também o RADIUS);
 *   - recusou  -> nada muda e o assinante vê o motivo na Central.
 *
 * Segurança:
 *   - a senha nova espera CIFRADA (AES-256-GCM, chave própria em cache/sol.key, modo 0600) e é APAGADA
 *     da fila assim que o pedido é decidido; a tela do operador nunca mostra a senha;
 *   - a decisão "reserva" o pedido antes de aplicar (dois operadores não aplicam duas vezes);
 *   - ao aprovar, tudo é conferido de novo (login já usado, CPF de outro titular…): se não der, o pedido
 *     fica "falhou" com o motivo, e nada é aplicado pela metade.
 *
 * Tipos: contato · endereco · titularidade · login_pppoe · login_ipoe · senha_pppoe · senha_ipoe
 */

const WS_SOL_MARCA = '.sol_ok';

function ws_sol_tipos(): array {
    return [
        'contato'      => 'E-mail / telefones',
        'endereco'     => 'Endereço',
        'endereco_cobranca' => 'Endereço de cobrança',
        'titularidade' => 'Titularidade (nome, CPF/CNPJ, nascimento, RG)',
        'login_pppoe'  => 'Login PPPoE',
        'login_ipoe'   => 'Login IPoE',
        'senha_pppoe'  => 'Senha PPPoE',
        'senha_ipoe'   => 'Senha IPoE',
        // Pedido do robô do WhatsApp quando o cliente já usou o desbloqueio automático do mês (01/10/2026).
        'confianca'    => 'Desbloqueio em confiança (além do limite do mês)',
        // Pedidos do robô (01/10/2026): mexem em cobrança/velocidade, então a equipe aprova; ao aprovar, aplica sozinho.
        'vencimento'   => 'Troca do dia de vencimento',
        'plano'        => 'Troca de plano',
    ];
}
function ws_sol_rotulo(string $tipo): string { return ws_sol_tipos()[$tipo] ?? $tipo; }

/** Cria a tabela uma vez (marca em cache/ para não repetir o DDL a cada acesso). */
function ws_sol_garantir(PDO $db): void {
    $m = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/' . WS_SOL_MARCA;
    if (is_file($m)) return;
    $db->exec("CREATE TABLE IF NOT EXISTS ws_solicitacao (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        contrato_id INT DEFAULT NULL,
        tipo VARCHAR(30) NOT NULL,
        dados MEDIUMTEXT NOT NULL,
        status ENUM('pendente','aprovada','recusada','falhou') NOT NULL DEFAULT 'pendente',
        motivo VARCHAR(255) DEFAULT NULL,
        origem VARCHAR(20) NOT NULL DEFAULT 'central',
        ip VARCHAR(45) DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        decidido_em DATETIME DEFAULT NULL,
        decidido_por VARCHAR(80) DEFAULT NULL,
        INDEX idx_status (status, criado_em),
        INDEX idx_cliente (cliente_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    @file_put_contents($m, date('c'));
}

/* ------------------------------------------------------------------ senha em espera (cifrada) */
function ws_sol_chave(): string {
    $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/sol.key';
    if (!is_file($f)) { @file_put_contents($f, bin2hex(random_bytes(32)), LOCK_EX); @chmod($f, 0600); }
    $k = hex2bin(trim((string)@file_get_contents($f)));
    return ($k !== false && strlen($k) === 32) ? $k : '';
}
/** '' = não foi possível cifrar (sem OpenSSL/sem chave): quem chama RECUSA o pedido, nunca guarda em claro. */
function ws_sol_cifrar(string $texto): string {
    $k = ws_sol_chave();
    if ($k === '' || !function_exists('openssl_encrypt') || !in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) return '';
    $iv = random_bytes(12); $tag = '';
    $c = openssl_encrypt($texto, 'aes-256-gcm', $k, OPENSSL_RAW_DATA, $iv, $tag);
    return $c === false ? '' : base64_encode($iv . $tag . $c);
}
function ws_sol_decifrar(string $b64): string {
    $k = ws_sol_chave(); $r = base64_decode($b64, true);
    if ($k === '' || $r === false || strlen($r) < 29) return '';
    $p = openssl_decrypt(substr($r, 28), 'aes-256-gcm', $k, OPENSSL_RAW_DATA, substr($r, 0, 12), substr($r, 12, 16));
    return $p === false ? '' : $p;
}

/* ------------------------------------------------------------------ criar */
/**
 * @param array  $campos  campo => ['de' => atual, 'para' => novo]  (é o que o operador vê)
 * @param string $segredo texto cifrado (só nas senhas)
 * @return int id do pedido. Pedido igual ainda pendente (mesmo cliente/contrato/tipo) é SUBSTITUÍDO.
 */
function ws_sol_criar(PDO $db, int $clienteId, ?int $contratoId, string $tipo, array $campos, string $segredo = '', string $ctx = ''): int {
    if (!isset(ws_sol_tipos()[$tipo])) throw new InvalidArgumentException('tipo inválido');
    if (in_array($tipo, ['senha_pppoe', 'senha_ipoe'], true) && $segredo === '') throw new RuntimeException('senha sem cifra');
    ws_sol_garantir($db);
    $json = json_encode(['campos' => $campos, 'segredo' => $segredo, 'ctx' => $ctx], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $ip = mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    $q = $db->prepare("SELECT id FROM ws_solicitacao WHERE cliente_id=? AND tipo=? AND status='pendente' AND (contrato_id <=> ?) LIMIT 1");
    $q->execute([$clienteId, $tipo, $contratoId]); $id = (int)$q->fetchColumn();
    if ($id) {
        $db->prepare("UPDATE ws_solicitacao SET dados=?, ip=?, criado_em=NOW() WHERE id=?")->execute([$json, $ip, $id]);
    } else {
        $db->prepare("INSERT INTO ws_solicitacao (cliente_id,contrato_id,tipo,dados,ip) VALUES (?,?,?,?,?)")->execute([$clienteId, $contratoId, $tipo, $json, $ip]);
        $id = (int)$db->lastInsertId();
    }
    if (function_exists('ws_evento')) ws_evento($db, $clienteId, 'solicitacao', 'Cliente pediu ' . (stripos($ctx, 'robô') !== false ? 'pelo robô do WhatsApp' : 'pela Central') . ': ' . ws_sol_rotulo($tipo) . " (pedido #$id, aguardando validação).");
    return $id;
}

/* ------------------------------------------------------------------ consultas */
/** Pedidos aguardando validação (para o 🔔 do topo). Não cria tabela: sem marca = zero. */
function ws_sol_pendentes(PDO $db): int {
    static $n = null; if ($n !== null) return $n;
    $m = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/' . WS_SOL_MARCA;
    if (!is_file($m)) return $n = 0;
    try { return $n = (int)$db->query("SELECT COUNT(*) FROM ws_solicitacao WHERE status='pendente'")->fetchColumn(); } catch (Throwable $e) { return $n = 0; }
}
/** Aviso no topo do WellSystem: só aparece quando há pedido pendente. */
function ws_sol_chip(): string {
    try { $db = ws_db(); $n = ws_sol_pendentes($db); } catch (Throwable $e) { return ''; }
    if ($n < 1) return '';
    $t = $n . ' solicitaç' . ($n === 1 ? 'ão' : 'ões') . ' da Central aguardando validação';
    return '<a href="solicitacoes.php" class="ws-top-chip ws-sol-chip" title="' . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . '" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;'
         . 'background:var(--warn,#e6a100);color:#1b1b1b;font-weight:700;font-size:12.5px;text-decoration:none">🔔 <span>' . $n . '</span> <span>' . ($n === 1 ? 'solicitação' : 'solicitações') . '</span></a>';
}
/** Para a Central: quantos pedidos do cliente esperam e o que foi decidido nos últimos 7 dias. */
function ws_sol_do_cliente(PDO $db, int $clienteId): array {
    $m = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/' . WS_SOL_MARCA;
    if (!is_file($m)) return ['pendentes' => 0, 'decididas' => []];
    try {
        $q = $db->prepare("SELECT COUNT(*) FROM ws_solicitacao WHERE cliente_id=? AND status='pendente'"); $q->execute([$clienteId]); $p = (int)$q->fetchColumn();
        $q = $db->prepare("SELECT tipo,status,motivo FROM ws_solicitacao WHERE cliente_id=? AND status<>'pendente' AND decidido_em >= (NOW() - INTERVAL 7 DAY) ORDER BY decidido_em DESC LIMIT 5");
        $q->execute([$clienteId]);
        return ['pendentes' => $p, 'decididas' => $q->fetchAll(PDO::FETCH_ASSOC)];
    } catch (Throwable $e) { return ['pendentes' => 0, 'decididas' => []]; }
}
function ws_sol_pode_decidir(): bool { return function_exists('ws_nivel_acesso') && ws_nivel_acesso() >= 2; }

/* ------------------------------------------------------------------ aplicar (na aprovação) */
function ws_sol_login_valido(string $l): bool { return (bool)preg_match('/^[A-Za-z0-9._@-]{3,60}$/', $l); }
function ws_sol_login_em_uso(PDO $db, string $login, int $ignorarContrato = 0): bool {
    $q = $db->prepare("SELECT id FROM ws_contrato WHERE (login_pppoe=? OR login_ipoe=?) AND id<>? LIMIT 1");
    $q->execute([$login, $login, $ignorarContrato]); return (bool)$q->fetchColumn();
}

/** @return array [bool ok, string mensagem] — nada é aplicado pela metade: valida tudo antes de gravar. */
function ws_sol_aplicar(PDO $db, array $s): array {
    if (!function_exists('ws_rad_sync_contrato') && is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    $d = json_decode((string)$s['dados'], true) ?: []; $c = $d['campos'] ?? []; $cid = (int)$s['cliente_id'];
    $para = function (string $k) use ($c): string { return (string)($c[$k]['para'] ?? ''); };
    $tem  = function (string $k) use ($c): bool { return array_key_exists($k, $c); };
    $q = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $q->execute([$cid]); $cli = $q->fetch(PDO::FETCH_ASSOC);
    if (!$cli) return [false, 'Cliente não encontrado.'];

    switch ($s['tipo']) {
    case 'contato': {
        $email = $tem('email') ? ($para('email') ?: null) : $cli['email'];
        $cel   = $tem('celular') ? $para('celular') : $cli['celular'];
        $tel   = $tem('telefone') ? ($para('telefone') ?: null) : $cli['telefone'];
        if ($email !== null && $email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) return [false, 'E-mail inválido.'];
        $db->prepare("UPDATE ws_cliente SET email=?, celular=?, telefone=? WHERE id=?")->execute([$email, $cel, $tel, $cid]);
        return [true, 'Contato atualizado.'];
    }
    case 'titularidade': {
        $set = []; $val = [];
        if ($tem('nome'))       { $n = trim($para('nome')); if ($n === '') return [false, 'Nome vazio.']; $set[] = 'nome=?'; $val[] = mb_substr($n, 0, 160); }
        if ($tem('data_nasc'))  { $set[] = 'data_nasc=?'; $val[] = $para('data_nasc') ?: null; }
        if ($tem('rg_ie'))      { $set[] = 'rg_ie=?'; $val[] = mb_substr($para('rg_ie'), 0, 30) ?: null; }
        if ($tem('cpf_cnpj')) {
            $dig = preg_replace('/\D/', '', $para('cpf_cnpj'));
            if (!in_array(strlen($dig), [11, 14], true)) return [false, 'CPF/CNPJ inválido.'];
            $x = $db->prepare("SELECT id FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND id<>? AND titular_id IS NULL AND status<>'cancelado' LIMIT 1");
            $x->execute([$dig, $cid]); if ($outro = $x->fetchColumn()) return [false, "CPF/CNPJ já pertence ao cliente #$outro — trate a transferência manualmente."];
            $mascarado = strpbrk((string)$cli['cpf_cnpj'], '.-/') !== false && function_exists('h_doc');
            $set[] = 'cpf_cnpj=?'; $val[] = $mascarado ? h_doc($dig) : $dig;
        }
        if (!$set) return [false, 'Nada a aplicar.'];
        $val[] = $cid; $db->prepare('UPDATE ws_cliente SET ' . implode(',', $set) . ' WHERE id=?')->execute($val);
        return [true, 'Titularidade/cadastro atualizado.'];
    }
    case 'endereco': {
        if (is_file(__DIR__ . '/schema_endereco.php')) require_once __DIR__ . '/schema_endereco.php';
        if (!function_exists('ws_end_resolver')) return [false, 'Módulo de endereço indisponível.'];
        $a = ws_end_cliente($db, $cid); $n = [];
        foreach (['cep', 'logradouro', 'numero', 'complemento', 'bairro', 'cidade', 'uf'] as $k) $n[$k] = $tem($k) ? trim($para($k)) : trim((string)($a[$k] ?? ''));
        $e = ws_end_resolver($db, ['cep' => $n['cep'], 'logradouro' => $n['logradouro'], 'bairro' => $n['bairro'], 'cidade' => $n['cidade'], 'uf' => $n['uf']]);
        $set = ['numero' => mb_substr($n['numero'], 0, 20), 'complemento' => mb_substr($n['complemento'], 0, 80)];
        if ($e['logradouro_id']) $set['logradouro_id'] = $e['logradouro_id'];
        if ($e['uf_id'])         $set['uf_id'] = $e['uf_id'];
        if (ws_end_texto_ativo($db)) { foreach (['logradouro', 'bairro', 'cidade', 'uf', 'cep'] as $k) $set[$k] = $e[$k] !== '' ? $e[$k] : $n[$k]; }
        elseif (!$e['logradouro_id']) return [false, 'Rua não encontrada no cadastro de endereços — atualize manualmente no cliente.'];
        $cols = implode(',', array_map(function ($k) { return "$k=?"; }, array_keys($set)));
        $db->prepare("UPDATE ws_cliente SET $cols WHERE id=?")->execute(array_merge(array_values($set), [$cid]));
        return [true, 'Endereço atualizado.'];
    }
    case 'endereco_cobranca': {   // (01/10/2026) colunas cob_* do cliente; o de instalação não muda
        $set = [];
        foreach (['cep' => 10, 'logradouro' => 160, 'numero' => 20, 'complemento' => 80, 'bairro' => 80, 'cidade' => 80, 'uf' => 2] as $k => $max)
            if ($tem($k)) $set['cob_' . $k] = mb_substr($k === 'uf' ? mb_strtoupper(trim($para($k))) : trim($para($k)), 0, $max) ?: null;
        if (!$set) return [false, 'Nada para alterar.'];
        $db->prepare("UPDATE ws_cliente SET " . implode(',', array_map(fn($k) => "$k=?", array_keys($set))) . " WHERE id=?")->execute(array_merge(array_values($set), [$cid]));
        return [true, 'Endereço de cobrança atualizado.'];
    }
    case 'login_pppoe': case 'login_ipoe': {
        $col = $s['tipo'] === 'login_ipoe' ? 'login_ipoe' : 'login_pppoe';
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=? AND cliente_id=?"); $q->execute([(int)$s['contrato_id'], $cid]); $ct = $q->fetch(PDO::FETCH_ASSOC);
        if (!$ct) return [false, 'Contrato não encontrado.'];
        $novo = trim($para('login')); $velho = (string)$ct[$col];
        if (!ws_sol_login_valido($novo)) return [false, 'Login inválido (use 3 a 60 letras, números, ponto, traço, _ ou @).'];
        if ($novo === $velho) return [false, 'O login pedido é igual ao atual.'];
        if (ws_sol_login_em_uso($db, $novo, (int)$ct['id'])) return [false, 'Este login já está em uso por outro contrato.'];
        $db->prepare("UPDATE ws_contrato SET $col=? WHERE id=?")->execute([$novo, $ct['id']]);
        $ctNovo = $ct; $ctNovo[$col] = $novo;
        try { if ($velho !== '' && function_exists('ws_rad_remover')) ws_rad_remover($db, $velho); } catch (Throwable $e) {}
        try { ws_rad_sync_contrato($db, $ctNovo, ws_rad_deve_bloquear($db, $ctNovo)); } catch (Throwable $e) { return [false, 'Login gravado, mas o RADIUS não sincronizou: ' . $e->getMessage()]; }
        try { if ($velho !== '' && function_exists('ws_rad_derrubar_contrato')) ws_rad_derrubar_contrato($db, $ct); } catch (Throwable $e) {}   // sessão antiga cai; o roteador reconecta com o login novo
        return [true, "Login alterado de $velho para $novo (RADIUS atualizado)."];
    }
    case 'senha_pppoe': case 'senha_ipoe': {
        $col = $s['tipo'] === 'senha_ipoe' ? 'senha_ipoe' : 'senha_pppoe';
        $pw = ws_sol_decifrar((string)($d['segredo'] ?? ''));
        if ($pw === '') return [false, 'Senha do pedido indisponível (chave de cifra mudou?). Peça ao cliente para pedir de novo.'];
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=? AND cliente_id=?"); $q->execute([(int)$s['contrato_id'], $cid]); $ct = $q->fetch(PDO::FETCH_ASSOC);
        if (!$ct) return [false, 'Contrato não encontrado.'];
        $db->prepare("UPDATE ws_contrato SET $col=? WHERE id=?")->execute([$pw, $ct['id']]);
        $ct[$col] = $pw;
        try { ws_rad_sync_contrato($db, $ct, ws_rad_deve_bloquear($db, $ct)); } catch (Throwable $e) { return [false, 'Senha gravada, mas o RADIUS não sincronizou: ' . $e->getMessage()]; }
        return [true, 'Senha da conexão alterada (RADIUS atualizado).'];
    }
    case 'vencimento': {
        // Novo dia vale para as PRÓXIMAS faturas geradas; as já emitidas mantêm a data (ajuste manual se o acordo pedir).
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=? AND cliente_id=?"); $q->execute([(int)$s['contrato_id'], $cid]); $ct = $q->fetch(PDO::FETCH_ASSOC);
        if (!$ct) return [false, 'Contrato não encontrado.'];
        $dia = (int)$para('dia');
        if ($dia < 1 || $dia > 28 && $dia !== 30) return [false, 'Dia de vencimento inválido.'];
        $db->prepare("UPDATE ws_contrato SET dia_vencimento=? WHERE id=?")->execute([$dia, $ct['id']]);
        return [true, "Vencimento alterado do dia {$ct['dia_vencimento']} para o dia $dia (vale para as próximas faturas; as já emitidas mantêm a data)."];
    }
    case 'plano': {
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=? AND cliente_id=?"); $q->execute([(int)$s['contrato_id'], $cid]); $ct = $q->fetch(PDO::FETCH_ASSOC);
        if (!$ct) return [false, 'Contrato não encontrado.'];
        $pq = $db->prepare("SELECT * FROM ws_plano WHERE id=?"); $pq->execute([(int)$para('plano_id')]); $pl = $pq->fetch(PDO::FETCH_ASSOC);
        if (!$pl) return [false, 'Plano não encontrado.'];
        $velho = $db->prepare("SELECT nome, valor FROM ws_plano WHERE id=?"); $velho->execute([(int)$ct['plano_id']]); $pv = $velho->fetch(PDO::FETCH_ASSOC) ?: ['nome' => '—', 'valor' => null];
        // Valor do contrato acompanha o plano quando seguia o preço do plano antigo (sem valor próprio negociado).
        $segue = $ct['valor'] === null || ($pv['valor'] !== null && abs((float)$ct['valor'] - (float)$pv['valor']) < 0.01);
        $db->prepare("UPDATE ws_contrato SET plano_id=?" . ($segue ? ", valor=NULL" : "") . " WHERE id=?")->execute([(int)$pl['id'], $ct['id']]);
        $ct['plano_id'] = (int)$pl['id'];
        try { ws_rad_sync_contrato($db, $ct, ws_rad_deve_bloquear($db, $ct));
              foreach ([$ct['login_pppoe'], $ct['login_ipoe']] as $lg) if (trim((string)$lg) !== '' && function_exists('ws_rad_coa_plano')) ws_rad_coa_plano($db, (string)$lg, (int)$pl['up_kbps'], (int)$pl['down_kbps']); }
        catch (Throwable $e) { return [false, 'Plano gravado, mas o RADIUS não sincronizou: ' . $e->getMessage()]; }
        return [true, "Plano alterado de {$pv['nome']} para {$pl['nome']} (velocidade aplicada na hora)" . ($segue ? '; mensalidade passa a ser a do novo plano a partir da próxima fatura.' : '; o contrato tem valor próprio negociado — confira o valor.')];
    }
    case 'confianca': {
        // Aprovado pelo operador: libera em confiança pelas regras do sistema (dias de Clientes → Config → Regras).
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=? AND cliente_id=?"); $q->execute([(int)$s['contrato_id'], $cid]); $ct = $q->fetch(PDO::FETCH_ASSOC);
        if (!$ct) return [false, 'Contrato não encontrado.'];
        if ($ct['status'] !== 'bloqueado') return [true, 'O contrato já não está bloqueado — nada a liberar.'];
        $dias = function_exists('ws_dias_confianca') ? ws_dias_confianca() : 1;
        if (!ws_rad_confiar($db, $ct, $dias)) return [false, ws_rad_confiar_aviso() ?: 'Não foi possível liberar.'];
        if (function_exists('ws_evento')) ws_evento($db, $cid, 'confianca', "Desbloqueio em confiança aprovado pelo operador (pedido do robô, $dias dia(s)).");
        return [true, "Liberado em confiança por $dias dia(s)."];
    }
    }
    return [false, 'Tipo de pedido desconhecido.'];
}

/**
 * Decide um pedido. $acao = 'aprovar' | 'recusar'.
 * @return array [bool ok, string mensagem]
 */
function ws_sol_decidir(PDO $db, int $id, string $acao, string $por, string $motivo = ''): array {
    ws_sol_garantir($db);
    $por = mb_substr($por, 0, 80); $motivo = mb_substr(trim($motivo), 0, 255);
    $novo = $acao === 'aprovar' ? 'aprovada' : 'recusada';
    // "Reserva": só um operador vence a corrida; quem chegou depois vê que já foi decidido.
    $r = $db->prepare("UPDATE ws_solicitacao SET status=?, decidido_em=NOW(), decidido_por=?, motivo=? WHERE id=? AND status='pendente'");
    $r->execute([$novo, $por, $motivo !== '' ? $motivo : null, $id]);
    if ($r->rowCount() !== 1) return [false, 'Este pedido já foi decidido.'];
    $q = $db->prepare("SELECT * FROM ws_solicitacao WHERE id=?"); $q->execute([$id]); $s = $q->fetch(PDO::FETCH_ASSOC);
    $msg = $acao === 'aprovar' ? '' : 'Pedido recusado.'; $ok = true;
    if ($acao === 'aprovar') {
        try { [$ok, $msg] = ws_sol_aplicar($db, $s); } catch (Throwable $e) { $ok = false; $msg = 'Erro ao aplicar: ' . $e->getMessage(); }
        if (!$ok) $db->prepare("UPDATE ws_solicitacao SET status='falhou', motivo=? WHERE id=?")->execute([mb_substr($msg, 0, 255), $id]);
    }
    // a senha em espera some assim que o pedido é decidido
    $d = json_decode((string)$s['dados'], true) ?: []; if (!empty($d['segredo'])) { $d['segredo'] = ''; $db->prepare("UPDATE ws_solicitacao SET dados=? WHERE id=?")->execute([json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $id]); }
    if (function_exists('ws_evento')) ws_evento($db, (int)$s['cliente_id'], 'solicitacao', ($ok ? ($acao === 'aprovar' ? 'Aprovada' : 'Recusada') : 'Falhou') . ': ' . ws_sol_rotulo((string)$s['tipo']) . " (pedido #$id) por $por — $msg" . ($motivo !== '' ? " · $motivo" : ''));
    return [$ok, $msg];
}
