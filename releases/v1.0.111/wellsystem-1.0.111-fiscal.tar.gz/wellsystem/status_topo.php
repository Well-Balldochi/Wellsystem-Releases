<?php
/**
 * =================================================================================================
 * WellSystem — BARRA DE STATUS DO TOPO
 * =================================================================================================
 * Mostra, em uma linha fina no alto de toda tela logada, o ESTADO DO SERVIDOR — o que um operador
 * de provedor olha dezenas de vezes por dia sem querer abrir tela nenhuma:
 *
 *     Linux 5.4 · RAM 45% · CPU 1% · DISCO 86% · Sessões: 1        IP 10.33.33.2 · ONLINE
 *
 * O nome do provedor e os horários de acesso já estiveram aqui e foram retirados: a logo ao lado já
 * identifica o provedor, e os horários poluíam a linha. Os dois acessos (atual e anterior)
 * CONTINUAM sendo gravados a cada login em ws_usuario — ver ws_registrar_acesso(). O dado existe,
 * só não ocupa a barra.
 *
 * TRÊS REGRAS, e é o que separa uma barra útil de um estorvo:
 *
 * 1. DADO REAL OU NADA.
 *    Cada número vem de uma fonte de verdade do sistema operacional: /proc/meminfo, /proc/loadavg,
 *    statvfs do disco. O que não puder ser medido no ambiente simplesmente NÃO APARECE — em vez de
 *    aparecer um zero ou um traço, que mentiria de forma convincente. Barra de status que mostra
 *    RAM errada é pior que não ter barra: alguém toma decisão com base nela.
 *
 * 2. CUSTO ZERO POR PÁGINA.
 *    Ela está em TODA tela logada, então não pode custar consulta ao banco — foi exatamente esse
 *    tipo de acréscimo que já deixou o sistema lento. As leituras de /proc e o statvfs são syscalls
 *    de microssegundos. O que exigiria consulta (último acesso) é resolvido no LOGIN e guardado na
 *    sessão. A checagem de internet é feita pelo CRON e lida de arquivo. Resultado: zero consultas
 *    e zero acesso de rede por página.
 *
 * 3. NÃO ESTOURA.
 *    O conteúdo é dividido em três grupos que se reorganizam pela largura: em tela cheia ficam
 *    esquerda / centro / direita; apertando, quebram em linha; no celular, os itens menos críticos
 *    desaparecem por CSS em vez de espremer a barra. Ver .ws-status-bar no wellsystem.css.
 */

/** Versão do sistema — do arquivo VERSAO, ou a data da build do config.php como último recurso. */
function ws_sistema_versao(): string {
    static $v = null;
    if ($v !== null) return $v;
    $f = WS_DIR . '/VERSAO';
    if (is_file($f)) {
        $t = trim((string)@file_get_contents($f));
        if ($t !== '') return $v = mb_substr($t, 0, 20);
    }
    // Sem arquivo de versão, a data de modificação do config.php identifica a build em uso.
    return $v = date('y.m', (int)(@filemtime(WS_DIR . '/config.php') ?: time()));
}

/**
 * Sistema operacional e versão do kernel, curtos — ex.: "linux 5.15".
 *
 * O NOME vem do próprio sistema (php_uname('s')), e não escrito fixo: o código roda em Linux no
 * servidor e em Windows na máquina de desenvolvimento, e uma barra que dissesse "linux" rodando no
 * Windows seria um dado falso — exatamente o que a regra 1 deste arquivo proíbe.
 * Só major.minor do kernel: o resto ("-119-generic") é ruído para quem olha de passagem.
 */
function ws_so_versao(): string {
    $r = @php_uname('r');
    $s = @php_uname('s');
    if (!is_string($r) || $r === '') return '';
    $ver = preg_match('/^(\d+\.\d+)/', $r, $m) ? $m[1] : mb_substr($r, 0, 12);
    // Nome do sistema com a primeira letra maiúscula: "Linux", "Windows", "Darwin". É nome próprio.
    $nome = '';
    if (is_string($s) && $s !== '') {
        $n = explode(' ', trim($s))[0];
        $nome = mb_strtoupper(mb_substr($n, 0, 1, 'UTF-8'), 'UTF-8') . mb_strtolower(mb_substr($n, 1, null, 'UTF-8'), 'UTF-8');
    }
    return trim($nome . ' ' . $ver);
}

/**
 * Saúde da máquina: RAM usada, carga de CPU e disco usado, em percentual.
 *
 * Devolve SÓ o que conseguiu medir. Chave ausente significa "não há como saber neste ambiente", e
 * a barra omite o item.
 *
 * RAM — usa MemAvailable, e não MemFree.
 * MemFree ignora o cache de disco, que o Linux devolve à aplicação quando ela precisa. Com MemFree,
 * um servidor folgado acusaria 95% de RAM usada, e alguém compraria memória sem necessidade.
 * MemAvailable é a estimativa do próprio kernel do que está de fato disponível.
 *
 * CPU — carga de 1 minuto do /proc/loadavg dividida pelo número de núcleos.
 * É a medida que responde "o servidor está apertado?" com UMA leitura. O /proc/stat daria o
 * percentual instantâneo, mas exige duas amostras separadas no tempo — numa página web isso
 * significaria dormir entre as leituras, ou seja, atrasar a resposta de propósito.
 *
 * O percentual de CPU pode passar de 100, e isso é correto: carga acima do número de núcleos é
 * fila de espera. Limitar em 100 esconderia justamente o servidor que está sofrendo.
 */
function ws_maquina_status(): array {
    $s = [];

    if (@is_readable('/proc/meminfo')) {
        $t = (string)@file_get_contents('/proc/meminfo');
        if (preg_match('/MemTotal:\s+(\d+)/', $t, $a) && preg_match('/MemAvailable:\s+(\d+)/', $t, $b)) {
            $total = (int)$a[1];
            $disp  = (int)$b[1];
            if ($total > 0) {
                $s['ram']    = (int)round((($total - $disp) / $total) * 100);
                $s['ram_gb'] = round($total / 1048576, 1);      // kB -> GiB
            }
        }
    }

    if (@is_readable('/proc/loadavg')) {
        $l = explode(' ', trim((string)@file_get_contents('/proc/loadavg')));
        $carga = (float)($l[0] ?? 0);
        $nucleos = 1;
        if (@is_readable('/proc/cpuinfo')) {
            $n = preg_match_all('/^processor\s*:/m', (string)@file_get_contents('/proc/cpuinfo'));
            if ($n > 0) $nucleos = $n;
        }
        $s['cpu']      = (int)round(($carga / $nucleos) * 100);
        $s['cpu_carga'] = $carga;
        $s['nucleos']  = $nucleos;
    }

    $dir = defined('WS_DIR') ? WS_DIR : __DIR__;
    $tot = @disk_total_space($dir);
    $liv = @disk_free_space($dir);
    if ($tot && $tot > 0 && $liv !== false) {
        $s['disco']     = (int)round((($tot - $liv) / $tot) * 100);
        $s['disco_liv'] = round($liv / 1073741824, 1);          // bytes -> GiB livres
    }

    return $s;
}

/**
 * Registra o acesso do operador: guarda o anterior e grava o atual.
 *
 * Chamada UMA vez, no login. É o que permite a barra mostrar "acesso atual # anterior" sem
 * consultar o banco a cada página — as duas datas ficam na sessão.
 *
 * A ordem importa e é o que faz a informação existir: o acesso ANTERIOR é lido ANTES de o atual ser
 * gravado. Invertido, o "anterior" seria sempre igual ao "atual".
 *
 * E isto não é enfeite: um operador que vê "acesso anterior" numa hora em que não estava
 * trabalhando descobre na hora que alguém usou a conta dele. É a informação de segurança mais
 * barata que existe num sistema multiusuário.
 */
function ws_registrar_acesso(int $usuarioId): void {
    if ($usuarioId <= 0) return;
    $_SESSION['ws_acesso_atual'] = date('Y-m-d H:i:s');
    try {
        $db = ws_db();
        /* As colunas são garantidas aqui mesmo. É tela de LOGIN: não pode depender de a migração
         * já ter rodado, senão o primeiro acesso depois de uma atualização perderia o registro. */
        foreach ([['ultimo_acesso', 'DATETIME DEFAULT NULL'], ['acesso_anterior', 'DATETIME DEFAULT NULL']] as $c) {
            $tem = (int)$db->query("SELECT COUNT(*) FROM information_schema.columns
                                    WHERE table_schema=DATABASE() AND table_name='ws_usuario'
                                      AND column_name='" . $c[0] . "'")->fetchColumn();
            if (!$tem) { try { $db->exec("ALTER TABLE ws_usuario ADD COLUMN " . $c[0] . ' ' . $c[1]); } catch (Throwable $e) {} }
        }
        $st = $db->prepare("SELECT ultimo_acesso FROM ws_usuario WHERE id=?");
        $st->execute([$usuarioId]);
        $anterior = (string)($st->fetchColumn() ?: '');
        $db->prepare("UPDATE ws_usuario SET acesso_anterior=?, ultimo_acesso=NOW() WHERE id=?")
           ->execute([($anterior !== '' ? $anterior : null), $usuarioId]);
        $_SESSION['ws_acesso_anterior'] = $anterior;
    } catch (Throwable $e) {
        /* Sem banco para isso, a barra mostra só o acesso atual (que já está na sessão acima).
         * Falhar em registrar histórico de acesso não pode impedir ninguém de entrar no sistema. */
    }
}

/** IP de quem está acessando — atrás de proxy reverso ou direto. */
function ws_ip_cliente(): string {
    /* X-Forwarded-For é cabeçalho ENVIADO PELO CLIENTE: qualquer um pode escrever o que quiser
     * nele. Só é confiável quando existe um proxy reverso NOSSO na frente, que o reescreve. Por
     * isso ele só é aceito quando a conexão vem do próprio servidor — o caso real de Apache atrás
     * de Traefik/Nginx local. De qualquer outra origem vale o IP da conexão, que não se falsifica.
     * Aceitar o cabeçalho sempre transformaria esta barra em um campo de texto livre do visitante. */
    $remoto = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if (in_array($remoto, ['127.0.0.1', '::1'], true) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $p = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($p, FILTER_VALIDATE_IP)) return $p;
    }
    return $remoto !== '' ? $remoto : '—';
}

/**
 * O servidor tem internet?
 *
 * LIDO DE ARQUIVO, verificado pelo CRON — nunca testado durante a requisição.
 * Testar rede no carregamento de uma página é a receita clássica da tela que passa a demorar
 * segundos para abrir quando o enlace cai. E é justamente na queda que o operador mais precisa que
 * o sistema responda rápido, porque é quando ele vai atender cliente reclamando.
 *
 * @return array ['online' => bool|null, 'em' => timestamp]  ·  null = ainda não verificado
 */
function ws_internet_status(): array {
    $f = WS_CACHE . '/internet.json';
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (is_array($j) && array_key_exists('online', $j)) {
            return ['online' => (bool)$j['online'], 'em' => (int)($j['em'] ?? 0)];
        }
    }
    return ['online' => null, 'em' => 0];
}

/** Testa a internet e grava o resultado. Chamada pelo CRON (radius_sync.php), não pela página. */
function ws_internet_verificar(): bool {
    /* Conexão TCP na porta 53 de um DNS público: responde em milissegundos e não depende de HTTP,
     * proxy, DNS ou certificado — qualquer um desses acrescentaria uma forma de falhar que não tem
     * relação com "há internet?". Dois destinos porque um deles pode estar bloqueado na rota do
     * provedor, e isso não significa estar sem internet. */
    $ok = false;
    foreach (['1.1.1.1', '8.8.8.8'] as $ip) {
        $c = @fsockopen($ip, 53, $e1, $e2, 2);
        if ($c) { fclose($c); $ok = true; break; }
    }
    @file_put_contents(WS_CACHE . '/internet.json', json_encode(['online' => $ok, 'em' => time()]));
    @chmod(WS_CACHE . '/internet.json', 0640);
    return $ok;
}

/**
 * A barra montada, pronta para ser impressa no topo.
 *
 * Devolve string vazia quando não há operador logado — a barra expõe IP, acesso e saúde do
 * servidor, e nada disso deve aparecer em tela pública (login, portal do assinante).
 */
/* OCORRÊNCIAS DA OLT NA BARRA (24/09/2026, pedido do provedor: "esses alertas devem pulsar na página da WellSystem
 * também"). Lê SÓ os arquivos de estado que o monitor da OLT já grava a cada varredura (cron, ~3 min):
 *   olt_pon_estado.json      {"0/5/8":"los"|"energia"}        — queda total pelas ONUs (olt_pon_alertas_e_log)
 *   olt_alarmes_estado.json  {"pon:0/5/8":{...},"placa:5":{...}} — pelos alarmes da OLT (olt_alarmes_*)
 * nas duas pastas de cache do módulo OLT (cache_trafego/ e /tmp, a mais nova de cada arquivo). Não fala com a
 * OLT, não consulta banco: a regra 2 desta barra (custo zero por página) continua valendo.
 * @return array lista de ['onde'=>'0/5/8'|'placa 5', 'tipo'=>'los'|'energia'|'placa', 'nome'=>descrição da PON] */
function ws_olt_ocorrencias(): array {
    static $out = null; if ($out !== null) return $out;
    $out = [];
    $dirs = [__DIR__ . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'];
    $ler = function (string $nome) use ($dirs) {
        $best = null; $bts = -1;
        foreach ($dirs as $d) { $f = $d . '/' . $nome; if (!is_file($f)) continue; $t = (int)@filemtime($f);
            if ($t >= $bts) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) { $best = $j; $bts = $t; } } }
        return $best ?: [];
    };
    $meta = $ler('olt_meta.json'); $pn = (isset($meta['porta']) && is_array($meta['porta'])) ? $meta['porta'] : [];
    $pl = (isset($meta['placa']) && is_array($meta['placa'])) ? $meta['placa'] : [];
    $pz = (isset($meta['portazona']) && is_array($meta['portazona'])) ? $meta['portazona'] : [];
    // mais dados para a janela de ocorrências: nome da placa, zona da porta, ONUs afetadas e hora (quando o arquivo tem)
    $item = function (string $fsp, string $tipo, array $v = []) use ($pn, $pl, $pz) {
        $sl = explode('/', $fsp)[1] ?? '';
        return ['onde' => $fsp, 'tipo' => $tipo, 'nome' => trim((string)($pn[$fsp] ?? '')),
                'placa' => $sl, 'placa_nome' => trim((string)($pl[$sl] ?? ($pl['0/' . $sl] ?? ''))), 'porta' => explode('/', $fsp)[2] ?? '',
                'zona' => trim((string)($pz[$fsp] ?? '')), 'n' => (int)($v['n'] ?? ($v['afet'] ?? 0)), 'tot' => (int)($v['tot'] ?? 0),
                'hora' => (string)($v['hora'] ?? '')];
    };
    $viu = [];
    foreach ($ler('olt_pon_estado.json') as $fsp => $tipo) {
        if (!is_string($fsp) || !preg_match('#^\d+/\d+/\d+$#', $fsp)) continue;
        $viu[$fsp] = 1; $out[] = $item($fsp, (string)$tipo === 'los' ? 'los' : 'energia');
    }
    foreach ($ler('olt_alarmes_estado.json') as $k => $v) {
        if (!is_array($v)) continue; $tp = (string)($v['tipo'] ?? '');
        if ($tp === 'placa') { $sl = (string)($v['slot'] ?? '?');
            $out[] = ['onde' => 'placa ' . $sl, 'tipo' => 'placa', 'nome' => trim((string)($v['board'] ?? '')), 'placa' => $sl,
                      'placa_nome' => trim((string)($pl[$sl] ?? ($pl['0/' . $sl] ?? ''))), 'porta' => '', 'zona' => '', 'n' => 0, 'tot' => 0, 'hora' => (string)($v['hora'] ?? '')];
            continue; }
        $fsp = (string)($v['fsp'] ?? ''); if ($fsp === '') continue;
        if (isset($viu[$fsp])) {   // já veio pela contagem de ONUs: só completa com os números do alarme
            foreach ($out as &$o) if ($o['onde'] === $fsp && !$o['n']) { $o['n'] = (int)($v['n'] ?? ($v['afet'] ?? 0)); $o['tot'] = (int)($v['tot'] ?? 0); }
            unset($o); continue; }
        $viu[$fsp] = 1; $out[] = $item($fsp, $tp === 'los' ? 'los' : 'energia', $v);
    }
    return $out;
}

function ws_barra_status(): string {
    $u = function_exists('ws_user') ? ws_user() : null;
    if (!$u) return '';

    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

    /* Só o que a barra REALMENTE usa.
     *
     * Saíram daqui, junto com os itens que deixaram de ser exibidos, a leitura do provedor.json e
     * as duas funções de formatar data. Código que não é mais chamado não fica "por precaução": foi
     * exatamente uma regra esquecida assim (duas declarações .ws-logo em pontos diferentes do CSS)
     * que espremeu a logo numa caixa de 200x46 e custou uma investigação. O que precisar voltar,
     * volta do histórico — com o comentário que explica para que servia. */
    $m   = ws_maquina_status();
    $so  = ws_so_versao();
    $ip  = ws_ip_cliente();
    $net = ws_internet_status();

    /* Sessões: lido da sessão, preenchido no login. Contar operadores online aqui seria uma
     * consulta por página — o preço que esta barra não pode cobrar. O número é a contagem no
     * momento do login, e o título explica isso para não passar por tempo real. */
    $sessoes = (int)($_SESSION['ws_sessoes_login'] ?? 1);

    /* Cor por faixa de uso. Os limites são os que importam operacionalmente: até 70% é folga,
     * 70–90% é atenção, acima de 90% é o ponto em que o servidor começa a engasgar de verdade. */
    $cor = function (int $pct): string {
        if ($pct >= 90) return 'var(--err)';
        if ($pct >= 70) return 'var(--warn)';
        return 'var(--ok)';
    };

    ob_start(); ?>
    <div class="ws-status-bar">
      <?php /* O nome "WellSystem" e o operador logado NÃO aparecem aqui: os dois já estão no topo
               (o selo do sistema na primeira linha, o operador no chip à direita). Repetir a mesma
               informação em duas linhas colada uma na outra só ocupa espaço e obriga o olho a
               ignorar metade da barra.
               A VERSÃO foi para o título do item do kernel, e não descartada: é a única forma de
               saber qual build está no ar, e é a primeira coisa que se pergunta no suporte. */ ?>
      <?php /* ORDEM: o PROVEDOR vem primeiro, depois o servidor.
               O nome de quem é o sistema identifica a tela antes de qualquer dado técnico — é o que
               o olho procura primeiro ao trocar de aba entre instalações diferentes. O kernel vem
               em seguida, como informação de apoio. */ ?>
      <?php
      /* ÍCONES: SVG embutido, 12px, herdando a cor do texto (currentColor) e com opacidade baixa.
       *
       * Embutidos e não de fonte de ícones: a barra aparece em TODA tela, e uma fonte externa que
       * demore ou falhe deixaria quadradinhos vazios no lugar — ou, pior, a barra pularia de altura
       * quando a fonte terminasse de carregar. SVG no HTML desenha junto com a página, sempre.
       *
       * currentColor é o que os torna discretos de verdade: cada ícone assume a cor do seu item
       * (azul no sistema, vermelho no IP, verde no online), em vez de virar uma fileira de bolinhas
       * coloridas competindo com os números — que é o dado que importa. */
      $ico = function (string $d, string $extra = '') {
          return '<svg class="ws-st-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"'
               . ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>' . $extra;
      };
      $icoSo    = $ico('<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>');           // monitor
      $icoRam   = $ico('<rect x="4" y="7" width="16" height="10" rx="2"/><path d="M8 7V4M12 7V4M16 7V4"/>');        // pente de memória
      $icoCpu   = $ico('<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M10 4v3M14 4v3M10 17v3M14 17v3M4 10h3M4 14h3M17 10h3M17 14h3"/>'); // processador
      $icoDisco = $ico('<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>'); // disco
      $icoSess  = $ico('<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5 6-5s6 1.7 6 5"/><path d="M17 11h4M19 9v4"/>'); // pessoas
      ?>
      <?php /* A barra ficou só com o que é ESTADO DO SERVIDOR: sistema, memória, processador, disco
               e sessões. Saíram, a pedido do operador:

                 · o NOME DO PROVEDOR — já está na logo, ao lado, e em tamanho maior;
                 · o RELÓGIO do acesso atual e o do acesso anterior.

               Os dois horários continuam sendo GRAVADOS a cada login (ws_usuario.ultimo_acesso e
               .acesso_anterior — ver ws_registrar_acesso). Só deixaram de ocupar a barra: o dado
               não se perde, e voltar a exibi-lo é devolver este trecho ao lugar. */ ?>
      <span class="ws-st-g">
        <?php if ($so !== ''): ?>
          <span class="ws-st-so" title="Sistema e kernel do servidor · WellSystem <?= $h(ws_sistema_versao()) ?>"><?= $icoSo ?> <?= $h($so) ?></span>
        <?php endif; ?>
      </span>

      <span class="ws-st-g ws-st-maq">
        <?php if (isset($m['ram'])): ?>
          <span title="Memória em uso<?= isset($m['ram_gb']) ? ' — total ' . $m['ram_gb'] . ' GB' : '' ?>">
            <?= $icoRam ?> RAM <b style="color:<?= $cor($m['ram']) ?>"><?= (int)$m['ram'] ?>%</b></span>
        <?php endif; ?>
        <?php if (isset($m['cpu'])): ?>
          <span title="Carga de CPU de 1 minuto sobre <?= (int)($m['nucleos'] ?? 1) ?> núcleo(s) — carga <?= $h($m['cpu_carga'] ?? '') ?>. Acima de 100% significa fila de espera.">
            <?= $icoCpu ?> CPU <b style="color:<?= $cor($m['cpu']) ?>"><?= (int)$m['cpu'] ?>%</b></span>
        <?php endif; ?>
        <?php if (isset($m['disco'])): ?>
          <span title="Disco em uso<?= isset($m['disco_liv']) ? ' — ' . $m['disco_liv'] . ' GB livres' : '' ?>">
            <?= $icoDisco ?> DISCO <b style="color:<?= $cor($m['disco']) ?>"><?= (int)$m['disco'] ?>%</b></span>
        <?php endif; ?>
      </span>

      <span class="ws-st-g">
        <span class="ws-st-sess" title="Operadores vistos no sistema quando você entrou"><?= $icoSess ?> Sessões: <b><?= $sessoes ?></b></span>
        <?php /* CONEXÕES RECENTES — só um ícone ⇅ discreto. A lista (quem voltou a conectar e quem
                 caiu) é buscada em conexoes_recentes.php NO CLIQUE: a barra continua sem custar
                 consulta nenhuma no carregamento da página. */ ?>
        <?php if (!function_exists('ws_edicao_tem') || ws_edicao_tem('erp')): /* edição OLT/Fiscal isolada não tem clientes/conexões do ERP */ ?>
        <span class="ws-st-conex" id="wsConexBtn" role="button" tabindex="0" aria-haspopup="true" aria-expanded="false"
              title="Conexões recentes: clientes que voltaram e que caíram"><?= $ico('<path d="M7 17V5M3.5 8.5 7 5l3.5 3.5"/><path d="M17 7v12M13.5 15.5 17 19l3.5-3.5"/>') ?></span>
        <?php endif; ?>
      </span>

      <?php /* ATENÇÃO PON NO WELLSYSTEM (24/09/2026) — o MESMO botão "❤ Atenção PON" da tela da OLT, FLUTUANTE no canto
               inferior direito de toda tela (fica no <body>, ver o script abaixo). Aparece sempre que o módulo OLT existe;
               PULSA em vermelho, com o número, quando há PON/placa em queda (ws_olt_ocorrencias). O clique abre a janela
               "Ocorrências na OLT" (fechar / minimizar para o rodapé / maximizar). Substitui o aviso que ficava nesta barra:
               nunca aparecem os dois. Se a página já tiver o botão da própria OLT (#oltBtnIntPon), este se esconde. */
      $oltOc = is_file(__DIR__ . '/olt_huawei.php') ? ws_olt_ocorrencias() : null;
      if ($oltOc !== null):
          $tit = $oltOc ? ('Ocorrência na OLT:' . "\n" . implode("\n", array_map(fn($o) => '• ' . $o['onde'] . ($o['nome'] !== '' ? ' ' . $o['nome'] : '')
                 . ' — ' . ($o['tipo'] === 'los' ? 'sem sinal (LOS/fibra)' : ($o['tipo'] === 'energia' ? 'falta de energia' : 'placa sem comunicação')), array_slice($oltOc, 0, 12))))
               : 'Nenhuma PON em queda agora'; ?>
        <?php /* FLUTUANTE DE VERDADE (24/09/2026): arrasta para qualquer lugar (mouse e toque; posição lembrada),
                 ▁ minimiza para uma bolinha ❤, ▢ abre a janela de ocorrências, ✕ esconde nesta aba — volta sozinho se
                 aparecer ocorrência NOVA (assinatura data-sig). Clique no nome (sem arrastar) = abrir a janela. */
              $sigOc = substr(md5(implode('|', array_map(fn($o) => $o['tipo'] . $o['onde'], $oltOc))), 0, 12); ?>
        <div id="wsOltBtn" class="ws-olt-btn<?= $oltOc ? ' on' : '' ?>" data-sig="<?= $h($sigOc) ?>" title="<?= $h($tit) ?> — arraste para mover">
          <span class="ws-olt-btn-t" onclick="if(window._wsOltArrastou) return; if(this.parentNode.classList.contains('mini')) wsOltFlut('min'); else wsOltJan('abrir');">❤<span class="ws-olt-btn-nome"> Atenção PON</span><?php if ($oltOc): ?> <span class="ws-olt-btn-n"><?= count($oltOc) ?></span><?php endif; ?></span>
          <span class="ws-olt-btn-c">
            <button type="button" onclick="wsOltFlut('min')" title="Minimizar">▁</button>
            <button type="button" onclick="wsOltJan('abrir')" title="Abrir a janela">▢</button>
            <button type="button" onclick="wsOltFlut('fechar')" title="Fechar (volta se houver ocorrência nova)">✕</button>
          </span>
        </div>
        <div id="wsOltJan" class="ws-olt-jan" hidden role="dialog" aria-label="Ocorrências na OLT">
          <div class="ws-olt-jan-top">
            <span class="ws-olt-jan-tit">❤ Atenção PON <small><?= count($oltOc) ?></small></span>
            <button type="button" onclick="wsOltJan('min')" title="Minimizar (vai para o rodapé)">▁</button>
            <button type="button" onclick="wsOltJan('max')" title="Maximizar / restaurar">▢</button>
            <button type="button" onclick="wsOltJan('fechar')" title="Fechar">✕</button>
          </div>
          <div class="ws-olt-jan-corpo">
            <?php foreach ($oltOc as $o):
                $cls = $o['tipo'] === 'los' ? 'los' : ($o['tipo'] === 'energia' ? 'ener' : 'placa');
                $rot = $o['tipo'] === 'los' ? 'Sem sinal · LOS' : ($o['tipo'] === 'energia' ? 'Falta de energia' : 'Placa sem comunicação'); ?>
              <div class="ws-olt-oc ws-olt-oc-<?= $cls ?>">
                <div class="ws-olt-oc-l1"><span class="ws-olt-tag"><?= $h($rot) ?></span>
                  <b><?= $o['tipo'] === 'placa' ? 'Placa ' . $h($o['placa']) : 'PON ' . $h($o['onde']) ?></b>
                  <?php if ($o['hora'] !== ''): ?><span class="ws-olt-hora">desde <?= $h($o['hora']) ?></span><?php endif; ?></div>
                <div class="ws-olt-oc-l2">
                  <?php if ($o['tipo'] !== 'placa'): ?><span>Placa <?= $h($o['placa']) ?><?= $o['placa_nome'] !== '' ? ' · ' . $h($o['placa_nome']) : '' ?> · Porta <?= $h($o['porta']) ?></span><?php endif; ?>
                  <?php if ($o['tipo'] === 'placa' && $o['placa_nome'] !== ''): ?><span><?= $h($o['placa_nome']) ?></span><?php endif; ?>
                  <?php if ($o['nome'] !== ''): ?><span><?= $h($o['nome']) ?></span><?php endif; ?>
                  <?php if ($o['zona'] !== ''): ?><span>Zona <?= $h($o['zona']) ?></span><?php endif; ?>
                  <?php if ($o['n'] > 0): ?><span><b><?= (int)$o['n'] ?></b><?= $o['tot'] ? ' de ' . (int)$o['tot'] : '' ?> ONUs</span><?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
            <?php if (!$oltOc): ?><div class="ws-olt-vazio">✅ Nenhuma PON ou placa em queda agora.</div><?php endif; ?>
            <a class="ws-olt-jan-ir" href="olt.php">Abrir a OLT →</a>
          </div>
        </div>
        <script>
        /* Botão flutuante: minimizar (bolinha ❤, clique volta) / fechar nesta aba. */
        function wsOltFlut(acao){
          var b=document.getElementById('wsOltBtn'); if(!b) return;
          if(acao==='min'){ b.classList.toggle('mini'); try{ localStorage.setItem('wsOltMini', b.classList.contains('mini')?'1':''); }catch(e){} }
          if(acao==='fechar'){ b.style.display='none'; try{ sessionStorage.setItem('wsOltFechado', b.getAttribute('data-sig')||''); }catch(e){} wsOltJan('fechar'); }
        }
        /* Janela de ocorrências da OLT: abrir / minimizar (barra no rodapé) / maximizar / fechar. */
        function wsOltJan(acao){
          var j=document.getElementById('wsOltJan'); if(!j) return;
          if(acao==='abrir'){ j.hidden=false; j.classList.remove('min'); }
          else if(acao==='min'){ j.classList.toggle('min'); j.classList.remove('max'); }
          else if(acao==='max'){ j.classList.toggle('max'); j.classList.remove('min'); }
          else if(acao==='fechar'){ j.hidden=true; j.classList.remove('min','max'); }
          try{ sessionStorage.setItem('wsOltJan', j.hidden?'':(j.classList.contains('min')?'min':(j.classList.contains('max')?'max':'aberta'))); }catch(e){}
        }
        (function(){ var j0=document.getElementById('wsOltJan');
          /* A janela vai para o <body>: o topo tem backdrop-filter, que prende "position:fixed" dentro dele — minimizada,
             ela ficava no alto em vez de descer para o rodapé. */
          if(j0 && j0.parentNode!==document.body) document.body.appendChild(j0);
          var b0=document.getElementById('wsOltBtn');
          if(b0){ if(document.getElementById('oltBtnIntPon')) b0.remove(); else if(b0.parentNode!==document.body) document.body.appendChild(b0); }
          b0=document.getElementById('wsOltBtn');
          if(b0){
            // estado: fechado nesta aba (só enquanto a ocorrência for a mesma), minimizado, posição arrastada
            try{ if(sessionStorage.getItem('wsOltFechado')===b0.getAttribute('data-sig')) b0.style.display='none'; }catch(e){}
            try{ if(localStorage.getItem('wsOltMini')==='1') b0.classList.add('mini'); }catch(e){}
            try{ var p=JSON.parse(localStorage.getItem('wsOltPos')||'null'); if(p&&p.x!=null&&innerWidth>100){ b0.style.left=Math.max(0,Math.min(p.x,innerWidth-60))+'px'; b0.style.top=Math.max(0,Math.min(p.y,innerHeight-40))+'px'; b0.style.right='auto'; b0.style.bottom='auto'; } }catch(e){}
            var sx=0,sy=0,ox=0,oy=0,arr=false;
            var ini=function(x,y,ev){ if(ev.target.closest && ev.target.closest('.ws-olt-btn-c button')) return false; var r=b0.getBoundingClientRect(); sx=x; sy=y; ox=r.left; oy=r.top; arr=true; window._wsOltArrastou=false; return true; };
            var mov=function(x,y){ if(!arr) return; if(Math.abs(x-sx)+Math.abs(y-sy)>4) window._wsOltArrastou=true; if(!window._wsOltArrastou) return;
              // nunca sai da tela (o limite de baixo vale mesmo se a janela informar tamanho 0)
              b0.style.left=Math.max(0,Math.min(ox+x-sx,innerWidth-b0.offsetWidth))+'px'; b0.style.top=Math.max(0,Math.min(oy+y-sy,innerHeight-b0.offsetHeight))+'px'; b0.style.right='auto'; b0.style.bottom='auto'; };
            var fim=function(){ if(!arr) return; arr=false; if(window._wsOltArrastou){ try{ localStorage.setItem('wsOltPos',JSON.stringify({x:parseInt(b0.style.left,10),y:parseInt(b0.style.top,10)})); }catch(e){} setTimeout(function(){ window._wsOltArrastou=false; },50); } };
            b0.addEventListener('mousedown',function(e){ if(ini(e.clientX,e.clientY,e)) e.preventDefault(); });
            document.addEventListener('mousemove',function(e){ mov(e.clientX,e.clientY); });
            document.addEventListener('mouseup',fim);
            b0.addEventListener('touchstart',function(e){ var t=e.touches[0]; ini(t.clientX,t.clientY,e); },{passive:true});
            b0.addEventListener('touchmove',function(e){ var t=e.touches[0]; mov(t.clientX,t.clientY); if(window._wsOltArrastou) e.preventDefault(); },{passive:false});
            b0.addEventListener('touchend',fim);
          }
          try{ var s=sessionStorage.getItem('wsOltJan'); var j=j0; if(!j||!s) return;
          j.hidden=false; if(s==='min') j.classList.add('min'); if(s==='max') j.classList.add('max'); }catch(e){} })();
        </script>
      <?php endif; ?>

      <span class="ws-st-g ws-st-rede">
        <?php /* IP em verde junto do ONLINE: os dois falam da mesma coisa — a conexão. Lidos como
                 um par da mesma cor, o olho pega o estado da rede de uma vez, sem precisar
                 distinguir dois blocos. */ ?>
        <span class="ws-st-ip" title="IP de onde você está acessando">IP <b><?= $h($ip) ?></b></span>
        <?php
            /* ONLINE fica SEMPRE visível junto do IP: se a página carregou, o acesso está
               acontecendo agora — isso não depende do cron ter rodado. Só vira "SEM INTERNET"
               (vermelho) quando o cron CONFIRMA a queda; sem checagem ainda ($net['online']
               === null) o padrão é otimista (ONLINE), nunca sumir o texto. */
            $quando = $net['em'] ? date('H:i', $net['em']) : '';
            $tit = $net['online'] === false
                ? "O servidor está SEM internet — verificado às $quando. Boleto, PIX, WhatsApp e e-mail não vão sair até voltar."
                : ($net['online'] === true
                    ? "O servidor tem internet. Verificado às $quando pelo cron."
                    : "Acesso ativo agora. Checagem de internet do servidor ainda não rodou.");
        ?>
        <?php /* A cor vem de CLASSE, não de style no elemento de fora.
                 O style inline ficava no <span> e o texto está dentro de um <b> — e a regra
                 `.ws-status-bar b{ color:var(--text) }`, deste mesmo arquivo de estilo, definia
                 a cor do <b> EXPLICITAMENTE. Cor explícita vence cor herdada, então o verde do
                 pai nunca chegava ao texto: o ONLINE saía preto.
                 Com classe, a regra `.ws-status-bar .ws-st-net-on b` tem especificidade maior
                 que `.ws-status-bar b` e ganha sem depender da ordem das regras no arquivo. */ ?>
        <?php /* HÁ QUANTO TEMPO O SERVIDOR ESTÁ LIGADO (24/09/2026, pedido do provedor): "ONLINE · há 12 dias", discreto,
                 ao lado do estado. Vem de /proc/uptime (leitura de microssegundos, sem banco — regra 2 desta barra).
                 Sem /proc (Windows/Docker restrito) simplesmente não aparece (regra 1: dado real ou nada). */
            $upSeg = 0; $upTxt = '';
            if (@is_readable('/proc/uptime')) { $upSeg = (int)(float)explode(' ', (string)@file_get_contents('/proc/uptime'))[0]; }
            if ($upSeg > 0) {
                $d = intdiv($upSeg, 86400); $hh = intdiv($upSeg % 86400, 3600); $mm = intdiv($upSeg % 3600, 60);
                $upTxt = $d > 0 ? ('há ' . $d . ($d === 1 ? ' dia' : ' dias') . ($d < 7 && $hh ? ' ' . $hh . 'h' : '')) : ($hh > 0 ? "há {$hh}h" . ($mm ? " {$mm}min" : '') : "há {$mm}min");
                $tit .= "\nServidor ligado " . $upTxt . ' — desde ' . date('d/m/Y H:i', time() - $upSeg) . '.';
            } ?>
        <span class="ws-st-net <?= $net['online'] === false ? 'ws-st-net-off' : 'ws-st-net-on' ?>" title="<?= $h($tit) ?>">
          <b><?= $net['online'] === false ? 'SEM INTERNET' : 'ONLINE' ?></b><?php if ($upTxt !== ''): ?><span class="ws-st-up"> · <?= $h($upTxt) ?></span><?php endif; ?></span>
      </span>
    </div>
    <style>
    /* Aviso de ocorrência na OLT — pulsa enquanto houver queda (some sozinho quando a OLT normaliza). */
    /* "há X dias" junto do ONLINE: mesma cor, mais leve e menor — informa sem disputar com o estado. */
    /* mesmo VERDE VIVO do ONLINE (pedido: "quase não dá para ver, muito claro") — só um pouco mais fino */
    .ws-status-bar .ws-st-up{font-weight:600;opacity:1;font-size:.95em;letter-spacing:.2px}
    .ws-status-bar .ws-st-net-on .ws-st-up{color:var(--ok)}
    .ws-status-bar .ws-st-net-off .ws-st-up{color:var(--err)}
    /* Botão flutuante "❤ Atenção PON" — o mesmo visual do botão da tela da OLT; pulsa vermelho com o número na queda. */
    .ws-olt-btn{position:fixed;right:16px;bottom:48px;z-index:99989;display:inline-flex;align-items:center;gap:5px;padding:5px 11px;border-radius:9px;
      border:1px solid #ef4444;background:#fff;color:#dc2626;font:700 12px/1.2 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.18)}
    .ws-olt-btn:hover{background:#fef2f2}
    .ws-olt-btn{cursor:grab;user-select:none;-webkit-user-select:none;touch-action:none}
    .ws-olt-btn-t{cursor:pointer;display:inline-flex;align-items:center;gap:4px}
    .ws-olt-btn-c{display:inline-flex;gap:3px;margin-left:4px}
    .ws-olt-btn-c button{width:18px;height:18px;padding:0;border-radius:5px;border:1px solid currentColor;background:transparent;color:inherit;font-size:9px;line-height:1;cursor:pointer;opacity:.75}
    .ws-olt-btn-c button:hover{opacity:1}
    .ws-olt-btn.mini{padding:6px 9px;border-radius:50%}
    .ws-olt-btn.mini .ws-olt-btn-nome,.ws-olt-btn.mini .ws-olt-btn-c{display:none}
    .ws-olt-btn.on{background:#dc2626;color:#fff;border-color:#dc2626;animation:wsOltPulse 1.2s ease-in-out infinite}
    .ws-olt-btn.on:hover{background:#b91c1c}
    .ws-olt-btn-n{background:#fff;color:#dc2626;border-radius:9px;padding:0 6px;font-size:10.5px;font-weight:800}
    @keyframes wsOltPulse{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.65);transform:scale(1)}50%{box-shadow:0 0 0 7px rgba(239,68,68,0);transform:scale(1.04)}}
    @media (prefers-reduced-motion:reduce){.ws-olt-btn.on{animation:none}}
    /* Janela "Atenção PON" — COMPACTA, logo acima do botão; min = só a barra no rodapé; max = maior, centralizada. */
    .ws-olt-jan{position:fixed;right:16px;bottom:84px;z-index:99990;width:min(320px,calc(100vw - 32px));max-height:min(60vh,440px);display:flex;flex-direction:column;
      background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:10px;box-shadow:0 12px 32px rgba(0,0,0,.25);overflow:hidden;
      font:400 12px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;text-align:left;text-transform:none;letter-spacing:normal}
    .ws-olt-jan[hidden]{display:none}
    .ws-olt-jan.max{bottom:auto;top:8vh;right:50%;transform:translateX(50%);width:min(640px,calc(100vw - 32px));max-height:80vh}
    .ws-olt-jan.min{width:min(220px,calc(100vw - 32px));max-height:none}
    .ws-olt-jan.min .ws-olt-jan-corpo{display:none}
    .ws-olt-jan-top{display:flex;align-items:center;gap:5px;padding:6px 8px;background:linear-gradient(135deg,#b91c1c,#7f1d1d);color:#fff}
    .ws-olt-jan-tit{flex:1;font-weight:800;font-size:12px}
    .ws-olt-jan-tit small{background:#fff;color:#b91c1c;border-radius:9px;padding:0 5px;font-size:10px;margin-left:3px}
    .ws-olt-jan-top button{width:20px;height:20px;border-radius:5px;border:1px solid rgba(255,255,255,.45);background:transparent;color:#fff;cursor:pointer;font-size:10px;line-height:1;padding:0}
    .ws-olt-jan-top button:hover{background:rgba(255,255,255,.18)}
    .ws-olt-jan-corpo{overflow:auto;padding:8px;display:flex;flex-direction:column;gap:6px}
    .ws-olt-oc{border:1px solid var(--border);border-left:3px solid #dc2626;border-radius:8px;padding:6px 8px}
    .ws-olt-oc-ener{border-left-color:#f59e0b}.ws-olt-oc-placa{border-left-color:#7c3aed}
    .ws-olt-oc-l1{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
    .ws-olt-oc-l1 b{font-size:12px}
    .ws-olt-tag{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.3px;padding:1px 6px;border-radius:9px;background:rgba(220,38,38,.12);color:#dc2626}
    .ws-olt-oc-ener .ws-olt-tag{background:rgba(245,158,11,.15);color:#b45309}.ws-olt-oc-placa .ws-olt-tag{background:rgba(124,58,237,.12);color:#6d28d9}
    .ws-olt-hora{margin-left:auto;font-size:10.5px;opacity:.7}
    .ws-olt-oc-l2{display:flex;flex-wrap:wrap;gap:2px 10px;margin-top:3px;font-size:11px;opacity:.85}
    .ws-olt-vazio{padding:10px;text-align:center;opacity:.8}
    .ws-olt-jan-ir{align-self:flex-end;font-size:11.5px;font-weight:700;text-decoration:none;padding:2px}
    @media(max-width:560px){ .ws-olt-btn{right:10px;bottom:44px;padding:4px 9px;font-size:11px} .ws-olt-jan{right:10px;bottom:78px;width:calc(100vw - 20px)} }
    /* Ícone de lista rápida (tarja do topo e cabeçalho da lista de clientes) — VERDE e discreto. */
    .ws-status-bar .ws-st-conex{display:inline-flex;align-items:center;cursor:pointer;color:var(--ok);opacity:.8;padding:1px 3px;border-radius:5px;transition:opacity .15s,background-color .15s}
    .ws-status-bar .ws-st-conex:hover,.ws-status-bar .ws-st-conex[aria-expanded="true"],.ws-status-bar .ws-st-conex:focus-visible{opacity:1;background:rgba(22,163,74,.14);outline:none}
    .ws-conex-pop{position:fixed;z-index:9999;width:min(390px,calc(100vw - 16px));max-height:min(440px,72vh);display:flex;flex-direction:column;
                  background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.18);font-size:12.5px;
                  text-align:left;font-weight:400;text-transform:none;letter-spacing:normal}
    .ws-conex-pop[hidden]{display:none}
    .ws-conex-topo{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid var(--border)}
    .ws-conex-abas{display:flex;gap:4px;flex:1;flex-wrap:wrap}
    .ws-conex-abas button{border:1px solid var(--border);background:transparent;color:var(--muted,inherit);border-radius:7px;padding:4px 9px;font-size:12px;cursor:pointer}
    .ws-conex-abas button.on{background:var(--ok);border-color:var(--ok);color:#fff}
    .ws-conex-abas button span{opacity:.85}
    .ws-conex-topo select{width:auto;padding:3px 6px;font-size:12px;border:1px solid var(--border);border-radius:7px;background:var(--bg);color:inherit}
    .ws-conex-lista{overflow:auto;padding:4px 0}
    .ws-conex-item{display:flex;align-items:center;gap:8px;padding:6px 12px;border-bottom:1px solid var(--border);text-decoration:none;color:inherit}
    .ws-conex-item:last-child{border-bottom:0}
    a.ws-conex-item:hover{background:var(--surface-2,rgba(0,0,0,.04))}
    .ws-conex-item .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .ws-conex-item .n small{display:block;opacity:.65;font-size:11px;overflow:hidden;text-overflow:ellipsis}
    .ws-conex-item .t{white-space:nowrap;opacity:.75;font-size:11.5px;text-align:right}
    .ws-conex-item .o{min-width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;
                      background:rgba(22,163,74,.14);color:var(--ok);font-size:11px;font-weight:700}
    .ws-conex-vazio{padding:16px 12px;opacity:.7;text-align:center}
    </style>
    <script>
    /* LISTA RÁPIDA — um componente para os ícones discretos do sistema (tarja do topo: quem voltou
       e quem caiu; cabeçalho da lista de clientes: instalados recentes). A lista só é buscada no
       clique; nada roda no carregamento da página.
       cfg = { url(estado) -> endereço, abas:[{id,rot}], periodos:[[valor,rótulo]], item(i, aba) -> html, vazio(aba, dados) -> texto } */
    (function(){
      if (window.wsPopLista) return;
      var esc = window.wsEsc = function(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); };
      window.wsDur = function(m){ if(m<60) return m+' min'; var h=Math.floor(m/60); return h<24 ? h+'h'+(m%60?String(m%60).padStart(2,'0'):'') : Math.floor(h/24)+'d'; };
      window.wsPopLista = function(btn, cfg){
        if(!btn || btn.dataset.wsPop) return; btn.dataset.wsPop='1';
        var pop=document.createElement('div'); pop.className='ws-conex-pop'; pop.hidden=true;
        pop.innerHTML='<div class="ws-conex-topo"><div class="ws-conex-abas">'
          + cfg.abas.map(function(a,i){ return '<button type="button" data-aba="'+a.id+'"'+(i?'':' class="on"')+'>'+a.rot+' <span></span></button>'; }).join('')
          + '</div>' + (cfg.periodos ? '<select aria-label="Período">'+cfg.periodos.map(function(p){return '<option value="'+p[0]+'">'+p[1]+'</option>';}).join('')+'</select>' : '')
          + '</div><div class="ws-conex-lista"></div>';
        document.body.appendChild(pop);
        var lista=pop.querySelector('.ws-conex-lista'), sel=pop.querySelector('select'), aba=cfg.abas[0].id, dados=null;
        function posicionar(){ var r=btn.getBoundingClientRect(), w=pop.offsetWidth||390;
          pop.style.top=Math.round(r.bottom+6)+'px'; pop.style.left=Math.round(Math.max(8,Math.min(r.left-w/2+r.width/2, window.innerWidth-w-8)))+'px'; }
        function desenhar(){
          if(!dados){ lista.innerHTML='<div class="ws-conex-vazio">Carregando…</div>'; return; }
          if(dados.status!=='ok'){ lista.innerHTML='<div class="ws-conex-vazio">'+esc(dados.msg||'Sem resposta.')+'</div>'; return; }
          pop.querySelectorAll('.ws-conex-abas button').forEach(function(b){ b.classList.toggle('on',b.dataset.aba===aba); b.querySelector('span').textContent='('+(dados[b.dataset.aba]||[]).length+')'; });
          var itens=dados[aba]||[];
          lista.innerHTML = itens.length ? itens.map(function(i,n){ return cfg.item(i, aba, n); }).join('') : '<div class="ws-conex-vazio">'+esc(cfg.vazio(aba, dados))+'</div>';
        }
        function carregar(){ dados=null; desenhar();
          fetch(cfg.url(sel ? sel.value : ''), {cache:'no-store', credentials:'same-origin'})
            .then(function(r){ return r.json(); }).then(function(d){ dados=d; desenhar(); })
            .catch(function(){ dados={status:'erro', msg:'Não foi possível carregar agora.'}; desenhar(); }); }
        function abrir(){ document.querySelectorAll('.ws-conex-pop').forEach(function(p){ if(p!==pop) p.hidden=true; });
          pop.hidden=false; btn.setAttribute('aria-expanded','true'); posicionar(); carregar(); }
        function fechar(){ pop.hidden=true; btn.setAttribute('aria-expanded','false'); }
        btn.addEventListener('click',function(e){ e.preventDefault(); e.stopPropagation(); pop.hidden?abrir():fechar(); });
        btn.addEventListener('keydown',function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); btn.click(); } });
        pop.addEventListener('click',function(e){ e.stopPropagation(); var b=e.target.closest('.ws-conex-abas button'); if(b){ aba=b.dataset.aba; desenhar(); } });
        if(sel) sel.addEventListener('change',carregar);
        document.addEventListener('click',function(){ if(!pop.hidden) fechar(); });
        document.addEventListener('keydown',function(e){ if(e.key==='Escape'&&!pop.hidden) fechar(); });
        window.addEventListener('resize',function(){ if(!pop.hidden) posicionar(); });
        window.addEventListener('scroll',function(){ if(!pop.hidden) posicionar(); },{passive:true});
      };

      // Tarja do topo: quem VOLTOU a conectar e quem CAIU.
      var pagCli = /crm\.php/.test(location.pathname) ? 'crm.php' : 'erp.php';
      wsPopLista(document.getElementById('wsConexBtn'), {
        url: function(h){ return 'conexoes_recentes.php?h='+encodeURIComponent(h); },
        abas: [{id:'voltaram', rot:'▲ Voltaram'}, {id:'cairam', rot:'▼ Caíram'}],
        periodos: [['1','1 h'], ['6','6 h'], ['24','24 h']],
        vazio: function(aba, d){ return (aba==='voltaram'?'Ninguém voltou a conectar':'Ninguém caiu')+' nas últimas '+d.horas+' h.'; },
        item: function(i, aba){
          var extra = aba==='voltaram' ? (i.fora_min ? 'ficou fora '+wsDur(i.fora_min) : 'conectou') : (i.causa ? esc(i.causa) : 'desconectou');
          var corpo='<span class="n">'+esc(i.nome||i.login)+'<small>'+esc(i.nome?i.login:'sem cadastro')+' · '+extra+'</small></span><span class="t">'+esc(i.hora)+'<br>há '+wsDur(i.ha_min)+'</span>';
          return i.cliente_id ? '<a class="ws-conex-item" href="'+pagCli+'?p=cliente&id='+i.cliente_id+'">'+corpo+'</a>' : '<div class="ws-conex-item">'+corpo+'</div>';
        }
      });
    })();
    </script>
    <?php
    return (string)ob_get_clean();
}
