/* WellSystem — service worker do APP DO TÉCNICO (01/10/2026). Só cuida das páginas do técnico
 * (tecnico_app.php e chamado_tec.php): busca na rede e, sem sinal, mostra a última cópia salva.
 * Qualquer outra página do sistema passa direto, sem cache. */
var CACHE = 'ws-tecnico-v1';
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function (e) {
  var u = new URL(e.request.url);
  if (e.request.method !== 'GET' || !/\/(tecnico_app|chamado_tec|tecnico_icone)\.php$/.test(u.pathname)) return;
  e.respondWith(fetch(e.request).then(function (r) {
    if (r && r.ok) { var c = r.clone(); caches.open(CACHE).then(function (k) { k.put(e.request, c); }); }
    return r;
  }).catch(function () {
    return caches.match(e.request).then(function (r) {
      return r || new Response('<meta charset="utf-8"><body style="font-family:system-ui;padding:24px;text-align:center">📴 Sem internet e sem cópia salva desta página.</body>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    });
  }));
});
