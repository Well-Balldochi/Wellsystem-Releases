<?php
/**
 * WellSystem — 2FA (TOTP compatível com Google Authenticator / Authy), sem libs externas.
 * Segredo base32 por usuário (ws_usuario.twofa_secret), código de 6 dígitos, janela 30s ±1.
 */

/** Gera um segredo base32 aleatório (padrão para apps TOTP). */
function ws_totp_secret(int $len = 16): string {
    $abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = '';
    for ($i = 0; $i < $len; $i++) $s .= $abc[random_int(0, 31)];
    return $s;
}

/** Decodifica base32 (RFC 4648) para binário. */
function ws_base32_decode(string $b32): string {
    $abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Z2-7]/', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $ch) $bits .= str_pad(decbin(strpos($abc, $ch)), 5, '0', STR_PAD_LEFT);
    $bin = '';
    foreach (str_split($bits, 8) as $byte) if (strlen($byte) === 8) $bin .= chr(bindec($byte));
    return $bin;
}

/** Código TOTP de 6 dígitos para um instante (padrão: agora). */
function ws_totp_code(string $secret, ?int $tempo = null): string {
    $key = ws_base32_decode($secret);
    $contador = floor(($tempo ?? time()) / 30);
    $bin = pack('N*', 0) . pack('N*', $contador);   // 8 bytes big-endian
    $hash = hash_hmac('sha1', $bin, $key, true);
    $offset = ord(substr($hash, -1)) & 0x0F;
    $parte = (unpack('N', substr($hash, $offset, 4))[1] & 0x7FFFFFFF) % 1000000;
    return str_pad((string)$parte, 6, '0', STR_PAD_LEFT);
}

/** Verifica um código, tolerando ±1 janela (relógio levemente fora). */
function ws_totp_verifica(string $secret, string $code, int $janela = 1): bool {
    $code = preg_replace('/\D/', '', $code);
    if (strlen($code) !== 6) return false;
    $t = time();
    for ($i = -$janela; $i <= $janela; $i++)
        if (hash_equals(ws_totp_code($secret, $t + $i * 30), $code)) return true;
    return false;
}

/** URI otpauth:// (para QR Code ou entrada manual no app). */
function ws_totp_uri(string $secret, string $conta, string $emissor = 'WellSystem'): string {
    return 'otpauth://totp/' . rawurlencode($emissor . ':' . $conta)
         . '?secret=' . $secret . '&issuer=' . rawurlencode($emissor) . '&period=30&digits=6';
}

/** Gera N códigos de recuperação (uso único). */
function ws_2fa_recovery_gerar(int $n = 8): array {
    $out = [];
    for ($i = 0; $i < $n; $i++) $out[] = strtoupper(bin2hex(random_bytes(4)));  // 8 hex
    return $out;
}
