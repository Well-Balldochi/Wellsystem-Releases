<?php
/**
 * WellSystem — URA TELEFÔNICA (14/11/2026, pedido do dono): o cliente liga, digita o CPF/CNPJ do titular e faz pelo telefone o que o robô do WhatsApp faz:
 *   1 segunda via (resumo falado + boleto/PIX por WhatsApp)   2 liberação em confiança   3 suporte   4 atendente.
 * Quem fala com o cliente é o PABX (agi wn_ura.php, na VM do telefone); aqui fica SÓ a regra, em POST /api/ura/{acao}.
 * Nada é duplicado: a 2ª via usa ws_chatbot_titulos(); confiança, diagnóstico, reconectar e chamado usam as rotas /api/conexao/* do robô (mesmas travas:
 * confiança 1 vez por ciclo, reconectar 2x/hora, chamado único por cliente).
 * REGRAS: mensagem automática ao cliente sai SÓ pela Wellnet-02 (ws_wa_enviar decide janela/template); 1 envio por ligação (o PABX garante) e no máximo
 * N por CPF em 24 h (cache/ura_envios.json) — cada mensagem da API custa dinheiro. Cliente cancelado/desativado nunca recebe nada (ws_msg_cliente_permitido).
 * Autenticação própria: cabeçalho X-URA-Chave = chave em cache/ura.json (gerada por Manutenção → URA telefônica). Sem chave = tudo recusado.
 */
if (!function_exists('ws_ura_arquivo')) {

function ws_ura_arquivo(): string { return (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/ura.json'; }

function ws_ura_cfg(): array {
    $c = json_decode((string)@file_get_contents(ws_ura_arquivo()), true);
    $c = is_array($c) ? $c : [];
    return ['ativo' => array_key_exists('ativo', $c) ? !empty($c['ativo']) : true,
            'envio_whatsapp' => array_key_exists('envio_whatsapp', $c) ? !empty($c['envio_whatsapp']) : true,
            'voz' => array_key_exists('voz', $c) ? !empty($c['voz']) : true,
            'chat_menu' => array_key_exists('chat_menu', $c) ? !empty($c['chat_menu']) : true,
            'envio_dia' => max(1, (int)($c['envio_dia'] ?? 3)),
            'chave' => (string)($c['chave'] ?? '')];
}

function ws_ura_salvar(array $novo): void {
    $c = array_merge(ws_ura_cfg(), $novo);
    @file_put_contents(ws_ura_arquivo(), json_encode($c, JSON_PRETTY_PRINT), LOCK_EX);
    @chmod(ws_ura_arquivo(), 0640);
}

/** Gera (ou troca) a chave da URA. A chave só é mostrada a quem está na Manutenção (root) e gravada no PABX; nunca vai a log/CHANGELOG. */
function ws_ura_chave_gerar(): string {
    $k = bin2hex(random_bytes(24));
    ws_ura_salvar(['chave' => $k]);
    return $k;
}

function ws_ura_chave_ok(string $enviada): bool {
    $k = ws_ura_cfg()['chave'];
    return $k !== '' && $enviada !== '' && hash_equals($k, $enviada);
}

/** Só dígitos; 11/14 = CPF/CNPJ, senão ''. */
function ws_ura_doc(string $s): string {
    $d = preg_replace('/\D/', '', $s);
    return (strlen($d) === 11 || strlen($d) === 14) ? $d : '';
}

/** Número de quem ligou no formato do WhatsApp (55 + DDD + número) ou '' se não der para usar (anônimo, curto, fixo sem WhatsApp não é checado aqui). */
function ws_ura_tel(string $t): string {
    $d = preg_replace('/\D/', '', $t);
    if ($d === '' || strlen($d) < 10) return '';
    if (strlen($d) >= 12 && substr($d, 0, 2) === '55') return $d;
    if (strlen($d) >= 11 && $d[0] === '0') $d = ltrim($d, '0');          // 081 99596-4040 (zero de operadora/DDD)
    if (strlen($d) === 10 || strlen($d) === 11) return '55' . $d;
    return strlen($d) >= 12 ? $d : '';
}

/** Cadastro vivo do titular pelo CPF/CNPJ: ['id','nome'(1º nome),'celular','bloqueado'] ou null. */
function ws_ura_cliente(PDO $db, string $doc): ?array {
    $st = $db->prepare("SELECT c.id, c.nome, c.celular, c.telefone FROM ws_cliente c
                         WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND COALESCE(c.status,'') NOT IN ('cancelado','desativado')
                         ORDER BY (c.titular_id IS NOT NULL), c.id LIMIT 1");
    $st->execute([$doc]); $r = $st->fetch(PDO::FETCH_ASSOC);
    if (!$r) return null;
    $q = $db->prepare("SELECT COUNT(*) FROM ws_contrato WHERE cliente_id=? AND status='bloqueado'");
    $q->execute([(int)$r['id']]);
    $nome = trim((string)preg_replace('/\s+/', ' ', (string)$r['nome']));
    return ['id' => (int)$r['id'], 'nome' => explode(' ', $nome)[0], 'nome_completo' => $nome, 'celular' => (string)($r['celular'] ?: $r['telefone']), 'bloqueado' => (int)$q->fetchColumn() > 0];
}

/** Envios por CPF nas últimas 24 h (cache/ura_envios.json). */
function ws_ura_envios_dia(string $doc, bool $registrar = false, int $limite = 3): bool {
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/ura_envios.json';
    $fp = @fopen($arq, 'c+'); if (!$fp) return true;
    flock($fp, LOCK_EX);
    $j = json_decode((string)stream_get_contents($fp), true); $j = is_array($j) ? $j : [];
    $agora = time(); $k = hash('sha256', $doc);
    foreach ($j as $kk => $ts) { $j[$kk] = array_values(array_filter((array)$ts, fn($t) => $agora - (int)$t < 86400)); if (!$j[$kk]) unset($j[$kk]); }
    $ok = count($j[$k] ?? []) < $limite;
    if ($ok && $registrar) $j[$k][] = $agora;
    ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($j)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    @chmod($arq, 0640);
    return $ok;
}

function ws_ura_reais(float $v): string { return 'R$ ' . number_format($v, 2, ',', '.'); }

/** Texto do boleto/PIX enviado por WhatsApp (padrão do dono: uma frase por linha, linha em branco entre blocos, marcador no começo, despedida curta). Máx. 3 títulos. */
function ws_ura_texto_boleto(string $nome, array $titulos): string {
    $t = "🧾 *2ª via do boleto*\n\nOlá, *" . $nome . "*!\nConforme pedido por ligação, seguem os dados.";
    foreach (array_slice($titulos, 0, 3) as $x) {
        $t .= "\n\n📅 Vencimento: *" . date('d/m/Y', strtotime((string)$x['datavenc'])) . "*\n💰 Valor: *" . ws_ura_reais((float)$x['valor']) . "*";
        if ((string)($x['pix'] ?? '') !== '') $t .= "\n\n📋 *Pix copia e cola:*\n" . $x['pix'];
        if ((string)($x['pix_link'] ?? '') !== '') $t .= "\n\n🔗 Boleto e QR Code:\n" . $x['pix_link'];
    }
    if (count($titulos) > 3) $t .= "\n\nℹ️ Há mais " . (count($titulos) - 3) . " em aberto. Peça a 2ª via de novo por aqui.";
    return $t . "\n\nAgradecemos! 🙏";
}

/** Chama as rotas do robô no próprio servidor (mesma credencial/regras). O servidor não alcança o próprio endereço público: resolve para 127.0.0.1 mantendo o nome (SNI/Host certos). */
function ws_ura_robo(string $metodo, string $caminho, array $corpo = []): array {
    if (!function_exists('ws_chatbot_token_emitir')) require_once __DIR__ . '/api_chatbot.php';
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($host === '' || !preg_match('/^[a-z0-9.\-]+$/', $host)) $host = strtolower((string)parse_url(trim((string)@file_get_contents((defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/api_base.txt')), PHP_URL_HOST));
    if ($host === '') return [];
    $ch = curl_init('https://' . $host . '/api/' . ltrim($caminho, '/'));
    $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 70, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_RESOLVE => [$host . ':443:127.0.0.1'], CURLOPT_CUSTOMREQUEST => $metodo,
          CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . ws_chatbot_token_emitir(ws_chatbot_cfg())]];   // token assinado na hora (só deste servidor), como ws_api_liberar_confianca()
    if ($metodo !== 'GET') $o[CURLOPT_POSTFIELDS] = json_encode($corpo, JSON_UNESCAPED_UNICODE);
    curl_setopt_array($ch, $o);
    $r = curl_exec($ch); curl_close($ch);
    $j = json_decode((string)$r, true);
    return is_array($j) ? $j : [];
}

/* VOZ NA URA (14/11/2026, pedido do dono): o cliente pode FALAR em vez de digitar. O PABX grava a fala e manda para POST /api/ura/voz; aqui o áudio é
   transcrito pelo mesmo Whisper do chat (ws_chatbot_transcrever) e traduzido em opção do menu ou em dígitos do CPF/CNPJ. Teclado continua valendo em tudo.
   Segurança: "confiança" (opção 2) SÓ pela palavra "confiança" ou pelo número — nunca por interpretação; CPF falado só vale se o dígito verificador bater
   (ou o cadastro existir). O texto transcrito NÃO é gravado em log (pode ter CPF). */

function ws_ura_voz_norm(string $t): string {
    $t = strtr(mb_strtolower($t, 'UTF-8'), ['á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'é' => 'e', 'ê' => 'e', 'í' => 'i', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ú' => 'u', 'ü' => 'u', 'ç' => 'c']);
    return trim((string)preg_replace('/\s+/', ' ', (string)preg_replace('/[^a-z0-9 ]/', ' ', $t)));
}

/**
 * Fala → só os dígitos. Aceita "123.456.789-01", "um dois três…" e também blocos por extenso, como as pessoas falam o CPF:
 * "cento e onze, quatrocentos e quarenta e quatro, setecentos e setenta e sete, trinta e cinco" → 11144477735 ("mil"/"milhões" só separam blocos).
 */
function ws_ura_voz_digitos(string $t): string {
    $u = ['zero' => 0, 'um' => 1, 'uma' => 1, 'dois' => 2, 'duas' => 2, 'tres' => 3, 'quatro' => 4, 'cinco' => 5, 'seis' => 6, 'meia' => 6, 'sete' => 7, 'oito' => 8, 'nove' => 9];
    $esp = ['dez' => 10, 'onze' => 11, 'doze' => 12, 'treze' => 13, 'quatorze' => 14, 'catorze' => 14, 'quinze' => 15, 'dezesseis' => 16, 'dezasseis' => 16, 'dezessete' => 17, 'dezoito' => 18, 'dezenove' => 19];
    $dez = ['vinte' => 20, 'trinta' => 30, 'quarenta' => 40, 'cinquenta' => 50, 'sessenta' => 60, 'setenta' => 70, 'oitenta' => 80, 'noventa' => 90];
    $cen = ['cem' => 100, 'cento' => 100, 'duzentos' => 200, 'duzentas' => 200, 'trezentos' => 300, 'trezentas' => 300, 'quatrocentos' => 400, 'quatrocentas' => 400, 'quinhentos' => 500, 'quinhentas' => 500,
            'seiscentos' => 600, 'seiscentas' => 600, 'setecentos' => 700, 'setecentas' => 700, 'oitocentos' => 800, 'oitocentas' => 800, 'novecentos' => 900, 'novecentas' => 900];
    $out = ''; $g = null; $nivel = 0;   // bloco em montagem: $nivel 3 = acabou de vir a centena, 2 = a dezena
    $fecha = function () use (&$out, &$g, &$nivel): void { if ($g !== null) $out .= (string)$g; $g = null; $nivel = 0; };
    foreach (explode(' ', ws_ura_voz_norm($t)) as $w) {
        if ($w === '' || $w === 'e') continue;
        if (ctype_digit($w)) { $fecha(); $out .= $w; }
        elseif (isset($cen[$w])) { $fecha(); $g = $cen[$w]; $nivel = 3; }
        elseif (isset($dez[$w])) { if ($nivel === 3) $g += $dez[$w]; else { $fecha(); $g = $dez[$w]; } $nivel = 2; }
        elseif (isset($esp[$w])) { if ($nivel === 3) { $g += $esp[$w]; $fecha(); } else { $fecha(); $out .= (string)$esp[$w]; } }
        elseif (isset($u[$w])) { if ($nivel >= 2) { $g += $u[$w]; $fecha(); } else { $fecha(); $out .= (string)$u[$w]; } }
        else $fecha();
    }
    $fecha();
    return $out;
}

/** Dígito verificador de CPF (11) ou CNPJ (14). */
function ws_ura_doc_valido(string $d): bool {
    if (!ctype_digit($d)) return false;
    if (strlen($d) === 11) {
        if (preg_match('/^(\d)\1{10}$/', $d)) return false;
        for ($t = 9; $t < 11; $t++) { $s = 0; for ($c = 0; $c < $t; $c++) $s += (int)$d[$c] * (($t + 1) - $c); if ((int)$d[$t] !== (($s * 10) % 11) % 10) return false; }
        return true;
    }
    if (strlen($d) === 14) {
        if (preg_match('/^(\d)\1{13}$/', $d)) return false;
        foreach ([[12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]], [13, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]]] as [$pos, $pesos]) {
            $s = 0; foreach ($pesos as $i => $p) $s += (int)$d[$i] * $p;
            $r = $s % 11; if ((int)$d[$pos] !== ($r < 2 ? 0 : 11 - $r)) return false;
        }
        return true;
    }
    return false;
}

/** Fala → opção. $ctx: menu (1 boleto, 2 confiança, 3 suporte, 4 comprovante, 5 atendente, 0 repetir) · sup (1 reconectar, 2 chamado) · voltar (9 menu, 5 atendente). '' = não entendi. */
function ws_ura_voz_opcao(string $t, string $ctx): string {
    $n = ws_ura_voz_norm($t);
    if ($n === '') return '';
    $num = ['0' => '0', 'zero' => '0', '1' => '1', 'um' => '1', 'uma' => '1', '2' => '2', 'dois' => '2', '3' => '3', 'tres' => '3', '4' => '4', 'quatro' => '4', '5' => '5', 'cinco' => '5', '9' => '9', 'nove' => '9'];
    if (preg_match('/^(?:opcao |numero |digito |tecla )?(\S+)$/', $n, $m) && isset($num[$m[1]])) return $num[$m[1]];
    if ($ctx === 'menu') {
        if (preg_match('/atendente|atendimento|humano|pessoa|operador|alguem|gente|recepcao/', $n)) return '5';
        if (preg_match('/comprovante|recibo/', $n)) return '4';
        if (strpos($n, 'confian') !== false) return '2';
        if (preg_match('/segunda via|2 via|2a via|boleto|fatura|pagamento|pagar|\bpix\b|mensalidade|\bconta\b/', $n)) return '1';
        if (preg_match('/suporte|internet|conexao|sinal|lent|caiu|tecnico|problema|funcion|navega|wifi|wi fi|roteador/', $n)) return '3';
        if (preg_match('/ouvir|repetir|de novo|novamente/', $n)) return '0';
        return '';
    }
    if ($ctx === 'tipo') {   // 17/11/2026: 1 vencidos, 2 a vencer
        if (preg_match('/a vencer|avencer|vencer|proxim|futur|nao venceu|ainda nao/', $n)) return '2';
        if (preg_match('/vencid|atrasad|em atraso|passou/', $n)) return '1';
        return '';
    }
    if ($ctx === 'sup') {
        if (preg_match('/chamado|tecnico|abrir|visita|atendente/', $n)) return '2';
        if (preg_match('/reconect|religar|reinicia|resetar|conectar|tentar/', $n)) return '1';
        return '';
    }
    if ($ctx === 'voltar') {
        if (preg_match('/atendente|humano|pessoa|falar com/', $n)) return '5';
        if (preg_match('/menu|voltar|outro|outra|mais|continuar|sim/', $n)) return '9';
        return '';
    }
    return '';
}

/** Palavras do nome (sem artigos/conectivos/enchimento de fala), minúsculas e sem acento. */
function ws_ura_nome_tokens(string $n): array {
    $ign = ['de', 'da', 'do', 'das', 'dos', 'meu', 'nome', 'sou', 'titular', 'cpf', 'cnpj', 'numero', 'mil', 'milhao', 'milhoes', 'senhor', 'senhora', 'obrigado', 'obrigada', 'tchau', 'alo', 'ola', 'bom', 'boa', 'dia', 'tarde', 'noite', 'por', 'favor', 'quero', 'aqui', 'esta', 'este', 'que', 'com'];
    $t = [];
    foreach (explode(' ', ws_ura_voz_norm($n)) as $w) if (strlen($w) >= 3 && !in_array($w, $ign, true)) $t[] = $w;
    return $t;
}

/** Nome falado (transcrição) → palavras do nome separadas por espaço; '' se não parece um nome. */
function ws_ura_voz_nome(string $txt): string { return implode(' ', ws_ura_nome_tokens($txt)); }

/** O nome falado confere com o do cadastro? 2+ palavras: ao menos 2 batem; 1 palavra: tem de ser o primeiro nome. Tolera 1 letra de diferença em palavras com 6+ letras (erro de transcrição; "Maria" x "Mario" não se confundem). */
function ws_ura_nome_confere(string $registrado, string $falado): bool {
    $r = ws_ura_nome_tokens($registrado); $s = ws_ura_nome_tokens($falado);
    if (!$r || !$s) return false;
    $igual = function (string $a, string $b): bool { return $a === $b || (strlen($a) >= 6 && strlen($b) >= 6 && levenshtein($a, $b) <= 1); };
    if (count($s) === 1) return $igual($s[0], $r[0]);
    $ach = 0;
    foreach ($s as $w) foreach ($r as $x) { if ($igual($w, $x)) { $ach++; break; } }
    return $ach >= 2;
}

/** POST /api/ura/voz — {ctx: menu|sup|voltar|cpf|ident, audio: base64 de WAV}. Devolve {opcao}, {digitos} ou (ident) {nome}. */
function ws_ura_voz(array $in): array {
    $cfg = ws_ura_cfg();
    if (!$cfg['ativo']) return ['ok' => false, 'situacao' => 'desligada'];
    if (!$cfg['voz']) return ['ok' => true, 'situacao' => 'voz_desligada', 'opcao' => '', 'digitos' => ''];
    $ctx = (string)($in['ctx'] ?? '');
    $bin = base64_decode((string)($in['audio'] ?? ''), true);
    if (!in_array($ctx, ['menu', 'sup', 'voltar', 'tipo', 'cpf', 'ident'], true) || $bin === false || strlen($bin) < 3000 || strlen($bin) > 3 * 1024 * 1024) return ['ok' => false, 'situacao' => 'invalido'];
    if (!function_exists('ws_chatbot_transcrever')) require_once __DIR__ . '/api_chatbot.php';
    $dicas = ['cpf' => 'Número de CPF (11 dígitos) ou CNPJ (14 dígitos) falado dígito por dígito, em português do Brasil. Exemplo: cinco, dois, nove, nove, oito, dois, dois, quatro, sete, dois, cinco.',
              'ident' => 'Ou o número do CPF (11 dígitos) ou CNPJ (14 dígitos) falado dígito por dígito, por exemplo: cinco, dois, nove, nove, oito, dois, dois, quatro, sete, dois, cinco; ou o nome completo de uma pessoa, por exemplo: Maria Aparecida da Silva.',
              'menu' => 'Menu da Wellnet: segunda via do boleto, liberação em confiança, suporte técnico, enviar comprovante de pagamento, falar com um atendente.',
              'sup' => 'Reconectar ou abrir um chamado técnico.', 'tipo' => 'Boletos vencidos ou boletos a vencer.', 'voltar' => 'Voltar ao menu ou falar com um atendente.'];
    $erro = '';
    $modelos = in_array($ctx, ['cpf', 'ident'], true) ? ['gpt-4o-transcribe', 'gpt-4o-mini-transcribe', 'whisper-1'] : [];   // número falado: modelo maior primeiro
    $txt = ws_chatbot_transcrever($bin, 'audio/wav', $erro, $dicas[$ctx], $modelos);
    $r = ['ok' => true, 'situacao' => $txt === '' ? 'sem_texto' : 'ok', 'opcao' => '', 'digitos' => '', 'nome' => ''];
    $nd = 0;
    if ($txt !== '') {
        if ($ctx === 'cpf' || $ctx === 'ident') {
            $d = ws_ura_voz_digitos($txt); $nd = strlen($d);
            if ($nd >= 8) { if (in_array($nd, [11, 14], true) && (ws_ura_doc_valido($d) || ws_ura_cliente(ws_db(), $d))) $r['digitos'] = $d; }
            elseif ($ctx === 'ident' && $nd <= 1) $r['nome'] = ws_ura_voz_nome($txt);   // número pela metade nunca vira "nome"
        } else $r['opcao'] = ws_ura_voz_opcao($txt, $ctx);
    }
    ws_ura_voz_log($ctx, strlen($bin), $r['situacao'] . ($erro !== '' ? ' (' . $erro . ')' : ''), $nd, $r['digitos'] !== '' || $r['opcao'] !== '' || $r['nome'] !== '');
    return $r;
}

/** Diagnóstico da voz (cache/ura_voz.log, últimas 200 linhas): contexto, bytes, situação, quantos dígitos entendeu e se resolveu. NUNCA grava o texto transcrito nem os dígitos. */
function ws_ura_voz_log(string $ctx, int $bytes, string $sit, int $nd, bool $resolveu): void {
    $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/ura_voz.log';
    $l = array_slice(array_filter(explode("\n", (string)@file_get_contents($f))), -199);
    $l[] = date('d/m H:i:s') . " ctx=$ctx bytes=$bytes sit=$sit digitos_entendidos=$nd resolveu=" . ($resolveu ? 'sim' : 'nao');
    @file_put_contents($f, implode("\n", $l) . "\n", LOCK_EX); @chmod($f, 0640);
}

/**
 * MENU DO CHAT DEPOIS DA LIGAÇÃO (15/11/2026). Opção 4 (atendente) FORA DO HORÁRIO: depois do aviso falado, o robô do WhatsApp comum (Wellnet-01) abre o menu
 * para quem ligou — só se o número de quem ligou tiver WhatsApp; se não tiver, fica só o aviso falado.
 * EXCEÇÃO autorizada pelo dono em 15/11/2026 à regra "envio automático só pela Wellnet-02" (CLAUDE.md §5): o cliente acabou de ligar e pediu atendimento.
 * Travas: 1 vez por número a cada 24 h, cliente ativo (ws_msg_cliente_permitido), robô da 01 ligado, instância no ar. Desliga em Manutenção → URA.
 * Devolve: iniciado | sem_whatsapp | nao_confirmou_whatsapp | instancia_fora | sem_instancia | robo_desligado | falhou_<http>.
 */
function ws_ura_chat_menu(string $tel, string $nome = ''): string {
    if (!function_exists('ws_at_evo')) require_once __DIR__ . '/atendimento_lib.php';
    $c = ws_wa_config(); $inst = ws_wa_instancia_comum_conversa($c);
    if ($inst === '') return 'sem_instancia';
    if (!ws_wa_instancia_online($inst, $c)) return 'instancia_fora';
    $num = ws_wa_numero($tel);
    [$s, $j] = ws_at_evo('POST', '/chat/whatsappNumbers/' . rawurlencode($inst), ['numbers' => [$num]], $inst);   // devolve o jid certo (com ou sem o 9)
    if ($s < 200 || $s >= 300 || !is_array($j) || !isset($j[0]) || !array_key_exists('exists', (array)$j[0])) return 'nao_confirmou_whatsapp';
    if (empty($j[0]['exists'])) return 'sem_whatsapp';
    $jid = (string)($j[0]['jid'] ?? ($num . '@s.whatsapp.net'));
    [$s, $b] = ws_at_evo('GET', '/typebot/find/' . rawurlencode($inst), null, $inst);
    $b = (is_array($b) && isset($b[0]) && is_array($b[0])) ? $b[0] : [];
    if (!$b || empty($b['enabled']) || (string)($b['url'] ?? '') === '' || (string)($b['typebot'] ?? '') === '') return 'robo_desligado';
    $vars = $nome !== '' ? [['name' => 'pushName', 'value' => $nome]] : [];
    [$s] = ws_at_evo('POST', '/typebot/start/' . rawurlencode($inst), ['url' => (string)$b['url'], 'typebot' => (string)$b['typebot'], 'remoteJid' => $jid, 'startSession' => true, 'variables' => $vars], $inst);
    return ($s >= 200 && $s < 300) ? 'iniciado' : 'falhou_' . $s;
}

/** Texto do COMPROVANTE pedido pela URA telefônica (17/11/2026, modelo do dono): saudação com o nome do provedor + pergunta do nome do cliente do pagamento.
 *  O resto (conferência do nome, selo antifraude, prazo — boleto até 2 dias úteis, PIX imediato — e agradecimento) já é feito pelo fluxo existente quando o comprovante chega. */
function ws_ura_texto_comprovante(): string {
    return "Olá! 👋
Seja bem-vindo à *Wellnet Telecom*.

🧾 Para enviar o comprovante de pagamento, responda esta mensagem:

*Qual o nome do cliente do pagamento que deseja enviar o comprovante?*

Depois, envie aqui a foto ou o PDF do comprovante.

Agradecemos! 🙏";
}

/**
 * COMPROVANTE pela URA (17/11/2026): em vez do menu do robô, manda pela Wellnet-01 a mensagem de saudação + pergunta do nome (ws_ura_texto_comprovante).
 * Mesma exceção, mesmas travas de ws_ura_chat_menu (só se o número tiver WhatsApp). Devolve: iniciado | sem_whatsapp | nao_confirmou_whatsapp | instancia_fora | sem_instancia | falhou_<http>.
 */
function ws_ura_comprovante_msg(string $tel): string {
    if (!function_exists('ws_at_evo')) require_once __DIR__ . '/atendimento_lib.php';
    $c = ws_wa_config(); $inst = ws_wa_instancia_comum_conversa($c);
    if ($inst === '') return 'sem_instancia';
    if (!ws_wa_instancia_online($inst, $c)) return 'instancia_fora';
    $num = ws_wa_numero($tel);
    [$s, $j] = ws_at_evo('POST', '/chat/whatsappNumbers/' . rawurlencode($inst), ['numbers' => [$num]], $inst);
    if ($s < 200 || $s >= 300 || !is_array($j) || !isset($j[0]) || !array_key_exists('exists', (array)$j[0])) return 'nao_confirmou_whatsapp';
    if (empty($j[0]['exists'])) return 'sem_whatsapp';
    $jid = (string)($j[0]['jid'] ?? ($num . '@s.whatsapp.net'));
    [$s] = ws_at_evo('POST', '/message/sendText/' . rawurlencode($inst), ['number' => preg_replace('/@.*/', '', $jid), 'text' => ws_ura_texto_comprovante()], $inst);
    return ($s >= 200 && $s < 300) ? 'iniciado' : 'falhou_' . $s;
}

/**
 * Ações da URA. $in = ['cpf','tel','simular'?]. Devolve sempre ['ok'=>bool,'situacao'=>'...'] + dados para a voz falar.
 * simular=true (testes): faz tudo MENOS enviar a mensagem de WhatsApp.
 */
function ws_ura_acao(PDO $db, string $acao, array $in): array {
    $cfg = ws_ura_cfg();
    if (!$cfg['ativo']) return ['ok' => false, 'situacao' => 'desligada'];
    $doc = ws_ura_doc((string)($in['cpf'] ?? ''));
    if ($doc === '') return ['ok' => false, 'situacao' => 'cpf_invalido'];
    $cli = ws_ura_cliente($db, $doc);
    if (!$cli) return ['ok' => false, 'situacao' => 'nao_encontrado'];
    $tel = ws_ura_tel((string)($in['tel'] ?? ''));

    switch ($acao) {
        case 'identificar':
            /* Entrou pelo NOME: o CPF achado VALE mesmo que o nome falado não confira — nomes como Wellington/Balldoci saem com grafias variadas na transcrição
               (caso real 15/11: CPF certo recusado 3 vezes) e pelo CPF direto ninguém precisa dizer nome. A confirmação para quem ligou é a URA falar o nome do
               cadastro ("Olá, <nome>"). Só registra (sem nomes) quando não confere, para acompanhar. */
            if (trim((string)($in['nome'] ?? '')) !== '' && !ws_ura_nome_confere($cli['nome_completo'], (string)$in['nome']))
                ws_ura_voz_log('ident_nome', 0, 'nome_nao_conferiu palavras_faladas=' . count(ws_ura_nome_tokens((string)$in['nome'])) . ' palavras_cadastro=' . count(ws_ura_nome_tokens($cli['nome_completo'])), 0, true);
            return ['ok' => true, 'situacao' => 'ok', 'nome' => $cli['nome'], 'bloqueado' => $cli['bloqueado']];

        case 'boleto': {
            if (!function_exists('ws_chatbot_titulos')) require_once __DIR__ . '/api_chatbot.php';
            /* 17/11/2026 (dono): o cliente escolhe VENCIDOS ou A VENCER (tipo) e só vai o que foi pedido: todos do tipo (indice 0, até 3) ou UM específico (indice N da lista).
               listar=1 só devolve a lista (dia, mês, valor) para a URA ler — não envia nada. Sem 'tipo' mantém o comportamento antigo (tudo em aberto). */
            $tipo = in_array((string)($in['tipo'] ?? ''), ['vencido', 'avencer'], true) ? (string)$in['tipo'] : '';
            $tit = ws_chatbot_titulos($db, $doc, $tipo === 'vencido' ? 'vencido' : 'aberto');
            if ($tipo === 'vencido') $tit = array_values(array_filter($tit, fn($x) => strtotime((string)$x['datavenc']) < strtotime(date('Y-m-d'))));
            if ($tipo === 'avencer') $tit = array_values(array_filter($tit, fn($x) => strtotime((string)$x['datavenc']) >= strtotime(date('Y-m-d'))));
            if (!$tit) return ['ok' => true, 'situacao' => 'sem_boleto', 'qtd' => 0, 'tipo' => $tipo];
            if (!empty($in['listar'])) {
                $itens = [];
                foreach (array_slice($tit, 0, 9) as $x) $itens[] = ['dia' => (int)date('j', strtotime((string)$x['datavenc'])), 'mes' => (int)date('n', strtotime((string)$x['datavenc'])), 'valor' => round((float)$x['valor'], 2), 'vencido' => strtotime((string)$x['datavenc']) < strtotime(date('Y-m-d'))];
                return ['ok' => true, 'situacao' => 'lista', 'tipo' => $tipo, 'qtd' => count($tit), 'itens' => $itens];
            }
            $ind = (int)($in['indice'] ?? 0);
            if ($ind > 0) { if (!isset($tit[$ind - 1])) return ['ok' => true, 'situacao' => 'sem_boleto', 'qtd' => 0, 'tipo' => $tipo]; $tit = [$tit[$ind - 1]]; }
            elseif ($tipo !== '') $tit = array_slice($tit, 0, 3);
            $total = 0.0; foreach ($tit as $x) $total += (float)$x['valor'];
            $t0 = $tit[0];
            $r = ['ok' => true, 'situacao' => 'boleto', 'tipo' => $tipo, 'qtd' => count($tit), 'total' => round($total, 2), 'valor' => round((float)$t0['valor'], 2),
                  'dia' => (int)date('j', strtotime((string)$t0['datavenc'])), 'mes' => (int)date('n', strtotime((string)$t0['datavenc'])),
                  'vencido' => strtotime((string)$t0['datavenc']) < strtotime(date('Y-m-d')), 'envio' => 'nao'];
            $dest = $tel !== '' ? $tel : ws_ura_tel($cli['celular']);
            if ($dest === '') { $r['envio'] = 'sem_numero'; return $r; }
            if (!$cfg['envio_whatsapp']) { $r['envio'] = 'desligado'; return $r; }
            if (function_exists('ws_msg_cliente_permitido') && !ws_msg_cliente_permitido($db, (int)$cli['id'])) { $r['envio'] = 'nao_permitido'; return $r; }
            if (!ws_ura_envios_dia($doc, false, $cfg['envio_dia'])) { $r['envio'] = 'limite'; return $r; }
            $r['destino'] = $tel !== '' ? 'chamador' : 'cadastro';
            if (!empty($in['simular'])) { $r['envio'] = 'simulado'; return $r; }
            if (!function_exists('ws_wa_enviar')) require_once __DIR__ . '/whatsapp.php';
            $env = ws_wa_enviar($dest, ws_ura_texto_boleto($cli['nome'], $tit), false, ['evento' => 'boleto', 'automatica' => true, 'garantir' => true]);
            if (!empty($env['ok'])) { ws_ura_envios_dia($doc, true, $cfg['envio_dia']); $r['envio'] = 'enviado'; } else { $r['envio'] = 'falhou'; }
            if (function_exists('ws_evento')) { try { ws_evento($db, (int)$cli['id'], 'robo', 'URA telefônica — 2ª via por ligação: ' . ($r['envio'] === 'enviado' ? 'dados enviados por WhatsApp' : 'envio ' . $r['envio']) . ' (final ' . substr($dest, -4) . ').'); } catch (Throwable $e) {} }
            return $r;
        }

        case 'confianca': {
            $j = ws_ura_robo('POST', 'conexao/confianca', ['cpf' => $doc, 'relato' => 'Pedido pela URA telefônica', 'origem' => 'ura']);   // origem=ura: já usou o do mês → NÃO abre solicitação, só informa (17/11/2026)
            $s = (string)($j['situacao'] ?? '');
            return ['ok' => !empty($j['ok']), 'situacao' => $s !== '' ? $s : 'erro'];
        }

        case 'suporte': {                                  // diagnóstico (sem efeito) — a voz decide o que oferecer
            $j = ws_ura_robo('GET', 'conexao/' . $doc);
            $s = (string)($j['situacao'] ?? '');
            return ['ok' => $s !== '', 'situacao' => $s !== '' ? $s : 'erro'];
        }

        case 'reconectar': {
            $j = ws_ura_robo('POST', 'conexao/reconectar', ['cpf' => $doc]);
            return ['ok' => !empty($j['ok']), 'situacao' => (string)($j['situacao'] ?? ($j ? 'recusado' : 'erro'))];
        }

        case 'chat': {                                     // opção 4 fora do horário: abre o menu do robô da Wellnet-01 para quem ligou (ver ws_ura_chat_menu)
            if (!$cfg['chat_menu']) return ['ok' => true, 'situacao' => 'desligado'];
            if ($tel === '') return ['ok' => true, 'situacao' => 'sem_numero'];
            if (function_exists('ws_msg_cliente_permitido') && !ws_msg_cliente_permitido($db, (int)$cli['id'])) return ['ok' => true, 'situacao' => 'nao_permitido'];
            if (!ws_ura_envios_dia('chat:' . $tel, false, 1)) return ['ok' => true, 'situacao' => 'limite'];
            if (!empty($in['simular'])) return ['ok' => true, 'situacao' => 'simulado'];
            if (!function_exists('ws_wa_config')) require_once __DIR__ . '/whatsapp.php';
            $sit = (($in['motivo'] ?? '') === 'comprovante') ? ws_ura_comprovante_msg($tel) : ws_ura_chat_menu($tel, mb_convert_case($cli['nome'], MB_CASE_TITLE, 'UTF-8'));   // comprovante: mensagem de saudação + pergunta do nome (sem menu do robô)
            if ($sit === 'iniciado') ws_ura_envios_dia('chat:' . $tel, true, 1);
            if (function_exists('ws_evento')) { try { ws_evento($db, (int)$cli['id'], 'robo', 'URA telefônica — ' . (($in['motivo'] ?? '') === 'comprovante' ? 'enviar comprovante' : 'opção de atendente fora do horário') . ': ' . (($in['motivo'] ?? '') === 'comprovante' ? 'mensagem no WhatsApp' : 'menu do WhatsApp') . ' ' . ($sit === 'iniciado' ? 'aberto pela Wellnet-01' : 'não aberto (' . $sit . ')') . ' (final ' . substr($tel, -4) . ').'); } catch (Throwable $e) {} }
            return ['ok' => $sit === 'iniciado', 'situacao' => $sit];
        }

        case 'chamado': {
            $j = ws_ura_robo('POST', 'conexao/chamado', ['cpf' => $doc, 'relato' => 'Pedido pela URA telefônica' . ($tel !== '' ? ' (ligou de ' . $tel . ')' : '')]);
            return ['ok' => !empty($j['ok']), 'situacao' => (string)($j['situacao'] ?? 'erro'), 'chamado' => (int)($j['chamado'] ?? 0), 'existia' => !empty($j['existia'])];
        }
    }
    return ['ok' => false, 'situacao' => 'acao_invalida'];
}

}
