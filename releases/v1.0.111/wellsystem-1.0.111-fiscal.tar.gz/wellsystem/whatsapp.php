<?php
/**
 * WellSystem — Cliente WhatsApp via Evolution API.
 *
 * Envia texto (janela de 24h) ou TEMPLATE oficial (fora da janela) pela instância
 * configurada (ex.: Wellnet-02). Credenciais em cache/whatsapp.json — NUNCA no código.
 *
 * Template oficial "atendimento" (pt_BR, 1 variável {{1}}) — quando usar_template=1,
 * mandamos a mensagem montada como a variável {{1}} do template aprovado.
 */
require_once __DIR__ . '/config.php';

define('WS_WA_CFG', WS_CACHE . '/whatsapp.json');

/** Config do Gateway WhatsApp — vários provedores suportados (igual ao MK-Auth nativo):
 *  'evolution' (padrão), 'ultramsg', 'zapi', 'textmebot', 'externo' (webhook genérico), ou
 *  'desativado'. Cada provedor usa só os campos que precisa; os outros ficam vazios/ignorados. */
function ws_wa_config(): array {
    $def = [
        'gateway' => 'evolution',
        // Evolution API
        'url' => '', 'apikey' => '', 'instance' => '', 'template' => 'atendimento', 'lang' => 'pt_BR',
        /* OUTRAS INSTÂNCIAS da mesma Evolution (mesma URL e chave), ex.: "Wellnet-01". O cliente pode falar com
         * qualquer número da empresa: antes de enviar, a janela de 24h é conferida em TODAS, e a mensagem sai
         * pela que estiver aberta — texto puro, sem custo de template. Nenhuma aberta: template pela principal. */
        'instancias_extra' => '',
        /* INSTÂNCIA DA API OFICIAL (14/10/2026): quando preenchida (ex.: "Wellnet-02"), é a ÚNICA instância pela qual o SISTEMA envia — recibo, boleto, resumo, cobrança, régua, avisos, templates,
         * anexos, resposta do robô feita pelo sistema… TUDO. As demais instâncias (WhatsApp comum, ex.: "Wellnet-01") só conversam com o cliente (robô/atendente/Chatwoot) e NUNCA enviam nada do sistema:
         * a Meta bane número de WhatsApp comum que dispara recibo/cobrança automática. Se esta instância cair, o envio FALHA (não troca para a comum). Vazio = comportamento antigo. */
        'instancia_api' => '',
        /* BOTÃO DE EMERGÊNCIA (14/10/2026): ligado = a instância da API (acima) está FORA — o sistema volta ao envio antigo (todas as instâncias, a comum assume), a conversa não é mais levada para a comum e o robô da API volta a responder. Desligue quando a API voltar. */
        'emergencia_comum' => 0,
        /* BOTÃO "TEXTO PELA API" (29/10/2026): ligado = o WhatsApp comum (01) está FORA — o que o ATENDENTE digita no Chatwoot (texto, print, áudio, documento) sai pela API (02), e digitado na caixa da 01 é repostado na conversa da 02 (ws_cwproxy_alvo). Desligado = regra de sempre (conversa pela comum). Não liga o robô nem mexe no envio automático do sistema. */
        'atendente_pela_api' => 0,
        /* TOKEN PRÓPRIO DE CADA INSTÂNCIA (14/10/2026): a chave geral (apikey) vale para as instâncias que usam o mesmo token (ex.: as da API oficial). Instância recriada como WhatsApp comum (Baileys) tem o token dela:
         * ["Wellnet-01" => "token"]. Vazio = usa a apikey geral. Gravado por: php evo_config.php chave <instância>. */
        'chaves_instancias' => [],
        // Telefone de cada instância, digitado na tela. Na API oficial a Evolution devolve só o ID do número na
        // Meta (ex.: 1274693592398762), não o telefone — sem isto a trava "não enviar para o próprio número" não age.
        'fones_instancias' => [],
        /* MODO HÍBRIDO (24/09/2026): cada FUNÇÃO escolhe o caminho — 'api' (regras da API oficial: janela, template,
         * rodízio) ou 'comum' (texto pelas instâncias do WhatsApp comum, mesma URL/chave da Evolution).
         * Só vale com 'hibrido' = 1 (tela: Tipo de WhatsApp → Híbrido). Grupos em ws_wa_grupo_evento(). */
        'hibrido'          => 0,
        'instancias_comum' => '',
        'rotas'            => ['recibo' => 'api', 'resumo' => 'api', 'cobranca' => 'api', 'suporte' => 'api', 'olt' => 'api', 'outros' => 'api'],
        // Ultramsg
        'ultramsg_instance' => '', 'ultramsg_token' => '',
        // Z-API
        'zapi_instance' => '', 'zapi_token' => '', 'zapi_client_token' => '',
        // TextMeBot
        'textmebot_apikey' => '',
        // Aplicativo externo (webhook genérico) — POST JSON {telefone, mensagem} pra essa URL.
        'externo_url' => '',
        /* API OFICIAL DA META (WhatsApp Cloud API) — atendida pela Evolution.
         *
         * Na API oficial, mensagem livre (sendText) SÓ é entregue dentro da janela de 24 h, ou seja,
         * quando o cliente falou com você nas últimas 24 h. Fora dela, a Meta só entrega TEMPLATE
         * APROVADO. Aviso de cobrança e recibo quase sempre caem fora da janela: sem template, eles
         * simplesmente não chegam — sem erro, sem aviso, sem nada.
         *
         * Com 'meta_oficial' ligado, o WellSystem faz o que a Meta exige:
         *   janela ABERTA  → manda a mensagem COMPLETA por sendText (como sempre);
         *   janela FECHADA → manda o TEMPLATE aprovado daquele tipo de mensagem e, se houver uma URL
         *                    de guarda (n8n), guarda o texto completo para ser reenviado quando o
         *                    cliente responder/clicar no botão do template.
         *
         * Os NOMES DOS TEMPLATES ficam aqui (e na tela), nunca no código: template aprovado pode ser
         * trocado/reprovado pela Meta a qualquer momento, e trocar o nome não pode exigir programador.
         */
        'meta_oficial'     => 0,        // 1 = é conta oficial da Meta (respeita janela de 24 h)
        'meta_lang'        => 'pt_BR',  // idioma com que os templates foram aprovados
        // Padrão = o abridor de conversa aprovado (templete_chat + {{1}}): SEM janela de 24h, toda mensagem
        // sem template próprio (suporte, boleto, recibo, resumo, backup) vai por ele, e o texto completo fica
        // guardado no n8n para chegar quando a pessoa tocar no botão. COM janela, vai sempre o texto puro.
        'meta_tpl_padrao'  => 'templete_chat', // template usado fora da janela quando nenhuma regra casa
        'meta_par_padrao'  => ws_wa_nome_empresa(), // variável {{1}} do template padrão (vazio = template sem variável)
        'meta_regras'      => [],       // [['re'=>'atras|vencid', 'tpl'=>'templete_chat', 'par'=>'Wellnet Telecom'], ...]
        'meta_guardar_url' => '', // n8n que guarda a mensagem completa p/ reenviar (mesma do evolution_meta.php)
        'meta_marca'       => 1,        // marca invisível nas automáticas (o n8n separa automática de atendente)
        /* Para onde o ÍCONE VERDE de WhatsApp leva (o do cadastro e o das listas). Vazio = wa.me,
         * como sempre foi. Com `%tel%` no endereço, o número do cliente entra ali. Isto é do
         * ÍCONE, não do envio: quem manda mensagem é o gateway acima. Lido por
         * ws_wa_link_destino() no config.php. */
        'link_icone' => '',
    ];
    if (is_file(WS_WA_CFG)) {
        $c = json_decode(@file_get_contents(WS_WA_CFG), true);
        if (is_array($c)) {
            $c = array_merge($def, $c);
            // Regras de template de fábrica (editáveis na tela): cobrança e aniversário, que são as
            // mensagens automáticas que mais caem fora da janela de 24 h.
            if (!is_array($c['meta_regras']) || !$c['meta_regras']) $c['meta_regras'] = ws_wa_meta_regras_padrao();
            /* Correção única (23/09/2026): as regras de fábrica gravadas antes saíam SEM a variável {{1}}
               e a Meta recusava. Preenche só nos dois templates de fábrica que estiverem em branco; depois
               de salvo (meta_regras_rev=2) o que o provedor deixar na tela é respeitado. */
            if ((int)($c['meta_regras_rev'] ?? 0) < 2) {
                foreach ($c['meta_regras'] as $i => $rg) {
                    if (in_array((string)($rg['tpl'] ?? ''), ['templete_01', 'templete_chat'], true) && trim((string)($rg['par'] ?? '')) === '')
                        $c['meta_regras'][$i]['par'] = ws_wa_nome_empresa();
                }
                $c['meta_regras_rev'] = 2;
            }
            /* Rev. 3 (23/09/2026): gravado antes com o template padrão e a guarda do n8n EM BRANCO, toda mensagem
               sem regra (suporte, boleto, resumo) falhava fora da janela. Preenche uma vez; depois vale a tela. */
            if ((int)($c['meta_regras_rev'] ?? 0) < 3) {
                if (trim((string)$c['meta_tpl_padrao']) === '') { $c['meta_tpl_padrao'] = $def['meta_tpl_padrao']; if (trim((string)$c['meta_par_padrao']) === '') $c['meta_par_padrao'] = $def['meta_par_padrao']; }
                if (trim((string)$c['meta_guardar_url']) === '') $c['meta_guardar_url'] = $def['meta_guardar_url'];
                $c['meta_regras_rev'] = 3;
            }
            return $c;
        }
    }
    $def['meta_regras'] = ws_wa_meta_regras_padrao();
    $def['meta_regras_rev'] = 3;
    return $def;
}

/** Instância da API que vale AGORA como única remetente do sistema: a configurada em "instancia_api", ou '' se não houver ou se o botão de emergência estiver ligado. */
function ws_wa_modo_api(array $c): string {
    return empty($c['emergencia_comum']) ? trim((string)($c['instancia_api'] ?? '')) : '';
}
/** Liga/desliga o ROBÔ (Typebot) de uma instância na Evolution, mantendo o resto da configuração dele. '' = ok; senão o motivo. (14/10/2026: o botão de emergência religa o robô do número oficial e o desliga ao voltar ao normal.) */
function ws_wa_robo_ligar(string $inst, bool $ligar): string {
    $c = ws_wa_config(); $url = rtrim((string)($c['url'] ?? ''), '/'); $k = ws_wa_chave($c, $inst); if ($url === '' || $k === '' || $inst === '') return 'Evolution não configurada';
    $http = function (string $m, string $p, ?array $b = null) use ($url, $k): array {
        $ch = curl_init($url . $p); $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_TIMEOUT => 25, CURLOPT_HTTPHEADER => ['apikey: ' . $k, 'Content-Type: application/json']];
        if ($b !== null) $o[CURLOPT_POSTFIELDS] = json_encode($b, JSON_UNESCAPED_UNICODE); curl_setopt_array($ch, $o); $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$s, json_decode((string)$r, true)];
    };
    [$s, $j] = $http('GET', '/typebot/find/' . rawurlencode($inst)); $b = isset($j[0]) ? $j[0] : (is_array($j) ? $j : []);
    if (empty($b['id'])) return 'robô não encontrado na instância';
    $body = array_filter(array_intersect_key($b, array_flip(['enabled', 'description', 'url', 'typebot', 'expire', 'keywordFinish', 'delayMessage', 'unknownMessage', 'listeningFromMe', 'stopBotFromMe', 'keepOpen', 'debounceTime', 'triggerType', 'triggerOperator', 'triggerValue', 'ignoreJids', 'splitMessages', 'timePerChar'])), fn($v) => $v !== null);
    if (isset($body['unknownMessage']) && (strpos((string)$body['unknownMessage'], "�") !== false || trim((string)$body['unknownMessage']) === '')) $body['unknownMessage'] = 'Mensagem não reconhecida';   // acento corrompido (16/10/2026)
    $body['enabled'] = $ligar;
    [$s2] = $http('PUT', '/typebot/update/' . $b['id'] . '/' . rawurlencode($inst), $body);
    return ($s2 >= 200 && $s2 < 300) ? '' : 'HTTP ' . $s2;
}
/** STATUS ACEITO NO WHATSAPP COMUM (08/11/2026, Wellnet-01 "conectada" sem receber desde 07/11 ~13h): com readStatus=false a Evolution manda o Baileys IGNORAR os status/stories dos contatos e ele
 *  os recusa (NACK 500) — o WhatsApp derruba a conexão a cada ~50 min ("stream errored out", ack class status), reenvia o mesmo status e a fila de entrega trava nele: nenhuma mensagem de cliente chega.
 *  Aqui garante readStatus=true na instância (mantendo os outros ajustes). O status não vai ao robô nem ao Chatwoot (a própria Evolution pula status@broadcast) nem ao webhook (api/index.php pula @broadcast).
 *  Chamada pela saúde (saude_lib.php, no máx. 1x/30 min) e pelo evo_config.php aplicar. '' = ok (ou já estava); senão o motivo. */
function ws_wa_status_aceitar(string $inst): string {
    $c = ws_wa_config(); $url = rtrim((string)($c['url'] ?? ''), '/'); $k = ws_wa_chave($c, $inst); if ($url === '' || $k === '' || $inst === '') return 'Evolution não configurada';
    $http = function (string $m, string $p, ?array $b = null) use ($url, $k): array {
        $ch = curl_init($url . $p); $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['apikey: ' . $k, 'Content-Type: application/json']];
        if ($b !== null) $o[CURLOPT_POSTFIELDS] = json_encode($b, JSON_UNESCAPED_UNICODE); curl_setopt_array($ch, $o); $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$s, json_decode((string)$r, true)];
    };
    [$s, $j] = $http('GET', '/settings/find/' . rawurlencode($inst));
    if ($s !== 200 || !is_array($j)) return 'ajustes não lidos (HTTP ' . $s . ')';
    if (!empty($j['readStatus'])) return '';
    $body = array_intersect_key($j, array_flip(['rejectCall', 'msgCall', 'groupsIgnore', 'alwaysOnline', 'readMessages', 'readStatus', 'syncFullHistory']));
    foreach (['rejectCall', 'groupsIgnore', 'alwaysOnline', 'readMessages', 'syncFullHistory'] as $b) $body[$b] = !empty($body[$b]);
    $body['msgCall'] = (string)($body['msgCall'] ?? ''); $body['readStatus'] = true;
    [$s2] = $http('POST', '/settings/set/' . rawurlencode($inst), $body);
    return ($s2 >= 200 && $s2 < 300) ? '' : 'HTTP ' . $s2;
}
/** O host é o do PRÓPRIO sistema?(endereço público configurado em ws_url_publica() ou o domínio por onde o robô chama a API, gravado em cache/api_base.txt) — só valores definidos pelo administrador/pela API autenticada. */
function ws_host_proprio(string $host): bool {
    $host = strtolower(trim($host)); if ($host === '') return false;
    $donos = [];
    if (function_exists('ws_url_publica')) $donos[] = strtolower((string)parse_url((string)ws_url_publica(), PHP_URL_HOST));
    if (defined('WS_CACHE')) $donos[] = strtolower((string)parse_url(trim((string)@file_get_contents(WS_CACHE . '/api_base.txt')), PHP_URL_HOST));
    return in_array($host, array_filter($donos), true);
}
/** ARQUIVO DO ROBÔ SEMPRE PELA API (14/10/2026): imagem (QR do PIX), áudio e vídeo que o robô manda ao cliente saem SÓ pelo número oficial (API), nunca pelo WhatsApp comum — arquivo automático no comum dá banimento e não pode
 *  ficar a critério do cliente. Baixa o arquivo da URL (https, host público, até 12 MB), envia por ws_wa_midia (regra única: só a API) e, com a janela fechada (saiu só o modelo), guarda o arquivo para entregar quando o
 *  cliente tocar em "Sim". Devolve ['ok','template','mensagem' (texto para o robô mostrar ao cliente, onde olhar)]. Número fictício de teste (558100000…) não envia nada. */
function ws_wa_midia_url_api(string $telefone, string $tipo, string $url, string $legenda = ''): array {
    $rot = ['image' => 'a imagem', 'video' => 'o vídeo', 'audio' => 'o áudio', 'document' => 'o arquivo'];
    $tipo = in_array($tipo, ['image', 'video', 'audio', 'document'], true) ? $tipo : 'image'; $oque = $rot[$tipo];
    $falha = ['ok' => false, 'template' => false, 'mensagem' => ''];
    $url = trim($url); $num = preg_replace('/\D/', '', $telefone);
    if ($url === '' || strpos($url, '{{') !== false || strlen($num) < 10) return $falha;
    if (preg_match('/^558100000/', $num)) return ['ok' => true, 'template' => false, 'mensagem' => "📎 (teste) $oque seria enviado pelo nosso *número oficial*."];
    $p = parse_url($url); if (!$p || strtolower((string)($p['scheme'] ?? '')) !== 'https' || empty($p['host'])) return $falha;
    /* 23/10/2026 (caso Rinaldo, QR manual sem valor): o servidor NÃO alcança o próprio endereço público (o roteador não devolve o tráfego para a própria máquina: timeout), e o QR do robô é uma URL DO PRÓPRIO sistema
       (/api/pix/qrcode/<cpf>.png) — o download falhava em silêncio, a mensagem voltava vazia e o cliente ficava sem QR e sem valor. URL do próprio sistema é buscada pelo loopback (CURLOPT_RESOLVE: certificado e nome
       continuam corretos); qualquer OUTRO endereço segue com a trava contra endereço interno. */
    $meu = ws_host_proprio((string)$p['host']);
    if (!$meu) { $ip = gethostbyname($p['host']); if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $falha; }   // nada de endereço interno
    $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_FOLLOWLOCATION => false, CURLOPT_MAXFILESIZE => 12582912]
        + ($meu ? [CURLOPT_RESOLVE => [$p['host'] . ':443:127.0.0.1']] : []));
    $bin = curl_exec($ch); $cod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $mime = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); curl_close($ch);
    if ($bin === false || $cod !== 200 || strlen((string)$bin) < 100 || strlen((string)$bin) > 12582912) return $falha;
    $ext = ['image' => 'png', 'video' => 'mp4', 'audio' => 'mp3', 'document' => 'pdf'][$tipo];
    if (stripos($mime, 'jpeg') !== false) $ext = 'jpg'; elseif (stripos($mime, 'png') !== false) $ext = 'png'; elseif (stripos($mime, 'ogg') !== false) $ext = 'ogg';
    $nome = ['image' => 'imagem', 'video' => 'video', 'audio' => 'audio', 'document' => 'arquivo'][$tipo] . '.' . $ext; $b64 = base64_encode((string)$bin);
    $r = ws_wa_midia($telefone, $tipo, $nome, $b64, $legenda, ['evento' => 'robo_concluiu']);          // só pela API (instancia_api)
    if (empty($r['ok']) && $tipo === 'audio') $r = ws_wa_midia($telefone, 'document', $nome, $b64, $legenda, ['evento' => 'robo_concluiu']);   // alguns gateways não aceitam áudio como mídia: vai como arquivo
    if (empty($r['ok'])) return $falha;
    if (!empty($r['template'])) { try { ws_wa_pendente_guardar($telefone, [['tipo' => $tipo === 'audio' ? 'document' : $tipo, 'nome' => $nome, 'b64' => $b64, 'legenda' => $legenda]]); } catch (Throwable $e) {}
        return ['ok' => true, 'template' => true, 'mensagem' => "📎 $oque vai pelo nosso número oficial do financeiro: \n ✅ toque em \"Sim\"  e o arquivo é entregue na hora."]; }
    return ['ok' => true, 'template' => false, 'mensagem' => "📎 $oque foi enviado pelo nosso *número oficial* — confira as mensagens do WhatsApp."];
}
/** RESUMO DAS TELAS (14/10/2026): como o envio funciona AGORA, em linguagem clara e SEM detalhe interno (nomes de instância, telefones, rodízio, caminhos de arquivo, n8n). Usado nas telas de Recibos, Chamados e Cobrança. */
function ws_wa_resumo_envio(array $wa): string {
    $gw = (string)($wa['gateway'] ?? 'evolution');
    if ($gw !== 'evolution') return $gw === 'desativado' ? 'Envio por WhatsApp desativado.' : 'Envio pelo gateway de WhatsApp configurado.';
    if (trim((string)($wa['instancia_api'] ?? '')) !== '') {
        return !empty($wa['emergencia_comum'])
            ? '🚨 Emergência ligada: o WhatsApp comum também está enviando recibos, boletos e mensagens automáticas (risco de bloqueio do número). Desligue quando o número oficial voltar.'
            : 'Recibos, boletos e mensagens automáticas saem pelo número oficial (API da Meta); as conversas com o cliente ficam no WhatsApp comum. Com a janela de 24 h aberta vai o texto; sem janela, o modelo aprovado.';
    }
    return !empty($wa['meta_oficial']) ? 'WhatsApp com API: com a janela de 24 h aberta vai o texto; sem janela, o modelo aprovado.' : 'WhatsApp comum: vai sempre texto.';
}
/** Instância COMUM (a que conversa com o cliente): a primeira que não é a da API. '' se não houver ou se a regra "só a API envia" não valer agora (botão de emergência). */
function ws_wa_instancia_comum_conversa(array $c): string {
    $api = ws_wa_modo_api($c);
    if ($api === '') {
        if (trim((string)($c['instancia_api'] ?? '')) !== '') return '';   // emergência ligada (há API oficial, fora do ar): comportamento de sempre
        /* PERFIL DE UM NÚMERO COMUM, sem API oficial (18/10/2026): a própria instância comum atende as conversas e confere se o número é WhatsApp (✓ verde do cadastro). */
        foreach (array_unique(array_merge([trim((string)($c['instance'] ?? ''))], ws_wa_instancias($c), ws_wa_instancias_comum($c))) as $in) if ($in !== '') return $in;
        return '';
    }
    foreach (array_unique(array_merge(ws_wa_instancias($c), ws_wa_instancias_comum($c))) as $in) if ($in !== $api) return $in;
    return '';
}
/** Mensagem DIGITADA pelo atendente no Chatwoot (não é nota privada, nem o que o sistema grava — recibo/boleto/modelo trazem source_id). */
function ws_cwproxy_do_atendente(array $pl): bool {
    return ($pl['event'] ?? '') === 'message_created' && ($pl['message_type'] ?? '') === 'outgoing' && empty($pl['private']) && empty($pl['source_id']);
}
/** A mensagem do atendente tem DOCUMENTO? (PDF, recibo, boleto, vídeo, qualquer anexo que NÃO seja print/foto nem áudio — esses dois podem sair pela comum, decisão do dono em 23/10/2026.) */
function ws_cwproxy_tem_documento(array $pl): bool {
    $deAtendente = ($pl['event'] ?? '') === 'message_created' && ($pl['message_type'] ?? '') === 'outgoing' && empty($pl['private']) && empty($pl['source_id']);   // o que o sistema grava (recibo, boleto, modelo) traz source_id
    if (!$deAtendente || empty($pl['attachments']) || !is_array($pl['attachments'])) return false;
    foreach ($pl['attachments'] as $a) {
        $ft = (string)($a['file_type'] ?? '');
        if (ws_cwproxy_foi_repostado((int)($pl['conversation']['id'] ?? 0), (string)($a['data_url'] ?? ''))) return true;   // 30/10/2026: arquivo que o próprio intermediário repostou na caixa da API já foi julgado (não lê de novo, não sai pela comum)
        if (!in_array($ft, ['image', 'audio'], true)) return true;
        if ($ft === 'image' && ws_cwproxy_imagem_e_documento($a)) return true;   // 24/10/2026: recibo/comprovante/boleto colado como IMAGEM também é documento
    }
    return false;
}
/** Arquivos que ws_cwproxy_repostar() acabou de postar na conversa da caixa da API (por nome, 5 min). Sem isto o 2º arquivo da mesma mensagem (print) era julgado de novo, saía pela COMUM sem legenda e o OCR repetia (caso Leopoldo, 30/10). */
function ws_cwproxy_nome_arquivo(string $url): string { return preg_replace('/[^A-Za-z0-9._-]+/', '_', basename((string)parse_url($url, PHP_URL_PATH))); }
function ws_cwproxy_marcar_repostados(int $conv, array $nomes): void {
    if ($conv <= 0 || !$nomes) return; $f = WS_CACHE . '/cwproxy_repostados.json'; $j = json_decode((string)@file_get_contents($f), true); if (!is_array($j)) $j = [];
    foreach ($j as $k => $v) if (time() - (int)($v['ts'] ?? 0) > 300) unset($j[$k]);
    $j[$conv] = ['ts' => time(), 'nomes' => array_values(array_unique(array_merge((array)($j[$conv]['nomes'] ?? []), $nomes)))]; @file_put_contents($f, json_encode($j), LOCK_EX);
}
function ws_cwproxy_foi_repostado(int $conv, string $url): bool {
    if ($conv <= 0 || $url === '') return false; $j = json_decode((string)@file_get_contents(WS_CACHE . '/cwproxy_repostados.json'), true);
    $r = is_array($j) ? ($j[$conv] ?? null) : null; if (!$r || time() - (int)($r['ts'] ?? 0) > 300) return false;
    $n = ws_cwproxy_nome_arquivo($url); return $n !== '' && in_array($n, (array)($r['nomes'] ?? []), true);
}
/** O texto lido de uma imagem é de RECIBO, COMPROVANTE DE PAGAMENTO ou BOLETO? (print comum de tela não casa.) */
function ws_cwproxy_texto_e_documento(string $txt): bool {
    return $txt !== '' && preg_match('/\b(recibo|comprovante|boleto|pix\s+(enviado|recebido|realizado)|transfer[eê]ncia|pagamento\s+(efetuado|realizado|confirmado)|linha\s+digit[aá]vel|c[óo]digo\s+de\s+barras|favorecido|benefici[aá]rio|autentica[cç][aã]o\s+(banc|sisbb)|valor\s+(pago|do\s+documento)|segunda\s+via|2[aª]\s+via)\b/iu', $txt) === 1;
}
/** Baixa a imagem do anexo do Chatwoot e lê o texto por OCR (o mesmo leitor dos comprovantes). Qualquer falha = false (fica como print, pela comum). */
function ws_cwproxy_imagem_e_documento(array $a): bool {
    $url = (string)($a['data_url'] ?? ''); if (!preg_match('#^https?://#i', $url)) return false;
    try {
        if (!function_exists('ws_comp_ler') && is_file(__DIR__ . '/comprovantes_lib.php')) require_once __DIR__ . '/comprovantes_lib.php';
        if (!function_exists('ws_comp_ler')) return false;
        $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_TIMEOUT => 20, CURLOPT_MAXFILESIZE => 12000000]);
        $bin = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($bin === false || $http < 200 || $http >= 300 || strlen((string)$bin) < 500) return false;
        $tmp = tempnam(sys_get_temp_dir(), 'wsimg'); file_put_contents($tmp, $bin);
        $mime = (string)(@getimagesize($tmp)['mime'] ?? 'image/png'); $txt = ws_comp_ler($tmp, $mime); @unlink($tmp);
        return ws_cwproxy_texto_e_documento($txt);
    } catch (Throwable $e) { return false; }
}
/** POR QUAL INSTÂNCIA SAI o que o ATENDENTE digita no Chatwoot (/api/cwproxy). Devolve [instância-alvo, pode-voltar-para-a-original-se-falhar, ação ('entregar' | 'repostar')].
 *  Texto, print/foto e áudio: como sempre — conversa pela COMUM (grátis), mesmo digitado na caixa da API.
 *  DOCUMENTO (PDF, recibo, boleto, vídeo…) digitado pelo atendente (23/10/2026): SEMPRE pela API oficial (Wellnet-02), NUNCA pela comum — documento na comum dá risco de banimento; sem queda para a comum se a API falhar.
 *  Digitado na caixa da API (02): entrega direto à API. Digitado na caixa da comum (01): a Evolution da API não entrega conversa de OUTRA caixa, então o intermediário REPOSTA o arquivo na conversa do mesmo cliente
 *  na caixa da API ('repostar') — ver ws_cwproxy_repostar(). Sem API ativa (emergência ligada ou sem instancia_api) o comportamento é o de sempre. */
function ws_cwproxy_alvo(array $c, string $orig, array $pl): array {
    $api = ws_wa_modo_api($c); $comum = ws_wa_instancia_comum_conversa($c);
    if ($api !== '' && ws_cwproxy_tem_documento($pl)) return [$api, false, $orig === $api ? 'entregar' : 'repostar'];
    if ($api !== '' && !empty($c['atendente_pela_api']) && ws_cwproxy_do_atendente($pl)) return [$api, false, $orig === $api ? 'entregar' : 'repostar'];   // 29/10/2026: botão "texto pela API" (comum fora do ar) — sem queda para a comum
    if ($comum !== '' && $orig === $api) return [$comum, false, 'entregar'];   // 29/10/2026: texto/print/áudio digitado na caixa da API sai SÓ pela comum; se a comum cair, falha no Chatwoot (conserto = reconectar a comum). NUNCA cai para a API sozinho — só com o botão "Texto pela API" ligado (caso 29/10: com a 01 banida o texto saía pela 02 sem o botão)
    return [$orig, true, 'entregar'];
}
/** RESPOSTA DE CONVERSA pela instância COMUM (14/10/2026): usada só quando o SISTEMA responde a algo que o cliente escreveu/enviou (ex.: resposta ao comprovante recebido na API), para não gerar custo na API.
 *  Recibo, boleto, cobrança, template e demais automáticas NÃO usam isto (vão só pela API — ws_wa_enviar). Sem instância comum / emergência ligada → cai no envio normal (ws_wa_enviar). */
function ws_wa_enviar_conversa(string $telefone, string $texto, array $ctx = []): array {
    /* 23/10/2026 (dono): resposta AUTOMÁTICA do sistema ao CLIENTE sobre o comprovante ("Recebi seu comprovante…", pedido de nome/CPF, confirmação) sai SÓ pela Wellnet-02, nunca pela 01 (risco de banimento). */
    if (($ctx['evento'] ?? '') === 'comprovante') return ws_wa_enviar($telefone, $texto, false, $ctx);
    $c = ws_wa_config(); $in = ws_wa_instancia_comum_conversa($c);
    $num = ws_wa_numero($telefone); if ($num === '') return ['ok' => false, 'raw' => 'Telefone inválido.'];
    if ($in === '' || ($c['url'] ?? '') === '') return ws_wa_enviar($telefone, $texto, false, $ctx);
    if (ws_wa_eh_numero_da_empresa($num, $c) !== '') return ['ok' => false, 'raw' => 'Não enviado: é o número de uma instância da empresa.'];
    $r = ws_wa_evo_um('texto', $in, $num, $texto, $c);
    if (empty($r['ok'])) return ws_wa_enviar($telefone, $texto, false, $ctx);   // a comum falhou: não deixa o cliente sem resposta (sai pela API)
    $r['instancia'] = $in; $r['raw'] = 'conversa pela ' . $in . ' (sem custo na API). ' . (string)($r['raw'] ?? ''); return $r;
}
/** Chave (apikey) para falar com UMA instância da Evolution: o token próprio dela, se cadastrado; senão a chave geral. */
function ws_wa_chave(array $c, string $inst): string {
    $k = trim((string)(((array)($c['chaves_instancias'] ?? []))[$inst] ?? ''));
    return $k !== '' ? $k : (string)($c['apikey'] ?? '');
}

function ws_wa_salvar(array $cfg): void {
    @file_put_contents(WS_WA_CFG, json_encode(array_merge(ws_wa_config(), $cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_WA_CFG, 0640);
}

/** HTTP helper genérico (GET ou POST, JSON ou form) — usado pelos gateways alternativos. */
function ws_wa_http_generico(string $url, string $metodo = 'POST', array $dados = [], array $headers = [], bool $json = true): array {
    $ch = curl_init();
    if ($metodo === 'GET') {
        $url .= (strpos($url, '?') !== false ? '&' : '?') . http_build_query($dados);
        curl_setopt($ch, CURLOPT_URL, $url);
    } else {
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json ? json_encode($dados, JSON_UNESCAPED_UNICODE) : http_build_query($dados));
        if ($json) $headers[] = 'Content-Type: application/json';
    }
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_HTTPHEADER => $headers]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) return [0, null, 'curl: ' . $err];
    return [$code, json_decode($raw, true), $raw];
}

/** Normaliza número BR para o formato E.164 sem símbolos (55 + DDD + número). */
function ws_wa_numero(string $tel): string {
    $n = preg_replace('/\D/', '', $tel);
    if ($n === '') return '';
    if (strlen($n) <= 11) $n = '55' . $n;   // acrescenta DDI Brasil se veio só DDD+número
    return $n;
}

/** Nome curto da empresa (fantasia do cadastro do provedor; ou o digitado no assistente de Atendimento) — usado como variável {{1}} dos templates da Meta e nas assinaturas. */
function ws_wa_nome_empresa(): string { return function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : ''; }

/** HTTP helper. Retorna [code, array|null, raw]. */
function ws_wa_http(string $url, array $headers, array $body): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => $headers, CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE),
    ]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) return [0, null, 'curl: ' . $err];
    return [$code, json_decode($raw, true), $raw];
}

/**
 * Envia mensagem de texto pelo WhatsApp, usando o gateway configurado em Mensagens → Servidor.
 * Mesma assinatura de sempre — todo o resto do sistema continua chamando igual, sem precisar
 * saber qual provedor está por trás. $usarTemplate só se aplica ao gateway Evolution.
 * @return array [ok, code, raw]
 */
/* =================================================================================================
 * API OFICIAL DA META (WhatsApp Cloud API) — janela de 24 h e templates aprovados
 * ================================================================================================= */

/** Regras de template de fábrica — o que o provedor já usa hoje. Tudo editável na tela. */
function ws_wa_meta_regras_padrao(): array {
    return [
        /* 23/09/2026: {{1}} = "Wellnet Telecom" nos DOIS, igual ao evolution_meta.php que funciona no
         * MK-Auth. Sem a variável a Meta recusa o template — era por isso que, com "conta oficial"
         * marcado, a mensagem parava de sair. */
        // Aniversário: template sem cobrança, aprovado à parte.
        ['re' => 'anivers|parab[eé]ns', 'tpl' => 'templete_01', 'par' => ws_wa_nome_empresa()],
        /* Cobrança (atrasado, vencido, em aberto, bloqueado/desbloqueado, suspenso, liberado).
         * "vencid" e NÃO "venciment": "Vencimento: 10/09" aparece no BOLETO, que não é cobrança. */
        ['re' => 'atras|vencid|em aberto|bloque|desbloque|suspens|liber', 'tpl' => 'templete_chat', 'par' => ws_wa_nome_empresa()],
    ];
}

/** A janela de 24 h deste número está ABERTA (o cliente falou com você nas últimas 24 h)?
 *  Pergunta à Evolution (chat/findMessages) e guarda a resposta por 10 min em cache/wa_janela.json,
 *  para não repetir a consulta a cada mensagem de um disparo em massa.
 *  Na dúvida (erro, timeout, resposta estranha) devolve FALSE = trata como fechada e manda o
 *  template, que a Meta entrega de qualquer forma. Nunca o contrário: supor "aberta" sem certeza
 *  faria a mensagem sumir em silêncio, que é exatamente o problema que isto resolve. */
function ws_wa_janela_aberta(string $num, array $c): bool {
    $arq = WS_CACHE . '/wa_janela.json';
    $cache = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    $ck = (string)($c['instance'] ?? '') . '|' . $num;   // a janela é de cada número da empresa, então de cada instância
    /* Validade do que ficou guardado (24/09/2026): "fechada" vale só 60 s — o cliente pode responder a qualquer
       momento e abrir a janela (com 10 min, o 2º recibo do teste saiu pela instância errada); "aberta" vale até
       10 min, mas nunca depois do fim real da janela de 24 h. */
    if (isset($cache[$ck])) {
        $em = (int)($cache[$ck]['em'] ?? 0);
        $vale = !empty($cache[$ck]['aberta']) ? min($em + 600, (int)($cache[$ck]['ate'] ?? $em + 600)) : $em + 60;
        if (time() < $vale) return !empty($cache[$ck]['aberta']);
    }
    $base = rtrim((string)$c['url'], '/');
    if ($base === '' || ($c['apikey'] ?? '') === '') return false;
    /* A Evolution guarda o jid ora COM ora SEM o nono dígito (55 + DDD + 8 ou 9 dígitos).
     * Consulta as duas formas: achou conversa recente em qualquer uma, a janela está aberta. */
    $n = preg_replace('/\D/', '', $num);
    $jids = [];
    if (strlen($n) === 13 && substr($n, 0, 2) === '55' && $n[4] === '9') {
        $jids[] = substr($n, 0, 4) . substr($n, 5) . '@s.whatsapp.net';
    } elseif (strlen($n) === 12 && substr($n, 0, 2) === '55') {
        $jids[] = substr($n, 0, 4) . '9' . substr($n, 4) . '@s.whatsapp.net';
    }
    $jids[] = $n . '@s.whatsapp.net';
    $aberta = false; $ate = 0;
    foreach (array_unique($jids) as $jid) {
        [$code, $resp] = ws_wa_http("$base/chat/findMessages/" . rawurlencode((string)$c['instance']),
            ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)$c['instance'])],
            ['where' => ['key' => ['remoteJid' => $jid]]]);
        if ($code < 200 || $code >= 300 || !is_array($resp)) continue;
        $recs = $resp['messages']['records'] ?? ($resp['records'] ?? []);
        if (!is_array($recs)) continue;
        foreach ($recs as $m) {
            if (!is_array($m)) continue;
            $deMim = $m['key']['fromMe'] ?? ($m['fromMe'] ?? null);
            $ts = (int)($m['messageTimestamp'] ?? 0);
            if ($deMim === false || $deMim === 0 || $deMim === '0') {
                if ($ts > 0 && (time() - $ts) < 86400) { $aberta = true; $ate = max($ate, $ts + 86400); }
            }
            elseif ($ts > 0 && (time() - $ts) < 79200) {
                /* 30/09/2026 (RESTAURADA em 10/10): a Evolution nem sempre grava a mensagem do cliente (imagem/áudio/figurinha) — ele falou na Wellnet-01, só as respostas do
                   ROBÔ ficaram, e o recibo saía como template pela outra. Texto LIVRE do robô/atendente na conversa só é possível com a janela aberta: conta como prova.
                   Template (▶️nome◀️) não conta. Margem de 22 h. NOVO: texto que o PRÓPRIO WellSystem enviou (cobrança, resumo, recibo…) NÃO conta — a Evolution grava como enviado
                   o que a Meta recusa (erro 131047) e uma recusa virava "prova" falsa (ws_wa_proprio_envio, gravado em ws_wa_evo_um). */
                $txt = (string)($m['message']['conversation'] ?? ($m['message']['extendedTextMessage']['text'] ?? ''));
                if ($txt !== '' && strpos($txt, "\u{25B6}") !== 0 && !ws_wa_proprio_envio((string)($c['instance'] ?? ''), $n, $ts)) { $aberta = true; $ate = max($ate, $ts + 79200); }
            }
        }
    }
    $cache[$ck] = ['aberta' => $aberta ? 1 : 0, 'em' => time(), 'ate' => $ate];
    if (count($cache) > 2000) $cache = array_slice($cache, -1000, null, true);
    @file_put_contents($arq, json_encode($cache)); @chmod($arq, 0640);
    return $aberta;
}

/** Guarda/consulta os envios feitos pelo próprio WellSystem (instância|número → horários), para a "prova de janela" não confundir texto nosso com resposta do robô. */
function ws_wa_proprio_envio(string $inst, string $num, int $ts = 0): bool {
    $arq = WS_CACHE . '/wa_proprios.json';
    $d = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    $k = $inst . '|' . substr(preg_replace('/\D/', '', $num), -8);
    if ($ts === 0) {   // gravar
        $l = array_values(array_filter((array)($d[$k] ?? []), fn($t) => time() - (int)$t < 172800)); $l[] = time(); $d[$k] = array_slice($l, -40);
        if (count($d) > 3000) $d = array_slice($d, -1500, null, true);
        @file_put_contents($arq, json_encode($d)); @chmod($arq, 0640); return true;
    }
    foreach ((array)($d[$k] ?? []) as $t) if (abs((int)$t - $ts) <= 40) return true;
    return false;
}

/** Quando o cliente falou por último NESTA instância (timestamp; 0 = janela fechada). Usa a mesma consulta/cache
 *  de ws_wa_janela_aberta — com as duas abertas, a mensagem sai pela conversa mais recente (regra de 24/09/2026). */
function ws_wa_janela_ultima(string $num, array $c): int {
    if (!ws_wa_janela_aberta($num, $c)) return 0;
    $cache = json_decode((string)@file_get_contents(WS_CACHE . '/wa_janela.json'), true) ?: [];
    $ate = (int)($cache[(string)($c['instance'] ?? '') . '|' . $num]['ate'] ?? 0);
    return $ate > 0 ? $ate - 86400 : 1;
}

/** Esquece o que ficou guardado sobre a janela deste número (em todas as instâncias), para a próxima checagem
 *  ir direto à Evolution. Usado pelo RESUMO: o cache ("fechada" 60 s, "aberta" 10 min) podia mandar template
 *  para quem tinha acabado de abrir a janela, ou texto puro para quem acabou de fechar. */
function ws_wa_janela_esquecer(string $telefone): void {
    $arq = WS_CACHE . '/wa_janela.json';
    $n = ws_wa_numero($telefone);
    if ($n === '' || !is_file($arq)) return;
    $cache = json_decode((string)@file_get_contents($arq), true);
    if (!is_array($cache)) return;
    $fim = '|' . $n; $mudou = false;
    foreach (array_keys($cache) as $k) {
        if (substr((string)$k, -strlen($fim)) === $fim) { unset($cache[$k]); $mudou = true; }
    }
    if ($mudou) { @file_put_contents($arq, json_encode($cache)); @chmod($arq, 0640); }
}

/** Instâncias para conferir a janela: a principal primeiro, depois as outras ("instancias_extra"), sem repetir. */
/** Funções do sistema para o modo híbrido: chave => rótulo da tela. */
function ws_wa_grupos(): array {
    return ['recibo' => 'Recibo para o cliente', 'resumo' => 'Resumo de pagamentos (equipe)',
            'cobranca' => 'Cobrança e mensagens automáticas (régua, vencimento, bloqueio, aniversário…)',
            'suporte' => 'Suporte (avisos aos técnicos)', 'olt' => 'Alertas da OLT', 'outros' => 'Outros envios (manual, boleto, backup)'];
}
/** De qual função é este envio? (o 'evento' que cada tela manda no $ctx). */
function ws_wa_grupo_evento(string $ev): string {
    if (in_array($ev, ['recibo', 'resumo', 'olt'], true)) return $ev;
    if ($ev === 'chamado') return 'suporte';
    if ($ev === 'regua' || ($ev !== '' && function_exists('ws_msg_eventos') && isset(ws_msg_eventos()[$ev]))) return 'cobranca';
    if (in_array($ev, ['venc_dia', 'bloqueio', 'desbloqueio', 'aniversario', 'manutencao', 'online', 'lembrete'], true)) return 'cobranca';
    return 'outros';
}
/** No híbrido, esta função vai pelo WhatsApp COMUM? */
function ws_wa_rota_comum(array $c, array $ctx): bool {
    if (empty($c['hibrido'])) return false;
    $g = ws_wa_grupo_evento((string)($ctx['evento'] ?? ''));
    $rotas = (array)($c['rotas'] ?? []);
    return ($rotas[$g] ?? 'api') === 'comum';
}
/** Instâncias do WhatsApp comum (híbrido), na ordem: a 1ª envia, as outras são reserva. */
function ws_wa_instancias_comum(array $c): array {
    return array_values(array_unique(array_filter(array_map('trim', preg_split('/[,;\s]+/', (string)($c['instancias_comum'] ?? '')) ?: []))));
}

function ws_wa_instancias(array $c): array {
    $out = [];
    foreach (array_merge([(string)($c['instance'] ?? '')], preg_split('/[,;\s]+/', (string)($c['instancias_extra'] ?? '')) ?: []) as $i) {
        $i = trim($i); if ($i !== '' && !in_array($i, $out, true)) $out[] = $i;
    }
    return $out;
}

/** Em qual instância a janela de 24h deste número está ABERTA? A principal é conferida primeiro.
 *  '' = nenhuma (fora da janela em todas) → vai template pela principal. */
function ws_wa_instancia_aberta(string $num, array $c): string {
    foreach (ws_wa_instancias($c) as $inst) if (ws_wa_janela_aberta($num, ['instance' => $inst] + $c)) return $inst;
    return '';
}

/** O destino é o próprio número de ALGUMA das instâncias? (ninguém manda mensagem para si mesmo) */
function ws_wa_eh_numero_da_empresa(string $num, array $c): string {
    foreach (array_unique(array_merge(ws_wa_instancias($c), ws_wa_instancias_comum($c))) as $inst) if (ws_wa_mesmo_numero($num, ws_wa_numero_proprio(['instance' => $inst] + $c))) return $inst;
    return '';
}

/** Template aprovado para esta mensagem: 1º o template do próprio evento (tela Mensagens), depois
 *  as regras por palavra (tela Servidor) e, por fim, o template padrão. Sem nada: null. */
function ws_wa_meta_template(string $texto, array $c, array $ctx = []): ?array {
    if (!empty($ctx['tpl_vars']) && trim((string)($ctx['tpl_recibo'] ?? '')) !== '') return ['tpl' => trim((string)$ctx['tpl_recibo']), 'par' => '', 'vars' => array_values((array)$ctx['tpl_vars'])];   // modelo que TRAZ o recibo (1 mensagem)
    $tpl = trim((string)($ctx['tpl'] ?? ''));
    if ($tpl !== '') return ['tpl' => $tpl, 'par' => (string)($ctx['par'] ?? '')];
    foreach ((array)($c['meta_regras'] ?? []) as $r) {
        $re = trim((string)($r['re'] ?? '')); $nome = trim((string)($r['tpl'] ?? ''));
        if ($re === '' || $nome === '') continue;
        if (@preg_match('/(' . $re . ')/iu', $texto)) return ['tpl' => $nome, 'par' => (string)($r['par'] ?? '')];
    }
    $pad = trim((string)($c['meta_tpl_padrao'] ?? ''));
    return $pad !== '' ? ['tpl' => $pad, 'par' => (string)($c['meta_par_padrao'] ?? '')] : null;
}

/** Envia um TEMPLATE aprovado pela Evolution (sendTemplate). Template sem variável vai sem 'components'. */
function ws_wa_enviar_meta_template(string $num, array $tpl, array $c): array {
    $base = rtrim((string)$c['url'], '/');
    $body = ['number' => $num, 'name' => $tpl['tpl'], 'language' => (string)($c['meta_lang'] ?: 'pt_BR')];
    if (!empty($tpl['vars'])) {   // modelo com os campos do recibo: variáveis na ordem fixa; falhou = quem chamou cai no modelo de sempre
        $body['components'] = [['type' => 'body', 'parameters' => ws_wa_meta_vars_params((array)$tpl['vars'])]];
        [$cv, $rv, $rawv] = ws_wa_http("$base/message/sendTemplate/" . rawurlencode((string)$c['instance']), ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)($c['instance'] ?? ''))], $body);
        /* A Evolution devolve a recusa da Meta (modelo inexistente 132001, variáveis 132000/132012…) com status de SUCESSO e o erro só no corpo: sem olhar o corpo, a queda para o modelo de sempre nunca disparava. */
        $erroMeta = (bool)preg_match('/OAuthException|"error"\s*:|\(#1\d{5}\)|"code"\s*:\s*1\d{5}/', (string)$rawv);
        return ['ok' => ($cv >= 200 && $cv < 300 && !$erroMeta), 'code' => $cv, 'raw' => $rawv, 'template' => $tpl['tpl']];
    }
    if (trim((string)$tpl['par']) !== '')
        $body['components'] = [['type' => 'body', 'parameters' => [['type' => 'text', 'text' => $tpl['par']]]]];
    $url = "$base/message/sendTemplate/" . rawurlencode((string)$c['instance']);
    $hdr = ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)($c['instance'] ?? ''))];
    [$code, $resp, $raw] = ws_wa_http($url, $hdr, $body);
    /* A Meta recusa quando a QUANTIDADE de variáveis não bate com o modelo aprovado (erro 132000,
       "number of parameters"). Pela tela não dá para ver se o modelo tem {{1}} — a pré-visualização
       já mostra o exemplo preenchido. Então, recusado por isso, tenta uma vez do outro jeito
       (com {{1}} ↔ sem) em vez de o aviso não sair. */
    if (($code < 200 || $code >= 300) && preg_match('/132000|param/i', (string)$raw)) {
        $body2 = $body;
        if (isset($body2['components'])) unset($body2['components']);
        else $body2['components'] = [['type' => 'body', 'parameters' => [['type' => 'text', 'text' => trim((string)$tpl['par']) !== '' ? $tpl['par'] : ws_wa_nome_empresa()]]]];
        [$code2, $resp2, $raw2] = ws_wa_http($url, $hdr, $body2);
        if ($code2 >= 200 && $code2 < 300) return ['ok' => true, 'code' => $code2, 'raw' => $raw2 . ' [ajustado: ' . (isset($body2['components']) ? 'com' : 'sem') . ' {{1}}]', 'template' => $tpl['tpl']];
    }
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'raw' => $raw, 'template' => $tpl['tpl']];
}

/** Guarda a mensagem completa (n8n) para ser reenviada quando o cliente responder o template. */
function ws_wa_meta_guardar(string $num, string $texto, array $c): void {
    $url = trim((string)($c['meta_guardar_url'] ?? ''));
    if ($url === '') return;
    /* 'instancia' = a instância que MANDOU o template. O aceite do cliente chega nela, e o reenvio tem que
       sair por ela (a janela de 24h abre só naquele número). Com o rodízio pode ser a Wellnet-01 ou a -02. */
    try { ws_wa_http_generico($url, 'POST', ['number' => $num, 'recibo' => $texto, 'mensagem' => $texto,
                                              'instancia' => (string)($c['instance'] ?? '')], [], true); } catch (Throwable $e) {}
}

/** ESTE NÚMERO TEM WHATSAPP? (15/10/2026) Pergunta à Evolution (chat/whatsappNumbers) pela instância COMUM. Devolve true / false / null (não deu para saber: instância fora, sem resposta). Guarda a resposta em cache/wa_numeros.json:
 *  "tem" vale 30 dias, "não tem" 2 dias (a pessoa pode instalar depois). null nunca é guardado. Número fictício de teste (558100000…) = null. */
function ws_wa_eh_whatsapp(string $telefone): ?bool {
    $num = ws_wa_numero($telefone); if (strlen($num) < 12 || preg_match('/^558100000/', $num)) return null;
    $arq = WS_CACHE . '/wa_numeros.json'; $cache = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    if (isset($cache[$num]) && time() - (int)$cache[$num]['t'] < (!empty($cache[$num]['v']) ? 2592000 : 172800)) return !empty($cache[$num]['v']);
    $c = ws_wa_config(); $in = ws_wa_instancia_comum_conversa($c); if ($in === '' || ($c['url'] ?? '') === '' || !ws_wa_instancia_online($in, $c)) return null;
    $ch = curl_init(rtrim((string)$c['url'], '/') . '/chat/whatsappNumbers/' . rawurlencode($in));
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($c, $in), 'Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode(['numbers' => [$num]])]);
    $r = curl_exec($ch); $cod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = json_decode((string)$r, true); if ($cod < 200 || $cod >= 300 || !is_array($j) || !isset($j[0]) || !array_key_exists('exists', (array)$j[0])) return null;
    $v = !empty($j[0]['exists']);
    $cache[$num] = ['v' => $v ? 1 : 0, 't' => time()]; if (count($cache) > 5000) $cache = array_slice($cache, -4000, null, true);
    @file_put_contents($arq, json_encode($cache), LOCK_EX); @chmod($arq, 0640);
    return $v;
}
/** DESTINO DO ENVIO DO SISTEMA AO CLIENTE (15/10/2026): o Celular-1 tem prioridade quando é WhatsApp; se NÃO for, tenta o Celular-2. Só vale para envio que o sistema inicia (recibo, cobrança, mensagens automáticas, atendente
 *  enviando boleto) — resposta de conversa (robô, comprovante, boleto pedido no chat, entrega do "Sim") vai SEMPRE para o número que escreveu. Sem cadastro achado, ou sem confirmação de que o 1º não tem WhatsApp = mantém o número recebido. */
function ws_wa_destino_cliente(string $telefone, array $ctx = []): string {
    $ev = (string)($ctx['evento'] ?? '');
    if (in_array($ev, ['robo_concluiu', 'pix_pedido', 'comprovante', 'boleto', 'chamado', 'pix_confirmar', 'olt', 'resumo', 'backup', 'entrega_pendente'], true)) return $telefone;
    $num = ws_wa_numero($telefone); $f8 = substr($num, -8); if (strlen($f8) < 8 || preg_match('/^558100000/', $num)) return $telefone;
    try {
        $db = ws_db();
        $q = $db->prepare("SELECT celular, telefone FROM ws_cliente WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''),8)=? OR RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(telefone,''),' ',''),'-',''),'(',''),')',''),8)=? ORDER BY (titular_id IS NULL) DESC, id LIMIT 1");
        $q->execute([$f8, $f8]); $r = $q->fetch(PDO::FETCH_ASSOC); if (!$r) return $telefone;
        $cands = []; foreach ([$r['celular'], $r['telefone']] as $x) { $d = preg_replace('/\D/', '', (string)$x); if (strlen($d) >= 10) $cands[] = $d; }
        if (count($cands) < 2) return $telefone;   // só um número: nada a escolher
        foreach ($cands as $cd) { $v = ws_wa_eh_whatsapp($cd); if ($v === true) return $cd; if ($v === null) return $telefone; }
    } catch (Throwable $e) {}
    return $telefone;
}
function ws_wa_enviar(string $telefone, string $texto, bool $usarTemplate = false, array $ctx = []): array {
    $c = ws_wa_config();
    $telefone = ws_wa_destino_cliente($telefone, $ctx);   // Celular-1 se for WhatsApp; senão o Celular-2 (15/10)
    $num = ws_wa_numero($telefone);
    if ($num === '') return ['ok' => false, 'raw' => 'Telefone vazio/inválido.'];
    switch ($c['gateway'] ?? 'evolution') {
        case 'desativado':
            return ['ok' => false, 'raw' => 'Gateway WhatsApp desativado (Mensagens → Servidor).'];
        case 'ultramsg':
            return ws_wa_enviar_ultramsg($num, $texto, $c);
        case 'zapi':
            return ws_wa_enviar_zapi($num, $texto, $c);
        case 'textmebot':
            return ws_wa_enviar_textmebot($num, $texto, $c);
        case 'externo':
            return ws_wa_enviar_externo($num, $texto, $c);
        case 'evolution':
        default:
            return ws_wa_enviar_evolution($num, $texto, $usarTemplate, $c, $ctx);
    }
}

/** Número do WhatsApp CONECTADO na instância (o que ENVIA), perguntado à Evolution
 *  (instance/fetchInstances → ownerJid na v2, instance.owner na v1). Guardado 12 h em
 *  cache/wa_proprio.json. '' quando não dá para saber — aí nada é bloqueado. */
function ws_wa_numero_proprio(array $c): string {
    $inst = (string)($c['instance'] ?? '');
    $base = rtrim((string)($c['url'] ?? ''), '/');
    $fonesInst = (array)($c['fones_instancias'] ?? []);
    $dig = preg_replace('/\D/', '', (string)($fonesInst[$inst] ?? ''));
    if ($dig !== '') return strlen($dig) <= 11 ? '55' . $dig : $dig;   // digitado na tela (Opções → Servidor ③) manda
    if ($inst === '' || $base === '' || ($c['apikey'] ?? '') === '') return '';
    $arq = WS_CACHE . '/wa_proprio.json';
    $cache = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    // v=2: descarta o que foi guardado antes da correção do ID da Meta (que não é telefone).
    if (isset($cache[$inst]) && (int)($cache[$inst]['v'] ?? 0) === 2 && (time() - (int)($cache[$inst]['em'] ?? 0)) < 43200) return (string)$cache[$inst]['num'];
    $num = '';
    $ch = curl_init("$base/instance/fetchInstances?instanceName=" . rawurlencode($inst));
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($c, $inst)]]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = ($raw !== false && $code >= 200 && $code < 300) ? json_decode((string)$raw, true) : null;
    if (is_array($j)) {
        $lista = isset($j[0]) ? $j : [$j];
        foreach ($lista as $it) {
            if (!is_array($it)) continue;
            $nome = (string)($it['name'] ?? ($it['instance']['instanceName'] ?? ($it['instanceName'] ?? '')));
            if ($nome !== '' && $nome !== $inst) continue;
            /* Na API OFICIAL o ownerJid vem com o ID DO NÚMERO NA META (ex.: 1274693592398762), não com o
               telefone. Só vale o que tem cara de telefone: 12–13 dígitos começando com 55, ou 10–11 (sem DDI).
               'number' vem primeiro porque, nas instâncias da Meta, é onde a Evolution guarda o telefone. */
            foreach ([$it['number'] ?? null, $it['ownerJid'] ?? null, $it['owner'] ?? null, $it['instance']['owner'] ?? null] as $cand) {
                $d = preg_replace('/\D/', '', explode('@', (string)$cand)[0]);
                $L = strlen($d);
                if (($L >= 12 && $L <= 13 && substr($d, 0, 2) === '55') || $L === 10 || $L === 11) { $num = strlen($d) <= 11 ? '55' . $d : $d; break 2; }
            }
        }
    }
    $cache[$inst] = ['num' => $num, 'em' => time(), 'v' => 2];
    @file_put_contents($arq, json_encode($cache)); @chmod($arq, 0640);
    return $num;
}

/** Os dois números são o mesmo WhatsApp? Compara com e sem o nono dígito (55 + DDD + 8 ou 9). */
function ws_wa_mesmo_numero(string $a, string $b): bool {
    $f = function (string $n): string {
        $n = preg_replace('/\D/', '', $n);
        return (strlen($n) === 13 && substr($n, 0, 2) === '55' && $n[4] === '9') ? substr($n, 0, 4) . substr($n, 5) : $n;
    };
    return $a !== '' && $b !== '' && $f($a) === $f($b);
}

/* =================================================================================================
 * ROTEAMENTO ENTRE INSTÂNCIAS DA EVOLUTION (ex.: Wellnet-02 principal + Wellnet-01)
 *
 *   R1  Instâncias = a principal ("instance") + as outras ("instancias_extra"), nessa ordem.
 *   R2  Instância FORA DO AR (connectionState ≠ open) não é usada enquanto houver outra no ar.
 *       Todas fora → tenta todas mesmo assim (melhor tentar do que não enviar).
 *   R3  API da Meta ligada + JANELA ABERTA numa instância no ar → mensagem PURA por ela (sem custo).
 *   R4  Janela fechada em todas (ou recibo da baixa pelo gateway) → TEMPLATE em RODÍZIO: cada envio
 *       vai pela próxima instância no ar, para não ficar tudo em cima de uma só.
 *   R5  Falha de CONEXÃO (sem resposta, 5xx, instância desconectada/inexistente) → a próxima
 *       instância assume na hora. Recusa da META (conteúdo/template) → NÃO troca: é erro real.
 *   R6  API da Meta desligada → texto pela principal; caiu → a próxima assume (R5).
 *   R7  Número de qualquer instância nunca recebe (ws_wa_eh_numero_da_empresa).
 * ================================================================================================= */

/** A instância está conectada? Evolution: instance/connectionState/{inst} → state "open".
 *  Cache de 60 s em cache/wa_estado.json. Resposta ilegível = considera no ar (não trava envio
 *  por dúvida; se falhar de verdade, R5 troca). Sem resposta / 404 / "close" = fora do ar. */
function ws_wa_instancia_online(string $inst, array $c): bool {
    $arq = WS_CACHE . '/wa_estado.json';
    $cache = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    if (isset($cache[$inst]) && (time() - (int)($cache[$inst]['em'] ?? 0)) < 60) return !empty($cache[$inst]['on']);
    $base = rtrim((string)($c['url'] ?? ''), '/');
    $on = true;
    if ($base !== '' && ($c['apikey'] ?? '') !== '') {
        $ch = curl_init("$base/instance/connectionState/" . rawurlencode($inst));
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($c, $inst)]]);
        $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($raw === false || $code === 0 || $code === 404) $on = false;
        else {
            $j = json_decode((string)$raw, true);
            $st = is_array($j) ? strtolower((string)($j['instance']['state'] ?? ($j['state'] ?? ''))) : '';
            if (in_array($st, ['close', 'closed', 'disconnected', 'connecting'], true)) $on = false;
        }
    }
    $cache[$inst] = ['on' => $on ? 1 : 0, 'em' => time()];
    @file_put_contents($arq, json_encode($cache)); @chmod($arq, 0640);
    return $on;
}

/** Instância que acabou de falhar por conexão: marcada FORA por 60 s, os próximos envios já pulam ela. */
function ws_wa_marcar_fora(string $inst): void {
    $arq = WS_CACHE . '/wa_estado.json';
    $cache = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
    $cache[$inst] = ['on' => 0, 'em' => time()];
    @file_put_contents($arq, json_encode($cache)); @chmod($arq, 0640);
}

/** R1+R2: instâncias utilizáveis agora, na ordem (principal primeiro). Todas fora → todas. */
function ws_wa_instancias_no_ar(array $c): array {
    $todas = ws_wa_instancias($c);
    $no = array_values(array_filter($todas, fn($i) => ws_wa_instancia_online($i, $c)));
    return $no ?: $todas;
}

/** R4: ordem do rodízio — começa pela próxima da vez e segue as demais (para a troca da R5).
 *  O contador fica em cache/wa_rodizio.json e avança a cada template enviado. */
function ws_wa_ordem_rodizio(array $lista): array {
    if (count($lista) < 2) return $lista;
    $arq = WS_CACHE . '/wa_rodizio.json';
    $n = is_file($arq) ? (int)(json_decode((string)@file_get_contents($arq), true)['n'] ?? 0) : 0;
    $k = $n % count($lista);
    @file_put_contents($arq, json_encode(['n' => $n + 1])); @chmod($arq, 0640);
    return array_merge(array_slice($lista, $k), array_slice($lista, 0, $k));
}

/** R5: a falha é de CONEXÃO da instância (vale trocar) ou recusa do conteúdo (não vale)? */
function ws_wa_falha_conexao(array $r): bool {
    $code = (int)($r['code'] ?? 0);
    if ($code === 0 || $code >= 500 || $code === 404) return true;
    return (bool)preg_match('/not connected|connection closed|disconnected|instance .*(not found|does not exist)|não conectad/i', (string)($r['raw'] ?? ''));
}

/** Um envio por UMA instância: 'texto', 'template' (tpl=[tpl,par]), 'legado' (template antigo com o texto
 *  em {{1}}) ou 'midia' (dados=[mediatype,nome,base64,caption]). */
function ws_wa_evo_um(string $modo, string $inst, string $num, $dados, array $c): array {
    $c['instance'] = $inst;
    if ($modo === 'template') return ws_wa_enviar_meta_template($num, $dados, $c);
    $base = rtrim($c['url'], '/');
    $hdr = ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)($c['instance'] ?? ''))];
    if ($modo === 'midia') {
        [$mt, $nome, $b64, $cap] = $dados;
        $body = ['number' => $num, 'mediatype' => $mt, 'fileName' => $nome, 'media' => $b64, 'caption' => $cap];
        /* Evolution v2 pede o tipo do arquivo (mimetype) pra documento — sem ele o anexo pode chegar
         * sem abrir ou nem chegar. Antes só o .pdf ganhava mimetype; o backup manda .sql/.zip e
         * ficava sem, então o "envio de backup não vai no WhatsApp" também pode ser isto. */
        $extMime = ['pdf' => 'application/pdf', 'sql' => 'application/sql', 'zip' => 'application/zip',
                    'json' => 'application/json', 'txt' => 'text/plain', 'csv' => 'text/csv',
                    'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg'];
        $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
        $body['mimetype'] = $extMime[$ext] ?? 'application/octet-stream';
        [$code, , $raw] = ws_wa_http("$base/message/sendMedia/" . rawurlencode($inst), $hdr, $body);
    } elseif ($modo === 'legado') {
        [$code, , $raw] = ws_wa_http("$base/message/sendTemplate/" . rawurlencode($inst), $hdr,
            ['number' => $num, 'name' => $c['template'], 'language' => $c['lang'],
             'components' => [['type' => 'body', 'parameters' => [['type' => 'text', 'text' => (string)$dados]]]]]);
    } else {
        /* 25/10/2026: texto COM LINK (aviso "Confirmar PIX no banco") chegava como notificação e a mensagem nunca abria no celular (a Evolution monta a pré-visualização do link e o WhatsApp não carrega). linkPreview=false: o link continua clicável, sem o cartão. */
        $corpoT = ['number' => $num, 'text' => (string)$dados]; if (preg_match('#https?://#i', (string)$dados)) $corpoT['linkPreview'] = false;
        [$code, , $raw] = ws_wa_http("$base/message/sendText/" . rawurlencode($inst), $hdr, $corpoT);
    }
    if ($code >= 200 && $code < 300) { try { ws_wa_proprio_envio($inst, $num, 0); } catch (Throwable $e) {} }   // texto/mídia nosso: não vale como prova de janela
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'raw' => $raw];
}

/** Tenta as instâncias na ordem dada; troca só por falha de conexão (R5). */
function ws_wa_evo_tentar(string $modo, array $ordem, string $num, $dados, array $c, string $motivo): array {
    $r = ['ok' => false, 'raw' => 'Nenhuma instância disponível.']; $caidas = [];
    foreach ($ordem as $inst) {
        $r = ws_wa_evo_um($modo, $inst, $num, $dados, $c);
        if (!empty($r['ok'])) {
            $r['instancia'] = $inst;
            $r['raw'] = $motivo . ' — pela ' . $inst . ($caidas ? ' (fora do ar: ' . implode(', ', $caidas) . ')' : '') . '. ' . (string)($r['raw'] ?? '');
            return $r;
        }
        if (!ws_wa_falha_conexao($r)) break;   // recusa real: outra instância não resolve
        $caidas[] = $inst; ws_wa_marcar_fora($inst);
    }
    $r['raw'] = $motivo . ' — FALHOU' . ($caidas ? ' (sem conexão: ' . implode(', ', $caidas) . ')' : '') . '. ' . (string)($r['raw'] ?? '');
    return $r;
}

/** Divide um texto longo em partes de até $max caracteres, cortando sempre no fim de uma linha (o resumo
 *  quebra nas linhas de "====="). O WhatsApp/Meta recusa mensagem de texto acima de 4096 caracteres. */
function ws_wa_texto_partes(string $t, int $max = 3500): array {
    if (mb_strlen($t, 'UTF-8') <= $max) return [$t];
    $partes = []; $atual = '';
    foreach (explode("\n", $t) as $linha) {
        $cand = $atual === '' ? $linha : $atual . "\n" . $linha;
        if ($atual !== '' && mb_strlen($cand, 'UTF-8') > $max) { $partes[] = $atual; $atual = $linha; }
        else $atual = $cand;
    }
    if ($atual !== '') $partes[] = $atual;
    return $partes;
}

/** Situação de uma mensagem enviada, perguntada à Evolution pelo ID (chat/findMessages). Devolve o status em
 *  maiúsculas (PENDING, SERVER_ACK, DELIVERY_ACK, READ, ERROR...) ou '' se não deu para saber. */
function ws_wa_msg_status(string $inst, string $id, array $c): string {
    $base = rtrim((string)($c['url'] ?? ''), '/');
    if ($base === '' || $id === '') return '';
    [$code, $resp] = ws_wa_http("$base/chat/findMessages/" . rawurlencode($inst),
        ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, $inst)], ['where' => ['key' => ['id' => $id]]]);
    if ($code < 200 || $code >= 300 || !is_array($resp)) return '';
    $recs = $resp['messages']['records'] ?? ($resp['records'] ?? (isset($resp[0]) ? $resp : []));
    foreach ((array)$recs as $m) { if (is_array($m) && isset($m['status'])) return strtoupper((string)$m['status']); }
    return '';
}

/** TEXTO PURO do resumo (janela aberta), à prova de "a API aceitou mas não chegou":
 *   1) texto acima de ~3500 caracteres vai em várias mensagens (limite de 4096 do WhatsApp);
 *   2) depois de enviar, confere na Evolution o status de cada mensagem — se a Meta marcou ERRO, devolve falha,
 *      e o chamador (ctx 'garantir') manda o TEMPLATE em vez de deixar o número sem nada. */
function ws_wa_texto_garantido(string $inst, string $num, string $texto, array $c): array {
    $partes = ws_wa_texto_partes($texto); $n = count($partes); $ids = []; $ult = ['ok' => false, 'raw' => 'sem partes'];
    foreach ($partes as $i => $p) {
        if ($n > 1) $p = '(' . ($i + 1) . '/' . $n . ")\n" . $p;
        $ult = ws_wa_evo_um('texto', $inst, $num, $p, $c);
        if (empty($ult['ok'])) { $ult['raw'] = "parte " . ($i + 1) . "/$n recusada: " . (string)($ult['raw'] ?? ''); return $ult; }
        $j = json_decode((string)($ult['raw'] ?? ''), true);
        $id = is_array($j) ? (string)($j['key']['id'] ?? ($j['id'] ?? '')) : '';
        if ($id !== '') $ids[] = $id;
        if ($i < $n - 1) usleep(600000);
    }
    if ($ids) {
        sleep(4);
        foreach ($ids as $id) {
            $st = ws_wa_msg_status($inst, $id, $c);
            if (in_array($st, ['ERROR', 'FAILED'], true))
                return ['ok' => false, 'code' => 422, 'raw' => "aceita pela API, mas marcada $st na entrega ($n parte(s), id $id)"];
        }
    }
    $ult['raw'] = ($n > 1 ? "texto em $n partes. " : '') . (string)($ult['raw'] ?? '');
    return $ult;
}

/** Roteador único da Evolution (texto e anexo). $midia = null para texto. */
function ws_wa_evo_rotear(string $num, string $texto, bool $usarTemplate, array $c, array $ctx = [], ?array $midia = null): array {
    if ($c['url'] === '' || $c['apikey'] === '') return ['ok' => false, 'raw' => 'Evolution API não configurada (Mensagens → Servidor).'];
    if (($dona = ws_wa_eh_numero_da_empresa($num, $c)) !== '')                                         // R7
        return ['ok' => false, 'raw' => "Não enviado: $num é o próprio número do WhatsApp da instância $dona. Tire-o da lista."];
    /* INSTÂNCIA DA API (14/10/2026): o sistema só envia pela instância da API oficial; a(s) comum(ns) ficam fora de TODO envio automático (R7 acima já protegeu os números de todas). */
    $iaApi = ws_wa_modo_api($c);   // '' = sem API definida OU botão de emergência ligado
    if ($iaApi !== '') { $c['instance'] = $iaApi; $c['instancias_extra'] = ''; $c['hibrido'] = 0; $c['meta_oficial'] = 1; }
    /* HÍBRIDO: esta função está marcada para o WhatsApp COMUM → vale como comum (texto, sem janela/template/n8n),
       pelas instâncias do comum. Sem instância do comum cadastrada, avisa em vez de desviar para a API. */
    if (ws_wa_rota_comum($c, $ctx)) {
        $ic = ws_wa_instancias_comum($c);
        if (!$ic) return ['ok' => false, 'raw' => 'Híbrido: esta função está no WhatsApp comum, mas nenhuma instância do comum foi cadastrada (Servidor de WhatsApp → Instâncias).'];
        $c = ['instance' => $ic[0], 'instancias_extra' => implode(',', array_slice($ic, 1)), 'meta_oficial' => 0] + $c;
    }
    $noAr = ws_wa_instancias_no_ar($c);                                                                // R1+R2
    /* so_janela_instancias: o retorno do técnico só pode sair pelas instâncias marcadas em ⚙️ Notificações ([] = todas). */
    if (!empty($ctx['so_janela']) && !empty($ctx['so_janela_instancias']) && $iaApi === '') {
        $noAr = array_values(array_intersect($noAr, array_map('strval', (array)$ctx['so_janela_instancias'])));
        if (!$noAr) return ['ok' => false, 'janela_fechada' => true, 'raw' => 'Não enviado: nenhuma das instâncias marcadas para o retorno do técnico está no ar.'];
    }
    /* ANEXO INTERNO (backup para o próprio admin): se houver instância do WhatsApp COMUM cadastrada, o arquivo
       vai por ela — sem janela de 24 h nem template (a API oficial NUNCA entrega arquivo fora da janela). */
    if ($midia && !empty($ctx['interna']) && $iaApi === '' && ($icb = ws_wa_instancias_comum($c))) {
        $rb = ws_wa_evo_tentar('midia', $icb, $num, $midia, ['meta_oficial' => 0] + $c, 'anexo interno pelo WhatsApp comum');
        if (!empty($rb['ok'])) return $rb;
    }
    /* $usarTemplate (a caixa antiga "usar template" da régua) NÃO manda mais em nada: quem decide é a REGRA
       ÚNICA — API oficial: janela aberta = texto puro, sem janela = template; WhatsApp normal: texto sempre.
       Antes, marcada, ela mandava template até com a janela aberta (gasto à toa). */
    $modoLivre = $midia ? 'midia' : 'texto';
    $dadosLivre = $midia ?: $texto;

    if (empty($c['meta_oficial']))                                                                    // R6
        return ws_wa_evo_tentar($modoLivre, $noAr, $num, $dadosLivre, $c, 'enviado');

    // Marca invisível (zero-width) nas AUTOMÁTICAS: o robô do atendimento separa sistema × atendente.
    if (!empty($c['meta_marca']) && !empty($ctx['automatica'])) {
        if ($midia) $midia[3] .= "\xE2\x80\x8B"; else $texto .= "\xE2\x80\x8B";
        $dadosLivre = $midia ?: $texto;
    }
    $conteudo = $midia ? (string)$midia[3] : $texto;

    /* R3 — JANELA ABERTA (regra do provedor, 24/09/2026):
     *   aberta em UMA só   → SEMPRE por ela (texto puro);
     *   aberta em VÁRIAS   → pela instância onde o cliente falou POR ÚLTIMO (texto puro) — é a conversa que ele
     *                        está olhando; as outras abertas ficam de reserva se ela cair. (Antes alternava: o
     *                        cliente falou na 01 às 05:38, a 02 estava aberta desde 00:14, e o recibo saiu pela 02.)
     *   fechada em todas   → R4: template alternando entre as instâncias.
     * VALE PARA TUDO, inclusive o recibo da baixa pelo gateway (não existe mais exceção "sempre template"). */
    $ult = [];
    foreach ($noAr as $k => $i) { $t = ws_wa_janela_ultima($num, ['instance' => $i] + $c); if ($t > 0) $ult[$i] = [$t, $k]; }
    uksort($ult, fn($a, $b) => [$ult[$b][0], $ult[$a][1]] <=> [$ult[$a][0], $ult[$b][1]]);   // mais recente primeiro; empate = ordem da principal
    $abertas = $ordemA = array_keys($ult);
    $recusaTexto = '';   // texto recusado com a janela "aberta" (só com ctx['garantir'], usado pelo resumo)
    foreach ($ordemA as $inst) {
        $r = ($modoLivre === 'texto' && !empty($ctx['garantir']))
            ? ws_wa_texto_garantido($inst, $num, (string)$dadosLivre, ['instance' => $inst] + $c)   // resumo: partes + confere entrega
            : ws_wa_evo_um($modoLivre, $inst, $num, $dadosLivre, $c);
        if (!empty($r['ok'])) {
            $r['instancia'] = $inst;
            $r['raw'] = 'janela aberta ' . (count($abertas) > 1 ? 'nas ' . count($abertas) . ' instâncias — pela conversa mais recente do cliente' : 'só nesta') . " — mensagem pura pela $inst. " . (string)($r['raw'] ?? '');
            return $r;
        }
        if (!ws_wa_falha_conexao($r)) {
            /* Resumo (ctx 'garantir'): a Meta recusou o texto puro mesmo com a janela dada como aberta. Não deixa o
               destinatário sem nada — segue para o template abaixo. Os demais envios mantêm o comportamento de sempre. */
            if (empty($ctx['garantir'])) return $r;
            $recusaTexto = (string)($r['raw'] ?? 'recusado');
            break;
        }
        // Caiu: sai da lista; tenta a próxima que também tem janela; sem nenhuma, vai o template (R4/R5).
        ws_wa_marcar_fora($inst);
        $noAr = array_values(array_diff($noAr, [$inst])) ?: $noAr;
    }

    /* so_janela: o retorno do técnico ao provedor NUNCA vai por template. A detecção de janela pode errar (Evolution sem
       histórico, cache, jid diferente) — então, sem janela detectada, tenta TEXTO PURO direto pelas instâncias permitidas;
       se a janela estiver realmente fechada, a Meta recusa o texto (sem custo, sem template) e o motivo volta no retorno. */
    if (!empty($ctx['so_janela']) && !$midia) {
        $motivoRecusa = '';
        foreach ($noAr as $inst) {
            $rd = ws_wa_evo_um('texto', $inst, $num, $dadosLivre, $c);
            if (!empty($rd['ok'])) { $rd['instancia'] = $inst; $rd['raw'] = "texto puro direto pela $inst (janela não detectada, sem template). " . (string)($rd['raw'] ?? ''); return $rd; }
            $motivoRecusa .= ($motivoRecusa !== '' ? ' | ' : '') . "$inst: " . mb_substr(trim(preg_replace('/\s+/', ' ', (string)($rd['raw'] ?? 'recusado'))), 0, 120);
        }
        return ['ok' => false, 'janela_fechada' => true, 'raw' => 'Não enviado: janela de 24 h fechada (sem template, por regra). ' . $motivoRecusa];
    }

    /* ANEXO INTERNO sem WhatsApp comum: a checagem de janela pode dar "fechada" mesmo com a janela aberta
       (Evolution sem o histórico, cache, jid diferente). Antes o backup saía SÓ como template, sem arquivo,
       até com a janela aberta. Agora o arquivo é tentado direto ANTES; o template segue como aviso garantido. */
    $arquivoDireto = '';
    if ($midia && !empty($ctx['interna']) && !$abertas) {
        foreach ($noAr as $ib) {
            $rd = ws_wa_evo_um($modoLivre, $ib, $num, $dadosLivre, $c);
            if (!empty($rd['ok'])) { $arquivoDireto = $ib; break; }
            if (!ws_wa_falha_conexao($rd)) break;
        }
        // Arquivo entregue à API: NÃO manda o template (era só um aviso vazio, sem o arquivo, e incomodava).
        if ($arquivoDireto !== '') { $rd['instancia'] = $arquivoDireto; $rd['arquivo_direto'] = $arquivoDireto; $rd['raw'] = 'arquivo enviado direto pela ' . $arquivoDireto . ' (sem template). ' . (string)($rd['raw'] ?? ''); return $rd; }
    }
    // R4: template em rodízio entre as instâncias no ar.
    $tpl = ws_wa_meta_template($conteudo, $c, $ctx);
    if (!$tpl) return ['ok' => false, 'raw' => 'Fora da janela de 24 h e sem template aprovado para esta mensagem (Mensagens → Servidor → API oficial da Meta).'];
    $motivo = 'janela de 24h fechada — template "' . $tpl['tpl'] . '" em rodízio';
    if ($recusaTexto !== '') $motivo = 'texto puro recusado com janela aberta (' . mb_substr(preg_replace('/\s+/', ' ', $recusaTexto), 0, 80) . ') — template "' . $tpl['tpl'] . '" em rodízio';
    $r = ws_wa_evo_tentar('template', ws_wa_ordem_rodizio($noAr), $num, $tpl, $c, $motivo);
    if (empty($r['ok']) && !empty($tpl['vars'])) {   // 26/10/2026: modelo do recibo com campos não aprovado/recusado — cai no modelo de sempre ("Abrir Recibo"): o recibo nunca deixa de sair
        $ctx2 = $ctx; unset($ctx2['tpl_vars'], $ctx2['tpl_recibo']); $tpl = ws_wa_meta_template($conteudo, $c, $ctx2);
        if ($tpl) $r = ws_wa_evo_tentar('template', ws_wa_ordem_rodizio($noAr), $num, $tpl, $c, $motivo . ' (modelo com os campos recusado; modelo de sempre)');
    }
    if (!empty($r['ok']) && empty($tpl['vars'])) ws_wa_meta_guardar($num, $conteudo, ['instance' => (string)$r['instancia']] + $c);   // n8n reenvia pela mesma instância (com o recibo dentro do modelo não há nada a guardar)
    $r['template'] = true;   // quem chamou sabe que saiu TEMPLATE (janela fechada): não manda anexo extra (QR) atrás
    if ($arquivoDireto !== '') { $r['template'] = false; $r['arquivo_direto'] = $arquivoDireto; }
    return $r;
}

/** Evolution API (gateway padrão/original do WellSystem). */
function ws_wa_enviar_evolution(string $num, string $texto, bool $usarTemplate, array $c, array $ctx = []): array {
    return ws_wa_evo_rotear($num, $texto, $usarTemplate, $c, $ctx);
}

/** Ultramsg (https://ultramsg.com) — instância + token. */
function ws_wa_enviar_ultramsg(string $num, string $texto, array $c): array {
    if ($c['ultramsg_instance'] === '' || $c['ultramsg_token'] === '') return ['ok' => false, 'raw' => 'Ultramsg não configurado (Mensagens → Servidor).'];
    $url = 'https://api.ultramsg.com/' . rawurlencode($c['ultramsg_instance']) . '/messages/chat';
    [$code, $resp, $raw] = ws_wa_http_generico($url, 'POST', ['token' => $c['ultramsg_token'], 'to' => $num, 'body' => $texto], [], false);
    $ok = $code >= 200 && $code < 300 && is_array($resp) && empty($resp['error']);
    return ['ok' => $ok, 'code' => $code, 'raw' => $raw];
}

/** Z-API (https://z-api.io) — instância + token + client-token (opcional). */
function ws_wa_enviar_zapi(string $num, string $texto, array $c): array {
    if ($c['zapi_instance'] === '' || $c['zapi_token'] === '') return ['ok' => false, 'raw' => 'Z-API não configurado (Mensagens → Servidor).'];
    $url = 'https://api.z-api.io/instances/' . rawurlencode($c['zapi_instance']) . '/token/' . rawurlencode($c['zapi_token']) . '/send-text';
    $headers = []; if (!empty($c['zapi_client_token'])) $headers[] = 'Client-Token: ' . $c['zapi_client_token'];
    [$code, $resp, $raw] = ws_wa_http_generico($url, 'POST', ['phone' => $num, 'message' => $texto], $headers, true);
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'raw' => $raw];
}

/** TextMeBot (https://textmebot.com) — apenas uma API key; envio por GET. */
function ws_wa_enviar_textmebot(string $num, string $texto, array $c): array {
    if ($c['textmebot_apikey'] === '') return ['ok' => false, 'raw' => 'TextMeBot não configurado (Mensagens → Servidor).'];
    $url = 'https://api.textmebot.com/send.php';
    [$code, $resp, $raw] = ws_wa_http_generico($url, 'GET', ['recipient' => $num, 'apikey' => $c['textmebot_apikey'], 'text' => $texto], [], false);
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'raw' => $raw];
}

/** Aplicativo externo — webhook genérico próprio (POST JSON {telefone, mensagem} pra sua URL). */
function ws_wa_enviar_externo(string $num, string $texto, array $c): array {
    if (empty($c['externo_url'])) return ['ok' => false, 'raw' => 'URL do aplicativo externo não configurada (Mensagens → Servidor).'];
    [$code, $resp, $raw] = ws_wa_http_generico($c['externo_url'], 'POST', ['telefone' => $num, 'mensagem' => $texto], [], true);
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'raw' => $raw];
}

/** Envia um DOCUMENTO (base64) pelo WhatsApp via Evolution (sendMedia). */
function ws_wa_documento(string $telefone, string $nomeArq, string $base64, array $ctx = []): array {
    return ws_wa_midia($telefone, 'document', $nomeArq, $base64, 'Backup WellSystem', $ctx);
}
/** Envia qualquer mídia (foto/documento) em base64 pelo WhatsApp — só o gateway Evolution e o
 *  Ultramsg suportam mídia por aqui; nos demais gateways, manda a legenda como texto simples e
 *  avisa no retorno que o anexo não foi enviado (evita silenciosamente "perder" a mensagem). */
function ws_wa_midia(string $telefone, string $mediatype, string $nomeArq, string $base64, string $caption = '', array $ctx = []): array {
    $c = ws_wa_config();
    $telefone = ws_wa_destino_cliente($telefone, $ctx);   // Celular-1 se for WhatsApp; senão o Celular-2 (15/10)
    $num = ws_wa_numero($telefone); if ($num === '') return ['ok' => false, 'raw' => 'Telefone inválido.'];
    $gw = $c['gateway'] ?? 'evolution';
    if ($gw === 'evolution') {
        /* Anexo segue as MESMAS regras R1–R7 do texto (ws_wa_evo_rotear): janela aberta → anexo pela
         * instância da janela; fechada → template em rodízio, com a legenda guardada para o reenvio. */
        return ws_wa_evo_rotear($num, $caption, false, $c, $ctx, [$mediatype, $nomeArq, $base64, $caption]);
    }
    if ($gw === 'ultramsg') {
        if ($c['ultramsg_instance'] === '' || $c['ultramsg_token'] === '') return ['ok' => false, 'raw' => 'Ultramsg não configurado.'];
        $endpoint = $mediatype === 'image' ? 'image' : 'document';
        $url = 'https://api.ultramsg.com/' . rawurlencode($c['ultramsg_instance']) . "/messages/$endpoint";
        $dados = ['token' => $c['ultramsg_token'], 'to' => $num, 'caption' => $caption];
        $dados[$mediatype === 'image' ? 'image' : 'document'] = 'data:application/octet-stream;base64,' . $base64;
        if ($mediatype !== 'image') $dados['filename'] = $nomeArq;
        [$code, $resp, $raw] = ws_wa_http_generico($url, 'POST', $dados, [], false);
        $ok = $code >= 200 && $code < 300 && is_array($resp) && empty($resp['error']);
        return ['ok' => $ok, 'code' => $code, 'raw' => $raw];
    }
    // Demais gateways (Z-API, TextMeBot, Externo): sem suporte a mídia aqui ainda — manda só o texto.
    $r = ws_wa_enviar($telefone, $caption);
    $r['raw'] = (is_string($r['raw'] ?? null) ? $r['raw'] . ' ' : '') . '[aviso: este gateway não suporta anexo por aqui — só o texto foi enviado]';
    return $r;
}

/**
 * REGRA DO PROVEDOR — PROIBIDO mandar mensagem para cliente DESATIVADO/CANCELADO.
 *
 * Recebe mensagem: ativo, bloqueado, em confiança, observação, suspenso.
 * NÃO recebe, em hipótese alguma: cliente cancelado ou inativo (desativado); contrato cancelado;
 * cliente cujos contratos estão TODOS cancelados. Cliente que não existe também não.
 * Todo envio a cliente (mensagens automáticas, régua, recibo, envio em lote) passa por aqui.
 */
function ws_msg_cliente_permitido(PDO $db, int $clienteId, ?int $contratoId = null): bool {
    if ($clienteId <= 0) return false;
    try {
        $st = $db->prepare("SELECT status FROM ws_cliente WHERE id=?");
        $st->execute([$clienteId]);
        $stCli = $st->fetchColumn();
        if ($stCli === false || in_array((string)$stCli, ['cancelado', 'inativo', 'desativado'], true)) return false;
        if ($contratoId) {
            $sc = $db->prepare("SELECT status FROM ws_contrato WHERE id=?");
            $sc->execute([$contratoId]);
            $stCt = $sc->fetchColumn();
            if ($stCt !== false && in_array((string)$stCt, ['cancelado', 'inativo', 'desativado'], true)) return false;
        }
        $q = $db->prepare("SELECT COUNT(*) total, SUM(status IN ('cancelado','inativo','desativado')) cancelados FROM ws_contrato WHERE cliente_id=?");
        $q->execute([$clienteId]);
        $r = $q->fetch(PDO::FETCH_ASSOC);
        if ((int)($r['total'] ?? 0) > 0 && (int)$r['total'] === (int)$r['cancelados']) return false;
        return true;
    } catch (Throwable $e) {
        return false;   // na dúvida, NÃO envia
    }
}

/** Assinatura padrão do recibo/resumo: nome curto do provedor cadastrado (se vier em CAIXA ALTA, em iniciais maiúsculas). */
function ws_recibo_assinatura_padrao(): string {
    $n = function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : '';
    if ($n === '') return 'Provedor';
    return $n === mb_strtoupper($n, 'UTF-8') ? mb_convert_case($n, MB_CASE_TITLE, 'UTF-8') : $n;
}

/** Config de recibos/resumo (cache/recibos.json). */
function ws_recibo_config(): array {
    $f = WS_CACHE . '/recibos.json';
    /* resumo_auto/resumo_hora: resumo do dia enviado sozinho pelo cron (radius_sync.php → ws_resumo_auto_run).
       meta_tpl/meta_par = template da Meta do RECIBO; resumo_tpl/resumo_par = do RESUMO (fora da janela de 24h). */
    $def = ['auto' => 0, 'assinatura' => ws_recibo_assinatura_padrao(), 'numeros_resumo' => '', 'pix_confirmadores' => '', 'limpeza_auto' => 0, 'limpeza_dias' => 90,
            'resumo_auto' => 0, 'resumo_hora' => '20:00', 'meta_tpl' => 'templete_pagamento', 'meta_par' => 'comprovante',
            'resumo_tpl' => 'templete_pagamento', 'resumo_par' => 'comprovante', 'meta_tpl_recibo' => ''];
    if (is_file($f)) { $c = json_decode(@file_get_contents($f), true); if (is_array($c)) return array_merge($def, $c); }
    return $def;
}
function ws_recibo_salvar(array $c): void {
    // Junta com o que já está gravado: salvar um bloco da tela não apaga as outras opções.
    $c = array_merge(ws_recibo_config(), $c);
    @file_put_contents(WS_CACHE . '/recibos.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/recibos.json', 0640);
}

/** CPF (11 dígitos) ou CNPJ (14) com pontuação; qualquer outra coisa volta como veio. */
function ws_doc_formatado(?string $doc): string {
    $d = preg_replace('/\D/', '', (string)$doc);
    if (strlen($d) === 11) return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $d);
    if (strlen($d) === 14) return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $d);
    return trim((string)$doc);
}

/** Forma de pagamento como o provedor escreve: PIX em maiúsculas, o resto como foi gravado. */
function ws_forma_pag_rotulo(?string $forma, bool $maiusc = false): string {
    $f = trim((string)$forma);
    if ($f === '') return $maiusc ? 'OUTROS' : 'outros';
    if (strtolower($f) === 'pix') return 'PIX';
    return $maiusc ? mb_strtoupper($f, 'UTF-8') : $f;
}

/** RECIBO PADRÃO — as linhas que o recibo do WhatsApp E o recibo impresso mostram, na mesma ordem.
 *  $f = linha da fatura (f.*, nome, cpf_cnpj). Pagamento (id, data, coletor, forma) vem do último
 *  lançamento em ws_pagamento; sem lançamento, usa os dados da própria fatura.
 *  Retorna [[ícone, rótulo, valor], ...]. */
function ws_recibo_linhas(PDO $db, array $f): array {
    $pg = null;
    try {
        $st = $db->prepare("SELECT id, data_pgto, valor_pago, forma, coletor, pago_por FROM ws_pagamento WHERE fatura_id=? ORDER BY id DESC LIMIT 1");
        $st->execute([(int)$f['id']]); $pg = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        // Banco antigo sem a coluna pago_por: tenta só sem ela (mantém o coletor).
        try { $st = $db->prepare("SELECT id, data_pgto, valor_pago, forma, coletor FROM ws_pagamento WHERE fatura_id=? ORDER BY id DESC LIMIT 1");
              $st->execute([(int)$f['id']]); $pg = $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $e1) {}
        // Banco antigo sem a coluna coletor: tenta sem ela.
        if (!$pg) try { $st = $db->prepare("SELECT id, data_pgto, valor_pago, forma FROM ws_pagamento WHERE fatura_id=? ORDER BY id DESC LIMIT 1");
              $st->execute([(int)$f['id']]); $pg = $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $e2) {}
    }
    // CPF/CNPJ de QUEM PAGOU (08/10/2026): vem do comprovante lido (o app do banco mascara o CPF: ***.030.654-**). Só aparece quando houve comprovante nesta baixa.
    $docPagou = '';
    try {
        $sq = $db->prepare("SELECT l.dados FROM ws_pix_selo s JOIN ws_comp_leitura l ON l.comprovante_id=s.comprovante_id WHERE s.fatura_id=? ORDER BY s.id DESC LIMIT 1");
        $sq->execute([(int)$f['id']]); $dj = json_decode((string)$sq->fetchColumn(), true);
        if (is_array($dj) && !empty($dj['pagador_doc'])) $docPagou = trim(preg_replace('/\s+/', '', preg_replace('/[*•xX]+/u', '', (string)$dj['pagador_doc'])), '.-/');   // sem a máscara do banco (09/10/2026)
        if ($docPagou !== '') { try { if (!function_exists('ws_comp_doc_completo') && is_file(__DIR__ . '/comprovantes_lib.php')) require_once __DIR__ . '/comprovantes_lib.php'; if (function_exists('ws_comp_doc_completo') && !empty($dj['pagador_doc'])) { $dc = ws_comp_doc_completo($db, (string)$dj['pagador_doc'], (int)($f['cliente_id'] ?? 0)); if ($dc !== '') $docPagou = $dc; } } catch (Throwable $e2) {} }
    } catch (Throwable $e) {}
    $dpag   = ($pg['data_pgto'] ?? null) ?: ($f['data_pagamento'] ?? null);
    $vpag   = ($f['valor_pago'] ?? null) !== null ? $f['valor_pago'] : (($pg['valor_pago'] ?? null) !== null ? $pg['valor_pago'] : ($f['valor'] ?? 0));
    $coletor = trim((string)(($pg['coletor'] ?? null) ?: ($f['coletor'] ?? '')));
    $forma   = ($pg['forma'] ?? null) ?: ($f['forma'] ?? '');
    $pagoPor = trim((string)($pg['pago_por'] ?? ''));   // "Pagamento Realizado por" — só aparece no recibo quando preenchido
    $d = fn($v) => $v ? date('d/m/Y', strtotime((string)$v)) : '—';
    $r = fn($v) => 'R$ ' . number_format((float)$v, 2, ',', '.');
    $linhas = [
        ['💵', 'CONFIRMAÇÃO DE PAGAMENTO', null],
        ['👤', 'Cliente', trim((string)($f['nome'] ?? ''))],
        ['🙋', 'Quem pagou', $pagoPor !== '' ? $pagoPor : 'O próprio cliente'],   // sempre logo abaixo do cliente (08/10/2026): deixa claro de quem é a conta e quem pagou
        ['📄', 'ID do Pagamento', (string)(($pg['id'] ?? null) ?: $f['id'])],
        ['📑', 'CPF/CNPJ do titular', ws_doc_formatado($f['cpf_cnpj'] ?? '') ?: '—'],
        ['✅', 'Pagamento em', $d($dpag ?: date('Y-m-d'))],
        ['📅', 'Vencimento em', $d($f['vencimento'] ?? null)],
        ['💰', 'Valor da fatura', $r($f['valor'] ?? 0)],
        ['💸', 'Valor do pagamento', $r($vpag)],
        ['👤', 'Recebido por', $coletor !== '' ? $coletor : '—'],
        ['💳', 'Forma de pagamento', $forma !== '' ? ws_forma_pag_rotulo($forma, true) : '—'],
    ];
    if ($docPagou !== '') $linhas[] = ['📑', 'CPF/CNPJ de quem pagou', $docPagou];
    // ordem de leitura (08/10/2026): cliente e o CPF dele; quem pagou e o CPF de quem pagou; depois o resto do recibo
    $ordem = ['CONFIRMAÇÃO DE PAGAMENTO' => 0, 'Cliente' => 1, 'CPF/CNPJ do titular' => 2, 'Quem pagou' => 3, 'CPF/CNPJ de quem pagou' => 4];
    $ix = 0; foreach ($linhas as $k => $l) $linhas[$k][3] = $ordem[$l[1]] ?? (10 + $ix++);
    usort($linhas, fn($a, $b) => $a[3] <=> $b[3]);
    foreach ($linhas as $k => $l) unset($linhas[$k][3]);
    return array_values($linhas);
}

/** SELO DE AUTENTICAÇÃO DO RECIBO (17/10/2026): código curto "WS-XXXX-XXXX" que identifica ESTE pagamento. Se a baixa veio de um comprovante, é o MESMO selo que o cliente já viu ao enviá-lo (ws_pix_selo);
 *  senão é calculado (HMAC com a chave do sistema sobre pagamento + título + valor + data): sempre o mesmo para o mesmo pagamento e impossível de inventar sem a chave. Quem tem o recibo confere recalculando. */
function ws_recibo_selo(PDO $db, array $f, string $idPag = ''): string {
    try {
        $q = $db->prepare("SELECT selo FROM ws_pix_selo WHERE fatura_id=? AND duplicado_de IS NULL ORDER BY id LIMIT 1"); $q->execute([(int)($f['id'] ?? 0)]);
        $sel = (string)$q->fetchColumn(); if ($sel !== '') return $sel;
    } catch (Throwable $e) {}
    $chave = ''; try { if (function_exists('ws_chatbot_cfg')) $chave = (string)(ws_chatbot_cfg()['chave'] ?? ''); } catch (Throwable $e) {}
    if ($chave === '') $chave = 'wellsystem';
    $h = hash_hmac('sha256', 'recibo|' . $idPag . '|' . (int)($f['id'] ?? 0) . '|' . number_format((float)($f['valor_pago'] ?? $f['valor'] ?? 0), 2, '.', '') . '|' . substr((string)($f['data_pagamento'] ?? ''), 0, 10), $chave, true);
    $abc = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'; $c = ''; for ($i = 0; $i < 8; $i++) $c .= $abc[ord($h[$i]) % strlen($abc)];
    return 'WS-' . substr($c, 0, 4) . '-' . substr($c, 4);
}
/** CAMPOS DO RECIBO PARA O MODELO DA META (26/10/2026): fora da janela de 24 h o recibo saía em 2 mensagens (modelo "Abrir Recibo" e, depois do toque do cliente, o recibo). Com um modelo aprovado que TRAZ o recibo
 *  (11 variáveis), sai em UMA mensagem. Ordem FIXA: {{1}} Cliente · {{2}} CPF/CNPJ titular · {{3}} Quem pagou (com o CPF de quem pagou, se houver) · {{4}} ID do pagamento · {{5}} Pagamento em · {{6}} Vencimento em ·
 *  {{7}} Valor da fatura · {{8}} Valor do pagamento · {{9}} Recebido por · {{10}} Forma de pagamento · {{11}} Autenticação. Texto fixo do modelo: ver CHANGELOG (CZ+1). */
function ws_recibo_vars_modelo(PDO $db, array $f): array {
    $m = []; foreach (ws_recibo_linhas($db, $f) as $l) if (isset($l[2]) && $l[2] !== null) $m[(string)$l[1]] = (string)$l[2];
    $quem = ($m['Quem pagou'] ?? 'O próprio cliente') . (!empty($m['CPF/CNPJ de quem pagou']) ? ' — CPF/CNPJ ' . $m['CPF/CNPJ de quem pagou'] : '');
    $idPag = $m['ID do Pagamento'] ?? (string)($f['id'] ?? '');
    return [$m['Cliente'] ?? '—', $m['CPF/CNPJ do titular'] ?? '—', $quem, $idPag, $m['Pagamento em'] ?? '—', $m['Vencimento em'] ?? '—', $m['Valor da fatura'] ?? '—', $m['Valor do pagamento'] ?? '—', $m['Recebido por'] ?? '—', $m['Forma de pagamento'] ?? '—', ws_recibo_selo($db, $f, $idPag)];
}
/** Variável de modelo da Meta: sem quebra de linha/tab nem espaços repetidos (a Meta recusa), vazio vira "—", no máximo 200 caracteres. */
function ws_wa_meta_vars_params(array $vars): array {
    $out = []; foreach ($vars as $v) { $t = trim(preg_replace('/\s+/u', ' ', str_replace(["\r", "\n", "\t"], ' ', (string)$v))); $out[] = ['type' => 'text', 'text' => $t !== '' ? mb_substr($t, 0, 200) : '—']; }
    return $out;
}
/** Texto do recibo para WhatsApp — modelo padrão do provedor. */
function ws_recibo_texto(PDO $db, array $f, ?array $cfg = null): string {
    $cfg = $cfg ?: ws_recibo_config();
    $lin = ws_recibo_linhas($db, $f);
    $cab = array_shift($lin);
    /* MODELO DO PROVEDOR (17/10/2026): sem negrito, rótulos com iniciais maiúsculas, "Obs do Boleto" logo após a forma de pagamento, rodapé "Gerado por @Wellsystem.". */
    $rot2 = ['CPF/CNPJ do titular' => 'CPF/CNPJ Titular', 'Quem pagou' => 'Quem Pagou', 'CPF/CNPJ de quem pagou' => 'CPF/CNPJ de Quem Pagou', 'Valor da fatura' => 'Valor da Fatura', 'Valor do pagamento' => 'Valor do Pagamento', 'Recebido por' => 'Recebido Por', 'Forma de pagamento' => 'Forma de Pagamento'];
    $t = "{$cab[0]} {$cab[1]}\n\n";
    foreach ($lin as [$ic, $rot, $val]) $t .= "$ic " . ($rot2[$rot] ?? $rot) . ": $val\n";
    $ass = trim((string)($cfg['assinatura'] ?? '')) ?: ws_recibo_assinatura_padrao();
    $obsR = trim((string)($f['obs'] ?? ''));
    $idPagR = ''; foreach ($lin as $lr) if (($lr[1] ?? '') === 'ID do Pagamento') { $idPagR = (string)$lr[2]; break; }
    $t .= "🔏 Autenticação: " . ws_recibo_selo($db, $f, $idPagR) . "\n";   // (17/10/2026) no lugar da observação interna do boleto
    $t .= "\nAtt.: $ass 🤝\n"
        . str_repeat('•', 33) . "\n"
        . "Recibo Gerado por Wellsystem.";
    return $t;
}
/** RESUMO DE PAGAMENTOS — modelo padrão do provedor (WhatsApp).
 *  Agrupa por forma (DINHEIRO, PIX, depois as demais em ordem alfabética); cada pagamento traz
 *  Nome, Login, Vencimento, Modo de Pag, Valor do Boleto, Valor Pago e Atendente; subtotal por
 *  forma e, no fim, Subtotal Geral e Total Geral (ambos = soma do que foi pago).
 *  Retorna ['texto' => string, 'n' => qtde, 'total' => float]. */
function ws_resumo_pagamentos_texto(PDO $db, string $ini, string $fim): array {
    $sql = "SELECT p.id, p.valor_pago, p.forma, %s coletor, %s pago_por, c.nome, f.vencimento, f.valor,
                   COALESCE(NULLIF(ct.login_pppoe,''), %s) login
            FROM ws_pagamento p JOIN ws_fatura f ON f.id=p.fatura_id
            JOIN ws_cliente c ON c.id=f.cliente_id LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
            WHERE p.data_pgto BETWEEN ? AND ? ORDER BY p.id";
    try { $st = $db->prepare(sprintf($sql, 'p.coletor', 'p.pago_por', 'ct.login_ipoe')); $st->execute([$ini, $fim]); }
    catch (Throwable $e) {
        try { $st = $db->prepare(sprintf($sql, 'p.coletor', 'NULL', 'ct.login_ipoe')); $st->execute([$ini, $fim]); }
        catch (Throwable $e2) { $st = $db->prepare(sprintf($sql, 'NULL', 'NULL', 'NULL')); $st->execute([$ini, $fim]); }
    }
    $grupos = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $m) {
        $k = strtolower(trim((string)$m['forma'])) ?: 'outros';
        $grupos[$k][] = $m;
    }
    uksort($grupos, function ($a, $b) {
        $pri = ['dinheiro' => 0, 'pix' => 1];
        $pa = $pri[$a] ?? 2; $pb = $pri[$b] ?? 2;
        return $pa !== $pb ? $pa - $pb : strcmp($a, $b);
    });
    $r   = fn($v) => 'R$ ' . number_format((float)$v, 2, ',', '.');
    $sep = str_repeat('=', 29);   // 29: com 30 a linha quebrava no celular (pedido 24/09)
    $nome = fn($v) => mb_convert_case(trim(preg_replace('/\s+/', ' ', (string)$v)), MB_CASE_TITLE, 'UTF-8');
    $cab = $ini === $fim ? date('d/m/Y', strtotime($ini))
                         : date('d/m/Y', strtotime($ini)) . ' a ' . date('d/m/Y', strtotime($fim));
    $t = "💵 *Resumo Pagamentos $cab*\n\n";
    $total = 0.0; $n = 0;
    foreach ($grupos as $k => $itens) {
        $modo = $k === 'pix' ? 'PIX' : $k;                                   // "Modo de Pag: dinheiro / PIX / galaxpay"
        $rot  = $k === 'pix' ? 'PIX' : mb_convert_case($k, MB_CASE_TITLE, 'UTF-8'); // "Subtotal Dinheiro / PIX / Galaxpay"
        $t .= "🔵 *PAG: " . mb_strtoupper($k, 'UTF-8') . "*\n\n";
        $sub = 0.0; $i = 0;
        foreach ($itens as $m) {
            $sub += (float)$m['valor_pago']; $n++;
            $i++;   // sem linha em branco entre os blocos (formato do provedor, 17/10/2026)
            /* FORMATO DO PROVEDOR (16/10/2026): número sozinho (*1* ), "Quem pagou" sempre (o próprio cliente ou quem pagou), Atendente por último. */
            $t .= "*" . $i . ")* "
                . "👷 Nome: *" . $nome($m['nome']) . "*\n"
                . "🔐 Login: " . (trim((string)$m['login']) !== '' ? trim($m['login']) : '—') . "\n"
                . "📅 Vencimento: " . ($m['vencimento'] ? date('d/m/Y', strtotime($m['vencimento'])) : '—') . "\n"
                . "💳 Modo de Pag: $modo\n"
                . "💰 Valor do Boleto: " . $r($m['valor']) . "\n"
                . "💸 Valor Pago: " . $r($m['valor_pago']) . "\n"
                . "🙋 Quem pagou: " . (trim((string)($m['pago_por'] ?? '')) !== '' ? trim($m['pago_por']) : 'O próprio cliente') . "\n"
                . "🙋‍♂️ Atendente: " . (trim((string)$m['coletor']) !== '' ? trim($m['coletor']) : '—') . "\n"
                . "$sep\n";
        }
        $total += $sub;
        $t .= "✅ *Subtotal $rot: " . $r($sub) . "*\n$sep\n\n";
    }
    if (!$grupos) $t .= "Nenhum pagamento no período.\n$sep\n\n";
    $t .= "🟡 *Subtotal Geral: " . $r($total) . "*\n"
        . "🔴 *Total Geral: " . $r($total) . "*";
    return ['texto' => $t, 'n' => $n, 'total' => $total];
}
/** Números que RECEBEM o resumo (config "numeros_resumo"), só dígitos, sem repetição. */
function ws_resumo_numeros(?array $cfg = null): array {
    $cfg = $cfg ?: ws_recibo_config();
    $out = [];
    /* Sem limite de quantidade: TODOS os números cadastrados recebem. Separadores aceitos: vírgula, ponto e vírgula,
       quebra de linha e ESPAÇO entre números (antes, dois números separados só por espaço viravam UM número
       gigante e nenhum dos dois recebia). "(11) 99999-0000" continua valendo como um número só. */
    foreach (preg_split('/[,;\r\n]+/', (string)($cfg['numeros_resumo'] ?? '')) as $trecho) {
        $trecho = trim($trecho);
        if ($trecho === '') continue;
        $partes = preg_split('/\s+/', $trecho) ?: [$trecho];
        $soDigitos = count($partes) > 1;
        foreach ($partes as $pt) if (!preg_match('/^\+?\d{10,13}$/', $pt)) { $soDigitos = false; break; }
        foreach ($soDigitos ? $partes : [$trecho] as $item) {
            $n = preg_replace('/\D/', '', $item);
            if ($n === '') continue;
            if (strlen($n) <= 11) $n = '55' . $n;
            $out[$n] = 1;
        }
    }
    return array_keys($out);
}

/** ENVIA O RESUMO de pagamentos do período para os números internos. Regra única do botão
 *  (origem 'manual') e do automático diário (origem 'automatico'). Fora da janela de 24h da API
 *  oficial da Meta vai o template do resumo (resumo_tpl, {{1}} = resumo_par) e o texto completo fica
 *  guardado no n8n para reenvio. O próprio número que envia é pulado (ws_wa_enviar_evolution).
 *  Cada número fica no Log de envios. @return ['ok'=>n enviados, 'falhas'=>n, 'nums'=>n, 'erros'=>[]] */
function ws_resumo_enviar(PDO $db, string $ini, string $fim, string $origem = 'manual', ?array $apenas = null): array {
    @set_time_limit(600);   // vários números, cada um conferindo a janela em 2 instâncias: não pode morrer no meio
    ignore_user_abort(true);
    $cfg = ws_recibo_config();
    $res = ws_resumo_pagamentos_texto($db, $ini, $fim);
    $nums = ws_resumo_numeros($cfg);
    // $apenas = reenvio só para quem falhou na rodada anterior (resumo automático); null = todos.
    if ($apenas !== null) $nums = array_values(array_intersect($nums, array_map('strval', $apenas)));
    $out = ['ok' => 0, 'falhas' => 0, 'nums' => count($nums), 'erros' => [], 'falhou_nums' => [], 'texto_puro' => 0, 'template' => 0];
    /* O {{1}} do template leva o total do dia de verdade (o texto completo fica guardado no n8n para reenvio). */
    $parDinamico = $res['n'] > 0
        ? $res['n'] . ' pagamento' . ($res['n'] === 1 ? '' : 's') . ' hoje — total R$ ' . number_format($res['total'], 2, ',', '.')
        : 'Nenhum pagamento hoje';
    /* REGRA DO RESUMO (pedido do provedor, repetido várias vezes): CADA número é decidido sozinho, na hora —
     *   janela ABERTA  → o resumo bruto, texto puro, SEM template;
     *   janela FECHADA → template.
     * Os dois tipos saem juntos na mesma rodada. Para isso: (1) a janela é conferida de novo, sem o cache de
     * 60 s/10 min; (2) 'garantir' faz o texto recusado pela Meta cair no template em vez de perder o envio;
     * (3) um número que dê erro ou exceção NÃO interrompe os outros. O log diz qual caminho cada um seguiu. */
    foreach ($nums as $n) {
        try {
            ws_wa_janela_esquecer($n);
            $r = ws_wa_enviar($n, $res['texto'], false, ['evento' => 'resumo', 'automatica' => true, 'garantir' => true,
                              'tpl' => (string)($cfg['resumo_tpl'] ?? ''), 'par' => $parDinamico]);
        } catch (Throwable $e) {
            $r = ['ok' => false, 'raw' => 'exceção: ' . $e->getMessage()];
        }
        $okN = !empty($r['ok']);
        $raw = is_string($r['raw'] ?? null) ? $r['raw'] : '';
        $via = '';
        if ($okN) {
            $okTpl = !empty($r['template']) || strpos($raw, 'template') !== false;
            $via = ($okTpl ? 'TEMPLATE (janela fechada)' : 'TEXTO PURO (janela aberta)') . (!empty($r['instancia']) ? ' pela ' . $r['instancia'] : '');
            $okTpl ? $out['template']++ : $out['texto_puro']++;
            $out['ok']++;
        } else {
            $out['falhas']++; $out['falhou_nums'][] = $n;
            $out['erros'][] = $n . ': ' . ($raw !== '' ? mb_substr($raw, 0, 160) : 'falha no envio');
        }
        ws_recibo_log_gravar($db, 'resumo', [
            'cliente_nome' => 'Resumo ' . date('d/m/Y', strtotime($ini)) . ($ini !== $fim ? ' a ' . date('d/m/Y', strtotime($fim)) : ''),
            'telefone' => $n, 'valor_pago' => $res['total'], 'enviado' => $okN, 'origem' => $origem,
            'erro' => $okN ? mb_substr($via . ' — ' . $raw, 0, 250) : ($raw !== '' ? $raw : 'falha no envio'),
        ]);
    }
    return $out;
}

/** Diagnóstico do resumo automático — mesmo modelo do backup (OLT/WellSystem): grava o MOTIVO da
 *  última passada (rodou, pulou e por quê, ou falhou), sobrescrito a cada rodada do cron, pra dar
 *  pra ver por que o resumo automático não saiu sem precisar entrar no servidor. */
function ws_resumo_ag_diag(string $msg): void {
    @file_put_contents(WS_CACHE . '/resumo_auto_diag.txt', date('Y-m-d H:i:s') . ' ' . $msg);
    @chmod(WS_CACHE . '/resumo_auto_diag.txt', 0666);
}
/** RESUMO AUTOMÁTICO DO DIA — chamado a cada passada do cron (radius_sync.php). Sai 1x por dia, a
 *  partir do horário "resumo_hora", com os pagamentos de HOJE. Marca em cache/resumo_auto_ultimo.txt. */
function ws_resumo_auto_run(PDO $db): array {
    $cfg = ws_recibo_config();
    if (empty($cfg['resumo_auto'])) { ws_resumo_ag_diag('Desligado — marque "Enviar o resumo do dia automaticamente" em Recibos → Configuração.'); return ['rodou' => false, 'motivo' => 'desligado']; }
    $hora = preg_match('/^\d{2}:\d{2}$/', (string)($cfg['resumo_hora'] ?? '')) ? $cfg['resumo_hora'] : '20:00';
    $marca = WS_CACHE . '/resumo_auto_ultimo.txt'; $hoje = date('Y-m-d');
    $tf0 = WS_CACHE . '/resumo_auto_try.txt';
    $espera = 300;   // 5 min entre uma tentativa e a próxima (antes 15 min)
    // REENVIO: rodada que saiu para uns e falhou para outros → repete SÓ para quem falhou, a cada 5 min (até 12 vezes).
    $pendF = WS_CACHE . '/resumo_auto_pend.json';
    $pd = is_file($pendF) ? json_decode((string)@file_get_contents($pendF), true) : null;
    if (is_array($pd)) {
        if (($pd['dia'] ?? '') !== $hoje || empty($pd['nums']) || (int)($pd['tent'] ?? 0) >= 12) { @unlink($pendF); }
        elseif (time() - (int)($pd['t'] ?? 0) < $espera) { return ['rodou' => false, 'motivo' => 'aguardando reenvio aos que falharam']; }
        else {
            try {
                $r = ws_resumo_enviar($db, $hoje, $hoje, 'automatico', (array)$pd['nums']);
                if ($r['falhas'] > 0) @file_put_contents($pendF, json_encode(['dia' => $hoje, 'nums' => $r['falhou_nums'], 't' => time(), 'tent' => (int)($pd['tent'] ?? 0) + 1]));
                else @unlink($pendF);
                ws_resumo_ag_diag('Reenvio — ' . $r['ok'] . ' enviado(s), ' . $r['falhas'] . ' falha(s)' . ($r['erros'] ? ' — ' . implode(' | ', $r['erros']) : '') . '.');
                return ['rodou' => true] + $r;
            } catch (Throwable $e) { ws_resumo_ag_diag('FALHOU no reenvio: ' . $e->getMessage()); return ['rodou' => false, 'motivo' => 'erro: ' . $e->getMessage()]; }
        }
    }
    if (is_file($tf0) && (time() - (int)@file_get_contents($tf0)) < $espera) { ws_resumo_ag_diag('Última tentativa não enviou nada — nova tentativa em até 5 min (veja o motivo em Recibos → Resumo).'); return ['rodou' => false, 'motivo' => 'aguardando nova tentativa']; }
    // Controle por HORÁRIO AGENDADO: remarcar o horário volta a disparar, mesmo já tendo enviado hoje.
    [$pend, $slot, $why] = ws_agenda_slot($marca, $hora);
    if (!$pend) { ws_resumo_ag_diag($why === 'antes' ? "Ainda não deu o horário (agora " . date('H:i') . ", agendado $hora)." : "Horário de hoje ($slot) já cumprido."); return ['rodou' => false, 'motivo' => $why === 'antes' ? "antes das $hora" : 'horário já cumprido']; }
    if (!ws_resumo_numeros($cfg)) { ws_resumo_ag_diag('Sem números cadastrados para receber (Recibos → Configuração → "Números que RECEBEM o resumo").'); return ['rodou' => false, 'motivo' => 'sem números']; }
    @file_put_contents($marca, $slot); @chmod($marca, 0640);   // marca ANTES: duas passadas juntas não mandam duas vezes
    /* 27/10/2026 (pedido do provedor): dia SEM pagamento = o resumo automático NÃO sai (antes saía o modelo "Nenhum pagamento hoje" e, com o toque, uma 2ª mensagem). O horário fica cumprido; o botão manual segue mandando. */
    try { if ((int)(ws_resumo_pagamentos_texto($db, $hoje, $hoje)['n'] ?? 0) === 0) { ws_resumo_ag_diag('Sem pagamento hoje (' . date('d/m/Y') . ') — resumo automático não enviado.'); return ['rodou' => false, 'motivo' => 'sem pagamento hoje']; } } catch (Throwable $e) { /* não deu para contar: segue o envio de sempre */ }
    try {
        $r = ws_resumo_enviar($db, $hoje, $hoje, 'automatico');
        if (empty($r['ok'])) { @unlink($marca); @file_put_contents($tf0, (string)time()); }   // nada saiu: libera nova tentativa (a cada 5 min)
        elseif ($r['falhas'] > 0) { @file_put_contents($pendF, json_encode(['dia' => $hoje, 'nums' => $r['falhou_nums'], 't' => time(), 'tent' => 0])); }   // saiu para uns: reenvia só aos que falharam
        ws_resumo_ag_diag('Rodou — ' . $r['ok'] . ' enviado(s) (' . $r['texto_puro'] . ' texto puro / ' . $r['template'] . ' template), ' . $r['falhas'] . ' falha(s)' . ($r['erros'] ? ' — ' . implode(' | ', $r['erros']) : '') . '.');
        return ['rodou' => true] + $r;
    } catch (Throwable $e) {
        // Antes, uma falha aqui (ex.: gateway derrubado no meio do envio) subia até o radius_sync.php
        // e caía num catch(Throwable){} genérico, sem deixar rastro — parecia que "nada acontecia".
        @unlink($marca); @file_put_contents($tf0, (string)time());
        ws_resumo_ag_diag('FALHOU: ' . $e->getMessage());
        return ['rodou' => false, 'motivo' => 'erro: ' . $e->getMessage()];
    }
}

/** Monta e envia o recibo de uma fatura paga pelo WhatsApp. Marca recibo_em. */
/** Grava no log de envios (tela Recibos → Log de envios) — cada tentativa, sucesso ou falha,
 *  pra deixar visível de verdade que o envio automático aconteceu (não só uma data escondida). */
function ws_recibo_log_gravar(PDO $db, string $tipo, array $dados): void {
    try {
        $db->prepare("INSERT INTO ws_recibo_log
            (tipo,fatura_id,cliente_nome,login,atendente,data_pagamento,vencimento,valor_boleto,valor_pago,forma,telefone,enviado,origem,erro)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
          ->execute([$tipo, $dados['fatura_id'] ?? null, $dados['cliente_nome'] ?? null, $dados['login'] ?? null,
                     $dados['atendente'] ?? null, $dados['data_pagamento'] ?? null, $dados['vencimento'] ?? null,
                     $dados['valor_boleto'] ?? null, $dados['valor_pago'] ?? null, $dados['forma'] ?? null,
                     $dados['telefone'] ?? null, !empty($dados['enviado']) ? 1 : 0, $dados['origem'] ?? 'automatico',
                     $dados['erro'] ?? null]);
    } catch (Throwable $e) { /* log é "nice to have" — nunca impede o envio em si */ }
}

/**
 * LIMPEZA DA TELA DE RECIBOS — sem impacto no caixa.
 * Marca ws_fatura.recibo_oculto=1 nos títulos pagos há mais de N dias (config "limpeza_dias", mín. 1).
 * NÃO apaga fatura nem pagamento: Caixa, Balancete e relatórios continuam contando igual; o título só
 * sai da lista de Recibos e do "Enviar em massa" (é isso que evita mandar recibo velho por engano).
 * Roda 1x por dia (marca em cache/recibos_limpeza.txt), chamada pela própria tela de Recibos e pelo
 * cron (recibos_limpar_run.php) — funciona mesmo em servidor sem cron configurado.
 * @return array ['rodou'=>bool,'ocultados'=>int,'dias'=>int,'motivo'=>?string]
 */
function ws_recibos_limpar_auto(PDO $db, bool $forcar = false): array {
    $cfg = ws_recibo_config();
    $dias = max(1, (int)($cfg['limpeza_dias'] ?? 90));
    $r = ['rodou' => false, 'ocultados' => 0, 'dias' => $dias, 'motivo' => null];
    if (empty($cfg['limpeza_auto'])) { $r['motivo'] = 'Limpeza automática desligada.'; return $r; }
    $marca = WS_CACHE . '/recibos_limpeza.txt';
    if (!$forcar && is_file($marca) && trim((string)@file_get_contents($marca)) === date('Y-m-d')) { $r['motivo'] = 'Já rodou hoje.'; return $r; }
    try {
        $st = $db->prepare("UPDATE ws_fatura SET recibo_oculto=1, recibo_oculto_em=NOW()
                             WHERE status='pago' AND COALESCE(recibo_oculto,0)=0
                               AND data_pagamento IS NOT NULL AND data_pagamento < (CURDATE() - INTERVAL ? DAY)");
        $st->execute([$dias]);
        $r['rodou'] = true; $r['ocultados'] = $st->rowCount();
        @file_put_contents($marca, date('Y-m-d')); @chmod($marca, 0640);
    } catch (Throwable $e) { $r['motivo'] = $e->getMessage(); }
    return $r;
}

/** Recibo por fatura, um de cada vez (14/10/2026): duas chamadas juntas (webhook repetido do gateway, conciliação + baixa) esperavam a checagem "já enviou?" ao mesmo tempo e mandavam o recibo em dobro.
 *  A trava (MySQL GET_LOCK por fatura) faz a 2ª esperar a 1ª terminar e ver o envio já registrado. Falhou em travar = segue (fail-open). */
function ws_recibo_enviar(PDO $db, int $faturaId, string $origem = 'automatico'): array {
    $nl = 'ws_recibo_' . $faturaId; $tr = false;
    try { $q = $db->prepare('SELECT GET_LOCK(?, 25)'); $q->execute([$nl]); $tr = (int)$q->fetchColumn() === 1; } catch (Throwable $e) {}
    try { return ws_recibo_enviar_i($db, $faturaId, $origem); }
    finally { if ($tr) { try { $q = $db->prepare('SELECT RELEASE_LOCK(?)'); $q->execute([$nl]); } catch (Throwable $e) {} } }
}
function ws_recibo_enviar_i(PDO $db, int $faturaId, string $origem = 'automatico'): array {
    $st = $db->prepare("SELECT f.*, c.nome, c.celular, c.cpf_cnpj, ct.login_pppoe,
                               (SELECT p.coletor FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) coletor,
                               (SELECT p.forma FROM ws_pagamento p WHERE p.fatura_id=f.id ORDER BY p.id DESC LIMIT 1) forma
                        FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?");
    $st->execute([$faturaId]); $f = $st->fetch();
    $logBase = ['fatura_id' => $faturaId, 'cliente_nome' => $f['nome'] ?? null, 'login' => $f['login_pppoe'] ?? null,
                'atendente' => $f['coletor'] ?? null, 'data_pagamento' => $f['data_pagamento'] ?? null,
                'vencimento' => $f['vencimento'] ?? null, 'valor_boleto' => $f['valor'] ?? null,
                'valor_pago' => $f['valor_pago'] ?? ($f['valor'] ?? null), 'forma' => $f['forma'] ?? null, 'origem' => $origem];
    if (!$f) { ws_recibo_log_gravar($db, 'recibo', $logBase + ['enviado'=>0,'erro'=>'Fatura não encontrada.']); return ['ok' => false, 'raw' => 'Fatura não encontrada.']; }
    if (trim((string)$f['celular']) === '') { ws_recibo_log_gravar($db, 'recibo', $logBase + ['enviado'=>0,'erro'=>'Cliente sem celular cadastrado.']); return ['ok' => false, 'raw' => 'Cliente sem celular.']; }
    if (!ws_msg_cliente_permitido($db, (int)$f['cliente_id'], !empty($f['contrato_id']) ? (int)$f['contrato_id'] : null)) {
        ws_recibo_log_gravar($db, 'recibo', $logBase + ['enviado'=>0,'erro'=>'Cliente desativado — envio proibido.']);
        return ['ok' => false, 'raw' => 'Cliente desativado: envio de mensagem proibido.'];
    }
    /* JANELA DE 24h NO AUTOMÁTICO (pedido do provedor). Envio AUTOMÁTICO (ao receber, webhook do
       gateway, conciliação) só sai se o PAGAMENTO aconteceu nas últimas 24h — assim uma baixa antiga
       (conciliação de extrato, pagamento lançado com data para trás, gateway que avisou atrasado) não
       dispara recibo fora de hora. MANUAL (botão WhatsApp, Enviar em massa, "enviar recibo agora")
       envia a qualquer tempo. Momento do pagamento = data do pagamento; se foi lançado no mesmo dia,
       usa a hora do lançamento (ws_pagamento.criado_em), senão considera o fim daquele dia. */
    if ($origem !== 'manual') {
        $momento = null;
        try {
            $pq = $db->prepare("SELECT data_pgto, criado_em FROM ws_pagamento WHERE fatura_id=? ORDER BY id DESC LIMIT 1");
            $pq->execute([$faturaId]); $pg = $pq->fetch();
            $dPg = (string)($pg['data_pgto'] ?? ($f['data_pagamento'] ?? ''));
            $cri = (string)($pg['criado_em'] ?? '');
            if ($dPg !== '') $momento = ($cri !== '' && substr($cri, 0, 10) === substr($dPg, 0, 10)) ? strtotime($cri) : strtotime(substr($dPg, 0, 10) . ' 23:59:59');
        } catch (Throwable $e) {}
        if ($momento && (time() - $momento) > 86400) {
            ws_recibo_log_gravar($db, 'recibo', $logBase + ['enviado' => 0, 'erro' => 'Automático bloqueado: pagamento com mais de 24h (envie manualmente se quiser).']);
            return ['ok' => false, 'raw' => 'Fora da janela de 24h do envio automático.'];
        }
    }
    /* SEM RECIBO EM DOBRO (14/10/2026): o mesmo recibo AUTOMÁTICO não sai duas vezes na mesma janela de 24 h (webhook repetido do gateway, conciliação + baixa, 2 caminhos juntos).
       Se esta fatura já teve recibo enviado com sucesso nas últimas 24 h, o automático não repete (o manual — botão do atendente — continua livre). A instância não importa: é por fatura. */
    if ($origem !== 'manual') {
        try {
            $dq = $db->prepare("SELECT COUNT(*) FROM ws_recibo_log WHERE tipo='recibo' AND fatura_id=? AND enviado=1 AND criado_em >= NOW() - INTERVAL 24 HOUR");
            $dq->execute([$faturaId]);
            if ((int)$dq->fetchColumn() > 0) {
                ws_recibo_log_gravar($db, 'recibo', $logBase + ['telefone' => $f['celular'], 'enviado' => 0, 'erro' => 'Automático bloqueado: o recibo desta fatura já foi enviado nas últimas 24h (sem duplicar).']);
                return ['ok' => false, 'duplicado' => true, 'raw' => 'Recibo já enviado nas últimas 24h (não duplica).'];
            }
        } catch (Throwable $e) {}
    }
    $cfg = ws_recibo_config();
    ws_wa_janela_esquecer($f['celular']);
    // Modelo único (o mesmo do recibo impresso): ws_recibo_texto() → ws_recibo_linhas().
    $msg = ws_recibo_texto($db, $f, $cfg);
    $r = ws_wa_enviar($f['celular'], $msg, false, ['evento' => 'recibo', 'automatica' => true,
                        'tpl' => (string)($cfg['meta_tpl'] ?? ''), 'par' => (string)($cfg['meta_par'] ?? ''),
                        'tpl_recibo' => trim((string)($cfg['meta_tpl_recibo'] ?? '')), 'tpl_vars' => trim((string)($cfg['meta_tpl_recibo'] ?? '')) !== '' ? ws_recibo_vars_modelo($db, $f) : [],
                        'origem' => $origem]);
    /* 24/09/2026: o recibo da baixa pelo gateway NÃO é mais "sempre template". Segue a regra única do roteador —
       janela aberta = mensagem pura pela instância da janela; fechada = template. (Pagamento real de teste: o
       cliente já conversava com a instância e o recibo chegou por template.) */
    if (!empty($r['ok'])) $db->prepare("UPDATE ws_fatura SET recibo_em=NOW() WHERE id=?")->execute([$faturaId]);
    ws_recibo_log_gravar($db, 'recibo', $logBase + ['telefone' => $f['celular'], 'enviado' => !empty($r['ok']), 'erro' => !empty($r['ok']) ? null : (is_string($r['raw'] ?? null) ? $r['raw'] : 'falha no envio')]);
    return $r;
}

/* ENTREGA DO QUE FICOU PENDENTE NO MODELO (10/10/2026) — com a janela de 24 h FECHADA só o modelo da Meta sai ("templete_chat" + botão Sim), e o n8n guarda
 * apenas o TEXTO para entregar quando o cliente responde. O boleto em PDF e o QR/"PIX copia e cola" ficavam de fora (cliente tocava em "Sim" e recebia só o texto,
 * várias mensagens juntas). Agora o WellSystem guarda esses anexos (cache/meta_pendente/, 1 arquivo por número, vale 24 h) e o webhook da Evolution
 * (api/index.php) dispara pendente_entregar_run.php assim que o cliente responde: ~7 s depois (o texto do n8n sai primeiro) entrega boleto + PIX, 1 vez só. */
function ws_wa_pendente_arq(string $telefone): string {
    $d = WS_CACHE . '/meta_pendente'; if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d . '/' . sha1(substr(preg_replace('/\D/', '', $telefone), -8)) . '.json';
}
/** $anexos: [['tipo'=>'document'|'image','nome'=>..,'b64'=>..,'legenda'=>..], ...] — o último envio substitui o anterior do mesmo número. */
function ws_wa_pendente_guardar(string $telefone, array $anexos, array $faturas = []): void {
    if (!$anexos || trim(preg_replace('/\D/', '', $telefone)) === '') return;
    $f = ws_wa_pendente_arq($telefone);
    /* $faturas (15/10/2026): as faturas a que o boleto/PIX guardado se refere — na entrega, se TODAS já foram pagas/canceladas nesse meio-tempo, nada é entregue (ver ws_wa_pendente_entregar). */
    @file_put_contents($f, json_encode(['em' => time(), 'num' => ws_wa_numero($telefone), 'anexos' => $anexos, 'faturas' => array_values(array_filter(array_map('intval', $faturas)))], JSON_UNESCAPED_UNICODE), LOCK_EX); @chmod($f, 0640);
}
function ws_wa_pendente_existe(string $jidOuTel): bool {
    $f = ws_wa_pendente_arq($jidOuTel); return is_file($f) && time() - (int)@filemtime($f) <= 86400;
}
/** Entrega os anexos guardados (uma única vez — quem consegue renomear o arquivo é quem entrega). Devolve quantos saíram. */
function ws_wa_pendente_entregar(string $jidOuTel): int {
    $f = ws_wa_pendente_arq($jidOuTel); if (!is_file($f)) return 0;
    $tmp = $f . '.' . getmypid(); if (!@rename($f, $tmp)) return 0;
    $d = json_decode((string)@file_get_contents($tmp), true); @unlink($tmp);
    if (!is_array($d) || time() - (int)($d['em'] ?? 0) > 86400 || empty($d['anexos'])) return 0;
    /* JÁ PAGO NO MEIO-TEMPO (15/10/2026): o modelo saiu com boleto/PIX, o cliente pagou antes de tocar em "Sim" — não entrega boleto/PIX velho; só agradece. -1 = não entregou por já estar paga. */
    if (!empty($d['faturas']) && function_exists('ws_db')) {
        try {
            $ph = implode(',', array_fill(0, count($d['faturas']), '?')); $q = ws_db()->prepare("SELECT COUNT(*) FROM ws_fatura WHERE id IN ($ph) AND status IN ('aberto','vencido','processando')"); $q->execute($d['faturas']);
            if ((int)$q->fetchColumn() === 0) { try { ws_wa_enviar_conversa((string)$d['num'], "✅ Obrigado! Já identificamos o pagamento desta fatura — não há mais nada a pagar por ela. 🙏", ['evento' => 'robo_concluiu']); } catch (Throwable $e) {} return -1; }
        } catch (Throwable $e) {}
    }
    $n = 0;
    foreach ($d['anexos'] as $a) {
        try { $r = ws_wa_midia((string)$d['num'], (string)$a['tipo'], (string)$a['nome'], (string)$a['b64'], (string)($a['legenda'] ?? ''), ['evento' => 'entrega_pendente', 'automatica' => true, 'interna' => true]); } catch (Throwable $e) { $r = []; }
        if (!empty($r['ok'])) $n++;
        sleep(1);
    }
    return $n;
}
