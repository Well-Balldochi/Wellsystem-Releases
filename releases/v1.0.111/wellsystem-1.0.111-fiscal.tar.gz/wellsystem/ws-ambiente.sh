#!/bin/bash
# =================================================================================================
# WellSystem — DETECÇÃO DO AMBIENTE (biblioteca; usada pelo ATUALIZAR.sh e pelo menu "wellsystem")
# =================================================================================================
# Responde sozinho, sem o operador digitar caminho nenhum:
#   · ONDE o WellSystem está publicado neste servidor
#   · em QUAL cenário ele roda
#   · com qual USUÁRIO os arquivos precisam ficar
#
# OS CENÁRIOS (é deles que tudo o mais depende):
#
#   servidor  WellSystem instalado direto no servidor pelo INSTALAR.sh, com FreeRADIUS próprio e
#             banco wellsystem separado. Normalmente em /var/www/wellsystem, com vhost próprio.
#             É o ÚNICO cenário em que o servidor é nosso: cron, menu de terminal, scripts do
#             FreeRADIUS e configuração do Apache podem ser mexidos.
#
#   mkauth    Addon dentro do MK-Auth, em /opt/mk-auth/admin/addons/wellsystem. O servidor é do
#             MK-Auth: FreeRADIUS, Apache, PHP-FPM e o menu do root são DELE. Aqui só se troca o
#             código do addon — instalar o nosso menu no login do root, por exemplo, atropelaria
#             o menu do MK-Auth.
#
#   addon     Addon dentro de outro ERP (subpasta de um site que não é nosso). Mesma regra do
#             MK-Auth: só o código do addon.
#
#   docker    Rodando em container. O código mora DENTRO da imagem; atualizar é reconstruir a
#             imagem na pasta do projeto (docker compose up -d --build) — nunca copiar arquivo.
#
# COMO A INSTALAÇÃO É ACHADA: primeiro se descobre quais pastas o servidor web realmente PUBLICA
# (DocumentRoot/Alias do Apache, root/alias do nginx), e só dentro delas se procura o WellSystem.
# Isso é o que impede confundir o sistema no ar com uma cópia do pacote largada em /root, /tmp ou
# /opt/wellsystem, ou com as versões guardadas em /var/backups — nenhuma delas é publicada.
#
# TESTES: todo caminho de sistema passa por WS_RAIZ (vazio em produção). O --selftest monta uma
# árvore falsa com os quatro cenários e confere a detecção sem tocar no servidor.
# =================================================================================================

WS_RAIZ="${WS_RAIZ:-}"

# Uma pasta é o WellSystem quando tem os três arquivos que só ele tem juntos.
ws_amb_eh_wellsystem() {
    [ -f "$1/config.php" ] && [ -f "$1/erp.php" ] && [ -f "$1/radius_lib.php" ]
}

# Caminho sem barra final, sem aspas, sem ponto-e-vírgula (formatos de Apache e nginx).
ws_amb_normaliza() {
    local p="$1"
    p="${p%;}"; p="${p%\"}"; p="${p#\"}"; p="${p%\'}"; p="${p#\'}"
    [ "$p" != "/" ] && p="${p%/}"
    printf '%s' "$p"
}

# Pastas que o servidor web publica, uma por linha (já com WS_RAIZ na frente).
ws_amb_raizes_publicadas() {
    local arqs=() f
    for f in "$WS_RAIZ"/etc/apache2/sites-enabled/* "$WS_RAIZ"/etc/apache2/conf-enabled/* \
             "$WS_RAIZ"/etc/httpd/conf/*.conf "$WS_RAIZ"/etc/httpd/conf.d/*.conf \
             "$WS_RAIZ"/etc/nginx/sites-enabled/* "$WS_RAIZ"/etc/nginx/conf.d/*.conf; do
        [ -f "$f" ] && arqs+=("$f")
    done
    [ "${#arqs[@]}" -gt 0 ] || return 0
    # Apache:  DocumentRoot /x   |   Alias /url /x       nginx:  root /x;   |   alias /x;
    # A diretiva é procurada EM QUALQUER POSIÇÃO da linha, e não só no começo: "server { root /x; }"
    # numa linha só é nginx válido, e ler apenas a primeira palavra deixava essa pasta de fora —
    # a instalação ali dentro não era achada, e o INSTALAR.sh não saberia que o servidor já é de
    # outro sistema. Comentário no fim da linha é descartado antes.
    cat "${arqs[@]}" 2>/dev/null \
    | awk '
        {
          sub(/#.*/, "")
          gsub(/[{};="\047]/, " ")
          n = split($0, t, /[[:space:]]+/)
          for (i = 1; i <= n; i++) {
            k = tolower(t[i])
            if (k == "documentroot" && i+1 <= n) { print t[i+1]; i++; continue }
            if (k == "alias") {
              # Apache: Alias /url /pasta (dois argumentos) — nginx: alias /pasta (um).
              if (i+2 <= n && substr(t[i+2],1,1) == "/") { print t[i+2]; i += 2 }
              else if (i+1 <= n)                         { print t[i+1]; i++ }
              continue
            }
            if (t[i] == "root" && i+1 <= n && substr(t[i+1],1,1) == "/") { print t[i+1]; i++; continue }
          }
        }
      ' \
    | while IFS= read -r p; do
        p="$(ws_amb_normaliza "$p")"
        case "$p" in /*) printf '%s%s\n' "$WS_RAIZ" "$p" ;; esac
      done | sort -u
}

# Instalações do WellSystem publicadas, uma por linha. $1 (opcional) = pasta a ignorar (o pacote).
ws_amb_instalacoes() {
    local ignorar="${1:-}" raiz d achou=0
    {
        while IFS= read -r raiz; do
            [ -d "$raiz" ] || continue
            ws_amb_eh_wellsystem "$raiz" && echo "$raiz"
            # 4 níveis dão conta do caso mais fundo conhecido: Alias /admin -> /opt/mk-auth/admin,
            # com o addon em /opt/mk-auth/admin/addons/wellsystem.
            find "$raiz" -mindepth 1 -maxdepth 4 -type f -name erp.php 2>/dev/null \
                | while IFS= read -r f; do d="$(dirname "$f")"; ws_amb_eh_wellsystem "$d" && echo "$d"; done
        done < <(ws_amb_raizes_publicadas)
        # Rede de segurança para servidor web com configuração fora do padrão (nada legível acima):
        # os dois lugares onde o WellSystem é instalado de fato.
        for d in "$WS_RAIZ"/var/www/wellsystem "$WS_RAIZ"/var/www/html/wellsystem "$WS_RAIZ"/opt/mk-auth/admin/addons/wellsystem; do
            ws_amb_eh_wellsystem "$d" && echo "$d"
        done
    } | while IFS= read -r d; do
        # Nunca a própria pasta do pacote que está sendo publicado.
        if [ -n "$ignorar" ] && [ "$(cd "$d" 2>/dev/null && pwd -P)" = "$(cd "$ignorar" 2>/dev/null && pwd -P)" ]; then continue; fi
        (cd "$d" 2>/dev/null && pwd -P)
    done | sort -u
}

# Cenário de uma instalação: servidor | mkauth | addon
ws_amb_cenario() {
    local d="$1" raiz
    case "$d" in "$WS_RAIZ"/opt/mk-auth/*|*/mk-auth/*) echo mkauth; return ;; esac
    # É a RAIZ de um site (DocumentRoot/root apontando para ela)? Então o site é nosso.
    while IFS= read -r raiz; do
        [ "$(cd "$raiz" 2>/dev/null && pwd -P)" = "$d" ] && { echo servidor; return; }
    done < <(ws_amb_raizes_publicadas)
    # Sinais que só o INSTALAR.sh deixa: o arquivo de senhas e as tarefas agendadas dele.
    if [ -f "$WS_RAIZ/root/.wellsystem-instalacao" ] || [ -f "$WS_RAIZ/etc/cron.d/wellsystem" ]; then
        case "$d" in "$WS_RAIZ"/var/www/*) echo servidor; return ;; esac
    fi
    echo addon
}

# Usuário:grupo que deve ser dono dos arquivos. Preserva o de hoje — é o que já funciona naquele
# servidor. Só quando está com root (errado para o PHP) procura o usuário do servidor web.
ws_amb_dono() {
    local d="$1" dono u
    dono="$(stat -c '%U:%G' "$d" 2>/dev/null || true)"
    if [ -n "$dono" ] && [ "${dono%%:*}" != "root" ]; then echo "$dono"; return; fi
    u="$( { ps -eo user=,comm= 2>/dev/null || true; } | awk '$2 ~ /^(apache2|httpd|php-fpm|php.*-fpm|nginx)$/ && $1 != "root" {print $1; exit}')"
    [ -n "$u" ] && { echo "$u:$u"; return; }
    echo "www-data:www-data"
}

# Container do WellSystem rodando? Devolve "container|pasta-do-projeto" (uma linha por container).
# A pasta sai do rótulo que o próprio docker compose grava — não é chute.
ws_amb_docker() {
    command -v docker >/dev/null 2>&1 || return 0
    docker ps --format '{{.Names}}|{{.Image}}|{{.Label "com.docker.compose.project.working_dir"}}' 2>/dev/null \
        | awk -F'|' 'tolower($2) ~ /wellsystem/ {print $1 "|" $3}'
}

# Estamos DENTRO de um container?
ws_amb_dentro_container() { [ -f "$WS_RAIZ/.dockerenv" ]; }

# Hash da instalação — o mesmo que o config.php usa (md5 do caminho real) para nomear os espelhos.
ws_amb_hash() {
    if command -v php >/dev/null 2>&1; then
        php -r 'echo substr(md5(realpath($argv[1])), 0, 10);' "$1" 2>/dev/null
    else
        printf '%s' "$(cd "$1" && pwd -P)" | md5sum | cut -c1-10
    fi
}

# Recarrega só o que este cenário permite, com o gerenciador de serviços que existir.
ws_amb_recarregar() {
    local cenario="$1" s
    case "$cenario" in
        mkauth)
            # Servidor do MK-Auth: opcache revalida sozinho em ~2s e nenhuma configuração dele foi
            # tocada. Recarregar os pools dele afetaria central do assinante e boletos — sem ganho.
            echo '    MK-Auth: nada a recarregar (o PHP do painel pega o codigo novo sozinho em segundos)'
            return 0 ;;
        addon)
            echo '    addon em outro ERP: servidor web desse sistema nao foi tocado (codigo novo entra sozinho)'
            return 0 ;;
    esac
    if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
        for s in apache2 httpd nginx; do
            systemctl is-active --quiet "$s" 2>/dev/null && systemctl reload "$s" 2>/dev/null && echo "    recarregado: $s"
        done
    else
        for s in apache2 httpd nginx; do
            [ -x "/etc/init.d/$s" ] && "/etc/init.d/$s" reload >/dev/null 2>&1 && echo "    recarregado: $s"
        done
    fi
    return 0
}

# Instala o MENU DE TERMINAL (comando "wellsystem") e a abertura automática dele no login do root —
# igual ao menu do MK-Auth: entrou pelo PuTTY/SSH, pede a senha do root e abre a lista; "Cancelar"
# (ou a opção 0) libera o terminal para digitar comandos. Só no cenário SERVIDOR.
#
# Chamada pelo INSTALAR.sh E pelo ATUALIZAR.sh. Antes só o INSTALAR.sh escrevia a chamada no
# .bashrc: servidor que recebeu o menu por atualização tinha o comando "wellsystem", mas o menu
# nunca abria sozinho no login.
#
# As guardas da chamada NÃO são decoração:
#   case $- in *i*        só em shell INTERATIVO — scp/rsync/sftp e "ssh root@host comando" quebram
#                         com qualquer saída no login.
#   -t 0 e -t 1           só com terminal de verdade.
#   WS_MENU_OFF=1         válvula para automação: "WS_MENU_OFF=1 ssh root@host" entra direto no shell.
#   WS_MENU_ABERTO        não reabre o menu em cada "bash" ou "su" digitado depois de sair dele.
ws_amb_menu_instalar() {
    local d="$1" rc="$WS_RAIZ/root/.bashrc" pf
    if [ ! -f "$d/WELLSYSTEM-MENU.sh" ]; then
        echo '    AVISO: WELLSYSTEM-MENU.sh nao veio no pacote — menu de terminal nao instalado'
        return 0
    fi
    mkdir -p "$WS_RAIZ/usr/local/lib/wellsystem" "$WS_RAIZ/usr/local/sbin"
    install -m 644 "$d/ws-ambiente.sh" "$WS_RAIZ/usr/local/lib/wellsystem/ws-ambiente.sh"
    [ -f "$d/ws-expandir-disco.sh" ] && install -m 750 "$d/ws-expandir-disco.sh" "$WS_RAIZ/usr/local/lib/wellsystem/ws-expandir-disco.sh"
    install -m 750 "$d/WELLSYSTEM-MENU.sh" "$WS_RAIZ/usr/local/sbin/wellsystem"
    if [ -z "$WS_RAIZ" ] && ! command -v whiptail >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
        apt-get install -y whiptail >/dev/null 2>&1 || true   # caixas do menu; sem ele cai no modo texto
    fi

    # Reescreve o bloco (tira qualquer versão antiga dele e grava a atual).
    touch "$rc"
    sed -i '/^# WellSystem — menu de configuracao no login/,/^fi$/d' "$rc"
    cat >> "$rc" <<'BASHRC'
# WellSystem — menu de configuracao no login (remova este bloco para entrar direto no shell)
if [ -x /usr/local/sbin/wellsystem ] && [ -t 0 ] && [ -t 1 ] && [ -z "$SSH_ORIGINAL_COMMAND" ] && [ -z "$WS_MENU_OFF" ] && [ -z "$WS_MENU_ABERTO" ]; then
    case $- in *i*) export WS_MENU_ABERTO=1; /usr/local/sbin/wellsystem ;; esac
fi
BASHRC

    # O login do root lê o .bash_profile (se existir) ou o .profile — e só então o .bashrc. O .profile
    # padrão do Debian já chama o .bashrc; se alguém o trocou, garante a chamada.
    pf="$WS_RAIZ/root/.profile"; [ -f "$WS_RAIZ/root/.bash_profile" ] && pf="$WS_RAIZ/root/.bash_profile"
    if ! grep -qs 'bashrc' "$pf"; then
        printf '\n# WellSystem: carrega o .bashrc no login (abre o menu)\n[ -f ~/.bashrc ] && . ~/.bashrc\n' >> "$pf"
    fi
    echo '    menu de terminal instalado: abre sozinho no login do root (ou digite: wellsystem)'
}

# Garante a configuração do banco da instalação. Só age se ela estiver faltando ou inválida.
# Fontes, em ordem: espelhos que o próprio sistema grava (inclusive dentro do /tmp privado de um
# serviço ainda em execução, que só o root enxerga) e, no cenário servidor, a senha gerada pelo
# INSTALAR.sh. Nada é gravado sem antes TESTAR a conexão com o PHP.
ws_amb_restaurar_config_banco() {
    local d="$1" cenario="$2" dono="$3" cfg hash c
    cfg="$d/cache/wellsystem_db.json"
    command -v php >/dev/null 2>&1 || { echo '    (php de linha de comando ausente — configuracao do banco nao conferida)'; return 0; }

    _ws_cfg_ok() {   # $1 = arquivo json → 0 se tem credencial E conecta
        [ -s "$1" ] || return 1
        php -r '
            $c = json_decode((string)@file_get_contents($argv[1]), true);
            if (!is_array($c) || empty($c["host"]) || empty($c["user"])) exit(1);
            try { new PDO("mysql:host={$c["host"]};port=" . (int)($c["porta"] ?? 3306), $c["user"], (string)($c["pass"] ?? ""),
                          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5]); exit(0); }
            catch (Throwable $e) { exit(1); }' "$1" >/dev/null 2>&1
    }

    if _ws_cfg_ok "$cfg"; then echo '    configuracao do banco: ok'; return 0; fi

    hash="$(ws_amb_hash "$d")"
    mkdir -p "$d/cache"
    for c in "$WS_RAIZ/var/lib/wellsystem/wellsystem_db_${hash}.json" \
             "$WS_RAIZ/var/tmp/wellsystem_db_${hash}.json" \
             "$WS_RAIZ"/var/tmp/systemd-private-*/tmp/wellsystem_db_"${hash}".json \
             "$WS_RAIZ"/tmp/systemd-private-*/tmp/wellsystem_db_"${hash}".json \
             "$WS_RAIZ"/var/tmp/wellsystem_cache_"${hash}"/wellsystem_db.json \
             "$WS_RAIZ"/var/tmp/systemd-private-*/tmp/wellsystem_cache_"${hash}"/wellsystem_db.json; do
        [ -f "$c" ] || continue
        if _ws_cfg_ok "$c"; then
            install -o "${dono%%:*}" -g "${dono##*:}" -m 640 "$c" "$cfg" 2>/dev/null || cp -f "$c" "$cfg" || true
            echo "    configuracao do banco RESTAURADA a partir de: $c"
            return 0
        fi
    done

    if [ "$cenario" = "servidor" ] && [ -f "$WS_RAIZ/root/.wellsystem-instalacao" ]; then
        local DB_SENHA='' tmp
        DB_SENHA="$(grep -m1 '^DB_SENHA=' "$WS_RAIZ/root/.wellsystem-instalacao" | cut -d= -f2-)"
        if [ -n "$DB_SENHA" ]; then
            tmp="$(mktemp)"
            php -r '$c = ["host"=>"127.0.0.1","porta"=>3306,"user"=>"wellsystem","pass"=>$argv[1],"dbname"=>"wellsystem","radius_db"=>"radius"];
                    echo json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);' "$DB_SENHA" > "$tmp"
            if _ws_cfg_ok "$tmp"; then
                install -o "${dono%%:*}" -g "${dono##*:}" -m 640 "$tmp" "$cfg" 2>/dev/null || cp -f "$tmp" "$cfg" || true
                rm -f "$tmp"
                echo '    configuracao do banco RECRIADA a partir da senha guardada na instalacao (/root/.wellsystem-instalacao)'
                return 0
            fi
            rm -f "$tmp"
        fi
    fi
    echo '    AVISO: configuracao do banco nao encontrada em lugar nenhum — abra o sistema e informe na tela de instalacao.'
    return 0
}

# Espelho persistente da configuração do banco (/var/lib sobrevive a reboot e a PrivateTmp).
ws_amb_espelhar_config_banco() {
    local d="$1" dono="$2" hash
    [ -s "$d/cache/wellsystem_db.json" ] || return 0
    hash="$(ws_amb_hash "$d" || true)"; [ -n "$hash" ] || return 0
    mkdir -p "$WS_RAIZ/var/lib/wellsystem"
    chown "${dono%%:*}:${dono##*:}" "$WS_RAIZ/var/lib/wellsystem" 2>/dev/null || true; chmod 750 "$WS_RAIZ/var/lib/wellsystem" 2>/dev/null || true
    install -o "${dono%%:*}" -g "${dono##*:}" -m 640 "$d/cache/wellsystem_db.json" \
        "$WS_RAIZ/var/lib/wellsystem/wellsystem_db_${hash}.json" 2>/dev/null \
        || cp -f "$d/cache/wellsystem_db.json" "$WS_RAIZ/var/lib/wellsystem/wellsystem_db_${hash}.json" 2>/dev/null || true
    echo '    configuracao do banco espelhada em /var/lib/wellsystem (sobrevive ao reboot)'
}

# =================================================================================================
# BANCO — funções usadas pela instalação como ADDON (ws-instalar-addon.sh).
# =================================================================================================

# Cliente de linha de comando do banco (MariaDB novo tem "mariadb"; MK-Auth e MySQL, "mysql").
ws_amb_mysql_bin() { command -v mysql 2>/dev/null || command -v mariadb 2>/dev/null; }

# Comando de ADMINISTRADOR do banco, pronto para receber SQL pela entrada padrão.
# Ordem: WS_MYSQL_ADM (quem já sabe), a conta de manutenção do Debian/MK-Auth (debian.cnf — tem
# privilégio total e dispensa a senha do root do banco) e, por último, o root pelo socket do sistema.
# Só devolve um comando que CONECTOU de fato; vazio = nenhum funcionou.
ws_amb_mysql_admin() {
    local bin cand
    if [ -n "${WS_MYSQL_ADM:-}" ]; then echo "$WS_MYSQL_ADM"; return 0; fi
    bin="$(ws_amb_mysql_bin)"; [ -n "$bin" ] || return 0
    for cand in "$bin --defaults-file=$WS_RAIZ/etc/mysql/debian.cnf" "$bin -u root"; do
        case "$cand" in *debian.cnf) [ -f "$WS_RAIZ/etc/mysql/debian.cnf" ] || continue ;; esac
        if echo 'SELECT 1' | $cand >/dev/null 2>&1; then echo "$cand"; return 0; fi
    done
    return 0
}

# A conta abre o banco com esta senha? Testa pelos DOIS nomes da máquina — são contas diferentes.
ws_amb_testa_login() {  # $1=usuario $2=senha → 0 se entra por 127.0.0.1 E por localhost
    command -v php >/dev/null 2>&1 || return 1
    php -r '
        foreach (["127.0.0.1", "localhost"] as $h) {
            try { new PDO("mysql:host=$h", $argv[1], $argv[2], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5]); }
            catch (Throwable $e) { exit(1); }
        }
        exit(0);' "$1" "$2" >/dev/null 2>&1
}

# Senha que JÁ ESTÁ em uso para a instalação $1, se existir em algum lugar (config gravada ou
# espelho). Reinstalar não pode trocar a senha de um usuário que outra configuração ainda usa.
ws_amb_senha_existente() {
    local d="$1" hash c
    command -v php >/dev/null 2>&1 || return 0
    hash="$(ws_amb_hash "$d" 2>/dev/null || true)"
    for c in "$d/cache/wellsystem_db.json" \
             "$WS_RAIZ/var/lib/wellsystem/wellsystem_db_${hash}.json" \
             "$WS_RAIZ/var/tmp/wellsystem_db_${hash}.json" \
             "$WS_RAIZ/var/tmp/wellsystem_cache_${hash}/wellsystem_db.json"; do
        [ -s "$c" ] || continue
        php -r '$c = json_decode((string)@file_get_contents($argv[1]), true);
                if (is_array($c) && !empty($c["pass"])) { echo $c["pass"]; exit(0); } exit(1);' "$c" 2>/dev/null && return 0
    done
    return 0
}

# Pode o INSTALAR.sh (que monta o cenário SERVIDOR) rodar aqui? Vazio = pode; texto = o motivo
# pelo qual NÃO pode. $1 = pasta do pacote (ignorada na busca por instalações).
# O INSTALAR.sh instala Apache/MariaDB/FreeRADIUS, desliga o site padrão do Apache e reinicia o
# FreeRADIUS: num servidor que já é de outro sistema, isso tiraria esse sistema do ar.
ws_amb_bloqueio_instalar() {
    local pacote="${1:-}" s d c
    if ws_amb_dentro_container; then echo 'container'; return; fi
    if [ -d "$WS_RAIZ/opt/mk-auth" ]; then echo 'mkauth'; return; fi
    for d in $(ws_amb_instalacoes "$pacote"); do
        c="$(ws_amb_cenario "$d")"
        [ "$c" != "servidor" ] && { echo "wellsystem-$c:$d"; return; }
    done
    if [ -d "$WS_RAIZ/etc/apache2/sites-enabled" ]; then
        for s in "$WS_RAIZ"/etc/apache2/sites-enabled/*.conf; do
            [ -f "$s" ] || continue
            # Sites do próprio WellSystem não contam: wellsystem.conf (INSTALAR.sh),
            # wellsystem-le-ssl.conf (certbot, pela tela de HTTPS), wellsystem-ssl.conf (Docker).
            case "$(basename "$s")" in 000-default*.conf|default-ssl.conf|wellsystem*.conf) ;; *) echo "site:$(basename "$s")"; return ;; esac
        done
    fi
    if [ -d "$WS_RAIZ/var/www/html" ] && [ -n "$(find "$WS_RAIZ/var/www/html" -mindepth 1 -maxdepth 1 ! -name 'index.html' ! -name 'index.nginx-debian.html' 2>/dev/null | head -1)" ]; then
        echo 'conteudo:/var/www/html'; return
    fi
    return 0
}

# =================================================================================================
# AUTOTESTE — monta os quatro cenários numa árvore falsa e confere a detecção.
# =================================================================================================
ws_amb_selftest() {
    local base ok=0 falha=0 r
    base="$(mktemp -d)"
    t() { if [ "$2" = "$3" ]; then ok=$((ok+1)); echo "OK    | $1"; else falha=$((falha+1)); echo "FALHA | $1 (esperado '$3', veio '$2')"; fi; }
    faz_ws() { mkdir -p "$1/cache"; touch "$1/config.php" "$1/erp.php" "$1/radius_lib.php"; }

    # ---------- CENÁRIO 1: servidor direto, vhost próprio em /var/www/wellsystem ----------
    local S="$base/s1"
    faz_ws "$S/var/www/wellsystem"
    mkdir -p "$S/etc/apache2/sites-enabled" "$S/root" "$S/etc/cron.d"
    printf '<VirtualHost *:80>\n    DocumentRoot /var/www/wellsystem\n    <Directory /var/www/wellsystem>\n    </Directory>\n</VirtualHost>\n' > "$S/etc/apache2/sites-enabled/wellsystem.conf"
    echo 'DB_SENHA=abc' > "$S/root/.wellsystem-instalacao"
    faz_ws "$S/root/pacote/wellsystem"            # pacote largado em /root: NÃO é instalação
    faz_ws "$S/var/backups/wellsystem-versoes/x"  # versão guardada: NÃO é instalação
    r="$(WS_RAIZ="$S" ws_amb_instalacoes)"
    t 'servidor: acha 1 instalacao'                       "$(printf '%s\n' "$r" | grep -c .)" 1
    t 'servidor: acha /var/www/wellsystem'                "${r#$S}" /var/www/wellsystem
    t 'servidor: ignora o pacote em /root e os backups'   "$(printf '%s\n' "$r" | grep -cE 'pacote|backups')" 0
    t 'servidor: cenario = servidor'                      "$(WS_RAIZ="$S" ws_amb_cenario "$r")" servidor

    # ---------- CENÁRIO 2a: addon MK-Auth, publicado por Alias ----------
    local M="$base/mk"
    faz_ws "$M/opt/mk-auth/admin/addons/wellsystem"
    mkdir -p "$M/etc/apache2/conf-enabled" "$M/etc/apache2/sites-enabled"
    printf 'Alias /admin /opt/mk-auth/admin\nAlias /admin/addons /opt/mk-auth/admin/addons\n' > "$M/etc/apache2/conf-enabled/admin.conf"
    printf 'DocumentRoot /var/www/html\n' > "$M/etc/apache2/sites-enabled/000-default.conf"
    mkdir -p "$M/var/www/html"
    r="$(WS_RAIZ="$M" ws_amb_instalacoes)"
    t 'mkauth: acha o addon pelo Alias'                   "${r#$M}" /opt/mk-auth/admin/addons/wellsystem
    t 'mkauth: cenario = mkauth'                          "$(WS_RAIZ="$M" ws_amb_cenario "$r")" mkauth

    # ---------- CENÁRIO 2b: addon em outro ERP (subpasta de um site que não é nosso) ----------
    local E="$base/erp"
    faz_ws "$E/var/www/outroerp/modulos/wellsystem"
    mkdir -p "$E/etc/nginx/sites-enabled"
    printf 'server {\n    root /var/www/outroerp;\n}\n' > "$E/etc/nginx/sites-enabled/erp"
    r="$(WS_RAIZ="$E" ws_amb_instalacoes)"
    t 'outro ERP (nginx): acha o addon na subpasta'       "${r#$E}" /var/www/outroerp/modulos/wellsystem
    t 'outro ERP: cenario = addon'                        "$(WS_RAIZ="$E" ws_amb_cenario "$r")" addon

    # ---------- CENÁRIO 2c: Docker — nada publicado no host, container rodando ----------
    local D="$base/dk"; mkdir -p "$D/etc/apache2/sites-enabled"
    docker() { [ "$1" = "ps" ] && printf 'wellsystem-web-1|wellsystem-web:latest|/srv/wellsystem\nmariadb-1|mariadb:11|/srv/wellsystem\n'; }
    r="$(WS_RAIZ="$D" ws_amb_instalacoes)"
    t 'docker: nenhuma instalacao no host'                "$(printf '%s' "$r" | grep -c .)" 0
    t 'docker: acha o container do wellsystem'            "$(ws_amb_docker | cut -d'|' -f1)" wellsystem-web-1
    t 'docker: sabe a pasta do projeto'                   "$(ws_amb_docker | cut -d'|' -f2)" /srv/wellsystem
    t 'docker: ignora o container do banco'               "$(ws_amb_docker | grep -c mariadb)" 0
    unset -f docker

    # ---------- Formatos de configuração ----------
    t 'normaliza aspas e barra final'                     "$(ws_amb_normaliza '"/var/www/x/"')" /var/www/x
    t 'normaliza ponto-e-virgula do nginx'                "$(ws_amb_normaliza '/var/www/x;')" /var/www/x
    local C="$base/coment"; faz_ws "$C/var/www/velho"; mkdir -p "$C/etc/apache2/sites-enabled"
    printf '#DocumentRoot /var/www/velho\nDocumentRoot /var/www/novo\n' > "$C/etc/apache2/sites-enabled/a.conf"
    t 'linha comentada nao conta como publicada'          "$(WS_RAIZ="$C" ws_amb_raizes_publicadas | grep -c velho)" 0

    # ---------- Formas de configuração que já enganaram o parser ----------
    local F="$base/formas"; mkdir -p "$F/etc/nginx/sites-enabled" "$F/etc/apache2/sites-enabled"
    printf 'server { listen 80; root /srv/nginx-linha-unica; }\n' > "$F/etc/nginx/sites-enabled/um"
    printf 'DocumentRoot "/srv/com-aspas"   # comentario no fim da linha\n' > "$F/etc/apache2/sites-enabled/a.conf"
    printf 'location /x { alias /srv/nginx-alias/; }\n' > "$F/etc/nginx/sites-enabled/dois"
    printf 'User root\n' > "$F/etc/apache2/sites-enabled/b.conf"
    r="$(WS_RAIZ="$F" ws_amb_raizes_publicadas)"
    t 'nginx em linha unica'                              "$(printf '%s\n' "$r" | grep -c '/srv/nginx-linha-unica$')" 1
    t 'Apache com aspas e comentario no fim'              "$(printf '%s\n' "$r" | grep -c '/srv/com-aspas$')" 1
    t 'nginx alias dentro de location'                    "$(printf '%s\n' "$r" | grep -c '/srv/nginx-alias$')" 1
    t '"User root" nao vira pasta publicada'              "$(printf '%s\n' "$r" | grep -c 'root$')" 0

    # ---------- Pacote que está sendo publicado nunca é destino ----------
    local P="$base/pac"; faz_ws "$P/var/www/wellsystem"; mkdir -p "$P/etc/apache2/sites-enabled"
    printf 'DocumentRoot /var/www/wellsystem\n' > "$P/etc/apache2/sites-enabled/w.conf"
    t 'ignora a pasta de origem passada'                  "$(WS_RAIZ="$P" ws_amb_instalacoes "$P/var/www/wellsystem" | grep -c .)" 0

    # ---------- INSTALAR.sh: quando NÃO pode rodar (tiraria outro sistema do ar) ----------
    t 'instalar: servidor limpo pode'                     "$(WS_RAIZ="$base/limpo" ws_amb_bloqueio_instalar)" ''
    mkdir -p "$base/limpo2/var/www/html"; echo x > "$base/limpo2/var/www/html/index.html"
    t 'instalar: so a pagina padrao do Apache, pode'      "$(WS_RAIZ="$base/limpo2" ws_amb_bloqueio_instalar)" ''
    t 'instalar: servidor MK-Auth BLOQUEIA'               "$(WS_RAIZ="$M" ws_amb_bloqueio_instalar)" mkauth
    local E2="$base/erp2"; faz_ws "$E2/var/www/outroerp/modulos/wellsystem"; mkdir -p "$E2/etc/nginx/sites-enabled"
    printf 'server { root /var/www/outroerp; }\n' > "$E2/etc/nginx/sites-enabled/erp"
    t 'instalar: WellSystem ja addon de outro ERP BLOQUEIA' "$(WS_RAIZ="$E2" ws_amb_bloqueio_instalar | cut -d: -f1)" wellsystem-addon
    local O="$base/outro"; mkdir -p "$O/etc/apache2/sites-enabled"; echo 'DocumentRoot /srv/sgp' > "$O/etc/apache2/sites-enabled/sgp.conf"
    t 'instalar: outro site publicado BLOQUEIA'           "$(WS_RAIZ="$O" ws_amb_bloqueio_instalar)" site:sgp.conf
    local H="$base/html"; mkdir -p "$H/var/www/html"; echo x > "$H/var/www/html/index.php"
    t 'instalar: /var/www/html com sistema BLOQUEIA'      "$(WS_RAIZ="$H" ws_amb_bloqueio_instalar)" conteudo:/var/www/html
    # Rodar o INSTALAR.sh de novo no próprio servidor do WellSystem é seguro e documentado:
    local W="$base/reinst"; faz_ws "$W/var/www/wellsystem"; mkdir -p "$W/etc/apache2/sites-enabled"
    echo 'DocumentRoot /var/www/wellsystem' > "$W/etc/apache2/sites-enabled/wellsystem.conf"
    echo 'DocumentRoot /var/www/wellsystem' > "$W/etc/apache2/sites-enabled/wellsystem-le-ssl.conf"
    t 'instalar: reinstalar no servidor WellSystem (com HTTPS) pode' "$(WS_RAIZ="$W" ws_amb_bloqueio_instalar)" ''
    touch "$base/cont/.dockerenv" 2>/dev/null || { mkdir -p "$base/cont"; touch "$base/cont/.dockerenv"; }
    t 'instalar: dentro de container BLOQUEIA'            "$(WS_RAIZ="$base/cont" ws_amb_bloqueio_instalar)" container

    rm -rf "$base"
    echo; echo "== $ok OK, $falha FALHA(S) =="
    [ "$falha" = "0" ]
}

# Executado diretamente: só o autoteste. Incluído com "source": só as funções.
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    case "${1:-}" in
        --selftest) ws_amb_selftest; exit $? ;;
        *) echo 'Biblioteca de deteccao do WellSystem. Uso direto: bash ws-ambiente.sh --selftest'; exit 0 ;;
    esac
fi
