#!/bin/bash
# =================================================================================================
# WellSystem — cache e compressão dos arquivos estáticos, na CONFIGURAÇÃO DO APACHE.
#
#     ./ws-apache-desempenho.sh [/var/www/wellsystem]
#
# Chamado pelo INSTALAR.sh e pelo ATUALIZAR.sh. Pode ser rodado sozinho, quantas vezes quiser.
#
# POR QUE AQUI, E NÃO NUM .htaccess — onde isto esteve e de onde saiu:
# num .htaccess, "ExpiresActive", "Header" e "AddOutputFilterByType" só funcionam se o Apache do
# servidor permitir (AllowOverride). Onde a permissão é parcial — o painel de outro ERP, um addon
# hospedado dentro do MK-Auth — a diretiva não é ignorada: ela derruba o site INTEIRO com erro 500,
# e o <IfModule> em volta não protege, porque o módulo existe; o que falta é a permissão.
# Na configuração do servidor não existe esse risco, e ela só é escrita onde este script roda —
# ou seja, no servidor que o próprio instalador do WellSystem montou.
#
# POR QUE CACHE DE UM ANO É SEGURO: todo arquivo estático do sistema é referenciado com "?v=" de
# data+tamanho (ws_ver). Atualizar o arquivo muda o endereço, e endereço novo o navegador busca de
# novo — cache longo nunca entrega versão velha depois de uma atualização.
#
# REDE DE SEGURANÇA: depois de escrever, roda "apache2ctl configtest". Se a configuração não passar,
# a mudança é DESFEITA na hora e o Apache nem chega a ser recarregado com ela. O pior caso é ficar
# sem a otimização — nunca o site fora do ar.
# =================================================================================================

DESTINO="${1:-${WS_DESTINO:-/var/www/wellsystem}}"
CONF_NOME="wellsystem-desempenho"
CONF="/etc/apache2/conf-available/${CONF_NOME}.conf"

# Sem Apache do Debian (a2enconf/apache2ctl), não há o que fazer — e não é erro.
command -v apache2ctl >/dev/null 2>&1 || { echo "    (apache2ctl nao encontrado — cache de estaticos nao aplicado)"; exit 0; }
command -v a2enconf  >/dev/null 2>&1 || { echo "    (a2enconf nao encontrado — cache de estaticos nao aplicado)"; exit 0; }
[ -d "$DESTINO" ] || { echo "    (pasta $DESTINO nao existe — cache de estaticos nao aplicado)"; exit 0; }

a2enmod expires headers deflate >/dev/null 2>&1 || true

cat > "$CONF" <<APACHE
# Gerado por ws-apache-desempenho.sh — reescrito a cada atualizacao do WellSystem.
# Vale SO para a pasta do sistema; o resto do servidor nao e afetado.
<Directory "$DESTINO">
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css               "access plus 1 year"
        ExpiresByType application/javascript "access plus 1 year"
        ExpiresByType text/javascript        "access plus 1 year"
        ExpiresByType image/png              "access plus 1 year"
        ExpiresByType image/jpeg             "access plus 1 year"
        ExpiresByType image/gif              "access plus 1 year"
        ExpiresByType image/webp             "access plus 1 year"
        ExpiresByType image/svg+xml          "access plus 1 year"
        ExpiresByType image/x-icon           "access plus 1 year"
        ExpiresByType font/woff2             "access plus 1 year"
        ExpiresByType font/woff              "access plus 1 year"
    </IfModule>
    <IfModule mod_headers.c>
        <FilesMatch "\.(css|js|png|jpe?g|gif|webp|svg|ico|woff2?)$">
            Header set Cache-Control "public, max-age=31536000, immutable"
        </FilesMatch>
        # PDF gerado (boleto, recibo, relatorio) muda a cada emissao: nunca do cache.
        <FilesMatch "\.pdf$">
            Header set Cache-Control "private, no-cache, must-revalidate"
        </FilesMatch>
    </IfModule>
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css
        AddOutputFilterByType DEFLATE application/javascript text/javascript application/json image/svg+xml
    </IfModule>
    # Backup (.maz/.sql e backup do proprio sistema) de ate 4 GB na tela Importar/Backup. O php.ini do Debian vem com 2M.
    # Com mod_php o .user.ini da pasta e ignorado, por isso o limite mora aqui. So vale nesta pasta.
    <IfModule php_module>
        php_admin_value upload_max_filesize 4096M
        php_admin_value post_max_size 4200M
        php_admin_value max_input_time 3600
    </IfModule>
    <IfModule php7_module>
        php_admin_value upload_max_filesize 4096M
        php_admin_value post_max_size 4200M
        php_admin_value max_input_time 3600
    </IfModule>
    # Apache pode ter LimitRequestBody menor em outro lugar; 0 = sem limite no Apache (o limite real e o do PHP acima).
    LimitRequestBody 0
    # Sem listagem de pasta (antes /backups/, /cache/ e /uploads/ mostravam todos os nomes de arquivo).
    Options -Indexes
    # Backup, dump, chave e instalador nunca saem pela web.
    <FilesMatch "\.(sql|sql\.gz|sql\.xz|wsbk|bak|old|orig|swp|pfx|p12|pem|key|crt|log|sh|md|ps1)\$">
        Require all denied
    </FilesMatch>
    # Bibliotecas (*_lib.php, *.class.php) só são incluídas pelo PHP; ninguém precisa abri-las pela web.
    <FilesMatch "(_lib|\.class)\.php\$">
        Require all denied
    </FilesMatch>
</Directory>

# DADOS E CONFIGURACAO NAO SAEM PELA WEB (17/11/2026, teste de vulnerabilidade): /cache, /cache_trafego e /backups guardavam senha do banco,
# do SMTP, tokens e os backups e eram legiveis e listaveis pela internet. O PHP le essas pastas pelo disco (WS_CACHE/__DIR__) e os downloads
# passam por backup_download.php (readfile), entao negar a URL nao afeta o sistema. <DirectoryMatch> vale depois do <Directory> do site.
<DirectoryMatch "^$DESTINO/(cache|cache_trafego|backups|olt/cache|olt/cache_trafego)(/|\$)">
    Require all denied
</DirectoryMatch>

# CENTRAL DO ASSINANTE no endereco curto (18/11/2026): o link do site (https://assinante.../central) sempre respondeu 404; a central publica
# abre por central_pub.php (que escolhe a central ativa e leva ao portal do assinante). /central e /central/ passam a abrir a mesma coisa.
AliasMatch "^/central/?\$" "$DESTINO/central_pub.php"
APACHE

a2enconf "$CONF_NOME" >/dev/null 2>&1 || true

if apache2ctl configtest >/dev/null 2>&1; then
    echo "    cache, compressao, upload de ate 4 GB e bloqueio de cache/backups pela web ativos ($CONF)"
else
    # Não passou: desfaz ANTES de qualquer reload. O site segue exatamente como estava.
    a2disconf "$CONF_NOME" >/dev/null 2>&1 || true
    rm -f "$CONF"
    echo "    AVISO: a configuracao de cache nao passou no teste do Apache e foi desfeita (o site segue normal)."
    apache2ctl configtest 2>&1 | head -5 | sed 's/^/        /'
fi
exit 0
