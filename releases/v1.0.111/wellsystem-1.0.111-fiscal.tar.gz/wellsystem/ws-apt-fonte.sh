#!/bin/bash
# WellSystem — garante uma fonte ONLINE de pacotes do Debian (o instalador por ISO só deixa o CD/pool offline; sem isso o apt não acha certbot, docker, atualizações).
# Idempotente: se já existe fonte http(s) ativa, não mexe. Sem internet não faz mal: o apt apenas não atualiza.
[ -r /etc/os-release ] && . /etc/os-release
[ "${ID:-}" = "debian" ] || exit 0
CODE="${VERSION_CODENAME:-trixie}"
if grep -rhsE '^\s*(deb|Types:).*|^\s*URIs:\s*https?://' /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null | grep -qE '^\s*deb\s+(\[[^]]*\]\s*)?https?://|^\s*URIs:\s*https?://'; then exit 0; fi
cat > /etc/apt/sources.list.d/wellsystem-debian.list <<LIST
deb http://deb.debian.org/debian ${CODE} main
deb http://deb.debian.org/debian ${CODE}-updates main
deb http://security.debian.org/debian-security ${CODE}-security main
LIST
echo "fonte online do Debian adicionada (${CODE})"
