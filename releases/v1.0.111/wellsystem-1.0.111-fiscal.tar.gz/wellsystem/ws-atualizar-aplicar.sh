#!/bin/bash
# =================================================================================================
# WellSystem — aplica uma atualização JÁ BAIXADA E CONFERIDA (assinatura) pelo atualizar_run.php. Como root.
#
#     bash ws-atualizar-aplicar.sh <wellsystem-X.Y.Z.tar.gz> <X.Y.Z>     aplica
#     bash ws-atualizar-aplicar.sh --voltar                              volta à última cópia de segurança do código
#
# 1) copia de segurança do código atual (SEM cache/uploads/backups/cache_trafego) em /var/backups/wellsystem/codigo-<data>;
# 2) extrai o pacote e roda o ATUALIZAR.sh dele (que preserva os dados do servidor);
# 3) confere a sintaxe de todo .php e se a página responde; se algo falhar, restaura a cópia sozinho.
# Guarda só as 3 últimas cópias.
# =================================================================================================
set -u
DEST="${WS_DESTINO:-/var/www/wellsystem}"
BKP="/var/backups/wellsystem"
EXCL=(--exclude 'cache/' --exclude 'uploads/' --exclude 'backups/' --exclude 'cache_trafego/' --exclude 'assets/' --exclude 'Mkfiles/')
[ "$(id -u)" = "0" ] || { echo "precisa ser root" >&2; exit 1; }
mkdir -p "$BKP"

saude() {   # a página principal responde (200/302) e todo .php passa no php -l
    local c; c="$(curl -sk -o /dev/null -m 20 -w '%{http_code}' http://127.0.0.1/ 2>/dev/null)"
    case "$c" in 200|301|302|401|403) ;; *) echo "pagina nao respondeu (HTTP $c)"; return 1 ;; esac
    local f; for f in "$DEST"/*.php "$DEST"/api/*.php; do [ -f "$f" ] || continue; php -l "$f" >/dev/null 2>&1 || { echo "erro de sintaxe em $f"; return 1; }; done
    return 0
}
restaurar() {  # $1 = pasta da cópia
    rsync -a --delete "${EXCL[@]}" "$1"/ "$DEST"/ && chown -R www-data:www-data "$DEST" 2>/dev/null
}

if [ "${1:-}" = "--voltar" ]; then
    ULT="$(ls -1d "$BKP"/codigo-* 2>/dev/null | sort | tail -1)"
    [ -n "$ULT" ] || { echo "nao ha copia de seguranca"; exit 1; }
    restaurar "$ULT" || exit 1
    saude || { echo "a copia restaurada nao passou na conferencia"; exit 1; }
    rm -rf "$ULT"; echo "restaurado"; exit 0
fi

TAR="${1:-}"; VER="${2:-}"
[ -f "$TAR" ] && [[ "$VER" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "uso: ws-atualizar-aplicar.sh <pacote.tar.gz> <X.Y.Z>" >&2; exit 1; }

COPIA="$BKP/codigo-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$COPIA" && rsync -a "${EXCL[@]}" "$DEST"/ "$COPIA"/ || { echo "falhou a copia de seguranca"; exit 1; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
tar xzf "$TAR" -C "$TMP" || { echo "pacote ilegivel"; exit 1; }
PKG="$(find "$TMP" -maxdepth 2 -name ATUALIZAR.sh -printf '%h\n' | head -1)"
[ -n "$PKG" ] || { echo "pacote sem ATUALIZAR.sh"; exit 1; }
echo "$VER" > "$PKG/VERSAO"
( cd "$PKG" && WS_DESTINO="$DEST" bash ATUALIZAR.sh ) >"$TMP/atualizar.log" 2>&1
RC=$?
if [ "$RC" != 0 ] || ! MOTIVO="$(saude)"; then
    echo "${MOTIVO:-ATUALIZAR.sh falhou ($RC)}" >&2
    restaurar "$COPIA" && echo "voltou a versao anterior"
    rm -rf "$COPIA"   # a copia desta tentativa e igual ao que ficou: nao serve para o "voltar"
    exit 1
fi
ls -1d "$BKP"/codigo-* 2>/dev/null | sort | head -n -3 | xargs -r rm -rf
echo "ok $VER"
exit 0
