#!/bin/bash
# =================================================================================================
# WellSystem — emite/renova o certificado HTTPS dos domínios do provedor.
#
#     ws-certificado.sh <email> <dominio> [dominio2] [dominio3] ...
#
# É chamado pela tela "Domínio & HTTPS" do sistema (Manutenção), através do sudo — por isso ele
# vive fora da pasta web e só o root pode alterá-lo. O www-data pode EXECUTÁ-LO, e nada mais:
# a regra do sudoers autoriza este caminho exato, sem curinga.
#
# POR QUE UM SCRIPT, E NÃO O CERTBOT DIRETO PELO SUDO
# Autorizar o www-data a rodar "certbot" com argumentos livres seria entregar a ele qualquer
# operação do certbot — inclusive apontar o servidor web para outro lugar. Aqui os argumentos são
# validados antes de chegarem ao certbot, e a única coisa que ele consegue fazer é pedir
# certificado para domínios que apontam para esta máquina.
# =================================================================================================
set -e

EMAIL="$1"; shift || true
[ -n "$EMAIL" ] || { echo "ERRO: informe o e-mail para avisos da Let's Encrypt."; exit 1; }
[ $# -gt 0 ]    || { echo "ERRO: informe ao menos um domínio."; exit 1; }

# ---- validação dos domínios ---------------------------------------------------------------------
# Aceita apenas nome de domínio: letras, números, hífen e ponto. Isso é o que impede um argumento
# hostil de virar opção do certbot (algo como "--deploy-hook rm -rf /").
ARGS=""
for d in "$@"; do
    case "$d" in
        -*|*" "*|*";"*|*"&"*|*"|"*|*'$'*|*'`'*)
            echo "ERRO: domínio inválido: $d"; exit 1 ;;
    esac
    echo "$d" | grep -qE '^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$' || { echo "ERRO: domínio inválido: $d"; exit 1; }
    ARGS="$ARGS -d $d"
done

case "$EMAIL" in
    *@*.*) ;;
    *) echo "ERRO: e-mail inválido: $EMAIL"; exit 1 ;;
esac

# ---- o certbot precisa existir ------------------------------------------------------------------
if ! command -v certbot >/dev/null 2>&1; then
    echo "Instalando o certbot..."
    export DEBIAN_FRONTEND=noninteractive
    [ -f "$(dirname "$0")/ws-apt-fonte.sh" ] && bash "$(dirname "$0")/ws-apt-fonte.sh"
    apt-get update -qq && apt-get install -y -qq certbot python3-certbot-apache >/dev/null
fi

# ---- DNS antes de pedir ------------------------------------------------------------------------
# A Let's Encrypt valida TODOS os domínios num pedido só: um sem DNS (ou apontando para outro servidor)
# derruba o pedido inteiro. Mostra para onde cada um aponta e para já no que nem existe no DNS.
echo 'Para onde cada domínio aponta:'
SEM_DNS=""
for d in "$@"; do
    IPD=$(getent ahostsv4 "$d" 2>/dev/null | awk 'NR==1{print $1}')
    if [ -n "$IPD" ]; then echo "  $d -> $IPD"; else echo "  $d -> SEM DNS"; SEM_DNS="$SEM_DNS $d"; fi
done
echo ''
if [ -n "$SEM_DNS" ]; then
    echo "ERRO: sem registro no DNS:$SEM_DNS"
    echo 'Crie o registro (tipo A) apontando para o IP público deste servidor e peça de novo.'
    exit 1
fi

# ---- nomes no site do WellSystem -----------------------------------------------------------------
# O site criado pelo INSTALAR.sh não tem ServerName. Com domínio novo (ex.: financeiro, sem o erp), o
# certbot não achava em qual site instalar e, sem ninguém para responder, falhava. Aqui os domínios
# pedidos viram ServerName/ServerAlias do site do WellSystem (porta 80 e a cópia HTTPS do certbot).
# Backup antes; se o Apache não aceitar a configuração, volta como estava e para.
# os ATIVOS (sites-enabled), resolvidos até o arquivo real — link para sites-available ou arquivo direto
SITES=""
for f in /etc/apache2/sites-enabled/wellsystem.conf /etc/apache2/sites-enabled/wellsystem-le-ssl.conf; do
    [ -e "$f" ] && SITES="$SITES $(readlink -f "$f")"
done
BKPV="/var/backups/wellsystem-cert-$(date +%Y%m%d-%H%M%S)"
PRIMEIRO="$1"; shift_dom=("$@"); RESTO="${shift_dom[*]:1}"
MEXEU=""
for f in $SITES; do
    [ -f "$f" ] || continue
    mkdir -p "$BKPV"; cp -a "$f" "$BKPV/"
    awk -v SN="$PRIMEIRO" -v SA="$RESTO" '
        /^[[:space:]]*Server(Name|Alias)[[:space:]]/ { next }
        { print }
        /^[[:space:]]*<VirtualHost[[:space:]]/ { print "    ServerName " SN; if (SA != "") print "    ServerAlias " SA }
    ' "$BKPV/$(basename "$f")" > "$f"
    MEXEU="$MEXEU $f"
done
if [ -n "$MEXEU" ]; then
    if ! apache2ctl configtest >/dev/null 2>&1; then
        for f in $MEXEU; do cp -a "$BKPV/$(basename "$f")" "$f"; done
        echo "ERRO: o Apache não aceitou os nomes no site; configuração anterior restaurada (backup em $BKPV)."
        exit 1
    fi
    echo "Site do WellSystem atende: $*"
fi

echo "Pedindo certificado para:$ARGS"
echo ''

# --redirect: passa a mandar todo acesso HTTP para HTTPS, que é o que se quer num painel com senha.
# --keep-until-expiring: rodar de novo não gasta cota da Let's Encrypt à toa.
# --expand: ACRESCENTAR domínio a um certificado que já existe (ex.: já havia o do erp e agora entram
#   financeiro e assinantes). Sem ele o certbot, em modo não interativo, recusa o pedido (24/09/2026).
certbot --apache $ARGS \
        --email "$EMAIL" --agree-tos --no-eff-email \
        --redirect --keep-until-expiring --expand --non-interactive 2>&1

echo ''
echo 'Renovação automática: o certbot instala a própria tarefa no sistema e renova sozinho'
echo 'antes de vencer. Não há o que agendar.'
systemctl reload apache2 2>/dev/null || true
echo 'PRONTO'
