#!/bin/bash
# WellSystem — confere se a atualizacao subiu completa. SO LEITURA: nao altera nada.
# Uso: bash /var/www/wellsystem/ws-conferir.sh   (no MK-Auth: bash /opt/mk-auth/admin/addons/wellsystem/ws-conferir.sh)
D=/var/www/wellsystem
[ -f "$D/config.php" ] || D=/opt/mk-auth/admin/addons/wellsystem
MK=0; case "$D" in /opt/mk-auth/*) MK=1 ;; esac
OK=0; FALHA=0; AVISO=0
ok()    { OK=$((OK+1));       printf '  \033[32mOK\033[0m     %s\n' "$*"; }
nok()   { FALHA=$((FALHA+1)); printf '  \033[31mFALHA\033[0m  %s\n' "$*"; }
aviso() { AVISO=$((AVISO+1)); printf '  \033[33mAVISO\033[0m  %s\n' "$*"; }
info()  { printf '         %s\n' "$*"; }
tem()   { if grep -qF -- "$2" "$D/$1" 2>/dev/null; then ok "$3"; else nok "$3 (arquivo $1)"; fi; }
idade() { [ -e "$1" ] && echo $(( $(date +%s) - $(stat -c %Y "$1") )) || echo 999999; }

echo ""
echo "=== WellSystem em $D — $(date '+%d/%m/%Y %H:%M') ==="
[ -f "$D/config.php" ] || { nok "WellSystem nao encontrado"; exit 1; }

echo ""; echo "-- 1) Arquivos da versao nova"
[ -f "$D/olt_unificar.php" ] && ok "OLT: modulo unico (olt_unificar.php)" || nok "OLT: olt_unificar.php ausente"
tem olt/olt.php "../olt.php" "OLT: olt/olt.php redireciona para a raiz"
tem olt_huawei.php "olt_lock_dir" "OLT: trava do Telnet compartilhada entre tela e cron"
tem olt_huawei.php "'modo_sn'" "OLT: puxar modo Bridge/Router pela ficha"
tem olt_huawei.php "olt_rescan_marcar" "OLT: ONU aprovisionada entra na lista na hora"
tem olt_monitor.sh "rescan_pendente" "OLT: cron busca ONU nova a cada minuto"
tem radius_lib.php "ws_rad_disconnect_accel" "Derrubada confirmada no accel"
tem radius_lib.php "ws_rad_fechar_sessao_derrubada" "Sessao e IP nao ficam presos"
tem radius_lib.php "Ws-Sem-Atualizacao" "Sessao sem sinal fecha em 30 min"
tem radius_lib.php "round(\$k * 1.024)" "Velocidade do plano em mega fechado (50 Mega = 51200k)"
tem radius_lib.php "function ws_rad_vel_processar" "Velocidade nova aplicada em quem esta conectado, sem derrubar"
tem radius_lib.php "if (!empty(\$ct['bloqueio_manual'])) {" "Pagamento libera tambem o bloqueio manual"
tem radius_lib.php "const WS_RATE_BLOQUEIO = '10k/10k'" "Bloqueado autentica com 10k/10k"
tem radius_lib.php "return 1;   // padrão: 1 dia" "Confianca padrao de 1 dia"
tem config.php "function ws_venc_passado" "Boleto com vencimento passado recusado"
tem faturamento.php "ws_venc_passado" "Faturamento automatico nunca cria titulo vencido"
tem config.php "WS_COR_PADRAO" "Recursos: cor do sistema vale para todos"
tem config.php "registros_pagina']" "Recursos: registros por pagina"
tem config.php "wsGeocodificar" "Recursos: coordenadas OpenStreet/Google"
tem mapa.php "mapaGoogle" "Recursos: mapa dos clientes OpenStreet/Google"
[ -f "$D/conexoes_recentes.php" ] && ok "Tarja: conexoes recentes (backend)" || nok "Tarja: conexoes_recentes.php ausente"
tem status_topo.php "wsConexBtn" "Tarja: icone verde de quem voltou/caiu"
tem erp.php "wsInstBtn" "Lista de clientes: icone verde de instalados recentes"
tem radius_lib.php "function ws_rad_reavaliar_adicionais" "Regra de ouro: titular e adicionais bloqueiam/liberam juntos"
tem radius_lib.php "function ws_rad_deve_bloquear_proprio" "Regra de ouro: decisao central segue o titular"
tem branding.php "LOGO EM assets/ VAI PARA uploads/sistema/" "Logo protegida contra atualizacao"
tem ATUALIZAR.sh "--exclude 'assets/'" "Atualizacao nao apaga assets/"
tem mkauth_import.php "function mk_olt_sn_hex" "Cadastro segue a OLT: zona/modo/sinais (serial HWTC e hex)"
tem radius_sync.php "ws_contrato_sincronizar_olt" "Cadastro segue a OLT a cada 2 min"
tem olt_monitor.sh "smartolt_map" "Cron renova zona/modo do SmartOLT a cada 10 min"
[ -f "$D/comandos.php" ] && ok "Pagina Comandos WellSystem" || nok "Pagina Comandos WellSystem ausente"
[ -f "$D/diagnostico_olt.php" ] && ok "Pagina Diagnostico da OLT" || nok "Pagina Diagnostico da OLT ausente"
[ -f "$D/ws-radius-alias.sh" ] && ok "Nome IPoE: ws-radius-alias.sh" || nok "Nome IPoE: ws-radius-alias.sh ausente"
[ -f "$D/ws-radius-sessao-mac.sh" ] && ok "Sessao presa do mesmo MAC: ws-radius-sessao-mac.sh" || nok "ws-radius-sessao-mac.sh ausente"
[ -f "$D/ws-radius-log.sh" ] && ok "Log de autenticacao do RADIUS: ws-radius-log.sh" || nok "ws-radius-log.sh ausente"
tem faturamento.php "function ws_contratos_adicionais" "Recursos: auto lancamento para adicionais (padrao Nao)"
tem whatsapp.php "function ws_recibo_linhas" "Recibo padrao: impresso e WhatsApp com todos os campos"
tem whatsapp.php "function ws_resumo_pagamentos_texto" "Resumo de pagamentos no modelo do provedor"
tem importar.php "name=\"ramal_backup\"" "Migracao: backup por cidade/ramal"
tem mkauth_import.php "function ws_importar_zerar_onde" "Migracao: substituir so a cidade marcada"
[ -f "$D/img/wellsystem-logo-padrao.png" ] && ok "Logo padrao Wellsystem ERP" || nok "img/wellsystem-logo-padrao.png ausente"
tem marca_registro.php "WS_MARCA_SELO_SHA256" "Marca de registro: selo protegido e nome so com senha root do banco"
[ -f "$D/boleto_pdf.php" ] && ok "Boleto/carne em PDF no servidor (anexo das mensagens)" || nok "boleto_pdf.php ausente"
tem boleto_pdf.php "function ws_qr_matriz" "QR Code do PIX gerado no proprio servidor"
tem whatsapp.php "function ws_msg_cliente_permitido" "PROIBIDO mandar mensagem para cliente desativado/cancelado"
tem mensagens_lib.php "function ws_msg_eventos_estado_run" "Aviso de bloqueio e de ONLINE saem sozinhos"
tem mensagens_lib.php "function ws_msg_textos_antigos" "Modelos do provedor nas mensagens automaticas"
tem mensagens_lib.php "anexo'] ?? 'nao'" "Anexo automatico de boleto/carne em PDF nas mensagens"
tem recibo.php "tamsPrint" "Recibo impresso compacto (via de cupom)"
tem olt_monitor.sh "PESADO_MAX" "Monitor da OLT: prazo por etapa e varredura pesada com trava propria"
tem whatsapp.php "function ws_wa_janela_aberta" "API oficial da Meta: janela de 24h e template aprovado"
tem mensagens.php "meta_regras" "Templates da Meta editaveis na tela (nome pode mudar)"
tem config.php "function ws_fuso_detectar" "Relogio do PHP no fuso do servidor"
tem config.php "function ws_pagto_mesmo_dia" "Estorno: mesmo dia (root em qualquer dia)"
tem erp.php "a class=\"ws-badge-bol\"" "Numero de boletos abre a ficha na tarja dos titulos"
tem erp.php "ws_bol_form" "Caixa de gerar boleto reabre preenchida quando a data e recusada"
tem css/wellsystem.css "ws-bol-erro" "Aviso da caixa de boleto nitido e dentro dela"
tem olt_huawei.php "olt_scan_cursor" "OLT: varredura placa a placa, gravando a cada placa (rodizio)"
tem config.php "function ws_marcar_saida" "Atendente sai da lista de online ao deslogar"
tem config.php "function ws_sessao_trava_verificar" "Tela trava por inatividade e volta na mesma tela"
tem radius.php "function rad_nomes" "Rede: nome do cliente nas telas de sessao/consumo"
tem radius.php "function rad_js_selecao" "Rede: selecao (um/todos), por pagina e rodape"
tem config.php "function ws_ver_valores" "Totais do caixa so para nivel 3+ (atendimento nao ve)"
tem config.php "function ws_contrato_datar_cancelamentos" "Desativacao grava a data no contrato (relatorio verdadeiro)"
tem relatorios.php "function rel_base_lista" "Ativacao/Desativacao: card abre a lista por tras do numero"
tem config.php "function ws_pode_infra" "Concentradores/NAS/Diagnostico/Comandos so nivel 3 e root"
tem radius.php "ws_exigir_infra('radius.php?p=online')" "Cadastro de concentrador e NAS recusa nivel 1 e 2"
tem diag.php "ws_exigir_infra()" "Diagnostico do servidor recusa nivel 1 e 2"
tem comandos.php "ws_exigir_infra()" "Comandos do servidor recusam nivel 1 e 2"
tem diagnostico_olt.php "ws_exigir_infra()" "Diagnostico da OLT recusa nivel 1 e 2"
tem config.php "function ws_api_bloqueio_html" "Configuracao de API somente leitura para nivel 1 e 2"
tem financeiro.php "ws_api_exigir_edicao('financeiro.php?p=gateway')" "Gateway CelCoin/GalaxPay: nivel 1 e 2 nao gravam"
tem mensagens.php "ws_api_exigir_edicao('mensagens.php?t=servidor')" "Servidor de WhatsApp: nivel 1 e 2 nao gravam"
tem fiscal.php "ws_api_exigir_edicao('fiscal.php?p=emissor')" "Emissor de NFSe: nivel 1 e 2 nao gravam"
tem config.php "function ws_valor_txt" "Totais das faturas aparecem como ***** para nivel 1 e 2"
tem config.php "function ws_pode_cadastro_basico" "Cadastros (cidade/bairro/ramal/zona/equipamento) liberados"
tem config.php "function ws_pode_editar_preco" "Plano e conta/banco/PIX somente leitura no nivel 1 e 2"
tem erp.php "if (!ws_pode_editar_preco())" "Salvar plano recusa nivel 1 e 2"
tem erp.php "Conexao da OLT do ramal" "Conexao da OLT do ramal intocada por nivel 1 e 2"
tem erp.php "linha_digitavel" "Emissao no gateway grava a linha digitavel (chave certa)"
tem erp.php "a CelCoin recusou a emissão" "Falha do gateway aparece na tela em vez de sumir"
tem celcash.php "function ws_celcash_webhook_url" "URL do webhook da CelCoin editavel"
tem celcash.php "galax_id" "Credencial da migracao MK-Auth (galax_id) tambem e lida"
tem financeiro.php "testar_gateway" "Botao de testar a conexao com a CelCoin"
tem erp.php "Conta do Boleto" "Gerar boleto abre na conta salva no cadastro"
tem erp.php "ct.bloqueio_manual=1" "Alerta de bloqueio manual filtra a lista so nos clientes do alerta"
tem erp.php "tr.ws-pulse-alert" "Alerta rola ate o cliente e pulsa na linha"
tem relatorios.php "os gráficos abaixo continuam disponíveis" "Graficos do balancete visiveis para nivel 1 e 2"

echo ""; echo "-- 2) PHP sem erro de sintaxe e scripts sem \\r do Windows"
ERRS=""; N=0
for f in "$D"/*.php "$D"/olt/*.php; do
  N=$((N+1)); php -l "$f" >/dev/null 2>&1 || ERRS="$ERRS $(basename "$f")"
done
[ -z "$ERRS" ] && ok "$N arquivos PHP sem erro de sintaxe" || nok "erro de sintaxe em:$ERRS"
CRLF=""; for s in "$D"/*.sh "$D"/olt/*.sh; do [ -f "$s" ] && grep -q $'\r' "$s" && CRLF="$CRLF $(basename "$s")"; done
[ -z "$CRLF" ] && ok "scripts .sh sem \\r" || nok "scripts com \\r:$CRLF"
[ -x "$D/olt_monitor.sh" ] && ok "olt_monitor.sh executavel" || nok "olt_monitor.sh sem permissao de execucao"

echo ""; echo "-- 3) OLT (dados e funcionamento)"
C="$D/cache_trafego"
if [ -f "$C/.unificado_olt" ]; then ok "dados da OLT unificados: $(cat "$C/.unificado_olt")"
elif [ -d "$D/olt/cache_trafego" ] && [ -n "$(ls -A "$D/olt/cache_trafego" 2>/dev/null)" ]; then aviso "dados antigos em olt/cache_trafego ainda nao unificados (acontece na 1a abertura da OLT ou no cron do proximo minuto)"
else ok "sem dados antigos em olt/ para unificar"; fi
if grep -q '"ip":"[^"]' "$C/olt_conexao.json" 2>/dev/null; then ok "conexao da OLT configurada ($(grep -o '"ip":"[^"]*"' "$C/olt_conexao.json" | head -1))"
else nok "conexao da OLT nao encontrada em cache_trafego (Aprovisionamento nao coleta sem ela)"; fi
A=$(idade "$C/olt_autofind.json"); [ "$A" -lt 300 ] && ok "busca de ONUs novas atualizada ha ${A}s" || aviso "busca de ONUs novas sem atualizar ha ${A}s (cron roda a cada minuto)"
A=$(idade "$C/olt_onus_cache.json"); [ "$A" -lt 900 ] && ok "lista de ONUs atualizada ha ${A}s" || aviso "lista de ONUs sem atualizar ha ${A}s (lista completa a cada 4 min)"
A=$(idade /tmp/olt_scan_count); [ "$A" -lt 240 ] && ok "monitor da OLT rodou ha ${A}s" || aviso "monitor da OLT sem rodar ha ${A}s"
# O ULTIMO CICLO, com o tempo de cada etapa: e o que explica um aviso acima sem ninguem adivinhar
# (varredura pesada demorada, etapa que estourou o prazo, ciclo pulado por outro em andamento).
[ -f "$C/olt_monitor_status.txt" ] && info "ultimo ciclo do monitor: $(cat "$C/olt_monitor_status.txt")"
if [ -f "$C/olt_monitor.log" ]; then
  PUL=$(tail -n 60 "$C/olt_monitor.log" | grep -c 'pulado:')
  EST=$(tail -n 60 "$C/olt_monitor.log" | grep -c 'ESTOUROU')
  [ "$PUL" -gt 0 ] && info "ciclos pulados nos ultimos 60 registros: $PUL (ciclo anterior ainda rodando)"
  [ "$EST" -gt 0 ] && aviso "etapas que estouraram o prazo nos ultimos 60 registros: $EST (veja cache_trafego/olt_monitor.log)"
fi
PEND=$(ps -eo pid,etimes,args 2>/dev/null | grep 'olt_huawei.php' | grep -v grep | awk '$2 > 720 {n++} END {print n+0}')
[ "$PEND" -gt 0 ] && aviso "$PEND processo(s) da OLT rodando ha mais de 12 min (o monitor encerra sozinho no proximo ciclo)" || ok "nenhum processo da OLT pendurado"
ls "$C"/olt_telnet_*.lock >/dev/null 2>&1 && ok "trava do Telnet em uso na pasta compartilhada" || info "(trava do Telnet ainda nao criada — nasce na 1a consulta a OLT)"

# RELOGIO: PHP e banco no MESMO fuso. Diferente, o dia "de hoje" muda de um lado e nao do outro —
# boleto abre com a data de amanha, caixa do dia nao fecha e o estorno do mesmo dia e recusado.
PHPDT=$(php -r 'require "/var/www/wellsystem/config.php"; echo date("Y-m-d H:i:s"), "|", date_default_timezone_get();' 2>/dev/null)
[ -z "$PHPDT" ] && PHPDT=$(php -r 'require "'"$D"'/config.php"; echo date("Y-m-d H:i:s"), "|", date_default_timezone_get();' 2>/dev/null)
PHPHORA=${PHPDT%%|*}; PHPTZ=${PHPDT##*|}
BANCOHORA=$(php -r 'require "'"$D"'/config.php"; try { echo ws_db()->query("SELECT NOW()")->fetchColumn(); } catch (Throwable $e) {}' 2>/dev/null)
if [ -n "$PHPHORA" ] && [ -n "$BANCOHORA" ]; then
  DIF=$(( $(date -d "$PHPHORA" +%s 2>/dev/null || echo 0) - $(date -d "$BANCOHORA" +%s 2>/dev/null || echo 0) ))
  DIF=${DIF#-}
  if [ "$DIF" -le 120 ]; then ok "relogio do PHP e do banco iguais (fuso $PHPTZ)"
  else nok "PHP ($PHPHORA, $PHPTZ) e banco ($BANCOHORA) com $DIF s de diferenca — boleto/caixa/estorno do dia saem errados"; fi
fi

echo ""; echo "-- 4) Tarefas automaticas"
CR=/etc/cron.d/wellsystem
if [ "$MK" = 1 ]; then info "(addon MK-Auth: cron do servidor e do MK-Auth)"
else
  grep -q "olt_monitor.sh scan" "$CR" 2>/dev/null && ok "cron da OLT instalado" || nok "cron da OLT ausente em $CR"
  grep -q "radius_sync.php" "$CR" 2>/dev/null && ok "cron do RADIUS instalado" || nok "cron do RADIUS ausente em $CR"
  systemctl is-active --quiet cron && ok "servico cron ativo" || nok "servico cron parado"
  A=$(idade "$D/cache/internet.json"); [ "$A" -lt 300 ] && ok "sincronismo do RADIUS rodou ha ${A}s" || aviso "sincronismo do RADIUS sem rodar ha ${A}s (roda a cada 2 min)"
fi

echo ""; echo "-- 5) FreeRADIUS e banco"
FR=/etc/freeradius/3.0
if [ "$MK" = 1 ]; then info "(addon MK-Auth: o FreeRADIUS e do MK-Auth e nao e alterado)"
elif [ -f "$FR/radiusd.conf" ]; then
  SITE=$(readlink -f "$FR/sites-enabled/default")
  grep -q '# >>> WellSystem-IPoE-Alias' "$SITE" && ok "regra do nome IPoE instalada (versao atual)" || nok "regra do nome IPoE ausente ou antiga"
  grep -q '# >>> WellSystem-Sessao-MAC' "$SITE" && ok "regra da sessao presa do mesmo MAC instalada (reconexao nao e recusada)" || nok "regra da sessao presa do mesmo MAC ausente (rode: bash $D/ws-radius-sessao-mac.sh)"
  grep -q 'ws_contrato ct JOIN' "$SITE" && grep -q 'wellsystem.ws_contrato\|[a-z_]*\.ws_contrato ct' "$SITE" && ok "consulta do nome IPoE com o nome do banco" || nok "consulta do nome IPoE sem o nome do banco"
  awk '/^log[[:space:]]*\{/{d=1} d&&/^\}/{d=0} d&&/^[[:space:]]*auth[[:space:]]*=[[:space:]]*yes/{f=1} END{exit !f}' "$(readlink -f "$FR/radiusd.conf")" && ok "log de autenticacao do FreeRADIUS ligado" || nok "log de autenticacao do FreeRADIUS desligado (rode: bash $D/ws-radius-log.sh)"
  freeradius -CX >/dev/null 2>&1 && ok "configuracao do FreeRADIUS valida" || nok "configuracao do FreeRADIUS com erro (rode: freeradius -CX)"
  systemctl is-active --quiet freeradius && ok "FreeRADIUS no ar" || nok "FreeRADIUS parado"
  RDB=$(awk -F'"' '/^[[:space:]]*radius_db[[:space:]]*=/{print $2; exit}' "$(readlink -f "$FR/mods-enabled/sql")")
  RDB=${RDB:-radius}
  V=$(mysql -N -B -e "SELECT CONCAT(groupname,'=',value) FROM \`$RDB\`.radgroupreply WHERE attribute='Mikrotik-Rate-Limit' AND groupname LIKE 'plano_%' ORDER BY groupname LIMIT 4" 2>/dev/null | tr '\n' ' ')
  if [ -z "$V" ]; then aviso "nao consegui ler as velocidades dos planos no banco $RDB"
  else
    RUIM=""; for n in $(echo "$V" | grep -o '=[0-9]*k/[0-9]*k' | grep -o '[0-9]\+'); do [ $((n % 1024)) -eq 0 ] || RUIM=1; done
    if echo "$V" | grep -q '=[0-9]*k/[0-9]*k' && [ -z "$RUIM" ]; then ok "velocidade dos planos em mega fechado: $V"
    else aviso "planos ainda no formato antigo (atualiza no proximo sincronismo, ate 2 min): $V"; fi
  fi
  VB=$(mysql -N -B -e "SELECT value FROM \`$RDB\`.radgroupreply WHERE groupname='bloqueado' AND attribute='Mikrotik-Rate-Limit'" 2>/dev/null)
  [ "$VB" = "10k/10k" ] && ok "grupo de bloqueio com 10k/10k" || aviso "grupo de bloqueio ainda sem 10k/10k (ajusta no proximo sincronismo): ${VB:-vazio}"
  F="$D/cache/velocidade_pendente.json"; if [ -s "$F" ]; then info "velocidade nova na fila para sessoes conectadas: $(grep -o '"n"' "$F" | wc -l) sessao(oes) (aplica em lotes a cada 2 min)"; else ok "nenhuma sessao aguardando velocidade nova"; fi
  P=$(mysql -N -B -e "SELECT COUNT(*) FROM \`$RDB\`.radacct WHERE acctstoptime IS NULL AND acctupdatetime > acctstarttime AND acctupdatetime < NOW() - INTERVAL 45 MINUTE" 2>/dev/null)
  [ "${P:-0}" = "0" ] && ok "nenhuma sessao presa sem sinal" || aviso "$P sessao(oes) sem sinal ha mais de 45 min (fecham no proximo sincronismo)"
  A=$(mysql -N -B -e "SELECT COUNT(*) FROM \`$RDB\`.radacct WHERE acctstoptime IS NULL" 2>/dev/null); info "sessoes abertas agora: ${A:-?}"
  # Sessao presa do mesmo equipamento: duas linhas abertas do mesmo login E mesmo MAC.
  PRESAS=$(mysql -N -B -e "SELECT COUNT(*) FROM (SELECT username FROM \`$RDB\`.radacct WHERE acctstoptime IS NULL AND callingstationid<>'' GROUP BY username, callingstationid HAVING COUNT(*)>1) x" 2>/dev/null)
  if [ -n "$PRESAS" ]; then [ "$PRESAS" = "0" ] && ok "nenhuma sessao presa do mesmo equipamento" || aviso "$PRESAS cliente(s) com sessao presa do mesmo MAC (fecha na proxima passada do cron)"; fi
else info "(sem FreeRADIUS neste servidor)"; fi
grep -o '"dias_[a-z]*":[0-9]*' "$D/cache/cobranca.json" 2>/dev/null | tr '\n' ' ' | sed 's/^/         regras de cobranca: /'; echo ""

echo ""; echo "-- 6) Paginas respondendo (Apache + PHP)"
BASE=http://127.0.0.1; [ "$MK" = 1 ] && BASE=http://127.0.0.1/admin/addons/wellsystem
for p in erp.php olt.php olt_erp.php mapa.php provedor.php; do
  c=$(curl -sk -o /tmp/ws-conf-body -w '%{http_code}' --max-time 15 "$BASE/$p")
  if grep -qi 'fatal error\|parse error' /tmp/ws-conf-body 2>/dev/null; then nok "$p com erro PHP"
  elif echo "$c" | grep -q '^\(200\|301\|302\|303\|401\)$'; then ok "$p responde (HTTP $c)"
  else nok "$p HTTP $c"; fi
done
curl -sk --max-time 15 "$BASE/conexoes_recentes.php" | grep -q 'status' && ok "conexoes_recentes.php responde (pede login, correto)" || nok "conexoes_recentes.php sem resposta"
curl -skI --max-time 15 "$BASE/olt/olt.php" | grep -qi 'location:.*\.\./olt\.php' && ok "link antigo olt/olt.php leva para a Gerencia unificada" || aviso "olt/olt.php nao redirecionou (confira abrindo no navegador)"
rm -f /tmp/ws-conf-body
L=$(grep -h "PHP Fatal" /var/log/apache2/*error*.log 2>/dev/null | grep "$(LC_ALL=C date '+%a %b %d')" | tail -3)
[ -z "$L" ] && ok "nenhum erro fatal de PHP hoje no log do Apache" || { nok "erros fatais de PHP hoje:"; echo "$L" | sed 's/^/         /'; }

if [ "$MK" = 0 ] && [ -f "$D/ws-radius-alias.sh" ]; then
  echo ""; echo "-- 7) Nome IPoE (teste real, sem derrubar ninguem)"
  bash "$D/ws-radius-alias.sh" --pasta "$D" --testar 49544253cf94abe0
fi

echo ""
printf '=== RESULTADO: \033[32m%s ok\033[0m, \033[31m%s falha(s)\033[0m, \033[33m%s aviso(s)\033[0m ===\n\n' "$OK" "$FALHA" "$AVISO"
