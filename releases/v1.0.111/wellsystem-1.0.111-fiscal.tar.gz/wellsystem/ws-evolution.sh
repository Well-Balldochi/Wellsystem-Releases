#!/bin/bash
# =================================================================================================
# WellSystem — PONTE DE WHATSAPP (Evolution API) instalada JUNTO com o sistema.
#
#     sudo bash ws-evolution.sh
#
# Para o provedor que NÃO tem uma Evolution: sobe a Evolution API v2 (com PostgreSQL e Redis) em containers,
# só neste servidor (porta 8080 no 127.0.0.1 — não fica exposta na internet) e já deixa o WellSystem apontando para ela.
# Na tela Atendimento aparece o QR code para escanear — sem terminal, sem configurar nada.
# Quem já tem a SUA Evolution não precisa disto: é só informar o endereço e a chave na tela Atendimento.
#
# Idempotente: rodar de novo não troca senha nem chave já geradas. Falha aqui NÃO derruba a instalação do sistema.
# =================================================================================================
DIR="/opt/wellsystem-evolution"
ARQ_SENHAS="/root/.wellsystem-instalacao"
IMG_EVO="${WS_EVO_IMAGEM:-evoapicloud/evolution-api:v2.3.7}"
PORTA="${WS_EVO_PORTA:-8080}"

[ "$(id -u)" = "0" ] || { echo "ERRO: rode como root" >&2; exit 1; }
echo '==> ponte de WhatsApp (Evolution API)'

# ---- 1) Docker ----------------------------------------------------------------------------------
if ! command -v docker >/dev/null 2>&1; then
    echo '    instalando o Docker...'
    export DEBIAN_FRONTEND=noninteractive
    [ -f /usr/local/sbin/ws-apt-fonte.sh ] && bash /usr/local/sbin/ws-apt-fonte.sh; apt-get update -qq >/dev/null 2>&1
    apt-get install -y -qq docker.io docker-compose >/dev/null 2>&1 || { echo '    AVISO: não consegui instalar o Docker; a ponte de WhatsApp fica para depois.'; exit 0; }
fi
systemctl enable --now docker >/dev/null 2>&1 || true
COMPOSE="docker-compose"; docker compose version >/dev/null 2>&1 && COMPOSE="docker compose"

# ---- 2) chaves (geradas uma vez) -----------------------------------------------------------------
[ -f "$ARQ_SENHAS" ] || { touch "$ARQ_SENHAS"; chmod 600 "$ARQ_SENHAS"; }
. "$ARQ_SENHAS"
if [ -z "${EVO_CHAVE:-}" ]; then
    EVO_CHAVE="$(openssl rand -hex 24)"; EVO_PG_SENHA="$(openssl rand -hex 12)"
    printf 'EVO_CHAVE=%s\nEVO_PG_SENHA=%s\n' "$EVO_CHAVE" "$EVO_PG_SENHA" >> "$ARQ_SENHAS"
fi

# ---- 3) containers ---------------------------------------------------------------------------------
mkdir -p "$DIR"
cat > "$DIR/docker-compose.yml" <<EOF
version: "3.3"
services:
  evolution:
    image: ${IMG_EVO}
    restart: always
    depends_on: [postgres, redis]
    ports: ["127.0.0.1:${PORTA}:8080"]
    environment:
      SERVER_URL: "http://127.0.0.1:${PORTA}"
      AUTHENTICATION_API_KEY: "${EVO_CHAVE}"
      DATABASE_PROVIDER: postgresql
      DATABASE_CONNECTION_URI: "postgresql://evolution:${EVO_PG_SENHA}@postgres:5432/evolution?schema=public"
      DATABASE_SAVE_DATA_INSTANCE: "true"
      DATABASE_SAVE_DATA_NEW_MESSAGE: "true"
      DATABASE_SAVE_MESSAGE_UPDATE: "true"
      DATABASE_SAVE_DATA_CONTACTS: "true"
      DATABASE_SAVE_DATA_CHATS: "true"
      CACHE_REDIS_ENABLED: "true"
      CACHE_REDIS_URI: "redis://redis:6379/6"
      CACHE_REDIS_PREFIX_KEY: evolution
      CACHE_LOCAL_ENABLED: "false"
      LANGUAGE: pt-BR
    volumes: ["evolution_instances:/evolution/instances"]
  postgres:
    image: postgres:15
    restart: always
    environment: {POSTGRES_USER: evolution, POSTGRES_PASSWORD: "${EVO_PG_SENHA}", POSTGRES_DB: evolution}
    volumes: ["evolution_pg:/var/lib/postgresql/data"]
  redis:
    image: redis:7-alpine
    restart: always
    command: redis-server --save 60 1 --loglevel warning
    volumes: ["evolution_redis:/data"]
volumes: {evolution_instances: {}, evolution_pg: {}, evolution_redis: {}}
EOF
chmod 600 "$DIR/docker-compose.yml"
echo '    baixando e iniciando os containers (alguns minutos na primeira vez)...'
( cd "$DIR" && yes | $COMPOSE up -d ) >/var/log/wellsystem-evolution.log 2>&1 || { echo '    AVISO: os containers não subiram (veja /var/log/wellsystem-evolution.log). O sistema segue sem a ponte.'; exit 0; }

# ---- 4) espera responder -------------------------------------------------------------------------
OK=0
for i in $(seq 1 60); do
    curl -s -m 5 -o /dev/null "http://127.0.0.1:${PORTA}/" && { OK=1; break; }
    sleep 5
done
[ "$OK" = 1 ] || { echo '    AVISO: a Evolution ainda não respondeu; ela continua iniciando em segundo plano.'; }

# ---- 5) deixa o WellSystem apontando para ela (só se ainda não há Evolution configurada) ------------------
DEST="${WS_DESTINO:-/var/www/wellsystem}"
if [ -f "$DEST/config.php" ] && command -v php >/dev/null 2>&1; then
    WS_DESTINO="$DEST" EVO_URL="http://127.0.0.1:${PORTA}" EVO_KEY="$EVO_CHAVE" php -r '
        chdir(getenv("WS_DESTINO") ?: "/var/www/wellsystem");
        require "config.php"; require_once "whatsapp.php";
        $c = ws_wa_config();
        if (trim((string)($c["url"] ?? "")) === "") { ws_wa_salvar(["gateway" => "evolution", "url" => getenv("EVO_URL"), "apikey" => getenv("EVO_KEY")]); echo "    WellSystem apontado para a ponte de WhatsApp deste servidor.\n"; }
        else echo "    WellSystem já tinha uma Evolution configurada; mantida.\n";
    ' 2>&1 | tail -2
    chown -R www-data:www-data "$DEST/cache" 2>/dev/null || true
fi
echo '    ponte de WhatsApp pronta (QR code na tela Atendimento).'
exit 0
