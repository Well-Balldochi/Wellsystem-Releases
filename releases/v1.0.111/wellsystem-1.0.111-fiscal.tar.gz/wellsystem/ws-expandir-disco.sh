#!/bin/bash
# =================================================================================================
# WellSystem — usa o espaço novo depois de AUMENTAR O DISCO da máquina virtual.
#
#     bash ws-expandir-disco.sh                mostra o plano, pede confirmação e aplica
#     WS_SIMULAR=1 bash ws-expandir-disco.sh   só mostra o plano (não muda nada)
#     WS_SIM=1 bash ws-expandir-disco.sh       aplica sem perguntar (o menu já perguntou)
#
# No menu do terminal: opção "Uso dos discos / expandir disco".
#
# POR QUE O ESPAÇO NÃO APARECE SOZINHO: aumentar o disco no Proxmox/VMware/Hyper-V/VirtualBox só
# aumenta o "disco". A PARTIÇÃO, o LVM (se houver) e o SISTEMA DE ARQUIVOS continuam do tamanho
# antigo até alguém esticar cada camada, nesta ordem:
#
#   1. o Linux reler o tamanho do disco            (rescan do barramento)
#   2. esticar a partição até o fim do disco       (sfdisk)
#   3. LVM: esticar o volume físico e o lógico     (pvresize + lvextend)
#   4. esticar o sistema de arquivos               (resize2fs / xfs_growfs / btrfs)
#
# Tudo com o sistema NO AR, sem reiniciar e sem mexer nos dados.
#
# O CASO MAIS COMUM QUE TRAVA: o instalador do Debian (e ISOs baseadas nele) cria a partição do
# sistema e, LOGO DEPOIS dela, a partição de SWAP. O espaço novo fica depois da swap, e a partição
# do sistema não tem como crescer "pulando" a swap. Nesse caso — e SÓ quando o que está no caminho é
# swap — o script oferece trocar a partição de swap por um ARQUIVO de swap do mesmo tamanho
# (/swapfile, funciona igual), liberando o caminho. Se houver qualquer outra coisa no caminho (outra
# partição com dados), ele PARA e explica — nunca apaga partição com dados.
#
# REDE DE SEGURANÇA: antes de mexer, a tabela de partições é salva em /root/ws-particoes-*.txt
# (restaurável com: sfdisk /dev/DISCO < arquivo) e o /etc/fstab ganha cópia .ws-AAAAMMDD-HHMMSS.
# =================================================================================================

WS_SIMULAR="${WS_SIMULAR:-0}"
WS_SIM="${WS_SIM:-0}"
XD_SYS="${XD_SYS:-/sys}"   # trocável só para teste
WS_CARIMBO="$(date +%Y%m%d-%H%M%S)"

xd_log()    { echo "    $*"; }
xd_titulo() { echo "==> $*"; }
xd_rodar() {   # executa (ou só mostra, em simulação)
    if [ "$WS_SIMULAR" = "1" ]; then echo "    [simulação] $*"; return 0; fi
    echo "    + $*"; "$@"
}

# ---- leitura da tabela de partições (sfdisk -d) --------------------------------------------------
# Saída: uma linha por partição → "NUMERO START SIZE TIPO"
xd_particoes() {
    sfdisk -d "$1" 2>/dev/null | awk '
        /^\/dev\// {
            nome=$1; sub(/:$/, "", nome); n=nome; sub(/.*[^0-9]/, "", n)
            st=""; sz=""; ty=""
            if (match($0, /start= *[0-9]+/)) { st=substr($0, RSTART, RLENGTH); gsub(/[^0-9]/, "", st) }
            if (match($0, /size= *[0-9]+/))  { sz=substr($0, RSTART, RLENGTH); gsub(/[^0-9]/, "", sz) }
            if (match($0, /type= *[0-9A-Fa-f-]+/)) { ty=substr($0, RSTART, RLENGTH); sub(/type= */, "", ty) }
            print n, st, sz, toupper(ty)
        }'
}
xd_rotulo() { sfdisk -d "$1" 2>/dev/null | awk -F': *' '/^label:/{print $2; exit}'; }
xd_setores_disco() {   # tamanho do disco em setores lógicos
    local b ss; b="$(blockdev --getsize64 "$1" 2>/dev/null)"; ss="$(blockdev --getss "$1" 2>/dev/null)"
    [ -n "$b" ] && [ -n "$ss" ] && [ "$ss" -gt 0 ] && echo $(( b / ss ))
}
xd_eh_extendida() { case "$1" in 5|F|85) return 0 ;; esac; return 1; }
xd_eh_swap()      { case "$1" in 82|0657FD6D-A4AB-43C4-84E5-0933C84B4F4F) return 0 ;; esac; return 1; }
xd_dev_particao() {   # disco + número → /dev/sda1, /dev/nvme0n1p1, /dev/mmcblk0p1
    case "$1" in *[0-9]) echo "${1}p$2" ;; *) echo "$1$2" ;; esac
}

# ---- análise: quanto a partição pode crescer e o que está no caminho ------------------------------
# Define: XD_LIVRE      setores livres logo depois da partição (até o próximo obstáculo)
#         XD_LIVRE_FIM  setores até o fim do disco (se o caminho fosse liberado)
#         XD_CONTAINER  nº da partição estendida que contém a partição (MBR), ou vazio
#         XD_BLOQ_SWAP  nºs das partições de swap (e estendidas) no caminho
#         XD_BLOQ_OUTRAS nºs das partições com dados no caminho
xd_analisar() {
    local disco="$1" num="$2" rot total fim lim tabela
    XD_LIVRE=0; XD_LIVRE_FIM=0; XD_NOVO=0; XD_MIN=131072; XD_CONTAINER=""; XD_BLOQ_SWAP=""; XD_BLOQ_OUTRAS=""
    rot="$(xd_rotulo "$disco")"; total="$(xd_setores_disco "$disco")"
    [ -n "$total" ] || return 1
    fim="$total"; [ "$rot" = "gpt" ] && fim=$(( total - 34 ))
    tabela="$(xd_particoes "$disco")"

    local st="" sz="" ty="" _n
    read -r _n st sz ty <<EOF
$(echo "$tabela" | awk -v n="$num" '$1==n')
EOF
    [ -n "$st" ] && [ -n "$sz" ] || return 1
    local tfim=$(( st + sz ))

    local n2 s2 z2 t2
    # estendida que contém a partição (MBR, lógica ≥ 5)
    while read -r n2 s2 z2 t2; do
        [ -n "$n2" ] || continue
        if xd_eh_extendida "$t2" && [ "$n2" != "$num" ] && [ "$st" -gt "$s2" ] && [ "$st" -lt $(( s2 + z2 )) ]; then
            XD_CONTAINER="$n2"
        fi
    done <<EOF
$tabela
EOF

    # tudo que começa depois do fim da partição (fora a estendida que a contém) está no caminho
    lim="$fim"
    while read -r n2 s2 z2 t2; do
        [ -n "$n2" ] || continue
        [ "$n2" = "$num" ] && continue
        [ "$n2" = "$XD_CONTAINER" ] && continue
        [ "$s2" -ge "$tfim" ] || continue
        [ "$s2" -lt "$lim" ] && lim="$s2"
        if xd_eh_extendida "$t2" || xd_eh_swap "$t2"; then
            XD_BLOQ_SWAP="$XD_BLOQ_SWAP $n2"      # estendida só sai se tudo dentro dela for swap
        else
            XD_BLOQ_OUTRAS="$XD_BLOQ_OUTRAS $n2"
        fi
    done <<EOF
$tabela
EOF

    XD_LIVRE=$(( lim - tfim )); [ "$XD_LIVRE" -lt 0 ] && XD_LIVRE=0
    XD_LIVRE_FIM=$(( fim - tfim )); [ "$XD_LIVRE_FIM" -lt 0 ] && XD_LIVRE_FIM=0
    # Espaço NOVO de verdade: o que sobra depois da ÚLTIMA partição do disco. Sem isso, a folga de
    # alinhamento (1 MB) entre partições parecia "espaço novo" e a swap seria trocada à toa.
    local maxfim=0
    while read -r n2 s2 z2 t2; do
        [ -n "$n2" ] || continue
        [ $(( s2 + z2 )) -gt "$maxfim" ] && maxfim=$(( s2 + z2 ))
    done <<EOF
$tabela
EOF
    XD_NOVO=$(( fim - maxfim )); [ "$XD_NOVO" -lt 0 ] && XD_NOVO=0
    # Mínimo que vale a pena: 64 MB (em setores deste disco).
    local ss; ss="$(blockdev --getss "$disco" 2>/dev/null)"; [ -n "$ss" ] && [ "$ss" -gt 0 ] || ss=512
    XD_MIN=$(( 67108864 / ss ))
    return 0
}

# ---- partes do sistema que vão crescer ------------------------------------------------------------
# Imprime "FONTE FSTYPE PONTO" de "/", da pasta do sistema e do MySQL (sem repetir a mesma fonte).
xd_alvos() {
    local p src fs tgt vistos=" "
    for p in / /var/www /opt/mk-auth /var/lib/mysql; do
        [ -e "$p" ] || continue
        src="$(findmnt -n -o SOURCE --target "$p" 2>/dev/null | head -1)"; src="${src%%[*}"
        fs="$(findmnt -n -o FSTYPE --target "$p" 2>/dev/null | head -1)"
        tgt="$(findmnt -n -o TARGET --target "$p" 2>/dev/null | head -1)"
        case "$src" in /dev/*) ;; *) continue ;; esac
        case "$vistos" in *" $src "*) continue ;; esac
        vistos="$vistos$src "
        echo "$src $fs $tgt"
    done
}

xd_crescer_fs() {   # dispositivo fstype ponto
    case "$2" in
        ext2|ext3|ext4) xd_rodar resize2fs "$1" ;;
        xfs)            xd_rodar xfs_growfs "$3" ;;
        btrfs)          xd_rodar btrfs filesystem resize max "$3" ;;
        *) xd_log "sistema de arquivos '$2' não suportado para crescer automaticamente"; return 1 ;;
    esac
}

xd_setores_gb() { awk -v s="$1" -v ss="${2:-512}" 'BEGIN{printf "%.1f", s*ss/1073741824}'; }

# Troca as partições de swap no caminho por /swapfile do mesmo tamanho (no máximo 8 GB).
xd_trocar_swap_por_arquivo() {
    local disco="$1"; shift
    local nums="$*" n dev uuid ty sz total_kb=0 ss tabela
    ss="$(blockdev --getss "$disco" 2>/dev/null || echo 512)"
    tabela="$(xd_particoes "$disco")"
    # confere: dentro de estendida no caminho só pode haver swap (já garantido pela análise:
    # qualquer lógica com dados cairia em XD_BLOQ_OUTRAS e o script teria parado antes)
    if [ "$WS_SIMULAR" != "1" ]; then cp -a /etc/fstab "/etc/fstab.ws-$WS_CARIMBO"; fi
    for n in $nums; do
        ty="$(echo "$tabela" | awk -v n="$n" '$1==n{print $4}')"
        xd_eh_extendida "$ty" && continue
        sz="$(echo "$tabela" | awk -v n="$n" '$1==n{print $3}')"
        total_kb=$(( total_kb + ${sz:-0} * ss / 1024 ))
        dev="$(xd_dev_particao "$disco" "$n")"
        uuid="$(blkid -s UUID -o value "$dev" 2>/dev/null)"
        xd_rodar swapoff "$dev" 2>/dev/null
        # comenta a linha da swap antiga no fstab (por UUID ou pelo nome do dispositivo)
        if [ "$WS_SIMULAR" != "1" ]; then
            [ -n "$uuid" ] && sed -i "s|^\([^#].*UUID=$uuid.*\)$|# (ws-expandir-disco $WS_CARIMBO) \1|" /etc/fstab
            sed -i "s|^\($dev[[:space:]].*swap.*\)$|# (ws-expandir-disco $WS_CARIMBO) \1|" /etc/fstab
        fi
        # hibernação apontando para a swap antiga faria o boot esperar por ela
        if [ -n "$uuid" ] && grep -qs "$uuid" /etc/initramfs-tools/conf.d/resume; then
            xd_rodar sh -c 'echo RESUME=none > /etc/initramfs-tools/conf.d/resume'
            XD_ATUALIZAR_INITRAMFS=1
        fi
    done
    # apaga da maior para a menor (lógicas renumeram); a estendida (nº menor) sai por último
    for n in $(echo "$nums" | tr ' ' '\n' | grep -v '^$' | sort -rn); do
        xd_rodar sfdisk --no-reread --delete "$disco" "$n" || return 1
        xd_rodar partx -d --nr "$n" "$disco" 2>/dev/null
    done
    [ "$total_kb" -gt 8388608 ] && total_kb=8388608
    XD_SWAPFILE_KB="$total_kb"
    return 0
}

xd_criar_swapfile() {
    local kb="$1" fs; fs="$(findmnt -n -o FSTYPE / 2>/dev/null)"
    [ "$kb" -gt 0 ] || return 0
    if [ "$fs" = "btrfs" ]; then
        xd_log "raiz em btrfs: arquivo de swap não criado automaticamente (btrfs exige preparo próprio)."
        return 0
    fi
    if [ -e /swapfile ] && [ "$WS_SIMULAR" != "1" ]; then xd_log "/swapfile já existe — mantido."; return 0; fi
    xd_titulo "criando /swapfile de $(( kb / 1024 )) MB no lugar da partição de swap"
    xd_rodar fallocate -l "${kb}K" /swapfile || xd_rodar dd if=/dev/zero of=/swapfile bs=1M count=$(( kb / 1024 )) status=none
    xd_rodar chmod 600 /swapfile
    xd_rodar mkswap /swapfile
    xd_rodar swapon /swapfile
    if [ "$WS_SIMULAR" != "1" ] && ! grep -qs '^/swapfile[[:space:]]' /etc/fstab; then
        echo '/swapfile none swap sw 0 0' >> /etc/fstab
    fi
}

xd_confirmar() {
    [ "$WS_SIMULAR" = "1" ] && return 1
    [ "$WS_SIM" = "1" ] && return 0
    [ -r /dev/tty ] || { xd_log "sem terminal para confirmar (use WS_SIM=1)"; return 1; }
    local r; printf '    %s Digite SIM para continuar: ' "$1" > /dev/tty; read -r r < /dev/tty
    [ "$r" = "SIM" ] || [ "$r" = "sim" ]
}

# Estica uma partição (e a estendida que a contém) até onde der.
xd_esticar_particao() {
    local disco="$1" num="$2" rot
    rot="$(xd_rotulo "$disco")"
    if [ "$rot" = "gpt" ]; then
        # a cópia de segurança do GPT fica no FIM do disco antigo: move para o fim do disco novo
        xd_rodar sfdisk --relocate gpt-bak-std "$disco" 2>/dev/null \
            || { command -v sgdisk >/dev/null 2>&1 && xd_rodar sgdisk -e "$disco"; } || true
    fi
    if [ -n "$XD_CONTAINER" ]; then
        echo ', +' | xd_rodar sfdisk --no-reread -N "$XD_CONTAINER" "$disco" || return 1
    fi
    echo ', +' | xd_rodar sfdisk --no-reread -N "$num" "$disco" || return 1
    # avisa o kernel do novo tamanho sem reiniciar (partx funciona com a partição montada)
    xd_rodar partx -u "$disco" 2>/dev/null || xd_rodar partprobe "$disco" 2>/dev/null || true
}

xd_principal() {
    [ "$(id -u)" = "0" ] || { echo "Rode como root."; exit 1; }
    if [ -f /.dockerenv ] || grep -qs 'docker\|containerd\|kubepods' /proc/1/cgroup; then
        echo "Dentro de container Docker o disco é da máquina HOST: rode este script no host."; exit 0
    fi
    local c
    for c in sfdisk findmnt blockdev partx lsblk; do
        command -v "$c" >/dev/null 2>&1 || { echo "Comando '$c' não encontrado (pacotes util-linux/fdisk)."; exit 1; }
    done
    [ "$WS_SIMULAR" = "1" ] && echo "SIMULAÇÃO — só mostra o plano, nada será alterado."

    xd_titulo "antes"; df -h / | sed 's/^/    /'

    xd_titulo "relendo o tamanho dos discos (sem reiniciar)"
    if [ "$WS_SIMULAR" != "1" ]; then
        for f in /sys/class/block/*/device/rescan; do [ -w "$f" ] && echo 1 > "$f" 2>/dev/null; done
        command -v udevadm >/dev/null 2>&1 && udevadm settle 2>/dev/null
    fi

    local algum=0 esticou=0 src fs tgt salvos=" "
    XD_SWAPFILE_KB=0; XD_CONFIRMADO=0
    # fd 3: o laço não pode ler do stdin, que é de onde vem a confirmação e o ", +" do sfdisk
    while read -r src fs tgt <&3; do
        [ -n "$src" ] || continue
        algum=1
        xd_titulo "$tgt  ($src, $fs)"
        local pvs_lista="" lv="" vg="" bloqueado=0
        if command -v lvs >/dev/null 2>&1 && lvs --noheadings -o vg_name "$src" >/dev/null 2>&1; then
            vg="$(lvs --noheadings -o vg_name "$src" 2>/dev/null | tr -d ' ')"; lv="$src"
            pvs_lista="$(pvs --noheadings -o pv_name,vg_name 2>/dev/null | awk -v v="$vg" '$2==v{print $1}')"
            xd_log "LVM: grupo $vg, volume(s) físico(s): $(echo $pvs_lista)"
        else
            pvs_lista="$src"
        fi

        local pv
        for pv in $pvs_lista; do
            local nome disco num ss antes
            nome="$(basename "$(readlink -f "$pv")")"
            if [ ! -f "$XD_SYS/class/block/$nome/partition" ]; then
                xd_log "$pv é o disco inteiro (sem partição) — nada a esticar na tabela"
                [ -n "$lv" ] && xd_rodar pvresize "$pv"
                continue
            fi
            num="$(cat "$XD_SYS/class/block/$nome/partition")"
            disco="/dev/$(lsblk -no PKNAME "$pv" 2>/dev/null | head -1)"
            [ "$disco" != "/dev/" ] || disco="/dev/$(basename "$(readlink -f "$XD_SYS/class/block/$nome/..")")"
            ss="$(blockdev --getss "$disco" 2>/dev/null || echo 512)"
            antes="$(cat "$XD_SYS/class/block/$nome/size" 2>/dev/null)"

            xd_analisar "$disco" "$num" || { xd_log "não consegui ler a tabela de partições de $disco"; bloqueado=1; continue; }
            if [ "$XD_LIVRE" -lt "$XD_MIN" ] && [ -n "$(echo $XD_BLOQ_OUTRAS)" ] && [ "$XD_NOVO" -ge "$XD_MIN" ]; then
                xd_log "PARADO: depois de $pv existe partição com dados ($(for n in $XD_BLOQ_OUTRAS; do xd_dev_particao "$disco" "$n"; done | tr '\n' ' '))."
                xd_log "O espaço novo está depois dela e não dá para juntar sem mover dados. Nada foi alterado."
                xd_log "Tabela atual:"; lsblk "$disco" 2>/dev/null | sed 's/^/        /'
                bloqueado=1; continue
            fi
            # tabela salva ANTES de qualquer mudança (uma vez por disco)
            case "$salvos" in *" $disco "*) ;; *)
                if [ "$WS_SIMULAR" != "1" ] && { [ "$XD_LIVRE" -ge "$XD_MIN" ] || [ "$XD_NOVO" -ge "$XD_MIN" ]; }; then
                    sfdisk -d "$disco" > "/root/ws-particoes-$(basename "$disco")-$WS_CARIMBO.txt" 2>/dev/null \
                        && xd_log "tabela de partições salva em /root/ws-particoes-$(basename "$disco")-$WS_CARIMBO.txt"
                fi
                salvos="$salvos$disco " ;;
            esac
            if [ "$XD_LIVRE" -lt "$XD_MIN" ] && [ -z "$(echo $XD_BLOQ_OUTRAS)" ] && [ -n "$(echo $XD_BLOQ_SWAP)" ] && [ "$XD_NOVO" -ge "$XD_MIN" ]; then
                xd_log "a partição de SWAP está entre $pv e o espaço novo ($(xd_setores_gb "$XD_NOVO" "$ss") GB novos no fim do disco)."
                xd_log "Solução: trocar a partição de swap por /swapfile do mesmo tamanho e esticar $pv."
                if [ "$WS_SIMULAR" = "1" ] || xd_confirmar "Trocar a swap por arquivo e usar o espaço?"; then
                    XD_CONFIRMADO=1
                    xd_trocar_swap_por_arquivo "$disco" $XD_BLOQ_SWAP || { xd_log "falha ao remover a partição de swap — a partição do sistema não foi alterada"; bloqueado=1; continue; }
                    if [ "$WS_SIMULAR" = "1" ]; then XD_LIVRE=$XD_LIVRE_FIM; else xd_analisar "$disco" "$num"; fi
                else
                    xd_log "cancelado — nada foi alterado."; bloqueado=1; continue
                fi
            fi
            if [ "$XD_LIVRE" -lt "$XD_MIN" ]; then
                xd_log "$pv já ocupa todo o espaço do disco $disco."
            else
                xd_log "espaço novo disponível para $pv: $(xd_setores_gb "$XD_LIVRE" "$ss") GB"
                if [ "$WS_SIMULAR" = "1" ] || [ "$XD_CONFIRMADO" = "1" ] || xd_confirmar "Esticar $pv até o fim do disco?"; then
                    XD_CONFIRMADO=1
                    if xd_esticar_particao "$disco" "$num"; then
                        esticou=1
                        if [ "$WS_SIMULAR" != "1" ] && [ "$(cat "$XD_SYS/class/block/$nome/size" 2>/dev/null)" = "$antes" ]; then
                            xd_log "a tabela foi gravada, mas o kernel ainda enxerga o tamanho antigo de $pv."
                            xd_log "Reinicie o servidor e rode esta opção de novo para terminar (os dados estão intactos)."
                        fi
                    else
                        xd_log "falha ao esticar a partição (tabela original salva em /root/ws-particoes-*)"; bloqueado=1
                    fi
                else
                    xd_log "cancelado — nada foi alterado."; bloqueado=1; continue
                fi
            fi
            if [ "$XD_SWAPFILE_KB" -gt 0 ]; then xd_criar_swapfile "$XD_SWAPFILE_KB"; XD_SWAPFILE_KB=0; fi
            [ -n "$lv" ] && xd_rodar pvresize "$pv"
        done

        if [ -n "$lv" ]; then
            local livres; livres="$(vgs --noheadings -o vg_free_count "$vg" 2>/dev/null | tr -d ' ')"
            if [ "${livres:-0}" -gt 0 ]; then
                xd_rodar lvextend -l +100%FREE "$lv" && esticou=1
            elif [ "$WS_SIMULAR" = "1" ]; then
                xd_rodar lvextend -l +100%FREE "$lv"
            fi
        fi
        # Crescer o sistema de arquivos é idempotente (se já ocupa tudo, não faz nada) — roda sempre
        # que não houve bloqueio, o que também resolve quem esticou a partição na mão e parou antes.
        if [ "$bloqueado" != "1" ] || [ "$esticou" = "1" ]; then xd_crescer_fs "$src" "$fs" "$tgt"; fi
    done 3<<EOF3
$(xd_alvos)
EOF3

    [ "$algum" = "1" ] || xd_log "nenhum sistema de arquivos em disco local encontrado"
    if [ "${XD_ATUALIZAR_INITRAMFS:-0}" = "1" ] && command -v update-initramfs >/dev/null 2>&1; then
        xd_titulo "atualizando initramfs (a swap antiga saiu da hibernação)"
        xd_rodar update-initramfs -u -k all >/dev/null
    fi
    xd_titulo "depois"; df -h / | sed 's/^/    /'
    if [ "$WS_SIMULAR" = "1" ]; then
        echo "Simulação: nada foi alterado."
    elif [ "$esticou" != "1" ]; then
        echo ''
        echo 'Nenhuma partição precisou crescer. Se o disco foi aumentado e o tamanho acima não mudou:'
        echo 'confira no painel da máquina virtual se o aumento foi salvo; alguns hipervisores só mostram'
        echo 'o tamanho novo ao Linux depois de reiniciar a VM. Depois de reiniciar, rode esta opção de novo.'
    fi
}

[ "${WS_EXPANDIR_SO_FUNCOES:-0}" = "1" ] || xd_principal "$@"
