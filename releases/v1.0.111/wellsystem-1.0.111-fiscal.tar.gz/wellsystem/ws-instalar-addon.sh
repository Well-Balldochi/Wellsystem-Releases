#!/bin/bash
# =================================================================================================
# WellSystem — instalação como ADDON, sem passo manual de banco.
#
# Não é chamado direto: o INSTALAR.sh detecta que o servidor é de outro sistema e passa para cá.
#     bash INSTALAR.sh                                   → servidor MK-Auth: tudo automático
#     WS_ADDON=/pasta/do/addon bash INSTALAR.sh          → addon em outro ERP (a pasta desse ERP
#                                                          não tem padrão; é informada uma vez)
#
# O QUE ELE FAZ, NA ORDEM:
#   1. descobre onde o addon fica (MK-Auth: /opt/mk-auth/admin/addons/wellsystem)
#   2. escolhe a senha do banco SEM trocar a de ninguém (ver "SENHA" abaixo)
#   3. cria os bancos e o usuário para os DOIS nomes da máquina (localhost e 127.0.0.1)
#   4. dá permissão por GRANT; onde o GRANT é bloqueado (MK-Auth), grava direto em mysql.db
#   5. confere que o usuário ENTRA com a senha, antes de seguir
#   6. copia o código preservando cache/, uploads/, cache_trafego/ e backups/
#   7. grava a configuração do banco e a cópia que sobrevive ao reboot
#   8. cria as tabelas
# No navegador sobra só a TELA DE ATIVAÇÃO — manual por design: é a trava anti-cópia.
#
# O QUE ELE NÃO TOCA: Apache, PHP-FPM, FreeRADIUS, cron e o menu do root. O servidor é do outro
# sistema; o WellSystem só ocupa a pasta dele e o banco dele.
#
# É IDEMPOTENTE: rodar de novo completa o que faltar (por exemplo, a conta de 127.0.0.1 que as
# instalações antigas não tinham) e não troca senha nem apaga dado.
#
# SENHA — ordem de escolha:
#   WS_DB_SENHA informada  →  senha que a instalação JÁ usa (config gravada)  →  a guardada em
#   /root/.wellsystem-instalacao  →  uma nova, gerada aqui.
# Se o usuário já existe no banco e nenhuma dessas senhas entra nele, o script PARA: trocar a senha
# de uma conta existente derrubaria quem a usa, e sem a senha certa não há como seguir com segurança.
# =================================================================================================
set -e

cd "$(dirname "$0")"
ORIGEM="$(pwd -P)"
WS_RAIZ="${WS_RAIZ:-}"
DB_NOME="${WS_DB_NOME:-wellsystem}"
DB_USER="${WS_DB_USER:-wellsystem}"
ARQ_SENHAS="${WS_ARQ_SENHAS:-$WS_RAIZ/root/.wellsystem-instalacao}"

[ "$(id -u)" = "0" ] || { echo "ERRO: rode como root" >&2; exit 1; }
[ -f "$ORIGEM/config.php" ] && [ -f "$ORIGEM/ws-ambiente.sh" ] || { echo "ERRO: rode de dentro da pasta do pacote do WellSystem." >&2; exit 1; }
. "$ORIGEM/ws-ambiente.sh"

echo ''
echo '================================================='
if [ "${WS_REPARO:-0}" = "1" ]; then echo ' WellSystem — reparo do banco de dados'; else echo ' WellSystem — instalacao como ADDON'; fi
echo '================================================='

ws_amb_dentro_container && { echo 'ERRO: dentro de container. Em Docker: docker compose up -d --build' >&2; exit 1; }
command -v php >/dev/null 2>&1 || { echo 'ERRO: o PHP de linha de comando nao esta instalado — ele e usado para conferir o banco e criar as tabelas.' >&2; exit 1; }

# ---- 1) onde o addon fica -----------------------------------------------------------------------
if [ -n "${WS_ADDON:-}" ]; then
    DESTINO="$WS_ADDON"; SISTEMA="${WS_SISTEMA_ROTULO:-outro ERP}"
elif [ -d "$WS_RAIZ/opt/mk-auth" ]; then
    DESTINO="$WS_RAIZ/opt/mk-auth/admin/addons/wellsystem"; SISTEMA='MK-Auth'
else
    echo 'ERRO: nao reconheci o sistema deste servidor.' >&2
    echo '      Para instalar como addon de outro ERP, informe a pasta onde o addon deve ficar:' >&2
    echo '      WS_ADDON=/pasta/dentro/do/site/wellsystem bash INSTALAR.sh' >&2
    exit 1
fi
[ -d "$(dirname "$DESTINO")" ] || { echo "ERRO: a pasta $(dirname "$DESTINO") nao existe — confira o caminho do addon." >&2; exit 1; }
# A pasta só é CRIADA no passo do código, depois de o banco estar pronto e conferido: se algo parar
# antes, o sistema hospedeiro não fica com uma pasta de addon vazia aparecendo no painel dele.
DESTINO="$(cd "$(dirname "$DESTINO")" && pwd -P)/$(basename "$DESTINO")"
# Pasta com o mesmo nome e OUTRO conteúdo: não mistura. Pode ser addon de outra pessoa.
if [ -d "$DESTINO" ] && [ -n "$(ls -A "$DESTINO" 2>/dev/null)" ] && ! ws_amb_eh_wellsystem "$DESTINO"; then
    echo "ERRO: $DESTINO ja existe e NAO e o WellSystem. Nada foi alterado." >&2
    exit 1
fi
echo "sistema:    $SISTEMA"
echo "addon em:   $DESTINO"

# ---- 2) administrador do banco ------------------------------------------------------------------
ADM="$(ws_amb_mysql_admin)"
[ -n "$ADM" ] || { echo 'ERRO: nao consegui acesso de administrador ao banco (nem pelo debian.cnf, nem pelo root do sistema).' >&2; exit 1; }

sql_str() { printf '%s' "$1" | sed "s/\\\\/\\\\\\\\/g; s/'/\\\\'/g"; }   # escapa para dentro de '...'
login_algum() {   # a conta entra por ALGUM dos dois nomes?
    php -r 'foreach (["127.0.0.1","localhost"] as $h) { try { new PDO("mysql:host=$h", $argv[1], $argv[2], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT=>5]); exit(0); } catch (Throwable $e) {} } exit(1);' "$1" "$2" >/dev/null 2>&1
}

# ---- 3) senha, sem trocar a de ninguém ----------------------------------------------------------
ORIGEM_SENHA=''
if [ -n "${WS_DB_SENHA:-}" ]; then SENHA="$WS_DB_SENHA"; ORIGEM_SENHA='informada'
else
    SENHA="$(ws_amb_senha_existente "$DESTINO")"; [ -n "$SENHA" ] && ORIGEM_SENHA='configuracao existente'
    if [ -z "$SENHA" ] && [ -f "$ARQ_SENHAS" ]; then
        SENHA="$(grep -m1 '^DB_SENHA=' "$ARQ_SENHAS" | cut -d= -f2- | sed "s/^'//; s/'\$//")"
        [ -n "$SENHA" ] && ORIGEM_SENHA="$ARQ_SENHAS"
    fi
fi
USUARIO_EXISTE="$(printf "SELECT COUNT(*) FROM mysql.user WHERE user='%s';" "$(sql_str "$DB_USER")" | $ADM -N 2>/dev/null || echo 0)"
SENHA_REDEFINIDA=0
if [ "${USUARIO_EXISTE:-0}" -gt 0 ] 2>/dev/null; then
    if [ -n "${WS_DB_SENHA:-}" ] && ! login_algum "$DB_USER" "$SENHA"; then
        echo "ERRO: a senha informada em WS_DB_SENHA nao entra no usuario '$DB_USER'. Nada foi alterado." >&2
        exit 1
    fi
    if [ -z "$SENHA" ] || ! login_algum "$DB_USER" "$SENHA"; then
        # A conta existe e nenhuma senha guardada entra nela: a configuração se perdeu (pasta apagada,
        # addon recriado, cópia sem o cache/). A conta '$DB_USER' é do PRÓPRIO WellSystem — ninguém
        # mais a usa — então a saída automática é definir uma senha nova e gravá-la em TODAS as
        # instalações do WellSystem deste servidor que usam essa conta (passo 7). Antes o script
        # parava aqui pedindo a senha, e quem não a tinha ficava sem instalação.
        SENHA="$(openssl rand -base64 24 2>/dev/null | tr -d '$/+=' | cut -c1-20)"
        [ -n "$SENHA" ] || SENHA="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' | cut -c1-20)"
        ORIGEM_SENHA='redefinida agora (nenhuma senha guardada entrava na conta)'
        SENHA_REDEFINIDA=1
    fi
    if [ "$SENHA_REDEFINIDA" = "1" ]; then echo "senha:      $ORIGEM_SENHA"
    else echo "senha:      a que ja estava em uso ($ORIGEM_SENHA)"; fi
else
    if [ -z "$SENHA" ]; then
        SENHA="$(openssl rand -base64 24 2>/dev/null | tr -d '$/+=' | cut -c1-20)"
        [ -n "$SENHA" ] || SENHA="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' | cut -c1-20)"
        ORIGEM_SENHA='gerada agora'
    fi
    echo "senha:      $ORIGEM_SENHA"
fi

# ---- 4) bancos e usuário para os DOIS nomes da máquina ------------------------------------------
echo "==> banco e usuario"
S="$(sql_str "$SENHA")"; U="$(sql_str "$DB_USER")"
{
    printf 'CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n' "$DB_NOME"
    printf 'CREATE DATABASE IF NOT EXISTS `%s_demo` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n' "$DB_NOME"
    # CREATE USER IF NOT EXISTS não altera conta existente: só cria a que falta (a de 127.0.0.1
    # das instalações antigas, por exemplo), com a mesma senha que a outra já usa.
    printf "CREATE USER IF NOT EXISTS '%s'@'localhost' IDENTIFIED BY '%s';\n" "$U" "$S"
    printf "CREATE USER IF NOT EXISTS '%s'@'127.0.0.1' IDENTIFIED BY '%s';\n" "$U" "$S"
    printf 'FLUSH PRIVILEGES;\n'
} | $ADM
if [ "$SENHA_REDEFINIDA" = "1" ]; then
    for h in localhost 127.0.0.1; do
        # ALTER USER (MariaDB 10.2+/MySQL 5.7+); SET PASSWORD cobre os servidores mais antigos.
        printf "ALTER USER '%s'@'%s' IDENTIFIED BY '%s';\n" "$U" "$h" "$S" | $ADM 2>/dev/null \
            || printf "SET PASSWORD FOR '%s'@'%s' = PASSWORD('%s');\n" "$U" "$h" "$S" | $ADM
    done
    printf 'FLUSH PRIVILEGES;\n' | $ADM
    echo '    senha da conta do WellSystem redefinida'
fi

# Permissão: GRANT quando o servidor deixa; senão (MK-Auth bloqueia GRANT fora do banco dele)
# direto em mysql.db, que é onde o GRANT gravaria. WS_TESTE_SEM_GRANT=1 força o segundo caminho.
GRANT_OK=0
if [ "${WS_TESTE_SEM_GRANT:-0}" != "1" ]; then
    if {
        for h in localhost 127.0.0.1; do
            printf "GRANT ALL PRIVILEGES ON \`%s\`.* TO '%s'@'%s';\n" "$DB_NOME" "$U" "$h"
            printf "GRANT ALL PRIVILEGES ON \`%s\\\\_%%\`.* TO '%s'@'%s';\n" "$DB_NOME" "$U" "$h"
        done
        printf 'FLUSH PRIVILEGES;\n'
    } | $ADM 2>/dev/null; then GRANT_OK=1; fi
fi
if [ "$GRANT_OK" = "1" ]; then
    echo '    permissoes concedidas (GRANT)'
else
    COLS='Host,Db,User,Select_priv,Insert_priv,Update_priv,Delete_priv,Create_priv,Drop_priv,Grant_priv,References_priv,Index_priv,Alter_priv,Create_tmp_table_priv,Lock_tables_priv,Create_view_priv,Show_view_priv,Create_routine_priv,Alter_routine_priv,Execute_priv,Event_priv,Trigger_priv'
    PRIV="'Y','Y','Y','Y','Y','Y','N','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y'"
    UPD="Select_priv='Y',Insert_priv='Y',Update_priv='Y',Delete_priv='Y',Create_priv='Y',Drop_priv='Y',Index_priv='Y',Alter_priv='Y',Create_tmp_table_priv='Y',Lock_tables_priv='Y',Create_view_priv='Y',Show_view_priv='Y',Create_routine_priv='Y',Alter_routine_priv='Y',Execute_priv='Y',Event_priv='Y',Trigger_priv='Y'"
    {
        for h in localhost 127.0.0.1; do
            printf "INSERT INTO mysql.db (%s) VALUES ('%s','%s','%s',%s) ON DUPLICATE KEY UPDATE %s;\n" "$COLS" "$h" "$DB_NOME" "$U" "$PRIV" "$UPD"
            printf "INSERT INTO mysql.db (%s) VALUES ('%s','%s\\\\_%%','%s',%s) ON DUPLICATE KEY UPDATE %s;\n" "$COLS" "$h" "$DB_NOME" "$U" "$PRIV" "$UPD"
        done
        printf 'FLUSH PRIVILEGES;\n'
    } | $ADM
    echo '    permissoes gravadas em mysql.db (este servidor bloqueia GRANT)'
fi

# ---- 5) conferir ANTES de seguir: entra pelos dois nomes e enxerga o banco ----------------------
if ! ws_amb_testa_login "$DB_USER" "$SENHA"; then
    echo "ERRO: o usuario '$DB_USER' foi criado, mas nao consegue entrar. Nada foi copiado." >&2
    exit 1
fi
php -r 'try { new PDO("mysql:host=127.0.0.1;dbname=" . $argv[3], $argv[1], $argv[2], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]); exit(0); }
        catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . "\n"); exit(1); }' "$DB_USER" "$SENHA" "$DB_NOME" \
    || { echo "ERRO: o usuario entra, mas nao tem acesso ao banco $DB_NOME. Nada foi copiado." >&2; exit 1; }
echo '    usuario entra por 127.0.0.1 e por localhost, com acesso ao banco'

# Guarda a senha para as próximas vezes (reinstalar, recuperar configuração), só se ainda não estava.
if [ "$SENHA_REDEFINIDA" = "1" ] && grep -q '^DB_SENHA=' "$ARQ_SENHAS" 2>/dev/null; then
    sed -i "s|^DB_SENHA=.*|DB_SENHA='$SENHA'|" "$ARQ_SENHAS"   # senha nova: só letras e números
    echo "    senha nova guardada em $ARQ_SENHAS (so o root le)"
fi
if ! grep -q '^DB_SENHA=' "$ARQ_SENHAS" 2>/dev/null; then
    mkdir -p "$(dirname "$ARQ_SENHAS")"
    printf "DB_SENHA='%s'\n" "$(printf '%s' "$SENHA" | sed "s/'/'\\\\''/g")" >> "$ARQ_SENHAS"
    chmod 600 "$ARQ_SENHAS"
    echo "    senha guardada em $ARQ_SENHAS (so o root le)"
fi

# ---- 6) código ----------------------------------------------------------------------------------
echo "==> codigo"
mkdir -p "$DESTINO"
if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude 'cache/' --exclude 'uploads/' --exclude 'cache_trafego/' --exclude 'backups/' \
          --exclude 'Mkfiles/' --exclude '.env' --exclude '.git/' "$ORIGEM"/ "$DESTINO"/
else
    for item in "$ORIGEM"/* "$ORIGEM"/.[!.]*; do
        [ -e "$item" ] || continue
        case "$(basename "$item")" in cache|uploads|cache_trafego|backups|Mkfiles|.env|.git) continue ;; esac
        cp -a "$item" "$DESTINO/" 2>/dev/null || true
    done
fi
for p in cache uploads uploads/mkfiles assets cache_trafego backups; do
    mkdir -p "$DESTINO/$p"
    # A pasta vazia do pacote traz o .htaccess de proteção (uploads/ proíbe executar PHP).
    if [ -f "$ORIGEM/$p/.htaccess" ] && [ ! -f "$DESTINO/$p/.htaccess" ]; then cp -a "$ORIGEM/$p/.htaccess" "$DESTINO/$p/" || true; fi
done
DONO="$(ws_amb_dono "$DESTINO")"
echo "    dono dos arquivos: $DONO"

# ---- 7) configuração do banco -------------------------------------------------------------------
echo "==> configuracao"
CFG="$DESTINO/cache/wellsystem_db.json"
php -r '$c = is_file($argv[1]) ? (json_decode((string)@file_get_contents($argv[1]), true) ?: []) : [];
        // preserva o que a configuração já tinha (tokens, radius_db...) e acerta só a conexão
        $c = array_merge($c, ["host"=>"127.0.0.1","porta"=>3306,"user"=>$argv[2],"pass"=>$argv[3],"dbname"=>$argv[4]]);
        file_put_contents($argv[1], json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));' \
    "$CFG" "$DB_USER" "$SENHA" "$DB_NOME"
chmod 640 "$CFG"
echo "    gravada em $CFG"
# Senha redefinida: toda OUTRA instalação do WellSystem neste servidor que usa a mesma conta recebe
# a senha nova junto — senão ela perderia o acesso ao banco na mesma hora.
if [ "$SENHA_REDEFINIDA" = "1" ]; then
    for OUTRA in $(ws_amb_instalacoes "$ORIGEM" 2>/dev/null); do
        [ "$OUTRA" = "$DESTINO" ] && continue
        OCFG="$OUTRA/cache/wellsystem_db.json"; [ -s "$OCFG" ] || continue
        php -r '$c = json_decode((string)@file_get_contents($argv[1]), true);
                if (!is_array($c) || ($c["user"] ?? "") !== $argv[2]) exit(1);
                $c["pass"] = $argv[3]; file_put_contents($argv[1], json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));' \n            "$OCFG" "$DB_USER" "$SENHA" 2>/dev/null \n            && { ws_amb_espelhar_config_banco "$OUTRA" "$(ws_amb_dono "$OUTRA")" >/dev/null; echo "    senha nova aplicada tambem em $OUTRA"; }
    done
fi

# ---- 8) tabelas ---------------------------------------------------------------------------------
echo "==> tabelas"
if (cd "$DESTINO" && php install_cli.php); then :; else
    echo '    (as tabelas serao criadas na primeira vez que o sistema for aberto no navegador)'
fi

chown -R "$DONO" "$DESTINO" 2>/dev/null || true
chmod -R 775 "$DESTINO/cache" "$DESTINO/uploads" "$DESTINO/assets" "$DESTINO/cache_trafego" "$DESTINO/backups" 2>/dev/null || true
chmod 640 "$CFG" 2>/dev/null || true
mkdir -p "$WS_RAIZ/var/lib/wellsystem" && chown "$DONO" "$WS_RAIZ/var/lib/wellsystem" 2>/dev/null && chmod 750 "$WS_RAIZ/var/lib/wellsystem" 2>/dev/null || true
ws_amb_espelhar_config_banco "$DESTINO" "$DONO"

# ---- pronto -------------------------------------------------------------------------------------
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo ''
echo '================================================='
echo ' PRONTO — falta so a ativacao, no navegador'
echo '================================================='
if [ "$SISTEMA" = "MK-Auth" ]; then
    echo "Abra:  http://${IP:-IP-DO-SERVIDOR}/admin/addons/wellsystem/"
else
    echo "Abra o endereco do $SISTEMA seguido da pasta do addon: .../$(basename "$DESTINO")/"
fi
echo '  1) tela de ativacao: digite a senha de ativacao desta instalacao'
echo '  2) entre com o usuario admin e crie a senha dele (nao existe senha de fabrica)'
echo ''
echo "Apache, PHP-FPM, FreeRADIUS, cron e menu do root do $SISTEMA NAO foram tocados."
echo 'Para atualizar depois:  bash ATUALIZAR.sh  (mesmo comando de sempre)'
