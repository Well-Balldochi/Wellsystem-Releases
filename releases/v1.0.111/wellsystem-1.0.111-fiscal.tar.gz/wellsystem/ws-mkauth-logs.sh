#!/bin/bash
# WellSystem — HORA CERTA e LOGS de um servidor MK-Auth (SEM WellSystem) para o servidor de logs (31/10/2026).
# Uso (como root, no servidor do MK-Auth):  bash ws-mkauth-logs.sh <endereço-do-servidor-de-logs> [porta=514]
# Faz três coisas, todas reversíveis (para desfazer: bash ws-mkauth-logs.sh --desfazer):
#   1) HORA: chrony com a NTP.br (se o apt não instalar, cai para ntpdate no cron a cada 30 min);
#   2) LOGS: rsyslog envia ao servidor de logs (TCP, fila em disco) o log do FreeRADIUS, os acessos (auth) e os registros de conexão;
#   3) CONEXÕES: a cada minuto lê o radacct do banco mkradius (credencial do próprio FreeRADIUS) e grava
#      "CONEXAO INICIO|FIM login= ip= nas= mac= ..." no syslog — o mesmo formato do WellSystem (logs_envio_lib.php).
# Ao lado do MK-Auth COM WellSystem instalado não precisa disto: a tela Logs de conexão do WellSystem já faz tudo.
set -u
[ "$(id -u)" = 0 ] || { echo "rode como root"; exit 1; }
RS=/etc/rsyslog.d/90-wellsystem-logs.conf; CR=/etc/cron.d/ws-mkauth-logs; PHPF=/usr/local/sbin/ws-conexao-log.php; HORA=/etc/cron.d/ws-hora; ESTADO=/var/lib/ws-logs

if [ "${1:-}" = "--desfazer" ]; then
    rm -f "$RS" "$CR" "$PHPF" "$HORA" /usr/local/sbin/ws-ctl-logs.sh /etc/chrony/conf.d/wellsystem-hora.conf; rm -rf "$ESTADO"
    sed -i '/# WellSystem-hora-inicio/,/# WellSystem-hora-fim/d' /etc/chrony/chrony.conf 2>/dev/null
    service rsyslog restart >/dev/null 2>&1; service chrony restart >/dev/null 2>&1
    echo "desfeito."; exit 0
fi

DEST="${1:-}"; PORTA="${2:-514}"
[[ "$DEST" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] || { echo "uso: bash $0 <endereco-do-servidor-de-logs> [porta]"; exit 1; }
[[ "$PORTA" =~ ^[0-9]+$ ]] || { echo "porta invalida"; exit 1; }
timeout 4 bash -c "echo > /dev/tcp/$DEST/$PORTA" 2>/dev/null || echo "AVISO: este servidor nao alcanca $DEST:$PORTA agora (o rsyslog guarda na fila e envia quando voltar)."

echo "==> 1/3 hora certa"
if ! command -v chronyd >/dev/null 2>&1; then DEBIAN_FRONTEND=noninteractive apt-get install -y -qq chrony >/dev/null 2>&1 || true; fi
if command -v chronyd >/dev/null 2>&1; then
    rm -f "$HORA"
    if ! grep -q 'WellSystem-hora-inicio' /etc/chrony/chrony.conf; then
        { echo '# WellSystem-hora-inicio'; echo 'server a.st1.ntp.br iburst'; echo 'server b.st1.ntp.br iburst'; echo 'server c.st1.ntp.br iburst'; echo "server $DEST iburst"; echo 'makestep 1.0 3'; echo '# WellSystem-hora-fim'; } >> /etc/chrony/chrony.conf
    fi
    service chrony restart >/dev/null 2>&1 || service chronyd restart >/dev/null 2>&1
    echo "   chrony ativo"
else
    printf '*/30 * * * * root /usr/sbin/ntpdate -u a.st1.ntp.br b.st1.ntp.br >/dev/null 2>&1\n' > "$HORA"; chmod 644 "$HORA"
    /usr/sbin/ntpdate -u a.st1.ntp.br b.st1.ntp.br >/dev/null 2>&1 || true
    echo "   chrony indisponivel: ntpdate a cada 30 min"
fi

echo "==> 2/3 envio dos logs (rsyslog)"
command -v rsyslogd >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rsyslog >/dev/null 2>&1
{
echo '# WellSystem — gerado por ws-mkauth-logs.sh (nao editar a mao)'
[ -f /var/log/freeradius/radius.log ] && echo 'module(load="imfile" PollingInterval="5")'
echo 'ruleset(name="ws_envio_logs") {'
echo "  action(type=\"omfwd\" target=\"$DEST\" port=\"$PORTA\" protocol=\"tcp\""
echo '    action.resumeRetryCount="-1" action.resumeInterval="30" queue.type="LinkedList" queue.filename="ws_envio_logs"'
echo '    queue.maxdiskspace="268435456" queue.size="50000" queue.saveonshutdown="on")'
echo '}'
echo 'if prifilt("local6.*") then { call ws_envio_logs }'
echo 'if prifilt("auth,authpriv.*") then { call ws_envio_logs }'
[ -f /var/log/freeradius/radius.log ] && echo 'input(type="imfile" File="/var/log/freeradius/radius.log" Tag="freeradius:" Severity="info" Facility="local5" ruleset="ws_envio_logs" addMetadata="off" freshStartTail="on")'
} > "$RS"
if ! rsyslogd -N1 >/dev/null 2>&1; then rm -f "$RS"; echo "   rsyslog recusou a configuracao: nada foi alterado"; exit 1; fi
service rsyslog restart >/dev/null 2>&1 && echo "   rsyslog enviando para $DEST:$PORTA (TCP)"

echo "==> 3/3 registro de conexoes (radacct do mkradius)"
mkdir -p "$ESTADO"
cat > "$PHPF" <<'PHPEOF'
<?php
// Lê o radacct do mkradius e grava INICIO/FIM no syslog (local6). Credencial = a do próprio FreeRADIUS.
if (PHP_SAPI !== 'cli') exit;
if (is_file('/var/lib/ws-logs/desligado')) exit(0);   // desligado pelo painel do servidor de logs
// FOTO DAS SESSÕES ABERTAS: uma linha "CONEXAO ABERTA" por sessão conectada AGORA, com o início REAL (inicio=). Na ativação e todo dia depois das 00:05.
function abertas($db, $motivo) {
    $q = $db->query('SELECT acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime, acctupdatetime FROM radacct WHERE acctstoptime IS NULL ORDER BY radacctid LIMIT 100000');
    openlog('wellsystem-conexao', LOG_PID, LOG_LOCAL6);
    while ($r = $q->fetch(PDO::FETCH_ASSOC)) syslog(LOG_INFO, 'CONEXAO ABERTA ' . ln(['motivo' => $motivo, 'login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'], 'sessao' => $r['acctsessionid'], 'inicio' => $r['acctstarttime'], 'atualizada' => $r['acctupdatetime']]));
    closelog();
}
$sql = (string)@file_get_contents(glob('/etc/freeradius/*/mods-enabled/sql')[0] ?? '');
$g = function ($k) use ($sql) { return preg_match('/^\s*' . $k . '\s*=\s*"?([^"\r\n]*)"?/m', $sql, $m) ? trim($m[1]) : ''; };
try { $db = new PDO('mysql:host=' . (($g('server') ?: 'localhost') === 'localhost' ? '127.0.0.1' : $g('server')) . ';dbname=' . ($g('radius_db') ?: 'mkradius') . ';charset=utf8mb4', $g('login'), $g('password'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); } catch (Throwable $e) { exit(1); }
$cf = '/var/lib/ws-logs/conexao.cursor.json'; $cur = json_decode((string)@file_get_contents($cf), true);
$agora = (string)$db->query('SELECT NOW()')->fetchColumn();
if (!is_array($cur) || !isset($cur['id_ini'])) { file_put_contents($cf, json_encode(['id_ini' => (int)$db->query('SELECT COALESCE(MAX(radacctid),0) FROM radacct')->fetchColumn(), 'fim_ts' => $agora, 'fim_ids' => [], 'snap' => date('Y-m-d')])); abertas($db, 'ativacao'); exit(0); }
function ln(array $a) { $o = []; foreach ($a as $k => $v) { $v = trim(str_replace(["\r", "\n", '"'], ' ', (string)$v)); if ($v === '') $v = '-'; $o[] = $k . '=' . (strpbrk($v, ' ') ? '"' . $v . '"' : $v); } return implode(' ', $o); }
openlog('wellsystem-conexao', LOG_PID, LOG_LOCAL6);
$q = $db->prepare('SELECT radacctid, acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime FROM radacct WHERE radacctid > ? ORDER BY radacctid LIMIT 1000'); $q->execute([(int)$cur['id_ini']]);
foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { syslog(LOG_INFO, 'CONEXAO INICIO ' . ln(['login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'], 'sessao' => $r['acctsessionid'], 'inicio' => $r['acctstarttime']])); $cur['id_ini'] = (int)$r['radacctid']; }
$vistos = array_map('intval', (array)($cur['fim_ids'] ?? []));
$q = $db->prepare('SELECT radacctid, acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime, acctstoptime, acctterminatecause, acctinputoctets, acctoutputoctets FROM radacct WHERE acctstoptime >= ? AND acctstoptime <= NOW() ORDER BY acctstoptime, radacctid LIMIT 1000'); $q->execute([(string)$cur['fim_ts']]);
foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $id = (int)$r['radacctid']; if ($r['acctstoptime'] === $cur['fim_ts'] && in_array($id, $vistos, true)) continue;
    syslog(LOG_INFO, 'CONEXAO FIM ' . ln(['login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'], 'sessao' => $r['acctsessionid'], 'inicio' => $r['acctstarttime'], 'fim' => $r['acctstoptime'], 'causa' => $r['acctterminatecause'], 'subiu' => $r['acctinputoctets'], 'desceu' => $r['acctoutputoctets']]));
    if ($r['acctstoptime'] !== $cur['fim_ts']) { $cur['fim_ts'] = $r['acctstoptime']; $vistos = []; } $vistos[] = $id;
}
if (($cur['snap'] ?? '') !== date('Y-m-d') && date('H:i') >= '00:05') { abertas($db, isset($cur['snap']) ? 'diario' : 'ativacao'); $cur['snap'] = date('Y-m-d'); }
$cur['fim_ids'] = array_slice($vistos, -200); closelog(); file_put_contents($cf, json_encode($cur));
PHPEOF
chmod 750 "$PHPF"
printf '* * * * * root php %s >/dev/null 2>&1\n' "$PHPF" > "$CR"; chmod 644 "$CR"
echo "==> 4/4 controle pelo painel do servidor de logs (botao Ligar/Desligar envio)"
rm -f "$ESTADO/desligado" "$ESTADO/90-wellsystem-logs.conf.off"
CTL=/usr/local/sbin/ws-ctl-logs.sh
cat > "$CTL" <<CTLEOF
#!/bin/bash
# Pergunta ao servidor de logs se deve enviar (ligado|desligado) e aplica. Gerado por ws-mkauth-logs.sh.
DEST="$DEST"; RS="$RS"; OFF="$ESTADO/90-wellsystem-logs.conf.off"; FLAG="$ESTADO/desligado"
[ -f "\$RS" ] && EST=ligado || EST=desligado
U="http://\$DEST:8086/ctl?est=\$EST"
if command -v curl >/dev/null 2>&1; then R=\$(curl -s -m10 "\$U" 2>/dev/null); else R=\$(wget -q -T 10 -O- "\$U" 2>/dev/null); fi
case "\$R" in
  desligado) if [ -f "\$RS" ]; then mv "\$RS" "\$OFF"; touch "\$FLAG"; service rsyslog restart >/dev/null 2>&1; fi ;;
  ligado) if [ -f "\$OFF" ]; then mv "\$OFF" "\$RS"; rm -f "\$FLAG"; service rsyslog restart >/dev/null 2>&1; fi ;;
esac
CTLEOF
chmod 750 "$CTL"
printf '* * * * * root %s >/dev/null 2>&1\n' "$CTL" >> "$CR"
"$CTL"; echo "   controle ligado (consulta o servidor de logs a cada minuto)"
php "$PHPF" && echo "   registro de conexoes ligado (a cada minuto)"
logger -p local6.info -t wellsystem-teste "TESTE-ENVIO mkauth $(hostname)"
echo "pronto."
