#!/bin/bash
# =================================================================================================
# WellSystem — NOME RESUMIDO do cliente na sessão IPoE (atributo SRouter-IPoE-Alias).
#
# O QUE FAZ
#   No IPoE o assinante é identificado por um ID técnico (ex.: 49544253cf94abe0). Na autenticação,
#   o FreeRADIUS devolve o nome resumido do cadastro em SRouter-IPoE-Alias, e o concentrador passa
#   a mostrar "adersonsilva" no lugar do ID. Nada é configurado no concentrador: tudo sai daqui.
#   PPPoE não passa por esta regra (continua exibindo o login normal).
#
# A REGRA (a mesma do MK-Auth, lendo as tabelas do WellSystem)
#   - só sessão Ethernet (NAS-Port-Type == Ethernet, que é como o accel-ppp marca o IPoE);
#   - busca o contrato pelo ID que chegou (login IPoE; na falta dele, o login do contrato IPoE);
#   - ignora contrato cancelado e prefere o ativo;
#   - nome em minúsculas; nome resumido vazio = nada é enviado (a sessão fica com o ID, como antes).
#
# POR QUE A CONSULTA DIZ O NOME DO BANCO
#   O módulo sql do FreeRADIUS abre a conexão no banco do RADIUS (normalmente "radius"). Sem o
#   prefixo, "ws_cliente" era procurada lá, dava "Table 'radius.ws_cliente' doesn't exist" e o
#   nome nunca saía. Com "wellsystem.ws_cliente" funciona em qualquer arranjo de bancos.
#
# SEGURANÇA DA CONEXÃO — nada aqui pode derrubar autenticação
#   - cópia do arquivo antes de mexer (/var/backups/wellsystem/freeradius);
#   - "freeradius -CX" valida a configuração; falhou = o arquivo original volta sozinho;
#   - reiniciou e o serviço não subiu = o original volta e o serviço sobe de novo;
#   - arquivo já atualizado = não reinicia nada;
#   - se a consulta falhar em tempo de execução, o FreeRADIUS só deixa de mandar o nome: o cliente
#     autentica igual (comportamento comprovado em produção antes desta correção).
#
# CENÁRIOS (autodetectados — ninguém precisa escolher)
#   servidor  FreeRADIUS próprio do WellSystem: instala/atualiza (INSTALAR.sh e ATUALIZAR.sh).
#   addon     em outro ERP: só age se o FreeRADIUS local lê o banco do WellSystem (--auto);
#             se ele lê o banco do outro ERP, não é tocado.
#   mkauth    o FreeRADIUS é do MK-Auth e já tem a regra dele (lê sis_cliente.nome_res): nada é
#             alterado aqui; o WellSystem grava o nome resumido em nome_res (mkauth_bridge.php).
#   docker    o container freeradius aplica a mesma regra ao subir (docker/freeradius/entrypoint.sh).
#
# USO
#   bash ws-radius-alias.sh                     instala/atualiza e reinicia o FreeRADIUS se mudou
#   bash ws-radius-alias.sh --auto              só age se este FreeRADIUS é do WellSystem
#   bash ws-radius-alias.sh --sem-reiniciar     grava e valida, sem reiniciar (usado pelo INSTALAR)
#   bash ws-radius-alias.sh --testar ID_IPOE    mostra o nome que será enviado e testa no RADIUS
#   Opcionais: --pasta DIR_DO_WELLSYSTEM   --banco NOME_DO_BANCO
# =================================================================================================
set -u

PASTA="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
BANCO="${WS_DB_NOME:-}"
AUTO=0; REINICIAR=1; TESTAR=""
while [ $# -gt 0 ]; do
    case "$1" in
        --auto)          AUTO=1 ;;
        --sem-reiniciar) REINICIAR=0 ;;
        --testar)        TESTAR="${2:-}"; shift; [ -n "$TESTAR" ] || { echo 'use: --testar ID_IPOE' >&2; exit 2; } ;;
        --pasta)         PASTA="${2:-}"; shift ;;
        --banco)         BANCO="${2:-}"; shift ;;
        -h|--help)       sed -n '2,48p' "$0"; exit 0 ;;
        *)               echo "opcao desconhecida: $1 (veja --help)" >&2; exit 2 ;;
    esac
    shift
done

ok()   { echo "    $*"; }
aviso(){ echo "    AVISO: $*" >&2; }

# ---- 1) FreeRADIUS local ------------------------------------------------------------------------
FR=""
# WS_FR_DIR / WS_RADBIN / WS_FR_SHARE: só para testes fora de um servidor real.
for d in ${WS_FR_DIR:-} /etc/freeradius/3.0 /etc/freeradius /etc/raddb; do
    [ -f "$d/radiusd.conf" ] && { FR="$d"; break; }
done
if [ -z "$FR" ]; then ok 'nome IPoE: sem FreeRADIUS neste servidor — nada a fazer'; exit 0; fi
RADBIN=""
for c in ${WS_RADBIN:-} freeradius radiusd /usr/sbin/freeradius /usr/sbin/radiusd; do
    command -v "$c" >/dev/null 2>&1 && { RADBIN="$(command -v "$c")"; break; }
done
[ -n "$RADBIN" ] || { aviso "binario do FreeRADIUS nao encontrado — nada alterado"; exit 0; }

SITE="$FR/sites-enabled/default"
[ -e "$SITE" ] || { ok "nome IPoE: $SITE nao existe — nada a fazer"; exit 0; }
ALVO="$(readlink -f "$SITE")"      # grava no arquivo real: sites-enabled costuma ser um link
SQLMOD="$FR/mods-enabled/sql"
[ -e "$SQLMOD" ] || { ok 'nome IPoE: modulo sql desligado neste FreeRADIUS — nada a fazer'; exit 0; }
SQLMOD="$(readlink -f "$SQLMOD")"

# Lê "chave = valor" do módulo sql (ignora comentários; tira aspas).
sql_campo() {
    awk -v k="$1" '
        $0 ~ "^[[:space:]]*" k "[[:space:]]*=" {
            sub(/^[^=]*=[[:space:]]*/, ""); sub(/[[:space:]]*#.*$/, ""); sub(/[[:space:]]+$/, "")
            gsub(/^"|"$/, ""); print; exit
        }' "$SQLMOD"
}
SQL_DIALETO="$(sql_campo dialect)"
SQL_HOST="$(sql_campo server)";    SQL_HOST="${SQL_HOST:-localhost}"
SQL_PORTA="$(sql_campo port)";     SQL_PORTA="${SQL_PORTA:-3306}"
SQL_USER="$(sql_campo login)"
SQL_SENHA="$(sql_campo password)"
SQL_DB="$(sql_campo radius_db)"
case "$SQL_DIALETO" in mysql|"") ;; *) ok "nome IPoE: modulo sql usa $SQL_DIALETO (so MySQL/MariaDB e suportado) — nada alterado"; exit 0 ;; esac

# ---- 2) banco do WellSystem ---------------------------------------------------------------------
json_campo() {
    [ -s "$1" ] && command -v php >/dev/null 2>&1 || return 0
    php -r '$c = json_decode((string)@file_get_contents($argv[1]), true); echo is_array($c) ? (string)($c[$argv[2]] ?? "") : "";' "$1" "$2" 2>/dev/null
}
CFG="$PASTA/cache/wellsystem_db.json"
[ -n "$BANCO" ] || BANCO="$(json_campo "$CFG" dbname)"
BANCO="${BANCO:-wellsystem}"
WS_RADIUS_DB="$(json_campo "$CFG" radius_db)"
if ! printf '%s' "$BANCO" | grep -Eq '^[A-Za-z0-9_]{1,64}$'; then
    aviso "nome de banco invalido: '$BANCO' — nada alterado"; exit 1
fi

# --auto (ATUALIZAR em addon): só mexe no FreeRADIUS que autentica pelas tabelas do WellSystem.
if [ "$AUTO" = 1 ] && [ -z "$TESTAR" ]; then
    if [ "$SQL_DB" != "$BANCO" ] && { [ -z "$WS_RADIUS_DB" ] || [ "$SQL_DB" != "$WS_RADIUS_DB" ]; }; then
        ok "nome IPoE: o FreeRADIUS deste servidor le o banco '$SQL_DB', que nao e do WellSystem — nao foi tocado"
        exit 0
    fi
fi

# Consulta usada pelo FreeRADIUS. %{User-Name} é escapado pelo próprio módulo sql.
consulta() {   # $1 = o que entra no lugar do ID
    printf "SELECT c.nome_resumido FROM %s.ws_contrato ct JOIN %s.ws_cliente c ON c.id = ct.cliente_id WHERE (ct.login_ipoe = '%s' OR (ct.tipo_conexao = 'ipoe' AND ct.login_pppoe = '%s')) AND ct.status <> 'cancelado' AND c.nome_resumido <> '' ORDER BY (ct.login_ipoe = '%s') DESC, (ct.status = 'ativo') DESC, ct.id DESC LIMIT 1" \
        "$BANCO" "$BANCO" "$1" "$1" "$1"
}

# Roda SQL COMO o usuário do módulo sql — é assim que o FreeRADIUS enxerga as permissões.
mysql_radius() {
    MYSQL_PWD="$SQL_SENHA" mysql -h "$SQL_HOST" -P "$SQL_PORTA" -u "$SQL_USER" -N -B "$@"
}

# ---- modo teste ---------------------------------------------------------------------------------
if [ -n "$TESTAR" ]; then
    if ! printf '%s' "$TESTAR" | grep -Eq '^[A-Za-z0-9@._:/-]{1,64}$'; then echo 'ID invalido' >&2; exit 2; fi
    echo "==> nome IPoE — teste do ID: $TESTAR"
    echo "    banco WellSystem: $BANCO   |   FreeRADIUS le: $SQL_DB (usuario $SQL_USER)"
    if grep -q '# >>> WellSystem-IPoE-Alias' "$ALVO"; then ok 'regra instalada no FreeRADIUS: sim (versao atual)'
    elif grep -q 'WellSystem-IPoE-Alias' "$ALVO"; then aviso 'regra instalada e ANTIGA — rode: bash ws-radius-alias.sh'
    else aviso 'regra NAO instalada — rode: bash ws-radius-alias.sh'; fi
    NOME="$(mysql_radius -e "$(consulta "$TESTAR")" 2>&1)"; RC=$?
    if [ $RC -ne 0 ]; then aviso "consulta falhou como '$SQL_USER': $NOME"; exit 1; fi
    if [ -z "$NOME" ]; then
        aviso 'nenhum nome: ID sem contrato IPoE ativo, contrato cancelado ou nome resumido vazio no cadastro'
    else
        ok "nome que sera enviado: $(printf '%s' "$NOME" | tr '[:upper:]' '[:lower:]')"
    fi
    # O nome é só EXIBIÇÃO (coluna user-alias do accel). A sessão continua registrada pelo ID — é
    # por ele que o bloqueio, o "Derrubar" e o CoA encontram a conexão. Mostra a prova:
    SESS="$(mysql_radius ${SQL_DB:+-D "$SQL_DB"} -e "SELECT CONCAT('username=', username, '  nas=', nasipaddress, '  ip=', IFNULL(framedipaddress,''), '  desde ', acctstarttime) FROM radacct WHERE username='$TESTAR' AND acctstoptime IS NULL ORDER BY acctstarttime DESC LIMIT 3" 2>/dev/null)"
    if [ -n "$SESS" ]; then
        echo '    sessao aberta registrada pelo ID (bloqueio e derrubada continuam achando a conexao):'
        printf '%s\n' "$SESS" | sed 's/^/      /'
    else
        echo '    (nenhuma sessao aberta com este ID no radacct agora)'
    fi
    # Pergunta de verdade ao FreeRADIUS, como o concentrador faz (só autenticação: não abre
    # sessão, não mexe em radacct, não afeta o cliente conectado).
    if command -v radclient >/dev/null 2>&1; then
        SEGREDO="$(awk '/^[[:space:]]*client[[:space:]]+localhost[[:space:]]*\{/ {d=1}
                        d && /^[[:space:]]*secret[[:space:]]*=/ { sub(/^[^=]*=[[:space:]]*/, ""); sub(/[[:space:]]*#.*$/, ""); gsub(/"/, ""); print; exit }' \
                    "$FR/clients.conf" 2>/dev/null)"
        SEGREDO="${SEGREDO:-testing123}"
        SENHA="$(mysql_radius ${SQL_DB:+-D "$SQL_DB"} -e "SELECT value FROM radcheck WHERE username='$TESTAR' AND attribute='Cleartext-Password' LIMIT 1" 2>/dev/null)"
        case "$SENHA" in *\"*|*\\*) echo '    (senha com caractere especial — teste no RADIUS pulado)'; exit 0 ;; esac
        echo '    resposta do FreeRADIUS (127.0.0.1):'
        printf 'User-Name = "%s"\nUser-Password = "%s"\nNAS-Port-Type = Ethernet\nNAS-IP-Address = 127.0.0.1\n' "$TESTAR" "$SENHA" \
            | radclient -r 1 -t 3 -x 127.0.0.1:1812 auth "$SEGREDO" 2>&1 \
            | grep -Ei 'Received|Access-|SRouter-IPoE-Alias|no reply|no response|failed' | sed 's/^/      /'
    fi
    exit 0
fi

# ---- 3) outra regra já manda o alias? (MK-Auth e similares) -------------------------------------
# Retira as NOSSAS regras e procura o atributo no que sobra. Havendo, a regra é de outro sistema:
# duas regras brigando pelo mesmo atributo é pior que nenhuma. Não mexe.
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
awk '/# >>> WellSystem-IPoE-Alias/ {p=1} !p && !/WellSystem-IPoE-Alias/ {print} /# <<< WellSystem-IPoE-Alias/ {p=0}' "$ALVO" \
    | grep -v '^[[:space:]]*#' > "$TMPD/sem-nossas"
if grep -q 'SRouter-IPoE-Alias' "$TMPD/sem-nossas" && ! grep -q 'WellSystem-IPoE-Alias' "$ALVO"; then
    ok 'nome IPoE: este FreeRADIUS ja tem regra propria de SRouter-IPoE-Alias (ex.: MK-Auth) — nao foi tocado'
    exit 0
fi

# ---- 4) dicionário do SRouter -------------------------------------------------------------------
FRS="${WS_FR_SHARE:-/usr/share/freeradius}"
DIC="$FRS/dictionary"
DIC_MUDOU=0
if ! grep -rqs 'SRouter-IPoE-Alias' "$FRS" "$FR/dictionary" 2>/dev/null; then
    if [ -f "$PASTA/freeradius/dictionary.srouter" ] && [ -f "$DIC" ]; then
        cp -f "$PASTA/freeradius/dictionary.srouter" "$FRS/dictionary.srouter"
        grep -q 'dictionary.srouter' "$DIC" || echo '$INCLUDE dictionary.srouter' >> "$DIC"
        DIC_MUDOU=1
        ok 'dicionario SRouter instalado'
    else
        aviso 'dicionario SRouter ausente e sem copia no pacote (freeradius/dictionary.srouter) — nada alterado'
        exit 1
    fi
fi

# ---- 5) monta o arquivo novo --------------------------------------------------------------------
cat > "$TMPD/bloco" <<BLOCO
	# >>> WellSystem-IPoE-Alias — inicio (mantido por ws-radius-alias.sh; nao editar entre as marcas)
	#  IPoE: o concentrador exibe o NOME RESUMIDO do cadastro no lugar do ID. PPPoE nao entra aqui.
	#  Consulta com o nome do banco: o modulo sql conecta no banco do RADIUS, nao no do WellSystem.
	if (NAS-Port-Type == Ethernet) {
		update control {
			&Tmp-String-1 := "%{sql:$(consulta '%{User-Name}')}"
		}
		if ("%{control:Tmp-String-1}" != "") {
			update reply {
				&SRouter-IPoE-Alias := "%{tolower:%{control:Tmp-String-1}}"
			}
		}
	}
	# <<< WellSystem-IPoE-Alias — fim
BLOCO

# Remove a regra antiga (sem marca de fim: comentário + "if (NAS-Port-Type ...) { ... }" inteiro)
# e a atual (entre as marcas), e insere a nova logo na abertura do post-auth.
# Se o trecho depois da marca antiga não for o esperado, NADA é gravado (sai com 4).
awk -v arq="$TMPD/bloco" '
    function saldo(s,   a, b) { a = gsub(/\{/, "", s); b = gsub(/\}/, "", s); return a - b }
    BEGIN { while ((getline l < arq) > 0) bloco = bloco l "\n" }
    /# >>> WellSystem-IPoE-Alias/ { nova = 1; next }
    nova { if ($0 ~ /# <<< WellSystem-IPoE-Alias/) nova = 0; next }
    /WellSystem-IPoE-Alias/ { antiga = 1; prof = 0; dentro = 0; next }
    antiga {
        if (!dentro) {
            if ($0 ~ /^[[:space:]]*(#.*)?$/) next
            if ($0 !~ /^[[:space:]]*if[[:space:]]*\([[:space:]]*NAS-Port-Type/) { erro = 1; exit 4 }
            dentro = 1
        }
        prof += saldo($0)
        if (prof <= 0) antiga = 0
        next
    }
    /^post-auth[[:space:]]*\{/ && !feito { print; printf "%s", bloco; feito = 1; next }
    { print }
    END { if (erro) exit 4; if (nova || antiga) exit 5; if (!feito) exit 3 }
' "$ALVO" > "$TMPD/novo"
RC=$?
case $RC in
    0) ;;
    3) aviso "secao post-auth nao encontrada em $ALVO — nada alterado"; exit 1 ;;
    4) aviso "regra antiga com formato inesperado em $ALVO — nada alterado (confira manualmente)"; exit 1 ;;
    *) aviso "nao consegui montar o arquivo novo (codigo $RC) — nada alterado"; exit 1 ;;
esac

if cmp -s "$TMPD/novo" "$ALVO" && [ "$DIC_MUDOU" = 0 ]; then
    ok 'nome IPoE: regra ja esta atualizada no FreeRADIUS'
else
    # ---- 6) grava com cópia, valida, e volta sozinho se algo falhar ----------------------------
    BK="${WS_FR_BACKUP:-/var/backups/wellsystem/freeradius}"
    mkdir -p "$BK" && chmod 700 "$BK"
    COPIA="$BK/default.$(date +%Y%m%d-%H%M%S)"
    cp -a "$ALVO" "$COPIA"
    ls -1t "$BK"/default.* 2>/dev/null | tail -n +11 | xargs -r rm -f     # guarda as 10 últimas
    cat "$TMPD/novo" > "$ALVO"                                            # mantém dono, permissão e link

    if ! "$RADBIN" -CX > "$TMPD/check.log" 2>&1; then
        cat "$COPIA" > "$ALVO"
        aviso 'a configuracao nova nao passou no teste do FreeRADIUS — arquivo original restaurado. Erro:'
        tail -15 "$TMPD/check.log" >&2
        exit 1
    fi
    ok "nome IPoE: regra atualizada (copia do original: $COPIA)"

    if [ "$REINICIAR" = 1 ]; then
        reiniciar() {
            if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q '^freeradius\.service'; then
                systemctl restart freeradius; sleep 2; systemctl is-active --quiet freeradius
            else
                service freeradius restart >/dev/null 2>&1; sleep 2; pgrep -x 'freeradius|radiusd' >/dev/null
            fi
        }
        if reiniciar; then
            ok 'FreeRADIUS reiniciado — o nome aparece a cada nova autenticacao IPoE'
        else
            cat "$COPIA" > "$ALVO"; reiniciar
            aviso 'o FreeRADIUS nao subiu com a regra nova — original restaurado e servico reiniciado'
            exit 1
        fi
    fi
fi

# ---- 7) permissão de leitura do cadastro para o usuário do RADIUS -------------------------------
# A consulta roda como o usuário do módulo sql. Sem SELECT nas duas tabelas ela volta vazia (o
# cliente autentica, só não aparece o nome). Só SELECT, e só nestas duas.
if [ -n "$SQL_USER" ] && command -v mysql >/dev/null 2>&1; then
    if mysql_radius -e "SELECT 1 FROM $BANCO.ws_contrato ct JOIN $BANCO.ws_cliente c ON c.id = ct.cliente_id LIMIT 1" >/dev/null 2>&1; then
        ok "permissao de leitura do cadastro para '$SQL_USER': ok"
    elif mysql -N -B -e 'SELECT 1' >/dev/null 2>&1 && printf '%s' "$SQL_USER" | grep -Eq '^[A-Za-z0-9_.-]{1,80}$'; then
        mysql -N -B -e "SELECT Host FROM mysql.user WHERE User='$SQL_USER'" 2>/dev/null | while IFS= read -r H; do
            printf '%s' "$H" | grep -Eq '^[A-Za-z0-9_.%:-]{1,255}$' || continue
            mysql -e "GRANT SELECT ON \`$BANCO\`.ws_cliente TO '$SQL_USER'@'$H'; GRANT SELECT ON \`$BANCO\`.ws_contrato TO '$SQL_USER'@'$H';" 2>/dev/null
        done
        mysql -e 'FLUSH PRIVILEGES' 2>/dev/null
        if mysql_radius -e "SELECT 1 FROM $BANCO.ws_contrato LIMIT 1" >/dev/null 2>&1; then
            ok "permissao de leitura do cadastro concedida a '$SQL_USER'"
        else
            aviso "o usuario '$SQL_USER' do RADIUS nao consegue ler $BANCO.ws_cliente/ws_contrato — o nome nao sera enviado"
        fi
    else
        aviso "o usuario '$SQL_USER' do RADIUS nao consegue ler $BANCO.ws_cliente/ws_contrato — o nome nao sera enviado"
    fi
fi
exit 0
