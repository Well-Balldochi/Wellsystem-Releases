#!/bin/bash
# =================================================================================================
# WellSystem — MODO CONTINGÊNCIA do RADIUS ("se o banco cair, ninguém fica sem internet").
#
#     ws-radius-fallback.sh on <megas>     ex.: ws-radius-fallback.sh on 300
#     ws-radius-fallback.sh off
#     ws-radius-fallback.sh status
#
# Chamado pela tela Manutenção → Contingência do RADIUS, via sudo. Vive fora da pasta web e só o
# root o altera; o www-data apenas o executa, com os argumentos validados abaixo.
#
# O QUE ELE FAZ, EXATAMENTE
# Acrescenta ao site "default" do FreeRADIUS uma regra que só age quando a CONSULTA AO BANCO
# FALHA (módulo sql devolvendo "fail" — banco parado, rede caída, disco cheio). Nesse caso, e só
# nesse, o pedido é aceito com a velocidade escolhida.
#
# O QUE ELE NÃO FAZ
# Não aceita quem o banco RECUSOU: se o MySQL responde e diz que a senha está errada, a resposta
# continua sendo recusa. "Banco fora" e "cliente inválido" são situações diferentes, e só a
# primeira aciona a contingência.
#
# O PREÇO, QUE PRECISA SER DITO
# Enquanto a contingência está agindo (ou seja, com o banco realmente fora), o FreeRADIUS não tem
# como conferir senha nenhuma — então QUALQUER usuário e senha entram, inclusive de quem não é
# cliente. É uma troca consciente: numa queda de banco, é melhor a cidade inteira navegando por
# alguns minutos do que a cidade inteira offline. Passada a queda, tudo volta a ser conferido.
# =================================================================================================
set -e

ACAO="$1"
MEGAS="$2"

if   [ -d /etc/freeradius/3.0 ]; then FR=/etc/freeradius/3.0
elif [ -d /etc/freeradius ];     then FR=/etc/freeradius
else echo "ERRO: FreeRADIUS nao encontrado neste servidor."; exit 1; fi

SITE="$FR/sites-enabled/default"
[ -f "$SITE" ] || { echo "ERRO: $SITE nao existe."; exit 1; }

INI='#### WS-CONTINGENCIA-INI ####'
FIM='#### WS-CONTINGENCIA-FIM ####'

remover() {
    # Tira o bloco anterior, se houver. Feito sempre antes de ligar, para não empilhar regras.
    if grep -q "$INI" "$SITE"; then
        sed -i "/$INI/,/$FIM/d" "$SITE"
    fi
}

case "$ACAO" in
  status)
    if grep -q "$INI" "$SITE"; then
        V=$(grep -A6 "$INI" "$SITE" | grep -oE '[0-9]+k/[0-9]+k' | head -1)
        echo "LIGADA ${V:-?}"
    else
        echo "DESLIGADA"
    fi
    exit 0
    ;;

  off)
    remover
    ;;

  on)
    # Só número, entre 1 e 10000 Mbps. É o que impede um valor hostil de virar linha de configuração.
    echo "$MEGAS" | grep -qE '^[0-9]{1,5}$' || { echo "ERRO: velocidade invalida: $MEGAS"; exit 1; }
    [ "$MEGAS" -ge 1 ] && [ "$MEGAS" -le 10000 ] || { echo "ERRO: velocidade fora da faixa (1 a 10000)."; exit 1; }
    KBPS=$((MEGAS * 1000))

    remover

    # Inserido logo APÓS a chamada do sql no authorize — é ali que se sabe se a consulta falhou.
    awk -v kbps="$KBPS" -v ini="$INI" -v fim="$FIM" '
        BEGIN { feito = 0 }
        {
            print
            # Primeira linha que é exatamente "sql" (dentro do authorize), e só a primeira.
            if (!feito && $0 ~ /^[[:space:]]*sql[[:space:]]*$/) {
                print "\t" ini
                print "\t#  Contingencia do WellSystem: age SOMENTE quando a consulta ao banco FALHA"
                print "\t#  (banco parado, rede caida). Cliente recusado pelo banco continua recusado."
                print "\t#  Gerado por ws-radius-fallback.sh — nao editar a mao."
                print "\tif (fail) {"
                print "\t\tupdate control {"
                print "\t\t\t&Auth-Type := Accept"
                print "\t\t}"
                print "\t\tupdate reply {"
                print "\t\t\t&Mikrotik-Rate-Limit := \"" kbps "k/" kbps "k\""
                print "\t\t}"
                print "\t}"
                print "\t" fim
                feito = 1
            }
        }
    ' "$SITE" > /tmp/ws-site.novo && mv /tmp/ws-site.novo "$SITE"

    grep -q "$INI" "$SITE" || { echo "ERRO: nao encontrei onde inserir (o site default nao tem o modulo sql ativo)."; exit 1; }
    ;;

  *)
    echo "uso: ws-radius-fallback.sh on <megas> | off | status"; exit 1
    ;;
esac

# Valida ANTES de reiniciar: configuração quebrada derruba a autenticação inteira, e aí o
# remédio teria sido pior que a doença.
if ! freeradius -CX >/tmp/ws-fr-check.log 2>&1; then
    echo "ERRO na configuracao — a contingencia foi desfeita:"
    tail -12 /tmp/ws-fr-check.log
    remover
    systemctl restart freeradius 2>/dev/null || true
    exit 1
fi

systemctl restart freeradius
echo "PRONTO"
