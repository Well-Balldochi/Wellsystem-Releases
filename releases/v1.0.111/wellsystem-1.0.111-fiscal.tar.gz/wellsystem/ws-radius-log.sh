#!/bin/bash
# =================================================================================================
# WellSystem — LOG DE AUTENTICAÇÃO DO FREERADIUS SEMPRE LIGADO
#
# O PROBLEMA
#   O FreeRADIUS vem com "auth = no": nenhuma autenticação vai para o radius.log. Quando um cliente
#   (PPPoE ou IPoE) não conecta, não há como saber se o pedido chegou ao RADIUS, se foi aceito ou
#   recusado, nem por quê. O diagnóstico ficava no escuro.
#
# O QUE ESTE ARQUIVO FAZ
#   No bloco log { } do radiusd.conf deixa:
#     auth          = yes   -> cada "Login OK" / "Login incorrect (motivo)" com login e MAC (cli ...)
#     auth_badpass  = no    -> NÃO grava a senha errada digitada (seria senha em texto no log)
#     auth_goodpass = no    -> NÃO grava a senha certa (idem)
#   O log fica em /var/log/freeradius/radius.log; o logrotate do pacote já gira diário e comprime.
#
# SEGURANÇA — nada aqui pode derrubar autenticação
#   · cópia do radiusd.conf antes de mexer (/var/backups/wellsystem/freeradius);
#   · "freeradius -CX" valida; falhou = o original volta sozinho;
#   · reiniciou e não subiu = o original volta e o serviço sobe de novo;
#   · já está ligado = não reinicia nada.
#
# USO
#   bash ws-radius-log.sh                  liga e reinicia se mudou
#   bash ws-radius-log.sh --sem-reiniciar  grava e valida, sem reiniciar (usado pelo INSTALAR)
#   bash ws-radius-log.sh --auto           só age se este FreeRADIUS é do WellSystem (não MK-Auth)
# =================================================================================================
set -u

AUTO=0; REINICIAR=1
while [ $# -gt 0 ]; do
    case "$1" in
        --auto)          AUTO=1 ;;
        --sem-reiniciar) REINICIAR=0 ;;
        -h|--help)       sed -n '2,27p' "$0"; exit 0 ;;
        *)               echo "opcao desconhecida: $1 (veja --help)" >&2; exit 2 ;;
    esac
    shift
done

ok()   { echo "    $*"; }
aviso(){ echo "    AVISO: $*" >&2; }

# ---- 1) FreeRADIUS local ------------------------------------------------------------------------
FR=""
for d in ${WS_FR_DIR:-} /etc/freeradius/3.0 /etc/freeradius /etc/raddb; do
    [ -f "$d/radiusd.conf" ] && { FR="$d"; break; }
done
if [ -z "$FR" ]; then ok 'log de autenticacao: sem FreeRADIUS neste servidor — nada a fazer'; exit 0; fi
RADBIN=""
for c in ${WS_RADBIN:-} freeradius radiusd /usr/sbin/freeradius /usr/sbin/radiusd; do
    command -v "$c" >/dev/null 2>&1 && { RADBIN="$(command -v "$c")"; break; }
done
[ -n "$RADBIN" ] || { aviso 'binario do FreeRADIUS nao encontrado — nada alterado'; exit 0; }

# MK-Auth tem o RADIUS dele: não mexemos.
if [ -d /opt/mk-auth ] && [ "$AUTO" = 1 ]; then
    ok 'log de autenticacao: FreeRADIUS do MK-Auth — nao alterado'
    exit 0
fi

ALVO="$(readlink -f "$FR/radiusd.conf")"

# ---- 2) monta o arquivo novo: só dentro do bloco "log {" ----------------------------------------
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
awk '
    /^log[[:space:]]*\{/ { dentro = 1; achou = 1; print; next }
    dentro && /^\}/ {
        if (!a)  print "\tauth = yes"
        if (!bp) print "\tauth_badpass = no"
        if (!gp) print "\tauth_goodpass = no"
        dentro = 0; print; next
    }
    dentro && /^[[:space:]]*auth[[:space:]]*=/          { sub(/=.*/, "= yes"); a = 1 }
    dentro && /^[[:space:]]*auth_badpass[[:space:]]*=/  { sub(/=.*/, "= no");  bp = 1 }
    dentro && /^[[:space:]]*auth_goodpass[[:space:]]*=/ { sub(/=.*/, "= no");  gp = 1 }
    { print }
    END { if (!achou) exit 3; if (dentro) exit 5 }
' "$ALVO" > "$TMPD/novo"
RC=$?
case $RC in
    0) ;;
    3) aviso "bloco log { } nao encontrado em $ALVO — nada alterado"; exit 1 ;;
    *) aviso "nao consegui montar o arquivo novo (codigo $RC) — nada alterado"; exit 1 ;;
esac

if cmp -s "$TMPD/novo" "$ALVO"; then
    ok 'log de autenticacao do FreeRADIUS: ja esta ligado'
    exit 0
fi

# ---- 3) grava com cópia, valida, e volta sozinho se algo falhar ---------------------------------
BK="${WS_FR_BACKUP:-/var/backups/wellsystem/freeradius}"
mkdir -p "$BK" && chmod 700 "$BK"
COPIA="$BK/radiusd.conf.$(date +%Y%m%d-%H%M%S).log"
cp -a "$ALVO" "$COPIA"
ls -1t "$BK"/radiusd.conf.*.log 2>/dev/null | tail -n +11 | xargs -r rm -f
cat "$TMPD/novo" > "$ALVO"

if ! "$RADBIN" -CX > "$TMPD/check.log" 2>&1; then
    cat "$COPIA" > "$ALVO"
    aviso 'a configuracao nova nao passou no teste do FreeRADIUS — arquivo original restaurado. Erro:'
    tail -15 "$TMPD/check.log" >&2
    exit 1
fi
ok "log de autenticacao ligado (auth = yes, sem senhas no log; copia do original: $COPIA)"

if [ "$REINICIAR" = 1 ]; then
    reiniciar() {
        if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q '^freeradius\.service'; then
            systemctl restart freeradius; sleep 2; systemctl is-active --quiet freeradius
        else
            service freeradius restart >/dev/null 2>&1; sleep 2; pgrep -x 'freeradius|radiusd' >/dev/null
        fi
    }
    if reiniciar; then
        ok 'FreeRADIUS reiniciado — autenticacoes aparecem em /var/log/freeradius/radius.log'
    else
        cat "$COPIA" > "$ALVO"; reiniciar
        aviso 'o FreeRADIUS nao subiu com o log ligado — original restaurado e servico reiniciado'
        exit 1
    fi
fi
exit 0
