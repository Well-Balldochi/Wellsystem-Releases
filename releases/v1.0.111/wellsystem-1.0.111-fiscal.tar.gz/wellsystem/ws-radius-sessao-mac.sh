#!/bin/bash
# =================================================================================================
# WellSystem — SESSÃO PRESA DO MESMO EQUIPAMENTO (MAC): reconectar não pode ser recusado.
#
# O PROBLEMA, como aparece no provedor
#   O cliente cai (queda de energia, reboot do roteador, oscilação do enlace) e o concentrador não
#   manda o Accounting-Stop. A linha da sessão fica ABERTA no radacct. Quando o MESMO equipamento
#   volta, o FreeRADIUS conta aquela sessão aberta e, com "1 conexão por cliente"
#   (Simultaneous-Use), RECUSA o cliente legítimo: "já está conectado". Ele fica fora do ar até
#   alguém derrubar a sessão na mão ou o cron limpar — pode levar minutos ou horas.
#
# A REGRA QUE ESTE ARQUIVO INSTALA (no authorize, ANTES da contagem de sessões)
#   Chegou autenticação com Calling-Station-Id (o MAC do equipamento do cliente):
#     · se existir sessão ABERTA do MESMO login com o MESMO MAC, ela é FECHADA na hora, com
#       acctterminatecause = 'Ws-Mesmo-MAC' e hora de término no último sinal de vida;
#     · a autenticação segue normalmente e o cliente entra — em vez de ser recusado.
#   Mesmo MAC = mesmo equipamento voltando. Não é uma segunda conexão: é a mesma, reconectando.
#
# O QUE ELA NÃO FAZ, de propósito
#   · Não toca em sessão de OUTRO MAC: duas conexões de equipamentos diferentes continuam contando,
#     e o limite de 1 conexão por cliente segue valendo como antes.
#   · Não altera senha, plano, bloqueio nem velocidade. Só fecha a linha órfã daquele equipamento.
#   · Login ou MAC fora do formato esperado: a regra não roda (nada é consultado com valor estranho).
#
# SEGURANÇA DA CONEXÃO — nada aqui pode derrubar autenticação
#   · cópia do arquivo antes de mexer (/var/backups/wellsystem/freeradius);
#   · "freeradius -CX" valida; falhou = o original volta sozinho;
#   · reiniciou e não subiu = o original volta e o serviço sobe de novo;
#   · já atualizado = não reinicia nada.
#
# USO
#   bash ws-radius-sessao-mac.sh                 instala/atualiza e reinicia se mudou
#   bash ws-radius-sessao-mac.sh --sem-reiniciar grava e valida, sem reiniciar (usado pelo INSTALAR)
#   bash ws-radius-sessao-mac.sh --auto          só age se este FreeRADIUS é do WellSystem
# =================================================================================================
set -u

AUTO=0; REINICIAR=1
while [ $# -gt 0 ]; do
    case "$1" in
        --auto)          AUTO=1 ;;
        --sem-reiniciar) REINICIAR=0 ;;
        -h|--help)       sed -n '2,36p' "$0"; exit 0 ;;
        *)               echo "opcao desconhecida: $1 (veja --help)" >&2; exit 2 ;;
    esac
    shift
done

ok()   { echo "    $*"; }
aviso(){ echo "    AVISO: $*" >&2; }

# ---- 1) FreeRADIUS local ------------------------------------------------------------------------
FR=""
for d in ${WS_FR_DIR:-} /etc/freeradius/3.0 /etc/freeradius /etc/raddb; do
    [ -f "$d/radiusd.conf" ] && { FR="$d"; break; }
done
if [ -z "$FR" ]; then ok 'sessao presa: sem FreeRADIUS neste servidor — nada a fazer'; exit 0; fi
RADBIN=""
for c in ${WS_RADBIN:-} freeradius radiusd /usr/sbin/freeradius /usr/sbin/radiusd; do
    command -v "$c" >/dev/null 2>&1 && { RADBIN="$(command -v "$c")"; break; }
done
[ -n "$RADBIN" ] || { aviso 'binario do FreeRADIUS nao encontrado — nada alterado'; exit 0; }

SITE="$FR/sites-enabled/default"
[ -e "$SITE" ] || { ok "sessao presa: $SITE nao existe — nada a fazer"; exit 0; }
ALVO="$(readlink -f "$SITE")"
SQLMOD="$FR/mods-enabled/sql"
[ -e "$SQLMOD" ] || { ok 'sessao presa: modulo sql desligado neste FreeRADIUS — nada a fazer'; exit 0; }

# MK-Auth tem o RADIUS dele, com as regras dele: não mexemos.
if [ -d /opt/mk-auth ] && [ "$AUTO" = 1 ]; then
    ok 'sessao presa: FreeRADIUS do MK-Auth — regra nao aplicada (o MK-Auth tem a dele)'
    exit 0
fi

# ---- 2) bloco da regra --------------------------------------------------------------------------
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
cat > "$TMPD/bloco" <<'BLOCO'
	# >>> WellSystem-Sessao-MAC — inicio (mantido por ws-radius-sessao-mac.sh; nao editar entre as marcas)
	#  Mesmo equipamento voltando (mesmo login + mesmo MAC) NAO pode ser recusado por causa de uma
	#  sessao que ficou aberta sem Accounting-Stop. Fecha a presa aqui, antes da contagem de sessoes.
	#  Sessao de OUTRO MAC nao e tocada: o limite de 1 conexao por cliente continua valendo.
	if (&Calling-Station-Id && "%{Calling-Station-Id}" =~ /^[0-9A-Fa-f:.-]{6,32}$/) {
		if (&User-Name && "%{User-Name}" =~ /^[0-9A-Za-z._@-]{1,64}$/) {
			update control {
				&Tmp-String-2 := "%{sql:UPDATE radacct SET acctstoptime = COALESCE(acctupdatetime, acctstarttime), acctterminatecause = 'Ws-Mesmo-MAC', acctsessiontime = COALESCE(acctsessiontime, TIMESTAMPDIFF(SECOND, acctstarttime, COALESCE(acctupdatetime, acctstarttime))) WHERE acctstoptime IS NULL AND username = '%{User-Name}' AND callingstationid = '%{Calling-Station-Id}'}"
			}
		}
	}
	# <<< WellSystem-Sessao-MAC — fim
BLOCO

# ---- 3) monta o arquivo novo (troca a regra antiga; insere na abertura do authorize) -------------
awk -v arq="$TMPD/bloco" '
    BEGIN { while ((getline l < arq) > 0) bloco = bloco l "\n" }
    /# >>> WellSystem-Sessao-MAC/ { dentro = 1; next }
    dentro { if ($0 ~ /# <<< WellSystem-Sessao-MAC/) dentro = 0; next }
    /^authorize[[:space:]]*\{/ && !feito { print; printf "%s", bloco; feito = 1; next }
    { print }
    END { if (dentro) exit 5; if (!feito) exit 3 }
' "$ALVO" > "$TMPD/novo"
RC=$?
case $RC in
    0) ;;
    3) aviso "secao authorize nao encontrada em $ALVO — nada alterado"; exit 1 ;;
    *) aviso "nao consegui montar o arquivo novo (codigo $RC) — nada alterado"; exit 1 ;;
esac

if cmp -s "$TMPD/novo" "$ALVO"; then
    ok 'sessao presa do mesmo MAC: regra ja esta atualizada no FreeRADIUS'
    exit 0
fi

# ---- 4) grava com cópia, valida, e volta sozinho se algo falhar ---------------------------------
BK="${WS_FR_BACKUP:-/var/backups/wellsystem/freeradius}"
mkdir -p "$BK" && chmod 700 "$BK"
COPIA="$BK/default.$(date +%Y%m%d-%H%M%S).mac"
cp -a "$ALVO" "$COPIA"
ls -1t "$BK"/default.*.mac 2>/dev/null | tail -n +11 | xargs -r rm -f
cat "$TMPD/novo" > "$ALVO"

if ! "$RADBIN" -CX > "$TMPD/check.log" 2>&1; then
    cat "$COPIA" > "$ALVO"
    aviso 'a configuracao nova nao passou no teste do FreeRADIUS — arquivo original restaurado. Erro:'
    tail -15 "$TMPD/check.log" >&2
    exit 1
fi
ok "sessao presa do mesmo MAC: regra instalada (copia do original: $COPIA)"

if [ "$REINICIAR" = 1 ]; then
    reiniciar() {
        if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q '^freeradius\.service'; then
            systemctl restart freeradius; sleep 2; systemctl is-active --quiet freeradius
        else
            service freeradius restart >/dev/null 2>&1; sleep 2; pgrep -x 'freeradius|radiusd' >/dev/null
        fi
    }
    if reiniciar; then
        ok 'FreeRADIUS reiniciado — reconexao do mesmo equipamento deixa de ser recusada'
    else
        cat "$COPIA" > "$ALVO"; reiniciar
        aviso 'o FreeRADIUS nao subiu com a regra nova — original restaurado e servico reiniciado'
        exit 1
    fi
fi
exit 0
