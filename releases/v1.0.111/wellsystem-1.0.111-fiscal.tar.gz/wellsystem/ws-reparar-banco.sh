#!/bin/bash
# =================================================================================================
# WellSystem — REPARA O BANCO DE DADOS de uma instalação que já está no servidor.
#
#     bash /pasta/do/wellsystem/ws-reparar-banco.sh
#
# Use quando o navegador mostrar "Não consegui abrir o banco de dados sozinho" (a própria tela
# mostra este comando já com o caminho certo). Serve para os dois cenários:
#   - servidor direto (/var/www/wellsystem)
#   - addon (MK-Auth ou outro ERP)
#
# O que faz — sem tocar em Apache, PHP-FPM, FreeRADIUS nem cron:
#   1. acha a conta de administrador do banco deste servidor (debian.cnf ou root do sistema)
#   2. cria o banco e o usuário próprio do WellSystem se faltarem (localhost e 127.0.0.1)
#   3. usa a senha que a instalação já tinha; se nenhuma entra, define uma nova para a conta do
#      WellSystem e grava em todas as instalações dele neste servidor
#   4. grava a configuração do banco (cache/ e /var/lib/wellsystem) e cria as tabelas que faltarem
# Nenhum dado é apagado. Pode rodar quantas vezes quiser.
#
# É o mesmo motor do ws-instalar-addon.sh, apontado para a pasta onde ESTE arquivo está.
# =================================================================================================
AQUI="$(cd "$(dirname "$0")" && pwd -P)"
[ "$(id -u)" = "0" ] || { echo "ERRO: rode como root" >&2; exit 1; }
[ -f "$AQUI/ws-instalar-addon.sh" ] || { echo "ERRO: ws-instalar-addon.sh nao encontrado em $AQUI" >&2; exit 1; }
export WS_REPARO=1
# No MK-Auth o instalador já sabe a pasta do addon; em qualquer outro lugar, a pasta é esta.
case "$AQUI" in
    */opt/mk-auth/admin/addons/wellsystem) ;;
    */var/www/*) export WS_ADDON="$AQUI" WS_SISTEMA_ROTULO='servidor WellSystem' ;;
    *) export WS_ADDON="$AQUI" ;;
esac
exec bash "$AQUI/ws-instalar-addon.sh"
