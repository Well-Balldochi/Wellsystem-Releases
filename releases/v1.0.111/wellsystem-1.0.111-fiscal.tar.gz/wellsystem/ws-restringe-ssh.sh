#!/bin/bash
# WellSystem — limita a porta 22 (SSH) deste servidor a redes de confiança (31/10/2026).
# Uso (como root):  bash ws-restringe-ssh.sh <rede> [<rede> ...]      ex.: bash ws-restringe-ssh.sh 10.0.0.0/8 138.0.60.0/22 177.84.120.0/24
#       desfazer:   bash ws-restringe-ssh.sh --desfazer
# Cria a cadeia WS_SSH do iptables (aceita só as redes listadas na porta 22, descarta o resto), guarda a lista em /etc/ws-ssh-permitidos.conf
# e reaplica sozinho a cada boot (/etc/cron.d/ws-restringe-ssh). Pensado para servidor com SSH exposto à internet (ex.: MK-Auth, que recebe
# tentativas de senha de IPs do mundo todo). Antes de fechar a sessão, TESTE um novo acesso; o --desfazer devolve tudo como era.
set -u
[ "$(id -u)" = 0 ] || { echo "rode como root"; exit 1; }
CONF=/etc/ws-ssh-permitidos.conf; BIN=/usr/local/sbin/ws-restringe-ssh.sh; CRON=/etc/cron.d/ws-restringe-ssh
command -v iptables >/dev/null 2>&1 || { echo "iptables nao encontrado"; exit 1; }

limpar() { while iptables -D INPUT -p tcp --dport 22 -j WS_SSH 2>/dev/null; do :; done; iptables -F WS_SSH 2>/dev/null; iptables -X WS_SSH 2>/dev/null; }
aplicar() {
    limpar; iptables -N WS_SSH
    while read -r rede; do [ -n "$rede" ] && iptables -A WS_SSH -s "$rede" -j ACCEPT; done < "$CONF"
    iptables -A WS_SSH -j DROP
    iptables -I INPUT 1 -p tcp --dport 22 -j WS_SSH
}

case "${1:-}" in
    --desfazer) limpar; rm -f "$CONF" "$CRON"; echo "SSH liberado de novo (sem restricao)."; exit 0 ;;
    --aplicar)  [ -s "$CONF" ] && aplicar; exit 0 ;;
    "")         echo "uso: bash $0 <rede> [<rede> ...]   |   --desfazer"; exit 1 ;;
esac

: > "$CONF"
for r in "$@"; do
    [[ "$r" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$ ]] || { echo "rede invalida: $r"; rm -f "$CONF"; exit 1; }
    echo "$r" >> "$CONF"
done
echo "Sua sessao atual vem de: ${SSH_CLIENT%% *} — confira se esse IP esta numa das redes da lista (senao voce perde o acesso ao fechar)."
[ "$0" != "$BIN" ] && install -m 750 "$0" "$BIN"
printf '@reboot root %s --aplicar >/dev/null 2>&1\n' "$BIN" > "$CRON"; chmod 644 "$CRON"
aplicar
echo "SSH (porta 22) agora so aceita: $(tr '\n' ' ' < "$CONF")"
