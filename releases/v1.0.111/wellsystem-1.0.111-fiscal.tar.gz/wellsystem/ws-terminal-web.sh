#!/bin/bash
# =================================================================================================
# WellSystem — MENU DO SERVIDOR NO NAVEGADOR (Provedor → Menu do servidor)
#
#     bash ws-terminal-web.sh [/var/www/wellsystem]
#
# Chamado pelo INSTALAR.sh e pelo ATUALIZAR.sh no cenário SERVIDOR. Pode rodar quantas vezes quiser.
#
# O QUE É: a MESMA tela do Menu WellSystem que abre no PuTTY, dentro do navegador. Quem desenha a tela
# é o ttyd (terminal web: pacote do sistema ou, onde não existe, binário oficial conferido por SHA-256),
# rodando o menu em modo web:
#   - pede a SENHA DO ROOT antes de abrir (3 tentativas);
#   - a opção 0 / Cancelar ENCERRA a tela — nunca libera o shell do root pela web.
#
# QUEM CHEGA ATÉ A TELA — três barreiras:
#   1. o ttyd escuta só na interface local (lo): de fora do servidor ninguém fala com ele direto;
#   2. o Apache só repassa /ws-terminal/ para quem tem o cookie de acesso gerado pela página do
#      sistema (menu_servidor.php), que exige operador ADMIN logado; o valor vale até a página ser
#      encerrada ou aberta de novo (arquivo /var/lib/wellsystem/terminal.token);
#   3. a senha do root, pedida pelo próprio menu.
#
# REDE DE SEGURANÇA: a configuração do Apache passa por "apache2ctl configtest" antes de valer; se
# não passar, é desfeita na hora. O pior caso é a tela não existir — nunca o site fora do ar.
# =================================================================================================

DESTINO="${1:-${WS_DESTINO:-/var/www/wellsystem}}"
PORTA=7681
BASE=/ws-terminal
TOKEN=/var/lib/wellsystem/terminal.token
UNIT=/etc/systemd/system/wellsystem-terminal.service
CONF_NOME=wellsystem-terminal
CONF="/etc/apache2/conf-available/${CONF_NOME}.conf"

aviso() { echo "    (menu do servidor no navegador: $*)"; }

[ "$(id -u)" = "0" ] || { aviso 'rode como root'; exit 0; }
[ -x /usr/local/sbin/wellsystem ] || { aviso 'menu de terminal nao instalado ainda'; exit 0; }
command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ] || { aviso 'sem systemd — nao aplicado'; exit 0; }
command -v apache2ctl >/dev/null 2>&1 && command -v a2enconf >/dev/null 2>&1 || { aviso 'sem Apache do Debian — nao aplicado'; exit 0; }

# ---- 1) ttyd ------------------------------------------------------------------------------------
# Primeiro o pacote do sistema (Debian 11+, Ubuntu 22.04+). Onde ele não existe — Ubuntu 20.04 e
# Debian 10 não têm ttyd nos repositórios — usa o binário OFICIAL do projeto (github.com/tsl0922/ttyd),
# versão fixa, conferido por SHA-256 fixo neste script: arquivo diferente em um único byte é descartado.
TTYD_VER=1.7.7
TTYD_LOCAL=/usr/local/lib/wellsystem/ttyd
LOG_APT=/var/log/wellsystem/ttyd-apt.log
mkdir -p /var/log/wellsystem
ttyd_oficial() {
    local arq sha tmp url
    case "$(uname -m)" in
        x86_64|amd64)  arq=ttyd.x86_64;  sha=8a217c968aba172e0dbf3f34447218dc015bc4d5e59bf51db2f2cd12b7be4f55 ;;
        aarch64|arm64) arq=ttyd.aarch64; sha=b38acadd89d1d396a0f5649aa52c539edbad07f4bc7348b27b4f4b7219dd4165 ;;
        *) aviso "arquitetura $(uname -m) sem binario oficial conferido — nao aplicado"; return 1 ;;
    esac
    if [ -x "$TTYD_LOCAL" ] && echo "$sha  $TTYD_LOCAL" | sha256sum -c --status 2>/dev/null; then return 0; fi
    url="https://github.com/tsl0922/ttyd/releases/download/$TTYD_VER/$arq"
    tmp="$(mktemp)"
    echo "    baixando o ttyd $TTYD_VER oficial ($arq)..."
    if command -v curl >/dev/null 2>&1; then curl -fsSL --max-time 180 -o "$tmp" "$url"
    elif command -v wget >/dev/null 2>&1; then wget -q -T 180 -O "$tmp" "$url"
    else aviso 'sem curl nem wget para baixar o ttyd — nao aplicado'; rm -f "$tmp"; return 1; fi \
        || { aviso "nao consegui baixar $url (sem internet?) — nao aplicado"; rm -f "$tmp"; return 1; }
    if ! echo "$sha  $tmp" | sha256sum -c --status 2>/dev/null; then
        aviso 'o arquivo baixado NAO confere com o SHA-256 oficial — descartado, nada instalado'
        rm -f "$tmp"; return 1
    fi
    mkdir -p "$(dirname "$TTYD_LOCAL")"
    install -m 755 "$tmp" "$TTYD_LOCAL"; rm -f "$tmp"
    echo "    ttyd $TTYD_VER oficial instalado em $TTYD_LOCAL (SHA-256 conferido)"
}
TTYD="$(command -v ttyd 2>/dev/null)"
if [ -z "$TTYD" ] && [ -x "$TTYD_LOCAL" ]; then TTYD="$TTYD_LOCAL"; fi
if [ -z "$TTYD" ]; then
    if DEBIAN_FRONTEND=noninteractive apt-get install -y -q ttyd > "$LOG_APT" 2>&1; then
        TTYD="$(command -v ttyd 2>/dev/null)"
    elif grep -qiE 'Unable to locate package|encontrar o pacote|has no installation candidate' "$LOG_APT"; then
        echo "    o pacote ttyd nao existe nos repositorios deste Linux — usando o binario oficial"
        ttyd_oficial && TTYD="$TTYD_LOCAL"
    else
        echo "    o apt falhou ao instalar o ttyd (detalhes em $LOG_APT):"
        tail -3 "$LOG_APT" | sed 's/^/        /'
        ttyd_oficial && TTYD="$TTYD_LOCAL"
    fi
fi
[ -n "$TTYD" ] || exit 0

# ---- 2) arquivo de acesso (a página do sistema grava; o Apache confere) -----------------------------
mkdir -p /var/lib/wellsystem
[ -f "$TOKEN" ] || : > "$TOKEN"
DONO="$(stat -c '%U:%G' "$DESTINO" 2>/dev/null)"; [ -n "$DONO" ] || DONO='www-data:www-data'
chown "$DONO" /var/lib/wellsystem "$TOKEN" 2>/dev/null; chmod 640 "$TOKEN"

# ---- 3) serviço ---------------------------------------------------------------------------------
# O pacote ttyd do Ubuntu liga o serviço DELE (ttyd.service, porta 7681, login do sistema) logo ao instalar — e ocupa a porta que o
# WellSystem usa (o serviço abaixo ficava em loop de erro). O serviço do pacote não é usado: desliga.
systemctl disable --now ttyd.service >/dev/null 2>&1 || true
# -W (escrita) só existe no ttyd 1.7+; no 1.6 a escrita já é o padrão.
ESCRITA=''; "$TTYD" --help 2>&1 | grep -q -- '--writable' && ESCRITA='-W'
cat > "$UNIT" <<UNIT
# Gerado por ws-terminal-web.sh — Menu WellSystem no navegador (Provedor → Menu do servidor).
[Unit]
Description=WellSystem - menu do servidor no navegador
After=network.target

[Service]
Environment=TERM=xterm-256color
Environment=LANG=C.UTF-8
ExecStart=$TTYD -i lo -p $PORTA -b $BASE -m 2 $ESCRITA -t titleFixed=WellSystem -t fontSize=15 /usr/local/sbin/wellsystem --web
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable wellsystem-terminal >/dev/null 2>&1
systemctl restart wellsystem-terminal
sleep 2   # dá tempo do serviço subir antes de conferir

# ---- 4) Apache: /ws-terminal/ → ttyd, só com o cookie de acesso ---------------------------------
a2enmod proxy proxy_http proxy_wstunnel >/dev/null 2>&1 || true
cat > "$CONF" <<APACHE
# Gerado por ws-terminal-web.sh — reescrito a cada atualizacao do WellSystem.
# WebSocket primeiro (mais especifico), depois as paginas do ttyd.
ProxyPass        $BASE/ws ws://127.0.0.1:$PORTA$BASE/ws
ProxyPass        $BASE/   http://127.0.0.1:$PORTA$BASE/
ProxyPassReverse $BASE/   http://127.0.0.1:$PORTA$BASE/
<Location $BASE>
    # So passa quem tem o cookie ws_term igual ao arquivo gravado pela pagina do sistema (admin logado).
    Require expr "%{HTTP_COOKIE} =~ /(?:^|; *)ws_term=([a-f0-9]{64})(?:;|\$)/ && \$1 == file('$TOKEN')"
</Location>
APACHE
a2enconf "$CONF_NOME" >/dev/null 2>&1 || true

if apache2ctl configtest >/dev/null 2>&1; then
    systemctl reload apache2 2>/dev/null || true
    if systemctl is-active --quiet wellsystem-terminal; then
        echo "    menu do servidor no navegador ativo (Provedor -> Menu do servidor)"
    else
        aviso 'servico wellsystem-terminal nao subiu — veja: journalctl -u wellsystem-terminal'
    fi
else
    a2disconf "$CONF_NOME" >/dev/null 2>&1 || true
    rm -f "$CONF"
    aviso 'a configuracao nao passou no teste do Apache e foi desfeita (o site segue normal)'
    apache2ctl configtest 2>&1 | head -5 | sed 's/^/        /'
fi
exit 0
