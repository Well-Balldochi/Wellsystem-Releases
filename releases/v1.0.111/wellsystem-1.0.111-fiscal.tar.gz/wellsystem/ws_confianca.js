/*
 * WellSystem — Modal ÚNICO de "Desbloqueio em confiança".
 *
 * Este arquivo é o componente compartilhado entre:
 *   - Menu Clientes / Todos os clientes (erp.php)         -> wsConfiar()
 *   - Ficha do cliente (erp.php, aba de contratos)        -> a.fic-conf
 *   - Menu Servidores / Painel dos Concentradores          -> servidores.php
 *     abre desbloqueio_obs.php num popup, que carrega este mesmo arquivo.
 *
 * Antes ele não existia no pacote — cada página tinha seu próprio jeito de
 * fazer a mesma coisa (uma ficava travada/em branco, a outra usava só um
 * <input type=date> simples). Agora é UM ÚNICO calendário, com o nome do
 * cliente sempre visível, igual em qualquer lugar do sistema.
 *
 * USO:
 *   wsAbrirModalConfianca({
 *     nome: 'Fulano de Tal',
 *     login: 'fulano',            // opcional
 *     plano: '100 MEGA',          // opcional
 *     jaEmConfiancaAte: '',       // 'dd/mm/aaaa' se já estiver em confiança, senão ''
 *     onConfirmar: function(dias, dataISO){ ... }
 *   });
 *
 * Retorna o elemento do overlay (pra quem chamar poder plugar mais listeners,
 * ex.: fechar o popup ao cancelar) ou null se os parâmetros forem inválidos.
 */
(function (global) {
    'use strict';

    // Atalhos rápidos — este é o padrão do sistema (mesmo conjunto em Clientes, Painel dos
    // Concentradores e Total Radius). NÃO alterar sem pedido: o operador usa 1 a 5 dias no
    // dia a dia, e 7/15/30 para prazos maiores.
    var DIAS_RAPIDOS = [1, 2, 3, 4, 5, 7, 15, 30];
    var MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    var DIAS_SEMANA = ['D','S','T','Q','Q','S','S'];

    function injetarEstilo() {
        if (document.getElementById('wsc-style')) return;
        var css = [
            // PALETA PRÓPRIA DO MODAL. Antes ele usava var(--surface)/var(--text)/var(--border)
            // da PÁGINA — e cada página define esses tokens de um jeito (o Painel dos
            // Concentradores tem --surface:#4a525a; o erp.php tem outro). Resultado: o MESMO
            // componente aparecia com cara diferente em cada tela. Agora as cores são do próprio
            // modal, então o calendário é idêntico em Clientes, Painel e Total Radius.
            ':root{--wsc-surface:#ffffff;--wsc-text:#1a1416;--wsc-border:#e6e2e3;--wsc-bg:#f8fafc;--wsc-muted:#6b6167}',
            '.wsc-overlay.wsc-dark{--wsc-surface:#1c2230;--wsc-text:#eef2f7;--wsc-border:#31394a;--wsc-bg:#151a24;--wsc-muted:#9aa4b5}',
            '.wsc-overlay{position:fixed;inset:0;background:rgba(20,10,12,.55);z-index:1000001;display:flex;',
            'align-items:center;justify-content:center;padding:16px;animation:wscFade .12s ease-out}',
            '@keyframes wscFade{from{opacity:0}to{opacity:1}}',
            '.wsc-card{background:var(--wsc-surface);color:var(--wsc-text);border:1px solid var(--wsc-border);',
            'border-radius:16px;box-shadow:0 18px 48px -14px rgba(0,0,0,.45);padding:22px;max-width:380px;',
            'width:100%;max-height:calc(100vh - 32px);overflow:auto;animation:wscPop .16s cubic-bezier(.2,.9,.3,1.2)}',
            '@keyframes wscPop{from{transform:translateY(6px) scale(.97);opacity:0}to{transform:none;opacity:1}}',
            '.wsc-titulo{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:17px;font-weight:800}',
            '.wsc-titulo .wsc-ico{width:30px;height:30px;border-radius:9px;background:rgba(147,51,234,.14);',
            'color:#9333ea;display:flex;align-items:center;justify-content:center;flex:0 0 auto;font-size:15px}',
            '.wsc-ficha{background:rgba(147,51,234,.08);border:1px solid rgba(147,51,234,.25);border-radius:10px;',
            'padding:9px 13px;margin:10px 0 12px;font-size:13.5px;line-height:1.55}',
            '.wsc-ficha b{color:#9333ea}',
            '.wsc-ja-conf{display:flex;gap:6px;margin-top:6px;font-size:12.5px;color:#9333ea;font-weight:700}',
            '.wsc-sub{margin:0 0 10px;font-size:12.5px;color:var(--wsc-muted)}',
            '.wsc-rapidos{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}',
            '.wsc-chip{border:1px solid var(--wsc-border);background:var(--wsc-bg);color:var(--wsc-text);',
            'border-radius:20px;padding:5px 12px;font-size:12.5px;font-weight:700;cursor:pointer;transition:.12s}',
            '.wsc-chip:hover{border-color:#9333ea;color:#9333ea}',
            '.wsc-chip.on{background:#9333ea;border-color:#9333ea;color:#fff}',
            '.wsc-cal{border:1px solid var(--wsc-border);border-radius:12px;padding:10px;margin-bottom:12px}',
            '.wsc-cal-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}',
            '.wsc-cal-head b{font-size:13.5px;text-transform:capitalize}',
            '.wsc-cal-nav{border:1px solid var(--wsc-border);background:transparent;color:var(--wsc-text);',
            'width:26px;height:26px;border-radius:7px;cursor:pointer;font-size:14px;line-height:1;',
            'display:inline-flex;align-items:center;justify-content:center}',
            '.wsc-cal-nav:hover{border-color:#9333ea;color:#9333ea}',
            '.wsc-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center}',
            '.wsc-cal-dow{font-size:10.5px;font-weight:800;color:var(--wsc-muted);padding:3px 0}',
            '.wsc-cal-day{border:none;background:transparent;color:var(--wsc-text);border-radius:8px;',
            'height:30px;font-size:12.5px;cursor:pointer;font-weight:600}',
            '.wsc-cal-day:hover:not(:disabled){background:rgba(147,51,234,.14)}',
            '.wsc-cal-day:disabled{opacity:.28;cursor:default}',
            '.wsc-cal-day.off{visibility:hidden}',
            '.wsc-cal-day.hoje{box-shadow:inset 0 0 0 1.5px #9333ea}',
            '.wsc-cal-day.sel{background:#9333ea!important;color:#fff!important;font-weight:800}',
            '.wsc-resumo{font-size:13px;margin-bottom:14px;padding:8px 12px;background:var(--wsc-bg);',
            'border-radius:9px;border:1px dashed var(--wsc-border)}',
            '.wsc-resumo b{color:#9333ea}',
            '.wsc-acoes{display:flex;gap:8px;justify-content:flex-end}',
            '.wsc-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 15px;border-radius:9px;',
            'border:1px solid var(--wsc-border);background:transparent;color:var(--wsc-text);',
            'font-size:13.5px;font-weight:700;cursor:pointer;transition:.12s}',
            '.wsc-btn:hover{border-color:var(--wsc-muted)}',
            '.wsc-btn.wsc-ok{background:linear-gradient(135deg,#9333ea,#7c22cf);border-color:transparent;color:#fff;',
            'box-shadow:0 4px 14px -6px rgba(147,51,234,.55)}',
            '.wsc-btn.wsc-ok:hover{filter:brightness(1.06)}',
            '.wsc-btn:disabled{opacity:.6;cursor:default;filter:none}',
            '@media(max-width:480px){.wsc-card{width:calc(100% - 8px);max-width:calc(100% - 8px);padding:16px}}'
        ].join('');
        var st = document.createElement('style');
        st.id = 'wsc-style';
        st.textContent = css;
        document.head.appendChild(st);
    }

    function pad2(n) { return n < 10 ? '0' + n : '' + n; }
    function toISO(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
    function fmtBR(d) { return pad2(d.getDate()) + '/' + pad2(d.getMonth() + 1) + '/' + d.getFullYear(); }
    function hoje0() { var h = new Date(); h.setHours(0, 0, 0, 0); return h; }
    function diffDias(a, b) { return Math.round((b - a) / 86400000); }

    /* O modal decide o PRÓPRIO tema, em vez de herdar tokens da página. Cada tela sinaliza
       "claro/escuro" de um jeito diferente (erp.php usa data-theme no <html>; o Painel dos
       Concentradores usa a classe .light-mode), e algumas não sinalizam nada — por isso o
       último critério é a luminância real do fundo, que funciona em qualquer página. */
    function hostEscuro() {
        var dt = document.documentElement.getAttribute('data-theme');
        if (dt === 'dark') return true;
        if (dt === 'light') return false;
        if (document.body.classList.contains('light-mode') ||
            document.documentElement.classList.contains('light-mode')) return false;
        try {
            var bg = getComputedStyle(document.body).backgroundColor || '';
            var m = bg.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
            if (m) {
                var lum = (0.2126 * +m[1] + 0.7152 * +m[2] + 0.0722 * +m[3]) / 255;
                return lum < 0.5;
            }
        } catch (e) {}
        return false;
    }

    function wsAbrirModalConfianca(opts) {
        opts = opts || {};
        var onConfirmar = typeof opts.onConfirmar === 'function' ? opts.onConfirmar : null;
        if (!onConfirmar) { return null; }

        injetarEstilo();

        var nome = String(opts.nome || '').trim() || 'Cliente';
        var login = String(opts.login || '').trim();
        var plano = String(opts.plano || '').trim();
        var jaAte = String(opts.jaEmConfiancaAte || '').trim();

        var HOJE = hoje0();
        /* PADRÃO DO SISTEMA: o calendário sempre ABRE em 1 dia de confiança (o valor vem de
           Configurações → Cobrança via window.WS_DIAS_CONFIANCA; sem ele, 1). Antes abria fixo
           em 3 dias, contradizendo a regra "1 dia de confiança". */
        var diasPadrao = Math.max(1, parseInt(global.WS_DIAS_CONFIANCA, 10) || 1);
        var selecionado = new Date(HOJE.getTime() + diasPadrao * 86400000);
        var mesVisto = new Date(selecionado.getFullYear(), selecionado.getMonth(), 1);

        var overlay = document.createElement('div');
        overlay.className = 'wsc-overlay' + (hostEscuro() ? ' wsc-dark' : '');
        overlay.innerHTML =
            '<div class="wsc-card" role="dialog" aria-modal="true" aria-label="Desbloqueio em confiança">' +
              '<h3 class="wsc-titulo"><span class="wsc-ico">🔒</span> Desbloqueio em confiança</h3>' +
              '<div class="wsc-ficha">' +
                '<div><b>Cliente:</b> <span id="wsc_nome"></span></div>' +
                (login ? '<div><b>Login:</b> <span id="wsc_login"></span></div>' : '') +
                (plano ? '<div><b>Plano:</b> <span id="wsc_plano"></span></div>' : '') +
                (jaAte ? '<div class="wsc-ja-conf">⚠️ <span>Já está em confiança até <b id="wsc_ja_ate"></b> — confirmar aqui substitui esse prazo.</span></div>' : '') +
              '</div>' +
              '<p class="wsc-sub">Escolha no calendário ou use um atalho rápido. Volta a bloquear sozinho ao vencer.</p>' +
              '<div class="wsc-rapidos" id="wsc_rapidos"></div>' +
              '<div class="wsc-cal">' +
                '<div class="wsc-cal-head">' +
                  '<button type="button" class="wsc-cal-nav" id="wsc_prev" aria-label="Mês anterior">‹</button>' +
                  '<b id="wsc_mes_lbl"></b>' +
                  '<button type="button" class="wsc-cal-nav" id="wsc_next" aria-label="Próximo mês">›</button>' +
                '</div>' +
                '<div class="wsc-cal-grid" id="wsc_dow"></div>' +
                '<div class="wsc-cal-grid" id="wsc_grid"></div>' +
              '</div>' +
              '<div class="wsc-resumo">Liberar até <b id="wsc_resumo_data"></b> <span id="wsc_resumo_dias"></span></div>' +
              '<div class="wsc-acoes">' +
                '<button type="button" class="wsc-btn" id="wsc_cancel">Cancelar</button>' +
                '<button type="button" class="wsc-btn wsc-ok" id="wsc_confirm">Confirmar</button>' +
              '</div>' +
            '</div>';
        document.body.appendChild(overlay);

        overlay.querySelector('#wsc_nome').textContent = nome;
        if (login) overlay.querySelector('#wsc_login').textContent = login;
        if (plano) overlay.querySelector('#wsc_plano').textContent = plano;
        if (jaAte) overlay.querySelector('#wsc_ja_ate').textContent = jaAte;

        var elRapidos = overlay.querySelector('#wsc_rapidos');
        DIAS_RAPIDOS.forEach(function (n) {
            var b = document.createElement('button');
            b.type = 'button'; b.className = 'wsc-chip'; b.dataset.dias = n;
            b.textContent = n + (n === 1 ? ' dia' : ' dias');
            b.addEventListener('click', function () {
                selecionarData(new Date(HOJE.getTime() + n * 86400000));
            });
            elRapidos.appendChild(b);
        });

        var elDow = overlay.querySelector('#wsc_dow');
        DIAS_SEMANA.forEach(function (d) {
            var s = document.createElement('div'); s.className = 'wsc-cal-dow'; s.textContent = d; elDow.appendChild(s);
        });

        function marcarChipAtivo() {
            var dias = diffDias(HOJE, selecionado);
            elRapidos.querySelectorAll('.wsc-chip').forEach(function (b) {
                b.classList.toggle('on', parseInt(b.dataset.dias, 10) === dias);
            });
        }

        function renderResumo() {
            overlay.querySelector('#wsc_resumo_data').textContent = fmtBR(selecionado);
            var dias = diffDias(HOJE, selecionado);
            overlay.querySelector('#wsc_resumo_dias').textContent =
                dias > 0 ? '(' + dias + (dias === 1 ? ' dia)' : ' dias)') : '(hoje)';
        }

        function renderGrid() {
            var grid = overlay.querySelector('#wsc_grid');
            grid.innerHTML = '';
            overlay.querySelector('#wsc_mes_lbl').textContent =
                MESES[mesVisto.getMonth()] + ' de ' + mesVisto.getFullYear();

            var primeiroDiaSemana = new Date(mesVisto.getFullYear(), mesVisto.getMonth(), 1).getDay();
            var totalDias = new Date(mesVisto.getFullYear(), mesVisto.getMonth() + 1, 0).getDate();

            for (var i = 0; i < primeiroDiaSemana; i++) {
                var vazio = document.createElement('span'); vazio.className = 'wsc-cal-day off'; grid.appendChild(vazio);
            }
            for (var d = 1; d <= totalDias; d++) {
                var dataCel = new Date(mesVisto.getFullYear(), mesVisto.getMonth(), d);
                var btn = document.createElement('button');
                btn.type = 'button'; btn.className = 'wsc-cal-day'; btn.textContent = d;
                if (dataCel.getTime() < HOJE.getTime()) btn.disabled = true;
                if (dataCel.getTime() === HOJE.getTime()) btn.classList.add('hoje');
                if (dataCel.getTime() === selecionado.getTime()) btn.classList.add('sel');
                (function (dc) { btn.addEventListener('click', function () { selecionarData(dc); }); })(dataCel);
                grid.appendChild(btn);
            }
        }

        function selecionarData(d) {
            d.setHours(0, 0, 0, 0);
            if (d.getTime() < HOJE.getTime()) d = new Date(HOJE.getTime());
            selecionado = d;
            mesVisto = new Date(d.getFullYear(), d.getMonth(), 1);
            renderGrid();
            renderResumo();
            marcarChipAtivo();
        }

        overlay.querySelector('#wsc_prev').addEventListener('click', function () {
            mesVisto = new Date(mesVisto.getFullYear(), mesVisto.getMonth() - 1, 1);
            renderGrid();
        });
        overlay.querySelector('#wsc_next').addEventListener('click', function () {
            mesVisto = new Date(mesVisto.getFullYear(), mesVisto.getMonth() + 1, 1);
            renderGrid();
        });

        function fechar() { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); document.removeEventListener('keydown', onEsc); }
        function onEsc(e) { if (e.key === 'Escape') fechar(); }
        document.addEventListener('keydown', onEsc);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) fechar(); });
        overlay.querySelector('#wsc_cancel').addEventListener('click', fechar);
        overlay.querySelector('#wsc_confirm').addEventListener('click', function () {
            var btn = overlay.querySelector('#wsc_confirm');
            btn.disabled = true; btn.textContent = 'Confirmando…';
            var dias = Math.max(1, diffDias(HOJE, selecionado));
            try { onConfirmar(dias, toISO(selecionado)); } finally { fechar(); }
        });

        renderGrid();
        renderResumo();
        marcarChipAtivo();

        return overlay;
    }

    /* =============================================================================================
     * FLUXO COMPLETO DO DESBLOQUEIO EM CONFIANÇA — use SEMPRE este, nunca o modal direto.
     *
     * wsAbrirModalConfianca() acima é só o calendário. Este wrapper é o COMPORTAMENTO do sistema:
     *   1. busca nome/plano/prazo atual do cliente (se não vierem prontos);
     *   2. se o cliente JÁ está em confiança, mostra os desbloqueios do mês e pede aceite antes
     *      de abrir um novo agendamento — a trava que evita empilhar desbloqueio sem querer;
     *   3. só então abre o calendário.
     *
     * POR QUE ESTÁ AQUI E NÃO EM CADA PÁGINA: a confirmação do passo 2 estava copiada dentro do
     * servidores.php (duas vezes) e não existia no erp.php. Resultado: o aviso aparecia no Total
     * Radius e não aparecia no Painel dos Concentradores nem em Clientes — a mesma ação com três
     * comportamentos diferentes. Regra geral do projeto: o que é comportamento COMPARTILHADO mora
     * no componente compartilhado; a página só diz o que fazer no "confirmar".
     *
     * USO:
     *   wsConfianca({
     *     login: 'fulano',            // usado para buscar ficha e histórico
     *     nome: 'FULANO',             // opcional: se já souber, evita uma requisição
     *     jaEmConfiancaAte: '',       // opcional: 'dd/mm/aaaa' se já souber
     *     onConfirmar: function (dias, dataISO) { ... }
     *   });
     * ========================================================================================== */
    var WSC_URL_INFO = 'servidores.php?acao=confianca_info';
    var WSC_URL_HIST = 'servidores.php?acao=confianca_hist';

    function wsConfianca(opts) {
        opts = opts || {};
        var login = String(opts.login || '').trim();
        var onConfirmar = typeof opts.onConfirmar === 'function' ? opts.onConfirmar : null;
        if (!onConfirmar) return;

        var urlInfo = opts.urlInfo || WSC_URL_INFO;
        var urlHist = opts.urlHist || WSC_URL_HIST;

        /* GANCHOS OPCIONAIS — quem não passa nenhum deles continua exatamente como antes.
         * Eles existem porque o popup desbloqueio_obs.php precisa de duas coisas que o fluxo
         * normal não dá:
         *   fichaLogin / fichaPlano  -> as linhas "Login" e "Plano" da ficha do modal, que
         *                               aquele popup sempre mostrou (ele já sabe os dois);
         *   onAbrirModal(modal)      -> o elemento do modal assim que ele abre. O aceite é
         *                               ASSÍNCRONO (busca o histórico do mês antes), então
         *                               wsConfianca não tem como devolver o modal no retorno —
         *                               quem precisa dele (o popup fecha a janela no Cancelar)
         *                               recebe por aqui;
         *   onCancelar()             -> o operador RECUSOU o aceite. Sem isso, o popup ficaria
         *                               uma janela vazia na tela depois do "Cancelar". */
        var onAbrirModal = typeof opts.onAbrirModal === 'function' ? opts.onAbrirModal : null;
        var onCancelar   = typeof opts.onCancelar   === 'function' ? opts.onCancelar   : null;

        function abrir(info) {
            var modal = wsAbrirModalConfianca({
                nome: info.nome || login || 'Cliente',
                login: String(opts.fichaLogin || '').trim(),
                plano: String(opts.fichaPlano || '').trim(),
                jaEmConfiancaAte: info.ate_br || '',
                onConfirmar: onConfirmar
            });
            if (onAbrirModal) onAbrirModal(modal);
        }
        function recusou() { if (onCancelar) onCancelar(); }

        // Passo 2: já está em confiança -> mostra o histórico do mês e pede aceite.
        function confirmarSeJa(info) {
            if (!info.ate_br) { abrir(info); return; }
            if (!login) {
                if (window.confirm('Este cliente JÁ está em confiança até ' + info.ate_br +
                                   '.\n\nConfirmar um NOVO desbloqueio em confiança? O prazo atual será substituído.')) abrir(info);
                else recusou();
                return;
            }
            fetch(urlHist + '&login=' + encodeURIComponent(login), { cache: 'no-store' })
                .then(function (r) { return r.json(); })
                .catch(function () { return null; })
                .then(function (d) {
                    var lst = (d && d.desbloqueios) || [];
                    var txt = 'Este cliente JÁ está em confiança até ' + info.ate_br + '.\n\n';
                    txt += 'Desbloqueios neste mês (' + ((d && d.mes) || '—') + '): ' + lst.length + '\n';
                    lst.forEach(function (h, i) { txt += (i + 1) + ') ' + (h.em || '') + '  →  até ' + (h.ate || '') + '\n'; });
                    txt += '\nConfirmar um NOVO desbloqueio em confiança? O prazo atual será substituído.';
                    if (window.confirm(txt)) abrir(info);
                    else recusou();
                });
        }

        // Passo 1: já veio pronto da página? Então não gasta requisição.
        if (opts.nome || opts.jaEmConfiancaAte) {
            confirmarSeJa({ nome: opts.nome || '', ate_br: opts.jaEmConfiancaAte || '' });
            return;
        }
        if (!login) { abrir({}); return; }
        fetch(urlInfo + '&login=' + encodeURIComponent(login), { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .catch(function () { return {}; })
            .then(function (info) { confirmarSeJa(info || {}); });
    }

    global.wsAbrirModalConfianca = wsAbrirModalConfianca;
    global.wsConfianca = wsConfianca;
})(window);
