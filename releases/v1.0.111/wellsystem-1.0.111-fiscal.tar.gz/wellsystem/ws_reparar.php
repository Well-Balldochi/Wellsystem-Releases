<?php
/**
 * WellSystem — REPARO DO SISTEMA (rotina ÚNICA).
 * =================================================================================================
 * Usada por DOIS lugares, que por isso fazem exatamente a mesma coisa:
 *   - Menu Manutenção (manutencao.php): botões "Verificar tabelas" e "Ressincronizar RADIUS";
 *   - Menu do servidor no PuTTY (WELLSYSTEM-MENU.sh), opção 6 "Reparar dados do sistema",
 *     que chama este arquivo pela linha de comando.
 * Antes o menu rodava install_cli.php e a Manutenção rodava outra sequência: cada um "reparava"
 * de um jeito, e o resultado não batia. Agora a regra mora aqui.
 *
 * Nada é apagado: só cria tabela/coluna que falta e reprovisiona o RADIUS a partir do cadastro.
 * Funciona com qualquer RADIUS configurado (o próprio do WellSystem ou o do MK-Auth), porque usa
 * as mesmas funções do sistema (ws_rad_sync_contrato / ws_rad_disconnect_muitos), que já
 * descobrem sozinhas onde gravar.
 *
 * CLI (menu do servidor):
 *   php ws_reparar.php                 → estrutura + RADIUS
 *   php ws_reparar.php --derrubar      → estrutura + RADIUS + derruba todas as conexões ativas
 * Saída em texto, uma linha por etapa, com "@@ <pct> <texto>" para a barra de progresso do menu.
 */

/** Estrutura do banco: tabelas do schema, migrações e auto-heal completo (sem a marca de "já feito"). */
function ws_reparar_estrutura(PDO $db): array {
    if (is_file(__DIR__ . '/schema.php')) require_once __DIR__ . '/schema.php';
    $c = 0; $erros = [];
    if (function_exists('ws_schema_sql')) {
        foreach (ws_schema_sql() as $sql) { try { $db->exec($sql); $c++; } catch (Throwable $e) { $erros[] = $e->getMessage(); } }
    }
    if (function_exists('ws_migracoes')) { try { ws_migracoes($db); } catch (Throwable $e) { $erros[] = $e->getMessage(); } }
    /* Apaga a marca ANTES do auto-heal: o ws_selfheal() pula a verificação quando já a fez para esta
       versão do código (é o que deixa as páginas rápidas). Quem pede REPARO quer a verificação
       inteira — sem apagar a marca, o reparo diria "verificado" sem ter verificado. */
    if (defined('WS_CACHE')) @unlink(WS_CACHE . '/schema_ok.json');
    if (function_exists('ws_selfheal')) { try { ws_selfheal($db); } catch (Throwable $e) { $erros[] = $e->getMessage(); } }
    return ['tabelas' => $c, 'erros' => $erros];
}

/** RADIUS: reprovisiona todo contrato não cancelado a partir do cadastro (senha, grupo, IP, bloqueio). */
function ws_reparar_radius(PDO $db): array {
    if (!function_exists('ws_rad_sync_contrato') && is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    if (!function_exists('ws_rad_sync_contrato')) return ['ok' => false, 'n' => 0, 'bloq' => 0, 'erro' => 'radius_lib.php não disponível'];
    $n = 0; $bloq = 0; $falhas = 0;
    foreach ($db->query("SELECT * FROM ws_contrato WHERE status<>'cancelado'")->fetchAll() as $ct) {
        try {
            $deve = function_exists('ws_rad_deve_bloquear') ? ws_rad_deve_bloquear($db, $ct) : ($ct['status'] !== 'ativo');
            ws_rad_sync_contrato($db, $ct, $deve); $n++; if ($deve) $bloq++;
        } catch (Throwable $e) { $falhas++; }
    }
    return ['ok' => true, 'n' => $n, 'bloq' => $bloq, 'falhas' => $falhas];
}

/** Derruba todas as conexões de contrato ativo (o cliente reconecta sozinho, já com o RADIUS corrigido).
 *  Mesmo critério do card "Derrubar conexões" da Manutenção com o filtro "Todos": lista pelo CADASTRO
 *  (PPPoE + IPoE), não pela radacct — que pode estar justamente desatualizada. */
function ws_reparar_derrubar(PDO $db): array {
    if (!function_exists('ws_rad_disconnect_muitos') && is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    $logins = [];
    foreach ($db->query("SELECT login_pppoe, login_ipoe FROM ws_contrato WHERE status<>'cancelado'
                         AND (COALESCE(login_pppoe,'')<>'' OR COALESCE(login_ipoe,'')<>'')")->fetchAll(PDO::FETCH_NUM) as $lr)
        foreach ($lr as $lg) if ((string)$lg !== '') $logins[] = (string)$lg;
    $logins = array_values(array_unique($logins));
    $n = function_exists('ws_rad_disconnect_muitos') ? (int)ws_rad_disconnect_muitos($db, $logins) : 0;
    return ['logins' => count($logins), 'derrubadas' => $n];
}

/* ------------------------------------------------------------------ linha de comando (menu) */
if (PHP_SAPI === 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === realpath(__FILE__)) {
    $derrubar = in_array('--derrubar', $argv, true);
    require __DIR__ . '/config.php';
    if (is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    try { $db = ws_db(); }
    catch (Throwable $e) { echo "ERRO: banco não abriu — ", $e->getMessage(), "\nRode a opção de reparo do banco (ws-reparar-banco.sh) e tente de novo.\n"; exit(1); }

    echo "@@ 20 Conferindo tabelas e colunas...\n=== estrutura do banco ===\n";
    $r = ws_reparar_estrutura($db);
    echo "{$r['tabelas']} tabela(s) conferidas + migrações + auto-heal. Só cria o que falta.\n";
    foreach (array_slice($r['erros'], 0, 5) as $er) echo "aviso: $er\n";

    echo "@@ 50 Reprovisionando o RADIUS...\n\n=== RADIUS ===\n";
    $rr = ws_reparar_radius($db);
    echo $rr['ok'] ? "{$rr['n']} contrato(s) reprovisionado(s), {$rr['bloq']} bloqueado(s) pela regra de inadimplência" . ($rr['falhas'] ? ", {$rr['falhas']} com falha" : '') . ".\n"
                   : "RADIUS: {$rr['erro']}\n";

    if ($derrubar) {
        echo "@@ 90 Derrubando as conexões...\n\n=== conexões ===\n";
        $rd = ws_reparar_derrubar($db);
        echo "{$rd['logins']} login(s) de contrato ativo, {$rd['derrubadas']} derrubada(s). O cliente reconecta sozinho.\n";
    }
    exit(0);
}
