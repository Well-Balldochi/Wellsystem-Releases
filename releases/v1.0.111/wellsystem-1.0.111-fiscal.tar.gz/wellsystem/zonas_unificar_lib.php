<?php
/**
 * WellSystem — UNIFICA zonas e bairros (16/10/2026). Biblioteca usada por zonas_unificar.php (CLI) e pelo zonas_sync.php (cron).
 *
 * O PROBLEMA
 *   Zona vinda da OLT/SmartOLT chegava com espaço duplo ("CADEIA   1", "TAMATAUPE  2"), sem acento ou truncada. O cadastro (ws_zona) e o texto
 *   guardado em cada contrato (ws_contrato.zona) deixavam de casar: a zona aparecia "sem cliente" mesmo com ONU na OLT, e o mesmo nome entrava
 *   duas vezes no cadastro. O mesmo vale para bairro (ws_bairro: "NOVA NAZARE" e "NOVA NAZARÉ"; linhas repetidas).
 *
 * A REGRA (nunca inventa, nunca junta o que é diferente)
 *   Chave = maiúsculas + sem acento + espaços repetidos viram um. Só o que tem a MESMA chave é a mesma zona/bairro.
 *   "CADEIA 1" e "CADEIA 2", "ALTO DA SANTA 1" e "2" têm chaves diferentes: NUNCA são juntados (a divisão 1/2 é real).
 *   Nome truncado só é completado quando é prefixo de UMA única zona/bairro; mais de uma possibilidade = fica como está e vai para o relatório.
 *
 * O QUE FAZ
 *   Zonas : junta linhas repetidas em ws_zona (fica a mais antiga, com o nome já limpo); acerta o texto de cada contrato para o nome do cadastro;
 *           cria no cadastro as zonas que contratos usam e não existiam.
 *   Bairros: junta linhas repetidas em ws_bairro (religa logradouros e clientes à que fica); acerta o texto do bairro dos clientes para o nome do cadastro.
 *   Sempre guarda o ANTES em cache/unificar_zonas_AAAAMMDD_HHMMSS.json (para desfazer) e devolve o relatório do que fez / faria.
 */

/** APELIDOS de zona: outro nome da MESMA zona (16/10/2026). "11 DE JULHO - SUBINDO" é a "11 DE JULHO - BR 408". Padrões no código; cache/zona_alias.json ({"NOME ANTIGO":"NOME CERTO"}) acrescenta sem mexer no código. */
function ws_zona_aliases(): array {
    static $m = null; if ($m !== null) return $m;
    $m = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/zona_alias.json';
    $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    if (is_array($j)) foreach ($j as $de => $para) if (trim((string)$de) !== '' && trim((string)$para) !== '') $m[(string)$de] = (string)$para;
    return $m;
}
/** Nome certo da zona (resolve o apelido; o que não é apelido volta igual). */
function ws_zona_alias(string $nome): string {
    static $mapa = null; if ($mapa === null) { $mapa = []; foreach (ws_zona_aliases() as $de => $para) $mapa[ws_zb_chave((string)$de)] = ws_zb_limpo((string)$para); }
    $k = ws_zb_chave($nome); return isset($mapa[$k]) ? $mapa[$k] : $nome;
}

/** VLAN -> ZONA (regra do provedor, 16/10/2026): a VLAN do cliente DEFINE a zona. Padrões no código; cache/vlan_zona.json (opcional, {"259":"ALTO DA SANTA 1"}) acrescenta/troca sem mexer no código. */
function ws_vlan_zona_mapa(): array {
    static $m = null; if ($m !== null) return $m;
    $m = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/vlan_zona.json';
    $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    if (is_array($j)) foreach ($j as $v => $z) if ((int)$v > 0 && trim((string)$z) !== '') $m[(int)$v] = trim((string)$z);
    return $m;
}
/** Bairro que a VLAN define, só entre as GRAFIAS da mesma família (VLAN 353: "BAIRRO BEIRA RIO" é o "BAIRRO BEIRA RIO / BR 408" do cadastro). Bairro de outro nome nunca é trocado. */
function ws_vlan_bairro_regras(): array {
    static $r = null; if ($r !== null) return $r; $r = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/vlan_bairro.json'; $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;   // {"258":{"para":"BAIRRO X","forcar":1}}
    if (is_array($j)) foreach ($j as $v => $rg) if ((int)$v > 0 && is_array($rg) && trim((string)($rg['para'] ?? '')) !== '') $r[(int)$v] = $rg;
    return $r;
}
/** Zona que a VLAN define (ou null se a VLAN não tem regra). */
function ws_vlan_zona($vlan, int $contratoId = 0): ?string { $v = (int)$vlan; $m = ws_vlan_zona_mapa(); if ($contratoId > 0 && in_array($contratoId, ws_vlan_excecoes(), true)) return null; return ($v > 0 && isset($m[$v])) ? $m[$v] : null; }
/** Contratos em que a VLAN define a ZONA mas NÃO o bairro (16/10/2026): 566 Laudeci e 431 Margarida (VLAN 55, zona SANTA MARIA, bairro LAGOA DANTAS). cache/vlan_excecoes_bairro.json ([id,...]) acrescenta. */
function ws_vlan_excecoes_bairro(): array {
    static $e = null; if ($e !== null) return $e; $e = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/vlan_excecoes_bairro.json'; $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    if (is_array($j)) foreach ($j as $i) if ((int)$i > 0) $e[] = (int)$i;
    return $e;
}
/** Contratos que ficam FORA da regra de VLAN (zona/bairro decididos à mão). 16/10/2026: 369 Maria de Lourdes e 436 Thiago (VLAN 258, mas são Lourdinha). cache/vlan_excecoes.json ([id,...]) acrescenta sem mexer no código. */
function ws_vlan_excecoes(): array {
    static $e = null; if ($e !== null) return $e; $e = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/vlan_excecoes.json'; $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    if (is_array($j)) foreach ($j as $i) if ((int)$i > 0) $e[] = (int)$i;
    return $e;
}

/** Chave de comparação: MAIÚSCULAS, sem acento, espaços repetidos viram um, sem espaço nas pontas. */
function ws_zb_chave(string $s): string {
    $s = mb_strtoupper(trim($s), 'UTF-8');
    $s = strtr($s, ['Á'=>'A','À'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','É'=>'E','È'=>'E','Ê'=>'E','Ë'=>'E','Í'=>'I','Ì'=>'I','Î'=>'I','Ï'=>'I','Ó'=>'O','Ò'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O','Ú'=>'U','Ù'=>'U','Û'=>'U','Ü'=>'U','Ç'=>'C','Ñ'=>'N']);
    return trim((string)preg_replace('/\s+/u', ' ', $s));
}
/** Chave de CIDADE: igual à de zona/bairro, mas antes tira o que sobra de colagem (emoji/número no início, "-UF" no fim): "1️⃣- Nazaré da Mata-PE" = "NAZARÉ DA MATA". */
function ws_zb_chave_cidade(string $s): string {
    $s = (string)preg_replace('/^[^\p{L}]+/u', '', trim($s));
    $s = (string)preg_replace('/\s*-\s*[A-Za-z]{2}\s*$/u', '', $s);
    return ws_zb_chave($s);
}
/** Nome de cidade limpo para gravar (mesmo corte de ws_zb_chave_cidade, mantendo acento e caixa). */
function ws_zb_cidade_limpa(string $s): string {
    $s = (string)preg_replace('/^[^\p{L}]+/u', '', trim($s));
    $s = (string)preg_replace('/\s*-\s*[A-Za-z]{2}\s*$/u', '', $s);
    return ws_zb_limpo($s);
}
/** Chave de BAIRRO: como a de zona, e sem o "BAIRRO " do começo (o cadastro usa o prefixo por convenção; "CENTRO" e "BAIRRO CENTRO" são o mesmo bairro). */
function ws_zb_chave_bairro(string $s): string { return (string)preg_replace('/^BAIRRO /', '', ws_zb_chave($s)); }
/** Nome de exibição limpo (espaço repetido vira um; mantém acento e caixa de origem). */
function ws_zb_limpo(string $s): string { return trim((string)preg_replace('/\s+/u', ' ', $s)); }

function ws_zonas_bairros_unificar(PDO $db, bool $aplicar = false): array {
    $rel = ['zonas_juntadas' => [], 'zonas_criadas' => [], 'contratos_acertados' => 0, 'zonas_prefixo' => [], 'zonas_ambiguas' => [], 'zonas_ignoradas' => [],
            'cidades_juntadas' => [], 'bairros_criados' => [], 'vlan_zona' => [], 'vlan_bairro' => 0, 'bairros_juntados' => [], 'clientes_bairro_acertados' => 0, 'bairros_sem_cadastro' => [], 'sem_zona' => 0, 'backup' => '', 'aplicado' => $aplicar];
    $antes = ['zonas' => [], 'bairros' => [], 'contratos_zona' => [], 'clientes_bairro' => [], 'logradouros' => []];
    $ex = function (string $sql, array $p = []) use ($db, $aplicar) { if (!$aplicar) return null; $st = $db->prepare($sql); $st->execute($p); return $st; };

    /* ============================ ZONAS ============================ */
    $zr = $db->query("SELECT id, nome, descricao, cor, ativo FROM ws_zona ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $antes['zonas'] = $zr;
    $grupos = []; foreach ($zr as $z) $grupos[ws_zb_chave(ws_zona_alias((string)$z['nome']))][] = $z;
    $canon = [];   // chave => nome que fica
    foreach ($grupos as $k => $g) {
        if ($k === '') continue;
        $sobrev = $g[0];
        // prefere, entre as variações, a que já está limpa (sem espaço repetido) e é a mais antiga
        foreach ($g as $z) if ((string)$z['nome'] === ws_zb_limpo((string)$z['nome']) && ws_zona_alias((string)$z['nome']) === (string)$z['nome']) { $sobrev = $z; break; }
        $nomeLimpo = ws_zb_limpo(ws_zona_alias((string)$sobrev['nome']));   // se a mais antiga for o apelido, o nome que fica é o certo
        $canon[$k] = $nomeLimpo;
        if (count($g) > 1) {
            $rel['zonas_juntadas'][] = $nomeLimpo . ' ← ' . implode(' + ', array_map(fn($x) => '#' . $x['id'] . ' "' . $x['nome'] . '"', $g));
            foreach ($g as $z) if ((int)$z['id'] !== (int)$sobrev['id']) $ex("DELETE FROM ws_zona WHERE id=?", [(int)$z['id']]);
        }
        if ((string)$sobrev['nome'] !== $nomeLimpo) $ex("UPDATE ws_zona SET nome=? WHERE id=?", [$nomeLimpo, (int)$sobrev['id']]);
    }

    // zonas que os contratos usam
    $uso = []; foreach ($db->query("SELECT zona z, COUNT(*) n FROM ws_contrato WHERE TRIM(COALESCE(zona,''))<>'' GROUP BY zona")->fetchAll(PDO::FETCH_ASSOC) as $r) { $k = ws_zb_chave(ws_zona_alias((string)$r['z'])); $uso[$k]['n'] = ($uso[$k]['n'] ?? 0) + (int)$r['n']; $uso[$k]['nome'] = $uso[$k]['nome'] ?? ws_zb_limpo((string)$r['z']); }
    $mapaZona = $canon;   // chave => nome final
    $paleta = ['#9E2A3B','#2A6F9E','#2A9E6F','#9E7A2A','#6F2A9E','#2A9E9E','#9E2A7A','#5A9E2A','#9E5A2A','#2A5A9E','#7A2A9E','#2A9E5A']; $ci = count($canon);
    foreach ($uso as $k => $v) {
        if (isset($canon[$k])) continue;
        // truncado? é prefixo (inteiro, até espaço) de UMA única zona do cadastro
        $cands = []; foreach ($canon as $kc => $nc) if ($kc !== $k && mb_strlen($k) >= 4 && strpos($kc, $k) === 0) $cands[] = $nc;
        if (mb_strlen($k) < 3) { $rel['zonas_ignoradas'][] = $v['nome'] . ' (' . $v['n'] . ' contratos — nome curto demais; confira na mão)'; continue; }
        if (count($cands) === 1) { $mapaZona[$k] = $cands[0]; $rel['zonas_prefixo'][] = $v['nome'] . ' → ' . $cands[0] . ' (' . $v['n'] . ')'; continue; }
        if (count($cands) > 1) { $rel['zonas_ambiguas'][] = $v['nome'] . ' (' . $v['n'] . ') pode ser: ' . implode(' / ', $cands); continue; }
        $mapaZona[$k] = $v['nome']; $rel['zonas_criadas'][] = $v['nome'] . ' (' . $v['n'] . ' contratos)';
        $ex("INSERT INTO ws_zona (nome, descricao, cor, ativo) VALUES (?, ?, ?, 1)", [mb_substr($v['nome'], 0, 80), 'Criada a partir dos contratos (unificação)', $paleta[$ci++ % count($paleta)]]);
    }
    // acerta o texto de cada contrato
    foreach ($db->query("SELECT id, zona FROM ws_contrato WHERE TRIM(COALESCE(zona,''))<>''")->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $k = ws_zb_chave(ws_zona_alias((string)$c['zona'])); if (!isset($mapaZona[$k])) continue; $novo = mb_substr($mapaZona[$k], 0, 80);
        if ($novo !== (string)$c['zona']) { $antes['contratos_zona'][(int)$c['id']] = $c['zona']; $rel['contratos_acertados']++; $ex("UPDATE ws_contrato SET zona=? WHERE id=?", [$novo, (int)$c['id']]); }
    }
    /* VLAN -> ZONA: contrato com VLAN que tem regra recebe a zona da regra (cria a zona no cadastro se faltar). Só muda quando está diferente/vazia. */
    $vz = ws_vlan_zona_mapa(); $vlanBairro = []; $vlanCli = [];   // id do cliente => zona definida pela VLAN (para acertar o bairro da família)
    if ($vz) {
        $in = implode(',', array_map('intval', array_keys($vz)));
        foreach ($vz as $vl => $zn) {
            $kz = ws_zb_chave($zn);
            if (!isset($canon[$kz])) { $canon[$kz] = ws_zb_limpo($zn); $mapaZona[$kz] = $canon[$kz]; $rel['zonas_criadas'][] = $canon[$kz] . ' (regra de VLAN ' . $vl . ')'; $ex("INSERT INTO ws_zona (nome, descricao, cor, ativo) VALUES (?, ?, ?, 1)", [mb_substr($canon[$kz], 0, 80), 'Criada pela regra de VLAN', $paleta[$ci++ % count($paleta)]]); }
        }
        foreach ($db->query("SELECT id, cliente_id, vlan, zona, status FROM ws_contrato WHERE vlan IN ($in)")->fetchAll(PDO::FETCH_ASSOC) as $c) {
            if (in_array((int)$c['id'], ws_vlan_excecoes(), true)) continue;   // exceção decidida à mão
            $alvo = $canon[ws_zb_chave($vz[(int)$c['vlan']])]; if ($c['status'] !== 'cancelado') { $vlanBairro[(int)$c['cliente_id']] = $alvo; if (!in_array((int)$c['id'], ws_vlan_excecoes_bairro(), true)) $vlanCli[(int)$c['cliente_id']] = (int)$c['vlan']; }
            if ((string)$c['zona'] === $alvo) continue;
            $antes['contratos_zona'][(int)$c['id']] = $c['zona']; $rel['vlan_zona'][] = 'contrato #' . $c['id'] . ' VLAN ' . $c['vlan'] . ': "' . trim((string)$c['zona']) . '" → ' . $alvo;
            $ex("UPDATE ws_contrato SET zona=? WHERE id=?", [mb_substr($alvo, 0, 80), (int)$c['id']]);
        }
    }
    $rel['sem_zona'] = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE status<>'cancelado' AND TRIM(COALESCE(zona,''))=''")->fetchColumn();

    /* ============================ CIDADES ============================ */
    $cidMap = [];   // id da cidade repetida => id da que fica
    $cr = $db->query("SELECT id, nome, uf, uf_id, chave FROM ws_cidade ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $antes['cidades'] = $cr;
    $gc = []; foreach ($cr as $c) $gc[ws_zb_chave_cidade((string)$c['nome'])][] = $c;
    foreach ($gc as $k => $g) {
        if ($k === '' || count($g) < 2) continue;
        $ufs = array_values(array_unique(array_filter(array_map(fn($x) => (int)$x['uf_id'], $g))));
        if (count($ufs) > 1) { $rel['zonas_ambiguas'][] = 'Cidade "' . $k . '" existe em mais de um estado — não juntei'; continue; }
        // fica a de nome já limpo (sem emoji/UF colados) e mais antiga
        $sobrev = $g[0]; foreach ($g as $c) if ((string)$c['nome'] === ws_zb_cidade_limpa((string)$c['nome'])) { $sobrev = $c; break; }
        $nomeC = ws_zb_cidade_limpa((string)$sobrev['nome']);
        $rel['cidades_juntadas'][] = $nomeC . ' ← ' . implode(' + ', array_map(fn($x) => '#' . $x['id'] . ' "' . $x['nome'] . '"', $g));
        foreach ($g as $c) {
            if ((int)$c['id'] === (int)$sobrev['id']) continue;
            $cidMap[(int)$c['id']] = (int)$sobrev['id'];
        }
        if ((string)$sobrev['nome'] !== $nomeC) $ex("UPDATE ws_cidade SET nome=? WHERE id=?", [$nomeC, (int)$sobrev['id']]);
    }
    // religa o que dependia da cidade repetida: bairros (juntando os de mesmo nome), ramais; depois apaga a repetida
    foreach ($cidMap as $de => $para) {
        $ex("UPDATE ws_ramal SET cidade_id=? WHERE cidade_id=?", [$para, $de]);
        $bs = $db->prepare("SELECT id, nome FROM ws_bairro WHERE cidade_id=?"); $bs->execute([$de]);
        foreach ($bs->fetchAll(PDO::FETCH_ASSOC) as $b) {
            $ja = $db->prepare("SELECT id FROM ws_bairro WHERE cidade_id=? AND id<>? "); $ja->execute([$para, (int)$b['id']]); $idJa = 0;
            foreach ($ja->fetchAll(PDO::FETCH_COLUMN) as $oid) { $nm = $db->prepare("SELECT nome FROM ws_bairro WHERE id=?"); $nm->execute([(int)$oid]); if (ws_zb_chave((string)$nm->fetchColumn()) === ws_zb_chave((string)$b['nome'])) { $idJa = (int)$oid; break; } }
            if ($idJa && $aplicar) { try { $db->prepare("UPDATE ws_logradouro SET bairro_id=? WHERE bairro_id=?")->execute([$idJa, (int)$b['id']]); } catch (Throwable $e) {} $db->prepare("DELETE FROM ws_bairro WHERE id=?")->execute([(int)$b['id']]); }
            elseif (!$idJa) $ex("UPDATE ws_bairro SET cidade_id=? WHERE id=?", [$para, (int)$b['id']]);
        }
        $ex("DELETE FROM ws_cidade WHERE id=?", [$de]);
    }

    /* ============================ BAIRROS ============================ */
    $br = $db->query("SELECT id, cidade_id, nome, ativo, chave FROM ws_bairro ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $antes['bairros'] = $br;
    $gb = []; foreach ($br as $b) $gb[ws_zb_chave_bairro((string)$b['nome']) . '|' . ($cidMap[(int)$b['cidade_id']] ?? (int)$b['cidade_id'])][] = $b;
    $temLog = false; try { $db->query("SELECT 1 FROM ws_logradouro LIMIT 1"); $temLog = true; } catch (Throwable $e) {}
    foreach ($gb as $kk => $g) {
        if (count($g) < 2) continue;
        // sobrevivente: a mais antiga; nome = o que tem acento (mais completo) senão o limpo
        $pref = array_values(array_filter($g, fn($x) => strpos(ws_zb_chave((string)$x['nome']), 'BAIRRO ') === 0)); $cand = $pref ?: $g;   // fica o de nome com "BAIRRO " (convenção do cadastro)
        $sobrev = $cand[0]; $nome = ws_zb_limpo((string)$sobrev['nome']); foreach ($cand as $b) if (preg_match('/[À-ÿ]/u', (string)$b['nome'])) { $nome = ws_zb_limpo((string)$b['nome']); break; }
        $rel['bairros_juntados'][] = $nome . ' ← ' . implode(' + ', array_map(fn($x) => '#' . $x['id'] . ' "' . $x['nome'] . '"', $g));
        foreach ($g as $b) {
            if ((int)$b['id'] === (int)$sobrev['id']) continue;
            if ($temLog) {
                $logs = $db->prepare("SELECT id, chave FROM ws_logradouro WHERE bairro_id=?"); $logs->execute([(int)$b['id']]);
                foreach ($logs->fetchAll(PDO::FETCH_ASSOC) as $l) {
                    $antes['logradouros'][(int)$l['id']] = (int)$b['id'];
                    $ja = $db->prepare("SELECT id FROM ws_logradouro WHERE bairro_id=? AND chave=? LIMIT 1"); $ja->execute([(int)$sobrev['id'], $l['chave']]); $idJa = (int)$ja->fetchColumn();
                    if ($idJa) { $ex("UPDATE ws_cliente SET logradouro_id=? WHERE logradouro_id=?", [$idJa, (int)$l['id']]); $ex("DELETE FROM ws_logradouro WHERE id=?", [(int)$l['id']]); }
                    else $ex("UPDATE ws_logradouro SET bairro_id=? WHERE id=?", [(int)$sobrev['id'], (int)$l['id']]);
                }
            }
            $ex("DELETE FROM ws_bairro WHERE id=?", [(int)$b['id']]);
        }
        if ((string)$sobrev['nome'] !== $nome) $ex("UPDATE ws_bairro SET nome=? WHERE id=?", [$nome, (int)$sobrev['id']]);
    }
    // texto do bairro dos clientes → nome do cadastro (só mesma chave: espaço/acento/caixa)
    $nomesB = []; foreach ($db->query("SELECT nome FROM ws_bairro")->fetchAll(PDO::FETCH_COLUMN) as $n) $nomesB[ws_zb_chave((string)$n)] = ws_zb_limpo((string)$n);
    if (!$aplicar) { $nomesB = []; foreach ($gb as $kk => $g) { $pf = array_values(array_filter($g, fn($x) => strpos(ws_zb_chave((string)$x['nome']), 'BAIRRO ') === 0)); $cd = $pf ?: $g; $nm = ws_zb_limpo((string)$cd[0]['nome']); foreach ($cd as $b) if (preg_match('/[À-ÿ]/u', (string)$b['nome'])) { $nm = ws_zb_limpo((string)$b['nome']); break; } $nomesB[ws_zb_chave($nm)] = $nm; } }
    $nomesBsem = []; foreach ($nomesB as $nmB) $nomesBsem[ws_zb_chave_bairro($nmB)] = $nmB;
    $semCad = []; $porZona = $db->prepare("SELECT zona FROM ws_contrato WHERE cliente_id=? AND TRIM(COALESCE(zona,''))<>'' ORDER BY (status='cancelado'), id LIMIT 1");
    foreach ($db->query("SELECT id, bairro, cidade, status FROM ws_cliente WHERE TRIM(COALESCE(bairro,''))<>''")->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $k = ws_zb_chave((string)$c['bairro']);
        if (!isset($nomesB[$k]) && isset($nomesBsem[ws_zb_chave_bairro((string)$c['bairro'])])) $k = ws_zb_chave($nomesBsem[ws_zb_chave_bairro((string)$c['bairro'])]);   // "PATIO FEIRA" = "BAIRRO PATIO FEIRA"
        /* VLAN define a zona e, nas famílias numeradas (ALTO DA SANTA 1/2, TAMATAUPE 1/2), também o bairro — só entre os bairros da MESMA família; bairro de outro nome (PEDREGULHO, CENTRO…) não é tocado. */
        if (isset($vlanCli[(int)$c['id']]) && isset(ws_vlan_bairro_regras()[$vlanCli[(int)$c['id']]])) {
            $rg = ws_vlan_bairro_regras()[$vlanCli[(int)$c['id']]]; $kp = ws_zb_chave($rg['para']);
            if (!empty($rg['forcar'])) {
                if (!isset($nomesB[$kp])) {   // o bairro da rota ainda não existe com esse nome: renomeia a grafia antiga ou cria
                    $ren = 0; foreach ((array)($rg['renomear'] ?? []) as $velho) { $kv = ws_zb_chave($velho); if (isset($nomesB[$kv])) { $ren = 1; $ex("UPDATE ws_bairro SET nome=?, chave=? WHERE nome=?", [$rg['para'], function_exists('ws_end_chave') ? ws_end_chave($rg['para']) : $kp, $nomesB[$kv]]); unset($nomesB[$kv]); $rel['bairros_criados'][] = $rg['para'] . ' (renomeado de ' . $velho . ')'; break; } }
                    if (!$ren) { $cidN = null; try { foreach ($db->query("SELECT id, nome FROM ws_cidade")->fetchAll(PDO::FETCH_ASSOC) as $ci) if (ws_zb_chave_cidade((string)$ci['nome']) === 'NAZARE DA MATA') { $cidN = (int)$ci['id']; break; } } catch (Throwable $e) {}
                        $ex("INSERT INTO ws_bairro (nome, chave, cidade_id, ativo) VALUES (?, ?, ?, 1)", [$rg['para'], function_exists('ws_end_chave') ? ws_end_chave($rg['para']) : $kp, $cidN]); $rel['bairros_criados'][] = $rg['para'] . ' (bairro da rota da VLAN ' . $vlanCli[(int)$c['id']] . ')'; }
                    $nomesB[$kp] = $rg['para'];
                }
                if ($k !== $kp) { $antes['clientes_bairro'][(int)$c['id']] = $c['bairro']; $rel['vlan_bairro']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomesB[$kp], 0, 80), (int)$c['id']]); }
                continue;
            }
            if (in_array($k, array_map('ws_zb_chave', $rg['de'] ?? []), true) && $k !== $kp && isset($nomesB[$kp])) { $antes['clientes_bairro'][(int)$c['id']] = $c['bairro']; $rel['vlan_bairro']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomesB[$kp], 0, 80), (int)$c['id']]); continue; }
        }
        if (isset($vlanBairro[(int)$c['id']])) {
            $zk = ws_zb_chave($vlanBairro[(int)$c['id']]); $stem = preg_replace('/ \d$/', '', $zk); $alvoB = 'BAIRRO ' . $zk;
            if ($stem !== $zk && isset($nomesB[$alvoB]) && in_array($k, ['BAIRRO ' . $stem, 'BAIRRO ' . $stem . ' 1', 'BAIRRO ' . $stem . ' 2'], true) && $k !== $alvoB) {
                $antes['clientes_bairro'][(int)$c['id']] = $c['bairro']; $rel['vlan_bairro']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomesB[$alvoB], 0, 80), (int)$c['id']]); continue;
            }
        }
        if (!isset($nomesB[$k])) {
            /* "BAIRRO ALTO DA SANTA" (sem o 1/2): a divisão 1/2 é real — só decide quando a ZONA do contrato do cliente aponta para exatamente um bairro cadastrado (zona "ALTO DA SANTA 2" -> "BAIRRO ALTO DA SANTA 2"). */
            $porZona->execute([(int)$c['id']]); $zk = ws_zb_chave((string)$porZona->fetchColumn()); $alvo = '';
            if ($zk !== '' && strpos($zk, $k === '' ? '#' : preg_replace('/^BAIRRO /', '', $k)) === 0) { $cb = 'BAIRRO ' . $zk; if (isset($nomesB[$cb])) $alvo = $cb; elseif (isset($nomesB[$zk])) $alvo = $zk; }
            if ($alvo !== '') { $antes['clientes_bairro'][(int)$c['id']] = $c['bairro']; $rel['clientes_bairro_acertados']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomesB[$alvo], 0, 80), (int)$c['id']]); continue; }
            $semCad[$k] = ($semCad[$k] ?? ['nome' => ws_zb_limpo((string)$c['bairro']), 'n' => 0, 'ids' => [], 'cidade' => trim((string)$c['cidade'])]); $semCad[$k]['n']++; $semCad[$k]['ids'][] = (int)$c['id']; continue;
        }
        if ($nomesB[$k] !== (string)$c['bairro']) { $antes['clientes_bairro'][(int)$c['id']] = $c['bairro']; $rel['clientes_bairro_acertados']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomesB[$k], 0, 80), (int)$c['id']]); }
    }
    foreach ($semCad as $k => $v) {
        $cands = []; foreach ($nomesB as $kb => $nb) if (strpos($kb, $k . ' ') === 0 || strpos(ws_zb_chave_bairro($nb), ws_zb_chave_bairro($v['nome']) . ' ') === 0) $cands[] = $nb;
        if (!$cands && mb_strlen(ws_zb_chave_bairro($v['nome'])) >= 4) {   // não existe nada parecido: cria o bairro no cadastro (convenção "BAIRRO ...") e acerta o texto dos clientes
            $nomeNovo = (strpos(ws_zb_chave($v['nome']), 'BAIRRO ') === 0) ? $v['nome'] : 'BAIRRO ' . $v['nome'];
            $cidId = null; try { $kc = ws_zb_chave_cidade($v['cidade'] ?: 'NAZARÉ DA MATA'); foreach ($db->query("SELECT id, nome FROM ws_cidade")->fetchAll(PDO::FETCH_ASSOC) as $ci) if (ws_zb_chave_cidade((string)$ci['nome']) === $kc) { $cidId = (int)$ci['id']; break; } } catch (Throwable $e) {}
            $rel['bairros_criados'][] = $nomeNovo . ' (' . $v['n'] . ' clientes)';
            $ex("INSERT INTO ws_bairro (nome, chave, cidade_id, ativo) VALUES (?, ?, ?, 1)", [mb_substr($nomeNovo, 0, 120), function_exists('ws_end_chave') ? ws_end_chave($nomeNovo) : ws_zb_chave($nomeNovo), $cidId]);
            foreach ($v['ids'] as $cid) { $antes['clientes_bairro'][$cid] = $v['nome']; $rel['clientes_bairro_acertados']++; $ex("UPDATE ws_cliente SET bairro=? WHERE id=?", [mb_substr($nomeNovo, 0, 80), $cid]); }
            continue;
        }
        $rel['bairros_sem_cadastro'][] = $v['nome'] . ' (' . $v['n'] . ' clientes)' . ($cands ? ' — pode ser: ' . implode(' / ', $cands) . ' (decidir por zona/rua; não junto sozinho)' : ' — nome curto demais; confira na mão');
    }

    if ($aplicar) {
        $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/unificar_zonas_' . date('Ymd_His') . '.json';
        @file_put_contents($arq, json_encode($antes, JSON_UNESCAPED_UNICODE)); @chmod($arq, 0640); $rel['backup'] = basename($arq);
    }
    return $rel;
}

/** Seriais (normalizados) das ONUs que a OLT mostra agora — lidos do cache do módulo da OLT (sem Telnet). Vazio = a OLT ainda não foi lida. */
function ws_olt_seriais_vivos(): array {
    static $set = null; if ($set !== null) return $set;
    $set = [];
    foreach ([__DIR__ . '/cache_trafego/olt_onus_cache.json', (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/olt_onus_cache.json'] as $arq) {
        if (!is_file($arq)) continue;
        $j = json_decode((string)@file_get_contents($arq), true); $sl = is_array($j) ? ($j['slots'] ?? []) : [];
        foreach ($sl as $lista) { if (!is_array($lista)) continue; foreach ($lista as $o) { if (!is_array($o)) continue; $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)($o['serial'] ?? ''))); if ($sn !== '') $set[$sn] = true; } }
        if ($set) break;
    }
    return $set;
}
/** Quantos dos contratos ativos de cada zona (nome => n) / de cada bairro de cliente (texto => n) têm a ONU na OLT agora. */
function ws_olt_contagem_por(PDO $db, string $por): array {
    $set = ws_olt_seriais_vivos(); $out = [];
    if (!$set) return $out;
    $sql = $por === 'zona'
        ? "SELECT ct.zona g, ct.sn_onu sn FROM ws_contrato ct WHERE ct.status<>'cancelado' AND TRIM(COALESCE(ct.zona,''))<>'' AND TRIM(COALESCE(ct.sn_onu,''))<>''"
        : "SELECT cl.bairro g, ct.sn_onu sn FROM ws_contrato ct JOIN ws_cliente cl ON cl.id=ct.cliente_id WHERE ct.status<>'cancelado' AND TRIM(COALESCE(cl.bairro,''))<>'' AND TRIM(COALESCE(ct.sn_onu,''))<>''";
    foreach ($db->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$r['sn']));
        if ($sn !== '' && isset($set[$sn])) { $k = mb_strtolower(trim((string)$r['g'])); $out[$k] = ($out[$k] ?? 0) + 1; }
    }
    return $out;
}

/** CLIENTES ATIVOS POR BAIRRO, uma vez cada (16/10/2026). O bairro de um cliente é o do CADASTRO dele: o texto que está na ficha, quando bate com um bairro cadastrado
 *  (na cidade dele, se houver mais de um com o mesmo nome); se não bate, o bairro do endereço normalizado (rua → bairro). Assim nenhum bairro com cliente fica sem total
 *  e ninguém é contado em dois. Devolve [id_do_bairro => n] e 'sem' = clientes sem bairro nenhum. */
function ws_bairro_contagem(PDO $db, array $bairros): array {
    $porNome = [];
    foreach ($bairros as $b) { $cc = ''; try { $cc = (string)($b['cidade_nome'] ?? ''); } catch (Throwable $e) {} $porNome[ws_zb_chave_bairro((string)$b['nome'])][] = ['id' => (int)$b['id'], 'cid' => ws_zb_chave_cidade($cc)]; }
    $idsOk = []; foreach ($bairros as $b) $idsOk[(int)$b['id']] = 1;
    $out = ['sem' => 0, 'total' => 0];
    $q = $db->query("SELECT cl.bairro, cl.cidade, lg.bairro_id lb FROM ws_cliente cl LEFT JOIN ws_logradouro lg ON lg.id = cl.logradouro_id WHERE cl.status <> 'cancelado'");
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $id = 0; $k = ws_zb_chave_bairro((string)$c['bairro']);
        if ($k !== '' && isset($porNome[$k])) {
            $cand = $porNome[$k]; $id = $cand[0]['id'];
            if (count($cand) > 1) { $kc = ws_zb_chave_cidade((string)$c['cidade']); foreach ($cand as $x) if ($x['cid'] === $kc) { $id = $x['id']; break; } }
        } elseif (!empty($c['lb']) && isset($idsOk[(int)$c['lb']])) $id = (int)$c['lb'];
        if ($id) { $out[$id] = ($out[$id] ?? 0) + 1; $out['total']++; } else $out['sem']++;
    }
    return $out;
}

/** ZONA RURAL -> bairro da localidade (16/10/2026, caso Eulália): cliente cujo bairro é "ZONA RURAL" e cujo contrato (não cancelado) tem zona/localidade conhecida passa a ter o bairro dessa localidade.
 *  Só mexe no campo bairro; bairro que não é ZONA RURAL nunca é tocado. Bairro novo é criado no cadastro (cidade do cliente). Devolve [bairro => qtd]. */
function ws_rural_bairro_da_zona(PDO $db, bool $aplicar = false): array {
    $mapa = [];
    $arq = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/zona_bairro.json'; $j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : null;
    if (is_array($j)) foreach ($j as $z => $b) if (trim((string)$z) !== '' && trim((string)$b) !== '') $mapa[ws_zb_chave((string)$z)] = trim((string)$b);
    $rel = []; $nomes = []; foreach ($db->query("SELECT nome FROM ws_bairro")->fetchAll(PDO::FETCH_COLUMN) as $n) $nomes[ws_zb_chave((string)$n)] = (string)$n;
    $rows = $db->query("SELECT c.id, c.cidade, ct.zona FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id=c.id AND ct.status<>'cancelado' AND TRIM(COALESCE(ct.zona,''))<>'' WHERE c.bairro IN ('BAIRRO ZONA RURAL','ZONA RURAL') ORDER BY c.id, ct.id")->fetchAll(PDO::FETCH_ASSOC);
    $feito = [];
    foreach ($rows as $r) {
        if (isset($feito[(int)$r['id']])) continue; $alvo = $mapa[ws_zb_chave((string)$r['zona'])] ?? ''; if ($alvo === '') continue; $feito[(int)$r['id']] = 1;
        $ka = ws_zb_chave($alvo);
        if (!isset($nomes[$ka])) {
            if ($aplicar) { $cidN = null; try { foreach ($db->query("SELECT id, nome FROM ws_cidade")->fetchAll(PDO::FETCH_ASSOC) as $ci) if (ws_zb_chave_cidade((string)$ci['nome']) === ws_zb_chave_cidade((string)$r['cidade'])) { $cidN = (int)$ci['id']; break; } } catch (Throwable $e) {}
                $db->prepare("INSERT INTO ws_bairro (nome, chave, cidade_id, ativo) VALUES (?, ?, ?, 1)")->execute([$alvo, function_exists('ws_end_chave') ? ws_end_chave($alvo) : $ka, $cidN]); }
            $nomes[$ka] = $alvo;
        }
        $rel[$nomes[$ka]] = ($rel[$nomes[$ka]] ?? 0) + 1;
        if ($aplicar) $db->prepare("UPDATE ws_cliente SET bairro=? WHERE id=?")->execute([mb_substr($nomes[$ka], 0, 80), (int)$r['id']]);
    }
    return $rel;
}
