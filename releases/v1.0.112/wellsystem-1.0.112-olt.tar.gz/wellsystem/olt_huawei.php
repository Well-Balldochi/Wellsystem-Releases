<?php
// =============================================================================
// OLT_HUAWEI.PHP  (MA5683T)
// Consulta de ONU/ONT (SN, sinal óptico, status, descrição) via Telnet.
//
// Fluxo real de login desta OLT (confirmado por debug):
//   >>User name:      -> envia usuario
//   >>User password:  -> envia senha
//   MA5683T>          -> modo usuario  (precisa "enable")
//   MA5683T#          -> modo privilegiado (precisa "config")
//   MA5683T(config)#  -> modo config (roda "display ont info ...")
//   MA5683T(config-if-gpon-0/1)#  -> dentro de "interface gpon 0/1"
//
// Ações:
//   ?acao=listar_todos              -> varre slots/portas e lista as ONUs
//   ?acao=buscar_cliente&login=SN   -> localiza a ONU pelo Serial Number
//                                       (o login do cliente É o SN da ONU)
//   ?acao=debug_varrer              -> saida bruta + parse de toda a faixa
//   ?acao=debug_sn&sn=SN            -> saida bruta do "display ont info by-sn"
//   ?acao=debug_login               -> etapas cruas do handshake de login
// =============================================================================

// Dá acesso a ws_db_config() (bootstrap do config.php da raiz), pra olt_radius_db()/olt_radius_host()
// poderem reaproveitar a MESMA credencial que já abre o banco `wellsystem` — mesmo modelo aplicado
// em socket_telnet.php. Em is_file() de propósito: o addon OLT precisa continuar funcionando sozinho,
// sem o restante do WellSystem ao lado, se for esse o caso.
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
// Um módulo, um cache: traz uma vez o que estava em olt/cache_trafego (ver olt_unificar.php).
if (is_file(__DIR__ . '/olt_unificar.php')) { require_once __DIR__ . '/olt_unificar.php'; olt_unificar_cache(__DIR__); }

// Sessão do WellSystem (login do painel) — lida e FECHADA aqui, ANTES do olt_auth.php (abaixo)
// abrir a sessão própria da OLT (cookie WSOLTSESS). É o MESMO padrão que olt.php já usa: são
// dois cookies de sessão diferentes e não podem ficar abertos ao mesmo tempo. Sem fechar aqui, o
// session_status() nunca voltaria a PHP_SESSION_NONE e o olt_auth.php pararia de trocar pra
// WSOLTSESS. $__ws_olt_root_op fica disponível (variável global) pro auto-conectar em olt_auth.php.
$__ws_olt_root_op = null;
if (session_status() === PHP_SESSION_ACTIVE) {
    $__ws_olt_root_op = $_SESSION['ws_user'] ?? null;
    @session_write_close();
}

header('Content-Type: application/json; charset=utf-8');
error_reporting(0);
ini_set('display_errors', 0);
@set_time_limit(300);

// --------------------------- CONFIGURAÇÃO DA OLT ----------------------------
// INSTALAÇÃO LIMPA: sem credenciais no código. Uma instalação nova NÃO se conecta
// a lugar nenhum até o operador informar os dados em "Conexão da OLT" (a tela grava
// em cache_trafego/olt_conexao.json, que sobrescreve os valores abaixo).
// Nunca volte a preencher IP/usuário/senha aqui: além de vazar credenciais ao
// distribuir o código, faz uma instalação nova conectar na OLT de outra empresa.
$olt_ip      = '';   // definido pela tela "Conexão da OLT"
$olt_porta   = 23;   // porta Telnet (padrão)
$olt_user    = '';   // definido pela tela "Conexão da OLT"
$olt_pass    = '';   // definido pela tela "Conexão da OLT"
$olt_timeout = 8;    // timeout de OCIOSIDADE por leitura (segundos sem novos bytes)

// Placas GPON desta OLT (display board 0): slots 1, 3 e 5 = H805GPFD.
// Varre 1..5 para ja cobrir qualquer placa GPON nova adicionada nesses slots
// (slots vazios respondem rapido, sem ONT). A H805GPFD tem 16 portas (0..15).
$faixa_slots  = [1, 2, 3, 4, 5];
$faixa_portas = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

// Perfis padrao usados ao AUTORIZAR uma ONU nova (aprovisionamento).
// Confira em: display ont-lineprofile gpon all / display ont-srvprofile gpon all.
// (No exemplo desta OLT: line-profile "SmartOLT_G" id 81, srv-profile "MAX1000" id 11.)
// Padrao/fallback (o operador escolhe no seletor da tela). Na OLT: a maioria usa o
// line-profile 1 = SMARTOLT_FLEXIBLE_GPON (446 vinculos); srv 11 = MAX1000 (bridge).
$olt_lineprofile = 1;
$olt_srvprofile  = 11;
// (Tabela completa de perfis Bridge/Router e o fluxo da autorização: ver "PERFIS NA AUTORIZAÇÃO"
//  logo acima de $OLT_SRV_CAP. NÃO apagar estas duas variáveis: são o padrão do perfil em branco.)
// Bridge<->Router na liberacao: cada escolha aplica um srv-profile REAL da OLT, para
// o que aparece na Huawei ser exatamente o que foi escolhido (sem divergencia).
//   Bridge (ONU)  -> MAX1000 (id 11)
//   Router (ONT)  -> ONT-HUAWEI-v2 (id 68)  (o srv-profile de router mais usado)
// Ajuste os IDs aqui se quiser outro perfil padrao (veja acao=perfis_olt).
$olt_srv_bridge = 11;
$olt_srv_router = 68;

// SmartOLT (para linkar o nome -> /onu/view/<id>). Token fica SO no servidor.
$__so = json_decode((string)@file_get_contents(__DIR__ . '/cache_trafego/olt_smartolt.json'), true);   // opcional: {"url":"https://empresa.smartolt.com","token":"..."} — vazio = sem integração
$smartolt_url   = is_array($__so) ? rtrim((string)($__so['url'] ?? ''), '/') : '';
$smartolt_token = is_array($__so) ? (string)($__so['token'] ?? '') : '';

// Regex do prompt de comando (usuario/privilegiado/config/interface):
//   MA5683T>   MA5683T#   MA5683T(config)#   MA5683T(config-if-gpon-0/1)#
// IMPORTANTE: exige o hostname no INICIO da ultima linha, senao "{ <cr>" (que
// termina em "r>") era confundido com prompt e o Enter nao era enviado.
$RX_PROMPT   = '/(?:^|\n)[ \t]*[A-Za-z][\w\-.]*(?:\([^)\n]*\))?[>#][ \t]*$/';
$RX_USER     = '/(user\s*name|login)\s*:\s*$/i';
$RX_PASS     = '/pass\s*word\s*:\s*$/i';

// =============================================================================
// LIMPEZA TELNET (IAC) — SOMENTE DESCARTE, SEM RESPONDER
// Conectando cru via fsockopen, a OLT envia comandos telnet IAC (0xFF). Este
// equipamento (MA5683T) NAO exige resposta de negociacao — o login funciona
// desde que apenas descartemos esses bytes de controle (responder DONT/WONT
// muda o modo de eco e quebra a autenticacao). Aqui removemos as sequencias
// IAC (2 bytes, 3 bytes WILL/WONT/DO/DONT e subnegociacoes SB..SE) e devolvemos
// apenas o texto puro, sem escrever nada de volta.
// =============================================================================
function telnet_processar_iac($socket, $raw) {
    $texto = '';
    $i = 0; $n = strlen($raw);
    while ($i < $n) {
        $c = ord($raw[$i]);
        if ($c !== 255) { $texto .= $raw[$i]; $i++; continue; } // byte normal
        $cmd = ($i + 1 < $n) ? ord($raw[$i + 1]) : 0;
        if ($cmd === 255) { $texto .= chr(255); $i += 2; continue; }   // 0xFF escapado
        if ($cmd >= 251 && $cmd <= 254) { $i += 3; continue; }         // WILL/WONT/DO/DONT (descarta)
        if ($cmd === 250) {                                            // SB ... IAC SE
            $j = $i + 2;
            while ($j + 1 < $n && !(ord($raw[$j]) === 255 && ord($raw[$j + 1]) === 240)) $j++;
            $i = $j + 2; continue;
        }
        $i += 2; // outros comandos IAC de 2 bytes (NOP, DM, etc.)
    }
    return $texto;
}

// =============================================================================
// LEITURA SINCRONIZADA DO SOCKET
// Le do socket ate casar $regexPrompt no FIM do buffer, tratando a paginacao
// "---- More ----" (envia espaco). O timeout é por OCIOSIDADE: reinicia toda
// vez que chegam bytes, entao tabelas longas nao sao cortadas.
// =============================================================================
function olt_ler_ate($socket, $regexPrompt, $idleTimeout) {
    $buffer = '';
    $ultimo = microtime(true);
    while (true) {
        if ((microtime(true) - $ultimo) > $idleTimeout) break;
        $trecho = @fread($socket, 8192);
        if ($trecho === false) break;
        if ($trecho === '') {
            $meta = stream_get_meta_data($socket);
            if (!empty($meta['timed_out'])) {
                // leitura estourou o stream_set_timeout: checa prompt e decide
                $limpoTmp = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
                if ($regexPrompt && preg_match($regexPrompt, rtrim($limpoTmp))) break;
                if ((microtime(true) - $ultimo) > $idleTimeout) break;
            }
            usleep(30000);
            continue;
        }
        $trecho = telnet_processar_iac($socket, $trecho); // responde/limpa IAC
        if ($trecho === '') { usleep(10000); continue; }
        $buffer .= $trecho;
        $ultimo = microtime(true);

        // Paginacao Huawei: "---- More ( Press 'Q'... ) ----" -> manda espaco
        if (preg_match('/----\s*More/i', $buffer)) {
            @fwrite($socket, ' ');
            // remove o marcador para nao re-disparar e nao poluir o parse
            $buffer = preg_replace('/\s*----\s*More.*?----\s*/is', "\n", $buffer);
            continue;
        }

        $limpo = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
        if ($regexPrompt && preg_match($regexPrompt, rtrim($limpo))) break;
        // Prompt de opcoes VRP: encerra a leitura assim que aparece "{ <cr>"
        // (com ou sem o "}:" final) ou qualquer "}:" — o loop de comandos manda Enter.
        if (preg_match('/\{\s*<cr>/i', $limpo) || preg_match('/\}\s*:\s*$/', rtrim($limpo))) break;
    }
    return preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
}

// =============================================================================
// CONEXAO + EXECUCAO DE COMANDOS
// Retorna array INDEXADO na mesma ordem de $comandos ( $out[$i] <-> $comandos[$i] ),
// para que comandos repetidos (ex.: "display ont info 0 all" em slots diferentes)
// nao colidam por chave.
// =============================================================================
function olt_telnet_exec($ip, $porta, $user, $pass, array $comandos, $idleTimeout = 8) {
    global $RX_PROMPT, $RX_USER, $RX_PASS;

    $socket = @fsockopen($ip, $porta, $errno, $errstr, $idleTimeout);
    if (!$socket) {
        throw new Exception("Falha ao conectar na OLT ($ip:$porta): $errstr");
    }
    stream_set_blocking($socket, true);
    stream_set_timeout($socket, 2); // leitura em blocos curtos; o loop controla o total

    // ---- Handshake de login (deterministico, SEM enter extra) ---------------
    // O "\r\n" extra antigo, quando a OLT estava lenta, era interpretado como
    // uma tentativa de login vazia -> a OLT re-exibia ">>User password:" e a
    // autenticacao falhava de forma intermitente. Aqui NAO enviamos enter extra:
    // apenas esperamos o prompt de comando com folga; se nao vier, sinalizamos
    // AUTH_RETRY para o wrapper reconectar.
    $saida = olt_ler_ate($socket, $RX_USER, $idleTimeout);
    if (!preg_match($RX_USER, rtrim($saida))) {
        @fclose($socket);
        throw new Exception("AUTH_RETRY: prompt de usuario nao recebido.");
    }
    @fwrite($socket, $user . "\r\n");
    $saida = olt_ler_ate($socket, $RX_PASS, $idleTimeout);
    if (!preg_match($RX_PASS, rtrim($saida))) {
        @fclose($socket);
        throw new Exception("AUTH_RETRY: prompt de senha nao recebido.");
    }
    @fwrite($socket, $pass . "\r\n");
    // O banner pos-login pode ser grande/lento -> espera com folga extra.
    $saida = olt_ler_ate($socket, $RX_PROMPT, $idleTimeout + 5);
    if (preg_match($RX_PASS, rtrim($saida)) || !preg_match($RX_PROMPT, rtrim($saida))) {
        @fwrite($socket, "quit\r\n");
        @fclose($socket);
        /* O QUE A OLT RESPONDEU vai junto — antes a mensagem era sempre a mesma e não dava para saber
           se era senha errada ou OLT sem sessão livre. A MA5683T tem poucas sessões VTY: com varredura,
           cron e várias janelas abertas ela recusa o login ("reached the upper limit"). */
        $resp = trim(preg_replace('/\s+/', ' ', substr($saida, -160)));
        if (preg_match('/upper\s*limit|maximum|too\s+many|limite|exceed/i', $saida))
            throw new Exception("AUTH_RETRY: OLT sem sessão Telnet livre — o usuário da OLT atingiu o limite de logins SIMULTÂNEOS (Reenter). Feche PuTTY/SmartOLT/outra aba usando o MESMO usuário ou crie um usuário só p/ o WellSystem. Resposta: $resp");
        if (preg_match($RX_PASS, rtrim($saida)) || preg_match('/password|senha|fail|incorrect|invalid/i', $saida))
            throw new Exception("AUTH_RETRY: a OLT recusou o usuário/senha. Confira em OLT › Conexão. Resposta: $resp");
        throw new Exception("AUTH_RETRY: nao chegou ao prompt de comando. Resposta da OLT: " . ($resp !== '' ? $resp : '(nada)'));
    }

    // ---- Execucao dos comandos, sincronizando por prompt ---------------------
    $out = [];
    foreach ($comandos as $cmd) {
        @fwrite($socket, $cmd . "\r\n");
        $resp = olt_ler_ate($socket, $RX_PROMPT, $idleTimeout);

        // Loop robusto: enquanto NAO estiver num prompt de comando (>/#),
        // responde a qualquer prompt intermediario e le de novo. Cobre:
        //   - senha ("enable" pedindo senha)
        //   - confirmacao "(y/n)" / "are you sure" (reset/reboot/factory/delete)
        //   - prompt de opcoes VRP "{ <cr>|... }:" e "{ <cr>" (ont confirm etc.)
        //     -> executa com Enter. Sem isso o comando fica preso e "nao roda".
        $g = 0;
        while ($g++ < 6 && !preg_match($RX_PROMPT, rtrim($resp))) {
            $tail = rtrim($resp);
            if (preg_match($RX_PASS, $tail)) {
                @fwrite($socket, $pass . "\r\n");                       // pede senha -> senha
            } elseif (preg_match('/\}\s*:\s*$/', $tail) || preg_match('/\{\s*<cr>/i', $tail)) {
                @fwrite($socket, "\r\n");                               // prompt de opcoes "{ <cr>|... }:" -> ENTER (executa)
            } elseif (preg_match('/\(\s*y\s*\/\s*n\s*\)\s*[\[\(]?\s*[yn]?\s*[\]\)]?\s*:?\s*$/i', $tail)
                      || preg_match('/are\s+you\s+sure|tem\s+certeza/i', $tail)) {
                @fwrite($socket, "y\r\n");                              // confirmacao real (y/n) -> "y"
            } else {
                @fwrite($socket, "\r\n");                               // fallback -> Enter
            }
            $resp .= "\n" . olt_ler_ate($socket, $RX_PROMPT, $idleTimeout);
        }
        $out[] = $resp;
    }

    // ---- Logout LIMPO: libera a sessao VTY na OLT ---------------------------
    // Sem isso, sessoes ficam presas na OLT e novos logins passam a falhar
    // (causa do "funcionou e depois perdeu conexao").
    olt_telnet_logout($socket);
    return $out;
}

/* LOGOUT DE VERDADE. Um "quit" só sai de UM nível (interface → config → enable → usuário): a sessão
   ficava aberta na OLT até o idle-timeout. Várias dessas presas estouravam o limite do usuário
   ("Reenter times have reached the upper limit") e tudo parava. Aqui: "quit" até a OLT fechar,
   respondendo "y" ao "Are you sure to log out? (y/n)". */
function olt_telnet_logout($socket) {
    for ($k = 0; $k < 6; $k++) {
        if (@feof($socket)) break;
        @fwrite($socket, "quit\r\n");
        $r = olt_ler_ate($socket, '/(?:[>#]|\(y\/n\)[^\r\n]*:?)\s*$/i', 2);
        if (preg_match('/\(\s*y\s*\/\s*n\s*\)|log\s*out|are\s+you\s+sure/i', $r)) {
            @fwrite($socket, "y\r\n");
            olt_ler_ate($socket, '/\bnao-existe-esse-prompt\b/', 1);
            break;
        }
        if ($r === '' && @feof($socket)) break;
    }
    @fclose($socket);
}

// =============================================================================
// MUTEX GLOBAL DE TELNET (flock) — SÓ UMA sessao Telnet por OLT de cada vez.
// A MA5683T tem poucas linhas VTY; quando o app dispara varios fetches juntos
// (ainda mais logo apos aprovisionar) + o cron, as VTYs esgotam -> auth-retry em
// cascata -> lentidao, leitura parcial (ONU some/volta), abort no front e erro
// ao deletar. O SmartOLT nao sofre isso porque SERIALIZA numa sessao so. Aqui
// replicamos isso: todo olt_exec (app E cron) passa por este lock.
//   - Espera ate ~$maxWait s pelo lock; se nao conseguir, segue mesmo assim
//     (FAIL-OPEN) -> nunca trava a producao.
//   - O lock fica em /tmp (gravavel pelo FPM E pelo CLI do cron) para o mutex
//     ser REALMENTE compartilhado entre os dois. O SO libera o flock sozinho se
//     o processo morrer (ex.: FPM matar em 15s) -> sem risco de deadlock.
// =============================================================================
function olt_lock_dir() {
    static $d = null;
    if ($d !== null) return $d;
    foreach (array(__DIR__ . '/cache_trafego', sys_get_temp_dir()) as $c) {
        if (!is_dir($c)) @mkdir($c, 0777, true);
        $t = $c . '/.__lk' . getmypid() . mt_rand();
        if (@file_put_contents($t, '1') !== false) { @unlink($t); return $d = $c; }
    }
    return $d = sys_get_temp_dir();
}
function olt_telnet_lock($ip, $maxWait = null) {
    /* CONSULTA MANUAL DA FICHA (Service-port, Portas LAN, Sinal, Tráfego...): espera a sua vez por
       até 75s e NÃO abre sessão paralela ($GLOBALS['OLT_LOCK_MANUAL']). O "fail-open" de 30s abria
       uma sessão a mais enquanto a varredura ainda usava outra — com cron + fichas abertas a OLT
       ficava sem sessão VTY livre e recusava o login ("nao chegou ao prompt"). */
    $manual = !empty($GLOBALS['OLT_LOCK_MANUAL']);
    // AÇÕES do operador (deletar, reiniciar, bloquear, trocar VLAN, autorizar, placa/porta/VLAN) esperam até 150s
    // pela vez: uma varredura de placa pode segurar a OLT mais de 75s e o Deletar desistia ("OLT ocupada").
    // Leituras da ficha (combo, uptime, sinal...) seguem 75s.
    $acaoLk = (string)($GLOBALS['acao'] ?? '');
    $acaoLonga = $manual && !in_array($acaoLk, ['onu_combo', 'onu_uptime', 'onu_vlan', 'onu_portas', 'onu_optico', 'onu_trafego'], true);
    if ($maxWait === null) $maxWait = $manual ? ($acaoLonga ? 150.0 : 75.0) : (PHP_SAPI === 'cli' ? 60.0 : 30.0);   // cron: espera mais (nunca abre em paralelo)
    /* A trava ficava em sys_get_temp_dir(). No Ubuntu o Apache roda com PrivateTmp: o /tmp da tela
     * NÃO é o /tmp do cron. Cada um tinha a sua trava, os dois abriam Telnet ao mesmo tempo e as
     * poucas sessões VTY da OLT se esgotavam — autofind e autorização ficavam esperando minutos.
     * Agora a trava mora em cache_trafego, que a tela e o cron enxergam igual (/tmp só se não gravar). */
    $path = olt_lock_dir() . '/olt_telnet_' . preg_replace('/[^0-9A-Za-z]/', '_', (string)$ip) . '.lock';
    $f = @fopen($path, 'c');
    if (!$f) return null;
    @chmod($path, 0666); // FPM e CLI precisam abrir o MESMO arquivo
    /* PRIORIDADE DO OPERADOR: com 1 sessão por vez, as leituras de fundo das telas (varredura, lotes)
       ocupavam a OLT sem parar e a ficha/ação do operador desistia na fila. Quem é MANUAL marca
       "estou esperando" (olt_prio_<ip>); leitura de FUNDO da tela vê a marca fresca e NÃO entra
       — cede a vez. Cron (CLI) segue normal. NÃO REMOVER. */
    $prio = dirname($path) . '/olt_prio_' . preg_replace('/[^0-9A-Za-z]/', '_', (string)$ip) . '.flag';
    $fundo = !$manual && PHP_SAPI !== 'cli';
    $deadline = microtime(true) + (float)$maxWait;
    while (true) {
        if ($fundo) clearstatcache(true, $prio);   // mtime sempre fresco (cache de stat do PHP)
        if ($fundo && is_file($prio) && (time() - (int)@filemtime($prio)) < 8) {   // operador esperando: cede
            if (microtime(true) >= $deadline) return array('fp' => $f, 'held' => false);
            usleep(250000); clearstatcache(true, $prio); continue;
        }
        if (@flock($f, LOCK_EX | LOCK_NB)) break;
        if ($manual) @touch($prio);                                                   // "estou esperando"
        if (microtime(true) >= $deadline) return array('fp' => $f, 'held' => false);
        usleep(120000); // 0.12s
    }
    return array('fp' => $f, 'held' => true);
}
function olt_telnet_unlock($lock) {
    if (!$lock || empty($lock['fp'])) return;
    if (!empty($lock['held'])) @flock($lock['fp'], LOCK_UN);
    @fclose($lock['fp']);
}

// =============================================================================
// MUTEX GENÉRICO PARA ARQUIVOS JSON COMPARTILHADOS (cache_trafego), mesmo
// motivo/pasta do MUTEX DE TELNET acima (FPM e CRON não compartilham /tmp).
//
// Corrige a "perda de gravação" quando duas telas/atendentes (ou a tela e o
// cron) fazem leitura->alteração->gravação do MESMO JSON ao mesmo tempo: quem
// grava por último apaga o que o outro tinha acabado de salvar. Isso explicava
// (a) a lista de ONUs "não sincronizar" entre abas (precisava excluir/re-
// aprovisionar várias vezes até uma gravação "vencer" a corrida contra o
// cron_scan) e (b) o cadastro/config falhando repetidas vezes até "pegar".
//
// AO CONTRÁRIO do mutex de Telnet, este NÃO é fail-open: se não conseguir a
// trava a tempo, quem chamou deve tratar como falha (avisar e deixar tentar de
// novo) em vez de gravar sem proteção — aqui o risco é silenciosamente perder
// dado, não travar a OLT.
// =============================================================================
function olt_json_lock($nome, $maxWait = 6.0) {
    $path = olt_lock_dir() . '/.upd_' . preg_replace('/[^0-9A-Za-z_\.\-]/', '_', (string)$nome) . '.lock';
    $f = @fopen($path, 'c');
    if (!$f) return null;
    @chmod($path, 0666);
    $deadline = microtime(true) + (float)$maxWait;
    while (!@flock($f, LOCK_EX | LOCK_NB)) {
        if (microtime(true) >= $deadline) { @fclose($f); return null; }
        usleep(80000); // 0.08s
    }
    return $f;
}
function olt_json_unlock($f) {
    if (!$f) return;
    @flock($f, LOCK_UN);
    @fclose($f);
}

// =============================================================================
// WRAPPER COM RETRY — reconecta em falhas transitorias de autenticacao/VTY.
// Agora serializado pelo MUTEX acima (mantido durante TODAS as tentativas).
// =============================================================================
function olt_exec($ip, $porta, $user, $pass, array $comandos, $idleTimeout = 8, $tentativas = 2) {
    $lock = olt_telnet_lock($ip);
    $ultimo = null;
    $manual = !empty($GLOBALS['OLT_LOCK_MANUAL']);   // ação disparada pelo operador (ficha/autorizar/trocar VLAN...)
    /* LEITURA DE FUNDO DA TELA sem a vez em 30s: NÃO abre sessão paralela ("fail-open"). Cada uma que
       abria em paralelo somava sessões do mesmo usuário até a OLT recusar todas ("Reenter times have
       reached the upper limit") — modelo/foto/perfil paravam de carregar. Desiste desta rodada; a tela
       tenta de novo. Ação do operador (manual) e cron (CLI) seguem como antes. NÃO REMOVER. */
    /* UMA SESSÃO POR VEZ, SEMPRE (tela, operador e cron). Confirmado na OLT em 23/09/2026: "display client"
       sem sessão presa, mas "All user fail login" com 14.861 recusas do servidor — a OLT limita os logins
       SIMULTÂNEOS do mesmo usuário ("Permitted Reenter Number", 0..4) e recusa o excedente com "Reenter
       times have reached the upper limit". Toda sessão aberta em paralelo (o antigo fail-open) virava
       recusa. Quem não consegue a vez desiste e tenta depois — nunca abre sessão paralela. NÃO REMOVER. */
    if ($lock && empty($lock['held'])) {
        olt_telnet_unlock($lock);
        throw new Exception('OLT ocupada: outra consulta está usando a sessão Telnet — tenta de novo em instantes.');
    }
    for ($i = 0; $i < $tentativas; $i++) {
        try {
            $r = olt_telnet_exec($ip, $porta, $user, $pass, $comandos, $idleTimeout);
            olt_telnet_unlock($lock);
            return $r;
        } catch (Exception $e) {
            $ultimo = $e;
            // Senha errada não melhora tentando de novo: para já (e não arrisca bloquear o usuário na OLT).
            if (stripos($e->getMessage(), 'recusou o usuário/senha') !== false) break;
            // backoff crescente: da tempo da OLT liberar a sessao VTY (era 0,6s/1,2s — curto demais
            // quando o cron ou outra janela esta no meio de uma varredura).
            // OLT sem sessão livre: espera mais (a OLT precisa derrubar a sessão ociosa)
            $semSessao = stripos($e->getMessage(), 'sem sessão Telnet livre') !== false;
            // AÇÃO DO OPERADOR + OLT sem sessão livre ("Reenter times have reached the upper limit"):
            // insiste até 4x com espera maior (8s, 16s, 24s) — a OLT libera a sessão ociosa (SmartOLT/
            // sessões antigas do mesmo usuário) e a ação sai, em vez de falhar na 2ª tentativa.
            if ($semSessao && $manual && $tentativas < 4) $tentativas = 4;
            if ($i < $tentativas - 1) usleep(($semSessao ? ($manual ? 8000000 : 6000000) : 1500000) * ($i + 1)); // 1,5s|6s|8s, 3s|12s|16s, 24s
        }
    }
    olt_telnet_unlock($lock);
    throw new Exception("Falha ao comunicar com a OLT apos $tentativas tentativas: " . ($ultimo ? $ultimo->getMessage() : 'desconhecido'));
}

// =============================================================================
// SERVICE-PORT COM O GEMPORT CERTO (autorização, troca de VLAN e reparo)
// -----------------------------------------------------------------------------
// O comando era sempre "... gemport 1 ...". Em line-profile que não usa o GEM 1 (ex.: o
// SMARTOLT_FLEXIBLE_GPON), a OLT recusava ("Failure") e a autorização IGNORAVA a falha: a ONU ficava
// online, com VLAN "250" na tela, e SEM service-port nenhum — "No service virtual port" — ou seja,
// sem caminho de dados: o cliente não conectava. Aqui: lê o line-profile da ONU, pega os GEM reais,
// tenta o 1º e, se falhar, os outros; em modo bridge aplica a native-vlan na LAN 1; e devolve o
// resultado de verdade (ok / gem / saída) para a tela mostrar.
// =============================================================================
/** ID do line-profile no "display ont info" — EN/PT/qualquer tradução (rótulo com perfil+linha+ID). */
function olt_lp_id_de($info) {
    $t = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]|-+\s*More\s*\(\s*Press[^)]*\)\s*-+/i', ' ', (string)$info);
    if (preg_match('/Line[\s\-]*profile[\s\-]*ID\s*:?\s*(\d+)/i', $t, $m)) return (int)$m[1];
    foreach (preg_split('/\r?\n/', $t) as $ln) {
        if (!preg_match('/^\s*([^:]{3,60}?)\s*:\s*(\d+)\b/u', $ln, $mm)) continue;
        $rot = strtolower($mm[1]);
        if (preg_match('/profile|perfil/', $rot) && preg_match('/\bline|linha/', $rot) && preg_match('/\bid\b/', $rot)) return (int)$mm[2];
    }
    return null;
}
/** Índices GEM do "display ont-lineprofile gpon profile-id N" — EN "<Gem Index 1>" / PT "<Índice GEM 1>". */
function olt_gems_de($raw) {
    $t = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', (string)$raw);
    $g = [];
    if (preg_match_all('/(?:Gem\s*Index|[I\x{00CD}]ndice\s*(?:de\s*)?GEM|GEM\s*[I\x{00CD}]ndice)\s*[:=]?\s*(\d+)/iu', $t, $mm)) $g = array_map('intval', $mm[1]);
    return array_values(array_unique($g));
}
/* "Service virtual port has existed already" (confirmado na OLT, 23/09/2026) = o service-port JÁ EXISTE -> sucesso,
   não falha (antes ia tentar outros GEM à toa). Demais Failure/erro = falha. */
function olt_sp_ja_existe($raw) { return (bool)preg_match('/has\s+existed\s+already|already\s+exist|j[aá]\s+existe/i', (string)$raw); }
function olt_sp_falhou($raw) { if (olt_sp_ja_existe($raw)) return false; return (bool)preg_match('/Failure|invalid|Parameter\s+error|Unknown\s+command|in\s+use|desconhecid/i', (string)$raw); }
function olt_sp_criar($ip, $porta, $user, $pass, $timeout, $slot, $port, $ontId, $vlan, $lpId = null, $bridge = true) {
    $slot = (int)$slot; $port = (int)$port; $ontId = (int)$ontId; $vlan = (int)$vlan;
    $log = '';
    // 1) line-profile da ONU (se não veio) + GEMs dele
    // $bridge === null: decide pelo srv-profile da própria ONU (ONT-* = router; demais = bridge)
    if ($lpId === null || (int)$lpId <= 0 || $bridge === null) {
        $o = olt_exec($ip, $porta, $user, $pass, ['enable', 'config', "interface gpon 0/$slot", "display ont info $port $ontId"], $timeout);
        $info = (string)end($o);
        if ((int)$lpId <= 0) { $lx = olt_lp_id_de($info); if ($lx) $lpId = $lx; }   // EN/PT
        if ($bridge === null) {
            $srv = preg_match('/Service[\s\-]*profile[\s\-]*name\s*:\s*([^\r\n]+)/i', $info, $m) ? trim($m[1]) : '';
            $bridge = !function_exists('olt_srv_tipo') || olt_srv_tipo($srv) !== 'ONT';
        }
    }
    $gems = [];
    if ((int)$lpId > 0) {
        $o = olt_exec($ip, $porta, $user, $pass, ['enable', 'config', 'display ont-lineprofile gpon profile-id ' . (int)$lpId], $timeout);
        $rawLp = (string)($o[2] ?? '');
        $gems = olt_gems_de($rawLp);   // EN/PT
        $log .= "--- line-profile $lpId: GEM " . ($gems ? implode(', ', $gems) : '(nenhum lido)') . " ---\n";
    }
    if (!$gems) $gems = [1, 2, 3, 4];   // GEM não lido: tenta os mais comuns em vez de só o 1
    $gems = array_values(array_unique($gems));
    // 2) tenta criar com cada GEM do perfil, até a OLT aceitar
    foreach ($gems as $g) {
        $cmd = "service-port vlan $vlan gpon 0/$slot/$port ont $ontId gemport $g multi-service user-vlan $vlan";
        $o = olt_exec($ip, $porta, $user, $pass, ['enable', 'config', $cmd], $timeout);
        $raw = (string)($o[2] ?? '');
        $log .= "--- $cmd ---\n" . trim($raw) . "\n";
        if (!olt_sp_falhou($raw)) {
            // 3) bridge: LAN 1 etiqueta o tráfego com a VLAN (sem isso o tráfego sai sem tag e é descartado)
            if ($bridge) {
                $o2 = olt_exec($ip, $porta, $user, $pass, ['enable', 'config', "interface gpon 0/$slot", "ont port native-vlan $port $ontId eth 1 vlan $vlan priority 0"], $timeout);
                $log .= "--- native-vlan eth 1 vlan $vlan ---\n" . trim((string)end($o2)) . "\n";
            }
            return ['ok' => true, 'gem' => $g, 'lp' => $lpId, 'saida' => $log];
        }
    }
    return ['ok' => false, 'gem' => null, 'lp' => $lpId, 'saida' => $log];
}

// =============================================================================
// NORMALIZA SERIAL HUAWEI PARA HEX CANONICO (16 chars minusculos)
//   4857544309D792AC  ou  HWTC09D792AC ("HWTC" = 48 57 54 43)  -> 4857544309d792ac
// =============================================================================
function sn_para_hex($sn) {
    $s = strtoupper(preg_replace('/[^a-z0-9]/i', '', (string)$sn));
    if ($s === '') return '';
    if (preg_match('/^([A-Z]{4})([0-9A-F]{8})$/', $s, $m)) {
        $prefixo = '';
        for ($i = 0; $i < 4; $i++) $prefixo .= sprintf('%02X', ord($m[1][$i]));
        $s = $prefixo . $m[2];
    }
    return strtolower($s);
}

// =============================================================================
// PARSER DA TABELA "display ont info <porta> all"
// A Huawei imprime DUAS tabelas para o mesmo comando:
//   Tabela 1: F/S/P  ONT-ID  SN  Control  Run  Config  Match  Protect
//   Tabela 2: F/S/P  ONT-ID  Description
// Aqui juntamos as duas por (F/S/P + ONT-ID): a linha com token de 16 hex é a
// da tabela 1 (SN + Run state); a outra é a descricao.
// =============================================================================
function parse_lista_ont($saida, $fspDefault = '') {
    // 1) Remove artefatos de terminal (ex.: "[37D") que aparecem no meio das linhas
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    // 2) DESGRUDA linhas: a OLT junta varias ONTs numa linha so (perde o \r\n).
    //    Insere uma quebra antes de cada "F/S/P  ONT-ID" que apareca no meio.
    $saida = preg_replace('/(\d+\s*\/\s*\d+\s*\/\s*\d+\s+\d+\s)/', "\n$1", $saida);

    $porId = [];
    foreach (explode("\n", $saida) as $linha) {
        $l = trim($linha);
        if ($l === '') continue;
        // Linha de dados: F/S/P  ONT-ID  <resto>
        if (!preg_match('#^(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s+(\d+)\s+(.*)$#', $l, $m)) continue;

        $fsp   = $m[1] . '/' . $m[2] . '/' . $m[3];
        $id    = $m[4];
        $resto = trim($m[5]);
        $chave = $fsp . '|' . $id;

        if (!isset($porId[$chave])) {
            $porId[$chave] = [
                'fsp' => $fsp, 'id' => $id, 'serial' => '', 'status' => '', 'estado' => '',
                'nome' => '', 'zona' => '', 'vlan' => '', 'rx' => '', 'tx' => '',
            ];
        }

        // Classifica a linha pelo ESTADO (online/offline), nao pelo formato do SN:
        // a linha da 1a tabela sempre traz o run state; a 2a tabela (descricao) nao.
        $temEstado = preg_match('/\b(online|offline)\b/i', $resto, $st);
        // Serial em qualquer forma: 16 hex OU vendor(4 letras)+[-]+8 hex (ex.: MONU-00E14011)
        $temSerial = preg_match('/\b([0-9A-Fa-f]{16}|[A-Za-z]{4}-?[0-9A-Fa-f]{8})\b/', $resto, $sn);

        if ($temEstado || $temSerial) {
            // Linha da tabela de SN / estado
            if ($temSerial) $porId[$chave]['serial'] = strtoupper(str_replace('-', '', $sn[1]));
            if ($temEstado) $porId[$chave]['status'] = strtolower($st[1]);
            // Estado bruto pela tabela resumo (online/offline). A distincao fina
            // OFFLINE(PwrFail) x LOS x DESATIVADA e feita depois em estado_offline
            // (pela CAUSA de queda), pois "inicial" aparece em TODA ONU offline.
            if (preg_match('/desativ|deactiv/i', $resto))                         $porId[$chave]['estado'] = 'deactivated';
            elseif (preg_match('/\blos\b|loss\s*of\s*signal|LOSi/i', $resto))     $porId[$chave]['estado'] = 'los';
            elseif ($temEstado)                                                   $porId[$chave]['estado'] = strtolower($st[1]);
        } else {
            // Linha da tabela de descricao: "NOME_zone_ZONA_descr_..._lat_..._long_..."
            if ($porId[$chave]['nome'] === '') {
                if (preg_match('/_zone_(.*?)(?:_descr_|_lat_|_long_|_authd_|$)/is', $resto, $mz)) {
                    $porId[$chave]['zona'] = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $mz[1])));
                }
                $partes = preg_split('/_zone_|_descr_|_lat_|_long_|_authd_|authd_/i', $resto);
                // Nome: troca "_" por espaco e colapsa (ex.: ADENIR_MARQUES -> ADENIR MARQUES)
                $porId[$chave]['nome'] = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $partes[0])));
            }
        }
    }
    return array_values($porId);
}

// Duracao em texto curto a partir de segundos: "3d 5h 12min".
function olt_dur_humana($secs) {
    if ($secs < 0) return '';
    $d = intdiv($secs, 86400); $h = intdiv($secs % 86400, 3600); $m = intdiv($secs % 3600, 60);
    $o = ''; if ($d) $o .= $d . 'd '; if ($h || $d) $o .= $h . 'h '; $o .= $m . 'min';
    return trim($o);
}

// =============================================================================
// PARSER ULTRA-RAPIDO: "display ont info summary 0/<slot>" (a PLACA INTEIRA em 1
// comando). Traz por porta: (tabela 1) ONT-ID, estado, ultimo up/down, causa de
// queda; (tabela 2) ONT-ID, SN, Tipo(=MODELO), distancia, Rx/Tx, descricao(nome+zona).
// Retorna a lista completa da placa: status, estado(los/deactivated/offline pela
// causa), serial, modelo, rx, tx, dist, uptime(calculado), nome, zona.
// =============================================================================
function parse_ont_summary($saida, $slot) {
    $r = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', (string)$saida); if ($r !== null) $saida = $r; // remove [37D
    // DESGRUDA (o [37D junta linhas). Se o preg_replace falhar, mantem o original.
    $r = preg_replace('/[ \t](\d{1,3}[ \t]+(?:online|offline)[ \t])/i', "\n$1", $saida); if ($r !== null) $saida = $r;
    $r = preg_replace('/[ \t](\d{1,3}[ \t]+[0-9A-Fa-f]{16}[ \t])/', "\n$1", $saida); if ($r !== null) $saida = $r;
    $onus = []; $port = -1;
    $novo = ['serial' => '', 'status' => '', 'estado' => '', 'nome' => '', 'zona' => '', 'vlan' => '', 'modelo' => '', 'rx' => '', 'tx' => '', 'dist' => '', 'uptime' => ''];
    foreach (preg_split('/\r\n|\r|\n/', $saida) as $l) {
        $l = trim($l);
        if ($l === '') continue;
        // Porta: detecta o token F/S/P "0/<slot>/<porta>" em QUALQUER cabecalho,
        // seja "Na porta 0/1/0", "F/S/P : 0/1/0" ou "0/1/0" sozinho. Como sabemos o
        // slot, ancoramos nele para nao confundir com taxas rx/tx (ex: -25.6/2.1).
        if (preg_match('#(?<![\d.])0\s*/\s*'.$slot.'\s*/\s*(\d+)\b#', $l, $mp)) { $port = (int)$mp[1]; continue; }
        // Fallback: "porta" + quaisquer nao-digitos + N/N/N (com ou sem espacos).
        if (preg_match('/porta\D*?(\d+)\D+(\d+)\D+(\d+)/i', $l, $mp)) { $port = (int)$mp[3]; continue; }
        if ($port < 0) continue;
        $fsp = "0/$slot/$port";
        // TABELA 1: "<id> online|offline <datas> <causa>"
        if (preg_match('/^(\d{1,3})\s+(online|offline)\s*(.*)$/i', $l, $m)) {
            $id = (int)$m[1]; $k = "$fsp|$id"; $resto = $m[3];
            if (!isset($onus[$k])) { $onus[$k] = $novo; $onus[$k]['id'] = (string)$id; $onus[$k]['fsp'] = $fsp; }
            $st = strtolower($m[2]); $onus[$k]['status'] = $st;
            if ($st === 'online') {
                $onus[$k]['estado'] = 'online';
                if (preg_match('/(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})/', $resto, $mu)) { $t = strtotime($mu[1]); if ($t) $onus[$k]['uptime'] = olt_dur_humana(time() - $t); }
            } else {
                $causa = strtolower(trim($resto));
                if (strpos($causa, 'los') !== false || strpos($causa, 'lob') !== false)                 $onus[$k]['estado'] = 'los';
                elseif ($causa === '' || $causa === '-' || preg_match('/^[-\s]+$/', $causa))              $onus[$k]['estado'] = 'deactivated';
                else                                                                                     $onus[$k]['estado'] = 'offline';
                // Tempo OFFLINE: colunas = ID State lastUpTime lastDownTime cause.
                // A 2a data = ultima inatividade (quando caiu) -> offline ha (agora - ela).
                if (preg_match_all('/(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})/', $resto, $mts) && count($mts[1]) >= 2) {
                    $td = strtotime($mts[1][1]); if ($td) $onus[$k]['downtime'] = olt_dur_humana(time() - $td);
                }
            }
            continue;
        }
        // TABELA 2: "<id> <SN> <modelo> <dist> <rx/tx> <descricao>"
        //
        // DUAS CORREÇÕES AQUI, cada uma capaz de PERDER UMA ONU sem avisar:
        //
        //  1. O serial aceitava SÓ 16 hexadecimais. A parse_lista_ont, no mesmo arquivo, sempre
        //     aceitou também o formato de fabricante (MONU-00E14011 = 4 letras + 8 hex). ONU com
        //     serial nesse formato não casava aqui e ficava sem serial — some da contagem que
        //     agrupa por serial e não aparece na busca por SN.
        //  2. As colunas depois do serial eram TODAS obrigatórias, inclusive a descrição. ONU sem
        //     descrição (nunca renomeada) não casava a linha inteira. Agora modelo, distância,
        //     sinal e descrição são opcionais: o que vier é aproveitado, o que faltar fica vazio.
        if (preg_match('/^(\d{1,3})\s+([0-9A-Fa-f]{16}|[A-Za-z]{4}-?[0-9A-Fa-f]{8})(?:\s+(\S+))?(?:\s+(\S+))?(?:\s+(\S+))?(?:\s+(.*))?$/', $l, $m)) {
            $id = (int)$m[1]; $k = "$fsp|$id";
            if (!isset($onus[$k])) { $onus[$k] = $novo; $onus[$k]['id'] = (string)$id; $onus[$k]['fsp'] = $fsp; }
            $onus[$k]['serial'] = strtoupper(str_replace('-', '', $m[2]));
            if (isset($m[3]) && $m[3] !== '' && $m[3] !== '-') $onus[$k]['modelo'] = $m[3];
            if (isset($m[4]) && is_numeric($m[4])) $onus[$k]['dist'] = $m[4];
            if (isset($m[5]) && preg_match('/(-?\d+[.,]\d+)\s*\/\s*(-?\d+[.,]\d+)/', $m[5], $mr)) {
                $onus[$k]['rx'] = str_replace(',', '.', $mr[1]) . ' dBm';
                $onus[$k]['tx'] = str_replace(',', '.', $mr[2]) . ' dBm';
            }
            $desc = trim((string)($m[6] ?? '')); $zona = '';
            if ($desc !== '') {
                if (preg_match('/_zone_(.*)$/i', $desc, $mz)) { $zona = trim(str_replace('_', ' ', $mz[1])); $desc = preg_replace('/_zone_.*$/i', '', $desc); }
                $desc = preg_replace('/_(descr|lat|long|authd)_.*$/i', '', $desc);
                $onus[$k]['nome'] = trim(str_replace('_', ' ', (string)$desc));
                if ($zona !== '') $onus[$k]['zona'] = $zona;
            }
            continue;
        }

        // REDE DE SEGURANÇA — nenhuma ONU registrada pode sumir por causa do layout da coluna.
        //
        // As duas tabelas acima dependem do formato exato da linha. Se a OLT mudar a largura de
        // uma coluna, acrescentar um campo ou devolver um estado que não seja online/offline, a
        // linha deixa de casar e a ONU simplesmente DESAPARECE da lista — sem erro, sem log, só
        // um número menor na tela. Foi assim que o total ficou 696 com a OLT tendo 697.
        //
        // Aqui, qualquer linha dentro de uma porta conhecida que comece por um ONT-ID e traga um
        // serial reconhecível é registrada com o mínimo: F/S/P e ID. Ela entra na contagem e nas
        // telas; os campos que não deram para ler ficam vazios e são preenchidos pelo detalhe
        // (display ont info by-sn) quando o operador abrir a ONU.
        if (preg_match('/^(\d{1,3})\b/', $l, $mid)
            && preg_match('/\b([0-9A-Fa-f]{16}|[A-Za-z]{4}-?[0-9A-Fa-f]{8})\b/', $l, $msn)) {
            $id = (int)$mid[1]; $k = "$fsp|$id";
            if (!isset($onus[$k])) {
                $onus[$k] = $novo; $onus[$k]['id'] = (string)$id; $onus[$k]['fsp'] = $fsp;
                $onus[$k]['serial'] = strtoupper(str_replace('-', '', $msn[1]));
                $onus[$k]['parcial'] = 1;   // marca: linha fora do formato conhecido
            }
        }
    }
    return array_values($onus);
}

// =============================================================================
// PARSER DO BLOCO DETALHADO "display ont info by-sn <SN>"  (chave : valor)
// Bilingue (PT/EN), pois esta OLT responde em portugues:
//   F/S/P : 0/3/13            ID da ONT : 20
//   Estado de execução : online   (EN: Run state : online)
//   SN: 4D4F4E5500E14011 (MONU-00E14011)
//   Descrição: NOME DO CLIENTE ...  (EN: Description:)
// =============================================================================
/** Nome do line/srv-profile pelo ID, usando a lista de perfis já lida da OLT (olt_perfis_olt.json).
 *  Sem a lista, devolve "ID n" (melhor que vazio). */
function olt_perfil_nome_por_id($tipo, $id) {
    static $c = null;
    if ($c === null) { $f = olt_cache_dir() . '/olt_perfis_olt.json'; $c = is_file($f) ? (json_decode(@file_get_contents($f), true) ?: []) : []; }
    foreach ((array)($c[$tipo] ?? []) as $p) { if ((string)($p['id'] ?? '') === (string)$id && !empty($p['nome'])) return (string)$p['nome']; }
    return 'ID ' . $id;
}
function parse_ont_detalhe($saida) {
    $pega = function($rx) use ($saida) {
        return preg_match($rx, $saida, $m) ? trim($m[1]) : '';
    };

    // F/S/P (neutro nos dois idiomas)
    $fsp = $pega('#F\s*/\s*S\s*/\s*P\s*:?\s*([0-9]+\s*/\s*[0-9]+\s*/\s*[0-9]+)#i');

    // ONT-ID: "ID da ONT : 20" (PT) ou "ONT-ID : 20" (EN)
    $id = $pega('/(?:ONT[\s\-]*ID|ID\s+da\s+ONT)\s*:?\s*(\d+)/i');

    // SN: pega o token hexadecimal (evita casar "SN-auth")
    $serial = $pega('/\bSN\s*:?\s*([0-9A-Fa-f]{12,16})\b/');

    // Estado: "Estado de execução : online" (PT) / "Run state : online" (EN)
    $status = strtolower($pega('/(?:Run\s*state|Estado\s+de\s+execu\S*)\s*:?\s*(online|offline)/i'));
    if ($status === '') { // fallback: qualquer online/offline no bloco
        $status = strtolower($pega('/\b(online|offline)\b/i'));
    }

    // Descrição: "Descrição:" (PT) / "Description:" (EN). O texto quebra em
    // varias linhas e termina em tags de metadados (_zone_, _descr_, _lat_...).
    // Captura ate a primeira tag/linha de separacao e limpa artefatos.
    $nome = ''; $zona = '';
    // "Descri..." cobre "Descrição:" (PT) e "Description:" (EN) sem depender do acento
    if (preg_match('/Descri[^\n:]*:\s*(.+?)(?:\r?\n\s*-{5,}|[UÚ]ltim[ao]|Last\s+d)/is', $saida, $m)
        || preg_match('/Descri[^\n:]*:\s*(.+)/i', $saida, $m)) {
        $bloco = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $m[1]); // remove "[37D"
        $bloco = preg_replace('/\s+/', ' ', $bloco);
        if (preg_match('/_zone_(.*?)(?:_descr_|_lat_|_long_|_authd_|$)/i', $bloco, $mz)) {
            $zona = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $mz[1])));
        }
        $partes = preg_split('/_zone_|_descr_|_lat_|_long_|_authd_|authd_/i', $bloco);
        $nome = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $partes[0]))); // "ADENIR_MARQUES" -> "ADENIR MARQUES"
    }

    // Tempo online: "Duração online da ONT: 3 dia(s)..." (PT) / "ONT online duration: 0 day(s)..." (EN).
    // O valor QUEBRA em varias linhas -> captura ate o proximo campo ("Rotulo :")
    // ou linha separadora, removendo artefatos e juntando tudo numa linha so.
    $uptime = '';
    if (preg_match('/(?:online\s+duration|Dura\S*\s+online)[^:\r\n]*:\s*(.+?)(?=\r?\n\s*\S[^:\r\n]*:|\r?\n\s*-{3,}|\r?\n\r?\n|$)/is', $saida, $mu)) {
        $u = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $mu[1]); // remove "[37D"
        $u = trim(preg_replace('/\s+/', ' ', $u));                  // junta as linhas
        // Compacta: "0 day(s), 5 hour(s), 45 minute(s), 30 second(s)" -> "0d 5h 45min 30s"
        $u = preg_replace('/\s*dia\(s\)|\s*day\(s\)/i', 'd', $u);
        $u = preg_replace('/\s*hora\(s\)|\s*hour\(s\)/i', 'h', $u);
        $u = preg_replace('/\s*minuto\(s\)|\s*minute\(s\)/i', 'min', $u);
        $u = preg_replace('/\s*segundo\(s\)|\s*second\(s\)/i', 's', $u);
        $u = trim(preg_replace('/\s+/', ' ', str_replace(',', '', $u)));
        $uptime = $u;
    }

    // Perfis atuais da ONT (p/ migração de perfil): nome do line/srv-profile.
    // EN: "Line profile name : R1" / "Service profile name : R1"
    // PT: "Nome do perfil de linha : R1" / "Nome do perfil de serviço : R1"
    // Lê sobre o texto LIMPO: a paginação ("---- More ----") injeta códigos "\x1b[37D" que podiam cair
    // no meio do rótulo e o perfil vinha vazio (ficha mostrava "não lido"). Aceita "Line-profile",
    // "Line profile", PT "perfil de/da linha" e, sem o nome, o ID ("Line profile ID : 1").
    $limpoP = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]|-+\s*More\s*\(\s*Press[^)]*\)\s*-+/i', ' ', (string)$saida);
    $pegaL = function ($rx) use ($limpoP) { return preg_match($rx, $limpoP, $m) ? trim($m[1]) : ''; };
    $lineprof = $pegaL('/(?:Line[\s\-]*profile[\s\-]*name|Nome\s+do\s+perfil\s+d[ea]\s+linha)\s*:?\s*(\S+)/i');
    $srvprof  = $pegaL('/(?:Service[\s\-]*profile[\s\-]*name|Nome\s+do\s+perfil\s+d[ea]\s+servi\S*)\s*:?\s*(\S+)/i');
    // LEITURA PELO SIGNIFICADO DO RÓTULO (qualquer tradução do firmware): cada linha "rótulo : valor";
    // rótulo com perfil/profile + linha/line (ou serviço/service) + nome/name (ou ID). Ex.: "Nome de
    // perfil de linha", "Line-profile name", "ID do perfil de serviço"...
    if ($lineprof === '' || $srvprof === '') {
        $nomeL = $nomeS = $idL2 = $idS2 = '';
        foreach (preg_split('/\r?\n/', $limpoP) as $ln) {
            if (!preg_match('/^\s*([^:]{3,60}?)\s*:\s*(\S+)/u', $ln, $mm)) continue;
            $rot = strtolower(strtr($mm[1], ['ç' => 'c', 'Ç' => 'c', 'ã' => 'a', 'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'õ' => 'o', 'ú' => 'u', 'ê' => 'e', 'â' => 'a']));
            if (!preg_match('/profile|perfil/', $rot)) continue;
            $ehLinha = (bool)preg_match('/\bline|linha/', $rot); $ehServ = (bool)preg_match('/service|servic/', $rot);
            $ehNome = (bool)preg_match('/name|nome/', $rot);   $ehId = (bool)preg_match('/\bid\b/', $rot);
            if ($ehLinha && $ehNome && $nomeL === '') $nomeL = $mm[2];
            elseif ($ehLinha && $ehId && $idL2 === '') $idL2 = $mm[2];
            elseif ($ehServ && $ehNome && $nomeS === '') $nomeS = $mm[2];
            elseif ($ehServ && $ehId && $idS2 === '') $idS2 = $mm[2];
        }
        if ($lineprof === '') $lineprof = $nomeL !== '' ? $nomeL : ($idL2 !== '' && ctype_digit($idL2) ? olt_perfil_nome_por_id('line', $idL2) : '');
        if ($srvprof === '')  $srvprof  = $nomeS !== '' ? $nomeS : ($idS2 !== '' && ctype_digit($idS2) ? olt_perfil_nome_por_id('srv', $idS2) : '');
    }
    if ($lineprof === '') { $idL = $pegaL('/(?:Line[\s\-]*profile[\s\-]*ID|ID\s+do\s+perfil\s+d[ea]\s+linha)\s*:?\s*(\d+)/i'); if ($idL !== '') $lineprof = olt_perfil_nome_por_id('line', $idL); }
    if ($srvprof === '')  { $idS = $pegaL('/(?:Service[\s\-]*profile[\s\-]*ID|ID\s+do\s+perfil\s+d[ea]\s+servi\S*)\s*:?\s*(\d+)/i'); if ($idS !== '') $srvprof = olt_perfil_nome_por_id('srv', $idS); }

    return [
        'fsp'    => preg_replace('/\s+/', '', $fsp), // "0/ 3/ 13" -> "0/3/13"
        'id'     => $id,
        'serial' => strtoupper($serial),
        'status' => $status,
        'nome'   => $nome,
        'zona'   => $zona,
        'uptime' => $uptime,
        'lineprofile' => $lineprof,
        'srvprofile'  => $srvprof,
        'vlan'   => '', 'rx' => '', 'tx' => '',
    ];
}

// =============================================================================
// PARSER DO SINAL OPTICO "display ont optical-info <porta> <id>"
// =============================================================================
function parse_sinal_optico($saida) {
    $rx = ''; $tx = '';
    // EN: "Rx optical power(dBm) : -20.55"  | PT: "Potência óptica Rx (dBm) : -20.55"
    if (preg_match('/(?:Rx\s*optical\s*power|Pot[\x80-\xFF\w]*\s*[\x80-\xFF\w]*ptica\s*Rx)[^\r\n:]*:?\s*(-?\d+(?:\.\d+)?)/i', $saida, $m)) {
        $rx = $m[1] . ' dBm';
    } elseif (preg_match('/Rx[^\r\n]*?(-?\d{1,2}\.\d+)/i', $saida, $m)) {
        $rx = $m[1] . ' dBm';
    }
    if (preg_match('/(?:Tx\s*optical\s*power|Pot[\x80-\xFF\w]*\s*[\x80-\xFF\w]*ptica\s*Tx)[^\r\n:]*:?\s*(-?\d+(?:\.\d+)?)/i', $saida, $m)) {
        $tx = $m[1] . ' dBm';
    } elseif (preg_match('/Tx[^\r\n]*?(-?\d{1,2}\.\d+)/i', $saida, $m)) {
        $tx = $m[1] . ' dBm';
    }
    // Rx da OLT (o que a OLT recebe da ONU, upstream): "OLT Rx ONT optical power(dBm) : -27.30"
    $rxOlt = '';
    if (preg_match('/(?:OLT\s*Rx|Rx\s*ONT\s*optical)[^\r\n:]*:?\s*(-?\d+(?:\.\d+)?)/i', $saida, $m)) {
        $rxOlt = $m[1] . ' dBm';
    }
    return ['rx' => $rx, 'tx' => $tx, 'rx_olt' => $rxOlt];
}

// =============================================================================
// PARSER DO "display ont autofind all" (ONUs novas aguardando aprovisionamento)
// Cada ONU vem num bloco separado por linhas de "-----". Extrai F/S/P, SN,
// modelo/equipmentID e o horario em que a OLT a encontrou.
// =============================================================================
function parse_autofind($saida) {
    $saida  = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    // Divide um bloco por ONU ancorando em cada "F/S/P" (nao depende das linhas de "-----",
    // que as vezes nao vem: sem separador, o antigo split lia SO a 1a ONU e ignorava o resto).
    $blocos = preg_split('/(?=F\s*\/\s*S\s*\/\s*P)/i', $saida);
    $lista  = []; $vistos = [];
    foreach ($blocos as $b) {
        if (!preg_match('#F\s*/\s*S\s*/\s*P\s*:?\s*([0-9]+\s*/\s*[0-9]+\s*/\s*[0-9]+)#i', $b, $mf)) continue;
        // SN: hex puro (12-16) OU formato vendor (4 letras + 8+ hex), com separadores opcionais.
        if (!preg_match('/(?:Ont\s*)?S\s*N\s*(?:\(.*?\))?\s*:?\s*([0-9A-Za-z]{4}[-\s]?[0-9A-Fa-f]{8,12}|[0-9A-Fa-f]{12,16})/i', $b, $ms)) continue;
        $sn  = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $ms[1]));
        $fsp = preg_replace('/\s+/', '', $mf[1]);
        $key = $fsp . '|' . $sn; if (isset($vistos[$key])) continue; $vistos[$key] = 1; // evita duplicar
        $modelo = '';
        if     (preg_match('/EquipmentID\s*:?\s*(\S+)/i', $b, $me)) $modelo = $me[1];
        elseif (preg_match('/VendorID\s*:?\s*(\S+)/i', $b, $mv))    $modelo = $mv[1];
        // Só a data/hora (a antiga pegava a quebra de linha e a linha de "-----" seguinte junto).
        $tempo = preg_match('/(?:autofind|localiza\w*|encontr\w*)[^:\n]*:\s*([0-9][0-9:\- ]{8,}[0-9](?:[+-][0-9]{2}:?[0-9]{2})?)/i', $b, $mt) ? trim($mt[1]) : '';
        $lista[] = [
            'fsp'    => $fsp,
            'sn'     => $sn,
            'modelo' => $modelo,
            'tempo'  => $tempo,
        ];
    }
    return $lista;
}

// =============================================================================
// VARREDURA COMPLETA EM UMA UNICA SESSAO TELNET
// Para cada slot: entra em "interface gpon 0/<slot>" e roda
// "display ont info <porta> all" em cada porta (forma dentro da interface).
// =============================================================================
function varrer_onts($ip, $porta_tel, $user, $pass, array $slots, array $portas, $idleTimeout, &$brutoPorFsp = null, $noVlan = false) {
    // ULTRA-RAPIDO: 1 "display ont info summary 0/<slot>" por placa (traz status,
    // causa, SN, MODELO, sinal Rx/Tx, distancia, nome/zona, uptime) + 1
    // "display service-port board" por placa (VLAN).
    // (A) Timeout de INATIVIDADE (reseta a cada pagina): so age se a OLT travar de verdade.
    //     E TAMBEM o teto no fim da leitura se o prompt nao for detectado -> tem que ser GENEROSO
    //     (35s) em TODAS as placas: a placa 1 tem ~209 ONUs (muitas paginas) e, com teto baixo,
    //     o resumo estourava antes de terminar e caia na varredura porta-a-porta (MUITO lenta).
    //     Nao atrasa placa pequena: a leitura sai assim que o prompt aparece (retorno antecipado).
    $tSum = max($idleTimeout, 35);
    $comandos = ['enable', 'config'];
    $sumIdx = []; $spIdx = [];
    foreach ($slots as $slot) {
        $comandos[]                  = "display ont info summary 0/$slot";
        $sumIdx[count($comandos) - 1] = $slot;
        // (B) VLAN: so le o service-port board quando NAO for pulado. A VLAN quase nunca muda,
        //     entao no sync da placa grande usamos o CACHE em disco (corta metade do trabalho).
        if (!$noVlan) { $comandos[] = "display service-port board 0/$slot"; $spIdx[count($comandos) - 1] = $slot; }
    }
    $out = olt_exec($ip, $porta_tel, $user, $pass, $comandos, $tSum);

    // (B) Mapa de VLAN com CACHE em disco (olt_vlan_cache.json): quando le, atualiza o cache;
    //     quando pula (noVlan), usa o ultimo conhecido. Assim a VLAN nunca some.
    $vlanMap = olt_jcache_load('olt_vlan_cache.json'); if (!is_array($vlanMap)) $vlanMap = [];
    if (!$noVlan) {
        $vlanFresh = [];
        foreach ($spIdx as $idx => $slot) { $vlanFresh += parse_service_ports($out[$idx] ?? ''); }
        if (!empty($vlanFresh)) { $vlanMap = array_merge($vlanMap, $vlanFresh); olt_jcache_save('olt_vlan_cache.json', $vlanMap); }
    }

    $todas = []; $brutoPorFsp = []; $faltam = [];
    foreach ($sumIdx as $idx => $slot) {
        $bruto = $out[$idx] ?? '';
        $brutoPorFsp["0/$slot"] = $bruto;
        $lst = parse_ont_summary($bruto, $slot);
        if (empty($lst)) { $faltam[] = $slot; continue; }   // resumo falhou nesta placa -> fallback
        foreach ($lst as $ont) {
            $k = $ont['fsp'] . '|' . $ont['id'];
            if (!empty($vlanMap[$k])) $ont['vlan'] = $vlanMap[$k];
            $todas[] = $ont;
        }
    }

    // FALLBACK porta-a-porta (so das placas que o resumo nao trouxe) — sempre funciona.
    if (!empty($faltam)) {
        $c2 = ['enable', 'config']; $mapa = [];
        foreach ($faltam as $slot) {
            $c2[] = "interface gpon 0/$slot";
            foreach ($portas as $p) { $c2[] = "display ont info $p all"; $mapa[count($c2) - 1] = "0/$slot/$p"; }
            $c2[] = "quit";
        }
        $out2 = olt_exec($ip, $porta_tel, $user, $pass, $c2, $idleTimeout);
        foreach ($mapa as $idx => $fsp) {
            foreach (parse_lista_ont($out2[$idx] ?? '', $fsp) as $ont) {
                $k = $ont['fsp'] . '|' . $ont['id'];
                if (!empty($vlanMap[$k])) $ont['vlan'] = $vlanMap[$k];
                $todas[] = $ont;
            }
        }
    }

    $todas = olt_dedup($todas);
    // Enriquece com o cache (MODO/modelo/sinal/estado ja lidos) — sem tocar na OLT.
    $det   = olt_detalhe_cache_load();
    $sinal = olt_jcache_load('olt_sinal_cache.json');
    $estd  = olt_estado_cache_load();
    foreach ($todas as &$o) {
        $k = $o['fsp'] . '|' . $o['id'];
        if (isset($det[$k]) && olt_det_do_aparelho($det[$k], $o['serial'] ?? '')) {   // só se for o MESMO aparelho (SN)
            if (empty($o['modelo']) && !empty($det[$k]['modelo'])) $o['modelo'] = $det[$k]['modelo'];
            if (empty($o['uptime']) && !empty($det[$k]['uptime'])) $o['uptime'] = $det[$k]['uptime'];
            if (!empty($det[$k]['modo'])) $o['modo'] = $det[$k]['modo'];
            if (!empty($det[$k]['srv']))  $o['srv']  = $det[$k]['srv'];
        }
        if (isset($sinal[$k])) { foreach (['rx', 'tx', 'rx_olt', 'dist'] as $c) { if (empty($o[$c]) && !empty($sinal[$k][$c])) $o[$c] = $sinal[$k][$c]; } }
        if (empty($o['estado']) && !empty($estd[$k]) && stripos((string)$o['status'], 'online') === false) { $o['estado'] = $estd[$k]; }
    }
    unset($o);
    return $todas;
}

// =============================================================================
// PARSER de "display service-port board 0/<slot>" -> mapa "fsp|ontid" => vlan
// Formato tipico: colunas INDEX  VLANID  ... F/S/P ... ONT ... (varia o layout).
// Extrai, por linha, o F/S/P (0/x/y), o ONT-ID e a VLAN. Tolerante a espacos.
// =============================================================================
function olt_vlan_valida($n) {
    // VLAN valida no padrao 802.1Q (1..4094). Filtra apenas valores impossiveis
    // (0 e >=4095), sem prender a rede a uma lista fixa de VLANs.
    return $n >= 1 && $n <= 4094;
}
// PARSER ROBUSTO do "display service-port board 0/<slot>" -> "fsp|ontid" => vlan.
// Formato V800R018 (colunas): INDEX  VLANID  VLAN-ATTR  PORT-TYPE  F/S/P  ONT-ID  ...
// A saida vem GRUDADA (perde \r\n). Em vez de "desgrudar" pelo F/S/P (o que jogava
// a VLAN para a linha anterior -> coluna VLAN vazia), ancoramos no proprio padrao:
//   <VLANID> (common|transparent) <PORT-TYPE> <F/S/P> <ONT-ID>
// Isso captura VLAN + F/S/P + ONT-ID de uma vez, mesmo com tudo numa linha so.
function parse_service_ports($saida) {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    $map = [];

    // 1) PADRAO PRINCIPAL: <VLANID> <ATTR> <PORT-TYPE> <F/S/P> <ONT-ID>
    //    ...  263  common  gpon  0/3/13  20  ...   (ATTR = common/transparent/qinq/...)
    //    Ancora em "numero + 2 termos alfabeticos + F/S/P + numero" -> nao depende
    //    da palavra exata do atributo (pega todas as VLANs, nao so common/transparent).
    if (preg_match_all('/(\d{1,4})\s+([A-Za-z][\w\-]*)\s+([A-Za-z][\w\-]*)\s+(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)\s+(\d+)/', $saida, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) {
            $vlan = (int)$m[1];
            $fsp  = $m[4] . '/' . $m[5] . '/' . $m[6];
            $ont  = (int)$m[7];
            if (olt_vlan_valida($vlan)) $map[$fsp . '|' . $ont] = (string)$vlan;
        }
    }

    // 2) FALLBACK (layouts sem a palavra common/transparent): desgruda por F/S/P
    //    e pega o 1o numero valido (!= ONT-ID) na janela em volta do F/S/P.
    $des = preg_replace('/(\d+\s*\/\s*\d+\s*\/\s*\d+)/', "\n$1", $saida);
    foreach (explode("\n", $des) as $l) {
        $l = trim($l);
        if (!preg_match('#(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s+(\d+)#', $l, $mf)) continue; // F/S/P + ONT-ID
        $fsp = $mf[1] . '/' . $mf[2] . '/' . $mf[3];
        $ont = (int)$mf[4];
        if (isset($map[$fsp . '|' . $ont])) continue; // ja resolvido pelo padrao principal
        preg_match_all('/\b(\d{1,4})\b/', $l, $nums);
        foreach ($nums[1] as $n) {
            $n = (int)$n;
            if ($n !== $ont && $n !== (int)$mf[1] && $n !== (int)$mf[2] && $n !== (int)$mf[3] && olt_vlan_valida($n)) {
                $map[$fsp . '|' . $ont] = (string)$n; break;
            }
        }
    }
    return $map;
}

// =============================================================================
// PARSER do "display ont optical-info <porta> all" -> "fsp|ontid" => [rx,tx]
// Formato V800R018 (colunas): ONT-ID  Rx power(dBm)  Tx power(dBm)  ...
// A saida vem grudada; cada linha de dados comeca pelo ONT-ID. O RX optico da
// ONU e sempre NEGATIVO (~ -8 a -30 dBm); o TX da ONU e positivo (~ 0 a 5).
// Heuristica robusta: RX = 1o decimal NEGATIVO da linha; TX = 1o decimal
// positivo (0..10) apos o RX. Evita depender da largura/ordem exata das colunas.
// =============================================================================
// Colunas reais (V800R018): ONT-ID  Rx(dBm)  Tx(dBm)  OLT-Rx(dBm)  Temp(C)  Voltage  Current  Distance
//   1  -23.87    2.15      -28.54      38           3.300    9        4516
// Ancora nas 3 colunas de potencia consecutivas (Rx neg, Tx, OLT-Rx neg) + o inteiro
// da temperatura, e pega Rx/Tx pela POSICAO. Assim a tensao (3.3xx) e a temperatura
// nunca sao confundidas com o Rx, mesmo com a saida grudada e artefatos [37D.
function parse_optical_all($saida, $fspBase) {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida); // remove [37D
    $map = [];
    // ONT-ID  Rx(ONU)  Tx(ONU)  OLT-Rx  Temp  Voltage  Current  Distance
    if (preg_match_all('/(?:^|\s)(\d{1,3})\s+(-?\d{1,2}\.\d{1,2})\s+(-?\d{1,2}\.\d{1,2})\s+(-?\d{1,2}\.\d{1,2})\s+\d+(?:\s+[\d.]+\s+\d+\s+(\d+))?/', $saida, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) {
            $id = (int)$m[1];
            $map[$fspBase . '|' . $id] = [
                'rx'     => $m[2] . ' dBm',   // Rx da ONU (downstream)
                'tx'     => $m[3] . ' dBm',   // Tx da ONU
                'rx_olt' => $m[4] . ' dBm',   // Rx que a OLT recebe da ONU (upstream)
                'dist'   => isset($m[5]) ? $m[5] : '',
            ];
        }
    }
    return $map;
}

// ---------------- Cache de detalhes por ONU (modelo + uptime) ----------------
// Modelo e estavel; guardamos em disco p/ nao reconsultar a OLT toda abertura.
/* TROCA DE EQUIPAMENTO NA MESMA PORTA — o cache de detalhe (modelo/modo/perfil) é indexado por
   "F/S/P|ID". Quando uma ONT é retirada e uma ONU nova entra na MESMA porta com o MESMO ID, a
   ONU nova herdava o modelo e o modo (Bridge/Router) do aparelho antigo. Agora cada registro guarda
   o SN do aparelho ('sn'), e só vale se o SN que está HOJE naquela posição for o mesmo; registro
   sem SN (antigo) também não é confiado para modelo/modo — o modelo real é lido de novo da OLT. */
function olt_sn_norm_pos($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); }
/** Mapa "fsp|id" => serial atual, a partir da lista da OLT em cache (memorizado por requisição). */
function olt_pos_sn() {
    static $m = null;
    if ($m !== null) return $m;
    $m = [];
    $c = function_exists('olt_cache_load') ? olt_cache_load() : [];
    foreach ((array)($c['slots'] ?? []) as $arr) {
        if (!is_array($arr)) continue;
        foreach ($arr as $o) { if (!empty($o['fsp']) && isset($o['id']) && !empty($o['serial'])) $m[$o['fsp'] . '|' . $o['id']] = olt_sn_norm_pos($o['serial']); }
    }
    return $m;
}
/** O registro do cache de detalhe pertence a ESTE aparelho? (mesmo SN gravado) */
function olt_det_do_aparelho($reg, $serialAtual) {
    $sn = olt_sn_norm_pos($reg['sn'] ?? '');
    return $sn !== '' && $sn === olt_sn_norm_pos($serialAtual);
}
function olt_detalhe_cache_path() { return olt_cache_dir() . '/olt_detalhe_cache.json'; }
function olt_detalhe_cache_load() {
    $f = olt_detalhe_cache_path();
    if (!is_file($f)) return [];
    $d = json_decode(@file_get_contents($f), true);
    return is_array($d) ? $d : [];
}
function olt_detalhe_cache_save($c) { @file_put_contents(olt_detalhe_cache_path(), json_encode($c, JSON_UNESCAPED_UNICODE)); }
// LOG/RELATORIO da OLT: registra eventos (aprovisionamento/retirada/etc) e mantem contadores
// do DIA e do MES em cache_trafego/olt_relatorio.json. Reset automatico: vira o dia -> zera
// os do dia; vira o mes (dia 1) -> arquiva o mes anterior em historico_mes e zera os do mes.
function olt_relatorio_rollover(&$d) {
    if (!isset($d['contadores']) || !is_array($d['contadores'])) $d['contadores'] = [];
    if (!isset($d['historico_mes']) || !is_array($d['historico_mes'])) $d['historico_mes'] = [];
    $c = &$d['contadores']; $hoje = date('Y-m-d'); $mes = date('Y-m'); $mud = false;
    if (($c['dia'] ?? '') !== $hoje) { $c['dia'] = $hoje; $c['aprov_dia'] = 0; $c['retirada_dia'] = 0; $mud = true; }
    if (($c['mes'] ?? '') !== $mes) {
        if (!empty($c['mes'])) $d['historico_mes'][$c['mes']] = ['aprov' => (int)($c['aprov_mes'] ?? 0), 'retirada' => (int)($c['retirada_mes'] ?? 0)];
        $c['mes'] = $mes; $c['aprov_mes'] = 0; $c['retirada_mes'] = 0; $mud = true;
        // AUTO-LIMPA todo dia 1: zera o histórico de EVENTOS do mês anterior (os totais ficam
        // guardados em historico_mes). Roda na 1a vez que o relatório é lido no mês novo.
        $d['eventos'] = [];
    }
    return $mud;
}
function olt_log_registrar($tipo, $desc, $fsp = '') {
    $d = olt_jcache_load('olt_relatorio.json');   // dual-cache: tela e cron gravam/leem a MESMA fonte
    if (!is_array($d)) $d = [];
    if (!isset($d['eventos']) || !is_array($d['eventos'])) $d['eventos'] = [];
    olt_relatorio_rollover($d);
    $c = &$d['contadores'];
    if ($tipo === 'aprovisionamento') { $c['aprov_dia'] = ($c['aprov_dia'] ?? 0) + 1; $c['aprov_mes'] = ($c['aprov_mes'] ?? 0) + 1; }
    elseif ($tipo === 'retirada')      { $c['retirada_dia'] = ($c['retirada_dia'] ?? 0) + 1; $c['retirada_mes'] = ($c['retirada_mes'] ?? 0) + 1; }
    array_unshift($d['eventos'], ['ts' => time(), 'data' => date('Y-m-d H:i:s'), 'tipo' => $tipo, 'desc' => substr((string)$desc, 0, 160), 'fsp' => $fsp]);
    if (count($d['eventos']) > 800) $d['eventos'] = array_slice($d['eventos'], 0, 800);
    unset($c);
    olt_jcache_save('olt_relatorio.json', $d);
}
// Calcula as PONs em QUEDA TOTAL a partir de uma lista de ONUs e REGISTRA no relatório as
// TRANSIÇÕES (entrou/saiu de queda) comparando com o estado anterior. Retorna a lista de alertas.
// Usado por acao=pon_alertas (poll do navegador) e acao=cron_scan (cron 24/7).
function olt_pon_alertas_e_log($all) {
    $portas = [];
    foreach ($all as $o) {
        $p = $o['fsp'] ?? ''; if ($p === '') continue;
        if (!isset($portas[$p])) $portas[$p] = ['total' => 0, 'down' => 0, 'los' => 0, 'off' => 0];
        $portas[$p]['total']++;
        // 17/11/2026 (PON 0/1/0 dava "falta de energia" falso várias vezes ao dia): a leitura SNMP rápida (olt_snmp_status_rapido) rebaixa o
        // 'status' para offline quando a ONU some de UM ciclo, mas deixa 'estado' = 'online' (a última leitura Telnet da própria OLT). ONU que a
        // OLT acabou de listar ONLINE NÃO conta como caída aqui: queda real vem do scan Telnet seguinte (estado offline/los) e do detector SNMP.
        $e = strtolower($o['estado'] ?? ''); $isOn = (strpos(strtolower($o['status'] ?? ''), 'online') !== false) || $e === 'online';
        if (!$isOn) { $portas[$p]['down']++; if ($e === 'los') $portas[$p]['los']++; elseif ($e !== 'deactivated') $portas[$p]['off']++; }
    }
    // Nomes/descrições das PONs (do banco local olt_meta.json -> grupo "porta") p/ mostrar no alerta.
    $mf = olt_cache_dir_g() . '/olt_meta.json';
    $meta = is_file($mf) ? json_decode(@file_get_contents($mf), true) : [];
    $pnome = (is_array($meta) && isset($meta['porta']) && is_array($meta['porta'])) ? $meta['porta'] : [];
    $nomeDe = function ($pon) use ($pnome) { return isset($pnome[$pon]) ? trim($pnome[$pon]) : ''; };
    $alertas = [];
    foreach ($portas as $p => $g) {
        if ($g['total'] >= 3 && $g['down'] >= $g['total']) $alertas[] = ['pon' => $p, 'nome' => $nomeDe($p), 'tipo' => ($g['los'] >= $g['off'] ? 'los' : 'energia'), 'total' => $g['total']];
    }
    // ANOMALIA DE PLACA (mesmo critério do SNMP): se VÁRIAS PONs da MESMA placa aparecem "em queda total"
    // na MESMA varredura, é falha do scan Telnet daquela placa (ou a placa caiu) — NÃO são quedas de PON
    // individuais. Queda real é 1 (ou poucas) porta isolada. Descarta as placas com >=4 PONs alertando juntas.
    $slotAnom = array();
    if (count($alertas) >= 4) {
        $cntSlot = array();
        foreach ($alertas as $a) { $pp = explode('/', $a['pon']); $sl = isset($pp[1]) ? $pp[1] : '?'; $cntSlot[$sl] = (isset($cntSlot[$sl]) ? $cntSlot[$sl] : 0) + 1; }
        foreach ($cntSlot as $sl => $c) { if ($c >= 4) $slotAnom[$sl] = 1; }
        if (!empty($slotAnom)) {
            $novo = array();
            foreach ($alertas as $a) { $pp = explode('/', $a['pon']); $sl = isset($pp[1]) ? $pp[1] : '?'; if (empty($slotAnom[$sl])) $novo[] = $a; }
            $alertas = $novo;
        }
    }
    // SEGUNDA OPINIÃO DO SNMP (fresco, 1 min): se o SNMP viu ONUs ONLINE nesta PON há < 6 min, a varredura
    // Telnet que a marcou "toda offline" estava INCOMPLETA -> NÃO é queda (descarta). Se o SNMP também vê 0
    // (ou não tem dado recente), o alerta segue normal -> queda REAL continua sendo detectada.
    if ($alertas) {
        $sp = olt_jcache_load('olt_snmp_ponline.json');
        if (is_array($sp) && isset($sp['on']) && is_array($sp['on']) && (time() - (int)($sp['ts'] ?? 0)) < 360) {
            $spon = $sp['on']; $novo = array();
            foreach ($alertas as $a) { if ((int)($spon[$a['pon']] ?? 0) > 0) continue;   // SNMP viu online -> Telnet incompleto
                $novo[] = $a; }
            $alertas = $novo;
        }
    }
    $stF = olt_cache_dir() . '/olt_pon_estado.json';
    $prev = is_file($stF) ? json_decode(@file_get_contents($stF), true) : []; if (!is_array($prev)) $prev = [];
    $cur = []; $qtdPon = [];
    foreach ($alertas as $a) { $cur[$a['pon']] = $a['tipo']; $qtdPon[$a['pon']] = $a['total']; }
    // CORREÇÃO: numa varredura PARCIAL (só algumas placas no cache), as PONs sem dados nesta
    // rodada NÃO podem ser tratadas como "normalizou" — isso gerava retorno falso no relatório
    // e fazia a queda das outras placas (1/3/5) sumir. Aqui o estado delas é PRESERVADO.
    foreach ($prev as $pon => $tipo) {
        if (isset($cur[$pon])) continue;
        $pp = explode('/', $pon); $sl = isset($pp[1]) ? $pp[1] : '?';
        // Preserva quem não foi varrido nesta rodada OU está numa placa anômala (glitch) — evita "normalizou" falso.
        if (!isset($portas[$pon]) || isset($slotAnom[$sl])) $cur[$pon] = $tipo;
    }
    if ($cur != $prev) { // só grava quando muda de verdade (evita repetir a cada checagem)
        // Linhas da NOTIFICAÇÃO (uma PON por linha, com marcador) — igual ao alerta
        // visual: "• 0/1/4 P_4 - SLT1_SANTA FE (energia)".
        $qBullets = []; $rBullets = [];
        foreach ($cur as $pon => $tipo) {
            $nm = $nomeDe($pon); $rot = 'PON ' . $pon . ($nm !== '' ? ' (' . $nm . ')' : '');
            if (!isset($prev[$pon]) || $prev[$pon] !== $tipo) {
                olt_log_registrar('pon_queda', $rot . ' em QUEDA TOTAL — ' . ($tipo === 'los' ? 'LOS' : 'falta de energia') . ' (' . ($qtdPon[$pon] ?? '?') . ' ONUs)', $pon);
                $qBullets[] = '🔴 ' . $pon . ($nm !== '' ? ' ' . $nm : '') . ' (' . ($tipo === 'los' ? 'LOS' : 'energia') . ')';
            }
        }
        foreach ($prev as $pon => $tipo) {
            if (!isset($cur[$pon])) {
                $nm = $nomeDe($pon); $rot = 'PON ' . $pon . ($nm !== '' ? ' (' . $nm . ')' : '');
                olt_log_registrar('pon_retorno', $rot . ' NORMALIZOU — voltou de ' . ($tipo === 'los' ? 'LOS' : 'falta de energia'), $pon);
                $rBullets[] = '🟢 ' . $pon . ($nm !== '' ? ' ' . $nm : '');
            }
        }
        @file_put_contents($stF, json_encode($cur, JSON_UNESCAPED_UNICODE));
        /* NOTIFICA (Telegram/WhatsApp) as transições. AVISO DETALHADO (24/09/2026, pedido do provedor: "a mensagem
           da Atenção da OLT, aprimorada com as informações"): antes era só "🔴 0/1/4 P_4 (energia)". Agora cada PON
           vem em bloco: ONDE (placa com nome, porta, zona, descrição), O QUE (fibra/LOS ou energia), QUANTAS ONUs e
           QUAIS clientes (até 10), e a hora. Mesmo formato do aviso pelos alarmes (olt_alarmes_*). */
        $placaNm = (is_array($meta) && isset($meta['placa']) && is_array($meta['placa'])) ? $meta['placa'] : [];
        $pzona   = (is_array($meta) && isset($meta['portazona']) && is_array($meta['portazona'])) ? $meta['portazona'] : [];
        $bloco = function ($pon, $tipo, $caiu) use ($all, $nomeDe, $placaNm, $pzona, $qtdPon) {
            $pp = explode('/', $pon); $sl = $pp[1] ?? '?'; $pt = $pp[2] ?? '?';
            $pl = trim((string)($placaNm[$sl] ?? ($placaNm['0/' . $sl] ?? '')));
            $nomes = []; $zc = [];
            foreach ($all as $o) { if (($o['fsp'] ?? '') !== $pon) continue;
                $nn = trim((string)($o['nome'] ?? '')); if ($nn !== '') $nomes[] = $nn;
                $z = trim((string)($o['zona'] ?? '')); if ($z !== '') $zc[$z] = ($zc[$z] ?? 0) + 1; }
            $zona = trim((string)($pzona[$pon] ?? '')); if ($zona === '' && $zc) { arsort($zc); reset($zc); $zona = (string)key($zc); }
            $nomes = array_values(array_unique($nomes)); $tot = (int)($qtdPon[$pon] ?? count($nomes));
            // mesmo formato ENXUTO do aviso pelos alarmes (olt_alarmes_*): título · causa / local / zona+descrição / ONUs / clientes
            $t  = ($caiu ? ($tipo === 'los' ? "🔴 *PON CAIU* · sem sinal (LOS)\n" : "🔴 *PON CAIU* · falta de energia\n")
                         : "🟢 *PON VOLTOU* · " . ($tipo === 'los' ? 'sinal restabelecido' : 'energia restabelecida') . "\n");
            $t .= "📍 Placa " . $sl . ($pl !== '' ? " ($pl)" : '') . " · Porta " . $pt . " · " . $pon . "\n";
            $extra = array_filter([$zona !== '' ? 'Zona ' . $zona : '', $nomeDe($pon)], fn($x) => $x !== '');
            if ($extra) $t .= "🗺️ " . implode(' · ', $extra) . "\n";
            if ($caiu) {
                $t .= ($tipo === 'los' ? "⛔ " : "⚡ ") . ($tot ? $tot . " ONUs" : "Todas as ONUs") . " fora · "
                    . ($tipo === 'los' ? "provável fibra/splitter" : "sem energia na área") . "\n";
                if ($nomes) $t .= "👥 Clientes: " . implode(', ', array_slice($nomes, 0, 10)) . (count($nomes) > 10 ? ' (+' . (count($nomes) - 10) . ')' : '') . "\n";
            }
            return $t;
        };
        $hora = "🕐 " . date('d/m H:i');
        $blQ = []; foreach ($cur as $pon => $tipo) if (!isset($prev[$pon]) || $prev[$pon] !== $tipo) $blQ[] = $bloco($pon, $tipo, true);
        $blR = []; foreach ($prev as $pon => $tipo) if (!isset($cur[$pon])) $blR[] = $bloco($pon, $tipo, false);
        if (!empty($blQ)) {
            $n = count($blQ);
            olt_notificar(($n > 1 ? "⚠️ *" . $n . " PONs em QUEDA TOTAL*\n\n" : '') . implode("\n", $blQ) . $hora);
        }
        if (!empty($blR)) {
            $n = count($blR);
            olt_notificar(($n > 1 ? "✅ *" . $n . " PONs VOLTARAM*\n\n" : '') . implode("\n", $blR) . $hora);
        }
    }
    return $alertas;
}
// ---- HISTÓRICO de conexões (p/ o gráfico dia/semana/mês) ----------------------
// Um ponto por HORA (arquivo minúsculo: ~720 pontos = 1 mês). Guarda online,
// total, pico e vale da hora e nº de PONs em queda. Cap ~800h (~33 dias).
function olt_hist_registrar($todas, $ponsQueda) {
    // Classifica cada ONU em 4 faixas (igual à legenda do gráfico):
    //   on = Online · en = Falha de Energia · los = LOS · na = N/A (sem estado).
    $on = 0; $en = 0; $los = 0; $na = 0; $tot = 0;
    foreach ($todas as $o) {
        $tot++;
        if (strpos(strtolower($o['status'] ?? ''), 'online') !== false) { $on++; continue; }
        $e = strtolower($o['estado'] ?? '');
        if ($e === 'los') $los++;
        elseif ($e === '' || $e === 'deactivated') $na++;
        else $en++;
    }
    if ($tot === 0) return;                       // varredura vazia: não polui o histórico
    // ---- BUFFER FINO (por minuto): mostra as variações reais (ONU entra/sai) ----
    // Usado nos modos "hora" e "diário". Dedup por MINUTO; guarda ~1200 pontos.
    $f = olt_cache_dir() . '/olt_hist.json';
    $h = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
    if (!is_array($h)) $h = [];
    $minuto = date('Y-m-d H:i');
    $n = count($h);
    $pt = ['h' => $minuto, 't' => time(), 'on' => $on, 'en' => $en, 'los' => $los, 'na' => $na, 'tot' => $tot, 'dn' => (int)$ponsQueda];
    if ($n && ($h[$n - 1]['h'] ?? '') === $minuto) { $h[$n - 1] = $pt; }   // mesmo minuto: atualiza
    else { $h[] = $pt; }
    if (count($h) > 1440) $h = array_slice($h, -1440);   // 24h a 1 ponto/min
    @file_put_contents($f, json_encode($h, JSON_UNESCAPED_UNICODE));
    // ---- RESUMO DIÁRIO: 1 ponto/dia (média + pico/vale). Semana/mês/ano leem daqui. ----
    $fd = olt_cache_dir() . '/olt_hist_dia.json';
    $hd = is_file($fd) ? json_decode(@file_get_contents($fd), true) : [];
    if (!is_array($hd)) $hd = [];
    $dia = date('Y-m-d'); $m = count($hd);
    if ($m && ($hd[$m - 1]['d'] ?? '') === $dia) {
        $g = $hd[$m - 1]; $g['soma'] += $on; $g['nn']++;
        $g['on'] = (int)round($g['soma'] / $g['nn']);
        $g['max'] = max((int)$g['max'], $on); $g['min'] = min((int)$g['min'], $on);
        $g['en'] = $en; $g['los'] = $los; $g['na'] = $na; $g['tot'] = $tot; $g['dn'] = max((int)$g['dn'], (int)$ponsQueda);
        $hd[$m - 1] = $g;
    } else {
        $hd[] = ['d' => $dia, 'soma' => $on, 'nn' => 1, 'on' => $on, 'max' => $on, 'min' => $on, 'en' => $en, 'los' => $los, 'na' => $na, 'tot' => $tot, 'dn' => (int)$ponsQueda];
    }
    if (count($hd) > 400) $hd = array_slice($hd, -400);
    @file_put_contents($fd, json_encode($hd, JSON_UNESCAPED_UNICODE));
}
// ---- RADIUS EMERGÊNCIA: liga/desliga "Qualquer login" no(s) painel(is) accel-ppp ----
// Fala DIRETO com o painel do concentrador (independente do Radius): faz login e
// posta o mesmo que o botão "Aplicar" (rad=3 = Qualquer login · rad=0 = Radius).
function olt_radpanel_file() { return olt_cache_dir() . '/olt_radpanel.json'; }
function olt_radpanel_load() { $f = olt_radpanel_file(); $c = is_file($f) ? json_decode(@file_get_contents($f), true) : []; return is_array($c) ? $c : []; }
function olt_radpanel_aplicar($p, $rad) {
    $base = trim($p['base'] ?? '');               // ex.: http://192.0.2.21:8086/adm
    $base = preg_replace('#/[^/]*\.php.*$#i', '', $base);   // tira /index.php (ou qualquer arquivo .php) do fim
    $base = rtrim($base, '/');
    $nome = trim($p['nome'] ?? '') !== '' ? $p['nome'] : $base;
    if ($base === '') return ['nome' => $nome, 'ok' => false, 'msg' => 'sem URL'];
    if (!function_exists('curl_init')) return ['nome' => $nome, 'ok' => false, 'msg' => 'cURL indisponível no PHP'];
    // UMA ÚNICA conexão cURL: mantém o cookie de sessão (PHPSESSID) na memória entre as
    // chamadas — cookies de SESSÃO não persistem entre conexões separadas (era o bug do 500).
    $origin = preg_replace('#^(https?://[^/]+).*$#i', '$1', $base);   // http://IP:porta
    $ch = curl_init();
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/150 Safari/537.36', CURLOPT_COOKIEFILE => '']);
    $post = function ($url, $fields, $to = 12, $ref = null) use ($ch, $base, $origin) {
        curl_setopt_array($ch, [CURLOPT_URL => $url, CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_TIMEOUT => $to, CURLOPT_REFERER => ($ref ?: $base . '/main.php'),
            CURLOPT_HTTPHEADER => ['X-Requested-With: XMLHttpRequest', 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
                'Origin: ' . $origin, 'Accept: */*', 'Accept-Language: pt-BR,pt;q=0.9']]);
        $r = curl_exec($ch); $e = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        return [$r, $e, $code];
    };
    $post($base . '/index.php', []);   // abre a PÁGINA DE LOGIN (pega o PHPSESSID)
    $u = $p['user'] ?? ''; $pw = $p['pass'] ?? '';
    // db_read.php É o login: valida E cria a sessão (mesma chamada do navegador, referer da página de login).
    list($lr, $le, $lc) = $post($base . '/php/db_read.php', ['select' => 'id|name|email|level|acces', 'table' => 'auth',
        'colun' => 'login =|and|passwd =|and|acces =', 'search' => $u . '|' . $pw . '|1', 'crypt' => '1'], 12, $base . '/index.php');
    if ($le) { curl_close($ch); return ['nome' => $nome, 'ok' => false, 'msg' => 'login: ' . $le]; }
    $post($base . '/main.php', [], 12, $base . '/index.php');   // navega pro painel (finaliza a sessão, como o navegador)
    $post($base . '/frm_pppoe.php', [], 12, $base . '/main.php');   // abre PPPoE/IPoE
    $post($base . '/tab_radius.php', [], 12, $base . '/main.php');  // abre a aba Radius (prepara o contexto)
    $post($base . '/php/read_radiusdb.php', [], 12, $base . '/main.php');   // carrega a config atual do Radius
    // 2) aplica rad (dmco/inter/defrat ficam como configurados; só rad muda)
    $campos = ['dmco' => ((($p['dmco'] ?? '') !== '') ? $p['dmco'] : '3799'), 'inter' => ((($p['inter'] ?? '') !== '') ? $p['inter'] : '300'), 'rad' => $rad, 'defrat' => (($p['defrat'] ?? '') !== '' ? $p['defrat'] : '3')];
    list($r1, $e1, $c1) = $post($base . '/php/update_radiusdb.php', $campos);
    usleep(500000);   // deixa o banco gravar antes de regenerar o arquivo
    list($r2, $e2, $c2) = $post($base . '/php/update_radfile.php', $campos, 40);   // regen do accel-ppp demora — mais tempo
    curl_close($ch);
    $corte = function ($s) { $s = trim(preg_replace('/\s+/', ' ', strip_tags((string)$s))); return mb_substr($s, 0, 120); };
    $diag = 'login[' . $lc . ']=' . $corte($lr) . ' · db[' . $c1 . ']=' . $corte($r1) . ' · file[' . $c2 . ']=' . $corte($r2);
    $ok = ($c1 >= 200 && $c1 < 400 && !$e1);
    return ['nome' => $nome, 'ok' => $ok, 'msg' => ($ok ? 'aplicado (rad=' . $rad . ')' : 'não aplicou'), 'diag' => $diag];
}
// ---- BACKUP automático diário por e-mail (chamado pelo cron_scan) -------------
// Monta o mesmo bundle do backup_export e envia como anexo .json. Envia no
// máximo 1x/dia, quando o horário marcado já passou. mail() precisa estar ativo.
// Cliente SMTP mínimo (fsockopen). Segurança: 'ssl' (465) / 'tls' STARTTLS (587) / 'none'.
function olt_smtp_enviar($s, $to, $subject, $mimeHeaders, $body) {
    $host = trim($s['smtp_host'] ?? ''); $port = (int)($s['smtp_port'] ?? 0);
    $seg = strtolower($s['smtp_seg'] ?? 'tls'); $user = $s['smtp_user'] ?? ''; $pass = $s['smtp_pass'] ?? '';
    $from = trim($s['smtp_from'] ?? '') ?: ($user ?: 'no-reply@wellsystem');
    if ($host === '' || $port === 0) return [false, 'SMTP sem host/porta.'];
    // Contexto TLS tolerante: não exige CA local (servidores antigos sem bundle)
    // — assim o STARTTLS/SSL negocia mesmo sem cacert.pem instalado.
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true, 'SNI_enabled' => true, 'peer_name' => $host]]);
    $alvo = ($seg === 'ssl') ? "ssl://$host:$port" : "tcp://$host:$port";
    $fp = @stream_socket_client($alvo, $eno, $estr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return [false, "Não conectou no SMTP $host:$port ($estr)."];
    stream_set_timeout($fp, 15);
    $ler = function () use ($fp) { $d = ''; while (($ln = fgets($fp, 515)) !== false) { $d .= $ln; if (isset($ln[3]) && $ln[3] === ' ') break; } return $d; };
    $cmd = function ($c) use ($fp, $ler) { if ($c !== null) fputs($fp, $c . "\r\n"); return $ler(); };
    $ler();
    $cmd("EHLO wellsystem");
    if ($seg === 'tls') {
        $r = $cmd("STARTTLS");
        if ($r === '' || $r[0] !== '2') { fclose($fp); return [false, 'Servidor recusou STARTTLS: ' . trim($r)]; }
        // Aceita TLS 1.0/1.1/1.2 (o método "TLS_CLIENT" sozinho é TLS 1.0 em PHP antigo → falhava).
        $cr = STREAM_CRYPTO_METHOD_TLS_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) $cr |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
        if (!@stream_socket_enable_crypto($fp, true, $cr)) { fclose($fp); return [false, 'Falha no STARTTLS (handshake TLS). Tente a opção SSL na porta 465.']; }
        $cmd("EHLO wellsystem");
    }
    if ($user !== '') {
        $cmd("AUTH LOGIN"); $cmd(base64_encode($user)); $r = $cmd(base64_encode($pass));
        if (strpos($r, '235') === false) { fclose($fp); return [false, 'Login SMTP recusado (usuário/senha).']; }
    }
    $cmd("MAIL FROM:<$from>");
    $r = $cmd("RCPT TO:<$to>");
    if ($r === '' || ($r[0] !== '2' && $r[0] !== '3')) { fclose($fp); return [false, 'Destinatário recusado pelo SMTP.']; }
    $cmd("DATA");
    $msg = "Date: " . date('r') . "\r\nFrom: $from\r\nTo: $to\r\nSubject: $subject\r\n" . $mimeHeaders . "\r\n" . $body . "\r\n.";
    $r = $cmd($msg); $cmd("QUIT"); fclose($fp);
    return (strpos($r, '250') !== false) ? [true, 'Enviado via SMTP.'] : [false, 'SMTP não aceitou a mensagem.'];
}
// Dados do BACKUP DO ERP (mesmos e-mail e SMTP — o dono configura uma vez só): usados quando a OLT não tem os próprios. Vazio = nada a herdar.
function olt_backup_dados_erp() {
    $r = ['ativo' => 0, 'email' => '', 'smtp' => []];
    $b = @json_decode((string)@file_get_contents(__DIR__ . '/cache/backup.json'), true); if (is_array($b)) { $r['ativo'] = !empty($b['ativo']) ? 1 : 0; $r['email'] = trim((string)($b['email'] ?? '')); }
    $m = @json_decode((string)@file_get_contents(__DIR__ . '/cache/smtp.json'), true); if (is_array($m) && trim((string)($m['smtp_host'] ?? '')) !== '') $r['smtp'] = $m;
    return $r;
}
// Envia o bundle de backup por e-mail (anexo .json). Usa SMTP se configurado (o da OLT ou, se vazio, o do ERP); senão mail().
function olt_backup_enviar_email($to) {
    $s = olt_jcache_load('olt_backup_ag.json'); if (!is_array($s)) $s = [];   // dual-cache
    $erp = olt_backup_dados_erp();
    if (trim((string)($s['smtp_host'] ?? '')) === '' && $erp['smtp']) $s = array_merge($s, $erp['smtp']);   // 24/10/2026: SMTP do ERP
    if (trim((string)($s['email'] ?? '')) === '' && $erp['email'] !== '') $s['email'] = $erp['email'];
    $to = trim((string)$to) !== '' ? trim((string)$to) : ($s['email'] ?? '');
    if (trim((string)$to) === '') return [false, 'E-mail de destino vazio.'];
    $dir = olt_cache_dir_g();   // backup = a pasta comum (config de todas as OLTs + a da principal)
    // BACKUP DE TUDO: pega TODOS os olt_*.json de config/dados. Só exclui os CACHES volateis, que se
    // regeneram sozinhos (sinal/tráfego/temperatura/tx/uplink/ifmap) — não fazem falta no restore.
    $excl = ['olt_sinal_cache.json','olt_sinal_hist.json','olt_snmp_traf.json','olt_snmp_last.json',
             'olt_pon_tx.json','olt_uplink.json','olt_temp_hist.json','olt_temp_estado.json',
             'olt_snmp_ifmap.json','olt_snmp_pon_zero.json','olt_hist.json'];
    $bundle = ['_wellsystem_backup' => 1, 'versao' => 2, 'data' => date('c'), 'arquivos' => []];
    // Une as DUAS pastas (dual-cache), pegando a versão MAIS NOVA de cada arquivo -> backup de TUDO.
    $best = array();
    foreach (olt_cache_dirs() as $cd) {
        foreach (glob($cd . '/olt_*.json') ?: array() as $p) {
            $a = basename($p); if (in_array($a, $excl, true)) continue;
            $t = (int)@filemtime($p);
            if (!isset($best[$a]) || $t >= $best[$a]['t']) { $j = json_decode(@file_get_contents($p), true); if ($j !== null) $best[$a] = ['t' => $t, 'j' => $j]; }
        }
    }
    foreach ($best as $a => $bb) { $bundle['arquivos'][$a] = $bb['j']; }
    $conteudo = json_encode($bundle, JSON_UNESCAPED_UNICODE);
    $nome = 'wellsystem-backup-' . date('Ymd') . '.json';
    // 26/10/2026: o mesmo backup também vai ao FTP, na pasta da OLT (Backup → Destinos → "FTP Pasta da OLT"); vazio = não envia. Falha aqui nunca atrapalha o e-mail.
    try {
        $dF = @json_decode((string)@file_get_contents(__DIR__ . '/cache/backup_dest.json'), true);
        if (is_array($dF) && trim((string)($dF['ftp_path_olt'] ?? '')) !== '' && trim((string)($dF['ftp_host'] ?? '')) !== '' && (!array_key_exists('on_ftp', $dF) || !empty($dF['on_ftp']))) {
            if (!function_exists('ws_backup_ftp_put')) require_once __DIR__ . '/backup_lib.php';
            $tmpF = sys_get_temp_dir() . '/' . $nome; @file_put_contents($tmpF, $conteudo);
            $rF = ws_backup_ftp_put($dF, $tmpF, $nome, (string)$dF['ftp_path_olt']); @unlink($tmpF);
            olt_log_registrar('backup_auto', 'Backup da OLT no FTP: ' . $rF);
        }
    } catch (Throwable $e) {}
    $bnd = 'ws' . md5(uniqid());
    $mime = "MIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"$bnd\"\r\n";
    $body = "--$bnd\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\nBackup automático do Wellsystem OLT — " . date('d/m/Y H:i') . ".\r\n\r\n"
          . "--$bnd\r\nContent-Type: application/json; name=\"$nome\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"$nome\"\r\n\r\n"
          . chunk_split(base64_encode($conteudo)) . "\r\n--$bnd--";
    $subject = 'Backup Wellsystem OLT — ' . date('d/m/Y');
    if (trim($s['smtp_host'] ?? '') !== '') return olt_smtp_enviar($s, $to, $subject, $mime, $body);
    if (!function_exists('mail')) return [false, 'Sem SMTP configurado e a função mail() está desabilitada. Preencha os dados de SMTP.'];
    $from = trim($s['smtp_from'] ?? '') ?: 'no-reply@wellsystem';
    $ok = @mail($to, $subject, $body, "From: $from\r\n" . $mime);
    return [$ok ? true : false, $ok ? 'Enviado.' : 'mail() recusou (sem MTA). Preencha os dados de SMTP para enviar.'];
}
function olt_backup_auto_check() {
    // Registra o MOTIVO de pular no Logs — no máx. 1x/hora (pra não poluir), assim dá
    // pra ver exatamente por que o backup automático não sai.
    // O MOTIVO de pular vai só para um arquivo de diagnóstico (NÃO polui o relatório visível).
    // Antes aparecia no Log e confundia. Agora o relatório só recebe o ENVIO REAL e as FALHAS.
    $diag = function ($msg) {
        $df = olt_cache_dir_g() . '/olt_backup_ag_diag.txt';
        @file_put_contents($df, date('Y-m-d H:i:s') . ' ' . $msg); @chmod($df, 0666);
    };
    // Lê o agendamento pelo MESMO caminho que a TELA usa (olt_jcache_load = o MAIS NOVO entre TODAS as
    // pastas de cache). Antes lia de UMA pasta só (olt_cache_dir), então pegava um arquivo VELHO com o
    // horário antigo -> enviava fora de hora (ex.: 01:30 mesmo remarcado p/ 07:00). Agora respeita o último salvo.
    $c = olt_jcache_load('olt_backup_ag.json');
    if (!is_array($c) || empty($c)) {
        /* 24/10/2026: servidor restaurado/novo sem o agendamento da OLT: herda o do ERP (mesmo e-mail e SMTP, ativo se o backup do ERP está ativo) às 00:30 — nunca fica sem backup em silêncio. */
        $erp = olt_backup_dados_erp();
        if (empty($erp['ativo']) || $erp['email'] === '') { $diag('Backup automático: agendamento da OLT nunca foi salvo e o backup do ERP não está ativo/sem e-mail para herdar.'); return; }
        $c = ['ativo' => 1, 'email' => $erp['email'], 'hora' => '00:30', 'herdado_erp' => 1];
    }
    if (empty($c['email'])) { $erp0 = olt_backup_dados_erp(); if ($erp0['email'] !== '') $c['email'] = $erp0['email']; }
    if (empty($c['ativo'])) { $diag('Backup automático DESATIVADO — marque "Ativar envio diário" e Salve.'); return; }
    if (empty($c['email'])) { $diag('Backup automático: e-mail de destino vazio.'); return; }
    $hora = $c['hora'] ?? '03:00';
    if (!preg_match('/^\d{2}:\d{2}$/', (string)$hora)) $hora = '03:00';
    $hoje = date('Y-m-d'); $slot = $hoje . ' ' . $hora; $slotTs = (int)strtotime($slot);
    if (time() < $slotTs) { $diag('Backup automático: ainda não deu o horário (agora ' . date('H:i') . ', agendado ' . $hora . ').'); return; }
    // Marca do HORÁRIO cumprido, nas pastas de cache E numa marca fixa em /tmp (sempre gravável por CLI e HTTP —
    // antes, se o cron (root) não conseguia gravar na cache_trafego do www-data, a marca nunca ficava e o
    // backup saía de novo a cada minuto = DUPLICIDADE). Remarcar o horário volta a disparar; a marca antiga
    // (só a data) só vale se foi gravada DEPOIS do horário.
    $dirsCache = array(__DIR__ . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego', olt_cache_dir_g());
    $dirsCache = array_unique($dirsCache);
    $marcas = array(); foreach ($dirsCache as $dc) { $marcas[] = $dc . '/olt_backup_ag_last.txt'; }
    $marcaTmp = sys_get_temp_dir() . '/olt_backup_ag_last_' . md5(__DIR__) . '.txt'; $marcas[] = $marcaTmp;
    $feito = function () use ($marcas, $slot, $hoje, $slotTs) {
        foreach ($marcas as $mf) { if (!is_file($mf)) continue; $m = trim((string)@file_get_contents($mf));
            if ($m === $slot || ($m === $hoje && (int)@filemtime($mf) >= $slotTs)) return true; }
        return false;
    };
    if ($feito()) return;   // horário já cumprido -> silêncio, sem log
    // TRAVA GLOBAL (flock): só um processo por vez decide/envia; o 2º espera fora (LOCK_NB) e vê a marca já gravada.
    $lockF = sys_get_temp_dir() . '/olt_backup_ag_' . md5(__DIR__) . '.lock';
    $lk = @fopen($lockF, 'c'); if ($lk) @chmod($lockF, 0666);
    if (!$lk || !flock($lk, LOCK_EX | LOCK_NB)) { if ($lk) fclose($lk); return; }
    try {
        if ($feito()) return;   // outro processo concluiu enquanto este esperava
        // Throttle: se falhar, tenta de novo só a cada 30 min.
        $tmk = sys_get_temp_dir() . '/olt_backup_ag_try_' . md5(__DIR__) . '.txt';
        if (is_file($tmk) && (time() - (int)@file_get_contents($tmk)) < 1800) return;
        // Reivindica ANTES de enviar (o envio SMTP demora e o cron roda a cada minuto): marca já vale como cumprido.
        foreach ($marcas as $mf) { $d = dirname($mf); if (is_dir($d)) { @file_put_contents($mf, $slot); @chmod($mf, 0666); } }
        list($ok, $motivo) = olt_backup_enviar_email($c['email']);
        if ($ok) {
            @unlink($tmk);
            olt_log_registrar('backup_auto', 'Backup diário enviado por e-mail para ' . $c['email']);
        } else {
            foreach ($marcas as $mf) { @unlink($mf); }   // falhou: libera nova tentativa (após o throttle)
            @file_put_contents($tmk, (string)time()); @chmod($tmk, 0666);
            olt_log_registrar('backup_auto_falha', 'Falha no backup diário automático: ' . $motivo);
        }
        return $ok;
    } finally { flock($lk, LOCK_UN); fclose($lk); }
}
// ---- TEMPERATURA da OLT: lê a placa CERTA (num só lugar) ----------------------
// A leitura vinha errada porque "display temperature 0" pegava a placa errada.
// A temperatura do SISTEMA é a da placa de CONTROLE ATIVA (SCU). Aqui a gente
// detecta o slot da SCU ativa (1x, cacheado) e lê a temperatura dela.
// Offset de calibração fica em 0 — o valor agora sai correto da própria OLT.
if (!defined('OLT_TEMP_OFFSET')) define('OLT_TEMP_OFFSET', 0);
function olt_temp_num($raw) {
    // Formato Huawei: "The temperature of the board:  32C(  89F)" -> pega o Celsius.
    if (preg_match('/temperature of the board:\s*(-?\d+)\s*C/i', (string)$raw, $m)) return (int)$m[1] + OLT_TEMP_OFFSET;
    if (preg_match('/(-?\d+)\s*C\b/i', (string)$raw, $m)) return (int)$m[1] + OLT_TEMP_OFFSET;
    return null;
}
function olt_temp_txt($raw) { $n = olt_temp_num($raw); return ($n === null) ? '' : ($n . '°C'); }
// Parser de "display board 0" -> só as PLACAS GPON (as que têm portas PON de cliente).
// Reconhece pelo nome da placa (GPON Huawei contém "GP": H805GPFD, H807GPFD, H808GPBD,
// H806GPBH...). Ignora controle (SCU), uplink (GIU/GICF/SCUN) e vazias. Estima as portas:
// GPFD=16, GPBD=8, senão 16 (o mais comum). Retorna [{slot,tipo,estado,portas}].
// Parser de "display board 0" -> TODAS as placas (não só GPON), como o SmartOLT lista.
// Marca gpon=true nas de cliente (têm "GP"), infere nº de portas e a função (Main/Standby)
// quando a OLT informa (master/slave/active/standby na linha).
function parse_board_all($saida) {
    $out = is_array($saida) ? implode("\n", $saida) : (string)$saida;
    $placas = array();
    foreach (explode("\n", $out) as $ln) {
        $ln = trim(str_replace("\x00", '', $ln));
        if (!preg_match('/^\s*(\d+)\s+(H\w+)\s+(\S+)(.*)$/', $ln, $m)) continue;   // slot  tipo  estado  resto
        $slot = (int)$m[1]; $tipo = strtoupper($m[2]); $estado = $m[3]; $resto = strtolower($m[4]);
        $gpon = (strpos($tipo, 'GP') !== false) && !preg_match('/SCU|GIU|GICF|GICG|CTRL/', $tipo);
        // nº de portas por família (as comuns da MA56xx). '' quando não sabemos.
        $portas = '';
        if (strpos($tipo, 'GPFD') !== false || strpos($tipo, 'GPFA') !== false) $portas = 16;
        elseif (strpos($tipo, 'GPBD') !== false) $portas = 8;
        elseif (strpos($tipo, 'SCU') !== false) $portas = 4;      // controle (2x GE + 2x 10GE)
        elseif (strpos($tipo, 'X2CS') !== false || strpos($tipo, 'X2CA') !== false) $portas = 2; // uplink 10GE
        elseif (strpos($tipo, 'GIU') !== false) $portas = 2;
        // função (placa de controle): Main/Standby
        $func = '';
        if (preg_match('/master|active_normal.*master|\bmain\b/', $resto) || preg_match('/master/i', $ln)) $func = 'Main';
        elseif (preg_match('/slave|standby/i', $ln)) $func = 'Standby';
        $placas[] = array('slot' => $slot, 'tipo' => $tipo, 'estado' => $estado, 'portas' => $portas, 'gpon' => $gpon, 'funcao' => $func);
    }
    return $placas;
}
// Compat: só as GPON (usado pra varredura de ONUs). Deriva de parse_board_all.
function parse_board_gpon($saida) {
    $todas = parse_board_all($saida); $g = array();
    foreach ($todas as $p) { if (!empty($p['gpon'])) $g[] = $p; }
    return $g;
}
// Slot da placa de CONTROLE ATIVA (SCU). Detectado 1x via "display board 0" e
// cacheado; nas leituras seguintes não custa nada. Padrão MA5683T: slot 6.
function olt_scu_slot() {
    $f = olt_cache_dir() . '/olt_scu_slot.txt';
    if (is_file($f)) { $v = trim((string)@file_get_contents($f)); if ($v !== '') return (int)$v; }
    global $olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout;
    $b = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
    $out = is_array($b) ? implode("\n", $b) : (string)$b;
    foreach (explode("\n", $out) as $ln) {
        // ex.: "  6       H802SCUN   Active_normal"
        if (preg_match('/^\s*(\d+)\s+H\d*SCU\w*\s+Active/i', $ln, $m)) {
            @file_put_contents($f, (string)(int)$m[1]); @chmod($f, 0666);
            return (int)$m[1];
        }
    }
    return null;
}
// Versão/modelo do firmware da OLT — detectado 1x via "display version" e cacheado.
function olt_versao() {
    $norm = function ($s) { return preg_match('/(R\d{3})/i', (string)$s, $m) ? strtoupper($m[1]) : ''; };  // só "R018"
    $f = olt_cache_dir() . '/olt_versao.txt';
    if (is_file($f)) { $v = trim((string)@file_get_contents($f)); if ($v !== '') return $norm($v) ?: $v; if (time() - @filemtime($f) < 3600) return ''; }
    global $olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout;
    $o = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display version', 'display board 0', 'quit'], $olt_timeout);
    $raw = is_array($o) ? implode("\n", $o) : (string)$o;
    $ver = $norm($raw);   // "R018"
    @file_put_contents($f, $ver); @chmod($f, 0666);
    return $ver;
}
// Coleta a potência Tx do SFP/GBIC de CADA porta PON (display sfp-info). Parse ancorado no
// rótulo "TX power", faixa plausível do laser GPON (0..10 dBm). Grava olt_pon_sfp.json.
function olt_pon_sfp_coletar() {
    global $olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout;
    $b = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
    $placas = parse_board_all($b);
    $cmds = ['enable', 'config']; $map = [];
    foreach ($placas as $p) {
        if (empty($p['gpon'])) continue; $slot = (int)$p['slot']; $np = (int)($p['portas'] ?: 16);
        for ($pt = 0; $pt < $np; $pt++) { $cmds[] = "display sfp-info 0/$slot/$pt"; $map[count($cmds) - 1] = "0/$slot/$pt"; }
    }
    $cmds[] = 'quit'; $cmds[] = 'quit';
    $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
    $tx = array();
    foreach ($map as $idx => $fsp) {
        $raw = $out[$idx] ?? '';
        if (preg_match('/T[Xx]\s*power[^-\d]{0,12}(-?\d+\.?\d*)/i', $raw, $m) || preg_match('/T[Xx][^-\d]{0,16}(-?\d+\.?\d*)\s*dbm/i', $raw, $m)) {
            $v = (float)$m[1]; if ($v >= -5 && $v <= 12) $tx[$fsp] = sprintf('%.2f', $v);
        }
    }
    if (!empty($tx)) { $f = olt_cache_dir() . '/olt_pon_sfp.json'; @file_put_contents($f, json_encode($tx, JSON_UNESCAPED_UNICODE)); @chmod($f, 0666); }
    return $tx;
}
// ---- Notificações (Telegram / WhatsApp) --------------------------------------
function olt_http_get($url, $timeout = 8) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => $timeout, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
        $r = curl_exec($ch); $err = curl_error($ch); curl_close($ch);
        return $err ? false : $r;
    }
    $ctx = stream_context_create(['http' => ['timeout' => $timeout], 'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    return @file_get_contents($url, false, $ctx);
}
function olt_http_post($url, $body, $headers = array(), $timeout = 10) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url); $h = array(); foreach ($headers as $k => $v) $h[] = $k . ': ' . $v;
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => $timeout, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $h, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
        $r = curl_exec($ch); $err = curl_error($ch); curl_close($ch);
        return $err ? false : $r;
    }
    $hs = ''; foreach ($headers as $k => $v) $hs .= $k . ': ' . $v . "\r\n";
    $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => $hs, 'content' => $body, 'timeout' => $timeout], 'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    return @file_get_contents($url, false, $ctx);
}
function olt_notif_config() {
    $d = olt_jcache_load('olt_notif.json');   // dual-cache: o CRON lê a MESMA config que a tela salvou
    return is_array($d) ? $d : [];
}
// Envia 1 mensagem para UM destino (canal + dados). $cfg traz as credenciais globais (Telegram/Evolution).
/** "81999998888, 5581988887777" → ['5581999998888','5581988887777'] (só dígitos, com 55; sem repetir). */
function olt_notif_fones(string $txt): array {
    $out = [];
    foreach (preg_split('/[,;\s]+/', $txt) ?: [] as $t) { $t = preg_replace('/\D/', '', $t); if (strlen($t) < 10) continue; if (strlen($t) <= 11) $t = '55' . $t; $out[$t] = 1; }
    return array_map("strval", array_keys($out));   // chave numérica vira int no PHP: volta a texto
}
function olt_notif_enviar_destino($d, $cfg, $msg) {
    $canal = $d['canal'] ?? ''; $res = [];
    $tgToken = trim($cfg['tg_token'] ?? '');
    if (($canal === 'whatsapp' || $canal === 'ambos') && !empty($d['phone']) && !empty($d['apikey'])) {
        $r = olt_http_get('https://api.callmebot.com/whatsapp.php?phone=' . rawurlencode(trim($d['phone'])) . '&apikey=' . rawurlencode(trim($d['apikey'])) . '&text=' . rawurlencode($msg));
        $res['whatsapp'] = ['ok' => ($r !== false && stripos((string)$r, 'error') === false), 'resp' => (is_string($r) ? substr($r, 0, 200) : $r)];
    }
    if (($canal === 'telegram' || $canal === 'ambos') && $tgToken && !empty($d['chat'])) {
        $r = olt_http_get('https://api.telegram.org/bot' . $tgToken . '/sendMessage?chat_id=' . rawurlencode(trim($d['chat'])) . '&text=' . rawurlencode($msg));
        $res['telegram'] = ['ok' => ($r !== false && strpos((string)$r, '"ok":true') !== false), 'resp' => (is_string($r) ? substr($r, 0, 200) : $r)];
    }
    /* DOIS WHATSAPP, SEM CONFUSÃO (24/09/2026):
     *   'sistema'   = WhatsApp API — pelo Servidor de WhatsApp do ERP (Opções → Servidor), com as regras de
     *                 lá: janela de 24h (aberta = texto puro pela instância em que falaram; sem janela =
     *                 template), as duas instâncias, rodízio e troca automática.
     *   'evolution' = WhatsApp comum — pela Evolution PRÓPRIA desta janela (URL/instâncias/chave), sempre
     *                 texto. Várias instâncias separadas por vírgula: a 1ª que responder envia.
     * Em qualquer um, o campo do número aceita VÁRIOS telefones (vírgula / ponto e vírgula / espaço). */
    $fones = olt_notif_fones((string)($d['phone'] ?? ''));
    if ($canal === 'sistema' && $fones) {
        if (!function_exists('ws_wa_enviar') && is_file(__DIR__ . '/whatsapp.php')) { ob_start(); try { require_once __DIR__ . '/whatsapp.php'; } catch (Throwable $e) {} ob_end_clean(); }
        if (!function_exists('ws_wa_enviar')) {
            $res['sistema'] = ['ok' => false, 'resp' => 'WhatsApp do ERP indisponível aqui (whatsapp.php não encontrado na pasta).'];
            return $res;
        }
        $oks = 0; $resp = [];
        foreach ($fones as $tel) {
            try { $r = ws_wa_enviar_conversa($tel, $msg, ['evento' => 'olt', 'automatica' => true]); }   /* aviso de PON/ONU à equipe: pelo WhatsApp comum (Wellnet-01) (14/10) */
            catch (Throwable $e) { $r = ['ok' => false, 'raw' => $e->getMessage()]; }
            if (!empty($r['ok'])) $oks++;
            $resp[] = $tel . ': ' . (!empty($r['ok']) ? 'ok' : substr((string)($r['raw'] ?? 'falha'), 0, 120));
        }
        $res['sistema'] = ['ok' => $oks === count($fones), 'resp' => substr(implode(' | ', $resp), 0, 400)];
        return $res;
    }
    if ($canal === 'evolution' && $fones) {
        $insts = array_values(array_filter(array_map('trim', preg_split('/[,;\s]+/', (string)($cfg['evo_instance'] ?? '')) ?: [])));
        if (empty($cfg['evo_url']) || empty($cfg['evo_apikey']) || !$insts) {
            $res['evolution'] = ['ok' => false, 'resp' => 'WhatsApp comum: preencha a Evolution própria (URL, instância e chave) acima.'];
            return $res;
        }
        $oks = 0; $resp = [];
        foreach ($fones as $tel) {
            $okTel = false; $ult = '';
            foreach ($insts as $inst) {   // 1ª instância que responder envia; caiu → a próxima assume
                $url = rtrim(trim($cfg['evo_url']), '/') . '/message/sendText/' . rawurlencode($inst);
                $corpoT = ['number' => $tel, 'text' => $msg]; if (preg_match('#https?://#i', (string)$msg)) $corpoT['linkPreview'] = false;   // 25/10/2026: texto com link sem pré-visualização (a mensagem não abria no celular)
                $body = json_encode($corpoT, JSON_UNESCAPED_UNICODE);
                $r = olt_http_post($url, $body, ['Content-Type' => 'application/json', 'apikey' => trim($cfg['evo_apikey'])]);
                $okTel = ($r !== false && stripos((string)$r, 'error') === false && stripos((string)$r, 'not found') === false && stripos((string)$r, 'exception') === false);
                $ult = $inst . ' → ' . (is_string($r) ? substr($r, 0, 100) : 'sem resposta');
                if ($okTel) { $ult = 'ok pela ' . $inst; break; }
            }
            if ($okTel) $oks++;
            $resp[] = $tel . ': ' . $ult;
        }
        $res['evolution'] = ['ok' => $oks === count($fones), 'resp' => substr(implode(' | ', $resp), 0, 400)];
    }
    return $res;
}
/* E-MAIL DOS AVISOS (17/11/2026, pedido do dono: "coloca também no e-mail"): endereços em olt_notif.json → "emails" (vírgula/;/espaço), preenchidos na janela de
   notificações. Mesmo canal dos avisos da OLT e dos alertas de infraestrutura (acao=infra_alerta). Usa o mailer do ERP (cache/smtp.json). Devolve [] sem endereço válido. */
function olt_notif_emails(array $cfg, string $msg): array {
    $lista = array_values(array_filter(array_map('trim', preg_split('/[,;\s]+/', (string)($cfg['emails'] ?? '')) ?: []), function ($e) { return $e !== '' && filter_var($e, FILTER_VALIDATE_EMAIL); }));
    if (!$lista) return [];
    if (!function_exists('ws_email_texto') && is_file(__DIR__ . '/mailer.php')) { ob_start(); try { require_once __DIR__ . '/mailer.php'; } catch (Throwable $e) {} ob_end_clean(); }
    if (!function_exists('ws_email_texto')) return ['email' => ['ok' => false, 'resp' => 'e-mail do ERP indisponível aqui (mailer.php não encontrado na pasta).']];
    $l1 = preg_split('/\R/', trim($msg)); $ass = trim(preg_replace('/\s+/', ' ', (string)($l1[0] ?? 'Aviso')));
    $ass = function_exists('mb_substr') ? mb_substr($ass, 0, 90) : substr($ass, 0, 90);
    $oks = 0; $resp = [];
    foreach ($lista as $to) {
        try { $r = ws_email_texto($to, 'WellSystem — ' . $ass, $msg); } catch (Throwable $e) { $r = [false, $e->getMessage()]; }
        if (!empty($r[0])) $oks++; $resp[] = $to . ': ' . (!empty($r[0]) ? 'ok' : substr((string)($r[1] ?? 'falha'), 0, 100));
    }
    return ['email' => ['ok' => $oks === count($lista), 'resp' => substr(implode(' | ', $resp), 0, 400)]];
}
// Envia a mensagem para TODOS os destinatários configurados.
function olt_notificar($msg) {
    $cfg = olt_notif_config();
    if (empty($cfg['ativo'])) { $ret = ['enviado' => false, 'motivo' => 'notificações desativadas']; olt_notif_log($msg, $ret); return $ret; }
    $destinos = (isset($cfg['destinos']) && is_array($cfg['destinos'])) ? $cfg['destinos'] : [];
    if (!$destinos && trim((string)($cfg['emails'] ?? '')) === '') { $ret = ['enviado' => false, 'motivo' => 'nenhum destinatário cadastrado']; olt_notif_log($msg, $ret); return $ret; }
    $out = [];
    foreach ($destinos as $i => $d) { $r = olt_notif_enviar_destino($d, $cfg, $msg); if ($r) $out[$i] = $r; }
    $re = olt_notif_emails($cfg, (string)$msg); if ($re) $out['email'] = $re;
    $ret = ['enviado' => true, 'resultado' => $out];
    if (!$out) $ret['motivo'] = 'destinatários sem canal válido (telefone/apikey/chat/token)';
    olt_notif_log($msg, $ret);
    return $ret;
}
/* HISTÓRICO DE ENVIOS (Telegram/WhatsApp) — cada alerta de PON grava aqui se saiu ou por que não saiu
   (desativado, sem destinatário, erro da API). Mostrado na janela "Atenção PON" (acao=notif_log).
   Sem isso não havia como saber se o alerta foi disparado. Guarda os 40 últimos. NÃO REMOVER. */
function olt_notif_log($msg, $ret) {
    $ok = 0; $fal = 0; $canais = [];
    foreach ((array)($ret['resultado'] ?? []) as $rr) { foreach ((array)$rr as $canal => $x) { if (!empty($x['ok'])) $ok++; else $fal++; $canais[$canal] = !empty($x['ok']) || !empty($canais[$canal]); } }
    $l = olt_jcache_load('olt_notif_log.json'); if (!is_array($l)) $l = [];
    array_unshift($l, ['ts' => time(), 'data' => date('d/m H:i:s'), 'msg' => (function_exists('mb_substr') ? mb_substr((string)$msg, 0, 160) : substr((string)$msg, 0, 160)), 'enviado' => !empty($ret['enviado']),
                       'motivo' => (string)($ret['motivo'] ?? ''), 'ok' => $ok, 'falha' => $fal, 'canais' => $canais]);
    olt_jcache_save('olt_notif_log.json', array_slice($l, 0, 40));
}
// Host do RADIUS ativo (config da tela -> env do Docker). Usado p/ montar o link do cadastro no host CERTO
// (o IP/host do radius), SEM hardcode e portável (cada instalação tem o seu). '' se não achar.
function olt_radius_host() {
    foreach ([__DIR__ . '/cache_trafego/wellsystem_config.json', sys_get_temp_dir() . '/acellApp_cache_trafego/wellsystem_config.json'] as $wf) {
        if (!is_file($wf)) continue; $wc = json_decode(@file_get_contents($wf), true);
        if (!is_array($wc) || empty($wc['radius']) || !is_array($wc['radius'])) continue;
        $wi = (int)($wc['radius_ativo'] ?? 0); $wr = $wc['radius'][$wi] ?? ($wc['radius'][0] ?? null);
        if (is_array($wr) && !empty($wr['host'])) return preg_replace('/:\d+$/', '', trim((string)$wr['host']));
    }
    // Mesmo host que abre o banco `wellsystem` (ver olt_radius_db() abaixo).
    if (function_exists('ws_db_config')) {
        $proprio = ws_db_config();
        if (!empty($proprio['host'])) return preg_replace('/:\d+$/', '', (string)$proprio['host']);
    }
    if (getenv('WS_DB_HOST')) return preg_replace('/:\d+$/', '', (string)getenv('WS_DB_HOST'));
    return '';
}
// Conexão com o banco do RADIUS. Ordem (mesmo modelo do socket_telnet.php):
//   1) RADIUS cadastrado na tela de Configurações
//   2) credencial do PRÓPRIO banco `wellsystem` (config.php/ws_db_config()), testada contra `mkradius`
//      — resolve o caso comum de senha do MySQL trocada, sem exigir cadastro novo
//   3) env Docker (WS_DB_*)
//   4) padrão fixo do MK-Auth (127.0.0.1/root/vertrigo), como último recurso
function olt_radius_db() {
    foreach ([__DIR__ . '/cache_trafego/wellsystem_config.json', sys_get_temp_dir() . '/acellApp_cache_trafego/wellsystem_config.json'] as $wf) {
        if (!is_file($wf)) continue; $wc = json_decode(@file_get_contents($wf), true);
        if (!is_array($wc) || empty($wc['radius']) || !is_array($wc['radius'])) continue;
        $wi = (int)($wc['radius_ativo'] ?? 0); $wr = $wc['radius'][$wi] ?? ($wc['radius'][0] ?? null);
        if (is_array($wr) && !empty($wr['host'])) { $l = @mysqli_connect($wr['host'], (string)($wr['user'] ?? 'root'), (string)($wr['pass'] ?? ''), (string)($wr['dbname'] ?? 'mkradius'), (int)($wr['porta'] ?? 3306)); if ($l) return $l; }
    }
    if (function_exists('ws_db_config')) {
        $proprio = ws_db_config();
        if (!empty($proprio['host'])) {
            $l = @mysqli_connect((string)$proprio['host'], (string)($proprio['user'] ?? 'root'), (string)($proprio['pass'] ?? ''), 'mkradius');
            if ($l) return $l;
        }
    }
    if (getenv('WS_DB_HOST')) { $l = @mysqli_connect(getenv('WS_DB_HOST'), getenv('WS_DB_USER') ?: 'root', getenv('WS_DB_PASS') ?: '', getenv('WS_DB_NAME') ?: 'mkradius', (int)(getenv('WS_DB_PORT') ?: 3306)); if ($l) return $l; }
    return @mysqli_connect('127.0.0.1', 'root', 'vertrigo', 'mkradius');
}
// Resolve o LOGIN AUTORITATIVO (login_pppoe) de um serial de ONU pelo CONTRATO do WellSystem
// (ws_contrato.sn_onu / ont_id / login_ipoe) — o MESMO vínculo que ws_cliente_sn usa pro botão
// "Cadastro" abrir a ficha certa.
//
// POR QUE EXISTE: cliente_uuid e clientes_db resolviam IP/nome/uuid fazendo
// sis_cliente.login = <serial normalizado> DIRETO. Isso só funciona se o login do RADIUS for
// literalmente o serial da ONU. Quando não é (ONU trocada, login legado, etc.), o match podia
// cair em OUTRO cliente cujo login por acaso normaliza pro mesmo valor — mostrando o IP/cadastro
// de outra pessoa (foi o que aconteceu: OLT mostrou 100.72.1.67, de outra sessão, no lugar do
// 100.72.1.10 que é o IP real do cliente, o mesmo que aparece no Cadastro e no painel dos
// concentradores). Aqui a fonte é o CONTRATO (ws_contrato), que é quem de fato vincula
// serial<->login — preferindo contrato NÃO cancelado, mais recente (mesma regra do ws_cliente_sn).
function olt_login_ws_por_sn($sn) {
    if (!function_exists('ws_db')) return '';
    $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$sn));
    if ($sn === '') return '';
    try {
        $db = ws_db();
        // PPPoE OU IPoE: devolve o login_pppoe; se o contrato for IPoE (sem PPPoE), o login_ipoe — que é
        // o username da sessão IPoE no RADIUS/accel. SN aceito nos 2 formatos (hex 4750.. e GPON00..).
        $sn2 = function_exists('sn_para_hex') ? strtoupper((string)sn_para_hex($sn)) : $sn; $sn3 = $sn2;
        if (preg_match('/^([0-9A-F]{8})([0-9A-F]{8})$/', $sn2, $mh)) { $pf = @hex2bin($mh[1]); if ($pf !== false && preg_match('/^[A-Z0-9]{4}$/', $pf)) $sn3 = $pf . $mh[2]; }
        $col = function ($c) { return "UPPER(REPLACE(REPLACE(COALESCE($c,''),':',''),'-',''))"; };
        $stmt = $db->prepare("SELECT login_pppoe, login_ipoe, tipo_conexao
            FROM ws_contrato
            WHERE " . $col('sn_onu') . " IN (?, ?, ?)
               OR " . $col('ont_id') . " IN (?, ?, ?)
               OR " . $col('login_ipoe') . " IN (?, ?, ?)
            ORDER BY (COALESCE(status,'') = 'cancelado') ASC, id DESC
            LIMIT 1");
        $stmt->execute([$sn, $sn2, $sn3, $sn, $sn2, $sn3, $sn, $sn2, $sn3]);   // posicional: EMULATE_PREPARES=false não aceita nome repetido
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$r) return '';
        // REGRA DO PROVEDOR: IPoE -> login = senha = o próprio ID (login_ipoe); PPPoE -> login_pppoe (+ senha).
        $ip = trim((string)($r['login_ipoe'] ?? '')); $pp = trim((string)($r['login_pppoe'] ?? ''));
        if (strtolower((string)($r['tipo_conexao'] ?? '')) === 'ipoe' && $ip !== '') return $ip;
        return $pp !== '' ? $pp : $ip;
    } catch (Throwable $e) { return ''; }
}
// IP AO VIVO de cada login: [loginNormalizado => ip]. MESMA fonte que o Cadastro e o Painel dos
// Concentradores usam — 1º a sessão lida nos concentradores (ws_conexao_viva, cache 90s),
// 2º a sessão aberta no radacct (acctstoptime IS NULL).
// POR QUE EXISTE: a OLT mostrava sis_cliente.ip (campo do cadastro do MK-Auth, que NÃO é o IP da
// sessão PPPoE — fica velho a cada reconexão) e uma memória no navegador que nunca expirava.
// O IP do PPPoE muda; o que vale é o da sessão atual. Adicional usa o PRÓPRIO username (a sessão
// dele), não o IP do titular.
// $ok (por referência) = true quando alguma fonte ao vivo respondeu — aí quem não está no mapa
// está OFFLINE e não deve exibir IP nenhum (um IP antigo pode já ser de outro cliente).
function olt_ips_vivos(&$ok = null) {
    static $cache = null, $okc = false;
    if ($cache !== null) { $ok = $okc; return $cache; }
    $ips = []; $ok = false;
    if (!function_exists('ws_conexao_viva') && is_file(__DIR__ . '/radius_lib.php')) {
        try { require_once __DIR__ . '/radius_lib.php'; } catch (Throwable $e) {}
    }
    if (function_exists('ws_conexao_viva')) {
        try {
            $viva = ws_conexao_viva(90);
            if ($viva) $ok = true;
            foreach ($viva as $k => $v) { $ip = trim((string)($v['ip'] ?? '')); if ($ip !== '' && $ip !== '0.0.0.0') $ips[strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$k))] = $ip; }
        } catch (Throwable $e) {}
    }
    if (function_exists('ws_db')) {
        try {
            $rs = ws_db()->query("SELECT username, framedipaddress FROM radacct
                WHERE acctstoptime IS NULL AND framedipaddress <> '' ORDER BY acctstarttime DESC");   // sessão mais nova primeiro
            foreach ($rs as $r) {
                $ok = true;
                $k = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$r['username']));
                $ip = trim((string)$r['framedipaddress']);
                if ($k !== '' && $ip !== '0.0.0.0' && !isset($ips[$k])) $ips[$k] = $ip;   // concentrador manda; radacct completa
            }
        } catch (Throwable $e) {}
    }
    $okc = $ok;
    return $cache = $ips;
}
// Sanitiza a lista de destinatários vinda do front (JSON).
function olt_notif_destinos_limpar($json) {
    $dst = json_decode($json ?? '[]', true); $clean = [];
    if (is_array($dst)) foreach ($dst as $d) {
        if (!is_array($d)) continue; $c = $d['canal'] ?? '';
        if (!in_array($c, ['whatsapp', 'telegram', 'ambos', 'evolution', 'sistema'], true)) continue;
        $clean[] = ['canal' => $c, 'nome' => substr(trim($d['nome'] ?? ''), 0, 40),
            'phone' => substr(trim($d['phone'] ?? ''), 0, 300), 'apikey' => substr(trim($d['apikey'] ?? ''), 0, 60),
            'chat' => substr(trim($d['chat'] ?? ''), 0, 60)];
    }
    return $clean;
}
// Resolve uma pasta de cache REALMENTE GRAVAVEL. Tenta cache_trafego do addon; se o PHP nao
// conseguir escrever nela (rodando com outro usuario, etc.), cai numa alternativa gravavel
// (temp do sistema). Assim a gravacao funciona "direto", sem precisar mexer no servidor.
// (Usa $base p/ nao colidir com o replace olt_cache_dir() -> olt_cache_dir()).
/* VÁRIAS OLTs NA GERÊNCIA (20/11/2026). A OLT PRINCIPAL é a de sempre (id vazio: pasta cache_trafego/ como sempre foi). Cada OLT
   cadastrada no "+" tem um id curto e a SUA pasta cache_trafego/olt_<id>/ com conexão, ONUs, sinal, histórico, alarmes e trava de
   varredura próprios. Os arquivos que valem para todas (usuários e sessões da OLT, notificações, backup agendado, nomes de VLAN,
   modelos, logos, opções, cadastro ONU→cliente) continuam na pasta comum — ver olt_nome_comum(). Qual OLT vale na requisição:
   1) env WS_OLT_ID (o cron roda um processo por OLT)  2) ?olt=  3) cookie WSOLT (gravado pela tela ao trocar de aba). Id que não
   está na lista = principal. Com nenhuma OLT cadastrada nada muda. */
function olt_ctx_limpar($v) { $v = strtolower(trim((string)$v)); return preg_match('/^[a-z0-9]{1,12}$/', $v) ? $v : ''; }
function olt_nome_comum($nome) {
    static $g = array('olt_lista.json', 'olt_usuarios.json', 'olt_sessoes.json', 'olt_sessoes_mes.txt', 'olt_cron_key.txt', 'olt_autoconnect.json',
        'olt_notif.json', 'olt_notif_log.json', 'olt_backup_ag.json', 'olt_backup_ag_last.txt', 'olt_backup_ag_diag.txt', 'olt_meta.json',
        'olt_cadastro.json', 'olt_cad_url.json', 'olt_perfis.json', 'olt_perfis_veloc.json', 'olt_vlan_nomes.json', 'olt_modelos.json',
        'olt_modelo_img.json', 'olt_opcoes.json', 'olt_limites_sinal.json', 'ws_bridge.json', 'olt_smartolt.json',
        'wellsystem_logo.txt', 'wellsystem_logo_olt.txt', 'wellsystem_config.json');
    return in_array($nome, $g, true);
}
/** OLTs cadastradas além da principal: id => ['nome' => ..., 'ip' => ...]. Arquivo comum (olt_lista.json). */
function olt_lista() {
    $j = olt_jcache_load('olt_lista.json'); $r = array();
    foreach ((array)($j['olts'] ?? array()) as $id => $o) {
        $id = olt_ctx_limpar($id);
        if ($id !== '' && is_array($o)) $r[$id] = array('nome' => (string)($o['nome'] ?? $id), 'ip' => (string)($o['ip'] ?? ''));
    }
    return $r;
}
function olt_lista_salvar($lista) {
    $o = array(); foreach ($lista as $id => $v) $o[$id] = array('nome' => (string)$v['nome'], 'ip' => (string)($v['ip'] ?? ''));
    $j = array('olts' => $o); $pn = olt_principal_nome(false); if ($pn !== '') $j['principal_nome'] = $pn;   // não perde o nome da principal
    olt_jcache_save('olt_lista.json', $j);
}
/** Nome da OLT principal no seletor (20/11/2026: antes era sempre "Principal"; o operador renomeia e passa a mostrar a cidade). */
function olt_principal_nome($padrao = true) {
    $j = olt_jcache_load('olt_lista.json'); $n = trim((string)($j['principal_nome'] ?? ''));
    return $n !== '' ? $n : ($padrao ? 'Principal' : '');
}
/** Id da OLT desta requisição ('' = principal). $forcar != null fixa o contexto (testes/CLI). */
function olt_ctx_id($forcar = null) {
    static $id = null;
    if ($forcar !== null) { $id = olt_ctx_limpar($forcar); return $id; }
    if ($id !== null) return $id;
    $c = getenv('WS_OLT_ID');
    if ($c === false || $c === '') $c = isset($_GET['olt']) ? $_GET['olt'] : (isset($_POST['olt']) ? $_POST['olt'] : (isset($_COOKIE['WSOLT']) ? $_COOKIE['WSOLT'] : ''));
    $c = olt_ctx_limpar($c);
    $id = ($c !== '' && isset(olt_lista()[$c])) ? $c : '';
    return $id;
}
// Pasta COMUM (a de sempre) — onde ficam os arquivos que valem para todas as OLTs e os da OLT principal.
function olt_cache_dir_g() {
    static $dir = null;
    if ($dir !== null) return $dir;
    $base = __DIR__;
    $tmp = sys_get_temp_dir() . '/acellApp_cache_trafego';
    $addon = $base . '/cache_trafego';
    // O FPM (navegador) MUITAS VEZES não grava na pasta do addon (open_basedir/SELinux), mesmo 777 — então
    // cai no /tmp (gravável). O CRON (CLI) grava na permanente. O cache_sync (no cron) converge /tmp -> addon,
    // então NADA se perde no reboot. Aqui: usa a 1ª pasta que REALMENTE grava (teste com nome único).
    foreach (array($addon, $tmp) as $d) {
        if (!is_dir($d)) @mkdir($d, 0777, true); @chmod($d, 0777);
        $t = $d . '/.__w' . getmypid() . mt_rand();
        if (@file_put_contents($t, 'ok') !== false) { @unlink($t); $dir = $d; return $dir; }
    }
    $dir = $addon; // ultimo recurso
    return $dir;
}
// Pasta de cache da OLT desta requisição: a comum (principal) ou cache_trafego/olt_<id>/ (OLT cadastrada).
function olt_cache_dir() {
    static $dirs = array();
    $id = olt_ctx_id();
    if (isset($dirs[$id])) return $dirs[$id];
    $g = olt_cache_dir_g();
    if ($id === '') { $dirs[$id] = $g; return $g; }
    $d = $g . '/olt_' . $id;
    if (!is_dir($d)) { @mkdir($d, 0777, true); @chmod($d, 0777); }
    $dirs[$id] = $d;
    return $d;
}
// Pasta "Mkfiles" (fotos de modelos ONU/ONT, logomarcas, etc.). Preferência: DENTRO do addon
// (fica junto dos arquivos, fácil de achar/backup). Se o FPM não gravar lá (open_basedir/permissão),
// cai na pasta de cache gravável. Cria e deixa 0777. Testa gravação real (nome único) antes de escolher.
/**
 * TODAS as pastas onde um arquivo do Mkfiles pode estar. A 1ª é onde se GRAVA.
 *
 * POR QUE A PRIMEIRA MUDOU PARA uploads/mkfiles
 * A pasta era `<projeto>/Mkfiles` — DENTRO da pasta do código. E a publicação de uma versão nova
 * roda `rsync --delete` excluindo apenas cache/, uploads/ e cache_trafego/. Resultado: a cada
 * atualização do sistema, as fotos dos equipamentos eram APAGADAS. O sintoma é o que o operador
 * relatou: "salvei a imagem, saí e voltei, não está mais lá" — sem ninguém ter apagado nada.
 *
 * `uploads/` resolve as três coisas de uma vez: está na lista de exclusão da publicação (logo,
 * sobrevive à atualização), já pertence ao www-data com permissão de escrita, e já tem o .htaccess
 * que proíbe execução de PHP lá dentro — que é obrigatório numa pasta que recebe arquivo enviado
 * pela web. Guardar upload numa pasta do código sem essa proteção é convite para execução remota.
 *
 * AS OUTRAS PASTAS CONTINUAM NA LISTA porque é onde estão os arquivos de quem já usava o sistema:
 * a leitura procura em todas, e a gravação migra o que achar para a pasta nova. Quem já tinha
 * imagem não perde nada, e ela passa a ficar num lugar que sobrevive.
 */
function olt_mkfiles_dirs() {
    static $lista = null;
    if ($lista !== null) return $lista;

    /* RAIZ DO PROJETO, e não __DIR__.
     * Este arquivo existe em DUAS cópias: na raiz do WellSystem e em olt/. Com __DIR__, a cópia de
     * olt/ apontaria para olt/uploads/mkfiles — uma pasta que não existe e que a publicação NÃO
     * protege, ou seja, o mesmo defeito de volta, só num caminho diferente. A raiz é reconhecida
     * pelo config.php, que só existe nela. */
    $raiz = is_file(__DIR__ . '/config.php') ? __DIR__ : dirname(__DIR__);

    $c = array(
        $raiz . '/uploads/mkfiles',          // persistente: excluída da publicação
        __DIR__ . '/Mkfiles',                // antiga (apagada a cada atualização)
        $raiz . '/Mkfiles',                  // antiga, quando o módulo está em olt/
        olt_cache_dir_g() . '/Mkfiles',        // antiga alternativa (pode ser /tmp: some no reboot)
    );
    // Sem duplicar quando as cópias apontam para o mesmo lugar.
    $lista = array_values(array_unique($c));
    return $lista;
}

/**
 * A pasta onde se GRAVA. Cria, testa escrita de verdade e migra o que houver nas antigas.
 *
 * O teste de escrita é com arquivo de nome único, e não com is_writable(): num servidor com
 * AppArmor/SELinux o is_writable() responde "sim" e a gravação falha em seguida — já aconteceu
 * neste projeto, e o efeito era a imagem "salva" que nunca aparecia.
 */
function olt_mkfiles_dir() {
    static $dir = null;
    if ($dir !== null) return $dir;

    $cands = olt_mkfiles_dirs();
    foreach ($cands as $d) {
        if (!is_dir($d)) @mkdir($d, 0775, true);
        $t = $d . '/.__w' . getmypid() . mt_rand();
        if (@file_put_contents($t, 'ok') !== false) { @unlink($t); $dir = $d; break; }
    }
    if ($dir === null) { $dir = $cands[0]; return $dir; }

    /* MIGRAÇÃO das pastas antigas para a definitiva — uma vez, de forma barata.
     * Só age quando a pasta antiga existe E tem arquivo; não sobrescreve o que já está na nova
     * (arquivo de mesmo nome na pasta nova é o mais recente, por definição). */
    foreach ($cands as $velha) {
        if ($velha === $dir || !is_dir($velha)) continue;
        foreach ((array)@glob($velha . '/*') as $p) {
            if (!is_file($p)) continue;
            $b = basename($p);
            if ($b === '' || $b[0] === '.') continue;
            if (is_file($dir . '/' . $b)) continue;
            @copy($p, $dir . '/' . $b);
        }
    }
    return $dir;
}

/** Caminho de um arquivo do Mkfiles, procurando em TODAS as pastas. '' se não existir. */
function olt_mkfiles_achar($nome) {
    $nome = (string)$nome;
    if ($nome === '' || strpos($nome, '..') !== false || strpos($nome, '/') !== false) return '';
    foreach (olt_mkfiles_dirs() as $d) {
        $p = $d . '/' . $nome;
        if (is_file($p)) return $p;
    }
    return '';
}
/** Fotos de MODELO no cadastro de equipamentos do ERP (ws_equipamento.foto): MODELO EM MAIÚSCULAS => caminho relativo. Só as que existem no disco. */
function olt_modelos_foto_erp(): array {
    static $c = null; if ($c !== null) return $c; $c = [];
    try {
        if (function_exists('ws_db')) {
            foreach (ws_db()->query("SELECT UPPER(TRIM(modelo)) m, foto FROM ws_equipamento WHERE modelo<>'' AND foto IS NOT NULL AND foto<>'' ORDER BY id") as $r) {
                $f = (string)$r['foto'];
                if (strpos($f, 'uploads/equipamentos/') === 0 && strpos($f, '..') === false && is_file(__DIR__ . '/' . $f) && !isset($c[$r['m']])) $c[$r['m']] = $f;
            }
        }
    } catch (Throwable $e) {}
    return $c;
}
// Cache de SINAL (rx/tx/rx_olt/dist) e de ESTADO (offline/los/deactivated) por fsp|id.
// Serve pra pagina abrir INSTANTANEA com tudo preenchido (nao espera a OLT).
// As DUAS pastas de cache possíveis. O PHP-FPM (tela) muitas vezes só grava no /tmp; o CLI (cron)
// grava no cache_trafego do addon. Se cada um usar uma, os dados divergem (ex.: o Tx que o cron
// coleta não chega na tela). Solução: GRAVAR NAS DUAS e LER SEMPRE A MAIS NOVA -> convergência total.
function olt_cache_dirs_g() {
    $a = array(olt_cache_dir_g());
    $addon = __DIR__ . '/cache_trafego'; $tmp = sys_get_temp_dir() . '/acellApp_cache_trafego';
    foreach (array($addon, $tmp) as $d) { if (!in_array($d, $a, true)) $a[] = $d; }
    return $a;
}
function olt_cache_dirs() {
    $id = olt_ctx_id();
    if ($id === '') return olt_cache_dirs_g();
    $a = array();
    foreach (olt_cache_dirs_g() as $d) $a[] = $d . '/olt_' . $id;
    return $a;
}
// Dupla pasta para arquivo que vale para todas as OLTs (usuários, notificações, logos...) ou da OLT em uso.
function olt_cache_dirs_de($nome) { return olt_nome_comum($nome) ? olt_cache_dirs_g() : olt_cache_dirs(); }
function olt_jcache_load($nome) {
    $best = null; $bts = -1;
    foreach (olt_cache_dirs_de($nome) as $d) { $f = $d . '/' . $nome;
        if (is_file($f)) { $t = (int)@filemtime($f); if ($t >= $bts) { $j = json_decode(@file_get_contents($f), true); if (is_array($j)) { $best = $j; $bts = $t; } } }
    }
    return is_array($best) ? $best : array();
}
function olt_estado_cache_load() {
    $c = olt_jcache_load('olt_estado_cache.json');
    if ((int)($c['__v'] ?? 0) < 2) { foreach ($c as $k => $v) { if ($v === 'deactivated') unset($c[$k]); } $c['__v'] = 2; }   // 29/10/2026: "Desativada" antiga era palpite (sem causa de queda); descarta e reapura pelo Control flag
    return $c;
}
function olt_jcache_save($nome, $c) {
    $data = json_encode($c, JSON_UNESCAPED_UNICODE);
    foreach (olt_cache_dirs_de($nome) as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); if (@file_put_contents($d . '/' . $nome, $data) !== false) @chmod($d . '/' . $nome, 0666); }
}

// ---- CONEXÃO DA OLT via interface (Menu > Conexão da OLT) --------------------
// Se existir olt_conexao.json, ele PREVALECE sobre os padrões do topo do arquivo.
// Assim NENHUM IP/credencial precisa ser editado no código-fonte.
function olt_conexao_cfg() {
    // dual-cache: lê a versão MAIS NOVA das 2 pastas -> a conexão (IP/user/senha/SNMP) NÃO some no restart
    // (a tela/FPM às vezes só grava no /tmp, que o boot limpa; a persistente cache_trafego mantém).
    $c = olt_jcache_load('olt_conexao.json');
    return is_array($c) ? $c : [];
}
(function () {
    $c = olt_conexao_cfg();
    if (!empty($c['ip']))      $GLOBALS['olt_ip']      = trim($c['ip']);
    if (!empty($c['porta']))   $GLOBALS['olt_porta']   = (int)$c['porta'];
    if (!empty($c['user']))    $GLOBALS['olt_user']    = trim($c['user']);
    if (isset($c['pass']) && $c['pass'] !== '') $GLOBALS['olt_pass'] = (string)$c['pass'];
    if (!empty($c['timeout'])) $GLOBALS['olt_timeout'] = (int)$c['timeout'];
})();

// =============================================================================
// SNMP — coleta de tráfego por porta PON (para os gráficos por PON, estilo SmartOLT)
// Config vem da conexão da OLT (olt_conexao.json): snmp_comm, snmp_port. SEM hardcode.
// Usa a extensão snmp do PHP se existir; senão os binários net-snmp (snmpget/bulkwalk).
// =============================================================================
function olt_snmp_cfg() {
    $c = olt_conexao_cfg();
    $rw = trim((string)($c['snmp_comm_rw'] ?? ''));
    return ['host' => $GLOBALS['olt_ip'] ?? '', 'comm' => trim((string)($c['snmp_comm'] ?? 'public')), 'port' => (int)($c['snmp_port'] ?? 161),
            'comm_rw' => $rw]; // community de ESCRITA (p/ ativar/desativar porta via SNMP SET)
}
// SNMP SET (integer). Usa a extensão php-snmp se houver, senão o binário snmpset (net-snmp).
function olt_snmp_set_int($host, $port, $comm, $oid, $val) {
    if (function_exists('snmp2_set')) { $r = @snmp2_set("$host:$port", $comm, $oid, 'i', (string)(int)$val, 1000000, 1); if ($r !== false) return 'ok'; }
    $b = olt_snmp_bin('snmpset');
    if ($b) { $o = @shell_exec($b . ' -v2c -t 3 -r 1 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' i ' . (int)$val . ' 2>&1'); return (string)$o; }
    return '';
}
function olt_snmp_bin($n) { $p = @shell_exec('command -v ' . $n . ' 2>/dev/null'); return $p ? trim($p) : ''; }
function olt_snmp_get($host, $port, $comm, $oid) {
    if (function_exists('snmp2_get')) { if (function_exists('snmp_set_valueretrieval')) @snmp_set_valueretrieval(SNMP_VALUE_PLAIN); $r = @snmp2_get("$host:$port", $comm, $oid, 1000000, 1); if ($r !== false) return trim((string)$r, " \t\n\r\0\x0B\""); }
    $b = olt_snmp_bin('snmpget');
    if ($b) { $o = @shell_exec($b . ' -v2c -Oqv -t 1 -r 1 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' 2>/dev/null'); if ($o !== null && trim($o) !== '') return trim($o, " \t\n\r\0\x0B\""); }
    return null;
}
function olt_snmp_walk($host, $port, $comm, $oid) {
    $res = [];
    if (function_exists('snmp2_real_walk')) { if (function_exists('snmp_set_valueretrieval')) @snmp_set_valueretrieval(SNMP_VALUE_PLAIN); $w = @snmp2_real_walk("$host:$port", $comm, $oid, 1000000, 1); if (is_array($w)) { foreach ($w as $k => $v) { if (preg_match('/(\d+)$/', $k, $m)) $res[$m[1]] = trim((string)$v, " \t\n\r\0\x0B\""); } return $res; } }
    $b = olt_snmp_bin('snmpbulkwalk'); if (!$b) $b = olt_snmp_bin('snmpwalk');
    if ($b) { $o = @shell_exec($b . ' -v2c -Osq -t 1 -r 1 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' 2>/dev/null'); foreach (explode("\n", (string)$o) as $ln) { $ln = trim($ln); if (preg_match('/\.(\d+)\s+(.*)$/', $ln, $m)) $res[$m[1]] = trim($m[2], " \t\""); } }
    return $res;
}
// Mapa fsp("0/s/p") -> ifIndex via ifName/ifDescr. Cacheado (1x); refaz com force.
function olt_snmp_ifmap($force = false) {
    $f = olt_cache_dir() . '/olt_snmp_ifmap.json';
    if (!$force && is_file($f)) { $c = json_decode(@file_get_contents($f), true); if (is_array($c) && $c) return $c; }
    $s = olt_snmp_cfg(); if ($s['host'] === '') return [];
    $names = olt_snmp_walk($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.1');       // ifName
    if (!$names) $names = olt_snmp_walk($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.2.2.1.2'); // ifDescr
    $map = [];
    foreach ($names as $idx => $nm) { if (preg_match('/(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)/', $nm, $m)) $map[$m[1] . '/' . $m[2] . '/' . $m[3]] = (int)$idx; }
    if ($map) { @file_put_contents($f, json_encode($map)); @chmod($f, 0666); }
    return $map;
}
// Mapa "fsp|ontId" -> ifIndex das interfaces de ONU (gpon-onu_f/s/p:id). Cada ONU é uma interface própria
// na ifTable (igual o SmartOLT usa), com contadores de octetos -> dá pra ler o tráfego POR CLIENTE.
// TTL 1h (ONU nova aparece sozinha depois disso; force=1 refaz na hora).
function olt_snmp_onumap($force = false) {
    $f = olt_cache_dir() . '/olt_snmp_onumap.json';
    if (!$force && is_file($f) && (time() - (int)@filemtime($f)) < 3600) { $c = json_decode(@file_get_contents($f), true); if (is_array($c) && $c) return $c; }
    $s = olt_snmp_cfg(); if ($s['host'] === '') { $c = is_file($f) ? json_decode(@file_get_contents($f), true) : []; return is_array($c) ? $c : []; }
    $names = olt_snmp_walk($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.1');       // ifName
    if (!$names) $names = olt_snmp_walk($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.2.2.1.2'); // ifDescr
    if (!$names) { $c = is_file($f) ? json_decode(@file_get_contents($f), true) : []; return is_array($c) ? $c : []; }  // sem resposta: mantém o antigo
    $map = [];
    foreach ($names as $idx => $nm) { if (preg_match('/(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)\s*:\s*(\d+)/', (string)$nm, $m)) $map[$m[1] . '/' . $m[2] . '/' . $m[3] . '|' . $m[4]] = (int)$idx; }
    if ($map) { @file_put_contents($f, json_encode($map)); @chmod($f, 0666); }
    return $map;
}
// Walk preservando o ÍNDICE COMPLETO (tudo após o OID base) -> [subindex => valorInt].
// Necessário pro sinal: o índice é "ifIndicePON.ontId" (composto), que o walk normal corta.
function olt_snmp_walk_full($host, $port, $comm, $oid) {
    $res = [];
    $b = olt_snmp_bin('snmpbulkwalk'); if (!$b) $b = olt_snmp_bin('snmpwalk');
    if (!$b) return $res;
    // -t 5 -r 2: mais tolerante a lentidão momentânea da OLT -> evita que a varredura ABORTE no meio e
    // deixe a CAUDA (PONs de índice alto, ex.: 14/15) sem leitura (que virava falso "queda"). Roda no cron (CLI, 300s).
    $o = @shell_exec($b . ' -v2c -On -t 5 -r 2 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' 2>/dev/null');
    foreach (explode("\n", (string)$o) as $ln) {
        $ln = trim($ln); if ($ln === '') continue;
        if (preg_match('/^\.?' . preg_quote($oid, '/') . '\.([0-9.]+)\s*=\s*\w*:?\s*(-?\d+)/', $ln, $m)) $res[$m[1]] = (int)$m[2];
    }
    return $res;
}
// COLETOR DE SINAL via SNMP (roda no cron, 2º plano, NÃO trava a tela). Lê Rx/Tx ópticos de TODAS
// as ONUs de uma vez e grava em olt_sinal_cache.json (mesmo cache que a tela já lê). Auto-descobre
// o mapa ifIndicePON -> placa/porta pelo próprio SNMP (ifName), sem chutar fórmula de índice.
function olt_snmp_sinal_coletar() {
    $s = olt_snmp_cfg(); if ($s['host'] === '') return ['ok' => false, 'msg' => 'OLT sem IP'];
    $RX = '1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4';   // Rx da ONU, x0.01 dBm (coluna .4 — confirmado)
    $TX = '1.3.6.1.4.1.2011.6.128.1.1.2.51.1.3';   // Tx da ONU, x0.01 dBm (coluna .3 — confirmado; .5=Volt .6=Bias)
    $rx = olt_snmp_walk_full($s['host'], $s['port'], $s['comm'], $RX);
    if (!$rx) return ['ok' => false, 'msg' => 'Sem retorno do SNMP (confira comunidade/porta em Conexão da OLT).'];
    $tx = olt_snmp_walk_full($s['host'], $s['port'], $s['comm'], $TX);
    // ifIndexes de porta únicos -> descobre a placa/porta (fsp) via ifName/ifDescr (1 get por porta).
    $portIdx = []; foreach ($rx as $ix => $v) { $p = explode('.', $ix); if (count($p) >= 2) $portIdx[$p[0]] = 1; }
    $fspDe = [];
    foreach (array_keys($portIdx) as $pix) {
        $nm = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.1.' . $pix);      // ifName
        if ($nm === null || $nm === '') $nm = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.2.2.1.2.' . $pix); // ifDescr
        if ($nm !== null && preg_match('/(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)/', $nm, $m)) $fspDe[$pix] = $m[1] . '/' . $m[2] . '/' . $m[3];
    }
    // Faixas plausíveis (x0.01 dBm): Rx da ONU -40..+6 dBm · Tx da ONU -10..+10 dBm.
    // Fora disso é offline/coluna errada -> mantém o valor anterior (não polui com lixo tipo 74 dBm).
    $okRx = function ($v) { return $v !== null && $v > -4000 && $v < 600; };
    $okTx = function ($v) { return $v !== null && $v > -1000 && $v < 1000; };
    $sc = olt_jcache_load('olt_sinal_cache.json'); $n = 0;
    $ponline = array(); $onlineNow = array(); $ponSeen = array();   // ONLINE por PON/ONU + PONs que APARECERAM na varredura
    foreach ($rx as $ix => $vr) {
        $p = explode('.', $ix); if (count($p) < 2) continue; $pix = $p[0]; $ont = $p[count($p) - 1];
        if (!isset($fspDe[$pix])) continue; $k = $fspDe[$pix] . '|' . $ont;
        $ponSeen[$fspDe[$pix]] = 1;   // esta PON retornou linha (mesmo offline/sentinela) -> foi LIDA (não truncada)
        $prev = (isset($sc[$k]) && is_array($sc[$k])) ? $sc[$k] : [];
        $ehOn = $okRx($vr);
        $rxd = $ehOn ? (sprintf('%.2f', $vr / 100) . ' dBm') : ($prev['rx'] ?? '');
        $vt = $tx[$ix] ?? null; $txd = $okTx($vt) ? (sprintf('%.2f', $vt / 100) . ' dBm') : ($prev['tx'] ?? '');
        $sc[$k] = ['rx' => $rxd, 'tx' => $txd, 'rx_olt' => $prev['rx_olt'] ?? '', 'dist' => $prev['dist'] ?? '', 'ts' => time(), 'snmp' => 1];
        if ($ehOn) { $ponline[$fspDe[$pix]] = ($ponline[$fspDe[$pix]] ?? 0) + 1; $onlineNow[$k] = 1; }
        $n++;
    }
    olt_jcache_save('olt_sinal_cache.json', $sc);
    @olt_snmp_pon_down_check($ponline, $ponSeen);   // ALERTA RÁPIDO de queda total de PON (via SNMP, ~3 min)
    @olt_snmp_status_rapido($onlineNow);   // atualiza online/offline na LISTA (cards reagem em ~1 min)
    // HISTÓRICO leve de Rx por ONU (pro gráfico de Sinal): anexa a leitura atual (centidBm) num
    // "anel" das últimas 60 amostras por ONU. Só Rx válido; compacto (~100 KB p/ 694 ONUs).
    $hist = olt_jcache_load('olt_sinal_hist.json'); if (!isset($hist['v']) || !is_array($hist['v'])) $hist = ['ts' => [], 'v' => []];
    $hist['ts'][] = time(); if (count($hist['ts']) > 60) $hist['ts'] = array_slice($hist['ts'], -60);
    foreach ($rx as $ix => $vr) {
        $p = explode('.', $ix); if (count($p) < 2) continue; $pix = $p[0]; if (!isset($fspDe[$pix])) continue;
        if (!$okRx($vr)) continue; $k = $fspDe[$pix] . '|' . $p[count($p) - 1];
        if (!isset($hist['v'][$k]) || !is_array($hist['v'][$k])) $hist['v'][$k] = [];
        $hist['v'][$k][] = (int)$vr; if (count($hist['v'][$k]) > 60) $hist['v'][$k] = array_slice($hist['v'][$k], -60);
    }
    olt_jcache_save('olt_sinal_hist.json', $hist);
    return ['ok' => true, 'onus' => $n, 'portas' => count($fspDe), 'mapa' => $fspDe, 'amostra' => array_slice($sc, 0, 4, true)];
}

// STATUS RÁPIDO (online/offline) na LISTA via SNMP — pra os CARDS (online/offline/etc.) reagirem em
// ~1 min, não só no scan Telnet (a cada ~10 min). Rx válido = online; sem Rx e estava online = offline.
// NÃO mexe em 'deactivated'. TRAVA: se o SNMP veio fraco (coleta parcial), NÃO marca ninguém offline.
function olt_snmp_status_rapido($onlineNow) {
    if (!is_array($onlineNow)) return;
    // TRAVA + releitura na hora: este poll roda a cada ~1 min e mexe no cache inteiro; sem trava
    // podia se cruzar com o cron_scan ou uma autorização e apagar a mudança de um dos dois.
    $lock = olt_json_lock('olt_onus_cache');
    if ($lock === null) return; // não segue sem trava aqui: é melhor pular este ciclo que perder dado
    $cc = olt_cache_load();
    if (!isset($cc['slots']) || !is_array($cc['slots'])) { olt_json_unlock($lock); return; }
    $total = 0; foreach ($cc['slots'] as $arr) { if (is_array($arr)) $total += count($arr); }
    if ($total < 5) { olt_json_unlock($lock); return; }
    if (count($onlineNow) < max(20, (int)($total * 0.30))) { olt_json_unlock($lock); return; }   // coleta fraca -> não mexe (anti-falso-positivo)
    $mudou = false;
    foreach ($cc['slots'] as $sl => $arr) {
        if (!is_array($arr)) continue;
        foreach ($arr as $ix => $o) {
            $k = ($o['fsp'] ?? '') . '|' . ($o['id'] ?? '');
            $st = strtolower((string)($o['status'] ?? '')); $est = strtolower((string)($o['estado'] ?? ''));
            if (isset($onlineNow[$k])) {
                if (strpos($st, 'online') === false) { $cc['slots'][$sl][$ix]['status'] = 'online'; $cc['slots'][$sl][$ix]['estado'] = ''; $mudou = true; }
            } else {
                if (strpos($st, 'online') !== false && $est !== 'deactivated') { $cc['slots'][$sl][$ix]['status'] = 'offline'; $mudou = true; }
            }
        }
    }
    if ($mudou) olt_cache_save($cc, $lock);
    olt_json_unlock($lock);
}

// ===== ALARMES REAIS DA OLT ("display alarm active all list") ======================================
// A própria OLT detecta e lista: dying-gasp (energia), LOSi (LOS de ONU), feeder LOS (PON inteira),
// board comm fail (placa). É a fonte AUTORITATIVA -> detecção IMEDIATA e SEM falso positivo (não
// inferimos por contagem de Rx). Aqui só importam PORTA PON e PLACA (o individual de ONU já está nos
// cards). Parser tolerante ao lixo de terminal ([37D etc.). Cada bloco começa por "SN  data hora".
function olt_alarmes_parse($raw) {
    $raw = is_array($raw) ? implode("\n", $raw) : (string)$raw;
    $raw = str_replace("\x00", '', $raw);
    $raw = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $raw);   // remove escapes tipo [37D
    $al = array(); $cur = null;
    $flush = function () use (&$al, &$cur) {
        if ($cur === null) return; $t = $cur['txt'];
        $slot = preg_match('/SlotID:\s*(\d+)/i', $t, $m) ? (int)$m[1] : null;
        $port = preg_match('/PortID:\s*(\d+)/i', $t, $m) ? (int)$m[1] : null;
        $ont  = preg_match('/ONT ID:\s*(\d+)/i', $t, $m) ? (int)$m[1] : null;
        $afet = preg_match('/affected ONTs:\s*(\d+)/i', $t, $m) ? (int)$m[1] : null;
        $board = preg_match('/Board Name:\s*([A-Za-z0-9]+)/i', $t, $m) ? $m[1] : null;
        $tipo = 'outro';
        if (stripos($t, 'dying-gasp') !== false) $tipo = 'energia';
        elseif (stripos($t, 'feeder fiber') !== false) $tipo = 'los_pon';
        elseif (stripos($t, 'cannot receive expected optical signals from the ONT') !== false) $tipo = 'los_onu';
        elseif (stripos($t, 'communication') !== false && stripos($t, 'board') !== false) $tipo = 'placa';
        elseif (stripos($t, 'GEM channel') !== false) $tipo = 'lcdgi';
        elseif (stripos($t, 'configuration recovery') !== false) $tipo = 'config';
        $fsp = ($slot !== null && $port !== null) ? ('0/' . $slot . '/' . $port) : '';
        $al[$cur['sn']] = array('sn' => $cur['sn'], 'hora' => $cur['hora'], 'tipo' => $tipo,
            'slot' => $slot, 'fsp' => $fsp, 'ont' => $ont, 'afet' => $afet, 'board' => $board);
        $cur = null;
    };
    foreach (explode("\n", $raw) as $ln) {
        if (preg_match('/^\s*(\d{5,})\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})/', $ln, $m)) {
            $flush(); $cur = array('sn' => (int)$m[1], 'hora' => $m[2], 'txt' => $ln);
        } elseif ($cur !== null) { $cur['txt'] .= ' ' . $ln; }
    }
    $flush();
    return $al;   // map: sn => alarme
}
// Lê os alarmes ATIVOS por Telnet e grava o cache (a TELA lê o cache; o CRON coleta com Telnet).
function olt_alarmes_coletar() {
    global $olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout;
    $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, array('enable', 'display alarm active all list'), $olt_timeout);
    $al = olt_alarmes_parse($out);
    if ($al) olt_jcache_save('olt_alarmes.json', array('ts' => time(), 'al' => $al));
    return $al;
}
// DETECTOR (roda no CRON): PON caiu (LOS ou ENERGIA em massa) ou PLACA caiu -> alerta IMEDIATO (a OLT
// já confirmou -> nada de CONFIRMA/delay). Só notifica MUDANÇA (nova queda / volta). NÃO cuida de ONU
// individual (já está nos cards). LCDGi/config = ruído -> ficam só no cache, não notificam.
function olt_alarmes_check() {
    $al = olt_alarmes_coletar();
    if (!is_array($al)) return null;
    $c = olt_cache_load(); $exp = array();   // nº de ONUs por PON (cache do cron_scan)
    if (isset($c['slots']) && is_array($c['slots'])) foreach ($c['slots'] as $arr) { if (is_array($arr)) foreach ($arr as $o) { $f = $o['fsp'] ?? ''; if ($f !== '') $exp[$f] = ($exp[$f] ?? 0) + 1; } }
    $ener = array(); $los = array(); $agora = array(); $onts = array();
    foreach ($al as $a) {
        if ($a['tipo'] === 'energia' && $a['fsp'] !== '') { $ener[$a['fsp']] = ($ener[$a['fsp']] ?? 0) + 1; if ($a['ont'] !== null && $a['ont'] !== '') $onts[$a['fsp']][] = (string)$a['ont']; }
        elseif ($a['tipo'] === 'los_pon' && $a['fsp'] !== '') $los[$a['fsp']] = $a['afet'];
        elseif ($a['tipo'] === 'placa' && $a['slot'] !== null) $agora['placa:' . $a['slot']] = array('tipo' => 'placa', 'slot' => $a['slot'], 'board' => $a['board'], 'hora' => $a['hora']);
    }
    // feeder LOS só é QUEDA se a porta TEM ONUs (roster). Porta vazia/reserva dá LOS permanente ("no ONT
    // online") e NÃO é queda — era o falso 0/1/9. Sem roster ainda, não arrisca (não alerta).
    foreach ($los as $fsp => $afet) { if ((isset($exp[$fsp]) ? (int)$exp[$fsp] : 0) < 1) continue; $agora['pon:' . $fsp] = array('tipo' => 'los', 'fsp' => $fsp, 'afet' => (int)$afet); }
    // ENERGIA em massa: >=4 ONUs em dying-gasp na PON e, se souber o total, >=70% dela (queda de energia da área).
    foreach ($ener as $fsp => $n) { $tot = isset($exp[$fsp]) ? (int)$exp[$fsp] : 0;
        if ($n >= 4 && ($tot === 0 || $n >= $tot * 0.7)) $agora['pon:' . $fsp] = array('tipo' => 'energia', 'fsp' => $fsp, 'n' => $n, 'tot' => $tot, 'onts' => array_values(array_unique($onts[$fsp] ?? array()))); }
    // estado anterior -> diff (só notifica MUDANÇA). Alerta IMEDIATO (sem confirmação: a OLT já confirmou).
    $stF = olt_cache_dir() . '/olt_alarmes_estado.json';
    $prev = is_file($stF) ? json_decode(@file_get_contents($stF), true) : array(); if (!is_array($prev)) $prev = array();
    $meta = olt_jcache_load('olt_meta.json'); $pnome = (is_array($meta) && isset($meta['porta']) && is_array($meta['porta'])) ? $meta['porta'] : array();
    $nm = function ($fsp) use ($pnome) { return (isset($pnome[$fsp]) && $pnome[$fsp] !== '') ? (' (' . $pnome[$fsp] . ')') : ''; };
    /* AVISO DETALHADO (24/09/2026): antes só dizia "PON CAIU 0/3/13". Agora diz ONDE (placa, porta, zona,
       descrição da PON), QUANTOS (ONUs afetadas / total da PON) e QUEM (nome dos clientes, até 10). */
    $placaNome = (is_array($meta) && isset($meta['placa']) && is_array($meta['placa'])) ? $meta['placa'] : array();
    $pzona     = (is_array($meta) && isset($meta['portazona']) && is_array($meta['portazona'])) ? $meta['portazona'] : array();
    $onusPon = array();   // fsp => lista de ONUs do cache (nome, zona, id, estado)
    if (isset($c['slots']) && is_array($c['slots'])) foreach ($c['slots'] as $arr) { if (is_array($arr)) foreach ($arr as $o) { $f0 = $o['fsp'] ?? ''; if ($f0 !== '') $onusPon[$f0][] = $o; } }
    $onde = function ($fsp) use ($placaNome, $pnome, $pzona, $onusPon) {
        $p = explode('/', (string)$fsp); $sl = $p[1] ?? '?'; $pt = $p[2] ?? '?';
        $pl = trim((string)($placaNome[$sl] ?? ($placaNome['0/' . $sl] ?? '')));
        $zona = trim((string)($pzona[$fsp] ?? ''));
        if ($zona === '') {   // sem zona cadastrada na porta: a zona mais comum entre as ONUs dela
            $cont = array(); foreach ($onusPon[$fsp] ?? array() as $o) { $z = trim((string)($o['zona'] ?? '')); if ($z !== '') $cont[$z] = ($cont[$z] ?? 0) + 1; }
            if ($cont) { arsort($cont); reset($cont); $zona = (string)key($cont); }
        }
        /* FORMATO ENXUTO (24/09/2026, "está quebrando linha, não deveria"): local numa linha só; zona e descrição
           juntas numa segunda linha, e só se existirem ("Zona: não cadastrada" ocupava linha sem informar nada). */
        $t  = "📍 Placa " . $sl . ($pl !== '' ? " ($pl)" : '') . " · Porta " . $pt . " · " . $fsp . "\n";
        $extra = array_filter(array($zona !== '' ? "Zona " . $zona : '', trim((string)($pnome[$fsp] ?? ''))), function ($x) { return $x !== ''; });
        if ($extra) $t .= "🗺️ " . implode(' · ', $extra) . "\n";
        return $t;
    };
    $clientes = function ($fsp, $ids = null) use ($onusPon) {
        $nomes = array();
        // ids das ONUs podem vir como número: compara como texto (antes a lista da queda de ENERGIA saía vazia)
        if (is_array($ids)) $ids = array_map('strval', $ids);
        foreach ($onusPon[$fsp] ?? array() as $o) {
            if (is_array($ids) && $ids && !in_array((string)($o['id'] ?? ''), $ids, true)) continue;
            $n = trim((string)($o['nome'] ?? '')); if ($n !== '') $nomes[] = $n;
        }
        $nomes = array_values(array_unique($nomes)); if (!$nomes) return '';
        $mais = count($nomes) > 10 ? ' (+' . (count($nomes) - 10) . ')' : '';
        return "👥 Clientes: " . implode(', ', array_slice($nomes, 0, 10)) . $mais . "\n";
    };
    $hora = "🕐 " . date('d/m H:i');
    foreach ($agora as $k => $v) { if (isset($prev[$k])) continue;   // já estava caído -> não repete
        if ($v['tipo'] === 'los') {
            $tot = count($onusPon[$v['fsp']] ?? array());
            olt_notificar("🔴 *PON CAIU* · sem sinal (LOS)\n" . $onde($v['fsp'])
                . "⛔ " . (int)$v['afet'] . ($tot ? " de $tot" : '') . " ONUs fora · provável fibra/splitter\n"
                . $clientes($v['fsp']) . $hora);
        } elseif ($v['tipo'] === 'energia') {
            olt_notificar("🔴 *PON CAIU* · falta de energia\n" . $onde($v['fsp'])
                . "⚡ " . (int)$v['n'] . ($v['tot'] ? (" de " . (int)$v['tot']) : '') . " ONUs sem energia na área\n"
                . $clientes($v['fsp'], $v['onts'] ?? null) . $hora);
        } elseif ($v['tipo'] === 'placa') {
            $sl = (string)$v['slot']; $pl = trim((string)($placaNome[$sl] ?? ($placaNome['0/' . $sl] ?? '')));
            $nOnu = 0; $nPon = 0; foreach ($onusPon as $f1 => $lst) { if ((explode('/', $f1)[1] ?? '') === $sl) { $nPon++; $nOnu += count($lst); } }
            olt_notificar("🔴 *PLACA CAIU* · sem comunicação\n📍 Placa " . $sl . ($pl !== '' ? " ($pl)" : '') . ($v['board'] ? (" · " . $v['board']) : '') . "\n"
                . "⛔ " . ($nPon ? "$nPon PONs · $nOnu ONUs afetadas" : "Placa sem resposta da controladora") . "\n" . $hora);
        }
    }
    foreach ($prev as $k => $v) { if (isset($agora[$k])) continue; $tp = $v['tipo'] ?? '';
        if ($tp === 'los')         olt_notificar("🟢 *PON VOLTOU* · sinal restabelecido\n" . $onde($v['fsp'] ?? '') . $hora);
        elseif ($tp === 'energia') olt_notificar("🟢 *PON VOLTOU* · energia restabelecida\n" . $onde($v['fsp'] ?? '') . $hora);
        elseif ($tp === 'placa')   { $sl = (string)($v['slot'] ?? ''); $pl = trim((string)($placaNome[$sl] ?? ''));
                                     olt_notificar("🟢 *PLACA VOLTOU* · comunicação restabelecida\n📍 Placa " . $sl . ($pl !== '' ? " ($pl)" : '') . "\n" . $hora); }
    }
    @file_put_contents($stF, json_encode($agora, JSON_UNESCAPED_UNICODE)); @chmod($stF, 0666);
    return $agora;
}
// DETECÇÃO RÁPIDA de QUEDA TOTAL de PON pelo SNMP (roda a cada ciclo do cron, ~3 min — sem Telnet,
// não congestiona). Compara ONUs ONLINE (Rx válido) por PON vs. o total esperado (cache do Telnet).
// Trava anti-falso-positivo: se a coleta global veio fraca (SNMP falhou/parcial), NÃO alerta nada.
// Grava no MESMO olt_pon_estado.json do detector Telnet -> não duplica alerta (o Telnet vê já-em-queda).
// 1 PONTO por MINUTO com a contagem FRESCA do SNMP -> o gráfico Status da rede captura quedas curtas (igual
// SmartOLT). O Online é 1-min-fresco; en/los carregam do último ponto (continuidade); na = o resto. Cap 24h.
function olt_hist_ponto($on, $tot) {
    $on = (int)$on; $tot = (int)$tot; if ($tot <= 0) return;
    $f = olt_cache_dir() . '/olt_hist.json';
    $h = is_file($f) ? json_decode(@file_get_contents($f), true) : array(); if (!is_array($h)) $h = array();
    $n = count($h); $prev = $n ? $h[$n - 1] : array();
    $en = (int)($prev['en'] ?? 0); $los = (int)($prev['los'] ?? 0); $na = max(0, $tot - $on - $en - $los);
    $minuto = date('Y-m-d H:i');
    $pt = array('h' => $minuto, 't' => time(), 'on' => $on, 'en' => $en, 'los' => $los, 'na' => $na, 'tot' => $tot, 'dn' => (int)($prev['dn'] ?? 0));
    if ($n && ($h[$n - 1]['h'] ?? '') === $minuto) $h[$n - 1] = $pt; else $h[] = $pt;
    if (count($h) > 1440) $h = array_slice($h, -1440);
    @file_put_contents($f, json_encode($h, JSON_UNESCAPED_UNICODE)); @chmod($f, 0666);
}
function olt_snmp_pon_down_check($ponline, $ponSeen = null) {
    if (!is_array($ponline)) $ponline = array();
    if (!is_array($ponSeen)) $ponSeen = null;   // null = compat (chamada antiga sem o mapa de "lidas")
    // esperado por PON = nº de ONUs no cache (Telnet, atualizado pelo cron_scan a cada ~9 min)
    $c = olt_cache_load(); $expected = array();
    if (isset($c['slots']) && is_array($c['slots'])) {
        foreach ($c['slots'] as $arr) { if (!is_array($arr)) continue;
            foreach ($arr as $o) { $f = $o['fsp'] ?? ''; if ($f !== '') $expected[$f] = ($expected[$f] ?? 0) + 1; } }
    }
    if (!$expected) return;   // ainda sem roster (cron_scan não rodou) -> nada a comparar
    // TRAVA: só confia se a coleta global veio saudável (evita alerta em massa por falha do SNMP).
    $totEsper = array_sum($expected); $totOn = array_sum($ponline);
    if ($totOn < max(20, (int)($totEsper * 0.30))) return;   // coleta fraca -> ignora este ciclo
    olt_hist_ponto($totOn, $totEsper);   // grava 1 ponto/min p/ o gráfico Status da rede (captura quedas curtas)
    // Guarda o retrato FRESCO do SNMP por PON (só em ciclo saudável) -> o detector TELNET usa como
    // SEGUNDA OPINIÃO: se o SNMP viu ONUs online numa PON agora há pouco, uma varredura Telnet que a
    // marcou "toda offline" estava INCOMPLETA -> não alerta (era o falso positivo das PONs 7/8, etc.).
    olt_jcache_save('olt_snmp_ponline.json', array('ts' => time(), 'on' => $ponline));
    // TRAVA anti-CEGUEIRA: só pode alertar PON que o SNMP JÁ CONSEGUIU ler online alguma vez (persistente).
    // Se o SNMP NUNCA viu aquela PON online (mapeamento/DDM não pega), NÃO é queda -> nunca alerta (era
    // isso que gerava alarme falso constante: PON que o SNMP não enxerga aparecia "zerada" pra sempre).
    $seenF = olt_cache_dir() . '/olt_snmp_pon_seen.json';
    $seen = is_file($seenF) ? json_decode(@file_get_contents($seenF), true) : []; if (!is_array($seen)) $seen = [];
    $seenMud = false;
    foreach ($ponline as $f => $on) { if ($on > 0 && empty($seen[$f])) { $seen[$f] = 1; $seenMud = true; } }
    if ($seenMud) { @file_put_contents($seenF, json_encode($seen, JSON_UNESCAPED_UNICODE)); @chmod($seenF, 0666); }
    $meta = olt_jcache_load('olt_meta.json');
    $pnome = (is_array($meta) && isset($meta['porta']) && is_array($meta['porta'])) ? $meta['porta'] : [];
    $stF = olt_cache_dir() . '/olt_pon_estado.json';
    $prev = is_file($stF) ? json_decode(@file_get_contents($stF), true) : []; if (!is_array($prev)) $prev = [];
    // CONFIRMAÇÃO curta (DETECÇÃO RÁPIDA): 2 ciclos ~= 2 min. NÃO precisa de delay grande porque o
    // FALSO POSITIVO já é morto na RAIZ pela trava ponSeen (PON truncada/não-lida é ignorada) + slotAnomalo
    // (placa inteira zerando = glitch). Então dá pra alertar em ~2 min sem alarme falso. 1 ciclo isolado
    // (engasgo momentâneo) ainda não dispara; 2 seguidos = queda real -> avisa rápido.
    $CONFIRMA = 2; $CONFIRMA_CLUSTER = 3;
    $zf = olt_cache_dir() . '/olt_snmp_pon_zero.json';
    $zero = is_file($zf) ? json_decode(@file_get_contents($zf), true) : []; if (!is_array($zero)) $zero = [];
    $novaQueda = array(); $novaVolta = array(); $mudou = false; $zmud = false;
    // ANOMALIA DE PLACA: se VÁRIAS PONs da MESMA placa zeram no MESMO ciclo, NÃO são quedas de PON
    // individuais — é a leitura SNMP daquela placa inteira que engasgou (ou a placa caiu, que é OUTRO
    // evento). Queda real de PON é 1 (ou poucas) porta isolada. Então, se >=metade (ou >=4) das PONs
    // conhecidas de uma placa zeram juntas, essa placa é ignorada neste ciclo (não alerta, reseta contador).
    $zeroSlot = array(); $ponSlot = array();
    foreach ($expected as $f => $tot) {
        if ($tot < 3 || empty($seen[$f])) continue;
        if ($ponSeen !== null && empty($ponSeen[$f])) continue;   // PON não apareceu na varredura = truncada, não conta
        $pp = explode('/', $f); $sl = isset($pp[1]) ? $pp[1] : '?';
        $ponSlot[$sl] = (isset($ponSlot[$sl]) ? $ponSlot[$sl] : 0) + 1;
        if ((int)(isset($ponline[$f]) ? $ponline[$f] : 0) === 0) $zeroSlot[$sl] = (isset($zeroSlot[$sl]) ? $zeroSlot[$sl] : 0) + 1;
    }
    $slotAnomalo = array();
    foreach ($zeroSlot as $sl => $z) { $tp = isset($ponSlot[$sl]) ? $ponSlot[$sl] : 1; if ($z >= 4 || $z >= $tp * 0.5) $slotAnomalo[$sl] = 1; }
    foreach ($expected as $f => $tot) {
        if ($tot < 3) continue;                         // PON pequena não conta como "queda total"
        if (empty($seen[$f])) continue;                 // SNMP NUNCA viu essa PON online -> não alerta (cegueira, não queda)
        if ($ponSeen !== null && empty($ponSeen[$f])) { // PON NÃO retornou linha nesta varredura = TRUNCADA (não lida).
            if (isset($zero[$f])) { unset($zero[$f]); $zmud = true; }   // não é queda -> reseta contador e ignora
            continue;                                   // (queda REAL retorna linha com sentinela -> NÃO cai aqui, alerta normal)
        }
        $ppF = explode('/', $f); $slF = isset($ppF[1]) ? $ppF[1] : '?';
        if (isset($slotAnomalo[$slF])) {                // placa inteira "zerou" junto -> glitch de leitura/placa, NÃO é queda de PON
            if (isset($zero[$f])) { unset($zero[$f]); $zmud = true; }   // reseta contador (não deixa confirmar falso)
            continue;
        }
        // quantas confirmações esta PON precisa: se OUTRA(s) PON da MESMA placa também zerou neste ciclo
        // (cluster/cauda truncada), exige CONFIRMA_CLUSTER; se está sozinha, CONFIRMA (queda real de bairro).
        $need = (isset($zeroSlot[$slF]) && $zeroSlot[$slF] >= 2) ? $CONFIRMA_CLUSTER : $CONFIRMA;
        $on = (int)($ponline[$f] ?? 0);
        if ($on === 0) {
            $zero[$f] = ($zero[$f] ?? 0) + 1; $zmud = true;
            if ($zero[$f] >= $need && !isset($prev[$f])) {
                $prev[$f] = 'energia'; $novaQueda[$f] = $tot; $mudou = true;
                $nm = isset($pnome[$f]) ? trim($pnome[$f]) : '';
                olt_log_registrar('pon_queda', 'PON ' . $f . ($nm !== '' ? ' (' . $nm . ')' : '') . ' em QUEDA TOTAL — SNMP confirmado (' . $tot . ' ONUs)', $f);
            }
        } else {
            if (isset($zero[$f])) { unset($zero[$f]); $zmud = true; }
            if (isset($prev[$f])) {
                unset($prev[$f]); $novaVolta[$f] = 1; $mudou = true;
                $nm = isset($pnome[$f]) ? trim($pnome[$f]) : '';
                olt_log_registrar('pon_retorno', 'PON ' . $f . ($nm !== '' ? ' (' . $nm . ')' : '') . ' NORMALIZOU (SNMP)', $f);
            }
        }
    }
    // ===== ALERTA DE PLACA (o outro lado da trava acima) =====================================
    // A trava de anomalia NÃO cala a placa quando ela CAI DE VERDADE — apenas troca 15 alertas de PON
    // por 1 alerta de PLACA, e SÓ depois de confirmar que não foi engasgo. Se a placa inteira fica zerada
    // por CONFIRMA_PLACA ciclos SEGUIDOS -> avisa "PLACA caiu". Se voltar antes, era glitch (não avisa).
    $CONFIRMA_PLACA = 3;
    $pf = olt_cache_dir() . '/olt_snmp_placa.json';
    $pcnt = is_file($pf) ? json_decode(@file_get_contents($pf), true) : []; if (!is_array($pcnt)) $pcnt = [];
    $pmud = false;
    // placas com pelo menos 1 PON conhecida nesta rodada (universo válido p/ decidir "voltou")
    foreach ($ponSlot as $sl => $tp) {
        $kA = 'PLACA:' . $sl;
        if (isset($slotAnomalo[$sl])) {                       // placa está zerada agora
            $pcnt[$sl] = (isset($pcnt[$sl]) ? $pcnt[$sl] : 0) + 1; $pmud = true;
            if ($pcnt[$sl] >= $CONFIRMA_PLACA && !isset($prev[$kA])) {   // confirmado -> avisa 1x
                $prev[$kA] = 'placa'; $mudou = true;
                olt_log_registrar('pon_queda', 'PLACA ' . $sl . ' SEM COMUNICAÇÃO/QUEDA — ' . $tp . ' PONs zeradas (SNMP confirmado)', $sl);
                olt_notificar("⛔ PLACA " . $sl . " caiu / sem comunicação\n\nTodas as PONs da placa " . $sl . " estão zeradas (confirmado " . $CONFIRMA_PLACA . "x).");
            }
        } else {                                              // placa respondendo normal
            if (isset($pcnt[$sl])) { unset($pcnt[$sl]); $pmud = true; }
            if (isset($prev[$kA])) {                           // estava alertada -> normalizou
                unset($prev[$kA]); $mudou = true;
                olt_log_registrar('pon_retorno', 'PLACA ' . $sl . ' NORMALIZOU (SNMP)', $sl);
                olt_notificar("🟢 PLACA " . $sl . " voltou ONLINE\n\nA placa " . $sl . " voltou a responder normalmente.");
            }
        }
    }
    if ($pmud) { @file_put_contents($pf, json_encode($pcnt, JSON_UNESCAPED_UNICODE)); @chmod($pf, 0666); }
    if ($zmud) { @file_put_contents($zf, json_encode($zero, JSON_UNESCAPED_UNICODE)); @chmod($zf, 0666); }
    if ($mudou) { @file_put_contents($stF, json_encode($prev, JSON_UNESCAPED_UNICODE)); @chmod($stF, 0666); }
    if ($novaQueda) { $b = array(); foreach ($novaQueda as $f => $t) { $nm = isset($pnome[$f]) ? trim($pnome[$f]) : ''; $b[] = '🔴 ' . $f . ($nm !== '' ? ' ' . $nm : ''); }
        olt_notificar('⚠️ ' . count($novaQueda) . ' PON' . (count($novaQueda) > 1 ? 's' : '') . " em QUEDA TOTAL\n\n" . implode("\n", $b)); }
    if ($novaVolta) { $b = array(); foreach ($novaVolta as $f => $x) { $nm = isset($pnome[$f]) ? trim($pnome[$f]) : ''; $b[] = '🟢 ' . $f . ($nm !== '' ? ' ' . $nm : ''); }
        olt_notificar('✅ ' . count($novaVolta) . ' PON' . (count($novaVolta) > 1 ? 's' : '') . " VOLTOU ONLINE\n\n" . implode("\n", $b)); }
}

// COLETOR do Tx do GBIC de cada PORTA PON (lado OLT), via SNMP. Índice = ifIndex da porta PON.
// OID descoberto pelo snmp_hunt: coluna .23 traz um valor por PORTA (não por ONT), na faixa de
// potência de saída GPON (÷10 = dBm). Mapeia ifIndex -> "0/s/p" pelo ifName e grava olt_pon_tx.json.
// COLETOR do Tx do GBIC (lado OLT) de cada porta PON, por TELNET. Comando confirmado no firmware:
// entrar em "interface gpon 0/<slot>" e rodar "display port state all" — a saída (em PT) traz, por
// porta: "F/S/P 0/s/p ... Potência TX (dBm) 5,03". Como é Telnet (congestiona), grava em cache
// (olt_pon_tx.json) e é o CRON que atualiza em 2º plano; a tela só lê o cache.
function olt_snmp_pon_tx() {
    global $olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout;
    if (trim((string)$olt_ip) === '') return ['ok' => false, 'msg' => 'OLT sem IP'];
    // UMA sessão só (evita 2º login em Telnet congestionado) + "screen-length 0 temporary" p/ DESLIGAR
    // a paginação ("---- More ----") que travava o "display port state all". Usa SÓ os slots GPON REAIS
    // (lidos do cache de ONUs, SEM Telnet) — entrar em "interface gpon" de slot VAZIO trava a sessão.
    $slots = array();
    $c = olt_cache_load();
    if (isset($c['slots']) && is_array($c['slots'])) { foreach ($c['slots'] as $sl => $arr) { if (is_array($arr) && count($arr) > 0) $slots[] = (int)$sl; } }
    $slots = array_values(array_unique($slots)); sort($slots);
    if (!$slots) $slots = array(1, 3, 5);   // fallback (antes do 1º cron_scan encher o cache)
    $cmds = ['enable', 'config']; $map = array();   // sem "screen-length" (o debug funcionou sem ele)
    foreach ($slots as $sl) { $cmds[] = "interface gpon 0/$sl"; $cmds[] = 'display port state all'; $map[count($cmds) - 1] = $sl; $cmds[] = 'quit'; }
    $cmds[] = 'quit';
    $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
    $tx = array(); $ok_slots = array();
    foreach ($map as $idx => $sl) {
        $raw = (string)($out[$idx] ?? '');
        $raw = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $raw);      // tira lixo de terminal ([37D)
        // Cada porta começa em "F/S/P 0/s/p"; dentro do bloco vem "... TX (dBm) 5,03".
        $blocos = preg_split('/F\s*\/\s*S\s*\/\s*P/i', $raw);
        foreach ($blocos as $bl) {
            // "TX power(dBm)   5.05" (inglês) — aceita "power" no meio e vírgula OU ponto decimal.
            if (preg_match('/(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)/', $bl, $mf)
                && preg_match('/TX\s*power\s*\(dBm\)\s*(-?\d+(?:[.,]\d+)?)/i', $bl, $mt)) {
                $fsp = $mf[1] . '/' . $mf[2] . '/' . $mf[3];
                $val = (float)str_replace(',', '.', $mt[1]);
                if ($val > -20 && $val < 20) { $tx[$fsp] = number_format($val, 2, '.', '') . ' dBm'; $ok_slots[$sl] = 1; }
            }
        }
    }
    if ($tx) { olt_jcache_save('olt_pon_tx.json', $tx); }
    return ['ok' => true, 'tx' => $tx, 'slots' => array_keys($ok_slots), 'lidas' => count($tx)];
}

// Sobrepõe status/velocidade/admin AO VIVO (SNMP) nas portas de uplink vindas do cache (Telnet).
// Assim a página abre na hora com dado atual, sem depender do Telnet (que vive congestionado).
// VLAN/óptico/duplex ficam do cache (mudam raramente). Se o SNMP falhar, devolve o cache como está.
function olt_uplink_snmp_overlay($portas) {
    if (!is_array($portas) || !$portas) return $portas;
    $s = olt_snmp_cfg(); if ($s['host'] === '') return $portas;
    $map = olt_snmp_ifmap(); if (!$map) return $portas;
    foreach ($portas as &$p) {
        $ix = $map[$p['fsp']] ?? null; if ($ix === null) continue;
        $op = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.2.2.1.8.' . $ix);   // ifOperStatus
        $ad = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.2.2.1.7.' . $ix);   // ifAdminStatus
        $hs = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.15.' . $ix); // ifHighSpeed (Mbps)
        if ($op !== null && $op !== '') { $p['link'] = ((int)$op === 1) ? 'online' : 'offline'; }
        if ($hs !== null && (int)$hs > 0) { $sp = (int)$hs; $p['vel'] = ($sp >= 10000 ? '10G' : ($sp >= 1000 ? '1G' : $sp . 'M')); }
        if ($ad !== null && $ad !== '') { $p['admin'] = ((int)$ad === 1) ? 'Habilitado' : 'Desabilitado'; }
        $up = ($p['link'] === 'online'); $p['status'] = $up ? ('UP · ' . ($p['vel'] ?? '')) : 'Down';
    }
    unset($p);
    return $portas;
}

// =============================================================================
// BRIDGE x ROUTER DIRETO DA OLT (via nome do Service-profile)
// O "Service profile name" (que o `display ont info` reporta) define a capacidade:
//   Bridging          -> ONU (bridge)
//   Bridging/Routing  -> ONT (router)
// Mapa abaixo espelha os perfis GPON desta rede (fonte: perfis da OLT/SmartOLT).
// Perfis com prefixo "ONT-" caem na regra geral como ONT; os demais como ONU.
// Para incluir/ajustar um perfil, basta editar $OLT_SRV_CAP.
// =============================================================================
// =============================================================================
// PERFIS NA AUTORIZAÇÃO — COMO FUNCIONA (LEIA ANTES DE MEXER)
// -----------------------------------------------------------------------------
// Tabela de uso desta rede (IDs = srv-profile REAL da OLT, lidos por acao=perfis_olt):
//
//   MODO BRIDGE (ONU básica — cliente usa roteador separado; disca no roteador dele)
//     ONU MG10 / Fiberlink ....... MAX-M10 (14)  ou em branco = MAX1000 (11) automático
//     ONU Maxprint 1 porta ....... MAX1000 (11)
//     ONU Huawei básica 1 porta .. HG8010H (1)
//     Intelbras R1/R2 ............ INTEL-R1 (18)  (+ "Perfil genérico": line+srv próprios)
//   MODO ROUTER (ONT com Wi-Fi — disca nela mesma)
//     ONT Maxprint Wi-Fi ......... ONT-MAX (15)
//     ONT Huawei V2/V5/V6... ..... ONT-HUAWEI-v2 (68)  (serve p/ quase todas as Huawei Wi-Fi)
//     ONT Multilaser ............. ONT-MULTILESE (80)
//
// REGRA DO TIPO: nome começa com "ONT-" = ROUTER; qualquer outro = BRIDGE (olt_srv_tipo()).
// Tela (olt_ui.js, _oltSrvOptsApHtml) e backend usam a MESMA regra — mudar um exige mudar o outro.
//
// FLUXO DO "autorizar" (acao=autorizar):
//   1) Perfil ESCOLHIDO na tela  -> vem srvprofile=ID e modo='' (vazio de propósito, senão o
//      backend trocaria o perfil pelo padrão). Perfil em BRANCO -> vem modo=bridge|router e o
//      backend usa $olt_srv_bridge (11) / $olt_srv_router (68). "Perfil genérico" manda line+srv.
//   2) "ont confirm ... ont-lineprofile-id LP ont-srvprofile-id SP" grava na OLT.
//   3) SERVICE-PORT via olt_sp_criar(): lê os GEM do line-profile e usa o GEM REAL.
//      NUNCA voltar para "gemport 1" fixo: com line-profile SMARTOLT_FLEXIBLE_GPON a OLT recusa,
//      a ONU fica online e o cliente NÃO navega ("No service virtual port can be operated").
//   4) NATIVE-VLAN na LAN 1 (ont port native-vlan ... eth 1 vlan X): aplicada SEMPRE, em QUALQUER caso
//      (perfil automático, escolhido à mão ou em branco; Bridge ou Router) — mesmo comportamento em tudo,
//      pedido do provedor. Comprovado em produção (Bridge MAX1000 e Router ONT-MAX conectando). Em 23/09/2026 ele foi
//      trocado para "só em bridge" e ONT Router autorizada deixou de conectar (ROSALIA, ONT-MAX):
//      REVERTIDO. NÃO trocar para "só bridge" sem testar Router E Bridge na OLT.
//      Troca de VLAN / recriar service-port aplicam native-vlan também (mesma regra).
//   5) Falha do service-port NÃO é silenciosa: vira 'vlan_aviso' (vermelho) + 'sp_ok'/'sp_gem'.
//
// NÃO REMOVER / NÃO ALTERAR SEM TESTAR NA OLT:
//   - olt_sp_criar(), olt_sp_falhou()      (service-port com GEM certo; usado também em
//                                            onu_trocar_vlan e criar_service_port)
//   - olt_telnet_logout()                  ("quit" em laço + "y": sem isso as sessões ficam
//                                            presas e a OLT recusa: "Reenter times have
//                                            reached the upper limit")
//   - $OLT_SRV_CAP, olt_srv_tipo()         (regra Bridge/Router)
//   - $olt_srv_bridge / $olt_srv_router    (padrões quando o perfil fica em branco)
//   - modo='' enviado pela tela quando há perfil escolhido
// Ficha da ONU -> "Trocar VLAN" (mesma VLAN = RECRIAR o service-port): conserta ONU online sem
// navegar, sem reaprovisionar. Abre janela de processamento e confere o service-port no fim.
// =============================================================================
$OLT_SRV_CAP = [
    // Bridging (ONU)
    'FIBERLINK' => 'ONU', 'HG8010H' => 'ONU', 'INTEL-R1' => 'ONU', 'MAX1000' => 'ONU', 'UBIQUIT' => 'ONU',
    // Bridging/Routing (ONT)
    'ONT-FIBERLINK' => 'ONT', 'ONT-HUAWEI-V2' => 'ONT', 'ONT-INTELBRAS-121' => 'ONT',
    'ONT-MAX' => 'ONT', 'ONT-MULTILESE' => 'ONT',
];
function olt_srv_tipo($srv) {
    global $OLT_SRV_CAP;
    $s = strtoupper(trim($srv));
    if ($s === '') return '';
    if (isset($OLT_SRV_CAP[$s])) return $OLT_SRV_CAP[$s];
    if (strpos($s, 'ONT-') === 0 || strpos($s, 'ONT ') === 0) return 'ONT'; // regra geral: ONT-* = router
    return 'ONU'; // demais perfis = bridge
}
// Parser de "display ont version <porta> all" -> map "fsp|ontid" => modelo.
// A saida repete um BLOCO por ONT (F/S/P, ONT-ID, Vendor-ID, Equipment-ID...).
// Divide por ONT-ID e pega o Equipment-ID de cada bloco.
function parse_versao_all($saida, $fspBase) {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    $map = [];
    $blocos = preg_split('/(?=(?:ONT[\s\-]*ID|ID\s+da\s+ONT)\s*:)/i', $saida);
    foreach ($blocos as $b) {
        if (!preg_match('/(?:ONT[\s\-]*ID|ID\s+da\s+ONT)\s*:?\s*(\d+)/i', $b, $mid)) continue;
        $id = (int)$mid[1];
        $modelo = '';
        if     (preg_match('/Equipment-ID\s*:\s*([^\r\n]+?)\s*(?:\r|\n|$)/i', $b, $m)) $modelo = trim($m[1]);
        elseif (preg_match('/Product-ID\s*:\s*([^\r\n]+?)\s*(?:\r|\n|$)/i', $b, $m2))  $modelo = trim($m2[1]);
        if ($modelo !== '' && $modelo !== '-') $map[$fspBase . '|' . $id] = $modelo;
    }
    return $map;
}

// Reforco pelo MODELO (Equipment-ID) quando o service-profile nao resolveu.
// Heuristica: modelos router costumam ter "ONT"/HG8245/HG8145/M10G; bridge tem
// "ONU"/HG8010/MAXFIBER. So e usado como fallback (o service-profile tem prioridade).
function olt_modelo_tipo($m) {
    $s = strtoupper((string)$m);
    if ($s === '') return '';
    if (preg_match('/\bONT\b|M10G|HG824|HG814|HG831|EG8|ONT-/', $s)) return 'ONT';
    if (preg_match('/\bONU\b|HG8010|MAXFIBER|MONU/', $s))            return 'ONU';
    return '';
}

// Parser de "display ont-lineprofile/ont-srvprofile gpon all" -> [{id, nome}].
// Formato: colunas "Profile-ID  Profile-name  Binding-times" (linhas de dados
// comecam com o ID numerico; o cabecalho comeca com letra).
function parse_perfis_olt($saida) {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    $lista = []; $vistos = [];
    foreach (explode("\n", $saida) as $l) {
        $l = trim($l);
        if (preg_match('/^(\d+)\s+([A-Za-z0-9][\w\-.]*)/', $l, $m)) {
            $id = (int)$m[1];
            if (isset($vistos[$id])) continue;
            $vistos[$id] = 1;
            $lista[] = ['id' => $id, 'nome' => $m[2]];
        }
    }
    return $lista;
}

// Parser de "display vlan all" -> [{id, nome}]. Na MA5683T a VLAN e identificada
// pelo ID; se houver descricao configurada, tenta capturar. Filtra palavras de
// coluna (smart/mux/common/...) para nao virarem "nome".
// Retorna MAPA { "<id>" => "<nome/descricao>" }. Na MA5683T o nome/descricao da VLAN
// aparece na ultima coluna do "display vlan all" (quando configurado via "vlan desc").
function parse_vlans_olt($saida) {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    $map = [];
    $colWords = '/^(smart|mux|common|standard|super|sub|vlan|type|attribute|enable|disable|up|down|bind|mac|stat|null|none|\-)$/i';
    foreach (explode("\n", $saida) as $l) {
        if (!preg_match('/^\s*(\d{1,4})\s+/', $l, $m)) continue;
        $id = (int)$m[1]; if ($id < 1 || $id > 4094 || isset($map[(string)$id])) continue;
        $desc = '';
        // descricao = texto com letras/underscore no fim da linha (nome tipo SLT1_JUA1)
        if (preg_match('/([A-Za-z][\w\-]{2,}(?:[ _\-][\w\-]+){0,4})\s*$/', trim($l), $md)) {
            $d = trim($md[1]);
            if (!preg_match($colWords, $d)) $desc = $d;
        }
        $map[(string)$id] = $desc;
    }
    return $map;
}

// Remove duplicatas. A chave DEFINITIVA e F/S/P + ONT-ID: identifica de forma
// unica cada ONU fisica na OLT (nunca ha duas ONTs com o mesmo F/S/P+ID).
// Ao deduplicar, mantem a versao mais "completa" (com serial/nome preenchidos).
function olt_dedup($arr) {
    $por = [];
    foreach ($arr as $o) {
        $k = $o['fsp'] . '|' . $o['id'];
        if (!isset($por[$k])) { $por[$k] = $o; continue; }
        // ja existe: completa campos vazios com o que vier
        foreach (['serial', 'status', 'nome', 'zona', 'vlan', 'rx', 'tx'] as $c) {
            if (empty($por[$k][$c]) && !empty($o[$c])) $por[$k][$c] = $o[$c];
        }
    }
    return array_values($por);
}

// ---------------- Cache em arquivo (varredura por slot) ----------------------
// DUAL-CACHE (mesma lógica do jcache): a LISTA de ONUs que o cron coleta precisa chegar na TELA.
// O FPM (tela) grava/lê /tmp e o CLI (cron) o cache_trafego -> se divergirem, a tela vê a lista VAZIA
// e cai em varredura Telnet AO VIVO (lentidão geral!). Grava nas 2 pastas e lê a MAIS NOVA.
function olt_cache_path() { return olt_cache_dir() . '/olt_onus_cache.json'; }
/** Pede ao cron a revarredura de uma placa (ONU recém-aprovisionada). */
function olt_rescan_marcar($slot) {
    $p = olt_jcache_load('olt_rescan_slots.json');
    $s = (array)($p['slots'] ?? []);
    $s[(string)(int)$slot] = time();
    olt_jcache_save('olt_rescan_slots.json', ['slots' => (object)$s]);
}
function olt_cache_load() {
    $best = null; $bts = -1;
    foreach (olt_cache_dirs() as $d) { $f = $d . '/olt_onus_cache.json';
        if (is_file($f)) { $t = (int)@filemtime($f); if ($t >= $bts) { $x = json_decode(@file_get_contents($f), true); if (is_array($x)) { $best = $x; $bts = $t; } } }
    }
    return (is_array($best)) ? $best : ['ts' => 0, 'slots' => []];
}
function olt_cache_save($c, $lockJaObtido = null) {
    // TRAVA (ver olt_json_lock acima): sem ela, duas gravações concorrentes (2 abas, ou uma aba e
    // o cron_scan) podiam se sobrepor e uma apagar a outra. $lockJaObtido permite que quem já
    // segura a trava (ex.: olt_cache_merge_slot) passe o mesmo handle e evite pedir a trava de novo
    // no MESMO processo (flock não é reentrante — pedir 2x travaria a si mesmo).
    $meuLock = ($lockJaObtido !== null) ? $lockJaObtido : olt_json_lock('olt_onus_cache');
    // SEM DADO NOVO NÃO APAGA O ANTERIOR: se a leitura veio VAZIA (sem ONUs) mas já existe cache
    // com dados, mantém o último dado bom em vez de esvaziar a tela. Só grava se houver conteúdo
    // (ou se ainda não existir cache algum). Assim o auto (3 min) atualiza quando há novidade e
    // preserva o anterior quando a OLT não respondeu / não mudou.
    //
    // Esta proteção existia na versão anterior do módulo e se perdeu na que veio no zip: sem ela,
    // uma varredura que falhe (Telnet ocupado, sessão derrubada) zera a lista na tela.
    $novoVazio = !is_array($c) || empty($c['slots']);
    if ($novoVazio) {
        $ant = olt_cache_load();
        if (!empty($ant['slots'])) { if ($meuLock !== null && $lockJaObtido === null) olt_json_unlock($meuLock); return; }
    }
    $data = json_encode($c, JSON_UNESCAPED_UNICODE);
    foreach (olt_cache_dirs() as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); if (@file_put_contents($d . '/olt_onus_cache.json', $data) !== false) @chmod($d . '/olt_onus_cache.json', 0666); }
    if ($meuLock !== null && $lockJaObtido === null) olt_json_unlock($meuLock);
}

/**
 * GRAVAÇÃO SEGURA de UM slot no cache de ONUs — usada pelo cron_scan (placa a placa) e pela
 * autorização de ONU nova. Em vez de reaproveitar uma cópia de $c carregada minutos atrás (que é
 * exatamente o que causava a "corrida perdida" contra outra aba/atendente ou contra o próprio
 * cron), esta função SEMPRE relê o cache do disco NA HORA, por dentro da trava, aplica só a
 * mudança deste slot e grava — outros slots alterados por outro processo enquanto isso não se
 * perdem. $onus === null significa "não mude a lista deste slot" (só quer atualizar timestamp/
 * outros slots via $extra).
 */
/* LEITURA PARCIAL DA PLACA NÃO DERRUBA A CONTAGEM (17/10/2026). A leitura por Telnet às vezes volta INCOMPLETA (sessão ocupada/cortada, PON que não respondeu a tempo): a lista da placa vinha com bem menos ONUs e SUBSTITUÍA a lista boa,
 * e as contagens da placa/OLT caíam até a próxima leitura completa (visto no histórico: 707 → 380 → 537 → 707). Agora, se a leitura nova tem menos de 85% das ONUs que a placa já tinha (e eram 20+), ela é tratada como parcial: o que veio
 * atualiza, e as ONUs que NÃO vieram ficam como estavam (marcadas _antigo=1). Se a MESMA contagem baixa se repetir em 3 leituras seguidas, é mudança real e a lista nova vale. Cada ocorrência vai para olt_leitura_parcial.log. */
function olt_slot_proteger($slot, $ant, $novo) {
    if (!is_array($ant) || !is_array($novo) || count($ant) < 20) return $novo;
    $a = count($ant); $n = count($novo); $k = (string)(int)$slot;
    $st = olt_jcache_load('olt_leitura_parcial.json'); if (!is_array($st)) $st = [];
    if ($n >= $a * 0.85) { if (isset($st[$k])) { unset($st[$k]); olt_jcache_save('olt_leitura_parcial.json', $st); } return $novo; }
    $vezes = (isset($st[$k]) && (int)($st[$k]['n'] ?? -1) === $n) ? (int)($st[$k]['vezes'] ?? 1) + 1 : 1;
    if ($vezes >= 3) { unset($st[$k]); olt_jcache_save('olt_leitura_parcial.json', $st); return $novo; }   // repetiu: mudança real
    $st[$k] = ['n' => $n, 'vezes' => $vezes, 'ts' => time()]; olt_jcache_save('olt_leitura_parcial.json', $st);
    $tem = []; foreach ($novo as $o) $tem[($o['fsp'] ?? '') . '|' . ($o['id'] ?? '')] = 1;
    $ficou = 0; foreach ($ant as $o) { $kk = ($o['fsp'] ?? '') . '|' . ($o['id'] ?? ''); if (!isset($tem[$kk])) { $o['_antigo'] = 1; $novo[] = $o; $ficou++; } }
    usort($novo, function ($x, $y) { $c = strnatcmp((string)($x['fsp'] ?? ''), (string)($y['fsp'] ?? '')); return $c !== 0 ? $c : ((int)($x['id'] ?? 0) <=> (int)($y['id'] ?? 0)); });
    @file_put_contents(olt_cache_dir() . '/olt_leitura_parcial.log', date('d/m H:i:s') . " placa $k: leitura parcial ($n de $a ONUs, " . $vezes . "/3) — mantidas $ficou da leitura anterior\n", FILE_APPEND);
    return $novo;
}
function olt_cache_merge_slot($slot, $onus, array $extraSlots = []) {
    $lock = olt_json_lock('olt_onus_cache');
    if ($lock === null) return false; // não segue sem trava: melhor falhar visivelmente que perder dado
    $c = olt_cache_load();
    if (!isset($c['slots']) || !is_array($c['slots'])) $c['slots'] = [];
    if ($onus !== null && $onus !== []) { $c['slots'][(string)(int)$slot] = olt_slot_proteger($slot, $c['slots'][(string)(int)$slot] ?? [], $onus); }
    foreach ($extraSlots as $sl => $arr) { if ($arr) $c['slots'][(string)(int)$sl] = olt_slot_proteger($sl, $c['slots'][(string)(int)$sl] ?? [], $arr); }
    $c['ts'] = time();
    olt_cache_save($c, $lock);
    olt_json_unlock($lock);
    return true;
}

// ---------------- SmartOLT API (mapa SN -> id do ONU) ------------------------
function smartolt_api($url, $token, $path) {
    $full = rtrim($url, '/') . '/api/' . ltrim($path, '/');
    $GLOBALS['_smartolt_diag'] = ['url' => $full, 'via' => '', 'http' => 0, 'erro' => ''];
    if (function_exists('curl_init')) {
        $ch = curl_init($full);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['X-Token: ' . $token, 'Accept: application/json'],
            CURLOPT_TIMEOUT        => 45,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT      => 'acellApp/olt',
        ]);
        $resp = curl_exec($ch);
        $GLOBALS['_smartolt_diag']['via']  = 'curl';
        $GLOBALS['_smartolt_diag']['http'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $GLOBALS['_smartolt_diag']['erro'] = curl_error($ch);
        curl_close($ch);
        return $resp !== false ? $resp : '';
    }
    // Fallback sem cURL
    $ctx = stream_context_create(['http' => ['header' => "X-Token: $token\r\nAccept: application/json\r\n", 'timeout' => 45, 'ignore_errors' => true],
                                  'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $r = @file_get_contents($full, false, $ctx);
    $GLOBALS['_smartolt_diag']['via']  = 'file_get_contents';
    $GLOBALS['_smartolt_diag']['erro'] = ($r === false) ? 'file_get_contents falhou (allow_url_fopen?)' : '';
    return $r !== false ? $r : '';
}
// Resolve o olt_id do SmartOLT (1x, cache 1 dia). Se só há 1 OLT, usa ela; senão casa pelo IP/nome.
function smartolt_olt_id() {
    global $smartolt_url, $smartolt_token, $olt_ip;
    static $cached = null; if ($cached !== null) return $cached;
    $f = olt_cache_dir() . '/smartolt_oltid.txt';
    if (is_file($f) && (time() - filemtime($f) < 86400)) { $v = trim((string)@file_get_contents($f)); if ($v !== '') { $cached = $v; return $v; } }
    $j = json_decode(smartolt_api($smartolt_url, $smartolt_token, 'system/get_olts'), true);
    $olts = (is_array($j) && isset($j['response']) && is_array($j['response'])) ? $j['response'] : [];
    $id = '';
    if (count($olts) === 1) { $id = (string)($olts[0]['id'] ?? ''); }
    else { foreach ($olts as $o) { if (($o['ip'] ?? '') === $olt_ip) { $id = (string)($o['id'] ?? ''); break; } } if ($id === '' && $olts) $id = (string)($olts[0]['id'] ?? ''); }
    if ($id !== '') { @file_put_contents($f, $id); @chmod($f, 0666); }
    $cached = $id; return $id;
}
// POST na API do SmartOLT (form-urlencoded) — usado p/ authorize_onu / update. Devolve
// ['http'=>codigo, 'body'=>resposta]. Mesma auth (X-Token).
function smartolt_api_post($url, $token, $path, array $params) {
    $full = rtrim($url, '/') . '/api/' . ltrim($path, '/');
    $post = http_build_query($params);
    if (function_exists('curl_init')) {
        $ch = curl_init($full);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $post,
            CURLOPT_HTTPHEADER => ['X-Token: ' . $token, 'Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT => 60, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_USERAGENT => 'acellApp/olt',
        ]);
        $resp = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        return ['http' => $http, 'body' => ($resp !== false ? $resp : ''), 'erro' => $err];
    }
    $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => "X-Token: $token\r\nContent-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\n", 'content' => $post, 'timeout' => 60, 'ignore_errors' => true],
                                  'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $r = @file_get_contents($full, false, $ctx);
    $code = 0; if (isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) $code = (int)$m[1];
    return ['http' => $code, 'body' => ($r !== false ? $r : ''), 'erro' => ($r === false ? 'falha POST' : '')];
}
// Normaliza um SN vindo do SmartOLT/OLT para comparar (maiusculo, so alfanumerico)
function sn_norm($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); }
/** Chave ÚNICA do serial: sempre em HEX ("MONU00E07A69" e "4D4F4E5500E07A69" viram a mesma). */
function olt_sn_chave($s) { $h = function_exists('sn_para_hex') ? strtoupper((string)sn_para_hex($s)) : ''; return $h !== '' ? $h : sn_norm($s); }
// Constroi/le do cache o mapa SmartOLT (cache de 10 min).
// __v marca o formato do mapa; se o cache for de formato antigo, e reconstruido.
function smartolt_mapa($url, $token) {
    $f = olt_cache_dir() . '/smartolt_map.json';
    if (is_file($f) && (time() - filemtime($f)) < 600) {
        $d = json_decode(@file_get_contents($f), true);
        if (is_array($d) && isset($d['__v']) && $d['__v'] === 5) return $d; // so aceita cache no formato atual
        @unlink($f); // cache antigo/incompativel -> descarta
    }
    $raw = smartolt_api($url, $token, 'onu/get_all_onus_details');
    $j = json_decode($raw, true);
    $map = ['__v' => 5];
    if (is_array($j)) {
        // A lista de ONUs pode vir em 'onus', 'response', 'data' ou na raiz
        $lista = $j['onus'] ?? $j['response'] ?? $j['data'] ?? (isset($j[0]) ? $j : []);
        if (is_array($lista)) {
            foreach ($lista as $o) {
                if (!is_array($o)) continue;
                $modo = strtolower($o['mode'] ?? $o['modo'] ?? '');
                // AJUSTE no download: o SmartOLT normalmente traz zona/nome ESTRUTURADOS
                // (zone_name / name). Mas se o 'name' vier com os tokens do formato de descrição
                // (NOME_zone_ZONA_descr_..._lat_..._long_..._authd_...), a gente LIMPA o nome e,
                // se a zona estruturada estiver vazia, EXTRAI a zona desses tokens. Assim o que
                // baixa da nuvem já vem ajustado (nome limpo + zona certa), batendo com o que o
                // nosso aprovisionamento grava na OLT.
                $nomeApi = (string)($o['name'] ?? $o['nome'] ?? '');
                $zonaApi = (string)($o['zone_name'] ?? '');
                if (strpos($nomeApi, '_zone_') !== false || strpos($nomeApi, '_descr_') !== false || strpos($nomeApi, '_authd_') !== false) {
                    if ($zonaApi === '' && preg_match('/_zone_(.*?)(?:_descr_|_lat_|_long_|_authd_|$)/is', $nomeApi, $mz)) {
                        $zonaApi = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $mz[1])));
                    }
                    $partesN = preg_split('/_zone_|_descr_|_lat_|_long_|_authd_/i', $nomeApi);
                    $nomeApi = trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $partesN[0])));
                }
                $rec = [
                    // ID INTERNO da ONU no SmartOLT (o que /onu/view/<id> usa p/ abrir o equipamento).
                    // O unique_external_id NAO serve (leva pra aba de autorizacao).
                    'id'   => (string)($o['onu_id'] ?? $o['id'] ?? $o['unique_external_id'] ?? ''),
                    'ext'  => (string)($o['unique_external_id'] ?? ''),
                    'vlan' => (string)($o['vlan'] ?? ''),
                    // Bridging = ONU (bridge) ; Routing/Route = ONT (router)
                    'tipo' => (strpos($modo, 'bridg') !== false ? 'ONU' : (strpos($modo, 'rout') !== false ? 'ONT' : '')),
                    'modo' => (string)($o['mode'] ?? $o['modo'] ?? ''),
                    'zona' => $zonaApi,
                    'nome' => $nomeApi,
                    'sinal'   => (string)($o['signal'] ?? ''),        // Rx da ONU
                    'sinal_tx'=> (string)($o['signal_1310'] ?? ''),   // Tx da ONU (upstream)
                ];
                // Casa por MULTIPLAS chaves para preencher TODAS as ONUs:
                //  (a) serial (com e sem prefixo), (b) sn ASCII, (c) posicao F/S/P+ont-id.
                foreach ([$o['unique_external_id'] ?? '', $o['sn'] ?? ''] as $k) {
                    $kn = sn_norm($k);
                    if ($kn !== '') { $map['sn:' . $kn] = $rec; $map[$kn] = $rec; }
                }
                $board = $o['board'] ?? ''; $port = $o['port'] ?? ''; $onu = $o['onu'] ?? '';
                if ($board !== '' && $port !== '' && $onu !== '') {
                    $map['pos:0/' . (int)$board . '/' . (int)$port . '|' . (int)$onu] = $rec;
                }
            }
        }
    }
    if (count($map) > 1) @file_put_contents($f, json_encode($map)); // >1 pois __v sempre existe
    return $map;
}

// =============================================================================
// BUSCA UMA ONU PELO SN (comando direto, sem varrer a OLT inteira)
// =============================================================================
function buscar_por_sn($ip, $porta_tel, $user, $pass, $sn, $idleTimeout, &$bruto = null) {
    $comandos = ['enable', 'config', "display ont info by-sn $sn", 'quit', 'quit'];
    $out = olt_exec($ip, $porta_tel, $user, $pass, $comandos, $idleTimeout);
    $bruto = $out[2] ?? '';

    // OLT responde com erro quando o SN nao existe (ex.: "Failure: ...")
    if ($bruto === '' || preg_match('/(Failure|does not exist|The required.*not|Parameter error|Erro de)/i', $bruto)) {
        return null;
    }
    $ont = parse_ont_detalhe($bruto);
    if ($ont['fsp'] === '' && $ont['id'] === '') return null;
    return $ont;
}

// =============================================================================
// EXECUCAO
// =============================================================================
$acao = $_GET['acao'] ?? $_POST['acao'] ?? 'listar_todos';
// Consultas que o operador pede na ficha da ONU: esperam a vez na trava do Telnet (sem sessão paralela).
if (in_array($acao, ['onu_vlan', 'onu_portas', 'onu_optico', 'onu_trafego', 'onu_uptime', 'onu_trocar_vlan', 'criar_service_port', 'onu_acao', 'autorizar', 'onu_combo', 'onu_uptime', 'onu_modo', 'pon_control', 'placa_estado', 'placa_reset', 'autofind', 'uplink_estado', 'uplink_vlan', 'vlan_criar', 'vlan_excluir'], true)) $GLOBALS['OLT_LOCK_MANUAL'] = 1;

// ---- AUTENTICAÇÃO E NÍVEIS (obrigatório antes de qualquer ação) -------------
// O olt_auth.php é OPCIONAL: se não estiver na pasta, o sistema roda sem login
// (compatível com instalações antigas). Estando presente, ninguém passa daqui
// sem sessão válida e sem o nível exigido pela ação.
if (is_file(__DIR__ . '/olt_auth.php')) {
    require_once __DIR__ . '/olt_auth.php';
    olt_auth_endpoints($acao);   // login / logout / sessão / usuários
    olt_auth_exigir($acao);      // porteiro: 401 sem sessão, 403 sem nível
}

// ---- TRAVA DE INSTALAÇÃO NÃO CONFIGURADA -----------------------------------
// Sem IP/usuário salvos, NADA que fale com a OLT é executado: a instalação nova
// começa zerada, sem herdar conexão de ninguém. As ações abaixo continuam
// liberadas porque são locais (configuração, dados em disco, diagnóstico).
$__acoes_locais = [
    'conexao_get' => 1, 'conexao_set' => 1, 'fix_perms' => 1, 'logo_get' => 1,
    'logo_set' => 1, 'logo_del' => 1, 'notif_get' => 1, 'notif_set' => 1,
    'meta_get' => 1, 'meta_set' => 1, 'modelos_get' => 1, 'modelos_set' => 1,
    'modelos_del' => 1, 'modelo_img_get' => 1, 'modelo_img_set' => 1,
    'modelo_img_del' => 1, 'backup_export' => 1, 'backup_import' => 1,
    'relatorio' => 1, 'relatorio_limpar' => 1, 'perfis_get' => 1,
    'perfis_add' => 1, 'perfis_del' => 1, 'cadastro_seed' => 1,
    'backup_run' => 1, 'backup_diag' => 1,   // backup é LOCAL — nunca depende da OLT
    'diag_origem' => 1, 'visto_sync' => 1,
];
if (trim((string)$olt_ip) === '' && !isset($__acoes_locais[$acao])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'          => 'nao_configurado',
        'nao_configurado' => true,
        'message'         => 'OLT não configurada. Abra "Conexão da OLT" e informe IP/host, porta, usuário e senha.',
        'onus'            => [], 'slots' => [], 'alertas' => [], 'total' => 0,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {

    // ---- DEBUG: etapas cruas do login --------------------------------------
    if ($acao === 'debug_login') {
        $socket = @fsockopen($olt_ip, $olt_porta, $errno, $errstr, $olt_timeout);
        if (!$socket) { echo json_encode(['status' => 'error', 'message' => "Falha ao conectar: $errstr"]); exit; }
        stream_set_blocking($socket, true);
        stream_set_timeout($socket, 2);

        $etapas = [];
        $ler = function($rotulo, $rx) use ($socket, $olt_timeout, &$etapas) {
            $r = olt_ler_ate($socket, $rx, $olt_timeout);
            $etapas[] = ['etapa' => $rotulo, 'bytes' => strlen($r), 'resposta' => $r];
            return $r;
        };
        $ler('1 - banner / user name', $GLOBALS['RX_USER']);
        @fwrite($socket, $olt_user . "\r\n");
        $ler('2 - apos usuario', $GLOBALS['RX_PASS']);
        @fwrite($socket, $olt_pass . "\r\n");
        $ler('3 - apos senha (prompt de comando)', $GLOBALS['RX_PROMPT']);
        @fwrite($socket, "enable\r\n");
        $ler('4 - apos enable', $GLOBALS['RX_PROMPT']);
        @fwrite($socket, "config\r\n");
        $ler('5 - apos config', $GLOBALS['RX_PROMPT']);
        olt_telnet_logout($socket);
        echo json_encode(['status' => 'ok', 'etapas' => $etapas], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: saida bruta do by-sn ---------------------------------------
    if ($acao === 'debug_sn') {
        $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $_GET['sn'] ?? $_POST['sn'] ?? ''));
        if ($sn === '') { echo json_encode(['status' => 'error', 'message' => 'SN nao informado.']); exit; }
        $bruto = '';
        $ont = buscar_por_sn($olt_ip, $olt_porta, $olt_user, $olt_pass, $sn, $olt_timeout, $bruto);
        echo json_encode(['status' => 'ok', 'sn_consultado' => $sn, 'saida_bruta' => $bruto, 'parse' => $ont], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: varre toda a faixa e mostra bruto + parse ------------------
    if ($acao === 'debug_varrer') {
        $relatorio = [];
        $board = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
        $relatorio['display_board_0'] = $board[1] ?? '';

        $bruto = [];
        $todas = varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, $faixa_slots, $faixa_portas, $olt_timeout, $bruto);
        foreach ($bruto as $fsp => $b) {
            $relatorio['portas'][$fsp] = [
                'bytes_bruto'    => strlen($b),
                'onts_parseadas' => count(parse_lista_ont($b, $fsp)),
                'saida_bruta'    => $b,
            ];
        }
        $relatorio['total_onts'] = count($todas);
        $relatorio['onts']       = $todas;
        echo json_encode(['status' => 'ok', 'relatorio' => $relatorio], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: saida bruta de UMA porta (para achar duplicidade/tipo) -----
    //   olt_huawei.php?acao=debug_slot_raw&slot=1&porta=0
    if ($acao === 'debug_slot_raw') {
        $slot   = (int)($_GET['slot'] ?? 1);
        $portas = isset($_GET['porta']) ? [(int)$_GET['porta']] : $faixa_portas;
        $bruto  = [];
        varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, [$slot], $portas, $olt_timeout, $bruto);
        $rel = [];
        foreach ($bruto as $fsp => $b) {
            $rel[$fsp] = [
                'bytes'          => strlen($b),
                'onts_parseadas' => count(parse_lista_ont($b, $fsp)),
                'saida_bruta'    => $b,
            ];
        }
        echo json_encode(['status' => 'ok', 'slot' => $slot, 'portas' => $rel], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: comandos de VLAN/WAN/trafego de uma ONU (para acertar cmd) --
    //   olt_huawei.php?acao=debug_onu&fsp=0/3/4&id=15
    if ($acao === 'debug_onu') {
        $fsp = preg_replace('/[^0-9\/]/', '', $_GET['fsp'] ?? '');
        $id  = (int)($_GET['id'] ?? -1);
        $p   = explode('/', $fsp);
        if (count($p) !== 3 || $id < 0) { echo json_encode(['status' => 'error', 'message' => 'fsp/id invalidos']); exit; }
        $slot = (int)$p[1]; $port = (int)$p[2];
        $cmds = [
            'enable', 'config',
            "display service-port port 0/$slot/$port ont $id",
            "interface gpon 0/$slot",
            "display ont wan-info $port $id",
            "display ont port vlan $port $id",
            "display ont traffic $port $id",
        ];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        echo json_encode(['status' => 'ok', 'comandos' => $cmds, 'saidas' => $out], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: formato do "display service-port board" (para VLAN) ---------
    //   olt_huawei.php?acao=debug_sp&slot=3
    if ($acao === 'debug_sp') {
        $slot = (int)($_GET['slot'] ?? 3);
        $out  = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', "display service-port board 0/$slot", 'quit'], $olt_timeout);
        $raw = $out[2] ?? '';
        echo json_encode(['status' => 'ok', 'slot' => $slot, 'saida_bruta' => $raw, 'vlan_map' => parse_service_ports($raw)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- REPARO: cria o service-port de uma ONU JÁ confirmada mas que ficou sem VLAN --------
    // Corrige o caso "autorizei sem informar VLAN": a ONU está confirmada na OLT (OMCI/gerência)
    // mas sem caminho de dados nenhum até o concentrador. Em vez de excluir e reaprovisionar (que
    // faz a ONU passar de novo por todo o autofind), isto só roda o "service-port vlan ... ont ..."
    // que faltou. NÃO tenta adivinhar se já existe service-port (o formato de saída do "display
    // service-port port ... ont ..." não foi validado nesta OLT) — deixa a própria OLT recusar se
    // já houver conflito (ela responde Failure/"in use"), e mostra a saída bruta pro operador ver.
    if ($acao === 'criar_service_port') {
        $fsp = preg_replace('/[^0-9\/]/', '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $id  = (int)($_POST['id'] ?? $_GET['id'] ?? -1);
        $vlanRep = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
        $p = explode('/', $fsp);
        if (count($p) !== 3 || $id < 0 || $vlanRep <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Informe F/S/P, ONT-ID e uma VLAN válida (> 0).']); exit;
        }
        $slot = (int)$p[1]; $port = (int)$p[2];
        $chk = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', "display service-port port 0/$slot/$port ont $id", 'quit'], $olt_timeout);
        $rawChk = $chk[2] ?? '';
        // GEM real do line-profile + native-vlan (bridge) — olt_sp_criar()
        $spRes = olt_sp_criar($olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout, $slot, $port, $id, $vlanRep, null, true);   // native-vlan: mesma regra da autorização
        $rawSpRep = $spRes['saida']; $falhou = !$spRes['ok'];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', "interface gpon 0/$slot", "display ont info $port $id"], $olt_timeout);
        $rawVerifRep = end($out);
        if (!$falhou) olt_log_registrar('reparo-service-port', "VLAN $vlanRep criada (ONT-ID $id, gem {$spRes['gem']})", "0/$slot/$port");
        echo json_encode(['status' => 'ok', 'sucesso' => !$falhou, 'sp_gem' => $spRes['gem'],
                          'comando' => "service-port vlan $vlanRep gpon 0/$slot/$port ont $id gemport " . ($spRes['gem'] ?? '?') . " multi-service user-vlan $vlanRep",
                          'saida' => "--- service-port já existente (antes) ---\n" . $rawChk
                                   . "\n\n--- comando de criação ---\n" . $rawSpRep . "\n\n--- verificação ---\n" . $rawVerifRep], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- SmartOLT: mapa SN -> id (para linkar o nome) ----------------------
    if ($acao === 'smartolt_map') {
        echo json_encode(['status' => 'ok', 'url' => $smartolt_url, 'map' => smartolt_mapa($smartolt_url, $smartolt_token)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- SmartOLT: INFO p/ montar o authorize_onu (OLTs, zonas, tipos de ONU) --
    // Lê da API do SmartOLT os IDs REAIS desta instalação, pra eu montar o authorize com os valores
    // certos (sem chutar): olt_id (casando pelo IP da OLT), zonas, tipos de ONU, e as não-configuradas.
    if ($acao === 'smartolt_prov_info') {
        header('Content-Type: application/json; charset=utf-8');
        // TENTA vários caminhos e pega o 1º que der certo de verdade (response_code success ou lista).
        $tenta = function (array $paths) use ($smartolt_url, $smartolt_token) {
            $tentativas = [];
            foreach ($paths as $p) {
                $raw = smartolt_api($smartolt_url, $smartolt_token, $p);
                $j = json_decode($raw, true);
                $ok = is_array($j) && (
                    (isset($j['response_code']) && $j['response_code'] === 'success') ||
                    (isset($j['status']) && $j['status'] === true && !isset($j['error'])) ||
                    isset($j['response']) || isset($j[0])
                );
                $tentativas[] = ['path' => $p, 'ok' => $ok, 'erro' => (is_array($j) && isset($j['error']) ? $j['error'] : null)];
                if ($ok) return ['path' => $p, 'json' => $j, 'tentativas' => $tentativas];
            }
            return ['path' => null, 'json' => null, 'tentativas' => $tentativas];
        };
        $olts  = $tenta(['system/get_olts']);
        $zones = $tenta(['system/get_zones']);
        $types = $tenta(['system/get_onu_types', 'onu/get_onu_types', 'system/get_onu_type_profiles', 'onu/get_onu_type_profiles', 'system/get_onu_profiles', 'onu/get_onu_profiles']);
        $sprof = $tenta(['system/get_service_profiles', 'onu/get_service_profiles', 'system/get_onu_services']);
        $unconf = $tenta(['onu/unconfigured_onus/2', 'onu/get_unconfigured_onus/2', 'onu/unconfigured/2']);
        echo json_encode(['status' => 'ok', 'url' => $smartolt_url, 'olt_id' => 2,
            'olts' => $olts, 'zones' => $zones, 'onu_types' => $types, 'service_profiles' => $sprof, 'unconfigured' => $unconf], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- SmartOLT: AUTORIZAR uma ONU via API (o SmartOLT grava zona/modo/tipo certos) ----
    // Recebe sn, board, port, vlan, zone(nome), onu_type(nome), onu_mode(Bridging/Routing), name.
    // Devolve a resposta CRUA do SmartOLT (pra vermos o contrato exato e iterar).
    if ($acao === 'smartolt_authorize') {
        header('Content-Type: application/json; charset=utf-8');
        $params = [
            'olt_id'    => (int)($_POST['olt_id'] ?? $_GET['olt_id'] ?? 2),
            'pon_type'  => trim($_POST['pon_type'] ?? $_GET['pon_type'] ?? 'gpon'),
            'board'     => trim($_POST['board'] ?? $_GET['board'] ?? ''),
            'port'      => trim($_POST['port'] ?? $_GET['port'] ?? ''),
            'sn'        => trim($_POST['sn'] ?? $_GET['sn'] ?? ''),
            'onu_type'  => trim($_POST['onu_type'] ?? $_GET['onu_type'] ?? ''),   // NOME (ex.: MAX1000)
            'onu_mode'  => trim($_POST['onu_mode'] ?? $_GET['onu_mode'] ?? 'Bridging'),
            'zone'      => trim($_POST['zone'] ?? $_GET['zone'] ?? ''),           // NOME (ex.: RUA DO RIO)
            'name'      => trim($_POST['name'] ?? $_GET['name'] ?? ''),
            'vlan'      => trim($_POST['vlan'] ?? $_GET['vlan'] ?? ''),
        ];
        // remove vazios (pra não mandar campo em branco que a API rejeite)
        $params = array_filter($params, function ($v) { return $v !== '' && $v !== null; });
        $r = smartolt_api_post($smartolt_url, $smartolt_token, 'onu/authorize_onu', $params);
        $j = json_decode($r['body'], true);
        echo json_encode(['status' => 'ok', 'http' => $r['http'], 'enviado' => $params,
            'resposta' => (is_array($j) ? $j : null), 'raw' => (is_array($j) ? null : substr((string)$r['body'], 0, 600)),
            'erro_conn' => $r['erro']], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG SmartOLT: diagnostico completo da API -----------------------
    if ($acao === 'smartolt_debug') {
        $path = $_GET['path'] ?? 'onu/get_all_onus_details';
        $raw  = smartolt_api($smartolt_url, $smartolt_token, $path);
        $j    = json_decode($raw, true);
        $lista = is_array($j) ? ($j['onus'] ?? $j['response'] ?? $j['data'] ?? (isset($j[0]) ? $j : [])) : [];
        $primeiro = (is_array($lista) && isset($lista[0])) ? $lista[0] : null;
        echo json_encode([
            'status'       => 'ok',
            'path'         => $path,
            'diag'         => $GLOBALS['_smartolt_diag'] ?? null,
            'bytes_raw'    => strlen($raw),
            'json_erro'    => json_last_error_msg(),
            'chaves_raiz'  => is_array($j) ? array_keys($j) : gettype($j),
            'total'        => is_array($lista) ? count($lista) : 0,
            'campos'       => $primeiro ? array_keys($primeiro) : [],
            'trecho_raw'   => substr($raw, 0, 700),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- STATUS DA OLT (cabecalho): uptime + placas + temperatura ----------
    if ($acao === 'olt_status') {
        $scu  = olt_scu_slot();                 // detecta 1x, depois vem do cache
        $slot = ($scu !== null) ? $scu : 6;     // padrão MA5683T
        // SÓ uptime + temperatura (rápido e confiável). CPU foi removido: o firmware MA5683T não
        // expõe (Telnet dá "comando desconhecido" e os OIDs SNMP dão No Such Object) — e a tentativa
        // deixava o status lento e sumia a info do topo.
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'display sysuptime', 'display temperature 0/' . $slot, 'quit'], $olt_timeout);
        $up = $out[1] ?? ''; $tp = $out[2] ?? '';
        $uptime = preg_match('/uptime\s*(?:is|:)?\s*(.+)/i', $up, $mu) ? trim($mu[1]) : trim(preg_replace('/^.*sysuptime\r?\n?/i', '', $up));
        $temp = olt_temp_txt($tp);   // temperatura da placa de controle (correta)
        $cpu = '';
        // Histórico de temperatura (anel de 96 amostras) p/ o gráfico da OLT.
        $tn = (int)preg_replace('/[^0-9\-]/', '', $temp);
        if ($tn > 0 && $tn < 120) {
            $th = olt_jcache_load('olt_temp_hist.json'); if (!isset($th['t'])) $th = ['t' => [], 'ts' => []];
            $th['t'][] = $tn; $th['ts'][] = time();
            if (count($th['t']) > 96) { $th['t'] = array_slice($th['t'], -96); $th['ts'] = array_slice($th['ts'], -96); }
            olt_jcache_save('olt_temp_hist.json', $th);
        }
        // Versão: SÓ lê o cache (instantâneo). A DETECÇÃO roda na ação separada 'versao_get'
        // (chamada async pelo front) — nunca dentro do status, pra não travar o topo.
        $vf = olt_cache_dir() . '/olt_versao.txt'; $ver = is_file($vf) ? trim((string)@file_get_contents($vf)) : '';
        echo json_encode(['status' => 'ok', 'uptime' => trim(substr($uptime, 0, 80)), 'temperatura' => $temp,
                          'cpu' => $cpu, 'versao' => $ver, 'olt' => 'OLT Huawei'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- VERSÃO da OLT (detecta 1x, cacheia) — chamada async pelo front, fora do status ----
    if ($acao === 'versao_get') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'ok', 'versao' => olt_versao()], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- DEBUG: saída crua do "display cpu-usage" (pra acertar o parser de CPU) ----
    if ($acao === 'cpu_raw') {
        header('Content-Type: application/json; charset=utf-8');
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'display cpu-usage', 'display cpu 0', 'quit'], $olt_timeout);
        echo json_encode(['raw' => is_array($out) ? implode("\n=====\n", $out) : (string)$out], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- APROVISIONAMENTO: listar ONUs novas (autofind) --------------------
    // A TELA lê do CACHE (instantâneo — abre na hora, não trava no Telnet). O cron pré-coleta a cada
    // ciclo. force=1 faz leitura Telnet nova (usado pelo cron e pelo botão "Atualizar" / pós-autorizar).
    if ($acao === 'autofind') {
        header('Content-Type: application/json; charset=utf-8');
        // SEM force (a TELA): SEMPRE do cache — NUNCA Telnet ao vivo (abre INSTANTÂNEO, nunca "gira").
        // Mesmo que o cache esteja velho/vazio, devolve o que tem; o cron (a cada 2 min) mantém fresco.
        // "Falso positivo" (ONU já autorizada aparecendo como aguardando, sumindo e voltando): o filtro
        // de "já registrada" só existia na leitura AO VIVO; a tela lê do CACHE, que alguma gravação
        // antiga (cron / outra cópia do cache) repunha. Agora o MESMO filtro vale para o cache.
        $registradas = function () {
            $reg = array(); $cc = olt_cache_load();
            if (isset($cc['slots']) && is_array($cc['slots'])) { foreach ($cc['slots'] as $arr) { if (is_array($arr)) foreach ($arr as $o) { $s = olt_sn_chave($o['serial'] ?? ''); if ($s !== '') $reg[$s] = $o; } } }
            return $reg;
        };
        /* ONU MOVIDA DE PORTA (30/09/2026): liberada numa PON/VLAN e ligada em OUTRA. Antes o filtro
           escondia QUALQUER SN já registrado, e ela sumia do Aprovisionamento. Agora:
             - registrada na MESMA porta, ou ONLINE na outra  -> esconde (o "falso positivo" de sempre);
             - registrada em OUTRA porta e fora do ar         -> aparece, com 'movida' = onde está
               cadastrada (a tela oferece Mover / Deletar e aprovisionar). */
        $filtrarReg = function (array $pend, array $reg) {
            $out = [];
            foreach ($pend as $p) {
                unset($p['movida']);   // recalcula sempre (o cache pode ter a marca de uma leitura antiga)
                $r = $reg[olt_sn_chave($p['sn'] ?? '')] ?? null;
                if ($r === null) { $out[] = $p; continue; }
                $fspReg = preg_replace('/\s+/', '', (string)($r['fsp'] ?? ''));
                $fspAf  = preg_replace('/\s+/', '', (string)($p['fsp'] ?? ''));
                $online = strtolower((string)($r['status'] ?? $r['estado'] ?? '')) === 'online';
                if ($fspReg === '' || $fspReg === $fspAf || $online) continue;
                $p['movida'] = ['fsp' => $fspReg, 'id' => (string)($r['id'] ?? ''), 'vlan' => (string)($r['vlan'] ?? ''),
                                'nome' => (string)($r['nome'] ?? ''), 'zona' => (string)($r['zona'] ?? ''),
                                'status' => (string)($r['estado'] ?? $r['status'] ?? '')];
                $out[] = $p;
            }
            return $out;
        };
        if (empty($_GET['force'])) {
            $c = olt_jcache_load('olt_autofind.json');
            $pendC = (array)($c['pendentes'] ?? []);
            $reg = $registradas();
            $pendC = $filtrarReg($pendC, $reg);
            echo json_encode(['status' => 'ok', 'pendentes' => $pendC, 'cache' => true,
                'idade' => isset($c['ts']) ? (time() - (int)$c['ts']) : -1], JSON_UNESCAPED_UNICODE); exit;
        }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', 'display ont autofind all', 'quit', 'quit'], $olt_timeout);
        $raw = $out[2] ?? '';
        $pend = parse_autofind($raw);
        // #5 (SEGURO): esconde só as ONUs que JÁ ESTÃO REGISTRADAS/ativas na OLT (aparecem na lista de
        // ONUs do cache). Uma ONU registrada não deveria estar no autofind — se a OLT a re-lista, a gente
        // não deixa "voltar" pra fila. NÃO usa olt_autorizacoes (que o backfill poluiu com todos os SNs).
        $reg = $registradas();
        $pend = $filtrarReg($pend, $reg);
        olt_jcache_save('olt_autofind.json', ['ts' => time(), 'pendentes' => $pend]);
        echo json_encode(['status' => 'ok', 'pendentes' => $pend, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- APROVISIONAMENTO: autorizar (liberar) uma ONU nova ----------------
    if ($acao === 'autorizar') {
        $fsp  = preg_replace('/[^0-9\/]/', '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $sn   = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $_POST['sn'] ?? $_GET['sn'] ?? ''));
        $nome = trim($_POST['nome'] ?? $_GET['nome'] ?? '');
        $lp   = (int)($_POST['lineprofile'] ?? $olt_lineprofile);
        $sp   = (int)($_POST['srvprofile'] ?? $olt_srvprofile);
        // IDs de profile validos na MA5683T sao pequenos (1..4096). Evita "Parameter error"
        // (ex.: 1000000) caindo no padrao quando vier valor invalido.
        if ($lp <= 0 || $lp > 4096) $lp = $olt_lineprofile;
        if ($sp <= 0 || $sp > 4096) $sp = $olt_srvprofile;
        // A ESCOLHA Bridge/Router define o srv-profile aplicado (grava na OLT o que foi escolhido).
        $modoSel = strtolower(trim($_POST['modo'] ?? $_GET['modo'] ?? ''));
        if ($modoSel === 'router') $sp = $olt_srv_router;
        elseif ($modoSel === 'bridge') $sp = $olt_srv_bridge;
        // Campos novos (opcionais) — vao na descricao/uso futuro
        $bairro = trim($_POST['bairro'] ?? '');   $rua    = trim($_POST['rua'] ?? '');
        $cidade = trim($_POST['cidade'] ?? '');   $numero = trim($_POST['numero'] ?? '');
        $onuTxt = trim($_POST['onu'] ?? '');      $ontTxt = trim($_POST['ont'] ?? '');
        $zona   = trim($_POST['zona'] ?? '');
        $tec    = strtolower(trim($_POST['tecnologia'] ?? 'gpon'));
        $modo   = strtolower(trim($_POST['modo'] ?? ''));
        $p    = explode('/', $fsp);
        if (count($p) !== 3 || $sn === '' || $nome === '') {
            echo json_encode(['status' => 'error', 'message' => 'Informe F/S/P, SN e Nome para autorizar.']);
            exit;
        }
        $vlan = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
        /* (16/10/2026) REGRA DE VLAN: a VLAN define a zona gravada na ONU (259 ALTO DA SANTA 1 · 260 ALTO DA SANTA 2 · 253 TAMATAUPE 1 · 254 TAMATAUPE 2 · 354 7 SETEMBRO). */
        if (is_file(__DIR__ . '/zonas_unificar_lib.php')) { require_once __DIR__ . '/zonas_unificar_lib.php'; if (($zv = ws_vlan_zona($vlan)) !== null) $zona = $zv; $zona = ws_zona_alias($zona); }
        $slot = (int)$p[1]; $port = (int)$p[2];

        // Descrição do "ont confirm". Se houver ZONA, grava o FORMATO COMPLETO do SmartOLT DIRETO no
        // confirm (atômico e confiável — o "ont modify ont-desc" separado caía com a congestão). O
        // SmartOLT parece EXIGIR o _descr_ pra ler a zona (só "_zone_ZONA" ele ignorou). A OLT aceita
        // descrição longa (as ONUs do SmartOLT têm ~125 chars). Formato EXATO das que funcionam:
        //   NOME_zone_ZONA_descr_NOME_lat_0_long_0_authd_ANO
        $zonaC = trim(preg_replace('/[_"\r\n]+/', ' ', (string)$zona));   // sem "_" (confunde o parser do SmartOLT)
        if ($zonaC !== '') {
            $desc = substr($nome . '_zone_' . $zonaC, 0, 63);   // curto e SEGURO (o SmartOLT não lê daqui mesmo; é só p/ a nossa lista)
        } else {
            $descFull = $nome . ($bairro ? ' ' . $bairro : '') . ($cidade ? ' ' . $cidade : '');
            $desc = substr(preg_replace('/["\r\n]+/', ' ', $descFull), 0, 63);
        }

        // Helper: o SN ainda esta pendente no autofind?
        $snPendente = function($rawAf) use ($sn) {
            foreach (parse_autofind($rawAf) as $pnd) { if (sn_norm($pnd['sn']) === sn_norm($sn)) return true; }
            return false;
        };

        // PASSO 0: RE-LOCALIZAR o SN no autofind AGORA e usar o F/S/P REAL que a
        // OLT reporta (o do formulario pode estar errado/alterado, e as entradas
        // de autofind da MA5683T expiram) -> corrige "ONT does not exist".
        $outAf0 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', 'display ont autofind all', 'quit'], $olt_timeout);
        $rawAf0 = $outAf0[2] ?? '';
        $achou = null;
        foreach (parse_autofind($rawAf0) as $pnd) { if (sn_norm($pnd['sn']) === sn_norm($sn)) { $achou = $pnd; break; } }
        if (!$achou) {
            echo json_encode(['status' => 'error',
                'message' => 'O SN ' . $sn . ' NAO esta mais na lista de autofind da OLT (pode ter expirado ou ja foi autorizado). Atualize o Aprovisionamento.',
                'saida' => $rawAf0], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $pr = explode('/', $achou['fsp']); // usa o F/S/P REAL do autofind
        if (count($pr) === 3) { $slot = (int)$pr[1]; $port = (int)$pr[2]; }
        $ifCmd = "interface gpon 0/$slot"; // V800R018: placas GPON desta OLT

        // SESSAO 1: confirma no F/S/P real + re-consulta autofind na MESMA sessao.
        $cmdConfirm = "ont confirm $port sn-auth $sn omci ont-lineprofile-id $lp ont-srvprofile-id $sp desc \"$desc\"";
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', $ifCmd, $cmdConfirm, 'quit', 'display ont autofind all', 'quit'], $olt_timeout);
        $rawConfirm  = $out[3] ?? '';
        $rawAutofind = $out[5] ?? '';
        // ONT-ID: EN "ONTID :11" / PT "ID da ONT : 11" (sem códigos de tela). Sem ele a ONU NÃO entrava
        // na lista na hora (só na varredura seguinte = "demorou demais") e o service-port não era criado.
        $rcLimpo = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', (string)$rawConfirm);
        $ontId = preg_match('/(?:ONT\s*-?\s*ID|ID\s+da\s+ONT)\s*(?:is|:|=)?\s*(\d+)/i', $rcLimpo, $mo) ? (int)$mo[1] : null;
        $confirmOk = (bool)preg_match('/(?:success|sucesso)\s*[:=]\s*1|(?:ONT\s*-?\s*ID|ID\s+da\s+ONT)\s*[:=]/i', $rcLimpo);

        // RE-CHECAGEM (enxuto): a OLT leva um instante pra tirar o SN do autofind. Basta 1 releitura
        // (0.8s) — cortamos as 3 sessões antigas p/ segurar MUITO menos a OLT (menos VTY ocupada,
        // menos "Placa não respondeu"). Se ainda constar pendente, marcamos como confirmado quando o
        // "ont confirm" retornou OK (o autofind às vezes demora a limpar, mas a ONT já subiu).
        $aindaPend = $snPendente($rawAutofind);
        $tent = 0;
        // RESERVA: confirm OK mas o ONT-ID não veio legível -> pergunta à OLT pelo SN (1 comando).
        if ($confirmOk && $ontId === null) {
            try {
                $oB = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', "display ont info by-sn $sn"], $olt_timeout);
                $rB = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', (string)($oB[2] ?? ''));
                if (preg_match('/(?:ONT\s*-?\s*ID|ID\s+da\s+ONT)\s*:?\s*(\d+)/i', $rB, $mb)) $ontId = (int)$mb[1];
                if (preg_match('#F\s*/\s*S\s*/\s*P\s*:?\s*(\d+)\s*/\s*(\d+)\s*/\s*(\d+)#i', $rB, $mf)) { $slot = (int)$mf[2]; $port = (int)$mf[3]; $ifCmd = "interface gpon 0/$slot"; }
            } catch (Exception $e) {}
        }
        if ($aindaPend) {
            usleep(800000);
            $outV = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', 'display ont autofind all', 'quit'], $olt_timeout);
            $rawAutofind = $outV[2] ?? '';
            $aindaPend = $snPendente($rawAutofind);
            $tent = 1;
        }
        // Confirmado se o "ont confirm" deu OK e (saiu do autofind OU já temos o ONT-ID atribuído).
        $autorizada = $confirmOk && (!$aindaPend || $ontId !== null);

        // SESSÃO ÚNICA (enxuto): cria o service-port + grava a descrição no formato SmartOLT +
        // verifica o que ficou gravado — TUDO num login só (antes eram 2-3 logins). Segura a OLT
        // bem menos tempo -> menos VTY ocupada. A ordem respeita o contexto: service-port em config,
        // ont-desc/verify dentro do "interface gpon".
        //   COMPATIBILIDADE SmartOLT: descrição = NOME_zone_ZONA_descr_NOME_lat_0_long_0_authd_ANO
        //   (o SmartOLT lê a zona daí, sem resync). É best-effort: se o ont-desc falhar, a ONU já está
        //   autorizada e com service-port — não quebra nada.
        $rawSp = ''; $srvAplicado = ''; $tipoAplicado = ''; $rawVerif = ''; $spFalhou = false;
        if ($autorizada && $ontId !== null) {
            usleep(400000);
            // A descrição JÁ foi gravada no formato completo pelo "ont confirm". Aqui só cria o
            // service-port e verifica (sem o "ont modify ont-desc", que caía com a congestão).
            // SERVICE-PORT com o GEM do line-profile aplicado ($lp) + native-vlan em bridge — tudo em
            // olt_sp_criar(): antes era "gemport 1" fixo, e a falha da OLT passava em silêncio.
            if ($vlan > 0) {
                $spRes = olt_sp_criar($olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout, $slot, $port, $ontId, $vlan, $lp, true);   // native-vlan na LAN 1 SEMPRE — igual com perfil automático, escolhido ou em branco, Bridge ou Router (comprovado em produção: Bridge MAX1000 e Router ONT-MAX). NÃO mudar sem testar Router e Bridge.
                $rawSp = $spRes['saida'];
                if (!$spRes['ok']) $spFalhou = true;
            }
            $outVf = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', $ifCmd, "display ont info $port $ontId"], $olt_timeout);
            $rawVerif = end($outVf);                         // última saída = "display ont info"
            if (preg_match('/(?:Service[\s\-]*profile[\s\-]*name|Nome\s+do\s+perfil\s+de\s+servi\S*)\s*:\s*([^\r\n]+)/i', $rawVerif, $mv)) $srvAplicado = trim($mv[1]);
            // leitura robusta (sem códigos de tela) e, se nem assim, o perfil que o "ont confirm" GRAVOU ($sp)
            if ($srvAplicado === '') { $dV = parse_ont_detalhe((string)$rawVerif); $srvAplicado = (string)($dV['srvprofile'] ?? ''); }
            if ($srvAplicado === '' || strpos($srvAplicado, 'ID ') === 0) { $nmSp = olt_perfil_nome_por_id('srv', $sp); if (strpos($nmSp, 'ID ') !== 0) $srvAplicado = $nmSp; }
            $tipoAplicado = olt_srv_tipo($srvAplicado);
        }

        // GRAVA as informacoes reais do provisionamento (persistencia por SN)
        if ($autorizada) {
            $af = olt_cache_dir() . '/olt_autorizacoes.json';
            $reg = is_file($af) ? json_decode(@file_get_contents($af), true) : [];
            if (!is_array($reg)) $reg = [];
            $reg[sn_norm($sn)] = [
                'sn' => $sn, 'fsp' => "0/$slot/$port", 'ont_id' => $ontId, 'nome' => $nome,
                'vlan' => $vlan, 'lineprofile' => $lp, 'srvprofile' => $sp,
                'srv_aplicado' => $srvAplicado,
                'bairro' => $bairro, 'rua' => $rua, 'cidade' => $cidade, 'numero' => $numero,
                'zona' => $zona, 'tecnologia' => $tec, 'modo' => $modo,
                'tipo' => ($tipoAplicado !== '' ? $tipoAplicado : ($modo === 'router' ? 'ONT' : 'ONU')),
                'data' => date('Y-m-d H:i:s'),
            ];
            $jreg = json_encode($reg, JSON_UNESCAPED_UNICODE);
            foreach (olt_cache_dirs() as $dd) { if (!is_dir($dd)) @mkdir($dd, 0777, true); if (@file_put_contents($dd . '/olt_autorizacoes.json', $jreg) !== false) @chmod($dd . '/olt_autorizacoes.json', 0666); }  // dual-cache
            olt_log_registrar('aprovisionamento', $sn . ' — ' . $nome . ' (VLAN ' . $vlan . ')', "0/$slot/$port");
            /* EQUIPAMENTO REAPROVEITADO (07/10/2026): o NOME/ZONA/TIPO do NOVO dono vão para o cadastro por serial
             * (olt_cadastro.json — o que a lista mostra primeiro) AQUI NO SERVIDOR. Antes só a TELA gravava isso,
             * depois da resposta da OLT: se a autorização demorava (OLT lenta, ~2,5 min) e a aba saía da tela da OLT,
             * a gravação não acontecia e o nome do dono ANTERIOR continuava aparecendo. O registro antigo do serial
             * (nos 2 formatos: hex e fabricante) é substituído — dados do dono anterior não ficam. Best-effort: a
             * autorização na OLT já está feita; se a trava não vier a tempo, a tela ainda grava como antes. */
            try {
                $lockCadA = olt_json_lock('olt_cadastro');
                if ($lockCadA !== null) {
                    $cadA = olt_jcache_load('olt_cadastro.json'); if (!is_array($cadA)) $cadA = [];
                    $hxA = strtoupper((string)sn_para_hex($sn)); if ($hxA === '') $hxA = strtoupper($sn);
                    $antA = [];
                    foreach (array_keys($cadA) as $kA) { if (strtoupper((string)sn_para_hex($kA)) === $hxA) { if (is_array($cadA[$kA])) $antA = array_merge($antA, $cadA[$kA]); unset($cadA[$kA]); } }   // tira as 2 grafias do serial
                    $mesmoDono = isset($antA['nome']) && mb_strtoupper(trim((string)$antA['nome'])) === mb_strtoupper(trim($nome));
                    // mesmo cliente reautorizado: mantém as anotações dele; outro cliente: registro novo (nada do anterior)
                    $novoA = array_merge($mesmoDono ? $antA : [], ['nome' => $nome, 'tipo' => ($tipoAplicado !== '' ? $tipoAplicado : ($modo === 'router' ? 'ONT' : 'ONU'))]);
                    if ($zona !== '') $novoA['zona'] = $zona;
                    $cadA[$hxA] = $novoA;
                    $jA = json_encode($cadA, JSON_UNESCAPED_UNICODE);
                    if ($jA !== false) foreach (olt_cache_dirs() as $dA) { if (!is_dir($dA)) @mkdir($dA, 0777, true); if (@file_put_contents($dA . '/olt_cadastro.json', $jA) !== false) @chmod($dA . '/olt_cadastro.json', 0666); }
                    olt_json_unlock($lockCadA);
                }
            } catch (Throwable $e) { if (isset($lockCadA) && $lockCadA) olt_json_unlock($lockCadA); }
            /* A ONU APROVISIONADA ENTRA NA LISTA AGORA.
             * Antes ela só aparecia na próxima varredura completa do cron (10 min). Aqui ela entra no
             * cache da lista com o que já se sabe (F/S/P, ONT-ID, serial, nome, VLAN, estado lido no
             * "display ont info" da verificação) e a placa é marcada para revarredura: no minuto
             * seguinte o cron lê a placa e completa sinal, modelo e o resto. */
            if ($ontId !== null) {
                try {
                    $fspN = "0/$slot/$port";
                    $stN  = 'online';
                    if (preg_match('/(?:Run\s*state|Estado\s+de\s+execu\S*)\s*:\s*(online|offline)/i', (string)$rawVerif, $mrs)) $stN = strtolower($mrs[1]);
                    $serN = strtoupper(sn_para_hex($sn)) ?: $sn;
                    $novaOnu = ['serial' => $serN, 'status' => $stN, 'estado' => $stN, 'nome' => $nome, 'zona' => $zonaC,
                                'vlan' => ($vlan > 0 ? (string)$vlan : ''), 'modelo' => '', 'rx' => '', 'tx' => '', 'dist' => '', 'uptime' => '',
                                'id' => (string)$ontId, 'fsp' => $fspN, 'srv' => $srvAplicado];
                    // TRAVA + releitura NA HORA (olt_json_lock): sem isso, se o cron_scan estivesse
                    // no meio da varredura desta mesma placa, um dos dois (autorizar ou cron)
                    // sobrescrevia o outro e a ONU recém-autorizada "sumia" da lista até o próximo
                    // ciclo — o sintoma de "preciso excluir e reaprovisionar várias vezes".
                    $lockOnu = olt_json_lock('olt_onus_cache');
                    $cL = olt_cache_load();
                    if (!isset($cL['slots']) || !is_array($cL['slots'])) $cL['slots'] = [];
                    $lsL = array_values(array_filter((array)($cL['slots'][(string)$slot] ?? []), function ($o) use ($fspN, $ontId, $serN) {
                        return !((($o['fsp'] ?? '') === $fspN && (string)($o['id'] ?? '') === (string)$ontId)
                                 || strtoupper(sn_para_hex($o['serial'] ?? '')) === $serN);
                    }));
                    $lsL[] = $novaOnu;
                    $cL['slots'][(string)$slot] = $lsL;
                    if (empty($cL['ts'])) $cL['ts'] = time();
                    olt_cache_save($cL, $lockOnu);
                    olt_json_unlock($lockOnu);
                    olt_rescan_marcar((int)$slot);
                } catch (Throwable $e) {}
            }
            // #5: tira a ONU do CACHE do autofind AGORA -> ela some do card na hora e NÃO volta.
            $afc = olt_jcache_load('olt_autofind.json');
            if (isset($afc['pendentes']) && is_array($afc['pendentes'])) {
                $afc['pendentes'] = array_values(array_filter($afc['pendentes'], function ($p) use ($sn) { return sn_norm($p['sn'] ?? '') !== sn_norm($sn); }));
                olt_jcache_save('olt_autofind.json', $afc);
            }
        }

        // ==== REDUNDÂNCIA SmartOLT: registra a ONU na API do SmartOLT com o TIPO/MODO/ZONA certos ====
        // (o modo/zona no SmartOLT vêm do onu_type + zone daqui — não da OLT). Best-effort: se o SmartOLT
        // estiver fora ou falhar, a ONU JÁ está provisionada na OLT (o app é independente).
        $stResult = null;
        if ($autorizada) {
            $stType = trim($_POST['st_onu_type'] ?? $_GET['st_onu_type'] ?? '');
            $stMode = trim($_POST['st_mode'] ?? $_GET['st_mode'] ?? '');
            if ($stType !== '') {
                $oltId = smartolt_olt_id();
                if ($oltId !== '') {
                    $stp = ['olt_id' => $oltId, 'pon_type' => 'gpon', 'board' => $slot, 'port' => $port, 'sn' => $sn,
                            'onu_type' => $stType, 'onu_mode' => ($stMode !== '' ? $stMode : 'Bridging'),
                            'zone' => $zona, 'name' => $nome, 'vlan' => $vlan];
                    if ($zona === '') unset($stp['zone']);
                    // ENDEREÇO/COMENTÁRIO SEMPRE: sem ele o SmartOLT reaproveitava o endereço ANTIGO guardado para
                    // esse serial (equipamento reutilizado) e gravava na descrição da ONU. Vai o endereço
                    // informado; sem endereço, a zona escolhida agora.
                    $endAp = trim(preg_replace('/\s+/', ' ', $rua . ' ' . $numero . ' ' . $bairro . ' ' . $cidade));
                    $stp['address_or_comment'] = $endAp !== '' ? $endAp : $zona;
                    $rr = smartolt_api_post($smartolt_url, $smartolt_token, 'onu/authorize_onu', $stp);
                    $jj = json_decode($rr['body'], true);
                    $stResult = ['http' => $rr['http'], 'ok' => (is_array($jj) && (($jj['response_code'] ?? '') === 'success')),
                                 'resp' => (is_array($jj) ? ($jj['response'] ?? $jj) : substr((string)$rr['body'], 0, 300)),
                                 'onu_type' => $stType, 'onu_mode' => ($stMode !== '' ? $stMode : 'Bridging')];
                }
            }
        }

        // ==== AVISO DE VLAN/SERVICE-PORT: sem VLAN > 0 aqui em cima, NENHUM service-port é criado —
        // a ONU fica registrada na OLT (camada de gerência/OMCI) mas SEM CAMINHO DE DADOS até o
        // concentrador. É o caso clássico de "autorizei, aparece OK na OLT, mas o cliente não
        // conecta": PPPoE/DHCP nunca chegam no concentrador porque não há service-port nenhum
        // carregando o tráfego dessa ONU pra rede. Diferente do fluxo via SmartOLT (que sempre
        // grava o service-port), aqui o VLAN é digitado manualmente e pode passar em branco.
        $vlanAviso = null;
        if ($autorizada && $vlan <= 0) {
            $vlanAviso = 'Nenhuma VLAN foi informada — o service-port NÃO foi criado na OLT. A ONU está '
                . 'registrada (aparece "autorizada"), mas SEM caminho de dados até o concentrador: o cliente '
                . 'não vai conectar mesmo com contrato ativo. Informe a VLAN correta e reautorize (ou peça pro '
                . 'suporte rodar o "service-port vlan ... ont ' . ($ontId ?? '?') . '" manualmente).';
        } elseif ($autorizada && $spFalhou) {
            $vlanAviso = 'A OLT RECUSOU o service-port da VLAN ' . $vlan . ' (nenhum GEM do line-profile aceitou). '
                . 'A ONU fica online, mas o cliente NÃO navega. Use "Criar service-port" / "Trocar VLAN" na ficha '
                . 'ou confira o line-profile. Saída da OLT abaixo.';
        }

        // ==== AVISO DE RADIUS: "autorizar" aqui SÓ mexe na OLT (service-port óptico) — nunca cria
        // nem confirma o login PPPoE/IPoE no RADIUS (isso vem do CONTRATO, em radius_lib.php). Uma
        // ONU podia sair "autorizada" na tela sem que exista credencial nenhuma pra ela autenticar
        // no concentrador — ficava com sinal e sem internet, e nada aparecia no log do concentrador
        // porque não havia login nenhum tentando logar. Aqui verificamos e avisamos, em vez de deixar
        // o operador achar que "autorizado" = "vai conectar". Best-effort: se a checagem falhar
        // (banco fora, tabela diferente), a autorização na OLT já aconteceu — não bloqueia nada.
        $radiusAviso = null; $equipCt = null;
        if ($autorizada) {
            try {
                $db = function_exists('ws_db') ? ws_db() : null;
                $loginPppoe = null; $statusContrato = null; $loginIpoe = '';
                if ($db) {
                    // SN nos DOIS formatos (hex 4750...A3C858 e fabricante GPON00A3C858) e sem ':'/'-': o
                    // contrato pode ter sido gravado em qualquer um — antes só o formato exato casava e o
                    // aviso dizia "não existe contrato" à toa. Prefere contrato não cancelado, mais recente.
                    $snHex = strtoupper(sn_para_hex($sn)); $snVend = $snHex;
                    if (preg_match('/^([0-9A-F]{8})([0-9A-F]{8})$/', $snHex, $mh)) { $pf = @hex2bin($mh[1]); if ($pf !== false && preg_match('/^[A-Z0-9]{4}$/', $pf)) $snVend = $pf . $mh[2]; }
                    $stmt = $db->prepare("SELECT id, login_pppoe, login_ipoe, tipo_conexao, status FROM ws_contrato
                        WHERE UPPER(REPLACE(REPLACE(COALESCE(sn_onu,''),':',''),'-','')) IN (?, ?, ?)
                        ORDER BY (COALESCE(status,'') = 'cancelado') ASC, id DESC LIMIT 1");
                    $stmt->execute([strtoupper($sn), $snHex, $snVend]);
                    $ctr = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($ctr) { $loginPppoe = trim((string)($ctr['login_pppoe'] ?? '')); $loginIpoe = trim((string)($ctr['login_ipoe'] ?? '')); $statusContrato = $ctr['status'] ?? null; }
                    // (03/10/2026) EQUIPAMENTO NO CONTRATO NA HORA: ONT = Router, ONU = Bridge (o perfil que a OLT aplicou), comodato Sim
                    if ($ctr && function_exists('ws_equip_auto')) {
                        $modoCt = ($tipoAplicado ?: (($modo ?? '') === 'router' ? 'ONT' : 'ONU')) === 'ONT' ? 'ONT (Router)' : 'ONU (Bridge)';
                        ws_equip_auto($db, (int)$ctr['id'], $modoCt);
                        $equipCt = ['contrato_id' => (int)$ctr['id'], 'modo' => $modoCt, 'perguntar_roteador' => $modoCt === 'ONU (Bridge)'];
                    }
                    // Cliente PPPoE OU IPoE. IPoE: login = senha = o próprio ID (login_ipoe). PPPoE: login_pppoe.
                    if ($ctr && strtolower((string)($ctr['tipo_conexao'] ?? '')) === 'ipoe' && $loginIpoe !== '') $loginPppoe = $loginIpoe;
                    elseif ($loginPppoe === '' && $loginIpoe !== '') $loginPppoe = $loginIpoe;
                }
                if ($loginPppoe === null) {
                    $radiusAviso = 'Não existe contrato com este SN (sn_onu) no WellSystem — a ONU foi autorizada na OLT, mas '
                        . 'sem contrato não há login PPPoE/IPoE no RADIUS, e ela não vai autenticar no concentrador.';
                } elseif ($loginPppoe === '') {
                    $radiusAviso = 'O contrato deste SN existe mas está sem login (PPPoE nem IPoE) — confirme o cadastro do contrato/plano.';
                } else {
                    $radMy = olt_radius_db();
                    $temRadcheck = false;
                    if ($radMy) {
                        $lq = mysqli_real_escape_string($radMy, $loginPppoe);
                        $rs = @mysqli_query($radMy, "SELECT 1 FROM radcheck WHERE username='$lq' LIMIT 1");
                        $temRadcheck = ($rs && mysqli_num_rows($rs) > 0);
                        // o login IPoE do contrato também vale (cliente IPoE autentica por ele)
                        if (!$temRadcheck && $loginIpoe !== '' && $loginIpoe !== $loginPppoe) {
                            $li = mysqli_real_escape_string($radMy, $loginIpoe);
                            $rs = @mysqli_query($radMy, "SELECT 1 FROM radcheck WHERE username='$li' LIMIT 1");
                            $temRadcheck = ($rs && mysqli_num_rows($rs) > 0);
                        }
                    }
                    if (!$temRadcheck) {
                        $radiusAviso = 'O contrato tem login_pppoe (' . $loginPppoe . ') mas não há credencial correspondente em radcheck — '
                            . 'o RADIUS não vai autenticar esta ONU. Verifique a sincronização do contrato com o RADIUS.';
                    } elseif ($statusContrato !== null && $statusContrato !== 'ativo') {
                        $radiusAviso = 'O contrato deste SN está com status "' . $statusContrato . '" (não "ativo") — o RADIUS pode recusar a autenticação.';
                    }
                }
            } catch (Throwable $e) { /* best-effort: checagem falhou, não impede a resposta da autorização na OLT */ }
        }

        $raw = trim($rawConfirm
                    . "\n\n--- re-consulta autofind (tentativas: " . ($tent + 1) . ", SN ainda pendente? " . ($aindaPend ? 'SIM' : 'NAO') . ") ---\n" . $rawAutofind
                    . ($rawSp !== '' ? "\n\n--- service-port (VLAN $vlan) ---\n" . $rawSp : '')
                    . ($rawVerif !== '' ? "\n\n--- verificacao (srv-profile aplicado) ---\n" . $rawVerif : ''));
        echo json_encode(['status' => 'ok', 'sucesso' => $autorizada, 'ainda_pendente' => $aindaPend,
                          'ont_id' => $ontId, 'tentativas' => $tent + 1,
                          'modo_escolhido' => $modo, 'srv_id' => $sp,
                          'srv_aplicado' => $srvAplicado, 'tipo_aplicado' => $tipoAplicado,
                          'smartolt' => $stResult, 'radius_aviso' => $radiusAviso, 'vlan_aviso' => $vlanAviso, 'equip' => $equipCt,
                          'sp_ok' => isset($spRes) ? $spRes['ok'] : null, 'sp_gem' => isset($spRes) ? $spRes['gem'] : null,
                          'comando' => $cmdConfirm, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- ESTADO REAL das OFFLINE (LOS x Desativada x Offline) via Telnet ---
    // Recebe POST itens=[{fsp,id},...] (so as offline) e consulta a causa de
    // queda de cada uma numa unica sessao. Fonte 100% Telnet (regra #7).
    if ($acao === 'estado_offline') {
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '[]', true);
        if (!is_array($itens)) $itens = [];
        $itens = array_slice($itens, 0, 120); // trava de seguranca
        $porSlot = [];
        foreach ($itens as $it) {
            $p = explode('/', preg_replace('/[^0-9\/]/', '', $it['fsp'] ?? ''));
            if (count($p) !== 3) continue;
            $porSlot[(int)$p[1]][] = ['port' => (int)$p[2], 'id' => (int)($it['id'] ?? -1), 'fsp' => $p[0] . '/' . $p[1] . '/' . $p[2]];
        }
        $comandos = ['enable', 'config']; $mapa = [];
        foreach ($porSlot as $slot => $lst) {
            $comandos[] = "interface gpon 0/$slot";
            foreach ($lst as $x) { $comandos[] = "display ont info {$x['port']} {$x['id']}"; $mapa[count($comandos) - 1] = $x['fsp'] . '|' . $x['id']; }
            $comandos[] = 'quit';
        }
        $res = [];
        if (!empty($mapa)) {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $comandos, $olt_timeout);
            foreach ($mapa as $idx => $chave) {
                $raw = $out[$idx] ?? '';
                $causa = preg_match('/(?:causa de inatividade|causa da queda|causa\s+de\s+falha|down\s*cause|Last\s+down\s+cause)[^:\n]*:\s*([^\r\n]+)/i', $raw, $mc) ? trim($mc[1]) : '';
                $causaLimpa = strtolower(trim($causa));
                // Classificacao pela CAUSA DE QUEDA (o que distingue de verdade):
                //   LOS -> los ; DESATIVADA = só com "Control flag: deactive" (29/10/2026: sem causa de queda NÃO é desativada — ONU ativa que nunca conectou é OFFLINE) ;
                //   dying-gasp / power-off / demais -> offline (cliente desligou).
                $est = 'offline';
                if     (preg_match('/\bLOS[i]?\b|loss\s*of\s*signal|sinal.*perd|perda.*sinal/i', $causa)) $est = 'los';
                elseif (preg_match('/(?:Control\s*flag|Flag\s+de\s+controle)\s*:\s*(?:deactive|desativ)/i', $raw)) $est = 'deactivated';
                $res[$chave] = ['estado' => $est, 'causa' => $causa];
            }
        }
        // grava o estado apurado no cache -> proxima abertura ja vem correto (instantaneo)
        if (!empty($res)) {
            $ec = olt_estado_cache_load();
            foreach ($res as $k => $v) { $ec[$k] = $v['estado']; }
            // ONUs que voltaram a ficar ONLINE saem do cache de estado (nao sao mais offline)
            olt_jcache_save('olt_estado_cache.json', $ec);
        }
        echo json_encode(['status' => 'ok', 'estados' => $res], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- VLANs REAIS DA OLT (para o seletor da autorizacao) ------------------
    // display vlan all -> [{id, nome}] (nome = descricao, se houver na OLT).
    if ($acao === 'vlans_olt') {
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', 'display vlan all', 'quit'], $olt_timeout);
        echo json_encode(['status' => 'ok', 'nomes' => parse_vlans_olt($out[2] ?? ''), 'saida' => $out[2] ?? ''], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DETECTA PLACAS GPON (display board 0) ------------------------------
    // Auto-reconhece as placas PON de cliente presentes na OLT. Cacheia em disco;
    // force=1 relê da OLT. O front usa isso pra não hardcodar os slots (1/3/5).
    if ($acao === 'placas_detect') {
        header('Content-Type: application/json; charset=utf-8');
        $cacheF = olt_cache_dir() . '/olt_placas.json';
        $force  = !empty($_GET['force']);
        if (!$force && is_file($cacheF)) {
            $c = json_decode(@file_get_contents($cacheF), true);
            if (is_array($c) && !empty($c)) { echo json_encode(['status' => 'ok', 'placas' => $c, 'cache' => true], JSON_UNESCAPED_UNICODE); exit; }
        }
        $b = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
        $placas = parse_board_all($b);   // TODAS as placas (GPON, controle SCU, uplink X2CS...)
        if (!empty($placas)) { @file_put_contents($cacheF, json_encode($placas, JSON_UNESCAPED_UNICODE)); @chmod($cacheF, 0666); }
        echo json_encode(['status' => 'ok', 'placas' => $placas, 'saida' => (is_array($b) ? implode("\n", $b) : (string)$b)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- UPLINK: lista as portas ethernet de uplink + as VLANs de cada uma ----
    // Descobre as placas NÃO-GPON (SCU/X2CS) e lê "display port vlan 0/s/p" por porta.
    // Devolve o bruto junto pra acertar o parser se o firmware variar.
    if ($acao === 'uplink_listar') {
        header('Content-Type: application/json; charset=utf-8');
        // A página abre SEMPRE do cache (qualquer idade) com o STATUS/velocidade/admin ao vivo por
        // SNMP (rápido, não depende do Telnet). Só relê por Telnet na 1ª vez (sem cache) ou com force=1.
        // O cron aquece esse cache em 2º plano (olt_monitor.sh), então quase nunca cai no Telnet aqui.
        $cacheF = olt_cache_dir() . '/olt_uplink.json';
        if (empty($_GET['force']) && is_file($cacheF)) {
            $c = json_decode(@file_get_contents($cacheF), true);
            if (is_array($c) && !empty($c['portas'])) {
                $pp = olt_uplink_snmp_overlay($c['portas']);   // status/vel/admin AO VIVO por SNMP
                echo json_encode(['status' => 'ok', 'portas' => $pp, 'placas' => (array)($c['placas'] ?? []), 'cache' => true, 'idade' => time() - (int)($c['ts'] ?? 0)], JSON_UNESCAPED_UNICODE); exit;
            }
        }
        $b = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
        $placas = parse_board_all($b);
        // 1 sessão: VLANs (config) + "display board 0/<slot>" por placa de uplink (status/vel/duplex/link REAIS).
        /* 30/10/2026 (caso placas de uplink): a leitura da configuração (381 linhas, lenta) ia ANTES dos "display board" e deslocava as saídas — a placa 0/9 sumia e as portas da 0/6 apareciam como 0/8
           (uma placa só, com as outras "DOWN"). Agora os "display board" (curtos) vão primeiro, a configuração por último, e cada saída é ligada à sua placa pelo ECO do comando (não pela posição). */
        $cmds = ['enable']; $mapB = array();
        foreach ($placas as $p) { if (!empty($p['gpon'])) continue; $slot = (int)$p['slot']; $cmds[] = "display board 0/$slot"; $mapB[count($cmds) - 1] = array('slot' => $slot, 'tipo' => $p['tipo']); }
        $cmds[] = 'display current-configuration | include port vlan'; $idxCfg = count($cmds) - 1;
        $cmds[] = 'quit';
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        $porEco = array();
        foreach ((array)$out as $kO => $tO) {
            $cab = preg_replace('/\s+/', '', substr((string)$tO, 0, 160));
            if (preg_match('/board0\/(\d+)/i', $cab, $mmE)) $porEco[(int)$mmE[1]] = (string)$tO;
            elseif (stripos($cab, 'current-configuration') !== false && stripos($cab, 'portvlan') !== false) $porEco['cfg'] = (string)$tO;
        }
        if (isset($porEco['cfg'])) $out[$idxCfg] = $porEco['cfg'];
        if ($porEco) foreach ($mapB as $iB => $mB) $out[$iB] = $porEco[$mB['slot']] ?? '';   // sem eco da placa = sem dado (nunca o de outra placa)
        $compacta = function ($ints) { sort($ints); $ints = array_values(array_unique($ints)); $r = array(); $n = count($ints); $i = 0;
            while ($i < $n) { $s = $ints[$i]; $e = $s; while ($i + 1 < $n && $ints[$i + 1] == $e + 1) { $i++; $e = $ints[$i]; } $r[] = ($s == $e) ? (string)$s : ($s . '-' . $e); $i++; } return $r; };
        $vlansDe = array();
        foreach (explode("\n", (string)($out[$idxCfg] ?? '')) as $ln) {
            if (preg_match('/port\s+vlan\s+(.+?)\s+0\/(\d+)\s+(\d+)\s*$/i', trim($ln), $m)) {
                $key = '0/' . $m[2] . '/' . $m[3]; $lista = str_ireplace(array(' to ', '-'), ' - ', trim($m[1]));
                $toks = preg_split('/\s*,\s*|\s+/', trim($lista)); $i2 = 0; $arr = array();
                while ($i2 < count($toks)) {
                    if (isset($toks[$i2 + 1]) && $toks[$i2 + 1] === '-' && isset($toks[$i2 + 2])) { $a = (int)$toks[$i2]; $bb = (int)$toks[$i2 + 2]; for ($x = $a; $x <= $bb && $x <= 4094; $x++) if ($x >= 1) $arr[] = $x; $i2 += 3; }
                    elseif (preg_match('/^\d+$/', $toks[$i2])) { $v = (int)$toks[$i2]; if ($v >= 1 && $v <= 4094) $arr[] = $v; $i2++; } else $i2++;
                }
                if ($arr) { if (!isset($vlansDe[$key])) $vlansDe[$key] = array(); $vlansDe[$key] = array_merge($vlansDe[$key], $arr); }
            }
        }
        // Parse REAL de "display board 0/<slot>": tabela Port|Type|Optic|VLAN|MDI|Speed|Duplex|Flow|Active|Link
        $portas = array();
        foreach ($mapB as $idx => $meta) {
            $raw = (string)($out[$idx] ?? ''); $slot = $meta['slot']; $tipo = $meta['tipo'];
            foreach (explode("\n", $raw) as $ln) {
                $ln = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $ln);   // remove [37D
                if (preg_match('/^\s*(\d+)\s+(\d*GE)\s+(\w+)\s+\d+\s+\S+\s+(\S+)\s+(\S+)\s+\S+\s+(\w+)\s+(\w+)/', $ln, $m)) {
                    $pt = (int)$m[1]; $ty = strtoupper($m[2]); $optic = $m[3]; $speed = $m[4]; $duplex = $m[5]; $active = $m[6]; $link = $m[7];
                    $fsp = "0/$slot/$pt"; $up = (stripos($link, 'online') !== false);
                    $vel = ($ty === '10GE') ? '10G' : (($ty === 'GE') ? '1G' : $ty);
                    if (is_numeric($speed)) { $sp = (int)$speed; $vel = ($sp >= 10000 ? '10G' : ($sp >= 1000 ? '1G' : $sp . 'M')); }
                    $neg = (strcasecmp($speed, 'auto') === 0) ? 'Auto' : ('Forçado ' . (is_numeric($speed) ? ($vel . ' ' . $duplex) : $speed));
                    $portas[] = array('nome' => 'ethernet' . $fsp, 'fsp' => $fsp, 'tipo' => $tipo, 'ptype' => $ty, 'vel' => $vel,
                        'optic' => $optic, 'duplex' => $duplex, 'neg' => $neg, 'link' => ($up ? 'online' : 'offline'),
                        'status' => ($up ? ('UP · ' . $vel) : 'Down'), 'admin' => (strcasecmp($active, 'active') === 0 ? 'Habilitado' : 'Desabilitado'),
                        'vlans' => isset($vlansDe[$fsp]) ? $compacta($vlansDe[$fsp]) : array());
                }
            }
        }
        $placasUp = array();   // 30/10/2026: placas de uplink/controle (slot, tipo, estado) — a tela mostra o estado da PLACA (Normal / Active / Standby) junto das portas
        foreach ($placas as $pl) { if (!empty($pl['gpon'])) continue; $placasUp[] = array('slot' => (int)$pl['slot'], 'tipo' => (string)$pl['tipo'], 'estado' => (string)($pl['estado'] ?? ''), 'funcao' => (string)($pl['funcao'] ?? '')); }
        if (!empty($portas)) { @file_put_contents($cacheF, json_encode(array('ts' => time(), 'portas' => $portas, 'placas' => $placasUp), JSON_UNESCAPED_UNICODE)); @chmod($cacheF, 0666); }
        echo json_encode(['status' => 'ok', 'portas' => $portas, 'placas' => $placasUp], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- VARRE TUDO: 1 comando só que roda TODOS os displays que faltam, e devolve o bruto.
    // Com isso eu monto de uma vez: Tx do GBIC PON (#1), Fan (#6), detalhe/potência das placas (#4),
    // negociação do uplink (#3) e versão. Sem ficar pedindo comando um por vez.
    if ($acao === 'olt_descobrir') {
        header('Content-Type: application/json; charset=utf-8');
        // Foco no que EXISTE: display board 0/<slot> (tem óptica/velocidade/duplex/link por porta).
        // Saída INTEIRA (sem cortar) p/ montar os parsers certos.
        $cmds = ['enable', 'config',
            'display board 0/1',    // 2  GPON (óptica por porta PON)
            'display board 0/6',    // 3  SCU uplink (velocidade/duplex/link)
            'display board 0/8',    // 4  X2CS uplink 10G (porta 0/8/0 ativa)
            'quit', 'quit'];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        $g = function ($i) use ($out) { return substr((string)($out[$i] ?? ''), 0, 3000); };
        echo json_encode(['status' => 'ok',
            'board_pon_0_1' => $g(2), 'board_uplink_0_6' => $g(3), 'board_uplink_0_8' => $g(4)
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- CAÇA OID (SNMP): varre vários ramos Huawei e devolve os que têm dados (Tx PON / Fan) ----
    // Localizador de OID por VALOR: varre uma subárvore e devolve as linhas cujo valor inteiro
    // bate com um dos alvos. Uso: achar a coluna do Tx do GBIC PON pelo valor conhecido do SmartOLT
    // (ex.: porta com Tx 7.06 dBm -> procurar 706 [x100] ou 71 [x10]). ?vals=706,485,503 &base=OID
    if ($acao === 'snmp_find') {
        header('Content-Type: application/json; charset=utf-8');
        $s = olt_snmp_cfg(); $host = trim((string)($_GET['host'] ?? '')) ?: $s['host']; $comm = trim((string)($_GET['comm'] ?? '')) ?: $s['comm']; $port = (int)($_GET['port'] ?? 0) ?: $s['port'];
        $base = trim((string)($_GET['base'] ?? '')) ?: '1.3.6.1.4.1.2011.6.128.1.1.2';   // subárvore óptica GPON
        $valsS = trim((string)($_GET['vals'] ?? '')) ?: '706,503,521,485,524,510,71,50,52,49';
        $alvos = array(); foreach (explode(',', $valsS) as $v) { $v = (int)trim($v); if ($v) $alvos[$v] = 1; }
        $bin = olt_snmp_bin('snmpbulkwalk'); if (!$bin) $bin = olt_snmp_bin('snmpwalk');
        $hits = array(); $tot = 0;
        if ($bin) {
            $raw = (string)@shell_exec($bin . ' -v2c -On -t 3 -r 1 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($base) . ' 2>/dev/null');
            foreach (explode("\n", $raw) as $ln) {
                $ln = trim($ln); if ($ln === '') continue; $tot++;
                if (preg_match('/^(\.?[0-9.]+)\s*=\s*\w*:?\s*(-?\d+)\s*$/', $ln, $m)) {
                    $val = (int)$m[2];
                    if (isset($alvos[$val]) && count($hits) < 60) $hits[] = array('oid' => $m[1], 'val' => $val);
                }
            }
        }
        echo json_encode(array('status' => 'ok', 'base' => $base, 'alvos' => array_keys($alvos), 'linhas_varridas' => $tot, 'achados' => $hits), JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- TESTE: acha o comando Telnet do Tx do GBIC PON (lado OLT) ----
    // Entra em "interface gpon 0/<slot>" e roda os candidatos de óptica por porta. Devolve o BRUTO
    // pra eu ver qual traz "TX power / RX power" e montar o parser certo. ?slot=1 (padrão).
    if ($acao === 'pon_tx_debug') {
        header('Content-Type: application/json; charset=utf-8');
        $slot = (int)($_GET['slot'] ?? 1);
        $cmds = ['enable', 'config', "interface gpon 0/$slot",
            'display port state 0',            // 3 — normalmente traz TX/RX power do módulo óptico da porta
            'display port state all',          // 4 — todas as portas do slot
            'display optical-info 0',          // 5 — variação de firmware
            'display port optical-info 0',     // 6 — outra variação
            'quit', 'quit', 'quit'];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        $g = function ($i) use ($out) { return substr((string)($out[$i] ?? ''), 0, 1500); };
        echo json_encode(['status' => 'ok', 'slot' => $slot,
            'a_port_state_0' => $g(3), 'b_port_state_all' => $g(4),
            'c_optical_info_0' => $g(5), 'd_port_optical_info_0' => $g(6)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($acao === 'snmp_hunt') {
        header('Content-Type: application/json; charset=utf-8');
        $s = olt_snmp_cfg(); $host = trim((string)($_GET['host'] ?? '')) ?: $s['host']; $comm = trim((string)($_GET['comm'] ?? '')) ?: $s['comm']; $port = (int)($_GET['port'] ?? 0) ?: $s['port'];
        $cands = array(
            // Óptica/GPON (OLT-side Tx por porta): candidatos
            'gpon_A' => '1.3.6.1.4.1.2011.6.128.1.1.2.22.1',
            'gpon_B' => '1.3.6.1.4.1.2011.6.128.1.1.2.23.1',
            'gpon_C' => '1.3.6.1.4.1.2011.6.128.1.1.2.46.1',
            // Fan (velocidade): candidatos
            'fan_A'  => '1.3.6.1.4.1.2011.6.3.4.2.1',
            'fan_B'  => '1.3.6.1.4.1.2011.6.3.9.1',
            'fan_C'  => '1.3.6.1.4.1.2011.6.7.1.1',
            // Sensores/entidade genéricos
            'sens_A' => '1.3.6.1.4.1.2011.6.3.3.2.1',
        );
        $bin = olt_snmp_bin('snmpbulkwalk'); if (!$bin) $bin = olt_snmp_bin('snmpwalk');
        $res = array();
        foreach ($cands as $nome => $oid) {
            $tot = 0; $amostra = array();
            if ($bin) {
                $raw = (string)@shell_exec($bin . ' -v2c -On -t 2 -r 0 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' 2>/dev/null');
                foreach (explode("\n", $raw) as $ln) { $ln = trim($ln); if ($ln === '' || stripos($ln, 'No Such') !== false || stripos($ln, 'No more') !== false) continue; $tot++; if (count($amostra) < 8) $amostra[] = substr($ln, 0, 90); }
            }
            $res[$nome] = array('oid' => $oid, 'total' => $tot, 'amostra' => $amostra);
        }
        echo json_encode(array('status' => 'ok', 'host' => $host, 'port' => $port, 'ramos' => $res), JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- POTÊNCIA Tx do GBIC/SFP de cada porta PON (display sfp-info 0/s/p) ----
    // Cacheado (olt_pon_sfp.json); force=1 relê. O cron atualiza junto do snmp_coletar.
    if ($acao === 'pon_sfp') {
        header('Content-Type: application/json; charset=utf-8');
        if (!empty($_GET['debug'])) {   // descobre QUAL comando traz a potência óptica da porta PON
            $o = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config',
                'display sfp-info 0/1/0', 'display port optical-info 0/1/0', 'display optical-module 0/1/0',
                'display gpon board optic 0/1', 'display board 0/1', 'quit', 'quit'], $olt_timeout);
            $g = function ($i) use ($o) { return substr((string)($o[$i] ?? ''), 0, 700); };
            echo json_encode(['a_sfp' => $g(2), 'b_optical' => $g(3), 'c_optmod' => $g(4), 'd_gponoptic' => $g(5), 'e_board' => $g(6)], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $cacheF = olt_cache_dir() . '/olt_pon_sfp.json';
        if (empty($_GET['force']) && is_file($cacheF)) {
            $c = json_decode(@file_get_contents($cacheF), true);
            if (is_array($c) && !empty($c)) { echo json_encode(['status' => 'ok', 'tx' => $c, 'cache' => true], JSON_UNESCAPED_UNICODE); exit; }
        }
        $tx = olt_pon_sfp_coletar();
        echo json_encode(['status' => 'ok', 'tx' => $tx], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- UPLINK DEBUG: saída CRUA dos comandos (pra montar o parser certo do firmware) ----
    if ($acao === 'uplink_raw') {
        header('Content-Type: application/json; charset=utf-8');
        $b = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display board 0', 'quit'], $olt_timeout);
        $placas = parse_board_all($b); $slot = null;
        foreach ($placas as $p) { if (empty($p['gpon'])) { $slot = (int)$p['slot']; break; } }   // 1ª placa não-GPON
        if ($slot === null) { echo json_encode(['status' => 'ok', 'msg' => 'nenhuma placa de uplink detectada', 'board' => (is_array($b) ? implode("\n", $b) : $b)]); exit; }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', "display port state 0/$slot", "display port vlan 0/$slot/0", "display port desc 0/$slot", 'quit', 'quit'], $olt_timeout);
        echo json_encode(['status' => 'ok', 'slot' => $slot,
            'port_state'  => substr($out[2] ?? '', 0, 1200),
            'port_vlan_0' => substr($out[3] ?? '', 0, 1200),
            'port_desc'   => substr($out[4] ?? '', 0, 1200)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- UPLINK: ativa/desativa uma porta (SNMP SET ifAdminStatus) — não usa Telnet ----
    if ($acao === 'uplink_estado') {
        header('Content-Type: application/json; charset=utf-8');
        $fsp = preg_replace('/[^0-9\/]/', '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $on  = (($_POST['on'] ?? $_GET['on'] ?? '1') === '1');
        $s = olt_snmp_cfg();
        if ($s['comm_rw'] === '') { echo json_encode(['ok' => false, 'msg' => 'Comunidade SNMP de ESCRITA não configurada (Conexão da OLT).']); exit; }
        $ifmap = olt_snmp_ifmap(); $ix = $ifmap[$fsp] ?? null;
        if ($ix === null) { echo json_encode(['ok' => false, 'msg' => 'porta sem ifIndex no SNMP']); exit; }
        $r = olt_snmp_set_int($s['host'], $s['port'], $s['comm_rw'], '1.3.6.1.2.1.2.2.1.7.' . $ix, $on ? 1 : 2);  // ifAdminStatus
        $ok = ($r === 'ok') || (stripos($r, 'Error') === false && stripos($r, 'fail') === false && $r !== '');
        @unlink(olt_cache_dir() . '/olt_uplink.json');   // força releitura do estado
        olt_log_registrar('uplink_estado', ($on ? 'Habilitou' : 'Desabilitou') . ' ethernet' . $fsp);
        echo json_encode(['ok' => $ok, 'saida' => substr((string)$r, 0, 200)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- PLACA: Ativa/Desativa TODAS as portas de uma placa via SNMP (ifAdminStatus) ----
    // Uniformiza a página de Placas: controle/uplink usam isto; GPON continua no controle de ONTs.
    if ($acao === 'placa_estado') {
        header('Content-Type: application/json; charset=utf-8');
        $slot = preg_replace('/[^0-9]/', '', $_POST['slot'] ?? $_GET['slot'] ?? '');
        $on   = (($_POST['on'] ?? $_GET['on'] ?? '1') === '1');
        $s = olt_snmp_cfg();
        if ($slot === '') { echo json_encode(['ok' => false, 'msg' => 'slot inválido']); exit; }
        if ($s['comm_rw'] === '') { echo json_encode(['ok' => false, 'msg' => 'Comunidade SNMP de ESCRITA não configurada (Conexão da OLT).']); exit; }
        $ifmap = olt_snmp_ifmap();
        $alvos = array();
        foreach ($ifmap as $fsp => $ix) { $pp = explode('/', $fsp); if (isset($pp[1]) && $pp[1] === $slot) $alvos[$fsp] = $ix; }
        if (!$alvos) { echo json_encode(['ok' => false, 'msg' => 'Nenhuma porta desta placa mapeada no SNMP.']); exit; }
        $okN = 0; $erN = 0;
        foreach ($alvos as $fsp => $ix) {
            $r = olt_snmp_set_int($s['host'], $s['port'], $s['comm_rw'], '1.3.6.1.2.1.2.2.1.7.' . $ix, $on ? 1 : 2);  // ifAdminStatus
            if (($r === 'ok') || (stripos($r, 'Error') === false && stripos($r, 'fail') === false && $r !== '')) $okN++; else $erN++;
        }
        @unlink(olt_cache_dir() . '/olt_uplink.json');
        olt_log_registrar('placa_estado', ($on ? 'Ativou' : 'Desativou') . ' placa ' . $slot . ' (' . $okN . ' portas)');
        echo json_encode(['ok' => ($okN > 0), 'portas' => $okN, 'erros' => $erN], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- UPLINK: adiciona/remove VLAN(s) numa porta de uplink (config REAL) ----
    if ($acao === 'uplink_vlan') {
        header('Content-Type: application/json; charset=utf-8');
        $fsp = preg_replace('/[^0-9\/]/', '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $opIn = (string)($_POST['op'] ?? $_GET['op'] ?? ''); $op = ($opIn === 'del') ? 'del' : 'add';
        $vlans = preg_replace('/[^0-9,\- ]/', '', $_POST['vlans'] ?? $_GET['vlans'] ?? '');
        $p = explode('/', $fsp); if (count($p) !== 3) { echo json_encode(['ok' => false, 'saida' => 'porta inválida']); exit; }
        $frameSlot = $p[0] . '/' . $p[1]; $port = (int)$p[2];
        $cmds = ['enable', 'config'];
        $expande = function (string $s): array { $r = array();
            foreach (preg_split('/\s*,\s*/', trim($s)) as $t) { $t = trim($t); if ($t === '') continue;
                if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $t, $mm)) { for ($x = (int)$mm[1]; $x <= (int)$mm[2] && $x <= 4094; $x++) if ($x >= 1) $r[$x] = 1; }
                elseif (preg_match('/^\d+$/', $t) && (int)$t >= 1 && (int)$t <= 4094) $r[(int)$t] = 1; }
            ksort($r); return array_keys($r); };
        $comprime = function (array $v): array { $r = array(); $n = count($v); $i = 0;
            while ($i < $n) { $s = $v[$i]; $e = $s; while ($i + 1 < $n && $v[$i + 1] == $e + 1) { $i++; $e = $v[$i]; } $r[] = ($s == $e) ? (string)$s : ($s . ' to ' . $e); $i++; } return $r; };
        if ($opIn === 'edit') {   // 30/10/2026: EDITAR — a lista da porta passa de "antes" para "vlans": adiciona só o que entrou e remove só o que saiu (o que continua não é tocado, sem cortar tráfego)
            $antes = $expande((string)preg_replace('/[^0-9,\- ]/', '', $_POST['antes'] ?? $_GET['antes'] ?? '')); $depois = $expande($vlans);
            $entram = array_values(array_diff($depois, $antes)); $saem = array_values(array_diff($antes, $depois));
            foreach ($comprime($entram) as $seg) $cmds[] = 'port vlan ' . $seg . ' ' . $frameSlot . ' ' . $port;   // primeiro entra a nova, depois sai a velha
            foreach ($comprime($saem) as $seg) $cmds[] = 'undo port vlan ' . $seg . ' ' . $frameSlot . ' ' . $port;
            if (count($cmds) === 2) { echo json_encode(['ok' => true, 'saida' => 'nada a alterar']); exit; }
            $vlans = 'de [' . implode(',', $antes ? array_map('strval', $antes) : array()) . '] para [' . implode(',', $depois) . ']'; $op = 'edit';
            if (strlen($vlans) > 300) $vlans = 'lista editada';
        } else
        foreach (preg_split('/\s*,\s*/', trim($vlans)) as $t) {
            $t = trim($t); if ($t === '') continue;
            if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $t, $mm)) $seg = $mm[1] . ' to ' . $mm[2];
            elseif (preg_match('/^\d+$/', $t)) $seg = $t; else continue;
            $cmds[] = ($op === 'del' ? 'undo ' : '') . 'port vlan ' . $seg . ' ' . $frameSlot . ' ' . $port;
        }
        $cmds[] = 'quit'; $cmds[] = 'quit';
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        $raw = is_array($out) ? implode("\n", $out) : (string)$out;
        $falhou = (bool)preg_match('/Failure|Error|invalid|Incomplete|Unknown/i', $raw);
        if (!$falhou) { @unlink(olt_cache_dir() . '/olt_uplink.json'); }   // VLAN mudou -> força releitura REAL
        olt_log_registrar('uplink_vlan', ($op === 'del' ? 'Removeu' : ($op === 'edit' ? 'Editou' : 'Adicionou')) . ' VLAN ' . $vlans . ' em ethernet' . $fsp);
        echo json_encode(['ok' => !$falhou, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- REINICIA UMA PLACA (reset board 0/<slot>) — controle/uplink/GPON ----
    if ($acao === 'placa_reset') {
        header('Content-Type: application/json; charset=utf-8');
        $slot = (int)($_POST['slot'] ?? $_GET['slot'] ?? -1);
        if ($slot < 0 || $slot > 20) { echo json_encode(['ok' => false, 'saida' => 'slot inválido']); exit; }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', "board reset 0/$slot", 'y', 'quit', 'quit'], $olt_timeout);
        $raw = is_array($out) ? implode("\n", $out) : (string)$out;
        $ok = !preg_match('/Failure|Unknown|invalid|Incomplete/i', $raw);
        olt_log_registrar('placa_reset', 'Reinício da placa 0/' . $slot);
        echo json_encode(['ok' => $ok, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- CRIA VLAN DE VERDADE NA OLT (vlan <id> smart) ----------------------
    // Provisiona a VLAN no equipamento (não-disruptivo). O NOME fica local (o app já
    // gerencia nomes de VLAN). Se a VLAN já existir, trata como sucesso.
    if ($acao === 'vlan_criar') {
        header('Content-Type: application/json; charset=utf-8');
        $vlan = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
        if (!olt_vlan_valida($vlan)) { echo json_encode(['status' => 'error', 'message' => 'VLAN inválida (use 1 a 4094).']); exit; }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', "vlan $vlan smart", 'quit'], $olt_timeout);
        $raw = is_array($out) ? implode("\n", $out) : (string)$out;
        // Sucesso: "success" OU já existia ("already exist"/"VLAN ... exists"). Falha real: "Failure"/"Error"
        $jaExiste = (bool)preg_match('/already\s+exist|already\s+been|exists/i', $raw);
        $falhou   = (bool)preg_match('/Failure|Error|invalid|Incomplete/i', $raw) && !$jaExiste;
        $ok = !$falhou;
        if ($ok) olt_log_registrar('vlan_criada', 'VLAN ' . $vlan . ' criada na OLT' . ($jaExiste ? ' (já existia)' : ''));
        echo json_encode(['status' => 'ok', 'criada' => $ok, 'ja_existia' => $jaExiste, 'vlan' => $vlan, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- EXCLUI VLAN DA OLT (undo vlan <id>) --------------------------------
    // ATENÇÃO: se a VLAN estiver em uso por service-port, a OLT recusa (retorna Failure) —
    // nesse caso nada é removido. Não força. O nome local é apagado só se a OLT confirmar.
    if ($acao === 'vlan_excluir') {
        header('Content-Type: application/json; charset=utf-8');
        $vlan = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
        if (!olt_vlan_valida($vlan)) { echo json_encode(['status' => 'error', 'message' => 'VLAN inválida.']); exit; }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', "undo vlan $vlan", 'quit'], $olt_timeout);
        $raw = is_array($out) ? implode("\n", $out) : (string)$out;
        $emUso  = (bool)preg_match('/service\s*virtual|in\s+use|being\s+used|service-port|Failure/i', $raw);
        $sumiu  = (bool)preg_match('/does\s+not\s+exist|not\s+exist|Unknown/i', $raw);
        $ok = (!$emUso) || $sumiu;   // sucesso se removeu ou se já não existia
        if ($ok) olt_log_registrar('vlan_excluida', 'VLAN ' . $vlan . ' removida da OLT');
        echo json_encode(['status' => 'ok', 'excluida' => $ok, 'em_uso' => ($emUso && !$sumiu), 'vlan' => $vlan, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- PERFIS REAIS DA OLT (para o filtro de escolha na autorizacao) -------
    // display ont-lineprofile gpon all / display ont-srvprofile gpon all -> [{id,nome}]
    if ($acao === 'perfis_olt') {
        // CACHE em disco: o Telnet as vezes atrasa/falha e retornava srv VAZIO -> o campo
        // "Perfil ONT-ONU" ficava sem equipamentos. Agora guarda o ultimo bom e serve ele
        // se a leitura nova vier vazia. force=1 ignora o cache.
        $cacheF = olt_cache_dir() . '/olt_perfis_olt.json';
        $cache  = is_file($cacheF) ? json_decode(@file_get_contents($cacheF), true) : null;
        $force  = !empty($_GET['force']);
        if (!$force && is_array($cache) && !empty($cache['srv'])) {
            // Serve o cache na hora (rápido). (A atualização real ocorre quando vier force=1.)
            echo json_encode(['status' => 'ok', 'line' => $cache['line'] ?? [], 'srv' => $cache['srv'] ?? [],
                              'cache' => true], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
            ['enable', 'config', 'display ont-lineprofile gpon all', 'display ont-srvprofile gpon all', 'quit'], $olt_timeout);
        $line = parse_perfis_olt($out[2] ?? '');
        $srv  = parse_perfis_olt($out[3] ?? '');
        if (!empty($srv)) { // só sobrescreve o cache quando a leitura trouxe algo
            if (!is_dir(olt_cache_dir())) @mkdir(olt_cache_dir(), 0775, true);
            @file_put_contents($cacheF, json_encode(['line' => $line, 'srv' => $srv], JSON_UNESCAPED_UNICODE));
        } elseif (is_array($cache) && !empty($cache['srv'])) { // leitura vazia -> devolve o último bom
            $line = $cache['line'] ?? []; $srv = $cache['srv'] ?? [];
        }
        echo json_encode(['status' => 'ok', 'line' => $line, 'srv' => $srv,
            'saida_line' => $out[2] ?? '', 'saida_srv' => $out[3] ?? ''], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- PERFIS de provisionamento (Generic_1..6 / personalizados) -----------
    // Cada perfil = {nome, lp (ont-lineprofile-id), sp (ont-srvprofile-id), modo}.
    // Guardado em cache_trafego/olt_perfis.json. NAO fala com a OLT.
    if ($acao === 'perfis_get' || $acao === 'perfis_add' || $acao === 'perfis_del') {
        $f = olt_cache_dir_g() . '/olt_perfis.json';
        $ps = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($ps)) $ps = [];
        if ($acao === 'perfis_add') {
            $nome = trim($_POST['nome'] ?? '');
            $lp   = (int)($_POST['lp'] ?? 0);
            $sp   = (int)($_POST['sp'] ?? 0);
            $modo = strtolower(trim($_POST['modo'] ?? ''));
            if ($nome !== '' && $lp > 0 && $sp > 0) {
                $achou = false;
                foreach ($ps as &$p0) { if (strcasecmp($p0['nome'] ?? '', $nome) === 0) { $p0 = ['nome' => $nome, 'lp' => $lp, 'sp' => $sp, 'modo' => $modo]; $achou = true; break; } }
                unset($p0);
                if (!$achou) $ps[] = ['nome' => $nome, 'lp' => $lp, 'sp' => $sp, 'modo' => $modo];
                @file_put_contents($f, json_encode($ps, JSON_UNESCAPED_UNICODE));
            }
        } elseif ($acao === 'perfis_del') {
            $nome = trim($_POST['nome'] ?? $_GET['nome'] ?? '');
            $ps = array_values(array_filter($ps, function ($p) use ($nome) { return strcasecmp($p['nome'] ?? '', $nome) !== 0; }));
            @file_put_contents($f, json_encode($ps, JSON_UNESCAPED_UNICODE));
        }
        echo json_encode(['status' => 'ok', 'perfis' => $ps], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- NOMES de VLAN (aprende o que o operador digita) ---------------------
    // Guarda mapa { "<vlan>" => "<nome livre>" } em cache_trafego/olt_vlan_nomes.json.
    if ($acao === 'vlan_nomes_get' || $acao === 'vlan_nomes_add') {
        $f = olt_cache_dir_g() . '/olt_vlan_nomes.json';
        $map = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($map)) $map = [];
        if ($acao === 'vlan_nomes_add') {
            $vid  = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
            $nome = trim($_POST['nome'] ?? $_GET['nome'] ?? '');
            if ($vid > 0 && $vid <= 4094 && $nome !== '') {
                $map[(string)$vid] = substr($nome, 0, 60);
                @file_put_contents($f, json_encode($map, JSON_UNESCAPED_UNICODE));
            }
        }
        echo json_encode(['status' => 'ok', 'nomes' => $map], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- OPCOES (ComboBox "+"): cadastro rapido de itens do aprovisionamento --
    // Guarda listas por campo (vlan, cidade, bairro, rua, zona, lineprofile,
    // srvprofile, ...) em cache_trafego/olt_opcoes.json. NAO fala com a OLT.
    if ($acao === 'opcoes_get' || $acao === 'opcoes_add' || $acao === 'opcoes_del') {
        $f = olt_cache_dir_g() . '/olt_opcoes.json';
        $op = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($op)) $op = [];
        if ($acao === 'opcoes_add') {
            $campo = preg_replace('/[^a-z0-9_]/i', '', $_POST['campo'] ?? $_GET['campo'] ?? '');
            $valor = trim($_POST['valor'] ?? $_GET['valor'] ?? '');
            if ($campo !== '' && $valor !== '') {
                if (!isset($op[$campo]) || !is_array($op[$campo])) $op[$campo] = [];
                $existe = false;
                foreach ($op[$campo] as $v) { if (strcasecmp((string)$v, $valor) === 0) { $existe = true; break; } }
                if (!$existe) { $op[$campo][] = $valor; natcasesort($op[$campo]); $op[$campo] = array_values($op[$campo]); }
                @file_put_contents($f, json_encode($op, JSON_UNESCAPED_UNICODE));
            }
        } elseif ($acao === 'opcoes_del') {
            $campo = preg_replace('/[^a-z0-9_]/i', '', $_POST['campo'] ?? $_GET['campo'] ?? '');
            $valor = trim($_POST['valor'] ?? $_GET['valor'] ?? '');
            if ($campo !== '' && $valor !== '' && isset($op[$campo]) && is_array($op[$campo])) {
                $op[$campo] = array_values(array_filter($op[$campo], function ($v) use ($valor) { return strcasecmp((string)$v, $valor) !== 0; }));
                @file_put_contents($f, json_encode($op, JSON_UNESCAPED_UNICODE));
            }
        }
        echo json_encode(['status' => 'ok', 'opcoes' => $op], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- CADASTRO LOCAL por SN (BANCO alternativo ao SmartOLT) ----------------
    // Guarda { "<SN>": { zona, nome, endereco, plano, obs, ... } } em
    // cache_trafego/olt_cadastro.json. É a base do "SmartOLT alternativo": dados
    // que a OLT nao tem (zona completa, observacoes, cadastro) ficam aqui e a lista
    // mescla por SN. NAO fala com a OLT. cadastro_set aceita 1 campo OU vários (JSON).
    if ($acao === 'cadastro_get' || $acao === 'cadastro_set') {
        // TRAVA (olt_json_lock) + releitura NA HORA por dentro dela: era o padrão clássico de
        // "perde gravação" — duas edições (ou uma edição e o cache_sync do cron convergindo as 2
        // pastas) liam o JSON inteiro, alteravam só o SEU campo em memória e regravavam o arquivo
        // INTEIRO; quem terminasse por último apagava a mudança do outro. Daí a necessidade de
        // tentar salvar 10+ vezes até "pegar". Para cadastro_get (só leitura) a trava não é
        // essencial, mas evita ler um arquivo pela metade enquanto outro processo grava.
        $lockCad = ($acao === 'cadastro_set') ? olt_json_lock('olt_cadastro') : null;
        if ($acao === 'cadastro_set' && $lockCad === null) {
            // Não conseguiu a trava a tempo: não escreve por cima de uma gravação concorrente.
            // Avisa a tela (em vez de reportar sucesso e silenciosamente perder o dado) para o
            // operador tentar de novo — bem diferente de "sucesso" seguido de dado sumido.
            echo json_encode(['status' => 'error', 'saved' => false,
                'message' => 'Não foi possível gravar agora (outra gravação em andamento). Tente novamente em instantes.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // DUAL-CACHE: lê a versão MAIS NOVA das 2 pastas e grava nas 2 -> nome/zona/tipo PERSISTEM
        // (antes gravava numa pasta que a tela não relia -> "F5 desfazia tudo").
        $cad = olt_jcache_load('olt_cadastro.json'); if (!is_array($cad)) $cad = [];
        $saved = null;
        if ($acao === 'cadastro_set') {
            $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $_POST['serial'] ?? $_GET['serial'] ?? ''));
            // chave SEMPRE no formato hex (o mesmo da lista): HWTC101E497B -> 48575443101E497B. Se já havia registro no
            // formato do fabricante, ele é juntado ao hex (o hex vence) — fim das duas entradas p/ o mesmo aparelho.
            if ($sn !== '' && function_exists('sn_para_hex')) { $hx = strtoupper((string)sn_para_hex($sn));
                if ($hx !== '' && $hx !== $sn) { if (isset($cad[$sn]) && is_array($cad[$sn])) { $cad[$hx] = array_merge($cad[$sn], (array)($cad[$hx] ?? [])); unset($cad[$sn]); } $sn = $hx; } }
            if ($sn !== '') {
                if (!isset($cad[$sn]) || !is_array($cad[$sn])) $cad[$sn] = [];
                $dados = null;
                if (isset($_POST['dados']) || isset($_GET['dados'])) { $dados = json_decode($_POST['dados'] ?? $_GET['dados'] ?? '', true); }
                if (is_array($dados)) {
                    foreach ($dados as $c => $v) { $c = preg_replace('/[^a-z0-9_]/i', '', (string)$c); if ($c !== '') $cad[$sn][$c] = substr(trim((string)$v), 0, 200); }
                } else {
                    $campo = preg_replace('/[^a-z0-9_]/i', '', $_POST['campo'] ?? $_GET['campo'] ?? '');
                    $valor = trim($_POST['valor'] ?? $_GET['valor'] ?? '');
                    if ($campo !== '') $cad[$sn][$campo] = substr($valor, 0, 200);
                }
                $ok = false; $j = json_encode($cad, JSON_UNESCAPED_UNICODE);
                foreach (olt_cache_dirs() as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); if (@file_put_contents($d . '/olt_cadastro.json', $j) !== false) { @chmod($d . '/olt_cadastro.json', 0666); $ok = true; } }
                $saved = $ok; // false => nenhuma pasta gravável: o front avisa
            }
        }
        if ($lockCad !== null) olt_json_unlock($lockCad);
        echo json_encode(['status' => 'ok', 'cadastro' => $cad, 'saved' => $saved, 'arquivo_gravavel' => ($saved !== false)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- CACHE SYNC: converge os arquivos de CONFIG entre as 2 pastas (persistente + /tmp) ----
    // O cron chama isto (roda como CLI, que CONSEGUE gravar no cache_trafego persistente). Se a TELA/FPM
    // só gravou no /tmp (que o boot limpa), o cron copia pro cache_trafego -> a conexão/backup/notif NÃO
    // somem mais no restart. Lê a versão MAIS NOVA de cada arquivo e reescreve nas 2 pastas.
    if ($acao === 'cache_sync') {
        header('Content-Type: application/json; charset=utf-8');
        $files = ['olt_conexao.json','olt_backup_ag.json','olt_notif.json','olt_relatorio.json',
                  'olt_cadastro.json','olt_meta.json','olt_autorizacoes.json','olt_perfis.json',
                  'olt_vlan_nomes.json','olt_modelos.json','olt_modelo_img.json','olt_opcoes.json',
                  'wellsystem_config.json','olt_backup_ag_last.txt',
                  // ADICIONADOS: o que o NAVEGADOR grava só no /tmp (FPM não escreve na permanente) e sumia no
                  // reboot -> agora o cron converge pra pasta permanente. USUÁRIOS criados, LOGO, cache de ONUs
                  // e a LISTA DE PLACAS (nº real de portas por placa -> portas vazias 9-15 aparecem na hora).
                  'olt_usuarios.json','wellsystem_logo_olt.txt','olt_onus_cache.json','olt_placas.json','olt_pon_tx.json',
                  // ALARMES reais da OLT (cache + estado da detecção de PON/placa caída) -> persiste no reboot.
                  'olt_alarmes.json','olt_alarmes_estado.json','olt_cad_url.json'];
        $n = 0;   // as pastas dependem do arquivo: comum a todas as OLTs ou da OLT em uso (olt_cache_dirs_de)
        // olt_cadastro.json e olt_onus_cache.json também são gravados por cadastro_set/olt_cache_save
        // com trava própria (olt_json_lock); convergir esses dois aqui SEM a mesma trava podia ler o
        // arquivo pela metade (no meio de uma gravação) e copiar lixo pra outra pasta. Os demais
        // arquivos desta lista mudam bem menos (configs), então não entraram nesta proteção.
        $travaPorArquivo = ['olt_cadastro.json' => 'olt_cadastro', 'olt_onus_cache.json' => 'olt_onus_cache'];
        foreach ($files as $nm) {
            $lockSync = isset($travaPorArquivo[$nm]) ? olt_json_lock($travaPorArquivo[$nm]) : null;
            if (isset($travaPorArquivo[$nm]) && $lockSync === null) continue; // não conseguiu a trava -> pula este arquivo NESTE ciclo (converge no próximo)
            $dirs = olt_cache_dirs_de($nm);
            $best = null; $bts = -1;
            foreach ($dirs as $d) { $f = $d . '/' . $nm; if (is_file($f)) { $t = (int)@filemtime($f); if ($t >= $bts) { $c = @file_get_contents($f); if ($c !== false) { $best = $c; $bts = $t; } } } }
            if ($best !== null) { $mudou = false;
                foreach ($dirs as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); $tf = $d . '/' . $nm;
                    $cur = is_file($tf) ? @file_get_contents($tf) : false;
                    if ($cur === $best) continue;                    // JÁ idêntico -> NÃO reescreve (preserva a data REAL da sua última alteração)
                    if (@file_put_contents($tf, $best) !== false) { @chmod($tf, 0666); $mudou = true; }
                }
                if ($mudou) $n++;   // conta só quando REALMENTE convergiu algo
            }
            if ($lockSync !== null) olt_json_unlock($lockSync);
        }
        echo json_encode(['status' => 'ok', 'sincronizados' => $n, 'pastas' => $dirs], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- FIX/TESTE de permissão de gravação (cache_trafego) — resolve "não grava" -----
    // Cria a pasta, ajusta permissão (se o PHP tiver direito) e testa gravar de verdade.
    if ($acao === 'fix_perms') {
        $dir = olt_cache_dir();
        $log = [];
        if (!is_dir($dir)) { $log['mkdir'] = @mkdir($dir, 0777, true); }
        @chmod($dir, 0777);
        if (is_dir($dir)) { foreach ((@glob($dir . '/*') ?: []) as $ff) { if (is_file($ff)) @chmod($ff, 0666); } }   // só arquivos: subpasta de OLT (olt_<id>) precisa continuar entrável
        $test = $dir . '/.__wtest'; $w = @file_put_contents($test, 'ok');
        $rb = ($w !== false) ? @file_get_contents($test) : false; @unlink($test);
        $owner = (function_exists('posix_getpwuid') && @fileowner($dir) !== false) ? (@posix_getpwuid(@fileowner($dir))['name'] ?? '') : '';
        echo json_encode(['status' => 'ok', 'dir' => $dir, 'existe' => is_dir($dir),
            'gravavel' => ($rb === 'ok'), 'owner' => $owner, 'log' => $log], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- BACKUP (exportar / restaurar as configs em JSON) ---------------------------
    // Empacota os arquivos de CONFIG (não o cache de tráfego) num único JSON, e restaura.
    if ($acao === 'backup_export' || $acao === 'backup_import') {
        $dir = olt_cache_dir_g(); if (!is_dir($dir)) @mkdir($dir, 0777, true);
        // BACKUP DE TUDO: todos os olt_*.json de config/dados. Exclui só os CACHES volateis (regeneram).
        $excl = ['olt_sinal_cache.json','olt_sinal_hist.json','olt_snmp_traf.json','olt_snmp_last.json',
                 'olt_pon_tx.json','olt_uplink.json','olt_temp_hist.json','olt_temp_estado.json',
                 'olt_snmp_ifmap.json','olt_snmp_pon_zero.json','olt_hist.json'];

        if ($acao === 'backup_export') {
            $bundle = ['_wellsystem_backup' => 1, 'versao' => 2, 'data' => date('c'), 'arquivos' => []];
            foreach (glob($dir . '/olt_*.json') ?: array() as $p) {
                $a = basename($p); if (in_array($a, $excl, true)) continue;
                $j = json_decode(@file_get_contents($p), true); if ($j !== null) $bundle['arquivos'][$a] = $j;
            }
            echo json_encode($bundle, JSON_UNESCAPED_UNICODE);
            exit;
        }

        // backup_import: recebe o JSON e regrava TUDO o que vier no bundle (nome validado p/ segurança).
        $raw = $_POST['dados'] ?? '';
        $b = json_decode($raw, true);
        if (!is_array($b) || empty($b['arquivos']) || !is_array($b['arquivos']) || empty($b['_wellsystem_backup'])) {
            echo json_encode(['status' => 'erro', 'msg' => 'Arquivo de backup inválido.'], JSON_UNESCAPED_UNICODE); exit;
        }
        $rest = []; $falhou = [];
        foreach ($b['arquivos'] as $a => $conteudo) {
            if (!preg_match('/^olt_[a-z0-9_]+\.json$/i', (string)$a)) continue;   // só nomes seguros olt_*.json
            if (in_array($a, $excl, true)) continue;                              // não sobrescreve cache volatil
            $r = @file_put_contents($dir . '/' . $a, json_encode($conteudo, JSON_UNESCAPED_UNICODE));
            if ($r !== false) { @chmod($dir . '/' . $a, 0666); $rest[] = $a; } else { $falhou[] = $a; }
        }
        echo json_encode(['status' => empty($falhou) ? 'ok' : 'parcial', 'restaurados' => $rest, 'falhou' => $falhou], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- VÁRIAS OLTs: lista, cadastro ("+") e exclusão ------------------------------------
    // olts_lista (nível 1): a principal + as cadastradas e qual está em uso. olts_ids (cron local): só os ids, um por linha.
    // olt_add / olt_del / olt_ren (nível 3): cadastram, excluem e renomeiam. A conexão de cada OLT se configura na própria aba.
    if ($acao === 'olts_lista' || $acao === 'olts_ids') {
        $lista = olt_lista();
        if ($acao === 'olts_ids') { header('Content-Type: text/plain; charset=utf-8'); echo implode("\n", array_keys($lista)); exit; }
        header('Content-Type: application/json; charset=utf-8');
        $itens = array(array('id' => '', 'nome' => olt_principal_nome(), 'ip' => trim((string)($GLOBALS['olt_ip'] ?? ''))));
        foreach ($lista as $id => $o) $itens[] = array('id' => $id, 'nome' => $o['nome'], 'ip' => $o['ip']);
        echo json_encode(array('status' => 'ok', 'atual' => olt_ctx_id(), 'olts' => $itens), JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'olt_add' || $acao === 'olt_del' || $acao === 'olt_ren') {
        header('Content-Type: application/json; charset=utf-8');
        $lista = olt_lista();
        $nome = trim(preg_replace('/\s+/', ' ', (string)($_POST['nome'] ?? '')));
        $nome = function_exists('mb_substr') ? mb_substr($nome, 0, 40) : substr($nome, 0, 40);
        if ($acao === 'olt_add') {
            if ($nome === '') { echo json_encode(array('status' => 'erro', 'message' => 'Informe o nome da OLT.'), JSON_UNESCAPED_UNICODE); exit; }
            if (count($lista) >= 20) { echo json_encode(array('status' => 'erro', 'message' => 'Limite de 20 OLTs cadastradas.'), JSON_UNESCAPED_UNICODE); exit; }
            if (function_exists('ws_lic_olts_verificar')) { $lv = ws_lic_olts_verificar(); if (!$lv['ok']) { echo json_encode(array('status' => 'erro', 'message' => $lv['msg']), JSON_UNESCAPED_UNICODE); exit; } }   // limite de OLTs da licença
            do { $nid = 'o' . substr(bin2hex(random_bytes(3)), 0, 5); } while (isset($lista[$nid]));
            $lista[$nid] = array('nome' => $nome, 'ip' => '');
            olt_lista_salvar($lista);
            foreach (olt_cache_dirs_g() as $d) { $sub = $d . '/olt_' . $nid; if (!is_dir($sub)) { @mkdir($sub, 0777, true); @chmod($sub, 0777); } }
            echo json_encode(array('status' => 'ok', 'id' => $nid, 'message' => 'OLT cadastrada. Configure a conexão dela.'), JSON_UNESCAPED_UNICODE); exit;
        }
        $oid = olt_ctx_limpar($_POST['id'] ?? '');
        if ($acao === 'olt_ren' && $oid === '' && !empty($_POST['principal'])) {   // renomear a PRINCIPAL (só muda o rótulo do seletor)
            if ($nome === '') { echo json_encode(array('status' => 'erro', 'message' => 'Informe o nome.'), JSON_UNESCAPED_UNICODE); exit; }
            $j = olt_jcache_load('olt_lista.json'); $j['principal_nome'] = $nome; if (!isset($j['olts'])) $j['olts'] = array();
            olt_jcache_save('olt_lista.json', $j);
            echo json_encode(array('status' => 'ok'), JSON_UNESCAPED_UNICODE); exit;
        }
        if ($oid === '' || !isset($lista[$oid])) { echo json_encode(array('status' => 'erro', 'message' => 'OLT não encontrada (a principal não se exclui nem se renomeia).'), JSON_UNESCAPED_UNICODE); exit; }
        if ($acao === 'olt_ren') {
            if ($nome === '') { echo json_encode(array('status' => 'erro', 'message' => 'Informe o nome.'), JSON_UNESCAPED_UNICODE); exit; }
            $lista[$oid]['nome'] = $nome; olt_lista_salvar($lista);
            echo json_encode(array('status' => 'ok'), JSON_UNESCAPED_UNICODE); exit;
        }
        // olt_del: tira da lista e guarda a pasta renomeada (credencial e histórico não são apagados sem querer).
        unset($lista[$oid]); olt_lista_salvar($lista);
        foreach (olt_cache_dirs_g() as $d) { $sub = $d . '/olt_' . $oid; if (is_dir($sub)) @rename($sub, $d . '/olt_excluida_' . $oid . '_' . date('Ymd_His')); }
        setcookie('WSOLT', '', time() - 3600, '/');
        echo json_encode(array('status' => 'ok', 'message' => 'OLT removida da lista (os dados dela ficaram guardados em olt_excluida_*).'), JSON_UNESCAPED_UNICODE); exit;
    }

    // ---- CONEXÃO DA OLT (IP/porta/usuário/senha) via interface ----------------------
    if ($acao === 'conexao_get' || $acao === 'conexao_set') {
        $dir = olt_cache_dir(); if (!is_dir($dir)) @mkdir($dir, 0777, true);
        $f = $dir . '/olt_conexao.json';
        $c = olt_conexao_cfg();
        $saved = null;
        if ($acao === 'conexao_set') {
            $novo = [
                'ip'      => substr(trim($_POST['ip'] ?? ''), 0, 60),
                'porta'   => (int)($_POST['porta'] ?? 23),
                'user'    => substr(trim($_POST['user'] ?? ''), 0, 60),
                'timeout' => max(3, min(30, (int)($_POST['timeout'] ?? 8))),
            ];
            // senha: só sobrescreve se o operador digitou algo (campo vazio = mantém a atual).
            $pw = (string)($_POST['pass'] ?? '');
            $novo['pass'] = ($pw !== '') ? $pw : ($c['pass'] ?? '');
            if ($novo['porta'] <= 0 || $novo['porta'] > 65535) $novo['porta'] = 23;
            /* IP REPETIDO (20/11/2026): a 2ª OLT cadastrada com o IP da principal mostrou os MESMOS clientes e dobrou a leitura da OLT. Cada OLT precisa de IP próprio. */
            if ($novo['ip'] !== '') {
                $ipN = strtolower($novo['ip']); $ctxN = olt_ctx_id(); $dupNome = '';
                if ($ctxN !== '') { $pj = @json_decode((string)@file_get_contents(olt_cache_dir_g() . '/olt_conexao.json'), true); if (is_array($pj) && strtolower(trim((string)($pj['ip'] ?? ''))) === $ipN) $dupNome = 'Principal'; }
                foreach (olt_lista() as $lid => $lo) if ((string)$lid !== $ctxN && strtolower(trim((string)($lo['ip'] ?? ''))) === $ipN) $dupNome = (string)$lo['nome'];
                if ($dupNome !== '') { echo json_encode(array('status' => 'erro', 'saved' => false, 'message' => 'Esse IP já é da OLT "' . $dupNome . '". Cada OLT precisa de um IP diferente.'), JSON_UNESCAPED_UNICODE); exit; }
            }
            // SNMP (gráficos/sinal): comunidade só-leitura + porta UDP. Preserva o atual se vier vazio.
            $sc = isset($_POST['snmp_comm']) ? substr(trim($_POST['snmp_comm']), 0, 60) : ($c['snmp_comm'] ?? '');
            $sp = isset($_POST['snmp_port']) ? (int)$_POST['snmp_port'] : (int)($c['snmp_port'] ?? 161);
            if ($sp <= 0 || $sp > 65535) $sp = 161;
            $srw = isset($_POST['snmp_comm_rw']) ? substr(trim($_POST['snmp_comm_rw']), 0, 60) : ($c['snmp_comm_rw'] ?? '');
            $novo['snmp_comm'] = $sc; $novo['snmp_port'] = $sp; $novo['snmp_comm_rw'] = $srw;
            // DUAL-CACHE: grava nas 2 pastas -> a conexão fica na PERSISTENTE (cache_trafego) e NÃO some
            // no restart (antes a tela/FPM só gravava no /tmp, que o boot limpa -> pedia IP/senha de novo).
            $w = false; $j = json_encode($novo, JSON_UNESCAPED_UNICODE);
            foreach (olt_cache_dirs() as $dd) { if (!is_dir($dd)) @mkdir($dd, 0777, true); if (@file_put_contents($dd . '/olt_conexao.json', $j) !== false) { @chmod($dd . '/olt_conexao.json', 0666); $w = true; } }
            $saved = $w; if ($w) $c = $novo;
            if ($w && olt_ctx_id() !== '') { $ls = olt_lista(); if (isset($ls[olt_ctx_id()])) { $ls[olt_ctx_id()]['ip'] = $novo['ip']; olt_lista_salvar($ls); } }   // o ERP acha a OLT pelo IP
        }
        // nunca devolve a senha em claro — só informa se há uma configurada.
        echo json_encode(['status' => 'ok', 'cfg' => [
            'ip' => $c['ip'] ?? $GLOBALS['olt_ip'], 'porta' => $c['porta'] ?? $GLOBALS['olt_porta'],
            'user' => $c['user'] ?? $GLOBALS['olt_user'], 'timeout' => $c['timeout'] ?? $GLOBALS['olt_timeout'],
            'tem_senha' => !empty($c['pass']),
            'snmp_comm' => $c['snmp_comm'] ?? '', 'snmp_port' => $c['snmp_port'] ?? 161, 'snmp_comm_rw' => $c['snmp_comm_rw'] ?? '',
        ], 'saved' => $saved], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DIAGNÓSTICO DAS NOTIFICAÇÕES (caminho REAL, igual ao do alerta) -----------
    // O "Testar" da tela usa os campos do formulário. Este aqui usa EXATAMENTE o que
    // está GRAVADO e chama olt_notificar() — a mesma função que o alerta automático
    // usa. Se funcionar aqui e não no alerta, o problema é a transição; se falhar
    // aqui, o problema é a configuração salva.
    if ($acao === 'notif_diag') {
        header('Content-Type: application/json; charset=utf-8');
        $f   = olt_cache_dir_g() . '/olt_notif.json';
        $cfg = olt_notif_config();
        $dst = (isset($cfg['destinos']) && is_array($cfg['destinos'])) ? $cfg['destinos'] : [];
        $canais = [];
        foreach ($dst as $d) { $canais[] = ['canal' => $d['canal'] ?? '?', 'nome' => $d['nome'] ?? '',
            'tem_chat' => !empty($d['chat']), 'tem_phone' => !empty($d['phone']), 'tem_apikey' => !empty($d['apikey'])]; }

        $diag = [
            'arquivo'        => $f,
            'arquivo_existe' => is_file($f),
            'pasta_gravavel' => is_writable(olt_cache_dir()),
            'ativo'          => !empty($cfg['ativo']),
            'tg_token'       => !empty($cfg['tg_token']) ? ('definido (' . strlen($cfg['tg_token']) . ' car.)') : 'VAZIO',
            'evo_url'        => !empty($cfg['evo_url']) ? 'definido' : 'vazio',
            'qtd_destinos'   => count($dst),
            'destinos'       => $canais,
        ];

        // Envio real (só quando pedido), pela MESMA função do alerta automático.
        $envio = null;
        if (!empty($_GET['enviar']) || !empty($_POST['enviar'])) {
            $envio = olt_notificar('🔔 TESTE REAL do Wellsystem — esta mensagem passou pelo MESMO caminho do alerta automático de PON. Se você recebeu, as notificações automáticas estão OK. (' . date('d/m/Y H:i:s') . ')');
        }

        // Estado atual das PONs (para explicar por que não houve transição).
        $stF  = olt_cache_dir() . '/olt_pon_estado.json';
        $prev = is_file($stF) ? json_decode(@file_get_contents($stF), true) : [];
        $diag['pons_ja_em_queda'] = is_array($prev) ? count($prev) : 0;
        $diag['obs_transicao'] = 'O alerta automático só envia quando uma PON MUDA de estado. '
            . 'PONs que já estavam caídas e continuam caídas não geram nova mensagem.';

        echo json_encode(['status' => 'ok', 'diag' => $diag, 'envio' => $envio], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- TERMINAL da OLT: roda um comando e devolve a saída (usa a conexão salva) --
    if ($acao === 'terminal_exec') {
        header('Content-Type: application/json; charset=utf-8');
        $cmd = trim((string)($_POST['cmd'] ?? $_GET['cmd'] ?? ''));
        // Credenciais digitadas no LOGIN do terminal (opcionais). Se vierem, entra
        // com elas (como se estivesse no console da OLT); senão usa as salvas.
        $tu = trim((string)($_POST['u'] ?? ''));
        $tp = (string)($_POST['p'] ?? '');
        $usr = ($tu !== '') ? $tu : $olt_user;
        $pwd = ($tp !== '') ? $tp : $olt_pass;
        if ($cmd === '') { echo json_encode(['status' => 'ok', 'saida' => '']); exit; }
        // Roda em enable+config (aceita "display ..." e comandos de configuração).
        try {
            $out = olt_exec($olt_ip, $olt_porta, $usr, $pwd, ['enable', 'config', $cmd, 'quit', 'quit'], max(12, (int)$olt_timeout));
            $raw = is_array($out) ? implode("\n", array_slice($out, 2)) : (string)$out;
            echo json_encode(['status' => 'ok', 'cmd' => $cmd, 'saida' => trim($raw)], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            // Devolve o motivo real (VTY ocupada, senha, timeout…) para aparecer no console.
            echo json_encode(['status' => 'erro', 'cmd' => $cmd, 'saida' => '[falha] ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }

    // ---- GRÁFICO: devolve o histórico de conexões (dia/semana/mês) ----------------
    // ---- RADIUS EMERGÊNCIA: config dos painéis + acionamento ---------------------
    if ($acao === 'radius_panel_get') {
        header('Content-Type: application/json; charset=utf-8');
        $c = olt_radpanel_load(); $ps = $c['paineis'] ?? [];
        $out = array_map(function ($p) { $q = $p; $q['tem_pass'] = !empty($p['pass']); unset($q['pass']); return $q; }, $ps);
        echo json_encode(['status' => 'ok', 'paineis' => $out], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'radius_panel_set') {
        header('Content-Type: application/json; charset=utf-8');
        $in = json_decode((string)($_POST['paineis'] ?? '[]'), true); if (!is_array($in)) $in = [];
        $old = olt_radpanel_load(); $oldP = $old['paineis'] ?? [];
        foreach ($in as $i => &$p) { if (empty($p['pass']) && isset($oldP[$i]['pass'])) $p['pass'] = $oldP[$i]['pass']; }
        unset($p);
        $r = @file_put_contents(olt_radpanel_file(), json_encode(['paineis' => $in], JSON_UNESCAPED_UNICODE));
        if ($r !== false) @chmod(olt_radpanel_file(), 0666);
        echo json_encode(['status' => 'ok', 'saved' => ($r !== false)], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'radius_emergencia') {
        header('Content-Type: application/json; charset=utf-8');
        $modo = (($_POST['modo'] ?? '') === 'emergencia') ? 'emergencia' : 'radius';
        $rad  = ($modo === 'emergencia') ? 3 : 0;
        $cfg = olt_radpanel_load(); $ps = $cfg['paineis'] ?? [];
        if (!$ps) { echo json_encode(['status' => 'erro', 'message' => 'Nenhum painel configurado.']); exit; }
        // Aplica só nos índices marcados (alvos); sem alvos = todos.
        $alvos = trim((string)($_POST['alvos'] ?? ''));
        if ($alvos !== '') { $ids = array_map('intval', explode(',', $alvos)); $sel = []; foreach ($ids as $i) if (isset($ps[$i])) $sel[] = $ps[$i]; if ($sel) $ps = $sel; }
        $res = []; foreach ($ps as $p) $res[] = olt_radpanel_aplicar($p, $rad);
        olt_log_registrar('radius_modo', 'Autenticação do Radius alterada para ' . ($modo === 'emergencia' ? 'QUALQUER LOGIN (emergência)' : 'RADIUS (normal)'));
        echo json_encode(['status' => 'ok', 'modo' => $modo, 'resultados' => $res], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'grafico_dados') {
        header('Content-Type: application/json; charset=utf-8');
        $f = olt_cache_dir() . '/olt_hist.json';
        $h = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($h)) $h = [];
        $fd = olt_cache_dir() . '/olt_hist_dia.json';
        $hd = is_file($fd) ? json_decode(@file_get_contents($fd), true) : [];
        if (!is_array($hd)) $hd = [];
        echo json_encode(['status' => 'ok', 'hist' => $h, 'hist_dia' => $hd], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- BACKUP AUTOMÁTICO: agendamento (horário + e-mail) -------------------------
    // DIAGNÓSTICO do backup automático (vê o que o PHP web enxerga + força envio com &enviar=1).
    if ($acao === 'backup_diag') {
        header('Content-Type: application/json; charset=utf-8');
        $dir = olt_cache_dir_g(); $f = $dir . '/olt_backup_ag.json';
        $c = is_file($f) ? json_decode(@file_get_contents($f), true) : null;
        $out = ['cache_dir' => $dir, 'config_existe' => is_file($f), 'agora_servidor' => date('H:i'),
            'ativo' => is_array($c) ? ($c['ativo'] ?? null) : null, 'hora' => is_array($c) ? ($c['hora'] ?? null) : null,
            'email' => is_array($c) ? ($c['email'] ?? null) : null, 'tem_smtp' => is_array($c) ? !empty($c['smtp_host']) : false];
        if (($_GET['enviar'] ?? '') === '1') { list($ok, $m) = olt_backup_enviar_email(is_array($c) ? ($c['email'] ?? '') : ''); $out['envio'] = ['ok' => $ok, 'motivo' => $m]; }
        echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
    }
    // BACKUP automático disparado pelo cron — independe da OLT, roda em ~1s (sem telnet).
    // Respeita horário + marca (envia 1x/dia). É a chamada que o olt_monitor.sh faz.
    if ($acao === 'backup_run') {
        header('Content-Type: application/json; charset=utf-8');
        $r = olt_backup_auto_check();
        // Mostra o ESTADO do agendamento p/ entender por que enviou ou não.
        $s = olt_jcache_load('olt_backup_ag.json'); if (!is_array($s)) $s = [];   // mesmo horário que o envio usa (o mais novo)
        $lf = olt_cache_dir_g() . '/olt_backup_ag_last.txt'; $lastd = is_file($lf) ? trim((string)@file_get_contents($lf)) : '';
        echo json_encode(['status' => 'ok', 'enviou' => ($r === true),
            'ativo' => !empty($s['ativo']), 'email' => $s['email'] ?? '', 'hora_agendada' => $s['hora'] ?? '',
            'ja_enviado_em' => $lastd, 'agora' => date('Y-m-d H:i'),
            'dica' => (substr($lastd, 0, 10) === date('Y-m-d')) ? 'Horário de hoje já cumprido (' . $lastd . ') — remarcar o horário ou apagar olt_backup_ag_last.txt força novo envio.' :
                      (empty($s['ativo']) ? 'Envio diário DESATIVADO na tela.' :
                      (empty($s['email']) ? 'E-mail de destino vazio.' :
                      ((date('H:i') < ($s['hora'] ?? '03:00')) ? 'Ainda não deu o horário agendado.' : 'Deveria ter enviado — veja falha de SMTP.')))], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'backup_ag_testar') {
        header('Content-Type: application/json; charset=utf-8');
        $to = trim((string)($_POST['email'] ?? ''));
        list($ok, $motivo) = olt_backup_enviar_email($to);
        olt_log_registrar($ok ? 'backup_teste' : 'backup_teste_falha', ($ok ? 'Backup de teste enviado para ' : 'Falha no backup de teste (' . $motivo . ') para ') . $to);
        echo json_encode(['status' => 'ok', 'enviado' => $ok, 'motivo' => $motivo], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($acao === 'backup_ag_get' || $acao === 'backup_ag_set') {
        header('Content-Type: application/json; charset=utf-8');
        $c = olt_jcache_load('olt_backup_ag.json'); if (!is_array($c)) $c = [];   // dual-cache (horário 07:00 persiste p/ o cron)
        $saved = null;
        if ($acao === 'backup_ag_set') {
            $c['ativo'] = ((string)($_POST['ativo'] ?? '') === '1');
            $c['hora']  = preg_match('/^\d{2}:\d{2}$/', ($_POST['hora'] ?? '')) ? $_POST['hora'] : '03:00';
            $c['email'] = substr(trim($_POST['email'] ?? ''), 0, 120);
            // SMTP (opcional) — usado quando o servidor não tem mail()/MTA.
            if (isset($_POST['smtp_host'])) $c['smtp_host'] = substr(trim($_POST['smtp_host']), 0, 120);
            if (isset($_POST['smtp_port'])) $c['smtp_port'] = (int)$_POST['smtp_port'];
            if (isset($_POST['smtp_seg']))  $c['smtp_seg']  = in_array($_POST['smtp_seg'], ['ssl','tls','none'], true) ? $_POST['smtp_seg'] : 'tls';
            if (isset($_POST['smtp_user'])) $c['smtp_user'] = substr(trim($_POST['smtp_user']), 0, 120);
            if (isset($_POST['smtp_pass']) && $_POST['smtp_pass'] !== '') $c['smtp_pass'] = substr((string)$_POST['smtp_pass'], 0, 120);
            if (isset($_POST['smtp_from'])) $c['smtp_from'] = substr(trim($_POST['smtp_from']), 0, 120);
            $w = false; $j = json_encode($c, JSON_UNESCAPED_UNICODE);
            foreach (olt_cache_dirs() as $dd) { if (!is_dir($dd)) @mkdir($dd, 0777, true); if (@file_put_contents($dd . '/olt_backup_ag.json', $j) !== false) { @chmod($dd . '/olt_backup_ag.json', 0666); $w = true; } }
            $saved = $w;
            // NÃO apaga mais a marca "já enviou hoje" (olt_backup_ag_last.txt) ao salvar — era isso que
            // causava o DUPLICADO: enviou às 01:35 com o horário antigo, você mudou p/ 07:00, salvou -> a
            // marca sumia e ele enviava DE NOVO às 07:00. Agora: 1 envio/dia, ponto. Novo horário vale a
            // partir de amanhã. Pra testar no MESMO dia use o botão "Testar" (backup_ag_testar). Só o throttle
            // de retry é limpo (inofensivo — apenas permite uma nova tentativa se a última FALHOU).
            foreach (olt_cache_dirs() as $dd) { @unlink($dd . '/olt_backup_ag_try.txt'); }
        }
        $safe = $c; $safe['tem_smtp_pass'] = !empty($c['smtp_pass']); unset($safe['smtp_pass']);
        echo json_encode(['status' => 'ok', 'saved' => $saved, 'cfg' => $safe], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DESCONECTAR: apaga os dados de conexão e o cache da OLT -------------------
    // Deixa a instalação como recém-instalada, sem mexer em usuários nem no relatório.
    if ($acao === 'conexao_desconectar') {
        header('Content-Type: application/json; charset=utf-8');
        $dir = olt_cache_dir();
        @unlink($dir . '/olt_conexao.json');                 // credenciais
        foreach (['olt_cache.json', 'olt_sinal.json', 'olt_estado.json',
                  'olt_pon_estado.json', 'olt_cron.lock'] as $f) { @unlink($dir . '/' . $f); }
        echo json_encode(['status' => 'ok', 'desconectado' => true,
            'message' => 'OLT desconectada. Configure uma nova conexão para voltar a operar.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- TESTE DE CONEXÃO (diagnóstico rápido, passo a passo) ----------------------
    // Não varre nada: só verifica alcance de rede, banner, login e prompt. Timeout
    // curto de propósito, para responder rápido mesmo com a OLT fora do ar.
    if ($acao === 'conexao_teste') {
        header('Content-Type: application/json; charset=utf-8');
        $passos = [];
        $t0 = microtime(true);

        if (trim((string)$olt_ip) === '') {
            echo json_encode(['status' => 'erro', 'conectado' => false,
                'etapa' => 'config', 'message' => 'Nenhum IP configurado.',
                'passos' => [['t' => 'Configuração', 'ok' => false, 'msg' => 'IP/host vazio — preencha e salve.']]], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $passos[] = ['t' => 'Configuração', 'ok' => true, 'msg' => $olt_ip . ':' . $olt_porta . ' · usuário "' . $olt_user . '"'];

        // 1) Alcance de rede (TCP)
        $ini = microtime(true);
        $sk = @fsockopen($olt_ip, $olt_porta, $errno, $errstr, 6);
        $ms = (int)round((microtime(true) - $ini) * 1000);
        if (!$sk) {
            $passos[] = ['t' => 'Rede (TCP)', 'ok' => false,
                'msg' => 'Não alcançou ' . $olt_ip . ':' . $olt_porta . ' em ' . $ms . 'ms — ' . ($errstr ?: 'sem resposta') .
                         '. Verifique IP, rota/VPN e firewall entre o servidor e a OLT.'];
            echo json_encode(['status' => 'erro', 'conectado' => false, 'etapa' => 'rede',
                'message' => 'Servidor não alcança a OLT em ' . $olt_ip . ':' . $olt_porta,
                'passos' => $passos], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $passos[] = ['t' => 'Rede (TCP)', 'ok' => true, 'msg' => 'Porta ' . $olt_porta . ' aberta (' . $ms . 'ms)'];

        @fclose($sk);   // o teste de porta terminou; o login usa o caminho oficial

        // 2) Login REAL — usa exatamente a mesma rotina da varredura (olt_exec).
        //    Reimplementar o login aqui dava falso negativo: a varredura conectava,
        //    mas o teste dizia "recusado". Uma rotina só, um resultado só.
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                        ['enable', 'display sysuptime', 'quit'], max(6, (int)$olt_timeout), 1);
        $bruto = is_array($out) ? implode("\n", $out) : (string)$out;
        $recusou = preg_match('/(Reenter|failure|failed|incorrect|inv[aá]lid|Username or password)/i', $bruto);
        $logou   = ($bruto !== '' && !$recusou);

        if ($logou) {
            $up = '';
            if (preg_match('/uptime\s*(?:is|:)?\s*([^\r\n]+)/i', $bruto, $mu)) $up = ' · uptime ' . trim($mu[1]);
            $passos[] = ['t' => 'Autenticação', 'ok' => true, 'msg' => 'Login aceito — a OLT respondeu' . $up];
        } elseif ($recusou) {
            $passos[] = ['t' => 'Autenticação', 'ok' => false, 'msg' => 'A OLT recusou usuário/senha. Confira as credenciais em "Conexão da OLT".'];
        } else {
            $passos[] = ['t' => 'Autenticação', 'ok' => false, 'msg' => 'A OLT aceitou a conexão mas não respondeu no tempo — normalmente sessões VTY esgotadas. Aguarde ~1 min e teste de novo.'];
        }

        $tot = (int)round((microtime(true) - $t0) * 1000);
        echo json_encode(['status' => $logou ? 'ok' : 'erro', 'conectado' => $logou,
            'etapa' => $logou ? 'ok' : ($recusou ? 'auth' : 'vty'),
            'ms' => $tot, 'passos' => $passos,
            'message' => $logou ? 'Conectado à OLT com sucesso.' : 'Falha ao autenticar na OLT.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- LOGOMARCA do Gerenciador OLT (independente do Radius) ---------------------
    // Fica AQUI (e não no index.php) para a página da OLT não depender do Radius.
    if ($acao === 'logo_get' || $acao === 'logo_set' || $acao === 'logo_del') {
        $dir = olt_cache_dir_g(); if (!is_dir($dir)) @mkdir($dir, 0777, true);
        $f = $dir . '/wellsystem_logo_olt.txt';
        $saved = null;
        if ($acao === 'logo_set') {
            $img = (string)($_POST['img'] ?? '');
            if (preg_match('#^data:image/(png|jpe?g|svg\+xml|webp);base64,#i', $img) && strlen($img) < 900000) {
                $r = @file_put_contents($f, $img);
                if ($r !== false) { @chmod($f, 0666); $saved = true; } else { $saved = false; }
            } else { $saved = false; }
        } elseif ($acao === 'logo_del') { @unlink($f); $saved = true; }
        echo json_encode(['status' => 'ok', 'saved' => $saved, 'alvo' => 'olt',
            'logo' => (is_file($f) ? trim((string)@file_get_contents($f)) : '')], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- MODELOS de ONU/ONT: nome de exibição + tipo, editáveis pelo operador --------
    // O modelo BRUTO é o que a OLT reporta (ex.: "HG8310M"). Aqui o operador define um
    // NOME AMIGÁVEL e o TIPO (ONU/Bridge ou ONT/Router) usado na coluna Tipo.
    if ($acao === 'modelos_get' || $acao === 'modelos_set' || $acao === 'modelos_del') {
        $dir = olt_cache_dir_g(); if (!is_dir($dir)) @mkdir($dir, 0777, true);
        $f = $dir . '/olt_modelos.json';
        $m = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($m)) $m = [];
        $chave = strtoupper(trim($_POST['chave'] ?? $_GET['chave'] ?? ''));
        $saved = null;
        if ($acao === 'modelos_set' && $chave !== '') {
            $nome = substr(trim($_POST['nome'] ?? ''), 0, 60);
            $tipo = strtoupper(trim($_POST['tipo'] ?? ''));
            if (!in_array($tipo, ['ONU', 'ONT', ''], true)) $tipo = '';
            $m[$chave] = ['nome' => $nome, 'tipo' => $tipo];
            if ($nome === '' && $tipo === '') unset($m[$chave]);
            $r = @file_put_contents($f, json_encode($m, JSON_UNESCAPED_UNICODE));
            if ($r !== false) { @chmod($f, 0666); $saved = true; } else { $saved = false; }
        } elseif ($acao === 'modelos_del' && $chave !== '') {
            unset($m[$chave]); @file_put_contents($f, json_encode($m, JSON_UNESCAPED_UNICODE)); $saved = true;
        }
        echo json_encode(['status' => 'ok', 'saved' => $saved, 'modelos' => $m], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- FOTO do MODELO do equipamento (PNG/JPEG) por modelo/serial ----------------
    // GET sem chave -> lista só as chaves que têm imagem (leve). GET com chave -> a imagem.
    if ($acao === 'modelo_img_get' || $acao === 'modelo_img_set' || $acao === 'modelo_img_del') {
        $dir = olt_cache_dir_g(); if (!is_dir($dir)) @mkdir($dir, 0777, true);
        $f = $dir . '/olt_modelo_img.json';
        $m = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($m)) $m = [];
        $chave = strtoupper(trim($_POST['chave'] ?? $_GET['chave'] ?? ''));
        $saved = null;
        if ($acao === 'modelo_img_set' && $chave !== '') {
            $img = (string)($_POST['img'] ?? '');
            if (preg_match('#^data:image/(png|jpe?g);base64,#i', $img) && strlen($img) < 1600000) {
                $m[$chave] = $img; $r = @file_put_contents($f, json_encode($m, JSON_UNESCAPED_UNICODE));
                if ($r !== false) { @chmod($f, 0666); $saved = true; } else { $saved = false; }
            } else { $saved = false; }
        } elseif ($acao === 'modelo_img_del' && $chave !== '') {
            unset($m[$chave]); @file_put_contents($f, json_encode($m, JSON_UNESCAPED_UNICODE)); $saved = true;
        }
        if ($acao === 'modelo_img_get') {
            if ($chave !== '') { 
                // Tenta buscar no gerenciador de Mkfiles primeiro (prioridade p/ arquivo físico local)
                $mk_file = '';
                $cleanChave = preg_replace('/[^a-zA-Z0-9_-]/', '_', $chave);
                foreach (['png','jpg','jpeg','webp'] as $ext) {
                    $mk_file = olt_mkfiles_achar('onu_type_' . $cleanChave . '.' . $ext);
                    if ($mk_file !== '') break;
                }
                if ($mk_file !== '') {
                    // Retorna URL direta do mkfile, o frontend (<img> src) aceita igual ao Base64
                    echo json_encode(['status' => 'ok', 'img' => 'olt_huawei.php?acao=mkfiles_get&nome=' . rawurlencode(basename($mk_file))], JSON_UNESCAPED_UNICODE); 
                    exit; 
                }
                // Fallback para o banco antigo em base64
                $b64 = (string)($m[$chave] ?? '');
                // 21/10/2026: sem foto própria, usa a foto do MODELO no cadastro de equipamentos do ERP (ws_equipamento.foto): os nomes de modelo da
                // OLT e do ERP são os mesmos. Só complemento — o que já existia (Mkfiles/base64) vale primeiro.
                if ($b64 === '') { $mp = olt_modelos_foto_erp(); $b64 = (string)($mp[$chave] ?? ''); }
                echo json_encode(['status' => 'ok', 'img' => $b64], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $chaves = array_keys($m);
            foreach (array_keys(olt_modelos_foto_erp()) as $kErp) if (!in_array($kErp, $chaves, true)) $chaves[] = $kErp;
            echo json_encode(['status' => 'ok', 'chaves' => array_values($chaves)], JSON_UNESCAPED_UNICODE); exit;
        }
        echo json_encode(['status' => 'ok', 'saved' => $saved], JSON_UNESCAPED_UNICODE); exit;
    }

    // ============================================================================
    // Mkfiles — GERENCIADOR DE ARQUIVOS (fotos de modelos ONU/ONT, logomarcas, etc.)
    // Grava os arquivos REAIS numa pasta "Mkfiles" DENTRO do addon (fácil de achar);
    // se o FPM não puder gravar lá, cai na pasta de cache gravável. Serve os arquivos
    // por mkfiles_get (usado no <img src>). Upload/del = nível 2; listar/ver = nível 1.
    // ============================================================================
    if ($acao === 'mkfiles_list' || $acao === 'mkfiles_upload' || $acao === 'mkfiles_del' || $acao === 'mkfiles_get') {
        $dir = olt_mkfiles_dir();

        if ($acao === 'mkfiles_get') {
            $nome = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)($_GET['nome'] ?? $_POST['nome'] ?? ''));
            // Procura em TODAS as pastas: a imagem pode estar na nova, na antiga do projeto ou na
            // de cache. Buscar só na de gravação daria 404 em arquivo que existe.
            $p = olt_mkfiles_achar($nome);
            if ($nome === '' || $p === '') { http_response_code(404); echo 'not found'; exit; }
            $mimes = ['png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','webp'=>'image/webp','gif'=>'image/gif','svg'=>'image/svg+xml','pdf'=>'application/pdf'];
            $ext = strtolower(pathinfo($p, PATHINFO_EXTENSION));
            header('Content-Type: ' . ($mimes[$ext] ?? 'application/octet-stream'));
            header('Content-Length: ' . filesize($p));
            header('Cache-Control: private, max-age=300');
            readfile($p); exit;
        }

        header('Content-Type: application/json; charset=utf-8');

        if ($acao === 'mkfiles_upload') {
            $nome = preg_replace('/[^A-Za-z0-9._ -]/', '_', trim((string)($_POST['nome'] ?? '')));
            $nome = trim(preg_replace('/\s+/', ' ', $nome));
            $img  = (string)($_POST['img'] ?? '');
            if ($nome === '' || !preg_match('#^data:(image/(png|jpe?g|webp|gif|svg\+xml)|application/pdf);base64,(.+)$#is', $img, $mm)) {
                echo json_encode(['status' => 'error', 'message' => 'Arquivo inválido. Envie PNG, JPEG, WEBP, GIF, SVG ou PDF.']); exit;
            }
            $bin = base64_decode($mm[3], true);
            if ($bin === false || strlen($bin) < 8) { echo json_encode(['status' => 'error', 'message' => 'Arquivo vazio/corrompido.']); exit; }
            if (strlen($bin) > 5 * 1024 * 1024) { echo json_encode(['status' => 'error', 'message' => 'Arquivo maior que 5 MB.']); exit; }
            $ext = (stripos($mm[1], 'png') !== false) ? 'png' : ((stripos($mm[1], 'jpe') !== false) ? 'jpg' : ((stripos($mm[1], 'webp') !== false) ? 'webp' : ((stripos($mm[1], 'gif') !== false) ? 'gif' : ((stripos($mm[1], 'svg') !== false) ? 'svg' : 'pdf'))));
            if (!preg_match('/\.(png|jpe?g|webp|gif|svg|pdf)$/i', $nome)) $nome .= '.' . $ext;
            $nome = str_replace(' ', '_', $nome);
            $r = @file_put_contents($dir . '/' . $nome, $bin);
            if ($r !== false) { @chmod($dir . '/' . $nome, 0666); echo json_encode(['status' => 'ok', 'saved' => true, 'nome' => $nome]); }
            else echo json_encode(['status' => 'error', 'message' => 'Não foi possível gravar na pasta Mkfiles (permissão).']);
            exit;
        }

        if ($acao === 'mkfiles_del') {
            $nome = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)($_POST['nome'] ?? $_GET['nome'] ?? ''));
            /* Apaga em TODAS as pastas. Apagar só na de gravação deixaria a cópia antiga viva, e a
             * leitura (que procura em todas) faria o arquivo "excluído" reaparecer — o operador
             * clicaria em excluir, a imagem voltaria, e ele concluiria que o botão não funciona. */
            if ($nome !== '' && strpos($nome, '..') === false && strpos($nome, '/') === false) {
                foreach (olt_mkfiles_dirs() as $d) { if (is_file($d . '/' . $nome)) @unlink($d . '/' . $nome); }
            }
            echo json_encode(['status' => 'ok', 'saved' => true]); exit;
        }

        /* mkfiles_list — junta as pastas, o mais NOVO de cada nome vence.
         * Listar só a pasta de gravação esconderia o que ainda está nas antigas, e o operador veria
         * a lista vazia com os arquivos existindo no disco. */
        $achados = [];
        foreach (olt_mkfiles_dirs() as $d) {
            foreach ((array)@glob($d . '/*') as $p) {
                if (!is_file($p)) continue;
                $b = basename($p);
                if ($b === '' || $b[0] === '.') continue;
                $ts = (int)@filemtime($p);
                if (isset($achados[$b]) && $achados[$b]['ts'] >= $ts) continue;
                $achados[$b] = ['nome' => $b, 'tam' => (int)@filesize($p), 'ts' => $ts,
                                'ext' => strtolower(pathinfo($p, PATHINFO_EXTENSION))];
            }
        }
        $out = array_values($achados);
        usort($out, function ($a, $b) { return $b['ts'] - $a['ts']; });
        /* `gravavel` vai na resposta para a tela poder AVISAR quando a pasta não aceita escrita, em
         * vez de aceitar o envio e perder o arquivo em silêncio. */
        $testeW = $dir . '/.__w' . getmypid() . mt_rand();
        $gravavel = (@file_put_contents($testeW, 'ok') !== false);
        if ($gravavel) @unlink($testeW);
        echo json_encode(['status' => 'ok', 'dir' => 'Mkfiles', 'caminho' => $dir,
                          'gravavel' => $gravavel, 'arquivos' => $out], JSON_UNESCAPED_UNICODE); exit;
    }

    // ---- META da OLT: apelidos de Placa/Porta e VLAN padrão por porta (item 9) ------
    if ($acao === 'meta_get' || $acao === 'meta_set') {
        $m = olt_jcache_load('olt_meta.json'); if (!is_array($m)) $m = [];   // dual-cache (persiste)
        $saved = null;
        if ($acao === 'meta_set') {
            $grupo = preg_replace('/[^a-z0-9_]/i', '', $_POST['grupo'] ?? $_GET['grupo'] ?? '');
            $chave = trim($_POST['chave'] ?? $_GET['chave'] ?? '');
            $valor = trim($_POST['valor'] ?? $_GET['valor'] ?? '');
            $ok = ['placa' => 1, 'porta' => 1, 'portavlan' => 1, 'portazona' => 1, 'portperfil' => 1];
            if (isset($ok[$grupo]) && $chave !== '') {
                if (!isset($m[$grupo]) || !is_array($m[$grupo])) $m[$grupo] = [];
                if ($valor === '') unset($m[$grupo][$chave]); else $m[$grupo][$chave] = substr($valor, 0, 120);
                $w = false; $j = json_encode($m, JSON_UNESCAPED_UNICODE);
                foreach (olt_cache_dirs() as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); if (@file_put_contents($d . '/olt_meta.json', $j) !== false) { @chmod($d . '/olt_meta.json', 0666); $w = true; } }
                $saved = $w;
            }
        }
        echo json_encode(['status' => 'ok', 'meta' => $m, 'saved' => $saved], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- ALERTA PON (queda total) a partir do CACHE — p/ a PÁGINA PRINCIPAL ----------
    // Calcula no servidor (sem falar com a OLT) as PONs 100% caidas (>=3 ONUs), pra o alerta
    // aparecer no topo mesmo com o Gerenciador fechado.
    /* DE ONDE ESTA PÁGINA RODA — abrir olt_huawei.php?acao=diag_origem por cada endereço (IP, domínio,
       /admin...) e comparar. Pasta ou cache diferentes = cópias diferentes do sistema (código e dados
       próprios): o que foi atualizado numa não aparece na outra. Sem senha/credencial na saída. */
    /* "PRIMEIRA VEZ VISTA" DE CADA ONU (base da ordem Recentes e da data de ativação sem registro) — NO SERVIDOR.
       Antes ficava só no navegador (localStorage, separado por endereço): pelo IP começava do zero, todas com a
       mesma data, e "Recentes" não mudava nada. Cada navegador manda o que sabe; fica a MENOR data de cada ONU. */
    if ($acao === 'visto_sync') {
        header('Content-Type: application/json; charset=utf-8');
        $in = json_decode((string)($_POST['vis'] ?? '{}'), true); if (!is_array($in)) $in = [];
        $lk = olt_json_lock('olt_visto');
        $vis = olt_jcache_load('olt_visto.json'); if (!is_array($vis)) $vis = [];
        $mud = false;
        foreach ($in as $k => $ts) {
            $k = substr((string)$k, 0, 60); $ts = (int)$ts;
            if ($k === '' || $ts <= 0 || $ts > (time() + 86400) * 1000) continue;
            if (!isset($vis[$k]) || $ts < (int)$vis[$k]) { $vis[$k] = $ts; $mud = true; }
        }
        if ($mud) olt_jcache_save('olt_visto.json', $vis);
        olt_json_unlock($lk);
        echo json_encode(['status' => 'ok', 'vis' => $vis], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'diag_origem') {
        header('Content-Type: application/json; charset=utf-8');
        $arq = [];
        foreach (['olt_ui.js', 'olt_huawei.php', 'olt_nativo.php'] as $a) { $p = __DIR__ . '/' . $a;
            $arq[$a] = is_file($p) ? ['modificado' => date('Y-m-d H:i:s', (int)filemtime($p)), 'hash' => hash_file('crc32b', $p)] : 'NAO EXISTE'; }
        $aut = olt_jcache_load('olt_autorizacoes.json');
        // TESTE AO VIVO (opcional): &fsp=0/5/8&id=15 -> pede a vez na OLT como operador, roda
        // "display ont info" e mostra espera, erro, perfil lido e o texto bruto (p/ ajustar o parser).
        $teste = null;
        $tf = preg_replace('/[^0-9\/]/', '', (string)($_GET['fsp'] ?? '')); $ti = (string)($_GET['id'] ?? '');
        if ($tf !== '' && ctype_digit($ti) && count(explode('/', $tf)) === 3 && trim((string)$olt_ip) !== '') {
            $GLOBALS['OLT_LOCK_MANUAL'] = 1;
            [$tfr, $tsl, $tpo] = array_map('intval', explode('/', $tf));
            $t0 = microtime(true);
            try {
                $o = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', "interface gpon 0/$tsl", "display ont info $tpo " . (int)$ti], $olt_timeout);
                $raw = (string)($o[3] ?? ''); $dt = parse_ont_detalhe($raw);
                $teste = ['ok' => true, 'segundos' => round(microtime(true) - $t0, 1), 'perfil_linha' => $dt['lineprofile'], 'perfil_servico' => $dt['srvprofile'],
                          'uptime' => $dt['uptime'], 'saida_bruta' => $raw];
            } catch (Exception $e) {
                $teste = ['ok' => false, 'segundos' => round(microtime(true) - $t0, 1), 'erro' => $e->getMessage()];
            }
        }        echo json_encode(['status' => 'ok', 'host' => $_SERVER['HTTP_HOST'] ?? '', 'pasta' => __DIR__, 'cache' => olt_cache_dir(),
            'caches' => olt_cache_dirs(), 'usuario_php' => (function_exists('posix_geteuid') && function_exists('posix_getpwuid') ? (posix_getpwuid(posix_geteuid())['name'] ?? '') : get_current_user()),
            'php' => PHP_VERSION, 'arquivos' => $arq, 'autorizacoes_registradas' => is_array($aut) ? count($aut) : 0,
            'lista_onus_ts' => (function () { $c = olt_cache_load(); return isset($c['ts']) ? date('Y-m-d H:i:s', (int)$c['ts']) : ''; })(),
            'usuario_olt' => (string)$olt_user, 'teste_ao_vivo' => $teste],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
    if ($acao === 'pon_alertas') {
        $c = olt_cache_load();
        $all = [];
        if (!empty($c['slots']) && is_array($c['slots'])) foreach ($c['slots'] as $arr) { if (is_array($arr)) $all = array_merge($all, $arr); }
        $alertas = olt_pon_alertas_e_log($all); // calcula + registra transições no relatório
        /* QUEDAS PELOS ALARMES DA OLT (24/09/2026): "PON CAIU (ENERGIA)" chegava no WhatsApp e o botão Atenção PON não
           pulsava — ele só contava as quedas pela contagem de ONUs (acima). Agora vêm também as do olt_alarmes_estado.json
           (LOS/energia/placa detectados pelos alarmes), só para o botão pulsar e contar. Não mexe na detecção nem no envio. */
        $alarmes = [];
        $af = olt_cache_dir() . '/olt_alarmes_estado.json';
        $aj = is_file($af) ? json_decode((string)@file_get_contents($af), true) : [];
        $jaPon = []; foreach ($alertas as $a) $jaPon[(string)($a['pon'] ?? '')] = 1;
        if (is_array($aj)) foreach ($aj as $v) { if (!is_array($v)) continue;
            $tp = (string)($v['tipo'] ?? ''); $fsp = (string)($v['fsp'] ?? '');
            if ($tp !== 'placa' && ($fsp === '' || isset($jaPon[$fsp]))) continue;
            $alarmes[] = ['onde' => $tp === 'placa' ? ('placa ' . ($v['slot'] ?? '?')) : $fsp, 'tipo' => $tp,
                          'n' => (int)($v['n'] ?? ($v['afet'] ?? 0)), 'tot' => (int)($v['tot'] ?? 0), 'hora' => (string)($v['hora'] ?? '')]; }
        echo json_encode(['status' => 'ok', 'alertas' => $alertas, 'alarmes' => $alarmes, 'idade' => (isset($c['ts']) ? (time() - $c['ts']) : null)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- Histórico de envios + estado da config (janela Atenção PON) ----
    if ($acao === 'notif_log') {
        $cfg = olt_notif_config();
        echo json_encode(['status' => 'ok', 'ativo' => !empty($cfg['ativo']),
            'destinos' => (isset($cfg['destinos']) && is_array($cfg['destinos'])) ? count($cfg['destinos']) : 0,
            'log' => (array)(olt_jcache_load('olt_notif_log.json') ?: [])], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- NOTIFICAÇÕES (Telegram/WhatsApp): ler/salvar config e testar --------------
    if ($acao === 'notif_get' || $acao === 'notif_set') {
        $cfg = olt_jcache_load('olt_notif.json'); if (!is_array($cfg)) $cfg = [];   // dual-cache
        $saved = null;
        if ($acao === 'notif_set') {
            $cfg['ativo']        = (((string)($_POST['ativo'] ?? '')) === '1');
            $cfg['tg_token']     = substr(trim($_POST['tg_token'] ?? ''), 0, 120);
            $cfg['evo_url']      = substr(trim($_POST['evo_url'] ?? ''), 0, 160);
            $cfg['evo_instance'] = substr(trim($_POST['evo_instance'] ?? ''), 0, 160);   // várias, separadas por vírgula
            $cfg['evo_apikey']   = substr(trim($_POST['evo_apikey'] ?? ''), 0, 120);
            $cfg['emails']       = substr(trim($_POST['emails'] ?? ($cfg['emails'] ?? '')), 0, 300);   // e-mails dos avisos (17/11/2026); sem o campo no POST preserva o que já tem
            $cfg['destinos']     = olt_notif_destinos_limpar($_POST['destinos'] ?? '[]');
            $w = false; $j = json_encode($cfg, JSON_UNESCAPED_UNICODE);
            foreach (olt_cache_dirs() as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); if (@file_put_contents($d . '/olt_notif.json', $j) !== false) { @chmod($d . '/olt_notif.json', 0666); $w = true; } }
            $saved = $w;
        }
        /* Tipo do WhatsApp do ERP (Opções → Servidor): a opção "servidor do ERP" desta janela se chama e funciona
           conforme ele — com o WhatsApp COMUM no ERP, nada de API (janela/template) vale aqui também. */
        $erpMeta = false;
        if (defined('WS_CACHE') && is_file(WS_CACHE . '/whatsapp.json')) { $wj = json_decode((string)@file_get_contents(WS_CACHE . '/whatsapp.json'), true); $erpMeta = !empty($wj['meta_oficial']) && !(!empty($wj['hibrido']) && (($wj['rotas']['olt'] ?? 'api') === 'comum')); }   // híbrido: vale a rota dos alertas da OLT
        echo json_encode(['status' => 'ok', 'saved' => $saved, 'erp_meta' => $erpMeta, 'isolada' => (function_exists('ws_edicao_tem') && !ws_edicao_tem('erp')), 'cfg' => [
            'ativo' => !empty($cfg['ativo']), 'tg_token' => $cfg['tg_token'] ?? '', 'emails' => (string)($cfg['emails'] ?? ''),
            'evo_url' => $cfg['evo_url'] ?? '', 'evo_instance' => $cfg['evo_instance'] ?? '', 'evo_apikey' => $cfg['evo_apikey'] ?? '',
            'destinos' => (isset($cfg['destinos']) && is_array($cfg['destinos'])) ? $cfg['destinos'] : [],
        ]], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($acao === 'notif_teste') {
        $saved = olt_notif_config();
        // Usa os valores do POST se vierem (config ainda não salva); senão os já salvos.
        $cfg = [
            'tg_token'     => trim($_POST['tg_token']     ?? ($saved['tg_token']     ?? '')),
            'evo_url'      => trim($_POST['evo_url']      ?? ($saved['evo_url']      ?? '')),
            'evo_instance' => trim($_POST['evo_instance'] ?? ($saved['evo_instance'] ?? '')),
            'evo_apikey'   => trim($_POST['evo_apikey']   ?? ($saved['evo_apikey']   ?? '')),
        ];
        $destinos = isset($_POST['destinos']) ? olt_notif_destinos_limpar($_POST['destinos']) : ((isset($saved['destinos']) && is_array($saved['destinos'])) ? $saved['destinos'] : []);
        $msg = '✅ Teste do monitor OLT — se você recebeu esta mensagem, as notificações estão funcionando. (' . date('d/m/Y H:i') . ')';
        $out = [];
        foreach ($destinos as $i => $d) { $r = olt_notif_enviar_destino($d, $cfg, $msg); if ($r) $out[$i] = $r; }
        $reT = olt_notif_emails(['emails' => (string)($_POST['emails'] ?? ($saved['emails'] ?? ''))], $msg); if ($reT) $out['email'] = $reT;   // 17/11/2026: o teste também manda o e-mail
        if (!$out) $out['aviso'] = 'Adicione ao menos um destinatário (com os dados do canal) antes de testar.';
        echo json_encode(['status' => 'ok', 'resultado' => $out], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- SEED em LOTE do cadastro (importa do SmartOLT etc.) ------------------
    // POST itens=[{serial, zona, nome, tipo, ...}] . Por padrao PRESERVA o que ja
    // existe (so preenche campo vazio); force=1 sobrescreve. Retorna quantos gravou.
    if ($acao === 'cadastro_seed') {
        $f = olt_cache_dir_g() . '/olt_cadastro.json';
        $cad = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($cad)) $cad = [];
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '', true);
        $force = ((string)($_POST['force'] ?? $_GET['force'] ?? '')) === '1';
        $n = 0; $campos = 0;
        if (is_array($itens)) {
            foreach ($itens as $it) {
                if (!is_array($it)) continue;
                $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $it['serial'] ?? ''));
                if ($sn === '') continue;
                if (!isset($cad[$sn]) || !is_array($cad[$sn])) $cad[$sn] = [];
                $mudou = false;
                foreach ($it as $c => $v) {
                    $c = preg_replace('/[^a-z0-9_]/i', '', (string)$c);
                    if ($c === '' || $c === 'serial') continue;
                    $v = substr(trim((string)$v), 0, 200);
                    if ($v === '') continue;
                    // preserva edicao manual: so grava se vazio (ou force)
                    if ($force || !isset($cad[$sn][$c]) || $cad[$sn][$c] === '') { if (($cad[$sn][$c] ?? '') !== $v) { $cad[$sn][$c] = $v; $campos++; $mudou = true; } }
                }
                if ($mudou) $n++;
            }
            @file_put_contents($f, json_encode($cad, JSON_UNESCAPED_UNICODE));
        }
        // REGISTRA no relatório o espelhamento do SmartOLT (antes não aparecia em Logs).
        if ($n > 0 || $campos > 0) {
            olt_log_registrar('espelho_smartolt', 'Espelhamento SmartOLT — ' . $n . ' ONU(s) atualizada(s), ' . $campos . ' campo(s) gravado(s); base local com ' . count($cad) . ' registro(s)');
        }
        echo json_encode(['status' => 'ok', 'onus_gravadas' => $n, 'campos_gravados' => $campos, 'total' => count($cad)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- RELATORIO / LOG da OLT (eventos + contadores dia/mes) ----------------
    // Leitura: aplica o rollover (zera dia/mes quando vira) e retorna tudo.
    // registrar=1 grava um evento manual (tipo, desc, fsp).
    if ($acao === 'relatorio') {
        if (((string)($_POST['registrar'] ?? $_GET['registrar'] ?? '')) === '1') {
            $tp = preg_replace('/[^a-z_]/i', '', $_POST['tipo'] ?? $_GET['tipo'] ?? 'evento');
            olt_log_registrar($tp, $_POST['desc'] ?? $_GET['desc'] ?? '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        }
        $d = olt_jcache_load('olt_relatorio.json');   // dual-cache
        if (!is_array($d)) $d = [];
        if (!isset($d['eventos']) || !is_array($d['eventos'])) $d['eventos'] = [];
        if (olt_relatorio_rollover($d)) olt_jcache_save('olt_relatorio.json', $d);
        echo json_encode(['status' => 'ok', 'contadores' => $d['contadores'], 'historico_mes' => $d['historico_mes'],
                          'eventos' => array_slice($d['eventos'], 0, 400)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- LIMPAR / ZERAR o relatorio (contadores + eventos + historico) --------
    if ($acao === 'relatorio_limpar') {
        $vazio = ['contadores' => ['dia' => date('Y-m-d'), 'mes' => date('Y-m'),
                      'aprov_dia' => 0, 'aprov_mes' => 0, 'retirada_dia' => 0, 'retirada_mes' => 0],
                  'historico_mes' => [], 'eventos' => []];
        olt_jcache_save('olt_relatorio.json', $vazio); $r = true;
        echo json_encode(['status' => 'ok', 'saved' => ($r !== false),
                          'contadores' => $vazio['contadores'], 'historico_mes' => [], 'eventos' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- SINAL OPTICO EM MASSA (RX/TX de TODAS as ONUs) via Telnet --------
    // Recebe POST itens=[{fsp,id},...]; agrupa por (slot,porta) e roda
    // "display ont optical-info <porta> all" UMA vez por porta ativa (bulk).
    // Fonte 100% OLT (regra dos indicadores). Retorna map fsp|id => {rx,tx}.
    if ($acao === 'optico_massa') {
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '[]', true);
        if (!is_array($itens)) $itens = [];
        // Descobre as portas ativas (0/slot/porta) a consultar
        $portasAtivas = []; // "slot/porta" => [slot,porta]
        foreach ($itens as $it) {
            $p = explode('/', preg_replace('/[^0-9\/]/', '', $it['fsp'] ?? ''));
            if (count($p) !== 3) continue;
            $portasAtivas[$p[1] . '/' . $p[2]] = [(int)$p[1], (int)$p[2]];
        }
        if (empty($portasAtivas)) { echo json_encode(['status' => 'ok', 'sinais' => []]); exit; }

        // Monta os comandos: por slot, entra na interface e roda optical-info all
        // em cada porta ativa daquele slot.
        $porSlot = [];
        foreach ($portasAtivas as $sp) { $porSlot[$sp[0]][] = $sp[1]; }
        $comandos = ['enable', 'config']; $mapaCmd = [];
        foreach ($porSlot as $slot => $portas) {
            $comandos[] = "interface gpon 0/$slot";
            foreach (array_unique($portas) as $pt) {
                $comandos[] = "display ont optical-info $pt all";
                $mapaCmd[count($comandos) - 1] = "0/$slot/$pt";
            }
            $comandos[] = 'quit';
        }
        $sinais = [];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $comandos, $olt_timeout);
        foreach ($mapaCmd as $idx => $fspBase) {
            $sinais += parse_optical_all($out[$idx] ?? '', $fspBase);
        }
        // grava no cache -> proxima abertura ja vem com o sinal (instantaneo)
        if (!empty($sinais)) {
            $sc = olt_jcache_load('olt_sinal_cache.json');
            foreach ($sinais as $k => $v) { $sc[$k] = $v; }
            olt_jcache_save('olt_sinal_cache.json', $sc);
        }
        echo json_encode(['status' => 'ok', 'sinais' => $sinais], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- SNMP: diagnóstico (valida comunidade/porta + mapeamento das PONs) -----
    if ($acao === 'snmp_diag') {
        $s = olt_snmp_cfg();
        // Overrides por URL p/ diagnosticar SEM mudar a config: ?host=192.0.2.23&comm=xxxx&port=2161
        $host = trim((string)($_GET['host'] ?? '')) ?: $s['host'];
        $comm = trim((string)($_GET['comm'] ?? '')) ?: $s['comm'];
        $port = (int)($_GET['port'] ?? 0) ?: $s['port'];
        $sys = olt_snmp_get($host, $port, $comm, '1.3.6.1.2.1.1.1.0');
        // Modo WALK: ?oid=... devolve entradas com ÍNDICE COMPLETO. ?str=1 captura o VALOR como TEXTO
        // (p/ ifName/ifDescr). ?match=onu filtra por substring no valor (achar interfaces de ONU).
        if (!empty($_GET['oid'])) {
            $oid = preg_replace('/[^0-9.]/', '', $_GET['oid']);
            $strMode = !empty($_GET['str']); $match = trim((string)($_GET['match'] ?? ''));
            $bin = olt_snmp_bin('snmpbulkwalk'); if (!$bin) $bin = olt_snmp_bin('snmpwalk');
            $amostra = []; $total = 0;
            if ($bin) {
                $cmd = escapeshellarg($bin) . ' -v2c -t 3 -r 1 -On -c ' . escapeshellarg($comm) . ' ' . escapeshellarg($host . ':' . $port) . ' ' . escapeshellarg($oid) . ' 2>/dev/null';
                $raw = (string)@shell_exec($cmd);
                foreach (explode("\n", $raw) as $ln) {
                    $ln = trim($ln); if ($ln === '') continue; $total++;
                    if ($strMode) {
                        if (preg_match('/^\.?' . preg_quote($oid, '/') . '\.([0-9.]+)\s*=\s*\w*:?\s*"?(.*?)"?\s*$/', $ln, $m)) {
                            if ($match !== '' && stripos($m[2], $match) === false) continue;
                            if (count($amostra) < 16) $amostra[$m[1]] = $m[2];
                        }
                    } else {
                        if (count($amostra) < 16 && preg_match('/^\.?' . preg_quote($oid, '/') . '\.([0-9.]+)\s*=\s*\w*:?\s*(-?\d+)/', $ln, $m)) {
                            $amostra[$m[1]] = $m[2];
                        }
                    }
                }
            }
            echo json_encode(['status' => 'ok', 'host' => $host, 'port' => $port, 'oid' => $oid,
                'total' => $total, 'amostra_indice_completo' => $amostra], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // Erro CRU do snmpget (revela o motivo: "Timeout: No Response" = ACL/rede · "authenticationError" = comunidade)
        $raw = ''; $bin = olt_snmp_bin('snmpget');
        if ($bin) {
            $cmd = escapeshellarg($bin) . ' -v2c -t 2 -r 1 -Oqv -c ' . escapeshellarg($comm) . ' ' . escapeshellarg($host . ':' . $port) . ' 1.3.6.1.2.1.1.1.0 2>&1';
            $raw = trim((string)@shell_exec($cmd));
        }
        $map = olt_snmp_ifmap(($_GET['force'] ?? '') === '1');
        echo json_encode(['status' => 'ok', 'host' => $host, 'port' => $port,
            'comm_ok' => ($comm !== '' && $comm !== 'public'),
            'php_snmp' => function_exists('snmp2_get'), 'snmpget_bin' => ($bin !== ''),
            'sysDescr' => $sys, 'snmpget_raw' => substr($raw, 0, 300),
            'portas_pon_mapeadas' => count($map), 'exemplo' => array_slice($map, 0, 6, true)], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- SNMP: coleta uma amostra e guarda o histórico (roda no cron) ----------
    if ($acao === 'snmp_coletar') {
        $s = olt_snmp_cfg(); if ($s['host'] === '') { echo json_encode(['status' => 'erro', 'msg' => 'OLT sem IP']); exit; }
        $map = olt_snmp_ifmap(); if (!$map) { echo json_encode(['status' => 'erro', 'msg' => 'Nenhuma porta PON mapeada via SNMP (confira comunidade/porta em Conexão da OLT).']); exit; }
        $lastF = olt_cache_dir() . '/olt_snmp_last.json'; $last = is_file($lastF) ? json_decode(@file_get_contents($lastF), true) : []; if (!is_array($last)) $last = [];
        $now = time(); $novo = ['ts' => $now]; $amostra = ['ts' => $now];
        foreach ($map as $fsp => $idx) {
            $in  = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.6.' . $idx);   // ifHCInOctets
            $out = olt_snmp_get($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.10.' . $idx);  // ifHCOutOctets
            if ($in === null || $out === null || !is_numeric($in) || !is_numeric($out)) continue;
            $in = (float)$in; $out = (float)$out; $novo[$fsp] = [$in, $out];
            if (isset($last[$fsp], $last['ts'])) { $dt = $now - (int)$last['ts'];
                if ($dt > 0) { $din = $in - $last[$fsp][0]; $dout = $out - $last[$fsp][1];
                    if ($din >= 0 && $dout >= 0) $amostra[$fsp] = [(int)round($din * 8 / $dt), (int)round($dout * 8 / $dt)]; } }  // bps (down,up)
        }
        @file_put_contents($lastF, json_encode($novo)); @chmod($lastF, 0666);
        if (count($amostra) > 1) { $h = olt_jcache_load('olt_snmp_traf.json'); if (!is_array($h) || isset($h['ts'])) $h = array_values(array_filter($h, 'is_array'));
            // (dual-cache: grava nas 2 pastas e lê a mais nova -> o gráfico da TELA vê o que o CRON coletou)
            $h[] = $amostra; if (count($h) > 288) $h = array_slice($h, -288);   // ~1 dia a cada 5 min
            olt_jcache_save('olt_snmp_traf.json', $h); }
        // ===== TRÁFEGO POR ONU (igual SmartOLT) ============================================
        // Cada ONU é uma interface gpon-onu_f/s/p:id na ifTable, com contadores de octeto. Lê TUDO em 2
        // bulkwalks (rápido) e calcula bps por ONU -> histórico POR CLIENTE. Mesmo método do PON acima.
        $amoOnu = 0;
        $omap = olt_snmp_onumap();
        if ($omap) {
            $inAll  = olt_snmp_walk_full($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.6');    // ifHCInOctets (todas as ifIndex)
            $outAll = olt_snmp_walk_full($s['host'], $s['port'], $s['comm'], '1.3.6.1.2.1.31.1.1.1.10');   // ifHCOutOctets
            if ($inAll && $outAll) {
                $loF = olt_cache_dir() . '/olt_snmp_last_onu.json'; $lo = is_file($loF) ? json_decode(@file_get_contents($loF), true) : []; if (!is_array($lo)) $lo = [];
                $noO = ['ts' => $now]; $amoMap = array();
                foreach ($omap as $key => $ix) {
                    if (!isset($inAll[$ix], $outAll[$ix]) || !is_numeric($inAll[$ix]) || !is_numeric($outAll[$ix])) continue;
                    $in = (float)$inAll[$ix]; $out = (float)$outAll[$ix]; $noO[$key] = [$in, $out];
                    if (isset($lo[$key], $lo['ts'])) { $dt = $now - (int)$lo['ts'];
                        if ($dt > 0) { $din = $in - $lo[$key][0]; $dout = $out - $lo[$key][1];
                            // ONU: ifIn = octetos que ENTRAM na OLT vindo do cliente = UPLOAD; ifOut = DOWNLOAD.
                            if ($din >= 0 && $dout >= 0) $amoMap[$key] = [(int)round($din * 8 / $dt), (int)round($dout * 8 / $dt), $now]; } }  // [up, down, ts]
                }
                @file_put_contents($loF, json_encode($noO)); @chmod($loF, 0666);
                if ($amoMap) { $ho = olt_jcache_load('olt_snmp_traf_onu.json'); if (!is_array($ho)) $ho = array();
                    foreach ($amoMap as $key => $v) { if (!isset($ho[$key]) || !is_array($ho[$key])) $ho[$key] = array(); $ho[$key][] = $v; if (count($ho[$key]) > 288) $ho[$key] = array_slice($ho[$key], -288); }
                    olt_jcache_save('olt_snmp_traf_onu.json', $ho); $amoOnu = count($amoMap); }
            }
        }
        // Coleta TAMBÉM o sinal óptico (Rx/Tx) de todas as ONUs via SNMP -> olt_sinal_cache.json.
        // Roda no mesmo cron; a tela lê do cache (instantâneo, nunca trava).
        $sig = @olt_snmp_sinal_coletar();
        // Tx do GBIC PON NÃO entra aqui: é Telnet (congestiona). Vai no cron pesado (?acao=pon_tx&force=1).
        echo json_encode(['status' => 'ok', 'portas' => count($map), 'amostrado' => count($amostra) - 1,
            'onus_traf' => $amoOnu, 'sinal_onus' => ($sig['ok'] ?? false) ? $sig['onus'] : 0, 'quando' => date('H:i:s')], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- SNMP: histórico de tráfego de UMA ONU (gráfico de banda por CLIENTE, igual SmartOLT) ------
    if ($acao === 'snmp_traf_onu') {
        header('Content-Type: application/json; charset=utf-8');
        $fsp = preg_replace('/[^0-9\/]/', '', $_GET['fsp'] ?? ''); $id = preg_replace('/[^0-9]/', '', $_GET['id'] ?? '');
        $ho = olt_jcache_load('olt_snmp_traf_onu.json'); $key = $fsp . '|' . $id;
        $serie = (is_array($ho) && isset($ho[$key]) && is_array($ho[$key])) ? array_values($ho[$key]) : array();
        echo json_encode(['status' => 'ok', 'serie' => $serie], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- TRÁFEGO POR ONU via TELNET (sob demanda) — igual SmartOLT NESTA OLT (MA5683T não expõe ONU no
    // SNMP). Lê os CONTADORES de bytes do service-port da ONU e calcula bps (Δbytes ÷ tempo). Chamado pelo
    // gráfico do cliente a cada 15s enquanto aberto. O índice do service-port é cacheado (muda raramente).
    if ($acao === 'onu_traf') {
        header('Content-Type: application/json; charset=utf-8');
        $fsp = preg_replace('/[^0-9\/]/', '', $_GET['fsp'] ?? '');
        $oid = preg_replace('/[^0-9]/', '', $_GET['id'] ?? '');
        $pp = explode('/', $fsp);
        if ($fsp === '' || $oid === '' || count($pp) < 3) { echo json_encode(['status' => 'erro', 'msg' => 'fsp/id inválido']); exit; }
        $key = $fsp . '|' . $oid;
        // Histórico JÁ guardado desta ONU — devolvido em TODOS os erros, pra o gráfico mostrar o que tem
        // mesmo se o Telnet falhar agora (não trava mais "Falha ao ler"; só não adiciona o ponto novo).
        $ho0 = olt_jcache_load('olt_onu_traf_hist.json'); $serie0 = (is_array($ho0) && isset($ho0[$key]) && is_array($ho0[$key])) ? array_values($ho0[$key]) : array();
        $idxF = olt_cache_dir() . '/olt_sp_index.json'; $idxC = is_file($idxF) ? json_decode(@file_get_contents($idxF), true) : []; if (!is_array($idxC)) $idxC = [];
        $spi = isset($idxC[$key]) ? (int)$idxC[$key] : 0;
        try {
            if ($spi <= 0) {   // descobre o índice do service-port desta ONU (1x, depois fica em cache)
                $o1 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', 'display service-port port ' . $fsp . ' ont ' . $oid], 8);
                $r1 = is_array($o1) ? implode("\n", $o1) : (string)$o1;
                foreach (explode("\n", $r1) as $ln) { $ln = trim(str_replace("\x00", '', $ln)); if (preg_match('/^(\d+)\s+\d+\s+\S+\s+gpon/i', $ln, $m)) { $spi = (int)$m[1]; break; } }
                if ($spi > 0) { $idxC[$key] = $spi; @file_put_contents($idxF, json_encode($idxC)); @chmod($idxF, 0666); }  // grava JÁ (mesmo que a leitura seguinte estoure o tempo do FPM)
            }
            if ($spi <= 0) { echo json_encode(['status' => 'erro', 'msg' => 'service-port não encontrado (ONU online?)', 'serie' => $serie0]); exit; }
            $o2 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', 'display statistics service-port ' . $spi], 8);
            $r2 = is_array($o2) ? implode("\n", $o2) : (string)$o2;
        } catch (Exception $e) { echo json_encode(['status' => 'ocupado', 'msg' => 'OLT ocupada (Telnet) — tento no próximo ciclo', 'serie' => $serie0]); exit; }
        $ub = null; $db = null;
        if (preg_match('/upstream\s+bytes\s*:\s*(\d+)/i', $r2, $m)) $ub = (float)$m[1];
        if (preg_match('/downstream\s+bytes\s*:\s*(\d+)/i', $r2, $m)) $db = (float)$m[1];
        if ($ub === null || $db === null) { echo json_encode(['status' => 'ocupado', 'msg' => 'sem contadores agora — tento no próximo ciclo', 'serie' => $serie0]); exit; }
        $now = time();
        $lf = olt_cache_dir() . '/olt_onu_traf_last.json'; $lc = is_file($lf) ? json_decode(@file_get_contents($lf), true) : []; if (!is_array($lc)) $lc = [];
        // PRIMEIRA vez desta ONU (sem base p/ calcular): faz uma 2ª leitura rápida (2s) pra JÁ sair 1 ponto de
        // bps AGORA -> o gráfico aparece bem antes (não espera o 2º/3º ciclo do navegador). Só na 1ª vez.
        if (!isset($lc[$key]) || !is_array($lc[$key])) {
            $lc[$key] = [$ub, $db, $now]; usleep(2000000);
            try {
                $o3 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', 'display statistics service-port ' . $spi], 8);
                $r3 = is_array($o3) ? implode("\n", $o3) : (string)$o3;
                $u3 = preg_match('/upstream\s+bytes\s*:\s*(\d+)/i', $r3, $mu) ? (float)$mu[1] : null;
                $d3 = preg_match('/downstream\s+bytes\s*:\s*(\d+)/i', $r3, $md) ? (float)$md[1] : null;
                if ($u3 !== null && $d3 !== null) { $ub = $u3; $db = $d3; $now = time(); }
            } catch (Exception $e) { /* mantém a base; o ponto sai no próximo ciclo */ }
        }
        $up = 0; $down = 0; $temBps = false;
        if (isset($lc[$key]) && is_array($lc[$key])) { $dt = $now - (int)$lc[$key][2];
            // upstream = cliente->OLT = UPLOAD; downstream = OLT->cliente = DOWNLOAD.
            if ($dt > 0 && $dt < 3600) { $dub = $ub - $lc[$key][0]; $ddb = $db - $lc[$key][1];
                if ($dub >= 0 && $ddb >= 0) { $up = (int)round($dub * 8 / $dt); $down = (int)round($ddb * 8 / $dt); $temBps = true; } } }
        $lc[$key] = [$ub, $db, $now]; @file_put_contents($lf, json_encode($lc)); @chmod($lf, 0666);
        $ho = olt_jcache_load('olt_onu_traf_hist.json'); if (!is_array($ho)) $ho = array();
        if ($temBps) { if (!isset($ho[$key]) || !is_array($ho[$key])) $ho[$key] = array(); $ho[$key][] = array($up, $down, $now); if (count($ho[$key]) > 288) $ho[$key] = array_slice($ho[$key], -288); olt_jcache_save('olt_onu_traf_hist.json', $ho); }
        $serie = (isset($ho[$key]) && is_array($ho[$key])) ? array_values($ho[$key]) : array();
        echo json_encode(['status' => 'ok', 'up' => $up, 'down' => $down, 'ts' => $now, 'idx' => $spi, 'serie' => $serie], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- SNMP: coletor de SINAL manual (teste/diagnóstico) --------------------
    if ($acao === 'snmp_sinal') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(olt_snmp_sinal_coletar(), JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- SNMP: Tx do GBIC de cada porta PON (cache olt_pon_tx.json) -----------
    if ($acao === 'pon_tx') {
        header('Content-Type: application/json; charset=utf-8');
        // force=1 (CLI/cron): faz a leitura Telnet e grava o cache. SEM force (navegador): SÓ o cache,
        // NUNCA Telnet — assim a tela é sempre rápida e não "some" o Tx por timeout do FPM (15s).
        if (!empty($_GET['force'])) { echo json_encode(olt_snmp_pon_tx(), JSON_UNESCAPED_UNICODE); exit; }
        $c = olt_jcache_load('olt_pon_tx.json');
        echo json_encode(['ok' => true, 'tx' => (is_array($c) ? $c : array()), 'cache' => true], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- SNMP: histórico de Rx de UMA ONU (gráfico de sinal na janela) --------
    if ($acao === 'snmp_sinal_hist') {
        header('Content-Type: application/json; charset=utf-8');
        $fsp = preg_replace('/[^0-9\/]/', '', $_GET['fsp'] ?? ''); $id = preg_replace('/[^0-9]/', '', $_GET['id'] ?? '');
        $hist = olt_jcache_load('olt_sinal_hist.json');
        if ($fsp !== '' && $id !== '') {   // uma ONU (gráfico na janela)
            $serie = isset($hist['v'][$fsp . '|' . $id]) ? array_map(function ($v) { return round($v / 100, 2); }, $hist['v'][$fsp . '|' . $id]) : [];
            echo json_encode(['status' => 'ok', 'serie' => $serie], JSON_UNESCAPED_UNICODE); exit;
        }
        // TODAS as ONUs (página de grade) — devolve o mapa key => série(dBm). Compacto.
        $v = [];
        foreach (($hist['v'] ?? []) as $k => $arr) { if (is_array($arr) && count($arr) >= 2) $v[$k] = array_map(function ($x) { return round($x / 100, 2); }, $arr); }
        echo json_encode(['status' => 'ok', 'v' => $v], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'olt_temp_hist') {   // histórico de temperatura (gráfico da OLT)
        header('Content-Type: application/json; charset=utf-8');
        $h = olt_jcache_load('olt_temp_hist.json'); if (!isset($h['t'])) $h = ['t' => [], 'ts' => []];
        echo json_encode(['status' => 'ok', 'temp' => $h['t'], 'ts' => $h['ts']], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- #7 AUTORIZAÇÕES POR DIA (do relatório: eventos tipo aprovisionamento) ----
    if ($acao === 'auth_dia') {
        header('Content-Type: application/json; charset=utf-8');
        $d = olt_jcache_load('olt_relatorio.json');   // dual-cache
        $ev = (is_array($d) && isset($d['eventos'])) ? $d['eventos'] : [];
        $cont = array();
        foreach ($ev as $e) {
            if (($e['tipo'] ?? '') !== 'aprovisionamento') continue;
            $dia = substr((string)($e['data'] ?? ''), 0, 10); if ($dia === '') continue;
            $cont[$dia] = ($cont[$dia] ?? 0) + 1;
        }
        ksort($cont); if (count($cont) > 30) $cont = array_slice($cont, -30, null, true);
        echo json_encode(['status' => 'ok', 'dias' => $cont], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- CADASTRO DO CLIENTE NO WELLSYSTEM (pelo serial da ONU) ---------------------------
    // POR QUE EXISTE: o link do Nome/botao Cadastro abria o cadastro ANTIGO (MK-Auth,
    // /admin/cliente_alt.hhvm?uuid=...). O nome e o uuid usados ali vinham de sis_cliente (banco
    // do MK-Auth) e de uma memoria por serial no navegador (localStorage oltClientesMem), que
    // nunca expira — entao ONU reaproveitada continuava apontando para o dono anterior.
    // AQUI a resposta vem do banco do WELLSYSTEM, na hora, e prefere SEMPRE o contrato que nao
    // esta cancelado. Somente leitura.
    if ($acao === 'ws_cliente_sn') {
        header('Content-Type: application/json; charset=utf-8');
        $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)($_GET['sn'] ?? $_POST['sn'] ?? '')));
        if ($sn === '') { echo json_encode(['ok' => false, 'erro' => 'sem serial']); exit; }

        // A pasta do WellSystem: a OLT roda tanto na raiz do addon quanto em olt/.
        $raiz = null;
        foreach ([__DIR__, dirname(__DIR__)] as $d) {
            if (is_file($d . '/config.php') && is_file($d . '/erp.php')) { $raiz = $d; break; }
        }
        if ($raiz === null) { echo json_encode(['ok' => false, 'erro' => 'WellSystem nao encontrado ao lado da OLT']); exit; }

        // Credenciais na MESMA ordem do ws_db_config(): ambiente primeiro (Docker), depois o
        // arquivo de cache e o espelho em /var/tmp. Nao carrega o config.php inteiro de proposito:
        // ele abre sessao, licenca e branding — peso e efeito colateral que este endpoint nao quer.
        $cfg = null;
        if (getenv('WS_DB_HOST')) {
            $cfg = ['host' => getenv('WS_DB_HOST'), 'porta' => (int)(getenv('WS_DB_PORT') ?: 3306),
                    'user' => getenv('WS_DB_USER') ?: 'root', 'pass' => getenv('WS_DB_PASS') ?: '',
                    'dbname' => getenv('WS_DB_NAME') ?: 'wellsystem'];
        } else {
            foreach ([$raiz . '/cache/wellsystem_db.json',
                      '/var/tmp/wellsystem_db_' . substr(md5($raiz), 0, 10) . '.json'] as $arq) {
                if (!is_file($arq)) continue;
                $c = json_decode((string)@file_get_contents($arq), true);
                if (is_array($c) && !empty($c['host'])) { $cfg = $c; break; }
            }
        }
        if (!$cfg) { echo json_encode(['ok' => false, 'erro' => 'config do banco do WellSystem nao encontrada']); exit; }

        try {
            $dsn = 'mysql:host=' . $cfg['host'] . ';port=' . (int)($cfg['porta'] ?? 3306)
                 . ';dbname=' . $cfg['dbname'] . ';charset=utf8mb4';
            $wdb = new PDO($dsn, $cfg['user'], $cfg['pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                 PDO::ATTR_TIMEOUT => 4]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'erro' => 'banco do WellSystem indisponivel']); exit;
        }

        // O serial pode estar em sn_onu, em ont_id ou no login_ipoe (cliente IPoE usa o ID da ONU).
        // Comparacao normalizada (maiuscula, sem separador) porque cada tela gravou de um jeito.
        // ORDER BY: contrato cancelado vai por ULTIMO — e o que fazia a ONU reaproveitada abrir o
        // cadastro do dono anterior.
        $sql = "SELECT ct.id contrato_id, ct.cliente_id, ct.status, c.nome
                FROM ws_contrato ct
                JOIN ws_cliente c ON c.id = ct.cliente_id
                WHERE UPPER(REPLACE(REPLACE(COALESCE(ct.sn_onu,''),':',''),'-','')) = :sn
                   OR UPPER(REPLACE(REPLACE(COALESCE(ct.ont_id,''),':',''),'-','')) = :sn
                   OR UPPER(REPLACE(REPLACE(COALESCE(ct.login_ipoe,''),':',''),'-','')) = :sn
                ORDER BY (COALESCE(ct.status,'') = 'cancelado') ASC, ct.id DESC
                LIMIT 1";
        try {
            $st = $wdb->prepare($sql); $st->execute([':sn' => $sn]); $r = $st->fetch();
        } catch (Throwable $e) { $r = null; }

        if (!$r) { echo json_encode(['ok' => false, 'erro' => 'serial nao vinculado a nenhum cliente']); exit; }
        echo json_encode([
            'ok' => true,
            'cliente_id'  => (int)$r['cliente_id'],
            'contrato_id' => (int)$r['contrato_id'],
            'nome'        => (string)$r['nome'],
            'status'      => (string)$r['status'],
            'url'         => 'erp.php?p=cliente&id=' . (int)$r['cliente_id'],
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ---- #8 AUTORIZAÇÕES (mapa serial -> data/nome/vlan) p/ mostrar a data na tela ----
    if ($acao === 'auth_get') {
        header('Content-Type: application/json; charset=utf-8');
        $out = array();
        // 1) autorizações gravadas pelo app (por SN)
        $f = olt_cache_dir() . '/olt_autorizacoes.json';
        $a = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        foreach ((array)$a as $k => $v) { if (is_array($v)) $out[sn_norm($k)] = array('srv' => (string)(($v['srv_aplicado'] ?? '') !== '' ? $v['srv_aplicado'] : ((int)($v['srvprofile'] ?? 0) > 0 && strpos(olt_perfil_nome_por_id('srv', (int)$v['srvprofile']), 'ID ') !== 0 ? olt_perfil_nome_por_id('srv', (int)$v['srvprofile']) : '')), 'data' => $v['data'] ?? '', 'nome' => $v['nome'] ?? '', 'vlan' => $v['vlan'] ?? '', 'sn' => $v['sn'] ?? $k, 'fsp' => $v['fsp'] ?? ''); }
        // 2) TAMBÉM do relatório: eventos de aprovisionamento trazem "SN — nome (VLAN x) (fsp)".
        $rd = olt_jcache_load('olt_relatorio.json');   // dual-cache
        foreach ((is_array($rd) && isset($rd['eventos'])) ? $rd['eventos'] : array() as $e) {
            if (($e['tipo'] ?? '') !== 'aprovisionamento') continue;
            if (preg_match('/([0-9A-Fa-f]{12,16})/', (string)($e['desc'] ?? ''), $m)) { $kk = sn_norm($m[1]);
                if (!isset($out[$kk])) $out[$kk] = array('data' => substr((string)($e['data'] ?? ''), 0, 16), 'nome' => '', 'vlan' => '', 'sn' => $m[1], 'fsp' => $e['fsp'] ?? ''); }
        }
        echo json_encode(['status' => 'ok', 'autoriz' => $out], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- AUTORIZAÇÃO: preenche a data das ONUs SEM registro com a data de HOJE ----
    // (congelada; roda 1x). Daqui pra frente cada liberação pelo app grava a data real.
    // Recebe 'sns' (JSON array ou lista separada por vírgula) das ONUs exibidas.
    if ($acao === 'auth_backfill') {
        header('Content-Type: application/json; charset=utf-8');
        $hoje = date('Y-m-d');
        $raw = (string)($_POST['sns'] ?? $_GET['sns'] ?? '');
        $lista = json_decode($raw, true);
        if (!is_array($lista)) { $lista = array_filter(array_map('trim', explode(',', $raw))); }
        $f = olt_cache_dir() . '/olt_autorizacoes.json';
        $reg = is_file($f) ? json_decode(@file_get_contents($f), true) : [];
        if (!is_array($reg)) $reg = [];
        $n = 0;
        foreach ($lista as $sn) {
            $k = sn_norm($sn); if ($k === '') continue;
            if (!isset($reg[$k]) || !is_array($reg[$k])) $reg[$k] = array('sn' => $sn);
            if (empty($reg[$k]['data'])) { $reg[$k]['data'] = $hoje; $reg[$k]['backfill'] = 1; $n++; }
        }
        if ($n > 0) { @file_put_contents($f, json_encode($reg, JSON_UNESCAPED_UNICODE)); @chmod($f, 0666); }
        echo json_encode(['ok' => true, 'preenchidas' => $n, 'hoje' => $hoje], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- SNMP: histórico p/ os gráficos por PON --------------------------------
    if ($acao === 'snmp_traf_hist') {
        header('Content-Type: application/json; charset=utf-8');
        $h = olt_jcache_load('olt_snmp_traf.json'); if (!is_array($h)) $h = [];   // dual-cache: lê o que o CRON gravou
        echo json_encode(['status' => 'ok', 'hist' => array_values($h)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- PERFIS DE VELOCIDADE (traffic-table da OLT) — estilo SmartOLT ---------
    // 1 comando só (rápido, não varre ONU). CIR=garantido, PIR=máximo. "ref" = quantos
    // service-ports referenciam o perfil (proxy do nº de ONUs, sem varredura pesada).
    if ($acao === 'perfis_veloc') {
        header('Content-Type: application/json; charset=utf-8');
        // CACHE-PRIMEIRO: SEM force, devolve o cache (rápido, tela abre na hora). Com force (ou sem cache),
        // lê da OLT por Telnet e grava o cache. Dado sempre REAL — só a ORDEM muda (cache agora, refina depois).
        if (empty($_GET['force'])) {
            $c = olt_jcache_load('olt_perfis_veloc.json');
            if (is_array($c) && !empty($c)) { echo json_encode(['status' => 'ok', 'perfis' => $c, 'cache' => true], JSON_UNESCAPED_UNICODE); exit; }
        }
        // MA5683T exige parâmetro: "display traffic table ip" sozinho dá "Incomplete command".
        // A forma que lista TODOS os perfis é "display traffic table ip from-index 0".
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display traffic table ip from-index 0'], $olt_timeout);
        $raw = is_array($out) ? implode("\n", $out) : (string)$out;
        $rows = [];
        foreach (explode("\n", $raw) as $ln) {
            $ln = trim(str_replace("\x00", '', $ln));
            if ($ln === '' || !preg_match('/^\d+\s/', $ln)) continue;   // só linhas de dados (começam pelo TID)
            $t = preg_split('/\s+/', $ln);
            if (count($t) < 4) continue;
            $rows[] = ['tid' => $t[0], 'cir' => $t[1], 'pir' => ($t[3] ?? ''), 'ref' => ($t[count($t) - 2] ?? ''), 'name' => $t[count($t) - 1]];
        }
        if ($rows) olt_jcache_save('olt_perfis_veloc.json', $rows);   // grava o cache (real) pra próxima abrir na hora
        echo json_encode(['status' => 'ok', 'perfis' => $rows, 'raw' => $raw, 'cache' => false], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- ALARMES REAIS DA OLT: a TELA lê o cache (rápido); force=1 lê da OLT por Telnet -----------
    if ($acao === 'alarmes') {
        header('Content-Type: application/json; charset=utf-8');
        if (!empty($_GET['force'])) { $al = olt_alarmes_coletar(); echo json_encode(['status' => 'ok', 'al' => array_values($al), 'cache' => false], JSON_UNESCAPED_UNICODE); exit; }
        $c = olt_jcache_load('olt_alarmes.json'); $al = (is_array($c) && isset($c['al'])) ? $c['al'] : array();
        echo json_encode(['status' => 'ok', 'al' => array_values($al), 'ts' => (is_array($c) ? ($c['ts'] ?? 0) : 0), 'cache' => true], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- URL do CADASTRO do cliente (integração com o radius) — salva no SERVIDOR (vale p/ IP e domínio,
    // todos os usuários). Curingas: {uuid} {login} {serial} {ip} {nome}. Persiste no cache_sync. ----------
    if ($acao === 'cad_url_get') {
        header('Content-Type: application/json; charset=utf-8');
        $u = olt_jcache_load('olt_cad_url.json'); echo json_encode(['ok' => true, 'url' => (is_array($u) ? ($u['url'] ?? '') : ''), 'host' => olt_radius_host()], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'cad_url_set') {
        header('Content-Type: application/json; charset=utf-8');
        $u = trim($_POST['url'] ?? $_GET['url'] ?? ''); olt_jcache_save('olt_cad_url.json', ['url' => substr($u, 0, 400)]);
        olt_log_registrar('cad_url', 'URL do cadastro definida: ' . substr($u, 0, 120)); echo json_encode(['ok' => true, 'url' => $u], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- MAPA COMPLETO login->{uuid,nome,ip} do radius (titulares sis_cliente + adicionais sis_adicional).
    // Carregado 1x pela tela -> clique no nome/serial abre INSTANTÂNEO (sem buscar a cada clique). Funciona
    // por IP e por DOMÍNIO (usa o banco direto, não o index.php). Portável (mesma conexão do config.php). ----
    if ($acao === 'clientes_db') {
        header('Content-Type: application/json; charset=utf-8');
        $lk = olt_radius_db(); $out = [];
        if ($lk) {
            $norm = function ($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); };
            $rs = @mysqli_query($lk, "SELECT login, uuid_cliente, nome, nome_res, ip FROM sis_cliente");
            if ($rs) { while ($r = mysqli_fetch_assoc($rs)) { $k = $norm($r['login'] ?? ''); if ($k === '') continue; $out[$k] = ['uuid' => (string)($r['uuid_cliente'] ?? ''), 'nome' => (string)(!empty($r['nome']) ? $r['nome'] : ($r['nome_res'] ?? '')), 'ip' => (string)($r['ip'] ?? '')]; } }
            $rsa = @mysqli_query($lk, "SELECT a.username, c.uuid_cliente, c.nome, c.nome_res, c.ip FROM sis_adicional a INNER JOIN sis_cliente c ON c.login = a.login");
            if ($rsa) { while ($r = mysqli_fetch_assoc($rsa)) { $k = $norm($r['username'] ?? ''); if ($k === '' || isset($out[$k])) continue; $out[$k] = ['uuid' => (string)($r['uuid_cliente'] ?? ''), 'nome' => (string)(!empty($r['nome']) ? $r['nome'] : ($r['nome_res'] ?? '')), 'ip' => (string)($r['ip'] ?? '')]; } }
        }
        // ---- Vínculo AUTORITATIVO serial->login, via CONTRATO do WellSystem (ws_contrato) --------
        // Sem isto o FRONT assumia sis_cliente.login = serial da ONU (ver olt_login_ws_por_sn acima
        // pro porquê isso dá cliente errado). Devolve normalizado(sn_onu/ont_id/login_ipoe) -> login,
        // pra tela trocar de chave ANTES de ler _loginToIp/_oltClientesDB. Best-effort: se o banco do
        // WellSystem estiver fora, segue sem o vínculo e o front cai no comportamento antigo.
        $sn2login = [];
        if (function_exists('ws_db')) {
            try {
                $wdb = ws_db();
                $rs2 = $wdb->query("SELECT sn_onu, ont_id, login_ipoe, login_pppoe, status FROM ws_contrato
                    WHERE login_pppoe IS NOT NULL AND login_pppoe <> ''
                    ORDER BY (COALESCE(status,'') = 'cancelado') ASC, id DESC");
                if ($rs2) foreach ($rs2 as $c) {
                    $lg = trim((string)($c['login_pppoe'] ?? '')); if ($lg === '') continue;
                    foreach (['sn_onu', 'ont_id', 'login_ipoe'] as $campo) {
                        $k = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)($c[$campo] ?? '')));
                        if ($k !== '' && !isset($sn2login[$k])) $sn2login[$k] = $lg;   // 1º = mais prioritário (ORDER BY acima)
                    }
                }
            } catch (Throwable $e) { /* sem WellSystem agora -> segue só com o mapa antigo (sis_cliente) */ }
        }
        // IP = o da SESSÃO ATUAL (ver olt_ips_vivos), nunca sis_cliente.ip. Offline -> sem IP.
        $vivoOk = false; $vivos = olt_ips_vivos($vivoOk);
        if ($vivoOk) {
            foreach ($out as $k => $v) $out[$k]['ip'] = $vivos[$k] ?? '';
            foreach ($vivos as $k => $ip) if (!isset($out[$k])) $out[$k] = ['uuid' => '', 'nome' => '', 'ip' => $ip];
        }
        echo json_encode(['status' => 'ok', 'clientes' => $out, 'contratos' => $sn2login, 'total' => count($out)], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- RESOLVE o UUID do cliente pelo LOGIN (=serial) direto no banco do radius (sis_cliente). É o que
    // faz o botão Cadastro abrir a ficha certa mesmo na página standalone (não depende do index.php nem do
    // host). Conecta como o config.php (lê o radius de wellsystem_config.json), SEM os echos/HTML dele. ----
    if ($acao === 'cliente_uuid') {
        header('Content-Type: application/json; charset=utf-8');
        $login = trim($_GET['login'] ?? $_POST['login'] ?? '');
        if ($login === '') { echo json_encode(['ok' => false, 'msg' => 'login vazio']); exit; }
        $lk = null;
        foreach ([__DIR__ . '/cache_trafego/wellsystem_config.json', sys_get_temp_dir() . '/acellApp_cache_trafego/wellsystem_config.json'] as $wf) {
            if (!is_file($wf)) continue; $wc = json_decode(@file_get_contents($wf), true);
            if (!is_array($wc) || empty($wc['radius']) || !is_array($wc['radius'])) continue;
            $wi = (int)($wc['radius_ativo'] ?? 0); $wr = $wc['radius'][$wi] ?? ($wc['radius'][0] ?? null);
            if (is_array($wr) && !empty($wr['host'])) { $lk = @mysqli_connect($wr['host'], (string)($wr['user'] ?? 'root'), (string)($wr['pass'] ?? ''), (string)($wr['dbname'] ?? 'mkradius'), (int)($wr['porta'] ?? 3306)); break; }
        }
        if (!$lk && getenv('WS_DB_HOST')) $lk = @mysqli_connect(getenv('WS_DB_HOST'), getenv('WS_DB_USER') ?: 'root', getenv('WS_DB_PASS') ?: '', getenv('WS_DB_NAME') ?: 'mkradius', (int)(getenv('WS_DB_PORT') ?: 3306));
        if (!$lk) $lk = @mysqli_connect('127.0.0.1', 'root', 'vertrigo', 'mkradius');
        if (!$lk) { echo json_encode(['ok' => false, 'msg' => 'sem conexão com o banco do radius']); exit; }
        $sn = trim($_GET['sn'] ?? $_POST['sn'] ?? '');   // serial CRU (hex 16) além do login (formato fabricante)
        $norm = function ($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); };

        // Vínculo AUTORITATIVO (ws_contrato.sn_onu/ont_id/login_ipoe -> login_pppoe). Quando existe,
        // ele vai PRIMEIRO na lista de candidatos: evita cair no login de outro cliente que só por
        // coincidência normaliza igual a esse serial (ver olt_login_ws_por_sn acima pro porquê).
        $loginWs = olt_login_ws_por_sn($sn !== '' ? $sn : $login);

        // casa por QUALQUER formato do serial=login: fabricante (HWTC...), hex cru (4857...) e sem separadores.
        $alvos = array_values(array_unique(array_filter([$norm($login), $norm($sn)])));
        $uuid = ''; $nome = ''; $ip = ''; $loginAchado = '';
        $candidatos = array_values(array_unique(array_filter(array_merge([$loginWs], [$login, $sn]))));
        foreach ($candidatos as $cand) {   // 1) match exato (rápido) — $loginWs (contrato) tem prioridade
            $e = mysqli_real_escape_string($lk, $cand);
            $rs = @mysqli_query($lk, "SELECT uuid_cliente, nome, nome_res, ip FROM sis_cliente WHERE login = '$e' LIMIT 1");
            if ($rs && ($r = mysqli_fetch_assoc($rs))) { $uuid = (string)($r['uuid_cliente'] ?? ''); $nome = (string)(!empty($r['nome']) ? $r['nome'] : ($r['nome_res'] ?? '')); $ip = (string)($r['ip'] ?? ''); $loginAchado = $cand; break; }
        }
        if ($uuid === '') {   // 2) cliente ADICIONAL: username em sis_adicional -> uuid vem do TITULAR (join). Rápido.
            foreach ($candidatos as $cand) {
                $e = mysqli_real_escape_string($lk, $cand);
                $rs2 = @mysqli_query($lk, "SELECT c.uuid_cliente, c.nome, c.nome_res, c.ip FROM sis_adicional a INNER JOIN sis_cliente c ON c.login = a.login WHERE a.username = '$e' LIMIT 1");
                if ($rs2 && ($r = mysqli_fetch_assoc($rs2))) { $uuid = (string)($r['uuid_cliente'] ?? ''); $nome = (string)(!empty($r['nome']) ? $r['nome'] : ($r['nome_res'] ?? '')); $ip = (string)($r['ip'] ?? ''); $loginAchado = $cand; break; }
            }
        }
        // IP da SESSÃO ATUAL do login encontrado (o adicional usa a sessão DELE, não o IP do titular).
        $vivoOk = false; $vivos = olt_ips_vivos($vivoOk);
        if ($vivoOk) $ip = ($loginAchado !== '') ? ($vivos[$norm($loginAchado)] ?? '') : '';
        echo json_encode(['ok' => ($uuid !== ''), 'uuid' => $uuid, 'nome' => $nome, 'ip' => $ip, 'host' => olt_radius_host()], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- IP AO VIVO de UMA ONU (Ficha Técnica pergunta na hora de abrir) --------------------
    // Login pelo CONTRATO (olt_login_ws_por_sn) primeiro; sem contrato, tenta login = serial nos dois
    // formatos (hex e fabricante). IP = sessão atual (olt_ips_vivos). Somente leitura.
    if ($acao === 'ip_vivo') {
        header('Content-Type: application/json; charset=utf-8');
        $norm = function ($s) { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s)); };
        $sn = (string)($_GET['sn'] ?? $_POST['sn'] ?? ''); $login = (string)($_GET['login'] ?? $_POST['login'] ?? '');
        $loginWs = olt_login_ws_por_sn($sn !== '' ? $sn : $login);
        $vivoOk = false; $vivos = olt_ips_vivos($vivoOk);
        $cands = $loginWs !== '' ? [$loginWs] : array_values(array_unique(array_filter([$norm($sn), $norm($login)])));
        $ip = ''; $lg = '';
        foreach ($cands as $c) { $k = $norm($c); if ($k !== '' && !empty($vivos[$k])) { $ip = $vivos[$k]; $lg = $c; break; } }
        echo json_encode(['ok' => $vivoOk, 'ip' => $ip, 'login' => ($lg !== '' ? $lg : ($cands[0] ?? '')), 'contrato' => ($loginWs !== '')], JSON_UNESCAPED_UNICODE); exit;
    }
    // ---- CRON: coleta os alarmes ativos + detecta QUEDA/VOLTA de PON (LOS ou energia) e de PLACA ----
    // Chamado pelo olt_monitor.sh (CLI). Alerta IMEDIATO via olt_notificar (funciona com o app fechado).
    // ---- ALERTA DE INFRAESTRUTURA (17/11/2026): o Zabbix (PAUSE nos switches, queda de tráfego do concentrador 1) manda POST {msg} (+ key do cron, ou do próprio servidor)
    // e sai pelo MESMO canal dos avisos da OLT (olt_notificar: Telegram + WhatsApp configurados na janela de notificações). Liga/desliga junto com "ativo" dos avisos.
    if ($acao === 'infra_alerta') {
        header('Content-Type: application/json; charset=utf-8');
        $im = trim((string)($_POST['msg'] ?? ''));
        if ($im === '') { echo json_encode(['status' => 'erro', 'message' => 'mensagem vazia'], JSON_UNESCAPED_UNICODE); exit; }
        $im = function_exists('mb_substr') ? mb_substr($im, 0, 700) : substr($im, 0, 700);
        $ir = olt_notificar($im);
        echo json_encode(['status' => 'ok', 'enviado' => !empty($ir['enviado']), 'motivo' => (string)($ir['motivo'] ?? '')], JSON_UNESCAPED_UNICODE); exit;
    }
    if ($acao === 'alarmes_check') {
        header('Content-Type: application/json; charset=utf-8');
        $r = olt_alarmes_check();
        echo json_encode(['status' => 'ok', 'caidos' => (is_array($r) ? array_keys($r) : [])], JSON_UNESCAPED_UNICODE); exit;
    }

    // ---- MODELO EM LOTE POR PORTA (display ont version <porta> all) ----------
    // MUITO mais rapido: 1 comando por PORTA ativa (~48) no lugar de 1 por ONU (700).
    // Retorna map fsp|id => modelo. Se o comando nao existir, volta vazio (o front
    // cai no detalhe_massa por-ONU). 'saida' traz a 1a porta p/ conferir formato.
    if ($acao === 'versao_massa') {
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '[]', true);
        if (!is_array($itens)) $itens = [];
        $portasAtivas = [];
        foreach ($itens as $it) {
            $p = explode('/', preg_replace('/[^0-9\/]/', '', $it['fsp'] ?? ''));
            if (count($p) !== 3) continue;
            $portasAtivas[$p[1] . '/' . $p[2]] = [(int)$p[1], (int)$p[2]];
        }
        if (empty($portasAtivas)) { echo json_encode(['status' => 'ok', 'modelos' => []]); exit; }
        $porSlot = [];
        foreach ($portasAtivas as $sp) { $porSlot[$sp[0]][] = $sp[1]; }
        $comandos = ['enable', 'config']; $mapaCmd = [];
        foreach ($porSlot as $slot => $portas) {
            $comandos[] = "interface gpon 0/$slot";
            foreach (array_unique($portas) as $pt) { $comandos[] = "display ont version $pt all"; $mapaCmd[count($comandos) - 1] = "0/$slot/$pt"; }
            $comandos[] = 'quit';
        }
        $modelos = []; $primeira = '';
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $comandos, $olt_timeout);
        foreach ($mapaCmd as $idx => $fspBase) {
            if ($primeira === '') $primeira = $out[$idx] ?? '';
            $modelos += parse_versao_all($out[$idx] ?? '', $fspBase);
        }
        // SALVA no cache em disco -> proxima abertura ja vem com o modelo (INSTANTANEO).
        if (!empty($modelos)) {
            $cache = olt_detalhe_cache_load();
            foreach ($modelos as $k => $mdl) {
                $ant = $cache[$k] ?? [];
                $cache[$k] = ['modelo' => $mdl, 'uptime' => $ant['uptime'] ?? '', 'sn' => olt_pos_sn()[$k] ?? '', 'ts' => time()];   // sn = aparelho dono do dado
            }
            olt_detalhe_cache_save($cache);
        }
        echo json_encode(['status' => 'ok', 'modelos' => $modelos, 'saida' => substr($primeira, 0, 1500)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- MODELO EM LOTE (display ont version) -------------------------------
    // Recebe POST itens=[{fsp,id},...]. Consulta SO o modelo (Equipment-ID) por ONU
    // -> comando pequeno (10 linhas), bem mais rapido que o "display ont info".
    // O Bridge/Router e classificado no front pela TABELA de modelo. Cache em disco.
    if ($acao === 'detalhe_massa') {
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '[]', true);
        if (!is_array($itens)) $itens = [];
        $itens = array_slice($itens, 0, 60); // comando leve -> lote maior
        $porSlot = [];
        foreach ($itens as $it) {
            $p = explode('/', preg_replace('/[^0-9\/]/', '', $it['fsp'] ?? ''));
            if (count($p) !== 3) continue;
            $porSlot[(int)$p[1]][] = ['port' => (int)$p[2], 'id' => (int)($it['id'] ?? -1), 'fsp' => $p[0] . '/' . $p[1] . '/' . $p[2]];
        }
        $comandos = ['enable', 'config']; $mapVer = [];
        foreach ($porSlot as $slot => $lst) {
            $comandos[] = "interface gpon 0/$slot";
            foreach ($lst as $x) {
                $comandos[] = "display ont version {$x['port']} {$x['id']}"; $mapVer[count($comandos) - 1] = $x['fsp'] . '|' . $x['id'];
            }
            $comandos[] = 'quit';
        }
        $res = [];
        if (!empty($mapVer)) {
            $out   = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $comandos, $olt_timeout);
            $cache = olt_detalhe_cache_load();
            foreach ($mapVer as $idx => $chave) {
                $raw = $out[$idx] ?? '';
                $modelo = '';
                if     (preg_match('/Equipment-ID\s*:\s*([^\r\n]+?)\s*(?:\r|\n|$)/i', $raw, $m)) $modelo = trim($m[1]);
                elseif (preg_match('/Product-ID\s*:\s*([^\r\n]+?)\s*(?:\r|\n|$)/i', $raw, $m2))  $modelo = trim($m2[1]);
                $res[$chave]['modelo'] = $modelo;
            }
            foreach ($res as $k => $v) {
                $antigo = $cache[$k] ?? [];
                $cache[$k] = ['modelo' => $v['modelo'] ?? '', 'uptime' => $antigo['uptime'] ?? '', 'sn' => olt_pos_sn()[$k] ?? '', 'ts' => time()];
            }
            olt_detalhe_cache_save($cache);
        }
        echo json_encode(['status' => 'ok', 'detalhes' => $res], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- UPTIME EM LOTE (display ont info) — só p/ a pagina visivel -----------
    // O "display ont info" e pesado, entao so rodamos p/ as ONUs que estao na tela.
    if ($acao === 'uptime_massa') {
        $itens = json_decode($_POST['itens'] ?? $_GET['itens'] ?? '[]', true);
        if (!is_array($itens)) $itens = [];
        $itens = array_slice($itens, 0, 25);
        $porSlot = [];
        foreach ($itens as $it) {
            $p = explode('/', preg_replace('/[^0-9\/]/', '', $it['fsp'] ?? ''));
            if (count($p) !== 3) continue;
            $porSlot[(int)$p[1]][] = ['port' => (int)$p[2], 'id' => (int)($it['id'] ?? -1), 'fsp' => $p[0] . '/' . $p[1] . '/' . $p[2]];
        }
        $comandos = ['enable', 'config']; $map = [];
        foreach ($porSlot as $slot => $lst) {
            $comandos[] = "interface gpon 0/$slot";
            foreach ($lst as $x) { $comandos[] = "display ont info {$x['port']} {$x['id']}"; $map[count($comandos) - 1] = $x['fsp'] . '|' . $x['id']; }
            $comandos[] = 'quit';
        }
        $res = [];
        if (!empty($map)) {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $comandos, $olt_timeout);
            $cache = olt_detalhe_cache_load();
            foreach ($map as $idx => $chave) {
                $rawInfo = $out[$idx] ?? '';
                $det = parse_ont_detalhe($rawInfo);
                // MODO real gravado na OLT = service-profile (bilingue EN/PT) -> Bridge/Router
                $srv = '';
                if (preg_match('/(?:Service[\s\-]*profile[\s\-]*name|Nome\s+do\s+perfil\s+de\s+servi\S*)\s*:\s*([^\r\n]+)/i', $rawInfo, $ms)) $srv = trim($ms[1]);
                $modo = olt_srv_tipo($srv); // ONU=Bridge, ONT=Router
                $lprof = $det['lineprofile'] ?? '';
                $res[$chave] = ['uptime' => $det['uptime'], 'srv' => $srv, 'modo' => $modo, 'lineprofile' => $lprof, 'srvprofile' => $det['srvprofile'] ?? ''];
                $ant = $cache[$chave] ?? [];
                // Modelo antigo só é mantido se for do MESMO aparelho (troca de ONU na mesma porta não herda).
                $snPos = olt_pos_sn()[$chave] ?? '';
                if (!olt_det_do_aparelho($ant, $snPos)) $ant['modelo'] = '';
                $cache[$chave] = ['modelo' => $ant['modelo'] ?? '', 'sn' => $snPos, 'uptime' => $det['uptime'],
                                  'srv' => $srv, 'modo' => $modo, 'lineprofile' => $lprof, 'srvprofile' => $det['srvprofile'] ?? '', 'ts' => time()];
            }
            olt_detalhe_cache_save($cache);
        }
        echo json_encode(['status' => 'ok', 'detalhes' => $res], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: varredura ULTRA-RAPIDA (1 comando por placa) ----------------
    //   olt_huawei.php?acao=debug_summary&slot=1
    // Testa qual comando resumo funciona e retorna a saida bruta p/ eu casar o parser.
    if ($acao === 'debug_summary') {
        $slot = (int)($_GET['slot'] ?? 1);
        $cands = [
            "display ont info summary 0/$slot",
            "display ont info 0/$slot summary",
            "display ont info summary 0/$slot/0",
        ];
        $cmds = ['enable', 'config', "display ont info summary 0/$slot", 'quit'];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, max($olt_timeout, 25));
        $raw = $out[2] ?? '';
        $parsed = parse_ont_summary($raw, $slot);
        $rawClean = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $raw);
        // Linhas que contem o token da porta "0/<slot>/<n>" (cabecalho de secao).
        $linhasFsp = [];
        foreach (preg_split('/\r\n|\r|\n/', $rawClean) as $ln) {
            $ln = trim($ln); if ($ln === '') continue;
            if (preg_match('#(?<![\d.])0\s*/\s*'.$slot.'\s*/\s*\d+\b#', $ln)) { $linhasFsp[] = $ln; if (count($linhasFsp) >= 12) break; }
        }
        // Primeiras 25 linhas nao-vazias (p/ ver a estrutura real do resumo).
        $primLinhas = []; foreach (preg_split('/\r\n|\r|\n/', $rawClean) as $ln) { $ln = rtrim($ln); if (trim($ln) === '') continue; $primLinhas[] = $ln; if (count($primLinhas) >= 25) break; }
        $diag = [
            'PARSER_VERSAO'   => 'v4-diag',
            'tem_porta'       => preg_match_all('/porta/i', $rawClean),
            'porta_contexto'  => (preg_match('/(porta.{0,22})/i', $rawClean, $pc) ? $pc[1] : 'NAO ACHOU'),
            'fsp_detector'    => preg_match_all('#(?<![\d.])0\s*/\s*'.$slot.'\s*/\s*(\d+)\b#', $rawClean, $xf),
            'fsp_linhas'      => $linhasFsp,
            'tab1_matches'    => preg_match_all('/(?:^|\n)\s*(\d{1,3})\s+(online|offline)\s/i', $rawClean, $x2),
            'pcre_erro'       => preg_last_error(),
        ];
        echo json_encode(['status' => 'ok', 'slot' => $slot, 'bytes' => strlen($raw),
                          'onus_parseadas' => count($parsed), 'diag' => $diag,
                          'linhas25' => $primLinhas,
                          'primeiros' => array_slice($parsed, 0, 5)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- DEBUG: saida bruta de comandos por-ONU (p/ fechar Modelo/Bridge) ---
    //   olt_huawei.php?acao=debug_detalhe&fsp=0/3/13&id=20
    if ($acao === 'debug_detalhe') {
        $fsp = preg_replace('/[^0-9\/]/', '', $_GET['fsp'] ?? '');
        $id  = (int)($_GET['id'] ?? -1);
        $p   = explode('/', $fsp);
        if (count($p) !== 3 || $id < 0) { echo json_encode(['status' => 'error', 'message' => 'fsp/id invalidos']); exit; }
        $slot = (int)$p[1]; $port = (int)$p[2];
        $cmds = [
            'enable', 'config', "interface gpon 0/$slot",
            "display ont optical-info $port all",   // sinal em massa (formato)
            "display ont version $port $id",        // modelo/equipment-id
            "display ont info $port $id",           // uptime + detalhes
            "display ont wan-info $port $id",        // bridge vs route
        ];
        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
        echo json_encode(['status' => 'ok', 'comandos' => $cmds, 'saidas' => $out,
                          'parse_optical' => parse_optical_all($out[3] ?? '', "0/$slot/$port")], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- BUSCAR CLIENTE PELO SN (login = SN da ONU) ------------------------
    if ($acao === 'buscar_cliente') {
        $login = trim($_GET['login'] ?? $_POST['login'] ?? '');
        if ($login === '') { echo json_encode(['status' => 'error', 'message' => 'Login (SN) do cliente nao informado.']); exit; }

        // O login do cliente É o SN da ONU. Consulta direta na OLT inteira.
        $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $login));
        $bruto = '';
        $ont = buscar_por_sn($olt_ip, $olt_porta, $olt_user, $olt_pass, $sn, $olt_timeout, $bruto);

        // Fallback: alguns firmwares aceitam o SN so na forma hex canonica
        if (!$ont) {
            $snHex = strtoupper(sn_para_hex($login));
            if ($snHex !== '' && $snHex !== $sn) {
                $ont = buscar_por_sn($olt_ip, $olt_porta, $olt_user, $olt_pass, $snHex, $olt_timeout, $bruto);
            }
        }

        if (!$ont) {
            echo json_encode(['status' => 'error', 'message' => 'ONU/ONT com SN "' . htmlspecialchars($login) . '" nao localizada na OLT.']);
            exit;
        }

        // Sinal optico da ONU encontrada
        $partes = explode('/', $ont['fsp']);
        if (count($partes) === 3) {
            $slot = (int)$partes[1];
            $port = (int)$partes[2];
            $cmdOpt = "display ont optical-info $port {$ont['id']}";
            $outOpt = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', "display service-port port 0/$slot/$port ont {$ont['id']}", "interface gpon 0/$slot", $cmdOpt], $olt_timeout);
            // VLAN (service-port) direto da OLT p/ o card VLAN da janela do cliente
            $vlanMap = parse_service_ports($outOpt[2] ?? '');
            $chaveV  = $ont['fsp'] . '|' . $ont['id'];
            if (!empty($vlanMap[$chaveV])) $ont['vlan'] = $vlanMap[$chaveV];
            $sinal = parse_sinal_optico($outOpt[4] ?? '');
            $ont['rx'] = $sinal['rx'];
            $ont['tx'] = $sinal['tx'];
        }

        echo json_encode(['status' => 'ok', 'onu' => $ont], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- LOCALIZAR ONU pelo SN (só leitura, do cache da lista) — usado pelos botões "Ações na OLT" da
    //      ficha do contrato (erp.php/crm.php), que só conhecem o SN/ID da ONU gravado no contrato.
    //      Aceita o SN nos dois formatos (hex 4750… e fabricante GPON…). Devolve fsp + id para as ações. ----
    if ($acao === 'onu_localizar') {
        $alvos = array_values(array_filter(array_map(function ($v) { return olt_sn_chave((string)$v); },
                 [(string)($_GET['sn'] ?? ''), (string)($_GET['ont'] ?? '')])));
        $achou = null; $cc = olt_cache_load();
        if ($alvos && isset($cc['slots']) && is_array($cc['slots'])) {
            foreach ($cc['slots'] as $arr) { if (!is_array($arr)) continue;
                foreach ($arr as $o) { if (in_array(olt_sn_chave($o['serial'] ?? ''), $alvos, true)) { $achou = $o; break 2; } } }
        }
        if (!$achou) { echo json_encode(['status' => 'error', 'message' => 'ONU não encontrada na lista da OLT (SN ' . preg_replace('/[^0-9A-Za-z]/', '', (string)($_GET['sn'] ?? '')) . '). Abra a Gerência OLT e atualize a lista.'], JSON_UNESCAPED_UNICODE); exit; }
        echo json_encode(['status' => 'ok', 'fsp' => (string)($achou['fsp'] ?? ''), 'id' => (string)($achou['id'] ?? ''), 'nome' => (string)($achou['nome'] ?? ''),
                          'estado' => (string)($achou['estado'] ?? $achou['status'] ?? ''), 'srv' => (string)($achou['srv'] ?? ''), 'modelo' => (string)($achou['modelo'] ?? '')], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // =======================================================================
    // ENDPOINTS DO DASHBOARD (recebem fsp=0/slot/porta e id da ONT)
    // =======================================================================

    // Extrai slot/porta do F/S/P recebido (comum a todas as acoes abaixo)
    if (in_array($acao, ['onu_optico', 'onu_vlan', 'onu_trafego', 'onu_acao', 'onu_uptime', 'onu_portas', 'onu_modo', 'onu_trocar_vlan', 'onu_combo', 'generico_migrar', 'onu_desc_smart'], true)) {
        $fsp = preg_replace('/[^0-9\/]/', '', $_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $id  = (int)($_POST['id'] ?? $_GET['id'] ?? -1);
        $p   = explode('/', $fsp);
        if (count($p) !== 3 || $id < 0) {
            echo json_encode(['status' => 'error', 'message' => 'Parametros F/S/P ou ID invalidos.']);
            exit;
        }
        $slot = (int)$p[1];
        $port = (int)$p[2];
        $ifg  = "interface gpon 0/$slot";

        // ---- Tempo online + detalhes (display ont info <porta> <id>) ----
        if ($acao === 'onu_uptime') {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "display ont info $port $id"], $olt_timeout);
            $raw = $out[3] ?? '';
            $det = parse_ont_detalhe($raw);
            // perfil também (o card da ficha atualiza) + guarda a saída bruta p/ diagnóstico do formato desta OLT
            @file_put_contents(olt_cache_dir() . '/olt_ultimo_ont_info.txt', $raw);
            echo json_encode(['status' => 'ok', 'uptime' => $det['uptime'], 'lineprofile' => $det['lineprofile'] ?? '', 'srvprofile' => $det['srvprofile'] ?? '', 'saida' => $raw], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- Trocar modo (Bridge<->Router): muda o ont-srvprofile-id da ONT ----
        if ($acao === 'onu_modo') {
            $sp = (int)($_POST['srvprofile'] ?? $_GET['srvprofile'] ?? 0);
            if ($sp <= 0 || $sp > 4096) { echo json_encode(['status' => 'error', 'message' => 'Srv-profile inválido.']); exit; }
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "ont modify $port $id ont-srvprofile-id $sp"], $olt_timeout);
            $raw = trim(implode("\n", array_slice($out, 3)));
            $sucesso = !preg_match('/Failure|invalid|Parameter\s+error|error|n[aã]o\s+exist/i', $raw);
            echo json_encode(['status' => 'ok', 'sucesso' => $sucesso, 'srvprofile' => $sp, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- MIGRAR PERFIL p/ Generic_1 (uma ONU) — só se for R1/R2 (seguro) ----
        // Fluxo controlado: o front chama ISTO por ONU (uma de cada vez), mostrando
        // progresso. LÊ o perfil atual da ONU; se NÃO casar com o filtro-origem
        // (padrão "R1|R2"), NÃO mexe (migrado=false, motivo=nao_e_alvo). Se casar,
        // aplica ont-lineprofile-id/ont-srvprofile-id do genérico alvo. Idempotente:
        // se já estiver no alvo, também retorna nao_e_alvo (o filtro não casa "Generic").
        if ($acao === 'generico_migrar') {
            // ⛔ BLOQUEIO DE SEGURANÇA (produção): trocar o line/srv-profile de uma ONU JÁ ATIVA com um
            // simples "ont modify" reescreve os GEM/T-CONT e deixa o SERVICE-PORT ÓRFÃO -> DERRUBA O
            // TRÁFEGO (foi o que quebrou ONUs; só voltou com resync no SmartOLT). O SmartOLT faz certo
            // porque desativa, troca o perfil e RECRIA o service-port. Enquanto não temos essa sequência
            // segura, esta ação fica DESATIVADA. O perfil genérico deve ser aplicado só NO APROVISIONAMENTO.
            echo json_encode(['status' => 'error', 'bloqueado' => true,
                'message' => 'DESATIVADO por segurança: trocar o perfil de uma ONU em funcionamento derruba o serviço (o service-port fica órfão). Aplique o genérico apenas no APROVISIONAMENTO da ONU, ou use o SmartOLT para as já ativas.'], JSON_UNESCAPED_UNICODE);
            exit;
            /* --- desabilitado até ter a sequência segura (deactivate + modify + activate + recriar service-port) ---
            $lp = (int)($_POST['lp'] ?? $_GET['lp'] ?? 0);
            $sp = (int)($_POST['sp'] ?? $_GET['sp'] ?? 0);
            $filtro = trim($_POST['origem'] ?? $_GET['origem'] ?? 'R1|R2'); // regex dos perfis a migrar
            $forcar = !empty($_POST['forcar']) || !empty($_GET['forcar']);   // troca manual (1 ONU): aplica sem filtrar
            if ($lp <= 0 || $lp > 4096 || $sp <= 0 || $sp > 4096) { echo json_encode(['status' => 'error', 'message' => 'Perfil-alvo (line/srv) inválido.']); exit; }
            // APLICAÇÃO DIRETA (forçada, filtro vazio ou ".*"): NÃO lê o perfil antes — faz tudo
            // numa SESSÃO SÓ (1 login por ONU). Isso evita esgotar as VTYs em migrações grandes
            // (era a causa do "AUTH_RETRY: nao chegou ao prompt" em lote). Só faz a leitura prévia
            // quando há um filtro REAL de origem (ex.: "R1|R2"), pra respeitar o "só mexe nas que casam".
            $direto = $forcar || $filtro === '' || $filtro === '.*';
            if (!$direto) {
                $outI = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                    ['enable', 'config', $ifg, "display ont info $port $id"], $olt_timeout);
                $det = parse_ont_detalhe($outI[3] ?? '');
                $perfAtual = trim(($det['lineprofile'] ?? '') . ' ' . ($det['srvprofile'] ?? ''));
                if (!preg_match('/' . str_replace('/', '\/', $filtro) . '/i', $perfAtual)) {
                    echo json_encode(['status' => 'ok', 'migrado' => false, 'motivo' => 'nao_e_alvo',
                                      'perfil' => trim(($det['lineprofile'] ?? '-') . '/' . ($det['srvprofile'] ?? '-')),
                                      'fsp' => "0/$slot/$port", 'id' => $id], JSON_UNESCAPED_UNICODE);
                    exit;
                }
            }
            // migra line + srv-profile p/ o genérico (uma sessão)
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "ont modify $port $id ont-lineprofile-id $lp", "ont modify $port $id ont-srvprofile-id $sp"], $olt_timeout);
            $raw = trim(implode("\n", array_slice($out, 3)));
            $sucesso = !preg_match('/Failure|invalid|Parameter\s+error|error|n[aã]o\s+exist/i', $raw);
            if ($sucesso) olt_log_registrar('perfil', "Migrada p/ generico (line $lp / srv $sp)", "0/$slot/$port");
            echo json_encode(['status' => 'ok', 'migrado' => $sucesso, 'de' => isset($det) ? trim(($det['lineprofile'] ?? '-') . '/' . ($det['srvprofile'] ?? '-')) : '',
                              'lp' => $lp, 'sp' => $sp, 'fsp' => "0/$slot/$port", 'id' => $id, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
            exit;
            --- fim do trecho desabilitado --- */
        }

        // ---- GRAVAR descrição no FORMATO SmartOLT numa ONU JÁ provisionada -------
        // Corrige ONUs antigas (aprovisionadas antes do ajuste) pra o SmartOLT ler a ZONA
        // sem resync. Grava NOME_zone_ZONA_descr_NOME_lat_0_long_0_authd_ANO via ont-desc.
        if ($acao === 'onu_desc_smart') {
            $nome = trim($_POST['nome'] ?? $_GET['nome'] ?? '');
            $zona = trim(preg_replace('/["\r\n]+/', ' ', (string)($_POST['zona'] ?? $_GET['zona'] ?? '')));
            if ($nome === '') { echo json_encode(['status' => 'error', 'message' => 'Nome vazio — edite o nome do cliente antes.']); exit; }
            $descSmart = substr($nome . ($zona !== '' ? '_zone_' . $zona : '') . '_descr_' . $nome . '_lat_0_long_0_authd_' . date('Y'), 0, 127);
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "ont modify $port $id ont-desc \"$descSmart\"", "display ont info $port $id"], $olt_timeout);
            $rawMod = $out[3] ?? '';
            $sucesso = !preg_match('/Failure|invalid|Parameter\s+error|error|n[aã]o\s+exist/i', $rawMod);
            if ($sucesso) olt_log_registrar('perfil', "Descrição SmartOLT gravada (zona: " . ($zona !== '' ? $zona : '-') . ")", "0/$slot/$port");
            echo json_encode(['status' => 'ok', 'sucesso' => $sucesso, 'desc' => $descSmart,
                              'zona' => $zona, 'saida' => trim(implode("\n", array_slice($out, 3)))], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- Status das portas LAN da ONU (Port/Type/Speed/Duplex/LinkState) ----
        if ($acao === 'onu_portas') {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "display ont port state $port $id eth-port all"], $olt_timeout);
            echo json_encode(['status' => 'ok', 'saida' => ($out[3] ?? '')], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- Sinal optico: Rx da ONU (entrada), Tx da ONU (saida) e Rx da OLT (retorno) ----
        // Usa "display ont optical-info <porta> all" (parser por POSICAO, confiavel p/ os 3) e
        // pega ESTA ONU pelo id; fallback no comando individual (parser por rotulo).
        if ($acao === 'onu_optico') {
            $outA = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "display ont optical-info $port all"], $olt_timeout);
            $raw = $outA[3] ?? '';
            $mapA = parse_optical_all($raw, "0/$slot/$port");
            $s = $mapA["0/$slot/$port|$id"] ?? null;
            if (!$s || (($s['rx'] ?? '') === '' && ($s['tx'] ?? '') === '')) {
                $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                    ['enable', 'config', $ifg, "display ont optical-info $port $id"], $olt_timeout);
                $raw = $out[3] ?? '';
                $s = parse_sinal_optico($raw);
            }
            echo json_encode(['status' => 'ok', 'rx' => $s['rx'] ?? '', 'tx' => $s['tx'] ?? '',
                'rx_olt' => $s['rx_olt'] ?? '', 'dist' => $s['dist'] ?? '', 'saida' => $raw], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- COMBO: sinal (Rx/Tx/RxOLT/dist) + uptime + portas LAN numa SÓ sessão ---
        // Abre 1 Telnet e roda os 4 displays de uma vez. Substitui as 3-4 chamadas
        // separadas (onu_optico + onu_uptime + onu_portas) que a janela fazia ao abrir
        // — cada uma era um login novo. Aqui é login único: janela abre MUITO mais rápido.
        if ($acao === 'onu_combo') {
            $kc = "0/$slot/$port|$id";
            // CACHE por ONU: reabrir a MESMA ONU volta INSTANTÂNEO (mostra o último Status/porta WAN já
            // lido) e a tela atualiza ao vivo em 2º plano. force=1 força leitura nova. TTL 90s.
            if (empty($_GET['force'])) {
                $dc = olt_jcache_load('olt_onu_detalhe.json');
                if (isset($dc[$kc]) && is_array($dc[$kc]) && (time() - (int)($dc[$kc]['ts'] ?? 0)) < 90 && (empty($dc[$kc]['sn']) || olt_det_do_aparelho($dc[$kc], olt_pos_sn()[$kc] ?? ''))) {
                    $r = $dc[$kc]; $r['status'] = 'ok'; $r['cache'] = true; echo json_encode($r, JSON_UNESCAPED_UNICODE); exit;
                }
            }
            /* VÁRIOS OPERADORES: a OLT aceita 1 sessão por vez. Se ela estiver com outro operador, a ficha
               mostra a ÚLTIMA leitura desta ONU feita por QUALQUER usuário (guardada no servidor e presa ao
               serial: troca de aparelho não herda), em vez de "não lido"/girando. */
            try {
                $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                    /* SEM o "optical-info <porta> all" (sinal de TODAS as ONUs da porta, com várias páginas):
                       era a parte que fazia a leitura da ficha falhar — o sinal POR-ONU abaixo é o autoritativo. */
                    ['enable', 'config', $ifg,
                     "display ont optical-info $port $id",              // 3: rx/tx/rx_olt + distância
                     "display ont info $port $id",                      // 4: uptime/perfis/detalhes
                     "display ont port state $port $id eth-port all"],  // 5: portas LAN
                    $olt_timeout);
            } catch (Exception $eC) {
                $snAgora = olt_pos_sn()[$kc] ?? '';
                $dcV = olt_jcache_load('olt_onu_detalhe.json');
                $r = (is_array($dcV) && isset($dcV[$kc]) && is_array($dcV[$kc]) && olt_det_do_aparelho($dcV[$kc], $snAgora)) ? $dcV[$kc] : [];
                $det = olt_detalhe_cache_load(); $dd = (isset($det[$kc]) && olt_det_do_aparelho($det[$kc], $snAgora)) ? $det[$kc] : [];
                if (empty($r['lineprofile']) && !empty($dd['lineprofile'])) $r['lineprofile'] = $dd['lineprofile'];
                if (empty($r['srvprofile'])) $r['srvprofile'] = (string)($dd['srvprofile'] ?? ($dd['srv'] ?? ''));
                if (empty($r['uptime']) && !empty($dd['uptime'])) $r['uptime'] = $dd['uptime'];
                if (!$r) throw $eC;   // nunca lida por ninguém: devolve o erro normal
                $r['status'] = 'ok'; $r['cache'] = true; $r['ocupada'] = true;
                echo json_encode($r, JSON_UNESCAPED_UNICODE); exit;
            }
            $sa = [];
            $si = parse_sinal_optico($out[3] ?? '');
            // PREFERE a leitura POR-ONU ("display ont optical-info porta id") — é a autoritativa e a
            // mesma que o SmartOLT usa. A leitura em LOTE (all, por posição) fica só como fallback.
            $rx = (($si['rx'] ?? '') !== '') ? $si['rx'] : ($sa['rx'] ?? '');
            $tx = (($si['tx'] ?? '') !== '') ? $si['tx'] : ($sa['tx'] ?? '');
            $det = parse_ont_detalhe($out[4] ?? '');
            // perfil não reconhecido no texto desta OLT -> guarda a saída bruta p/ ajustar a leitura (diagnóstico)
            if (($det['lineprofile'] ?? '') === '' && ($det['srvprofile'] ?? '') === '') { foreach (olt_cache_dirs() as $dd) { if (@file_put_contents($dd . '/olt_ultimo_ont_info.txt', '== combo ' . date('Y-m-d H:i:s') . ' ' . $kc . " ==
" . (string)($out[4] ?? '')) !== false) break; } }
            // GRAVA a leitura VIVA no cache de sinal (olt_sinal_cache.json) -> a LISTA passa a mostrar
            // esse valor novo também (antes a janela atualizava mas a lista ficava com o valor velho).
            $rxOlt = $si['rx_olt'] ?? ''; $dist = $si['dist'] ?? '';
            if ($rx !== '' || $tx !== '' || $rxOlt !== '') {
                $k = "0/$slot/$port|$id"; $sc = olt_jcache_load('olt_sinal_cache.json');
                $prev = (isset($sc[$k]) && is_array($sc[$k])) ? $sc[$k] : [];
                $sc[$k] = [
                    'rx'     => ($rx     !== '') ? $rx     : ($prev['rx']     ?? ''),
                    'tx'     => ($tx     !== '') ? $tx     : ($prev['tx']     ?? ''),
                    'rx_olt' => ($rxOlt  !== '') ? $rxOlt  : ($prev['rx_olt'] ?? ''),
                    'dist'   => ($dist   !== '') ? $dist   : ($prev['dist']   ?? ''),
                    'ts'     => time(),
                ];
                olt_jcache_save('olt_sinal_cache.json', $sc);
            }
            $result = ['status' => 'ok', 'rx' => $rx, 'tx' => $tx, 'rx_olt' => $rxOlt, 'dist' => $dist,
                'uptime' => $det['uptime'] ?? '', 'portas' => ($out[5] ?? ''),
                'lineprofile' => $det['lineprofile'] ?? '', 'srvprofile' => $det['srvprofile'] ?? ''];
            // Guarda o detalhe desta ONU pra reabrir instantâneo (dual-cache, mesma pasta do resto).
            $dc = olt_jcache_load('olt_onu_detalhe.json'); if (!is_array($dc)) $dc = [];
            $snKc = olt_pos_sn()[$kc] ?? '';
            $dc[$kc] = array_merge($result, ['ts' => time(), 'sn' => $snKc]);
            olt_jcache_save('olt_onu_detalhe.json', $dc);
            // perfil lido -> cache de detalhe (cache_get entrega à lista de TODOS os operadores)
            if (($result['srvprofile'] ?? '') !== '' || ($result['lineprofile'] ?? '') !== '') {
                $cD = olt_detalhe_cache_load(); $antD = $cD[$kc] ?? [];
                if (!olt_det_do_aparelho($antD, $snKc)) $antD = ['modelo' => ''];
                $srvL = (string)($result['srvprofile'] ?? '');
                $cD[$kc] = array_merge($antD, ['sn' => $snKc, 'lineprofile' => (string)($result['lineprofile'] ?? ''), 'srvprofile' => $srvL,
                    'srv' => $srvL !== '' ? $srvL : ($antD['srv'] ?? ''), 'modo' => $srvL !== '' ? olt_srv_tipo($srvL) : ($antD['modo'] ?? ''), 'ts' => time()]);
                olt_detalhe_cache_save($cD);
            }
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- VLAN / service-port (no modo config, fora da interface gpon) ----
        if ($acao === 'onu_vlan') {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', "display service-port port 0/$slot/$port ont $id"], $olt_timeout);
            echo json_encode(['status' => 'ok', 'saida' => ($out[2] ?? '')], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- Trafego de monitoramento ----
        if ($acao === 'onu_trafego') {
            $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', $ifg, "display ont traffic $port $id"], $olt_timeout);
            echo json_encode(['status' => 'ok', 'saida' => ($out[3] ?? '')], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- Acoes de controle (independentes) ----
        // ---- TROCAR a VLAN da ONU na OLT (reconfigura o service-port) ----
        // Espelha os comandos JA comprovados: descobre os service-ports (como no delete),
        // remove com "undo service-port <idx>" e cria de novo com a nova VLAN (como no autorizar).
        if ($acao === 'onu_trocar_vlan') {
            $novaVlan = (int)($_POST['vlan'] ?? $_GET['vlan'] ?? 0);
            if ($novaVlan < 1 || $novaVlan > 4094) { echo json_encode(['status' => 'error', 'message' => 'VLAN inválida (1..4094).']); exit; }
            $outSp = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                ['enable', 'config', "display service-port port 0/$slot/$port ont $id", 'quit'], $olt_timeout);
            $rawSp = $outSp[2] ?? '';
            $limpo = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $rawSp);
            $limpo = preg_replace('/(\d+\s+\d+\s+(?:common|transparent))/i', "\n$1", $limpo);
            $indices = [];
            foreach (explode("\n", $limpo) as $l) { $l = trim($l); if (preg_match('/^(\d+)\s+\d+\b/', $l, $m)) $indices[] = (int)$m[1]; }
            $indices = array_values(array_unique($indices));
            $cmds = ['enable', 'config'];
            foreach ($indices as $ix) $cmds[] = "undo service-port $ix";
            $rawNew = '';
            if (count($cmds) > 2) {
                $out2 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
                $rawNew = trim(implode("\n", array_slice($out2, 2))) . "\n";
            }
            // cria o novo com o GEM real do line-profile + native-vlan (bridge) — olt_sp_criar()
            $spRes = olt_sp_criar($olt_ip, $olt_porta, $olt_user, $olt_pass, $olt_timeout, $slot, $port, $id, $novaVlan, null, true);   // native-vlan: mesma regra da autorização
            $rawNew .= $spRes['saida'];
            $sucesso = $spRes['ok'];
            if ($sucesso) olt_log_registrar('evento', "VLAN trocada p/ $novaVlan (0/$slot/$port id $id)", "0/$slot/$port");
            // CONFERÊNCIA: relê o service-port na OLT (a tela mostra o que ficou de verdade)
            $rawConf = '';
            try { $oc = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'config', "display service-port port 0/$slot/$port ont $id"], $olt_timeout); $rawConf = (string)($oc[2] ?? ''); } catch (Exception $e) { $rawConf = $e->getMessage(); }
            $confOk = preg_match('/\b' . $novaVlan . '\b/', $rawConf) && !preg_match('/No\s+service\s+virtual\s+port/i', $rawConf);
            echo json_encode(['status' => 'ok', 'sucesso' => $sucesso, 'vlan' => $novaVlan, 'sp_gem' => $spRes['gem'], 'sp_lp' => $spRes['lp'],
                'indices' => $indices, 'conferido' => (bool)$confOk, 'conferencia' => $rawConf, 'sp_log' => $spRes['saida'],
                'saida' => "--- service-ports atuais ---\n" . $rawSp . "\n\n--- undo + novo (VLAN $novaVlan) ---\n" . $rawNew], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($acao === 'onu_acao') {
            $tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? '';

            // DELETE completo: na MA5683T nao se deleta uma ONT com service-port.
            // 1) descobre os indices dos service-ports da ONT;
            // 2) undo service-port <idx> (config) + deactivate + delete (gpon).
            if ($tipo === 'delete') {
                $outSp = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                    ['enable', 'config', "display service-port port 0/$slot/$port ont $id", 'quit'], $olt_timeout);
                $rawSp = $outSp[2] ?? '';
                $limpo = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $rawSp);
                $limpo = preg_replace('/(\d+\s+\d+\s+(?:common|transparent))/i', "\n$1", $limpo); // desgruda
                $indices = [];
                foreach (explode("\n", $limpo) as $l) {
                    $l = trim($l);
                    if (preg_match('/^(\d+)\s+\d+\b/', $l, $m)) $indices[] = (int)$m[1]; // INDEX + VLAN
                }
                $indices = array_values(array_unique($indices));

                $cmds = ['enable', 'config'];
                foreach ($indices as $ix) $cmds[] = "undo service-port $ix";
                $cmds[] = "interface gpon 0/$slot";
                $cmds[] = "ont deactivate $port $id";
                $cmds[] = "ont delete $port $id";
                $out2 = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);

                $rawDel = trim(implode("\n", array_slice($out2, 2)));
                $ultimo = $out2[count($out2) - 1] ?? '';          // saida do "ont delete"
                // IDEMPOTENTE: se a ONU JA nao existe ("The ONT does not exist"), o objetivo
                // (removida) ja foi cumprido -> SUCESSO. So e falha se a OLT recusou de fato.
                $jaSumiu = preg_match('/does\s+not\s+exist|n[aã]o\s+exist|no\s+such|inexisten/i', $ultimo . "\n" . $rawDel);
                $sucesso = $jaSumiu || !preg_match('/Failure|invalid|desconhecid|error/i', $ultimo);
                $raw = "--- service-ports da ONT (indices: " . ($indices ? implode(',', $indices) : 'nenhum') . ") ---\n" . $rawSp
                     . "\n\n--- remocao + delete ---\n" . $rawDel;
                if ($sucesso) {
                    olt_log_registrar('retirada', "ONT removida (0/$slot/$port id $id)", "0/$slot/$port");
                    // REMOVE do CACHE — senão o cache_get "traz de volta" a ONU deletada na lista até o
                    // próximo scan completo (era o "deletei e voltou como se não estivesse deletada").
                    // TRAVA + releitura na hora: sem isso, se o cron_scan estivesse gravando esta
                    // MESMA placa ao mesmo tempo, a exclusão podia ser apagada de volta pelo cron —
                    // exigindo excluir e reaprovisionar várias vezes até "vencer a corrida".
                    $lockDel = olt_json_lock('olt_onus_cache');
                    $cc = olt_cache_load(); $sk = (string)$slot;
                    if (isset($cc['slots'][$sk]) && is_array($cc['slots'][$sk])) {
                        $antes = count($cc['slots'][$sk]);
                        $cc['slots'][$sk] = array_values(array_filter($cc['slots'][$sk], function ($o) use ($slot, $port, $id) {
                            return !((($o['fsp'] ?? '') === "0/$slot/$port") && ((string)($o['id'] ?? '') === (string)$id));
                        }));
                        if (count($cc['slots'][$sk]) !== $antes) olt_cache_save($cc, $lockDel);
                    }
                    olt_json_unlock($lockDel);
                }
                echo json_encode(['status' => 'ok', 'sucesso' => $sucesso,
                                  'comando' => 'undo service-port [' . implode(',', $indices) . '] ; ont deactivate ; ont delete',
                                  'saida' => $raw], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $acoes = [
                'reboot'  => ["ont reset $port $id"],                                  // reiniciar (reboot)
                'resync'  => ["ont deactivate $port $id", "ont activate $port $id"],   // ressincronizar (re-registro)
                'factory' => ["ont factory-restore $port $id"],                        // reset de fabrica
                'block'   => ["ont deactivate $port $id"],                             // bloquear cliente
                'unblock' => ["ont activate $port $id"],                               // liberar cliente
                'delete'  => ["ont deactivate $port $id", "ont delete $port $id"],     // desativa e deleta (MA5683T)
            ];
            if (!isset($acoes[$tipo])) {
                echo json_encode(['status' => 'error', 'message' => 'Acao invalida.']);
                exit;
            }
            $cmds = array_merge(['enable', 'config', $ifg], $acoes[$tipo]);
            $out  = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, $olt_timeout);
            // junta a saida dos comandos de acao (do 4o em diante)
            $raw = trim(implode("\n", array_slice($out, 3)));
            $sucesso = !preg_match('/(Failure|desconhecid|Erro|invalid|error|n[aã]o\s+exist)/i', $raw);
            echo json_encode(['status' => 'ok', 'sucesso' => $sucesso, 'comando' => implode(' ; ', $acoes[$tipo]), 'saida' => $raw], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // ---- DESATIVAR / ATIVAR PORTA PON ou PLACA inteira ----------------------
    // op=deactivate|activate. Alvo: uma PORTA (fsp="0/s/p") ou uma PLACA (slot=s,
    // com a lista de portas em "portas"=0,1,2...). Usa "ont deactivate <p> all"
    // (todas as ONTs da porta). É operação de ALTO IMPACTO — o front confirma antes.
    if ($acao === 'pon_control') {
        header('Content-Type: application/json; charset=utf-8');
        // op -> palavra do comando Huawei. reboot usa "ont reset".
        $opRaw = $_POST['op'] ?? $_GET['op'] ?? '';
        $cmdMap = ['deactivate' => 'deactivate', 'activate' => 'activate', 'reboot' => 'reset'];
        if (!isset($cmdMap[$opRaw])) { echo json_encode(['status' => 'error', 'message' => 'Operação inválida.'], JSON_UNESCAPED_UNICODE); exit; }
        $op = $opRaw; $cmdWord = $cmdMap[$opRaw];
        $fsp  = trim($_POST['fsp'] ?? $_GET['fsp'] ?? '');
        $slotP = trim($_POST['slot'] ?? $_GET['slot'] ?? '');
        $portasP = trim($_POST['portas'] ?? $_GET['portas'] ?? '');

        $cmds = ['enable', 'config']; $alvoDesc = '';
        if ($fsp !== '' && preg_match('#^0/(\d+)/(\d+)$#', $fsp, $mm)) {
            // UMA porta PON
            $sl = (int)$mm[1]; $pt = (int)$mm[2];
            $cmds[] = "interface gpon 0/$sl";
            $cmds[] = "ont $cmdWord $pt all";
            $cmds[] = 'quit';
            $alvoDesc = "Porta PON 0/$sl/$pt";
        } elseif ($slotP !== '' && ctype_digit($slotP)) {
            // PLACA inteira: todas as portas informadas (fallback 0..15)
            $sl = (int)$slotP;
            $ports = [];
            if ($portasP !== '') { foreach (explode(',', $portasP) as $p) { $p = trim($p); if ($p !== '' && ctype_digit($p)) $ports[] = (int)$p; } }
            if (!$ports) $ports = range(0, 15);
            $ports = array_values(array_unique($ports));
            $cmds[] = "interface gpon 0/$sl";
            foreach ($ports as $pt) $cmds[] = "ont $cmdWord $pt all";
            $cmds[] = 'quit';
            $alvoDesc = "Placa $sl (" . count($ports) . " portas)";
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Alvo inválido (informe fsp da porta ou slot da placa).'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $out = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, $cmds, max(12, (int)$olt_timeout));
        $raw = trim(implode("\n", array_slice($out, 2)));
        $sucesso = !preg_match('/(Failure|desconhecid|Erro de|invalid|error)/i', $raw);
        $rot = ($op === 'activate' ? 'ATIVADA' : ($op === 'reboot' ? 'REINICIADA' : 'DESATIVADA'));
        if ($sucesso) olt_log_registrar('evento', $alvoDesc . ' — ' . $rot . ' (todas as ONTs)', $fsp !== '' ? $fsp : ('0/' . $slotP . '/*'));
        echo json_encode(['status' => 'ok', 'sucesso' => $sucesso, 'op' => $op,
            'alvo' => $alvoDesc, 'saida' => $raw], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- LISTAR UM SLOT (varredura fatiada, chamada pela dashboard) ---------
    // A dashboard chama este endpoint uma vez por slot, para nao estourar o
    // tempo limite do servidor web com uma unica requisicao gigante (80 portas).
    // ---- MODO (Bridge/Router) de uma ONU pelo SN — botão "puxar da OLT" da ficha do cliente ----
    // A ficha chamava esta ação, que NÃO existia: o backend caía no final e rodava a VARREDURA
    // COMPLETA da OLT a cada clique (e ainda devolvia erro). Agora: acha a ONU na lista em cache e,
    // se o perfil de serviço ainda não é conhecido, lê só aquela ONU (1 comando).
    // (03/10/2026) ONU Bridge autorizada: o operador responde se o roteador do cliente é comodato e qual modelo.
    if ($acao === 'contrato_roteador') {
        header('Content-Type: application/json; charset=utf-8');
        $db = function_exists('ws_db') ? ws_db() : null; $cid = (int)($_POST['contrato_id'] ?? 0);
        if (!$db || !$cid) { echo json_encode(['ok' => false]); exit; }
        if (($_POST['listar'] ?? '') === '1') {
            $l = []; try { $l = $db->query("SELECT DISTINCT modelo FROM ws_equipamento WHERE COALESCE(modelo,'')<>'' ORDER BY (LOWER(COALESCE(tipo,'')) LIKE '%rot%') DESC, modelo")->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) {}
            echo json_encode(['ok' => true, 'modelos' => $l], JSON_UNESCAPED_UNICODE); exit;
        }
        $com = (string)($_POST['comodato'] ?? '') === '1' ? 1 : 0; $mod = mb_substr(trim((string)($_POST['modelo'] ?? '')), 0, 80);
        $db->prepare("UPDATE ws_contrato SET roteador_comodato=?, roteador_modelo=? WHERE id=?")->execute([$com, $com && $mod !== '' ? $mod : null, $cid]);
        if (function_exists('ws_evento')) { $q = $db->prepare("SELECT cliente_id FROM ws_contrato WHERE id=?"); $q->execute([$cid]); ws_evento($db, (int)$q->fetchColumn(), 'olt', 'Roteador do cliente: ' . ($com ? 'comodato' . ($mod !== '' ? ' (' . $mod . ')' : '') : 'do cliente (não é comodato)') . '.'); }
        echo json_encode(['ok' => true]); exit;
    }
    if ($acao === 'modo_sn') {
        header('Content-Type: application/json; charset=utf-8');
        $snQ = sn_para_hex($_GET['sn'] ?? $_POST['sn'] ?? '');
        if ($snQ === '') { echo json_encode(['status' => 'error', 'message' => 'Informe o SN.']); exit; }
        $achou = null;
        foreach ((array)(olt_cache_load()['slots'] ?? []) as $arr) {
            foreach ((array)$arr as $o) { if (sn_para_hex($o['serial'] ?? '') === $snQ) { $achou = $o; break 2; } }
        }
        if (!$achou) { echo json_encode(['status' => 'error', 'message' => 'SN não encontrado na lista da OLT (a lista é atualizada pelo cron a cada poucos minutos).'], JSON_UNESCAPED_UNICODE); exit; }
        $srv = trim((string)($achou['srv'] ?? ''));
        if ($srv === '') {
            $pp = explode('/', (string)$achou['fsp']);
            if (count($pp) === 3) {
                $outM = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass,
                    ['enable', 'config', 'interface gpon 0/' . (int)$pp[1], 'display ont info ' . (int)$pp[2] . ' ' . (int)$achou['id'], 'quit', 'quit'], $olt_timeout);
                if (preg_match('/(?:Service[\s\-]*profile[\s\-]*name|Nome\s+do\s+perfil\s+de\s+servi\S*)\s*:\s*([^\r\n]+)/i', (string)($outM[3] ?? ''), $mv)) $srv = trim($mv[1]);
            }
        }
        $tipoM = olt_srv_tipo($srv);
        $modoM = $tipoM === 'ONT' ? 'ONT (Router)' : ($tipoM === 'ONU' ? 'ONU (Bridge)' : '');
        echo json_encode(['status' => 'ok', 'modo' => $modoM, 'srvprofile' => $srv, 'fsp' => $achou['fsp'], 'id' => $achou['id']], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- REVARREDURA das placas marcadas (ONU recém-aprovisionada) — chamada pelo cron ----
    // Sem pedido pendente não abre Telnet nenhum. Placa que não respondeu fica para a próxima;
    // pedido com mais de 30 min é descartado (a varredura periódica já cobriu).
    if ($acao === 'rescan_pendente') {
        header('Content-Type: application/json; charset=utf-8');
        $pedidos = olt_jcache_load('olt_rescan_slots.json');
        $slotsP = array_map('intval', array_keys((array)($pedidos['slots'] ?? [])));
        if (!$slotsP) { echo json_encode(['status' => 'ok', 'nada' => true]); exit; }
        $inicio = time(); $brutoP = [];
        $todasP = varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, $slotsP, $faixa_portas, $olt_timeout, $brutoP, false);
        $porSlotP = [];
        foreach ($todasP as $o) { $pp = explode('/', $o['fsp'] ?? ''); if (count($pp) === 3) $porSlotP[(string)(int)$pp[1]][] = $o; }
        if ($porSlotP) {
            // Relê e grava sob trava (olt_cache_merge_slot), pelo mesmo motivo do cron_scan:
            // isto pode rodar ao mesmo tempo que outra tela ou o próprio cron_scan.
            olt_cache_merge_slot((int)array_key_first($porSlotP), null, $porSlotP);
        }
        $atual = olt_jcache_load('olt_rescan_slots.json');
        foreach ((array)($atual['slots'] ?? []) as $sl => $ts) {
            if ((isset($porSlotP[(string)$sl]) && (int)$ts <= $inicio) || (time() - (int)$ts) > 1800) unset($atual['slots'][$sl]);
        }
        olt_jcache_save('olt_rescan_slots.json', ['slots' => (object)($atual['slots'] ?? [])]);
        echo json_encode(['status' => 'ok', 'slots' => array_keys($porSlotP), 'onus' => count($todasP)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($acao === 'listar_slot') {
        $slot = (int)($_GET['slot'] ?? $_POST['slot'] ?? -1);
        if ($slot < 0) { echo json_encode(['status' => 'error', 'message' => 'Slot invalido.']); exit; }
        $noVlan = (((string)($_GET['novlan'] ?? $_POST['novlan'] ?? '')) === '1'); // (B) pula VLAN (usa cache)
        $bruto = [];
        $t0 = microtime(true);
        $todas = varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, [$slot], $faixa_portas, $olt_timeout, $bruto, $noVlan);
        $ms = (int)round((microtime(true) - $t0) * 1000); // cronometragem p/ diagnosticar lentidão
        // grava no cache (por slot) para abertura instantanea depois — relê sob trava (mesmo
        // motivo do cron_scan/autorizar: outra tela ou o cron pode estar gravando ao mesmo tempo)
        olt_cache_merge_slot($slot, $todas ?: null);
        echo json_encode(['status' => 'ok', 'slot' => $slot, 'onus' => $todas, 'ms' => $ms], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- CACHE: lista instantanea a partir do ultimo scan ------------------
    if ($acao === 'cache_get') {
        $c = olt_cache_load();
        $all = [];
        foreach ($c['slots'] as $arr) { if (is_array($arr)) $all = array_merge($all, $arr); }
        $all = olt_dedup($all);
        // Mescla os caches de enriquecimento -> a lista ja vem com modelo/sinal/uptime/estado
        // (abertura INSTANTANEA com TUDO, sem esperar a OLT).
        $det = olt_detalhe_cache_load();
        $sinal = olt_jcache_load('olt_sinal_cache.json');
        $estd  = olt_estado_cache_load();
        foreach ($all as &$o) {
            $k = ($o['fsp'] ?? '') . '|' . ($o['id'] ?? '');
            /* uptime do cache de detalhe é uma FOTO da hora em que a ficha foi aberta ("0d 0h 1min 6s" de dias atrás): só vale se a
               lista não trouxer o tempo calculado da hora de subida (mesma regra da mesclagem acima, 09/11/2026). */
            if (isset($det[$k]) && olt_det_do_aparelho($det[$k], $o['serial'] ?? '')) { if (!empty($det[$k]['modelo'])) $o['modelo'] = $det[$k]['modelo']; if (empty($o['uptime']) && !empty($det[$k]['uptime'])) $o['uptime'] = $det[$k]['uptime']; if (!empty($det[$k]['modo'])) $o['modo'] = $det[$k]['modo']; if (!empty($det[$k]['srv'])) $o['srv'] = $det[$k]['srv']; }
            if (isset($sinal[$k])) { foreach (['rx', 'tx', 'rx_olt', 'dist'] as $cc) { if (!empty($sinal[$k][$cc])) $o[$cc] = $sinal[$k][$cc]; } }
            if (!empty($estd[$k]) && stripos((string)($o['status'] ?? ''), 'online') === false) { $o['estado'] = $estd[$k]; }
        }
        unset($o);
        // Alimenta o gráfico "Status da rede" MESMO sem o cron: registra um ponto
        // a partir da lista em cache (no máx. 1 gravação a cada ~2 min).
        if (!empty($all)) {
            $__hf = olt_cache_dir() . '/olt_hist_last.txt';
            if (!is_file($__hf) || (time() - (int)@file_get_contents($__hf)) > 120) {
                @olt_hist_registrar($all, 0);
                @file_put_contents($__hf, (string)time());
            }
        }
        echo json_encode(['status' => 'ok', 'onus' => $all, 'idade' => ($c['ts'] ? (time() - $c['ts']) : null)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- CACHE: limpa (usado ao iniciar uma nova varredura completa) -------
    if ($acao === 'cache_clear') {
        @unlink(olt_cache_path());
        echo json_encode(['status' => 'ok'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- VARREDURA AUTOMÁTICA p/ CRON (monitoramento 24/7, sem navegador) ----------
    // Varre TODAS as placas, atualiza o cache (por slot) e registra os alertas de PON no
    // relatório. TRAVA (lock) impede sobrepor scans e travar o servidor: se um scan começou
    // há < 4 min, PULA. Ideal: cron a cada 3-5 min chamando este endpoint.
    if ($acao === 'cron_scan') {
        @olt_backup_auto_check();   // BACKUP diário PRIMEIRO — não depende da varredura (que é lenta e pode ser cortada pelo timeout)
        $lock = olt_cache_dir() . '/olt_cron.lock';
        $agora = time();
        if (is_file($lock)) {
            $lt = (int)@file_get_contents($lock);
            if (($agora - $lt) < 240) { echo json_encode(['status' => 'ok', 'pulou' => true, 'motivo' => 'scan recente/em andamento', 'ha_segundos' => $agora - $lt], JSON_UNESCAPED_UNICODE); exit; }
        }
        @file_put_contents($lock, (string)$agora);
        $t0 = microtime(true);
        /* VARREDURA PLACA A PLACA, COM RODÍZIO E GRAVAÇÃO A CADA PLACA.
         *
         * Antes era uma única leitura com TODAS as placas e a gravação só no fim. Numa OLT grande
         * isso passava de 10 minutos; quando o monitor encerrava a etapa no prazo, o trabalho inteiro
         * era perdido e a lista de ONUs ficava PARADA por 40 min ou mais (visto em produção).
         *
         * Agora cada placa é lida e GRAVADA na hora. Se o tempo do ciclo acabar, o que já foi lido
         * está salvo e o próximo ciclo continua da placa onde parou (rodízio pelo cursor). O teto do
         * ciclo é WS_OLT_SCAN_SEG (padrão 420 s), sempre menor que o prazo da etapa no monitor. */
        $limiteCiclo = (int)(getenv('WS_OLT_SCAN_SEG') ?: 420);
        $arqCursor = olt_cache_dir() . '/olt_scan_cursor.txt';
        $cursor = (int)@file_get_contents($arqCursor);
        $slotsOrdem = array_values($faixa_slots);
        sort($slotsOrdem);
        $ini = array_search($cursor, $slotsOrdem, true);
        if ($ini === false) $ini = 0;
        $ordem = array_merge(array_slice($slotsOrdem, $ini), array_slice($slotsOrdem, 0, $ini));

        // NÃO carrega $c uma vez só pra reusar no laço inteiro (o laço leva minutos varrendo
        // placa por placa via Telnet): isso fazia o cron gravar de volta uma FOTO velha do cache
        // e apagar qualquer autorização/edição feita por uma tela enquanto o cron ainda varria.
        // Cada iteração agora relê o cache na hora (via olt_cache_merge_slot), sob trava.
        $lidas = []; $proximo = $slotsOrdem[0] ?? 0;
        /* VLAN (display service-port board) é METADE do trabalho por placa e quase nunca muda: lê no
         * máximo 1x por hora POR PLACA e, no resto do tempo, usa o cache (olt_vlan_cache.json). Assim
         * a volta completa fica bem mais curta sem perder a VLAN de ninguém. */
        $arqVlanTs = olt_cache_dir() . '/olt_vlan_ts.json';
        $vlanTs = is_file($arqVlanTs) ? (json_decode((string)@file_get_contents($arqVlanTs), true) ?: []) : [];
        foreach ($ordem as $i => $slot) {
            $lerVlan = (time() - (int)($vlanTs[(string)$slot] ?? 0)) > 3600;
            $bruto = [];
            $lista = varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, [$slot], $faixa_portas, $olt_timeout, $bruto, !$lerVlan);
            if ($lerVlan) { $vlanTs[(string)$slot] = time(); @file_put_contents($arqVlanTs, json_encode($vlanTs)); }
            $doSlot = [];
            foreach ($lista as $o) {
                $p = explode('/', $o['fsp'] ?? '');
                if (count($p) === 3 && (int)$p[1] === (int)$slot) $doSlot[] = $o;
            }
            // Placa que não respondeu nada NÃO apaga o que já era conhecido dela.
            // Relê o cache do disco (sob trava) e grava só ESTE slot — nada de outro processo
            // (autorização numa aba, outra placa sendo editada) se perde no meio do caminho.
            olt_cache_merge_slot($slot, $doSlot ?: null);   // grava A CADA placa: nada se perde
            $lidas[] = $slot;
            $proximo = $ordem[$i + 1] ?? ($slotsOrdem[0] ?? 0);
            if ((microtime(true) - $t0) > $limiteCiclo) break;   // continua no próximo ciclo
        }
        @file_put_contents($arqCursor, (string)$proximo);

        /* Os alertas de PON olham a OLT INTEIRA: usa a união do cache (placas lidas agora + as últimas
         * conhecidas das demais). Assim uma placa que ficou para o próximo ciclo não vira "PON caiu". */
        $todas = [];
        foreach ($c['slots'] as $arr) { if (is_array($arr)) foreach ($arr as $o) $todas[] = $o; }
        $alertas = olt_pon_alertas_e_log($todas); // calcula + registra quedas/recuperações
        /* VIGIA DE ZONA: ONU autorizada nas últimas 24h cuja zona NA OLT (descrição lida nesta varredura) ficou
           diferente da escolhida na autorização = outro sistema regravou (ex.: SmartOLT com o cadastro antigo
           do serial reaproveitado). Registra no relatório (tipo zona_divergente) 1x por serial+zona — aparece
           em diagnostico_olt.php. Só registra; não altera nada. */
        try {
            $autV = olt_jcache_load('olt_autorizacoes.json'); $vg = olt_jcache_load('olt_zona_vigia.json'); if (!is_array($vg)) $vg = [];
            $nz = function ($z) { return strtoupper(trim(preg_replace('/\s+/', ' ', (string)$z))); };
            $recentes = [];
            foreach ((array)$autV as $ka => $va) { $ts = strtotime((string)($va['data'] ?? '')); if ($ts && strlen((string)($va['data'] ?? '')) > 10 && time() - $ts < 86400 && trim((string)($va['zona'] ?? '')) !== '') $recentes[strtoupper(sn_para_hex($va['sn'] ?? $ka))] = $va; }
            if ($recentes) { $mudouV = false;
                foreach ((array)$todas as $oV) { $kh = strtoupper(sn_para_hex($oV['serial'] ?? '')); if (!isset($recentes[$kh])) continue;
                    $zAut = $recentes[$kh]['zona']; $zOlt = (string)($oV['zona'] ?? '');
                    if ($zOlt === '' || $nz($zOlt) === $nz($zAut)) continue;
                    $chV = $kh . '|' . $nz($zOlt); if (isset($vg[$chV])) continue;
                    $vg[$chV] = time(); $mudouV = true;
                    olt_log_registrar('zona_divergente', ($recentes[$kh]['nome'] ?? $kh) . ' (' . $kh . '): autorizada com zona "' . $zAut . '" — na OLT agora "' . $zOlt . '" (descrição regravada depois da autorização, provável SmartOLT)', (string)($oV['fsp'] ?? ''));
                }
                if ($mudouV) { if (count($vg) > 500) $vg = array_slice($vg, -500, null, true); olt_jcache_save('olt_zona_vigia.json', $vg); }
            }
        } catch (Throwable $eV) {}
        // --- TEMPERATURA: alerta quando >= 39°C (anti-spam: só notifica na virada) ---
        $tempAtual = null;
        $__scu = olt_scu_slot(); $__slot = ($__scu !== null) ? $__scu : 6;
        $tOut = olt_exec($olt_ip, $olt_porta, $olt_user, $olt_pass, ['enable', 'display temperature 0/' . $__slot, 'quit'], $olt_timeout);
        $tv = olt_temp_num($tOut[1] ?? '');   // placa de controle (correta)
        if ($tv !== null) {
            $tempAtual = $tv;
            $tf = olt_cache_dir() . '/olt_temp_estado.json';
            $prev = is_file($tf) ? (json_decode(@file_get_contents($tf), true) ?: []) : [];
            $eraQuente = !empty($prev['quente']); $quente = ($tv >= 39);
            if ($quente && !$eraQuente) {
                olt_log_registrar('temp_alta', "Temperatura ALTA na OLT: {$tv}°C (limite 39°C)");
                olt_notificar("🌡️ ALERTA OLT — TEMPERATURA ALTA\n\n• Placa de controle: {$tv}°C\n• Limite: 39°C\n• Verifique ventilação / refrigeração do rack.");
            } elseif (!$quente && $eraQuente) {
                olt_log_registrar('temp_normal', "Temperatura NORMALIZOU na OLT: {$tv}°C");
                olt_notificar("🌡️ OLT — TEMPERATURA NORMALIZOU\n\n• Placa de controle: {$tv}°C");
            }
            @file_put_contents($tf, json_encode(['quente' => $quente, 'temp' => $tv, 'ts' => time()], JSON_UNESCAPED_UNICODE));
        }
        @olt_hist_registrar($todas, count($alertas));   // ponto horário p/ o gráfico
        @olt_backup_auto_check();   // backup diário por e-mail (se agendado)
        @unlink($lock);
        echo json_encode(['status' => 'ok', 'onus' => count($todas), 'pons_em_queda' => count($alertas),
            'temperatura' => $tempAtual, 'ms' => (int)round((microtime(true) - $t0) * 1000)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Ação desconhecida: responde erro. Antes ela caía aqui embaixo e rodava a VARREDURA COMPLETA
    // da OLT (todas as placas, por Telnet) — um nome de ação errado prendia a OLT por minutos.
    if ($acao !== 'listar_todos') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'Ação desconhecida: ' . substr(preg_replace('/[^\w\-]/', '', (string)$acao), 0, 40)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ---- LISTAR TODOS (varredura completa numa so requisicao) --------------
    // Mantido para compatibilidade/uso direto; a dashboard usa listar_slot.
    $bruto = [];
    $todas = varrer_onts($olt_ip, $olt_porta, $olt_user, $olt_pass, $faixa_slots, $faixa_portas, $olt_timeout, $bruto);
    echo json_encode(['status' => 'ok', 'onus' => $todas], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
}
