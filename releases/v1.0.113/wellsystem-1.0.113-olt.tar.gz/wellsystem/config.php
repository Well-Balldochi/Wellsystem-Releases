<?php
/**
 * WellSystem — Conexão com o banco próprio `wellsystem` (PDO).
 *
 * Ordem de descoberta da conexão (sem hardcode, igual ao padrão do addon OLT):
 *   1) cache/wellsystem_db.json  (gravado pela tela de instalação)
 *   2) variáveis de ambiente WS_DB_HOST/USER/PASS/NAME/PORT (Docker / servidor separado)
 *   3) fallback local (127.0.0.1 / root) — instalação de desenvolvimento
 *
 * A tela nunca guarda credencial no código: o install.php grava o JSON.
 *
 * ------------------------------------------------------------------------------------------
 * MAPA RÁPIDO DO SISTEMA (pra quem for mexer depois):
 * ------------------------------------------------------------------------------------------
 *  - config.php ......... bootstrap: conexão com banco, sessão, helpers globais (h(), ws_dir(),
 *                          ws_ver(), ws_selfheal(), ws_footer_bar(), ws_nav_completo() etc).
 *                          TODO arquivo de tela dá `require __DIR__ . '/config.php'` primeiro.
 *  - erp.php ............ o maior arquivo: dashboard, cadastro de cliente/adicional, contrato/
 *                          conexão, cidades/ramais/bairros, config do sistema (abas).
 *  - financeiro.php ..... faturas/boletos, recebimento, gateway.
 *  - radius.php + radius_lib.php ... usuários RADIUS, bloqueio/desbloqueio, sincronização com
 *                          o FreeRADIUS (radcheck/radreply/radusergroup) e CoA (derrubar sessão).
 *  - olt_erp.php ........ painel de aprovisionamento da OLT (dados do addon `olt/`), respeita
 *                          o ramal selecionado (só busca dado se aquele ramal tiver OLT própria).
 *  - js/wellsystem.js ... TODO o menu superior é remontado em JS (array `groups`) — pra adicionar/
 *                          mover um item de menu, mexe só ali, não precisa tocar no HTML de cada
 *                          página. Também tem as máscaras de campo (CPF/CNPJ/CEP/telefone/R$),
 *                          aplicadas automaticamente pelo NOME/ID do campo (função `aplica()`).
 *  - css/wellsystem.css . visual único de todo o sistema; responsivo em 3 breakpoints (820px,
 *                          520px, 380px) no final do arquivo.
 *  - TROUBLESHOOTING.md . solução dos problemas mais comuns (permissão de pasta, SELinux,
 *                          OPcache, cache do navegador, importação do backup) — abre pelo menu
 *                          Sistema → Ajuda/Docs, aba "TROUBLESHOOTING".
 *
 * PADRÕES usados no código (auto-explicativos, mas documentando aqui pra não se perder):
 *  - `ws_selfheal($db)` roda 1x por request e cria/ajusta colunas/tabelas que faltarem no banco
 *    — é assim que features novas ganham suas colunas sem precisar rodar migração manual.
 *  - Toda pasta que o PHP precisa escrever (cache/, backups/, uploads/) tem fallback automático
 *    pra pasta temporária do servidor se a pasta preferida não puder ser usada — ver
 *    `ws_dir_realmente_gravavel()` e `ws_resolver_cache_dir()`/`ws_resolver_backup_dir()`.
 *  - CSS/JS carregam com `?v=<?= ws_ver('caminho') ?>` (data de modificação do arquivo) — qualquer
 *    edição futura já invalida o cache do navegador sozinha, sem precisar trocar número à mão.
 * ------------------------------------------------------------------------------------------
 */
require_once __DIR__ . '/lixeira_lib.php';   // Recupera Deletado: WsPDO/WsStmt (classes que ws_db() usa) — antes de qualquer conexão

/* COMPATIBILIDADE COM PHP 7.4.
 * O sistema é escrito para PHP 8, mas o Ubuntu 20.04 — base de muitos servidores em produção,
 * inclusive de MK-Auth — entrega 7.4 nos repositórios oficiais. Sem estas três funções, que só
 * existem a partir do 8.0, a instalação morre com "Call to undefined function" em duas telas:
 * backup e documentos. Trocar o PHP do servidor para atender duas chamadas seria desproporcional;
 * definir o que falta custa dez linhas e faz o mesmo código servir aos dois.
 * As implementações são as da própria documentação do PHP. */
if (!function_exists('str_contains')) {
    function str_contains(string $palheiro, string $agulha): bool {
        return $agulha === '' || strpos($palheiro, $agulha) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $palheiro, string $agulha): bool {
        return strncmp($palheiro, $agulha, strlen($agulha)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $palheiro, string $agulha): bool {
        return $agulha === '' || substr($palheiro, -strlen($agulha)) === $agulha;
    }
}

/* COOKIE DE SESSÃO PROTEGIDO (17/11/2026, teste de vulnerabilidade): HttpOnly (JS não lê), Secure quando a página está em HTTPS e SameSite=Lax (mesmo que os navegadores já aplicavam por padrão).
   Mantém o tempo de vida e o path que já valiam. Secure só em HTTPS para o acesso interno por http (se houver) continuar entrando. */
if (session_status() === PHP_SESSION_NONE) {
    $__cp = session_get_cookie_params();
    $__https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https' || (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
    @session_set_cookie_params(['lifetime' => (int)$__cp['lifetime'], 'path' => (string)$__cp['path'], 'secure' => $__https, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

/* LIMITE DE TENTATIVAS DE LOGIN / 2FA / TELA TRAVADA (17/11/2026, teste de vulnerabilidade — antes dava para tentar milhares de senhas por minuto).
   Fora da rede interna: 5 erros em 10 min do MESMO usuário+IP bloqueiam 10 min; 20 erros do mesmo IP bloqueiam 15 min.
   Rede interna/VPN (10/8, 172.16/12, 192.168/16, 100.64/10): só 10 erros usuário+IP em 10 min, bloqueio de 2 min — o time não é atrapalhado.
   Cada erro também espera 0,4 s. Contadores em cache/login_limite.json (sem senha, usuário guardado só como hash). O bloqueio nunca trava a conta:
   vale para aquele IP, então um estranho não consegue deixar o operador de fora. */
if (!function_exists('ws_login_ip')) {
    function ws_login_ip(): string {
        $r = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        $confia = ['127.0.0.1', '::1'];
        try { if (function_exists('ws_espelho_cfg')) { $c = ws_espelho_cfg(); if (!empty($c['par'])) $confia[] = (string)$c['par']; } } catch (Throwable $e) {}
        if (in_array($r, $confia, true) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {   // atrás do proxy do espelho: vale o ÚLTIMO IP (o que o NOSSO proxy acrescentou)
            $l = array_map('trim', explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])); $p = end($l);
            if (filter_var($p, FILTER_VALIDATE_IP)) return $p;
        }
        return $r !== '' ? $r : '-';
    }
    function ws_login_ip_interno(string $ip): bool {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;
        return !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) || (bool)preg_match('/^(100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|127\.|::1$)/', $ip);
    }
    /** Lê, altera ($fn recebe o array por referência) e grava o arquivo de contadores com trava. Falha de disco nunca derruba o login. */
    function ws_login_lim_op(callable $fn) {
        $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/login_limite.json';
        $fp = @fopen($f, 'c+'); if (!$fp) return null;
        try {
            @flock($fp, LOCK_EX);
            $raw = stream_get_contents($fp); $d = json_decode((string)$raw, true); if (!is_array($d)) $d = [];
            $agora = time();
            foreach ($d as $k => $v) {   // poda: janelas vencidas e bloqueios já passados
                if (!is_array($v)) { unset($d[$k]); continue; }
                if (isset($v['ate'])) { if ((int)$v['ate'] <= $agora) unset($d[$k]); continue; }
                $d[$k] = array_values(array_filter($v, fn($t) => (int)$t > $agora - 900)); if (!$d[$k]) unset($d[$k]);
            }
            if (count($d) > 4000) $d = array_slice($d, -2000, null, true);
            $r = $fn($d, $agora);
            ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($d)); fflush($fp);
            return $r;
        } finally { @flock($fp, LOCK_UN); @fclose($fp); @chmod($f, 0640); }
    }
    function ws_login_chave(string $tipo, string $id, string $ip): array {
        $h = substr(hash('sha256', $tipo . '|' . mb_strtolower(trim($id), 'UTF-8')), 0, 20);
        return ['u' => "u:$h:$ip", 'i' => "i:$tipo:$ip"];
    }
    /** Segundos que faltam de bloqueio (0 = pode tentar). $tipo: login | 2fa | trava. */
    function ws_login_bloqueado(string $id, string $tipo = 'login'): int {
        $ip = ws_login_ip(); $k = ws_login_chave($tipo, $id, $ip);
        $r = ws_login_lim_op(function (&$d, $agora) use ($k) {
            $m = 0; foreach (['u', 'i'] as $q) { $b = $d['b:' . $k[$q]]['ate'] ?? 0; if ($b > $agora) $m = max($m, $b - $agora); }
            return $m;
        });
        return (int)$r;
    }
    /** Registra um erro (senha/código errado), espera 0,4 s e aplica o bloqueio quando passar do limite. */
    function ws_login_falha(string $id, string $tipo = 'login'): void {
        $ip = ws_login_ip(); $k = ws_login_chave($tipo, $id, $ip); $int = ws_login_ip_interno($ip);
        ws_login_lim_op(function (&$d, $agora) use ($k, $int, $tipo) {
            foreach (['u', 'i'] as $q) { $d[$k[$q]][] = $agora; }
            $janela = $agora - 600;
            $nu = count(array_filter($d[$k['u']], fn($t) => $t > $janela)); $ni = count(array_filter($d[$k['i']], fn($t) => $t > $janela));
            $limU = $int ? 10 : 5; $limI = $int ? 0 : 20;
            if ($nu >= $limU) $d['b:' . $k['u']] = ['ate' => $agora + ($int ? 120 : 600)];
            if ($limI && $ni >= $limI) $d['b:' . $k['i']] = ['ate' => $agora + 900];
            return null;
        });
        usleep(400000);
        $l = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/login_falhas.log';   // só data, tipo e IP (nunca usuário nem senha); mantém as últimas 300 linhas
        $ls = array_slice(array_filter(explode("\n", (string)@file_get_contents($l))), -299); $ls[] = date('d/m H:i:s') . " $tipo $ip";
        @file_put_contents($l, implode("\n", $ls) . "\n", LOCK_EX); @chmod($l, 0640);
    }
    /** Acertou: zera o contador daquele usuário+IP. */
    function ws_login_ok(string $id, string $tipo = 'login'): void {
        $k = ws_login_chave($tipo, $id, ws_login_ip());
        ws_login_lim_op(function (&$d, $agora) use ($k) { unset($d[$k['u']], $d['b:' . $k['u']]); return null; });
    }
    function ws_login_msg_bloqueio(int $seg): string {
        return 'Muitas tentativas. Aguarde ' . max(1, (int)ceil($seg / 60)) . ' min e tente de novo.';
    }
}

/* PÁGINA ESTÁVEL NA TROCA DE TELA (07/10/2026). Ao navegar, o navegador pintava a tela AOS POUCOS: o topo aparecia pela metade (menu e ícones
   chegando), a tabela esticava a cada linha nova e o JS reajustava colunas depois — "entorta e depois se ajusta". Agora, nas telas
   HTML do sistema, o <head> ganha uma regra que ESCONDE o corpo (visibility:hidden — o layout continua sendo calculado) e o fim do
   <body>, depois de TODOS os scripts de ajuste, ganha a linha que marca a tela como pronta (classe ws-pronto) e a revela de uma vez, já
   organizada. (link rel=expect não serve: Chrome/Edge atuais não o aceitam.) Se o JS falhar, uma animação revela sozinha após 2,5 s.
   Download/JSON/PDF passam sem alteração.
   Nada de buffer grande: devolve em blocos de 1 MB. Ligado só em GET; _auto (recarga automática) e WS_SEM_EXPECT ficam de fora. */
if (PHP_SAPI !== 'cli' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && !defined('WS_SEM_EXPECT') && !isset($_GET['_auto'])
    && !in_array(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')), ['olt_huawei.php', 'img.php', 'anexo.php', 'backup_download.php', 'backup_link.php'], true)) {
    function ws_ob_pagina_estavel(string $b, int $fase = 0): string {
        static $linkOk = false;
        if ($b === '') return $b;
        foreach (headers_list() as $h) if (stripos($h, 'content-type:') === 0 && stripos($h, 'text/html') === false) return $b;   // JSON, PDF, imagem, CSV…
        if (!$linkOk && ($i = strpos($b, '<link rel="stylesheet" href="css/wellsystem.css')) !== false && ($j = strpos($b, '>', $i)) !== false && strpos($b, '</head>') !== false) {
            $b = substr($b, 0, $j + 1) . '<style id="ws-pre">html:not(.ws-pronto) body{visibility:hidden;animation:wsPreFim 0s 2.5s forwards}@keyframes wsPreFim{to{visibility:visible}}</style>' . substr($b, $j + 1); $linkOk = true;
        }
        if ($linkOk && ($p = strripos($b, '</body>')) !== false && strlen($b) - $p < 600 && stripos(substr($b, $p), '</html>') !== false)
            $b = substr($b, 0, $p) . '<script>document.documentElement.classList.add("ws-pronto")</script>' . substr($b, $p);
        return $b;
    }
    ob_start('ws_ob_pagina_estavel', 1048576);
}

/* MYSQLI DEVOLVE FALSE, NÃO LANÇA EXCEÇÃO.
 * A partir do PHP 8.1, o mysqli passou a lançar exceção a cada erro. Todo o código deste sistema
 * que fala com o MK-Auth, com a OLT e com o importador foi escrito para o comportamento anterior:
 * "@mysqli_connect(...)" seguido de "if (!$m) return null" — tentar, falhar em silêncio e seguir
 * sem aquele recurso. E o "@" NÃO suprime exceção: ele só cala aviso.
 *
 * O resultado era página em branco com erro fatal onde deveria haver degradação suave. O caso
 * concreto: no Docker não existe MK-Auth, então o banco "mkradius" não existe — e a tela de
 * Servidores, que só queria saber se ele estava lá, morria com
 * "Uncaught mysqli_sql_exception: Access denied ... to database 'mkradius'" em vez de simplesmente
 * mostrar os dados do WellSystem. No servidor MK-Auth a mesma tela abria normalmente, porque lá o
 * banco existe — o que escondia o problema justamente onde ele não aparecia.
 *
 * Uma linha aqui vale por todas as dezenas de chamadas mysqli do projeto, e devolve a elas o
 * contrato que já tratam corretamente: verificar o retorno. Não se perde tratamento de erro —
 * o tratamento é o que o código já faz, caso a caso. O PDO, usado no banco do próprio WellSystem,
 * continua lançando exceção como sempre: lá o erro precisa mesmo interromper. */
if (function_exists('mysqli_report')) mysqli_report(MYSQLI_REPORT_OFF);

define('WS_DIR', __DIR__);

/* =================================================================================================
 * FUSO HORÁRIO — o PHP segue o relógio DO SERVIDOR, que é o mesmo que o banco usa.
 *
 * O PHP no Linux quase sempre vem em UTC, enquanto o MySQL/MariaDB usa o horário do sistema. Com os
 * dois em fusos diferentes, depois das 21h (UTC-3) o PHP já estava no DIA SEGUINTE: boleto abria com
 * a data de amanhã, "recebido hoje" não batia com o caixa do dia, tempo de sessão saía negativo e
 * "há 5 horas" aparecia em quem tinha acabado de conectar. Nada disso é erro de cálculo: é relógio
 * diferente nos dois lados.
 *
 * Ordem: WS_TZ (se o operador quiser forçar) → fuso do SISTEMA (/etc/timezone ou /etc/localtime, que
 * é o que o MySQL usa) → o que estiver no php.ini → America/Sao_Paulo.
 * ================================================================================================= */
function ws_fuso_detectar(): string {
    $env = (string)getenv('WS_TZ');
    if ($env !== '' && @timezone_open($env)) return $env;
    if (@is_readable('/etc/timezone')) {
        $t = trim((string)@file_get_contents('/etc/timezone'));
        if ($t !== '' && @timezone_open($t)) return $t;
    }
    if (@is_link('/etc/localtime')) {
        $alvo = (string)@readlink('/etc/localtime');
        if (preg_match('~zoneinfo/(.+)$~', $alvo, $m) && @timezone_open($m[1])) return $m[1];
    }
    $ini = (string)@ini_get('date.timezone');
    if ($ini !== '' && @timezone_open($ini)) return $ini;
    return 'America/Sao_Paulo';
}
date_default_timezone_set(ws_fuso_detectar());

/** O pagamento foi recebido HOJE? (regra do estorno: só no mesmo dia; root estorna qualquer dia.)
 *  Confere pelo relógio do PHP E pelo do BANCO: se por algum motivo os dois estiverem em fusos
 *  diferentes, quem recebeu agora continua conseguindo estornar — nunca o contrário. */
function ws_pagto_mesmo_dia(PDO $db, ?string $dataPagamento): bool {
    $d = substr(trim((string)$dataPagamento), 0, 10);
    if ($d === '') return false;
    if ($d === date('Y-m-d')) return true;
    try { return $d === (string)$db->query("SELECT CURDATE()")->fetchColumn(); } catch (Throwable $e) { return false; }
}
// Licença/ativação (proteção anti-cópia): as constantes WS_ATIVACAO_* ficam em licenca.php,
// um arquivo separado que VOCÊ edita para definir/trocar a senha de ativação.
if (is_file(__DIR__ . '/licenca.php')) require_once __DIR__ . '/licenca.php';
// ÂNCORA NO NÚCLEO (fail-closed / anti-adulteração): mesmo que apaguem o licenca.php, a trava
// continua LIGADA e ainda aceita a senha por este fallback — deletar não desliga a proteção.
// (Deletar config.php quebraria o sistema inteiro, então a trava não tem como ser "removida".)
if (!defined('WS_LICENCA_OBRIGATORIA')) define('WS_LICENCA_OBRIGATORIA', true);   // trava sempre exigida
// Contato de aquisição da licença (tela de ativação e avisos de "sistema não ativado").
if (!defined('WS_LICENCA_CONTATO')) define('WS_LICENCA_CONTATO', 'wellington1015@hotmail.com');
if (!defined('WS_LICENCA_FONE'))    define('WS_LICENCA_FONE', '(81) 9.9596-4040');
/* HASH DE RESERVA — sem a senha escrita ao lado, e isso não é detalhe.
 * Aqui havia o comentário "(senha: ...)" logo depois do hash. O hash é seguro e não pode ser
 * revertido; o comentário entregava tudo de graça. Qualquer pessoa que abrisse este arquivo
 * ativava o sistema em qualquer servidor — a proteção existia só no papel.
 * A senha de reserva agora vive FORA do código: com você, no gerador de licenças. */
/* CHAVE PÚBLICA DE ATIVAÇÃO (18/10/2026): o instalador é um só, igual para todos, e leva apenas esta chave PÚBLICA. A primeira tela pede a CHAVE DE
 * ATIVAÇÃO (gerada no gerador, que guarda a chave PRIVADA só com o dono); aqui ela é conferida pela assinatura. A ativação vale para o servidor
 * onde a chave foi digitada. A privada nunca vai no pacote. */
/* Repositório do GitHub (dono/nome) onde o fornecedor publica as Releases assinadas. Vazio = o fornecedor preenche na tela Atualizações (área do fornecedor). */
if (!defined('WS_ATUALIZACAO_REPO')) define('WS_ATUALIZACAO_REPO', 'Well-Balldochi/Wellsystem-Releases');
if (!defined('WS_LICENCA_PUBKEY')) define('WS_LICENCA_PUBKEY', 'KDkfnSEICAFSxQAOxed5iGeBbVcFcv+5itYOsYNEnbE=');
if (!defined('WS_ATIVACAO_HASH_CORE'))  define('WS_ATIVACAO_HASH_CORE', '$2y$10$cHrfYAbt3K49cU0Oz.udquWprFoF138luRHQJAnI3q26FqbbA5CRW');

/**
 * Escolhe a pasta de cache: usa cache/ (padrão) se der pra criar/gravar nela; senão cai
 * automaticamente numa pasta temporária do sistema, sem precisar de nenhuma ação manual no
 * servidor. Isso GARANTE que o sistema funciona mesmo quando o hosting bloqueia a criação de
 * pastas no diretório do addon (comum em painéis tipo MK-Auth com permissão restrita).
 * Aviso: o plano B usa a pasta temp do SO, que ALGUNS servidores limpam de tempos em tempos —
 * o ideal continua sendo corrigir a permissão de verdade (mkdir+chmod) quando for possível.
 */
function ws_resolver_cache_dir(): string {
    $preferida = __DIR__ . '/cache';
    if (ws_dir_realmente_gravavel($preferida)) return $preferida;
    // Plano B: pasta de contingência em /var/tmp, isolada por instalação (hash do caminho).
    // ATENÇÃO — ela NÃO é garantidamente persistente: onde o Apache/PHP-FPM roda com PrivateTmp
    // (padrão no Debian/Ubuntu), o /var/tmp que o PHP enxerga é privado do serviço e é apagado a
    // cada restart. Por isso a configuração do banco não depende desta pasta: ela é procurada
    // também em cache/ e em /var/lib/wellsystem (ver ws_db_config_candidatos).
    $hash = substr(md5(__DIR__), 0, 10);
    foreach (['/var/tmp', rtrim(sys_get_temp_dir(), '/\\'), '/tmp'] as $base) {
        if ($base === '') continue;
        $cand = $base . '/wellsystem_cache_' . $hash;
        if (ws_dir_realmente_gravavel($cand)) { if (!defined('WS_CACHE_FALLBACK')) define('WS_CACHE_FALLBACK', true); return $cand; }
    }
    // Nem isso — devolve a preferida mesmo assim, pra a mensagem de erro apontar pro lugar certo.
    return $preferida;
}
/** Testa se dá pra gravar DE VERDADE numa pasta — não só olha os bits de permissão (is_writable()),
 *  mas tenta criar um arquivo de teste e apagar. Isso pega casos como SELinux/AppArmor, que podem
 *  bloquear a escrita mesmo com chmod 777 + dono certo (comum em servidores CentOS/RHEL com o
 *  SELinux "enforcing" — os bits do Linux dizem que pode, mas o SELinux barra por trás). */
function ws_dir_realmente_gravavel(string $d): bool {
    if (!is_dir($d)) { if (!@mkdir($d, 0777, true)) { $GLOBALS['ws_cache_diag'] = 'não deu pra criar a pasta (sem permissão no diretório pai)'; return false; } @chmod($d, 0777); }
    if (!is_writable($d)) { @chmod($d, 0777); if (!is_writable($d)) { $GLOBALS['ws_cache_diag'] = 'is_writable=false (dono/permissão da pasta)'; return false; } }
    $teste = $d . '/.ws_teste_escrita_' . getmypid();
    $ok = @file_put_contents($teste, 'x');
    if ($ok === false) { $e = error_get_last(); $GLOBALS['ws_cache_diag'] = 'file_put_contents falhou → ' . ($e['message'] ?? 'motivo desconhecido'); return false; }
    @unlink($teste);
    return true;
}
define('WS_CACHE', ws_resolver_cache_dir());
/* PÁGINAS LENTAS (07/10/2026): "tem página lenta pra abrir" — em vez de adivinhar, o sistema se mede. Toda página (não API, não
   CLI) que levar mais de 1,2 s grava UMA linha em cache/paginas_lentas.log: data, arquivo?página, tempo, pico de memória,
   operador e nº de consultas ao banco. Guarda só as últimas 300 linhas. Custo no caminho normal: um microtime() e um
   register_shutdown_function; nada vai ao banco quando a página é rápida. Ler (a mais lenta primeiro; arquivo na pasta cache/):
   sort -t'|' -k3 -nr paginas_lentas.log | head. */
if (PHP_SAPI !== 'cli' && !defined('WS_SEM_MEDICAO')) {
    $GLOBALS['ws_t_ini'] = microtime(true);
    register_shutdown_function(function () {
        $ms = (microtime(true) - ($GLOBALS['ws_t_ini'] ?? microtime(true))) * 1000;
        if ($ms < 1200) return;
        $arq = basename((string)($_SERVER['SCRIPT_NAME'] ?? '?'));
        if (strpos((string)($_SERVER['REQUEST_URI'] ?? ''), '/api/') !== false || in_array($arq, ['cron.php', 'saude_run.php', 'radius_sync.php'], true)) return;
        $q = '?';
        try { if (function_exists('ws_db')) { $r = ws_db()->query("SHOW SESSION STATUS LIKE 'Questions'")->fetch(PDO::FETCH_NUM); $q = (int)($r[1] ?? 0); } } catch (Throwable $e) {}
        $pg = (string)($_GET['p'] ?? ''); $ac = (string)($_GET['acao'] ?? ($_POST['acao'] ?? '')); $f = WS_CACHE . '/paginas_lentas.log';   /* (14/10) inclui a AÇÃO (ex.: olt_huawei.php?acao=listar_slot) — sem ela não dá para saber qual chamada demora */
        $lin = date('d/m H:i:s') . ' | ' . $arq . ($pg !== '' ? '?p=' . preg_replace('/[^\w\-]/', '', $pg) : '') . ($ac !== '' ? '#' . preg_replace('/[^\w\-]/', '', $ac) : '') . ' | ' . (int)$ms . ' ms | ' . round(memory_get_peak_usage(true) / 1048576, 1) . ' MB | ' . ($_SESSION['ws_user']['login'] ?? '-') . ' | ' . $q . ' consultas';
        $l = is_file($f) ? (array)@file($f, FILE_IGNORE_NEW_LINES) : [];
        $l[] = $lin; if (count($l) > 300) $l = array_slice($l, -300);
        @file_put_contents($f, implode("\n", $l) . "\n"); @chmod($f, 0640);
    });
}
define('WS_DB_CFG', WS_CACHE . '/wellsystem_db.json');
// Espelho PERSISTENTE da config do banco, FORA do addon: o painel MK-Auth recria o addon e apaga
// a cache/ (levando a config junto). /var/tmp sobrevive a reboot E à recriação do addon — assim o
// sistema NUNCA MAIS volta a pedir "instalar/criar tabelas" só por ter perdido a config de conexão.
define('WS_DB_CFG_MIRROR', '/var/tmp/wellsystem_db_' . substr(md5(__DIR__), 0, 10) . '.json');
/* ESPELHO QUE SOBREVIVE AO REBOOT DE VERDADE — /var/lib/wellsystem.
 *
 * O espelho acima conta com uma coisa que não é garantida: no Debian/Ubuntu o Apache (e o
 * PHP-FPM) rodam com PrivateTmp. O /var/tmp que o PHP enxerga é uma pasta PRIVADA do serviço,
 * apagada toda vez que o serviço para — no restart do Apache e no reboot. Resultado real: depois
 * de reiniciar o servidor a configuração sumia, o sistema caía no padrão de fábrica (root) e o
 * MariaDB respondia "[1698] Access denied for user 'root'@'localhost'".
 *
 * /var/lib não é afetado por PrivateTmp nem limpo no boot. O PHP não consegue criar essa pasta
 * sozinho (ela pertence ao root), então quem a cria é o INSTALAR.sh, já com dono www-data. Onde
 * ela não existe (addon dentro do MK-Auth, por exemplo), este caminho é simplesmente ignorado. */
define('WS_DB_CFG_PERSIST', '/var/lib/wellsystem/wellsystem_db_' . substr(md5(__DIR__), 0, 10) . '.json');
/**
 * PASTA DE UPLOADS — resolvida sozinha, igual à de cache.
 *
 * Antes era fixa em __DIR__.'/uploads'. Quando o servidor não deixava o PHP gravar ali (addon
 * recriado pelo painel do MK-Auth, pasta com dono de FTP, SELinux), o sistema não tinha plano B:
 * a logo, os fundos da tela de login e as imagens da central simplesmente não subiam, e a tela
 * mandava "ajuste a permissão da pasta no servidor (chmod 775)" — um passo manual, que numa
 * instalação nova ninguém faz, e que este código não pode exigir.
 *
 * Agora tenta na ordem: uploads/ do addon → /var/tmp/wellsystem_uploads_<hash> (sobrevive a
 * reboot e à recriação do addon) → temp do SO. Quem lê os arquivos é o img.php, que já serve a
 * partir de WS_UPLOADS — então a mudança de lugar é invisível para as telas.
 */
function ws_resolver_uploads_dir(): string {
    $preferida = __DIR__ . '/uploads';
    /* SEM ATALHO POR is_writable().
     * Eu tinha posto aqui um "caminho rápido": se a pasta existe e is_writable() diz sim, devolve
     * na hora, sem o teste de escrita real. Foi exatamente isso que quebrou o envio de imagens
     * neste servidor — is_writable() respondia SIM para uploads/ do addon e a gravação falhava
     * mesmo assim (dono/ACL), então o plano B nunca era acionado e o erro dizia que a pasta era
     * "gravável" enquanto nada era gravado.
     * ws_dir_realmente_gravavel() existe justamente para isso: ele CRIA e apaga um arquivo de
     * teste. É uma escrita de poucos bytes por requisição — o mesmo custo que o resolvedor de
     * cache já paga desde sempre, e barato demais para trocar por um diagnóstico errado. */
    if (ws_dir_realmente_gravavel($preferida)) return $preferida;

    /* PLANO B QUE SEMPRE EXISTE: dentro da pasta de CACHE.
     * Os planos B anteriores eram /var/tmp e a temp do SO — e num MK-Auth o pool do PHP costuma
     * ter open_basedir preso à pasta do addon, o que torna esses caminhos INALCANÇÁVEIS. Era por
     * isso que a logo não subia e o erro citava só as pastas do addon: as alternativas nem
     * chegavam a ser testadas de verdade.
     * A pasta de cache, por definição, é gravável — todo o resto do sistema (config do banco,
     * branding, JSON dos concentradores) já grava nela sem falhar. Se ela funciona, upload
     * funciona. E ela é o PRIMEIRO plano B justamente por estar dentro do open_basedir. */
    $cacheUp = WS_CACHE . '/uploads';
    if (ws_dir_realmente_gravavel($cacheUp)) {
        if (!defined('WS_UPLOADS_FALLBACK')) define('WS_UPLOADS_FALLBACK', true);
        return $cacheUp;
    }

    $hash = substr(md5(__DIR__), 0, 10);
    foreach (['/var/tmp', rtrim(sys_get_temp_dir(), '/\\'), '/tmp'] as $base) {
        if ($base === '') continue;
        $cand = $base . '/wellsystem_uploads_' . $hash;
        if (ws_dir_realmente_gravavel($cand)) {
            if (!defined('WS_UPLOADS_FALLBACK')) define('WS_UPLOADS_FALLBACK', true);
            return $cand;
        }
    }
    return $preferida;   // devolve a preferida para a mensagem de erro apontar o lugar certo
}
// Pastas de imagens (criadas sob demanda por ws_dir() — NÃO no hot path de toda requisição).
if (!defined('WS_UPLOADS')) define('WS_UPLOADS', ws_resolver_uploads_dir());
if (!defined('WS_UP_SISTEMA')) define('WS_UP_SISTEMA', WS_UPLOADS . '/sistema');   // logos, modelos, imagens do sistema
define('WS_UP_CLIENTES', WS_UPLOADS . '/clientes'); // fotos/documentos por cliente

/**
 * MOVE UM ARQUIVO ENVIADO — o único caminho de upload do sistema.
 *
 * Havia uma dúzia de lugares chamando move_uploaded_file() sozinho e desistindo no primeiro "não".
 * Só que o move falha por motivos que NÃO são falta de permissão de escrita: open_basedir
 * separando a pasta temporária do PHP da pasta de destino, /tmp em outro sistema de arquivos,
 * upload_tmp_dir esquisito. Nesses casos rename() ou copy() passam sem problema — e o resultado
 * era a imagem "não subir" sem nenhum erro visível, em cada tela de um jeito diferente.
 *
 * Ordem: cria a pasta → move_uploaded_file → rename → copy. Ajusta a permissão do arquivo no fim
 * (0644) para o servidor web conseguir servir o que o PHP acabou de gravar.
 */
/**
 * Perfil AppArmor que confina ESTE processo PHP, ou '' quando não há confinamento.
 *
 * Existe porque o AppArmor foi a causa de um "Permission denied" que consumiu horas: dono certo,
 * chmod certo, disco livre, e a escrita negada assim mesmo — porque quem proíbe não é o sistema
 * de arquivos, é o perfil. Nenhuma mensagem apontava para isso, então a investigação sempre
 * voltava para permissão. O kernel publica o perfil em /proc/self/attr/current; ler dali custa
 * um arquivo minúsculo e transforma o mistério num nome.
 */
function ws_apparmor_perfil(): string {
    $f = '/proc/self/attr/current';
    if (!@is_readable($f)) return '';
    $v = trim((string)@file_get_contents($f));
    // "unconfined" = sem perfil. Confinado vem como "/caminho/do/binario (enforce)".
    if ($v === '' || stripos($v, 'unconfined') === 0) return '';
    return $v;
}

/** Usuário do sistema com que o PHP está rodando ("www-data", "mkauth", "nobody"…), ou ''.
 *  Sem isso, "Permission denied" numa pasta que o operador acabou de liberar vira um mistério:
 *  ele deu chown para o usuário ERRADO e não tem como saber. */
function ws_php_usuario(): string {
    if (function_exists('posix_geteuid') && function_exists('posix_getpwuid')) {
        $u = @posix_getpwuid(posix_geteuid());
        if (!empty($u['name'])) return (string)$u['name'];
    }
    $u = getenv('USER') ?: getenv('USERNAME');
    return $u ? (string)$u : '';
}

function ws_mover_upload(string $tmp, string $destino, ?string &$erro = null): bool {
    $erro = '';
    /* POR QUE ESTA FUNÇÃO NÃO USA "@" NAS TENTATIVAS
     * Usava, e foi um erro meu: o "@" apaga a mensagem do PHP, e sem ela "não gravou" pode ser
     * permissão, open_basedir, disable_functions, disco cheio ou arquivo temporário sumido —
     * cinco causas com cinco soluções diferentes, indistinguíveis na tela. Agora cada tentativa
     * é feita com o aviso capturado e o motivo REAL sobe até quem chamou. */
    $motivo = function (string $rotulo): string {
        $e = error_get_last();
        $m = $e['message'] ?? '';
        // Tira o prefixo "move_uploaded_file(...): " que só repete o nome da função.
        $m = trim((string)preg_replace('/^[a-z_]+\([^)]*\):\s*/i', '', $m));
        return $rotulo . ($m !== '' ? ' → ' . $m : '');
    };

    if ($tmp === '') { $erro = 'caminho temporário vazio'; return false; }
    if (!is_file($tmp)) { $erro = 'o arquivo temporário do upload não existe mais (' . $tmp . ')'; return false; }

    /* SEGURANÇA: rename/copy só entram como alternativa quando o arquivo REALMENTE veio de um
     * upload HTTP (is_uploaded_file). É o que o move_uploaded_file garante sozinho; sem esta
     * checagem, uma alternativa cega poderia mover um arquivo qualquer do servidor caso um dia
     * um caminho controlável chegasse aqui. */
    if (!is_uploaded_file($tmp)) { $erro = 'o arquivo não foi reconhecido como upload HTTP'; return false; }

    $dir = dirname($destino);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (is_dir($dir) && !is_writable($dir)) { @chmod($dir, 0775); if (!is_writable($dir)) @chmod($dir, 0777); }
    if (!is_dir($dir))      { $erro = 'a pasta de destino não existe e não pôde ser criada: ' . $dir; return false; }
    if (!is_writable($dir)) { $erro = 'a pasta de destino não aceita escrita: ' . $dir; return false; }

    $tentativas = [];
    error_clear_last();
    if (@move_uploaded_file($tmp, $destino)) { @chmod($destino, 0644); return true; }
    $tentativas[] = $motivo('move_uploaded_file');

    error_clear_last();
    if (@rename($tmp, $destino)) { @chmod($destino, 0644); return true; }
    $tentativas[] = $motivo('rename');

    error_clear_last();
    if (@copy($tmp, $destino)) { @chmod($destino, 0644); return true; }
    $tentativas[] = $motivo('copy');

    /* Espaço em disco entra no relatório porque disco cheio deixa is_writable() dizendo "sim" e
     * derruba a gravação mesmo assim — é a causa que mais se disfarça de permissão. */
    $livre = @disk_free_space($dir);
    if ($livre !== false && $livre < 1048576) $tentativas[] = 'disco praticamente cheio (' . round($livre / 1024) . ' KB livres)';

    /* "Permission denied" numa pasta que o operador acabou de liberar quase sempre significa que
       ele deu chown para um usuário e o PHP roda como OUTRO. Dizer o nome do usuário do PHP
       transforma um mistério num comando de uma linha. */
    $usu = ws_php_usuario();
    if ($usu !== '') $tentativas[] = 'o PHP roda como "' . $usu . '"';

    /* Se o processo está confinado por AppArmor, ELE é o suspeito número um — e a mensagem tem
       que dizer isso, senão a investigação volta para permissão de pasta, que já está certa. */
    $aa = ws_apparmor_perfil();
    if ($aa !== '') {
        $tentativas[] = 'ATENÇÃO: este PHP está confinado pelo AppArmor (' . $aa . '). '
                      . 'Quando o dono e o chmod da pasta já estão corretos, é ELE que nega a escrita — '
                      . 'use Manutenção → "Liberar AppArmor p/ gravar imagens"';
    } elseif ($usu !== '') {
        $tentativas[] = 'a pasta precisa pertencer a "' . $usu . '"';
    }

    $erro = implode(' · ', $tentativas);
    return false;
}

/**
 * Caminho FÍSICO de um arquivo guardado como caminho relativo ("uploads/sistema/logo_x.png").
 *
 * O banco e os JSON guardam o caminho relativo, e o código resolvia com WS_DIR.'/'.$rel. Isso
 * deixou de valer no instante em que uploads/ pode morar fora da pasta do addon: is_file()
 * respondia "não existe" e a logo sumia da tela sem erro nenhum. Esta função é o único lugar que
 * sabe traduzir — o resto do sistema só pergunta.
 */
function ws_caminho_fisico(string $rel): string {
    $rel = ltrim(str_replace('\\', '/', trim($rel)), '/');
    if ($rel === '') return '';
    if (strpos($rel, 'uploads/') === 0) return WS_UPLOADS . '/' . substr($rel, 8);
    return WS_DIR . '/' . $rel;
}

/**
 * Cria e conserta TODAS as pastas graváveis do sistema, de uma vez.
 *
 * É o que faz uma instalação nova subir pronta: sem isto, cada recurso descobria a falta de
 * permissão só na hora em que o operador tentava usar — e a resposta era sempre "rode chmod no
 * servidor". Roda uma vez por requisição, a partir do ws_selfheal(), e é barata: mkdir/chmod em
 * pasta que já existe e já está certa não custa nada.
 *
 * @return array pastas que continuaram SEM escrita (vazio = tudo certo).
 */
function ws_garantir_pastas(): array {
    static $ruins = null;
    if ($ruins !== null) return $ruins;
    $ruins = [];

    /* THROTTLE: a verificação profunda (criar e apagar arquivo de teste em cada pasta) roda no
     * máximo a cada 5 minutos. São 8 pastas — 8 escritas por requisição seria caro para repetir
     * em toda página só para confirmar o que quase nunca muda. O que continua acontecendo SEMPRE
     * é o mkdir/chmod das pastas que faltam, que é barato e é o que garante a instalação nova. */
    $marca = WS_CACHE . '/ws_pastas_ok.txt';
    $recente = is_file($marca) && (time() - (int)@filemtime($marca)) < 300;
    $alvos = [
        WS_CACHE,
        WS_UPLOADS,
        WS_UPLOADS . '/sistema',      // logo, fundos do login, imagens da central
        WS_UPLOADS . '/clientes',
        WS_UPLOADS . '/operadores',
        WS_UPLOADS . '/equipamentos',
        WS_UPLOADS . '/anexos',
        WS_UPLOADS . '/documentos',
    ];
    /* assets/ é OPCIONAL: é só o lugar preferido da logo (servida direto pelo servidor web, sem
       passar pelo img.php). Quando a pasta do addon não pertence ao usuário do PHP, ela nunca
       vai gravar — e mantê-la na lista de obrigatórias deixaria o diagnóstico vermelho para
       sempre por causa de algo que tem substituto perfeito em uploads/sistema. */
    $opcional = WS_DIR . '/assets';
    if (!is_dir($opcional)) @mkdir($opcional, 0775, true);
    if (is_dir($opcional) && !is_writable($opcional)) @chmod($opcional, 0775);

    foreach ($alvos as $d) {
        if (!is_dir($d)) @mkdir($d, 0775, true);
        // Pasta criada por FTP costuma vir com dono diferente do PHP: afrouxa antes de desistir.
        if (is_dir($d) && !is_writable($d)) { @chmod($d, 0775); if (!is_writable($d)) @chmod($d, 0777); }
        /* Confere GRAVANDO, não só olhando o bit de permissão: is_writable() responde "sim" para
           pasta cujo dono é outro em algumas configurações, e foi assim que uma pasta que não
           gravava nada apareceu como "gravável" no diagnóstico. */
        if ($recente) { if (!is_dir($d)) $ruins[] = $d; continue; }
        if (!is_dir($d) || !ws_dir_realmente_gravavel($d)) $ruins[] = $d;
    }
    // Só marca como conferido quando a checagem profunda aconteceu e passou em tudo.
    if (!$recente && !$ruins) { @file_put_contents($marca, (string)time()); @chmod($marca, 0640); }
    return $ruins;
}
/** AGENDAMENTO POR HORÁRIO (backup / resumo): diz se o "slot" de HOJE (data + hora marcada) já passou e
 *  ainda NÃO foi cumprido. A marca guarda o SLOT cumprido ("Y-m-d H:i"), não só o dia — então se o
 *  horário for remarcado (ex.: testar 23:02 depois de já ter enviado às 03:00), o novo horário volta a
 *  disparar. Marca antiga (só a data) vale como cumprida apenas se foi gravada DEPOIS do horário.
 *  Retorna [pendente, slot, motivo]. */
function ws_agenda_slot(string $marcaFile, string $hora): array {
    if (!preg_match('/^\d{2}:\d{2}$/', $hora)) $hora = '03:00';
    $slot = date('Y-m-d') . ' ' . $hora;
    $slotTs = (int)strtotime($slot);
    if (time() < $slotTs) return [false, $slot, 'antes'];
    $m = is_file($marcaFile) ? trim((string)@file_get_contents($marcaFile)) : '';
    if ($m === $slot) return [false, $slot, 'feito'];
    if ($m === date('Y-m-d') && (int)@filemtime($marcaFile) >= $slotTs) return [false, $slot, 'feito'];
    return [true, $slot, ''];
}
/** Garante que uma pasta exista (só chamada por quem vai gravar). */
function ws_dir(string $d): string {
    if (!is_dir($d)) @mkdir($d, 0775, true);
    // Auto-cura: se a pasta já existe mas está sem permissão de escrita (comum quando foi criada
    // por FTP com dono diferente do PHP/Apache), tenta relaxar a permissão sozinho antes de desistir.
    if (is_dir($d) && !is_writable($d)) @chmod($d, 0775);
    return $d;
}

/** Diagnóstico de permissão pra mensagens de erro mais úteis (dono real da pasta, permissão atual, usuário do PHP). */
function ws_diag_permissao(string $d): string {
    $partes = [];
    $meNome = '';
    if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
        $meInfo = @posix_getpwuid(posix_geteuid());
        if ($meInfo) $meNome = $meInfo['name'];
    }
    if (is_dir($d)) {
        $perm = @fileperms($d);
        if ($perm !== false) $partes[] = 'permissão atual: ' . substr(sprintf('%o', $perm), -4);
        if (function_exists('posix_getpwuid') && function_exists('fileowner')) {
            $uid = @fileowner($d); $info = $uid !== false ? @posix_getpwuid($uid) : false;
            if ($info) $partes[] = 'dono da pasta: ' . $info['name'];
        }
        if ($meNome) $partes[] = 'PHP roda como: ' . $meNome;
        // Se os bits E o dono batem mas mesmo assim não grava, o culpado quase sempre é o SELinux/
        // AppArmor (comum em CentOS/RHEL, onde o MK-Auth roda) — o chmod aí não resolve sozinho.
        $bitsParecemOk = $perm !== false && (($perm & 0777) >= 0775);
        if ($bitsParecemOk && !ws_dir_realmente_gravavel($d)) {
            $partes[] = 'permissão E dono já estão corretos mas a gravação ainda falha — isso é sinal de SELinux/AppArmor bloqueando por trás (comum em CentOS/RHEL)';
            $partes[] = 'rode no servidor pra confirmar: getenforce';
            $partes[] = 'se disser "Enforcing", rode: chcon -R -t httpd_sys_rw_content_t ' . $d . '  (ou, se não tiver esse comando: setenforce 0 temporariamente pra testar)';
        } else {
            $partes[] = 'rode no servidor: chmod 775 ' . $d . ($meNome ? " && chown $meNome $d" : '');
        }
    } else {
        $partes[] = 'a pasta nem existe e o PHP não conseguiu criá-la';
        $partes[] = 'rode no servidor (via SSH/terminal): mkdir -p ' . $d . ' && chmod 775 ' . $d . ($meNome ? " && chown $meNome $d" : '');
    }
    return $partes ? ' (' . implode(' · ', $partes) . ')' : '';
}

/**
 * ONDE A CONFIGURAÇÃO DO BANCO PODE ESTAR — na ordem em que é procurada.
 *
 *   1. WS_DB_CFG ............ onde o sistema grava hoje (cache/ ou a pasta de contingência)
 *   2. <sistema>/cache/ ..... o lugar CANÔNICO, procurado mesmo quando a pasta não é gravável
 *   3. /var/lib/wellsystem .. espelho que sobrevive a reboot e a PrivateTmp (criado pelo INSTALAR.sh)
 *   4. /var/tmp ............. espelho antigo, mantido para quem já dependia dele
 *
 * O item 2 corrige um defeito de leitura: se a pasta cache/ deixava de ser gravável (permissão
 * mudada, AppArmor, disco), WS_DB_CFG passava a apontar para a pasta de contingência — e o
 * arquivo que CONTINUAVA existindo em cache/ nem era lido. Ler não depende de poder gravar.
 *
 * A ordem começa por WS_DB_CFG de propósito: para toda instalação que já funciona, o arquivo
 * usado continua sendo exatamente o mesmo de antes. Os outros só entram quando ele falta.
 */
/** Selo do topo/rodapé — marca de registro do sistema (marca_registro.php confere e restaura o original). */
function ws_selo_src(): string {
    if (!function_exists('ws_marca_selo_src') && is_file(__DIR__ . '/marca_registro.php')) require_once __DIR__ . '/marca_registro.php';
    if (function_exists('ws_marca_selo_src')) return ws_marca_selo_src();
    return 'img/wellsystem-selo.jpg?v=' . (function_exists('ws_ver') ? ws_ver('img/wellsystem-selo.jpg') : '1');
}

/** Link do selo do rodapé = site do dono do código (marca de registro, fixo e conferido em marca_registro.php). */
function ws_dono_url(): string {
    if (!function_exists('ws_marca_dono_url') && is_file(__DIR__ . '/marca_registro.php')) require_once __DIR__ . '/marca_registro.php';
    return function_exists('ws_marca_dono_url') ? ws_marca_dono_url() : 'https://wellnet.com.br';
}

function ws_db_config_candidatos(): array {
    $lista = [WS_DB_CFG, __DIR__ . '/cache/wellsystem_db.json', WS_DB_CFG_PERSIST, WS_DB_CFG_MIRROR];
    return array_values(array_unique($lista));
}

/** Grava a config do banco em TODOS os lugares onde ela pode ser procurada — o que der certo fica,
 *  o que falhar (pasta sem permissão, /var/lib inexistente) é ignorado sem erro. */
function ws_db_config_salvar(array $cfg): void {
    $j = json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    foreach (ws_db_config_candidatos() as $arq) {
        // /var/lib/wellsystem só existe quando o INSTALAR.sh a criou; o PHP não cria pasta ali.
        if ($arq === WS_DB_CFG_PERSIST && !is_dir(dirname($arq))) continue;
        if (@file_put_contents($arq, $j) !== false) @chmod($arq, 0640);
    }
}
function ws_db_config(): array {
    $def = ['host' => '127.0.0.1', 'porta' => 3306, 'user' => 'root', 'pass' => 'vertrigo', 'dbname' => 'wellsystem'];

    // AMBIENTE PRIMEIRO (Docker/docker-compose). Isto ANTES do arquivo é o que corrige o
    // "SQLSTATE[HY000] [2002] Connection refused" numa instalação nova em container: o
    // docker-compose.yml monta ./cache do host dentro do container, e o cache/wellsystem_db.json
    // que vem junto aponta pro banco da OUTRA instalação (127.0.0.1/root) — que dentro do
    // container não existe, daí a recusa de conexão. O .dockerignore só protege a IMAGEM;
    // o bind mount entra depois e passa por cima dele. Quem declara WS_DB_HOST está dizendo
    // explicitamente onde é o banco, então essa declaração tem que ganhar do arquivo.
    if (getenv('WS_DB_HOST')) {
        return [
            'host'   => getenv('WS_DB_HOST'),
            'porta'  => (int)(getenv('WS_DB_PORT') ?: 3306),
            'user'   => getenv('WS_DB_USER') ?: 'root',
            'pass'   => getenv('WS_DB_PASS') ?: '',
            'dbname' => getenv('WS_DB_NAME') ?: 'wellsystem',
        ];
    }

    // Procura em todos os lugares possíveis (ver ws_db_config_candidatos); usa o 1º válido e
    // RESTAURA os que estiverem faltando, para a próxima perda não ser a última cópia.
    $achado = null; $faltando = false;
    foreach (ws_db_config_candidatos() as $arq) {
        if ($arq === WS_DB_CFG_PERSIST && !is_dir(dirname($arq))) continue;   // lugar que não existe aqui
        if (is_file($arq)) {
            $c = json_decode((string)@file_get_contents($arq), true);
            if (is_array($c) && !empty($c['host'])) { if ($achado === null) { $achado = $c; if (!defined('WS_DB_CFG_LIDO')) define('WS_DB_CFG_LIDO', $arq); } }
            else $faltando = true;
        } else { $faltando = true; }
    }
    if ($achado !== null) {
        if ($faltando) ws_db_config_salvar($achado); // alguma cópia sumiu -> reescreve as que faltam
        $cfg = array_merge($def, $achado);

        /* CONFIG HERDADA DE OUTRA INSTALAÇÃO, DENTRO DE UM CONTAINER.
         * Cenário real e recorrente: a pasta do projeto é copiada de um servidor que já rodava o
         * WellSystem, e o cache/wellsystem_db.json vem junto apontando para 127.0.0.1/root — o
         * banco DAQUELE servidor. Dentro do container esse endereço é o próprio container, onde
         * não há MySQL nenhum: "[2002] Connection refused" numa instalação nova, sem nada de
         * errado com o Docker.
         * Quando ISTO é um container (/.dockerenv), NÃO há variável WS_DB_* declarada e o arquivo
         * aponta para loopback, esse arquivo é resquício — não configuração deste ambiente. Aí o
         * host vira o nome de serviço padrão do compose. É uma correção estreita de propósito:
         * fora de container, ou com WS_DB_HOST declarado, ou apontando para qualquer outro host,
         * nada muda. */
        $loopback = in_array((string)$cfg['host'], ['127.0.0.1', 'localhost', '::1'], true);
        if ($loopback && @is_file('/.dockerenv') && !getenv('WS_DB_HOST')) {
            foreach (['db', 'mysql', 'mariadb'] as $servico) {
                $t = @fsockopen($servico, (int)$cfg['porta'], $e1, $e2, 1);
                if ($t) {
                    fclose($t);
                    $cfg['host'] = $servico;
                    if (!defined('WS_DB_HOST_AUTO')) define('WS_DB_HOST_AUTO', $servico);
                    break;
                }
            }
        }
        return $cfg;
    }

    /* NADA SALVO AINDA — ESTE SERVIDOR É UM MK-AUTH?
     * Se for, as credenciais do banco já existem no próprio MK-Auth e não há razão para pedir ao
     * instalador que digite de novo o que o servidor já sabe. A detecção abaixo lê a configuração
     * dele e devolve host/usuário/senha prontos, de modo que o instalador abre com os campos
     * preenchidos: o operador confere e avança.
     * Custo zero depois de instalado: este trecho só roda enquanto NÃO existe configuração
     * salva — e, dentro da mesma requisição, o resultado fica em cache estático. */
    $mk = ws_mkauth_credenciais();
    if ($mk) {
        if (!defined('WS_DB_CFG_ORIGEM')) define('WS_DB_CFG_ORIGEM', 'mkauth');
        return $mk;
    }
    /* Nenhuma configuração em lugar nenhum: devolve o padrão de fábrica — e AVISA que é isso.
     * O padrão (root) quase nunca conecta num Linux atual, porque o root do MariaDB entra só pelo
     * socket do sistema. Sem esta marca, a tela de instalação mostrava "senha errada" para o que
     * na verdade é "a configuração deste servidor não foi encontrada" — e o operador ia corrigir
     * uma senha que nunca esteve errada. */
    if (!defined('WS_DB_CFG_ORIGEM')) define('WS_DB_CFG_ORIGEM', 'padrao');
    return $def;
}

/**
 * Descobre as credenciais do banco lendo a configuração do MK-Auth instalado neste servidor.
 *
 * Por que ler o código do MK-Auth em vez de um caminho fixo: a instalação dele varia de versão
 * para versão (o arquivo já se chamou config.php, conexao.php, ficou em admin/, em inc/...). Em
 * vez de apostar num caminho, a função varre os .php das pastas prováveis, extrai todo par
 * usuário/senha que encontrar — nas três formas que o MK-Auth usa ao longo das versões — e
 * TESTA cada um. Quem define o vencedor não é o nome da variável: é a conexão que abre e enxerga
 * a tabela `sis_cliente`, que só existe no banco do MK-Auth. Errar o palpite é inofensivo; o
 * teste descarta.
 *
 * Devolve null (silenciosamente) em qualquer instalação que não seja MK-Auth — Docker, bare-metal
 * ou servidor de outro ERP. Nenhum erro é exibido: aqui "não achei" é resposta legítima, e o
 * instalador simplesmente abre com os campos em branco, como sempre fez.
 *
 * A senha encontrada NÃO é gravada em lugar nenhum por esta função. Ela só vai para
 * cache/wellsystem_db.json quando o operador confirmar no instalador — o mesmo caminho de uma
 * senha digitada à mão.
 */
function ws_mkauth_credenciais(): ?array {
    static $cache = false;              // false = ainda não procurou; null = procurou e não achou
    if ($cache !== false) return $cache;
    $cache = null;

    // Pastas onde o MK-Auth (e o arquivo de conexão) já morou — nas várias versões e também nos
    // vários jeitos comuns de instalar (docroot direto, /var/www/mk-auth, /opt/mk-auth...).
    // ANTES: só olhava pra /opt/mk-auth — se o MK-Auth deste servidor estivesse em QUALQUER outro
    // lugar, a função inteira desistia na hora (nem chegava a testar nada), mesmo o MK-Auth
    // estando instalado e funcionando ao lado. Confirmado pelo log do operador: pasta não existe
    // neste servidor. Agora cada candidato de pasta é checado por conta própria — pasta que não
    // existe é só pulada, não derruba a busca inteira.
    $bases = ['/opt/mk-auth', '/opt/mk-auth/admin', '/opt/mk-auth/inc', '/opt/mk-auth/admin/inc',
              '/opt/mk-auth/include', '/opt/mk-auth/admin/include',
              '/var/www/mk-auth', '/var/www/mk-auth/admin', '/var/www/mk-auth/inc', '/var/www/mk-auth/include',
              '/var/www/html/mk-auth', '/var/www/html/mk-auth/admin', '/var/www/html/mk-auth/inc',
              '/var/www/html/admin', '/var/www/html/inc',
              '/usr/local/mk-auth', '/usr/local/mk-auth/admin'];
    $arquivos = [];
    foreach ($bases as $dir) {
        if (!@is_dir($dir)) continue;
        foreach ((array)@glob($dir . '/*.php') as $f) {
            $tam = @filesize($f);
            if ($tam !== false && $tam > 0 && $tam < 262144) $arquivos[] = $f;   // ignora arquivão
        }
    }
    $arquivos = array_slice(array_unique($arquivos), 0, 150);   // teto: não varre o sistema inteiro
    if (!$arquivos) return $cache;

    $candidatos = [];
    foreach ($arquivos as $arq) {
        $src = (string)@file_get_contents($arq);
        if ($src === '' || stripos($src, 'mysql') === false) continue;   // nem fala de banco

        // FORMA 1 — chamada direta: mysqli_connect('host','user','senha'[,'banco'])
        //                           new mysqli('host','user','senha'[,'banco'])
        if (preg_match_all(
                '/(?:mysqli_connect|new\s+mysqli)\s*\(\s*([\'"])(.*?)\1\s*,\s*([\'"])(.*?)\3\s*,\s*([\'"])(.*?)\5/s',
                $src, $m, PREG_SET_ORDER)) {
            foreach ($m as $g) $candidatos[] = ['host' => $g[2], 'user' => $g[4], 'pass' => $g[6]];
        }

        // FORMA 2 — DSN do PDO: new PDO("mysql:host=X;dbname=Y", 'user', 'senha')
        if (preg_match_all(
                '/new\s+PDO\s*\(\s*[\'"]mysql:host=([^;\'"]+)[^\'"]*[\'"]\s*,\s*([\'"])(.*?)\2\s*,\s*([\'"])(.*?)\4/s',
                $src, $m, PREG_SET_ORDER)) {
            foreach ($m as $g) $candidatos[] = ['host' => $g[1], 'user' => $g[3], 'pass' => $g[5]];
        }

        // FORMA 3 — variáveis ou constantes soltas, montadas depois.
        $val = [];
        if (preg_match_all(
                '/(?:\$|define\s*\(\s*[\'"])([A-Za-z_][A-Za-z0-9_]*)[\'"]?\s*(?:=|,)\s*([\'"])(.*?)\2/s',
                $src, $m, PREG_SET_ORDER)) {
            foreach ($m as $g) $val[strtolower($g[1])] = $g[3];
        }
        if ($val) {
            $primeiro = function (array $nomes) use ($val) {
                foreach ($nomes as $n) if (isset($val[$n]) && $val[$n] !== '') return $val[$n];
                return null;
            };
            $u = $primeiro(['mysql_user', 'mysqluser', 'dbuser', 'db_user', 'bd_user', 'usuario_bd',
                            'dbusuario', 'usuario', 'user']);
            $p = $primeiro(['mysql_pass', 'mysqlpass', 'mysql_senha', 'dbpass', 'db_pass', 'bd_senha',
                            'senha_bd', 'password', 'senha', 'pass']);
            $h = $primeiro(['mysql_host', 'mysqlhost', 'dbhost', 'db_host', 'bd_host', 'servidor', 'host']);
            if ($u !== null && $p !== null) {
                $candidatos[] = ['host' => (string)($h ?? 'localhost'), 'user' => $u, 'pass' => $p];
            }
        }
    }
    if (!$candidatos) return $cache;

    // Tira repetidos (o mesmo par costuma aparecer em vários arquivos) e limita as tentativas:
    // cada teste é uma conexão, e não faz sentido martelar o MySQL com dezenas delas.
    $vistos = []; $fila = [];
    foreach ($candidatos as $c) {
        $chave = $c['host'] . "\0" . $c['user'] . "\0" . $c['pass'];
        if (isset($vistos[$chave])) continue;
        $vistos[$chave] = true; $fila[] = $c;
        if (count($fila) >= 12) break;
    }

    foreach ($fila as $c) {
        $host = ($c['host'] === '' ? 'localhost' : $c['host']);
        try {
            $pdo = new PDO("mysql:host={$host};port=3306;charset=utf8mb4", $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 3,
            ]);
            // O VEREDITO: só é MK-Auth se estas credenciais enxergam a tabela sis_cliente.
            $n = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables
                                   WHERE table_name = 'sis_cliente'")->fetchColumn();
            if ($n > 0) {
                $cache = ['host' => $host, 'porta' => 3306, 'user' => $c['user'],
                          'pass' => $c['pass'], 'dbname' => 'wellsystem'];
                return $cache;
            }
        } catch (Throwable $e) {
            // Palpite errado. Segue para o próximo — silêncio é o comportamento correto aqui.
        }
    }
    return $cache;
}

/**
 * Abre uma conexão PDO com retry/backoff — cobre a instalação nova em Docker/docker-compose:
 * mesmo com "depends_on: condition: service_healthy" e o wait-loop do entrypoint.sh, o
 * MariaDB/MySQL oficial reinicia o processo internamente durante a 1ª inicialização (roda os
 * scripts de init, derruba o mysqld e sobe de novo "pra valer") — e QUALQUER conexão que chegue
 * nesse meio-tempo recebe "SQLSTATE[HY000] [2002] Connection refused", mesmo o container do
 * banco já estando de pé. Usada tanto por ws_db() (toda página/cron) quanto pelo install_cli.php
 * (a conexão "root" que cria o banco/tabelas na 1ª subida do container) — é justamente essa
 * primeira conexão, logo após o wait-loop do entrypoint, a mais sujeita a essa corrida.
 * Só re-tenta para o erro 2002 (recusa de conexão); qualquer outro erro (senha errada, banco
 * inexistente etc.) falha na hora, sem esperar à toa.
 */
/* ------------------------------------------------------------------------------------------
 * OS TRÊS NOMES DA MESMA MÁQUINA — e por que isso derruba a instalação em UM servidor só.
 *
 * 'localhost', '127.0.0.1' e '::1' levam ao mesmo lugar, mas NÃO são a mesma coisa para o MySQL:
 * ele autoriza por usuário E origem, e 'wellsystem'@'localhost' é uma conta diferente de
 * 'wellsystem'@'127.0.0.1'. Junte-se a isso que "localhost" conecta por SOCKET e "127.0.0.1" por
 * TCP, e que com skip-name-resolve ligado o servidor para de traduzir 127.0.0.1 em localhost.
 *
 * É exatamente daí que sai o "[1045] Access denied for user 'wellsystem'@'127.0.0.1'" num
 * servidor e nada no outro, com o MESMO código e a MESMA senha: a conta é criada para
 * 'localhost' e a configuração grava 127.0.0.1 — onde o MySQL resolve nomes, casa; onde não
 * resolve, nega. Como o sistema roda junto de vários ERPs, cada um com seu my.cnf, não dá para
 * presumir qual dos dois nomes vale naquele servidor.
 *
 * Então, e SÓ depois de a conexão já ter falhado por acesso negado, tentamos os outros nomes
 * antes de desistir. Quem conecta de primeira nunca passa por aqui — nada muda para quem já
 * está funcionando. Se nenhum nome for aceito, o erro devolvido é o ORIGINAL, sem maquiagem.
 * ---------------------------------------------------------------------------------------- */
function ws_pdo_hosts_equivalentes(string $host): array {
    $eq = [
        'localhost' => ['127.0.0.1', '::1'],
        '127.0.0.1' => ['localhost', '::1'],
        '::1'       => ['localhost', '127.0.0.1'],
    ];
    return $eq[strtolower(trim($host))] ?? [];
}
/** Host declarado num DSN "mysql:host=…;port=…". */
function ws_dsn_host(string $dsn): string { return preg_match('/host=([^;]*)/i', $dsn, $m) ? trim($m[1]) : ''; }
/** O mesmo DSN apontando para outro host. */
function ws_dsn_trocar_host(string $dsn, string $novo): string { return (string)preg_replace('/host=[^;]*/i', 'host=' . $novo, $dsn, 1); }
/** "Access denied" (1045 senha/conta, 1044 banco) — os dois casos em que trocar de nome pode resolver. */
function ws_pdo_erro_acesso(Throwable $e): bool {
    $m = $e->getMessage();
    return strpos($m, '1045') !== false || strpos($m, '1044') !== false || stripos($m, 'Access denied for user') !== false;
}

/**
 * @param string|null $dsnUsado devolve o DSN que realmente conectou (pode diferir do pedido,
 *                              quando foi preciso usar outro nome do mesmo servidor).
 */
function ws_pdo_conectar(string $dsn, string $user, string $pass, array $opt, ?string &$dsnUsado = null): PDO {
    $dsnUsado = $dsn;
    $tentativas = 6;         // 1+2+3+4+5 = 15s de espera total, no pior caso
    $ultimoErro = null;
    for ($i = 1; $i <= $tentativas; $i++) {
        try {
            return new WsPDO($dsn, $user, $pass, $opt);   // WsPDO = PDO + Recupera Deletado (lixeira_lib.php)
        } catch (PDOException $e) {
            $ultimoErro = $e;
            // Acesso negado: a conta pode existir só para o OUTRO nome deste mesmo servidor.
            if (ws_pdo_erro_acesso($e)) {
                foreach (ws_pdo_hosts_equivalentes(ws_dsn_host($dsn)) as $alt) {
                    $dsnAlt = ws_dsn_trocar_host($dsn, $alt);
                    try {
                        $conn = new WsPDO($dsnAlt, $user, $pass, $opt);
                        $dsnUsado = $dsnAlt;
                        return $conn;
                    } catch (PDOException $e2) { /* segue tentando; o erro que interessa é o 1º */ }
                }
                throw $e;    // nenhum nome foi aceito: o erro continua sendo o de sempre
            }
            $ehRecusa = ((int)$e->getCode() === 2002) || (strpos($e->getMessage(), '2002') !== false)
                || (stripos($e->getMessage(), 'Connection refused') !== false);
            if (!$ehRecusa || $i === $tentativas) throw $e;
            sleep($i); // 1s, 2s, 3s... — dá tempo do banco terminar de subir/reiniciar
        }
    }
    throw $ultimoErro; // segurança (nunca deve chegar aqui)
}

/**
 * Retorna uma conexão PDO com o banco `wellsystem`.
 * @param bool $semBanco  true = conecta ao servidor sem selecionar o banco (usado no install).
 */
function ws_db(bool $semBanco = false): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO && !$semBanco) return $pdo;

    $c = ws_db_config();
    // ISOLAMENTO DEMO: em sessão DEMO, conecta num banco SEPARADO (<base>_demo). A produção só é
    // usada quando NÃO é sessão demo — nunca há mistura.
    $dbname = (!empty($_SESSION['ws_demo']) && function_exists('ws_demo_dbname')) ? ws_demo_dbname($c['dbname']) : $c['dbname'];
    $dsn = "mysql:host={$c['host']};port={$c['porta']};charset=utf8mb4";
    if (!$semBanco) $dsn .= ";dbname={$dbname}";

    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_STATEMENT_CLASS    => ['WsStmt'],   // Recupera Deletado: guarda o que um DELETE vai apagar
    ];

    $dsnUsado = null;
    $conn = ws_pdo_conectar($dsn, $c['user'], $c['pass'], $opt, $dsnUsado);

    /* Conectou por outro nome do mesmo servidor (ver ws_pdo_hosts_equivalentes)? Grava o nome que
     * funcionou. Sem isso o sistema continuaria tentando primeiro o que dá acesso negado em TODA
     * requisição — funcionaria, porém pagando duas conexões por página. Só grava quando o host
     * vem de arquivo: com WS_DB_HOST declarado (Docker), quem manda é a variável de ambiente. */
    $hostUsado = $dsnUsado ? ws_dsn_host($dsnUsado) : '';
    if ($hostUsado !== '' && strcasecmp($hostUsado, (string)$c['host']) !== 0 && !getenv('WS_DB_HOST')
        && defined('WS_DB_CFG_LIDO')) {   // só corrige config que veio de ARQUIVO
        /* array_merge sobre a config INTEIRA, trocando só o host: ws_db_config_salvar() regrava o
         * arquivo por completo, e montar um array novo aqui apagaria campos que não são desta
         * função — o `radius_db`, por exemplo, que o INSTALAR.sh grava e o módulo do FreeRADIUS lê. */
        ws_db_config_salvar(array_merge($c, ['host' => $hostUsado]));
    }

    if (!$semBanco) {
        $pdo = $conn;
        // AUTO-PERSISTE a config que FUNCIONOU (cache/ + espelho /var/tmp) se ainda não existe em
        // nenhum lugar. Assim, mesmo conectando pelos padrões/env, o sistema para de pedir
        // "instalar/criar tabelas" — e o espelho sobrevive à recriação do addon pelo painel.
        if (!defined('WS_DB_CFG_LIDO')) {   // não veio de arquivo nenhum: grava em todos os lugares
            ws_db_config_salvar(['host'=>$c['host'],'porta'=>(int)$c['porta'],'user'=>$c['user'],'pass'=>$c['pass'],'dbname'=>$c['dbname']]);
        }
    }
    return $conn;
}

/**
 * Registra uma VISITA à Central do assinante (é de onde sai o número do card do Painel).
 *
 * Conta uma vez por SESSÃO do visitante, não por página: quem entra, consulta o status, tira a
 * 2ª via e abre um chamado fez UMA visita. E quando o assinante faz login, a visita que já estava
 * registrada ganha o cliente_id — assim dá para saber quem usou a central, sem contar duas vezes
 * a mesma pessoa.
 *
 * NUNCA lança. Este código roda na página que atende o cliente final do provedor: um contador de
 * visita não pode, em hipótese alguma, ser o motivo de a central não abrir.
 */
function ws_central_visita(string $origem = 'portal', ?int $clienteId = null): void {
    try {
        /* 03/10/2026: visita só conta quando o assinante ENTRA na central (login feito). Antes contava
           ao abrir a URL, e o card enchia de visitas sem nome — robô, link aberto e fechado etc. */
        if (!$clienteId) return;
        if (session_status() !== PHP_SESSION_ACTIVE) return;
        // Virou o mês com a sessão ainda aberta? Essa pessoa volta a contar como visita do mês novo
        // (senão o card do mês novo ficaria sem quem já estava com a central aberta na virada).
        if (!empty($_SESSION['ws_central_visita_id']) && ($_SESSION['ws_central_visita_mes'] ?? '') !== date('Y-m')) {
            unset($_SESSION['ws_central_visita_id'], $_SESSION['ws_central_visita_cli']);
        }
        if (!empty($_SESSION['ws_central_visita_id'])) {
            // Já contada nesta sessão. Se agora sabemos QUEM é, completa o registro.
            if ($clienteId && empty($_SESSION['ws_central_visita_cli'])) {
                ws_db()->prepare("UPDATE ws_central_visita SET cliente_id=? WHERE id=?")
                       ->execute([$clienteId, (int)$_SESSION['ws_central_visita_id']]);
                $_SESSION['ws_central_visita_cli'] = 1;
            }
            return;
        }
        $db = ws_db();
        $db->prepare("INSERT INTO ws_central_visita (cliente_id, origem, ip, ua) VALUES (?,?,?,?)")
           ->execute([$clienteId ?: null, mb_substr($origem, 0, 20),
                      mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
                      mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 160)]);
        $_SESSION['ws_central_visita_id'] = (int)$db->lastInsertId();
        $_SESSION['ws_central_visita_mes'] = date('Y-m');
        if ($clienteId) $_SESSION['ws_central_visita_cli'] = 1;
    } catch (Throwable $e) { /* silêncio proposital: ver o comentário acima */ }
}

/** Visitas da Central para o card do Painel: ['hoje'=>n, 'mes'=>n, 'total'=>n, 'clientes'=>n]. */
function ws_central_visitas_resumo(PDO $db): array {
    $r = ['hoje' => 0, 'mes' => 0, 'total' => 0, 'clientes' => 0];
    try {
        $q = $db->query("SELECT
                COUNT(*) total,
                SUM(v.criado_em >= CURDATE()) hoje,
                SUM(v.criado_em >= DATE_FORMAT(CURDATE(),'%Y-%m-01')) mes,   /* mês corrente: zera na virada do mês */
                COUNT(DISTINCT v.cliente_id) clientes
            FROM ws_central_visita v
            JOIN ws_cliente c ON c.id = v.cliente_id")->fetch();   /* só visita com cliente (login feito) */
        if ($q) $r = ['hoje' => (int)$q['hoje'], 'mes' => (int)$q['mes'],
                      'total' => (int)$q['total'], 'clientes' => (int)$q['clientes']];
    } catch (Throwable $e) { /* tabela ainda não criada: card mostra zero, não quebra o Painel */ }
    return $r;
}

/**
 * Card "Central do assinante" do Painel.
 *
 * Mostrava um travessão fixo — ou seja, ocupava o lugar de um indicador sem indicar nada. Agora
 * traz as visitas do MÊS CORRENTE, zerando na virada do mês (o número que responde "a central está sendo usada?"), com
 * hoje / total / quantos assinantes diferentes no tooltip, e leva para a tela da Central.
 */
function ws_card_central(): string {
    $v = ['hoje' => 0, 'mes' => 0, 'total' => 0, 'clientes' => 0];
    try { $v = ws_central_visitas_resumo(ws_db()); } catch (Throwable $e) {}
    $n = number_format($v['mes'], 0, ',', '.');
    $titulo = $v['total'] > 0
        ? 'Visitas à Central do assinante — ' . $v['hoje'] . ' hoje · ' . $v['mes'] . ' neste mês · '
          . $v['total'] . ' no total · ' . $v['clientes'] . ' assinante(s) identificado(s). Conta uma visita por sessão.'
        : 'Nenhuma visita registrada ainda. O número começa a contar quando um assinante entrar na central.';
    /* Item 6: linkava para central.php, que é a tela de upload de logos/modelos (Provedor → Central
     * de modelos) — nada a ver com visita nenhuma. O card fala de VISITAS, então tem que abrir a
     * lista de quem visitou (central_visitas.php), não uma ferramenta de outro assunto. */
    return '<a class="ws-stat" href="central_visitas.php" title="' . h($titulo) . '">'
         . '<span' . ($v['mes'] > 0 ? ' style="color:#0ea5e9"' : '') . '>' . $n . '</span>'
         . '<label>Central — visitas (mês)</label></a>';   // só a quantidade; os nomes ficam na tela que o clique abre
}

/** Escape simples para HTML. */
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/**
 * Cliente DESATIVADO (03/10/2026): limpa nos contratos dele os dados de acesso e do equipamento — ID,
 * Login/Senha IPoE, SN da ONU/ONT e Login/Senha PPPoE — para a ONU e o login ficarem livres para outro
 * cliente (e a OLT não trazer mais o nome de quem saiu). O que estava gravado vai para o histórico.
 * Chame DEPOIS de tirar os logins do RADIUS (que precisa deles). Não mexe em cliente, fatura ou histórico.
 */
function ws_contratos_limpar_desativacao(PDO $db, int $cid, bool $limpar = true): void {
    /* 06/10/2026: a desativação pode ser SEM limpar (marcação na janela de confirmação). $limpar=false não toca em nada. */
    if (!$limpar) return;
    /* A LIMPEZA É O QUE IMPORTA e roda sempre: log e tarja do equipamento ficam em try/catch próprio, para nenhuma falha
       neles (coluna que não existe, evento) impedir o UPDATE que apaga os dados. */
    $colsC = [];
    try {
        ws_equip_snap_garantir($db);
        $antes = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=?");
        $antes->execute([$cid]);
        $linhasC = $antes->fetchAll(PDO::FETCH_ASSOC);
        if ($linhasC) $colsC = array_keys($linhasC[0]);
        foreach ($linhasC as $a) {
            $g = fn($k) => trim((string)($a[$k] ?? ''));
            $tinha = [];
            foreach (['ont_id' => 'ID', 'login_ipoe' => 'Login IPoE', 'sn_onu' => 'SN ONU/ONT', 'login_pppoe' => 'Login PPPoE'] as $col => $rot)
                if ($g($col) !== '') $tinha[] = $rot . ': ' . $a[$col];
            try { if ($tinha) ws_evento($db, $cid, 'desativacao', 'Contrato #' . (int)$a['id'] . ' — dados limpos na desativação (' . implode(' · ', $tinha) . ')'); } catch (Throwable $e) {}
            /* TARJA "Equipamento": guarda MAC, modelo, serial e comodato ANTES de limpar, para a ficha continuar mostrando o aparelho. */
            $snap = ['tipo' => $g('equip_tipo') !== '' ? $g('equip_tipo') : $g('equipamento'), 'mac' => $g('equip_mac'), 'modelo' => $g('equip_modelo'),
                     'serial' => $g('equip_serial') !== '' ? $g('equip_serial') : $g('sn_onu'), 'comodato' => (int)($a['comodato'] ?? 0),
                     'roteador' => $g('roteador_modelo')];
            if ($snap['mac'] !== '' || $snap['modelo'] !== '' || $snap['serial'] !== '' || $snap['comodato'] || $snap['roteador'] !== '')
                $db->prepare("UPDATE ws_contrato SET desativ_equip=? WHERE id=?")->execute([json_encode($snap, JSON_UNESCAPED_UNICODE), (int)$a['id']]);
        }
    } catch (Throwable $e) { @error_log('[desativar] tarja/log do equipamento falhou (a limpeza segue): ' . $e->getMessage()); }
    $db->prepare("UPDATE ws_contrato SET ont_id=NULL, login_ipoe=NULL, senha_ipoe=NULL, sn_onu=NULL, login_pppoe=NULL, senha_pppoe=NULL
                  WHERE cliente_id=?")->execute([$cid]);
    /* EQUIPAMENTO (06/10/2026): "limpando tudo" também zera a seção Equipamento do contrato — tipo, comodato, modelo, serial, MAC,
       foto e roteador. O aparelho não se perde: ficou na tarja da ficha (desativ_equip). Só toca nas colunas que existem. */
    try {
        $sets = [];
        foreach (['equipamento', 'equip_tipo', 'equip_modelo', 'equip_serial', 'equip_mac', 'equip_foto', 'roteador_comodato', 'roteador_modelo'] as $col)
            if (in_array($col, $colsC, true)) $sets[] = "$col=NULL";
        if (in_array('comodato', $colsC, true)) $sets[] = 'comodato=0';
        if ($sets) $db->prepare("UPDATE ws_contrato SET " . implode(', ', $sets) . " WHERE cliente_id=?")->execute([$cid]);
    } catch (Throwable $e) { @error_log('[desativar] limpar equipamento falhou: ' . $e->getMessage()); throw $e; }
}
/** Garante a coluna que guarda o equipamento do cliente desativado (migração idempotente, feita na hora de usar). */
function ws_equip_snap_garantir(PDO $db): void {
    static $ok = false; if ($ok) return; $ok = true;
    try {
        $q = $db->query("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_contrato' AND column_name='desativ_equip'");
        if ((int)$q->fetchColumn() === 0) $db->exec("ALTER TABLE ws_contrato ADD COLUMN desativ_equip VARCHAR(400) DEFAULT NULL");
    } catch (Throwable $e) {}
}
/** TARJA da ficha do cliente desativado: 📦 Equipamento — MAC · Modelo · Serial · Comodato (guardado quando se desativa LIMPANDO). */
function ws_tarja_equip_desativado(PDO $db, int $cid): string {
    $h = fn($x) => htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8');
    try {
        $q = $db->prepare("SELECT id, desativ_equip FROM ws_contrato WHERE cliente_id=? AND desativ_equip IS NOT NULL AND desativ_equip<>'' ORDER BY id");
        $q->execute([$cid]); $linhas = $q->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return ''; }
    $out = '';
    foreach ($linhas as $l) {
        $d = json_decode((string)$l['desativ_equip'], true); if (!is_array($d)) continue;
        $p = [];
        if (($d['tipo'] ?? '') !== '')   $p[] = $h($d['tipo']);
        $p[] = 'MAC: ' . (($d['mac'] ?? '') !== '' ? $h($d['mac']) : '—');
        $p[] = 'Modelo: ' . (($d['modelo'] ?? '') !== '' ? $h($d['modelo']) : '—');
        $p[] = 'Serial: ' . (($d['serial'] ?? '') !== '' ? $h($d['serial']) : '—');
        $p[] = 'Comodato: ' . (!empty($d['comodato']) ? '<b>Sim</b>' : 'Não');
        if (($d['roteador'] ?? '') !== '') $p[] = 'Roteador: ' . $h($d['roteador']);
        $out .= '<span class="ws-tag suspenso" title="Equipamento do cliente guardado ao desativar limpando os dados (contrato #' . (int)$l['id'] . ')" style="font-size:11px;padding:2px 9px;vertical-align:middle;margin-left:6px;font-weight:600">📦 Equipamento — ' . implode(' · ', $p) . '</span>';
    }
    return $out;
}
/** Janela de confirmação do "Desativar": escolhe entre desativar LIMPANDO tudo ou SEM limpar. Imprime o script uma vez só.
 *  Uso no link: onclick="return wsDesativar(this, 'Nome')" — acrescenta &limpar=1 ou &limpar=0 ao endereço. */
function ws_desativar_modal_js(): string {
    static $feito = false; if ($feito) return ''; $feito = true;
    return <<<'JS'
<script>
function wsDesativar(a, nome) {
  var old = document.getElementById('wsDesatBox'); if (old) old.remove();
  var bk = document.createElement('div'); bk.id = 'wsDesatBox';
  bk.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px';
  var bx = document.createElement('div');
  bx.style.cssText = 'background:Canvas;color:CanvasText;border-radius:14px;max-width:460px;width:100%;padding:20px 22px;box-shadow:0 18px 50px rgba(0,0,0,.4);font:14.5px/1.45 system-ui,Segoe UI,Roboto,sans-serif;text-align:left;white-space:normal';
  var t = document.createElement('div'); t.style.cssText = 'font-weight:700;font-size:16px;margin-bottom:6px';
  t.textContent = 'Desativar o cliente "' + nome + '"?';
  var d = document.createElement('div'); d.style.cssText = 'opacity:.8;margin-bottom:12px'; d.textContent = 'Ele será cancelado e removido do RADIUS. Escolha o que fazer com os dados:';
  function op(v, ck, tit, sub) {
    var l = document.createElement('label');
    l.style.cssText = 'display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1px solid rgba(128,128,128,.4);border-radius:10px;margin-bottom:8px;cursor:pointer;font-weight:400';
    var r = document.createElement('input'); r.type = 'radio'; r.name = 'wsDesatOp'; r.value = v; r.checked = ck; r.style.cssText = 'margin-top:3px;flex:0 0 auto;width:auto';
    var s = document.createElement('span'); s.innerHTML = '<b>' + tit + '</b><br><span style="opacity:.75;font-size:12.5px">' + sub + '</span>';
    l.appendChild(r); l.appendChild(s); return l;
  }
  var o1 = op('1', true, '🧹 Desativar limpando tudo', 'Apaga ID, Login/Senha IPoE, SN da ONU/ONT, Login/Senha PPPoE e a seção Equipamento (tipo, comodato, modelo, serial e MAC). O equipamento fica registrado numa tarja na ficha.');
  var o2 = op('0', false, '💾 Desativar sem limpar os dados', 'Mantém ID, logins/senhas e SN como estão.');
  var bt = document.createElement('div'); bt.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:14px';
  var ok = document.createElement('button'); ok.type = 'button'; ok.textContent = 'OK';
  ok.style.cssText = 'border:0;border-radius:10px;padding:9px 22px;background:#dc2626;color:#fff;font-weight:700;cursor:pointer;font-size:14px';
  var no = document.createElement('button'); no.type = 'button'; no.textContent = 'Cancelar';
  no.style.cssText = 'border:1px solid rgba(128,128,128,.5);border-radius:10px;padding:9px 18px;background:transparent;color:inherit;cursor:pointer;font-size:14px';
  /* Só fecha pelos botões: Esc e clique fora NÃO cancelam — a janela espera uma ação (OK ou Cancelar). */
  no.onclick = function () { bk.remove(); };
  ok.onclick = function () {
    var v = bx.querySelector('input[name=wsDesatOp]:checked').value;
    location.href = a.href + (a.href.indexOf('?') > -1 ? '&' : '?') + 'limpar=' + v;
  };
  bt.appendChild(ok); bt.appendChild(no);
  bx.appendChild(t); bx.appendChild(d); bx.appendChild(o1); bx.appendChild(o2); bx.appendChild(bt);
  bk.appendChild(bx); document.body.appendChild(bk); ok.focus();
  return false;
}
</script>
JS;
}

/**
 * Para onde voltar depois de uma ação feita na LISTA de clientes (nota, bloquear, confiar…).
 * Volta para a mesma lista (busca e página como estavam) já centralizada no cliente (#cliID), para o
 * operador não precisar pesquisar o nome de novo. Só aceita página do próprio sistema.
 */
function ws_volta_cli($volta, int $cid, string $padrao): string {
    $volta = (string)$volta;
    if (!preg_match('~^[a-z_]+\.php(\?[^#\s<>"\']*)?$~i', $volta)) $volta = $padrao;
    return $volta . (strpos($volta, 'p=clientes') !== false && $cid > 0 ? '#cli' . $cid : '');
}
/** Versão de cache automática pra JS/CSS — usa a data real do arquivo, então QUALQUER alteração
 *  futura já força o navegador a buscar de novo sozinho, sem precisar lembrar de trocar "?v=N". */
/** VERSÃO CURTA p/ o rodapé: data/hora do arquivo MAIS NOVO do módulo ("v23.09.26 16:54"); o detalhe
 *  (arquivos, md5 e datas) fica no title — passar o mouse. Mesma ideia no rodapé da OLT (olt.php). */
function ws_versao_curta(array $rels, string $base = ''): array {
    $base = $base !== '' ? $base : WS_DIR; $max = 0; $det = [];
    foreach ($rels as $rel) { $f = $base . '/' . ltrim($rel, '/'); if (!is_file($f)) continue; $t = (int)filemtime($f); $max = max($max, $t);
        $det[] = $rel . ' ' . substr((string)@md5_file($f), 0, 8) . ' ' . date('d/m H:i', $t); }
    return ['txt' => $max ? 'v' . date('d.m.y', $max) : '', 'tip' => 'Versão de ' . ($max ? date('d/m/Y H:i', $max) : '—') . "\n" . implode("\n", $det) . "\n" . (string)($_SERVER['HTTP_HOST'] ?? '')];
}
function ws_ver(string $rel): string { $f = WS_DIR . '/' . ltrim($rel, '/'); return is_file($f) ? (filemtime($f) . 'x' . filesize($f)) : '1'; }
/* =====================================================================================================
 * RECURSOS DO SISTEMA (Provedor → Recursos do sistema) — as opções de comportamento do sistema:
 * Setup, Tema, Mapas e Vencimentos. Guardado em cache/recursos.json.
 *
 * Os PADRÕES abaixo são exatamente o comportamento que o WellSystem já tinha antes desta tela existir:
 * enquanto ninguém mudar nada, nenhuma cobrança, bloqueio ou tela se comporta diferente.
 * ===================================================================================================== */
function ws_recursos_padrao(): array {
    return [
        // Setup — recursos do sistema
        'mascara_moeda'       => 0,        // campos de dinheiro formatados 0,00 enquanto digita
        'mostrar_senhas'      => 1,        // senha PPPoE/IPoE visível em listas e contratos
        'validar_cpf'         => 1,        // recusa CPF/CNPJ com dígito verificador errado
        'chamados_bloqueados' => 1,        // permite abrir chamado para cliente bloqueado
        // Geração automática de títulos
        'vence_sabado'        => 1,        // 0 = vencimento em sábado/domingo passa para segunda
        'auto_titulos'        => 1,        // quantos meses de fatura o faturamento mantém gerados (0 = não gera)
        'manter_titulos'      => 1,        // 1 = completa sempre; 0 = só gera para contrato ainda sem fatura
        'auto_adicionais'     => 0,        // 1 = auto lançamento (títulos e carnês) também para cliente ADICIONAL; 0 = só o titular
        // Geração automática de carnês
        'auto_parcelas_carne' => 1,        // parcelas sugeridas ao gerar carnê
        'manter_carne'        => 0,        // 1 = quando acabam as parcelas em aberto, gera novo carnê
        // Corte e desbloqueio
        'corte_auto'          => 1,        // bloqueia sozinho quem passa dos dias de tolerância
        'dias_corte'          => [0, 1, 2, 3, 4, 5, 6],   // dias da semana em que o corte pode acontecer (0=dom)
        'desbloqueio_auto'    => 1,        // libera sozinho quem pagou
        'obs_auto'            => 0,        // mostra em "Observação" quem tem 1+ título atrasado (sem bloquear)
        // Tema
        'cor_padrao'          => 'vinho',  // cor do sistema (vale para todos ao gravar; quem escolher outra depois mantém a sua)
        'cor_padrao_em'       => 0,        // quando a cor padrão foi gravada (é o que faz ela valer para todos)
        'registros_pagina'    => 50,       // itens por página nas listas
        'trava_minutos'       => 120,      // tranca a tela e pede a senha depois deste tempo sem uso (0 = nunca)
        'auto_atualizar_seg'  => 120,      // recarrega a tela aberta sozinha a cada N segundos, só quando ninguém está mexendo (0 = desligado)
        // Mapas
        'mapa_servidor'       => 'osm',    // osm = OpenStreetMap; google = Google Maps
        'google_key'          => '',
        'auto_coordenadas'    => 1,        // busca latitude/longitude pelo endereço digitado
        // Vencimentos
        'venc_dias'           => range(1, 31),
        // Boletos avulsos / Carnê
        'bol_emissao_padrao'  => '',       // emissao padrao ao gerar ('' = automático pelo gateway, 'gateway', ou 'proprio')
        'bol_banco_padrao'    => 0,        // conta (ws_banco.id) padrao ao gerar (0 = segue a conta do cadastro)
    ];
}
function ws_recursos(): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $def = ws_recursos_padrao();
    $f = WS_CACHE . '/recursos.json';
    $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    $cache = is_array($j) ? array_merge($def, array_intersect_key($j, $def)) : $def;
    // tipos sempre coerentes, mesmo com arquivo editado à mão
    foreach (['mascara_moeda','mostrar_senhas','validar_cpf','chamados_bloqueados','vence_sabado','manter_titulos','auto_adicionais','manter_carne','corte_auto','desbloqueio_auto','obs_auto','auto_coordenadas'] as $k) $cache[$k] = (int)!empty($cache[$k]);
    $cache['bol_banco_padrao']    = (int)$cache['bol_banco_padrao'];
    $cache['bol_emissao_padrao']  = in_array($cache['bol_emissao_padrao'], ['gateway','proprio'], true) ? $cache['bol_emissao_padrao'] : '';
    $cache['cor_padrao_em']       = max(0, (int)$cache['cor_padrao_em']);
    $cache['auto_titulos']        = max(0, min(24, (int)$cache['auto_titulos']));
    $cache['auto_parcelas_carne'] = max(0, min(36, (int)$cache['auto_parcelas_carne']));
    $cache['registros_pagina']    = in_array((int)$cache['registros_pagina'], [25, 50, 100], true) ? (int)$cache['registros_pagina'] : 50;
    $cache['trava_minutos']       = max(0, min(1440, (int)$cache['trava_minutos']));
    $cache['auto_atualizar_seg']  = (int)$cache['auto_atualizar_seg'] <= 0 ? 0 : max(30, min(3600, (int)$cache['auto_atualizar_seg']));
    $cache['cor_padrao']          = in_array($cache['cor_padrao'], ['vinho','azul','preto','verde'], true) ? $cache['cor_padrao'] : 'vinho';
    $cache['mapa_servidor']       = $cache['mapa_servidor'] === 'google' ? 'google' : 'osm';
    $cache['google_key']          = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$cache['google_key']);
    $cache['dias_corte']          = array_values(array_unique(array_filter(array_map('intval', (array)$cache['dias_corte']), fn($d) => $d >= 0 && $d <= 6)));
    $cache['venc_dias']           = array_values(array_unique(array_filter(array_map('intval', (array)$cache['venc_dias']), fn($d) => $d >= 1 && $d <= 31)));
    sort($cache['dias_corte']); sort($cache['venc_dias']);
    if (!$cache['venc_dias']) $cache['venc_dias'] = range(1, 31);   // nenhum dia marcado não pode travar o cadastro
    return $cache;
}
function ws_recursos_salvar(array $novos): bool {
    $atual = ws_recursos();
    $dados = array_merge($atual, array_intersect_key($novos, ws_recursos_padrao()));
    $ok = @file_put_contents(WS_CACHE . '/recursos.json', json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
    if ($ok) @chmod(WS_CACHE . '/recursos.json', 0640);
    return $ok;
}
/** Chave PIX impressa no boleto/carnê quando o título foi emitido pelo gateway (CelCoin/GalaxPay).
 *  ÚNICO ponto onde ela mora: trocar a chave é mudar só esta linha. */
function ws_pix_chave_gateway(): string { return '04154749000144'; }
/** Competência (AAAA-MM) -> "MM/AAAA" para o campo "mês referente". Formato inesperado volta como veio. */
function ws_mes_ref_fmt($comp): string {
    $comp = trim((string)$comp);
    return preg_match('/^(\d{4})-(\d{2})/', $comp, $m) ? ($m[2] . '/' . $m[1]) : $comp;
}
/** Taxa de cobrança das contas ativas: [banco_id => "12,50"] só das que estão com "Taxa de cobrança = Sim".
 *  Chave 0 = a conta que vale quando o boleto sai em "Conta padrão do sistema (1ª ativa)". */
function ws_taxas_cobranca_bancos(PDO $db): array {
    $out = []; $primeiro = null;
    try {
        foreach ($db->query("SELECT id,taxa_cobranca_ativa,taxa_cobranca_valor FROM ws_banco WHERE ativo=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $b) {
            $v = (!empty($b['taxa_cobranca_ativa']) && (float)$b['taxa_cobranca_valor'] > 0) ? number_format((float)$b['taxa_cobranca_valor'], 2, ',', '') : '';
            if ($primeiro === null) $primeiro = $v;
            if ($v !== '') $out[(int)$b['id']] = $v;
        }
    } catch (Throwable $e) {}
    if ($primeiro) $out[0] = $primeiro;
    return $out;
}
/** Conta vinculada a cada Emissão: ['gateway' => banco_id, 'proprio' => banco_id]. Com mais de uma conta na
 *  mesma emissão vale a primeira cadastrada. Emissão sem conta vinculada simplesmente não aparece. */
function ws_bancos_por_emissao(PDO $db): array {
    $out = [];
    try {
        foreach ($db->query("SELECT id,emissao FROM ws_banco WHERE ativo=1 AND emissao IN('gateway','proprio','lytex') ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $b)
            if (!isset($out[$b['emissao']])) $out[$b['emissao']] = (int)$b['id'];
    } catch (Throwable $e) {}
    return $out;
}
/** "Máximo de dias para recalcular 2ª via" (Banco / Contas): título ABERTO/VENCIDO cuja conta tem esse limite e
 *  que já passou de N dias do vencimento vira CANCELADO — e só isso. Conta com limite 0 nunca cancela.
 *  Conta do título = a escolhida no título > a do contrato > a 1ª ativa com PIX (a mesma que imprime o boleto).
 *  Não fala com o gateway: a cobrança registrada na CelCoin não é cancelada por aqui. Devolve quantos cancelou. */
function ws_faturas_cancelar_expiradas(PDO $db): int {
    $n = 0;
    try {
        $bancos = $db->query("SELECT id,pix,max_dias_recalc FROM ws_banco WHERE ativo=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
        $padrao = 0; foreach ($bancos as $b) { if (trim((string)$b['pix']) !== '') { $padrao = (int)$b['id']; break; } }
        foreach ($bancos as $b) {
            $dias = (int)$b['max_dias_recalc']; $id = (int)$b['id'];
            if ($dias <= 0) continue;
            $st = $db->prepare("UPDATE ws_fatura f LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
                                SET f.status='cancelado', f.obs=LEFT(CONCAT_WS(' | ', NULLIF(f.obs,''), ?), 255)
                                WHERE f.status IN('aberto','vencido')
                                  AND f.vencimento < DATE_SUB(CURDATE(), INTERVAL ? DAY)
                                  AND COALESCE(NULLIF(f.banco_id,0), NULLIF(ct.banco_id,0), " . (int)$padrao . ") = ?");
            $st->execute(['Cancelado automaticamente em ' . date('d/m/Y') . ': passou de ' . $dias . ' dia(s) do vencimento.', $dias, $id]);
            $n += $st->rowCount();
        }
    } catch (Throwable $e) {}
    return $n;
}
/** "Observação automática" (Recursos do sistema): trecho SQL que soma à Observação o cliente ativo com
 *  1+ título vencido em aberto — só na LISTA/contagem, sem mudar status nem bloqueio. Vazio se desligado. */
function ws_obs_auto_sql(string $a): string {
    if (!ws_recursos()['obs_auto']) return '';
    return " OR ($a.status='ativo' AND EXISTS(SELECT 1 FROM ws_fatura fo WHERE fo.cliente_id=$a.id"
         . " AND fo.status IN('aberto','vencido','processando') AND fo.vencimento < CURDATE()))";
}
/** Vencimento no passado? (vazio = não informado, não é passado). Boleto novo nunca nasce vencido. */
function ws_venc_passado(string $venc): bool {
    $venc = trim($venc);
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $venc) === 1 && $venc < date('Y-m-d');
}
function ws_venc_passado_msg(string $venc): string {
    return '⚠️ Vencimento ' . date('d/m/Y', strtotime($venc)) . ' já passou — o boleto não foi criado. Use hoje ou uma data futura.';
}
/** Vencimento que cai no fim de semana vai para segunda, quando "Vence aos sábados" = Não. */
function ws_venc_ajustar(string $ymd): string {
    if (ws_recursos()['vence_sabado']) return $ymd;
    $t = strtotime($ymd); if ($t === false) return $ymd;
    $dow = (int)date('w', $t);                       // 6 = sábado, 0 = domingo
    if ($dow === 6) $t = strtotime('+2 days', $t);
    elseif ($dow === 0) $t = strtotime('+1 day', $t);
    return date('Y-m-d', $t);
}
/** <select> do dia de vencimento com só os dias liberados (mantém o dia atual, mesmo fora da lista). */
function ws_venc_dia_select(string $nome, $atual, string $extra = ''): string {
    $dias = ws_recursos()['venc_dias'];
    $atual = (int)$atual;
    if ($atual < 1 || $atual > 31) $atual = 0;
    $html = '<select name="' . h($nome) . '" ' . $extra . '>';
    if ($atual && !in_array($atual, $dias, true)) {
        $html .= '<option value="' . $atual . '" selected>' . sprintf('%02d', $atual) . ' (fora dos dias liberados)</option>';
    }
    if (!$atual) {   // contrato novo: o dia de hoje (como era antes) ou o próximo dia liberado
        $hoje = (int)date('j'); $atual = $dias[0];
        foreach ($dias as $d) { if ($d >= $hoje) { $atual = $d; break; } }
    }
    foreach ($dias as $d) $html .= '<option value="' . $d . '"' . ($d === $atual ? ' selected' : '') . '>' . sprintf('%02d', $d) . '</option>';
    return $html . '</select>';
}

/** Valor do php.ini ("2M", "100M", "1G", "-1") em bytes. -1/0 = sem limite → devolve 0. */
if (!function_exists('ws_ini_bytes')) {
function ws_ini_bytes(string $v): int {
    $v = trim($v); if ($v === '' || $v === '-1') return 0;
    $n = (float)$v; $u = strtolower(substr($v, -1));
    $mult = ['k' => 1024, 'm' => 1048576, 'g' => 1073741824][$u] ?? 1;
    return max(0, (int)($n * $mult));
}
}
/** Bytes → "100 MB" / "512 KB". */
if (!function_exists('ws_bytes_legivel')) {
function ws_bytes_legivel(int $b): string {
    if ($b >= 1073741824) return rtrim(rtrim(number_format($b / 1073741824, 1, ',', ''), '0'), ',') . ' GB';
    if ($b >= 1048576) return rtrim(rtrim(number_format($b / 1048576, 1, ',', ''), '0'), ',') . ' MB';
    return max(1, (int)round($b / 1024)) . ' KB';
}
}

/** Formata CPF (11 díg.) ou CNPJ (14 díg.) com pontuação. Cai pro valor original se não bater. */
function h_doc($v): string {
    $d = preg_replace('/\D/', '', (string)$v);
    if (strlen($d) === 11) return substr($d,0,3).'.'.substr($d,3,3).'.'.substr($d,6,3).'-'.substr($d,9,2);
    if (strlen($d) === 14) return substr($d,0,2).'.'.substr($d,2,3).'.'.substr($d,5,3).'/'.substr($d,8,4).'-'.substr($d,12,2);
    return h($v);
}
/** Formata telefone/celular BR ((00) 00000-0000 ou (00) 0000-0000). */
/** Usuário logado (sessão). Fica aqui em config.php — usado por TODA página do sistema — em vez
 *  de só no erp.php, pra nunca dar "função indefinida" em Financeiro/Radius/Chamados/etc. */
if (!function_exists('ws_user')) {
    function ws_user(): ?array { return $_SESSION['ws_user'] ?? null; }
}

/**
 * Marca que o operador logado está ATIVO agora (para a tela de "atendentes online").
 *
 * COMO A PRESENÇA É MEDIDA
 * Não existe "logout" confiável: o operador fecha a aba, cai a internet, o computador hiberna.
 * Por isso presença aqui é "deu sinal de vida recentemente" — cada página aberta atualiza o
 * carimbo, e quem não aparece há alguns minutos deixa de constar como online. É a mesma ideia do
 * "visto por último" dos mensageiros, e é honesta: não promete saber o que não dá para saber.
 *
 * CUSTO: um UPDATE por operador a cada 60 segundos, no máximo. A trava fica na sessão, não no
 * banco — sem ela, cada clique em cada tela viraria uma escrita, e num expediente com dez
 * atendentes isso seria escrita constante numa tabela que quase nunca muda.
 */
function ws_marcar_presenca(): void {
    $u = ws_user(); if (!$u || empty($u['id'])) return;
    $agora = time();
    if (!empty($_SESSION['ws_presenca_em']) && ($agora - (int)$_SESSION['ws_presenca_em']) < 60) return;
    $_SESSION['ws_presenca_em'] = $agora;
    try { ws_db()->prepare("UPDATE ws_usuario SET visto_em = NOW() WHERE id = ?")->execute([(int)$u['id']]); }
    catch (Throwable $e) { /* coluna ainda não criada, ou banco fora: presença não é crítica */ }
}

/** SAIU do sistema: apaga o carimbo de presença NA HORA.
 *  Sem isto o operador continuava aparecendo em "Atendentes online" por até 5 minutos depois de
 *  clicar em sair — a tela dizia que ele estava no sistema quando ele já tinha ido embora. */
function ws_marcar_saida(?int $usuarioId = null): void {
    if ($usuarioId === null) { $u = ws_user(); $usuarioId = (int)($u['id'] ?? 0); }
    unset($_SESSION['ws_presenca_em'], $_SESSION['ws_ativ_em']);
    if ($usuarioId <= 0) return;
    try { ws_db()->prepare("UPDATE ws_usuario SET visto_em = NULL WHERE id = ?")->execute([$usuarioId]); }
    catch (Throwable $e) { /* presença não é crítica: nunca impede a saída */ }
}

/** Operadores vistos nos últimos N minutos (padrão 5). Base da tela de atendentes online. */
function ws_operadores_online(int $minutos = 5): array {
    try {
        $st = ws_db()->prepare(
            "SELECT id, nome, login, nivel, visto_em,
                    TIMESTAMPDIFF(SECOND, visto_em, NOW()) segundos
               FROM ws_usuario
              WHERE ativo = 1 AND visto_em IS NOT NULL
                AND visto_em >= (NOW() - INTERVAL ? MINUTE)
              ORDER BY visto_em DESC");
        $st->execute([max(1, $minutos)]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return []; }
}
/** Nível de acesso NUMÉRICO do usuário logado: 1=só leitura · 2=usa tudo mas não deleta/configura
 *  · 3=configura e deleta tudo · 99=root (dono do sistema). Admin antigo (papel 'admin') sempre
 *  conta como nível 3 mesmo que o campo novo ainda não tenha sido migrado (transição suave). */
function ws_nivel_acesso(): int {
    $u = ws_user(); if (!$u) return 0;
    $n = (int)($u['nivel_acesso'] ?? 0);
    if ($n < 1 && ($u['nivel'] ?? '') === 'admin') $n = 99;
    // DEMO: o visitante NUNCA é root (bloqueia menu de emergência e áreas críticas). Máx. nível 3.
    if (function_exists('ws_em_demo') && ws_em_demo() && $n > 3) $n = 3;
    return max($n, 1);
}
function ws_eh_root(): bool { return ws_nivel_acesso() >= 99; }
/** Rótulo VISÍVEL do status de cliente/contrato: o valor gravado continua 'cancelado' (SQL, filtros, API); na tela lê-se "desativado" (07/10/2026). */
function ws_status_rotulo(?string $s): string { return $s === 'cancelado' ? 'desativado' : (string)$s; }

define('WS_MANUTENCAO_LOGIN_CFG', WS_CACHE . '/manutencao_login.json');
/** Modo manutenção (login travado p/ todo mundo exceto admin/root). Lido em toda página. */
function ws_manutencao_login(): array {
    $def = ['ativo' => false, 'motivo' => ''];
    if (is_file(WS_MANUTENCAO_LOGIN_CFG)) {
        $c = json_decode((string)@file_get_contents(WS_MANUTENCAO_LOGIN_CFG), true);
        if (is_array($c)) return array_merge($def, $c);
    }
    return $def;
}
/** Liga/desliga o modo manutenção. Só quem já É root pode mexer — sem isso, dava pra um nível
 *  menor se trancar fora sozinho, ou pior, trancar o root fora também por engano. */
function ws_manutencao_login_salvar(bool $ativo, string $motivo = ''): bool {
    if (!ws_eh_root()) return false;
    @file_put_contents(WS_MANUTENCAO_LOGIN_CFG, json_encode(['ativo' => $ativo, 'motivo' => trim($motivo)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_MANUTENCAO_LOGIN_CFG, 0640);
    return true;
}
/** Este usuário (linha de ws_usuario, ou o array de $_SESSION['ws_user']) fica de fora enquanto o
 *  modo manutenção estiver ativo? Só admin/root (nivel_acesso>=99, ou nivel='admin' antigo) passa. */
function ws_manutencao_login_bloqueia(array $usuario): bool {
    if (!ws_manutencao_login()['ativo']) return false;
    $n = (int)($usuario['nivel_acesso'] ?? 0);
    if ($n < 1 && ($usuario['nivel'] ?? '') === 'admin') $n = 99;
    return $n < 99;
}
/**
 * TELAS DE INFRAESTRUTURA — concentradores, NAS, diagnóstico e comandos do servidor.
 *
 * São as telas que mexem (ou ensinam a mexer) no que mantém a rede de pé: cadastro de
 * concentrador, secret do RADIUS, estado do servidor e a lista de comandos de terminal. Um erro
 * ali derruba o provedor inteiro, não um cliente. Por isso ficam no nível 3 e root.
 *
 * O atendimento (níveis 1 e 2) continua com o PAINEL DOS CONCENTRADORES, que é só leitura: ver
 * quem está online, derrubar uma conexão, acompanhar a sessão do cliente que ligou.
 */
function ws_pode_infra(): bool { return ws_nivel_acesso() >= 3; }

/** Barra a tela de infraestrutura para níveis 1 e 2 e manda de volta para o painel permitido. */
function ws_exigir_infra(string $volta = 'servidores.php'): void {
    if (ws_pode_infra()) return;
    $_SESSION['ws_flash_err'] = '🔒 Esta tela é de nível 3 (configuração) para cima. '
        . 'O Painel dos Concentradores continua liberado para você.';
    header('Location: ' . $volta); exit;
}

/**
 * DATA DE CANCELAMENTO QUE FALTOU — conserto do histórico, uma vez só.
 *
 * Até agora, desativar um cliente gravava a data no CADASTRO (ws_cliente.data_desativacao) mas não
 * no CONTRATO. O relatório de Ativação/Desativação lê o contrato, então mostrava "Desativações: 0"
 * mesmo com centenas de clientes cancelados — número errado, e ninguém sabia por quê.
 *
 * Aqui a data que JÁ EXISTE no cadastro é copiada para os contratos cancelados que estão sem ela.
 * Não inventa data nenhuma: contrato cancelado cujo cliente também não tem data continua sem, e o
 * relatório mostra esse total à parte, para o número ser honesto.
 *
 * @return int quantos contratos ganharam a data
 */
function ws_contrato_datar_cancelamentos(PDO $db): int {
    try {
        $st = $db->prepare("UPDATE ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                               SET ct.data_cancelamento = c.data_desativacao
                             WHERE ct.status = 'cancelado' AND ct.data_cancelamento IS NULL
                               AND c.data_desativacao IS NOT NULL");
        $st->execute();
        return $st->rowCount();
    } catch (Throwable $e) { return 0; }
}

/** CLIENTES ATIVADOS E DESATIVADOS NO MÊS CORRENTE (16/10/2026) — zera sozinho a cada mês (conta sempre do dia 1 ao último dia do mês de hoje).
 *  Mesma contagem do relatório Ativação/Desativação: ativado = data de ativação do contrato no mês; desativado = contrato cancelado com data de cancelamento no mês. */
function ws_clientes_mes(): array {
    static $r = null; if ($r !== null) return $r;
    $ini = date('Y-m-01'); $fim = date('Y-m-t'); $r = ['a' => 0, 'd' => 0, 'ini' => $ini, 'fim' => $fim];
    try {
        $db = ws_db();
        $r['a'] = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE data_ativacao BETWEEN '$ini' AND '$fim'")->fetchColumn();
        $r['d'] = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE status='cancelado' AND data_cancelamento BETWEEN '$ini' AND '$fim'")->fetchColumn();
    } catch (Throwable $e) {}
    return $r;
}
/** Os dois cartões do Painel (clicáveis: abrem a lista que formou cada número). */
function ws_cards_clientes_mes(): string {
    $m = ws_clientes_mes(); $q = '&de=' . $m['ini'] . '&ate=' . $m['fim']; $per = date('m/Y');
    return '<a class="ws-stat" href="relatorios.php?p=base&ver=ativacoes' . $q . '" title="Contratos ativados neste mês — zera todo mês"><span>' . $m['a'] . '</span><label>Clientes ativados no mês</label><small class="ws-stat-per">' . $per . '</small></a>'
         . '<a class="ws-stat" href="relatorios.php?p=base&ver=desativacoes' . $q . '" title="Contratos desativados neste mês — zera todo mês"><span>' . $m['d'] . '</span><label>Clientes desativados no mês</label><small class="ws-stat-per">' . $per . '</small></a>';
}

/** VÊ OS TOTAIS DE DINHEIRO DO PROVEDOR (caixa, balancete, a receber, recebido no mês)?
 *
 *  Só nível 3 e root. Atendimento (níveis 1 e 2) recebe pagamento, imprime recibo e vê o título do
 *  cliente que está atendendo — mas o CAIXA do provedor, o quanto entrou no mês e a inadimplência
 *  não são informação de atendimento. É por linha de visão, não por desconfiança: quem atende não
 *  precisa desse número para trabalhar, e ele costuma acabar em conversa fora da empresa.
 *  Some o número, não a tela: a pessoa continua trabalhando normalmente em tudo o mais. */
function ws_ver_valores(): bool { return ws_nivel_acesso() >= 3; }

/** SOMA DE DINHEIRO NA TELA, JÁ RESPEITANDO O NÍVEL.
 *
 *  Nível 3 e root veem "R$ 596.014,69"; atendimento vê "*****". Preferimos o asterisco a sumir com
 *  o cartão: o atendente enxerga que ali existe um total (a tela não fica torta, o lugar continua
 *  reconhecível) e só não lê o número. Vale para TOTAIS do provedor — o valor do título do cliente
 *  que está sendo atendido continua visível, senão não dá para atender. */
function ws_valor_txt(float $v, string $prefixo = 'R$ '): string {
    return ws_ver_valores() ? $prefixo . number_format($v, 2, ',', '.') : '*****';
}

/**
 * CONFIGURAÇÃO DE API — VÊ, MAS NÃO MEXE (níveis 1 e 2).
 *
 * Gateway de boleto/PIX, WhatsApp, NFS-e, tokens de webhook: um caractere trocado por engano numa
 * credencial derruba a cobrança ou o envio do provedor inteiro, e o erro só aparece horas depois,
 * longe de quem mexeu. Por isso a tela CONTINUA ABRINDO para o atendimento — dá para conferir qual
 * gateway está ativo, qual instância, qual ambiente, e responder o cliente — mas os campos ficam
 * travados e o Salvar não grava.
 *
 * São duas trancas, de propósito: ws_api_bloqueio_html() trava o formulário na tela (o que a pessoa
 * vê) e ws_api_exigir_edicao() recusa o POST (o que realmente protege — formulário na tela se burla
 * em dez segundos pelo navegador).
 */
function ws_pode_editar_api(): bool { return ws_nivel_acesso() >= 3; }

/** Recusa a GRAVAÇÃO de configuração de API e devolve para a mesma tela com o aviso. */
function ws_api_exigir_edicao(string $volta): void {
    if (ws_pode_editar_api()) return;
    $_SESSION['ws_flash_err'] = '🔒 Configuração de API é somente leitura no seu nível. '
        . 'A tela continua aberta para consulta — quem altera é nível 3 ou root.';
    header('Location: ' . $volta); exit;
}

/**
 * Aviso + trava visual da tela de API. Retorna string vazia para quem pode editar.
 *
 * Trava só formulários POST (os que gravam); busca e filtro, que são GET, seguem funcionando. Um
 * formulário que precise continuar livre nessa tela é marcado com data-api-livre no HTML. Campo de
 * senha continua senha: o "mostrar" some junto, para o token não ir parar numa foto de tela.
 */
function ws_api_bloqueio_html(): string {
    if (ws_pode_editar_api()) return '';
    return ws_bloqueio_leitura_html('Você pode conferir esta configuração, mas alterar credencial de API é de nível 3 e root.');
}

/** Mesmo cadeado, texto próprio — serve para plano, conta/banco/PIX e qualquer tela só de consulta. */
function ws_bloqueio_leitura_html(string $motivo): string {
    return '<div class="ws-alert" style="background:rgba(217,119,6,.10);color:#b45309;border:1px solid #d97706">'
         . '🔒 <b>Somente leitura.</b> ' . htmlspecialchars($motivo, ENT_QUOTES, 'UTF-8') . '</div>'
         . "<script>(function(){function t(){document.querySelectorAll('form').forEach(function(f){"
         . "if((f.getAttribute('method')||'get').toLowerCase()!=='post'||f.hasAttribute('data-api-livre'))return;"
         . "f.querySelectorAll('input,select,textarea,button').forEach(function(e){var k=(e.type||'').toLowerCase();"
         . "if(k==='hidden')return;"
         . "if(e.tagName==='SELECT'||e.tagName==='BUTTON'||['submit','button','reset','checkbox','radio','file'].indexOf(k)>=0)e.disabled=true;"
         . "else e.readOnly=true;"
         . "e.title='Somente leitura neste nível de acesso.';});"
         . "f.addEventListener('submit',function(ev){ev.preventDefault();});});}"
         . "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',t);else t();})();</script>";
}

/**
 * CADASTROS DO DIA A DIA — cidade, bairro, ramal, zona, equipamento em comodato.
 *
 * Isto é trabalho de quem atende: cadastrar o bairro novo que apareceu na rua, o ramal da torre, o
 * roteador que saiu em comodato. Travar em nível 3 só fazia o atendimento parar para pedir. Fica
 * liberado para todo usuário com login.
 *
 * FORA daqui, de propósito: PLANO (é preço) e CONTA/BANCO/PIX (é para onde o dinheiro vai). Essas
 * duas o atendimento VÊ, para conferir com o cliente, mas não altera — ver ws_pode_editar_preco().
 */
function ws_pode_cadastro_basico(): bool { return ws_nivel_acesso() >= 1; }

/** Plano (preço) e conta/banco/PIX: nível 3 e root alteram; o resto só consulta. */
function ws_pode_editar_preco(): bool { return ws_nivel_acesso() >= 3; }

/** VALOR MENSAL DO CONTRATO (26/10/2026, pedido do dono): nível 2 também digita um valor diferente do plano (antes só nível 3+/root). Nível 1 é somente leitura e não salva nada. A alteração segue registrada no histórico do cliente ("Plano/valor alterado"). */
function ws_pode_editar_valor_contrato(): bool { return ws_nivel_acesso() >= 2; }

/** Pode configurar (telas de Config/Cadastros/Provedor) e apagar registros. */
function ws_pode_configurar(): bool { return ws_nivel_acesso() >= 3; }
/** Nível 2 já usa TUDO no dia a dia: cria/exclui cliente, boleto, contrato, aprovisiona OLT,
 *  imprime recibo/carnê — só NÃO mexe em configuração técnica (cadastros de cidade/bairro/ramal/
 *  NAS/concentrador/régua/backup/CTO), que fica reservada pro nível 3+ (ws_pode_configurar). */
function ws_pode_deletar(): bool { return ws_nivel_acesso() >= 2; }
/** Nível 1 = só leitura — não deve conseguir salvar/enviar/excluir nada. */
function ws_somente_leitura(): bool { return ws_nivel_acesso() <= 1; }

/** Retorna o CNPJ do próprio provedor (limpo de pontos/traços/barras). */
function ws_provedor_cnpj(): string {
    static $cnpj = null;
    if ($cnpj !== null) return $cnpj;
    $cnpj = '';
    $file = WS_CACHE . '/provedor.json';
    if (is_file($file)) {
        $j = json_decode((string)@file_get_contents($file), true);
        if (is_array($j) && !empty($j['cnpj'])) $cnpj = preg_replace('/\D/', '', $j['cnpj']);
    }
    return $cnpj;
}

/** Registra no log NATIVO de boletos excluídos ANTES de apagar de verdade (guarda os dados pra
 *  consulta depois). Chamada em TODO ponto do sistema que apaga uma fatura — sem isso, o dado
 *  simplesmente sumia sem deixar rastro nenhum. */
function ws_fatura_log_exclusao(PDO $db, int $faturaId, ?string $motivo = null): void {
    $f = null;
    try {
        $st = $db->prepare("SELECT f.*, c.nome cliente_nome FROM ws_fatura f LEFT JOIN ws_cliente c ON c.id=f.cliente_id WHERE f.id=?");
        $st->execute([$faturaId]); $f = $st->fetch();
        if (!$f) return;
        $motivo = trim((string)$motivo);
        $db->prepare("INSERT INTO ws_fatura_excluida (fatura_id,cliente_id,cliente_nome,competencia,vencimento,valor,status_antes,excluido_por,motivo)
                      VALUES (?,?,?,?,?,?,?,?,?)")
           ->execute([$faturaId, $f['cliente_id'], $f['cliente_nome'], $f['competencia'] ?? null, $f['vencimento'] ?? null,
                      $f['valor'] ?? null, $f['status'] ?? null, ws_user()['nome'] ?? 'desconhecido', ($motivo !== '' ? $motivo : null)]);
    } catch (Throwable $e) { /* log nunca deve impedir a exclusão em si */ }
    /* Título emitido no CELCASH e ainda não pago (16/10/2026): cancela a cobrança lá também — senão ela fica ATIVA no gateway (o cliente pode pagar um boleto que não existe mais no WellSystem e a baixa não acha o título). Falha não impede a exclusão; fica no log. */
    try {
        if (!empty($f['celcash_charge_id']) && !in_array((string)($f['status'] ?? ''), ['pago', 'processando'], true) && is_file(__DIR__ . '/celcash.php')) {
            require_once __DIR__ . '/celcash.php';
            [$okCc, $msgCc] = ws_celcash_cancelar_cobranca((string)$f['celcash_charge_id']);
            @file_put_contents(WS_CACHE . '/celcash_cancelamentos.log', '[' . date('c') . "] [Fatura #$faturaId · cobrança " . $f['celcash_charge_id'] . '] ' . ($okCc ? 'cancelada' : $msgCc) . "
", FILE_APPEND);
        }
    } catch (Throwable $e) {}
    /* Título emitido na Lytex e ainda não pago: cancela lá também, senão o cliente continua podendo
       pagar um boleto que não existe mais no WellSystem. Falha no cancelamento não impede a exclusão. */
    try {
        if (!empty($f['lytex_id']) && ($f['status'] ?? '') !== 'pago' && is_file(__DIR__ . '/lytex.php')) {
            require_once __DIR__ . '/lytex.php';
            if (ws_lytex_pronto()) { [$okC, $msgC] = ws_lytex_cancelar((string)$f['lytex_id']);
                @file_put_contents(WS_CACHE . '/webhook_lytex.log', '[' . date('c') . "] [CANCELAMENTO Fatura #$faturaId] " . ($okC ? 'ok' : $msgC) . "\n", FILE_APPEND); }
        }
    } catch (Throwable $e) {}
}

/** Confere a SENHA DO PRÓPRIO OPERADOR logado (não precisa ser root) — usada na confirmação de
 *  ações destrutivas do dia a dia, como excluir título (tela "Excluir título": Motivo + Senha).
 *  Mesmo espírito do mnt_senha_ok() de manutencao.php, só que reutilizável por qualquer tela. */
function ws_senha_atual_ok(PDO $db, string $senha): bool {
    if ($senha === '') return false;
    $uid = (int)(ws_user()['id'] ?? 0);
    if (!$uid) return false;
    try {
        $st = $db->prepare("SELECT senha_hash FROM ws_usuario WHERE id=?");
        $st->execute([$uid]);
        $hash = (string)$st->fetchColumn();
        return $hash !== '' && password_verify($senha, $hash);
    } catch (Throwable $e) { return false; }
}

function h_fone($v): string {
    $d = preg_replace('/\D/', '', (string)$v);
    if (strlen($d) === 11) return '('.substr($d,0,2).') '.substr($d,2,5).'-'.substr($d,7,4);
    if (strlen($d) === 10) return '('.substr($d,0,2).') '.substr($d,2,4).'-'.substr($d,6,4);
    return h($v);
}

/**
 * Limpa a pontuação que ficou gravada em CPF/CNPJ, RG e telefones de cadastros ANTERIORES a esta
 * correção — dado que já existia no banco antes de existir ws_so_numeros(). Roda em lotes (não
 * trava com base grande), é idempotente (rodar de novo não faz nada além do que ainda falta) e só
 * atualiza a linha que tiver algo além de dígito, então nunca reescreve o que já está limpo.
 *
 * Botão em Manutenção — mesma filosofia do ws_end_migrar(): não corre sozinho numa atualização.
 */
function ws_normalizar_documentos_texto(PDO $db, int $limite = 5000): array {
    $r = ['cliente' => 0, 'erros' => []];
    foreach (['cpf_cnpj', 'rg_ie', 'celular', 'telefone'] as $c) {
        try {
            $q = $db->prepare("SELECT id, `$c` AS v FROM ws_cliente WHERE `$c` IS NOT NULL AND `$c` REGEXP '[^0-9]' LIMIT $limite");
            $q->execute();
            $upd = $db->prepare("UPDATE ws_cliente SET `$c`=? WHERE id=?");
            foreach ($q as $row) {
                $upd->execute([ws_so_numeros((string)$row['v']) ?: null, (int)$row['id']]);
                $r['cliente']++;
            }
        } catch (Throwable $e) { $r['erros'][] = "$c: " . $e->getMessage(); }
    }
    return $r;
}

/** Ícone de link pro WhatsApp (abre a conversa direto, wa.me) — usado em qualquer lugar que
 *  mostra um telefone/celular de cliente. Vazio se o número não tiver DDD+número válido.
 *  Se $clienteId for informado, passa por wa_abrir.php pra REGISTRAR no log/timeline do cliente
 *  quem abriu a conversa e quando — sem isso, o clique ia direto pro wa.me sem deixar rastro.
 *  $dentroDoCampo=true: posiciona o ícone COMO SE fosse parte do próprio input (empurra o texto
 *  do campo pra esquerda com padding), em vez de aparecer solto do lado de fora. */
/**
 * PARA ONDE O ÍCONE VERDE LEVA.
 *
 * Nem todo provedor atende pelo WhatsApp Web: quem usa uma plataforma de atendimento (Chatwoot e
 * afins) quer que o clique caia lá dentro, onde fica o histórico da conversa. O destino é
 * configurável em Mensagens → Servidor ("Link do ícone de WhatsApp"), guardado junto do resto da
 * configuração de WhatsApp.
 *
 * Vazio = comportamento de sempre (wa.me). Com `%tel%` no meio, o número entra ali — é o que
 * permite abrir a conversa daquele cliente. Sem `%tel%`, o endereço é usado como está, que atende
 * quem só quer cair na caixa de entrada da plataforma.
 *
 * Lido direto do arquivo, e não por ws_wa_config(): aquela função vive no whatsapp.php, e este
 * ícone aparece em telas que não carregam aquele arquivo.
 */
function ws_wa_link_destino(string $telE164): string {
    static $tpl = null;
    if ($tpl === null) {
        $tpl = '';
        $f = WS_CACHE . '/whatsapp.json';
        if (is_file($f)) {
            $c = json_decode((string)@file_get_contents($f), true);
            if (is_array($c)) $tpl = trim((string)($c['link_icone'] ?? ''));
        }
    }
    /* DESTINO PADRÃO DO CLIENTE (licenca.php → WS_WA_LINK_PADRAO): vale quando a tela está vazia, quando
     * nela está o WhatsApp comum (wa.me — justamente o que o padrão existe para substituir) e quando está
     * um link antigo para UMA conversa fixa (/conversations/N) do MESMO endereço, que abria sempre o mesmo
     * atendimento qualquer que fosse o cliente clicado. Outro endereço escolhido na tela continua valendo. */
    $padrao = (defined('WS_WA_LINK_PADRAO') && WS_WA_LINK_PADRAO !== '') ? (string)WS_WA_LINK_PADRAO : '';
    $usa = $tpl;
    if ($padrao !== '') {
        $hostPadrao = strtolower((string)parse_url($padrao, PHP_URL_HOST));
        $hostTela   = strtolower((string)parse_url($tpl, PHP_URL_HOST));
        $ehWhatsAppComum = in_array($hostTela, ['wa.me', 'api.whatsapp.com', 'web.whatsapp.com'], true);
        if ($tpl === '' || $ehWhatsAppComum || ($hostTela === $hostPadrao && preg_match('#/conversations/\d+#', $tpl))) $usa = $padrao;
    }
    if ($usa === '') return 'https://wa.me/' . $telE164;
    if (strpos($usa, '%tel%') !== false) return str_replace('%tel%', rawurlencode($telE164), $usa);
    return $usa;
}

function ws_wa_icone(?string $tel, string $titulo = 'Abrir no WhatsApp', ?int $clienteId = null, bool $dentroDoCampo = false): string {
    $d = preg_replace('/\D/', '', (string)$tel);
    if (strlen($d) < 10) return '';
    if (strlen($d) <= 11) $d = '55' . $d; // acrescenta DDI Brasil se só tem DDD+número
    // Com cliente, passa pelo wa_abrir.php (registra quem abriu a conversa e quando); sem cliente,
    // vai direto ao destino configurado. Os dois caminhos terminam no MESMO lugar.
    $href = $clienteId ? ('wa_abrir.php?tel=' . $d . '&cliente=' . $clienteId) : ws_wa_link_destino($d);
    $svg = '<svg width="15" height="15" viewBox="0 0 32 32" fill="#25D366" style="vertical-align:middle"><path d="M16.001 3C9.373 3 4 8.373 4 15c0 2.386.697 4.605 1.902 6.47L4 29l7.72-1.865A11.94 11.94 0 0 0 16.001 27C22.63 27 28 21.627 28 15S22.63 3 16.001 3zm6.965 17.06c-.297.836-1.47 1.53-2.406 1.73-.64.137-1.475.246-4.287-.92-3.598-1.49-5.913-5.14-6.093-5.38-.18-.24-1.458-1.94-1.458-3.7 0-1.76.92-2.62 1.246-2.98.326-.36.71-.45.947-.45.237 0 .474.002.68.013.218.012.51-.083.798.61.297.71 1.008 2.47 1.096 2.65.088.18.147.39.03.63-.12.24-.18.39-.356.6-.178.21-.373.47-.533.63-.18.18-.366.373-.157.733.208.36.926 1.53 1.988 2.478 1.366 1.22 2.518 1.598 2.878 1.778.36.18.57.15.78-.09.208-.24.89-1.04 1.128-1.397.238-.36.475-.3.802-.18.326.12 2.073.978 2.43 1.156.356.18.593.27.68.42.09.15.09.87-.207 1.71z"/></svg>';
    $style = $dentroDoCampo
        ? 'position:absolute;right:9px;top:50%;transform:translateY(-50%);text-decoration:none;line-height:0;z-index:2'
        : 'text-decoration:none;margin-left:4px';
    return '<a href="' . h($href) . '" target="_blank" title="' . h($titulo) . '" style="' . $style . '">' . $svg . '</a>';
}

/**
 * ÍCONE VERDE EM QUALQUER CAMPO DE TELEFONE — basta o atributo data-wa no <input>.
 *
 * O mesmo desenho do cadastro do cliente (ícone dentro do campo, à direita), para as telas que ainda
 * não tinham: aparece quando o número fica válido (10+ dígitos) e some quando não, sem recarregar.
 * O link passa pelo wa_abrir.php, que registra quem abriu a conversa e segue para o destino configurado
 * em Mensagens → WhatsApp (wa.me ou a plataforma de atendimento). data-wa-cliente="ID" liga o registro
 * ao cliente. Imprima uma vez por página: <?= ws_wa_campos_script() ?>
 */
function ws_wa_campos_script(): string {
    static $feito = false;
    if ($feito) return '';
    $feito = true;
    $svg = '<svg width="15" height="15" viewBox="0 0 32 32" fill="#25D366" style="vertical-align:middle"><path d="M16.001 3C9.373 3 4 8.373 4 15c0 2.386.697 4.605 1.902 6.47L4 29l7.72-1.865A11.94 11.94 0 0 0 16.001 27C22.63 27 28 21.627 28 15S22.63 3 16.001 3zm6.965 17.06c-.297.836-1.47 1.53-2.406 1.73-.64.137-1.475.246-4.287-.92-3.598-1.49-5.913-5.14-6.093-5.38-.18-.24-1.458-1.94-1.458-3.7 0-1.76.92-2.62 1.246-2.98.326-.36.71-.45.947-.45.237 0 .474.002.68.013.218.012.51-.083.798.61.297.71 1.008 2.47 1.096 2.65.088.18.147.39.03.63-.12.24-.18.39-.356.6-.178.21-.373.47-.533.63-.18.18-.366.373-.157.733.208.36.926 1.53 1.988 2.478 1.366 1.22 2.518 1.598 2.878 1.778.36.18.57.15.78-.09.208-.24.89-1.04 1.128-1.397.238-.36.475-.3.802-.18.326.12 2.073.978 2.43 1.156.356.18.593.27.68.42.09.15.09.87-.207 1.71z"/></svg>';
    return '<script>(function(){var SVG=' . json_encode($svg) . ';'
        . 'function pinta(i){var v=(i.value||"").replace(/\D/g,""),a=i._wsWa;if(v.length>=10){var n=v.length<=11?"55"+v:v,c=i.getAttribute("data-wa-cliente");'
        . 'a.href="wa_abrir.php?tel="+n+(c?"&cliente="+encodeURIComponent(c):"");a.style.display="";}else{a.style.display="none";}}'
        . 'function prepara(i){if(i._wsWa)return;var w=document.createElement("span");w.style.cssText="position:relative;display:block";'
        . 'i.parentNode.insertBefore(w,i);w.appendChild(i);i.style.paddingRight="34px";i.style.width="100%";i.style.boxSizing="border-box";'
        . 'var a=document.createElement("a");a.target="_blank";a.rel="noopener";a.title="Abrir no WhatsApp";'
        . 'a.style.cssText="position:absolute;right:9px;top:50%;transform:translateY(-50%);text-decoration:none;line-height:0;z-index:2";'
        . 'a.innerHTML=SVG;w.appendChild(a);i._wsWa=a;i.addEventListener("input",function(){pinta(i)});pinta(i);}'
        . 'function tudo(){var l=document.querySelectorAll("input[data-wa]");for(var k=0;k<l.length;k++)prepara(l[k]);}'
        . 'if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",tudo);else tudo();})();</script>';
}

/**
 * Estilo (ícone + cor da ação) de um evento do log — ÚNICA fonte, usada tanto no "Log do sistema"
 * do Painel quanto no "Log / Auditoria" (Relatórios), pra ficarem idênticos.
 * Retorna [emoji, cor]. Casa por prefixo/substring (ex.: "pagamento_estorno" cai em pagamento).
 */
function ws_evento_estilo(string $tipo): array {
    $t = strtolower(trim($tipo));
    $map = [
        'robo'        => ['🤖', '#0d9488'],
        'central'     => ['🌐', '#0284c7'],
        'login'       => ['🔑', '#22c55e'],
        'logout'      => ['🚪', '#6b7280'],
        'bloqueio'    => ['🔒', '#ef4444'],
        'desbloqueio' => ['🔓', '#3b82f6'],
        'cancelad'    => ['❌', '#dc2626'],
        'desativ'     => ['🛑', '#dc2626'],
        'reativ'      => ['✅', '#16a34a'],
        'pagamento'   => ['💰', '#16a34a'],
        'estorno'     => ['↩️', '#f59e0b'],
        'boleto_del'  => ['🗑', '#ef4444'],
        'boleto'      => ['🧾', '#0ea5e9'],
        'contrato'    => ['📋', '#8b5cf6'],
        'cliente'     => ['👤', '#6366f1'],
        'cadastro'    => ['📝', '#6366f1'],
        'exclu'       => ['🗑', '#dc2626'],
        'ativ'        => ['✅', '#16a34a'],
    ];
    if (isset($map[$t])) return $map[$t];
    foreach ($map as $k => $v) if ($k !== '' && strpos($t, $k) !== false) return $v;
    return ['📌', '#64748b'];
}

/**
 * Cor/estilo de cada FORMA de pagamento (dinheiro/pix/cartão/boleto/manual) — fonte única, usada
 * no Caixa (movimento) e na tabela "Pagos anteriormente" do cliente. Retorna [rotulo, cor].
 */
function ws_forma_cor(string $forma): array {
    $f = strtolower(trim($forma));
    $map = [
        'dinheiro'      => ['Dinheiro',      '#16a34a'],
        'pix'           => ['Pix',           '#0891b2'],
        'cartao'        => ['Cartão',        '#7c3aed'],
        'cartão'        => ['Cartão',        '#7c3aed'],
        'cheque'        => ['Cheque',        '#0d9488'],
        'duplicata'     => ['Duplicata',     '#c026d3'],
        'transferencia' => ['Transferência', '#2563eb'],
        'transferência' => ['Transferência', '#2563eb'],
        'boleto'        => ['Boleto',        '#ea580c'],
        'outros'        => ['Outros',        '#6b7280'],
        'manual'        => ['Manual',        '#6b7280'],
    ];
    return $map[$f] ?? [ucfirst($f ?: '—'), '#64748b'];
}
/**
 * Upload seguro da FOTO de um equipamento (comodato/estoque). Valida imagem e tamanho, gera nome
 * aleatório e grava em uploads/equipamentos/. Retorna o caminho relativo (ex.: uploads/equipamentos/ab12.jpg)
 * ou null se não houver upload válido. Cria a pasta sob demanda (regra: resolver no código, sem terminal).
 */
function ws_upload_foto_equip(array $file): ?string {
    if (empty($file['tmp_name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    if (!is_uploaded_file($file['tmp_name']) && !is_file($file['tmp_name'])) return null;
    if (($file['size'] ?? 0) > 8388608) return null; // 8 MB
    $mimes = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    $fi = new finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($file['tmp_name']);
    if (!isset($mimes[$mime])) return null;
    $dir = WS_UPLOADS . '/equipamentos';
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    $nome = 'eq_' . bin2hex(random_bytes(8)) . '.' . $mimes[$mime];
    $dest = $dir . '/' . $nome;
    /* Um caminho só de upload (move/rename/copy + permissão) — ver ws_mover_upload().
       O motivo da falha fica em $GLOBALS para a tela poder mostrar: devolver null seco fazia a
       foto do equipamento em comodato sumir sem uma palavra de explicação. */
    $eEq = '';
    if (!ws_mover_upload($file['tmp_name'], $dest, $eEq)) {
        $GLOBALS['ws_upload_erro'] = $eEq;
        return null;
    }
    return 'uploads/equipamentos/' . $nome;
}

/**
 * ACERVO de fotos de equipamento: lista TODAS as imagens da pasta uploads/equipamentos/ (o "botão Foto").
 * É o pool compartilhado — as fotos enviadas por qualquer tela aparecem aqui e ficam disponíveis para
 * ESCOLHA no campo de equipamento em comodato do contrato. Retorna [['foto'=>caminho,'modelo'=>arquivo], ...]
 * mais recentes primeiro.
 */
function ws_acervo_fotos(): array {
    $dir = WS_UPLOADS . '/equipamentos';
    if (!is_dir($dir)) return [];
    $out = [];
    foreach (glob($dir . '/*.{jpg,jpeg,png,webp,gif,JPG,JPEG,PNG,WEBP,GIF}', GLOB_BRACE) ?: [] as $f) {
        $out[] = ['foto' => 'uploads/equipamentos/' . basename($f), 'modelo' => basename($f), 'mtime' => @filemtime($f) ?: 0];
    }
    usort($out, fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    return $out;
}

/**
 * Corrige "mojibake" (acentuação corrompida) de backups mal-exportados — ex.:
 *   "NAZARÃ‰ DA MATA" / "JosÃ©" / "ConceiÃ§Ã£o"  ->  "NAZARÉ DA MATA" / "José" / "Conceição".
 * Reverte camada por camada (UTF-8 relido como Windows-1252). Texto já limpo passa intacto.
 * Só age quando há sinais FORTES de corrupção (não aparecem em português normal).
 */
/**
 * Quanto este texto AINDA parece corrompido? Só conta marcas que não existem em português
 * escrito normalmente. Serve para decidir se uma passada de limpeza melhorou ou piorou —
 * sem isso não há como repetir a limpeza com segurança.
 */
function ws_mojibake_score(string $s): int {
    /* "Ã" seguido de O é PORTUGUÊS LEGÍTIMO — SÃO, NÃO, CONCEIÇÃO. Contá-lo como sujeira fazia
       um nome já correto pontuar acima de zero; inofensivo por causa da trava de melhora, mas
       enganava a leitura do teste. Fora esse caso, "Ã" solto só aparece em texto corrompido. */
    return preg_match_all('/Ã(?!O)|Â|â€|í†|í‚|íƒ|Å|Æ/u', $s);
}

/**
 * Corrige mojibake REPETINDO a limpeza até o texto parar de mudar.
 *
 * POR QUE: a versão de uma passada resolvia 1–4 camadas. Backups que passaram por várias
 * exportações acumulam mais — no diagnóstico do provedor apareceu "SEBASTIíƒÆ’í†â€™íƒâ€ ââ‚¬â„¢O"
 * para "SEBASTIÃO", que é a corrupção aplicada uma dezena de vezes. Enumerar cada variante é
 * perder a corrida; repetir até estabilizar não é.
 *
 * TRAVA DE SEGURANÇA: cada passada só é aceita se DIMINUIR o score de corrupção. Assim um texto
 * já limpo nunca é destruído, e uma passada que pioraria é descartada — o pior caso é o texto
 * ficar como estava.
 */
/** Item 3: valida CPF pelo dígito verificador oficial — não deixa passar número aleatório nem
 *  sequência repetida (ex.: "111.111.111-11", que passaria despercebido sem essa conta). */
function ws_cpf_valido(string $cpf): bool {
    $cpf = preg_replace('/\D/', '', $cpf);
    if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($i = 0; $i < $t; $i++) $soma += (int)$cpf[$i] * (($t + 1) - $i);
        $resto = ($soma * 10) % 11;
        if ($resto === 10) $resto = 0;
        if ($resto !== (int)$cpf[$t]) return false;
    }
    return true;
}

/** Mesma ideia do CPF, mas o cálculo oficial do CNPJ (2 dígitos verificadores, pesos próprios). */
function ws_cnpj_valido(string $cnpj): bool {
    $cnpj = preg_replace('/\D/', '', $cnpj);
    if (strlen($cnpj) !== 14 || preg_match('/^(\d)\1{13}$/', $cnpj)) return false;
    $calc = function (string $base, array $pesos): int {
        $soma = 0;
        foreach ($pesos as $i => $peso) $soma += (int)$base[$i] * $peso;
        $resto = $soma % 11;
        return $resto < 2 ? 0 : 11 - $resto;
    };
    if ($calc(substr($cnpj, 0, 12), [5,4,3,2,9,8,7,6,5,4,3,2]) !== (int)$cnpj[12]) return false;
    if ($calc(substr($cnpj, 0, 13), [6,5,4,3,2,9,8,7,6,5,4,3,2]) !== (int)$cnpj[13]) return false;
    return true;
}

/** Valida CPF (11 dígitos) ou CNPJ (14 dígitos), decidindo pelo tamanho do que foi digitado.
 *  Campo vazio é considerado válido aqui — obrigatoriedade é responsabilidade de quem chama. */
function ws_cpf_cnpj_valido(?string $doc): bool {
    $doc = preg_replace('/\D/', '', (string)$doc);
    if ($doc === '') return true;
    if (strlen($doc) === 11) return ws_cpf_valido($doc);
    if (strlen($doc) === 14) return ws_cnpj_valido($doc);
    return false; // não tem 11 nem 14 dígitos: não é CPF nem CNPJ válido
}

/* =================================================================================================
 * DOCUMENTOS/CONTATO — SÓ NÚMERO POR DENTRO, MÁSCARA SÓ NA TELA
 * -------------------------------------------------------------------------------------------------
 * CPF/CNPJ, RG, CEP e telefone eram gravados como o operador digitasse: com ponto, traço,
 * barra e parêntese incluídos no VARCHAR. Três problemas nascem disso: (1) o MESMO CPF gravado
 * como "111.222.333-44" numa ficha e "11122233344" noutra não bate em nenhum WHERE nem em nenhum
 * JOIN; (2) buscar/agrupar por esses campos fica dependente de como cada um foi digitado;
 * (3) o dado ocupa mais espaço à toa. A partir daqui, TODA gravação desses campos passa por
 * ws_so_numeros() — o dígito é o dado, o resto é só como o dígito aparece na tela (a exibição já
 * tinha h_doc()/h_fone(), aqui do lado; só faltava o CEP — daí h_cep()).
 */

/** Só os dígitos de um documento/telefone/CEP. É a única forma que deve ir para o banco. */
function ws_so_numeros(?string $v): string {
    return preg_replace('/\D/', '', (string)$v);
}

/** CEP com traço (00000-000) para exibição — irmão de h_doc()/h_fone() logo abaixo. */
function h_cep($v): string {
    $d = ws_so_numeros((string)$v);
    return strlen($d) === 8 ? substr($d,0,5).'-'.substr($d,5,3) : h($v);
}

function ws_fix_mojibake(?string $s): string {
    $s = (string)$s;
    if ($s === '') return '';
    /* GUARDA O MELHOR, NÃO O ÚLTIMO.
     *
     * A primeira versão parava na primeira passada que não melhorasse. Só que corrupção de muitas
     * camadas tem PLATÔ: uma passada não baixa o score, a seguinte baixa. Parando no platô, nomes
     * como "SEBASTIíƒÆ’..." ficavam no meio do caminho.
     * Agora percorre até estabilizar (ou o teto) e devolve o MENOR score já visto — se nenhuma
     * passada melhorar, devolve o texto original intacto. */
    $atual  = $s;
    $melhor = $s;
    $score  = ws_mojibake_score($s);
    $vistos = [$s => true];
    for ($volta = 0; $volta < 12 && $score > 0; $volta++) {
        $tent = ws_fix_mojibake_1x($atual);
        if ($tent === $atual || isset($vistos[$tent])) break;   // estabilizou ou entrou em ciclo
        $vistos[$tent] = true;
        $atual = $tent;
        $sc = ws_mojibake_score($tent);
        if ($sc < $score) { $melhor = $tent; $score = $sc; }    // só troca quando melhora de fato
    }
    return $melhor;
}

/** UMA passada de limpeza (tabela de substituição + iconv). Chamada por ws_fix_mojibake(). */
function ws_fix_mojibake_1x(?string $s): string {
    $s = (string)$s;
    if ($s === '') return '';
    // Tabela de substituição: cobre a corrupção PROFUNDA (várias camadas UTF-8↔Windows-1252),
    // gerada de cada letra acentuada do português — inclui a variante "í" (Ã→í, Ã¢→â) que aparece
    // quando o texto passou por mais uma reinterpretação. Sequências maiores substituídas primeiro.
    static $map = null;
    if ($map === null) {
        $map = [];
        $chars = 'áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ°ºª';
        $len = mb_strlen($chars, 'UTF-8');
        for ($k = 0; $k < $len; $k++) {
            $ch = mb_substr($chars, $k, 1, 'UTF-8'); $c = $ch;
            for ($n = 1; $n <= 4; $n++) {
                $c = mb_convert_encoding($c, 'UTF-8', 'Windows-1252');
                if ($c === $ch) break;
                $map[$c] = $ch;
                $v = str_replace(['Ã¢', 'Ã'], ['â', 'í'], $c);   // variante "í"
                if ($v !== $c && !isset($map[$v])) $map[$v] = $ch;
            }
        }
        uksort($map, fn($a, $b) => strlen($b) - strlen($a));
    }
    $s = strtr($s, $map);
    // Passada final para os casos simples de 1–2 camadas que sobrarem (ex.: "JosÃ©" → "José").
    $cur = $s; $n = 0;
    while ($n < 6) {
        $n++;
        if (!preg_match('/[ÃÂ]|â€/u', $cur)) break;
        $t = @iconv('UTF-8', 'Windows-1252//IGNORE', $cur);
        if ($t === false || $t === '' || $t === $cur || !mb_check_encoding($t, 'UTF-8')) break;
        $cur = $t;
    }
    return $cur;
}

/**
 * Galeria de FOTOS de equipamentos — botão "📷 Fotos" + modal com dois modos de exibição:
 * miniatura (grade) e detalhes (lista com modelo/serial/MAC). Reutilizável no Estoque e no Comodato.
 * $ctx = identificador único (ex.: "estoque"/"comodato"); $itens = linhas com foto/modelo/serial/mac/tipo.
 */
function ws_galeria_fotos(string $ctx, array $itens, string $uploadHtml = ''): string {
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $id = 'gal_' . preg_replace('/[^a-z0-9]/', '', strtolower($ctx));
    $n = count($itens);
    // Quando há formulário de upload embutido, o botão fica SEMPRE ativo (dá pra upar mesmo com 0 fotos).
    if ($n === 0 && $uploadHtml === '') {
        return '<button type="button" class="ws-btn" style="font-size:12px;padding:6px 12px;margin-bottom:8px" title="Nenhuma foto enviada ainda" disabled>📷 Foto (0)</button>';
    }
    $btn = '<button type="button" class="ws-btn" style="font-size:12px;padding:6px 12px;margin-bottom:8px" onclick="document.getElementById(\'' . $id . '\').style.display=\'flex\'">📷 Foto (' . $n . ')</button>';
    $cards = '';
    foreach ($itens as $it) {
        $foto = $h(ws_img((string)$it['foto'])); $mod = $h($it['modelo'] ?? ''); $sn = $h($it['serial'] ?? ''); $mac = $h($it['mac'] ?? ''); $tp = $h($it['tipo'] ?? '');
        $cards .= '<figure class="ws-gal-item" style="margin:0">'
            . '<a href="' . $foto . '" target="_blank" title="Abrir em tamanho real"><img src="' . $foto . '" alt="' . $mod . '" loading="lazy"></a>'
            . '<figcaption><b>' . ($mod ?: '—') . '</b>' . ($tp ? ' · ' . $tp : '') . '<span class="ws-gal-det">' . ($sn ? 'SN ' . $sn : '') . ($mac ? ' · ' . $mac : '') . '</span></figcaption>'
            . '</figure>';
    }
    if ($cards === '') $cards = '<p class="ws-muted" style="grid-column:1/-1;margin:0">Nenhuma foto ainda — envie a primeira acima. 👆</p>';
    $up = $uploadHtml !== ''
        ? '<div style="border:1px dashed var(--border);border-radius:10px;padding:12px;margin-bottom:12px;background:rgba(122,31,43,.04)">'
          . '<b style="font-size:13px;display:block;margin-bottom:8px">⬆ Enviar foto</b>' . $uploadHtml . '</div>'
        : '';
    return $btn
        . '<div class="ws-modal-ov" id="' . $id . '" style="display:none" onclick="if(event.target===this)this.style.display=\'none\'">'
        . '<div class="ws-modal" style="max-width:820px;width:calc(100% - 24px)">'
        . '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px">'
        . '<h3 style="margin:0">📷 Fotos dos equipamentos</h3>'
        . '<div style="display:flex;gap:6px;align-items:center">'
        . '<button type="button" class="ws-btn" style="font-size:12px" onclick="var g=document.getElementById(\'' . $id . '_grid\');g.classList.toggle(\'det\')">Miniatura / Detalhes</button>'
        . '<button type="button" class="ws-btn" style="font-size:12px" onclick="document.getElementById(\'' . $id . '\').style.display=\'none\'">✕ Fechar</button>'
        . '</div></div>'
        . $up
        . '<div class="ws-gal-grid" id="' . $id . '_grid">' . $cards . '</div>'
        . '</div></div>';
}

/** Badge (etiqueta colorida) da forma de pagamento, pronto pra imprimir na tabela. */
function ws_forma_badge(string $forma): string {
    if (trim($forma) === '') return '—';
    [$rot, $cor] = ws_forma_cor($forma);
    return '<span class="ws-forma-badge" style="display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:700;'
         . 'background:' . $cor . '1f;color:' . $cor . ';border:1px solid ' . $cor . '55">' . htmlspecialchars($rot, ENT_QUOTES, 'UTF-8') . '</span>';
}

/**
 * Auto-heal barato das colunas/tabelas novas (servidor que não rodou a migração).
 * Faz UMA checagem-sentinela; se já curado, retorna na hora. Chamado pelas páginas que gravam.
 */
/**
 * Cria os arquivos de configuração que ainda não existem, com um esqueleto vazio e válido.
 *
 * POR QUE ISSO EXISTE: várias telas (gateway de pagamento, API, e-mail, provedor, cobrança…)
 * liam o JSON com json_decode(file_get_contents(...)) e seguiam com array vazio quando o arquivo
 * não estava lá. O efeito era silencioso e confuso numa instalação nova: a tela abre, o operador
 * preenche, e a regra que depende daquele arquivo já rodou antes com valor nenhum — o caso mais
 * caro foi o provedor.json, cuja ausência fazia o cadastro do próprio provedor entrar como
 * cliente na migração. Com o arquivo criado, a chave existe (vazia), a tela mostra o campo em
 * branco e o comportamento é o mesmo em qualquer instalação.
 *
 * NÃO sobrescreve nada: só cria o que falta. Nunca lança exceção.
 */
function ws_configs_garantir(): void {
    static $feito = false; if ($feito) return; $feito = true;
    $padroes = [
        // Identidade do provedor — usada em boleto, portal, documentos e na migração.
        'provedor.json'      => ['razao' => '', 'fantasia' => '', 'cnpj' => '', 'ie' => '', 'endereco' => '',
                                 'cidade' => '', 'uf' => '', 'cep' => '', 'telefone' => '', 'email' => '', 'site' => ''],
        // Regras de cobrança/bloqueio (ws_dias_bloqueio / ws_dias_confianca leem daqui).
        'cobranca.json'      => ['dias_bloqueio' => 5, 'dias_confianca' => 1, 'multa_pct' => 2.00, 'juros_pct' => 1.00],
        // Gateway de pagamento (CelCash) e token em arquivo separado.
        'celcash.json'       => ['ativo' => 0, 'ambiente' => 'producao', 'galax_id' => '', 'galax_hash' => '', 'webhook_secret' => ''],
        'celcash_token.json' => ['access_token' => '', 'expira_em' => 0],
        // Envio de e-mail.
        'smtp.json'          => ['host' => '', 'porta' => 587, 'seguranca' => 'tls', 'usuario' => '', 'senha' => '', 'remetente' => '', 'nome_remetente' => ''],
        // WhatsApp / mensageria.
        'whatsapp.json'      => ['ativo' => 0, 'url' => '', 'token' => '', 'instancia' => ''],
        // Nota fiscal de serviço.
        'nfse.json'          => ['ativo' => 0, 'ambiente' => 'homologacao', 'cnpj' => '', 'im' => '', 'token' => '', 'serie' => '1'],
        // Textos do boleto e numeração (nosso número) — ver ws_boleto_proximo_numero().
        'boleto_textos.json' => ['instrucoes' => '', 'demonstrativo' => '', 'local_pgto' => '', 'nosso_numero_inicial' => 1],
        // Portal do assinante / central.
        'portal.json'        => ['ativo' => 1, 'titulo' => '', 'aviso' => ''],
        'central.json'       => ['ativo' => 1, 'titulo' => '', 'aviso' => ''],
        'branding.json'      => ['nome_sistema' => 'WellSystem', 'cor' => '#9333ea', 'logo' => ''],
        /* RADIUS. "simultaneas" = quantas sessões o MESMO login pode ter ao mesmo tempo.
         * 1 impede senha compartilhada entre vizinhos, que é o padrão desejado num provedor.
         * 0 desliga a verificação — necessário em parque cujo roteador reconecta antes de o
         * concentrador fechar a sessão anterior, caso em que o cliente legítimo seria recusado. */
        'radius.json'        => ['simultaneas' => 1],
        // Servidor de logs de conexão (syslog) consultado pela tela logs_servidor.php.
        'logs_servidor.json' => ['url' => '', 'usuario' => '', 'senha' => ''],
    ];
    foreach ($padroes as $arq => $conteudo) {
        $caminho = WS_CACHE . '/' . $arq;
        if (is_file($caminho)) continue;                       // já existe: não encosta
        $j = json_encode($conteudo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (@file_put_contents($caminho, $j) !== false) @chmod($caminho, 0640);
    }
}

/** Impressão digital do código que define o schema. Muda quando o sistema é atualizado. */
function ws_schema_fp(): string {
    $p = '';
    // schema_radius.php entra na conta: mudar as tabelas do RADIUS tem de refazer a verificação,
    // senão a marca "schema em dia" continuaria válida e a mudança não seria aplicada.
    foreach ([WS_DIR . '/config.php', WS_DIR . '/schema.php', WS_DIR . '/schema_radius.php'] as $a) {
        $p .= (string)@filemtime($a) . ':' . (string)@filesize($a) . '|';
    }
    return md5($p);
}

/**
 * ÍNDICES DAS CONSULTAS QUE TODA TELA DE CLIENTE FAZ.
 *
 * POR QUE ESTA FUNÇÃO EXISTE (e por que ela mora AQUI, e não só no schema.php):
 * a lista era montada com estes índices em mente, mas eles só nasciam dentro de ws_migracoes(),
 * que roda apenas no INSTALADOR. Quem atualiza o sistema do jeito normal — trocando os arquivos
 * do addon — nunca passava por lá. Resultado: base sem nenhum desses índices, e cada card da tela
 * de clientes (são seis, cada um um COUNT com EXISTS) virando varredura da tabela inteira. Com
 * cem clientes ninguém nota; com a base cheia, é a tela demorando a abrir.
 *
 * Agora quem chama é o ws_selfheal() também — que roda uma vez a cada atualização, pela impressão
 * digital dos arquivos. O custo do ALTER é pago uma vez; a falta do índice se paga em toda página.
 *
 * Nada aqui altera DADO: índice só é criado se faltar, e falha de ALTER (sem permissão, tabela
 * inexistente) é ignorada em silêncio — indexar é melhoria, não pode virar tela de erro.
 */
function ws_indices_garantir(PDO $db): void {
    $addIdx = function (string $tabela, string $indice, string $colunas) use ($db) {
        try {
            $tb = $db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
            $tb->execute([$tabela]);
            if ((int)$tb->fetchColumn() === 0) return;
            $st = $db->prepare("SELECT COUNT(*) FROM information_schema.statistics
                                WHERE table_schema=DATABASE() AND table_name=? AND index_name=?");
            $st->execute([$tabela, $indice]);
            if ((int)$st->fetchColumn() > 0) return;
            $db->exec("ALTER TABLE `$tabela` ADD INDEX `$indice` ($colunas)");
        } catch (Throwable $e) { /* ver o comentário acima */ }
    };

    /* Colunas filtradas a cada carregamento da lista de clientes:
     *   confianca_ate → card "Em confiança"      · login_ipoe → busca por ID de ONU
     *   titular_id    → card "Adicionais"        · ramal_id   → recorte por cidade/ramal */
    $addIdx('ws_contrato', 'idx_confianca',      'confianca_ate');
    $addIdx('ws_contrato', 'idx_login_ipoe',     'login_ipoe');
    $addIdx('ws_cliente',  'idx_titular',        'titular_id');
    $addIdx('ws_cliente',  'idx_ramal',          'ramal_id');
    // Situação + vencimento: o par que os cards de atraso/aberto usam na mesma consulta.
    $addIdx('ws_fatura',   'idx_status_venc',    'status, vencimento');
    /* ---------------------------------------------------------------------------------------
     * O ÍNDICE QUE FAZIA A LISTA DE CLIENTES DEMORAR — medido, não suposto.
     *
     * Cada linha da lista mostra quantos títulos em aberto o cliente tem, e essa conta é feita
     * assim: ws_fatura JOIN ws_contrato ON ct.id = f.contrato_id. Sem índice em contrato_id, o
     * banco varre a tabela de faturas INTEIRA para cada cliente exibido. Numa base de teste com
     * 8.000 clientes e 64.000 faturas, a consulta da lista levava 748 ms; com este índice, 2,5 ms.
     * O resto (índice em status, em ramal, em nome) somava menos de 5% desse tempo — era este
     * aqui, e só ele, que segurava a tela.
     * ------------------------------------------------------------------------------------- */
    $addIdx('ws_fatura',   'idx_contrato_status', 'contrato_id, status');
    // Faturas de um cliente pela situação e pelo vencimento (card "Em atraso").
    $addIdx('ws_fatura',   'idx_cliente_status', 'cliente_id, status, vencimento');
    /* A lista é ordenada por nome. Sem índice, ordenar exige ler e classificar a tabela toda
     * antes de devolver as 50 linhas da página (o "filesort" do plano de execução). */
    $addIdx('ws_cliente',  'idx_nome',           'nome');
    /* `ws_cliente.status` é a coluna mais filtrada do sistema (cards do Painel, GROUP BY da lista
     * e o "status<>'cancelado'" de quase toda consulta). O par (ramal_id, status) atende o
     * provedor com mais de uma cidade: com ramal selecionado, TODA consulta filtra os dois. */
    $addIdx('ws_cliente',  'idx_status',         'status');
    $addIdx('ws_cliente',  'idx_ramal_status',   'ramal_id, status');
    $addIdx('ws_contrato', 'idx_status',         'status');
    $addIdx('ws_contrato', 'idx_cliente_status', 'cliente_id, status');
    // Chamados: o par que a tela do Suporte e os cards do Painel filtram juntos.
    $addIdx('ws_chamado',  'idx_status_tipo',    'status, tipo');
    // Presença do operador (tela de atendentes online) — filtra "visto nos últimos N minutos".
    $addIdx('ws_usuario',  'idx_visto',          'visto_em');
    // Visitas da Central (card do Painel): sempre lidas por faixa de data.
    $addIdx('ws_central_visita', 'idx_data',     'criado_em');
}

/* TAXA DE EMISSÃO PELA LINHA DIGITÁVEL (24/09/2026).
 * O backup importado grava o título com o valor da mensalidade (ex.: 70,00) e soma a taxa de emissão só na
 * impressão/registro no banco (73,50). A importação trazia 70,00: o WellSystem imprimia 70,00 e o PIX
 * próprio saía com 70,00 — R$ 3,50 a menos. A linha digitável (47 dígitos) traz o valor EXATO registrado
 * no banco nos 10 últimos dígitos: a diferença é a taxa. Aceita só diferença entre R$ 0,01 e R$ 50,00. */
/** VALOR COBRADO do cliente = valor do título (o PLANO) + taxa de emissão. É o que vai na impressão, no
 *  PIX, no carnê e na cobrança registrada no banco (modelo B, o mesmo do backup importado — 24/09/2026). A tela, a
 *  ficha e o recebimento trabalham com o valor do título (o plano). */
/**
 * TAXA DE EMISSÃO NA HORA DE IMPRIMIR E DE RECEBER (11/11/2026, regra do dono): o valor do título/boleto fica o do plano (60, 70, 80…) e a taxa
 * ESTABELECIDA no cadastro do provedor (Provedor → Bancos → Taxa de cobrança, R$ 3,50) entra como ACRÉSCIMO ao imprimir (boleto, carnê, PDF do robô)
 * e já vem preenchida ao receber. Título que já tem taxa gravada usa a gravada; título pago/cancelado nunca ganha taxa nova. Não grava nada no banco
 * e não altera a cobrança do gateway (código de barras e PIX do gateway seguem com o valor emitido).
 */
function ws_fatura_taxa_efetiva(array $f): float {
    $t = (float)($f['taxa_emissao'] ?? 0);
    if ($t > 0) return $t;
    if (in_array((string)($f['status'] ?? ''), ['pago', 'cancelado'], true)) return 0.0;
    static $m = null;
    if ($m === null) { try { $m = ws_taxas_cobranca_bancos(ws_db()); } catch (Throwable $e) { $m = []; } }
    $v = $m[(int)($f['banco_id'] ?? 0)] ?? ($m[0] ?? '');
    return $v !== '' ? (float)str_replace(',', '.', (string)$v) : 0.0;
}
function ws_fatura_valor_cobrado(array $f): float {
    return round((float)($f['valor'] ?? 0) + (float)($f['taxa_emissao'] ?? 0), 2);
}
/**
 * MULTA E JUROS PARA TODOS OS RECEBIMENTOS (01/10/2026, pedido do provedor). Mesma conta da tela de baixa:
 *   multa = valor do título × multa% (uma vez, se vencido) · mora = valor × juros% ao mês ÷ 30 × dias de atraso
 *   (sobre o valor do PLANO; a taxa de emissão entra à parte, como no valor cobrado). Percentuais da CONTA do título
 *   (Provedor → Bancos: multa_pct / juros_pct); sem conta, a 1ª conta ativa. Devolve [dias, multa, mora, total a pagar].
 * Usada no boleto/PIX próprio vencido, na emissão de boleto vencido (CelCash/Lytex), no robô e na conferência do PIX do BB.
 */
function ws_fatura_encargos(array $f, ?string $dataPgto = null): array {
    static $bancos = null;
    if ($bancos === null) { $bancos = []; try { foreach (ws_db()->query("SELECT id, multa_pct, juros_pct, ativo FROM ws_banco ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $b) $bancos[(int)$b['id']] = $b; } catch (Throwable $e) {} }
    $bk = $bancos[(int)($f['banco_id'] ?? 0)] ?? null;
    if (!$bk) foreach ($bancos as $b) if (!empty($b['ativo'])) { $bk = $b; break; }
    $mPct = (float)($bk['multa_pct'] ?? 2); $jPct = (float)($bk['juros_pct'] ?? 1);
    $ref = strtotime(date('Y-m-d', $dataPgto ? strtotime($dataPgto) : time()));
    $venc = strtotime(substr((string)($f['vencimento'] ?? ''), 0, 10));
    $dias = ($venc && $ref > $venc) ? (int)round(($ref - $venc) / 86400) : 0;
    $base = (float)($f['valor'] ?? 0);
    $multa = $dias > 0 ? round($base * $mPct / 100, 2) : 0.0;
    $mora = $dias > 0 ? round($base * $jPct / 100 / 30 * $dias, 2) : 0.0;
    return [$dias, $multa, $mora, round(ws_fatura_valor_cobrado($f) + $multa + $mora, 2)];
}
/** Valor a pagar HOJE (ou na data informada): cobrado + multa + juros quando vencido. */
function ws_fatura_valor_atualizado(array $f, ?string $dataPgto = null): float { return ws_fatura_encargos($f, $dataPgto)[3]; }

/** Converte UMA vez para o modelo B os títulos EM ABERTO que ainda somam a taxa no valor (gravados antes).
 *  A marca é no PRÓPRIO BANCO (ws_fatura.valor_modelo): NULL = antigo (valor já inclui a taxa); 2 = plano.
 *  Título novo nasce com 2 (DEFAULT da coluna) — nunca é convertido. Não depende de arquivo em cache/:
 *  reinstalar ou atualizar de novo não desconta a taxa duas vezes. Pagos não são tocados. */
function ws_faturas_modelo_b_converter(PDO $db): int {
    $n = $db->exec("UPDATE ws_fatura SET valor = ROUND(valor - taxa_emissao, 2), valor_modelo = 2
                     WHERE valor_modelo IS NULL AND status IN('aberto','vencido','processando')
                       AND taxa_emissao > 0 AND valor - taxa_emissao > 0");
    $db->exec("UPDATE ws_fatura SET valor_modelo = 2 WHERE valor_modelo IS NULL AND COALESCE(taxa_emissao,0) = 0");
    if ($n && function_exists('ws_evento')) { try { ws_evento($db, null, 'correcao', "Taxa de emissão no modelo do backup importado: $n título(s) em aberto voltaram ao valor do plano (a taxa segue anotada e entra só na cobrança)."); } catch (Throwable $e) {} }
    return (int)$n;
}

function ws_valor_pela_linha(?string $linha): float {
    $d = preg_replace('/\D/', '', (string)$linha);
    return strlen($d) === 47 ? round(((int)substr($d, 37, 10)) / 100, 2) : 0.0;
}
function ws_taxa_pela_linha(?string $linha, float $valor): float {
    $v = ws_valor_pela_linha($linha); $dif = round($v - $valor, 2);
    return ($v > 0 && $dif >= 0.01 && $dif <= 50) ? $dif : 0.0;
}
/** Uma vez só (marca em cache/): títulos EM ABERTO sem taxa cuja linha digitável tem valor maior → valor = o
 *  da linha e taxa_emissao = a diferença. Pagos não são tocados. */
function ws_faturas_taxa_pela_linha_corrigir(PDO $db): int {
    $marca = WS_CACHE . '/taxa_pela_linha_v2.ok';   // v2 = modelo B (só anota a taxa)
    if (is_file($marca)) return 0;
    $n = 0;
    $st = $db->query("SELECT id, valor, linha_digitavel FROM ws_fatura WHERE status IN('aberto','vencido','processando')
                        AND COALESCE(taxa_emissao,0)=0 AND linha_digitavel IS NOT NULL AND linha_digitavel<>''");
    $up = $db->prepare("UPDATE ws_fatura SET taxa_emissao=? WHERE id=? AND COALESCE(taxa_emissao,0)=0");   // modelo B: valor fica o plano
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
        $tx = ws_taxa_pela_linha($f['linha_digitavel'], (float)$f['valor']);
        if ($tx > 0) { $up->execute([$tx, (int)$f['id']]); $n += $up->rowCount(); }
    }
    @file_put_contents($marca, date('c') . " — $n título(s) corrigido(s)\n"); @chmod($marca, 0640);
    if ($n && function_exists('ws_evento')) { try { ws_evento($db, null, 'correcao', "Taxa de emissão recuperada pela linha digitável em $n título(s) em aberto importado(s) do backup."); } catch (Throwable $e) {} }
    return $n;
}

function ws_selfheal(PDO $db): void {
    static $ok = false; if ($ok) return; $ok = true;
    ws_garantir_pastas();    // uploads/, assets/ e cache/ criadas e com permissão de escrita
    ws_configs_garantir();   // configs ausentes (API/gateway/e-mail/provedor) nascem com esqueleto válido

    /* POR QUE ISTO NÃO PODE RODAR EM TODA REQUISIÇÃO.
     * Daqui para baixo são ~60 comandos de ESTRUTURA (CREATE TABLE IF NOT EXISTS, ALTER, leitura
     * completa do information_schema). Cada um é barato isolado, mas todos juntos, em TODA página,
     * custam o tempo que o usuário sente como "o sistema está lento" — e o custo não depende de
     * haver um cliente sequer no banco, o que explica a lentidão numa instalação recém-criada.
     *
     * A sentinela NÃO é por tempo, e sim pela IMPRESSÃO DIGITAL DO CÓDIGO: data e tamanho do
     * config.php e do schema.php. Foi a forma de resolver o problema que derrubou a sentinela
     * anterior — uma marca fixa fazia migração nova ser pulada em quem já tinha a marca gravada.
     * Aqui, atualizar o sistema muda os arquivos, muda a impressão digital, e a verificação roda
     * INTEIRA de novo na primeira página aberta. Nenhuma migração se perde, e ninguém precisa
     * lembrar de "limpar cache" depois de atualizar.
     *
     * O prazo de 6 horas é a rede de segurança para o caso de alguém mexer no banco por fora
     * (apagar uma coluna à mão, restaurar um backup antigo): no pior caso o sistema se conserta
     * sozinho no mesmo dia, sem nenhuma intervenção. */
    $marca = WS_CACHE . '/schema_ok.json';
    $fp    = ws_schema_fp();
    if (is_file($marca)) {
        $j = json_decode((string)@file_get_contents($marca), true);
        if (is_array($j) && (string)($j['fp'] ?? '') === $fp && (time() - (int)($j['em'] ?? 0)) < 21600) return;
    }

    try {
        // Lê de UMA vez todas as colunas do schema e só cria as que faltam (sem sentinela — nunca pula).
        $have = [];
        foreach ($db->query("SELECT table_name t, column_name c FROM information_schema.columns WHERE table_schema=DATABASE()")->fetchAll(PDO::FETCH_ASSOC) as $r) $have[$r['t'] . '.' . $r['c']] = 1;
        $add = function ($t, $c, $ddl) use ($db, $have) { if (empty($have["$t.$c"])) { try { $db->exec("ALTER TABLE `$t` ADD COLUMN $ddl"); } catch (Throwable $e) {} } };
        $add('ws_pagamento', 'coletor', "coletor VARCHAR(80) DEFAULT NULL");
        if (function_exists('ws_lixeira_garantir') && $db instanceof WsPDO) { try { ws_lixeira_garantir($db); } catch (Throwable $e) {} }   // Recupera Deletado: cria ws_lixeira_* aqui (fora de transação)
        // Forma/Modo de recebimento passa a aceitar mais modos (cheque, duplicata, outros…) — vira VARCHAR.
        try { $tp = $db->query("SELECT DATA_TYPE FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_pagamento' AND column_name='forma'")->fetchColumn();
              if ($tp && strtolower((string)$tp) === 'enum') $db->exec("ALTER TABLE ws_pagamento MODIFY forma VARCHAR(20) NOT NULL DEFAULT 'dinheiro'"); } catch (Throwable $e) {}
        // Tipo de chamado (05/10/2026): passa de ENUM para VARCHAR para permitir tipos customizados.
        try { $tp = $db->query("SELECT DATA_TYPE FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_chamado' AND column_name='tipo'")->fetchColumn();
              if ($tp && strtolower((string)$tp) === 'enum') $db->exec("ALTER TABLE ws_chamado MODIFY tipo VARCHAR(60) NOT NULL DEFAULT 'suporte'"); } catch (Throwable $e) {}
        $add('ws_banco', 'tipo_chave', "tipo_chave VARCHAR(12) DEFAULT NULL");
        $add('ws_banco', 'multa_pct', "multa_pct DECIMAL(5,2) NOT NULL DEFAULT 2.00");
        $add('ws_banco', 'juros_pct', "juros_pct DECIMAL(5,2) NOT NULL DEFAULT 1.00");
        $add('ws_banco', 'local_pgto', "local_pgto VARCHAR(160) DEFAULT NULL");
        // Banco / Contas: mês referente no boleto/carnê, taxa de cobrança e máximo de dias p/ recalcular a 2ª via.
        $add('ws_banco', 'exibir_mes_ref', "exibir_mes_ref TINYINT(1) NOT NULL DEFAULT 0");
        $add('ws_banco', 'taxa_cobranca_ativa', "taxa_cobranca_ativa TINYINT(1) NOT NULL DEFAULT 0");
        $add('ws_banco', 'taxa_cobranca_valor', "taxa_cobranca_valor DECIMAL(10,2) NOT NULL DEFAULT 0.00");
        $add('ws_banco', 'max_dias_recalc', "max_dias_recalc INT NOT NULL DEFAULT 60");
        // Emissão a que esta conta pertence ('gateway' = CelCoin/GalaxPay · 'proprio' = boleto próprio QR/PIX · vazio = sem vínculo).
        $add('ws_banco', 'emissao', "emissao VARCHAR(10) DEFAULT NULL");
        // NF-e modelo 55 (11/11/2026): colunas fiscais do item (produto) e tabela ws_nfe55 (fallback, se a instalação vier de antes do schema.php novo).
        $add('ws_nota_item', 'ncm', "ncm VARCHAR(8) DEFAULT NULL");
        $add('ws_nota_item', 'cfop', "cfop VARCHAR(4) DEFAULT NULL");
        $add('ws_nota_item', 'csosn', "csosn VARCHAR(4) DEFAULT NULL");
        $add('ws_nota_item', 'cest', "cest VARCHAR(7) DEFAULT NULL");
        $add('ws_nota_item', 'unidade', "unidade VARCHAR(6) NOT NULL DEFAULT 'UN'");
        $add('ws_nota', 'nfe55_id', "nfe55_id INT DEFAULT NULL");
        $add('ws_nota', 'nfcom_id', "nfcom_id INT DEFAULT NULL");
        $add('ws_nota', 'regime', "regime VARCHAR(12) DEFAULT NULL");
        $add('ws_nota', 'banco_id', "banco_id INT DEFAULT NULL");
        $add('ws_nota', 'sem_cobranca', "sem_cobranca TINYINT(1) NOT NULL DEFAULT 0");   // 13/11/2026: 1 = NÃO gerar cobrança no GalaxPay para esta nota   // 13/11/2026: conta escolhida na nota para o PIX (NULL = automático)   // 13/11/2026: regime tributário próprio da nota (NULL = o do emissor)
        $add('ws_nota', 'observacao_interna', "observacao_interna TEXT DEFAULT NULL");
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_ncm (codigo CHAR(8) NOT NULL PRIMARY KEY, descricao TEXT NOT NULL, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); $db->exec("CREATE TABLE IF NOT EXISTS ws_produto (id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(30) DEFAULT NULL, descricao VARCHAR(120) NOT NULL, ncm CHAR(8) NOT NULL DEFAULT '', cest VARCHAR(7) DEFAULT NULL, cfop CHAR(4) NOT NULL DEFAULT '5102', csosn VARCHAR(4) NOT NULL DEFAULT '400', origem CHAR(1) NOT NULL DEFAULT '0', unidade VARCHAR(6) NOT NULL DEFAULT 'UN', preco DECIMAL(12,2) NOT NULL DEFAULT 0, ativo TINYINT(1) NOT NULL DEFAULT 1, obs VARCHAR(255) DEFAULT NULL, fonte VARCHAR(10) NOT NULL DEFAULT 'manual', criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_prod_desc (descricao), INDEX idx_prod_ncm (ncm)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}   // 13/11/2026: NCM oficial + produtos (Fiscal)
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_tomador (id INT AUTO_INCREMENT PRIMARY KEY, cliente_id INT NOT NULL, origem VARCHAR(10) NOT NULL DEFAULT 'nota', criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_tomador_cliente (cliente_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}   // 13/11/2026: tomadores (Fiscal)
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_nfcom (id INT AUTO_INCREMENT PRIMARY KEY, nota_id INT DEFAULT NULL, cliente_id INT NOT NULL, valor DECIMAL(10,2) NOT NULL DEFAULT 0, status ENUM('pendente','processando','autorizada','erro','cancelada') NOT NULL DEFAULT 'pendente', numero INT DEFAULT NULL, chave_acesso CHAR(44) DEFAULT NULL, protocolo VARCHAR(30) DEFAULT NULL, codigo_status VARCHAR(6) DEFAULT NULL, motivo VARCHAR(255) DEFAULT NULL, url_xml VARCHAR(255) DEFAULT NULL, retorno_raw MEDIUMTEXT DEFAULT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_nota (nota_id), INDEX idx_cli (cliente_id), UNIQUE INDEX idx_chave (chave_acesso)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_nfe55 (id INT AUTO_INCREMENT PRIMARY KEY, nota_id INT DEFAULT NULL, cliente_id INT NOT NULL, valor DECIMAL(10,2) NOT NULL DEFAULT 0, status ENUM('pendente','processando','autorizada','rejeitada','denegada','erro','cancelada') NOT NULL DEFAULT 'pendente', serie VARCHAR(5) NOT NULL DEFAULT '1', numero INT DEFAULT NULL, chave_acesso CHAR(44) DEFAULT NULL, protocolo VARCHAR(30) DEFAULT NULL, codigo_status VARCHAR(6) DEFAULT NULL, motivo VARCHAR(255) DEFAULT NULL, url_xml VARCHAR(255) DEFAULT NULL, retorno_raw MEDIUMTEXT DEFAULT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_nota (nota_id), INDEX idx_cli (cliente_id), INDEX idx_status (status), UNIQUE INDEX idx_chave (chave_acesso)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        // Auto-detect: bancos existentes com emissao=NULL recebem vinculação automática pelo nome.
        // Palavras que indicam gateway CelCoin/GalaxPay no nome do banco.
        try {
            $bancosSemEmi = $db->query("SELECT id, nome FROM ws_banco WHERE emissao IS NULL AND ativo=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($bancosSemEmi as $bk) {
                $nomeLow = mb_strtolower((string)$bk['nome'], 'UTF-8');
                if (preg_match('/galax|celcoin|celcash|gateway|api/i', $nomeLow)) {
                    $db->prepare("UPDATE ws_banco SET emissao='gateway' WHERE id=? AND emissao IS NULL")->execute([(int)$bk['id']]);
                } elseif (preg_match('/pix|qr|proprio|pr[oó]prio|baixa.?manual/i', $nomeLow)) {
                    $db->prepare("UPDATE ws_banco SET emissao='proprio' WHERE id=? AND emissao IS NULL")->execute([(int)$bk['id']]);
                }
            }
        } catch (Throwable $e) {}
        /* REPARO DO VÍNCULO INVERTIDO (Emissão x Conta do boleto).
         * Duas contas ativas na MESMA emissão (ex.: "WELLNET ( PIX/QR )" e "WELLNET ( GALAXPLAY )" as duas
         * em 'gateway') fazem ws_bancos_por_emissao() devolver só a de menor id: a conta PIX/QR virava a
         * conta do Gateway e o Boleto próprio ficava SEM conta (caindo na conta padrão = GALAXPLAY).
         * O auto-detect acima só age em emissao NULL, então não corrigia isso.
         * Este bloco só age quando HÁ duplicidade E o nome da conta indica claramente a outra emissão;
         * conta cujo nome não dá pista nunca é alterada, e vínculo sem duplicidade nunca é tocado. */
        try {
            $dupEmi = $db->query("SELECT emissao FROM ws_banco WHERE ativo=1 AND emissao IN('gateway','proprio') GROUP BY emissao HAVING COUNT(*)>1")->fetchAll(PDO::FETCH_COLUMN);
            if ($dupEmi) {
                $ixDup = implode(',', array_fill(0, count($dupEmi), '?'));
                $stDup = $db->prepare("SELECT id, nome, emissao FROM ws_banco WHERE ativo=1 AND emissao IN($ixDup)");
                $stDup->execute(array_values($dupEmi));
                foreach ($stDup->fetchAll(PDO::FETCH_ASSOC) as $bk) {
                    $nomeLow = mb_strtolower((string)$bk['nome'], 'UTF-8');
                    $deve = preg_match('/galax|celcoin|celcash|gateway/i', $nomeLow) ? 'gateway'
                          : (preg_match('/pix|qr|proprio|pr[oó]prio|baixa.?manual/i', $nomeLow) ? 'proprio' : null);
                    if ($deve !== null && $deve !== $bk['emissao'])
                        $db->prepare("UPDATE ws_banco SET emissao=? WHERE id=?")->execute([$deve, (int)$bk['id']]);
                }
            }
        } catch (Throwable $e) {}
        // Motivo da exclusão de título (tela de confirmação "Excluir título" — Motivo + Senha).
        $add('ws_fatura_excluida', 'motivo', "motivo VARCHAR(255) DEFAULT NULL");
        $add('ws_fatura', 'recibo_em', "recibo_em DATETIME DEFAULT NULL");
        // Some da lista da tela "Recibos de pagamento" (limpeza automática ou manual) SEM apagar a
        // fatura/pagamento — Caixa, Balancete e todo relatório financeiro continuam contando este
        // título normalmente; só a página de envio de recibo para de listá-lo.
        $add('ws_fatura', 'recibo_oculto', "recibo_oculto TINYINT(1) NOT NULL DEFAULT 0");
        $add('ws_fatura', 'recibo_oculto_em', "recibo_oculto_em DATETIME DEFAULT NULL");
        $add('ws_fatura', 'obs', "obs VARCHAR(255) DEFAULT NULL");
        $add('ws_fatura', 'taxa_emissao', "taxa_emissao DECIMAL(10,2) NOT NULL DEFAULT 0.00");
        // Categoria do título (mensalidade|servico|venda|outros) — vem do "Tipo" ao gerar boleto/carnê.
        $add('ws_fatura', 'categoria', "categoria VARCHAR(20) DEFAULT NULL");
        // Conta do boleto deste título (em branco = a conta salva no cadastro do contrato).
        $add('ws_fatura', 'banco_id', "banco_id INT DEFAULT NULL");
        $add('ws_fatura', 'lytex_id', "lytex_id VARCHAR(255) DEFAULT NULL");  // Lytex (_hashId) — lytex.php
        // 30/09/2026: o _hashId da Lytex passa de 64 caracteres ("Data too long for column lytex_id") — alarga.
        try { $ln = (int)$db->query("SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='ws_fatura' AND column_name='lytex_id'")->fetchColumn();
              if ($ln > 0 && $ln < 255) $db->exec("ALTER TABLE ws_fatura MODIFY lytex_id VARCHAR(255) DEFAULT NULL"); } catch (Throwable $e) {}
        // Cidades (ramais) de cada operador — ws_ramais_permitidos(). Mesma tabela do schema.php.
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_usuario_ramal (usuario_id INT NOT NULL, ramal_id INT NOT NULL,
                         PRIMARY KEY (usuario_id, ramal_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        $add('ws_usuario_ramal', 'principal', "principal TINYINT(1) NOT NULL DEFAULT 0");   // cidade do login (as demais: acesso extra)
        $add('ws_cliente', 'data_cadastro', "data_cadastro DATE DEFAULT NULL");
        $add('ws_cliente', 'apto_casa', "apto_casa VARCHAR(20) DEFAULT NULL");   // 19/11/2026: apartamento ou casa (endereço)
        $add('ws_cliente', 'cob_apto_casa', "cob_apto_casa VARCHAR(20) DEFAULT NULL");   // 19/11/2026: apartamento ou casa (cobrança)
        $add('ws_cliente', 'cob_lat', "cob_lat VARCHAR(20) DEFAULT NULL");   // 19/11/2026: latitude da cobrança
        $add('ws_cliente', 'cob_lng', "cob_lng VARCHAR(20) DEFAULT NULL");   // 19/11/2026: longitude da cobrança
        $add('ws_cliente', 'inscricao_municipal', "inscricao_municipal VARCHAR(30) DEFAULT NULL");   // 13/11/2026: inscrição municipal do tomador (nota fiscal)
        $add('ws_banco', 'anatel', "anatel VARCHAR(40) DEFAULT NULL");
        // Nível de acesso NUMÉRICO (1/2/3/99=root) — além do "nivel" (papel: admin/financeiro/
        // tecnico/atendente, usado noutras telas). 1=só leitura · 2=acessa tudo mas não deleta nem
        // configura · 3=configura e deleta tudo · 99=root (dono do sistema, único que pode ligar
        // "Todas as cidades" no seletor do topo). Quem já era 'admin' vira nível 3 automaticamente;
        // os demais entram como nível 2 (acessa mas não deleta/configura) até o admin ajustar.
        $add('ws_usuario', 'nivel_acesso', "nivel_acesso TINYINT NOT NULL DEFAULT 2");
        // Presença do operador (tela de atendentes online). Vai aqui E no schema.php — são as duas
        // listas de colunas do sistema, e coluna que entra só numa some na instalação que usa a outra.
        $add('ws_usuario', 'visto_em', "visto_em DATETIME DEFAULT NULL");
        // Quem já era 'admin' vira ROOT na migração (evita ficar sem ninguém que possa promover
        // outros depois — só o Root consegue mexer em nível de acesso). Dá pra rebaixar outros
        // admins pra nível 3 manualmente depois, em Config → Operadores.
        try { $db->exec("UPDATE ws_usuario SET nivel_acesso=99 WHERE nivel='admin'"); } catch (Throwable $e) {}
        // CORREÇÃO ÚNICA: títulos emitidos no gateway (CelCoin/GalaxPay) antes desta versão ficaram
        // travados em 'processando' pra sempre (nada os movia pra 'aberto' — só o pagamento via
        // webhook os tirava dali). A emissão é síncrona (já volta com linha digitável/PIX prontos
        // na mesma chamada), então quem já tem boleto do gateway em mãos está 'aberto', não
        // 'processando'. Roda só uma vez por trigger de schema (idempotente: já não sobra nenhum
        // depois da 1ª passada) e não mexe em nada que não tenha dado gateway confirmado.
        try { $db->exec("UPDATE ws_fatura SET status='aberto' WHERE status='processando'
                          AND (celcash_charge_id IS NOT NULL OR linha_digitavel IS NOT NULL)"); } catch (Throwable $e) {}
        // Mapa de CTO — NATIVO (cadastro próprio, sem depender de addon externo).
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_nota (id INT AUTO_INCREMENT PRIMARY KEY, cliente_id INT NOT NULL, fatura_id INT DEFAULT NULL, tipo VARCHAR(10) NOT NULL DEFAULT 'nfse', status VARCHAR(20) NOT NULL DEFAULT 'rascunho', observacao TEXT DEFAULT NULL, total DECIMAL(12,2) NOT NULL DEFAULT 0, nfse_id INT DEFAULT NULL, usuario VARCHAR(80) DEFAULT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_cli (cliente_id), INDEX idx_fat (fatura_id), INDEX idx_status (status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_nota_item (id INT AUTO_INCREMENT PRIMARY KEY, nota_id INT NOT NULL, ordem INT NOT NULL DEFAULT 1, tipo VARCHAR(10) NOT NULL DEFAULT 'servico', descricao VARCHAR(255) NOT NULL, qtd DECIMAL(12,3) NOT NULL DEFAULT 1, valor_unit DECIMAL(12,2) NOT NULL DEFAULT 0, desconto DECIMAL(12,2) NOT NULL DEFAULT 0, INDEX idx_nota (nota_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_cto (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            latitude DECIMAL(10,7) DEFAULT NULL,
            longitude DECIMAL(10,7) DEFAULT NULL,
            portas TINYINT NOT NULL DEFAULT 8,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_cto_porta (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cto_id INT NOT NULL,
            numero_porta TINYINT NOT NULL,
            cliente_id INT DEFAULT NULL,
            UNIQUE KEY uq_porta (cto_id, numero_porta),
            CONSTRAINT fk_ctoporta_cto FOREIGN KEY (cto_id) REFERENCES ws_cto(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        // Log NATIVO de boletos excluídos (nada de addon externo) — guarda os dados da fatura
        // ANTES de apagar, pra dar pra consultar depois quem excluiu o quê e quando.
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_fatura_excluida (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fatura_id INT NOT NULL,
            cliente_id INT DEFAULT NULL,
            cliente_nome VARCHAR(160) DEFAULT NULL,
            competencia VARCHAR(10) DEFAULT NULL,
            vencimento DATE DEFAULT NULL,
            valor DECIMAL(10,2) DEFAULT NULL,
            status_antes VARCHAR(20) DEFAULT NULL,
            excluido_por VARCHAR(80) DEFAULT NULL,
            motivo VARCHAR(255) DEFAULT NULL,
            excluido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_data (excluido_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        // Log de envio de recibo/resumo por WhatsApp — pra mostrar na tela que o envio automático
        // realmente aconteceu (antes só ficava a data em ws_fatura.recibo_em, sem histórico visível).
        // Saídas do caixa (tarifa do gateway no retorno) — mesma definição do schema.php.
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_caixa_saida (
            id INT AUTO_INCREMENT PRIMARY KEY,
            data DATE NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            historico VARCHAR(255) NOT NULL,
            fatura_id INT DEFAULT NULL,
            origem VARCHAR(30) NOT NULL DEFAULT 'manual',
            ref VARCHAR(80) DEFAULT NULL,
            usuario VARCHAR(80) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_origem_ref (origem, ref), INDEX idx_data (data), INDEX idx_fatura (fatura_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        // Títulos importados do backup SEM a taxa de emissão: corrige uma vez pela linha digitável.
        // Modelo B: marca no banco (NULL = antigo, com a taxa somada; novos nascem 2). Converte ANTES da
        // recuperação pela linha, que só anota a taxa — nessa ordem nada é descontado duas vezes.
        try { $db->exec("ALTER TABLE ws_fatura ADD COLUMN valor_modelo TINYINT NULL DEFAULT NULL"); } catch (Throwable $e) {}
        try { $db->exec("ALTER TABLE ws_fatura ALTER valor_modelo SET DEFAULT 2"); } catch (Throwable $e) {}
        try { ws_faturas_modelo_b_converter($db); } catch (Throwable $e) {}
        try { ws_faturas_taxa_pela_linha_corrigir($db); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_recibo_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            tipo VARCHAR(10) NOT NULL DEFAULT 'recibo',
            fatura_id INT DEFAULT NULL,
            cliente_nome VARCHAR(160) DEFAULT NULL,
            login VARCHAR(80) DEFAULT NULL,
            atendente VARCHAR(80) DEFAULT NULL,
            data_pagamento DATE DEFAULT NULL,
            vencimento DATE DEFAULT NULL,
            valor_boleto DECIMAL(10,2) DEFAULT NULL,
            valor_pago DECIMAL(10,2) DEFAULT NULL,
            forma VARCHAR(30) DEFAULT NULL,
            telefone VARCHAR(20) DEFAULT NULL,
            enviado TINYINT(1) NOT NULL DEFAULT 0,
            origem VARCHAR(12) NOT NULL DEFAULT 'automatico',
            erro VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_fatura (fatura_id), INDEX idx_data (criado_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        // Avaliação do chamado feita pelo cliente no portal. Vai aqui E no schema.php (as duas
        // listas de colunas do sistema). Até então só o portal.php criava, com ALTER próprio:
        // instalação que nunca abriu o portal ficava sem as colunas, e as telas que mostram
        // satisfação (Painel, lista de chamados) não tinham o que ler.
        /* TODOS os índices das telas de cliente — não só o de chamados, como estava aqui antes.
         * A lista completa e o porquê de cada um estão em ws_indices_garantir(), logo acima. */
        ws_indices_garantir($db);
        $add('ws_chamado', 'avaliacao', "avaliacao TINYINT DEFAULT NULL");
        $add('ws_chamado', 'avaliacao_comentario', "avaliacao_comentario VARCHAR(300) DEFAULT NULL");
        $add('ws_chamado', 'avaliacao_em', "avaliacao_em DATETIME DEFAULT NULL");
        $add('ws_chamado', 'causa_raiz', "causa_raiz VARCHAR(60) DEFAULT NULL");   // causa-raiz automática (chamado_causa_lib.php)
        // Telefones do técnico que recebe o aviso deste chamado (ver o comentário no schema.php).
        $add('ws_chamado', 'notificar_fones', "notificar_fones VARCHAR(255) DEFAULT NULL");
        /* CADASTRO DE TÉCNICOS (24/09/2026) — quem vai a campo (instalação/suporte), separado dos usuários do
           sistema (atendimento). O chamado aponta para ele em tecnico_cad_id; tecnico_id (usuário) fica só
           como histórico dos chamados antigos. Mesma definição no schema.php. */
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_tecnico (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            celular VARCHAR(20) DEFAULT NULL,
            email VARCHAR(160) DEFAULT NULL,
            funcao VARCHAR(12) NOT NULL DEFAULT 'ambos',
            avisar TINYINT(1) NOT NULL DEFAULT 1,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            obs VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_ativo (ativo, nome)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $e) {}
        $add('ws_chamado', 'tecnico_cad_id', "tecnico_cad_id INT DEFAULT NULL");
        $add('ws_chamado', 'tec_concluido_em', "tec_concluido_em DATETIME DEFAULT NULL");   // técnico concluiu pelo link → aguarda validação (chamado_tec.php)
        $add('ws_chamado', 'pesquisa_em', "pesquisa_em DATETIME DEFAULT NULL");   // pesquisa de satisfação enviada ao cliente (satisfacao_lib.php)
        /* COMPROVANTES PIX do robô do WhatsApp (24/09/2026) — Financeiro → Comprovantes PIX. A definição mora em
           comprovantes_lib.php (ws_comp_sql) e é a mesma do schema.php. */
        if (is_file(__DIR__ . '/comprovantes_lib.php')) { require_once __DIR__ . '/comprovantes_lib.php'; try { $db->exec(ws_comp_sql()); } catch (Throwable $e) {} }
        /* CGNAT determinístico: definição única em cgnat_lib.php (ws_cgnat_sql), a mesma do schema.php. */
        if (is_file(__DIR__ . '/cgnat_lib.php')) { require_once __DIR__ . '/cgnat_lib.php'; foreach (ws_cgnat_sql() as $q) { try { $db->exec($q); } catch (Throwable $e) {} } }
        if (function_exists('ws_comp_selo_sql')) { try { $db->exec(ws_comp_selo_sql()); } catch (Throwable $e) {} }
        if (function_exists('ws_pixped_sql')) { try { $db->exec(ws_pixped_sql()); } catch (Throwable $e) {} }   // pedido de confirmação do PIX (comprovantes_lib.php)   // selo antifraude permanente (comprovantes_lib.php)
        if (is_file(__DIR__ . '/bb_pix.php')) { require_once __DIR__ . '/bb_pix.php'; try { $db->exec(ws_bb_sql()); } catch (Throwable $e) {} }   // PIX recebidos (API do BB)
        try { $db->exec("ALTER TABLE ws_chamado ADD INDEX idx_tec_cad (tecnico_cad_id)"); } catch (Throwable $e) {}
        // Visitas à Central do assinante — o número do card do Painel sai daqui. Também no
        // schema.php (instalação nova cria pela tabela; instalação existente ganha por aqui).
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_central_visita (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT DEFAULT NULL,
            origem VARCHAR(20) NOT NULL DEFAULT 'portal',
            ip VARCHAR(45) DEFAULT NULL,
            ua VARCHAR(160) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_data (criado_em), INDEX idx_cli (cliente_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        $add('ws_cliente', 'titular_id', "titular_id INT DEFAULT NULL");
        $add('ws_contrato', 'confianca_ate', "confianca_ate DATETIME DEFAULT NULL");
        $add('ws_estoque', 'quantidade', "quantidade INT NOT NULL DEFAULT 1");
        $add('ws_estoque', 'condicao', "condicao VARCHAR(10) NOT NULL DEFAULT 'novo'");
        $add('ws_estoque', 'destino_saida', "destino_saida VARCHAR(12) DEFAULT NULL");
        $add('ws_estoque', 'foto', "foto VARCHAR(255) DEFAULT NULL");
        // Estoque robusto: fornecedor, local/prateleira e nível mínimo (alerta de estoque baixo).
        $add('ws_estoque', 'fornecedor', "fornecedor VARCHAR(120) DEFAULT NULL");
        $add('ws_estoque', 'local_estoque', "local_estoque VARCHAR(80) DEFAULT NULL");
        $add('ws_estoque', 'estoque_min', "estoque_min INT NOT NULL DEFAULT 0");
        // Dados da ONU/ONT no contrato (aprovisionamento OLT) + concentradores + equipamento
        $add('ws_contrato', 'placa_pon', "placa_pon VARCHAR(20) DEFAULT NULL");
        $add('ws_contrato', 'pon', "pon VARCHAR(20) DEFAULT NULL");
        $add('ws_contrato', 'rx_sinal', "rx_sinal VARCHAR(20) DEFAULT NULL");
        $add('ws_contrato', 'tx_sinal', "tx_sinal VARCHAR(20) DEFAULT NULL");
        // Potência que a OLT recebe da ONU (upstream) — a outra ponta do enlace. Ver schema.php.
        $add('ws_contrato', 'rx_olt', "rx_olt VARCHAR(20) DEFAULT NULL");
        $add('ws_contrato', 'equipamento', "equipamento VARCHAR(40) DEFAULT NULL");
        $add('ws_contrato', 'concentradores', "concentradores VARCHAR(255) DEFAULT NULL");
        $add('ws_contrato', 'banco_id', "banco_id INT DEFAULT NULL");
        // Emissão do boleto do cliente ('gateway' | 'proprio'; vazio = automático) — Recursos → "Aplicar a todos".
        $add('ws_contrato', 'emissao_boleto', "emissao_boleto VARCHAR(10) DEFAULT NULL");
        // Acesso simultâneo (titular e adicional) + vínculo do cliente a um ramal/cidade
        $add('ws_cliente', 'acesso_simultaneo', "acesso_simultaneo TINYINT(1) NOT NULL DEFAULT 0");
        $add('ws_cliente', 'ramal_id', "ramal_id INT DEFAULT NULL");
        // Cadastro INTERNO (equipe/teste, ex.: a conta "Suporte" usada só pra testar o Portal/Central)
        // — não é cliente de verdade. Sem esta flag contaminava contadores/relatórios (apareceu como
        // "cliente que acessou a Central" no card do Painel).
        $add('ws_cliente', 'interno', "interno TINYINT(1) NOT NULL DEFAULT 0");
        // endereço de cobrança (opcional; Central do assinante pede a troca)
        $add('ws_cliente', 'cob_cep', "cob_cep VARCHAR(10) DEFAULT NULL");
        $add('ws_cliente', 'cob_logradouro', "cob_logradouro VARCHAR(160) DEFAULT NULL");
        $add('ws_cliente', 'cob_numero', "cob_numero VARCHAR(20) DEFAULT NULL");
        $add('ws_cliente', 'cob_complemento', "cob_complemento VARCHAR(80) DEFAULT NULL");
        $add('ws_cliente', 'cob_bairro', "cob_bairro VARCHAR(80) DEFAULT NULL");
        $add('ws_cliente', 'cob_cidade', "cob_cidade VARCHAR(80) DEFAULT NULL");
        $add('ws_cliente', 'cob_uf', "cob_uf VARCHAR(2) DEFAULT NULL");
        $add('ws_contrato', 'roteador_comodato', "roteador_comodato TINYINT(1) DEFAULT NULL");   // ONU Bridge: roteador em comodato?
        $add('ws_contrato', 'roteador_modelo', "roteador_modelo VARCHAR(80) DEFAULT NULL");
        $add('ws_pagamento', 'pago_por', "pago_por VARCHAR(120) DEFAULT NULL");   // "Pagamento Realizado por" (Receber)
        $add('ws_cliente', 'codigo', "codigo VARCHAR(20) DEFAULT NULL");   // código do cliente (ws_cliente_codigo)
        try { $db->exec("UPDATE ws_cliente SET codigo=LPAD(id,6,'0') WHERE codigo IS NULL OR codigo=''"); } catch (Throwable $e) {}
        $add('ws_contrato', 'onu_ativa', "onu_ativa TINYINT(1) NOT NULL DEFAULT 1");
        // Foto do equipamento (comodato) — exibida no hover do "Modelo do equip." e no Estoque.
        $add('ws_equipamento', 'foto', "foto VARCHAR(255) DEFAULT NULL");
        $add('ws_contrato', 'equip_foto', "equip_foto VARCHAR(255) DEFAULT NULL");
        // Bloqueio MANUAL: 1 = bloqueado à mão pelo operador (persiste mesmo sem dívida vencida).
        // 0 = segue a regra automática (bloqueia só se houver boleto aberto vencido).
        $add('ws_contrato', 'bloqueio_manual', "bloqueio_manual TINYINT(1) NOT NULL DEFAULT 0");
        /* ÚLTIMA CONEXÃO VISTA NO CONCENTRADOR (mesmas colunas do schema.php).
           O IP do cliente é dinâmico e só existe enquanto a sessão está de pé; sem gravar, a
           lista de Clientes não tem o que mostrar de quem caiu. Gravadas por
           ws_conexao_registrar() (radius_lib.php) na leitura normal do painel. */
        $add('ws_contrato', 'ultimo_ip',    "ultimo_ip VARCHAR(45) DEFAULT NULL");
        $add('ws_contrato', 'ultimo_ip_em', "ultimo_ip_em DATETIME DEFAULT NULL");
        $add('ws_contrato', 'ultimo_cnc',   "ultimo_cnc VARCHAR(45) DEFAULT NULL");
        // Boleto não pode mais sumir quando o contrato é excluído: solta a FK (SET NULL em vez de CASCADE).
        try {
            $db->exec("ALTER TABLE ws_fatura MODIFY contrato_id INT DEFAULT NULL");
            $fk = $db->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
                WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ws_fatura' AND COLUMN_NAME='contrato_id' AND REFERENCED_TABLE_NAME='ws_contrato'")->fetchColumn();
            if ($fk) {
                $db->exec("ALTER TABLE ws_fatura DROP FOREIGN KEY `$fk`");
                $db->exec("ALTER TABLE ws_fatura ADD CONSTRAINT fk_ft_contrato FOREIGN KEY (contrato_id) REFERENCES ws_contrato(id) ON DELETE SET NULL");
            }
        } catch (Throwable $e) {}
        // Tabelas de Cidade e Ramal (unifica cadastro multi-cidade, separado por ramal)
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_cidade (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            uf VARCHAR(2) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_ramal (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cidade_id INT NOT NULL,
            nome VARCHAR(120) NOT NULL,
            codigo VARCHAR(20) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            CONSTRAINT fk_ramal_cidade FOREIGN KEY (cidade_id) REFERENCES ws_cidade(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        // Lat/long da cidade (preenchimento automático via geocodificação) + config de OLT PRÓPRIA
        // por ramal — cada ramal só puxa dado de OLT se tiver a própria conexão configurada.
        $add('ws_cidade', 'latitude', "latitude DECIMAL(10,7) DEFAULT NULL");
        $add('ws_cidade', 'longitude', "longitude DECIMAL(10,7) DEFAULT NULL");
        // CEP geral da cidade (auto-preenche o CEP no cadastro do cliente ao digitar cidade/UF; editável).
        $add('ws_cidade', 'cep', "cep VARCHAR(10) DEFAULT NULL");
        $add('ws_ramal', 'olt_host', "olt_host VARCHAR(120) DEFAULT NULL");
        $add('ws_ramal', 'olt_porta', "olt_porta VARCHAR(10) DEFAULT NULL");
        $add('ws_ramal', 'olt_usuario', "olt_usuario VARCHAR(60) DEFAULT NULL");
        $add('ws_ramal', 'olt_senha', "olt_senha VARCHAR(120) DEFAULT NULL");
        // Bairro como cadastro próprio (não mais texto livre) — editável, um por cidade.
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_bairro (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cidade_id INT DEFAULT NULL,
            nome VARCHAR(120) NOT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            CONSTRAINT fk_bairro_cidade FOREIGN KEY (cidade_id) REFERENCES ws_cidade(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
        // Cadastro de equipamentos em comodato (ONU/roteador etc.) — alimenta o autopreenchimento
        // de modelo/MAC no cadastro do cliente (Comodato) a partir do número de série escolhido.
        try { $db->exec("CREATE TABLE IF NOT EXISTS ws_equipamento (
            id INT AUTO_INCREMENT PRIMARY KEY,
            tipo VARCHAR(40) DEFAULT NULL,
            modelo VARCHAR(120) NOT NULL,
            serial VARCHAR(80) DEFAULT NULL,
            mac VARCHAR(40) DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'estoque',
            obs VARCHAR(255) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            -- A coluna foto precisa estar AQUI, e nao so na lista de acrescimos la em cima.
            -- Aquela lista roda ANTES deste CREATE: numa instalacao nova a tabela ainda nao existe,
            -- o ALTER falha em silencio, e logo depois a tabela nasce sem a coluna. O resultado era
            -- o erro de coluna inexistente ao salvar equipamento, so em servidor recem-instalado —
            -- invisivel em qualquer instalacao antiga, que ja tinha a coluna.
            foto VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_equip_serial (serial)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}

        /* Acréscimo repetido DE PROPÓSITO: aqui a tabela já existe com certeza. Cobre a instalação
         * antiga, criada antes de a coluna existir, sem depender da ordem das listas acima. */
        try { $db->exec("ALTER TABLE ws_equipamento ADD COLUMN foto VARCHAR(255) DEFAULT NULL"); } catch (Throwable $e) {}

        /* POOL DE BLOQUEIO — fixa o nome que ESTA instalação já usa, antes de o padrão mudar.
         *
         * O padrão de instalação nova passou de `pgcorte` (nome herdado do sistema anterior) para `bloqueio`.
         * Só que a pool existe NO CONCENTRADOR: o RADIUS apenas devolve `Framed-Pool = <nome>`, e o
         * equipamento só conhece a pool configurada nele. Num parque que tem `pgcorte`, deixar o
         * padrão novo valer faria o RADIUS pedir uma pool inexistente — e o inadimplente receberia
         * IP NORMAL, navegando de graça, com o sistema registrando o bloqueio como feito.
         *
         * Então: se o arquivo de configuração ainda não diz qual é a pool, mas o RADIUS já tem uma
         * gravada em radgroupreply, é ELA que vale — o nome é lido do que está no ar e fixado no
         * arquivo. A partir daí o padrão do código não interfere mais nesta instalação.
         *
         * Para adotar `bloqueio`: criar a pool com esse nome no concentrador PRIMEIRO, e só então
         * trocar em Servidores → Configuração. */
        try {
            $arqMk = WS_CACHE . '/mkauth.json';
            $jMk = is_file($arqMk) ? (json_decode((string)@file_get_contents($arqMk), true) ?: []) : [];
            if (!is_array($jMk)) $jMk = [];
            if (empty($jMk['pool_corte'])) {
                $emUso = '';
                try {
                    $q = $db->query("SELECT value FROM radgroupreply WHERE attribute='Framed-Pool'
                                     AND value<>'' ORDER BY id LIMIT 1");
                    $emUso = trim((string)($q ? $q->fetchColumn() : ''));
                } catch (Throwable $e) {}
                if ($emUso !== '') {
                    $jMk['pool_corte'] = $emUso;
                    if (@file_put_contents($arqMk, json_encode($jMk, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false)
                        @chmod($arqMk, 0640);
                }
            }
        } catch (Throwable $e) {}

        /* BANCO DO RADIUS — tabelas no banco próprio e as visões aqui.
         * Entra no selfheal (e não só no instalador) porque é ele que roda quando o CÓDIGO é
         * atualizado: a instalação que já existia passa a ter os dois bancos na primeira página
         * aberta, sem ninguém rodar nada à mão. Idempotente e sem perda de dado — a tabela antiga
         * é renomeada, nunca apagada. Ver schema_radius.php. */
        try {
            require_once WS_DIR . '/schema_radius.php';
            ws_radius_preparar($db);
        } catch (Throwable $e) {}

        /* ENDEREÇO NORMALIZADO — só a estrutura (tabelas + colunas de vínculo + as 27 UFs).
         * A migração dos endereços que já estão em texto NÃO roda aqui: é um resolve por cliente,
         * e com 1.600 clientes isso é tempo que o operador sente na primeira página que abrir.
         * Ela roda no cron, em lotes — ver radius_sync.php. */
        try {
            require_once WS_DIR . '/schema_endereco.php';
            ws_endereco_preparar($db);
        } catch (Throwable $e) {}

        /* Verificação concluída: grava a marca. Fica DENTRO do try de propósito — se a conexão
         * caiu no meio, a marca não é gravada e a próxima requisição refaz tudo. Marcar como
         * "pronto" um schema que talvez não esteja seria o pior dos dois mundos. */
        @file_put_contents($marca, json_encode(['fp' => $fp, 'em' => time()]));
        @chmod($marca, 0640);
    } catch (Throwable $e) { /* tabela pode não existir ainda */ }
}

/** Registra um evento na timeline/auditoria do cliente (silencioso se a tabela não existir). */
function ws_evento(PDO $db, ?int $clienteId, string $tipo, string $texto, ?int $usuarioId = null): void {
    try {
        $db->prepare("INSERT INTO ws_evento (cliente_id,usuario_id,tipo,texto) VALUES (?,?,?,?)")
           ->execute([$clienteId, $usuarioId ?? ($_SESSION['ws_user']['id'] ?? null), $tipo, mb_substr($texto, 0, 255)]);
    } catch (Throwable $e) { /* tabela pode não existir ainda (pré-install) */ }
}

/** Resposta JSON e encerra. */
function ws_json($data): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/edicoes.php';   // edição (completo/erp/olt/fiscal): ws_edicao(), menu e guarda de rota
require_once __DIR__ . '/branding.php';   // marca/logo do sistema (ws_brand_sm / ws_brand_big)
require_once __DIR__ . '/status_topo.php'; // barra de status do topo (máquina, operador, acesso)

/** Ícones modernos (linha fina, SVG, cor herdada de currentColor) — substituem emojis nos pontos
 *  mais visíveis do sistema (atalhos do Painel, ações da OLT, etc.). Nome desconhecido = bolinha
 *  neutra (nunca quebra a tela por causa de um ícone que não existe no mapa). */
function ws_icon(string $nome, string $extra = ''): string {
    $svgs = [
        'usuario'    => '<circle cx="12" cy="8" r="3.4" stroke="currentColor" stroke-width="1.6"/><path d="M4.5 20c1.4-3.6 4.2-5.4 7.5-5.4s6.1 1.8 7.5 5.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'radio'      => '<circle cx="12" cy="12" r="1.8" fill="currentColor"/><path d="M8.4 8.4a5 5 0 0 0 0 7.2M15.6 8.4a5 5 0 0 1 0 7.2M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
        'resumo'     => '<rect x="4" y="4" width="16" height="16" rx="2.5" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h8M8 12.5h8M8 16h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'grafico'    => '<path d="M4 20V10M10 20V4M16 20v-7M20 20v-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'mais'       => '<path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>',
        'rede'       => '<rect x="3" y="4" width="18" height="6" rx="1.6" stroke="currentColor" stroke-width="1.5"/><path d="M7 13v2a2 2 0 0 0 2 2h1M17 13v2a2 2 0 0 1-2 2h-1M12 17v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="7" cy="7" r=".9" fill="currentColor"/>',
        'salvar'     => '<path d="M5 4h11l3 3v13H5V4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 4v5h7V4M8 14h8v6H8v-6Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
        'chamado'    => '<path d="M4 6h16v10H9l-3.5 3V16H4V6Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8.5 10h7M8.5 13h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
        'engrenagem' => '<circle cx="12" cy="12" r="2.6" stroke="currentColor" stroke-width="1.5"/><path d="M12 3.5v2.2M12 18.3v2.2M20.5 12h-2.2M5.7 12H3.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5M17.7 17.7l-1.5-1.5M7.8 7.8 6.3 6.3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
        'atualizar'  => '<path d="M20 11A8 8 0 1 0 18.6 16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M20 5v6h-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
        'ressync'    => '<path d="M4 12a8 8 0 0 1 14-5.2M20 12a8 8 0 0 1-14 5.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M18 4v4h-4M6 20v-4h4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
        'trocar'     => '<path d="M7 7h11l-3-3M17 17H6l3 3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
        'check'      => '<path d="M5 12.5 10 17l9-10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
        'bloqueio'   => '<circle cx="12" cy="12" r="8.4" stroke="currentColor" stroke-width="1.7"/><path d="M6.5 17.5 17.5 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
        'cadeado'    => '<rect x="5.5" y="10.5" width="13" height="9" rx="1.8" stroke="currentColor" stroke-width="1.6"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'desbloqueio'=> '<rect x="5.5" y="10.5" width="13" height="9" rx="1.8" stroke="currentColor" stroke-width="1.6"/><path d="M8 10.5V8a4 4 0 0 1 7.6-1.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'lixeira'    => '<path d="M5 7h14M9 7V5.2A1.2 1.2 0 0 1 10.2 4h3.6A1.2 1.2 0 0 1 15 5.2V7M7 7l1 12.5a1.5 1.5 0 0 0 1.5 1.4h5a1.5 1.5 0 0 0 1.5-1.4L17 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    ];
    $miolo = $svgs[$nome] ?? '<circle cx="12" cy="12" r="3" fill="currentColor"/>';
    return '<svg class="ws-ico' . ($extra ? ' ' . h($extra) : '') . '" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' . $miolo . '</svg>';
}

/** Barra de rodapé padrão — usada em TODAS as páginas internas.
 *  $fluxo=false (padrão, todas as páginas): rodapé FIXO na tela, como sempre foi.
 *  $fluxo=true (usado SÓ pelo Painel): rodapé no FLUXO normal, no final do conteúdo — via estilo
 *  INLINE (vence qualquer !important de CSS/cache antigo), sem mexer em mais nenhuma página.
 *  Se a página chamou ws_pager_render() antes, a paginação aparece dentro do próprio rodapé. */
function ws_footer_bar(bool $fluxo = false): string {
    $nome = function_exists('ws_sistema_nome') ? ws_sistema_nome() : 'WellSystem';
    $pager = $GLOBALS['ws_pager_html'] ?? ''; unset($GLOBALS['ws_pager_html']);
    // style="" INLINE de propósito (além da classe .ws-rodape no CSS externo): isso faz o rodapé
    // aparecer mesmo se o wellsystem.css não carregar, estiver em cache antigo, ou for sobrescrito
    // por algum CSS do painel hospedeiro (isto aqui é um addon dentro dele).
    if ($fluxo) {
        // Painel: SEM position fixed — fica dentro do conteúdo, no final da página mesmo.
        // !important aqui TAMBÉM (não só na classe do CSS) pra garantir que vence de qualquer jeito.
        $estilo = 'position:static!important;left:auto!important;right:auto!important;bottom:auto!important;top:auto!important;z-index:auto!important;'
                . 'margin-top:40px;border-top:1px solid var(--border,rgba(128,128,128,.35));'
                . 'background:var(--top-bg,#fff);box-shadow:none!important';
    } else {
        // Todas as outras páginas: FIXO na tela, exatamente como sempre foi.
        $estilo = 'position:fixed;left:0;right:0;bottom:0;top:auto;z-index:999999;display:block;'
                . 'visibility:visible;opacity:1;margin-top:40px;border-top:1px solid var(--border,rgba(128,128,128,.35));'
                . 'background:var(--top-bg,#fff);box-shadow:0 -6px 24px -8px rgba(0,0,0,.2)';
    }
    $script = $fluxo ? '<script>(function(){var f=document.currentScript.previousElementSibling;if(f&&f.classList.contains("ws-rodape")){f.style.setProperty("position","static","important");f.style.setProperty("left","auto","important");f.style.setProperty("right","auto","important");f.style.setProperty("bottom","auto","important");f.style.setProperty("top","auto","important");f.style.setProperty("z-index","auto","important");f.style.boxShadow="none";}})();</script>' : '';
    return '<footer class="ws-rodape' . ($fluxo ? ' ws-rodape-fluxo' : '') . '" style="' . $estilo . '">'
         . $pager
         . '<style>.ws-rodape-in{display:grid!important;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center}.ws-rodape-in>.ws-rodape-marca{justify-self:start}.ws-rodape-in>.ws-rodape-mid{justify-self:center;text-align:center}.ws-rodape-in>.ws-rodape-meta{justify-self:end}@media(max-width:760px){.ws-rodape-in{grid-template-columns:1fr}.ws-rodape-in>*{justify-self:center!important}}</style>'
         . '<div class="ws-rodape-in" style="max-width:none;margin:0 auto;padding:4px clamp(14px,2vw,32px);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">'
         /* RODAPÉ PADRONIZADO (igual ao da OLT): à esquerda o BLOCO do sistema com contorno — [selo] WellSystem ·
            "Versão Master Wellsystem" (vermelho) · vDD.MM.AA (hora/arquivos no mouse); no meio o PROVEDOR sozinho
            (© ano Wellnet Telecom — "Todos os direitos reservados" no mouse); à direita usuário e data. */
         . (function () use ($nome) { $v = ws_versao_curta(['config.php', 'erp.php', 'crm.php', 'financeiro.php', 'radius_lib.php', 'js/wellsystem.js', 'css/wellsystem.css']);
               return '<span class="ws-rodape-marca" title="' . h($nome) . ' — ERP para provedores de internet" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border:1px solid var(--border,rgba(128,128,128,.35));border-radius:20px;white-space:nowrap">'
                    . '<a href="' . h(ws_dono_url()) . '" target="_blank" rel="noopener" title="' . h(preg_replace('#^https?://#', '', ws_dono_url())) . '" style="display:inline-flex;line-height:0"><img src="' . h(ws_selo_src()) . '" alt="WellSystem" class="ws-rodape-selo" style="width:20px!important;height:20px!important;border-radius:4px"></a><b>' . (function_exists('ws_nome_estilizado') ? ws_nome_estilizado($nome) : h($nome)) . '</b>'
                    . '<i style="opacity:.5;font-style:normal">·</i><b class="ws-rodape-versao">Versão Master Wellsystem</b>'
                    . ($v['txt'] !== '' ? '<span class="ws-rodape-ver" title="' . h($v['tip']) . '" style="font-size:10px;color:var(--text,#374151)!important;opacity:.8;font-weight:700;cursor:help">' . h($v['txt']) . '</span>' : '')
                    . '</span>'; })()
         . '<span class="ws-rodape-mid" title="© ' . date('Y') . ' ' . h(ws_provedor_nome_curto()) . ' — Todos os direitos reservados">© ' . date('Y') . ' ' . h(ws_provedor_nome_curto()) . '</span>'
         . '<span class="ws-rodape-meta">' . h(ws_user()['nome'] ?? '') . '<i>·</i>' . date('d/m/Y H:i\h') . '</span>'
         . '</div></footer>' . $script . '<script src="js/ws_tabelas.js?v=' . ws_ver('js/ws_tabelas.js') . '"></script>';   // 15/11/2026: Exportar CSV + Imprimir em toda tabela de dados (js/ws_tabelas.js)
}

/**
 * Paginação do RODAPÉ — chame ANTES de ws_footer_bar().
 * $urlBase já vem com "?" e os demais parâmetros (sem &pg=), ex.: "relatorios.php?p=log&pp=50".
 *
 * obs4 — MODELO ÚNICO DE SELETOR DE PÁGINA. Existiam dois no sistema: este, que só tinha
 * "« ← anterior · Página 3 de 31 · próxima → »" (para chegar na 17 eram catorze cliques e nenhuma
 * noção de onde se está), e o de ws_paginacao_html(), com números. Ter dois significava que
 * melhorar um deixava o outro para trás — foi o que aconteceu. Agora este monta exatamente a
 * MESMA marcação (.ws-pag/.ws-pag-btn) do outro: um CSS só, um comportamento só, em toda tela.
 * A única adição é o campo "ir para", que aparece quando a lista tem muita página.
 */
function ws_pager_html(int $pg, int $paginas, string $urlBase): string {
    if ($paginas <= 1) return '';
    $pg = max(1, min($pg, $paginas));

    $url = fn(int $n) => h($urlBase . '&pg=' . $n);
    $btn = function (int $n, string $rot, string $titulo, bool $desativado = false, bool $ativo = false) use ($url) {
        // Ponta da lista: a seta continua no lugar, apagada — o controle não "pula" ao navegar.
        if ($desativado) return '<span class="ws-pag-btn off" aria-hidden="true">' . $rot . '</span>';
        return '<a class="ws-pag-btn' . ($ativo ? ' ativo' : '') . '" href="' . $url($n) . '" title="' . h($titulo) . '"'
             . ($ativo ? ' aria-current="page"' : '') . '>' . $rot . '</a>';
    };

    // Janela de 2 páginas para cada lado da atual — navega sem poluir o rodapé.
    $ini = max(1, $pg - 2);
    $fim = min($paginas, $pg + 2);

    $out  = '<nav class="ws-pag ws-pag-rodape" aria-label="Paginação">';
    $out .= $btn(1, '&laquo;', 'Primeira página', $pg <= 1);
    $out .= $btn($pg - 1, '&lsaquo;', 'Página anterior', $pg <= 1);

    if ($ini > 1) {
        $out .= $btn(1, '1', 'Página 1', false, $pg === 1);
        if ($ini > 2) $out .= '<span class="ws-pag-gap">…</span>';
    }
    for ($i = $ini; $i <= $fim; $i++) $out .= $btn($i, (string)$i, "Página $i", false, $i === $pg);
    if ($fim < $paginas) {
        if ($fim < $paginas - 1) $out .= '<span class="ws-pag-gap">…</span>';
        $out .= $btn($paginas, (string)$paginas, "Página $paginas", false, $pg === $paginas);
    }

    $out .= $btn($pg + 1, '&rsaquo;', 'Próxima página', $pg >= $paginas);
    $out .= $btn($paginas, '&raquo;', 'Última página', $pg >= $paginas);

    /* "Ir para": só acima de 8 páginas, onde clicar número a número deixa de compensar.
       Enter ou sair do campo já navega; o valor é preso ao intervalo válido. */
    /* UM SÓ INDICADOR DE PÁGINA, NUNCA DOIS.
       Havia "ir para [1]" e, logo ao lado, "página 1 de 16" — a mesma informação escrita duas
       vezes, uma delas editável. Agora, com o campo presente, o próprio campo É o indicador:
       "ir para [1] de 16". Sem o campo (lista curta), fica só o texto. */
    if ($paginas > 8) {
        $base = h($urlBase);
        $ir   = 'var n=Math.max(1,Math.min(' . $paginas . ',parseInt(this.value||1,10)));location=\'' . $base . '&pg=\'+n;';
        $out .= '<span class="ws-pag-ir"><label for="wsPagIr">ir&nbsp;para</label>'
              . '<input id="wsPagIr" type="number" min="1" max="' . $paginas . '" value="' . $pg . '"'
              . ' inputmode="numeric" aria-label="Ir para a página"'
              . ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();' . $ir . '}"'
              . ' onchange="' . $ir . '">'
              . '<span class="ws-pag-de">de ' . $paginas . '</span></span>';
    } else {
        $out .= '<span class="ws-pag-info">página <b>' . $pg . '</b> de ' . $paginas . '</span>';
    }
    $out .= '</nav>';
    return $out;
}

/**
 * 2FA OBRIGATÓRIO PARA NÍVEL 3 E ROOT (01/10/2026) — Configurações → Segurança (cache/seguranca.json).
 * Ligado: quem tem nível 3+ só usa o sistema depois de ativar a verificação em 2 etapas (é levado direto para a
 * tela de ativação) e não consegue desativá-la. Desligado (padrão): 2FA continua opcional para todos.
 */
function ws_seg_cfg(): array {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/seguranca.json'), true);
    return (is_array($j) ? $j : []) + ['twofa_obrigatorio' => 0];
}
function ws_twofa_obrigatorio_para_mim(): bool {
    return !empty(ws_seg_cfg()['twofa_obrigatorio']) && function_exists('ws_nivel_acesso') && !empty($_SESSION['ws_user']) && ws_nivel_acesso() >= 3
        && !(function_exists('ws_em_demo') && ws_em_demo());
}

/**
 * NÚMEROS DA GERÊNCIA (01/10/2026; reduzido em 06/10/2026): SÓ alertas técnicos — saúde do sistema (servidor/concentrador
 * fora do ar), saúde dos servidores e erro crítico que impeça o sistema de funcionar. Pedidos do robô e cliente insatisfeito
 * NÃO vão mais para cá (ficam no atendimento do cliente / Solicitações). Separado da lista
 * de Notificações de chamado, que é do TÉCNICO (chamados e instalações). Vazio = esses alertas ficam só no sistema
 * (Saúde, Solicitações, Monitor), sem WhatsApp. Configurado em Servidores → Saúde do sistema (cache/alertas_gerencia.json).
 */
function ws_alertas_numeros(): string {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/alertas_gerencia.json'), true);
    return is_array($j) ? trim((string)($j['numeros'] ?? '')) : '';
}
/**
 * CONTRATO/CLIENTE CANCELADO NÃO ENTRA NA BASE (regra do provedor, 01/10/2026): fica guardado só para o caso de
 * voltar a ser cliente. Títulos em aberto deles NÃO contam em painel, relatórios, a receber, inadimplência nem
 * alertas. Use em todo SELECT de ws_fatura que soma/lista em aberto: "... WHERE f.status IN(...)" . ws_sql_fatura_viva('f').
 */
function ws_sql_fatura_viva(string $a = 'ws_fatura'): string {
    return " AND NOT EXISTS (SELECT 1 FROM ws_contrato zct WHERE zct.id=$a.contrato_id AND zct.status='cancelado')"
         . " AND NOT EXISTS (SELECT 1 FROM ws_cliente zcl WHERE zcl.id=$a.cliente_id AND zcl.status IN('cancelado','desativado'))";
}

/**
 * PORTAS DE ACESSO AO EQUIPAMENTO DO CLIENTE (01/10/2026) — configuráveis na tela (Configurações → Geral), sem código.
 * Cada provedor usa a sua: aqui 80 e, sem resposta em 600 ms, a alternativa 1080. Arquivo cache/equipamento.json
 * (entra no backup). Alternativa vazia/0 = não tenta segunda porta.
 */
function ws_equip_cfg(): array {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/equipamento.json'), true);
    $j = is_array($j) ? $j : [];
    $p  = (int)($j['porta'] ?? 80);      $p  = ($p >= 1 && $p <= 65535) ? $p : 80;
    $pa = (int)($j['porta_alt'] ?? 1080); $pa = ($pa >= 0 && $pa <= 65535) ? $pa : 1080;
    return ['proto' => (($j['proto'] ?? 'http') === 'https') ? 'https' : 'http', 'porta' => $p, 'porta_alt' => $pa];
}
/** Endereço base do equipamento ("http://IP" ou "https://IP:8443"). */
function ws_equip_url(string $ip, ?int $porta = null): string {
    $c = ws_equip_cfg(); $porta = $porta ?? $c['porta'];
    $padrao = $c['proto'] === 'https' ? 443 : 80;
    return $c['proto'] . '://' . $ip . ($porta && $porta !== $padrao ? ':' . $porta : '');
}
/** Grava a partir do formulário (Configurações → Geral). */
function ws_equip_salvar(array $post): void {
    $alt = trim((string)($post['equip_porta_alt'] ?? ''));
    $cfg = ['proto' => ($post['equip_proto'] ?? '') === 'https' ? 'https' : 'http',
            'porta' => max(1, min(65535, (int)($post['equip_porta'] ?? 80) ?: 80)),
            'porta_alt' => $alt === '' ? 0 : max(0, min(65535, (int)$alt))];
    ws_dir(WS_CACHE);
    @file_put_contents(WS_CACHE . '/equipamento.json', json_encode($cfg));
    // endereço fixo dos links (aceita só http(s)://domínio, sem barra no fim)
    $u = rtrim(trim((string)($post['url_publica'] ?? '')), '/');
    if ($u !== '' && preg_match('#^https?://[a-z0-9.\-]*[a-z][a-z0-9.\-]*(:\d+)?(/[A-Za-z0-9._\-/]*)?$#i', $u)) @file_put_contents(WS_CACHE . '/url_publica.txt', $u);
}
/** Formulário (só administrador). */
function ws_bloco_equip(): void {
    $c = ws_equip_cfg(); ?>
      <?php if (!function_exists('ws_edicao_tem') || ws_edicao_tem('erp')): /* acesso ao equipamento/links ao cliente: coisa do ERP; edição OLT/Fiscal isolada não mostra */ ?>
      <form method="post" class="ws-form" style="max-width:420px;margin-top:18px">
        <h3>🌐 Acesso ao equipamento do cliente</h3>
        <input type="hidden" name="acao" value="salvar_equip_porta">
        <label>Protocolo <select name="equip_proto"><option value="http" <?= $c['proto'] === 'http' ? 'selected' : '' ?>>http</option><option value="https" <?= $c['proto'] === 'https' ? 'selected' : '' ?>>https</option></select></label>
        <label>Porta principal <input type="number" name="equip_porta" min="1" max="65535" value="<?= (int)$c['porta'] ?>"></label>
        <label>Porta alternativa <input type="number" name="equip_porta_alt" min="0" max="65535" value="<?= $c['porta_alt'] ?: '' ?>" placeholder="vazio = não usar"></label>
        <p class="ws-muted" style="font-size:12px">Ao clicar no IP do cliente (Concentradores, Radius, OLT, ficha), o sistema abre a <b>porta principal</b>; se o equipamento não responder em 0,6 s, tenta a <b>alternativa</b>. Ex.: 80 e 1080.</p>
        <label>🔗 Endereço dos links enviados <input name="url_publica" value="<?= htmlspecialchars(trim((string)@file_get_contents(WS_CACHE . '/url_publica.txt')), ENT_QUOTES) ?>" placeholder="https://financeiro.seuprovedor.com.br"></label>
        <p class="ws-muted" style="font-size:12px">Domínio usado nos links que saem do sistema (técnico, aceite do contrato, pesquisa, app do técnico). Use um domínio com <b>https</b> válido — não use o IP nem o domínio da Central do Assinante.</p>
        <button class="ws-btn primary">Salvar</button>
      </form>
      <?php endif; ?>
<?php }

/**
 * ABRIR O EQUIPAMENTO PELO IP — a MESMA regra em toda tela que mostra um IP.
 *
 * A regra nasceu no Painel dos Concentradores (testarEAbrirIP): abre http://IP e, se em 600 ms o
 * equipamento não responder, troca a aba para a porta ALTERNATIVA (padrão 1080; configurável — ws_equip_cfg) — porque boa parte das ONTs/roteadores
 * deste parque serve o painel web nessa porta alternativa. Fora do Painel, cada tela abria o IP à
 * sua maneira (link http:// puro), e o operador via comportamento diferente para o mesmo clique.
 *
 * Devolve o <script> com wsAbrirIP(ip). Quem tem mostrarToast() ganha o aviso; quem não tem,
 * funciona igual e em silêncio.
 */
function ws_abrir_ip_js(): string {
    $c = ws_equip_cfg(); $pad = $c['proto'] === 'https' ? 443 : 80;
    $cfgJs = json_encode(['base' => $c['proto'] . '://', 'porta' => $c['porta'] !== $pad ? ':' . $c['porta'] : '', 'alt' => $c['porta_alt'] ? ':' . $c['porta_alt'] : '']);
    return '<script>window.WS_EQUIP=' . $cfgJs . ';
function wsAbrirIP(ip){
  ip = String(ip||"").trim(); if(!ip) return;
  if (typeof mostrarToast === "function") { try { mostrarToast("Abrindo console web p/ o IP: " + ip); } catch(e){} }
  var E = window.WS_EQUIP || {base:"http://", porta:"", alt:":1080"};
  var aba = window.open(E.base + ip + E.porta, "_blank");
  if (!aba) return;                       // bloqueador de pop-up: nada a fazer, e nada a quebrar
  if (!E.alt) return;                     // sem porta alternativa configurada
  var ctrl = new AbortController();
  var t = setTimeout(function(){ ctrl.abort(); try { aba.location.href = E.base + ip + E.alt; } catch(e){} }, 600);
  fetch(E.base + ip + E.porta, { mode: "no-cors", signal: ctrl.signal })
      .then(function(){ clearTimeout(t); })
      .catch(function(){});
}
</script>';
}

/**
 * Manda a paginação para o RODAPÉ FIXO (quem imprime é ws_footer_bar).
 * Telas com pouca rolagem preferem assim — o seletor fica sempre à vista.
 * Quem quiser o seletor no FIM DA PÁGINA (rolando junto com o conteúdo) chama
 * ws_pager_html() e imprime onde quiser; é o que a lista de Clientes faz.
 */
function ws_pager_render(int $pg, int $paginas, string $urlBase): void {
    $GLOBALS['ws_pager_html'] = ws_pager_html($pg, $paginas, $urlBase);
}

/** Rodapé do sistema na Central do Assinante (template e tela padrão): discreto, herda a cor do tema
 *  (claro ou escuro) e fica abaixo do conteúdo. */
function ws_central_rodape_sistema(): string {
    $nome = function_exists('ws_sistema_nome') ? ws_sistema_nome() : 'WellSystem';
    return '<div class="ws-central-rodape" style="clear:both;text-align:center;font-size:12px;padding:14px 10px 18px;opacity:.75;color:inherit">'
         . 'Sistema <b>' . htmlspecialchars($nome, ENT_QUOTES, 'UTF-8') . '</b> · © ' . date('Y') . '</div>';
}

/** Pode trocar a FORMA deste recebimento (ws_pagamento)? No mesmo dia em que foi lançado, qualquer
 *  operador; de dias anteriores, só nível 3 e Root (financeiro.php, acao=alterar_forma). */

/* =====================================================================================================================
 * INTEGRAÇÕES (30/09/2026) — o WellSystem roda em provedores diferentes: nem todo mundo tem WhatsApp via API, robô
 * Typebot/n8n, gateway, OLT Huawei etc. Esta é a lista ÚNICA do que é serviço externo, se está ligado, o que ele
 * habilita e onde se configura. Usada pela tela Provedor → Integrações (integracoes.php) e pelo aviso
 * ws_aviso_integracao() nas telas que dependem de um serviço: sem o serviço, a tela explica o que falta e o
 * resto do sistema segue funcionando. Só lê arquivos locais de configuração — nenhuma chamada de rede (rápido).
 * ================================================================================================================== */
function ws_integracoes(): array {
    static $memo = null;
    if ($memo !== null) return $memo;
    $j = function (string $arq): array { $c = json_decode((string)@file_get_contents(WS_CACHE . '/' . $arq), true); return is_array($c) ? $c : []; };
    $tem = fn(array $c, array $ks) => (bool)array_filter($ks, fn($k) => trim((string)($c[$k] ?? '')) !== '');
    $wa = $j('whatsapp.json'); $bot = $j('api_chatbot.json'); $cc = $j('celcash.json'); $lx = $j('lytex.json'); $sm = $j('smtp.json');
    $ch = $j('chamados_notif.json'); $nf = $j('nfse.json'); $bd = $j('backup_dest.json');
    $olt = is_file(WS_DIR . '/cache_trafego/olt_conexao.json') || is_file(WS_DIR . '/olt/cache_trafego/olt_conexao.json');
    $conc = 0; try { $conc = (int)ws_db()->query("SELECT COUNT(*) FROM ws_concentrador WHERE ativo=1")->fetchColumn(); } catch (Throwable $e) {}
    $memo = [
        'concentrador' => ['nome' => 'Concentradores (accel-ppp / MikroTik)', 'ok' => $conc > 0, 'onde' => 'radius.php?p=conc',
            'serve' => 'Clientes online, derrubar/desbloquear na hora, tráfego ao vivo e log de conexão.',
            'req' => 'IP e acesso de cada concentrador (porta 2000 do accel-ppp ou API 8728 do MikroTik).'],
        'whatsapp' => ['nome' => 'WhatsApp (Evolution API / API oficial da Meta)', 'ok' => $tem($wa, ['url']) && $tem($wa, ['apikey']), 'onde' => 'mensagens.php',
            'serve' => 'Recibos, régua de cobrança, resumo do dia, avisos de chamado ao técnico e mensagens automáticas.',
            'req' => 'Um servidor Evolution API (URL + chave) com a instância conectada; templates aprovados se for API oficial.'],
        'robo' => ['nome' => 'Robô de atendimento (Typebot / n8n)', 'ok' => !empty($bot['ativo']) && $tem($bot, ['auth_hash', 'chave']), 'onde' => 'api_chatbot.php',
            'serve' => '2ª via e PIX pelo WhatsApp, comprovantes PIX enviados pelo cliente (com selo antifraude).',
            'req' => 'Typebot (ou n8n) apontando para a API do WellSystem com a credencial gerada aqui.'],
        'audio' => ['nome' => 'Áudio no robô (OpenAI Whisper)', 'ok' => $tem($bot, ['openai_key']), 'onde' => 'mensagens.php?t=servidor',
            'serve' => 'O cliente responde o menu do robô falando (áudio vira a opção: "segunda via" → 2).',
            'req' => 'Chave da OpenAI (platform.openai.com). Sem ela, áudio no menu cai em "não entendi".'],
        'celcash' => ['nome' => 'Gateway CelCoin / GalaxPay', 'ok' => $tem($cc, ['galaxId', 'galax_id']) && $tem($cc, ['galaxHash', 'galax_hash']), 'onde' => 'financeiro.php?p=gateway',
            'serve' => 'Boleto registrado + PIX dinâmico com baixa automática.', 'req' => 'Conta na CelCoin/GalaxPay (Galax ID e Hash).'],
        'lytex' => ['nome' => 'Gateway Lytex', 'ok' => $tem($lx, ['clientId']) && $tem($lx, ['clientSecret']), 'onde' => 'financeiro.php?p=gateway#lytex',
            'serve' => 'Boleto + PIX pela Lytex, por cliente, com baixa automática (a cada minuto e pelo webhook).', 'req' => 'Conta na Lytex (Client ID e Secret com permissão Faturas).'],
        'bb_pix' => ['nome' => 'Banco do Brasil — API PIX', 'ok' => (function () use ($j, $tem) { $b = $j('bb_pix.json'); return $tem($b, ['client_id']) && $tem($b, ['client_secret']) && $tem($b, ['app_key']); })(),
            'onde' => 'financeiro.php?p=gateway#bb',
            'serve' => 'Baixa AUTOMÁTICA do PIX próprio (QR/chave da conta) e conferência do comprovante no banco — barra comprovante falso.',
            'req' => 'API PIX v2 liberada em developers.bb.com.br (client_id, secret, app key) + certificado e-CNPJ A1. Sem ela, o financeiro confere e dá a baixa.'],
        'smtp' => ['nome' => 'E-mail (SMTP)', 'ok' => $tem($sm, ['smtp_host']) && $tem($sm, ['smtp_user']), 'onde' => 'backup.php?t=smtp',
            'serve' => 'Backup por e-mail, recibos e avisos por e-mail.', 'req' => 'Servidor SMTP (ex.: Gmail com senha de app).'],
        'olt' => ['nome' => 'OLT Huawei', 'ok' => $olt, 'onde' => 'olt.php',
            'serve' => 'Autorizar ONU, sinal, VLAN, mover/excluir ONU e ações na ficha do contrato.', 'req' => 'Acesso Telnet à OLT (IP, usuário e senha).'],
        'telegram' => ['nome' => 'Telegram (avisos de chamado)', 'ok' => $tem($ch, ['tg_token']), 'onde' => 'chamados.php?p=config',
            'serve' => 'Aviso de chamado para a equipe pelo Telegram (opcional; o WhatsApp já cobre).', 'req' => 'Bot do Telegram (token) e o chat da equipe.'],
        'nfse' => ['nome' => 'Nota fiscal de serviço (NFS-e)', 'ok' => !empty($nf['ativo']) && $tem($nf, ['token']), 'onde' => 'nfse.php',
            'serve' => 'Emissão de NFS-e dos títulos.', 'req' => 'Credenciamento na prefeitura / provedor de NFS-e.'],
        'logs_servidor' => ['nome' => 'Servidor de logs de conexão (syslog)', 'ok' => $tem($j('logs_servidor.json'), ['url']) && $tem($j('logs_servidor.json'), ['usuario']),
            'onde' => 'logs_servidor.php', 'serve' => 'Achar no log guardado o que um cliente fez em determinado dia e horário (guarda legal de 1 ano).',
            'req' => 'Servidor de logs do provedor (endereço do painel, usuário e senha) recebendo o syslog dos concentradores.'],
        'backup_externo' => ['nome' => 'Backup fora do servidor', 'ok' => !empty($bd['on_email']) || !empty($bd['on_ftp']) || !empty($bd['on_whatsapp']) || !empty($bd['on_mega']) || !empty($bd['on_telegram']),
            'onde' => 'backup.php', 'serve' => 'Cópia diária do backup completo em e-mail, FTP, WhatsApp, MEGA ou Telegram.', 'req' => 'Pelo menos um destino configurado.'],
    ];
    return $memo;
}

/** Aviso padrão na tela que depende de um serviço externo não configurado. '' quando está tudo certo. */
function ws_aviso_integracao(string $chave, string $oQue = ''): string {
    $i = ws_integracoes()[$chave] ?? null;
    if (!$i || $i['ok']) return '';
    return '<div class="ws-alert" style="border-left:4px solid var(--warn,#e6a100);background:color-mix(in srgb,var(--warn,#e6a100) 9%,transparent);color:var(--text);font-size:13px">'
         . '🔌 <b>' . h($oQue !== '' ? $oQue : 'Este recurso') . ' precisa de: ' . h($i['nome']) . '.</b> ' . h($i['req'])
         . ' <a href="' . h($i['onde']) . '">Configurar</a> · <a href="integracoes.php">ver todas as integrações</a>. O restante do sistema funciona normalmente.</div>';
}
/** NOME DOS SELOS dos títulos (Lytex / gateway CelCoin / boleto próprio) — configurável em Financeiro → Gateway, para
 *  cada provedor usar o nome do gateway dele (30/09/2026). Fica em cache/selos_titulos.json (vai no backup). */
function ws_selos_titulos(): array {
    $d = ['lytex' => 'Lytex', 'gateway' => 'Galaxpay', 'proprio' => 'PIX/QR'];
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/selos_titulos.json'), true);
    if (is_array($j)) foreach ($d as $k => $v) if (trim((string)($j[$k] ?? '')) !== '') $d[$k] = mb_substr(trim((string)$j[$k]), 0, 24);
    return $d;
}
/** Selo do título pela origem da cobrança. $novo = destaque do PIX/QR recém-gerado (ficha do cliente). */
function ws_selo_titulo(array $f, bool $novo = false): string {
    $s = ws_selos_titulos();
    if (!empty($f['lytex_id'])) return ' <span class="ws-badge-lytex" title="Boleto emitido pela Lytex">' . h($s['lytex']) . '</span>';
    if (!empty($f['celcash_charge_id'])) return ' <span class="ws-badge-galaxpay" title="Boleto emitido pelo gateway CelCoin/GalaxPay">' . h($s['gateway']) . '</span>';
    return ' <span class="' . ($novo ? 'ws-badge-pix' : 'ws-badge-pix-cinza') . '" title="Boleto próprio (PIX/QR, baixa manual)">' . h($s['proprio']) . '</span>';
}

function ws_forma_troca_permitida(array $pg): bool {
    if (ws_pode_configurar()) return true;
    $dia = substr((string)($pg['criado_em'] ?? '') ?: (string)($pg['data_pgto'] ?? ''), 0, 10);
    return $dia === date('Y-m-d');
}

/**
 * "AÇÕES NA OLT" da ficha do contrato (erp.php e crm.php) — botões + janela de progresso.
 * Antes eram links para olt.php?onu=…&acao=…, que nada tratava (não faziam nada), e Ativar/Desativar
 * só trocava a marca onu_ativa no cadastro, sem falar com a OLT. Agora cada botão: confirma → localiza a
 * ONU na lista da OLT pelo SN (olt_huawei.php?acao=onu_localizar) → manda a MESMA ação da Gerência OLT
 * (onu_acao: reboot/resync/block/unblock/delete; onu_modo: troca o srv-profile) → mostra a resposta.
 * $pagina = 'erp.php' ou 'crm.php' (onde fica o onu_estado que grava a marca do cadastro).
 */
function ws_olt_acoes_html(array $ct, int $contratoId, string $pagina): string {
    $sn = (string)($ct['sn_onu'] ?? ''); $ont = (string)($ct['ont_id'] ?? '');
    $ativa = (int)($ct['onu_ativa'] ?? 1) === 1;
    $b = function (string $cls, string $ic, string $txt, string $tipo, bool $ok = true, string $tit = '') {
        return $ok ? '<button type="button" class="ws-btn ' . $cls . '" onclick="wsOltAcao(\'' . $tipo . '\')">' . ws_icon($ic) . ' <span>' . $txt . '</span></button>'
                   : '<span class="ws-btn ' . $cls . '" style="opacity:.45;cursor:not-allowed" title="' . h($tit) . '">' . ws_icon($ic) . ' <span>' . $txt . '</span></span>';
    };
    $cfg = json_encode(['sn' => $sn, 'ont' => $ont, 'ct' => $contratoId, 'pag' => $pagina], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS);
    return '<div class="ws-olt-grid">'
        . $b('olt-reiniciar', 'atualizar', 'Reiniciar ONU', 'reboot')
        . $b('olt-resync', 'ressync', 'Ressincronizar', 'resync')
        . $b('olt-modo', 'trocar', 'Modo Bridge/Router', 'modo')
        . $b('olt-ativar', 'check', 'Ativar ONU/ONT', 'unblock', !$ativa, 'A ONU já está ativa')
        . $b('olt-desativar', 'bloqueio', 'Desativar ONU/ONT', 'block', $ativa, 'A ONU já está desativada')
        . $b('olt-deletar', 'lixeira', 'Deletar ONU', 'delete')
        . '</div>'
        . "<script>window.WS_OLT_CT=$cfg;</script>"
        . <<<'JS'
<script>
(function(){ if (window.wsOltAcao) return;
  var TIT={reboot:'Reiniciar ONU',resync:'Ressincronizar ONU',modo:'Trocar modo Bridge/Router',unblock:'Ativar ONU/ONT',block:'Desativar ONU/ONT',delete:'Deletar ONU'};
  var PERG={reboot:'Reiniciar esta ONU na OLT? O cliente cai por 1–2 minutos.',resync:'Ressincronizar esta ONU (desativa e ativa de novo na OLT)?',
    unblock:'Ativar esta ONU/ONT na OLT?',block:'Desativar esta ONU/ONT? O cliente perde a conexão até reativar.',delete:'DELETAR esta ONU da OLT? Remove service-port e o cadastro dela na OLT. Ação irreversível.'};
  function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function janela(tit){
    var ov=document.createElement('div'); ov.style.cssText='position:fixed;inset:0;z-index:100100;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:16px';
    ov.innerHTML='<div style="background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:14px;width:min(560px,96vw);max-height:88vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.4)">'
      +'<div style="padding:12px 16px;font-weight:800;border-bottom:1px solid var(--border)">'+esc(tit)+'</div><div class="wsOltPassos" style="padding:14px 16px;font-size:13px;line-height:1.9"></div>'
      +'<div class="wsOltRes" style="padding:0 16px 12px"></div><div style="padding:10px 16px;border-top:1px solid var(--border);text-align:right"><button type="button" class="ws-btn wsOltFechar" disabled>Fechar</button></div></div>';
    document.body.appendChild(ov);
    var pas=ov.querySelector('.wsOltPassos'), res=ov.querySelector('.wsOltRes'), fe=ov.querySelector('.wsOltFechar');
    fe.onclick=function(){ ov.remove(); if (ov.dataset.recarregar) location.reload(); };
    return { passo:function(t){ var d=document.createElement('div'); d.innerHTML='⏳ '+esc(t); pas.appendChild(d); return { ok:function(x){ d.innerHTML='✅ '+esc(t)+(x?' — '+esc(x):''); }, erro:function(x){ d.innerHTML='❌ '+esc(t)+(x?' — '+esc(x):''); } }; },
             fim:function(ok,msg,saida,recarregar){ res.innerHTML='<div style="font-weight:800;color:'+(ok?'var(--ok)':'var(--err)')+'">'+esc(msg)+'</div>'+(saida?'<details style="margin-top:6px"><summary style="cursor:pointer;font-size:12px">Resposta da OLT</summary><pre style="white-space:pre-wrap;font-size:11px;max-height:260px;overflow:auto;background:var(--bg);padding:8px;border-radius:8px">'+esc(saida)+'</pre></details>':''); fe.disabled=false; if(recarregar) ov.dataset.recarregar='1'; },
             res:res };
  }
  function json(url,ms){ var c=('AbortController' in window)?new AbortController():null, t=c?setTimeout(function(){c.abort();},ms):null;
    return fetch(url,{credentials:'same-origin',signal:c?c.signal:undefined}).then(function(r){ if(t)clearTimeout(t); return r.json(); }); }
  window.wsOltAcao=function(tipo){
    var C=window.WS_OLT_CT||{}; if(!C.sn && !C.ont){ alert('Este contrato não tem SN/ID da ONU cadastrado.'); return; }
    if (tipo!=='modo' && !confirm(PERG[tipo])) return;
    var J=janela(TIT[tipo]), p1=J.passo('Localizando a ONU na OLT (SN '+(C.sn||C.ont)+')');
    json('olt_huawei.php?acao=onu_localizar&sn='+encodeURIComponent(C.sn)+'&ont='+encodeURIComponent(C.ont),30000).then(function(o){
      if(!o||o.status!=='ok'){ p1.erro((o&&o.message)||'não encontrada'); J.fim(false,'Nada foi enviado à OLT.'); return; }
      p1.ok(o.fsp+' · ID '+o.id+(o.nome?' · '+o.nome:'')+(o.estado?' · '+o.estado:''));
      if (tipo==='modo') return escolherModo(J,o);
      executar(J,'olt_huawei.php?acao=onu_acao&tipo='+tipo+'&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id), tipo, C);
    }).catch(function(){ p1.erro('sem resposta'); J.fim(false,'A OLT não respondeu. Nada foi enviado.'); });
  };
  function escolherModo(J,o){
    var p=J.passo('Carregando os perfis da OLT');
    json('olt_huawei.php?acao=perfis_olt',60000).then(function(d){
      var srv=((d&&d.srv)||[]).filter(function(s){ return !/^generic|default/i.test(s.nome||''); });
      if(!srv.length){ p.erro('lista vazia'); J.fim(false,'Não consegui ler os perfis da OLT.'); return; }
      p.ok('perfil atual: '+(o.srv||'—'));
      var opts=srv.map(function(s){ var r=/^ONT/i.test(s.nome); return '<option value="'+s.id+'">'+esc(s.nome)+' — '+(r?'Router (ONT)':'Bridge (ONU)')+'</option>'; }).join('');
      J.res.innerHTML='<label style="display:block;font-size:13px">Novo perfil <select class="wsOltSp" style="width:100%;margin-top:4px">'+opts+'</select></label><button type="button" class="ws-btn primary wsOltAplicar" style="margin-top:8px">Aplicar na OLT</button>';
      J.res.querySelector('.wsOltAplicar').onclick=function(){
        var sp=J.res.querySelector('.wsOltSp').value, nm=J.res.querySelector('.wsOltSp').selectedOptions[0].textContent;
        if(!confirm('Trocar o perfil desta ONU para:\n'+nm+'\n\nO cliente pode cair por alguns instantes.')) return;
        J.res.innerHTML='';
        executar(J,'olt_huawei.php?acao=onu_modo&srvprofile='+encodeURIComponent(sp)+'&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id),'modo',window.WS_OLT_CT||{});
      };
    }).catch(function(){ p.erro('sem resposta'); J.fim(false,'Não consegui ler os perfis da OLT.'); });
  }
  function executar(J,url,tipo,C,tent){
    tent=tent||0;
    var p=J.passo(tent?('OLT ocupada — tentando de novo ('+(tent+1)+'/4)'):'Enviando o comando à OLT (pode levar até 1–2 minutos)');
    json(url,240000).then(function(d){
      if(d&&d.status!=='ok'&&/ocupada/i.test(d.message||'')&&tent<3){ p.erro('ocupada'); setTimeout(function(){ executar(J,url,tipo,C,tent+1); },4000); return; }
      if(!d||d.status!=='ok'){ p.erro((d&&d.message)||'falhou'); J.fim(false,(d&&d.message)||'A OLT recusou.'); return; }
      if(!d.sucesso){ p.erro('a OLT retornou erro'); J.fim(false,'A OLT retornou um aviso/erro — confira a resposta.',d.saida||''); return; }
      p.ok('concluído');
      if(tipo==='block'||tipo==='unblock'){   // grava a marca do cadastro (Ativa/Desativada) igual à OLT
        var p2=J.passo('Atualizando o cadastro do contrato');
        fetch(C.pag+'?onu_estado='+encodeURIComponent(C.ct)+'&v='+(tipo==='unblock'?1:0),{credentials:'same-origin'}).then(function(){ p2.ok(); J.fim(true,'Pronto — '+TIT[tipo]+' concluído.',d.saida||'',true); })
          .catch(function(){ p2.erro(); J.fim(true,'Feito na OLT, mas o cadastro não foi atualizado — recarregue a página.',d.saida||'',true); });
        return;
      }
      J.fim(true,'Pronto — '+TIT[tipo]+' concluído.',d.saida||'',tipo==='delete'||tipo==='modo');
    }).catch(function(e){ p.erro('sem resposta a tempo'); J.fim(false,'A OLT não respondeu a tempo. O comando pode ter sido aplicado — aguarde 1 minuto e confira antes de repetir.'); });
  }
})();
</script>
JS;
}

/** Ramais (cidades) que o operador logado pode acessar. null = TODOS: nível 3/root, ou operador ainda
 *  sem cidade marcada em Config → Operadores (não tranca quem já trabalhava antes da regra existir).
 *  Com cidades marcadas, ele só vê essas — e troca entre elas pelo seletor do topo, sem novo login. */
function ws_ramais_permitidos(): ?array {
    if (ws_pode_configurar()) return null;
    static $memo = null;
    if ($memo === null) {
        $memo = [];
        try {
            $st = ws_db()->prepare("SELECT ur.ramal_id FROM ws_usuario_ramal ur JOIN ws_ramal r ON r.id=ur.ramal_id AND r.ativo=1 WHERE ur.usuario_id=? ORDER BY ur.principal DESC, ur.ramal_id");
            $st->execute([(int)(ws_user()['id'] ?? 0)]);
            $memo = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
            /* 30/09/2026 (regra do provedor): login SEM cidade marcada NÃO fica livre — fica só na 1ª cidade ativa.
               Outras cidades só com a marcação no cadastro do operador (a principal vem primeiro). */
            if (!$memo) { $pr = (int)ws_db()->query("SELECT id FROM ws_ramal WHERE ativo=1 ORDER BY id LIMIT 1")->fetchColumn(); if ($pr > 0) $memo = [$pr]; }
        } catch (Throwable $e) {}
    }
    return $memo ?: null;
}
function ws_ramal_permitido(int $rid): bool { $p = ws_ramais_permitidos(); return $p === null || in_array($rid, $p, true); }

/** Cidade/ramal selecionado no Painel (fica na sessão, vale pro sistema todo). */
function ws_ramal_atual(): ?array {
    if (isset($_GET['set_ramal'])) {
        $rid = (int)$_GET['set_ramal'];
        // "Todas as cidades" (rid=0/vazio) só pra root/nível 3 — usuário sem permissão que tentar
        // isso pela URL é ignorado (mantém o ramal que já estava, não muda nada) e avisado.
        if ($rid <= 0 && !ws_pode_configurar()) {
            $_SESSION['ws_flash_err'] = '❌ Você não tem permissão pra ver "Todas as cidades" — seu acesso fica preso ao(s) ramal(is) autorizado(s). Exclusivo de nível 3 e root.';
        } elseif ($rid <= 0) { unset($_SESSION['ws_ramal_id']); }
        elseif (!ws_ramal_permitido($rid)) {
            $_SESSION['ws_flash_err'] = '❌ Você não tem acesso a essa cidade — só às cidades liberadas no seu login.';
        }
        else { $_SESSION['ws_ramal_id'] = $rid; }
    }
    // Ramal da sessão que deixou de ser permitido (cidade tirada do login): volta para uma permitida.
    if (!empty($_SESSION['ws_ramal_id']) && !ws_ramal_permitido((int)$_SESSION['ws_ramal_id'])) unset($_SESSION['ws_ramal_id']);
    if (empty($_SESSION['ws_ramal_id'])) {
        // Sem nível 3+, nunca cai em "todas as cidades" por padrão — começa na primeira cidade
        // liberada para o login (ou, sem cidade marcada, no primeiro ramal ativo, como sempre foi).
        if (!ws_pode_configurar()) {
            try {
                $db = ws_db();
                $perm = ws_ramais_permitidos();
                $r = $perm
                    ? $db->query("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 AND r.id IN (" . implode(',', $perm) . ") ORDER BY r.id LIMIT 1")->fetch()
                    : $db->query("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 ORDER BY r.id LIMIT 1")->fetch();
                if ($r) { $_SESSION['ws_ramal_id'] = $r['id']; return $r; }
            } catch (Throwable $e) {}
        }
        return null;
    }
    try {
        $db = ws_db();
        $st = $db->prepare("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.id=?");
        $st->execute([$_SESSION['ws_ramal_id']]);
        $r = $st->fetch();
        if (!$r) { unset($_SESSION['ws_ramal_id']); return null; }
        return $r;
    } catch (Throwable $e) { return null; }
}

/**
 * Menu completo — usado em TODAS as páginas (evita cada arquivo ter um menu parcial próprio).
 * $ativo: chave da página atual, só pra marcar o link com a classe "on".
 */
/**
 * Cabeçalho completo (2 linhas), usado em TODA página — chame como <?= ws_topo_completo('chave') ?>
 * dentro de <header class="ws-top-wrap">...</header>, ou diretamente no lugar do antigo trio
 * ws_brand_sm()+ws_nav_completo()+ws_user_chip(). Estrutura:
 *   Linha 1 (discreta): selo pequeno · setas voltar/avançar · [espaço] · tema · cidade · usuário
 *   Linha 2 (principal): marca completa (esq.) · MENU centralizado de verdade (grid) · espaço (dir.)
 */
/** Ícone da ABA DO NAVEGADOR: o selo WellSystem. Vai direto no <head> das telas de entrada (login,
 *  ativação, instalação) e é colocado sozinho pelo topo em toda tela logada (ws_topo_completo). Além
 *  disso existe o favicon.ico na raiz do sistema, que o navegador pede sozinho quando nada é declarado. */
function ws_favicon_tags(): string {
    return '<link rel="icon" type="image/png" sizes="32x32" href="img/wellsystem-favicon-32.png?v=' . ws_ver('img/wellsystem-favicon-32.png') . '">'
         . '<link rel="apple-touch-icon" href="img/wellsystem-favicon.png?v=' . ws_ver('img/wellsystem-favicon.png') . '">';
}
function ws_topo_completo(string $ativo = ''): string {
    /* PRESENÇA DO OPERADOR — marcada aqui, e não em cada página.
     * Este cabeçalho é o único ponto por onde TODA tela logada passa. Espalhar a chamada por
     * arquivo significaria esquecer alguma e ter atendente que nunca aparece online — bem quando
     * alguém precisa saber quem estava no sistema. A função tem trava própria de 60 segundos. */
    if (function_exists('ws_marcar_presenca') && !isset($_GET['_auto'])) ws_marcar_presenca();   // recarga automática não é presença
    ob_start();
    // Atualização automática das telas (Provedor → Recursos do sistema): lida por js/wellsystem.js
    echo '<script>window.WS_AUTO_ATUALIZAR=' . (int)(ws_recursos()['auto_atualizar_seg'] ?? 120) . ';window.WS_TRAVA_MIN=' . (int)ws_sessao_minutos_trava() . ';</script>';
    /* "Máscara de moeda" (Provedor → Recursos do sistema): nos campos de dinheiro, o valor é digitado
       como no WellSystem — só números, e a vírgula dos centavos entra sozinha (9990 → 99,90). Sem ponto de
       milhar de propósito: todas as telas convertem "99,90" com vírgula → ponto antes de gravar. */
    if (function_exists('ws_recursos') && ws_recursos()['mascara_moeda']) {
        echo '<script>(function(){var S=\'input[name="valor"]:not(.senha),input[name="valor_pago"],input[name="taxa_emissao"],input[name="desconto"],input[name="valor_estimado"],input[name="valor_entrada"],input[name="valor_saida"],input[data-moeda]\';'
           . 'document.addEventListener("input",function(e){var i=e.target;if(!i||!i.matches||!i.matches(S)||i.type==="number")return;'
           . 'var d=(i.value||"").replace(/\D/g,"").replace(/^0+(?=\d)/,"");if(d===""){i.value="";return;}while(d.length<3)d="0"+d;'
           . 'i.value=d.slice(0,-2).replace(/^0+(?=\d)/,"")+","+d.slice(-2);},true);})();</script>';
    }
    // Selo na aba do navegador em TODA tela logada, mesmo nas que não declaram ícone no <head>.
    echo '<script>(function(h){if(h&&!h.querySelector(' . json_encode('link[rel~="icon"]') . '))h.insertAdjacentHTML("beforeend",' . json_encode(ws_favicon_tags()) . ');})(document.head);</script>';
    ?>
    <?php $wsRc = ws_recursos(); ?>
    <script>/* Aplica IMEDIATAMENTE o tema (claro/escuro) e a cor salvos — em TODA página do topo padrão,
       sem depender de quando o wellsystem.js carrega (era a causa do botão "não funcionar" ao navegar).

       COR DO SISTEMA (Provedor → Recursos do sistema → Tema): a cor gravada ali vale para TODOS. A
       cor pessoal (botão de cor do topo) só vence quando foi escolhida DEPOIS da última gravação do
       padrão. Antes a opção nunca era lida: quem já tinha clicado numa cor ficava nela para sempre e
       a tela de Tema parecia não funcionar. */
    window.WS_COR_PADRAO = <?= json_encode($wsRc['cor_padrao']) ?>;
    window.WS_COR_PADRAO_EM = <?= (int)$wsRc['cor_padrao_em'] ?> * 1000;
    (function(){ var r=document.documentElement, c=window.WS_COR_PADRAO, t=null;
      try{ t=localStorage.getItem('ws_theme');
        var mc=localStorage.getItem('ws_cor'), em=+(localStorage.getItem('ws_cor_em')||0);
        if(mc && em>=window.WS_COR_PADRAO_EM) c=mc;
        else { localStorage.setItem('ws_cor',c); localStorage.setItem('ws_cor_em',String(window.WS_COR_PADRAO_EM)); }
      }catch(e){}
      if(t) r.setAttribute('data-theme',t); else r.removeAttribute('data-theme');
      if(c && c!=='vinho') r.setAttribute('data-cor',c); else r.removeAttribute('data-cor');
    })();
    /* MAPAS (Recursos do sistema → Mapas): toda busca de latitude/longitude passa por aqui.
       Google com chave → Geocoding do Google (se falhar, cai no OpenStreet). Sem chave → OpenStreet.
       WS_MAPA.auto = 0 desliga o preenchimento AUTOMÁTICO (o botão "Localizar" continua). */
    window.WS_MAPA = <?= json_encode(['servidor' => $wsRc['mapa_servidor'], 'key' => $wsRc['google_key'], 'auto' => (int)$wsRc['auto_coordenadas']]) ?>;
    window.wsGeocodificar = function(q){
      q=String(q||'').trim(); if(!q) return Promise.resolve(null);
      var osm=function(){ return fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q='+encodeURIComponent(q),{headers:{'Accept-Language':'pt-BR'}})
        .then(function(r){return r.json();}).then(function(a){ return (a&&a[0]) ? {lat:+a[0].lat, lon:+a[0].lon} : null; }); };
      var M=window.WS_MAPA||{};
      if(M.servidor==='google' && M.key){
        return fetch('https://maps.googleapis.com/maps/api/geocode/json?region=br&language=pt-BR&address='+encodeURIComponent(q)+'&key='+encodeURIComponent(M.key))
          .then(function(r){return r.json();})
          .then(function(j){ var l=j&&j.results&&j.results[0]&&j.results[0].geometry&&j.results[0].geometry.location; return l ? {lat:+l.lat, lon:+l.lng} : osm(); })
          .catch(osm);
      }
      return osm();
    };</script>
    <div class="ws-top-l1">
      <a href="erp.php?p=dashboard" class="ws-top-selo" title="WellSystem"><img src="<?= h(ws_selo_src()) ?>" alt="WellSystem"></a>
      <!-- NAVEGAÇÃO VOLTAR / AVANÇAR.
           Dois problemas foram corrigidos aqui:
           1. Era <a href="javascript:history.back()">. URL javascript: é bloqueada pela
              Content-Security-Policy dos navegadores atuais — o clique não fazia nada.
           2. Mesmo como botão, várias telas do sistema abrem em ABA NOVA (window.open com
              _blank): numa aba recém-aberta não existe página anterior, então history.back()
              também não teria para onde ir. Por isso o "voltar" cai no referrer e, na falta
              dele, no Painel — sempre leva a algum lugar útil em vez de não responder. -->
      <span class="ws-nav-hist">
        <button type="button" onclick="wsNavVoltar()" title="Voltar" aria-label="Voltar">&larr;</button>
        <button type="button" onclick="wsNavAvancar()" title="Avançar" aria-label="Avançar">&rarr;</button>
      </span>
      <script>
      function wsNavVoltar(){
        // Aba com histórico próprio: volta normalmente.
        if (window.history.length > 1) { window.history.back(); return; }
        // Aba nova (window.open): usa quem abriu, se for do mesmo site.
        try {
          if (document.referrer && new URL(document.referrer).host === location.host) {
            location.href = document.referrer; return;
          }
        } catch (e) {}
        // Último recurso: o Painel.
        location.href = 'erp.php?p=dashboard';
      }
      function wsNavAvancar(){ window.history.forward(); }
      </script>
      <?php if (is_file(__DIR__ . '/solicitacoes_lib.php')) { require_once __DIR__ . '/solicitacoes_lib.php'; echo ws_sol_chip(); } // pedidos da Central aguardando validação ?>
      <?= ws_ch_validar_chip() /* chamados que o técnico concluiu pelo link e esperam validação */ ?>
      <?= ws_precad_chip() /* pré-cadastros do robô esperando aprovar/recusar */ ?>
      <?= ws_robo_chamados_chip() /* atendimentos abertos pelo robô esperando a equipe */ ?>
      <span class="ws-top-fill" style="flex:1"></span>
      <!-- Lupa de busca GLOBAL (mapa do código): acha PÁGINAS/funções e também CLIENTES em qualquer
           situação (ativo, bloqueado, cancelado, em confiança…). Enter busca clientes pelo termo. -->
      <span class="ws-lupa-wrap" id="wsLupa">
        <button type="button" class="ws-lupa-btn" title="Buscar em tudo (páginas, funções, clientes, login, CPF…)" onclick="var w=document.getElementById('wsLupa'),i=w.querySelector('input');w.classList.toggle('open');if(w.classList.contains('open')){i.focus();wsLupaFiltra(i.value);}else{document.getElementById('wsLupaRes').style.display='none';}">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        </button>
        <input type="search" class="ws-lupa-input" autocomplete="off" placeholder="buscar página, função, cliente, CPF…" oninput="wsLupaFiltra(this.value)">
        <div class="ws-lupa-res" id="wsLupaRes"></div>
      </span>
      <script>
      /* =================================================================================
       * LUPA = MAPA DO CÓDIGO. Ela NÃO filtra dado nenhum da tela — é só navegação.
       * (O filtro de dados é o campo de pesquisa de cada página, que é outra coisa.)
       *
       * Como ela casa o que foi digitado, do melhor para o pior:
       *   1) SIGLA / INICIAIS   "cb"      -> Cadastros: Bairros
       *                         "pdc"     -> Painel dos Concentradores
       *   2) INÍCIO DO RÓTULO   "clien"   -> Clientes
       *   3) INÍCIO DE PALAVRA  "cad bai" -> Cadastros: Bairros   (cada pedaço abre uma palavra)
       *   4) EM QUALQUER LUGAR  "gpon"    -> OLT   (pelas palavras-chave escondidas)
       * Acento não atrapalha: "manutencao" acha "Manutenção", "relatorio" acha "Relatórios".
       * ================================================================================= */
      (function(){
        /* MAPA: [rótulo, endereço, palavras-chave]. Só DESTINOS — páginas e abas que a
           pessoa pode abrir. Scripts que EXECUTAM ação sozinhos ao abrir (gerar fatura,
           rodar backup, régua de cobrança, cron) ficam de fora de propósito: a lupa é
           para navegar, não para disparar rotina sem querer. */
        var mapa = [
          ['Painel / Dashboard','erp.php?p=dashboard','inicio home resumo principal'],
          ['Atalhos do Painel','erp.php?p=atalhos','acesso rapido favoritos'],

          ['Clientes','erp.php?p=clientes','lista assinantes base'],
          ['Clientes ativos','erp.php?p=clientes&status=ativo','liberados'],
          ['Clientes bloqueados','erp.php?p=clientes&status=bloqueado','corte suspenso'],
          ['Clientes em atraso','erp.php?p=clientes&status=atraso','inadimplente devendo'],
          ['Clientes online','erp.php?p=clientes&status=online','conectados'],
          ['Clientes cancelados/desativados','erp.php?p=clientes&status=cancelado','desativado inativo'],
          ['Clientes em observação','erp.php?p=clientes&status=observacao','promessa confianca'],
          ['Adicionais','erp.php?p=clientes&status=adicional','dependentes ponto extra'],
          ['Novo cliente','erp.php?p=cliente','cadastrar adicionar incluir'],
          ['Novo adicional','erp.php?p=adicional','ponto extra dependente'],
          ['Contrato do cliente','erp.php?p=contrato','plano login pppoe vencimento'],
          ['Planos de velocidade','erp.php?p=planos','mega velocidade valor mensalidade'],

          ['Cadastros: Cidades','erp.php?p=cadastros&t=cidades','cidade uf cep municipio'],
          ['Cadastros: Bairros','erp.php?p=cadastros&t=bairros','bairro zona'],
          ['Cadastros: Ramais','erp.php?p=cadastros&t=ramais','olt filial unidade'],
          ['Cadastros: Equipamentos (comodato + fotos)','erp.php?p=cadastros&t=equipamentos','onu ont roteador foto galeria'],
          ['Cadastros: Comodatos','erp.php?p=cadastros&t=comodatos','equipamento emprestado cliente'],

          ['Configurações: Geral','erp.php?p=config&t=geral','ajustes preferencias marca logo'],
          ['Configurações: Operadores/Usuários','erp.php?p=config&t=operadores','usuario permissao nivel senha funcionario'],
          ['Configurações: Segurança/2FA','erp.php?p=config&t=seguranca','2fa autenticacao senha login bloqueio'],
          ['Configurações: Cobrança','erp.php?p=config&t=cobranca','juros multa carencia'],
          ['Configurações: Migração (regras)','erp.php?p=config&t=migracao','backup regras importacao migracao'],

          ['Financeiro / Faturas','financeiro.php','boletos cobranca titulos mensalidade'],
          ['Financeiro: Lista de faturas','financeiro.php?p=faturas','titulos boletos'],
          ['Financeiro: Resumo','financeiro.php?p=resumo','totais painel financeiro'],
          ['Financeiro: Gerar faturas','financeiro.php?p=gerar','emitir mensalidade lote'],
          ['Financeiro: Carnê','financeiro.php?p=carne','impressao bloco boletos'],
          ['Financeiro: Gateway (CelCoin/GalaxPay · Lytex)','financeiro.php?p=gateway','celcash lytex api pix integracao'],
          ['Financeiro: Títulos por gateway','financeiro.php?p=por_gateway','celcash galaxpay lytex pix qr proprio titulos boletos gateway'],
          ['Financeiro: Faturas com mês errado','financeiro.php?p=mes_errado','competencia divergente correcao'],
          ['Financeiro: Comprovantes PIX (WhatsApp)','comprovantes.php','comprovante recibo pix robo typebot whatsapp conferir'],

          ['Caixa do Dia','relatorios.php?p=caixa','entradas saidas saldo dia'],
          ['Boletos a receber','relatorios.php?p=receber','a receber inadimplencia'],
          ['Relatório de boletos','relatorios.php?p=boletos','titulos emitidos'],
          ['Balancete / Gráficos','relatorios.php?p=financeiro','balanco grafico faturamento'],
          ['Relatório da base','relatorios.php?p=base','ativacao desativacao churn clientes'],
          ['Log / Auditoria','relatorios.php?p=log','eventos historico quem fez'],
          ['Monitor do robô / Central','relatorios.php?p=log&tipo=robo','robo whatsapp typebot central assinante diagnostico confianca audio'],
          ['Relatórios (todos)','relatorios.php','listagens'],

          ['Recibos / Resumo do dia','recibos.php?p=resumo','pagamentos fechamento caixa'],
          ['Recibos: Emitidos','recibos.php?p=recibos','comprovante'],
          ['Recibos: Log de envios','recibos.php?p=log','whatsapp enviado'],
          ['Recibos: Configuração','recibos.php?p=config','modelo texto'],

          ['Faturamento (gerar mensalidade)','faturamento.php','fatura lote mes competencia'],
          ['Cobrança: Régua','cobranca.php?p=regua','lembrete aviso automatico dias'],
          ['Cobrança: WhatsApp','cobranca.php?p=whatsapp','mensagem zap evolution'],
          ['Cobrança: Log','cobranca.php?p=log','envios historico'],
          ['Mensagens automáticas','mensagens.php?t=mensagens','whatsapp cobranca lembrete modelo'],
          ['Atualizações do sistema (GitHub, automática)','atualizar.php','atualizar atualizacao versao github release voltar'],
          ['Atendimento: WhatsApp, robô, Chatwoot, n8n','atendimento.php','atendimento whatsapp robo typebot chatwoot n8n qrcode instancia'],
          ['Mensagens: Servidor (Evolution)','mensagens.php?t=servidor','api whatsapp instancia qrcode'],

          ['Conciliação bancária','conciliacao.php','ofx extrato banco baixa'],
          ['Provedor: Dados','provedor.php?p=dados','razao social cnpj endereco logo'],
          ['Recursos do sistema','provedor.php?p=recursos','vencimento dias corte automatico desbloqueio sabado carne titulos mapa google tema cor registros senha cpf mascara'],
          ['Provedor / Bancos (PIX)','provedor.php?p=bancos','pix chave conta banco'],
          <?php if (ws_pode_configurar()): /* Fiscal: só nível 3 e root (14/11/2026) */ ?>['NFS-e','nfse.php','nota fiscal servico prefeitura'],
          ['Fiscal: Notas','fiscal.php?p=notas','nfse emitidas impostos'],
          ['Fiscal: Emissor','fiscal.php?p=emissor','certificado configuracao nota'],
          ['Fiscal: Nova nota','fiscal.php?p=nova','emitir nfse nfe nfcom rascunho servico produto'],
          ['Fiscal: Tomadores','fiscal.php?p=tomadores','cliente cadastro cpf cnpj endereco nota'],
          ['Fiscal: Produtos','fiscal.php?p=produtos','ncm cfop unidade produto servico'],
          ['Fiscal: Conta do PIX','fiscal.php?p=contas','qr pix chave conta recebimento api cobranca celcoin galaxpay'],
          ['Fiscal: Arquivos XML','fiscal.php?p=arquivos','xml pdf nota baixar'],<?php endif; ?>
          ['QR Code / PIX (gerar e ler)','qr.php','leitor camera pix qrcode codigo barras'],

          ['Solicitações da Central','solicitacoes.php','alterar login senha pppoe ipoe titularidade endereco cpf validar aprovar recusar central assinante pedido'],
          ['Chamados','chamados.php?p=lista','suporte os atendimento ticket'],
          ['Novo chamado','chamados.php?p=novo','abrir os suporte'],
          ['Instalações','chamados.php?p=lista&tipo=instalacao','instalar agenda tecnico'],
          ['Técnicos (cadastro)','chamados.php?p=tecnicos','tecnico campo instalador equipe cadastro'],

          ['Radius','radius.php','pppoe autenticacao'],
          ['Radius: Usuários','radius.php?p=usuarios','login senha pppoe'],
          ['Radius: Online','radius.php?p=online','conectados sessoes ativas'],
          ['Radius: Grupos','radius.php?p=grupos','radgroupreply plano velocidade'],
          ['Radius: IPoE','radius.php?p=ipoe','dhcp sem pppoe'],
          ['Radius: Consumo','radius.php?p=consumo','trafego download upload'],
          ['Radius: Logins inválidos','radius.php?p=invalidos','erro senha rejeitado'],
          ['Radius: Conexões por data','radius.php?p=por_data','historico sessao'],
          ['Concentradores','radius.php?p=conc','mikrotik nas accel bras'],
          ['Concentradores (tabela nas)','radius.php?p=nas','secret ip cliente radius'],
          ['Tráfego dos Servidores (ao vivo)','trafego_servidores.php','grafico download upload banda concentrador cnc gerencia mikrotik accel tempo real'],
          ['ACS / TR-069 (gerência remota das ONUs)','acs.php','acs tr069 tr-069 cwmp onu wifi canal senha rede reiniciar remoto roteador genieacs'],
          ['Saúde do sistema','saude.php','saude monitor alerta caiu fora do ar status servidor radius olt whatsapp rotina disco'],
          ['Painel dos Concentradores (monitoramento)','servidores.php','servidor online sessoes pppoe ipoe cnc monitoramento derrubar desbloqueio confianca ao vivo'],
          ['Total Radius (todos os clientes)','servidores.php?view=total_radius','radius total clientes ativo bloqueado confianca online'],

          ['OLT (aba do ERP)','olt_erp.php','fibra onu gpon autorizar'],
          ['OLT: Painel','olt_erp.php?p=painel','onu sinal status'],
          ['OLT: CTO / Caixas','olt_erp.php?p=cto','caixa atendimento porta splitter'],
          ['OLT: Clientes da CTO','olt_erp.php?p=cto_clientes','caixa porta cliente'],
          ['OLT: Rede FTTH (postes, cabos, CTOs)','rede_ftth.php','rede ftth kmz poste cabo mapa cto coordenada endereco'],
          ['OLT: Tráfego','olt_erp.php?p=trafego','grafico banda porta'],
          ['OLT: Terminal','olt_erp.php?p=terminal','telnet comando huawei'],
          ['OLT: Configuração','olt_erp.php?p=config','ip usuario senha telnet conexao'],
          ['OLT: Gerência OLT (painel completo)','olt.php','huawei onu gpon mkfiles arquivo equipamento'],
          ['OLT: Mini OLT Integrada','olts_genericas.php','mini olt integrada monitoramento olt outras marcas generica vlan clientes online offline switch snmp porta'],
          ['OLT: conferir contagem (tela x OLT real)','manutencao.php#comandos','conferencia divergencia quantidade onu faltando serial auditoria'],

          ['Estoque','estoque.php','equipamentos galeria onu roteador'],
          ['Estoque: Movimentações','estoque.php?view=mov','entrada saida historico'],
          ['Mapa','mapa.php','gps localizacao georreferencia coordenada'],
          ['Comercial / Leads','comercial.php','kanban vendas crm funil prospecto'],
          ['Documentos','documentos.php','contrato modelo assinatura'],

          ['Backup: Lista','backup.php?t=lista','copia seguranca download arquivo'],
          ['Backup: Agenda','backup.php?t=agenda','automatico horario cron'],
          ['Backup: Destinos','backup.php?t=destinos','ftp google drive local'],
          ['Backup: SMTP','backup.php?t=smtp','email envio servidor'],
          ['Importar backup / Migração','importar.php','migrar unificar maz restaurar backup'],

          ['Manutenção','manutencao.php','emergencia sincronizar verificar conferencia comandos em massa'],
          ['Diagnóstico da OLT','diagnostico_olt.php','diagnostico olt zona trava telnet versao md5 autorizacao cadastro serial teste ao vivo perfil sessao'],
          ['Comandos WellSystem','comandos.php','comando terminal putty ssh instalar atualizar conferir menu radius olt disco apache docker scp diagnostico versao md5 trava telnet service-port gemport native-vlan zona cadastro autorizacao'],
          ['Diagnóstico do servidor','diag.php','saude ram cpu disco cron tarefas extensao php banco pasta gravacao internet'],
          ['O que ficou de fora na importação','importacao_fora.php','descartado motivo backup cliente faltando nao entrou conferencia'],
          ['Central do assinante','central.php','portal cliente area assinante'],
          ['Ajuda / Docs','docs.php','manual duvidas documentacao'],
          ['Menu do servidor','menu_servidor.php','menu wellsystem putty disco update downgrade reparar ip backup expandir root'],
          ['Terminal (root)','terminal.php','console shell comando linux'],
          ['Backup','backup.php','copia seguranca download'],
          ['Backup para MK-Auth','backup_mkauth.php','exportar maz mkauth migrar restaurar cidade'],
          ['Integrações','integracoes.php','whatsapp typebot robo gateway lytex celcoin smtp email olt telegram nfse servico externo configurar'],
          ['Modelos de boleto/carnê (layout e textos)','boleto_template.php','template impressao carne layout'],
          ['Chamados abertos','chamados.php?p=lista&status=aberto','os pendente suporte'],
          ['Chamados resolvidos','chamados.php?p=lista&status=resolvido','os fechado concluido'],
          ['Instalações abertas','chamados.php?p=lista&tipo=instalacao&status=aberto','instalar pendente agenda'],
          ['Instalações resolvidas','chamados.php?p=lista&tipo=instalacao&status=resolvido','instalado concluido'],
          ['Nova instalação','chamados.php?p=novo&tipo=instalacao','agendar tecnico'],
          ['Documentos: Logo','documentos.php?p=logo','marca imagem cabecalho'],
          ['Clientes sem título','erp.php?p=clientes&status=semtitulo','sem fatura sem boleto pendencia'],
          ['Financeiro: Faturas excluídas','financeiro.php?p=excluidos','apagadas lixeira auditoria'],
          ['Faturas em aberto','financeiro.php?p=faturas&status=aberto','a vencer pendente'],
          ['Faturas pagas','financeiro.php?p=faturas&status=pago','quitado recebido baixado'],
          ['Faturas vencidas','financeiro.php?p=faturas&status=vencido','atraso inadimplente'],
          ['Mensagens','mensagens.php','whatsapp modelo automatico'],
          ['Monitor de concentrador (log/ping)','mk_monitor.php','ping log servidor concentrador'],
          ['Recibos','recibos.php','comprovante pagamento'],
          ['Zonas','zonas.php','regiao area cobertura setor'],
          ['Sair / Logout','erp.php?sair=1','logout deslogar encerrar sessao']
        ];
        /* EDIÇÃO (18/11/2026): a busca só lista página que existe na edição (OLT/Fiscal/ERP isolados não têm as telas dos outros módulos). */
        var __edOk = <?= json_encode(function_exists('ws_edicao_busca_arquivos') ? ws_edicao_busca_arquivos() : null) ?>, __edErp = <?= (!function_exists('ws_edicao_tem') || ws_edicao_tem('erp')) ? 'true' : 'false' ?>;
        if (__edOk) mapa = mapa.filter(function(m){ var h = String(m[1] || ''), b = h.split('?')[0]; if (/^https?:/.test(h)) return true; if (__edOk.indexOf(b) < 0) return false; if (b === 'erp.php' && !__edErp) return /^erp\.php\?(sair=1|p=config&t=(geral|operadores|seguranca))/.test(h); return true; });

        /* Tira acento e deixa minúsculo: "Manutenção" -> "manutencao". */
        function norm(s){
          return (s||'').toString().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
        }
        /* Nota do item: quanto maior, mais em cima ele aparece. -1 = não serve. */
        function nota(m, termos, sigla){
          var rotulo = norm(m[0]);
          var alvo   = norm(m[0]+' '+m[1]+' '+m[2]);
          var palavras = rotulo.split(/[^a-z0-9]+/).filter(Boolean);
          var iniciais = palavras.map(function(p){ return p.charAt(0); }).join('');
          var pts = 0;
          // 1) INICIAIS das palavras — "cb" acha "Cadastros: Bairros"
          if (sigla.length >= 2 && iniciais.indexOf(sigla) !== -1) pts += 1000;
          for (var i=0;i<termos.length;i++){
            var t = termos[i], ganho = 0;
            if (rotulo.indexOf(t) === 0) ganho = 500;                                        // abre o rótulo
            else if (palavras.some(function(p){ return p.indexOf(t) === 0; })) ganho = 300;  // abre uma palavra
            else if (alvo.indexOf(t) !== -1) ganho = 100;                                    // aparece no meio
            if (!ganho) return pts >= 1000 ? pts : -1;   // faltou esse pedaço: só passa se a sigla salvou
            pts += ganho;
          }
          return pts;
        }

        window.wsLupaFiltra = function(q){
          var box = document.getElementById('wsLupaRes'); if(!box) return;
          var cru = (q||'').trim();
          var n = norm(cru);
          var termos = n.split(/\s+/).filter(Boolean);
          var sigla  = n.replace(/[^a-z0-9]/g,'');
          var itens;
          if (termos.length === 0) {
            itens = mapa.slice(0,10);
          } else {
            itens = mapa.map(function(m){ return [m, nota(m, termos, sigla)]; })
                        .filter(function(x){ return x[1] > 0; })
                        .sort(function(a,b){ return b[1] - a[1]; })
                        .map(function(x){ return x[0]; });
          }
          var html='';
          itens.slice(0,40).forEach(function(m,idx){
            html += '<a href="'+m[1]+'" class="ws-lupa-hit'+(idx===0?' first':'')+'">'+m[0]+'</a>';
          });
          /* O campo de pesquisa de clientes continua existindo e é OUTRA coisa; a lupa só
             oferece o atalho para ele, nunca filtra a tela por conta própria. */
          if (cru !== '') {
            html += '<a href="erp.php?p=clientes&q='+encodeURIComponent(cru)+'" class="ws-lupa-hit'+(itens.length?'':' first')+'" style="border-top:1px solid var(--border)"><b>&#128270; Buscar clientes:</b> "'+cru.replace(/</g,"&lt;")+'"</a>';
          }
          box.innerHTML = html; box.style.display='block';
        };
        // Enter vai para o 1º resultado (página mapeada; se nenhuma casar, cai na busca de clientes).
        var inp=document.querySelector('#wsLupa .ws-lupa-input');
        if(inp) inp.addEventListener('keydown',function(e){
          if(e.key==='Enter'){ e.preventDefault(); var f=document.querySelector('#wsLupaRes .ws-lupa-hit.first')||document.querySelector('#wsLupaRes .ws-lupa-hit'); if(f){ location=f.getAttribute('href'); } else if(this.value.trim()){ location='erp.php?p=clientes&q='+encodeURIComponent(this.value.trim()); } }
          if(e.key==='Escape'){ document.getElementById('wsLupa').classList.remove('open'); document.getElementById('wsLupaRes').style.display='none'; }
        });
        document.addEventListener('click',function(e){ var w=document.getElementById('wsLupa'); if(w&&!w.contains(e.target)) document.getElementById('wsLupaRes').style.display='none'; });
      })();
      </script>
      <script>
      /* RECEBER / BUSCAR CLIENTE (pedido 07/10/2026) — janela no padrão do sistema (ws-modal + ws-table + ws-btn), aberta
         por F2 ou pelo atalho "Receber / buscar cliente" da lupa. Busca por nome, CPF, login, telefone, endereço, SN…;
         o cliente escolhido abre o formulário de recebimento IGUAL ao da ficha (valor do título, taxa, acréscimo, multa+mora,
         desconto — cada um com "zerar" —, valor pago, pago por, observação, recibo). A baixa é o MESMO POST do botão "Receber"
         da ficha (financeiro.php, acao=baixa_manual): mesmas travas, recibo, desbloqueio e log. Consulta: busca_rapida.php.
         Depois de receber, a janela limpa e já fica pronta para a próxima busca.
         Teclas: ↑↓ escolhe o cliente · Enter (na busca) vai para o valor · Enter (nos campos) recebe · Esc fecha · Ctrl+Enter abre a ficha. */
      (function(){
        var S = {lista:[], idx:0, tit:0, busy:false, reciboAuto:false, seq:0, aviso:'', timer:null, ov:null};
        function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
        function $(id){ return document.getElementById(id); }
        function num(v){ v = String(v||'').trim(); if (v.indexOf(',') > -1) v = v.replace(/\./g,'').replace(',','.'); var n = parseFloat(v); return isNaN(n) ? 0 : n; }
        function fmt(n){ return (Math.round(n*100)/100).toFixed(2).replace('.',','); }
        function cli(){ return S.lista[S.idx]; }
        function mostraNome(){ var c = cli(), q = $('wsRcQ'); if (c && q) q.value = c.nome; }   // o cliente escolhido fica escrito na pesquisa
        function titulo(){ var c = cli(); return c && c.titulos[S.tit]; }
        function montar(){
          if (S.ov) return;
          var o = document.createElement('div'); o.className = 'ws-modal-ov'; o.style.display = 'none';
          o.innerHTML = '<div class="ws-modal ws-rc-jan">'
            + '<h3>💰 Receber — buscar cliente</h3>'
            + '<p class="ws-muted" style="font-size:13px;margin:2px 0 10px">Digite nome, CPF, login, telefone, endereço ou SN. ↑↓ escolhe o cliente, Enter vai para o valor, Enter de novo recebe.</p>'
            + '<div id="wsRcMsg"></div>'
            + '<label style="display:block;margin-bottom:10px">Cliente<br><input id="wsRcQ" autocomplete="off" placeholder="digite ao menos 3 letras" style="font-size:16px;padding:11px 12px"></label>'
            + '<div id="wsRcTab" style="max-height:230px;overflow:auto"></div>'
            + '<div id="wsRcForm"></div>'
            + '<style>.ws-rc-g2{display:grid;grid-template-columns:2fr 1fr;gap:10px;margin-bottom:8px}.ws-rc-g5{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-bottom:8px}.ws-rc-g3{display:grid;grid-template-columns:1fr 2fr 2fr;gap:10px;margin-bottom:8px}'
            +   '.ws-rc-jan input,.ws-rc-jan select{max-width:100%;box-sizing:border-box}'
            +   '.ws-rc-barra{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-top:14px}.ws-rc-btns{display:flex;gap:10px;align-items:center;margin-left:auto}.ws-rc-btns .ws-btn{min-height:40px}'
            +   '@media(max-width:1000px){.ws-rc-g5{grid-template-columns:repeat(3,minmax(0,1fr))}.ws-rc-g3{grid-template-columns:1fr 1fr}}'
            +   '@media(max-width:700px){.ws-rc-g2,.ws-rc-g3{grid-template-columns:1fr}.ws-rc-g5{grid-template-columns:repeat(2,minmax(0,1fr))}.ws-rc-barra{flex-direction:column;align-items:stretch}.ws-rc-btns{margin-left:0;width:100%}.ws-rc-btns .ws-btn{flex:1}.ws-rc-barra>span{text-align:center}}'
            +   '@media(max-width:420px){.ws-rc-g5{grid-template-columns:1fr}}</style>'
            + '<div class="ws-rc-barra">'
            +   '<span class="ws-muted" style="font-size:12px">Ctrl+Enter abre a ficha · Esc fecha</span>'
            +   '<span class="ws-rc-btns"><button type="button" class="ws-btn" id="wsRcX">Fechar</button>'
            +   '<button type="button" class="ws-btn verde" id="rcGo" onclick="wsRcExec()" style="display:none;font-size:15px;padding:9px 26px">Receber</button></span></div></div>';
          document.body.appendChild(o); S.ov = o;
          /* Clicar FORA não fecha a janela de recebimento (pedido 07/10/2026): só o botão Fechar ou Esc. */
          /* Aumentar/diminuir pelo canto inferior direito (além de arrastar, maximizar e minimizar, que vêm do padrão das janelas). */
          var cx = o.firstChild;
          cx.addEventListener('mousedown', function(e){ var r = cx.getBoundingClientRect(); if (e.clientX > r.right-22 && e.clientY > r.bottom-22 && !o.classList.contains('solta') && !o.classList.contains('max')) { o.classList.add('solta'); cx.style.left = r.left+'px'; cx.style.top = r.top+'px'; } });
          $('wsRcX').onclick = fechar;
          var q = $('wsRcQ');
          q.addEventListener('input', function(){ clearTimeout(S.timer); var v = q.value; S.timer = setTimeout(function(){ consulta(v); }, 220); });
          q.addEventListener('keydown', teclasBusca);
          o.addEventListener('keydown', function(e){ if (e.key === 'Escape') { e.preventDefault(); fechar(); } });
        }
        function abrir(){ montar(); if (!S.ov.classList.contains('max') && !S.ov.classList.contains('min')) { S.ov.classList.remove('solta'); S.ov.firstChild.style.left = ''; S.ov.firstChild.style.top = ''; } S.ov.style.display = 'flex'; var q = $('wsRcQ'); q.focus(); q.select(); }
        function fechar(){ if (S.ov) S.ov.style.display = 'none'; }
        function reinicia(){ S.lista = []; S.idx = 0; S.tit = 0; $('wsRcQ').value = ''; render(); $('wsRcQ').focus(); }
        function render(){
          $('wsRcMsg').innerHTML = S.aviso ? '<div class="ws-alert" style="background:rgba(22,163,74,.12);color:var(--ok);margin:0 0 12px;font-size:13px">'+S.aviso+'</div>' : '';
          var q = $('wsRcQ').value.trim();
          if (!S.lista.length) { $('wsRcTab').innerHTML = q.length >= 3 ? '<div class="ws-muted" style="padding:12px 0">Nenhum cliente encontrado.</div>' : ''; $('wsRcForm').innerHTML = ''; var bgo1 = $('rcGo'); if (bgo1) bgo1.style.display = 'none'; return; }
          var h = '<table class="ws-table"><thead><tr><th>Cliente</th><th>Login</th><th>Em aberto</th><th>Mais antigo</th><th style="text-align:right">Valor hoje</th></tr></thead><tbody>';
          S.lista.forEach(function(c,i){
            var t = c.titulos[0], on = (i === S.idx);
            h += '<tr style="cursor:pointer'+(on?';background:color-mix(in srgb,var(--brand) 9%,transparent)':'')+'" onclick="wsRcSel('+i+')">'
              + '<td><b class="ws-rc-nome" data-cli="'+c.id+'">'+esc(c.nome)+'</b>'+(c.status==='bloqueado'?' <span class="ws-tag bloqueado">bloqueado</span>':'')+'<br><span class="ws-muted" style="font-size:12px">'+esc(c.cpf)+'</span></td>'
              + '<td>'+esc(c.login||'—')+'</td>'
              + '<td>'+(c.abertos ? c.abertos+' · R$ '+esc(c.total_fmt) : '<span class="ws-muted">nada</span>')+'</td>'
              + '<td>'+(t ? esc(t.venc)+(t.dias>0?' <span style="font-size:12px;color:var(--err)">('+t.dias+' d)</span>':'') : '—')+'</td>'
              + '<td style="text-align:right">'+(t ? '<b>R$ '+esc(t.valor_fmt)+'</b>' : '—')+'</td></tr>';
          });
          $('wsRcTab').innerHTML = h + '</tbody></table>';
          formulario();
        }
        /* Formulário de recebimento do cliente escolhido (mesmos campos do "Receber título" da ficha). */
        function formulario(){
          var c = cli(), t = titulo(), f = $('wsRcForm'), antes = document.activeElement && document.activeElement.id;
          var bgo0 = $('rcGo'); if (bgo0) bgo0.style.display = (c && t) ? '' : 'none';
          if (!c || !t) { f.innerHTML = c ? '<div class="ws-muted" style="padding:12px 0">Este cliente não tem título em aberto. Ctrl+Enter abre a ficha.</div>' : ''; return; }
          var opts = ''; c.titulos.forEach(function(x,k){ opts += '<option value="'+k+'"'+(k===S.tit?' selected':'')+'>#'+x.id+' · venc. '+esc(x.venc)+' · R$ '+esc(x.valor_fmt)+'</option>'; });
          var z = function(id){ return ' <span style="font-size:11px;color:var(--err);white-space:nowrap;font-weight:400"><input type="checkbox" onchange="wsRcZ(\''+id+'\',this)" style="margin:0 2px 0 4px;width:auto;vertical-align:middle"> zerar</span>'; };
          f.innerHTML = '<div style="border-top:1px solid var(--border);margin-top:12px;padding-top:12px">'
            + '<div class="ws-rc-g2">'
            +   '<label>Título<br><select id="rcTit" onchange="wsRcTit(this.value)">'+opts+'</select></label>'
            +   '<label>Modo de recebimento<br><select id="rcFor"><option value="dinheiro">💵 Dinheiro</option><option value="pix">💠 Pix</option><option value="cartao">💳 Cartão</option><option value="cheque">🧾 Cheque</option></select></label>'
            + '</div>'
            + '<div class="ws-rc-g5">'
            +   '<label>Valor do título<br><input id="rcB" value="'+esc(t.base_txt)+'" style="text-align:right"></label>'
            +   '<label for="rcT">Taxa emissão'+z('rcT')+'<br><input id="rcT" value="'+esc(t.taxa_txt)+'" style="text-align:right"></label>'
            +   '<label for="rcA">Acréscimo'+z('rcA')+'<br><input id="rcA" value="0,00" style="text-align:right"></label>'
            +   '<label for="rcM">Multa+Mora'+z('rcM')+'<br><input id="rcM" value="'+esc(t.mm_txt)+'" style="text-align:right"></label>'
            +   '<label for="rcD">Desconto'+z('rcD')+'<br><input id="rcD" value="0,00" style="text-align:right"></label>'
            + '</div>'
            + '<div class="ws-rc-g3">'
            +   '<label>Valor pago<br><input id="rcV" value="'+esc(t.valor_txt)+'" style="text-align:right;font-weight:800;font-size:17px"></label>'
            +   '<label>Pagamento realizado por (opcional)<br><input id="rcP" maxlength="120" placeholder="ex.: Maria (mãe do titular), vizinho, empresa..."></label>'
            +   '<label>Observação (opcional)<br><input id="rcO" placeholder="ex.: pagou com atraso, combinado com o cliente..."></label>'
            + '</div>'
            + '<div style="display:flex;align-items:center">'
            +   '<label class="ws-chk" style="font-size:13px;display:flex!important;align-items:center;gap:6px"><input type="checkbox" id="rcR" style="margin:0;width:auto" '+(S.reciboAuto?'checked':'')+'> 📲 Enviar recibo por WhatsApp agora</label>'
            + '</div></div>';
          var bgo = $('rcGo'); if (bgo) { bgo.style.display = ''; bgo.textContent = S.busy ? 'Recebendo…' : 'Receber'; }
          ['rcB','rcT','rcA','rcM','rcD'].forEach(function(id){ $(id).addEventListener('input', calc); });
          ['rcB','rcT','rcA','rcM','rcD','rcV','rcP','rcO','rcFor','rcR'].forEach(function(id){
            $(id).addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); wsRcExec(); } });
          });
          if (S.forma) $('rcFor').value = S.forma;
          $('rcFor').addEventListener('change', function(){ S.forma = this.value; });
        }
        function calc(){ $('rcV').value = fmt(num($('rcB').value) + num($('rcT').value) + num($('rcA').value) + num($('rcM').value) - num($('rcD').value)); }
        window.wsRcZ = function(id, cb){ var el = $(id); if (!cb || cb.checked) { if (cb) el.dataset.orig = el.value; el.value = '0,00'; } else if (el.dataset.orig !== undefined) { el.value = el.dataset.orig; } calc(); };   // marcado = zera; desmarcado = volta o valor que estava
        window.wsRcSel = function(i){ S.idx = i; S.tit = 0; mostraNome(); render(); };
        window.wsRcTit = function(k){ S.tit = +k; formulario(); var v = $('rcV'); if (v) { v.focus(); v.select(); } };
        window.wsRcExec = function(){
          var c = cli(), t = titulo(); if (!c || !t || S.busy) return;
          var vp = num($('rcV').value);
          if (vp <= 0) { S.aviso = ''; $('wsRcMsg').innerHTML = '<div class="ws-alert" style="background:rgba(220,38,38,.12);color:var(--err);margin:0 0 12px;font-size:13px">Informe o valor pago.</div>'; return; }
          S.busy = true; $('rcGo').textContent = 'Recebendo…';
          var fd = new URLSearchParams();
          fd.set('acao','baixa_manual'); fd.set('fatura_id',t.id); fd.set('forma',$('rcFor').value); fd.set('valor_pago',fmt(vp));
          fd.set('data_pgto',''); fd.set('obs',($('rcO').value.trim() ? $('rcO').value.trim() : 'Recebido pela busca rápida')); fd.set('pago_por',$('rcP').value.trim()); fd.set('volta','busca_rapida.php');
          if ($('rcR').checked) fd.set('enviar_recibo','1');
          var forma = $('rcFor').options[$('rcFor').selectedIndex].text;
          fetch('financeiro.php', {method:'POST', body:fd, credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded'}})
            .then(function(r){ return r.json(); })
            .then(function(j){
              S.busy = false;
              if (j && j.ok && j.pago) {
                S.aviso = '✅ #'+t.id+' de '+esc(c.nome)+' recebido: R$ '+esc(fmt(vp))+' ('+esc(forma)+'). Pronto para o próximo.';
                reinicia();   // limpa a busca e já deixa o cursor pronto para o próximo cliente
              } else {
                S.aviso = '';
                $('wsRcMsg').innerHTML = '<div class="ws-alert" style="background:rgba(217,119,6,.14);color:var(--warn);margin:0 0 12px;font-size:13px">'
                  + (j && j.ok ? 'Este título já estava pago — nada foi duplicado.' : 'Não consegui confirmar a baixa. Abra a ficha e confira antes de tentar de novo.') + '</div>';
                var b = $('rcGo'); if (b) b.textContent = 'Receber';
              }
            })
            ['catch'](function(){ S.busy = false; $('wsRcMsg').innerHTML = '<div class="ws-alert" style="background:rgba(217,119,6,.14);color:var(--warn);margin:0 0 12px;font-size:13px">Falha de conexão. Confira na ficha se o título foi pago antes de tentar de novo.</div>'; var b = $('rcGo'); if (b) b.textContent = 'Receber'; });
        };
        function consulta(q){
          q = (q||'').trim();
          if (q.length < 3) { S.lista = []; S.idx = 0; render(); return; }
          var seq = ++S.seq;
          fetch('busca_rapida.php?q='+encodeURIComponent(q), {credentials:'same-origin'})
            .then(function(r){ return r.json(); })
            .then(function(j){
              if (seq !== S.seq || !j || !j.ok) return;
              S.lista = j.clientes || []; S.reciboAuto = !!j.recibo_auto; S.idx = 0; S.tit = 0; S.aviso = ''; render();
            })['catch'](function(){});
        }
        function teclasBusca(e){
          var n = S.lista.length; if (!n) return;
          if (e.key === 'ArrowDown') { S.idx = Math.min(S.idx+1, n-1); S.tit = 0; mostraNome(); render(); e.preventDefault(); }
          else if (e.key === 'ArrowUp') { S.idx = Math.max(S.idx-1, 0); S.tit = 0; mostraNome(); render(); e.preventDefault(); }
          else if (e.key === 'Enter') {
            e.preventDefault(); var c = cli();
            if (e.ctrlKey || !c.titulos.length) { location = 'erp.php?p=cliente&id='+c.id; return; }
            var v = $('rcV'); if (v) { v.focus(); v.select(); }
          }
        }
        window.wsReceberAbrir = abrir;
        /* RESUMO AO PASSAR O MOUSE no nome do cliente da lista (15/10/2026): o mesmo cartão do nome resumido nas listas (erp.php?ajax=resumo_cli). */
        (function(){ var box = null, timer = null, tHide = null, alvo = null, cache = {};
          function caixa(){ if (box) return box; box = document.createElement('div');
            box.style.cssText = 'position:fixed;z-index:100300;width:max-content;max-width:min(560px,94vw);min-width:230px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:10px;padding:10px 12px;font-size:12.5px;line-height:1.55;box-shadow:0 12px 30px -10px rgba(0,0,0,.45);display:none';
            box.addEventListener('mouseenter', function(){ clearTimeout(tHide); }); box.addEventListener('mouseleave', agenda); document.body.appendChild(box); return box; }
          function pos(el){ var r = el.getBoundingClientRect(), b = caixa(), w = b.offsetWidth, h = b.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
            var topo = (r.bottom - 2 + h <= vh - 8) ? r.bottom - 2 : Math.max(4, r.top + 2 - h); b.style.left = Math.max(8, Math.min(r.left, vw - w - 8)) + 'px'; b.style.top = topo + 'px'; }
          function mostra(el){ var id = el.getAttribute('data-cli'); if (!id) return; var b = caixa();
            if (cache[id]) { b.innerHTML = cache[id]; b.style.display = 'block'; pos(el); return; }
            b.innerHTML = '<span style="opacity:.7">Carregando…</span>'; b.style.display = 'block'; pos(el);
            fetch('erp.php?ajax=resumo_cli&id=' + encodeURIComponent(id), {credentials: 'same-origin'}).then(function(r){ return r.text(); })
              .then(function(t){ cache[id] = t; if (alvo === el) { b.innerHTML = t; pos(el); } }).catch(function(){ b.innerHTML = '<span style="opacity:.7">Não consegui carregar.</span>'; }); }
          function esconde(){ clearTimeout(timer); clearTimeout(tHide); alvo = null; if (box) box.style.display = 'none'; }
          function agenda(){ clearTimeout(timer); clearTimeout(tHide); tHide = setTimeout(esconde, 120); }
          document.addEventListener('mouseover', function(e){ var el = e.target.closest && e.target.closest('.ws-rc-nome'); if (el) clearTimeout(tHide); if (!el || el === alvo) return;
            alvo = el; clearTimeout(timer); timer = setTimeout(function(){ if (alvo === el) mostra(el); }, 350); });
          document.addEventListener('mouseout', function(e){ var el = e.target.closest && e.target.closest('.ws-rc-nome'); if (!el) return; var p = e.relatedTarget; if (p && (el.contains(p) || (box && box.contains(p)))) return; agenda(); });
          document.addEventListener('click', function(e){ if (e.target.closest && e.target.closest('.ws-rc-nome')) esconde(); }, true);
        })();
        document.addEventListener('click', function(e){ var a = e.target.closest && e.target.closest('a[href="#ws-receber"]'); if (a) { e.preventDefault(); abrir(); } });   // item do menu Financeiro
        document.addEventListener('keydown', function(e){ if (e.key === 'F2') { e.preventDefault(); abrir(); } });
        /* Atalho dentro da lupa: sempre o 1º item da lista. */
        var origF = window.wsLupaFiltra;
        window.wsLupaFiltra = function(q){
          origF(q);
          var b = document.getElementById('wsLupaRes'); if (!b) return;
          var a = document.createElement('a'); a.href = '#'; a.className = 'ws-lupa-hit'; a.innerHTML = '<b>💰 Receber / buscar cliente</b> <span class="ws-muted">(F2)</span>';
          a.onclick = function(ev){ ev.preventDefault(); b.style.display = 'none'; abrir(); var v = (q||'').trim(); if (v) { $('wsRcQ').value = v; consulta(v); } };
          b.insertBefore(a, b.firstChild);
        };
      })();
      </script>
      <button type="button" class="ws-btn-tema-top" onclick="var t=localStorage.getItem('ws_theme')||(window.matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'); var nt=t==='dark'?'light':'dark'; localStorage.setItem('ws_theme',nt); document.documentElement.setAttribute('data-theme',nt);" title="Alternar claro/escuro">
        <svg class="ws-ico-sol" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="4.2" stroke="currentColor" stroke-width="1.6"/><path d="M12 2.5v2.4M12 19.1v2.4M4.4 4.4l1.7 1.7M17.9 17.9l1.7 1.7M2.5 12h2.4M19.1 12h2.4M4.4 19.6l1.7-1.7M17.9 6.1l1.7-1.7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
        <svg class="ws-ico-lua" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.5 14.6A8.6 8.6 0 1 1 9.4 3.5a7 7 0 0 0 11.1 11.1Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
      </button>
      <div id="ws-cor-pick" style="position:relative;display:inline-flex;align-items:center">
        <button type="button" class="ws-btn-cor-top" title="Aparência do sistema (cor)" onclick="document.getElementById('ws-cor-pop').classList.toggle('open')">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.7-.9 1.2-1.85-.25-.47-.15-1.05.27-1.35A2.5 2.5 0 0 1 15 17.2c.9.35 1.9-.1 2.2-1A9 9 0 0 0 12 3Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="7.5" cy="11" r="1.4" fill="currentColor"/><circle cx="11" cy="7.3" r="1.4" fill="currentColor"/><circle cx="15.2" cy="8.3" r="1.4" fill="currentColor"/><circle cx="16.8" cy="12.6" r="1.4" fill="currentColor"/></svg>
        </button>
        <div id="ws-cor-pop" class="ws-cor-pop">
          <span style="font-size:11px;color:var(--muted);width:100%;display:block;margin-bottom:2px">Cor do sistema</span>
          <span id="wc-vinho" data-cor="vinho" title="Vinho" onclick="wsThemeSet('vinho')" style="width:22px;height:22px;border-radius:50%;background:#9E2A3B;cursor:pointer;border:2px solid transparent;display:inline-block"></span>
          <span id="wc-azul"  data-cor="azul"  title="Azul"  onclick="wsThemeSet('azul')"  style="width:22px;height:22px;border-radius:50%;background:#1d4ed8;cursor:pointer;border:2px solid transparent;display:inline-block"></span>
          <span id="wc-preto" data-cor="preto" title="Preto" onclick="wsThemeSet('preto')" style="width:22px;height:22px;border-radius:50%;background:#111827;cursor:pointer;border:2px solid transparent;display:inline-block"></span>
          <span id="wc-verde" data-cor="verde" title="Verde" onclick="wsThemeSet('verde')" style="width:22px;height:22px;border-radius:50%;background:#16a34a;cursor:pointer;border:2px solid transparent;display:inline-block"></span>
        </div>
      </div>
      <script>
      (function(){
        document.addEventListener('click',function(e){var p=document.getElementById('ws-cor-pop'),b=document.getElementById('ws-cor-pick');if(p&&b&&!b.contains(e.target))p.classList.remove('open');});
        var c=localStorage.getItem('ws_cor')||window.WS_COR_PADRAO||'vinho';
        document.querySelectorAll('#ws-cor-pop [data-cor]').forEach(function(s){s.style.borderColor=s.dataset.cor===c?'var(--text)':'transparent';});
      })();
      function wsThemeSet(c){
        localStorage.setItem('ws_cor',c);
        localStorage.setItem('ws_cor_em',String(Math.max(Date.now(),(window.WS_COR_PADRAO_EM||0)+1)));   // escolha pessoal, depois do padrão
        if(c==='vinho') document.documentElement.removeAttribute('data-cor'); else document.documentElement.setAttribute('data-cor',c);
        document.querySelectorAll('#ws-cor-pop [data-cor]').forEach(function(s){s.style.borderColor=s.dataset.cor===c?'var(--text)':'transparent'});
        document.getElementById('ws-cor-pop').classList.remove('open');
      }
      </script>
      <a href="erp.php?ws_reflexo=1" title="Reflexo do sistema: ressincroniza todo o código e re-autentica (sem apagar dados)" onclick="return confirm('Ressincronizar o sistema e sair? Você vai entrar com a senha de novo. Nenhum dado é apagado.')" class="ws-btn-reflexo-top" style="color:var(--ok);-webkit-text-fill-color:var(--ok)">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 11A8 8 0 1 0 18.6 16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M20 5v6h-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </a>
      <?php
        $ramal = ws_ramal_atual();
        $opts = [];
        try { $opts = ws_db()->query("SELECT r.id,r.nome,c.nome cidade FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 ORDER BY c.nome,r.nome")->fetchAll(); } catch (Throwable $e) {}
        // Só as cidades liberadas para o login (nível 3/root: todas). "Todas as cidades" só para nível 3.
        $permTopo = ws_ramais_permitidos();
        if ($permTopo !== null) $opts = array_values(array_filter($opts, fn($o) => in_array((int)$o['id'], $permTopo, true)));
        if ($opts): ?>
        <select class="ws-nav-cidade" onchange="location='?set_ramal='+this.value" title="Cidade/ramal">
          <?php if (ws_pode_configurar()): ?><option value="0">Todas as cidades</option><?php endif; ?>
          <?php foreach ($opts as $o): $sel = ($ramal && (int)$ramal['id'] === (int)$o['id']) ? 'selected' : ''; ?>
          <option value="<?= (int)$o['id'] ?>" <?= $sel ?>><?= h($o['cidade'] . ' — ' . $o['nome']) ?></option>
          <?php endforeach; ?>
        </select>
      <?php endif; ?>
      <div class="ws-user"><?= ws_user_chip() ?></div>
    </div>
    <div class="ws-top-l2">
      <span class="ws-top-marca"><?= ws_brand_sm() ?></span>
      <!-- Botão HAMBÚRGUER (só aparece no celular/tablet) — abre o menu completo em coluna. -->
      <button type="button" class="ws-nav-toggle" aria-label="Menu" aria-expanded="false" onclick="wsToggleMenu(this)">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        <span>Menu</span>
      </button>
      <?php ws_nav_completo($ativo); ?>
      <span class="ws-top-spacer" aria-hidden="true"></span>
    </div>
    <?php /* BARRA DE STATUS — última linha do topo, abaixo do menu.
             Fica aqui, e não acima, por uma razão de leitura: o que o operador usa para TRABALHAR
             (marca e menu) vem primeiro; o que ele usa para CONFERIR (saúde do servidor, seu
             acesso, seu IP) vem depois, como rodapé do cabeçalho. Assim a barra informa sem
             competir com a navegação.
             Só aparece logado — ela expõe IP, horário de acesso e saúde da máquina. */ ?>
    <?= function_exists('ws_barra_status') ? ws_barra_status() : '' ?>
    <div class="ws-nav-backdrop" id="wsNavBackdrop" onclick="wsToggleMenu(false)"></div>
    <script>
      // Menu mobile: abre/fecha o painel em coluna e permite abrir/fechar cada grupo (acordeão).
      function wsToggleMenu(btn){
        var nav=document.querySelector('.ws-nav'), bd=document.getElementById('wsNavBackdrop'); if(!nav) return;
        var abrir = (btn===false) ? false : !nav.classList.contains('open');
        nav.classList.toggle('open', abrir); if(bd) bd.classList.toggle('open', abrir);
        var t=document.querySelector('.ws-nav-toggle'); if(t) t.setAttribute('aria-expanded', abrir?'true':'false');
        document.body.style.overflow = abrir ? 'hidden' : '';
      }
      // Acordeão dos grupos SÓ no mobile (no desktop continua por hover). Um aberto por vez.
      document.addEventListener('click', function(e){
        if (window.innerWidth > 900) return;
        var lbl = e.target.closest && e.target.closest('.ws-grp-lbl'); if(!lbl) return;
        e.preventDefault(); e.stopPropagation();
        var grp = lbl.parentNode, jaAberto = grp.classList.contains('open');
        document.querySelectorAll('.ws-nav .ws-grp.open').forEach(function(g){ if(g!==grp) g.classList.remove('open'); });
        grp.classList.toggle('open', !jaAberto);
      }, true);
    </script>
    <?php
    return ob_get_clean();
}

function ws_nav_completo(string $ativo = ''): void {
    // Menu inteiro montado AQUI em PHP puro (HTML), sem depender de JS pra abrir os submenus —
    // funciona só com CSS (:hover em .ws-grp mostra .ws-sub). O JS antes reconstruía tudo isso
    // via JS puro; se o JS falhasse por qualquer motivo (erro, cache, bloqueio), o menu caía pra
    // uma versão "achatada" sem dropdown nenhum. Agora não tem esse ponto único de falha.
    $grupos = [
        ['label' => 'Painel', 'href' => 'erp.php?p=dashboard'],
        ['label' => 'Clientes', 'sections' => [
            'Relacionar' => [
                ['erp.php?p=clientes', '📋 Listar todos os clientes'],
                ['erp.php?p=clientes_recentes', '⭐ Clientes recentes'],
                ['erp.php?p=cliente', '➕ Inserir novo cliente'],
                ['erp.php?p=clientes&status=adicional', '👥 Clientes adicionais'],
                ['documentos.php', 'Documentos do cliente'],
            ],
            'Financeiro' => [
                ['erp.php?p=clientes&status=atraso', '⏰ Com pagamentos em atraso'],
            ],
            'Status' => [
                ['erp.php?p=clientes&status=ativo', '✅ Ativos'],
                ['erp.php?p=clientes&status=bloqueado', '⛔ Bloqueados'],
                ['erp.php?p=clientes&status=observacao', '🔓 Em observação'],
                ['erp.php?p=clientes&status=observacao', '👁️ Em observação'],
                ['erp.php?p=clientes&status=semtitulo', '❓ Sem boleto/título'],
                ['erp.php?p=clientes&status=cancelado', '🚫 Total Cancelado'],
                ['relatorios.php?p=base&ver=ativacoes&de=' . ws_clientes_mes()['ini'] . '&ate=' . ws_clientes_mes()['fim'], '🆕 Ativados no mês (' . ws_clientes_mes()['a'] . ')'],
                ['relatorios.php?p=base&ver=desativacoes&de=' . ws_clientes_mes()['ini'] . '&ate=' . ws_clientes_mes()['fim'], '📉 Desativados no mês (' . ws_clientes_mes()['d'] . ')'],
            ],
        ]],
        /* FINANCEIRO DIVIDIDO EM DOIS — e por que não cabia em um.
         *
         * Eram 19 itens em 4 colunas num painel só: o menu abria mais largo que a tela e a última
         * coluna ficava cortada na borda. Separar por PERGUNTA, e não por tamanho:
         *   Financeiro → o que o provedor EMITE e tem a receber (título, carnê).
         *   Cobrança   → o dinheiro que ENTRA e o que o faz entrar (caixa, conciliação, nota,
         *                recibo, régua, mensagem).
         * Nenhum item sumiu e nenhuma URL mudou — favorito antigo continua abrindo a mesma tela.
         *
         * ÍCONES: um por função, sem repetir dentro do mesmo assunto. Antes o 🧾 aparecia três
         * vezes (gerar fatura, nota fiscal e recibo) e o 📚 duas, então o ícone não distinguia
         * nada — que é a única coisa que um ícone de menu precisa fazer. Agora 🧾 é só nota
         * fiscal, 💵 é recibo (e conversa com o 💰 do caixa) e ➕ é emitir, como no Suporte. */
        ['label' => 'Financeiro', 'sections' => [
            'Títulos' => [
                ['#ws-receber', '💰 Receber / buscar cliente (F2)'],   /* (15/10/2026) o mesmo atalho da lupa, também no menu; abre a janela de recebimento */
                ['financeiro.php?p=faturas', '📋 Listar todos os títulos'],
                ['financeiro.php?p=faturas&status=aberto', '📥 Títulos a receber'],
                ['financeiro.php?p=faturas&status=vencido', '⏰ Títulos vencidos'],
                ['financeiro.php?p=faturas&status=pago', '✅ Títulos já pagos'],
                ['financeiro.php?p=gerar', '➕ Gerar fatura'],
                ['financeiro.php?p=mes_errado', '⚠️ Pagou o boleto do mês errado'],
                ['financeiro.php?p=excluidos', '🗑️ Relatório de boletos excluídos'],
            ],
            // comprovantes que o cliente manda pelo robô do WhatsApp (comprovantes_lib.php); título próprio (18/11)
            'Comprovantes PIX' => [
                ['comprovantes.php', '📎 Comprovantes PIX (WhatsApp)'],
            ],
            'Carnês / Boleto' => [
                ['financeiro.php?p=carne', '📚 Gerar carnê em massa'],
                ['boleto_template.php', '🖌️ Modelos de boleto/carnê (layout e textos)'],
                ['financeiro.php?p=gateway', '🔌 Gateway / API (CelCoin · Lytex)'],
                ['financeiro.php?p=por_gateway', '🏦 Títulos por gateway (CelCash · PIX QR · Lytex)'],
            ],
        ]],
        ['label' => 'Cobrança', 'sections' => [
            'Caixa / Conciliação' => [
                ['relatorios.php?p=caixa', '💰 Caixa do Dia'],
                ['financeiro.php?p=resumo', '📊 Resumo (mensal/semestral/anual)'],
                ['conciliacao.php', '🔄 Conciliação (OFX/PIX)'],
            ],
            ...(ws_pode_configurar() ? ['Notas fiscais' => [['fiscal.php?p=notas', '🧾 Notas fiscais (NFSe)']]] : []),   // Fiscal: só nível 3 e root (14/11/2026); título próprio (18/11)
            'Recibos / Régua' => [
                ['recibos.php', '💵 Recibos'],
                ['recibos.php?p=resumo', '📅 Resumo do dia'],
                ['cobranca.php?p=regua', '📐 Régua de cobrança'],
                ['erp.php?p=config&t=cobranca', '⚙️ Regras de cobrança'],
                ['mensagens.php', '💬 Mensagens automáticas'],
            ],
        ]],
        ['label' => 'OLT', 'items' => [
            /* GERÊNCIA OLT — o painel completo da OLT (ONU/ONT, sinais, aprovisionamento). Estava
               em Servidores e, antes disso, escondido dentro do menu interno do Painel dos
               Concentradores. Lugar de OLT é no menu OLT, e em primeiro, que é o mais usado. */
            ['olt.php', '🛰️ Gerência OLT', '_blank'],
            ['olt_erp.php', '🔧 Aprovisionamento ONU / ONT'],
            ['olt_erp.php?p=terminal', '💻 Gerenciador (Telnet)'],
            ['olt_erp.php?p=trafego', '📶 Relatório de tráfego'],
            ['olt_erp.php?p=cto', '📍 Mapa de CTO'],
            ['olt_erp.php?p=cto_clientes', '📦 Relatório CTO (clientes por caixa)'],
            ['olts_genericas.php', '📡 Mini OLT Integrada'],
            ['rede_ftth.php', '🗺️ Rede FTTH (postes, cabos, CTOs)'],
        ]],
        ['label' => 'Rede', 'sections' => array_filter([
            /* Concentradores e NAS ficam fora para níveis 1 e 2 (ws_pode_infra): é cadastro de
               infraestrutura, não consulta. O resto do Radius — usuários, online, rejeitados,
               acessos por data, consumo — continua como está, que é o trabalho do atendimento. */
            'Radius' => array_merge([
                ['radius.php?p=usuarios', '👤 Usuários'],
                ['radius.php?p=online', '🟢 Online agora'],
            ], ws_pode_infra() ? [
                ['radius.php?p=conc', '🖧 Concentradores'],
                ['radius.php?p=nas', '🖧 NAS'],
            ] : [], [
                ['radius.php?p=invalidos', '⚠️ Acessos rejeitados'],
                ['radius.php?p=por_data', '📅 Acessos por data'],
                ['radius.php?p=consumo', '📶 Consumo de banda'],
            ]),
            'Monitoramento' => [
                ['mapa.php', '📍 Mapa geral'],
            ],
            // Ofício/ordem judicial: quem era este IP público e porta (traz CPF e endereço: só nível 3+).
            'CGNAT' => ws_nivel_acesso() >= 3 ? [
                ['cgnat.php', '⚖️ Identificação de Assinante (CGNAT)'],
            ] : null,
            // Mexe na rede do próprio servidor (IP/máscara/gateway) — item de risco, só root.
            'Servidor' => ws_eh_root() ? [
                ['rede_servidor.php', '🌐 Rede do servidor'],
            ] : null,
        ])],
        /* array_filter: a seção de configuração some do menu para quem não pode configurar, e
           uma seção que vira null precisa CAIR do array — o desenho do menu percorre as seções
           com foreach, e um null ali seria erro de PHP na hora de montar o topo. Mesmo motivo do
           grupo Rede, logo acima. */
        ['label' => 'Suporte', 'sections' => array_filter([
            /* Chamados e instalações são duas seções separadas neste menu — então os itens de
               CHAMADO não podem listar instalação junto, senão as duas seções mostram a mesma
               coisa. O "!instalacao" é lido pelo chamados.php como "tudo que não é instalação"
               (mesma conta que o card "Chamados em aberto" do Painel faz). */
            'Controle de chamados' => [
                ['chamados.php?p=novo', '➕ Inserir novo chamado'],
                ['chamados.php?p=lista&tipo=!instalacao', '🔍 Buscar chamados'],
                ['chamados.php?p=lista&status=aberto&tipo=!instalacao', '📂 Chamados abertos'],
                ['chamados.php?p=lista&status=resolvido&tipo=!instalacao', '✅ Chamados fechados'],
            ],
            'Central do assinante' => [
                ['solicitacoes.php', '🔔 Solicitações da Central (validar)'],
                ['solicitacoes.php?s=historico', '🗂️ Histórico de solicitações'],
            ],
            'Controle de instalações' => [
                ['chamados.php?p=novo&tipo=instalacao', '➕ Inserir nova instalação'],
                ['chamados.php?p=lista&tipo=instalacao', '🔍 Buscar instalação'],
                ['chamados.php?p=lista&tipo=instalacao&status=aberto', '📂 Instalações abertas'],
                ['chamados.php?p=lista&tipo=instalacao&status=resolvido', '✅ Instalações concluídas'],
            ],
            // Técnicos de CAMPO (instalação/suporte) — cadastro próprio, separado dos usuários (atendimento).
            'Equipe de campo' => [
                ['chamados.php?p=tecnicos', '👷 Técnicos (cadastro)'],
            ],
            // Por onde sai o aviso de chamado (WhatsApp/Evolution e Telegram) e para quem.
            'Envio / avisos' => ws_pode_configurar() ? [
                ['chamados.php?p=config', '⚙️ Notificações (WhatsApp / Telegram)'],
            ] : null,
        ])],
        ['label' => 'Relatórios', 'sections' => [
            'Financeiro' => [
                ['relatorios.php?p=caixa', '💰 Caixa do Dia'],
                ['relatorios.php?p=financeiro', '📊 Balancete / Gráficos'],
                ['relatorios.php?p=receber', '📥 Boletos a receber'],
            ],
            'Operacional' => [
                ['relatorios.php?p=base', '🔌 Ativação / Desativação'],
                ['relatorios.php?p=log', '📜 Log / Auditoria'],
            ],
        ]],
        ['label' => 'Backup', 'items' => array_merge([
            ['backup.php', '💾 Backup do sistema'],
            ['backup_mkauth.php', '🗄️ Backup para MK-Auth'],
            ['importar.php', '🛠️ Correção de Cadastros'],
            ['backup.php?t=smtp', '📧 Servidor de E-mail (p/ envio de backup)'],
            ['erp.php?p=config&t=migracao', '🔁 Migração (backup importado ou outro ERP)'],
        ], ws_pode_infra() ? [   /* atalho repetido do grupo Servidores: some junto, pelo mesmo motivo */
            ['diag.php', '🩺 Diagnóstico do servidor'],
            ['comandos.php', '⌨️ Comandos WellSystem'],
            ['diagnostico_olt.php', '🔎 Diagnóstico da OLT'],
        ] : [])],
        ['label' => 'Provedor', 'sections' => [
            'Gerenciar' => [
                ['provedor.php?p=dados', '🏢 Dados do provedor'],
                ['integracoes.php', '🔌 Integrações'],
                ['provedor.php?p=recursos', '⚙️ Recursos do sistema'],
                ['menu_servidor.php', '🖥️ Menu do servidor'],
                ['terminal.php', '💻 Webterminal (shell)'],
                ['central.php', '📺 Central do assinante'],
            ],
            'Config / Logs' => [
                ['erp.php?p=config&t=geral', '🎨 Geral · Marca · Operadores'],
                ['erp.php?p=config&t=seguranca', '🔐 Segurança / 2FA'],
                ['docs.php', '📖 Ajuda / Docs'],
            ],
        ]],
        ['label' => 'Cadastros', 'sections' => [
            'Localização' => [
                ['erp.php?p=cadastros&t=cidades', '🏙️ Cidades'],
                ['erp.php?p=cadastros&t=bairros', '🏘️ Bairros'],
                ['erp.php?p=cadastros&t=ramais', '🏢 Ramais'],
                ['zonas.php', '🗺️ Zonas'],
            ],
            'Comercial' => [
                ['erp.php?p=planos', '📶 Planos'],
                ['provedor.php?p=bancos', '🏦 Contas / Bancos / PIX'],
                ['comercial.php', '📈 Funil de vendas'],
            ],
            'Equipamentos' => [
                ['erp.php?p=cadastros&t=equipamentos', '📦 Equipamentos (comodato)'],
            ],
        ]],
        /* Níveis 1 e 2 veem só o PAINEL (leitura/derrubada). Concentradores, NAS, Diagnóstico e
           Comandos são configuração de infraestrutura — nível 3 e root (ver ws_pode_infra). O item
           some do menu E a tela recusa direto, senão bastaria digitar o endereço. */
        ['label' => 'Servidores', 'items' => array_merge(
            [
                ['servidores.php', '🖥️ Painel dos Concentradores', '_blank'],
                ['trafego_servidores.php', '📈 Tráfego dos Servidores (ao vivo)'],
                ['saude.php', '🩺 Saúde do sistema'],
                ['mk_monitor.php', '📡 Monitor de concentrador (log/ping)', '_blank'],
            ],
            ws_pode_infra() ? [
                ['radius.php?p=conc', '🖧 Concentradores'],
                ['radius.php?p=nas', '🖧 NAS'],
                ['diag.php', '🩺 Diagnóstico do servidor'],
                ['comandos.php', '⌨️ Comandos WellSystem'],
                ['diagnostico_olt.php', '🔎 Diagnóstico da OLT'],
                ['acs.php', '📡 ACS / TR-069 (ONUs)'],
            ] : []
        )],
        ['label' => 'Estoque', 'href' => 'estoque.php'],
        ['label' => 'Manutenção', 'href' => 'manutencao.php'],
        ['label' => 'Opções', 'items' => array_merge([
            ['atendimento.php', 'Atendimento (WhatsApp e robô)'],
            ['atualizar.php', 'Atualizações do sistema'],
            ['mensagens.php?t=servidor', 'Servidor de WhatsApp'],
            ['documentos.php?p=logo', 'Documentos do sistema'],
        ], ws_pode_configurar() ? [['recupera_deletado.php', '♻️ Recupera Deletado']] : [])],
    ];
    $grupos = ws_edicao_filtrar_menu($grupos);   // edição: tira o que o plano/pacote não tem (OLT, Fiscal, ERP)
    /* QUEM SOME DO MENU, POR NOME — e não por posição.
     *
     * Isto era `unset($grupos[8])` com o comentário "Cadastros". Só que a posição 8 é o grupo
     * **Provedor**: quem não podia configurar perdia o menu errado, e continuava vendo Cadastros.
     * Índice fixo só funciona enquanto ninguém insere um menu no meio — e foi exatamente o que
     * aconteceu ao dividir o Financeiro. Tirar pelo rótulo não tem esse problema.
     *
     * O que estas duas linhas fazem é só ESCONDER: quem entrar pela URL continua barrado pelas
     * telas (backup.php responde 403, e o cadastro exige nível 3+). Esconder é para não convidar
     * um operador limitado a clicar num link que vai dar acesso negado. */
    $tirarMenu = function (array $labels) use (&$grupos) {
        foreach ($grupos as $i => $g) if (in_array($g['label'] ?? '', $labels, true)) unset($grupos[$i]);
    };
    /* Cadastros fica no menu de TODO MUNDO: cidade, bairro, ramal, zona, equipamento e funil são
       trabalho do dia a dia. Plano e Conta/Banco/PIX continuam na lista, porém abrem travados em
       leitura para níveis 1 e 2 (ws_pode_editar_preco). */
    if (!ws_eh_root())         $tirarMenu(['Backup']);      // Backup = só admin/root (mesma regra do backup.php)

    // Casa a URL atual com um link do menu (mesmo arquivo + mesmos parâmetros).
    $arqAtual = basename(parse_url($_SERVER['REQUEST_URI'] ?? 'erp.php', PHP_URL_PATH) ?: 'erp.php');
    parse_str((string)parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY), $qsAtual);
    /* QUANTOS PARÂMETROS DO LINK CASARAM com a URL atual (-1 = não casou).
     *
     * O critério de "item ativo" é subconjunto: o link acende quando todos os parâmetros DELE
     * aparecem na URL aberta. Só que um subconjunto menor também é subconjunto — estando em
     * "Instalações abertas" (p, tipo, status), o item "Buscar instalação" (p, tipo) também casa,
     * e o menu acendia DOIS itens ao mesmo tempo, como se houvesse duas telas abertas.
     * Medindo o casamento em vez de responder sim/não, dá para acender só o mais específico. */
    $peso = function (string $href) use ($arqAtual, $qsAtual): int {
        $partes = explode('?', $href, 2);
        if (basename($partes[0]) !== $arqAtual) return -1;
        if (count($partes) < 2) return $qsAtual === [] ? 0 : -1;
        parse_str($partes[1], $qsLink);
        foreach ($qsLink as $k => $v) if (($qsAtual[$k] ?? null) !== $v) return -1;
        return count($qsLink);
    };
    // Mesmo significado de antes ("este link corresponde à página atual") — usado pelo destaque do
    // GRUPO e pelo título da página, onde acender por aproximação é o certo.
    $bate = static fn(string $href): bool => $peso($href) >= 0;

    /* O maior casamento do menu inteiro. Calculado aqui, uma vez, porque um item só sabe se é o
     * mais específico depois que todos foram medidos. $grupos já vem filtrado por permissão, então
     * item escondido não influencia. */
    $pesoMax = -1;
    foreach ($grupos as $g) {
        if (isset($g['href'])) { $pesoMax = max($pesoMax, $peso($g['href'])); continue; }
        foreach (($g['sections'] ?? ['' => ($g['items'] ?? [])]) as $itens) {
            foreach ((array)$itens as $it) if (!isset($it[2])) $pesoMax = max($pesoMax, $peso($it[0]));
        }
    }
    /** O item que fica ACESO: casou e é o casamento mais específico do menu. */
    $aceso = static fn(string $href): bool => $peso($href) >= 0 && $peso($href) === $pesoMax;

    echo '<nav class="ws-nav">';
    foreach ($grupos as $g) {
        if (isset($g['href'])) {
            echo '<a href="' . h($g['href']) . '" class="' . ($aceso($g['href']) ? 'on' : '') . '">' . h($g['label']) . '</a>';
            continue;
        }
        // Se algum item deste grupo bate com a página atual, o RÓTULO do grupo também fica destacado
        // (com a cor do tema) — assim dá pra ver de longe em qual área do menu você está, mesmo com
        // o submenu fechado. Ex.: abrindo "Financeiro > Títulos a receber", o botão "Financeiro" acende.
        $itensDoGrupo = $g['sections'] ?? ['' => $g['items']];
        $grupoAtivo = false;
        foreach ($itensDoGrupo as $itens) foreach ($itens as $it) if (!isset($it[2]) && $bate($it[0])) $grupoAtivo = true;
        echo '<div class="ws-grp' . ($grupoAtivo ? ' ativo' : '') . '">';
        echo '<button type="button" class="ws-grp-lbl' . ($grupoAtivo ? ' on' : '') . '">' . h($g['label']) . '</button>';
        if (isset($g['sections'])) {
            echo '<div class="ws-sub ws-mega">';
            foreach ($g['sections'] as $titulo => $itens) {
                echo '<div class="ws-mega-col"><div class="ws-mega-titulo">' . h($titulo) . '</div>';
                foreach ($itens as $it) {
                    $alvo = isset($it[2]) ? ' target="' . h($it[2]) . '"' : '';
                    $on = (!isset($it[2]) && $aceso($it[0])) ? ' on' : '';
                    echo '<a href="' . h($it[0]) . '"' . $alvo . ' class="' . trim($on) . '">' . h($it[1]) . '</a>';
                }
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<div class="ws-sub">';
            foreach ($g['items'] as $it) {
                $alvo = isset($it[2]) ? ' target="' . h($it[2]) . '"' : '';
                $on = (!isset($it[2]) && $aceso($it[0])) ? ' on' : '';
                echo '<a href="' . h($it[0]) . '"' . $alvo . ' class="' . trim($on) . '">' . h($it[1]) . '</a>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    echo '</nav>';
    echo '<span class="ws-nav-right"></span>';
    // Barra do nome da página/menu atual — fica ABAIXO do cabeçalho e ACIMA do conteúdo.
    // Usa o rótulo do GRUPO ativo (ex.: "Financeiro"); se a página bater com o link de topo
    // (ex.: "Painel"), usa esse. Sempre mostra alguma coisa (fallback = "Painel").
    $tituloPagina = 'Painel';
    foreach ($grupos as $g) {
        if (isset($g['href']) && $bate($g['href'])) { $tituloPagina = $g['label']; break; }
        if (isset($g['sections']) || isset($g['items'])) {
            $itensDoGrupo = $g['sections'] ?? ['' => $g['items']];
            foreach ($itensDoGrupo as $itens) foreach ($itens as $it) {
                if (!isset($it[2]) && $bate($it[0])) { $tituloPagina = $g['label']; break 3; }
            }
        }
    }
    echo '<div class="ws-titulo-pagina"><span class="ws-pagina-atual" title="Menu atual">' . h($tituloPagina) . '</span></div>';
    // REGRA "tudo no código, sem terminal": quando a pasta cache/ do addon não é gravável, o sistema
    // usa uma pasta temporária PERSISTENTE (/var/tmp) como plano B automático — funciona sozinho, sem
    // pedir nenhum comando de terminal. Por isso NÃO mostramos mais o aviso de permissão aqui.
}

/**
 * Paginação reutilizável (25/50/100/tudo + navegação de páginas).
 * Uso: [$pp,$pg,$lim] = ws_paginar($total); ... SQL com $lim; echo ws_paginacao_html($total,$pp,$pg,$baseUrl);
 */
/**
 * PAGINAÇÃO — dividida em DUAS peças, porque cada uma resolve uma coisa diferente:
 *
 *   ws_paginacao_topo()  -> vai ACIMA da tabela. Traz a contagem e o seletor "por página".
 *                           Ficava lá embaixo junto com as setas, então para trocar de 25 para
 *                           100 o operador tinha que rolar a lista inteira até o fim.
 *   ws_paginacao_html()  -> vai ABAIXO da tabela. Só navegação, com números de página.
 *
 * O rodapé antigo tinha apenas "‹ anterior · página 3 de 40 · próxima ›": para chegar na página
 * 20 eram 17 cliques. Agora mostra a primeira, a última, uma janela ao redor da atual e reticências
 * no que foi omitido — e ‹‹ / ›› para os extremos.
 *
 * Ambas preservam os filtros da tela (o array $extra vira campos ocultos / query string), então
 * mudar de página não perde busca nem filtro.
 */
/* =====================================================================================
 * BUSCA DOS CAMPOS DE PESQUISA — agora também pelo INÍCIO das palavras.
 *
 * A FUNÇÃO DO CAMPO NÃO MUDA: ele continua filtrando exatamente o que filtrava, nas
 * mesmas colunas, com as mesmas regras de permissão e de status. O que muda é só o
 * casamento do texto digitado.
 *
 * ANTES: o texto inteiro ia como um pedaço só -> LIKE '%jose silva%'.
 *        Quem está gravado como "JOSE DA SILVA" NÃO era encontrado, porque entre
 *        "JOSE" e "SILVA" existe um "DA" no meio.
 *
 * AGORA: o texto é quebrado em palavras e CADA palavra precisa aparecer em ALGUMA das
 *        colunas pesquisadas (E entre as palavras, OU entre as colunas). Como o LIKE
 *        usado é '%palavra%', ele casa tanto no meio do texto quanto no começo de
 *        qualquer palavra dele — é daí que sai o "buscar pela inicial":
 *            "jo si"      acha  JOSE DA SILVA
 *            "mar cav"    acha  MARIA CAVALCANTI
 *            "100 mega"   acha  PLANO 100 SUPER MEGA
 *
 * ISTO SÓ ACRESCENTA RESULTADO, NUNCA TIRA. Prova: se o LIKE antigo '%a b%' casava com
 * um registro, então esse registro contém "a b", logo contém "a" e contém "b", logo
 * casa nas duas condições novas. Tudo que era achado antes continua sendo achado.
 *
 * Onde NÃO se usa: comandos em massa da Manutenção. Lá o filtro escolhe quem vai ser
 * ALTERADO em lote; alargar o casamento pegaria cliente que o operador não pediu.
 */

/**
 * Colunas que a tabela REALMENTE tem, em minúsculas.
 *
 * A busca "Tudo" procura em muita coluna, e nem toda instalação tem todas: coluna nova entra por
 * migração, e um banco que ainda não migrou faria a consulta inteira estourar com "Unknown column"
 * — ou seja, a tela de clientes pararia de abrir por causa de um campo de busca. Perguntar ao
 * banco o que existe, uma vez por requisição, é mais barato que um erro desses.
 */
function ws_colunas_tabela(PDO $db, string $tabela): array {
    static $cache = [];
    if (isset($cache[$tabela])) return $cache[$tabela];
    $cols = [];
    try {
        $st = $db->prepare("SELECT column_name FROM information_schema.columns
                            WHERE table_schema = DATABASE() AND table_name = ?");
        $st->execute([$tabela]);
        foreach ($st->fetchAll(PDO::FETCH_NUM) as $r) $cols[] = strtolower((string)$r[0]);
    } catch (Throwable $e) { /* sem catálogo, devolve vazio e quem chama usa só o essencial */ }
    return $cache[$tabela] = $cols;
}

/** Das colunas desejadas, devolve só as que existem — já prefixadas ("c.nome", "ct.zona"). */
function ws_colunas_existentes(PDO $db, string $tabela, string $alias, array $desejadas): array {
    $tem = ws_colunas_tabela($db, $tabela);
    if (!$tem) return [];                      // não deu para consultar: quem chama decide o mínimo
    $ok = [];
    foreach ($desejadas as $c) if (in_array(strtolower($c), $tem, true)) $ok[] = $alias . '.' . $c;
    return $ok;
}

/** Quebra o que foi digitado em palavras (no máximo $max, pra consulta não virar um monstro). */
function ws_busca_palavras(string $termo, int $max = 6): array {
    $termo = trim(preg_replace('/\s+/u', ' ', $termo));
    if ($termo === '') return [];
    $p = array_values(array_filter(explode(' ', $termo), fn($x) => $x !== ''));
    return count($p) > $max ? array_slice($p, 0, $max) : $p;
}

/**
 * Condição SQL pronta para colunas simples.
 *
 * @param array  $cols    expressões de coluna (ex.: ['c.nome','ct.login_pppoe'])
 * @param string $termo   o que o operador digitou
 * @param array  $par     ARRAY DE PARÂMETROS DA CONSULTA — os valores entram aqui, na ordem
 * @param array  $colsNum colunas onde a palavra entra só com os dígitos (CPF, telefone, IP…)
 * @return string         ex.: "((c.nome LIKE ?) AND (c.nome LIKE ?))" — ou '' se não houver termo
 */
function ws_busca_cond(array $cols, string $termo, array &$par, array $colsNum = []): string {
    return ws_busca_blocos($termo, function (string $pal) use ($cols, $colsNum) {
        $ors = []; $vals = [];
        foreach ($cols as $c) { $ors[] = "$c LIKE ?"; $vals[] = '%' . $pal . '%'; }
        $num = preg_replace('/\D/', '', $pal);
        if ($num !== '' && $colsNum) foreach ($colsNum as $c) { $ors[] = "$c LIKE ?"; $vals[] = '%' . $num . '%'; }
        return [$ors, $vals];
    }, $par);
}

/**
 * Versão livre: quem chama monta o bloco de UMA palavra e esta função repete o bloco para
 * cada palavra digitada, ligando tudo com AND. Serve para os casos em que a busca não é
 * só coluna — por exemplo quando envolve EXISTS(...) num contrato.
 *
 * @param callable $fn  recebe a palavra, devolve [array $condicoes, array $valores]
 */
function ws_busca_blocos(string $termo, callable $fn, array &$par): string {
    $blocos = [];
    foreach (ws_busca_palavras($termo) as $pal) {
        [$ors, $vals] = $fn($pal);
        if (!$ors) continue;
        $blocos[] = '(' . implode(' OR ', $ors) . ')';
        foreach ($vals as $v) $par[] = $v;
    }
    return $blocos ? '(' . implode(' AND ', $blocos) . ')' : '';
}

/**
 * A BUSCA "TUDO" DA LISTA DE CLIENTES — em dois níveis.
 *
 * O PROBLEMA QUE ISTO RESOLVE: procurar em todas as colunas faz o campo achar qualquer coisa,
 * mas também faz uma palavra comum casar com a base inteira. Digitar "well" devolvia 767 de 775
 * clientes, porque o texto aparece em campo que quase todo contrato tem igual — zona da OLT,
 * pool do concentrador, observação padrão, nome do plano. Uma lista com 767 nomes não é resposta:
 * é a mesma lista de antes, com o trabalho de ter digitado.
 *
 * COMO FICA: a busca acontece primeiro no NÚCLEO — o que identifica uma pessoa ou o acesso dela:
 * nome, documento, contatos, endereço (de cadastro e de instalação), login, IP, serial, ID. Se
 * algum cliente casa aí, é isso que a tela mostra.
 * Só quando o núcleo não devolve NADA a busca se amplia para os campos de apoio (observação,
 * zona, pool, situação, plano, modelo do equipamento, senha da conexão). Ou seja: continua dando
 * para achar pela senha anotada no roteador ou pelo texto da observação — que é o motivo de esses
 * campos estarem na busca —, sem que eles sequestrem o resultado quando o operador procurou um
 * nome.
 *
 * $GLOBALS['ws_busca_ampliou'] fica true quando o segundo nível foi usado, para a tela poder
 * explicar por que o resultado não parece com o que foi digitado.
 *
 * @param array $par  parâmetros da consulta (por referência, na ordem dos "?")
 * @return string     condição SQL pronta, ou '' se não houver o que filtrar
 */
function ws_busca_clientes_cond(PDO $db, string $busca, array &$par): string {
    $GLOBALS['ws_busca_ampliou'] = false;
    $busca = trim($busca);
    if ($busca === '') return '';

    $subC    = static fn($cond) => "EXISTS(SELECT 1 FROM ws_contrato ct WHERE ct.cliente_id=c.id AND $cond)";
    /* Tira a pontuação DENTRO do banco, para comparar com o termo já sem pontuação: o operador
       digita "123.456.789-00" e no banco pode estar "12345678900" — ou o contrário. */
    $semPont = static fn($c) => "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE($c,'.',''),'-',''),'/',''),' ',''),'(',''),')','')";

    // --- NÍVEL 1: O NOME. É o que o operador procura em nove de cada dez buscas.
    $cliNome = ws_colunas_existentes($db, 'ws_cliente', 'c', ['nome', 'nome_resumido']);
    if (!$cliNome) $cliNome = ['c.nome'];

    // --- NÚCLEO: identifica a pessoa ou o acesso dela.
    $cliNucleo = ws_colunas_existentes($db, 'ws_cliente', 'c', [
        'nome', 'nome_resumido', 'cpf_cnpj', 'rg_ie', 'email', 'celular', 'telefone',
        'cep', 'logradouro', 'numero', 'complemento', 'bairro', 'cidade', 'uf',
    ]);
    if (!$cliNucleo) $cliNucleo = ['c.nome', 'c.cpf_cnpj', 'c.email', 'c.logradouro', 'c.bairro', 'c.cidade'];
    $ctNucleo = ws_colunas_existentes($db, 'ws_contrato', 'ct', [
        'login_pppoe', 'login_ipoe', 'ont_id', 'ip_fixo', 'ultimo_ip', 'sn_onu', 'equip_serial', 'equip_mac',
        'inst_cep', 'inst_logradouro', 'inst_numero', 'inst_complemento', 'inst_bairro', 'inst_cidade', 'inst_uf',
    ]);
    if (!$ctNucleo) $ctNucleo = ['ct.login_pppoe', 'ct.ip_fixo', 'ct.sn_onu'];

    // --- APOIO: campos que se repetem entre muitos clientes (é daqui que vinha o falso positivo).
    $cliApoio = ws_colunas_existentes($db, 'ws_cliente', 'c', ['status', 'obs']);
    $ctApoio  = ws_colunas_existentes($db, 'ws_contrato', 'ct', [
        'status', 'obs', 'zona', 'pool', 'vlan', 'senha_pppoe', 'equip_modelo',
    ]);

    $semPontCli = array_values(array_intersect($cliNucleo, ['c.cpf_cnpj', 'c.celular', 'c.telefone', 'c.cep']));
    $semPontCt  = array_values(array_intersect($ctNucleo, ['ct.ip_fixo', 'ct.ultimo_ip', 'ct.equip_mac', 'ct.inst_cep']));

    /* Monta a condição de UM nível: 1 = só o nome · 2 = nome + identificação/acesso ·
       3 = tudo, inclusive os campos de apoio e o nome do plano. Os três passam pelo mesmo
       caminho para não existirem três comportamentos diferentes de busca. */
    $monta = function (int $nivel) use ($subC, $semPont, $cliNome, $cliNucleo, $ctNucleo, $cliApoio, $ctApoio, $semPontCli, $semPontCt) {
        return function (string $pal) use ($nivel, $subC, $semPont, $cliNome, $cliNucleo, $ctNucleo, $cliApoio, $ctApoio, $semPontCli, $semPontCt) {
            $l = "%$pal%";
            $ors = []; $vals = [];
            $amplo   = ($nivel >= 3);
            $colsCli = $nivel === 1 ? $cliNome : ($amplo ? array_merge($cliNucleo, $cliApoio) : $cliNucleo);
            $colsCt  = $nivel === 1 ? []       : ($amplo ? array_merge($ctNucleo, $ctApoio)   : $ctNucleo);
            // No nível do NOME não entram número de cadastro nem comparação sem pontuação: quem
            // digita um nome não está digitando CPF, e "ana 2" não deve trazer o cliente #2.
            if ($nivel === 1) {
                foreach ($colsCli as $c) { $ors[] = "$c LIKE ?"; $vals[] = $l; }
                return [$ors, $vals];
            }

            foreach ($colsCli as $c) { $ors[] = "$c LIKE ?"; $vals[] = $l; }

            /* OS DÍGITOS SÓ VALEM COMO NÚMERO QUANDO A PALAVRA É UM NÚMERO.
             * A comparação sem pontuação e o casamento por ID existem para quem digita documento,
             * telefone, CEP, IP ou o número do cadastro. Aplicando-os a qualquer palavra que
             * contenha dígitos, "senha123" virava "id = 123" e devolvia um cliente que não tem
             * nada a ver com o que foi procurado — e, pior, fazia a busca parar no primeiro nível
             * achando que tinha encontrado alguém. Pontuação de documento/telefone continua
             * valendo: "123.456.789-00" e "(81) 99999-8888" são números para esta regra. */
            $ehNumero = (bool)preg_match('/^[0-9.\-\/() ]+$/', $pal);
            $soNum = $ehNumero ? preg_replace('/\D/', '', $pal) : '';
            $likeN = $soNum !== '' ? "%$soNum%" : null;
            if ($likeN !== null) foreach ($semPontCli as $c) { $ors[] = $semPont($c) . " LIKE ?"; $vals[] = $likeN; }
            // O número do cadastro também é "tudo": digitou 1234, acha o cliente #1234.
            if ($soNum !== '' && (int)$soNum > 0) { $ors[] = "c.id = ?"; $vals[] = (int)$soNum; }

            /* Contrato entra por último no OR — e os valores dele por último em $vals, na MESMA
               ordem dos "?" de dentro do EXISTS. */
            $orsC = []; $valsC = [];
            foreach ($colsCt as $c) {
                // vlan é número: o CAST evita depender da conversão implícita do banco.
                $expr = (substr($c, -5) === '.vlan') ? "CAST($c AS CHAR)" : $c;
                $orsC[] = "$expr LIKE ?"; $valsC[] = $l;
            }
            if ($likeN !== null) foreach ($semPontCt as $c) { $orsC[] = $semPont($c) . " LIKE ?"; $valsC[] = $likeN; }
            if ($soNum !== '' && (int)$soNum > 0) { $orsC[] = "ct.id = ?"; $valsC[] = (int)$soNum; }
            if ($orsC) { $ors[] = $subC('(' . implode(' OR ', $orsC) . ')'); foreach ($valsC as $v) $vals[] = $v; }

            // NOME DO PLANO — mora em outra tabela e é igual para centenas de clientes: só no amplo.
            if ($amplo) {
                $ors[]  = "EXISTS(SELECT 1 FROM ws_contrato ct JOIN ws_plano p ON p.id=ct.plano_id
                                  WHERE ct.cliente_id=c.id AND p.nome LIKE ?)";
                $vals[] = $l;
            }
            return [$ors, $vals];
        };
    };

    /* DESCE UM DEGRAU DE CADA VEZ, e para no primeiro que acha alguém.
     *
     * A pergunta de cada degrau é só "o texto digitado identifica alguém aqui?" — por isso a
     * verificação é um EXISTS, sem os outros filtros da tela (situação, ramal): responder isso
     * custa uma consulta que para no primeiro registro encontrado.
     *
     * Por que o NOME é um degrau sozinho: numa base real o mesmo texto aparece no e-mail de todo
     * mundo (o endereço do próprio provedor), na zona da OLT, no pool do concentrador. Procurar
     * "well" devolvia 712 de 775 clientes — a lista inteira, com o trabalho de ter digitado. */
    foreach ([1, 2, 3] as $nivel) {
        $p = []; $cond = ws_busca_blocos($busca, $monta($nivel), $p);
        if ($cond === '') continue;
        $ultimo = ($nivel === 3);
        if (!$ultimo) {
            try {
                $st = $db->prepare("SELECT EXISTS(SELECT 1 FROM ws_cliente c WHERE $cond LIMIT 1)");
                $st->execute($p);
                if ((int)$st->fetchColumn() === 0) continue;   // ninguém aqui: tenta o degrau seguinte
            } catch (Throwable $e) {
                /* A consulta do degrau falhou (coluna inesperada nesta instalação). Usa este
                 * mesmo nível: é o mais próximo do que o operador pediu, e é melhor do que
                 * cair no nível mais amplo, que é justamente o que traz a base inteira. */
            }
        }
        if ($nivel >= 3) $GLOBALS['ws_busca_ampliou'] = true;
        foreach ($p as $v) $par[] = $v;
        return $cond;
    }
    return '';
}

function ws_paginar(int $total, int $padrao = 50): array {
    $padrao = ws_recursos()['registros_pagina'];   // Recursos do sistema → Tema → Registros por página
    $ppOpts = [20, 25, 50, 100, 0];
    $ppReq = (int)($_GET['pp'] ?? $padrao); $pp = in_array($ppReq, $ppOpts, true) ? $ppReq : $padrao;
    $pg = max(1, (int)($_GET['pg'] ?? 1));
    $lim = $pp > 0 ? " LIMIT $pp OFFSET " . (($pg - 1) * $pp) : "";
    return [$pp, $pg, $lim];
}

/**
 * Barra de topo: quantos registros, qual fatia está na tela e o seletor "por página".
 * @param array $extra filtros da tela a preservar (ex.: ['p'=>'usuarios','q'=>$busca])
 */
function ws_paginacao_topo(int $total, int $pp, int $pg, array $extra = [], array $opcoes = [20, 50, 100, 0]): string {
    $de  = $total === 0 ? 0 : (($pg - 1) * max(1, $pp) + 1);
    $ate = $pp > 0 ? min($total, $pg * $pp) : $total;

    $out  = '<div class="ws-pag-topo">';
    $out .= '<span class="ws-pag-tot"><b>' . number_format($total, 0, ',', '.') . '</b> registro(s)';
    if ($pp > 0 && $total > 0) $out .= ' <span class="ws-pag-fatia">· mostrando ' . $de . '–' . $ate . '</span>';
    $out .= '</span>';

    $out .= '<form method="get" class="ws-pag-form">';
    foreach ($extra as $k => $v) $out .= '<input type="hidden" name="' . h($k) . '" value="' . h($v) . '">';
    $out .= '<label class="ws-pag-lbl">por página</label>';
    $out .= '<div class="ws-pag-pills" role="group" aria-label="Registros por página">';
    foreach ($opcoes as $o) {
        $sel = ($pp === $o) ? ' ativo' : '';
        $qs  = http_build_query(array_merge($extra, ['pp' => $o, 'pg' => 1]));
        $out .= '<a class="ws-pag-pill' . $sel . '" href="?' . h($qs) . '"'
              . ($sel ? ' aria-current="true"' : '') . '>' . ($o ?: 'Todos') . '</a>';
    }
    $out .= '</div></form></div>';
    return $out;
}

/** Paginador do rodapé: primeira, última, janela ao redor da atual e reticências. */
function ws_paginacao_html(int $total, int $pp, int $pg, array $extra = []): string {
    if ($pp <= 0) return '';                               // "Todos" não pagina
    $paginas = max(1, (int)ceil($total / $pp));
    if ($paginas <= 1) return '';

    $url = function (int $n) use ($extra, $pp) {
        return '?' . h(http_build_query(array_merge($extra, ['pg' => $n, 'pp' => $pp])));
    };
    $btn = function (int $n, string $rot, string $titulo, bool $desativado = false, bool $ativo = false) use ($url) {
        if ($desativado) return '<span class="ws-pag-btn off" aria-hidden="true">' . $rot . '</span>';
        return '<a class="ws-pag-btn' . ($ativo ? ' ativo' : '') . '" href="' . $url($n) . '" title="' . h($titulo) . '"'
             . ($ativo ? ' aria-current="page"' : '') . '>' . $rot . '</a>';
    };

    // Janela de 2 páginas para cada lado da atual — suficiente para navegar sem poluir.
    $ini = max(1, $pg - 2);
    $fim = min($paginas, $pg + 2);

    $out  = '<nav class="ws-pag" aria-label="Paginação">';
    $out .= $btn(1, '&laquo;', 'Primeira página', $pg <= 1);
    $out .= $btn($pg - 1, '&lsaquo;', 'Página anterior', $pg <= 1);

    if ($ini > 1) {
        $out .= $btn(1, '1', 'Página 1', false, $pg === 1);
        if ($ini > 2) $out .= '<span class="ws-pag-gap">…</span>';
    }
    for ($i = $ini; $i <= $fim; $i++) $out .= $btn($i, (string)$i, "Página $i", false, $i === $pg);
    if ($fim < $paginas) {
        if ($fim < $paginas - 1) $out .= '<span class="ws-pag-gap">…</span>';
        $out .= $btn($paginas, (string)$paginas, "Página $paginas", false, $pg === $paginas);
    }

    $out .= $btn($pg + 1, '&rsaquo;', 'Próxima página', $pg >= $paginas);
    $out .= $btn($paginas, '&raquo;', 'Última página', $pg >= $paginas);
    $out .= '<span class="ws-pag-info">página <b>' . $pg . '</b> de ' . $paginas . '</span>';
    $out .= '</nav>';
    return $out;
}

/** Normaliza um nome para comparar duplicidade: maiúsculo, SEM acento, só letras/números/espaço,
 *  espaços únicos. Ex.: "Nazaré da Mata" e "NAZARE DA  MATA" viram a MESMA chave. */
function ws_nome_norm(string $s): string {
    $s = trim($s);
    $t = @iconv('UTF-8', 'ASCII//TRANSLIT', $s); if ($t !== false && $t !== '') $s = $t;
    $s = preg_replace('/[^A-Za-z0-9 ]/', ' ', $s);
    return mb_strtoupper(trim(preg_replace('/\s+/', ' ', $s)), 'UTF-8');
}
/** Se já existir na tabela um nome DUPLICADO NORMALIZADO de $nome, devolve o nome JÁ cadastrado
 *  (o "correto" que fica); senão devolve ''. Usado para bloquear cidade/bairro/zona/rua repetida
 *  mesmo com grafia/aconto diferente. $escopo filtra (ex.: ['cidade_id'=>5]); $idExcluir ignora o
 *  próprio registro na edição. */
function ws_dup_nome(PDO $db, string $tabela, string $nome, int $idExcluir = 0, array $escopo = []): string {
    $alvo = ws_nome_norm($nome);
    if ($alvo === '') return '';
    $where = 'id<>?'; $par = [$idExcluir];
    foreach ($escopo as $col => $val) {
        if ($val === null) { $where .= " AND `$col` IS NULL"; }
        else { $where .= " AND `$col`=?"; $par[] = $val; }
    }
    try { $st = $db->prepare("SELECT nome FROM `$tabela` WHERE $where"); $st->execute($par); }
    catch (Throwable $e) { return ''; }
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) if (ws_nome_norm((string)$n) === $alvo) return (string)$n;
    return '';
}

/** Host atual normalizado (domínio/IP sem porta, minúsculo). */
function ws_host_atual(): string {
    return strtolower(trim(explode(':', (string)($_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'cli')), 2)[0]));
}
/** Assinatura da ativação (HMAC com o segredo da licença). */
function ws_ativacao_assinatura(string $host): string {
    $seg = (defined('WS_LICENCA_SEGREDO') && WS_LICENCA_SEGREDO !== '') ? WS_LICENCA_SEGREDO : 'wellsystem-segredo-padrao';
    return hash_hmac('sha256', $host, $seg);
}

/* =====================================================================================================
 * ATIVAÇÃO POR SERVIDOR + CÓPIA SEGURA
 *
 * ANTES: a ativação valia por ENDEREÇO e morava só em cache/ativacao.json. Cada domínio/IP novo pedia a
 * senha de novo, e qualquer coisa que apagasse a cache/ (limpeza de pasta, addon recriado pelo painel,
 * reinstalação copiando os arquivos) derrubava a ativação em todos os endereços de uma vez.
 *
 * AGORA:
 *  1. A senha é digitada UMA vez e vale para QUALQUER endereço do mesmo servidor (domínio do ERP, da
 *     central, IP interno, IP público). A assinatura é HMAC("servidor|<id da máquina>", segredo da
 *     licença). Copiar a pasta para OUTRO servidor continua pedindo a senha: lá o id é outro.
 *  2. O registro tem cópias fora da pasta (/var/lib/wellsystem e /var/tmp), como a configuração do
 *     banco. Perdeu a cache/? A ativação volta sozinha da cópia no próximo acesso.
 *  3. Instalação ativada no formato antigo (por endereço) continua valendo e, no primeiro acesso por
 *     um endereço já ativado, passa a valer para o servidor inteiro — ninguém precisa reativar.
 *
 * ID DO SERVIDOR: /etc/machine-id (único por instalação do Linux, legível por qualquer usuário). Em
 * container (onde o machine-id vem da imagem e seria igual para todos) ou quando o arquivo não pode ser
 * lido, usa um id aleatório gerado uma vez. Fora de container esse id fica SÓ nas cópias externas
 * (/var/lib, /var/tmp) — nunca dentro da pasta, senão copiar a pasta levaria a ativação junto. No
 * Docker fica também na cache/, que é um volume persistente daquele container.
 * Observação: VM clonada de outra (template) herda o machine-id e, portanto, a ativação.
 * ===================================================================================================== */

/** O PHP está rodando dentro de um container? */
function ws_em_container(): bool {
    static $r = null; if ($r !== null) return $r;
    if (@is_file('/.dockerenv') || @is_file('/run/.containerenv')) return $r = true;
    $cg = (string)@file_get_contents('/proc/1/cgroup');
    return $r = (bool)preg_match('/docker|containerd|kubepods|libpod/', $cg);
}

/** Todos os lugares onde um registro de licença ($nome = ativacao | licenca | servidor_id) pode estar. */
function ws_ativacao_arquivos(string $nome, bool $dentroDaPasta = true): array {
    $h = substr(md5(__DIR__), 0, 10);
    $lista = [];
    if ($dentroDaPasta) { $lista[] = WS_CACHE . "/{$nome}.json"; $lista[] = __DIR__ . "/cache/{$nome}.json"; }
    $lista[] = "/var/lib/wellsystem/wellsystem_{$nome}_{$h}.json";   // sobrevive a reboot e a PrivateTmp
    $lista[] = "/var/tmp/wellsystem_{$nome}_{$h}.json";              // aceito pelo AppArmor do MK-Auth
    return array_values(array_unique($lista));
}
/** Lê um registro: devolve [conteúdo, arquivo] de cada cópia válida encontrada. */
function ws_ativacao_copias(string $nome, bool $dentroDaPasta = true): array {
    $out = [];
    foreach (ws_ativacao_arquivos($nome, $dentroDaPasta) as $arq) {
        if (!@is_file($arq)) continue;
        $j = json_decode((string)@file_get_contents($arq), true);
        if (is_array($j) && $j) $out[] = [$j, $arq];
    }
    return $out;
}
/** Primeira cópia válida de um registro (ou []). */
function ws_ativacao_ler(string $nome, bool $dentroDaPasta = true): array {
    $c = ws_ativacao_copias($nome, $dentroDaPasta);
    return $c ? $c[0][0] : [];
}
/** Grava um registro em todos os lugares. /var/lib/wellsystem só existe se o instalador a criou.
 *  Devolve true se ao menos uma cópia foi gravada. Com $soFaltando, não reescreve o que já existe. */
function ws_ativacao_gravar(string $nome, array $j, bool $dentroDaPasta = true, bool $soFaltando = false): bool {
    $txt = json_encode($j, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $algum = false;
    foreach (ws_ativacao_arquivos($nome, $dentroDaPasta) as $arq) {
        $dir = dirname($arq);
        if (!@is_dir($dir)) { if (strpos($dir, '/var/lib/') === 0 || !@mkdir($dir, 0775, true)) continue; }
        if ($soFaltando && @is_file($arq)) { $algum = true; continue; }
        if (@file_put_contents($arq, $txt) !== false) { @chmod($arq, 0640); $algum = true; }
    }
    return $algum;
}

/** Identidade DESTE servidor (ver o comentário acima). */
function ws_servidor_id(): string {
    static $id = null; if ($id !== null) return $id;
    $container = ws_em_container();
    if (!$container) {
        foreach (['/etc/machine-id', '/var/lib/dbus/machine-id'] as $f) {
            $v = strtolower(trim((string)@file_get_contents($f)));
            if (preg_match('/^[0-9a-f]{32}$/', $v)) return $id = 'm:' . $v;
        }
    }
    // Container, ou machine-id ilegível: id aleatório gerado uma vez. Fora de container, só fora da pasta.
    foreach (ws_ativacao_copias('servidor_id', $container) as [$j]) {
        if (!empty($j['id']) && preg_match('/^[0-9a-f]{32}$/', (string)$j['id'])) {
            ws_ativacao_gravar('servidor_id', $j, $container, true);   // repõe cópia que tenha sumido
            return $id = 'r:' . $j['id'];
        }
    }
    $novo = ['id' => bin2hex(random_bytes(16)), 'em' => date('c')];
    ws_ativacao_gravar('servidor_id', $novo, $container);
    return $id = 'r:' . $novo['id'];
}
/** Código curto deste servidor (aparece na tela de ativação). Quem quiser uma chave PRESA a este servidor pede ao fornecedor informando este código. */
function ws_servidor_codigo(): string {
    $h = strtoupper(substr(hash('sha256', 'wsid|' . ws_servidor_id()), 0, 12));
    return implode('-', str_split($h, 4));
}
/** Confere uma CHAVE DE ATIVAÇÃO assinada ("WS1.<dados>.<assinatura>"). Devolve os dados da licença (n = empresa, i = id, t = emissão,
 *  s = código do servidor, quando a chave é presa a um servidor) ou null se a assinatura não bate / a chave é de outro servidor. */
function ws_chave_verificar(string $chave): ?array {
    $chave = trim(preg_replace('/\s+/', '', $chave));
    if (strpos($chave, 'WS1.') !== 0 || !function_exists('sodium_crypto_sign_verify_detached')) return null;
    $p = explode('.', $chave);
    if (count($p) !== 3) return null;
    $d = fn($s) => base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
    $dados = $d($p[1]); $sig = $d($p[2]); $pub = base64_decode((string)(defined('WS_LICENCA_PUBKEY') ? WS_LICENCA_PUBKEY : ''), true);
    if ($dados === false || $sig === false || $pub === false || strlen($sig) !== 64 || strlen($pub) !== 32) return null;
    try { if (!sodium_crypto_sign_verify_detached($sig, $dados, $pub)) return null; } catch (Throwable $e) { return null; }
    $j = json_decode($dados, true);
    if (!is_array($j) || trim((string)($j['n'] ?? '')) === '') return null;
    if (!empty($j['s']) && strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$j['s'])) !== strtoupper(preg_replace('/[^A-Za-z0-9]/', '', ws_servidor_codigo()))) return null;   // chave presa a OUTRO servidor
    return $j;
}
/** Nome da empresa licenciada neste servidor (vem da chave digitada na ativação), ou ''. */
function ws_licenca_empresa(): string {
    $j = ws_ativacao_ler('ativacao');
    return trim((string)($j['licenca']['n'] ?? ''));
}

/* =====================================================================================================
 * ÁREA DO FORNECEDOR (18/10/2026) — licença, senha de ativação e ambiente DEMO ficam TRAVADOS para o cliente.
 * O cliente é "root" do próprio sistema (criou a senha no primeiro acesso), mas licença/demo são do FORNECEDOR. Para abrir, o
 * fornecedor gera um CÓDIGO DE DESBLOQUEIO no gerador de chaves (mesma chave privada das ativações) informando o "código do servidor"
 * que aparece na tela; o código é assinado, vale só para ESTE servidor e expira (máx. 72 h). Sem sodium/chave pública = fica travado.
 * ===================================================================================================== */
function ws_fornecedor_token_ok(string $token): bool {
    $token = trim(preg_replace('/\s+/', '', $token));
    if (strpos($token, 'WSU1.') !== 0 || !function_exists('sodium_crypto_sign_verify_detached')) return false;
    $p = explode('.', $token); if (count($p) !== 3) return false;
    $d = fn($s) => base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
    $dados = $d($p[1]); $sig = $d($p[2]); $pub = base64_decode((string)(defined('WS_LICENCA_PUBKEY') ? WS_LICENCA_PUBKEY : ''), true);
    if ($dados === false || $sig === false || $pub === false || strlen($sig) !== 64 || strlen($pub) !== 32) return false;
    try { if (!sodium_crypto_sign_verify_detached($sig, $dados, $pub)) return false; } catch (Throwable $e) { return false; }
    $j = json_decode($dados, true);
    if (!is_array($j) || empty($j['u']) || empty($j['e']) || empty($j['t'])) return false;
    $norm = fn($x) => strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$x));
    if ($norm($j['u']) !== $norm(ws_servidor_codigo())) return false;                 // gerado para OUTRO servidor
    if ((int)$j['e'] <= time() || ((int)$j['e'] - (int)$j['t']) > 72 * 3600) return false;   // vencido (ou validade acima de 72 h)
    $_SESSION['ws_fornecedor_ate'] = min((int)$j['e'], time() + 4 * 3600);              // a sessão destrava por até 4 h
    return true;
}
/** A sessão atual está com a área do fornecedor destravada? */
function ws_fornecedor_desbloqueado(): bool {
    return !empty($_SESSION['ws_fornecedor_ate']) && time() < (int)$_SESSION['ws_fornecedor_ate'];
}
function ws_fornecedor_travar(): void { unset($_SESSION['ws_fornecedor_ate']); }

/** Nome CURTO e limpo do provedor para rodapé, assinaturas e modelos (fantasia do cadastro; senão a razão social).
 *  O cadastro vindo do MK-Auth costuma trazer lixo ("WELLNET---BOLETOS---( WELLNET TELECOM )"): usa o que está entre parênteses, tira
 *  segmentos genéricos (boletos, financeiro, cobrança), traços repetidos, espaços duplicados e o sufixo societário (- ME, LTDA, EPP, MEI). */
function ws_provedor_nome_curto(): string {
    static $r = null; if ($r !== null) return $r;
    $p = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true); if (!is_array($p)) $p = [];
    $limpa = function (string $s): string {
        $s = trim(preg_replace('/\s+/u', ' ', $s));
        if (preg_match('/\(([^)]{3,})\)/u', $s, $m)) $s = trim(preg_replace('/\s+/u', ' ', $m[1]));
        else {
            $seg = array_values(array_filter(array_map('trim', preg_split('/\s*-{2,}\s*/u', $s)), fn($x) => $x !== '' && !preg_match('/^(boletos?|financeiro|cobran[cç]a|nf-?e?|nota fiscal)$/iu', $x)));
            if ($seg) $s = $seg[0];
        }
        $s = preg_replace('/\s*[-–]\s*(ME|EPP|MEI|EIRELI)\s*\.?$/iu', '', $s);
        $s = preg_replace('/\s+(LTDA|S\/?A|ME|EPP|MEI|EIRELI)\.?$/iu', '', $s);
        return trim(preg_replace('/\s+/u', ' ', $s), " -–");
    };
    foreach (['fantasia', 'razao'] as $k) { $n = $limpa((string)($p[$k] ?? '')); if ($n !== '') return $r = $n; }
    $a = json_decode((string)@file_get_contents(WS_CACHE . '/atendimento.json'), true);
    return $r = (is_array($a) && trim((string)($a['empresa'] ?? '')) !== '') ? trim((string)$a['empresa']) : 'WellSystem';
}

/** Assinatura que ativa o servidor inteiro. */
function ws_ativacao_assinatura_servidor(): string { return ws_ativacao_assinatura('servidor|' . ws_servidor_id()); }

/** Ativado? Vale a assinatura do SERVIDOR em qualquer cópia; o formato antigo (por endereço) também
 *  vale e é convertido na hora. Encontrou ativação válida: repõe as cópias que faltarem. */
function ws_ativado(): bool {
    $copias = ws_ativacao_copias('ativacao');
    if (!$copias) return false;
    $sigSrv = ws_ativacao_assinatura_servidor();

    foreach ($copias as [$j]) {
        if (!empty($j['servidor']['sig']) && hash_equals($sigSrv, (string)$j['servidor']['sig'])) {
            ws_ativacao_gravar('ativacao', $j, true, true);   // repõe só as cópias que faltarem
            return true;
        }
    }
    // Formato anterior: lista de endereços (ou um endereço só).
    $atual = ws_ativacao_assinatura(ws_host_atual());
    foreach ($copias as [$j]) {
        $ok = !empty($j['sig']) && hash_equals($atual, (string)$j['sig']);
        foreach ((array)($j['hosts'] ?? []) as $h) {
            if (!empty($h['sig']) && hash_equals($atual, (string)$h['sig'])) $ok = true;
        }
        if ($ok) {
            // Servidor já ativado antes desta versão: passa a valer para todos os endereços dele.
            $j['servidor'] = ['sig' => $sigSrv, 'em' => date('c'), 'origem' => 'convertido de ' . ws_host_atual()];
            ws_ativacao_gravar('ativacao', $j);
            return true;
        }
    }
    return false;
}

/** Endereços por onde o sistema já foi ativado (histórico, para a tela de licença). */
function ws_ativacao_hosts(): array {
    $j = ws_ativacao_ler('ativacao'); if (!$j) return [];
    $out = [];
    foreach ((array)($j['hosts'] ?? []) as $h) {
        if (!empty($h['host'])) $out[] = ['host' => (string)$h['host'], 'em' => (string)($h['em'] ?? '')];
    }
    if (!$out && !empty($j['host'])) $out[] = ['host' => (string)$j['host'], 'em' => (string)($j['ativado_em'] ?? '')];
    return $out;
}
/** A ativação é exigida? SIM se: a trava do núcleo está ligada (WS_LICENCA_OBRIGATORIA), OU há senha
 *  em licenca.php, OU o sistema JÁ foi ativado antes (fail-closed: tirar a licença não desliga). */
function ws_ativacao_exigida(): bool {
    if (defined('WS_LICENCA_OBRIGATORIA') && WS_LICENCA_OBRIGATORIA) return true;
    if ((defined('WS_ATIVACAO_HASH') && WS_ATIVACAO_HASH !== '') || (defined('WS_ATIVACAO_TEXTO') && WS_ATIVACAO_TEXTO !== '')) return true;
    return (bool)ws_ativacao_copias('ativacao');
}
/** Store gravável da senha de ativação (trocada pelo painel, sem terminal) — com as mesmas cópias. */
function ws_licenca_store(): array {
    $c = ws_ativacao_copias('licenca');
    if (!$c) return [];
    ws_ativacao_gravar('licenca', $c[0][0], true, true);   // repõe só as cópias que faltarem
    return $c[0][0];
}
/** A senha em vigor foi definida pelo PAINEL? / A recuperação de emergência está desligada? */
function ws_licenca_via_painel(): bool { $s = ws_licenca_store(); return !empty($s['hash']); }
function ws_licenca_sem_recuperacao(): bool { $s = ws_licenca_store(); return !empty($s['hash']) && !empty($s['so_esta']); }
/** Confere a senha de ativação: 1º a senha do PAINEL (se houver), depois licenca.php/texto e o
 *  fallback do núcleo (recuperação). Se o dono marcou "só esta senha", a recuperação é ignorada. */
function ws_ativacao_ok(string $senha): bool {
    $senha = trim($senha); if ($senha === '') return false;
    // CHAVE DE ATIVAÇÃO assinada (instalador único): vale se a assinatura bate; os dados da licença seguem para ws_ativar_marcar()
    if (strpos($senha, 'WS1.') === 0) {
        $lic = ws_chave_verificar($senha);
        if ($lic && function_exists('ws_edicao_chave_aceita') && !ws_edicao_chave_aceita($lic)) { $GLOBALS['ws_chave_erro'] = 'Esta chave é de outra edição do WellSystem. Use a chave da edição deste instalador.'; return false; }
        if ($lic) { $GLOBALS['ws_chave_licenca'] = $lic; $GLOBALS['ws_chave_texto'] = trim(preg_replace('/\s+/', '', $senha)); return true; }
        return false;
    }
    $store = ws_licenca_store();
    if (!empty($store['hash'])) {
        if (password_verify($senha, (string)$store['hash'])) return true;
        if (!empty($store['so_esta'])) return false; // dono desligou a recuperação: só a senha do painel vale
    }
    if (defined('WS_ATIVACAO_HASH') && WS_ATIVACAO_HASH !== '' && password_verify($senha, WS_ATIVACAO_HASH)) return true;
    if (defined('WS_ATIVACAO_TEXTO') && WS_ATIVACAO_TEXTO !== '' && hash_equals((string)WS_ATIVACAO_TEXTO, $senha)) return true;
    if (defined('WS_ATIVACAO_HASH_CORE') && WS_ATIVACAO_HASH_CORE !== '' && password_verify($senha, WS_ATIVACAO_HASH_CORE)) return true;
    return false;
}
/** Troca a senha de ativação PELO PAINEL (sem terminal). Exige a senha ATUAL. Se $soEsta=true, a
 *  nova senha vira a ÚNICA (desliga a recuperação de emergência — cuidado: não esqueça a senha). */
function ws_licenca_trocar_senha(string $atual, string $nova, bool $soEsta = false): array {
    if (!ws_ativacao_ok($atual)) return [false, 'Senha atual incorreta.'];
    $nova = trim($nova);
    if (strlen($nova) < 4) return [false, 'A nova senha precisa ter ao menos 4 caracteres.'];
    if (!is_dir(WS_CACHE)) @mkdir(WS_CACHE, 0775, true);
    $ok = ws_ativacao_gravar('licenca', ['hash' => password_hash($nova, PASSWORD_DEFAULT), 'so_esta' => $soEsta, 'em' => date('c')]);
    if (!$ok) return [false, 'Não consegui gravar (permissão na pasta cache/).'];
    return [true, 'Senha de ativação trocada com sucesso.' . ($soEsta ? ' A recuperação de emergência foi DESLIGADA.' : '')];
}
/** Marca este SERVIDOR como ativado (vale para todos os endereços dele) e guarda as cópias. */
function ws_ativar_marcar(): void {
    $host = ws_host_atual();
    $j = ws_ativacao_ler('ativacao');

    // Histórico de endereços: acrescenta, não substitui (e converte o formato antigo).
    $hosts = [];
    foreach ((array)($j['hosts'] ?? []) as $h) {
        if (!empty($h['host']) && strcasecmp((string)$h['host'], $host) !== 0) $hosts[] = $h;
    }
    if (!empty($j['host']) && !empty($j['sig']) && strcasecmp((string)$j['host'], $host) !== 0) {
        $hosts[] = ['host' => (string)$j['host'], 'sig' => (string)$j['sig'], 'em' => (string)($j['ativado_em'] ?? '')];
    }
    $hosts[] = ['host' => $host, 'sig' => ws_ativacao_assinatura($host), 'em' => date('c')];

    ws_ativacao_gravar('ativacao', [
        'ativado_em' => date('c'),   // último endereço ativado (compatibilidade com telas antigas)
        'host'       => $host,
        'sig'        => ws_ativacao_assinatura($host),
        'hosts'      => $hosts,
        'servidor'   => ['sig' => ws_ativacao_assinatura_servidor(), 'em' => date('c'), 'origem' => $host],
        'licenca'    => (isset($GLOBALS['ws_chave_licenca']) && is_array($GLOBALS['ws_chave_licenca'])) ? $GLOBALS['ws_chave_licenca'] : ((array)($j['licenca'] ?? [])),
        'chave'      => !empty($GLOBALS['ws_chave_texto']) ? (string)$GLOBALS['ws_chave_texto'] : (string)($j['chave'] ?? ''),   // chave assinada (licença online: o servidor confere a assinatura)
    ]);
}

/** Troca a senha do BANCO de dados (do próprio usuário conectado) PELA CAIXA, sem terminal:
 *  roda ALTER USER no MySQL e atualiza a config gravada. Exige a senha de ATIVAÇÃO para autorizar. */
function ws_banco_trocar_senha(PDO $db, string $nova): array {
    $nova = trim($nova);
    if (strlen($nova) < 4) return [false, 'A nova senha do banco precisa ter ao menos 4 caracteres.'];
    $q = $db->quote($nova);
    $mudou = false;
    try { $db->exec("ALTER USER USER() IDENTIFIED BY $q"); $mudou = true; }
    catch (Throwable $e) {
        try { $db->exec("SET PASSWORD = PASSWORD($q)"); $mudou = true; }   // MySQL/MariaDB antigos
        catch (Throwable $e2) { return [false, 'O MySQL não deixou trocar a senha deste usuário: ' . $e->getMessage()]; }
    }
    if ($mudou) {
        $cfg = ws_db_config(); $cfg['pass'] = $nova; ws_db_config_salvar($cfg);
        return [true, 'Senha do banco trocada no MySQL e salva na configuração. As próximas conexões já usam a nova.'];
    }
    return [false, 'Não foi possível trocar a senha do banco.'];
}

/* ======================= AMBIENTE DEMO (sandbox isolado) ======================= */
function ws_demo_arq(): string { return WS_CACHE . '/demo.json'; }
function ws_demo_cfg(): array {
    $f = ws_demo_arq();
    if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) return $j; }
    return ['ativo' => false, 'horas' => 24];
}
function ws_demo_salvar(array $c): void { @file_put_contents(ws_demo_arq(), json_encode($c, JSON_UNESCAPED_UNICODE)); @chmod(ws_demo_arq(), 0640); }
/** O modo DEMO está LIGADO no painel (admin)? Se off, a URL de demo é bloqueada. */
function ws_demo_ligado(): bool { $c = ws_demo_cfg(); return !empty($c['ativo']); }
function ws_demo_horas(): int { $h = (int)(ws_demo_cfg()['horas'] ?? 24); return $h > 0 ? $h : 24; }
/** Nome do banco DEMO (separado da produção). */
function ws_demo_dbname(string $base): string { return $base . '_demo'; }
/** A requisição atual é uma sessão DEMO? (setada por demo.php) */
function ws_em_demo(): bool { return !empty($_SESSION['ws_demo']); }
/** A sessão demo ainda está dentro do prazo (24h)? */
function ws_demo_no_prazo(): bool {
    if (!ws_em_demo()) return false;
    $exp = (int)($_SESSION['ws_demo_expira'] ?? 0);
    return $exp > 0 && time() < $exp;
}

/* ======================= Exclusão em massa (Cadastros) ======================= */
/** Apaga vários registros de UMA tabela de cadastro permitida. Retorna quantos foram removidos.
 *  Só aceita tabelas da lista branca (evita SQL injection no nome da tabela). */
/**
 * Exclusão em massa de cadastro simples.
 *
 * VÍNCULO QUE BLOQUEIA A EXCLUSÃO NÃO PODE VIRAR TELA DE ERRO.
 * Desde que o plano passou a ser protegido por RESTRICT (apagar plano em uso é recusado pelo
 * banco — ver a FK fk_ct_plano no schema), este DELETE pode falhar de propósito. Sem tratamento, a
 * exceção subiria e derrubaria a página: o operador veria uma tela branca onde devia ver
 * "este plano está em uso".
 *
 * Então: apaga um por um, conta o que saiu, e guarda em $_SESSION['ws_flash'] o motivo do que ficou.
 * Apagar em lote num comando só era mais rápido, mas um vínculo em UM item cancelava o lote
 * inteiro — e o operador não tinha como saber qual item tinha travado tudo.
 */
function ws_excluir_massa(PDO $db, string $tabela, array $ids): int {
    $permitidas = ['ws_cidade', 'ws_bairro', 'ws_ramal', 'ws_zona', 'ws_plano', 'ws_estoque', 'ws_banco', 'ws_equipamento'];
    if (!in_array($tabela, $permitidas, true)) return 0;
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    if (!$ids) return 0;

    $st = $db->prepare("DELETE FROM `$tabela` WHERE id=?");
    $apagados = 0; $presos = [];
    foreach ($ids as $id) {
        try { $st->execute([$id]); $apagados += $st->rowCount(); }
        catch (Throwable $e) { $presos[] = $id; }
    }

    if ($presos) {
        // Diz quantos contratos seguram cada plano — é a informação que resolve, não o erro do banco.
        $detalhe = '';
        if ($tabela === 'ws_plano') {
            $linhas = [];
            foreach ($presos as $pid) {
                try {
                    $q = $db->prepare("SELECT p.nome, (SELECT COUNT(*) FROM ws_contrato c WHERE c.plano_id=p.id) n
                                       FROM ws_plano p WHERE p.id=?");
                    $q->execute([$pid]);
                    if ($r = $q->fetch()) $linhas[] = $r['nome'] . ' (' . (int)$r['n'] . ' contrato(s))';
                } catch (Throwable $e) {}
            }
            if ($linhas) $detalhe = ' — ' . implode(', ', $linhas)
                . '. Troque o plano desses contratos, ou apenas DESATIVE o plano (ele deixa de aparecer'
                . ' para novos contratos e o histórico continua correto).';
        }
        $_SESSION['ws_flash'] = '⚠️ ' . count($presos) . ' item(ns) não pôde(puderam) ser excluído(s) por estar(em) em uso' . $detalhe;
    }
    return $apagados;
}
/* ---- Contas pessoais do DEMO (cada visitante cria a sua, com tempo próprio) ---- */
function ws_demo_users_arq(): string { return WS_CACHE . '/demo_users.json'; }   // { login: expira_ts }
function ws_demo_user_expira(string $login): int {
    $f = ws_demo_users_arq(); if (!is_file($f)) return 0;
    $j = json_decode((string)@file_get_contents($f), true);
    return is_array($j) ? (int)($j[$login] ?? 0) : 0;
}
/** Registra a conta demo criada, com validade própria (agora + horas). */
function ws_demo_user_registrar(string $login, int $horas): int {
    $f = ws_demo_users_arq(); $j = is_file($f) ? (json_decode((string)@file_get_contents($f), true) ?: []) : [];
    if (!is_array($j)) $j = [];
    $exp = time() + max(1, $horas) * 3600; $j[$login] = $exp;
    // limpa contas vencidas há mais de 1 dia
    foreach ($j as $k => $t) if (time() - (int)$t > 86400) unset($j[$k]);
    @file_put_contents($f, json_encode($j)); @chmod($f, 0640);
    return $exp;
}

/** Registra a "presença" da sessão demo atual (pra contar usuários no card de Manutenção). */
function ws_demo_ping(): void {
    if (!ws_em_demo()) return;
    $f = WS_CACHE . '/demo_sessions.json';
    $j = is_file($f) ? (json_decode((string)@file_get_contents($f), true) ?: []) : [];
    if (!is_array($j)) $j = [];
    $u = ws_user();
    $j[session_id()] = ['login' => (string)($u['login'] ?? ''), 'nome' => (string)($u['nome'] ?? 'visitante'), 'em' => time()];
    foreach ($j as $k => $v) if (time() - (int)($v['em'] ?? 0) > 900) unset($j[$k]);  // limpa >15 min
    @file_put_contents($f, json_encode($j)); @chmod($f, 0640);
}
/** Sessões demo ATIVAS (vistas nos últimos 5 min): [session_id => ['login','nome','em']]. */
function ws_demo_sessoes(): array {
    $f = WS_CACHE . '/demo_sessions.json';
    $j = is_file($f) ? (json_decode((string)@file_get_contents($f), true) ?: []) : [];
    $out = [];
    if (is_array($j)) foreach ($j as $sid => $v) if (time() - (int)($v['em'] ?? 0) <= 300) $out[$sid] = $v;
    return $out;
}
/** Logins demo ONLINE agora (vistos nos últimos 5 min): [login => true]. */
function ws_demo_logins_online(): array {
    $on = [];
    foreach (ws_demo_sessoes() as $v) { $l = (string)($v['login'] ?? ''); if ($l !== '') $on[$l] = true; }
    return $on;
}
/** Lista as CONTAS demo criadas pelos visitantes: [login => expira_ts] (a conta 'admin' porta não conta). */
function ws_demo_users_lista(): array {
    $f = ws_demo_users_arq(); if (!is_file($f)) return [];
    $j = json_decode((string)@file_get_contents($f), true);
    if (!is_array($j)) return [];
    unset($j['admin']);
    arsort($j);                       // mais recentes/maior validade primeiro
    return $j;
}
/** Existe alguma conta demo AINDA no prazo? Retorna o MAIOR expira_ts entre as ativas (0 se nenhuma).
 *  Serve para NÃO resetar o ambiente enquanto alguém ainda está no tempo dele. */
function ws_demo_conta_ativa_ate(): int {
    $ate = 0; $agora = time();
    foreach (ws_demo_users_lista() as $exp) if ((int)$exp > $agora && (int)$exp > $ate) $ate = (int)$exp;
    return $ate;
}
/** Exclui uma conta demo: remove do controle de tempo E do banco demo (ws_usuario). */
function ws_demo_user_excluir(string $login): bool {
    $login = trim($login); if ($login === '' || $login === 'admin') return false;
    // 1) remove do arquivo de validade
    $f = ws_demo_users_arq();
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true); if (!is_array($j)) $j = [];
        unset($j[$login]);
        @file_put_contents($f, json_encode($j)); @chmod($f, 0640);
    }
    // 2) apaga o usuário no BANCO DEMO (conecta direto no banco demo, sem depender da sessão)
    try {
        $c = ws_db_config(); $demoDb = ws_demo_dbname($c['dbname']);
        $db = new PDO("mysql:host={$c['host']};port={$c['porta']};dbname=$demoDb;charset=utf8mb4", $c['user'], $c['pass'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db->prepare("DELETE FROM ws_usuario WHERE login=? AND login<>'admin'")->execute([$login]);
    } catch (Throwable $e) { /* banco demo pode não existir ainda */ }
    return true;
}

/** Zera o ambiente DEMO apagando as TABELAS do banco demo (não o banco — assim funciona mesmo
 *  onde o usuário só tem privilégio dentro do banco, como no MK-Auth). Recriadas no próximo acesso.
 *  NUNCA toca a produção (só o banco <base>_demo). */
function ws_demo_reset(): array {
    $c = ws_db_config(); $demoDb = ws_demo_dbname($c['dbname']);
    try {
        $db = new PDO("mysql:host={$c['host']};port={$c['porta']};dbname=$demoDb;charset=utf8mb4", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db->exec("SET FOREIGN_KEY_CHECKS=0");
        $tabs = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tabs as $t) { try { $db->exec("DROP TABLE IF EXISTS `$t`"); } catch (Throwable $e) {} }
        $db->exec("SET FOREIGN_KEY_CHECKS=1");
        return [true, "Ambiente demo ($demoDb) zerado (" . count($tabs) . " tabela(s)) — recriado limpo no próximo acesso."];
    } catch (Throwable $e) { return [false, 'Não consegui resetar o demo (crie/permita o banco ' . $demoDb . ' — ver Docs → SEGURANÇA & DEMO): ' . $e->getMessage()]; }
}

/** Saudação por horário (bom dia / boa tarde / boa noite). */
function ws_saudacao(): string {
    $hh = (int)date('G');
    if ($hh < 12) return 'Bom dia';
    if ($hh < 18) return 'Boa tarde';
    return 'Boa noite';
}
/**
 * URL para servir uma imagem interna de uploads/ via img.php — contorna servidores que BLOQUEIAM
 * o acesso DIRETO à pasta uploads/ (403 "sem permissão"). Aceita "uploads/x" ou "x" e preserva ?v=.
 */
function ws_img(string $rel): string {
    $rel = trim($rel);
    if ($rel === '') return '';
    $path = $rel; $qs = '';
    if (($pos = strpos($rel, '?')) !== false) { $qs = substr($rel, $pos + 1); $path = substr($rel, 0, $pos); }
    $path = ltrim($path, '/');
    // SÓ roteia arquivos de uploads/ pelo img.php; assets/, img/ etc. ficam diretos (sem bloqueio).
    if (strpos($path, 'uploads/') !== 0) return $rel;
    $inner = substr($path, 8); // remove "uploads/"
    return 'img.php?p=' . rawurlencode($inner) . ($qs !== '' ? '&' . $qs : '');
}
/** URL da foto do operador (servida por img.php), ou '' se não tiver. */
function ws_operador_foto(int $id): string {
    if ($id <= 0) return '';
    if (function_exists('ws_em_demo') && ws_em_demo()) return '';   // DEMO não usa fotos reais (produção)
    $g = glob(WS_UPLOADS . '/operadores/' . $id . '.*');
    if ($g && is_file($g[0])) return ws_img('uploads/operadores/' . basename($g[0]) . '?v=' . @filemtime($g[0]));
    return '';
}
/** Chip do usuário logado no topo: foto (ou inicial) + nome + ponto "online" + sair.
 *  Usado no lugar do antigo "<nome> · sair" em todas as páginas de operador. */
function ws_user_chip(): string {
    $u = ws_user(); if (!$u) return '';
    $nome = htmlspecialchars((string)($u['nome'] ?? ''), ENT_QUOTES, 'UTF-8');
    $foto = ws_operador_foto((int)($u['id'] ?? 0));
    $ini = htmlspecialchars(mb_strtoupper(mb_substr(trim((string)($u['nome'] ?? '?')), 0, 1)), ENT_QUOTES) ?: '?';
    if ($foto !== '') {
        // Mostra a inicial como base e a foto por cima; se a foto falhar (404), o onerror a remove e a inicial aparece — nunca fica imagem quebrada.
        $img = '<span class="ws-user-foto ws-user-ini" style="position:relative;overflow:hidden">' . $ini
             . '<img src="' . htmlspecialchars($foto, ENT_QUOTES) . '" alt="" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit"></span>';
    } else {
        $img = '<span class="ws-user-foto ws-user-ini">' . $ini . '</span>';
    }
    return '<span class="ws-user-chip">' . $img
         . '<span class="ws-user-nome"><span class="ws-online-dot" title="online"></span>'
         . '<span class="ws-user-saudacao">' . ws_saudacao() . ',</span> ' . $nome . '</span>'
         . ' · <a href="erp.php?sair=1">sair</a></span>';
}

/** Registra a RUA automaticamente ao salvar um endereço, seguindo a regra:
 *  - MESMO CEP não duplica (é a mesma rua) — se o CEP já existe, não cria de novo;
 *  - sem CEP, deduplica por nome normalizado + cidade;
 *  - a MESMA rua PODE existir em ramal/cidade diferente (CEP diferente) — aí cria separada.
 *  Nunca bloqueia o salvamento (silencioso); só alimenta o cadastro de ruas. */
function ws_rua_registrar(PDO $db, string $nome, ?string $cep, ?string $cidade, ?int $ramalId): void {
    $nome = trim($nome); if ($nome === '') return;
    $cep = $cep !== null ? preg_replace('/\D/', '', $cep) : '';
    $cidade = ($cidade !== null && trim($cidade) !== '') ? mb_strtoupper(trim($cidade), 'UTF-8') : null;
    try {
        if ($cep !== '') {
            $st = $db->prepare("SELECT COUNT(*) FROM ws_rua WHERE cep=?"); $st->execute([$cep]);
            if ((int)$st->fetchColumn() > 0) return; // esse CEP já tem rua registrada
        } else {
            $alvo = ws_nome_norm($nome);
            $st = $db->prepare("SELECT nome FROM ws_rua WHERE " . ($cidade !== null ? "cidade=?" : "cidade IS NULL"));
            $st->execute($cidade !== null ? [$cidade] : []);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) if (ws_nome_norm((string)$n) === $alvo) return;
        }
        $db->prepare("INSERT INTO ws_rua (nome,cep,cidade,ramal_id,ativo) VALUES (?,?,?,?,1)")
           ->execute([mb_substr(mb_strtoupper($nome, 'UTF-8'), 0, 160), $cep ?: null, $cidade, $ramalId]);
    } catch (Throwable $e) { /* registro automático nunca atrapalha o salvamento */ }
}

/**
 * Chamada no LOGIN: registra o acesso e guarda na sessão o que a barra de status mostra.
 *
 * Existe para que a barra do topo não custe consulta nenhuma por página. Tudo que ela precisa e que
 * viria do banco — o acesso anterior e a contagem de operadores — é resolvido aqui, uma vez, no
 * único momento em que uma consulta a mais não se nota: o login.
 *
 * Chamada dos TRÊS pontos de entrada (senha, 2FA e primeiro acesso). Um esquecido significaria um
 * operador cuja barra nunca mostra o acesso anterior — e é justamente o acesso anterior que revela
 * uso indevido da conta.
 */
function ws_login_registrar(int $usuarioId): void {
    if (function_exists('ws_registrar_acesso')) ws_registrar_acesso($usuarioId);
    // Marca a presença já no login, para o próprio operador contar na sessão logo abaixo.
    if (function_exists('ws_marcar_presenca')) { unset($_SESSION['ws_presenca_em']); ws_marcar_presenca(); }
    try {
        $n = function_exists('ws_operadores_online') ? count(ws_operadores_online()) : 1;
        $_SESSION['ws_sessoes_login'] = max(1, $n);
    } catch (Throwable $e) { $_SESSION['ws_sessoes_login'] = 1; }
}

/* =================================================================================================
 * TELA TRAVADA POR INATIVIDADE (padrão: 2 horas)
 *
 * Computador que fica aberto na recepção é a porta mais fácil que existe para a base inteira: basta
 * alguém sentar. Aqui, passado o tempo sem NENHUMA tela aberta, o sistema tranca e pede a senha de
 * novo — e, ao destravar, volta EXATAMENTE para a tela em que a pessoa estava, sem perder o caminho.
 *
 * O relógio da inatividade conta só as telas de verdade (navegação), não as consultas de fundo que
 * a página faz sozinha — senão uma aba esquecida aberta manteria a sessão viva para sempre.
 * Enquanto está trancado, o operador também não aparece mais como "online": ele não está usando.
 *
 * Tempo ajustável em Provedor → Recursos do sistema ("Travar a tela após"); 0 desliga.
 * ================================================================================================= */
function ws_sessao_minutos_trava(): int {
    $m = 120;
    if (function_exists('ws_recursos')) { $r = ws_recursos(); if (isset($r['trava_minutos'])) $m = (int)$r['trava_minutos']; }
    return max(0, min(1440, $m));
}
/** A requisição é uma TELA (navegação) ou uma consulta de fundo (fetch/XHR)? */
function ws_req_tela(): bool {
    $dest = $_SERVER['HTTP_SEC_FETCH_DEST'] ?? '';
    if ($dest !== '') return $dest === 'document' || $dest === 'iframe';
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) return false;
    $ac = $_SERVER['HTTP_ACCEPT'] ?? '';
    return $ac === '' || stripos($ac, 'text/html') !== false;
}
function ws_tela_travada_render(string $erro = ''): void {
    $u = ws_user();
    $nome = (string)($u['nome'] ?? 'Operador');
    $login = (string)($u['login'] ?? '');
    $volta = (string)($_SESSION['ws_ultima_tela'] ?? 'erp.php');
    $ini = mb_strtoupper(mb_substr(trim($nome), 0, 1), 'UTF-8');
    $foto = function_exists('ws_operador_foto') ? (string)ws_operador_foto((int)($u['id'] ?? 0)) : '';
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $css = 'css/wellsystem.css';
    http_response_code(401);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="pt-br"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Tela travada — WellSystem</title>'
       . '<link rel="stylesheet" href="' . $css . '?v=' . (function_exists('ws_ver') ? ws_ver($css) : '1') . '">'
       . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);padding:16px}'
       . '.tv{background:var(--surface);border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow-lg);max-width:420px;width:100%;padding:26px 24px;text-align:center}'
       . '.tv .av{width:64px;height:64px;border-radius:50%;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;background:var(--brand);color:#fff;font-size:24px;font-weight:800;object-fit:cover}'
       . '.tv h1{font-size:18px;margin:0 0 4px;color:var(--text)}.tv p{margin:0 0 16px;color:var(--muted);font-size:13.5px}'
       . '.tv input[type=password]{width:100%;padding:12px;border:1px solid var(--border);border-radius:10px;background:var(--bg);color:var(--text);font-size:15px}'
       . '.tv button{width:100%;margin-top:10px;padding:12px;border:0;border-radius:10px;background:var(--grad-brand,var(--brand));color:#fff;font-weight:800;font-size:15px;cursor:pointer}'
       . '.tv .err{background:var(--surface);border:2px solid var(--err);color:var(--err);border-radius:10px;padding:9px 12px;margin-bottom:12px;font-size:13.5px;font-weight:600}'
       . '.tv .sair{display:inline-block;margin-top:14px;color:var(--muted);font-size:12.5px}</style></head><body>'
       . '<form class="tv" method="post" autocomplete="off">'
       . ($foto !== '' ? '<img class="av" src="' . $h($foto) . '" alt="">' : '<div class="av">' . $h($ini) . '</div>')
       . '<h1>🔒 Tela travada</h1>'
       . '<p>' . $h($nome) . ' — ' . (int)ws_sessao_minutos_trava() . ' min sem uso. Digite a senha para voltar<br>'
       . 'para onde você estava.</p>'
       . ($erro !== '' ? '<div class="err">' . $h($erro) . '</div>' : '')
       . '<input type="hidden" name="ws_destravar" value="1">'
       . '<input type="password" name="ws_senha" placeholder="Senha de ' . $h($login) . '" autofocus required>'
       . '<button type="submit">Destravar</button>'
       . '<a class="sair" href="erp.php?sair=1">sair da conta</a>'
       . '</form>'
       . '<script>var f=document.querySelector(".tv");f&&f.querySelector("input[type=password]").focus();</script>'
       . '</body></html>';
    exit;
}
/** Aviso no topo: chamados que o técnico concluiu pelo link e esperam a validação do provedor (01/10/2026).
 *  Mesmo visual do 🔔 da Central; some sozinho quando não há nenhum. */
/* EQUIPAMENTO E COMODATO AUTOMÁTICOS (03/10/2026). Regra do provedor: toda ONT é Router e é comodato; toda ONU é
   Bridge (e é comodato) — o roteador, nesse caso, é perguntado na autorização. O tipo vem do que a OLT do sistema
   gravou para aquele SN (cadastro da OLT: tipo ONT/ONU escolhido ao autorizar). */
function ws_equip_sn_hex(string $sn): string {
    $s = strtoupper(preg_replace('/[^a-z0-9]/i', '', $sn));
    if (preg_match('/^([A-Z]{4})([0-9A-F]{8})$/', $s, $m)) { $p = ''; for ($i = 0; $i < 4; $i++) $p .= sprintf('%02X', ord($m[1][$i])); return $p . $m[2]; }
    return $s;
}
function ws_equip_tipo_do_sn(string $sn): string {
    static $cad = null;
    if ($cad === null) {
        $cad = [];
        foreach ([WS_DIR . '/cache_trafego/olt_cadastro.json', WS_DIR . '/olt/cache_trafego/olt_cadastro.json'] as $f)
            if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) foreach ($j as $k => $v) $cad[ws_equip_sn_hex((string)$k)] = strtoupper((string)($v['tipo'] ?? '')); }
    }
    $t = $cad[ws_equip_sn_hex($sn)] ?? '';
    return $t === 'ONT' ? 'ONT (Router)' : ($t === 'ONU' ? 'ONU (Bridge)' : '');
}
/** Preenche Equipamento (Bridge/Router pelo tipo da OLT), Comodato=Sim e o serial nos contratos com ONU/ONT.
 *  $contratoId: só aquele; null: todos sem equipamento definido. Não troca o que o operador já escolheu. */
function ws_equip_auto(PDO $db, ?int $contratoId = null, string $modo = ''): int {
    $n = 0;
    try {
        $sql = "SELECT id, sn_onu, equipamento, comodato, equip_serial, equip_tipo FROM ws_contrato WHERE COALESCE(sn_onu,'')<>'' AND COALESCE(status,'')<>'cancelado'"
             . ($contratoId ? " AND id=" . (int)$contratoId : " AND (COALESCE(equipamento,'')='' OR comodato IS NULL OR comodato=0)");
        $up = $db->prepare("UPDATE ws_contrato SET equipamento=?, equip_tipo=?, comodato=1, equip_serial=? WHERE id=?");
        foreach ($db->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $ct) {
            // só SN de verdade (16 hex ou 4 letras + 8 hex): há contratos importados com o LOGIN escrito no campo do SN
            if (!preg_match('/^([0-9A-F]{16}|[A-Z]{4}[0-9A-F]{8})$/', strtoupper(preg_replace('/[^a-z0-9]/i', '', (string)$ct['sn_onu'])))) continue;
            $eq = $modo !== '' ? $modo : (trim((string)$ct['equipamento']) !== '' ? (string)$ct['equipamento'] : ws_equip_tipo_do_sn((string)$ct['sn_onu']));
            $tp = $eq === 'ONT (Router)' ? 'ONT' : ($eq === 'ONU (Bridge)' ? 'ONU' : (string)$ct['equip_tipo']);
            $up->execute([$eq !== '' ? $eq : null, $tp !== '' ? $tp : null, trim((string)$ct['equip_serial']) !== '' ? $ct['equip_serial'] : $ct['sn_onu'], (int)$ct['id']]);
            $n++;
        }
    } catch (Throwable $e) {}
    return $n;
}

/** Código do cliente (01/10/2026). Quem ainda não tem (cadastro novo, importação, robô) ganha agora: id com 6 dígitos. */
function ws_cliente_codigo(PDO $db, int $id, ?string $atual = null): string {
    if ($id <= 0) return '';
    if ($atual !== null && trim($atual) !== '') return $atual;
    try {
        $db->prepare("UPDATE ws_cliente SET codigo=LPAD(id,6,'0') WHERE id=? AND (codigo IS NULL OR codigo='')")->execute([$id]);
        $q = $db->prepare("SELECT codigo FROM ws_cliente WHERE id=?"); $q->execute([$id]); return (string)$q->fetchColumn();
    } catch (Throwable $e) { return str_pad((string)$id, 6, '0', STR_PAD_LEFT); }
}
/** Aviso no topo: pré-cadastros feitos pelo robô do WhatsApp aguardando aprovar/recusar (01/10/2026). */
function ws_precad_chip(): string {
    static $html = null; if ($html !== null) return $html;
    try { $n = (int)ws_db()->query("SELECT COUNT(*) FROM ws_lead WHERE origem='WhatsApp (robô)' AND etapa='novo' AND cliente_id IS NULL")->fetchColumn(); }
    catch (Throwable $e) { $n = 0; }
    if ($n < 1) return $html = '';
    $t = $n . ' pré-cadastro' . ($n === 1 ? '' : 's') . ' do robô aguardando aprovação';
    return $html = '<a href="comercial.php#precad" class="ws-top-chip ws-precad-chip" title="' . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . '" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;'
         . 'background:var(--warn,#e6a100);color:#1b1b1b;font-weight:700;font-size:12.5px;text-decoration:none;white-space:nowrap">🆕 <span>' . $n . '</span> <span>pré-cadastro' . ($n === 1 ? '' : 's') . '</span></a>';
}
/** Aviso no topo: chamados abertos pelo ROBÔ do WhatsApp (atendimento fora do horário, mudança de endereço, instalação…) esperando alguém da equipe (10/10/2026). */
function ws_robo_chamados_chip(): string {
    static $html = null; if ($html !== null) return $html;
    try { $n = (int)ws_db()->query("SELECT COUNT(*) FROM ws_chamado WHERE status='aberto' AND titulo LIKE '%robô%' AND criado_em > NOW() - INTERVAL 7 DAY")->fetchColumn(); }
    catch (Throwable $e) { $n = 0; }
    if ($n < 1) return $html = '';
    $t = $n . ' atendimento' . ($n === 1 ? '' : 's') . ' do robô aguardando a equipe';
    return $html = '<a href="chamados.php" class="ws-top-chip ws-robochamado-chip" title="' . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . '" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;'
         . 'background:var(--warn,#e6a100);color:#1b1b1b;font-weight:700;font-size:12.5px;text-decoration:none;white-space:nowrap">🤖 <span>' . $n . '</span> <span>atendimento' . ($n === 1 ? '' : 's') . ' do robô</span></a>';
}
function ws_ch_validar_chip(): string {
    static $html = null; if ($html !== null) return $html;
    try { $n = (int)ws_db()->query("SELECT COUNT(*) FROM ws_chamado WHERE tec_concluido_em IS NOT NULL AND status NOT IN('resolvido','cancelado')")->fetchColumn(); }
    catch (Throwable $e) { $n = 0; }
    if ($n < 1) return $html = '';
    $t = $n . ' chamado' . ($n === 1 ? '' : 's') . ' concluído' . ($n === 1 ? '' : 's') . ' pelo técnico aguardando validação';
    return $html = '<a href="chamados.php?validar=1" class="ws-top-chip ws-chval-chip" title="' . htmlspecialchars($t, ENT_QUOTES, 'UTF-8') . '" style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;'
         . 'background:var(--warn,#e6a100);color:#1b1b1b;font-weight:700;font-size:12.5px;text-decoration:none;white-space:nowrap">🛠️ <span>' . $n . '</span> <span>validar</span></a>';
}
function ws_sessao_trava_verificar(): void {
    if (PHP_SAPI === 'cli') return;
    if (defined('WS_SEM_TRAVA')) return;   // olt.php carrega o config.php só p/ o rodapé, com a página JÁ impressa: travar ali colava a tela de bloqueio no fim da OLT
    if (empty($_SESSION['ws_user'])) return;                       // ninguém logado: nada a travar
    if (function_exists('ws_em_demo') && ws_em_demo()) return;     // demonstração não tranca
    $min = ws_sessao_minutos_trava();

    // DESTRAVAR: senha do próprio operador (a mesma do login) e volta para a última tela.
    if (!empty($_POST['ws_destravar'])) {
        $u = ws_user(); $ok = false;
        $__bq = ws_login_bloqueado('u' . (int)($u['id'] ?? 0), 'trava');   // limite de tentativas (17/11/2026)
        if ($__bq > 0) { ws_tela_travada_render(ws_login_msg_bloqueio($__bq)); exit; }
        try {
            $st = ws_db()->prepare("SELECT senha_hash FROM ws_usuario WHERE id=?");
            $st->execute([(int)($u['id'] ?? 0)]);
            $hash = (string)$st->fetchColumn();
            $ok = $hash !== '' && password_verify((string)($_POST['ws_senha'] ?? ''), $hash);
        } catch (Throwable $e) { $ok = false; }
        if (!$ok) ws_login_falha('u' . (int)($u['id'] ?? 0), 'trava'); else ws_login_ok('u' . (int)($u['id'] ?? 0), 'trava');
        if ($ok) {
            unset($_SESSION['ws_trancada']);
            $_SESSION['ws_ativ_em'] = time();
            if (function_exists('ws_marcar_presenca')) { unset($_SESSION['ws_presenca_em']); ws_marcar_presenca(); }
            $volta = (string)($_SESSION['ws_ultima_tela'] ?? 'erp.php');
            if (!preg_match('~^[a-z_0-9\-]+\.php~i', ltrim($volta, '/'))) $volta = 'erp.php';
            header('Location: ' . $volta); exit;
        }
        ws_tela_travada_render('Senha incorreta.');
    }

    /* SAIR com a tela travada (01/10/2026): o "Sair" da tela de bloqueio encerra a sessão de verdade e volta ao login. */
    if (isset($_GET['sair'])) {
        if (function_exists('ws_marcar_saida')) ws_marcar_saida();
        $_SESSION = []; @session_destroy();
        $pag = in_array(basename((string)($_SERVER['SCRIPT_FILENAME'] ?? '')), ['crm.php'], true) ? 'crm.php' : 'erp.php';
        header('Location: ' . $pag); exit;
    }
    if (!empty($_SESSION['ws_trancada'])) {
        if (ws_req_tela()) ws_tela_travada_render('');
        http_response_code(401); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'trancada' => true]); exit;
    }
    if ($min <= 0) return;                                          // 0 = nunca tranca

    /* Passou do tempo: tranca TUDO — inclusive as consultas de fundo de uma aba esquecida aberta,
     * que senão continuariam devolvendo dados do provedor numa tela abandonada. */
    $agora = time();
    $ultimo = (int)($_SESSION['ws_ativ_em'] ?? 0);
    if ($ultimo > 0 && ($agora - $ultimo) > $min * 60) {
        $_SESSION['ws_trancada'] = 1;
        if (function_exists('ws_marcar_saida')) ws_marcar_saida();   // trancado não é "online"
        if (ws_req_tela()) ws_tela_travada_render('');
        http_response_code(401); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'trancada' => true]); exit;
    }
    if (!ws_req_tela()) return;   // consulta de fundo não RENOVA o relógio da inatividade
    if (isset($_GET['_auto'])) return;   // recarga AUTOMÁTICA da tela (js/wellsystem.js) também não: não é uso
    $_SESSION['ws_ativ_em'] = $agora;
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
        // não guarda logout/atalhos como "tela para voltar"
        if ($uri !== '' && !preg_match('~[?&](sair|ws_reflexo)=~', $uri)) $_SESSION['ws_ultima_tela'] = $uri;
    }
}
/* TRAVA CENTRAL DE LICENÇA (01/10/2026) — além das telas (index/erp/crm/install/portal), TUDO que carrega o núcleo
 * exige o servidor ativado: páginas, API do robô, webhooks de gateway e as rotinas do cron (RADIUS, cobrança,
 * faturamento, baixa automática, backup). Cópia não ativada não presta serviço nenhum.
 * Só ficam de fora a própria ativação e o install_cli.php (cria as tabelas na instalação, antes da ativação web).
 * A verificação é a mesma de sempre (ws_ativado: assinatura do servidor + cópias de segurança). */
(function () {
    if (!function_exists('ws_ativacao_exigida') || !ws_ativacao_exigida()) return;
    $arq = basename((string)($_SERVER['SCRIPT_FILENAME'] ?? ''));
    if (in_array($arq, ['ativacao.php', 'install_cli.php'], true)) return;
    if (ws_ativado()) return;
    $msg = 'Sistema não ativado neste servidor. Licença: ' . WS_LICENCA_CONTATO . ' · ' . WS_LICENCA_FONE;
    if (PHP_SAPI === 'cli') { fwrite(STDERR, "WellSystem: $msg\n"); exit(3); }
    $dir = realpath(dirname((string)($_SERVER['SCRIPT_FILENAME'] ?? ''))) ?: WS_DIR;
    $rel = strpos($dir, WS_DIR) === 0 ? trim(str_replace(DIRECTORY_SEPARATOR, '/', substr($dir, strlen(WS_DIR))), '/') : '';
    $volta = str_repeat('../', $rel === '' ? 0 : substr_count($rel, '/') + 1) . 'ativacao.php';
    $json = $rel !== '' || preg_match('/^webhook_/', $arq) || stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'json') !== false || !empty($_SERVER['HTTP_X_REQUESTED_WITH']);
    http_response_code($json ? 403 : 302);
    if ($json) { header('Content-Type: application/json; charset=utf-8'); echo json_encode(['erro' => 'sistema_nao_ativado', 'mensagem' => $msg], JSON_UNESCAPED_UNICODE); exit; }
    header('Location: ' . $volta); exit;
})();
/**
 * ENDEREÇO PÚBLICO para LINKS QUE SAEM DO SISTEMA (técnico, aceite do contrato, pesquisa, app do técnico) — 01/10/2026.
 * Sempre o DOMÍNIO salvo (cache/url_publica.txt, ex.: https://financeiro.provedor.com.br), nunca o IP: quem acessa o
 * sistema pelo IP gerava links "http://IP/..." que não abriam no 4G do técnico/cliente. Sem domínio salvo, usa o acesso atual.
 */
function ws_url_publica(): string {
    $u = rtrim(trim((string)@file_get_contents(WS_CACHE . '/url_publica.txt')), '/');
    if ($u !== '' && preg_match('#^https?://[^/]*[a-z]#i', $u)) return $u;
    $hst = preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($hst === '') return $u;
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    return ($https ? 'https' : 'http') . '://' . $hst . ws_url_pasta();
}
/** Pasta do sistema dentro do site ('' quando o domínio aponta direto para ele). */
function ws_url_pasta(): string {
    $doc = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
    $p = ($doc !== '' && strpos(WS_DIR, $doc) === 0) ? str_replace('\\', '/', substr(WS_DIR, strlen($doc))) : '';
    return rtrim($p, '/');
}

/* ENDEREÇO PÚBLICO do sistema (01/10/2026): o domínio por onde a equipe acessa fica guardado em cache/url_publica.txt
   para os links que saem pelas rotinas sem navegador (pesquisa de satisfação, avisos). Só domínio de verdade, nunca IP local. */
(function () {
    $hst = preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    if (PHP_SAPI === 'cli' || $hst === '' || !preg_match('/[a-z]/i', $hst) || preg_match('/^(localhost|127\.)/', $hst)) return;
    /* VÁRIOS DOMÍNIOS no mesmo sistema (erp., financeiro., assinante., …): o endereço dos links é FIXO — grava só se ainda não
       existe, só por operador logado e nunca pelo domínio da Central do Assinante. Trocar: Configurações → Geral. */
    if (trim((string)@file_get_contents(WS_CACHE . '/url_publica.txt')) !== '' || empty($_SESSION['ws_user'])) return;
    $cen = json_decode((string)@file_get_contents(WS_CACHE . '/central.json'), true);
    if (is_array($cen) && !empty($cen['host']) && strcasecmp(preg_replace('/:\d+$/', '', $hst), trim((string)$cen['host'])) === 0) return;
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $u = ($https ? 'https' : 'http') . '://' . $hst . ws_url_pasta(); $f = WS_CACHE . '/url_publica.txt';
    if (trim((string)@file_get_contents($f)) !== $u) @file_put_contents($f, $u);
})();

/* TRAVA DO 2FA OBRIGATÓRIO (ver ws_twofa_obrigatorio_para_mim): sem 2FA ativo, nível 3+ só acessa a tela de ativação. */
(function () {
    if (PHP_SAPI === 'cli' || empty($_SESSION['ws_user']) || !ws_twofa_obrigatorio_para_mim()) return;
    if (!empty($_SESSION['ws_2fa_conf_ok'])) return;
    try { $st = ws_db()->prepare("SELECT twofa_enabled FROM ws_usuario WHERE id=?"); $st->execute([(int)$_SESSION['ws_user']['id']]);
          if ((int)$st->fetchColumn() === 1) { $_SESSION['ws_2fa_conf_ok'] = 1; return; } } catch (Throwable $e) { return; }
    $arq = basename((string)($_SERVER['SCRIPT_FILENAME'] ?? ''));
    $pagina = in_array($arq, ['erp.php', 'crm.php'], true) ? $arq : 'erp.php';
    $liberado = in_array($arq, ['erp.php', 'crm.php'], true) && (
        (($_GET['p'] ?? '') === 'config' && ($_GET['t'] ?? '') === 'seguranca') || isset($_GET['twofa_init']) || isset($_GET['sair']) || isset($_GET['logout'])
        || in_array((string)($_POST['acao'] ?? ''), ['twofa_ativar', 'login', 'logout'], true));
    if ($liberado) return;
    if (stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'json') !== false || !empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        http_response_code(403); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['erro' => '2fa_obrigatorio', 'mensagem' => 'Ative a verificação em 2 etapas para continuar.'], JSON_UNESCAPED_UNICODE); exit;
    }
    header('Location: ' . $pagina . '?p=config&t=seguranca&exigir2fa=1'); exit;
})();

ws_edicao_guarda();   // página/cron de módulo fora da edição não abre
if (is_file(__DIR__ . '/licenca_online.php')) { require_once __DIR__ . '/licenca_online.php'; ws_lic_guarda_web(); }   // licença online (18/11/2026): só uma REVOGAÇÃO assinada, há mais de 7 dias, deixa o sistema em somente leitura
ws_sessao_trava_verificar();
