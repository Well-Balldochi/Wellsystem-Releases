<?php
/**
 * WellSystem — Cliente CelCash / GalaxPay v2 (boleto + PIX).
 *
 * Fluxo: Basic base64(galaxId:galaxHash) → POST /token → Bearer (600s, cacheado)
 *        → POST /charges (cobrança avulsa boleto+PIX).
 *
 * SEGREDO NUNCA NO CÓDIGO: credenciais vêm de cache/celcash.json (bloqueado p/ web),
 * gravado pela tela de configuração (financeiro.php?p=gateway).
 *
 * O parse da resposta é DEFENSIVO (aceita nomes de campo do v1 e v2), e guardamos
 * o JSON cru em ws_fatura.gateway_raw para travar o mapeamento no 1º teste em sandbox.
 */
require_once __DIR__ . '/config.php';

define('WS_CELCASH_CFG', WS_CACHE . '/celcash.json');
define('WS_CELCASH_TOKEN', WS_CACHE . '/celcash_token.json');

/** Lê config do gateway (sandbox|producao + credenciais). */
function ws_celcash_config(): array {
    /* webhookUrl: o endereço que a CelCoin chama quando o boleto/PIX é pago. Fica GRAVADO (e não
       mais só calculado a partir do host da tela) porque o provedor pode receber o retorno em outro
       domínio — por exemplo num endereço só de financeiro, fora do ERP. Vazio = usa o padrão desta
       instalação (webhook_celcash.php aqui mesmo). */
    $def = ['ambiente' => 'sandbox', 'galaxId' => '', 'galaxHash' => '', 'webhookToken' => '', 'cedente' => '', 'webhookUrl' => ''];
    if (is_file(WS_CELCASH_CFG)) {
        $c = json_decode(@file_get_contents(WS_CELCASH_CFG), true);
        if (is_array($c)) {
            $c = array_merge($def, $c);
            /* MESMO ARQUIVO, DOIS NOMES PARA O MESMO DADO.
             *
             * A migração do MK-Auth e o ws_configs_garantir() gravam galax_id / galax_hash /
             * webhook_secret; esta função sempre leu galaxId / galaxHash / webhookToken. Resultado:
             * provedor que veio de migração tinha a credencial da CelCoin guardada no arquivo, a
             * tela aparecia VAZIA e o boleto do gateway nunca saía — "está configurado e não gera".
             * Agora o nome antigo vale quando o novo está em branco. Ninguém precisa redigitar. */
            foreach (['galaxId' => 'galax_id', 'galaxHash' => 'galax_hash', 'webhookToken' => 'webhook_secret'] as $novo => $velho)
                if (trim((string)$c[$novo]) === '' && trim((string)($c[$velho] ?? '')) !== '') $c[$novo] = (string)$c[$velho];
            return $c;
        }
    }
    return $def;
}

/** Grava config do gateway (chamado pela tela). */
function ws_celcash_salvar(array $cfg): void {
    $atual = ws_celcash_config();
    @file_put_contents(WS_CELCASH_CFG, json_encode(array_merge($atual, $cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CELCASH_CFG, 0640);
    @unlink(WS_CELCASH_TOKEN); // força novo token ao trocar credencial/ambiente
}

/** Base URL conforme ambiente. */
function ws_celcash_base(): string {
    // CORRIGIDO: o domínio antigo "api.cel.cash" foi descontinuado na migração para a Celcoin
    // e passou a devolver 503 (Cloudflare) para qualquer chamada. O endereço de produção atual
    // é o mesmo que aparece no painel Celcoin em Módulos → Webservice.
    return ws_celcash_config()['ambiente'] === 'producao'
        ? 'https://api-celcash.celcoin.com.br/v2'
        : 'https://api.sandbox.cel.cash/v2';
}

/** HTTP helper (curl). Retorna [http_code, array|null, raw]. */
function ws_celcash_http(string $metodo, string $url, ?array $headers = null, $body = null): array {
    $ch = curl_init($url);
    $allHeaders = $headers ?: [];
    $allHeaders[] = 'Accept: application/json'; // Padrão de API, o Cloudflare pode exigir
    $allHeaders[] = 'Cache-Control: no-cache';

    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $metodo,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
        CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1, // Força HTTP/1.1 (evita bugs de http2 no cURL/Cloudflare)
        CURLOPT_ENCODING       => '', // Aceita gzip/deflate (WAF gosta disso)
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', // Disfarça como navegador
        CURLOPT_HTTPHEADER     => $allHeaders,
        CURLINFO_HEADER_OUT    => true, // Necessário para capturar os headers de envio
        CURLOPT_HEADER         => true, // Inclui headers da resposta no raw output
    ]);

    $bodyStr = $body !== null ? (is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE)) : null;
    if ($bodyStr !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyStr);

    $response = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    $reqHeaders = curl_getinfo($ch, CURLINFO_HEADER_OUT) ?: "Requisicao falhou antes de enviar headers\n";
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

    curl_close($ch);

    if ($response === false) {
        $rawBody = 'curl err: ' . $err;
        $respHeaders = "Nenhum header de resposta (falha local)\n";
    } else {
        $respHeaders = substr($response, 0, $headerSize);
        $rawBody = substr($response, $headerSize);
    }

    // ADICIONADO: oculta o valor do header Authorization (Basic/Bearer) antes de gravar no log.
    // O log anterior gravava a credencial em texto (base64), que não é sigilo — qualquer um que
    // veja o arquivo consegue decodificar o Galax Id/Hash ou o token de acesso.
    $reqHeadersLog = preg_replace('/Authorization: (Basic|Bearer) \S+/', 'Authorization: $1 [oculto]', $reqHeaders);

    // Grava o log detalhado para o suporte
    $log = "===== REQUEST =====\n" .
           "URL: " . $url . "\n\n" .
           $reqHeadersLog . "\n" .
           ($bodyStr ? "BODY:\n" . $bodyStr . "\n" : "") .
           "\n===== RESPONSE =====\n" .
           "HTTP CODE: " . $code . "\n\n" .
           $respHeaders . "\n" .
           "BODY:\n" . $rawBody . "\n\n" .
           "====================\n\n";

    $tmpLogPath = sys_get_temp_dir() . '/celcash_debug.txt';
    @file_put_contents($tmpLogPath, $log, FILE_APPEND);
    @file_put_contents(WS_CACHE . '/celcash_debug.txt', $log, FILE_APPEND); // Tenta no cache do sistema tambem

    if ($response === false) return [0, null, $rawBody];
    return [$code, json_decode($rawBody, true), $rawBody];
}

/** Escopos v2 necessários para operar cobranças/boletos/webhooks. */
function ws_celcash_scopes(): string {
    // "card.read", "card.write" e "webhooks.read" não são valores de escopo válidos nesta API
    // (a própria Celcoin retorna 401 com erro de validação apontando os três) e não são usados
    // pelo fluxo deste arquivo — cobrança avulsa (boleto+PIX) não mexe em cartão, e o webhook é
    // configurado manualmente no painel, não lido via API.
    return 'customers.write customers.read plans.write plans.read '
         . 'transactions.read transactions.write charges.write charges.read '
         . 'boletos.read webhooks.write';
}

/**
 * Obtém access_token (cacheado em arquivo até expirar).
 * @throws RuntimeException em falha de autenticação.
 */
function ws_celcash_token(bool $renovar = false): string {
    /* UM POR VEZ (01/10/2026): dois atendentes emitindo ao mesmo tempo pediam dois tokens; a CelCoin invalidava o primeiro
       e respondia "ocupado/aguarde" para quem estava no meio. Agora o pedido de token passa por uma trava e o segundo
       reaproveita o token que o primeiro acabou de gerar. */
    static $trava = null;
    if ($trava === null) { $trava = @fopen(WS_CELCASH_TOKEN . '.lock', 'c'); }
    if ($trava) @flock($trava, LOCK_EX);
    try { return ws_celcash_token_obter($renovar); } finally { if ($trava) @flock($trava, LOCK_UN); }
}
function ws_celcash_token_obter(bool $renovar): string {
    if ($renovar) @unlink(WS_CELCASH_TOKEN);
    if (is_file(WS_CELCASH_TOKEN)) {
        $t = json_decode(@file_get_contents(WS_CELCASH_TOKEN), true);
        if (is_array($t) && !empty($t['access_token']) && ($t['exp'] ?? 0) > time() + 30) return $t['access_token'];
    }
    $c = ws_celcash_config();
    if ($c['galaxId'] === '' || $c['galaxHash'] === '') throw new RuntimeException('CelCash sem credenciais (configure em Financeiro → Gateway).');

    $basic = base64_encode($c['galaxId'] . ':' . $c['galaxHash']);
    [$code, $resp, $raw] = ws_celcash_http('POST', ws_celcash_base() . '/token',
        ['Authorization: Basic ' . $basic, 'Content-Type: application/json'],
        ['grant_type' => 'authorization_code', 'scope' => ws_celcash_scopes()]);

    if ($code !== 200 || empty($resp['access_token'])) {
        $rawStr = is_string($raw) ? mb_substr(strip_tags($raw), 0, 500) : 'vazio';
        throw new RuntimeException("NOVO ARQUIVO! CelCash HTTP $code. Log salvo no servidor! Resposta: $rawStr");
    }
    $exp = time() + (int)($resp['expires_in'] ?? 600);
    @file_put_contents(WS_CELCASH_TOKEN, json_encode(['access_token' => $resp['access_token'], 'exp' => $exp]));
    @chmod(WS_CELCASH_TOKEN, 0640);
    return $resp['access_token'];
}

/** Só dígitos. */
function ws_so_num($s): string { return preg_replace('/\D/', '', (string)$s); }

/** E-mail do cliente para o CelCash. Válido no cadastro = usa. Senão: nome.sobrenome + N (1,2,3… o primeiro livre) @ site do provedor; guardado em cache/email_gateway.json. */
function ws_celcash_email_cliente(array $cliente): string {
    $e = trim((string)($cliente['email'] ?? ''));
    if ($e !== '' && filter_var($e, FILTER_VALIDATE_EMAIL)) return $e;
    $arq = WS_CACHE . '/email_gateway.json'; $id = (string)($cliente['id'] ?? '0');
    $mapa = json_decode((string)@file_get_contents($arq), true); if (!is_array($mapa)) $mapa = [];
    if (!empty($mapa[$id])) return $mapa[$id];
    $nome = mb_strtolower(trim((string)($cliente['nome'] ?? '')));
    $nome = strtr($nome, ['á'=>'a','à'=>'a','â'=>'a','ã'=>'a','ä'=>'a','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ó'=>'o','ò'=>'o','ô'=>'o','õ'=>'o','ö'=>'o','ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c','ñ'=>'n']);
    $p = array_values(array_filter(preg_split('/[^a-z]+/', $nome), fn($w) => !in_array($w, ['da','de','do','das','dos','e'], true)));
    $slug = $p ? ($p[0] . (count($p) > 1 ? $p[1] : '')) : 'cliente';   /* mesmo padrão das caixas já entregues: nome+sobrenome juntos (ex.: joaomonteiro) */
    $pv = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
    $dom = preg_replace('#^(https?://)?(www\.)?#i', '', trim((string)($pv['site'] ?? ''))); $dom = trim(explode('/', $dom)[0]);
    if ($dom === '' || strpos($dom, '.') === false) { $pe = (string)($pv['email'] ?? ''); $dom = strpos($pe, '@') !== false ? substr($pe, strpos($pe, '@') + 1) : 'cliente.com.br'; }
    $usados = array_flip(array_map('strtolower', $mapa));
    $ja = []; try { $st = ws_db()->prepare("SELECT LOWER(email) FROM ws_cliente WHERE email LIKE ? AND id<>?"); $st->execute([$slug . '%@' . $dom, (int)$id]); $ja = array_flip($st->fetchAll(PDO::FETCH_COLUMN)); } catch (Throwable $e) {}
    for ($k = 1; $k < 100000; $k++) { $c = "$slug$k@$dom"; if (!isset($usados[$c]) && !isset($ja[$c])) break; }
    $mapa[$id] = $c; @file_put_contents($arq, json_encode($mapa), LOCK_EX); @chmod($arq, 0640);
    /* completa o cadastro: só quando o e-mail está vazio/inválido (nunca sobrescreve válido). */
    try { if ((int)$id > 0) ws_db()->prepare("UPDATE ws_cliente SET email=? WHERE id=? AND (email IS NULL OR TRIM(email)='' OR email NOT LIKE '%_@_%._%')")->execute([$c, (int)$id]); } catch (Throwable $e) {}
    return $c;
}
/**
 * Cria a cobrança (boleto+PIX) no CelCash para uma fatura.
 * @param array $fatura   linha de ws_fatura (precisa: id, valor, vencimento, celcash_my_id)
 * @param array $cliente  linha de ws_cliente
 * @return array parse: [ok, charge_id, linha_digitavel, boleto_url, pix_emv, pix_qr_url, raw, erro]
 */
/** (16/10/2026) "O myId está em uso por outra assinatura ou cobrança avulsa": a chamada anterior (tempo esgotado, clique repetido) JÁ criou a cobrança no CelCash. Em vez de mostrar erro, acha a cobrança pelo myId e devolve os mesmos dados
 *  (nada novo é criado). Se o myId existe mas não é achado como cobrança, gera um myId novo para o título e tenta de novo uma vez. */
function ws_celcash_criar_cobranca(array $fatura, array $cliente): array {
    /* TRAVA POR TÍTULO (16/10/2026, definitivo): a tela de emissão e o emissor automático (cron em fatias) pegavam o MESMO título ao mesmo tempo — o segundo recebia "myId em uso" (ou criava cobrança em dobro). Agora só um emite cada título por vez;
       quem chega depois espera o primeiro terminar e, se o título já tem cobrança, devolve a que existe (nada novo é criado). */
    if (function_exists('ws_lic_liberado') && !ws_lic_liberado()) return ['ok' => false, 'erro' => 'Sistema em somente leitura (licença revogada). Fale com o suporte WellSystem.', 'raw' => null];
    $lk = null; $fid = (int)($fatura['id'] ?? 0);
    if ($fid > 0 && defined('WS_CACHE')) { $lk = @fopen(WS_CACHE . '/celcash_emit_' . $fid . '.lock', 'c'); if ($lk) { $ate = time() + 90; while (!@flock($lk, LOCK_EX | LOCK_NB) && time() < $ate) usleep(300000); } }
    try {
        if ($fid > 0) {
            $q = ws_db()->prepare("SELECT celcash_charge_id, linha_digitavel, boleto_url, pix_emv, pix_qr_url, gateway_raw FROM ws_fatura WHERE id=?"); $q->execute([$fid]); $ja = $q->fetch(PDO::FETCH_ASSOC);
            if ($ja && trim((string)$ja['celcash_charge_id']) !== '' && (trim((string)$ja['linha_digitavel']) !== '' || trim((string)$ja['boleto_url']) !== '' || trim((string)$ja['pix_emv']) !== ''))
                return ['ok' => true, 'charge_id' => (string)$ja['celcash_charge_id'], 'linha_digitavel' => $ja['linha_digitavel'], 'boleto_url' => $ja['boleto_url'], 'pix_emv' => $ja['pix_emv'], 'pix_qr_url' => $ja['pix_qr_url'], 'raw' => $ja['gateway_raw']];   // outro processo acabou de emitir
        }
        /* myId VAZIO (18/11/2026): título importado sem identificador mandava "myId":"" e o CelCash não respondia (timeout de 30 s a cada minuto; fatura 6931 da Emilly e outras ficaram sem emitir, alerta de saúde piscando). Gera e grava o myId antes de emitir (mesmo padrão do boleto.php). */
        if ($fid > 0 && trim((string)($fatura['celcash_my_id'] ?? '')) === '') {
            $qm = ws_db()->prepare("SELECT contrato_id, competencia, celcash_my_id FROM ws_fatura WHERE id=?"); $qm->execute([$fid]); $fm = $qm->fetch(PDO::FETCH_ASSOC);
            $mid = trim((string)($fm['celcash_my_id'] ?? ''));
            if ($mid === '' && $fm) {
                $mid = 'ws-' . (int)$fm['contrato_id'] . '-' . str_replace('-', '', (string)$fm['competencia']) . '-' . substr(uniqid(), -4);
                ws_db()->prepare("UPDATE ws_fatura SET celcash_my_id=? WHERE id=? AND (celcash_my_id IS NULL OR celcash_my_id='')")->execute([$mid, $fid]);
            }
            if ($mid !== '') $fatura['celcash_my_id'] = $mid;
        }
        return ws_celcash_criar_cobranca_seguro($fatura, $cliente);
    } finally { if ($lk) { @flock($lk, LOCK_UN); @fclose($lk); } }
}
function ws_celcash_criar_cobranca_seguro(array $fatura, array $cliente): array {
    $r = ws_celcash_criar_cobranca_http($fatura, $cliente);
    if (!empty($r['ok']) || stripos((string)($r['erro'] ?? ''), 'myId') === false || stripos((string)($r['erro'] ?? ''), 'uso') === false) return $r;
    $rr = ws_celcash_buscar_por_myid((string)$fatura['celcash_my_id']);
    if (!empty($rr['ok'])) return $rr;
    if (empty($rr['inexistente'])) ws_celcash_log_emissao($fatura, $cliente, false, 'HTTP 400 — myId em uso e a busca da cobrança falhou: ' . mb_substr((string)($rr['erro'] ?? ''), 0, 90));
    if (empty($fatura['id']) || empty($rr['inexistente'])) return $r;   // busca falhou por outro motivo (limite/rede): NÃO cria outra cobrança (gerava duplicata no CelCash)
    $novo = preg_replace('/-[a-z0-9]{3,5}$/i', '', (string)$fatura['celcash_my_id']) . '-' . substr(uniqid(), -5);
    try { ws_db()->prepare("UPDATE ws_fatura SET celcash_my_id=? WHERE id=?")->execute([$novo, (int)$fatura['id']]); } catch (Throwable $e) { return $r; }
    $fatura['celcash_my_id'] = $novo;
    return ws_celcash_criar_cobranca_http($fatura, $cliente);
}
function ws_celcash_criar_cobranca_http(array $fatura, array $cliente): array {
    try {
        $token = ws_celcash_token();
    } catch (Throwable $e) {
        return ['ok' => false, 'erro' => $e->getMessage(), 'raw' => null];
    }

    $tel = ws_so_num($cliente['celular'] ?? $cliente['telefone'] ?? '');
    $body = [
        'myId'  => (string)$fatura['celcash_my_id'],
        // CENTAVOS · cobrança = plano + taxa de emissão (modelo B); VENCIDA = + multa e juros até hoje (ws_fatura_encargos)
        'value' => (int) round((function_exists('ws_fatura_valor_atualizado') && !empty($fatura['vencimento']) ? ws_fatura_valor_atualizado($fatura) : ((float)$fatura['valor'] + (float)($fatura['taxa_emissao'] ?? 0))) * 100),
        /* Fatura VENCIDA (01/10/2026): a CelCash recusa vencimento no passado ("Charge.payday: A data não é válida"). O boleto sai
           com vencimento de HOJE; no WellSystem a fatura mantém o vencimento original (régua, bloqueio, multa/juros contam dele). */
        'payday' => max(date('Y-m-d'), date('Y-m-d', strtotime($fatura['vencimento']))),
        'mainPaymentMethodId' => 'boleto',      // boleto com PIX embutido
        'additionalInfo' => 'Fatura ' . ($fatura['competencia'] ?? '') . (!empty($fatura['login']) ? ' - ' . $fatura['login'] : '') . ' - WellSystem',
        'Customer' => [
            'myId'     => 'cli-' . $cliente['id'],
            'name'     => $cliente['nome'],
            'document' => ws_so_num($cliente['cpf_cnpj'] ?? ''),
            /* (15/10/2026) o CelCash exige e-mail ("Customer.emails"); telefone NÃO é obrigatório. Sem e-mail válido no cadastro: gera nome.sobrenomeN@<site do provedor> (N = 1, 2, 3… para não repetir; fica guardado por cliente). */
            'emails'   => [ws_celcash_email_cliente($cliente)],
            'phones'   => (strlen($telV = (strlen($tel) >= 12 && substr($tel, 0, 2) === '55') ? substr($tel, 2) : $tel) >= 10 && strlen($telV) <= 11 && preg_match('/^[1-9][1-9](9\d{8}|[2-5]\d{7})$/', $telV)) ? [(int)$telV] : [],   /* (17/10/2026) só telefone BRASILEIRO válido: DDD (11–99) + celular 9xxxx-xxxx ou fixo 2–5xxx-xxxx. 0800/0300 e número torto (ex.: 0800031001 virava 800031001) o CelCash recusa com 400 "Customer.phones" e o boleto não saía. */   /* telefone ruim/ausente = cliente sem telefone (não trava a emissão) */
            'Address'  => [
                'zipCode'      => ws_so_num($cliente['cep'] ?? ''),
                'street'       => $cliente['logradouro'] ?? '',
                'number'       => $cliente['numero'] ?? 'S/N',
                'complement'   => $cliente['complemento'] ?? '',
                'neighborhood' => $cliente['bairro'] ?? '',
                'city'         => $cliente['cidade'] ?? '',
                'state'        => $cliente['uf'] ?? '',
            ],
        ],
    ];

    for ($tent = 1; ; $tent++) {
        [$code, $resp, $raw] = ws_celcash_http('POST', ws_celcash_base() . '/charges',
            ['Authorization: Bearer ' . $token, 'Content-Type: application/json'], $body);
        // concorrência entre atendentes: ocupado / aguarde / limite / token derrubado → espera um instante e repete, sem erro na tela
        $ocupado = in_array($code, [401, 409, 423, 429, 503], true) || preg_match('/ocupad|aguard|andamento|concorr|too many|try again|unauthori/i', (string)$raw);
        if ($code >= 200 && $code < 300 || !$ocupado || $tent >= 3) break;
        usleep($tent * 1200000);
        if ($code === 401) { try { $token = ws_celcash_token(true); } catch (Throwable $e) { break; } }
    }

    /* telefone recusado mesmo assim ("Customer.phones"): telefone não é obrigatório — repete UMA vez sem ele em vez de deixar o boleto sem emitir */
    if ($code === 400 && stripos((string)$raw, 'Customer.phones') !== false && !empty($body['Customer']['phones'])) {
        $body['Customer']['phones'] = [];
        [$code, $resp, $raw] = ws_celcash_http('POST', ws_celcash_base() . '/charges', ['Authorization: Bearer ' . $token, 'Content-Type: application/json'], $body);
    }
    if ($code < 200 || $code >= 300) {
        if (!($code === 400 && stripos((string)$raw, 'myId') !== false && stripos((string)$raw, 'uso') !== false)) ws_celcash_log_emissao($fatura, $cliente, false, 'HTTP ' . $code . ' — ' . preg_replace('/\s+/', ' ', (string)$raw));   // 'myId em uso' é tratado por quem chamou (recupera a cobrança); não polui o log do cliente
        return ['ok' => false, 'erro' => 'CelCash HTTP ' . $code . ': ' . $raw, 'raw' => $raw];
    }
    $ok = ws_celcash_parse_resposta($resp);
    ws_celcash_log_emissao($fatura, $cliente, true, (string)($ok['charge_id'] ?? ''));
    return ['ok' => true] + $ok + ['raw' => $raw];
}
/** ALTERAR O VENCIMENTO DE UMA COBRANÇA JÁ EMITIDA (15/10/2026): PUT /charges/{galaxPayId}/galaxPayId com {"payDay":"AAAA-MM-DD"} (confirmado em produção; "payday" minúsculo é ignorado). Depois da troca relê a cobrança pelo myId e
 *  devolve os dados atuais (linha digitável, boleto, PIX) para o título ser atualizado. Cobrança paga/cancelada ou data no passado o CelCash recusa — o erro vem em 'erro'. */
function ws_celcash_alterar_vencimento(string $chargeId, string $novaData, string $myId = ''): array {
    $chargeId = trim($chargeId); if (!ctype_digit($chargeId) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $novaData)) return ['ok' => false, 'erro' => 'dados inválidos', 'raw' => null];
    try { $token = ws_celcash_token(); } catch (Throwable $e) { return ['ok' => false, 'erro' => $e->getMessage(), 'raw' => null]; }
    $H = ['Authorization: Bearer ' . $token, 'Content-Type: application/json'];
    if ($myId !== '') {   // o CelCash recusa trocar para a MESMA data: se já está na data pedida, só devolve os dados atuais
        $ja = ws_celcash_buscar_por_myid($myId);
        if (!empty($ja['ok'])) { $cj = json_decode((string)$ja['raw'], true); if ((string)($cj['Transactions'][0]['payday'] ?? '') === $novaData) return $ja; }
    }
    for ($t = 1; ; $t++) {
        [$code, $resp, $raw] = ws_celcash_http('PUT', ws_celcash_base() . '/charges/' . $chargeId . '/galaxPayId', $H, ['payDay' => $novaData]);
        if ($code >= 200 && $code < 300) break;
        if ($t >= 3 || !preg_match('/Limite de requis|HTTP 0|ocupad/i', (string)$raw . ' ' . $code)) return ['ok' => false, 'erro' => 'CelCash HTTP ' . $code . ': ' . preg_replace('/\s+/', ' ', (string)$raw), 'raw' => $raw];
        sleep(15);
    }
    if ($myId !== '') { $r = ws_celcash_buscar_por_myid($myId); if (!empty($r['ok'])) return $r; }
    return ['ok' => true, 'charge_id' => $chargeId, 'linha_digitavel' => null, 'boleto_url' => null, 'pix_emv' => null, 'pix_qr_url' => null, 'raw' => $raw];
}
/** CANCELAR UMA COBRANÇA NO CELCASH (16/10/2026): DELETE /charges/{galaxPayId}/galaxPayId. Só cobrança ainda não paga; paga/liquidada o CelCash recusa. Devolve [ok, mensagem]. Confere o resultado relendo a cobrança. */
function ws_celcash_cancelar_cobranca(string $chargeId): array {
    $chargeId = trim($chargeId); if (!ctype_digit($chargeId)) return [false, 'id inválido'];
    try { $token = ws_celcash_token(); } catch (Throwable $e) { return [false, $e->getMessage()]; }
    $H = ['Authorization: Bearer ' . $token, 'Content-Type: application/json'];
    for ($t = 1; ; $t++) {
        [$code, $resp, $raw] = ws_celcash_http('DELETE', ws_celcash_base() . '/charges/' . $chargeId . '/galaxPayId', $H);
        if ($code >= 200 && $code < 300) return [true, 'cancelada'];
        if ($t >= 3 || !preg_match('/Limite de requis|HTTP 0|ocupad/i', (string)$raw . ' ' . $code)) return [false, 'CelCash HTTP ' . $code . ': ' . mb_substr(preg_replace('/\s+/', ' ', (string)$raw), 0, 200)];
        sleep(15);
    }
}
/** REGISTRO DA EMISSÃO DE BOLETO (15/10/2026): toda emissão no CelCash (de qualquer tela, do carnê ou do cron) entra no LOG DO SISTEMA e na linha do tempo do cliente — dá para saber o que foi e o que NÃO foi gerado.
 *  Sucesso: "Boleto emitido no CelCash — título #… (competência), venc., valor, cobrança N". Falha: "Falha ao emitir boleto…" com o motivo; a mesma falha do mesmo título é registrada no máximo 1 vez a cada 6 h (o cron tenta todo minuto). */
function ws_celcash_log_emissao(array $fatura, array $cliente, bool $ok, string $det): void {
    try {
        if (!function_exists('ws_evento') || !function_exists('ws_db')) return;
        $fid = (int)($fatura['id'] ?? 0); $cid = (int)($cliente['id'] ?? 0) ?: null;
        if (!$ok) {
            $f = WS_CACHE . '/emissao_falha_log.json'; $m = json_decode((string)@file_get_contents($f), true); if (!is_array($m)) $m = [];
            foreach ($m as $k => $t) if (time() - (int)$t > 21600) unset($m[$k]);
            if (isset($m[$fid])) return; $m[$fid] = time(); @file_put_contents($f, json_encode($m), LOCK_EX); @chmod($f, 0640);
        }
        $venc = !empty($fatura['vencimento']) ? date('d/m/Y', strtotime((string)$fatura['vencimento'])) : '—';
        $val = number_format((float)($fatura['valor'] ?? 0), 2, ',', '.');
        $txt = $ok ? "Boleto emitido no CelCash — título #$fid" . (!empty($fatura['competencia']) ? ' (' . $fatura['competencia'] . ')' : '') . ", venc. $venc, R$ $val" . ($det !== '' ? " · cobrança $det" : '')
                   : "Falha ao emitir boleto no CelCash — título #$fid" . (!empty($fatura['competencia']) ? ' (' . $fatura['competencia'] . ')' : '') . ", venc. $venc: " . mb_substr($det, 0, 170);
        ws_evento(ws_db(), $cid, 'fatura', $txt);
    } catch (Throwable $e) {}
}

/** COBRANÇA JÁ CRIADA NO CELCASH, PELO myId (15/10/2026). Quando a chamada de emissão estoura o tempo (timeout) o CelCash pode ter criado a cobrança mesmo assim; a nova tentativa volta "myId está em uso". Aqui a cobrança é
 *  achada pelo myId (GET /charges?myIds=…, que esta conta respeita) e devolve os mesmos campos da emissão (linha digitável, link do boleto, PIX) para o título ser completado — sem criar nada. */
function ws_celcash_buscar_por_myid(string $myId): array {
    $myId = trim($myId); if ($myId === '') return ['ok' => false, 'erro' => 'myId vazio', 'raw' => null];
    try { $token = ws_celcash_token(); } catch (Throwable $e) { return ['ok' => false, 'erro' => $e->getMessage(), 'raw' => null]; }
    [$code, $resp, $raw] = ws_celcash_http('GET', ws_celcash_base() . '/charges?myIds=' . rawurlencode($myId) . '&startAt=0&limit=2', ['Authorization: Bearer ' . $token]);
    if ($code < 200 || $code >= 300) return ['ok' => false, 'erro' => 'CelCash HTTP ' . $code, 'raw' => $raw];
    $ch = $resp['Charges'][0] ?? null; if (!is_array($ch) || (string)($ch['myId'] ?? '') !== $myId) return ['ok' => false, 'erro' => 'cobrança não encontrada pelo myId', 'raw' => $raw, 'inexistente' => true];
    $r = ws_celcash_parse_resposta(['Charges' => [$ch]]); if (empty($r['charge_id'])) return ['ok' => false, 'erro' => 'cobrança sem ID', 'raw' => $raw];
    return ['ok' => true] + $r + ['raw' => json_encode($ch, JSON_UNESCAPED_UNICODE)];
}
/**
 * Busca no CelCash uma cobrança JÁ EXISTENTE pelo ID (galaxPayId) — usada para completar títulos
 * IMPORTADOS do MK-Auth, que chegam com celcash_charge_id (mkauth_boletos.php) mas sem o PIX
 * dinâmico/URL do boleto, porque nunca passaram pelo ws_celcash_criar_cobranca() acima.
 *
 * @param string $chargeId  celcash_charge_id (= sis_lanc.chave_galaxpay = galaxPayId) já gravado na fatura.
 * @return array mesmo formato de ws_celcash_criar_cobranca(): [ok, charge_id, linha_digitavel, boleto_url, pix_emv, pix_qr_url, raw, erro]
 */
function ws_celcash_buscar_cobranca(string $chargeId): array {
    $chargeId = trim($chargeId);
    if ($chargeId === '' || !ctype_digit($chargeId)) return ['ok' => false, 'erro' => 'ID de cobrança inválido.', 'raw' => null];
    try {
        $token = ws_celcash_token();
    } catch (Throwable $e) {
        return ['ok' => false, 'erro' => $e->getMessage(), 'raw' => null];
    }
    $auth = ['Authorization: Bearer ' . $token];
    $base = ws_celcash_base();
    $alvo = (int)$chargeId;

    /* FORMATO DO ENDPOINT CONFIRMADO EM PRODUÇÃO (log real desta conta, 2026-09-20):
     * - GET /charges/{id}            -> 404 "endpoint inválido" (não existe rota por caminho).
     * - GET /charges?galaxPayId={id} -> exige "limit"/"startAt", mas o PARÂMETRO galaxPayId É
     *   IGNORADO por esta conta: duas chamadas com galaxPayId diferentes (32321 e 32844) devolveram
     *   IDÊNTICA a mesma cobrança #1 (a mais antiga, startAt=0). Ou seja, este endpoint é só
     *   paginação crua da lista completa, sem filtro nenhum — o "galaxPayId=" na query não faz nada.
     * A SAÍDA: como galaxPayId é sequencial (a cobrança #1 caiu exatamente em startAt=0), a posição
     * de uma cobrança nessa lista é previsível: startAt = galaxPayId - 1. Por segurança contra
     * pequenos desvios (cobrança cancelada/removida que desloque a posição), pedimos uma JANELA em
     * volta do alvo e, dentro dela, aceitamos SÓ o item cujo galaxPayId bate exatamente com o
     * pedido — nunca o primeiro item da resposta. Sem essa conferência, um desvio de posição faz o
     * sistema devolver o PIX de OUTRO cliente (foi exatamente o que aconteceu: as duas tentativas
     * do log trouxeram uma cobrança cancelada de 2023 de outro título). Fica tudo registrado em
     * cache/celcash_debug.txt (REQUEST/RESPONSE completos). */
    $janela  = 3; // cobre pequenos desvios de posição sem precisar de muitas chamadas
    $startAt = max(0, $alvo - 1 - $janela);
    $limit   = ($janela * 2) + 1;
    $url = $base . '/charges?galaxPayId=' . rawurlencode($chargeId) . '&limit=' . $limit . '&startAt=' . $startAt;

    [$code, $resp, $raw] = ws_celcash_http('GET', $url, $auth);
    if ($code < 200 || $code >= 300) {
        return ['ok' => false, 'erro' => 'CelCash HTTP ' . $code . ' em ' . $url . ': ' . mb_substr((string)$raw, 0, 300), 'raw' => null];
    }

    $lista = is_array($resp) ? ($resp['Charges'] ?? $resp) : [];
    if (!is_array($lista)) $lista = [];
    $achado = null;
    foreach ($lista as $c) {
        if (is_array($c) && isset($c['galaxPayId']) && (int)$c['galaxPayId'] === $alvo) { $achado = $c; break; }
    }
    if ($achado === null) {
        return ['ok' => false, 'erro' => 'CelCash respondeu 200 em ' . $url . ' mas a cobrança galaxPayId=' . $alvo . ' não apareceu na janela pesquisada (pode ter mais desvio de posição do que o previsto).', 'raw' => $raw];
    }

    $parsed = ws_celcash_parse_resposta($achado);
    if (empty($parsed['pix_emv']) && empty($parsed['charge_id'])) {
        return ['ok' => false, 'erro' => 'CelCash devolveu a cobrança galaxPayId=' . $alvo . ' correta, mas sem PIX/ID reconhecível nela.', 'raw' => $raw];
    }
    return ['ok' => true] + $parsed + ['raw' => $raw];
}

/**
 * COMPLETA UMA FATURA IMPORTADA DO MK-AUTH com o PIX/boleto REAIS da cobrança já registrada na
 * Celcoin/GalaxPay — sem gerar cobrança nova nenhuma.
 *
 * POR QUE ISTO EXISTE — sintoma relatado: a fatura vinda da migração aparece com o selo "Galaxpay"
 * (tem celcash_charge_id), mas na hora de pagar (boleto.php) o sistema monta um PIX PRÓPRIO (chave
 * do provedor), não o PIX daquela cobrança. Resultado: quem paga esse QR paga DIRETO na conta do
 * provedor — nenhum evento chega na Celcoin, o webhook_celcash.php (a "página automática pela URL
 * de retorno") nunca é chamado, e a baixa não sai sozinha. A causa: a importação
 * (mkauth_boletos.php) só grava celcash_charge_id; pix_emv/pix_qr_url/boleto_url só nascem quando a
 * cobrança é CRIADA por aqui (financeiro.php?emitir=), caminho que um título migrado nunca passa.
 *
 * A correção NÃO cria cobrança nova (isso duplicaria a cobrança na Celcoin) — busca os dados da
 * MESMA cobrança que já existe lá (mesmo ID que veio no backup) e completa a fatura, UMA VEZ SÓ:
 * depois de gravado, pix_emv deixa de estar vazio e esta função para de rodar para essa fatura.
 * Título sem celcash_charge_id (nunca teve cobrança no gateway) e título que já tem pix_emv
 * (emitido por aqui mesmo) não são tocados — nada muda para quem já funcionava.
 *
 * Chamar só na hora de EXIBIR a fatura para pagamento (boleto.php) — nunca em lote sobre a base
 * toda, para não gerar milhares de chamadas à API de uma vez só numa migração grande.
 */
/**
 * TRAVA "cobrança de outro cliente" (caso Emilly Vitória, 02/11: o PIX/boleto saiu no nome de outra pessoa).
 * Procura no gateway_raw a cobrança cujo galaxPayId é o do título e compara o documento (CPF/CNPJ) do
 * Customer com o do cliente. false = PROVADO que a cobrança é de outro; true = confere ou não dá para provar.
 */
function ws_fatura_cobranca_confere(array $f, string $cpfCliente): bool {
    $chargeId = trim((string)($f['celcash_charge_id'] ?? ''));
    $cpf = preg_replace('/\D+/', '', $cpfCliente);
    if ($chargeId === '' || $cpf === '') return true;
    $j = json_decode((string)($f['gateway_raw'] ?? ''), true);
    if (!is_array($j)) return true;
    if (isset($j['Charges']) && is_array($j['Charges'])) $cands = $j['Charges'];
    elseif (isset($j['Charge']) && is_array($j['Charge'])) $cands = [$j['Charge']];
    elseif ($j && array_keys($j) === range(0, count($j) - 1)) $cands = $j;
    else $cands = [$j];
    foreach ($cands as $c) {
        if (!is_array($c) || (string)($c['galaxPayId'] ?? '') !== $chargeId) continue;
        $doc = preg_replace('/\D+/', '', (string)($c['Customer']['document'] ?? ''));
        return $doc === '' || $doc === $cpf;
    }
    return true;
}

/**
 * Se o título em aberto aponta para cobrança de OUTRO cliente: guarda backup, desvincula (zera os dados do
 * gateway) e registra no histórico — a fatura passa a sair com o PIX da chave própria, com o nome certo.
 * Título pago não é tocado. Devolve true se desvinculou ($f já atualizado em memória).
 */
function ws_fatura_cobranca_sanear(PDO $db, array &$f): bool {
    try {
        if (trim((string)($f['celcash_charge_id'] ?? '')) === '' || empty($f['id']) || empty($f['cliente_id'])) return false;
        if (!in_array((string)($f['status'] ?? 'aberto'), ['aberto', 'vencido'], true)) return false;
        $st = $db->prepare("SELECT cpf_cnpj FROM ws_cliente WHERE id=?"); $st->execute([(int)$f['cliente_id']]);
        $cpf = (string)$st->fetchColumn();
        if (!isset($f['gateway_raw'])) { $g = $db->prepare("SELECT gateway_raw FROM ws_fatura WHERE id=?"); $g->execute([(int)$f['id']]); $f['gateway_raw'] = (string)$g->fetchColumn(); }
        if (ws_fatura_cobranca_confere($f, $cpf)) return false;
        $q = $db->prepare("SELECT id,cliente_id,celcash_charge_id,celcash_my_id,nosso_numero,linha_digitavel,boleto_url,pix_emv,pix_qr_url,gateway_raw FROM ws_fatura WHERE id=?");
        $q->execute([(int)$f['id']]); $antes = $q->fetch(PDO::FETCH_ASSOC);
        $arq = WS_CACHE . '/cobranca_trocada_' . date('Ymd') . '.json';
        $lista = is_file($arq) ? (json_decode((string)@file_get_contents($arq), true) ?: []) : [];
        $lista[] = ['em' => date('c'), 'motivo' => 'cobrança de outro cliente (documento diferente)', 'antes' => $antes];
        @file_put_contents($arq, json_encode($lista, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $db->prepare("UPDATE ws_fatura SET celcash_charge_id=NULL, pix_emv=NULL, pix_qr_url=NULL, linha_digitavel=NULL, boleto_url=NULL, gateway_raw=NULL, nosso_numero=NULL WHERE id=? AND status IN ('aberto','vencido')")->execute([(int)$f['id']]);
        try { $db->prepare("INSERT INTO ws_evento (cliente_id, tipo, texto, criado_em) VALUES (?,?,?,NOW())")
                 ->execute([(int)$f['cliente_id'], 'sistema', 'Fatura #' . (int)$f['id'] . ' apontava para cobrança de OUTRO cliente no gateway; vínculo desfeito automaticamente (a fatura sai com o PIX da chave própria).']); } catch (Throwable $e) {}
        foreach (['celcash_charge_id', 'pix_emv', 'pix_qr_url', 'linha_digitavel', 'boleto_url', 'gateway_raw', 'nosso_numero'] as $k) $f[$k] = null;
        return true;
    } catch (Throwable $e) { return false; }
}

function ws_celcash_completar_importada(PDO $db, array &$f): void {
    ws_fatura_cobranca_sanear($db, $f);   // cobrança de outro cliente: desfaz ANTES de completar (senão puxaria os dados dela de novo)
    $chargeId = trim((string)($f['celcash_charge_id'] ?? ''));
    if ($chargeId === '' || trim((string)($f['pix_emv'] ?? '')) !== '') return; // nada a completar
    try {
        $r = ws_celcash_buscar_cobranca($chargeId);
    } catch (Throwable $e) {
        return; // nunca derruba a tela do boleto por causa disto — fica no PIX próprio como já estava
    }
    if (empty($r['ok']) || empty($r['pix_emv'])) return; // sem PIX na resposta: mantém o comportamento atual
    /* 14/11/2026: a trava "cobrança de outro cliente" (ws_fatura_cobranca_sanear) só enxergava o gateway_raw JÁ gravado — fatura importada sem ele passava
       e recebia aqui o PIX da cobrança buscada mesmo sendo de OUTRA pessoa (ex.: fatura #2, cliente 449, apontava para a cobrança 905 de outra escola).
       Agora o documento da cobrança buscada é conferido ANTES de gravar: de outro cliente = desvincula (backup + histórico) e não grava nada dela. */
    $f['gateway_raw'] = (string)($r['raw'] ?? '');
    if (ws_fatura_cobranca_sanear($db, $f)) return;

    $db->prepare("UPDATE ws_fatura SET
                    pix_emv = ?, pix_qr_url = ?,
                    boleto_url = COALESCE(NULLIF(boleto_url,''), ?),
                    linha_digitavel = COALESCE(NULLIF(linha_digitavel,''), ?),
                    gateway_raw = COALESCE(NULLIF(gateway_raw,''), ?)
                  WHERE id = ? AND (pix_emv IS NULL OR pix_emv = '')")
       ->execute([$r['pix_emv'], $r['pix_qr_url'], $r['boleto_url'] ?? null, $r['linha_digitavel'] ?? null, $r['raw'], (int)$f['id']]);

    // Atualiza em memória para a página atual (a que está sendo exibida agora) já sair certa, sem
    // precisar recarregar — quem chamou já tem $f com os campos novos daqui em diante.
    $f['pix_emv']    = $r['pix_emv'];
    $f['pix_qr_url'] = $r['pix_qr_url'];
    if (empty($f['boleto_url']))      $f['boleto_url']      = $r['boleto_url'] ?? $f['boleto_url'];
    if (empty($f['linha_digitavel'])) $f['linha_digitavel'] = $r['linha_digitavel'] ?? $f['linha_digitavel'];
}

/**
 * Extrai os campos de pagamento da resposta do CelCash.
 * DEFENSIVO: procura recursivamente por nomes conhecidos (v1 e v2),
 * porque a resposta vem aninhada em Charge/Transactions/Boleto/Pix.
 */
function ws_celcash_parse_resposta($resp): array {
    $out = ['charge_id' => null, 'linha_digitavel' => null, 'boleto_url' => null, 'pix_emv' => null, 'pix_qr_url' => null];
    if (!is_array($resp)) return $out;

    $achar = function ($chaves) use ($resp) {
        $chaves = (array)$chaves;
        $pilha = [$resp];
        while ($pilha) {
            $n = array_pop($pilha);
            if (!is_array($n)) continue;
            foreach ($n as $k => $v) {
                if (in_array((string)$k, $chaves, true) && (is_string($v) || is_numeric($v)) && $v !== '') return (string)$v;
                if (is_array($v)) $pilha[] = $v;
            }
        }
        return null;
    };

    $out['charge_id']       = $achar(['galaxPayId', 'chargeId', 'id']);
    // Linha digitável: a Celcoin real retorna Boleto.bankLine (também aceita variantes legadas).
    $out['linha_digitavel'] = $achar(['bankLine', 'digitableLine', 'boletoBankLine', 'typefulLine', 'linhaDigitavel']);
    // Código de barras real (44 dígitos): Celcoin retorna Boleto.barCode.
    $out['barcode']         = $achar(['barCode', 'barcodeNumber', 'codigoBarras']);
    $out['boleto_url']      = $achar(['pdf', 'boleto', 'urlBoleto', 'pdfUrl']);
    // PIX EMV: Celcoin retorna Pix.qrCode (ou Boleto.qrCode quando é boleto+PIX).
    $out['pix_emv']         = $achar(['emv', 'qrCode', 'qrCodePix', 'payload', 'pixQrCode']);
    $out['pix_qr_url']      = $achar(['image', 'imageQrCodePix', 'qrCodeImage', 'qrCodeUrl']);
    return $out;
}

/**
 * Endereço do webhook que deve ser colado no painel da CelCoin/GalaxPay.
 *
 * Devolve o que está configurado; se não houver nada, monta o padrão desta instalação a partir do
 * host da tela. O token vai junto na URL — é ele que o webhook_celcash.php confere.
 */
function ws_celcash_webhook_url(bool $comToken = true): string {
    $c = ws_celcash_config();
    $url = trim((string)($c['webhookUrl'] ?? ''));
    if ($url === '') {
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        /* Só usa a pasta quando o pedido veio mesmo da web: no cron/CLI o SCRIPT_NAME é o caminho
           do arquivo no disco e sairia um endereço sem sentido. */
        $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        /* Corta na última barra em vez de usar dirname(): no Windows o dirname devolve "\\" para
           "/financeiro.php" e a URL saía com uma barra invertida no meio. */
        $corte = strrpos($script, '/');
        $dir = ($script !== '' && $script[0] === '/' && $corte !== false) ? substr($script, 0, $corte) : '';
        $url  = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http')
              . '://' . $host . $dir . '/webhook_celcash.php';
    }
    if ($comToken && $c['webhookToken'] !== '' && strpos($url, 'token=') === false)
        $url .= (strpos($url, '?') === false ? '?' : '&') . 'token=' . rawurlencode($c['webhookToken']);
    return $url;
}

/** Valida o token do webhook recebido contra o configurado. */
function ws_celcash_webhook_valido(string $tokenRecebido): bool {
    $cfg = ws_celcash_config();
    return $cfg['webhookToken'] !== '' && hash_equals($cfg['webhookToken'], $tokenRecebido);
}
/** 14/11/2026: ID e myId da COBRANÇA num aviso (webhook) do GalaxPay/CelCoin. @return array [chargeId|null, myId|null]
 *  O "galaxPayId" do bloco Transaction é o da TRANSAÇÃO, não o da cobrança: na maioria das vezes os dois coincidem, mas não sempre (no log real, a transação
 *  40897 era da cobrança 40898 e a 40898 da 40897, em 03/11) — e a busca antiga, que pegava o primeiro "galaxPayId" que achasse, casava a fatura de OUTRO
 *  cliente. Ordem: Transaction.chargeGalaxPayId → Charge.galaxPayId → chargeGalaxPayId/chargeId em qualquer lugar; "galaxPayId" solto só em aviso sem os blocos. */
function ws_celcash_webhook_ids(array $payload): array {
    $tx = is_array($payload['Transaction'] ?? null) ? $payload['Transaction'] : (is_array($payload['data']['Transaction'] ?? null) ? $payload['data']['Transaction'] : []);
    $ch = is_array($payload['Charge'] ?? null) ? $payload['Charge'] : (is_array($payload['data']['Charge'] ?? null) ? $payload['data']['Charge'] : []);
    $val = function ($v) { return ((is_string($v) || is_numeric($v)) && (string)$v !== '') ? (string)$v : null; };
    $busca = function (array $chaves) use ($payload, $val) {   // mesma busca recursiva do webhook, só para formatos antigos
        $pilha = [$payload];
        while ($pilha) { $n = array_pop($pilha); if (!is_array($n)) continue;
            foreach ($n as $k => $v) { if (in_array((string)$k, $chaves, true) && $val($v) !== null) return $val($v); if (is_array($v)) $pilha[] = $v; } }
        return null;
    };
    $semBlocos = !$tx && !$ch;
    $chargeId = $val($tx['chargeGalaxPayId'] ?? null) ?? $val($ch['galaxPayId'] ?? null) ?? $busca(['chargeGalaxPayId', 'chargeId']) ?? ($semBlocos ? $busca(['galaxPayId']) : null);
    $myId = $val($tx['chargeMyId'] ?? null) ?? $val($ch['myId'] ?? null) ?? $busca(['chargeMyId']) ?? ($semBlocos ? $busca(['myId']) : null);
    return [$chargeId, $myId];
}
/** 14/11/2026: a fatura certa do aviso quando VÁRIAS faturas têm o mesmo ID de cobrança (carnê importado: uma cobrança com várias parcelas; 213 casos no 18).
 *  Antes valia "a primeira que vier" (LIMIT 1): o pagamento da parcela de dezembro da cobrança 32827 (fatura #7762, aberta) caía na #6907 (novembro, paga)
 *  e era ignorado como "já paga". Ordem: (1) a parcela cuja linha digitável é a do boleto pago (Transaction.Boleto.bankLine); (2) só as do cliente do aviso
 *  (Customer.document); (3) entre elas, a parcela em aberto mais antiga; sem nenhuma em aberto, a primeira. @param array $cands linhas de ws_fatura */
function ws_celcash_webhook_escolher(PDO $db, array $cands, array $payload): ?array {
    if (!$cands) return null;
    if (count($cands) === 1) return $cands[0];
    $tx = is_array($payload['Transaction'] ?? null) ? $payload['Transaction'] : (is_array($payload['data']['Transaction'] ?? null) ? $payload['data']['Transaction'] : []);
    $ch = is_array($payload['Charge'] ?? null) ? $payload['Charge'] : (is_array($payload['data']['Charge'] ?? null) ? $payload['data']['Charge'] : []);
    $bl = preg_replace('/\D/', '', (string)($tx['Boleto']['bankLine'] ?? ''));
    if (strlen($bl) >= 44) foreach ($cands as $f) if (preg_replace('/\D/', '', (string)($f['linha_digitavel'] ?? '')) === $bl) return $f;
    $doc = preg_replace('/\D/', '', (string)($ch['Customer']['document'] ?? ''));
    if ($doc !== '') {
        $ids = implode(',', array_map(fn($f) => (int)$f['cliente_id'], $cands));
        $docs = []; foreach ($db->query("SELECT id, cpf_cnpj FROM ws_cliente WHERE id IN ($ids)")->fetchAll(PDO::FETCH_ASSOC) as $c) $docs[(int)$c['id']] = preg_replace('/\D/', '', (string)$c['cpf_cnpj']);
        $doCliente = array_values(array_filter($cands, fn($f) => ($docs[(int)$f['cliente_id']] ?? '') === $doc));
        if ($doCliente) $cands = $doCliente;
    }
    $abertas = array_values(array_filter($cands, fn($f) => in_array((string)$f['status'], ['aberto', 'vencido', 'processando'], true)));
    if ($abertas) { usort($abertas, fn($a, $b) => strcmp((string)$a['vencimento'], (string)$b['vencimento']) ?: ((int)$a['id'] <=> (int)$b['id'])); return $abertas[0]; }
    return $cands[0];
}