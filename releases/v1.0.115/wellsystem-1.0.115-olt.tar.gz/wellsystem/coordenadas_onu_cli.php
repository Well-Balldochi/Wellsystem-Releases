<?php
/**
 * WellSystem — COORDENADAS DOS CLIENTES PELA ONU/ONT NO SMARTOLT (07/10/2026).
 *   php coordenadas_onu_cli.php           → aplica
 *   php coordenadas_onu_cli.php --teste   → só mostra o que faria (não grava)
 *
 * O SmartOLT guarda latitude/longitude de cada ONU. Mas muitas estão num PONTO PADRÃO (centenas de ONUs no mesmo lugar),
 * então só vale a coordenada da ONU que é CONFIÁVEL: ponto exclusivo dela ou de um grupo pequeno (≤ 16 ONUs = a CTO/caixa).
 * Casa ONU × contrato pelo serial (sn_onu do contrato), comparando sempre em HEX ("HWTC1234ABCD" = "485754431234ABCD").
 *
 * Quem recebe a coordenada da ONU:
 *   - cliente em PONTO REPETIDO (3+ clientes no mesmo ponto) ou sem coordenada;
 *   - cliente cuja coordenada foi achada PELO ENDEREÇO (coordenadas_corrigir) — a da ONU é melhor quando o ponto dela
 *     tem até 8 ONUs (exclusivo ou da caixa); a de rua/bairro vira a da ONU.
 * Coordenada ÚNICA que não veio do endereço (técnico "Estou no cliente", cadastro manual) NÃO é tocada.
 * Antes de gravar, guarda a anterior em cache/coord_backup.json (o "Desfazer" da tela Mapa → Corrigir coordenadas volta).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php';
@set_time_limit(0);
$teste = in_array('--teste', $argv, true);
$db = ws_db();

function co_hex(string $s): string {
    $s = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $s));
    if (preg_match('/^[A-Z]{4}[0-9A-F]{8}$/', $s)) return strtoupper(bin2hex(substr($s, 0, 4))) . substr($s, 4);
    return $s;
}
// credenciais do SmartOLT: as mesmas do módulo OLT (olt_huawei.php)
$src = (string)@file_get_contents(__DIR__ . '/olt_huawei.php');
preg_match('/\$smartolt_url\s*=\s*[\'"]([^\'"]+)/', $src, $mu); preg_match('/\$smartolt_token\s*=\s*[\'"]([^\'"]+)/', $src, $mt);
if (empty($mu[1]) || empty($mt[1])) exit("SmartOLT não configurado (olt_huawei.php).\n");
$ch = curl_init(rtrim($mu[1], '/') . '/api/onu/get_all_onus_details');
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 90, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_HTTPHEADER => ['X-Token: ' . $mt[1], 'Accept: application/json']]);
$j = json_decode((string)curl_exec($ch), true); curl_close($ch);
$lista = $j['onus'] ?? $j['response'] ?? $j['data'] ?? [];
if (!$lista) exit("SmartOLT não respondeu a lista de ONUs.\n");

$pts = []; $onu = [];
foreach ($lista as $o) {
    $la = (float)($o['latitude'] ?? 0); $lo = (float)($o['longitude'] ?? 0);
    if (!$la || !$lo || abs($la) > 90 || abs($lo) > 180) continue;
    $k = round($la, 5) . ',' . round($lo, 5); $pts[$k] = ($pts[$k] ?? 0) + 1;
    $onu[co_hex((string)($o['sn'] ?? ''))] = [$la, $lo, $k];
}
// clientes e o quanto a coordenada atual de cada um é confiável
$bk = json_decode((string)@file_get_contents(WS_CACHE . '/coord_backup.json'), true) ?: [];
$rows = $db->query("SELECT c.id, c.nome, c.lat, c.lng, ct.id ctid, ct.lat ctlat, ct.lng ctlng, ct.sn_onu
                    FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id=c.id AND ct.status<>'cancelado'
                    WHERE c.status NOT IN('cancelado','desativado') AND ct.sn_onu IS NOT NULL AND ct.sn_onu<>'' ORDER BY c.id")->fetchAll(PDO::FETCH_ASSOC);
$todos = $db->query("SELECT COALESCE(ct.lat,c.lat) la, COALESCE(ct.lng,c.lng) lo FROM ws_cliente c LEFT JOIN ws_contrato ct ON ct.cliente_id=c.id AND ct.status<>'cancelado'
                     WHERE c.status NOT IN('cancelado','desativado')")->fetchAll(PDO::FETCH_ASSOC);
$rep = []; foreach ($todos as $t) if ($t['la'] && $t['lo']) { $k = round((float)$t['la'], 5) . ',' . round((float)$t['lo'], 5); $rep[$k] = ($rep[$k] ?? 0) + 1; }

$ok = 0; $vistos = []; $motivos = ['sem ONU no SmartOLT' => 0, 'ponto padrão do SmartOLT' => 0, 'coordenada atual já é boa' => 0];
if ($teste) $db->beginTransaction();
foreach ($rows as $r) {
    if (isset($vistos[$r['id']])) continue; $vistos[$r['id']] = 1;
    $o = $onu[co_hex((string)$r['sn_onu'])] ?? null;
    if (!$o) { $motivos['sem ONU no SmartOLT']++; continue; }
    $tam = $pts[$o[2]];
    if ($tam > 16) { $motivos['ponto padrão do SmartOLT']++; continue; }
    $la0 = $r['ctlat'] ?: $r['lat']; $lo0 = $r['ctlng'] ?: $r['lng'];
    $repAtual = ($la0 && $lo0) ? ($rep[round((float)$la0, 5) . ',' . round((float)$lo0, 5)] ?? 0) : 0;
    $doEndereco = isset($bk[$r['id']]);   // coordenada atual veio da busca pelo endereço
    $troca = !$la0 || !$lo0 || $repAtual >= 3 || ($doEndereco && $tam <= 8);
    if (!$troca) { $motivos['coordenada atual já é boa']++; continue; }
    [$la, $lo] = [round($o[0], 7), round($o[1], 7)];
    if (!isset($bk[$r['id']])) $bk[$r['id']] = ['lat' => $r['lat'], 'lng' => $r['lng'], 'ctid' => $r['ctid'], 'ctlat' => $r['ctlat'], 'ctlng' => $r['ctlng']];
    $db->prepare("UPDATE ws_cliente SET lat=?, lng=? WHERE id=?")->execute([$la, $lo, (int)$r['id']]);
    $db->prepare("UPDATE ws_contrato SET lat=?, lng=? WHERE cliente_id=? AND status<>'cancelado'")->execute([$la, $lo, (int)$r['id']]);
    if (function_exists('ws_evento')) try { ws_evento($db, (int)$r['id'], 'cadastro', "Coordenada pela ONU/ONT do SmartOLT (" . ($tam === 1 ? 'ponto exclusivo' : "ponto da caixa, $tam ONUs") . "): $la, $lo — antes: $la0, $lo0."); } catch (Throwable $e) {}
    $ok++;
    echo "✔ {$r['nome']} — " . ($tam === 1 ? 'ponto exclusivo' : "caixa ($tam ONUs)") . "\n";
}
if ($teste) $db->rollBack();
else { @file_put_contents(WS_CACHE . '/coord_backup.json', json_encode($bk), LOCK_EX); @chmod(WS_CACHE . '/coord_backup.json', 0640); }
$fim = "FIM — coordenadas pela ONU: $ok" . ($teste ? ' (TESTE, nada gravado)' : '') . ' · ' . implode(' · ', array_map(fn($k, $v) => "$k: $v", array_keys($motivos), $motivos));
echo "$fim\n";
if (!$teste) @file_put_contents(WS_CACHE . '/coord_progresso.txt', date('d/m/Y H:i:s') . " — $fim\n", FILE_APPEND);
