<?php
/**
 * =================================================================================================
 * WellSystem — DIAGNÓSTICO DA OLT (tudo pela tela, sem PuTTY)
 * =================================================================================================
 * Reúne, numa página, as verificações usadas na investigação de 23/09/2026 — e que antes exigiam
 * comandos no servidor:
 *   • versão (assinatura md5) dos arquivos da OLT e cópias do sistema nas pastas conhecidas;
 *   • pasta do sistema, pastas de dados da OLT, data/hora, Apache (qual pasta cada site abre);
 *   • trava do Telnet (a OLT aceita 1 sessão por vez): livre/em uso, prioridade do operador;
 *   • quando a ficha leu a OLT pela última vez e o texto bruto do último "display ont info" sem perfil;
 *   • últimas autorizações: zona escolhida × zona no cadastro × zona que está NA OLT (lista);
 *   • VIGIA DE ZONA: trocas de zona detectadas depois da autorização (ex.: SmartOLT regravando);
 *   • busca por serial (cadastro nos 2 formatos, autorização, posição na OLT);
 *   • teste AO VIVO na OLT (pede a vez como operador e mostra o "display ont info").
 * SÓ LEITURA: nada aqui altera dado nenhum. RESTRITA AO ADMIN (mostra caminhos).
 * Os mesmos itens, como comando de terminal, estão em comandos.php (grupo "Diagnóstico").
 * =================================================================================================
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
ws_exigir_infra();
$admin = ($_SESSION['ws_user']['nivel'] ?? '') === 'admin';
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

// ---- pastas de dados da OLT (mesma regra do olt_huawei.php: cache_trafego da pasta; /tmp se não gravar) ----
$D = str_replace('\\', '/', (string)(realpath(__DIR__) ?: __DIR__));
$dirs = array_values(array_filter([$D . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'], 'is_dir'));
/** Lê o JSON mais NOVO entre as pastas de dados. */
$jl = function (string $nome) use ($dirs) { $best = null; $bt = -1;
    foreach ($dirs as $d) { $f = "$d/$nome"; if (is_file($f) && ($t = (int)filemtime($f)) >= $bt) { $x = json_decode((string)@file_get_contents($f), true); if (is_array($x)) { $best = $x; $bt = $t; } } }
    return $best ?? []; };
$mt = function (string $nome) use ($dirs) { $bt = 0; foreach ($dirs as $d) { $f = "$d/$nome"; if (is_file($f)) $bt = max($bt, (int)filemtime($f)); } return $bt; };
$quando = fn(int $t) => $t ? date('d/m/Y H:i:s', $t) . ' (' . ($s = time() - $t) . 's atrás' . ($s > 3600 ? ' — ' . round($s / 3600, 1) . 'h' : '') . ')' : '—';
$snNorm = fn($s) => strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s));
/** Serial nos 2 formatos: hex (48575443…) e fabricante (HWTC…). */
$snVar = function (string $sn) use ($snNorm): array {
    $sn = $snNorm($sn); if ($sn === '') return [];
    $v = [$sn];
    if (preg_match('/^([A-Z0-9]{4})([0-9A-F]{8})$/', $sn, $m) && preg_match('/[G-Z]/', $m[1])) array_unshift($v, strtoupper(bin2hex($m[1])) . $m[2]);
    elseif (preg_match('/^([0-9A-F]{8})([0-9A-F]{8})$/', $sn, $m)) { $t = @hex2bin($m[1]); if ($t !== false && preg_match('/^[A-Z0-9]{4}$/', $t)) $v[] = $t . $m[2]; }
    return array_values(array_unique($v)); };

// ---- lista de ONUs da OLT (cache) indexada pelo serial hex ----
$lista = $jl('olt_onus_cache.json'); $porSn = [];
foreach ((array)($lista['slots'] ?? []) as $arr) foreach ((array)$arr as $o) { $k = $snVar((string)($o['serial'] ?? ''))[0] ?? ''; if ($k !== '') $porSn[$k] = $o; }
$cad = $jl('olt_cadastro.json'); $aut = $jl('olt_autorizacoes.json');
$cadDe = function (string $sn) use ($cad, $snVar) { foreach ($snVar($sn) as $k) if (isset($cad[$k])) return ['chave' => $k] + (array)$cad[$k]; return null; };
$norm = fn($z) => mb_strtoupper(trim(preg_replace('/\s+/', ' ', (string)$z)), 'UTF-8');
?><!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Diagnóstico da OLT</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
.dg-g{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:12px 14px;margin:0 0 14px}
.dg-g h3{margin:0 0 8px;font-size:15px}
.dg-g table{width:100%;border-collapse:collapse;font-size:12.5px}
.dg-g td,.dg-g th{border-top:1px solid var(--border);padding:6px 8px;text-align:left;vertical-align:top}
.dg-g th{font-size:11px;text-transform:uppercase;color:var(--muted);border-top:0}
.dg-ok{color:#16a34a;font-weight:700}.dg-er{color:#dc2626;font-weight:700}.dg-av{color:#d97706;font-weight:700}
.dg-pre{margin:6px 0 0;padding:8px 10px;border-radius:8px;background:#0f172a;color:#e2e8f0;font-size:11.5px;line-height:1.45;max-height:360px;overflow:auto;white-space:pre-wrap;word-break:break-word}
.dg-nota{font-size:12px;color:var(--muted);margin:4px 0 8px;line-height:1.5}
.dg-form{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:4px 0 8px}
.dg-form input{max-width:260px}
.dg-wrap{overflow-x:auto}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('') ?></header>
<main class="ws-main">
<?php if (!$admin): ?>
  <div class="ws-card"><h2>🔎 Diagnóstico da OLT</h2><p class="ws-muted">Restrito ao administrador (mostra caminhos do servidor).</p>
  <a class="ws-btn" href="erp.php?p=dashboard">Voltar ao painel</a></div></main><?= ws_footer_bar() ?></body></html>
<?php exit; endif; ?>
<div class="ws-head-row"><h2>🔎 Diagnóstico da OLT</h2>
  <?php if (is_file(__DIR__ . '/comandos.php')): ?><a class="ws-btn" href="comandos.php">⌨️ Comandos</a> <?php endif; ?><a class="ws-btn" href="?">🔄 Atualizar</a></div>
<p class="dg-nota">Tudo aqui é <b>só leitura</b> — nenhum dado é alterado. Servidor: <?= $h(date('d/m/Y H:i:s')) ?> · pasta <code><?= $h($D) ?></code> · endereço <code><?= $h($_SERVER['HTTP_HOST'] ?? '') ?></code></p>

<?php // ================================================================ 1) VERSÃO DOS ARQUIVOS ?>
<section class="dg-g"><h3>📦 Versão dos arquivos (compare com as assinaturas do pacote enviado)</h3><div class="dg-wrap"><table>
<tr><th>Arquivo</th><th>md5</th><th>Modificado</th></tr>
<?php foreach (['olt_huawei.php', 'olt_ui.js', 'olt_nativo.php', 'olt.php', 'olt_auth.php', 'comandos.php', 'config.php', 'diagnostico_olt.php', 'erp.php', 'crm.php', 'financeiro.php'] as $a):
  $p = "$D/$a"; if (!is_file($p) && function_exists('ws_edicao') && ws_edicao() !== 'completo') continue;   /* edição isolada: não lista (nem acusa "não existe") arquivo de outro módulo */ ?>
<tr><td><?= $h($a) ?></td><td><code><?= is_file($p) ? $h(md5_file($p)) : '<span class="dg-er">não existe</span>' ?></code></td><td><?= is_file($p) ? $h(date('d/m/Y H:i:s', (int)filemtime($p))) : '' ?></td></tr>
<?php endforeach; ?></table></div></section>

<?php // ================================================================ 2) CÓPIAS / PASTAS ?>
<section class="dg-g"><h3>🗂️ Cópias do sistema e pastas de dados</h3>
<p class="dg-nota">Só a pasta em uso (acima) precisa estar atualizada. Pacotes de instalação e backups de versão aparecem aqui também — é normal.</p>
<div class="dg-wrap"><table><tr><th>olt_huawei.php encontrado em</th><th>md5</th><th>Modificado</th></tr>
<?php $cands = array_merge(glob('/var/www/*/olt_huawei.php') ?: [], glob('/var/www/html/*/olt_huawei.php') ?: [], glob('/opt/mk-auth/admin/addons/*/olt_huawei.php') ?: [],
        glob('/opt/*/olt_huawei.php') ?: [], glob('/opt/olt_huawei.php') ?: [], glob('/root/wellsystem/olt_huawei.php') ?: [], glob('/home/*/wellsystem/olt_huawei.php') ?: [], glob('/tmp/ws-pacote/*/olt_huawei.php') ?: []);
  $vistos = [];
  foreach ($cands as $f) { $r = realpath($f) ?: $f; if (isset($vistos[$r])) continue; $vistos[$r] = 1; ?>
<tr><td><code><?= $h($r) ?></code><?= dirname($r) === $D ? ' <span class="dg-ok">← em uso</span>' : '' ?></td><td><code><?= $h(@md5_file($r) ?: '?') ?></code></td><td><?= $h(@date('d/m/Y H:i', (int)@filemtime($r))) ?></td></tr>
<?php } if (!$vistos): ?><tr><td colspan="3" class="dg-nota">Sem permissão para listar outras pastas (normal no addon). Use o comando "Achar todas as cópias" na página Comandos.</td></tr><?php endif; ?>
</table></div>
<p class="dg-nota" style="margin-top:8px"><b>Pastas de dados da OLT:</b>
<?php foreach ([$D . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'] as $d): ?>
  <br><code><?= $h($d) ?></code> — <?= is_dir($d) ? (is_writable($d) ? '<span class="dg-ok">existe, gravável</span>' : '<span class="dg-av">existe, sem gravação</span>') : 'não existe' ?>
<?php endforeach; ?></p>
<?php $apache = []; foreach (glob('/etc/apache2/sites-enabled/*.conf') ?: [] as $cf) { foreach (preg_split('/\r?\n/', (string)@file_get_contents($cf)) as $ln) if (preg_match('/^\s*(ServerName|ServerAlias|DocumentRoot|<VirtualHost)\b/i', $ln)) $apache[] = basename($cf) . ': ' . trim($ln); }
if ($apache): ?><p class="dg-nota"><b>Apache (qual pasta cada site abre):</b></p><pre class="dg-pre"><?= $h(implode("\n", $apache)) ?></pre><?php endif; ?>
</section>

<?php // ================================================================ 3) TRAVA / LEITURAS ?>
<section class="dg-g"><h3>🔒 OLT: trava do Telnet e leituras</h3>
<p class="dg-nota">A OLT aceita <b>uma sessão por vez</b> por usuário. Ações do operador (ficha, autorizar, trocar VLAN) passam na frente das leituras automáticas.</p>
<div class="dg-wrap"><table><tr><th>Item</th><th>Situação</th></tr>
<?php foreach ($dirs as $d) foreach (glob("$d/olt_telnet_*.lock") ?: [] as $lk):
  $fp = @fopen($lk, 'c'); $livre = $fp && @flock($fp, LOCK_EX | LOCK_NB); if ($livre) @flock($fp, LOCK_UN); if ($fp) @fclose($fp); ?>
<tr><td>Trava do Telnet <code><?= $h(basename($lk)) ?></code></td><td><?= $livre ? '<span class="dg-ok">livre agora</span>' : '<span class="dg-av">em uso agora (uma consulta está na OLT)</span>' ?></td></tr>
<?php endforeach;
foreach ($dirs as $d) foreach (glob("$d/olt_prio_*.flag") ?: [] as $pf): ?>
<tr><td>Último pedido com prioridade do operador</td><td><?= $h($quando((int)filemtime($pf))) ?></td></tr>
<?php endforeach; ?>
<tr><td>Ficha: última leitura gravada (olt_onu_detalhe.json)</td><td><?php $t = $mt('olt_onu_detalhe.json'); echo $h($quando($t)); if ($t && time() - $t > 7200) echo ' <span class="dg-av">— antiga: a ficha pode não estar conseguindo a vez na OLT</span>'; ?></td></tr>
<tr><td>Lista de ONUs: última varredura</td><td><?= $h($quando((int)($lista['ts'] ?? 0))) ?></td></tr>
<tr><td>Pendentes (autofind): última leitura</td><td><?= $h($quando($mt('olt_autofind.json'))) ?></td></tr>
<?php $ps = function_exists('shell_exec') ? (string)@shell_exec('ps -eo pid,etimes,cmd 2>/dev/null | grep -Ei "olt|cron_scan|php" | grep -v grep | head -20') : ''; ?>
<tr><td>Processos ligados à OLT (pid · segundos rodando · comando)</td><td><?= trim($ps) !== '' ? '<pre class="dg-pre" style="margin:0">' . $h(trim($ps)) . '</pre>' : '<span class="dg-nota">não disponível para o usuário do site</span>' ?></td></tr>
</table></div>
<?php $raw = ''; foreach ($dirs as $d) if (is_file("$d/olt_ultimo_ont_info.txt")) $raw = (string)@file_get_contents("$d/olt_ultimo_ont_info.txt");
if ($raw !== ''): ?><p class="dg-nota" style="margin-top:8px"><b>Último "display ont info" em que o perfil NÃO foi reconhecido</b> (mande este texto para ajustar a leitura):</p><pre class="dg-pre"><?= $h($raw) ?></pre><?php endif; ?>
</section>

<?php // ================================================================ 4) AUTORIZAÇÕES × ZONA ?>
<section class="dg-g"><h3>🗺️ Últimas autorizações: zona escolhida × cadastro × gravada na OLT</h3>
<p class="dg-nota">"Na OLT" = zona lida da descrição da ONU na última varredura. Diferente da escolhida = alguém regravou depois (ex.: SmartOLT). O cadastro é o que a lista mostra.</p>
<div class="dg-wrap"><table><tr><th>Data</th><th>Cliente</th><th>Serial</th><th>Posição</th><th>Escolhida</th><th>Cadastro</th><th>Na OLT</th><th></th></tr>
<?php $ult = $aut; uasort($ult, fn($x, $y) => strcmp((string)($y['data'] ?? ''), (string)($x['data'] ?? '')));
foreach (array_slice($ult, 0, 12, true) as $k => $v):
  $sn = $snNorm($v['sn'] ?? $k); $hx = $snVar($sn)[0] ?? $sn; $c = $cadDe($sn); $l = $porSn[$hx] ?? null;
  $zA = (string)($v['zona'] ?? ''); $zC = (string)($c['zona'] ?? ''); $zO = (string)($l['zona'] ?? '');
  $okC = $norm($zA) === $norm($zC); $okO = $zO === '' || $norm($zA) === $norm($zO); ?>
<tr><td><?= $h(substr((string)($v['data'] ?? ''), 0, 16)) ?></td><td><?= $h($v['nome'] ?? '') ?></td><td><code><?= $h($hx) ?></code></td>
  <td><?= $h(($v['fsp'] ?? '') . ' · ID ' . ($v['ont_id'] ?? '?')) ?></td><td><?= $h($zA) ?></td>
  <td class="<?= $okC ? '' : 'dg-er' ?>"><?= $h($zC !== '' ? $zC : '(nada)') ?></td><td class="<?= $okO ? '' : 'dg-er' ?>"><?= $h($zO !== '' ? $zO : '—') ?></td>
  <td><a href="?sn=<?= $h($hx) ?>#busca">ver</a></td></tr>
<?php endforeach; ?></table></div></section>

<?php // ================================================================ 5) VIGIA DE ZONA ?>
<section class="dg-g"><h3>👁️ Vigia de zona (trocas depois da autorização)</h3>
<p class="dg-nota">A varredura automática compara, nas ONUs autorizadas nas últimas 24h, a zona gravada na OLT com a escolhida na autorização. Cada troca fica registrada aqui.</p>
<?php $ev = array_values(array_filter((array)($jl('olt_relatorio.json')['eventos'] ?? []), fn($e) => ($e['tipo'] ?? '') === 'zona_divergente'));
if (!$ev): ?><p class="dg-ok" style="font-size:13px">Nenhuma troca de zona detectada.</p>
<?php else: ?><div class="dg-wrap"><table><tr><th>Quando</th><th>Posição</th><th>O que aconteceu</th></tr>
<?php foreach (array_slice($ev, 0, 30) as $e): ?><tr><td><?= $h($e['data'] ?? '') ?></td><td><?= $h($e['fsp'] ?? '') ?></td><td><?= $h($e['desc'] ?? '') ?></td></tr><?php endforeach; ?>
</table></div><?php endif; ?></section>

<?php // ================================================================ 6) BUSCA POR SERIAL ?>
<section class="dg-g" id="busca"><h3>🔍 Buscar uma ONU pelo serial</h3>
<form class="dg-form" method="get" action="#busca"><input name="sn" value="<?= $h($_GET['sn'] ?? '') ?>" placeholder="serial (inteiro ou os 8 últimos)"><button class="ws-btn">Buscar</button></form>
<?php $q = $snNorm($_GET['sn'] ?? '');
if ($q !== ''):
  $achouCad = []; foreach ((array)$cad as $k => $v) if (stripos((string)$k, substr($q, -8)) !== false) $achouCad[$k] = $v;
  $achouAut = []; foreach ((array)$aut as $k => $v) if (stripos((string)$k, substr($q, -8)) !== false || stripos((string)($v['sn'] ?? ''), substr($q, -8)) !== false) $achouAut[$k] = $v;
  $achouLst = []; foreach ($porSn as $k => $o) if (stripos((string)$k, substr($q, -8)) !== false) $achouLst[$k] = $o; ?>
  <p class="dg-nota"><b>Cadastro local</b> (<?= count($achouCad) ?> entrada(s)<?= count($achouCad) > 1 ? ' — <span class="dg-av">mais de uma: formatos diferentes do mesmo serial</span>' : '' ?>):</p>
  <pre class="dg-pre"><?= $h($achouCad ? json_encode($achouCad, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : '(nenhuma)') ?></pre>
  <p class="dg-nota"><b>Registro da autorização:</b></p><pre class="dg-pre"><?= $h($achouAut ? json_encode($achouAut, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : '(nenhum — não foi autorizada por este sistema)') ?></pre>
  <p class="dg-nota"><b>Na lista da OLT (última varredura):</b></p><pre class="dg-pre"><?= $h($achouLst ? json_encode($achouLst, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : '(não encontrada)') ?></pre>
  <?php $l1 = $achouLst ? reset($achouLst) : null; if ($l1 && !empty($l1['fsp'])): ?>
  <p class="dg-nota">Teste ao vivo desta ONU: <a class="ws-btn" href="?fsp=<?= $h($l1['fsp']) ?>&id=<?= $h($l1['id'] ?? '') ?>#vivo">▶ Ler agora na OLT</a></p>
  <?php endif; endif; ?></section>

<?php // ================================================================ 7) TESTE AO VIVO ?>
<section class="dg-g" id="vivo"><h3>🛰️ Teste ao vivo na OLT</h3>
<p class="dg-nota">Pede a vez na OLT como operador e roda o "display ont info" da ONU: mostra o tempo de espera, o erro (se houver), o perfil lido e o texto bruto (linha <b>Description</b> = zona gravada NA OLT).</p>
<form class="dg-form" method="get" action="#vivo"><input name="fsp" value="<?= $h($_GET['fsp'] ?? '') ?>" placeholder="placa/porta ex.: 0/1/2" style="max-width:160px"><input name="id" value="<?= $h($_GET['id'] ?? '') ?>" placeholder="ID ex.: 11" style="max-width:90px"><button class="ws-btn">Ler agora</button></form>
<?php $tf = preg_replace('/[^0-9\/]/', '', (string)($_GET['fsp'] ?? '')); $ti = preg_replace('/\D/', '', (string)($_GET['id'] ?? ''));
if ($tf !== '' && $ti !== ''): ?>
  <div id="dgVivo" class="dg-nota">⏳ Consultando a OLT (pode levar até 1 minuto)…</div>
  <script>
  fetch('olt_huawei.php?acao=diag_origem&fsp=<?= rawurlencode($tf) ?>&id=<?= rawurlencode($ti) ?>').then(function(r){ return r.json(); }).then(function(d){
    var t=(d&&d.teste_ao_vivo)||null, el=document.getElementById('dgVivo'); if(!el) return;
    if(!t){ el.innerHTML='<span class="dg-er">Sem resposta do teste (sessão expirada ou OLT não configurada).</span>'; return; }
    var esc=function(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); };
    var desc=(String(t.saida_bruta||'').match(/Description\s*:\s*([^\r\n]*)/i)||[])[1]||'';
    el.innerHTML=t.ok
      ? '<span class="dg-ok">OK em '+t.segundos+'s</span> · usuário da OLT: <b>'+esc(d.usuario_olt)+'</b> · perfil: <b>'+esc(t.perfil_linha)+' / '+esc(t.perfil_servico)+'</b> · online há '+esc(t.uptime)+(desc?'<br>Descrição NA OLT: <b>'+esc(desc)+'</b>':'')+'<pre class="dg-pre">'+esc(t.saida_bruta)+'</pre>'
      : '<span class="dg-er">Falhou em '+t.segundos+'s: '+esc(t.erro)+'</span>';
  }).catch(function(){ var el=document.getElementById('dgVivo'); if(el) el.innerHTML='<span class="dg-er">Erro ao consultar.</span>'; });
  </script>
<?php endif; ?></section>
</main>
<?= ws_footer_bar() ?>
</body></html>
