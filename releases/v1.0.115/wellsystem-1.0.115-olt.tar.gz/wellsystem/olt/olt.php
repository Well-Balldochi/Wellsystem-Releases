<?php
// OLT unificada: a Gerência OLT mora na RAIZ do WellSystem (olt.php), com o mesmo backend e o
// mesmo cache do Aprovisionamento e do cron. Esta cópia só leva quem tem o link antigo para lá.
$qs = (string)($_SERVER['QUERY_STRING'] ?? '');
header('Location: ../olt.php' . ($qs !== '' ? '?' . $qs : ''), true, 302);
exit;
