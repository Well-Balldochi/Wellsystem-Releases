<?php
// OLT unificada: autenticação da OLT é a da RAIZ (mesmos usuários e sessão).
require_once dirname(__DIR__) . '/olt_auth.php';
