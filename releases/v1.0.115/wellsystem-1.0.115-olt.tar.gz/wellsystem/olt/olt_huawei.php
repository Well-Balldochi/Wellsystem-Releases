<?php
// OLT unificada: o backend é um só, o da RAIZ (mesmo cache do Aprovisionamento e do cron).
// Quem ainda chama por olt/olt_huawei.php é atendido por ele.
require dirname(__DIR__) . '/olt_huawei.php';
