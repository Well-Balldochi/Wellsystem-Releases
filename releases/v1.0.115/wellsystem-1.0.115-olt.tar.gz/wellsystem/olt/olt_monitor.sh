#!/bin/sh
# OLT unificada: o monitor é um só, o da RAIZ do WellSystem (mesmo cache da tela). Este arquivo
# só repassa — um crontab antigo apontando para cá continua funcionando, e a trava do monitor
# impede que rode em dobro com o cron do sistema.
D="$(dirname "$(readlink -f "$0" 2>/dev/null || echo "$0")")"
exec sh "$D/../olt_monitor.sh" "$@"
