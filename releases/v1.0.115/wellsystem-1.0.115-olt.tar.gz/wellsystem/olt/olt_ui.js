// OLT unificada: a interface é a da RAIZ do WellSystem. Esta cópia só carrega a de lá.
document.write('<script src="../olt_ui.js"><\/script>');
