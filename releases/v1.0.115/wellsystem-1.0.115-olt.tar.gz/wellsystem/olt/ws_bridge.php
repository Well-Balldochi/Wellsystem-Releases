<?php
/**
 * WellSystem OLT — Ponte para o CRM WellSystem (espelho SN -> contrato).
 *
 * Ao AUTORIZAR uma ONU, este helper avisa o WellSystem (olt_bridge.php) o SN + nome,
 * e o CRM vincula o SN ao contrato do cliente. É BEST-EFFORT: se não estiver configurado
 * ou o CRM não responder, NÃO atrapalha em nada a autorização da OLT.
 *
 * CONFIG (crie o arquivo cache_trafego/ws_bridge.json):
 *   { "ativo": true, "url": "https://SEU_CRM/wellsystem/olt_bridge.php", "token": "MESMO_olt_token_do_wellsystem_db.json" }
 *
 * Nada aqui roda se o arquivo não existir ou "ativo" for false.
 */

/** Caminho do config da ponte (usa a pasta de cache do addon). */
function ws_bridge_cfg_path() {
    if (function_exists('olt_cache_dir')) return olt_cache_dir() . '/ws_bridge.json';
    return __DIR__ . '/cache_trafego/ws_bridge.json';
}

/** Lê a config da ponte (ou null se desativada/inexistente). */
function ws_bridge_cfg() {
    $f = ws_bridge_cfg_path();
    if (!is_file($f)) return null;
    $c = json_decode((string)@file_get_contents($f), true);
    if (!is_array($c) || empty($c['ativo']) || empty($c['url']) || empty($c['token'])) return null;
    return $c;
}

/** POST simples com timeout curto; devolve [ok, resposta_array|null]. */
function ws_bridge_post(array $c, array $campos) {
    if (!function_exists('curl_init')) return [false, null];
    $campos['token'] = $c['token'];
    $ch = curl_init($c['url']);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($campos),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_SSL_VERIFYPEER => false,   // muitos provedores usam cert interno
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [($code >= 200 && $code < 300), $raw ? json_decode($raw, true) : null];
}

/**
 * Avisa o WellSystem que um SN foi autorizado (vincula ao contrato).
 * Nunca lança exceção — é chamado dentro do fluxo de autorização.
 */
function ws_olt_notificar_bridge($sn, $nome, $zona = '') {
    try {
        $c = ws_bridge_cfg();
        if (!$c) return false;
        [$ok] = ws_bridge_post($c, ['acao' => 'set_sn', 'sn' => $sn, 'nome' => $nome, 'zona' => $zona]);
        return $ok;
    } catch (Throwable $e) { return false; }
}

/**
 * Consulta o WellSystem QUEM é o cliente de um SN (nome/plano/status/financeiro).
 * Para uso futuro na tela da ONU. Devolve array do CRM ou null.
 */
function ws_olt_cliente_por_sn($sn) {
    try {
        $c = ws_bridge_cfg();
        if (!$c) return null;
        [$ok, $resp] = ws_bridge_post($c, ['acao' => 'cliente_por_sn', 'sn' => $sn]);
        return ($ok && is_array($resp) && !empty($resp['ok'])) ? $resp : null;
    } catch (Throwable $e) { return null; }
}
