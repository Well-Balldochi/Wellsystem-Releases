<?php
/**
 * WellSystem — Ponte OLT ↔ contrato (API para o addon da OLT).
 *
 * O addon `wellsystem_olt` chama esta API para:
 *   - vincular o SN da ONU ao contrato (ao autorizar/editar a ONU);
 *   - descobrir QUEM é o cliente de um SN (nome, plano, status, financeiro) p/ mostrar na tela da OLT.
 *
 * Auth por token: defina "olt_token" em cache/wellsystem_db.json e envie ?token=... (ou header X-Olt-Token).
 * Assim o addon atual passa a "enxergar" o WellSystem sem depender do MK-Auth.
 *
 * Endpoints (GET/POST, JSON):
 *   ?acao=set_sn&login=LOGIN&sn=SERIAL         → grava sn_onu no contrato do login
 *   ?acao=set_sn&contrato_id=ID&sn=SERIAL      → idem por id
 *   ?acao=cliente_por_sn&sn=SERIAL             → dados do cliente/contrato/financeiro
 *   ?acao=cliente_por_login&login=LOGIN        → idem por login PPPoE
 */
require __DIR__ . '/config.php';

// --- auth ---
$cfg = ws_db_config();
$tok = $cfg['olt_token'] ?? '';
$rec = $_GET['token'] ?? $_POST['token'] ?? $_SERVER['HTTP_X_OLT_TOKEN'] ?? '';
if ($tok === '' || !hash_equals($tok, (string)$rec)) { http_response_code(403); ws_json(['ok' => false, 'erro' => 'token inválido']); }

$db = ws_db();
$acao = $_REQUEST['acao'] ?? '';

/** Monta o retorno padrão de um contrato + cliente + financeiro. */
function olt_ficha(PDO $db, array $ct): array {
    $fin = $db->prepare("SELECT
            SUM(status IN('aberto','vencido','processando') AND vencimento < CURDATE()) vencidas,
            SUM(status IN('aberto','vencido','processando')) em_aberto
        FROM ws_fatura WHERE contrato_id=?");
    $fin->execute([$ct['id']]); $f = $fin->fetch();
    $plano = null;
    if ($ct['plano_id']) { $p = $db->prepare("SELECT nome FROM ws_plano WHERE id=?"); $p->execute([$ct['plano_id']]); $plano = $p->fetchColumn(); }
    $cli = $db->prepare("SELECT nome,cpf_cnpj,celular,email FROM ws_cliente WHERE id=?");
    $cli->execute([$ct['cliente_id']]); $c = $cli->fetch() ?: [];
    $inadimplente = (int)($f['vencidas'] ?? 0) > 0;
    return [
        'ok' => true,
        'contrato_id' => (int)$ct['id'],
        'login_pppoe' => $ct['login_pppoe'],
        'sn_onu' => $ct['sn_onu'],
        'zona' => $ct['zona'],
        'status' => $ct['status'],
        'plano' => $plano,
        'cliente' => $c,
        'financeiro' => [
            'em_aberto' => (int)($f['em_aberto'] ?? 0),
            'vencidas' => (int)($f['vencidas'] ?? 0),
            'inadimplente' => $inadimplente,
        ],
    ];
}

switch ($acao) {
    case 'set_sn':
        $sn = trim($_REQUEST['sn'] ?? '');
        if ($sn === '') ws_json(['ok' => false, 'erro' => 'sn vazio']);
        if (!empty($_REQUEST['contrato_id'])) {
            $db->prepare("UPDATE ws_contrato SET sn_onu=? WHERE id=?")->execute([$sn, (int)$_REQUEST['contrato_id']]);
            ws_json(['ok' => true, 'sn' => $sn, 'via' => 'contrato_id']);
        } elseif (!empty($_REQUEST['login'])) {
            $db->prepare("UPDATE ws_contrato SET sn_onu=? WHERE login_pppoe=?")->execute([$sn, trim($_REQUEST['login'])]);
            ws_json(['ok' => true, 'sn' => $sn, 'via' => 'login']);
        } elseif (!empty($_REQUEST['nome'])) {
            // Casa pelo NOME do cliente (vindo da autorização da OLT). Só aplica se houver
            // EXATAMENTE 1 contrato daquele cliente sem SN — senão pede vínculo manual (seguro).
            $nome = trim($_REQUEST['nome']);
            $st = $db->prepare("SELECT ct.id FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                                WHERE LOWER(c.nome)=LOWER(?) AND (ct.sn_onu IS NULL OR ct.sn_onu='')");
            $st->execute([$nome]); $ids = $st->fetchAll(PDO::FETCH_COLUMN);
            if (count($ids) === 1) {
                $db->prepare("UPDATE ws_contrato SET sn_onu=? WHERE id=?")->execute([$sn, (int)$ids[0]]);
                $cid = $db->prepare("SELECT cliente_id FROM ws_contrato WHERE id=?"); $cid->execute([(int)$ids[0]]);
                if (function_exists('ws_evento')) ws_evento($db, (int)$cid->fetchColumn(), 'olt', "ONU $sn vinculada (autorização OLT)");
                ws_json(['ok' => true, 'sn' => $sn, 'via' => 'nome', 'contrato_id' => (int)$ids[0]]);
            }
            ws_json(['ok' => false, 'erro' => count($ids) ? 'nome com vários contratos sem SN — vincule manual' : 'nenhum contrato sem SN p/ esse nome', 'via' => 'nome', 'encontrados' => count($ids)]);
        } else ws_json(['ok' => false, 'erro' => 'informe contrato_id, login ou nome']);

    case 'cliente_por_sn':
        $st = $db->prepare("SELECT * FROM ws_contrato WHERE sn_onu=? LIMIT 1");
        $st->execute([trim($_REQUEST['sn'] ?? '')]); $ct = $st->fetch();
        ws_json($ct ? olt_ficha($db, $ct) : ['ok' => false, 'erro' => 'SN não vinculado a nenhum contrato']);

    case 'cliente_por_login':
        $st = $db->prepare("SELECT * FROM ws_contrato WHERE login_pppoe=? LIMIT 1");
        $st->execute([trim($_REQUEST['login'] ?? '')]); $ct = $st->fetch();
        ws_json($ct ? olt_ficha($db, $ct) : ['ok' => false, 'erro' => 'login não encontrado']);

    default:
        ws_json(['ok' => false, 'erro' => 'ação inválida', 'acoes' => ['set_sn', 'cliente_por_sn', 'cliente_por_login']]);
}
