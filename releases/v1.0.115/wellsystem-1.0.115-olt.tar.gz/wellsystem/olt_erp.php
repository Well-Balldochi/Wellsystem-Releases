<?php
/**
 * WellSystem ERP — Aba OLT: unificação com o addon (autorizações → cadastro automático).
 * Lê as ONUs autorizadas no addon e permite criar o cliente já preenchido (nome, VLAN, zona, SN, ONT-ID, endereço).
 * Reaproveita a sessão do erp.php.
 */
require __DIR__ . '/config.php';
require __DIR__ . '/olt_link.php';
require __DIR__ . '/olt_nativo.php';
if (is_file(__DIR__ . '/olt_unificar.php')) { require_once __DIR__ . '/olt_unificar.php'; olt_unificar_cache(__DIR__); }

/**
 * AUTO-CONECTAR nesta página — a MESMA preferência da página autônoma da OLT.
 *
 * A caixa de marcar é montada pelo olt_ui.js (card Aprovisionamento), então aparece igual aqui e
 * na olt.php. O que faltava era o outro lado: esta página não lia nem gravava a preferência, e o
 * card acabava sempre marcado. Grava no MESMO arquivo que a olt.php usa
 * (<módulo>/cache_trafego/olt_autoconnect.json), senão seriam duas preferências para a mesma coisa.
 *
 * Depois de gravar, volta para a própria URL SEM o parâmetro — recarregar a página não pode
 * regravar a preferência sem parar.
 */
function ws_olt_autoconn_arquivo(): string {
    $base = function_exists('ws_olt_base') ? (ws_olt_base() ?? '') : '';
    foreach ([__DIR__ . '/' . $base . 'cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'] as $d) {
        if (!is_dir($d)) @mkdir($d, 0777, true);
        if (is_dir($d) && is_writable($d)) return $d . '/olt_autoconnect.json';
    }
    return __DIR__ . '/' . $base . 'cache_trafego/olt_autoconnect.json';
}
function ws_olt_autoconn(): bool {
    $f = ws_olt_autoconn_arquivo();
    if (isset($_GET['autoconnect'])) {
        @file_put_contents($f, json_encode(['auto' => ($_GET['autoconnect'] === '1')])); @chmod($f, 0666);
        $qs = $_GET; unset($qs['autoconnect']);
        $url = basename((string)($_SERVER['SCRIPT_NAME'] ?? 'olt_erp.php')) . ($qs ? '?' . http_build_query($qs) : '');
        header('Location: ' . $url, true, 302); exit;
    }
    if (is_file($f)) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (is_array($j) && array_key_exists('auto', $j)) return (bool)$j['auto'];
    }
    return true;   // padrão: ligado, igual à página autônoma
}

/**
 * Onde está o módulo da OLT (olt_ui.js + olt_huawei.php)?
 *
 * O padrão do projeto é a RAIZ da pasta do WellSystem. Mas em muitas instalações ele fica em
 * `olt/`, e o Menu OLT acusava "módulo ausente" mesmo com tudo instalado. Procurar nos dois
 * lugares evita duplicar 650 KB de JavaScript só para satisfazer um caminho — e duas cópias do
 * mesmo arquivo é justamente o tipo de coisa que faz uma correção "não aparecer" depois.
 *
 * @return string '' quando está na raiz, 'olt/' quando está na subpasta, null quando não existe.
 */
function ws_olt_base(): ?string {
    static $base = false;
    if ($base !== false) return $base;
    foreach (['', 'olt/'] as $p) {
        if (is_file(__DIR__ . '/' . $p . 'olt_ui.js') && is_file(__DIR__ . '/' . $p . 'olt_huawei.php')) {
            return $base = $p;
        }
    }
    return $base = null;
}

/** O módulo da OLT está instalado (na raiz ou em olt/)? */
if (!function_exists('ws_olt_disponivel')) {
    function ws_olt_disponivel(): bool { return ws_olt_base() !== null; }
}

/**
 * Configuração e logo do módulo OLT — leitura direta dos MESMOS arquivos que o Painel dos
 * Concentradores usa (cache_trafego/wellsystem_config.json e wellsystem_logo_olt.txt).
 *
 * Existe porque ws_cfg() e ws_logo() moram no servidores.php, que não é carregado aqui. Sem
 * essas variáveis o olt_ui.js monta o card com logo genérica e links de cadastro quebrados —
 * o mesmo módulo se comportando diferente conforme a página que o abre.
 */
if (!function_exists('ws_olt_cache_dir')) {
    function ws_olt_cache_dir(): string {
        foreach ([__DIR__ . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'] as $d) {
            if (is_dir($d)) return $d;
        }
        return __DIR__ . '/cache_trafego';
    }
}
if (!function_exists('ws_olt_cfg')) {
    function ws_olt_cfg(): array {
        $f = ws_olt_cache_dir() . '/wellsystem_config.json';
        $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
        $c = is_array($j) ? $j : [];
        // Mesma detecção automática do Painel: sem "servidor web" configurado, vale o host que
        // está servindo esta página. Sem isto, esta tela montava links com endereço vazio.
        if (trim((string)($c['servidor_web'] ?? '')) === '' && function_exists('ws_servidor_web_auto')) {
            $c['servidor_web'] = ws_servidor_web_auto();
        }
        return $c;
    }
}
if (!function_exists('ws_olt_logo')) {
    function ws_olt_logo(): string {
        $f = ws_olt_cache_dir() . '/wellsystem_logo_olt.txt';
        return is_file($f) ? trim((string)@file_get_contents($f)) : '';
    }
}

if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$db = ws_db();
$p  = $_GET['p'] ?? 'painel';

/* ------------------------------------------------------- AJAX NATIVO (sem depender de addon externo) */
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');
    switch ($_GET['ajax']) {
        case 'autofind':
            try { echo json_encode(ws_olt_autofind($db, !empty($_GET['force'])), JSON_UNESCAPED_UNICODE); }
            catch (Throwable $e) { echo json_encode(['status' => 'error', 'message' => $e->getMessage()]); }
            break;
        case 'autorizar':
            echo json_encode(ws_olt_autorizar($db, $_POST), JSON_UNESCAPED_UNICODE);
            break;
        case 'onu_acao':
            $tipoAcao = (string)($_POST['tipo'] ?? '');
            $rAcao = ws_olt_onu_acao($db, (string)($_POST['fsp'] ?? ''), (int)($_POST['id'] ?? 0), $tipoAcao);
            // No "delete", remove também do CACHE local — assim a ONU some da lista e não volta,
            // mesmo com a OLT offline (se estiver online, o comando acima já a apagou da OLT).
            if ($tipoAcao === 'delete') {
                $rem = ws_olt_cache_remover_fsp((string)($_POST['fsp'] ?? ''), (int)($_POST['id'] ?? 0));
                if ($rem > 0) { $rAcao['status'] = 'ok'; $rAcao['sucesso'] = true; if (empty($rAcao['saida'])) $rAcao['saida'] = 'Removida do cache local.'; }
            }
            echo json_encode($rAcao, JSON_UNESCAPED_UNICODE);
            break;
        case 'trocar_vlan':
            echo json_encode(ws_olt_trocar_vlan($db, (string)($_POST['fsp'] ?? ''), (int)($_POST['id'] ?? 0), (int)($_POST['vlan'] ?? 0)), JSON_UNESCAPED_UNICODE);
            break;
        case 'comando':
            // Gerenciador (Telnet) NATIVO — executa um comando cru na OLT e devolve a saída.
            // Mesma conexão/mutex/engine do resto (ws_olt_exec), sem depender do addon externo.
            if (!ws_pode_deletar()) { echo json_encode(['status' => 'error', 'message' => 'Seu nível de acesso não permite executar comandos na OLT.']); break; }
            $cmd = trim((string)($_POST['cmd'] ?? ''));
            if ($cmd === '') { echo json_encode(['status' => 'error', 'message' => 'Comando vazio.']); break; }
            try {
                $cx = ws_olt_conexao($db);
                if ($cx['ip'] === '') { echo json_encode(['status' => 'error', 'message' => 'Conexão da OLT não configurada.']); break; }
                // Sessão persistente por navegador (evita logar de novo a cada comando digitado) —
                // guarda os comandos já digitados na sessão e reenvia a "sequência" completa mantendo
                // o contexto de config/interface (enable/config já ficam implícitos se o operador não
                // repetir); mais simples e seguro: cada chamada já entra logada e roda só o comando novo.
                $out = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'], ['enable', $cmd], (float)$cx['timeout']);
                echo json_encode(['status' => 'ok', 'saida' => end($out) ?: ''], JSON_UNESCAPED_UNICODE);
            } catch (Throwable $e) {
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
            break;
        default:
            echo json_encode(['status' => 'error', 'message' => 'Ação inválida.']);
    }
    exit;
}

/* ------------------------------------------------------------- ACTIONS */
if (($_POST['acao'] ?? '') === 'salvar_olt_link' && ws_user()['nivel'] === 'admin') {
    ws_olt_link_salvar([
        'modo'      => ($_POST['modo'] ?? 'arquivo') === 'http' ? 'http' : 'arquivo',
        'caminho'   => trim($_POST['caminho'] ?? ''),
        'url'       => trim($_POST['url'] ?? ''),
        'cron_key'  => trim($_POST['cron_key'] ?? ''),
        'olt_url'   => trim($_POST['olt_url'] ?? ''),
        'radius_url'=> trim($_POST['radius_url'] ?? ''),
    ]);
    header('Location: olt_erp.php?p=config&ok=1'); exit;
}
if (($_POST['acao'] ?? '') === 'salvar_olt_nativo' && ws_user()['nivel'] === 'admin') {
    ws_olt_conexao_salvar([
        'ip' => trim($_POST['ip'] ?? ''), 'porta' => (int)($_POST['porta'] ?? 23),
        'user' => trim($_POST['user'] ?? ''), 'pass' => (string)($_POST['pass'] ?? ''),
        'timeout' => max(3, (int)($_POST['timeout'] ?? 8)),
    ]);
    header('Location: olt_erp.php?p=config&ok=1'); exit;
}
// Limpa o CACHE de autorizações da OLT (some com a lista "congelada"; volta só se a OLT for lida
// de novo, aí com dados reais). Só root/admin.
if (isset($_GET['limpar_cache']) && ws_user()['nivel'] === 'admin') {
    $cfg = ws_olt_link_config();
    $arqs = ['olt_autorizacoes.json', 'olt_autofind.json', 'olt_onus_cache.json'];
    if (!empty($cfg['caminho'])) foreach ($arqs as $f) @unlink(rtrim($cfg['caminho'], '/\\') . '/' . ws_olt_sub_erp() . $f);
    foreach ($arqs as $f) @unlink(WS_CACHE . '/' . $f);
    foreach (['olt_autorizacoes_nativo', 'olt_autofind_nativo'] as $b) @unlink(ws_olt_nativo_arq($b));   // só a OLT em uso (há uma por cidade)
    header('Location: olt_erp.php?p=painel&limpo=1'); exit;
}

/* --------------------------------------------------------------- LAYOUT */
function ol_header(string $p): void { ?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — OLT</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<!-- Font Awesome: o módulo da OLT desenha TODOS os botões com ícones dessa fonte (minimizar,
     maximizar, fechar, ações de cada linha). Sem ela eles viram quadrados vazios. É a mesma
     folha que o Painel dos Concentradores carrega — por isso lá os ícones aparecem e aqui não.
     Duas fontes: a local do MK-Auth e a CDN, para funcionar mesmo sem internet no servidor. -->
<link rel="stylesheet" href="../../estilos/font-awesome.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('olt') ?></header><main class="ws-main">
<div class="ws-search">
  <a class="ws-btn <?= ($p==='painel'||$p==='')?'primary':'' ?>" href="olt_erp.php?p=painel">Aprovisionamento ONU / ONT</a>
  <a class="ws-btn <?= $p==='terminal'?'primary':'' ?>" href="olt_erp.php?p=terminal">Gerenciador OLT (Telnet)</a>
  <a class="ws-btn <?= $p==='trafego'?'primary':'' ?>" href="olt_erp.php?p=trafego">Relatório de tráfego</a>
  <a class="ws-btn <?= $p==='cto'?'primary':'' ?>" href="olt_erp.php?p=cto">Mapa de CTO</a>
  <a class="ws-btn <?= $p==='cto_clientes'?'primary':'' ?>" href="olt_erp.php?p=cto_clientes">Relatório CTO</a>
  <a class="ws-btn" href="rede_ftth.php">Rede FTTH</a>
  <a class="ws-btn <?= $p==='config'?'primary':'' ?>" href="olt_erp.php?p=config">Conexão</a>
</div>
<?php if (isset($_GET['ok'])) echo '<div class="ws-alert ok">Salvo.</div>'; }
function ol_footer(): void { echo '</main>' . ws_footer_bar() . '<script src="js/wellsystem.js?v=' . ws_ver('js/wellsystem.js') . '"></script></body></html>'; }

/** OLT Telnet embutida no ERP (o seu olt.php roda aqui dentro). */
function ol_telnet(): void {
    if (!is_file(__DIR__ . '/olt.php')) {
        echo '<div class="ws-alert err">A pasta <code>olt/</code> (seu addon Telnet) não está aqui. Copie o addon para <code>wellsystem/olt/</code>.</div>';
        return;
    }
    echo '<p class="ws-muted" style="font-size:13px;margin:0 0 8px">Gerenciador da OLT ao vivo (Telnet) — dentro do WellSystem. Se pedir login na primeira vez, use a senha da OLT.</p>';
    echo '<iframe src="olt.php" title="Gerenciador OLT" style="width:100%;height:calc(100vh - 170px);min-height:520px;border:1px solid var(--border);border-radius:12px;background:var(--surface)"></iframe>';
}

ol_header($p);
if ($p === 'config') ol_config($db);
elseif ($p === 'terminal') ol_terminal_nativo($db);
elseif ($p === 'trafego') ol_trafego_nativo($db);
// 'cto_clientes' (menu OLT › Relatório CTO) caía no else e abria o Aprovisionamento: o relatório
// nunca aparecia. As duas telas passam pelo ol_cto_nativo (que também trata os POSTs das portas).
elseif ($p === 'cto' || $p === 'cto_clientes') ol_cto_nativo($db);
elseif ($p === 'painel') ol_painel($db);
else ol_painel($db);
ol_footer();

/* ---------------------------------------------------------------- VIEWS */
/** Gerenciador OLT (Telnet) — NATIVO, dentro do próprio WellSystem, sem link pra addon nenhum.
 *  Terminal simples: cada linha digitada roda como comando na OLT (via ws_olt_exec do motor
 *  nativo), a saída aparece embaixo. Cada chamada já entra logada (enable) — não guarda uma
 *  sessão contínua entre comandos (mais simples e mais seguro contra sessão travada). */
function ol_terminal_nativo(PDO $db): void {
    $cx = ws_olt_conexao($db);
    ?>
    <div class="ws-head-row"><h2>🖧 Gerenciador OLT — Terminal (Telnet nativo)</h2></div>
    <?php if ($cx['ip'] === ''): ?>
      <div class="ws-alert" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">
        ⚠️ Conexão da OLT não configurada. Vá em <a href="olt_erp.php?p=config">Conexão</a> (ou cadastre em Cadastros → Ramais).
      </div>
    <?php else: ?>
      <p class="ws-muted" style="font-size:13px">Conectando em <code><?= h($cx['ip']) ?>:<?= h($cx['porta']) ?></code>. Cada linha enviada roda um comando na OLT
        (o <code>enable</code> já é feito sozinho antes). Pra comandos com "confirma (y/n)", já responde "y" automaticamente (mesma regra do resto do sistema).</p>
      <div id="ws_term_saida" style="background:#0d1117;color:#c9d1d9;font-family:monospace;font-size:13px;padding:14px;border-radius:10px;height:420px;overflow-y:auto;white-space:pre-wrap"></div>
      <form onsubmit="return wsTermEnviar(event)" style="display:flex;gap:8px;margin-top:8px">
        <span style="align-self:center;color:var(--muted);font-family:monospace">$</span>
        <input type="text" id="ws_term_cmd" autocomplete="off" placeholder="ex.: display ont autofind all" style="flex:1;font-family:monospace" autofocus>
        <button class="ws-btn primary">Enviar</button>
      </form>
      <div class="ws-search" style="margin-top:8px">
        <?php foreach (['display board 0'=>'display board 0','display ont autofind all'=>'ONUs pendentes','display ont info 0 all'=>'ONTs (porta 0)','display ont version 0 0'=>'Versão ONT'] as $c=>$lbl): ?>
          <button type="button" class="ws-btn" onclick="wsTermAtalho('<?= h($c) ?>')"><?= h($lbl) ?></button>
        <?php endforeach; ?>
      </div>
      <script>
        function wsTermLinha(txt, cls){
          var d = document.getElementById('ws_term_saida');
          var el = document.createElement('div'); if (cls) el.className = cls; el.textContent = txt;
          d.appendChild(el); d.scrollTop = d.scrollHeight;
        }
        function wsTermAtalho(cmd){ document.getElementById('ws_term_cmd').value = cmd; wsTermEnviar({preventDefault:function(){}}); }
        function wsTermEnviar(ev){
          ev.preventDefault();
          var inp = document.getElementById('ws_term_cmd'); var cmd = inp.value.trim();
          if (!cmd) return false;
          wsTermLinha('$ ' + cmd);
          inp.value = ''; inp.disabled = true;
          fetch('olt_erp.php?ajax=comando', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'cmd=' + encodeURIComponent(cmd)})
            .then(function(r){ return r.json(); })
            .then(function(d){
              if (d.status === 'ok') wsTermLinha(d.saida || '(sem saída)');
              else wsTermLinha('❌ ' + (d.message || 'erro'), 'ws-term-erro');
            })
            .catch(function(){ wsTermLinha('❌ Erro de comunicação.', 'ws-term-erro'); })
            .finally(function(){ inp.disabled = false; inp.focus(); });
          return false;
        }
      </script>
      <style>.ws-term-erro{color:#ff7b72}</style>
    <?php endif;
}

/** Relatório de tráfego — NATIVO, via SNMP direto na OLT (mesmas funções do motor original,
 *  portadas), sem depender de addon nenhum. */
function ol_trafego_nativo(PDO $db): void {
    $cx = ws_olt_conexao($db);
    ?>
    <div class="ws-head-row"><h2>📊 Relatório de tráfego (SNMP nativo)</h2></div>
    <?php if ($cx['ip'] === ''): ?>
      <div class="ws-alert" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">
        ⚠️ Conexão da OLT não configurada. Vá em <a href="olt_erp.php?p=config">Conexão</a>.
      </div>
    <?php else: ?>
      <form method="get" class="ws-search"><input type="hidden" name="p" value="trafego">
        <label>Slot <input type="number" name="slot" value="<?= h($_GET['slot'] ?? '1') ?>" style="width:80px"></label>
        <label>Porta <input type="number" name="porta" value="<?= h($_GET['porta'] ?? '0') ?>" style="width:80px"></label>
        <button class="ws-btn primary" style="align-self:flex-end">Consultar</button>
      </form>
      <?php
      $slot = (int)($_GET['slot'] ?? 1); $porta = (int)($_GET['porta'] ?? 0);
      if (isset($_GET['slot'])) {
          $snmp = ws_olt_snmp_cfg($cx);
          if (function_exists('snmp2_get') || ws_olt_snmp_bin('snmpget')) {
              $ifIndex = 10000000 + ($slot * 10000) + ($porta * 10);   // heurística comum em MA5683T (varia por firmware)
              $in = ws_olt_snmp_get($snmp['host'], $snmp['port'], $snmp['comm'], "1.3.6.1.2.1.31.1.1.1.6.$ifIndex");
              $out = ws_olt_snmp_get($snmp['host'], $snmp['port'], $snmp['comm'], "1.3.6.1.2.1.31.1.1.1.10.$ifIndex");
              echo '<div class="ws-mkcards" style="margin-top:14px">'
                 . '<div class="ws-mk ws-mk-azul"><span class="ws-mk-lbl">Bytes recebidos (in)</span><span class="ws-mk-num">' . ($in !== null ? number_format((float)$in,0,',','.') : '—') . '</span></div>'
                 . '<div class="ws-mk ws-mk-verde"><span class="ws-mk-lbl">Bytes enviados (out)</span><span class="ws-mk-num">' . ($out !== null ? number_format((float)$out,0,',','.') : '—') . '</span></div>'
                 . '</div>';
              if ($in === null && $out === null) echo '<p class="ws-muted">Sem resposta SNMP pra esse slot/porta — confira se o SNMP está habilitado na OLT e a community configurada em Conexão.</p>';
          } else {
              echo '<div class="ws-alert" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">⚠️ Este servidor não tem suporte a SNMP (nem extensão PHP nem binários net-snmp instalados). Peça pro seu suporte de hospedagem instalar <code>php-snmp</code> ou <code>snmp</code> (pacote net-snmp).</div>';
          }
      } else {
          echo '<p class="ws-muted">Escolha slot/porta e clique em Consultar.</p>';
      }
      ?>
    <?php endif;
}

/** Mapa de CTO — NATIVO. Cadastro próprio de caixas CTO (sem depender de addon externo), com
 *  posição no mapa e clientes vinculados por porta. */
function ol_cto_nativo(PDO $db): void {
    if (($_POST['acao'] ?? '') === 'salvar_cto' && ws_pode_deletar()) {
        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome'] ?? ''); $lat = (float)str_replace(',','.',$_POST['lat'] ?? 0); $lng = (float)str_replace(',','.',$_POST['lng'] ?? 0);
        $portas = max(1, min(64, (int)($_POST['portas'] ?? 8)));
        if ($id) $db->prepare("UPDATE ws_cto SET nome=?,latitude=?,longitude=?,portas=? WHERE id=?")->execute([$nome,$lat,$lng,$portas,$id]);
        else $db->prepare("INSERT INTO ws_cto (nome,latitude,longitude,portas) VALUES (?,?,?,?)")->execute([$nome,$lat,$lng,$portas]);
        header('Location: olt_erp.php?p=cto&ok=1'); exit;
    }
    if (isset($_GET['del_cto']) && ws_pode_deletar()) { $db->prepare("DELETE FROM ws_cto WHERE id=?")->execute([(int)$_GET['del_cto']]); header('Location: olt_erp.php?p=cto'); exit; }
    if (($_POST['acao'] ?? '') === 'ligar_porta' && ws_pode_deletar()) {
        $ctoId = (int)$_POST['cto_id']; $np = (int)$_POST['numero_porta']; $cliId = (int)($_POST['cliente_id'] ?: 0);
        $ex = $db->prepare("SELECT id FROM ws_cto_porta WHERE cto_id=? AND numero_porta=?"); $ex->execute([$ctoId, $np]); $pid = $ex->fetchColumn();
        if ($pid) $db->prepare("UPDATE ws_cto_porta SET cliente_id=? WHERE id=?")->execute([$cliId ?: null, $pid]);
        else $db->prepare("INSERT INTO ws_cto_porta (cto_id,numero_porta,cliente_id) VALUES (?,?,?)")->execute([$ctoId, $np, $cliId ?: null]);
        header('Location: olt_erp.php?p=cto_clientes&cto=' . $ctoId); exit;
    }
    if (($_GET['p'] ?? '') === 'cto_clientes') { ol_cto_clientes($db); return; }

    $eid = (int)($_GET['cto'] ?? 0); $e = null;
    if ($eid) { $st = $db->prepare("SELECT * FROM ws_cto WHERE id=?"); $st->execute([$eid]); $e = $st->fetch(); }
    $ctos = $db->query("SELECT ct.*, (SELECT COUNT(*) FROM ws_cto_porta p WHERE p.cto_id=ct.id AND p.cliente_id IS NOT NULL) ocupadas FROM ws_cto ct ORDER BY ct.nome")->fetchAll();
    ?>
    <div class="ws-head-row"><h2>🗺️ Mapa de CTO</h2></div>
    <p class="ws-muted" style="font-size:13px">Cadastro próprio de caixas CTO — nativo do WellSystem (sem depender de addon externo). Latitude/longitude alimentam o mapa geral.</p>
    <div class="ws-two">
      <div>
        <table class="ws-table"><thead><tr><th>Nome</th><th>Portas</th><th>Ocupadas</th><th>Lat/Long</th><th></th></tr></thead><tbody>
        <?php foreach ($ctos as $c): ?>
          <tr><td><?= h($c['nome']) ?></td><td><?= (int)$c['portas'] ?></td>
          <td><?= (int)$c['ocupadas'] ?>/<?= (int)$c['portas'] ?></td>
          <td class="ws-muted" style="font-size:12px"><?= h($c['latitude']) ?>, <?= h($c['longitude']) ?></td>
          <td><div class="ws-acoes"><a href="olt_erp.php?p=cto&cto=<?= $c['id'] ?>">editar</a>
            <?php if (ws_pode_deletar()): ?><a href="olt_erp.php?del_cto=<?= $c['id'] ?>" onclick="return confirm('Excluir esta CTO?')" style="color:var(--err)">excluir</a><?php endif; ?></div></td></tr>
        <?php endforeach; if (!$ctos) echo '<tr><td colspan="5" class="ws-muted">Nenhuma CTO cadastrada ainda.</td></tr>'; ?>
        </tbody></table>
      </div>
      <?php if (ws_pode_deletar()): ?>
      <form method="post" class="ws-form">
        <input type="hidden" name="acao" value="salvar_cto"><input type="hidden" name="id" value="<?= $eid ?>">
        <h3><?= $eid?'Editar CTO':'Nova CTO' ?></h3>
        <label>Nome/identificação <input name="nome" required value="<?= h($e['nome']??'') ?>" placeholder="ex.: CTO-014"></label>
        <label>Quantidade de portas <input type="number" name="portas" value="<?= h($e['portas']??8) ?>" min="1" max="64"></label>
        <label>Latitude <input name="lat" value="<?= h($e['latitude']??'') ?>"></label>
        <label>Longitude <input name="lng" value="<?= h($e['longitude']??'') ?>"></label>
        <button class="ws-btn verde">Salvar CTO</button>
      </form>
      <?php endif; ?>
    </div>
    <?php
}

/** Relatório CTO — clientes por caixa (mesma tabela ws_cto/ws_cto_porta, agrupado por porta). */
function ol_cto_clientes(PDO $db): void {
    $ctoId = (int)($_GET['cto'] ?? 0);
    $ctos = $db->query("SELECT id,nome,portas FROM ws_cto ORDER BY nome")->fetchAll();
    if (!$ctoId && $ctos) $ctoId = (int)$ctos[0]['id'];
    $cto = null; foreach ($ctos as $c) if ((int)$c['id'] === $ctoId) $cto = $c;
    /* DADOS DA CONEXÃO DE CADA PORTA — antes o relatório só mostrava nome e status; o técnico na
       rua precisa de login, plano, SN ONU / ONT, sinal, VLAN e se está online. Tudo vem do contrato
       ativo do cliente (o mais recente não cancelado). Online = mesma fonte do Painel. */
    $ocupadas = [];
    if ($cto) {
        $st = $db->prepare("SELECT p.numero_porta, p.cliente_id, c.nome, c.status, c.celular,
                   ct.login_pppoe, ct.login_ipoe, ct.sn_onu, ct.vlan, ct.rx_sinal, ct.zona, ct.ultimo_ip, pl.nome plano
            FROM ws_cto_porta p
            LEFT JOIN ws_cliente c ON c.id=p.cliente_id
            LEFT JOIN ws_contrato ct ON ct.id=(SELECT ct2.id FROM ws_contrato ct2 WHERE ct2.cliente_id=p.cliente_id
                                               ORDER BY (ct2.status='cancelado') ASC, ct2.id DESC LIMIT 1)
            LEFT JOIN ws_plano pl ON pl.id=ct.plano_id
            WHERE p.cto_id=?");
        $st->execute([$ctoId]);
        foreach ($st->fetchAll() as $r) $ocupadas[(int)$r['numero_porta']] = $r;
    }
    $onIds = [];
    if (!function_exists('ws_clientes_online_ids') && is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
    if (function_exists('ws_clientes_online_ids')) { try { foreach (ws_clientes_online_ids($db) as $i) $onIds[$i] = true; } catch (Throwable $e) {} }
    // Todos os clientes não cancelados (antes cortava em 500 — quem passava disso não podia ser ligado).
    $clientes = $db->query("SELECT id,nome FROM ws_cliente WHERE status<>'cancelado' ORDER BY nome")->fetchAll();
    $nOcup = count(array_filter($ocupadas, fn($o) => !empty($o['cliente_id'])));
    $nPortas = $cto ? (int)$cto['portas'] : 0;
    $nOn = count(array_filter($ocupadas, fn($o) => !empty($o['cliente_id']) && isset($onIds[(int)$o['cliente_id']])));
    ?>
    <div class="ws-head-row"><h2>📋 Relatório CTO — clientes por caixa</h2></div>
    <div class="ws-search">
      <?php foreach ($ctos as $c): ?><a class="ws-btn <?= (int)$c['id']===$ctoId?'primary':'' ?>" href="olt_erp.php?p=cto_clientes&cto=<?= $c['id'] ?>"><?= h($c['nome']) ?></a><?php endforeach; ?>
      <a class="ws-btn" href="olt_erp.php?p=cto">← Cadastro de CTOs</a>
    </div>
    <?php if (!$cto): ?><p class="ws-muted">Nenhuma CTO cadastrada ainda. Cadastre em <a href="olt_erp.php?p=cto">Mapa de CTO</a>.</p><?php return; endif; ?>
    <div class="ws-cards" style="margin:10px 0">
      <div class="ws-stat"><span><?= $nOcup ?>/<?= $nPortas ?></span><label>Portas ocupadas</label></div>
      <div class="ws-stat"><span style="color:var(--ok)"><?= max(0, $nPortas - $nOcup) ?></span><label>Portas livres</label></div>
      <div class="ws-stat"><span style="color:var(--ok)"><?= $nOn ?></span><label>Online agora</label></div>
      <div class="ws-stat"><span style="color:var(--err)"><?= max(0, $nOcup - $nOn) ?></span><label>Offline</label></div>
    </div>
    <datalist id="ws_cto_cli"><?php foreach ($clientes as $cl) echo '<option value="' . (int)$cl['id'] . ' — ' . h($cl['nome']) . '">'; ?></datalist>
    <div style="overflow-x:auto"><table class="ws-table"><thead><tr>
      <th>Porta</th><th>Cliente</th><th>Conexão</th><th>Login</th><th>Plano</th><th>SN ONU / ONT</th><th>VLAN</th><th>Sinal RX</th><th>Status</th><th></th>
    </tr></thead><tbody>
    <?php for ($n = 1; $n <= $nPortas; $n++): $o = $ocupadas[$n] ?? null; $tem = $o && $o['cliente_id'];
      $on = $tem && isset($onIds[(int)$o['cliente_id']]); ?>
      <tr>
        <td><b><?= $n ?></b></td>
        <td><?= $tem ? '<a href="erp.php?p=cliente&id='.(int)$o['cliente_id'].'">'.h($o['nome']).'</a>' : '<span class="ws-muted">livre</span>' ?></td>
        <td><?= $tem ? ($on ? '<span class="ws-tag ativo">🟢 online</span>' : '<span class="ws-tag inativo">⚪ offline</span>') : '—' ?></td>
        <td><?= $tem ? h($o['login_pppoe'] ?: ($o['login_ipoe'] ?: '—')) : '—' ?></td>
        <td><?= $tem ? h($o['plano'] ?: '—') : '—' ?></td>
        <td><?= $tem ? h($o['sn_onu'] ?: '—') : '—' ?></td>
        <td><?= $tem ? h($o['vlan'] ?: '—') : '—' ?></td>
        <td><?= $tem && $o['rx_sinal'] !== null && $o['rx_sinal'] !== '' ? h($o['rx_sinal']) . ' dBm' : '—' ?></td>
        <td><?= $tem && $o['status'] ? '<span class="ws-tag '.h($o['status']).'">'.h($o['status']).'</span>' : '—' ?></td>
        <td><?php if (ws_pode_deletar()): ?>
          <?php /* Busca por nome digitando (datalist) em vez de um <select> com milhares de nomes
                   repetido em cada porta — a página ficava enorme e lenta. O id vai no começo do texto. */ ?>
          <form method="post" style="display:flex;gap:6px" onsubmit="var i=this.querySelector('[data-cli]');var m=(i.value||'').match(/^\s*(\d+)/);this.cliente_id.value=m?m[1]:'';">
            <input type="hidden" name="acao" value="ligar_porta"><input type="hidden" name="cto_id" value="<?= $ctoId ?>"><input type="hidden" name="numero_porta" value="<?= $n ?>">
            <input type="hidden" name="cliente_id" value="<?= $tem ? (int)$o['cliente_id'] : '' ?>">
            <input data-cli list="ws_cto_cli" style="font-size:12px;min-width:200px" placeholder="digite o nome (vazio = livre)" value="<?= $tem ? (int)$o['cliente_id'] . ' — ' . h($o['nome']) : '' ?>">
            <button class="ws-btn" style="font-size:12px">Salvar</button>
          </form>
        <?php endif; ?></td>
      </tr>
    <?php endfor; ?>
    </tbody></table></div>
    <?php
}

function ol_config(PDO $db): void {
    $c = ws_olt_link_config();
    // SEMPRE a conexão global (o "true"), nunca a do ramal: este formulário grava no JSON global,
    // então precisa MOSTRAR o que grava. Carregar a do ramal aqui fazia a senha recém-digitada
    // "sumir" ao salvar — a tela voltava exibindo a senha antiga do ramal.
    $cn = ws_olt_conexao($db, true);

    // Quem está realmente no comando agora? Se há um ramal selecionado no topo COM OLT própria,
    // é a conexão dele que o sistema usa — e mexer no formulário abaixo não muda nada para ele.
    $ramalAtivo = ws_ramal_atual();
    $ramalComOlt = null;
    if ($ramalAtivo) {
        $q = $db->prepare("SELECT olt_host FROM ws_ramal WHERE id=?");
        $q->execute([$ramalAtivo['id']]);
        if ($q->fetchColumn()) $ramalComOlt = $ramalAtivo;
    }
    ?>
    <div class="ws-head-row"><h2>Conexão com a OLT</h2></div>

    <?php if ($ramalComOlt): ?>
    <div class="ws-alert" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">
      ⚠️ <b>Atenção:</b> o topo da página está em <b><?= h($ramalComOlt['cidade'] . ' — ' . $ramalComOlt['nome']) ?></b>,
      e esse ramal tem <b>OLT própria</b>. É a conexão dele que está sendo usada agora — o formulário abaixo é a
      conexão <b>global</b> e não afeta esta cidade. Para mudar a senha desta OLT, vá em
      <a href="erp.php?p=cadastros&t=ramais">Cadastros → Ramais</a> e edite o ramal.
      Para editar a global, troque o topo para <b>Todas as cidades</b>.
    </div>
    <?php endif; ?>

    <div class="ws-panel">
      <b>🔌 Motor nativo (recomendado) — conexão Telnet direta, código embutido no WellSystem</b>
      <p class="ws-muted" style="font-size:13px">Usada quando "Todas as cidades" está selecionada no topo. Pra uma cidade/ramal específico
        com OLT própria, configure em <a href="erp.php?p=cadastros&t=ramais">Cadastros → Ramais</a> (prevalece sobre esta).</p>
      <form method="post" class="ws-form grid">
        <input type="hidden" name="acao" value="salvar_olt_nativo">
        <label>Host/IP da OLT <input name="ip" value="<?= h($cn['ip']) ?>" placeholder="ex.: 10.0.0.5"></label>
        <label>Porta <input name="porta" value="<?= h($cn['porta']) ?>" placeholder="23"></label>
        <label>Usuário <input name="user" autocomplete="off" value="<?= h($cn['user']) ?>"></label>
        <!-- autocomplete="new-password": impede o gerenciador de senhas do navegador de sobrescrever
             o campo com uma senha salva de outro site. Sem isso o Chrome troca a senha da OLT
             sozinho ao abrir a tela, e o operador salva a senha errada sem perceber. -->
        <label>Senha <input type="password" name="pass" autocomplete="new-password" value="<?= h($cn['pass']) ?>"></label>
        <label>Timeout (segundos) <input name="timeout" value="<?= h($cn['timeout']) ?>" placeholder="8"></label>
        <div class="c4"><button class="ws-btn verde">Salvar conexão nativa</button></div>
      </form>
    </div>

    <div class="ws-panel" style="margin-top:16px">
      <b>Unificação com addon externo (opcional/legado)</b>
    <div class="ws-alert ok" style="background:rgba(2,132,199,.10);color:var(--info);border-color:var(--info)">
      Na instalação <b>unificada</b> (addon + ERP no mesmo servidor), aponte o <b>caminho</b> da pasta
      <code>cache_trafego</code> do addon da OLT. O ERP passa a ler as autorizações e a preencher o cadastro sozinho.
    </div>
    <form method="post" class="ws-form" style="max-width:640px">
      <input type="hidden" name="acao" value="salvar_olt_link">
      <label>Modo <select name="modo" onchange="document.getElementById('m_http').style.display=this.value==='http'?'contents':'none';document.getElementById('m_arq').style.display=this.value==='arquivo'?'contents':'none'">
        <option value="arquivo" <?= $c['modo']==='arquivo'?'selected':'' ?>>Arquivo (mesmo servidor — recomendado)</option>
        <option value="http" <?= $c['modo']==='http'?'selected':'' ?>>HTTP (addon em outro servidor)</option>
      </select></label>
      <span id="m_arq" style="display:<?= $c['modo']==='arquivo'?'contents':'none' ?>">
        <label>Caminho da pasta cache_trafego do addon
          <input name="caminho" value="<?= h($c['caminho']) ?>" placeholder="/opt/mk-auth/admin/addons/wellsystem_olt/cache_trafego"></label>
      </span>
      <span id="m_http" style="display:<?= $c['modo']==='http'?'contents':'none' ?>">
        <label>URL base do addon <input name="url" value="<?= h($c['url']) ?>" placeholder="https://olt.seudominio.com"></label>
        <label>Chave do cron do addon (olt_cron_key.txt) <input name="cron_key" value="<?= h($c['cron_key']) ?>"></label>
      </span>
      <div style="border-top:1px dashed var(--border);padding-top:10px;margin-top:6px"><b>Painéis ao vivo (Telnet) — seus arquivos do addon</b></div>
      <label>URL do Gerenciador da OLT (olt.php — Telnet)
        <input name="olt_url" value="<?= h($c['olt_url']) ?>" placeholder="https://olt.seudominio.com/olt.php"></label>
      <label>URL do WellSystem Radius / Total Radius (index.php — concentradores)
        <input name="radius_url" value="<?= h($c['radius_url']) ?>" placeholder="https://radius.seudominio.com/index.php"></label>
      <button class="ws-btn primary">Salvar conexão</button>
    </form>
    <p class="ws-muted" style="margin-top:10px">O Telnet com a OLT é feito pelo seu addon (100% funcional). Aqui o ERP <b>abre</b> esses painéis reais e usa as autorizações para criar clientes.</p>
    <?php
}

function ol_painel(PDO $db): void {
    // Ramal selecionado sem OLT própria configurada: não tenta buscar dado ao vivo (evita
    // erro/travamento por ramal sem conexão) — só mostra quando "Todas as cidades" ou quando
    // o ramal selecionado TEM host de OLT cadastrado (Cadastros → Ramais).
    $ramalAtivo = ws_ramal_atual();
    $ramalSemOlt = false;
    if ($ramalAtivo) {
        $chk = $db->prepare("SELECT olt_host FROM ws_ramal WHERE id=?"); $chk->execute([$ramalAtivo['id']]);
        $ramalSemOlt = !$chk->fetchColumn();
    }
    if ($ramalSemOlt): ?>
        <div class="ws-head-row"><h2>Aprovisionamento da OLT</h2></div>
        <div class="ws-alert" style="background:rgba(217,119,6,.10);color:var(--warn);border:1px solid var(--warn)">
          ⚠️ O ramal <b><?= h($ramalAtivo['cidade'] . ' — ' . $ramalAtivo['nome']) ?></b> não tem uma OLT própria configurada
          (Cadastros → Ramais → edite este ramal e preencha "OLT deste ramal"). Por isso, nenhum dado ao vivo é buscado
          para ele — troque pra "Todas as cidades" no topo pra ver os dados gerais, ou cadastre a OLT deste ramal.
        </div>
        <?php return;
    endif;
    // GERÊNCIA OLT — o card de APROVISIONAMENTO renderizado DENTRO desta página.
    //
    // O olt_ui.js já tem a função que monta esse card: oltAprovisionamento(). Ela é
    // autossuficiente — cria o próprio conteúdo e não depende da janela principal do
    // gerenciador estar aberta. Aqui ela é chamada e o card é ANCORADO na página, em vez de
    // ficar flutuando por cima dela.
    //
    // É por isso que não há iframe: o olt_ui.js roda no MESMO documento (igual ao Painel dos
    // Concentradores), então o card é só um elemento do DOM e pode ser movido para o lugar certo.
    // Um documento, um topo, um rodapé, uma barra de rolagem.
    if (!ws_olt_disponivel()) {
        echo '<div class="ws-alert err">Módulo da OLT não encontrado. Esperado <code>olt_ui.js</code> + '
           . '<code>olt_huawei.php</code> na raiz desta pasta ou em <code>olt/</code>.</div>';
        return;
    }
    ?>
    <style>
    /* ============================================================================================
       ESTILOS DESTA TELA — inline de propósito.
       Ficavam no css/wellsystem.css, que é uma SUBPASTA: várias correções se perderam porque o
       arquivo não chegava lá. Aqui viajam junto com o olt_erp.php, um arquivo só, na raiz.
       ========================================================================================= */

    /* Barra da página: título + Diagnóstico + Atualizar busca. */
    .ws-olt-topbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 10px;
                   padding:9px 13px;border:1px solid var(--border);border-radius:10px;background:var(--surface)}
    .ws-olt-topbar b{font-size:13.5px}
    .ws-olt-topbar .ws-muted{font-size:12px}
    .ws-olt-topbar-acoes{margin-left:auto;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .ws-olt-topbar-acoes .ws-btn{font-size:12.5px;padding:6px 13px;white-space:nowrap}
    .ws-olt-topbar-acoes .ws-btn:disabled{opacity:.65;cursor:default}

    /* LARGURA: o card recebe width:100% do container, mas tem padding e borda próprios. Sem
       border-box o total passa de 100% e ele sangra para os lados, ficando mais largo que as
       abas e a barra acima. Com border-box a borda esquerda do card alinha com a das abas. */
    .ws-olt-ancora{display:block;width:100%;margin:0 0 10px}
    .ws-olt-ancora, .ws-olt-ancora #oltApWin, .ws-olt-ancora #oltApWin *{box-sizing:border-box}
    .ws-olt-ancora #oltApWin{width:100%!important;max-width:100%!important;margin:0!important;
                             border:1px solid var(--border)}

    /* ALINHAMENTO DENTRO DO CARD.
       Três coisas desalinhavam a fileira de campos, e as três são tratadas aqui:

       1. RÓTULO DE DUAS LINHAS — "PORTA PON (AUTO · PODE TROCAR)" e "PERFIL ONU/ONT
          (CADASTRADO)" ocupam duas linhas; "Placa", "VLAN", "Tipo" e "Zona" ocupam uma. Como
          cada campo é <label> em cima do <input>, o campo do rótulo maior descia. Todo rótulo
          passa a ter a mesma altura mínima.
       2. CÉLULA DO GRID — cada campo é uma célula que estica em altura; alinhando o conteúdo
          pela BASE, o input encosta no rodapé da célula independentemente do rótulo.
       3. ALTURA DOS CAMPOS — input e select vinham com alturas diferentes (um com padding, o
          outro com a altura nativa do select). Uniformizados, a fileira fica reta.
       Vale para qualquer fileira do card, inclusive as que existirem depois. */
    #oltApWin label{min-height:28px!important;display:flex!important;align-items:flex-end!important;
                    line-height:1.2!important;margin:0 0 4px!important}
    #oltApWin [style*="grid-template-columns"] > div{
      display:flex!important;flex-direction:column!important;justify-content:flex-end!important}
    #oltApWin input[type="text"], #oltApWin select{
      height:36px!important;line-height:normal!important;box-sizing:border-box!important;
      padding-top:0!important;padding-bottom:0!important;vertical-align:middle!important}





    /* Mesmo alinhamento, embutido nesta tela (não depende do css/ chegar na subpasta). */
    #oltApWin div:has(> label), #oltWin div:has(> label){
      display:flex!important;flex-direction:column!important;justify-content:flex-end!important}
    /* A CAMADA DO MÓDULO NUNCA APARECE — é ela a "outra página" que abria e fechava.
       oltAprovisionamento() cria #oltApModal em tela cheia (position:fixed; inset:0) e monta o
       card DENTRO dela. Meu código tira o card de lá e ancora na página, mas entre uma coisa e
       outra a camada chegava a ser pintada: era essa a piscada.
       Escondendo a camada de saída, ela nunca é vista. O card continua sendo montado dentro
       dela normalmente e, ao ser movido para a âncora, volta a ficar visível. */
    #oltApModal{ display:none!important }
    /* A JANELA CHEIA DO GERENCIADOR NUNCA É PINTADA NESTA TELA.
       abrirOltHuawei() (que carrega os dados do card) mostra #oltOverlay maximizado na hora; o
       script abaixo só conseguia esconder no tick seguinte — o operador via a Gerência OLT abrir
       e depois a tela de busca. Escondida por CSS desde o 1º frame, só a busca aparece.
       A pílula "OLT Huawei" (minimizado) também não tem sentido aqui. */
    #oltOverlay, #oltPill{ display:none!important }
    /* CLIQUE NO SERIAL NÃO DESLOCA MAIS A TELA.
       Ao clicar no serial o módulo copia o texto, e para isso dá foco a um elemento auxiliar.
       O navegador então "rola até o elemento focado" — e como o card é largo, essa rolagem era
       HORIZONTAL: a tela andava para o lado a cada clique.
       Travando a rolagem horizontal do card, o navegador não tem para onde rolar. O conteúdo
       largo continua acessível: quem rola é a tabela, dentro da própria caixa dela. */
    #oltApWin{ overflow-x:hidden!important }
    #oltApWin *{ scroll-margin:0!important }
    /* COLUNAS PARADAS AO PASSAR O MOUSE.
       As colunas "pulavam" porque o :hover mudava algo que afeta o TAMANHO — negrito, borda ou
       padding. Numa tabela de largura automática, qualquer mudança dessas recalcula a largura de
       TODAS as colunas, e a tabela inteira se mexe a cada linha que o mouse passa.

       Duas travas:
       1. table-layout:fixed — a largura é decidida uma vez, pelo cabeçalho, e não muda mais com
          o conteúdo. É o que impede o recálculo.
       2. no :hover, nada que ocupe espaço pode mudar. O destaque continua existindo, mas por
          COR e sombra, que não empurram nada. O negrito vira text-shadow: engrossa visualmente
          sem alterar a largura do texto.
       O hover das AÇÕES (botões e links dentro da linha) não é tocado — ali o realce é esperado. */
    #oltApWin table, #oltApWin table *{ box-sizing:border-box }
    #oltApWin table{ table-layout:fixed!important; width:100%!important }
    #oltApWin td, #oltApWin th{ overflow:hidden; text-overflow:ellipsis }
    #oltApWin tr:hover td, #oltApWin tr:hover th{
      font-weight:inherit!important;          /* negrito no hover alargava o texto */
      transform:none!important;
      padding:inherit!important;
      border-width:inherit!important;
      letter-spacing:inherit!important;
    }
    /* Realce que NÃO ocupa espaço: cor de fundo e um leve engrossamento óptico. */
    #oltApWin tr:hover{ background:rgba(0,0,0,.035)!important }
    #oltApWin tr:hover td{ text-shadow:0 0 .35px currentColor }
    /* Transição só em cor — nunca em largura/altura, que é o que faz "pular". */
    #oltApWin tr, #oltApWin td{ transition:background-color .12s ease!important }
    /* Camadas do gerenciador começam ABAIXO do topo, para a navegação continuar visível. */
    #oltOverlay,#oltApModal,#oltAddOv,#oltBulkOv,#oltCxOv,#oltImgOv,#oltLogoOv,#oltPgOv,#oltSesOv{
      top:var(--ws-topo-h,104px)!important}
    #oltIntWin,#oltResumoWin,#oltPonWin,#oltDescWin,#oltRelWin,#oltDocWin,#oltGrafWin,#oltCxBox,
    .oltMSWin,[id^="oltWin_"],[id^="modalGraficoRT_"],[id^="log_modal_"]{
      top:max(var(--ws-topo-h,104px),0px)!important;
      max-height:calc(100vh - var(--ws-topo-h,104px) - 16px)!important}

    /* Caixa de diagnóstico (abre pelo botão). */
    .ws-olt-diag{border:1px solid var(--border);border-left:3px solid var(--brand);border-radius:8px;
                 padding:9px 12px;margin:0 0 10px;background:var(--surface);font-size:12.5px;line-height:1.7}
    .ws-olt-diag b{display:block;margin-bottom:4px}
    .ws-olt-diag div{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px}

    @media(max-width:640px){
      .ws-olt-topbar{flex-direction:column;align-items:stretch}
      .ws-olt-topbar-acoes{margin-left:0;justify-content:space-between}
    }
    </style>
    <div class="ws-olt-topbar">
      <b>🔌 Aprovisionamento</b>
      <span class="ws-muted">ONUs/ONTs aguardando liberação</span>
      <div class="ws-olt-topbar-acoes">
        <span id="wsOltQuando" class="ws-muted"></span>
        <!-- Diagnóstico sob demanda: fica escondido e só aparece ao clicar. Antes ocupava a tela
             sempre, mesmo com tudo funcionando. -->
        <button type="button" class="ws-btn" id="wsOltDiagBtn"
                title="Verifica módulo, backend, cache de ONUs e estado do card">🔎 Diagnóstico</button>
        <button type="button" class="ws-btn primary" id="wsOltAtualizar"
                title="Consulta a OLT de novo e recarrega a lista de ONUs aguardando liberação">
          ↻ Atualizar Busca
        </button>
      </div>
    </div>
    <div id="wsOltDiag" class="ws-olt-diag" hidden>
      <b>🔎 Diagnóstico</b>
      <div id="wsOltDiagLinhas"></div>
    </div>
    <div id="wsOltAprov" class="ws-olt-ancora"></div>
    <script>
    /* MESMO AMBIENTE DO PAINEL DOS CONCENTRADORES.
       O olt_ui.js lê estas variáveis para montar links e a logo do card. Sem elas o card abre,
       mas se comporta diferente do que abre em Servidores › Menu › OLT: logo genérica e links
       de cadastro quebrados. É o mesmo módulo — o ambiente tem que ser o mesmo. */
    window.WS_RADIUS = true;
    var WS_CFG  = <?= json_encode(ws_olt_cfg(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    /* Mesma regra do Painel dos Concentradores: o IP configurado em Configurações manda; sem ele,
       o host atual. Campo vazio virava a URL "http://", que não abre nada e não explica por quê. */
    var WS_SRV  = (function () {
        var cfg = String(WS_CFG.servidor_web || '').trim().replace(/\/+$/, '');
        if (cfg === '') return location.protocol + '//' + location.host;
        return /^https?:\/\//i.test(cfg) ? cfg : ('http://' + cfg);
    })();
    var WS_CNC  = WS_CFG.concentradores || [];
    var WS_CNC1 = (WS_CNC[0] && WS_CNC[0].ip) || '';
    var WS_CNC2 = (WS_CNC[1] && WS_CNC[1].ip) || '';
    var WS_LOGO_OLT = <?= json_encode(ws_olt_logo(), JSON_UNESCAPED_SLASHES) ?>;
    var WS_LOGO_URL = <?= json_encode(function_exists('ws_brand_logo_url') ? ws_brand_logo_url() : '', JSON_UNESCAPED_SLASHES) ?>; // link da logo do topo (site do provedor)
    var WS_OLT_UNIFICADA = true;
    window.WS_OLT_AUTOCONN = <?= ws_olt_autoconn() ? 'true' : 'false' ?>;   // caixa "Auto-conectar" do card
    // Limpa a marca ANTES do olt_ui.js carregar: com ela, o módulo reabria a Gerência OLT inteira
    // no load (quem veio da Gerência pro Aprovisionamento via a Gerência primeiro).
    try { sessionStorage.removeItem('oltAberto'); } catch (e) {}
    </script>
    <?php $oltBase = ws_olt_base(); ?>
    <script src="<?= $oltBase ?>olt_ui.js?v=<?= @hash_file("crc32b", __DIR__ . "/" . $oltBase . "olt_ui.js") ?: (@filemtime(__DIR__ . "/" . $oltBase . "olt_ui.js") ?: time()) ?>"></script>
    <script>
    (function () {
      var alvo = document.getElementById('wsOltAprov');

      // Tira o card do modo "janela flutuante" e encaixa no fluxo da página.
      function ancorar() {
        // A janela cheia do gerenciador NUNCA aparece nesta página — só o card. Isto fica no
        // ancorar() (que roda periodicamente) e não só na abertura, porque várias ações do
        // gerenciador reabrem essa janela sozinhas, e ela passava por cima da barra do botão.
        var ovFull = document.getElementById("oltOverlay");
        if (ovFull) ovFull.style.setProperty("display", "none", "important");

        // O olt_ui.js grava sessionStorage.oltAberto='1' quando o gerenciador abre, e usa isso
        // para REABRIR a janela cheia sozinho no próximo carregamento — em qualquer página do
        // sistema. Nesta tela o gerenciador é só o motor por trás do card, não uma janela; sem
        // limpar a marca, apertar F5 fazia a página piscar o gerenciador e sair dela.
        try { sessionStorage.removeItem('oltAberto'); } catch (e) {}

        // Um card por vez: se houver mais de um (remontagem), fica só o primeiro.
        var todos = document.querySelectorAll("#oltApWin");
        for (var i = 1; i < todos.length; i++) todos[i].remove();
        var win = document.getElementById('oltApWin');
        if (!win || !alvo) return false;
        if (win.parentNode !== alvo) alvo.appendChild(win);      // move para dentro da página

        var f = function (el, css) { if (el) for (var k in css) el.style.setProperty(k, css[k], 'important'); };
        // Largura TOTAL da página: com o alinhamento dos campos corrigido no CSS (cada célula
        // do grid alinhada pela base), esticar não desalinha mais nada. Centralizado sobrava
        // um vazio enorme à esquerda.
        f(win, { position: "static", width: "100%", "max-width": "none", margin: "0",
                 "max-height": "none", height: "auto", "border-radius": "10px", "box-shadow": "none" });

        // A camada que sobrou fica sem função (o card já saiu de dentro dela).
        var modal = document.getElementById('oltApModal');
        if (modal && !modal.querySelector('#oltApWin')) f(modal, { display: 'none' });

        // Minimizar / Maximizar / Fechar: FICAM VISÍVEIS, mas com contraste. No cabeçalho
        // vermelho do card eles ficavam brancos sobre vermelho claro e praticamente sumiam.
        // Ganham fundo escuro translúcido e borda branca — legíveis sem destoar da barra.
        var head = document.getElementById('oltApHead');
        if (head) {
          var bts = head.querySelectorAll('button');
          for (var b = 0; b < bts.length; b++) {
            f(bts[b], {
              display: 'inline-flex', 'align-items': 'center', 'justify-content': 'center',
              width: '30px', height: '30px', 'min-width': '30px', padding: '0',
              background: 'rgba(0,0,0,.28)', color: '#ffffff',
              border: '1px solid rgba(255,255,255,.85)', 'border-radius': '7px',
              'font-size': '13px', cursor: 'pointer', opacity: '1'
            });
          }
          // "Fechar" some o card e deixaria a tela vazia; aqui ele RECARREGA a busca, que é o
          // que o operador espera nesta página.
          var fechar = head.querySelector('button[title="Fechar"]');
          if (fechar && !fechar.dataset.wsAjustado) {
            fechar.dataset.wsAjustado = '1';
            fechar.title = 'Recarregar a busca';
            fechar.onclick = function (ev) { ev.preventDefault(); ev.stopPropagation(); atualizar(); return false; };
          }
        }
        return true;
      }

      // O CARD PRECISA DOS DADOS CARREGADOS.
      // oltAprovisionamento() só MONTA a tela; quem busca as ONUs é abrirOltHuawei(), que dispara
      // oltCarregarStatus/oltCarregarCadastro/_oltPreloadPerfis e lê a lista da OLT. Chamar só o
      // card resultava em tela montada e vazia — "tem ONU pra aprovisionar e não exibe".
      // Então: inicializa o gerenciador (que carrega tudo), esconde a janela dele — esta página
      // mostra só o card — e aí monta o Aprovisionamento com os dados já em memória.
      function iniciar() {
        if (typeof abrirOltHuawei !== 'function' || typeof oltAprovisionamento !== 'function') return false;
        abrirOltHuawei();
        var ov = document.getElementById('oltOverlay');
        if (ov) ov.style.setProperty('display', 'none', 'important');   // a janela cheia não aparece aqui
        document.body.style.overflow = '';   // abrirOltHuawei() trava a rolagem da página para a janela cheia
        oltAprovisionamento();
        return true;
      }


      // ATUALIZAR BUSCA — reconsulta a OLT e remonta a lista de ONUs aguardando liberação.
      //
      // ATENÇÃO AO DETALHE QUE QUEBRAVA: depois de ancorado, o card (#oltApWin) NÃO está mais
      // dentro de #oltApModal — ele foi movido para a página. Remover só a camada deixava o card
      // antigo na tela, e o oltAprovisionamento() montava OUTRO. Resultado: dois cards.
      // Por isso a limpeza esvazia a âncora E remove a camada, antes de remontar.
      var btn = document.getElementById('wsOltAtualizar');
      var quando = document.getElementById('wsOltQuando');

      // TROCA SEM PISCAR.
      // Antes o botão esvaziava a âncora ANTES de montar o card novo — a tela ficava em branco
      // durante a consulta e depois "voltava", que é a piscada. Agora o card antigo continua
      // visível enquanto o novo é montado fora da tela; a troca acontece de uma vez só, no fim.
      function marcarAntigo() {
        var atual = alvo ? alvo.querySelector('#oltApWin') : null;
        if (atual) { atual.id = 'oltApWinAntigo'; atual.setAttribute('data-ws-antigo', '1'); }
        var m = document.getElementById('oltApModal');
        if (m) m.remove();
      }
      function removerAntigo() {
        var velho = document.querySelector('[data-ws-antigo="1"]');
        if (velho) velho.remove();
      }

      function marcarHora() {
        if (quando) quando.textContent = 'atualizado às ' + new Date().toLocaleTimeString('pt-BR').slice(0, 5);
      }

      function atualizar() {
        if (typeof oltAprovisionamento !== 'function') return;
        if (btn) { btn.disabled = true; btn.textContent = '⏳ consultando a OLT…'; }
        marcarAntigo();                 // não apaga: só tira do caminho, ainda visível
        if (typeof oltCarregarStatus === "function") { try { oltCarregarStatus(); } catch (e) {} }
        oltAprovisionamento();
        var n = 0;
        var t = setInterval(function () {
          if (ancorar()) {
            clearInterval(t);
            removerAntigo();            // só some quando o novo já está na tela
            if (btn) { btn.disabled = false; btn.textContent = '↻ Atualizar Busca'; }
            marcarHora();
          } else if (++n > 60) {
            clearInterval(t);
            removerAntigo();
            if (btn) { btn.disabled = false; btn.textContent = '↻ Atualizar Busca'; }
          }
        }, 200);
      }
      /* O botao vermelho da barra passa a usar a MESMA rotina do card: oltApAtualizarBusca().
         A antiga (atualizar(), logo acima) remontava o card inteiro — era o que piscava. A nova so'
         refaz a consulta e reescreve o corpo do card, sem descartar nada. O botao continua onde
         estava e com a cor vermelha; muda so' o que ele chama.
         atualizar() fica no arquivo como reserva: se o olt_ui.js nao tiver carregado, ela responde. */
      function dispararAtualizacao() {
          if (typeof oltApAtualizarBusca === 'function') { oltApAtualizarBusca(btn); marcarHora(); return; }
          atualizar();
      }
      if (btn) btn.addEventListener('click', dispararAtualizacao);

      /* AUTO-ATUALIZAR A CADA 60s.
         ONU nova aparece na OLT a qualquer momento; deixar a lista parada até alguém clicar
         significa cliente esperando à toa. O ciclo usa a MESMA rotina do botão (não recarrega a
         página, não pisca) e é pausado quando:
           - a aba está em segundo plano (document.hidden) — consulta à OLT é cara e ninguém está
             olhando; quem avisa nesse caso é o sino do Painel;
           - o botão está desabilitado, ou seja, uma consulta ainda está em curso — sem isso duas
             leituras se atropelariam na OLT. */
      setInterval(function () {
          if (document.hidden) return;
          if (btn && btn.disabled) return;
          dispararAtualizacao();
      }, 60000);
      // Ao voltar para a aba depois de um tempo, atualiza uma vez em vez de esperar o próximo ciclo.
      document.addEventListener('visibilitychange', function () {
          if (!document.hidden && !(btn && btn.disabled)) dispararAtualizacao();
      });


      // DIAGNÓSTICO SOB DEMANDA — só roda quando o operador clica.
      // Rodar na abertura dava resultado errado: as funções do olt_ui.js ainda não existiam e
      // apareciam dois ❌ falsos. Clicando, o módulo já carregou e o retrato é o real.
      var diagBtn = document.getElementById('wsOltDiagBtn');
      var diagBox = document.getElementById('wsOltDiag');
      var diagOut = document.getElementById('wsOltDiagLinhas');

      function diagnosticar() {
        var l = [];
        var put = function (ok, txt) { l.push('<div>' + (ok ? '✅' : '❌') + ' ' + txt + '</div>'); render(); };
        var info = function (txt)    { l.push('<div>•&nbsp; ' + txt + '</div>'); render(); };
        var render = function ()     { if (diagOut) diagOut.innerHTML = l.join(''); };

        put(typeof abrirOltHuawei === 'function', 'módulo olt_ui.js carregado');
        put(typeof oltAprovisionamento === 'function', 'função do card disponível');

        var t0 = Date.now();
        fetch('olt_huawei.php?acao=cache_get', { cache: 'no-store' })
          .then(function (r) { put(r.ok, 'backend olt_huawei.php: HTTP ' + r.status + ' em ' + (Date.now() - t0) + 'ms'); return r.ok ? r.json() : null; })
          .then(function (d) {
            if (!d) { info('sem resposta do backend — verifique o caminho do arquivo'); return; }
            put(d.status === 'ok', 'resposta do backend: status=' + (d.status || '?'));
            var n = (d.onus && d.onus.length) || 0;
            put(n > 0, 'ONUs no cache: ' + n + (d.idade != null ? '  (cache de ' + d.idade + 's atrás)' : ''));
          })
          .catch(function (e) { put(false, 'falha ao chamar o backend: ' + e.message); });

        var win = document.getElementById('oltApWin');
        put(!!win, 'card do Aprovisionamento montado');
        if (win) {
          put(win.closest('#wsOltAprov') !== null, 'card ancorado na página (não flutuando)');
          info('linhas na lista do card: ' + win.querySelectorAll('tbody tr').length);
        }
        var ovf = document.getElementById('oltOverlay');
        info('janela cheia do gerenciador: ' + (ovf && ovf.style.display !== 'none' ? 'VISÍVEL (não deveria)' : 'escondida, correto'));
      }

      if (diagBtn) diagBtn.addEventListener('click', function () {
        if (!diagBox) return;
        diagBox.hidden = !diagBox.hidden;
        diagBtn.textContent = diagBox.hidden ? '🔎 Diagnóstico' : '✖ Fechar diagnóstico';
        if (!diagBox.hidden) diagnosticar();
      });
      // iniciar() roda UMA vez: antes era chamado a cada 200ms até o card aparecer, e cada chamada
      // do abrirOltHuawei() começava outra varredura na OLT (Telnet) por cima da anterior.
      var n = 0, iniciado = false;
      var t = setInterval(function () {
        if (!iniciado) iniciado = iniciar();
        if (iniciado && ancorar()) { clearInterval(t); setInterval(ancorar, 1500); }  // o card é recriado ao atualizar
        if (++n > 60) clearInterval(t);
      }, 200);
    })();
    </script>
    <?php
}
