<?php
/**
 * WellSystem OLT — HISTÓRICO DE CONEXÕES DE UMA ONU/CLIENTE (21/10/2026). SÓ LEITURA, arquivo à parte (não toca olt_huawei.php nem a coleta).
 *
 * Linha do tempo das sessões do RADIUS (radacct) de um login: quando conectou, quando caiu, por quê (causa), quanto durou, IP e concentrador.
 *   GET olt_historico.php?login=<login PPPoE, login IPoE ou SN>&dias=30   (dias: 1 a 90)
 *   -> {ok, login, nome, dias, resumo:{sessoes, quedas, perdas}, itens:[{inicio, fim, dur_s, causa, causa_cod, ip, nas}]}   (até 300 sessões, a mais recente primeiro)
 * Acesso: login da OLT, nível 1 (leitura) ou mais — mesma sessão da página da OLT. Nada é gravado.
 */
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
$__ws_olt_root_op = null;
if (session_status() === PHP_SESSION_ACTIVE) { $__ws_olt_root_op = $_SESSION['ws_user'] ?? null; @session_write_close(); }
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
error_reporting(0); ini_set('display_errors', 0);
@set_time_limit(60);

function his_json(array $d, int $http = 200): void { http_response_code($http); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
if (!is_file(__DIR__ . '/olt_auth.php')) his_json(['ok' => false, 'erro' => 'olt_auth.php não encontrado.'], 500);
require_once __DIR__ . '/olt_auth.php';
if (!function_exists('olt_auth_nivel') || olt_auth_nivel() < 1) his_json(['ok' => false, 'erro' => 'Faça login na OLT.'], 401);

$login = trim((string)($_GET['login'] ?? ''));
$dias = max(1, min(90, (int)($_GET['dias'] ?? 30)));
if ($login === '' || strlen($login) > 80) his_json(['ok' => false, 'erro' => 'Informe o login do cliente.'], 400);
try {
    $db = ws_db();
    // Todos os "nomes" que esse cliente usa no RADIUS: o informado + login PPPoE/IPoE do contrato (e SN) que casarem.
    $nomes = [$login]; $nomeCli = '';
    $q = $db->prepare("SELECT ct.login_pppoe, ct.login_ipoe, c.nome FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                       WHERE ct.status <> 'cancelado' AND (UPPER(ct.login_pppoe) = UPPER(?) OR UPPER(ct.login_ipoe) = UPPER(?) OR UPPER(REPLACE(REPLACE(ct.sn_onu,'-',''),' ','')) = UPPER(?))
                       ORDER BY (ct.status = 'ativo') DESC, ct.id LIMIT 1");
    $q->execute([$login, $login, $login]); $r = $q->fetch(PDO::FETCH_ASSOC);
    if ($r) { $nomeCli = (string)$r['nome']; foreach (['login_pppoe', 'login_ipoe'] as $k) if (!empty($r[$k])) $nomes[] = (string)$r[$k]; }
    $nomes = array_values(array_unique($nomes));
    $in = implode(',', array_fill(0, count($nomes), '?'));
    $desde = date('Y-m-d H:i:s', time() - $dias * 86400);
    $st = $db->prepare("SELECT acctstarttime, acctstoptime, acctsessiontime, acctterminatecause, framedipaddress, nasipaddress
                        FROM radacct WHERE username IN ($in) AND (acctstoptime IS NULL OR acctstoptime >= ?)
                        ORDER BY acctstarttime DESC LIMIT 300");
    $st->execute(array_merge($nomes, [$desde]));
    $nomeCausa = ['Lost-Carrier' => 'perda de sinal', 'Lost-Service' => 'perda de serviço', 'Port-Error' => 'erro de porta', 'NAS-Error' => 'erro no concentrador',
                  'User-Request' => 'cliente/roteador reiniciou', 'NAS-Request' => 'pedido do concentrador', 'Idle-Timeout' => 'tempo ocioso', 'Session-Timeout' => 'limite de sessão',
                  'Admin-Reset' => 'reiniciado pelo operador', 'Admin-Reboot' => 'reinício pelo operador', 'NAS-Reboot' => 'reinício do concentrador',
                  'Ws-Derrubada' => 'derrubada pelo sistema', 'Ws-Mesmo-MAC' => 'derrubada pelo sistema (mesmo MAC)', 'Ws-Sem-Atualizacao' => 'sessão sem atualização'];
    $nasNome = [];
    try { foreach ($db->query("SELECT nasname, shortname FROM nas")->fetchAll(PDO::FETCH_ASSOC) as $n) $nasNome[(string)$n['nasname']] = (string)$n['shortname']; } catch (Throwable $e) {}
    $itens = []; $quedas = 0; $perdas = 0;
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $causa = (string)$s['acctterminatecause']; $fim = $s['acctstoptime'];
        if ($fim !== null && strpos($causa, 'Ws-') !== 0 && !in_array($causa, ['Admin-Reset', 'Admin-Reboot', 'NAS-Reboot'], true)) { $quedas++; if (in_array($causa, ['Lost-Carrier', 'Lost-Service', 'Port-Error', 'NAS-Error'], true)) $perdas++; }
        $itens[] = ['inicio' => (string)$s['acctstarttime'], 'fim' => $fim === null ? '' : (string)$fim, 'dur_s' => (int)$s['acctsessiontime'],
                    'causa' => $fim === null ? 'conectado agora' : ($nomeCausa[$causa] ?? ($causa !== '' ? $causa : '—')), 'causa_cod' => $causa,
                    'ip' => (string)$s['framedipaddress'], 'nas' => $nasNome[(string)$s['nasipaddress']] ?? (string)$s['nasipaddress']];
    }
    his_json(['ok' => true, 'login' => $login, 'nome' => $nomeCli, 'dias' => $dias, 'resumo' => ['sessoes' => count($itens), 'quedas' => $quedas, 'perdas' => $perdas], 'itens' => $itens]);
} catch (Throwable $e) {
    his_json(['ok' => false, 'erro' => 'Não consegui consultar o histórico de sessões.'], 500);
}
