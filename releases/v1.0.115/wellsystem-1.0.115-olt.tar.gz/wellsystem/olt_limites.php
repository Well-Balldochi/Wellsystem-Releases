<?php
/**
 * WellSystem OLT — LIMITES DE SINAL (21/10/2026). Arquivo à parte: não toca olt_huawei.php nem a coleta da OLT.
 *
 * O operador define o SINAL BASE (dBm) de aceitação: abaixo dele a ONU é classificada como RUIM. Vale para a OLT toda e, se quiser,
 * por PON (F/S/P). Regra derivada do mesmo padrão de sempre: RUIM abaixo da base; vermelho até base+0,3; âmbar até base+1,4
 * (com a base padrão -29,4 dá exatamente os -29,1 / -28 que a página já usava). Sem nada salvo, nada muda.
 *
 *   GET  olt_limites.php                -> {ok, global: número|null, pon: {"0/1/2": número, ...}}      (nível 1+)
 *   POST olt_limites.php  (global=-29.4&pon={"0/1/2":-27.5})  + cabeçalho X-Olt-Limites: 1              (nível 2+)
 * Guarda em cache_trafego/olt_limites_sinal.json (entra no backup). Valores aceitos: -45 a -10 dBm.
 */
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
$__ws_olt_root_op = null;
if (session_status() === PHP_SESSION_ACTIVE) { $__ws_olt_root_op = $_SESSION['ws_user'] ?? null; @session_write_close(); }
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
error_reporting(0); ini_set('display_errors', 0);

function lim_json(array $d, int $http = 200): void { http_response_code($http); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
if (!is_file(__DIR__ . '/olt_auth.php')) lim_json(['ok' => false, 'erro' => 'olt_auth.php não encontrado.'], 500);
require_once __DIR__ . '/olt_auth.php';
$nivel = function_exists('olt_auth_nivel') ? olt_auth_nivel() : 0;
if ($nivel < 1) lim_json(['ok' => false, 'erro' => 'Faça login na OLT.'], 401);

$dir = __DIR__ . '/cache_trafego'; $arq = $dir . '/olt_limites_sinal.json';
function lim_num($v): ?float { if ($v === null || $v === '') return null; $n = (float)str_replace(',', '.', trim((string)$v)); return ($n <= -10 && $n >= -45) ? round($n, 2) : null; }

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if ($nivel < 2) lim_json(['ok' => false, 'erro' => 'Sem permissão (precisa de nível 2 ou mais).'], 403);
    if (($_SERVER['HTTP_X_OLT_LIMITES'] ?? '') !== '1') lim_json(['ok' => false, 'erro' => 'Pedido inválido.'], 400);
    $g = lim_num($_POST['global'] ?? null);
    if (($_POST['global'] ?? '') !== '' && $g === null) lim_json(['ok' => false, 'erro' => 'Sinal base fora do aceito (use entre -45 e -10 dBm).'], 422);
    $pj = json_decode((string)($_POST['pon'] ?? '{}'), true); $pon = [];
    if (is_array($pj)) foreach ($pj as $k => $v) {
        if (!preg_match('#^\d{1,2}/\d{1,2}/\d{1,2}$#', (string)$k)) continue;
        $n = lim_num($v); if ($n === null) { if ($v !== '' && $v !== null) lim_json(['ok' => false, 'erro' => 'Valor inválido na PON ' . $k . ' (use entre -45 e -10 dBm).'], 422); continue; }
        $pon[(string)$k] = $n;
    }
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) lim_json(['ok' => false, 'erro' => 'Não consegui criar a pasta de dados.'], 500);
    $ok = @file_put_contents($arq, json_encode(['global' => $g, 'pon' => $pon, 'em' => date('c')], JSON_UNESCAPED_UNICODE), LOCK_EX);
    if ($ok === false) lim_json(['ok' => false, 'erro' => 'Não consegui gravar (permissão na pasta cache_trafego).'], 500);
    @chmod($arq, 0640);
    lim_json(['ok' => true, 'global' => $g, 'pon' => (object)$pon]);
}
$j = is_file($arq) ? json_decode((string)@file_get_contents($arq), true) : [];
lim_json(['ok' => true, 'global' => isset($j['global']) ? $j['global'] : null, 'pon' => (object)(is_array($j['pon'] ?? null) ? $j['pon'] : [])]);
