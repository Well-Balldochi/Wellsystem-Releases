<?php
/**
 * WellSystem — Motor de Telnet da OLT (Huawei MA5683T/família) — NATIVO.
 *
 * Isto NÃO é uma chamada pra um addon externo: é o mesmo motor de telnet do
 * addon original (olt_huawei.php), portado linha a linha pra dentro do próprio
 * código do WellSystem. Os comandos Huawei enviados são EXATAMENTE os mesmos já
 * testados em produção — não inventei sintaxe nova (isso seria arriscado demais
 * pra hardware de rede real). O que mudou foi só ONDE o código mora e de ONDE
 * ele lê a conexão: agora é 100% WellSystem (banco de dados, sessão, cache),
 * sem depender de nenhum arquivo/pasta de addon externo.
 *
 * Conexão: usa o host/porta/usuário/senha cadastrados no RAMAL selecionado
 * (Cadastros → Ramais → "OLT deste ramal"); sem ramal selecionado ("Todas as
 * cidades"), usa a conexão global salva em cache/olt_nativo.json.
 */
require_once __DIR__ . '/config.php';

/* ============================================================= CONEXÃO ============================================================= */

/**
 * Lê a conexão da OLT a usar agora: do ramal selecionado, ou a global.
 *
 * $somenteGlobal = true ignora o ramal e devolve SEMPRE a conexão global (o JSON).
 * Existe por um motivo prático e que já custou caro: a tela "Conexão com a OLT" edita a
 * conexão GLOBAL — salvar é sempre no JSON. Se ela CARREGASSE os dados do ramal (porque
 * havia uma cidade selecionada no topo), o operador digitaria a senha certa, salvaria, e a
 * tela voltaria mostrando a senha antiga do ramal. Sintoma: "a senha da OLT não entra",
 * como se alguém a tivesse apagado. Quem lê para CONECTAR usa a forma normal; quem EDITA a
 * conexão global usa esta.
 */
function ws_olt_conexao(PDO $db, bool $somenteGlobal = false): array {
    $def = ['ip' => '', 'porta' => 23, 'user' => '', 'pass' => '', 'timeout' => 8];
    $ramal = $somenteGlobal ? null : ws_ramal_atual();
    if ($ramal) {
        $st = $db->prepare("SELECT olt_host, olt_porta, olt_usuario, olt_senha FROM ws_ramal WHERE id=?");
        $st->execute([$ramal['id']]); $r = $st->fetch();
        if ($r && !empty($r['olt_host'])) {
            return array_merge($def, ['ip' => $r['olt_host'], 'porta' => (int)($r['olt_porta'] ?: 23),
                'user' => (string)$r['olt_usuario'], 'pass' => (string)$r['olt_senha']]);
        }
    }
    $f = WS_CACHE . '/olt_nativo.json';
    if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) return array_merge($def, $j); }
    return $def;
}
function ws_olt_conexao_salvar(array $c): void {
    @file_put_contents(WS_CACHE . '/olt_nativo.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/olt_nativo.json', 0640);
}

/* VÁRIAS OLTs NO ERP (20/11/2026): cada cidade (ramal) pode ter a sua OLT. Os arquivos de cache do ERP (fila de autorização,
   lista de autorizadas, perfis, SNMP) eram únicos — a fila de uma cidade apareceria na outra. Agora a OLT PRINCIPAL (conexão
   global; sem ela, a do primeiro ramal com OLT) mantém os nomes de sempre e qualquer OLT de OUTRO IP leva o IP no nome do
   arquivo. Com uma OLT só (ou várias cidades na mesma OLT) nada muda. */
function ws_olt_ip_principal(PDO $db): string {
    static $ip = null; if ($ip !== null) return $ip;
    $ip = trim((string)(ws_olt_conexao($db, true)['ip'] ?? ''));
    if ($ip === '') { try { $ip = trim((string)$db->query("SELECT olt_host FROM ws_ramal WHERE COALESCE(olt_host,'')<>'' ORDER BY id LIMIT 1")->fetchColumn()); } catch (Throwable $e) { $ip = ''; } }
    return $ip;
}
function ws_olt_sufixo(PDO $db, ?array $cx = null): string {
    $ip = trim((string)(($cx ?? ws_olt_conexao($db))['ip'] ?? ''));
    return ($ip === '' || $ip === ws_olt_ip_principal($db)) ? '' : '_' . preg_replace('/[^0-9A-Za-z]/', '_', $ip);
}
/** Arquivo de cache do ERP para a OLT em uso ($base sem ".json"). */
function ws_olt_cache_arq(PDO $db, string $base, ?array $cx = null): string { return WS_CACHE . '/' . $base . ws_olt_sufixo($db, $cx) . '.json'; }

/* Perfis padrão usados ao autorizar (ajustáveis em Config, mesma ideia do addon original). */
function ws_olt_perfis(?PDO $db = null): array {
    $f = $db ? ws_olt_cache_arq($db, 'olt_perfis') : WS_CACHE . '/olt_perfis.json';
    $def = ['lineprofile' => 1, 'srvprofile' => 11, 'srv_router' => 11, 'srv_bridge' => 11];
    if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) return array_merge($def, $j); }
    return $def;
}

/* ============================================================= MOTOR TELNET =============================================================
 * Portado do addon original (olt_huawei.php) — mesmas regex de prompt, mesmo
 * tratamento de paginação "---- More ----", mesmo mutex por IP (evita esgotar
 * as poucas linhas VTY da OLT quando duas ações rodam ao mesmo tempo). */

const WS_OLT_RX_PROMPT = '/(?:^|\n)[ \t]*[A-Za-z][\w\-.]*(?:\([^)\n]*\))?[>#][ \t]*$/';
const WS_OLT_RX_USER   = '/(user\s*name|login)\s*:\s*$/i';
const WS_OLT_RX_PASS   = '/pass\s*word\s*:\s*$/i';

/** Descarta bytes de controle Telnet (IAC) sem responder — a MA5683T aceita assim. */
function ws_olt_iac(string $raw): string {
    $texto = ''; $i = 0; $n = strlen($raw);
    while ($i < $n) {
        $c = ord($raw[$i]);
        if ($c !== 255) { $texto .= $raw[$i]; $i++; continue; }
        $cmd = ($i + 1 < $n) ? ord($raw[$i + 1]) : 0;
        if ($cmd === 255) { $texto .= chr(255); $i += 2; continue; }
        if ($cmd >= 251 && $cmd <= 254) { $i += 3; continue; }
        if ($cmd === 250) { $j = $i + 2; while ($j + 1 < $n && !(ord($raw[$j]) === 255 && ord($raw[$j + 1]) === 240)) $j++; $i = $j + 2; continue; }
        $i += 2;
    }
    return $texto;
}

/** Lê do socket até casar o prompt no fim do buffer, tratando paginação "More". */
function ws_olt_ler_ate($socket, string $regexPrompt, float $idleTimeout): string {
    $buffer = ''; $ultimo = microtime(true);
    while (true) {
        if ((microtime(true) - $ultimo) > $idleTimeout) break;
        $trecho = @fread($socket, 8192);
        if ($trecho === false) break;
        if ($trecho === '') {
            $meta = stream_get_meta_data($socket);
            if (!empty($meta['timed_out'])) {
                $limpoTmp = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
                if ($regexPrompt && preg_match($regexPrompt, rtrim($limpoTmp))) break;
                if ((microtime(true) - $ultimo) > $idleTimeout) break;
            }
            usleep(30000); continue;
        }
        $trecho = ws_olt_iac($trecho);
        if ($trecho === '') { usleep(10000); continue; }
        $buffer .= $trecho; $ultimo = microtime(true);
        if (preg_match('/----\s*More/i', $buffer)) {
            @fwrite($socket, ' ');
            $buffer = preg_replace('/\s*----\s*More.*?----\s*/is', "\n", $buffer);
            continue;
        }
        $limpo = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
        if ($regexPrompt && preg_match($regexPrompt, rtrim($limpo))) break;
        if (preg_match('/\{\s*<cr>/i', $limpo) || preg_match('/\}\s*:\s*$/', rtrim($limpo))) break;
    }
    return preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
}

/** Login + execução dos comandos, sincronizando por prompt (1 tentativa). */
function ws_olt_telnet_exec(string $ip, int $porta, string $user, string $pass, array $comandos, float $idleTimeout = 8): array {
    $socket = @fsockopen($ip, $porta, $errno, $errstr, (int)$idleTimeout);
    if (!$socket) throw new RuntimeException("Falha ao conectar na OLT ($ip:$porta): $errstr");
    stream_set_blocking($socket, true); stream_set_timeout($socket, 2);

    $saida = ws_olt_ler_ate($socket, WS_OLT_RX_USER, $idleTimeout);
    if (!preg_match(WS_OLT_RX_USER, rtrim($saida))) { @fclose($socket); throw new RuntimeException("AUTH_RETRY: prompt de usuário não recebido."); }
    @fwrite($socket, $user . "\r\n");
    $saida = ws_olt_ler_ate($socket, WS_OLT_RX_PASS, $idleTimeout);
    if (!preg_match(WS_OLT_RX_PASS, rtrim($saida))) { @fclose($socket); throw new RuntimeException("AUTH_RETRY: prompt de senha não recebido."); }
    @fwrite($socket, $pass . "\r\n");
    $saida = ws_olt_ler_ate($socket, WS_OLT_RX_PROMPT, $idleTimeout + 5);
    if (preg_match(WS_OLT_RX_PASS, rtrim($saida)) || !preg_match(WS_OLT_RX_PROMPT, rtrim($saida))) {
        @fwrite($socket, "quit\r\n"); @fclose($socket); throw new RuntimeException("AUTH_RETRY: não chegou ao prompt de comando (usuário/senha da OLT corretos?).");
    }

    $out = [];
    foreach ($comandos as $cmd) {
        @fwrite($socket, $cmd . "\r\n");
        $resp = ws_olt_ler_ate($socket, WS_OLT_RX_PROMPT, $idleTimeout);
        $g = 0;
        while ($g++ < 6 && !preg_match(WS_OLT_RX_PROMPT, rtrim($resp))) {
            $tail = rtrim($resp);
            if (preg_match(WS_OLT_RX_PASS, $tail)) { @fwrite($socket, $pass . "\r\n"); }
            elseif (preg_match('/\}\s*:\s*$/', $tail) || preg_match('/\{\s*<cr>/i', $tail)) { @fwrite($socket, "\r\n"); }
            elseif (preg_match('/\(\s*y\s*\/\s*n\s*\)\s*[\[\(]?\s*[yn]?\s*[\]\)]?\s*:?\s*$/i', $tail) || preg_match('/are\s+you\s+sure|tem\s+certeza/i', $tail)) { @fwrite($socket, "y\r\n"); }
            else { @fwrite($socket, "\r\n"); }
            $resp .= "\n" . ws_olt_ler_ate($socket, WS_OLT_RX_PROMPT, $idleTimeout);
        }
        $out[] = $resp;
    }
    // Logout de verdade: "quit" até a OLT fechar (um só sai de 1 nível e a sessão ficava presa,
    // estourando o limite "Reenter times have reached the upper limit").
    for ($k = 0; $k < 6; $k++) {
        if (@feof($socket)) break;
        @fwrite($socket, "quit\r\n");
        $r = ws_olt_ler_ate($socket, '/(?:[>#]|\(y\/n\)[^\r\n]*:?)\s*$/i', 2);
        if (preg_match('/\(\s*y\s*\/\s*n\s*\)|log\s*out|are\s+you\s+sure/i', $r)) { @fwrite($socket, "y\r\n"); ws_olt_ler_ate($socket, '/\bnao-existe-esse-prompt\b/', 1); break; }
        if ($r === '' && @feof($socket)) break;
    }
    @fclose($socket);
    return $out;
}

/** Mutex por IP (só 1 sessão telnet por OLT de cada vez — a MA5683T tem poucas linhas VTY). */
/* MESMA TRAVA do motor principal (olt_huawei.php, olt_telnet_lock): arquivo olt_telnet_<ip>.lock em
   cache_trafego (visível pela tela E pelo cron; /tmp só se não gravar). Antes era um arquivo separado
   em /tmp: os dois motores abriam Telnet ao mesmo tempo e esgotavam as sessões VTY da OLT. NÃO separar. */
function ws_olt_lock(string $ip, float $maxWait = 30.0): array {
    static $dir = null;
    if ($dir === null) {
        $dir = sys_get_temp_dir();
        $c = __DIR__ . '/cache_trafego';
        if (!is_dir($c)) @mkdir($c, 0777, true);
        $t = $c . '/.__lk' . getmypid() . mt_rand();
        if (@file_put_contents($t, '1') !== false) { @unlink($t); $dir = $c; }
    }
    $path = $dir . '/olt_telnet_' . preg_replace('/[^0-9A-Za-z]/', '_', $ip) . '.lock';
    $f = @fopen($path, 'c'); if (!$f) return ['fp' => null, 'held' => false];
    @chmod($path, 0666);
    $deadline = microtime(true) + $maxWait;
    while (!@flock($f, LOCK_EX | LOCK_NB)) { if (microtime(true) >= $deadline) return ['fp' => $f, 'held' => false]; usleep(120000); }
    return ['fp' => $f, 'held' => true];
}
function ws_olt_unlock(array $lock): void {
    if (empty($lock['fp'])) return;
    if (!empty($lock['held'])) @flock($lock['fp'], LOCK_UN);
    @fclose($lock['fp']);
}

/** Executa com retry (reconecta em falha transitória de autenticação/VTY) — igual ao original. */
function ws_olt_exec(string $ip, int $porta, string $user, string $pass, array $comandos, float $idleTimeout = 8, int $tentativas = 2): array {
    $lock = ws_olt_lock($ip); $ultimo = null;
    // uma sessão por vez (limite de logins simultâneos do usuário na OLT) — ver olt_exec() no olt_huawei.php
    if (empty($lock['held']) && !empty($lock['fp'])) { ws_olt_unlock($lock); throw new RuntimeException('OLT ocupada: outra consulta está usando a sessão Telnet — tente de novo em instantes.'); }
    for ($i = 0; $i < $tentativas; $i++) {
        try { $r = ws_olt_telnet_exec($ip, $porta, $user, $pass, $comandos, $idleTimeout); ws_olt_unlock($lock); return $r; }
        catch (Throwable $e) { $ultimo = $e; usleep(600000 * ($i + 1)); }
    }
    ws_olt_unlock($lock);
    throw new RuntimeException("Falha ao comunicar com a OLT após $tentativas tentativas: " . ($ultimo ? $ultimo->getMessage() : 'desconhecido'));
}

/* ============================================================= PARSERS ============================================================= */

function ws_olt_sn_norm(string $s): string { return strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $s)); }

/** Parser do "display ont autofind all" — mesma regex do addon original. */
function ws_olt_parse_autofind(string $saida): array {
    $saida = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $saida);
    $blocos = preg_split('/(?=F\s*\/\s*S\s*\/\s*P)/i', $saida);
    $lista = []; $vistos = [];
    foreach ($blocos as $b) {
        if (!preg_match('#F\s*/\s*S\s*/\s*P\s*:?\s*([0-9]+\s*/\s*[0-9]+\s*/\s*[0-9]+)#i', $b, $mf)) continue;
        if (!preg_match('/(?:Ont\s*)?S\s*N\s*(?:\(.*?\))?\s*:?\s*([0-9A-Za-z]{4}[-\s]?[0-9A-Fa-f]{8,12}|[0-9A-Fa-f]{12,16})/i', $b, $ms)) continue;
        $sn = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $ms[1]));
        $fsp = preg_replace('/\s+/', '', $mf[1]);
        $key = $fsp . '|' . $sn; if (isset($vistos[$key])) continue; $vistos[$key] = 1;
        $modelo = '';
        if (preg_match('/EquipmentID\s*:?\s*(\S+)/i', $b, $me)) $modelo = $me[1];
        elseif (preg_match('/VendorID\s*:?\s*(\S+)/i', $b, $mv)) $modelo = $mv[1];
        $tempo = preg_match('/(?:autofind|localiza\w*|encontr\w*)[^:\n]*:\s*([0-9][0-9:\-\s]{8,})/i', $b, $mt) ? trim($mt[1]) : '';
        $lista[] = ['fsp' => $fsp, 'sn' => $sn, 'modelo' => $modelo, 'tempo' => $tempo];
    }
    return $lista;
}

/** Config SNMP (community/porta) — do cache nativo, complementando IP/porta da conexão telnet. */
function ws_olt_snmp_cfg(array $cx): array {
    $f = ws_olt_cache_arq(ws_db(), 'olt_snmp', $cx);
    $def = ['host' => $cx['ip'], 'comm' => 'public', 'port' => 161];
    if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) return array_merge($def, $j, ['host' => $cx['ip']]); }
    return $def;
}
function ws_olt_snmp_bin(string $n): string { $p = @shell_exec('command -v ' . escapeshellarg($n) . ' 2>/dev/null'); return $p ? trim($p) : ''; }
function ws_olt_snmp_get(string $host, int $port, string $comm, string $oid): ?string {
    if (function_exists('snmp2_get')) { $r = @snmp2_get("$host:$port", $comm, $oid, 1000000, 1); if ($r !== false) return trim((string)$r, " \t\n\r\0\x0B\""); }
    $b = ws_olt_snmp_bin('snmpget');
    if ($b) { $o = @shell_exec($b . ' -v2c -Oqv -t 1 -r 1 -c ' . escapeshellarg($comm) . ' ' . escapeshellarg("$host:$port") . ' ' . escapeshellarg($oid) . ' 2>/dev/null'); if ($o !== null && trim($o) !== '') return trim($o, " \t\n\r\0\x0B\""); }
    return null;
}

/* ============================================================= OPERAÇÕES DE ALTO NÍVEL ============================================================= */

/** ONUs aguardando liberação — SEM force lê do cache (instantâneo); force=1 faz Telnet ao vivo. */
function ws_olt_autofind(PDO $db, bool $force = false): array {
    $cacheFile = ws_olt_cache_arq($db, 'olt_autofind_nativo');
    if (!$force) {
        if (is_file($cacheFile)) { $c = json_decode((string)@file_get_contents($cacheFile), true); if (is_array($c)) return $c; }
        return ['pendentes' => [], 'idade' => -1];
    }
    $cx = ws_olt_conexao($db);
    if ($cx['ip'] === '') throw new RuntimeException('Conexão da OLT não configurada (Cadastros → Ramais, ou Config global).');
    $out = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'],
        ['enable', 'config', 'display ont autofind all', 'quit', 'quit'], (float)$cx['timeout']);
    $pend = ws_olt_parse_autofind($out[2] ?? '');
    // esconde SNs que já estão autorizados (não deixa "voltar" pra fila).
    $reg = [];
    foreach ($db->query("SELECT UPPER(sn_onu) s FROM ws_contrato WHERE sn_onu IS NOT NULL AND sn_onu<>''")->fetchAll(PDO::FETCH_COLUMN) as $s) $reg[$s] = 1;
    if ($reg) $pend = array_values(array_filter($pend, fn($p) => !isset($reg[ws_olt_sn_norm($p['sn'])])));
    $r = ['pendentes' => $pend, 'idade' => 0, 'ts' => time()];
    @file_put_contents($cacheFile, json_encode($r, JSON_UNESCAPED_UNICODE)); @chmod($cacheFile, 0640);
    return $r;
}

/** Autoriza (libera) uma ONU pendente — porta fiel do fluxo real do addon original:
 *  1) relocaliza o SN no autofind AGORA (pega o F/S/P real, que pode ter mudado);
 *  2) "ont confirm ... sn-auth ..." (comando real de autorização Huawei);
 *  3) lê o ONT-ID atribuído pela OLT na resposta;
 *  4) cria o service-port (VLAN) se informado;
 *  5) grava o resultado no cache nativo (pra aparecer na lista de autorizadas). */
function ws_olt_autorizar(PDO $db, array $dados): array {
    $cx = ws_olt_conexao($db);
    if ($cx['ip'] === '') return ['status' => 'error', 'message' => 'Conexão da OLT não configurada.'];
    $fsp = preg_replace('/[^0-9\/]/', '', $dados['fsp'] ?? '');
    $sn  = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $dados['sn'] ?? ''));
    $nome = trim($dados['nome'] ?? '');
    $p = explode('/', $fsp);
    if (count($p) !== 3 || $sn === '' || $nome === '') return ['status' => 'error', 'message' => 'Informe F/S/P, SN e Nome para autorizar.'];
    $slot = (int)$p[1]; $port = (int)$p[2];
    $perfis = ws_olt_perfis($db);
    $lp = (int)($dados['lineprofile'] ?? $perfis['lineprofile']); if ($lp <= 0 || $lp > 4096) $lp = $perfis['lineprofile'];
    $sp = (int)($dados['srvprofile'] ?? $perfis['srvprofile']); if ($sp <= 0 || $sp > 4096) $sp = $perfis['srvprofile'];
    $modo = strtolower(trim($dados['modo'] ?? ''));
    if ($modo === 'router') $sp = $perfis['srv_router']; elseif ($modo === 'bridge') $sp = $perfis['srv_bridge'];
    $vlan = (int)($dados['vlan'] ?? 0);
    $zona = trim($dados['zona'] ?? '');
    $bairro = trim($dados['bairro'] ?? ''); $rua = trim($dados['rua'] ?? '');
    $cidade = trim($dados['cidade'] ?? ''); $numero = trim($dados['numero'] ?? '');
    $tec = strtolower(trim($dados['tecnologia'] ?? 'gpon'));
    $zonaC = trim(preg_replace('/[_"\r\n]+/', ' ', $zona));
    $desc = $zonaC !== ''
        ? substr($nome . '_zone_' . $zonaC, 0, 63)
        : substr(preg_replace('/["\r\n]+/', ' ', $nome . ($bairro ? ' ' . $bairro : '') . ($cidade ? ' ' . $cidade : '')), 0, 63);

    try {
        // PASSO 0 — relocaliza o SN no autofind AGORA: usa o F/S/P REAL (pode ter mudado desde
        // que a tela abriu). Evita "ONT does not exist" por F/S/P desatualizado.
        $outAf0 = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'],
            ['enable', 'config', 'display ont autofind all', 'quit'], (float)$cx['timeout']);
        $achou = null;
        foreach (ws_olt_parse_autofind($outAf0[2] ?? '') as $pnd) { if (ws_olt_sn_norm($pnd['sn']) === ws_olt_sn_norm($sn)) { $achou = $pnd; break; } }
        if (!$achou) {
            return ['status' => 'error', 'message' => "O SN $sn não está mais na lista de autofind da OLT (pode ter expirado ou já foi autorizado). Clique em Atualizar."];
        }
        $pr = explode('/', $achou['fsp']); if (count($pr) === 3) { $slot = (int)$pr[1]; $port = (int)$pr[2]; }
        $ifCmd = "interface gpon 0/$slot";

        // PASSO 1 — comando REAL de autorização Huawei (ont confirm ... sn-auth ...).
        $cmdConfirm = "ont confirm $port sn-auth $sn omci ont-lineprofile-id $lp ont-srvprofile-id $sp desc \"$desc\"";
        $out = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'],
            ['enable', 'config', $ifCmd, $cmdConfirm, 'quit', 'display ont autofind all', 'quit'], (float)$cx['timeout']);
        $rawConfirm = $out[3] ?? ''; $rawAutofind = $out[5] ?? '';
        $ontId = preg_match('/ONT\s*-?\s*ID\s*(?:is|:)?\s*(\d+)/i', $rawConfirm, $mo) ? (int)$mo[1] : null;
        $confirmOk = (bool)preg_match('/success\s*[:=]\s*1|ONT\s*-?\s*ID\s*[:=]/i', $rawConfirm);
        $aindaPend = false;
        foreach (ws_olt_parse_autofind($rawAutofind) as $pnd) { if (ws_olt_sn_norm($pnd['sn']) === ws_olt_sn_norm($sn)) { $aindaPend = true; break; } }
        $autorizada = $confirmOk && (!$aindaPend || $ontId !== null);

        // PASSO 2 — cria o service-port (VLAN), se informado, e confere o que ficou gravado.
        $rawVerif = ''; $srvAplicado = ''; $spRes = null;
        if ($autorizada && $ontId !== null) {
            usleep(400000);
            // service-port com o GEM real + native-vlan só em bridge (ws_olt_sp_criar)
            if ($vlan > 0) $spRes = ws_olt_sp_criar($cx, $slot, $port, (int)$ontId, $vlan, $lp, true);   // mesma regra do olt_huawei.php: native-vlan sempre
            $cmds = ['enable', 'config', $ifCmd, "display ont info $port $ontId"];
            $outVf = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'], $cmds, (float)$cx['timeout']);
            $rawVerif = end($outVf) ?: '';
            if (preg_match('/(?:Service[\s\-]*profile[\s\-]*name)\s*:\s*([^\r\n]+)/i', $rawVerif, $mv)) $srvAplicado = trim($mv[1]);
        }

        if ($autorizada) {
            // Grava no cache NATIVO do WellSystem (mesmo formato que ws_olt_autorizacoes() já lê).
            $af = ws_olt_cache_arq($db, 'olt_autorizacoes_nativo');
            $reg = is_file($af) ? (json_decode((string)@file_get_contents($af), true) ?: []) : [];
            if (!is_array($reg)) $reg = [];
            $reg[ws_olt_sn_norm($sn)] = [
                'sn' => $sn, 'fsp' => "0/$slot/$port", 'ont_id' => $ontId, 'nome' => $nome, 'vlan' => $vlan,
                'zona' => $zona, 'bairro' => $bairro, 'rua' => $rua, 'cidade' => $cidade, 'numero' => $numero,
                'tipo' => ($modo === 'router' ? 'ONT' : 'ONU'), 'modo' => $modo, 'tecnologia' => $tec,
                'data' => date('Y-m-d H:i:s'),
            ];
            @file_put_contents($af, json_encode($reg, JSON_UNESCAPED_UNICODE)); @chmod($af, 0640);
            // Tira da lista de pendentes na hora (não espera o próximo "Atualizar").
            $cacheFile = ws_olt_cache_arq($db, 'olt_autofind_nativo');
            if (is_file($cacheFile)) {
                $c = json_decode((string)@file_get_contents($cacheFile), true);
                if (is_array($c) && !empty($c['pendentes'])) {
                    $c['pendentes'] = array_values(array_filter($c['pendentes'], fn($pp) => ws_olt_sn_norm($pp['sn']) !== ws_olt_sn_norm($sn)));
                    @file_put_contents($cacheFile, json_encode($c, JSON_UNESCAPED_UNICODE));
                }
            }
        }
        $spFalhou = $spRes && !$spRes['ok'];
        return ['status' => 'ok', 'sucesso' => $autorizada, 'ont_id' => $ontId, 'fsp' => "0/$slot/$port", 'sn' => $sn,
            'sp_ok' => $spRes ? $spRes['ok'] : null, 'sp_gem' => $spRes ? $spRes['gem'] : null,
            'message' => !$autorizada ? 'A OLT não confirmou a autorização — veja "saida".'
                       : ($spFalhou ? "ONU autorizada, mas a OLT RECUSOU o service-port da VLAN $vlan — o cliente não vai navegar. Use Trocar VLAN (mesma VLAN) para recriar." : ''),
            'saida' => $rawConfirm . ($spRes ? "\n\n--- service-port (VLAN $vlan) ---\n" . $spRes['saida'] : '') . "\n\n--- verificação ---\n" . $rawVerif];
    } catch (Throwable $e) {
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}

/**
 * SERVICE-PORT COM O GEM CERTO (espelho de olt_sp_criar() do olt_huawei.php — mesma regra nos dois motores).
 * O "gemport 1" fixo era recusado pela OLT em line-profile com outro GEM (ex.: SMARTOLT_FLEXIBLE_GPON) e a
 * falha passava em silêncio: ONU online, cliente sem navegar ("No service virtual port can be operated").
 * Lê o line-profile da ONU, tenta cada GEM dele até a OLT aceitar e, em BRIDGE, põe a LAN 1 na VLAN
 * (native-vlan). Chamadas usam a regra ORIGINAL: native-vlan sempre, exceto modo 'router' explícito.
 * NÃO REMOVER / NÃO voltar para gemport fixo. Doc completa: olt_huawei.php, "PERFIS NA AUTORIZAÇÃO".
 */
function ws_olt_sp_criar(array $cx, int $slot, int $port, int $ontId, int $vlan, ?int $lpId = null, ?bool $bridge = null): array {
    $ex = function (array $cmds) use ($cx) { return ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'], $cmds, (float)$cx['timeout']); };
    $log = '';
    if (!$lpId || $bridge === null) {
        $o = $ex(['enable', 'config', "interface gpon 0/$slot", "display ont info $port $ontId"]);
        $info = (string)end($o);
        if (!$lpId) { $t = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $info);   // EN/PT
            if (preg_match('/Line[\s\-]*profile[\s\-]*ID\s*:?\s*(\d+)/i', $t, $m)) $lpId = (int)$m[1];
            else foreach (preg_split('/\r?\n/', $t) as $ln) { if (preg_match('/^\s*([^:]{3,60}?)\s*:\s*(\d+)\b/u', $ln, $mm) && preg_match('/profile|perfil/i', $mm[1]) && preg_match('/\bline|linha/i', $mm[1]) && preg_match('/\bid\b/i', $mm[1])) { $lpId = (int)$mm[2]; break; } } }
        if ($bridge === null) {
            $srv = preg_match('/Service[\s\-]*profile[\s\-]*name\s*:\s*([^\r\n]+)/i', $info, $m) ? strtoupper(trim($m[1])) : '';
            $bridge = !(strpos($srv, 'ONT-') === 0 || strpos($srv, 'ONT ') === 0);
        }
    }
    $gems = [];
    if ($lpId) {
        $o = $ex(['enable', 'config', 'display ont-lineprofile gpon profile-id ' . (int)$lpId]);
        if (preg_match_all('/(?:Gem\s*Index|[I\x{00CD}]ndice\s*(?:de\s*)?GEM|GEM\s*[I\x{00CD}]ndice)\s*[:=]?\s*(\d+)/iu', preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', (string)($o[2] ?? '')), $mm)) $gems = array_map('intval', $mm[1]);   // EN/PT
        $log .= "--- line-profile $lpId: GEM " . ($gems ? implode(', ', $gems) : '(nenhum lido)') . " ---\n";
    }
    $gems = $gems ? array_values(array_unique($gems)) : [1, 2, 3, 4];   // GEM não lido: tenta os mais comuns
    foreach ($gems as $g) {
        $cmd = "service-port vlan $vlan gpon 0/$slot/$port ont $ontId gemport $g multi-service user-vlan $vlan";
        $o = $ex(['enable', 'config', $cmd]); $raw = (string)($o[2] ?? '');
        $log .= "--- $cmd ---\n" . trim($raw) . "\n";
        // "has existed already" = service-port já existe -> sucesso (igual olt_sp_ja_existe no olt_huawei.php)
        if (preg_match('/has\s+existed\s+already|already\s+exist|j[aá]\s+existe/i', $raw) || !preg_match('/Failure|invalid|Parameter\s+error|Unknown\s+command|in\s+use|desconhecid/i', $raw)) {
            if ($bridge) {
                $o2 = $ex(['enable', 'config', "interface gpon 0/$slot", "ont port native-vlan $port $ontId eth 1 vlan $vlan priority 0"]);
                $log .= "--- native-vlan eth 1 vlan $vlan ---\n" . trim((string)end($o2)) . "\n";
            }
            return ['ok' => true, 'gem' => $g, 'lp' => $lpId, 'saida' => $log];
        }
    }
    return ['ok' => false, 'gem' => null, 'lp' => $lpId, 'saida' => $log];
}

/** Ações sobre uma ONU já provisionada: ativar, desativar, ressincronizar, excluir. */
function ws_olt_onu_acao(PDO $db, string $fsp, int $id, string $tipo): array {
    $cx = ws_olt_conexao($db);
    if ($cx['ip'] === '') return ['status' => 'error', 'sucesso' => false, 'message' => 'Conexão da OLT não configurada.'];
    $fsp = preg_replace('/[^0-9\/]/', '', $fsp); $p = explode('/', $fsp);
    if (count($p) !== 3) return ['status' => 'error', 'sucesso' => false, 'message' => 'F/S/P inválido.'];
    $slot = (int)$p[1]; $port = (int)$p[2]; $ifg = "interface gpon 0/$slot";

    if ($tipo === 'delete') {
        // A MA5683T NÃO deixa deletar uma ONT que ainda tem service-port ativo — por isso, antes de
        // desativar/deletar, descobre os índices dos service-ports dela e remove ("undo") cada um.
        // Fiel ao original: sem esse passo, o "ont delete" é recusado pela OLT em ONTs já com VLAN.
        try {
            $outSp = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'],
                ['enable', 'config', "display service-port port 0/$slot/$port ont $id", 'quit'], (float)$cx['timeout']);
        } catch (Throwable $e) {
            return ['status' => 'error', 'sucesso' => false, 'message' => $e->getMessage()];
        }
        $rawSp = $outSp[2] ?? '';
        $limpo = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $rawSp);
        $limpo = preg_replace('/(\d+\s+\d+\s+(?:common|transparent))/i', "\n$1", $limpo);
        $indices = [];
        foreach (explode("\n", $limpo) as $l) { $l = trim($l); if (preg_match('/^(\d+)\s+\d+\b/', $l, $m)) $indices[] = (int)$m[1]; }
        $indices = array_values(array_unique($indices));
        $cmds = ['enable', 'config'];
        foreach ($indices as $ix) $cmds[] = "undo service-port $ix";
        $cmds[] = "interface gpon 0/$slot"; $cmds[] = "ont deactivate $port $id"; $cmds[] = "ont delete $port $id";
    } else {
        $acoes = [
            'reboot'  => ["ont reset $port $id"],
            'resync'  => ["ont deactivate $port $id", "ont activate $port $id"],
            'block'   => ["ont deactivate $port $id"],
            'unblock' => ["ont activate $port $id"],
        ];
        if (!isset($acoes[$tipo])) return ['status' => 'error', 'sucesso' => false, 'message' => 'Ação inválida.'];
        $cmds = array_merge(['enable', 'config', $ifg], $acoes[$tipo]);
    }
    try {
        $out = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'], $cmds, (float)$cx['timeout']);
    } catch (Throwable $e) {
        return ['status' => 'error', 'sucesso' => false, 'message' => $e->getMessage()];
    }
    $raw = trim(implode("\n", array_slice($out, 3)));
    $ultimo = end($out) ?: '';
    $jaSumiu = (bool)preg_match('/does\s+not\s+exist|n[aã]o\s+exist|no\s+such|inexisten/i', $ultimo . "\n" . $raw);
    $sucesso = $jaSumiu || !preg_match('/(Failure|invalid|desconhecid|error)/i', $ultimo);
    return ['status' => 'ok', 'sucesso' => $sucesso, 'saida' => $raw];
}

/** Troca a VLAN de uma ONU (recria o service-port com a nova VLAN). */
function ws_olt_trocar_vlan(PDO $db, string $fsp, int $id, int $novaVlan): array {
    $cx = ws_olt_conexao($db);
    if ($cx['ip'] === '') return ['status' => 'error', 'sucesso' => false, 'message' => 'Conexão da OLT não configurada.'];
    if ($novaVlan < 1 || $novaVlan > 4094) return ['status' => 'error', 'sucesso' => false, 'message' => 'VLAN inválida (1..4094).'];
    $fsp = preg_replace('/[^0-9\/]/', '', $fsp); $p = explode('/', $fsp);
    if (count($p) !== 3) return ['status' => 'error', 'sucesso' => false, 'message' => 'F/S/P inválido.'];
    $slot = (int)$p[1]; $port = (int)$p[2];
    // Igual ao olt_huawei.php: remove os service-ports atuais da ONU (antes só criava outro e a ONU
    // ficava com DOIS, VLAN velha + nova) e cria o novo com o GEM real (ws_olt_sp_criar).
    try {
        $outSp = ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'],
            ['enable', 'config', "display service-port port 0/$slot/$port ont $id", 'quit'], (float)$cx['timeout']);
        $rawSp = $outSp[2] ?? '';
        $limpo = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $rawSp);
        $limpo = preg_replace('/(\d+\s+\d+\s+(?:common|transparent))/i', "\n$1", $limpo);
        $indices = [];
        foreach (explode("\n", $limpo) as $l) { $l = trim($l); if (preg_match('/^(\d+)\s+\d+\b/', $l, $m)) $indices[] = (int)$m[1]; }
        $indices = array_values(array_unique($indices));
        $rawUndo = '';
        if ($indices) {
            $cmds = ['enable', 'config']; foreach ($indices as $ix) $cmds[] = "undo service-port $ix";
            $rawUndo = trim(implode("\n", array_slice(ws_olt_exec($cx['ip'], (int)$cx['porta'], $cx['user'], $cx['pass'], $cmds, (float)$cx['timeout']), 2)));
        }
        $spRes = ws_olt_sp_criar($cx, $slot, $port, $id, $novaVlan, null, true);
    } catch (Throwable $e) {
        return ['status' => 'error', 'sucesso' => false, 'message' => $e->getMessage()];
    }
    return ['status' => 'ok', 'sucesso' => $spRes['ok'], 'sp_gem' => $spRes['gem'], 'indices' => $indices,
            'saida' => "--- service-ports atuais ---\n" . $rawSp . ($rawUndo !== '' ? "\n\n--- undo ---\n" . $rawUndo : '') . "\n\n--- novo (VLAN $novaVlan) ---\n" . $spRes['saida']];
}
