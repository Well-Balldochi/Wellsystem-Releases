<?php
/**
 * WellSystem OLT — OSCILAÇÃO DE CONEXÕES (21/10/2026). SÓ LEITURA, arquivo à parte (não toca olt_huawei.php nem a coleta da OLT).
 *
 * Quais conexões mais CAEM num período, a partir do histórico de sessões do RADIUS (radacct: cada queda = uma sessão que terminou).
 * Separa "perda de sinal/serviço" (Lost-Carrier, Lost-Service, Port-Error, NAS-Error) do restante (cliente/roteador reiniciou, tempo ocioso, etc.).
 * Ignora o que o PRÓPRIO sistema derrubou (causas "Ws-...": bloqueio, derrubada, mesmo MAC) e o reinício do concentrador. Nada é gravado.
 *
 *   GET olt_oscilacao.php?dias=7&min=3   (dias: 1 a 30; min: 1 a 50)  ->  JSON {ok, dias, min, desde, itens:[...], sem_historico}
 * Acesso: login da OLT, nível 1 (leitura) ou mais — mesma sessão da página da OLT.
 */
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
// Mesmo padrão do olt_huawei.php: a sessão do painel é lida e FECHADA antes da sessão própria da OLT (cookie WSOLTSESS) abrir.
$__ws_olt_root_op = null;
if (session_status() === PHP_SESSION_ACTIVE) { $__ws_olt_root_op = $_SESSION['ws_user'] ?? null; @session_write_close(); }
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
error_reporting(0); ini_set('display_errors', 0);
@set_time_limit(60);

function osc_json(array $d, int $http = 200): void { http_response_code($http); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }

if (!is_file(__DIR__ . '/olt_auth.php')) osc_json(['ok' => false, 'erro' => 'olt_auth.php não encontrado.'], 500);
require_once __DIR__ . '/olt_auth.php';
if (!function_exists('olt_auth_nivel') || olt_auth_nivel() < 1) osc_json(['ok' => false, 'erro' => 'Faça login na OLT para ver este relatório.'], 401);

$dias = max(1, min(30, (int)($_GET['dias'] ?? 7)));
$min  = max(1, min(50, (int)($_GET['min'] ?? 3)));
try {
    $db = ws_db();
    $desde = date('Y-m-d H:i:s', time() - $dias * 86400);
    // Histórico disponível: a sessão mais antiga do radacct (o accounting só conta a partir de quando o RADIUS passou a receber).
    $primeira = (string)$db->query("SELECT MIN(acctstarttime) FROM radacct")->fetchColumn();
    $st = $db->prepare("SELECT username,
                               COUNT(*) AS quedas,
                               SUM(acctterminatecause IN ('Lost-Carrier','Lost-Service','Port-Error','NAS-Error')) AS perdas,
                               MAX(acctstoptime) AS ultima,
                               ROUND(AVG(NULLIF(acctsessiontime,0))) AS dur_media
                        FROM radacct
                        WHERE acctstoptime IS NOT NULL AND acctstoptime >= ?
                          AND acctterminatecause NOT LIKE 'Ws-%' AND acctterminatecause NOT IN ('Admin-Reset','Admin-Reboot','NAS-Reboot')
                        GROUP BY username HAVING quedas >= ?
                        ORDER BY quedas DESC, perdas DESC LIMIT 300");
    $st->execute([$desde, $min]);
    $linhas = $st->fetchAll(PDO::FETCH_ASSOC);
    // Causa mais frequente por login (uma consulta só, para os logins da lista).
    $causa = []; $nomes = [];
    if ($linhas) {
        $us = array_column($linhas, 'username'); $in = implode(',', array_fill(0, count($us), '?'));
        $sc = $db->prepare("SELECT username, acctterminatecause AS causa, COUNT(*) AS n FROM radacct
                            WHERE acctstoptime IS NOT NULL AND acctstoptime >= ? AND username IN ($in)
                              AND acctterminatecause NOT LIKE 'Ws-%' AND acctterminatecause NOT IN ('Admin-Reset','Admin-Reboot','NAS-Reboot')
                            GROUP BY username, acctterminatecause");
        $sc->execute(array_merge([$desde], $us));
        foreach ($sc->fetchAll(PDO::FETCH_ASSOC) as $r) { if (!isset($causa[$r['username']]) || (int)$r['n'] > $causa[$r['username']][1]) $causa[$r['username']] = [(string)$r['causa'], (int)$r['n']]; }
        // Nome do cliente (login PPPoE ou IPoE do contrato).
        $sn = $db->prepare("SELECT ct.login_pppoe, ct.login_ipoe, c.nome FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id
                            WHERE ct.status <> 'cancelado' AND (ct.login_pppoe IN ($in) OR ct.login_ipoe IN ($in))");
        $sn->execute(array_merge($us, $us));
        foreach ($sn->fetchAll(PDO::FETCH_ASSOC) as $r) { if ($r['login_pppoe'] !== '' && $r['login_pppoe'] !== null) $nomes[strtolower($r['login_pppoe'])] = $r['nome']; if ($r['login_ipoe'] !== '' && $r['login_ipoe'] !== null) $nomes[strtolower($r['login_ipoe'])] = $r['nome']; }
    }
    $nomeCausa = ['Lost-Carrier' => 'perda de sinal', 'Lost-Service' => 'perda de serviço', 'Port-Error' => 'erro de porta', 'NAS-Error' => 'erro no concentrador',
                  'User-Request' => 'cliente/roteador reiniciou', 'NAS-Request' => 'pedido do concentrador', 'Idle-Timeout' => 'tempo ocioso', 'Session-Timeout' => 'limite de sessão',
                  'Admin-Reset' => 'reiniciado pelo operador', 'Service-Unavailable' => 'serviço indisponível'];
    $itens = [];
    foreach ($linhas as $r) {
        $u = (string)$r['username']; $c = $causa[$u] ?? ['', 0];
        $itens[] = ['login' => $u, 'nome' => $nomes[strtolower($u)] ?? '', 'quedas' => (int)$r['quedas'], 'perdas' => (int)$r['perdas'], 'ultima' => (string)$r['ultima'],
                    'dur_media_s' => (int)$r['dur_media'], 'causa' => ($nomeCausa[$c[0]] ?? $c[0]), 'causa_cod' => $c[0]];
    }
    osc_json(['ok' => true, 'dias' => $dias, 'min' => $min, 'desde' => $desde, 'primeira_sessao' => $primeira, 'itens' => $itens,
              'sem_historico' => ($primeira === '' || strtotime($primeira) > time() - $dias * 86400 + 3600)]);
} catch (Throwable $e) {
    osc_json(['ok' => false, 'erro' => 'Não consegui consultar o histórico de sessões.'], 500);
}
