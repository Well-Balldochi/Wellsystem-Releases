<?php
/**
 * OLT — UM MÓDULO SÓ, UM CACHE SÓ.
 *
 * O PROBLEMA QUE ISTO RESOLVE
 * O módulo da OLT existia em duas cópias: na raiz do WellSystem e em olt/. A Gerência OLT abria a
 * de olt/ (dados em olt/cache_trafego); o Aprovisionamento e o cron de 1 minuto usavam a da raiz
 * (dados em cache_trafego). Nada do que o cron coletava chegava à Gerência, e a conexão da OLT
 * salva pela Gerência não existia para o Aprovisionamento — que respondia "OLT não configurada" e
 * não coletava ONU nenhuma. A Gerência, sem cache alimentado, varria a OLT sozinha e disputava as
 * sessões Telnet com o cron: ONU nova e ONU aprovisionada levavam 10 minutos ou mais para aparecer.
 *
 * AGORA
 * Tudo roda na raiz (olt/ só redireciona). Esta função traz, UMA vez, o que estava em
 * olt/cache_trafego para cache_trafego: arquivo que não existe na raiz é copiado; arquivo que existe
 * nos dois fica com a versão MAIS NOVA (a data de alteração é real: o cache_sync não regrava arquivo
 * igual). Todo arquivo da raiz que seria substituído é guardado antes em
 * cache_trafego/.antes_unificar_<data>/ — nada se perde. Terminou sem falha? Marca e não roda mais.
 */
if (!function_exists('olt_unificar_cache')) {
    function olt_unificar_cache(string $raiz): void {
        static $feito = false;
        if ($feito) return;
        $feito = true;

        $legado  = $raiz . '/olt/cache_trafego';
        $destino = $raiz . '/cache_trafego';
        if (!is_dir($legado) || is_file($destino . '/.unificado_olt')) return;
        if (!is_dir($destino)) @mkdir($destino, 0775, true);
        $t = $destino . '/.__w' . getmypid() . mt_rand();
        if (@file_put_contents($t, 'ok') === false) return;   // sem gravação real: tenta na próxima
        @unlink($t);

        $bk = $destino . '/.antes_unificar_' . date('Ymd_His');
        $copiados = 0; $falhas = 0;
        try {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($legado, FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $nome = $f->getFilename();
                if ($nome === '' || $nome[0] === '.' || substr($nome, -5) === '.lock') continue;   // travas e testes
                $rel  = str_replace('\\', '/', substr($f->getPathname(), strlen($legado) + 1));
                $alvo = $destino . '/' . $rel;
                if (is_file($alvo) && (int)@filemtime($alvo) >= (int)$f->getMTime()) continue;     // a raiz já é a mais nova
                if (is_file($alvo)) {
                    @mkdir(dirname($bk . '/' . $rel), 0775, true);
                    @copy($alvo, $bk . '/' . $rel);
                }
                @mkdir(dirname($alvo), 0775, true);
                if (@copy($f->getPathname(), $alvo)) {
                    @touch($alvo, (int)$f->getMTime());
                    @chmod($alvo, 0666);
                    $copiados++;
                } else {
                    $falhas++;
                }
            }
        } catch (Throwable $e) {
            $falhas++;
        }
        if ($falhas === 0) {
            @file_put_contents($destino . '/.unificado_olt', date('c') . " copiados=$copiados\n");
        }
    }
}
