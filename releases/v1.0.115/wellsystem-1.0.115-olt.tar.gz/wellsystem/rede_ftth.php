<?php
/**
 * WellSystem — REDE FTTH (21/10/2026): mapa da rede (postes/cabos do KMZ), sugestão de CTOs nos postes reais, viabilidade e
 * auditoria endereço × coordenada. Leitura para nível 1+; importar/gravar/corrigir só nível 3+ (ws_pode_configurar). Nada grava sem clique.
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
require __DIR__ . '/rede_ftth_lib.php';
$db = ws_db(); rede_schema($db);
$pode = function_exists('ws_pode_configurar') && ws_pode_configurar();
$usuario = (string)($_SESSION['ws_user']['login'] ?? '');
function rf_json($d): void { header('Content-Type: application/json; charset=utf-8'); echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR); exit; }
@ini_set('memory_limit', '512M'); @set_time_limit(120);

/* ---------- download KMZ ---------- */
if (isset($_GET['baixar'])) {
    $kml = rede_gerar_kml($db, !empty($_GET['clientes']) && $pode);
    if (!class_exists('ZipArchive')) { header('Content-Type: application/vnd.google-earth.kml+xml'); header('Content-Disposition: attachment; filename="rede-ftth.kml"'); echo $kml; exit; }
    $tmp = tempnam(sys_get_temp_dir(), 'kmz'); $z = new ZipArchive(); $z->open($tmp, ZipArchive::OVERWRITE); $z->addFromString('doc.kml', $kml); $z->close();
    header('Content-Type: application/vnd.google-earth.kmz'); header('Content-Disposition: attachment; filename="rede-ftth-' . date('Ymd') . '.kmz"'); header('Content-Length: ' . filesize($tmp)); readfile($tmp); @unlink($tmp); exit;
}

/* ---------- leitura (ajax) ---------- */
$aj = $_GET['ajax'] ?? '';
if ($aj === 'dados') {
    $ctos = [];
    try { foreach ($db->query("SELECT ct.id, ct.nome, ct.latitude, ct.longitude, ct.portas, (SELECT COUNT(*) FROM ws_cto_porta p WHERE p.cto_id=ct.id AND p.cliente_id IS NOT NULL) oc FROM ws_cto ct WHERE ct.latitude IS NOT NULL AND ct.latitude<>0")->fetchAll(PDO::FETCH_ASSOC) as $c) $ctos[] = [(int)$c['id'], $c['nome'], (float)$c['latitude'], (float)$c['longitude'], (int)$c['portas'], (int)$c['oc']]; } catch (Throwable $e) {}
    $cli = []; foreach (rede_clientes($db) as $c) if ($c['lat'] && $c['lng']) $cli[] = [$c['id'], $c['nome'], round($c['lat'], 6), round($c['lng'], 6), $c['pon']];
    $po = []; foreach (rede_postes($db) as $p) $po[] = [(int)$p['id'], round((float)$p['lat'], 6), round((float)$p['lng'], 6), $p['plaqueta'] !== '' ? $p['plaqueta'] : $p['nome'], (int)$p['terceiros']];
    $tr = []; foreach (rede_trechos($db) as $t) $tr[] = [$t['tipo'], $t['pontos'], (int)$t['metros']];
    rf_json(['postes' => $po, 'trechos' => $tr, 'ctos' => $ctos, 'clientes' => $cli, 'pode' => $pode]);
}
if ($aj === 'sugerir') {
    $portas = in_array((int)($_GET['portas'] ?? 8), [4, 8, 16], true) ? (int)$_GET['portas'] : 8; $raio = max(30, min(400, (int)($_GET['raio'] ?? 150)));
    $postes = rede_postes($db); if (!$postes) rf_json(['erro' => 'Importe o mapa da rede (KMZ) primeiro.']);
    $r = rede_sugerir_ctos($db, rede_clientes($db), $postes, $portas, (float)$raio, !empty($_GET['pon']));
    $r['resumo'] = ['ctos' => count($r['propostas']), 'clientes_atendidos' => array_sum(array_column($r['propostas'], 'ocupacao')), 'sem_poste' => count($r['sem_poste']), 'portas' => $portas, 'raio' => $raio];
    $r['sem_poste'] = array_slice($r['sem_poste'], 0, 300); rf_json($r);
}
if ($aj === 'auditoria') {
    $a = rede_auditar(rede_clientes($db), rede_postes($db)); $a['itens'] = array_slice($a['itens'], 0, 1500); rf_json($a);
}
if ($aj === 'viab') {
    $la = (float)($_GET['lat'] ?? 0); $lo = (float)($_GET['lng'] ?? 0); if (!$la || !$lo) rf_json(['erro' => 'Ponto inválido.']);
    [$p, $dp] = rede_poste_proximo(rede_postes($db), $la, $lo); [$t, $dt, $pt] = rede_trecho_proximo(rede_trechos($db), $la, $lo);
    $ct = []; try { foreach ($db->query("SELECT ct.id, ct.nome, ct.latitude, ct.longitude, ct.portas, (SELECT COUNT(*) FROM ws_cto_porta p WHERE p.cto_id=ct.id AND p.cliente_id IS NOT NULL) oc FROM ws_cto ct WHERE ct.latitude IS NOT NULL AND ct.latitude<>0")->fetchAll(PDO::FETCH_ASSOC) as $c) { $ct[] = ['nome' => $c['nome'], 'livres' => (int)$c['portas'] - (int)$c['oc'], 'm' => (int)round(rede_dist($la, $lo, (float)$c['latitude'], (float)$c['longitude'])), 'lat' => (float)$c['latitude'], 'lng' => (float)$c['longitude']]; } } catch (Throwable $e) {}
    usort($ct, fn($a, $b) => $a['m'] <=> $b['m']);
    rf_json(['poste' => $p ? ['nome' => $p['plaqueta'] ?: $p['nome'], 'm' => (int)round($dp), 'lat' => (float)$p['lat'], 'lng' => (float)$p['lng']] : null, 'cabo_m' => $t ? (int)round($dt) : null, 'cabo_ponto' => $pt, 'ctos' => array_slice($ct, 0, 3)]);
}

/* ---------- escrita (POST, nível 3+) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if (!$pode) rf_json(['ok' => false, 'erro' => 'Seu nível de acesso não permite esta ação.']);
    if ($acao === 'importar') {
        if (empty($_FILES['kmz']['tmp_name']) || $_FILES['kmz']['error'] !== UPLOAD_ERR_OK) rf_json(['ok' => false, 'erro' => 'Envie o arquivo KMZ ou KML.']);
        [$xml, $erro] = rede_ler_kml($_FILES['kmz']['tmp_name'], (string)$_FILES['kmz']['name']); if ($xml === null) rf_json(['ok' => false, 'erro' => $erro]);
        $d = rede_interpretar_kml($xml, (string)$_FILES['kmz']['name']);
        if (!$d['postes'] && !$d['trechos']) rf_json(['ok' => false, 'erro' => 'Não encontrei postes nem cabos no arquivo.']);
        if (empty($_POST['confirmar'])) rf_json(['ok' => true, 'previa' => true, 'postes' => count($d['postes']), 'trechos' => count($d['trechos']), 'metros' => array_sum(array_column($d['trechos'], 'metros')), 'terceiros' => count(array_filter($d['postes'], fn($p) => $p['terceiros']))]);
        $r = rede_gravar_rede($db, $d, (string)$_FILES['kmz']['name'], !empty($_POST['substituir']));
        ws_evento($db, null, 'cadastro', 'Rede FTTH importada de "' . mb_substr((string)$_FILES['kmz']['name'], 0, 60) . '": ' . $r['postes'] . ' postes, ' . $r['trechos'] . ' trechos.');
        rf_json(['ok' => true] + $r);
    }
    if ($acao === 'gravar_ctos') {
        $lista = json_decode((string)($_POST['ctos'] ?? '[]'), true); if (!is_array($lista) || !$lista) rf_json(['ok' => false, 'erro' => 'Nenhuma CTO marcada.']);
        $vivos = []; foreach (rede_clientes($db) as $c) $vivos[$c['id']] = 1;
        $db->beginTransaction();
        try {
            $ic = $db->prepare("INSERT INTO ws_cto (nome, latitude, longitude, portas) VALUES (?,?,?,?)"); $ip = $db->prepare("INSERT INTO ws_cto_porta (cto_id, numero_porta, cliente_id) VALUES (?,?,?)");
            $ja = $db->prepare("SELECT 1 FROM ws_cto_porta WHERE cliente_id=? LIMIT 1"); $nc = 0; $np = 0;
            foreach ($lista as $c) {
                $la = (float)($c['lat'] ?? 0); $lo = (float)($c['lng'] ?? 0); $po = max(1, min(64, (int)($c['portas'] ?? 8))); $nome = trim((string)($c['nome'] ?? ''));
                if ($nome === '' || !$la || !$lo) continue;
                $nome = mb_substr('PLANEJADA ' . $nome, 0, 80);   // sugestão ≠ caixa instalada: o prefixo marca e permite apagar todas de uma vez
                $ic->execute([$nome, $la, $lo, $po]); $id = (int)$db->lastInsertId(); $nc++;
                for ($n = 1; $n <= $po; $n++) {
                    $cid = null; foreach ((array)($c['clientes'] ?? []) as $x) if ((int)$x['porta'] === $n && isset($vivos[(int)$x['id']])) { $ja->execute([(int)$x['id']]); if (!$ja->fetchColumn()) $cid = (int)$x['id']; }
                    $ip->execute([$id, $n, $cid]); if ($cid) $np++;
                }
            }
            $db->commit();
        } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); rf_json(['ok' => false, 'erro' => 'Falhou e nada foi gravado: ' . $e->getMessage()]); }
        ws_evento($db, null, 'cadastro', "Rede FTTH: $nc CTO(s) criadas a partir de sugestão aprovada ($np clientes ligados às portas).");
        rf_json(['ok' => true, 'ctos' => $nc, 'clientes' => $np]);
    }
    if ($acao === 'apagar_planejadas') {
        $n = (int)$db->query("SELECT COUNT(*) FROM ws_cto WHERE nome LIKE 'PLANEJADA %'")->fetchColumn();
        $lig = (int)$db->query("SELECT COUNT(*) FROM ws_cto_porta p JOIN ws_cto c ON c.id=p.cto_id WHERE c.nome LIKE 'PLANEJADA %' AND p.cliente_id IS NOT NULL")->fetchColumn();
        if (empty($_POST['confirmar'])) rf_json(['ok' => true, 'previa' => true, 'ctos' => $n, 'clientes' => $lig]);
        $db->beginTransaction();
        try { $db->exec("DELETE FROM ws_cto_porta WHERE cto_id IN (SELECT id FROM ws_cto WHERE nome LIKE 'PLANEJADA %')"); $db->exec("DELETE FROM ws_cto WHERE nome LIKE 'PLANEJADA %'"); $db->commit(); }
        catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); rf_json(['ok' => false, 'erro' => 'Falhou e nada foi apagado: ' . $e->getMessage()]); }
        ws_evento($db, null, 'cadastro', "Rede FTTH: $n CTO(s) planejada(s) apagadas ($lig clientes liberados das portas).");
        rf_json(['ok' => true, 'ctos' => $n, 'clientes' => $lig]);
    }
    if ($acao === 'aplicar_coords') {
        $lista = json_decode((string)($_POST['itens'] ?? '[]'), true); if (!is_array($lista) || !$lista) rf_json(['ok' => false, 'erro' => 'Nada marcado.']);
        $lote = date('ymdHis'); $n = 0;
        $db->beginTransaction();
        try {
            $sel = $db->prepare("SELECT lat, lng FROM ws_cliente WHERE id=? AND status NOT IN ('cancelado','desativado')"); $up = $db->prepare("UPDATE ws_cliente SET lat=?, lng=? WHERE id=?");
            $cts = $db->prepare("SELECT id, lat, lng FROM ws_contrato WHERE cliente_id=? AND status<>'cancelado' AND lat IS NOT NULL AND lat<>0"); $upc = $db->prepare("UPDATE ws_contrato SET lat=?, lng=? WHERE id=?");
            $lg = $db->prepare("INSERT INTO ws_rede_log (usuario, acao, lote, cliente_id, lat_antes, lng_antes, lat_depois, lng_depois, motivo) VALUES (?,?,?,?,?,?,?,?,?)");
            foreach ($lista as $i) {
                $id = (int)($i['id'] ?? 0); $la = (float)($i['lat'] ?? 0); $lo = (float)($i['lng'] ?? 0); if (!$id || abs($la) > 90 || abs($lo) > 180 || !$la || !$lo) continue;
                $sel->execute([$id]); $a = $sel->fetch(PDO::FETCH_ASSOC); if (!$a) continue;
                $mot = mb_substr((string)($i['motivo'] ?? ''), 0, 160);
                $up->execute([$la, $lo, $id]); $lg->execute([$usuario, 'coord', $lote, $id, $a['lat'] ?: null, $a['lng'] ?: null, $la, $lo, $mot]); $n++;
                // o contrato (quando tem coordenada) vale primeiro nas telas: acompanha o cadastro; no log vai com acao=coord_ct e cliente_id = id do CONTRATO
                $cts->execute([$id]); foreach ($cts->fetchAll(PDO::FETCH_ASSOC) as $ct) { $upc->execute([$la, $lo, (int)$ct['id']]); $lg->execute([$usuario, 'coord_ct', $lote, (int)$ct['id'], $ct['lat'], $ct['lng'], $la, $lo, $mot]); }
            }
            $db->commit();
        } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); rf_json(['ok' => false, 'erro' => 'Falhou e nada foi gravado: ' . $e->getMessage()]); }
        ws_evento($db, null, 'cadastro', "Rede FTTH: $n coordenada(s) de clientes corrigidas (lote $lote, dá para desfazer).");
        rf_json(['ok' => true, 'alterados' => $n, 'lote' => $lote]);
    }
    if ($acao === 'desfazer') {
        $lote = preg_replace('/\D/', '', (string)($_POST['lote'] ?? '')); if ($lote === '') rf_json(['ok' => false, 'erro' => 'Lote inválido.']); $n = 0;
        $db->beginTransaction();
        try {
            $rs = $db->prepare("SELECT id, acao, cliente_id, lat_antes, lng_antes FROM ws_rede_log WHERE lote=? AND desfeito=0"); $rs->execute([$lote]);
            $up = $db->prepare("UPDATE ws_cliente SET lat=?, lng=? WHERE id=?"); $upc = $db->prepare("UPDATE ws_contrato SET lat=?, lng=? WHERE id=?"); $mk = $db->prepare("UPDATE ws_rede_log SET desfeito=1 WHERE id=?");
            foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) { ($r['acao'] === 'coord_ct' ? $upc : $up)->execute([$r['lat_antes'], $r['lng_antes'], (int)$r['cliente_id']]); $mk->execute([(int)$r['id']]); $n++; }
            $db->commit();
        } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); rf_json(['ok' => false, 'erro' => $e->getMessage()]); }
        ws_evento($db, null, 'cadastro', "Rede FTTH: lote $lote desfeito ($n coordenadas voltaram ao valor anterior).");
        rf_json(['ok' => true, 'revertidos' => $n]);
    }
    rf_json(['ok' => false, 'erro' => 'Ação desconhecida.']);
}
$lotes = []; try { $lotes = $db->query("SELECT lote, MIN(criado_em) em, COUNT(*) n, MIN(usuario) u FROM ws_rede_log WHERE desfeito=0 GROUP BY lote ORDER BY lote DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) {}
$nPostes = (int)$db->query("SELECT COUNT(*) FROM ws_rede_poste")->fetchColumn(); $nTrechos = (int)$db->query("SELECT COUNT(*) FROM ws_rede_trecho")->fetchColumn();
?><!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Rede FTTH</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
#rfMapa{height:calc(100vh - 250px);min-height:460px;border:1px solid var(--border);border-radius:12px}
.rf-abas{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}
.rf-painel{display:none}.rf-painel.on{display:block}
.rf-tab{width:100%;border-collapse:collapse;font-size:13px}.rf-tab th,.rf-tab td{padding:5px 8px;border-bottom:1px solid var(--border);text-align:left}
.rf-cards{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 10px}.rf-card{border:1px solid var(--border);border-radius:10px;padding:8px 14px;background:var(--surface)}.rf-card b{font-size:20px;display:block}
.rf-barra{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 10px}.rf-barra label{font-size:13px}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('olt') ?></header><main class="ws-main">
<div class="ws-search">
  <a class="ws-btn" href="olt_erp.php?p=painel">Aprovisionamento ONU / ONT</a><a class="ws-btn" href="olt_erp.php?p=cto">Mapa de CTO</a><a class="ws-btn" href="olt_erp.php?p=cto_clientes">Relatório CTO</a><a class="ws-btn primary" href="rede_ftth.php">Rede FTTH</a>
</div>
<div class="rf-cards"><div class="rf-card"><b id="cPostes"><?= $nPostes ?></b>postes</div><div class="rf-card"><b id="cTrechos"><?= $nTrechos ?></b>trechos de cabo/trajeto</div><div class="rf-card"><b id="cCtos">–</b>CTOs cadastradas</div><div class="rf-card"><b id="cCli">–</b>clientes no mapa</div></div>
<div class="rf-abas">
  <button class="ws-btn primary" data-aba="mapa">Mapa da rede</button><button class="ws-btn" data-aba="sugerir">Sugerir CTOs</button><button class="ws-btn" data-aba="audit">Endereço × coordenada</button><button class="ws-btn" data-aba="imp">Importar / Exportar</button>
</div>

<section class="rf-painel on" id="p-mapa">
  <div class="rf-barra"><label><input type="checkbox" id="kPostes" checked> Postes</label><label><input type="checkbox" id="kCabos" checked> Cabos/trajeto</label><label><input type="checkbox" id="kCtos" checked> CTOs</label><label><input type="checkbox" id="kCli"> Clientes</label>
    <span class="ws-muted" style="font-size:12px">Clique no mapa para consultar viabilidade (poste, cabo e CTO mais próximos).</span></div>
  <div id="rfMapa"></div><div id="rfViab" class="ws-muted" style="margin-top:8px;font-size:13px"></div>
</section>

<section class="rf-painel" id="p-sugerir">
  <div class="rf-barra"><label>Portas por caixa <select id="sPortas"><option>8</option><option>16</option><option>4</option></select></label><label>Alcance máx. (m) <input id="sRaio" type="number" value="150" min="30" max="400" style="width:70px"></label><label><input type="checkbox" id="sPon"> Separar por PON</label><button class="ws-btn primary" id="bSug">Calcular sugestão</button></div>
  <div id="sRes" class="ws-muted">Nada é gravado ao calcular. Marque as caixas e clique em “Gravar marcadas”. As gravadas entram como “PLANEJADA …”.</div>
  <?php if ($pode): ?><p style="margin-top:12px"><button class="ws-btn" id="bApagaPlan">Apagar todas as CTOs planejadas</button></p><?php endif; ?>
</section>

<section class="rf-painel" id="p-audit">
  <div class="rf-barra"><button class="ws-btn primary" id="bAud">Analisar cadastro</button><span class="ws-muted" style="font-size:12px">Compara rua/bairro de cada cliente com a posição dos vizinhos da mesma rua.</span></div>
  <div id="aRes" class="ws-muted"></div>
  <?php if ($lotes): ?><div style="margin-top:12px"><b>Correções aplicadas (desfazer):</b><?php foreach ($lotes as $l): ?><div style="font-size:13px;margin:3px 0"><?= htmlspecialchars($l['em']) ?> — <?= (int)$l['n'] ?> coordenada(s) por <?= htmlspecialchars($l['u']) ?> <?php if ($pode): ?><button class="ws-btn" data-desfazer="<?= htmlspecialchars($l['lote']) ?>">Desfazer</button><?php endif; ?></div><?php endforeach; ?></div><?php endif; ?>
</section>

<section class="rf-painel" id="p-imp">
  <p><a class="ws-btn" href="rede_ftth.php?baixar=1">Baixar rede + CTOs (KMZ)</a> <?php if ($pode): ?><a class="ws-btn" href="rede_ftth.php?baixar=1&clientes=1">Baixar com clientes</a><?php endif; ?></p>
  <?php if ($pode): ?>
  <div class="rf-barra"><input type="file" id="fArq" accept=".kmz,.kml" multiple><label><input type="checkbox" id="fSub"> Substituir a rede atual</label><button class="ws-btn primary" id="bImp">Ler arquivo(s)</button></div><div class="ws-muted" style="font-size:12px;margin:-4px 0 8px">Vários arquivos são unificados: o 1º da seleção é o mais preciso (a posição dele vale); postes a até 6 m são o mesmo poste e cabos repetidos são ignorados.</div><div id="iRes" class="ws-muted"></div>
  <?php else: ?><p class="ws-muted">Importar é só para nível 3 ou superior.</p><?php endif; ?>
</section>
</main><?= ws_footer_bar() ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function(){
var POSTE=<?= $pode ? 'true' : 'false' ?>, D=null, mapa, gP, gC, gT, gK, mV=null, propostas=[], audit=[];
function $(i){return document.getElementById(i);} function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function post(d,cb){var f=d instanceof FormData?d:(function(){var x=new FormData();for(var k in d)x.append(k,d[k]);return x;})();fetch('rede_ftth.php',{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json();}).then(cb).catch(function(e){alert('Falha: '+e);});}
function get(q,cb){fetch('rede_ftth.php?'+q,{credentials:'same-origin'}).then(function(r){return r.json();}).then(cb).catch(function(e){alert('Falha: '+e);});}
document.querySelectorAll('[data-aba]').forEach(function(b){b.onclick=function(){document.querySelectorAll('[data-aba]').forEach(function(x){x.classList.remove('primary');});b.classList.add('primary');document.querySelectorAll('.rf-painel').forEach(function(p){p.classList.remove('on');});$('p-'+b.dataset.aba).classList.add('on');if(b.dataset.aba==='mapa'&&mapa)mapa.invalidateSize();};});
function cor(o,p){if(!p)return '#888';var r=o/p;return r>=1?'#d33':(r>=.75?'#e8a200':'#2a9d4a');}
function desenha(){
  [gP,gC,gT,gK].forEach(function(g){if(g)g.clearLayers();});
  D.postes.forEach(function(p){L.circleMarker([p[1],p[2]],{radius:3,color:p[4]?'#999':'#c0392b',weight:1,fillOpacity:.8}).bindTooltip(esc(p[3]||'poste')).addTo(gP);});
  D.trechos.forEach(function(t){L.polyline(t[1],{color:t[0]==='cabo'?'#0aa':'#46a',weight:2,opacity:.7}).bindTooltip(t[2]+' m').addTo(gT);});
  D.ctos.forEach(function(c){L.circleMarker([c[2],c[3]],{radius:8,color:'#222',weight:2,fillColor:/^PLANEJADA /.test(c[1])?'#5b8def':cor(c[5],c[4]),fillOpacity:.95,dashArray:/^PLANEJADA /.test(c[1])?'3':null}).bindPopup('<b>'+esc(c[1])+'</b><br>'+c[5]+'/'+c[4]+' portas').addTo(gC);});
  D.clientes.forEach(function(c){L.circleMarker([c[2],c[3]],{radius:2.5,color:'#2c7',weight:1,fillOpacity:.7}).bindTooltip(esc(c[1])+(c[4]?' · PON '+c[4]:'')).addTo(gK);});
  $('cCtos').textContent=D.ctos.length;$('cCli').textContent=D.clientes.length;$('cPostes').textContent=D.postes.length;$('cTrechos').textContent=D.trechos.length;
}
function alterna(){[['kPostes',gP],['kCabos',gT],['kCtos',gC],['kCli',gK]].forEach(function(a){if($(a[0]).checked)mapa.addLayer(a[1]);else mapa.removeLayer(a[1]);});}
function carrega(cb){get('ajax=dados',function(d){D=d;if(!mapa){mapa=L.map('rfMapa');L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:20,maxNativeZoom:19,attribution:'© OpenStreetMap'}).addTo(mapa);gP=L.layerGroup();gC=L.layerGroup();gT=L.layerGroup();gK=L.layerGroup();
  ['kPostes','kCabos','kCtos','kCli'].forEach(function(i){$(i).onchange=alterna;});
  mapa.on('click',function(e){get('ajax=viab&lat='+e.latlng.lat+'&lng='+e.latlng.lng,function(v){if(mV)mapa.removeLayer(mV);mV=L.marker(e.latlng).addTo(mapa);var h='<b>Viabilidade neste ponto:</b> ';if(v.erro){h+=esc(v.erro);}else{h+=(v.poste?'poste '+esc(v.poste.nome||'')+' a '+v.poste.m+' m':'sem poste')+' · '+(v.cabo_m!=null?'cabo a '+v.cabo_m+' m':'sem cabo')+' · ';h+=v.ctos.length?v.ctos.map(function(c){return esc(c.nome)+' ('+c.m+' m, '+c.livres+' livre(s))';}).join('; '):'nenhuma CTO';}$('rfViab').innerHTML=h;});});}
  desenha();alterna();var pts=D.postes.length?D.postes.map(function(p){return [p[1],p[2]];}):D.clientes.map(function(c){return [c[2],c[3]];});if(pts.length)mapa.fitBounds(pts,{padding:[20,20]});else mapa.setView([-7.74,-35.23],14);if(cb)cb();});}
carrega();
$('bSug').onclick=function(){$('sRes').textContent='Calculando...';get('ajax=sugerir&portas='+$('sPortas').value+'&raio='+$('sRaio').value+'&pon='+($('sPon').checked?1:0),function(r){
  if(r.erro){$('sRes').textContent=r.erro;return;}propostas=r.propostas;var s=r.resumo;
  var h='<p><b>'+s.ctos+' CTOs</b> atendem <b>'+s.clientes_atendidos+'</b> clientes ('+s.portas+' portas, alcance '+s.raio+' m). Sem poste a '+s.raio+' m: <b>'+s.sem_poste+'</b> cliente(s). Já em porta de CTO: '+r.ja_em_porta+'. Fora da sugestão por coordenada genérica (repetida): '+r.coord_generica+' — corrija em “Endereço × coordenada”.</p>';
  if(POSTE)h+='<p><button class="ws-btn" id="sTodas">Marcar todas</button> <button class="ws-btn primary" id="bGrav">Gravar marcadas</button></p>';
  h+='<table class="rf-tab"><tr><th></th><th>Caixa</th><th>PON</th><th>Ocupação</th><th>Aviso</th><th></th></tr>';
  propostas.forEach(function(p,i){h+='<tr><td><input type="checkbox" class="sCk" data-i="'+i+'"'+(p.ja_tem_cto_no_poste?'':' checked')+'></td><td>'+esc(p.nome)+'</td><td>'+esc(p.pon)+'</td><td>'+p.ocupacao+'/'+p.portas+'</td><td>'+(p.ja_tem_cto_no_poste?'já existe CTO neste poste':'')+'</td><td><a href="#" data-ver="'+i+'">ver</a></td></tr>';});
  $('sRes').innerHTML=h+'</table>';
  document.querySelectorAll('[data-ver]').forEach(function(a){a.onclick=function(e){e.preventDefault();document.querySelector('[data-aba=mapa]').click();var p=propostas[a.dataset.ver];mapa.setView([p.lat,p.lng],19);L.popup().setLatLng([p.lat,p.lng]).setContent('<b>'+esc(p.nome)+'</b><br>'+p.clientes.map(function(c){return c.porta+': '+esc(c.nome)+' ('+c.dist_m+' m)';}).join('<br>')).openOn(mapa);};});
  if($('sTodas'))$('sTodas').onclick=function(){document.querySelectorAll('.sCk').forEach(function(c){c.checked=true;});};
  if($('bGrav'))$('bGrav').onclick=function(){var sel=[];document.querySelectorAll('.sCk').forEach(function(c){if(c.checked)sel.push(propostas[c.dataset.i]);});if(!sel.length)return alert('Nada marcado.');if(!confirm('Criar '+sel.length+' CTO(s) e ligar os clientes às portas?'))return;post({acao:'gravar_ctos',ctos:JSON.stringify(sel)},function(r){alert(r.ok?('Gravado: '+r.ctos+' CTO(s), '+r.clientes+' clientes ligados.'):r.erro);if(r.ok){carrega();$('bSug').click();}});};
});};
var ROT={sem_coord:'sem coordenada',longe_rua:'longe da rua',longe_bairro:'longe do bairro',repetida:'coordenada repetida',diverge:'contrato≠cadastro',fora_regiao:'fora da região'};
$('bAud').onclick=function(){$('aRes').textContent='Analisando...';get('ajax=auditoria',function(a){audit=a.itens;var c=a.contagem;
  var h='<div class="rf-cards"><div class="rf-card"><b>'+c.ok+'</b>coordenada coerente</div><div class="rf-card"><b>'+c.sem_coord+'</b>sem coordenada</div><div class="rf-card"><b>'+c.longe_rua+'</b>longe da rua</div><div class="rf-card"><b>'+c.longe_bairro+'</b>longe do bairro</div><div class="rf-card"><b>'+c.repetida+'</b>repetidas</div><div class="rf-card"><b>'+c.diverge+'</b>contrato≠cadastro</div></div>';
  if(POSTE)h+='<p><button class="ws-btn" id="aMed">Marcar sugestões de confiança média</button> <button class="ws-btn primary" id="aAp">Aplicar marcadas</button> <span class="ws-muted" style="font-size:12px">Fica registrado e dá para desfazer.</span></p>';
  h+='<table class="rf-tab"><tr><th></th><th>Cliente</th><th>Endereço</th><th>Problema</th><th>Sugestão</th><th>Poste</th></tr>';
  audit.forEach(function(i,k){h+='<tr><td>'+(i.sug?'<input type="checkbox" class="aCk" data-k="'+k+'">':'')+'</td><td>'+esc(i.nome)+'</td><td>'+esc(i.rua+' '+i.numero+' — '+i.bairro)+'</td><td>'+i.problemas.map(function(p){return ROT[p]||p;}).join(', ')+'</td><td>'+(i.sug?esc(i.conf+': '+i.motivo)+' <a href="https://www.google.com/maps?q='+i.sug[0]+','+i.sug[1]+'" target="_blank">mapa</a>':'—')+'</td><td>'+(i.poste_m!=null?i.poste_m+' m':'')+'</td></tr>';});
  $('aRes').innerHTML=h+'</table>';
  if($('aMed'))$('aMed').onclick=function(){document.querySelectorAll('.aCk').forEach(function(c){c.checked=audit[c.dataset.k].conf==='média';});};
  if($('aAp'))$('aAp').onclick=function(){var sel=[];document.querySelectorAll('.aCk').forEach(function(c){if(c.checked){var i=audit[c.dataset.k];sel.push({id:i.id,lat:i.sug[0],lng:i.sug[1],motivo:i.motivo});}});if(!sel.length)return alert('Nada marcado.');if(!confirm('Alterar a coordenada de '+sel.length+' cliente(s)?'))return;post({acao:'aplicar_coords',itens:JSON.stringify(sel)},function(r){alert(r.ok?('Alterados: '+r.alterados+' (lote '+r.lote+').'):r.erro);if(r.ok)location.reload();});};
});};
document.querySelectorAll('[data-desfazer]').forEach(function(b){b.onclick=function(){if(!confirm('Desfazer este lote?'))return;post({acao:'desfazer',lote:b.dataset.desfazer},function(r){alert(r.ok?('Revertidos: '+r.revertidos):r.erro);if(r.ok)location.reload();});};});
if($('bImp'))$('bImp').onclick=function(){var fs=[].slice.call($('fArq').files);if(!fs.length)return alert('Escolha o arquivo.');var sub=$('fSub').checked,ok=false,out=[];
  (function prox(i){if(i>=fs.length){$('iRes').innerHTML=out.join('<br>');if(ok)carrega();return;}
    var fd=new FormData();fd.append('acao','importar');fd.append('kmz',fs[i]);if(sub&&i===0)fd.append('substituir','1');
    post(fd,function(r){if(!r.ok){out.push(esc(fs[i].name)+': '+esc(r.erro));return prox(i+1);}if(!r.previa)return prox(i+1);
      if(!confirm(fs[i].name+': '+r.postes+' postes ('+r.terceiros+' de terceiros) e '+r.trechos+' trechos ('+r.metros+' m). Importar'+(sub&&i===0?', SUBSTITUINDO a rede atual':', unificando com a rede atual')+'?')){out.push(esc(fs[i].name)+': não importado.');return prox(i+1);}
      fd.append('confirmar','1');post(fd,function(g){if(g.ok){ok=true;out.push(esc(fs[i].name)+': '+g.postes+' postes novos, '+g.mesclados+' já existiam (completados), '+g.trechos+' trechos novos ('+g.metros+' m), '+g.trechos_ja_cobertos+' cabos repetidos ignorados.');}else out.push(esc(fs[i].name)+': '+esc(g.erro));prox(i+1);});});})(0);};
if($('bApagaPlan'))$('bApagaPlan').onclick=function(){post({acao:'apagar_planejadas'},function(r){if(!r.ok)return alert(r.erro);if(!r.ctos)return alert('Não há CTOs planejadas.');if(!confirm('Apagar '+r.ctos+' CTO(s) planejada(s)? Os '+r.clientes+' clientes ligados a elas saem das portas. CTOs que não começam com PLANEJADA não são tocadas.'))return;post({acao:'apagar_planejadas',confirmar:'1'},function(g){alert(g.ok?('Apagadas: '+g.ctos+' CTO(s).'):g.erro);if(g.ok){carrega();}});});};
})();
</script></body></html>
