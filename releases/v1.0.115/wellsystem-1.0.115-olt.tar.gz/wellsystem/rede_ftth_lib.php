<?php
/**
 * WellSystem — REDE FTTH (21/10/2026). Biblioteca: importação do mapa da rede (KMZ/KML do Google Earth/AutoCAD), geometria, auditoria dos
 * endereços × coordenadas dos clientes, sugestão de CTOs NOS POSTES REAIS e exportação em KMZ.
 *
 * REGRAS: nada é gravado sem pedido explícito da tela (importar, gravar CTOs, aplicar correções). Cancelado/desativado fica fora de tudo.
 * Tabelas novas (criadas na primeira abertura da tela): ws_rede_poste, ws_rede_trecho, ws_rede_log. As CTOs usam as tabelas que já existem
 * (ws_cto / ws_cto_porta), as mesmas do Mapa de CTO e do mapa dos clientes.
 */

function rede_schema(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS ws_rede_poste (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(60) NOT NULL DEFAULT '',
        plaqueta VARCHAR(24) NOT NULL DEFAULT '',
        descricao VARCHAR(190) NOT NULL DEFAULT '',
        altura TINYINT UNSIGNED NULL,
        esforco SMALLINT UNSIGNED NULL,
        lado CHAR(1) NOT NULL DEFAULT '',
        terceiros TINYINT NOT NULL DEFAULT 0,
        lat DECIMAL(10,7) NOT NULL,
        lng DECIMAL(10,7) NOT NULL,
        origem VARCHAR(90) NOT NULL DEFAULT '',
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY ix_latlng (lat, lng)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS ws_rede_trecho (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(90) NOT NULL DEFAULT '',
        tipo VARCHAR(20) NOT NULL DEFAULT 'trajeto',
        pontos MEDIUMTEXT NOT NULL,
        metros INT NOT NULL DEFAULT 0,
        origem VARCHAR(90) NOT NULL DEFAULT '',
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS ws_rede_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        usuario VARCHAR(80) NOT NULL DEFAULT '',
        acao VARCHAR(40) NOT NULL DEFAULT '',
        lote VARCHAR(24) NOT NULL DEFAULT '',
        cliente_id INT NULL,
        lat_antes DECIMAL(10,7) NULL, lng_antes DECIMAL(10,7) NULL,
        lat_depois DECIMAL(10,7) NULL, lng_depois DECIMAL(10,7) NULL,
        motivo VARCHAR(160) NOT NULL DEFAULT '',
        desfeito TINYINT NOT NULL DEFAULT 0,
        KEY ix_lote (lote), KEY ix_cli (cliente_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/* ---------------------------------------------------------------- geometria ---------------------------------------------------------------- */
function rede_dist(float $la1, float $lo1, float $la2, float $lo2): float {
    $x = deg2rad($lo2 - $lo1) * cos(deg2rad(($la1 + $la2) / 2)); $y = deg2rad($la2 - $la1); return 6371000 * sqrt($x * $x + $y * $y);
}
/** Distância (m) de um ponto a um segmento a-b ([lat,lng]) e o ponto mais próximo [lat,lng]. */
function rede_dist_seg(float $la, float $lo, array $a, array $b): array {
    $k = cos(deg2rad($la)); $px = $lo * $k; $py = $la; $ax = $a[1] * $k; $ay = $a[0]; $bx = $b[1] * $k; $by = $b[0];
    $dx = $bx - $ax; $dy = $by - $ay; $den = $dx * $dx + $dy * $dy; $t = $den > 0 ? max(0, min(1, (($px - $ax) * $dx + ($py - $ay) * $dy) / $den)) : 0;
    $cx = $ax + $t * $dx; $cy = $ay + $t * $dy; return [111320 * sqrt(($px - $cx) ** 2 + ($py - $cy) ** 2), [$cy, $cx / $k]];
}
function rede_mediana(array $v): float { sort($v); $n = count($v); if (!$n) return 0.0; return $n % 2 ? (float)$v[intdiv($n, 2)] : ((float)$v[$n / 2 - 1] + (float)$v[$n / 2]) / 2; }
function rede_chave(string $s): string {
    $s = mb_strtoupper(trim($s), 'UTF-8'); $de = ['Á','À','Â','Ã','Ä','É','È','Ê','Ë','Í','Ì','Î','Ï','Ó','Ò','Ô','Õ','Ö','Ú','Ù','Û','Ü','Ç'];
    $pa = ['A','A','A','A','A','E','E','E','E','I','I','I','I','O','O','O','O','O','U','U','U','U','C']; $s = str_replace($de, $pa, $s);
    $s = preg_replace('/^BAIRRO\s+/', '', $s); $s = preg_replace('/[^A-Z0-9 ]+/', ' ', $s); return trim(preg_replace('/\s+/', ' ', $s));
}
/** Nome de rua sem o tipo (RUA/AV/TRAV...) para casar "R. DO COMERCIO" com "RUA DO COMERCIO". */
function rede_chave_rua(string $s): string { $k = rede_chave($s); $k = preg_replace('/^(RUA|R|AVENIDA|AV|TRAVESSA|TRAV|TV|ALAMEDA|AL|PRACA|PCA|ESTRADA|EST|RODOVIA|ROD|BECO|SITIO|SIT|VILA|LOTEAMENTO|LOT|CONJUNTO|CJ)\s+/', '', $k); return trim($k); }

/* ---------------------------------------------------------------- importação do KML/KMZ ---------------------------------------------------------------- */
/** Lê o arquivo (KMZ = zip com doc.kml; ou KML puro) e devolve o texto XML. [texto|null, erro] */
function rede_ler_kml(string $arquivo, string $nomeOriginal): array {
    if (!is_file($arquivo) || filesize($arquivo) > 25 * 1048576) return [null, 'Arquivo vazio ou maior que 25 MB.'];
    $ini = (string)@file_get_contents($arquivo, false, null, 0, 4);
    if (strncmp($ini, "PK\x03\x04", 4) === 0) {
        if (!class_exists('ZipArchive')) return [null, 'O servidor não tem a extensão ZipArchive para abrir KMZ. Envie o KML (descompactado).'];
        $z = new ZipArchive(); if ($z->open($arquivo) !== true) return [null, 'Não consegui abrir o KMZ.'];
        $alvo = null; for ($i = 0; $i < $z->numFiles; $i++) { $n = $z->getNameIndex($i); if (preg_match('/(^|\/)doc\.kml$/i', $n)) { $alvo = $n; break; } if ($alvo === null && preg_match('/\.kml$/i', $n)) $alvo = $n; }
        if ($alvo === null) { $z->close(); return [null, 'O KMZ não tem um arquivo .kml dentro.']; }
        $st = $z->statName($alvo); if ($st && $st['size'] > 60 * 1048576) { $z->close(); return [null, 'KML interno grande demais.']; }
        $txt = $z->getFromName($alvo); $z->close(); return [($txt === false ? null : $txt), $txt === false ? 'Não consegui ler o KML dentro do KMZ.' : ''];
    }
    $txt = file_get_contents($arquivo); return [$txt === false ? null : $txt, ''];
}
function rede_limpa_texto(string $s): string { return trim(preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', html_entity_decode($s, ENT_QUOTES | ENT_XML1, 'UTF-8'))); }

/** Interpreta o KML: postes (pontos) e trechos de cabo (linhas). Devolve ['postes'=>[], 'trechos'=>[], 'avisos'=>[]]. */
function rede_interpretar_kml(string $xml, string $origem): array {
    $res = ['postes' => [], 'trechos' => [], 'avisos' => []];
    $prev = libxml_use_internal_errors(true);
    $dom = new DOMDocument(); $ok = $dom->loadXML($xml, LIBXML_NONET | LIBXML_NOCDATA | LIBXML_COMPACT | LIBXML_PARSEHUGE); libxml_clear_errors(); libxml_use_internal_errors($prev);
    if (!$ok) { $res['avisos'][] = 'KML inválido.'; return $res; }
    $xp = new DOMXPath($dom); $xp->registerNamespace('k', $dom->documentElement->namespaceURI ?: 'http://www.opengis.net/kml/2.2');
    foreach ($xp->query('//k:Placemark') as $pm) {
        $nome = rede_limpa_texto((string)$xp->evaluate('string(k:name)', $pm)); $desc = rede_limpa_texto(strip_tags((string)$xp->evaluate('string(k:description)', $pm)));
        $pasta = []; for ($n = $pm->parentNode; $n && $n->nodeType === XML_ELEMENT_NODE; $n = $n->parentNode) { if ($n->localName === 'Folder' || $n->localName === 'Document') { $nm = rede_limpa_texto((string)$xp->evaluate('string(k:name)', $n)); if ($nm !== '') array_unshift($pasta, $nm); } }
        $caminho = implode('/', $pasta); $terceiros = (bool)preg_match('/TERCEIRO/i', $caminho . ' ' . $nome . ' ' . $desc);
        $pt = $xp->query('.//k:Point/k:coordinates', $pm); $ln = $xp->query('.//k:LineString/k:coordinates', $pm);
        if ($pt->length) {
            $c = explode(',', trim($pt->item(0)->textContent)); if (count($c) < 2) continue; $lo = (float)$c[0]; $la = (float)$c[1];
            if (abs($la) > 90 || abs($lo) > 180 || (!$la && !$lo)) continue;
            $plaq = ''; if (preg_match('/\b[sS](\d{4,8})\b/', $desc, $m)) $plaq = 'S' . $m[1];
            $alt = null; $esf = null; if (preg_match('/\b(\d{1,2})\s*\/\s*(\d{2,4})\b/', $desc, $m)) { $alt = (int)$m[1]; $esf = (int)$m[2]; }
            $lado = ''; if (preg_match('/\b([deDE])\s*$/', $desc, $m)) $lado = strtoupper($m[1]);
            if ($nome === 'Marcador de local sem título') $nome = '';
            $res['postes'][] = ['nome' => mb_substr($nome, 0, 60), 'plaqueta' => $plaq, 'descricao' => mb_substr($desc, 0, 190), 'altura' => $alt, 'esforco' => $esf, 'lado' => $lado, 'terceiros' => $terceiros ? 1 : 0, 'lat' => round($la, 7), 'lng' => round($lo, 7), 'pasta' => $caminho];
        } elseif ($ln->length) {
            $pts = []; foreach (preg_split('/\s+/', trim($ln->item(0)->textContent)) as $cc) { $q = explode(',', $cc); if (count($q) >= 2 && is_numeric($q[0]) && is_numeric($q[1])) $pts[] = [round((float)$q[1], 7), round((float)$q[0], 7)]; }
            if (count($pts) < 2) continue; $m = 0.0; for ($i = 1; $i < count($pts); $i++) $m += rede_dist($pts[$i - 1][0], $pts[$i - 1][1], $pts[$i][0], $pts[$i][1]);
            $tipo = preg_match('/cabo/i', $caminho) ? 'cabo' : 'trajeto'; $nome = ($nome === '' || preg_match('/sem t[ií]tulo|Entidade com/i', $nome)) ? '' : $nome;
            $res['trechos'][] = ['nome' => mb_substr($nome, 0, 90), 'tipo' => $tipo, 'pontos' => $pts, 'metros' => (int)round($m), 'pasta' => $caminho];
        }
    }
    return $res;
}

/**
 * Grava a rede importada. UNIFICA com o que já existe: poste a menos de $raio m de um já gravado é o MESMO poste (a posição do primeiro gravado
 * — o arquivo mais preciso — permanece; só os campos vazios são completados: plaqueta, altura/esforço, lado, descrição). Dentro do mesmo arquivo
 * vale 1,5 m. Trecho de cabo cujo percurso já está coberto (≥85% dos pontos a até 8 m) por cabo já gravado é ignorado.
 * $substituir=true apaga a rede anterior antes. Importe primeiro o arquivo MAIS PRECISO.
 */
function rede_gravar_rede(PDO $db, array $dados, string $origem, bool $substituir, float $raio = 6.0): array {
    $db->beginTransaction();
    try {
        if ($substituir) { $db->exec("DELETE FROM ws_rede_poste"); $db->exec("DELETE FROM ws_rede_trecho"); }
        $grade = []; $chave = fn($la, $lo) => floor($la * 10000) . ':' . floor($lo * 10000);   // célula ≈ 11 m
        foreach ($db->query("SELECT id, lat, lng FROM ws_rede_poste")->fetchAll(PDO::FETCH_NUM) as $r) $grade[$chave((float)$r[1], (float)$r[2])][] = [(float)$r[1], (float)$r[2], (int)$r[0], false];
        $achar = function ($la, $lo) use (&$grade, $raio) {
            $cx = floor($la * 10000); $cy = floor($lo * 10000); $mel = null; $md = 1e9;
            for ($i = -1; $i <= 1; $i++) for ($j = -1; $j <= 1; $j++) foreach ($grade[($cx + $i) . ':' . ($cy + $j)] ?? [] as $e) { $d = rede_dist($la, $lo, $e[0], $e[1]); if ($d < ($e[3] ? 1.5 : $raio) && $d < $md) { $md = $d; $mel = $e; } }
            return $mel;
        };
        $ip = $db->prepare("INSERT INTO ws_rede_poste (nome, plaqueta, descricao, altura, esforco, lado, terceiros, lat, lng, origem) VALUES (?,?,?,?,?,?,?,?,?,?)");
        $um = $db->prepare("UPDATE ws_rede_poste SET nome=IF(nome='',?,nome), plaqueta=IF(plaqueta='',?,plaqueta), descricao=IF(descricao='',?,descricao), altura=COALESCE(altura,?), esforco=COALESCE(esforco,?), lado=IF(lado='',?,lado), terceiros=GREATEST(terceiros,?) WHERE id=?");
        $nP = 0; $nMes = 0; $nDup = 0;
        foreach ($dados['postes'] as $p) {
            $e = $achar($p['lat'], $p['lng']);
            if ($e) { if ($e[3]) { $nDup++; continue; } $um->execute([$p['nome'], $p['plaqueta'], $p['descricao'], $p['altura'], $p['esforco'], $p['lado'], $p['terceiros'], $e[2]]); $nMes++; continue; }
            $ip->execute([$p['nome'], $p['plaqueta'], $p['descricao'], $p['altura'], $p['esforco'], $p['lado'], $p['terceiros'], $p['lat'], $p['lng'], mb_substr($origem, 0, 90)]);
            $grade[$chave($p['lat'], $p['lng'])][] = [$p['lat'], $p['lng'], (int)$db->lastInsertId(), true]; $nP++;
        }
        // cabos já gravados (para não repetir o mesmo percurso)
        $exist = []; foreach ($db->query("SELECT pontos FROM ws_rede_trecho")->fetchAll(PDO::FETCH_COLUMN) as $pj) { $pp = json_decode($pj, true) ?: []; for ($i = 1; $i < count($pp); $i++) $exist[] = [$pp[$i - 1], $pp[$i]]; }
        $coberto = function (array $pts) use ($exist) {
            if (!$exist) return false; $tot = 0; $ok = 0;
            for ($i = 1; $i < count($pts); $i++) {
                $a = $pts[$i - 1]; $b = $pts[$i]; $len = rede_dist($a[0], $a[1], $b[0], $b[1]); $n = max(1, (int)ceil($len / 10));
                for ($k = 0; $k <= $n; $k++) {
                    $t = $k / $n; $la = $a[0] + ($b[0] - $a[0]) * $t; $lo = $a[1] + ($b[1] - $a[1]) * $t; $tot++; $best = 1e9;
                    foreach ($exist as $sg) { if (abs($sg[0][0] - $la) > 0.0008 && abs($sg[1][0] - $la) > 0.0008) continue; [$d] = rede_dist_seg($la, $lo, $sg[0], $sg[1]); if ($d < $best) $best = $d; if ($best <= 8) break; }
                    if ($best <= 8) $ok++;
                }
            }
            return $tot > 0 && $ok / $tot >= 0.85;
        };
        $it = $db->prepare("INSERT INTO ws_rede_trecho (nome, tipo, pontos, metros, origem) VALUES (?,?,?,?,?)"); $nT = 0; $nTi = 0; $metros = 0;
        foreach ($dados['trechos'] as $t) { if ($coberto($t['pontos'])) { $nTi++; continue; } $it->execute([$t['nome'], $t['tipo'], json_encode($t['pontos']), $t['metros'], mb_substr($origem, 0, 90)]); $nT++; $metros += $t['metros']; }
        $db->commit();
        return ['postes' => $nP, 'mesclados' => $nMes, 'duplicados' => $nDup, 'trechos' => $nT, 'trechos_ja_cobertos' => $nTi, 'metros' => $metros];
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
}

/* ---------------------------------------------------------------- clientes ---------------------------------------------------------------- */
/** Clientes vivos com a melhor coordenada (contrato → cadastro), endereço e PON. Cancelado/desativado fora. */
function rede_clientes(PDO $db): array {
    $sql = "SELECT c.id, c.nome, c.logradouro, c.numero, c.bairro, c.cidade, c.lat clat, c.lng clng, ct.lat tlat, ct.lng tlng, ct.placa_pon, ct.pon, ct.status ct_status, c.status c_status
            FROM ws_cliente c LEFT JOIN ws_contrato ct ON ct.cliente_id = c.id AND ct.status <> 'cancelado'
            WHERE c.status NOT IN ('cancelado','desativado') ORDER BY c.id, (ct.status='ativo') DESC, ct.id";
    $out = []; $vistos = [];
    foreach ($db->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $r) {
        if (isset($vistos[$r['id']])) continue; $vistos[$r['id']] = 1;
        $cl = (float)$r['clat']; $cn = (float)$r['clng']; $tl = (float)$r['tlat']; $tn = (float)$r['tlng'];
        $la = $tl ?: $cl; $lo = $tn ?: $cn; $pon = ($r['placa_pon'] !== null && $r['placa_pon'] !== '' && $r['pon'] !== null && $r['pon'] !== '') ? ((int)$r['placa_pon'] . '/' . (int)$r['pon']) : '';
        $out[] = ['id' => (int)$r['id'], 'nome' => (string)$r['nome'], 'rua' => trim((string)$r['logradouro']), 'numero' => trim((string)$r['numero']), 'bairro' => trim((string)$r['bairro']), 'cidade' => trim((string)$r['cidade']),
                  'lat' => $la, 'lng' => $lo, 'clat' => $cl, 'clng' => $cn, 'tlat' => $tl, 'tlng' => $tn, 'pon' => $pon, 'status' => (string)($r['ct_status'] ?: $r['c_status'])];
    }
    return $out;
}

function rede_postes(PDO $db): array { return $db->query("SELECT id, nome, plaqueta, descricao, altura, esforco, lado, terceiros, lat, lng FROM ws_rede_poste")->fetchAll(PDO::FETCH_ASSOC); }
function rede_trechos(PDO $db): array { $o = []; foreach ($db->query("SELECT id, nome, tipo, pontos, metros FROM ws_rede_trecho")->fetchAll(PDO::FETCH_ASSOC) as $t) { $t['pontos'] = json_decode($t['pontos'], true) ?: []; $o[] = $t; } return $o; }

/** Poste mais próximo de um ponto: [poste|null, distância m]. */
function rede_poste_proximo(array $postes, float $la, float $lo): array {
    $b = null; $bd = 1e12; foreach ($postes as $p) { $d = rede_dist($la, $lo, (float)$p['lat'], (float)$p['lng']); if ($d < $bd) { $bd = $d; $b = $p; } } return [$b, $bd];
}
function rede_trecho_proximo(array $trechos, float $la, float $lo): array {
    $bd = 1e12; $bp = null; $bt = null;
    foreach ($trechos as $t) { $pts = $t['pontos']; for ($i = 1; $i < count($pts); $i++) { [$d, $pp] = rede_dist_seg($la, $lo, $pts[$i - 1], $pts[$i]); if ($d < $bd) { $bd = $d; $bp = $pp; $bt = $t; } } }
    return [$bt, $bd, $bp];
}

/* ---------------------------------------------------------------- auditoria: endereço × coordenada ---------------------------------------------------------------- */
/**
 * Cruza o ENDEREÇO do cadastro (rua + bairro) com a COORDENADA de cada cliente. A referência de cada rua é a posição MEDIANA dos vizinhos da mesma rua
 * (≥3 clientes); a do bairro, a mediana do bairro. Marca: sem coordenada, longe da própria rua, longe do bairro, coordenada repetida (genérica),
 * contrato × cadastro divergentes e fora da região. Sempre devolve uma SUGESTÃO (com a confiança) — nada é alterado aqui.
 */
function rede_auditar(array $clientes, array $postes = []): array {
    $comCoord = array_values(array_filter($clientes, fn($c) => $c['lat'] && $c['lng']));
    $mlaT = rede_mediana(array_column($comCoord, 'lat')); $mloT = rede_mediana(array_column($comCoord, 'lng'));
    // referência por rua e por bairro (só com quem tem coordenada dentro da região)
    $regiao = fn($c) => rede_dist($c['lat'], $c['lng'], $mlaT, $mloT) <= 40000;
    $ruaRef = []; $bairroRef = [];
    foreach ($comCoord as $c) {
        if (!$regiao($c)) continue;
        $kr = rede_chave_rua($c['rua']); $kb = rede_chave($c['bairro']); $cid = rede_chave($c['cidade']);
        if ($kr !== '' && $kb !== '') $ruaRef[$cid . '|' . $kr . '|' . $kb][] = $c;
        if ($kb !== '') $bairroRef[$cid . '|' . $kb][] = $c;
    }
    $medRef = function (array $lista, ?int $excluir = null) {
        $l = array_values(array_filter($lista, fn($x) => $x['id'] !== $excluir)); if (!$l) return null;
        $la = rede_mediana(array_column($l, 'lat')); $lo = rede_mediana(array_column($l, 'lng'));
        $ds = []; foreach ($l as $x) $ds[] = rede_dist($x['lat'], $x['lng'], $la, $lo);
        return ['lat' => $la, 'lng' => $lo, 'n' => count($l), 'raio' => rede_mediana($ds), 'max' => $ds ? max($ds) : 0];
    };
    // coordenadas repetidas (genéricas): muitos clientes no mesmo ponto
    $rep = []; foreach ($comCoord as $c) $rep[sprintf('%.5f,%.5f', $c['lat'], $c['lng'])][] = $c['id'];
    $itens = []; $cont = ['ok' => 0, 'sem_coord' => 0, 'longe_rua' => 0, 'longe_bairro' => 0, 'repetida' => 0, 'diverge' => 0, 'fora_regiao' => 0];
    foreach ($clientes as $c) {
        $problemas = []; $sug = null; $conf = ''; $motivo = '';
        $kr = rede_chave_rua($c['rua']); $kb = rede_chave($c['bairro']); $cid = rede_chave($c['cidade']);
        $ruaKey = $cid . '|' . $kr . '|' . $kb; $baiKey = $cid . '|' . $kb;
        $rr = ($kr !== '' && $kb !== '' && isset($ruaRef[$ruaKey])) ? $medRef($ruaRef[$ruaKey], $c['id']) : null; if ($rr && $rr['n'] < 2) $rr = null;
        $br = ($kb !== '' && isset($bairroRef[$baiKey])) ? $medRef($bairroRef[$baiKey], $c['id']) : null; if ($br && $br['n'] < 4) $br = null;
        $temCoord = $c['lat'] && $c['lng'];
        if (!$temCoord) {
            $problemas[] = 'sem_coord'; $cont['sem_coord']++;
            if ($rr) { $sug = [$rr['lat'], $rr['lng']]; $conf = $rr['n'] >= 4 ? 'média' : 'baixa'; $motivo = 'mediana de ' . $rr['n'] . ' vizinho(s) da mesma rua'; }
            elseif ($br) { $sug = [$br['lat'], $br['lng']]; $conf = 'baixa'; $motivo = 'centro do bairro (' . $br['n'] . ' clientes)'; }
        } else {
            if (!$regiao($c)) { $problemas[] = 'fora_regiao'; $cont['fora_regiao']++; }
            if ($rr) {
                $d = rede_dist($c['lat'], $c['lng'], $rr['lat'], $rr['lng']); $lim = max(400.0, 4 * $rr['raio'], 0.8 * $rr['max']);
                if ($d > $lim) { $problemas[] = 'longe_rua'; $cont['longe_rua']++; $sug = [$rr['lat'], $rr['lng']]; $conf = $rr['n'] >= 4 ? 'média' : 'baixa'; $motivo = round($d) . ' m da rua (mediana de ' . $rr['n'] . ' vizinhos)'; }
            }
            if (!$sug && $br) {
                $d = rede_dist($c['lat'], $c['lng'], $br['lat'], $br['lng']); $lim = max(2500.0, 4 * $br['raio']);
                if ($d > $lim) { $problemas[] = 'longe_bairro'; $cont['longe_bairro']++; $sug = [$br['lat'], $br['lng']]; $conf = 'baixa'; $motivo = round($d / 1000, 1) . ' km do centro do bairro'; }
            }
            if (count($rep[sprintf('%.5f,%.5f', $c['lat'], $c['lng'])] ?? []) >= 4) {
                $problemas[] = 'repetida'; $cont['repetida']++; if (!$sug && $rr) { $sug = [$rr['lat'], $rr['lng']]; $conf = 'baixa'; $motivo = 'mesma coordenada de ' . (count($rep[sprintf('%.5f,%.5f', $c['lat'], $c['lng'])]) - 1) . ' outros clientes; mediana da rua'; }
            }
            if ($c['tlat'] && $c['clat'] && rede_dist($c['tlat'], $c['tlng'], $c['clat'], $c['clng']) > 60) { $problemas[] = 'diverge'; $cont['diverge']++; }
        }
        if (!$problemas) $cont['ok']++;
        [$po, $dp] = ($temCoord && $postes) ? rede_poste_proximo($postes, $c['lat'], $c['lng']) : [null, null];
        if ($problemas) $itens[] = ['id' => $c['id'], 'nome' => $c['nome'], 'rua' => $c['rua'], 'numero' => $c['numero'], 'bairro' => $c['bairro'], 'lat' => $c['lat'] ?: null, 'lng' => $c['lng'] ?: null,
            'problemas' => $problemas, 'sug' => $sug ? [round($sug[0], 7), round($sug[1], 7)] : null, 'conf' => $conf, 'motivo' => $motivo, 'poste_m' => $dp !== null ? (int)round($dp) : null];
    }
    return ['total' => count($clientes), 'contagem' => $cont, 'itens' => $itens];
}

/* ---------------------------------------------------------------- sugestão de CTOs nos postes ---------------------------------------------------------------- */
/**
 * Cada CTO sugerida fica num POSTE real. Clientes de PONs diferentes não dividem caixa (se $porPon). Escolha gulosa: o poste que alcança mais clientes
 * livres (dentro de $raio m), até $portas por caixa; empate = menor soma de distâncias. Ignora quem já está numa porta e quem não tem coordenada confiável.
 */
function rede_sugerir_ctos(PDO $db, array $clientes, array $postes, int $portas, float $raio, bool $porPon, array $excluirIds = []): array {
    $ocupados = []; try { foreach ($db->query("SELECT cliente_id FROM ws_cto_porta WHERE cliente_id IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN) as $i) $ocupados[(int)$i] = 1; } catch (Throwable $e) {}
    $postesComCto = []; try { foreach ($db->query("SELECT latitude, longitude FROM ws_cto WHERE latitude IS NOT NULL")->fetchAll(PDO::FETCH_NUM) as $c) $postesComCto[] = [(float)$c[0], (float)$c[1]]; } catch (Throwable $e) {}
    $livres = []; $semPoste = []; $generica = 0; $rep = [];
    foreach ($clientes as $c) if ($c['lat'] && $c['lng']) { $k = sprintf('%.5f,%.5f', $c['lat'], $c['lng']); $rep[$k] = ($rep[$k] ?? 0) + 1; }
    foreach ($clientes as $c) {
        if (isset($ocupados[$c['id']]) || isset($excluirIds[$c['id']]) || !$c['lat'] || !$c['lng']) continue;
        if (($rep[sprintf('%.5f,%.5f', $c['lat'], $c['lng'])] ?? 0) >= 4) { $generica++; continue; }   // coordenada repetida = genérica, não prova onde o cliente mora
        $livres[$porPon ? ($c['pon'] !== '' ? $c['pon'] : '(sem PON)') : 'todos'][] = $c;
    }
    $propostas = []; $seq = [];
    foreach ($livres as $grupo => $lista) {
        // candidatos: para cada cliente, postes dentro do raio
        $cand = []; foreach ($lista as $i => $c) { $achou = false; foreach ($postes as $pi => $p) { $d = rede_dist($c['lat'], $c['lng'], (float)$p['lat'], (float)$p['lng']); if ($d <= $raio) { $cand[$pi][$i] = $d; $achou = true; } } if (!$achou) $semPoste[] = ['id' => $c['id'], 'nome' => $c['nome']]; }
        $livre = array_fill_keys(array_keys($lista), true);
        while (true) {
            $melhor = null; $mn = 0; $ms = 1e18;
            foreach ($cand as $pi => $cl) { $v = array_filter($cl, fn($d, $i) => isset($livre[$i]), ARRAY_FILTER_USE_BOTH); if (!$v) continue; asort($v); $v = array_slice($v, 0, $portas, true); $n = count($v); $s = array_sum($v);
                if ($n > $mn || ($n === $mn && $s < $ms)) { $mn = $n; $ms = $s; $melhor = [$pi, $v]; } }
            if (!$melhor) break;
            [$pi, $v] = $melhor; $p = $postes[$pi]; $seq[$grupo] = ($seq[$grupo] ?? 0) + 1; $cls = []; $port = 1;
            foreach ($v as $i => $d) { unset($livre[$i]); $c = $lista[$i]; $cls[] = ['id' => $c['id'], 'nome' => $c['nome'], 'porta' => $port++, 'dist_m' => (int)round($d)]; }
            $jaTem = false; foreach ($postesComCto as $pc) if (rede_dist($pc[0], $pc[1], (float)$p['lat'], (float)$p['lng']) < 8) { $jaTem = true; break; }
            $rot = $grupo === 'todos' ? '' : (($grupo === '(sem PON)') ? 'SP' : '0-' . str_replace('/', '-', $grupo));
            $propostas[] = ['nome' => 'CTO-' . ($rot !== '' ? $rot . '-' : '') . str_pad((string)$seq[$grupo], 2, '0', STR_PAD_LEFT) . ($p['plaqueta'] !== '' ? ' (poste ' . $p['plaqueta'] . ')' : ($p['nome'] !== '' ? ' (poste ' . $p['nome'] . ')' : '')),
                'pon' => $grupo === 'todos' ? '' : $grupo, 'poste_id' => (int)$p['id'], 'lat' => (float)$p['lat'], 'lng' => (float)$p['lng'], 'portas' => $portas, 'clientes' => $cls, 'ocupacao' => count($cls), 'ja_tem_cto_no_poste' => $jaTem];
        }
    }
    usort($propostas, fn($a, $b) => $b['ocupacao'] <=> $a['ocupacao']);
    return ['propostas' => $propostas, 'sem_poste' => $semPoste, 'clientes_considerados' => array_sum(array_map('count', $livres)), 'ja_em_porta' => count($ocupados), 'coord_generica' => $generica];
}

/* ---------------------------------------------------------------- exportação KMZ ---------------------------------------------------------------- */
function rede_kml_esc(string $s): string { return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }
function rede_gerar_kml(PDO $db, bool $comClientes): string {
    $k = '<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Rede FTTH — WellSystem</name>'
       . '<Style id="poste"><IconStyle><color>ff0000ff</color><scale>0.6</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href></Icon></IconStyle><LabelStyle><scale>0</scale></LabelStyle></Style>'
       . '<Style id="cto"><IconStyle><color>ff00a5ff</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/triangle.png</href></Icon></IconStyle></Style>'
       . '<Style id="cli"><IconStyle><color>ff50c878</color><scale>0.5</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href></Icon></IconStyle><LabelStyle><scale>0</scale></LabelStyle></Style>'
       . '<Style id="cabo"><LineStyle><color>ffffff00</color><width>3</width></LineStyle></Style>';
    $k .= '<Folder><name>POSTES</name>'; foreach (rede_postes($db) as $p) $k .= '<Placemark><name>' . rede_kml_esc($p['plaqueta'] !== '' ? $p['plaqueta'] : $p['nome']) . '</name><description>' . rede_kml_esc($p['descricao']) . '</description><styleUrl>#poste</styleUrl><Point><coordinates>' . $p['lng'] . ',' . $p['lat'] . ',0</coordinates></Point></Placemark>';
    $k .= '</Folder><Folder><name>TRAJETO / CABOS</name>'; foreach (rede_trechos($db) as $t) { $c = []; foreach ($t['pontos'] as $q) $c[] = $q[1] . ',' . $q[0] . ',0'; $k .= '<Placemark><name>' . rede_kml_esc($t['nome'] !== '' ? $t['nome'] : ucfirst($t['tipo'])) . '</name><description>' . (int)$t['metros'] . ' m</description><styleUrl>#cabo</styleUrl><LineString><tessellate>1</tessellate><coordinates>' . implode(' ', $c) . '</coordinates></LineString></Placemark>'; }
    $k .= '</Folder><Folder><name>CTOs</name>';
    try { foreach ($db->query("SELECT ct.nome, ct.latitude, ct.longitude, ct.portas, (SELECT COUNT(*) FROM ws_cto_porta p WHERE p.cto_id=ct.id AND p.cliente_id IS NOT NULL) oc FROM ws_cto ct WHERE ct.latitude IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC) as $c) $k .= '<Placemark><name>' . rede_kml_esc($c['nome']) . '</name><description>' . (int)$c['oc'] . '/' . (int)$c['portas'] . ' portas ocupadas</description><styleUrl>#cto</styleUrl><Point><coordinates>' . $c['longitude'] . ',' . $c['latitude'] . ',0</coordinates></Point></Placemark>'; } catch (Throwable $e) {}
    $k .= '</Folder>';
    if ($comClientes) { $k .= '<Folder><name>CLIENTES</name>'; foreach (rede_clientes($db) as $c) if ($c['lat'] && $c['lng']) $k .= '<Placemark><name>' . rede_kml_esc($c['nome']) . '</name><description>' . rede_kml_esc(trim($c['rua'] . ' ' . $c['numero'] . ' — ' . $c['bairro'])) . '</description><styleUrl>#cli</styleUrl><Point><coordinates>' . $c['lng'] . ',' . $c['lat'] . ',0</coordinates></Point></Placemark>'; $k .= '</Folder>'; }
    return $k . '</Document></kml>';
}
