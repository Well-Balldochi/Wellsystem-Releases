<?php
// Dá acesso a ws_db_config()/ws_mkauth_credenciais() (bootstrap do config.php), pra este arquivo
// poder reaproveitar a MESMA credencial que já abre o banco `wellsystem` — sem exigir nenhum
// arquivo novo nem cadastro manual. Guardado em is_file() pra nunca quebrar quem rodar este script
// solto, sem o restante do WellSystem ao lado (não faz sentido aqui, mas é o padrão do projeto).
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
// Dá acesso a ws_conexao_viva()/ws_ler_sessoes()/ws_cache_dir() (radius_lib.php) — usadas pelo
// fallback "ao vivo" da ação 'log' abaixo, pra ler o mesmo jeito que o Painel dos Concentradores
// já usa quando o radacct não tem registro nenhum pro NAS. Guardado em is_file() pelo mesmo
// motivo do require do config.php acima: nunca quebrar quem rodar este script solto.
if (is_file(__DIR__ . '/radius_lib.php')) require_once __DIR__ . '/radius_lib.php';
header('Content-Type: application/json');
/* SEGURANÇA (30/09/2026): este endpoint respondia SEM login — qualquer um na internet lia o log de conexões dos
   clientes (login, IP, MAC) e chamava ações como limpar_mac. Todos os chamadores são telas logadas do sistema
   (servidores.php, mk_monitor.php, trafego_servidores.php), que já mandam o cookie da sessão. */
if (function_exists('ws_user') && empty($_SESSION['ws_user'])) { http_response_code(401); echo json_encode(['status' => 'erro', 'mensagem' => 'Sessão expirada — entre no sistema de novo.']); exit; }

// Função de Conexão Telnet sobre SSL
function executar_comando_telnet_ssl($ip, $port, $comando, $timeout = 2, $username = '', $password = '') {
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ]);

    // Tenta conexão SSL/TLS
    $socket = @stream_socket_client("ssl://$ip:$port", $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);
    
    // Tratamento de erro e reconexão automática (segunda tentativa)
    if (!$socket) {
        usleep(300000); // espera 300ms antes de tentar de novo
        $socket = @stream_socket_client("ssl://$ip:$port", $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);
        if (!$socket) {
            // Tenta fallback TCP normal
            $socket = @stream_socket_client("tcp://$ip:$port", $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT);
            if (!$socket) {
                throw new Exception("Falha na conexao Telnet (SSL e TCP falharam): $errstr ($errno)");
            }
        }
    }

    stream_set_timeout($socket, $timeout);
    
    $buffer = "";
    $start_time = time();
    
    // Ler dados iniciais e lidar com login se necessário
    while (!feof($socket)) {
        if ((time() - $start_time) > $timeout) {
            break;
        }
        $line = fgets($socket, 4096);
        if ($line === false) break;
        $buffer .= $line;
        
        $clean_buf = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $buffer);
        
        if (preg_match('/(login|user|usuario):/i', $clean_buf) && !strpos($buffer, "sent_user")) {
            fwrite($socket, $username . "\r\n");
            $buffer .= " sent_user ";
        }
        if (preg_match('/(password|senha):/i', $clean_buf) && !strpos($buffer, "sent_pass")) {
            fwrite($socket, $password . "\r\n");
            $buffer .= " sent_pass ";
        }
        if (preg_match('/(accel-ppp#|#|>|\$)\s*$/i', trim($clean_buf))) {
            break;
        }
    }
    
    // Envia o comando
    fwrite($socket, $comando . "\r\n");
    
    // Lê a resposta
    $resposta = "";
    $start_time = time();
    while (!feof($socket)) {
        if ((time() - $start_time) > $timeout) {
            break;
        }
        $line = fgets($socket, 4096);
        if ($line === false) break;
        $resposta .= $line;
        
        $clean_resp = preg_replace('/[^\x20-\x7E\n\r\t]/', '', $resposta);
        if (preg_match('/(accel-ppp#|#|>|\$)\s*$/i', trim($clean_resp))) {
            break;
        }
    }
    
    // Encerra sessão de forma limpa
    fwrite($socket, "exit\r\n");
    fclose($socket);
    
    return preg_replace('/[^\x20-\x7E\n\r\t]/', '', $resposta);
}

// Porta do CLI Telnet do Accel
$accel_port = !empty($_POST['porta']) ? intval($_POST['porta']) : (!empty($_POST['porta_telnet']) ? intval($_POST['porta_telnet']) : 2000); 

// Pega o nome/slug que o modal enviou (Ex: concentrador-01 ou concentrador-02)
$cnc_recebido = !empty($_POST['ip_concentrador']) ? trim($_POST['ip_concentrador']) : "";

// =========================================================================
// REGRA RECONHECIMENTO DOS CONCENTRADORES
// =========================================================================
$accel_ip = '';
if (!empty($cnc_recebido)) $accel_ip = $cnc_recebido;   // IP (ou nome) do concentrador vem da tela de Servidores — nada fixo no código
if ($accel_ip === '') { echo 'Concentrador não informado.'; exit; }
// =========================================================================

// Credenciais do banco do RADIUS: instalação HÍBRIDA — o mesmo arquivo pode rodar como addon do
// MK-Auth (banco mkradius local, credenciais clássicas root/vertrigo) OU como WellSystem standalone
// (Docker, credenciais próprias em WS_DB_*) OU com um RADIUS de terceiros cadastrado na tela de
// Configurações. Antes esta função devolvia o PRIMEIRO candidato que tivesse host preenchido na
// tela, mesmo que esse host/senha estivesse errado ou fosse de OUTRO banco (ex.: as credenciais do
// banco de dados do próprio WellSystem, que são diferentes das do RADIUS/MK-Auth) — e nunca tentava
// os próximos da lista. Resultado: LOG-01/LOG-02 e "Ver Logs" do cliente ficavam sem log mesmo com
// o RADIUS certo disponível um passo adiante.
//
// 2ª TENTATIVA DE CORREÇÃO (a credencial do banco `wellsystem` testada contra `mkradius`) TAMBÉM
// FALHOU nesta instalação: confirmado pelo próprio log do operador — o MySQL tem um usuário
// dedicado "wellsystem", com GRANT só no banco `wellsystem`, sem acesso ao `mkradius`. Ou seja,
// não é "a mesma senha abre os dois bancos": são credenciais DIFERENTES de propósito (boa prática
// de segurança), e o WellSystem nunca precisou saber a senha real do root do MySQL até agora.
//
// CORREÇÃO DE VERDADE: quem SABE a senha real do root do MySQL é o próprio MK-Auth (é ele quem
// criou o banco `mkradius` e se conecta nele o tempo todo). O config.php já tem uma função pronta
// pra isso — ws_mkauth_credenciais() — que vasculha os .php de instalação do MK-Auth (/opt/mk-auth
// e subpastas), extrai todo par usuário/senha de banco que encontrar e TESTA cada um contra a
// tabela sis_cliente (só existe no banco do MK-Auth) até achar o que funciona de verdade. É
// EXATAMENTE "buscar automaticamente, mesmo modelo de achar IP" — só que eu tinha esquecido de
// chamar essa função aqui; só usava ws_db_config(), que devolve a credencial CACHEADA (o usuário
// "wellsystem" restrito), sem nunca escanear o MK-Auth de novo depois da 1ª instalação.
// Ordem final, cada candidato REALMENTE testado (mysqli_connect de verdade) antes de ser aceito:
//   1) cada RADIUS cadastrado na tela de Configurações (começando pelo ativo, depois os demais)
//   2) autodescoberta do MK-Auth (ws_mkauth_credenciais() — escaneia /opt/mk-auth e testa contra
//      sis_cliente): é quem sabe a senha real do root do MySQL, testada aqui contra `mkradius`
//   3) a credencial do PRÓPRIO banco `wellsystem` (ws_db_config()), testada contra `mkradius` — só
//      por garantia, caso um dia o usuário "wellsystem" ganhe GRANT nesse banco também
//   4) variáveis de ambiente WS_DB_* (instalação WellSystem em Docker)
//   5) padrão clássico do MK-Auth (127.0.0.1 / root / vertrigo / mkradius) — só devolvido sem
//      testar por ser o último recurso.
function ws_socket_telnet_radius_cfg() {
    $tentativas = [];
    $funciona = function ($host, $user, $pass, $name) use (&$tentativas, &$fonte) {
        if ($host === '') { $tentativas[] = "{$fonte}: host vazio, pulado"; return false; }
        $l = @mysqli_connect($host, $user, $pass, $name);
        if ($l) { mysqli_close($l); $tentativas[] = "{$fonte}: host={$host} usuario={$user} banco={$name} -> OK"; return true; }
        $tentativas[] = "{$fonte}: host={$host} usuario={$user} banco={$name} -> FALHOU (" . mysqli_connect_error() . ")";
        return false;
    };

    foreach ([__DIR__ . '/cache_trafego/wellsystem_config.json', sys_get_temp_dir() . '/acellApp_cache_trafego/wellsystem_config.json'] as $wf) {
        if (!is_file($wf)) continue;
        $wc = json_decode(@file_get_contents($wf), true);
        if (!is_array($wc) || empty($wc['radius']) || !is_array($wc['radius'])) continue;
        $wi = (int)($wc['radius_ativo'] ?? 0);
        // Testa primeiro o RADIUS marcado como ativo; se não conectar, tenta os outros cadastrados
        // antes de desistir da tela e passar para o Docker/padrão do MK-Auth.
        $ordem = array_unique(array_merge([$wi], array_keys($wc['radius'])));
        foreach ($ordem as $idx) {
            $wr = $wc['radius'][$idx] ?? null;
            if (!is_array($wr) || empty($wr['host'])) continue;
            $host = (string)$wr['host']; $user = (string)($wr['user'] ?? 'root');
            $pass = (string)($wr['pass'] ?? ''); $name = (string)($wr['dbname'] ?? 'mkradius');
            $fonte = "tela (radius #{$idx})";
            if ($funciona($host, $user, $pass, $name)) {
                return ['host' => $host, 'user' => $user, 'pass' => $pass, 'name' => $name, 'tentativas' => $tentativas];
            }
        }
    }

    // 2) Autodescoberta do MK-Auth — quem realmente sabe a senha do root do MySQL.
    $fonte = 'autodescoberta MK-Auth (ws_mkauth_credenciais)';
    if (function_exists('ws_mkauth_credenciais')) {
        $mk = ws_mkauth_credenciais();
        if (is_array($mk) && !empty($mk['host'])) {
            if ($funciona((string)$mk['host'], (string)($mk['user'] ?? 'root'), (string)($mk['pass'] ?? ''), 'mkradius')) {
                return ['host' => (string)$mk['host'], 'user' => (string)($mk['user'] ?? 'root'),
                        'pass' => (string)($mk['pass'] ?? ''), 'name' => 'mkradius', 'tentativas' => $tentativas];
            }
        } else {
            $tentativas[] = "{$fonte}: não achou credencial de MK-Auth em /opt/mk-auth (ou a pasta não existe neste servidor)";
        }
    } else {
        $tentativas[] = "{$fonte}: config.php não estava disponível (arquivo ausente ao lado deste script)";
    }

    // 3) Credencial do PRÓPRIO banco `wellsystem` — mantida como candidato por garantia (caso o
    // usuário "wellsystem" um dia ganhe GRANT no mkradius também), mas hoje é o usuário restrito.
    $fonte = 'banco do próprio WellSystem (config.php)';
    if (function_exists('ws_db_config')) {
        $proprio = ws_db_config();
        $hostProprio = (string)($proprio['host'] ?? '');
        $nomeProprio = (string)($proprio['dbname'] ?? 'wellsystem');
        if ($hostProprio !== '') {
            if ($funciona($hostProprio, (string)($proprio['user'] ?? 'root'), (string)($proprio['pass'] ?? ''), 'mkradius')) {
                return ['host' => $hostProprio, 'user' => (string)($proprio['user'] ?? 'root'),
                        'pass' => (string)($proprio['pass'] ?? ''), 'name' => 'mkradius', 'tentativas' => $tentativas];
            }
            // 3b) INSTALAÇÃO NATIVA (freeradius embutido, sem MK-Auth): aqui não existe banco
            // `mkradius` nenhum — o radacct mora dentro do PRÓPRIO banco `wellsystem` (ver
            // schema_radius.php). O teste acima falha SEMPRE nesse caso (usuário "wellsystem" sem
            // GRANT em `mkradius`), e antes a função ia direto pro Docker/padrão sem nunca tentar o
            // nome de banco certo com a credencial certa. Mesmo host/usuário/senha já testados,
            // agora tentando o banco de verdade («wellsystem» ou o que estiver configurado).
            if ($nomeProprio !== '' && $nomeProprio !== 'mkradius'
                && $funciona($hostProprio, (string)($proprio['user'] ?? 'root'), (string)($proprio['pass'] ?? ''), $nomeProprio)) {
                return ['host' => $hostProprio, 'user' => (string)($proprio['user'] ?? 'root'),
                        'pass' => (string)($proprio['pass'] ?? ''), 'name' => $nomeProprio, 'tentativas' => $tentativas];
            }
        } else {
            $tentativas[] = "{$fonte}: ws_db_config() não devolveu host";
        }
    }

    $fonte = 'docker env WS_DB_HOST';
    if (getenv('WS_DB_HOST')) {
        $host = (string)getenv('WS_DB_HOST'); $user = getenv('WS_DB_USER') ?: 'root';
        $pass = getenv('WS_DB_PASS') ?: '';
        // Mesma lógica do item 3b acima, agora para a instalação em Docker: primeiro tenta
        // `mkradius` (Docker rodando ao lado de um MK-Auth), e só então o banco que o próprio
        // ambiente Docker configurou (WS_DB_NAME) — «wellsystem» por padrão, igual ao ws_db_config()
        // em config.php — em vez de cair direto no «mkradius» fixo mesmo quando o Docker nem usa
        // esse nome de banco.
        $nameEnv = getenv('WS_DB_NAME') ?: 'wellsystem';
        if ($funciona($host, $user, $pass, 'mkradius')) {
            return ['host' => $host, 'user' => $user, 'pass' => $pass, 'name' => 'mkradius', 'tentativas' => $tentativas];
        }
        if ($nameEnv !== 'mkradius' && $funciona($host, $user, $pass, $nameEnv)) {
            return ['host' => $host, 'user' => $user, 'pass' => $pass, 'name' => $nameEnv, 'tentativas' => $tentativas];
        }
    } else {
        $tentativas[] = 'docker env WS_DB_HOST: getenv() não retornou nada (variável não chega ao PHP)';
    }

    $tentativas[] = 'padrão MK-Auth (127.0.0.1/root/vertrigo/mkradius): usado como último recurso, sem testar antes';
    return ['host' => '127.0.0.1', 'user' => 'root', 'pass' => 'vertrigo', 'name' => 'mkradius', 'tentativas' => $tentativas];
}
$__ws_rad_cfg = ws_socket_telnet_radius_cfg();
$db_host = $__ws_rad_cfg['host'];
$db_user = $__ws_rad_cfg['user'];
$db_pass = $__ws_rad_cfg['pass'];
$db_name = $__ws_rad_cfg['name'];
$db_tentativas = $__ws_rad_cfg['tentativas'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['command']) || isset($_POST['acao']))) {
    $acao = $_POST['acao'] ?? $_POST['command'] ?? '';
    
    // Ação: PING real com suporte a Linux e Windows de forma segura e rápida
    if ($acao === 'ping') {
        error_reporting(0);
        ini_set('display_errors', 0);
        $host = trim($_POST['host'] ?? $_POST['alvo'] ?? $_POST['username'] ?? '');
        
        if (preg_match('/^[a-zA-Z0-9\.\-_]+$/', $host)) {
            // Detecta se o sistema operacional do servidor é Windows ou Linux
            if (stristr(PHP_OS, 'WIN')) {
                // Windows: -n (número de pacotes), -w (timeout em milissegundos)
                $cmd = "ping -n 1 -w 1000 " . escapeshellarg($host);
            } else {
                // Linux: -c (número de pacotes), -W (timeout em segundos), -w (deadline em segundos)
                $cmd = "ping -c 1 -W 1 -w 2 " . escapeshellarg($host);
            }
            
            $output = @shell_exec($cmd);
            if ($output === null || $output === false || trim((string)$output) === '') {
                echo json_encode(["status" => "ok", "output" => "Sem resposta do host (timeout atingido)"]);
                exit;
            }
            $output = @mb_convert_encoding($output, 'UTF-8', 'CP850');
            echo json_encode(["status" => "ok", "output" => $output]);
        } else {
            echo json_encode(["status" => "error", "message" => "Destino de ping invalido: $host"]);
        }
        exit;
    }

    // Ação: LIMPAR MAC real
    if ($acao === 'limpar_mac') {
        error_reporting(0);
        ini_set('display_errors', 0);
        $username = trim($_POST['username'] ?? '');
        if (!empty($username)) {
            $link_db = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
            if ($link_db) {
                $user_esc = mysqli_real_escape_string($link_db, $username);
                mysqli_query($link_db, "UPDATE sis_cliente SET mac = '' WHERE login = '$user_esc'");
                mysqli_query($link_db, "DELETE FROM radreply WHERE username = '$user_esc' AND attribute = 'Calling-Station-Id'");
                mysqli_query($link_db, "UPDATE sis_adicional SET mac = '' WHERE username = '$user_esc'");
                mysqli_close($link_db);
                echo json_encode(["status" => "ok", "message" => "Endereco MAC liberado com sucesso no RADIUS!"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao conectar no banco de dados."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Usuario nao especificado."]);
        }
        exit;
    }

    // Ação: Obter tráfego real do Accel-PPP
    if ($acao === 'obter_banda_cliente' || $acao === 'load' || $acao === 'iftop') {
        error_reporting(0);
        ini_set('display_errors', 0);
        $username = trim($_POST['username'] ?? '');
        // login vai direto no comando do accel: só caracteres de login (nada de espaço/quebra de linha) (09/11/2026)
        if (!preg_match('/^[A-Za-z0-9@._:\/+-]{1,64}$/', $username)) { echo json_encode(["status" => "error", "message" => "Login inválido."]); exit; }

        $socket = @fsockopen($accel_ip, $accel_port, $errno, $errstr, 2);
        if ($socket) {
            stream_set_timeout($socket, 2);
            fgets($socket); // limpa banner

            $cmd = "show sessions username,ifname,rx-bytes-raw,tx-bytes-raw,rx-pkts,tx-pkts match username " . $username . "\r\n";
            fputs($socket, $cmd);
            /* LÊ EM BLOCOS até o prompt (09/11/2026, mesma regra do ws_ler_sessoes_status): o prompt "accel-ppp# " vem SEM quebra de
               linha e o fgets esperava o tempo-limite em TODA leitura (2,0 s cravados, 299 vezes em 3 dias no log de páginas lentas).
               Só para depois do cabeçalho da tabela ("| rx-bytes-raw"): o prompt que sobra do banner não corta a leitura. */
            $resp = "";
            $fim_leitura = microtime(true) + 2;
            while (!feof($socket) && microtime(true) < $fim_leitura) {
                $bloco = fread($socket, 8192);
                if ($bloco === false) break;
                if ($bloco === '') { if (!empty(stream_get_meta_data($socket)['timed_out'])) break; continue; }
                $resp .= $bloco;
                if (preg_match('/\|\s*rx-bytes-raw/', $resp) && preg_match('/accel-ppp#\s*$/', $resp)) break;
            }
            fputs($socket, "exit\r\n");
            fclose($socket);

            $linhas = explode("\n", $resp);
            $dados_session = null;
            foreach ($linhas as $l) {
                $l = trim(str_replace("\x00", "", $l));
                if (empty($l) || strpos($l, 'username') !== false || strpos($l, '|') === false) continue;
                $partes = array_map('trim', explode('|', $l));
                if (count($partes) >= 5) {
                    $dados_session = [
                        "username" => $partes[0],
                        "ifname" => $partes[1],
                        "octet_in" => floatval($partes[2] ?? 0),
                        "octet_out" => floatval($partes[3] ?? 0),
                        "packets_in" => intval($partes[4] ?? 0),
                        "packets_out" => intval($partes[5] ?? 0)
                    ];
                    break;
                }
            }
            
            if ($dados_session) {
                echo json_encode(["status" => "ok", "dados" => $dados_session]);
            } else {
                echo json_encode(["status" => "error", "message" => "Sessao nao encontrada no concentrador."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Falha na conexao com o concentrador via Telnet."]);
        }
        exit;
    }

    // Ação: Consumo diário REAL do mês corrente
    if ($acao === 'consumo_mensal') {
        error_reporting(0);
        ini_set('display_errors', 0);
        $username = trim($_POST['username'] ?? '');
        $dias_no_mes = intval(date('t'));
        $dias_out = array_fill(1, $dias_no_mes, 0.0);

        if (!empty($username)) {
            $link_db = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
            if ($link_db) {
                $user_esc = mysqli_real_escape_string($link_db, $username);
                $inicio_mes = date('Y-m-01 00:00:00');
                $sql = "SELECT
                            DAY(COALESCE(acctstoptime, acctstarttime)) AS dia,
                            SUM(COALESCE(acctinputoctets,0) + COALESCE(acctoutputoctets,0)) AS total_bytes
                        FROM radacct
                        WHERE username = '$user_esc'
                          AND COALESCE(acctstoptime, acctstarttime) >= '$inicio_mes'
                        GROUP BY dia";
                $res = mysqli_query($link_db, $sql);
                if ($res) {
                    while ($row = mysqli_fetch_assoc($res)) {
                        $dia = intval($row['dia']);
                        if ($dia >= 1 && $dia <= $dias_no_mes) {
                            $dias_out[$dia] = round(floatval($row['total_bytes']) / 1073741824, 2); // GB
                        }
                    }
                }
                mysqli_close($link_db);
            }
        }
        echo json_encode(["status" => "ok", "dias" => array_values($dias_out), "dia_atual" => intval(date('j'))]);
        exit;
    }

    // Ação: Histórico de Conexões Exclusivo do Cliente
    if ($acao === 'log_cliente') {
        error_reporting(0);
        ini_set('display_errors', 0);
        $username = trim($_POST['username'] ?? '');
        $log_resultado = "";
        
        if (!empty($username)) {
            $link_db = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
            if (!$link_db) {
                // Mesmo diagnóstico aplicado na ação 'log' (LOG-01/LOG-02): mostra host/usuário/banco
                // tentados e a mensagem real do MySQL/MariaDB, em vez de um erro genérico mudo.
                $log_resultado = "Erro ao conectar ao banco de dados (host={$db_host} usuario={$db_user} "
                    . "banco={$db_name}): " . mysqli_connect_error()
                    . (!empty($db_tentativas) ? "\n\nTentativas (tela -> Docker -> padrão MK-Auth):\n - " . implode("\n - ", $db_tentativas) : "");
                echo json_encode(["status" => "ok", "log" => $log_resultado]);
                exit;
            }
            if ($link_db) {
                mysqli_set_charset($link_db, 'utf8');
                $user_esc = mysqli_real_escape_string($link_db, $username);
                
                $sql = "SELECT 
                            username, callingstationid, calledstationid, framedipaddress, 
                            acctstarttime, acctstoptime, acctterminatecause, acctsessionid, nasportid
                        FROM radacct 
                        WHERE username = '$user_esc' OR callingstationid = '$user_esc' 
                        ORDER BY radacctid DESC 
                        LIMIT 50";
                
                $res = mysqli_query($link_db, $sql);
                $eventos = [];
                /* TENTATIVAS RECUSADAS (14/10): as recusas do FreeRADIUS deste login (radpostauth, class 'ws:código|MAC|concentrador') entram no mesmo histórico como RECUSADO. */
                $recusas = [];
                $mot = ['S' => 'senha incorreta', 'N' => 'login não cadastrado (provável erro de digitação)', 'C' => 'login cadastrado, mas sem senha no RADIUS', 'O' => 'recusado pelo RADIUS'];
                $rr = @mysqli_query($link_db, "SELECT authdate, class FROM radpostauth WHERE username = '$user_esc' AND class LIKE 'ws:%' ORDER BY authdate DESC LIMIT 30");
                if ($rr) while ($x = mysqli_fetch_assoc($rr)) {
                    $pc = explode('|', substr((string)$x['class'], 3)); $tsr = strtotime($x['authdate']);
                    $recusas[] = ['ts' => $tsr, 'line' => date('d/m/Y - H:i:s', $tsr) . " - RECUSADO: {$username} - " . ($mot[$pc[0]] ?? $mot['O']) . ' - ' . (($pc[1] ?? '-') !== '-' ? $pc[1] : 'sem MAC') . ' -- ' . ($pc[2] ?? '')];
                }
                
                if ($res && mysqli_num_rows($res) > 0) {
                    $causas = [
                        'User-Request'        => 'Cliente encerrou',
                        'Lost-Carrier'        => 'Sem portadora',
                        'Idle-Timeout'        => 'Tempo ocioso',
                        'Session-Timeout'     => 'Tempo de sessão expirado',
                        'Admin-Reset'         => 'Reset pelo administrador',
                        'Admin-Reboot'        => 'Reboot pelo administrador',
                            // Códigos do próprio WellSystem (antes apareciam crus, ex.: "Ws-Mesmo-MAC"):
                            'Ws-Mesmo-MAC'        => 'Equipamento reconectou (nova sessão substituiu a antiga)',
                            'Ws-Derrubada'        => 'Derrubada pelo sistema (bloqueio/desbloqueio/reconexão)',
                            'Ws-Sem-Atualizacao'  => 'Sessão sem sinal do concentrador (encerrada)',
                            'NAS-Request'         => 'Encerrada pelo concentrador',
                            'NAS-Error'           => 'Erro no concentrador',
                            'User-Error'          => 'Erro de autenticação do equipamento',
                            'Port-Error'          => 'Erro na porta',
                        ''                    => 'Desconhecido'
                    ];
                    
                    while ($row = mysqli_fetch_assoc($res)) {
                        $mac       = $row['callingstationid'] ?? '00:00:00:00:00:00';
                        $vlan_raw  = $row['calledstationid'] ?? '';
                        $ip_cli    = $row['framedipaddress'] ?? '0.0.0.0';
                        $inicio    = $row['acctstarttime'] ?? '';
                        $fim       = $row['acctstoptime'] ?? '';
                        $causa     = $row['acctterminatecause'] ?? '';
                        $ifname    = $row['nasportid'] ?? 'N/A';
                        
                        $vlan_exibicao = $vlan_raw;
                        if (!empty($vlan_raw) && stripos($vlan_raw, 'vlan') === false) {
                            $vlan_exibicao = 'vlan' . $vlan_raw;
                        }
                        
                        if (!empty($inicio)) {
                            $ts = strtotime($inicio);
                            $eventos[] = [
                                'ts' => $ts,
                                'line' => date('d/m/Y - H:i:s', $ts) . " - CONECTADO: {$ifname} - {$username} - {$vlan_exibicao} - {$mac} -- {$ip_cli}"
                            ];
                        }
                        if (!empty($fim)) {
                            $ts_fim = strtotime($fim);
                            $causa_txt = $causas[$causa] ?? ($causa ?: 'Desconhecido');
                            $eventos[] = [
                                'ts' => $ts_fim,
                                'line' => date('d/m/Y - H:i:s', $ts_fim) . " - ENCERRADO: {$ifname} - {$username} - {$vlan_exibicao} - {$mac} -- {$causa_txt}"
                            ];
                        }
                    }
                    
                    foreach ($recusas as $rcu) $eventos[] = $rcu;
                    usort($eventos, function($a, $b) { return $b['ts'] - $a['ts']; });
                    $linhas = [];
                    foreach ($eventos as $ev) { $linhas[] = $ev['line']; }
                    $log_resultado = implode("\n", $linhas);
                } else {
                    // FALLBACK "AO VIVO" — mesmo problema do LOG-01/LOG-02: sem accounting no
                    // radacct, o "Ver Logs" do cliente sempre dizia "Nenhum historico encontrado",
                    // mesmo cliente conectado agora. Duas fontes que não dependem do radacct:
                    //  1) status AGORA, via ws_conexao_viva() — mesma leitura do Painel;
                    //  2) histórico já acumulado nos arquivos log_live_*.log que a ação 'log'
                    //     (LOG-01/LOG-02) constrói enquanto está aberta — só filtrando por este
                    //     username, sem duplicar a leitura do concentrador aqui.
                    $status_vivo = '';
                    if (function_exists('ws_conexao_viva') && function_exists('ws_conexao_norm')) {
                        $itens_vivos = ws_conexao_viva(2, false);
                        $chave = ws_conexao_norm($username);
                        if (isset($itens_vivos[$chave])) {
                            $it = $itens_vivos[$chave];
                            $vlan = !empty($it['vlan']) ? ('vlan' . $it['vlan']) : '';
                            $status_vivo = "[" . date('d/m/Y - H:i:s') . "] CONECTADO AGORA: {$username} - {$vlan} -- "
                                . ($it['ip'] ?: '0.0.0.0') . " (concentrador " . ($it['cnc_nome'] ?: $it['cnc'])
                                . ", uptime " . ($it['uptime'] ?: '?') . ")";
                        }
                    }

                    $linhas_hist = [];
                    if (function_exists('ws_cache_dir')) {
                        foreach ((glob(ws_cache_dir() . '/log_live_*.log') ?: []) as $arq_hist) {
                            $conteudo_hist = @file_get_contents($arq_hist);
                            if (!$conteudo_hist) continue;
                            foreach (explode("\n", $conteudo_hist) as $linha_hist) {
                                if (stripos($linha_hist, $username) !== false) $linhas_hist[] = trim($linha_hist);
                            }
                        }
                    }

                    $partes = [];
                    if ($status_vivo !== '') $partes[] = $status_vivo;
                    if ($recusas) { usort($recusas, function($a, $b) { return $b['ts'] - $a['ts']; }); $partes[] = implode("
", array_column($recusas, 'line')); }
                    // Mesmo limite de 1.000 linhas do LOG-01/LOG-02 — sobrescrevendo as mais
                    // antigas primeiro (array_slice com índice negativo mantém só as ÚLTIMAS).
                    if (!empty($linhas_hist)) $partes[] = implode("\n", array_slice(array_unique($linhas_hist), -1000));

                    if (!empty($partes)) {
                        $log_resultado = implode("\n\n", $partes);
                    } else {
                        $log_resultado = "Nenhum historico encontrado para o usuario {$username} na tabela radacct, "
                            . "e ele não está conectado agora em nenhum concentrador monitorado.";
                    }
                }
                mysqli_close($link_db);
            }
            // (a falha de conexão já foi tratada e encerrou a execução logo acima)
        } else {
            $log_resultado = "Usuario invalido.";
        }
        echo json_encode(["status" => "ok", "log" => $log_resultado]);
        exit;
    }
    
    if ($acao === 'log') {
        error_reporting(0);
        ini_set('display_errors', 0);

        $ip_concentrador = $accel_ip;
        $log_resultado = "";

        $link_db = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
        if (!$link_db) {
            // DIAGNÓSTICO: antes isto caía direto no "Erro ao conectar ao banco de dados" genérico
            // (com error_reporting(0) escondendo o motivo real), obrigando a adivinhar se o problema
            // era host, usuário, senha ou banco errado. Agora mostra exatamente o que foi tentado
            // (sem a senha) e a mensagem do próprio MySQL/MariaDB.
            $log_resultado = "[" . date('d/m/Y - H:i:s') . "] Erro ao conectar ao banco de dados "
                . "(host={$db_host} usuario={$db_user} banco={$db_name}): " . mysqli_connect_error()
                . (!empty($db_tentativas) ? "\n\nTentativas (tela -> Docker -> padrão MK-Auth):\n - " . implode("\n - ", $db_tentativas) : "");
            echo json_encode(["status" => "ok", "log" => $log_resultado]);
            exit;
        }
        if ($link_db) {
            $ip_escaped = mysqli_real_escape_string($link_db, $ip_concentrador);
            $sql = "SELECT 
                        username, callingstationid, calledstationid, framedipaddress, 
                        acctstarttime, acctstoptime, acctterminatecause, acctsessionid, nasportid
                    FROM radacct 
                    WHERE nasipaddress = '$ip_escaped' 
                    ORDER BY radacctid DESC 
                    LIMIT 1000";

            $res = mysqli_query($link_db, $sql);

            if ($res && mysqli_num_rows($res) > 0) {
                $mapa_nomes = [];
                $usernames_log = [];
                $rows_buffer = [];
                while ($row = mysqli_fetch_assoc($res)) {
                    $rows_buffer[] = $row;
                    $u = trim($row['username'] ?? '');
                    if (!empty($u)) {
                        $usernames_log[$u] = true;
                    }
                }

                if (!empty($usernames_log)) {
                    $lista_users = implode(',', array_map(function($u) use ($link_db) {
                        return "'" . mysqli_real_escape_string($link_db, $u) . "'";
                    }, array_keys($usernames_log)));

                    $res_cli = mysqli_query($link_db, "SELECT login, nome, nome_res FROM sis_cliente WHERE login IN ($lista_users)");
                    if ($res_cli) {
                        while ($c = mysqli_fetch_assoc($res_cli)) {
                            $nome_exibir = !empty($c['nome_res']) ? $c['nome_res'] : '';
                            if (empty($nome_exibir) && !empty($c['nome'])) {
                                $partes_nome = explode(' ', trim($c['nome']));
                                $nome_exibir = strtolower($partes_nome[0]);
                                if (count($partes_nome) > 1) {
                                    $nome_exibir .= strtolower(end($partes_nome));
                                }
                            }
                            if (!empty($nome_exibir)) {
                                $mapa_nomes[strtolower($c['login'])] = $nome_exibir;
                            }
                        }
                    }

                    $res_adic = mysqli_query($link_db, "SELECT username, nome, nome_res FROM sis_adicional WHERE username IN ($lista_users)");
                    if ($res_adic) {
                        while ($a = mysqli_fetch_assoc($res_adic)) {
                            $nome_exibir = !empty($a['nome_res']) ? $a['nome_res'] : '';
                            if (empty($nome_exibir) && !empty($a['nome'])) {
                                $partes_nome = explode(' ', trim($a['nome']));
                                $nome_exibir = strtolower($partes_nome[0]);
                                if (count($partes_nome) > 1) {
                                    $nome_exibir .= strtolower(end($partes_nome));
                                }
                            }
                            if (!empty($nome_exibir)) {
                                $mapa_nomes[strtolower($a['username'])] = $nome_exibir;
                            }
                        }
                    }
                }

                $causas = [
                    'User-Request'        => 'Cliente encerrou',
                    'Lost-Carrier'        => 'Sem portadora',
                    'Idle-Timeout'        => 'Tempo ocioso',
                    'Session-Timeout'     => 'Tempo de sessão expirado',
                    'Admin-Reset'         => 'Reset pelo administrador',
                    'Admin-Reboot'        => 'Reboot pelo administrador',
                        // Códigos do próprio WellSystem (antes apareciam crus, ex.: "Ws-Mesmo-MAC"):
                        'Ws-Mesmo-MAC'        => 'Equipamento reconectou (nova sessão substituiu a antiga)',
                        'Ws-Derrubada'        => 'Derrubada pelo sistema (bloqueio/desbloqueio/reconexão)',
                        'Ws-Sem-Atualizacao'  => 'Sessão sem sinal do concentrador (encerrada)',
                        'NAS-Request'         => 'Encerrada pelo concentrador',
                        'NAS-Error'           => 'Erro no concentrador',
                        'User-Error'          => 'Erro de autenticação do equipamento',
                        'Port-Error'          => 'Erro na porta',
                    'Port-Error'          => 'Erro na porta',
                    'NAS-Error'           => 'Erro no concentrador',
                    ''                    => 'Desconhecido'
                ];

                $eventos = [];
                foreach ($rows_buffer as $row) {
                    $username  = $row['username'] ?? '';
                    $mac       = $row['callingstationid'] ?? '00:00:00:00:00:00';
                    $vlan_raw  = $row['calledstationid'] ?? '';
                    $ip_cli    = $row['framedipaddress'] ?? '0.0.0.0';
                    $inicio    = $row['acctstarttime'] ?? '';
                    $fim       = $row['acctstoptime'] ?? '';
                    $causa     = $row['acctterminatecause'] ?? '';
                    $ifname    = $row['nasportid'] ?? 'N/A';

                    $key_user = strtolower($username);
                    $nome_resumido = isset($mapa_nomes[$key_user]) ? $mapa_nomes[$key_user] : '';
                    $identificador = $username;
                    if (!empty($nome_resumido)) {
                        $identificador = "{$username} - {$nome_resumido}";
                    }

                    $vlan_exibicao = $vlan_raw;
                    if (!empty($vlan_raw) && stripos($vlan_raw, 'vlan') === false) {
                        $vlan_exibicao = 'vlan' . $vlan_raw;
                    }

                    $mac_formatado = strtoupper($mac);
                    if (strlen(preg_replace('/[^a-fA-F0-9]/', '', $mac_formatado)) === 12 && strpos($mac_formatado, ':') === false) {
                        $mac_formatado = implode(':', str_split(preg_replace('/[^a-fA-F0-9]/', '', $mac_formatado), 2));
                    }

                    if (!empty($inicio)) {
                        $ts = strtotime($inicio);
                        $data_fmt = date('d/m/Y - H:i:s', $ts);
                        $eventos[] = [
                            'ts'   => $ts,
                            'line' => "{$data_fmt} - CONECTADO: {$ifname} - {$identificador} - {$vlan_exibicao} - {$mac_formatado} -- {$ip_cli}"
                        ];
                    }

                    if (!empty($fim)) {
                        $ts_fim = strtotime($fim);
                        $data_fmt_fim = date('d/m/Y - H:i:s', $ts_fim);
                        $causa_texto = isset($causas[$causa]) ? $causas[$causa] : ($causa ?: 'Desconhecido');
                        $eventos[] = [
                            'ts'   => $ts_fim,
                            'line' => "{$data_fmt_fim} - ENCERRADO: {$ifname} - {$identificador} - {$vlan_exibicao} - {$mac_formatado} -- {$causa_texto}"
                        ];
                    }
                }
 
                usort($eventos, function($a, $b) {
                    return $a['ts'] - $b['ts'];
                });

                // Log mais leve: só as 1.000 linhas mais recentes (pedido do provedor, 01/10/2026).
                if (count($eventos) > 1000) $eventos = array_slice($eventos, -1000);
                $linhas_log = [];
                foreach ($eventos as $ev) {
                    $linhas_log[] = $ev['line'];
                }
                $log_resultado = implode("\n \n", $linhas_log);

            } else {
                // FALLBACK "AO VIVO" — pedido do operador: se o Painel dos Concentradores já sabe
                // ler quem está online direto do accel-ppp (ws_conexao_viva/ws_ler_sessoes, em
                // radius_lib.php), o LOG-01/LOG-02 usa a MESMA leitura em vez de depender só do
                // radacct. Entra aqui só quando a query acima já rodou e achou ZERO linhas — nunca
                // no caminho feliz (radacct com registro), que continua 100% como estava.
                //
                // Como não existe "show sessions encerradas" no accel-ppp (ele só mostra quem está
                // conectado AGORA), o histórico é construído por COMPARAÇÃO entre leituras: cada
                // chamada desta ação guarda quem estava online da vez passada (arquivo de estado em
                // cache/) e, comparando com quem está online agora, gera as linhas CONECTADO/
                // ENCERRADO — exatamente o formato que o modal já sabe colorir e filtrar. A cada
                // poll de 1s do modal isso vai preenchendo o arquivo de log deste concentrador.
                $log_resultado = null;

                if (function_exists('ws_conexao_viva') && function_exists('ws_cache_dir')) {
                    $itens_vivos = ws_conexao_viva(2, false);
                    $atual = [];
                    foreach ($itens_vivos as $k => $it) {
                        if ((string)($it['cnc'] ?? '') === (string)$ip_concentrador) $atual[$k] = $it;
                    }

                    $slug       = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $ip_concentrador);
                    $arq_estado = ws_cache_dir() . "/log_live_estado_{$slug}.json";
                    $arq_log    = ws_cache_dir() . "/log_live_{$slug}.log";

                    $anterior = [];
                    if (is_file($arq_estado)) {
                        $j = json_decode((string)@file_get_contents($arq_estado), true);
                        if (is_array($j)) $anterior = $j;
                    }

                    $agora = date('d/m/Y - H:i:s');
                    $linhas_novas = [];
                    foreach ($atual as $k => $it) {
                        if (isset($anterior[$k])) continue;
                        $vlan = !empty($it['vlan']) ? ('vlan' . $it['vlan']) : '';
                        $linhas_novas[] = "{$agora} - CONECTADO: {$it['login']} - {$vlan} -- " . ($it['ip'] ?: '0.0.0.0');
                    }
                    foreach ($anterior as $k => $it) {
                        if (isset($atual[$k])) continue;
                        $linhas_novas[] = "{$agora} - ENCERRADO: {$it['login']} -- saiu do concentrador";
                    }

                    if ($linhas_novas) @file_put_contents($arq_log, implode("\n", $linhas_novas) . "\n", FILE_APPEND | LOCK_EX);
                    @file_put_contents($arq_estado, json_encode($atual, JSON_UNESCAPED_UNICODE));

                    $linhas_arq = [];
                    if (is_file($arq_log)) {
                        $conteudo = trim((string)@file_get_contents($arq_log));
                        if ($conteudo !== '') $linhas_arq = explode("\n", $conteudo);
                    }
                    if (count($linhas_arq) > 1000) {
                        $linhas_arq = array_slice($linhas_arq, -1000);
                        @file_put_contents($arq_log, implode("\n", $linhas_arq) . "\n", LOCK_EX);
                    }

                    /* TENTATIVAS DE CONEXÃO RECUSADAS NESTE CONCENTRADOR (21/10/2026): o log ao vivo só tinha CONECTADO/ENCERRADO. Agora mistura, em ordem de hora,
                       as recusas do FreeRADIUS deste concentrador (radpostauth, class 'ws:código|MAC|concentrador', gravadas por ws_rad_recusas_coletar) como
                       RECUSADO — cliente com senha errada, login não cadastrado, ou o próprio concentrador desconhecido pelo RADIUS. Nunca mostra senha. */
                    try {
                        if (function_exists('ws_db')) {
                            $motR = ['S' => 'senha incorreta', 'N' => 'login não cadastrado (provável erro de digitação)', 'C' => 'login cadastrado, mas sem senha no RADIUS', 'O' => 'recusado pelo RADIUS', 'K' => 'concentrador desconhecido pelo RADIUS (cadastre-o e reinicie o FreeRADIUS)'];
                            $stR = ws_db()->prepare("SELECT username, authdate, class FROM radpostauth WHERE class LIKE ? ORDER BY authdate DESC LIMIT 80");
                            $stR->execute(['ws:%|%|' . $ip_concentrador]);
                            $misto = [];
                            foreach ($linhas_arq as $la) { $dt = DateTime::createFromFormat('d/m/Y - H:i:s', substr($la, 0, 20)); $misto[] = [$dt ? $dt->getTimestamp() : 0, $la]; }
                            foreach ($stR->fetchAll(PDO::FETCH_ASSOC) as $x) {
                                $pc = explode('|', substr((string)$x['class'], 3)); $tsr = strtotime((string)$x['authdate']);
                                $misto[] = [$tsr, date('d/m/Y - H:i:s', $tsr) . ' - RECUSADO: ' . $x['username'] . ' - ' . ($motR[$pc[0]] ?? $motR['O']) . (($pc[1] ?? '-') !== '-' ? ' - ' . $pc[1] : '')];
                            }
                            usort($misto, function ($a, $b) { return $a[0] <=> $b[0]; });
                            $linhas_arq = array_slice(array_map(function ($m) { return $m[1]; }, $misto), -1000);
                        }
                    } catch (Throwable $e) {}

                    if (!empty($linhas_arq)) {
                        $log_resultado = implode("\n", $linhas_arq);
                    } elseif (!empty($atual)) {
                        $nomes = array_map(function ($it) { return $it['login']; }, $atual);
                        $log_resultado = "[{$agora}] " . count($atual) . " sessão(ões) ativa(s) agora neste "
                            . "concentrador ({$ip_concentrador}) — histórico de eventos ainda começando: "
                            . implode(', ', array_slice($nomes, 0, 20)) . (count($nomes) > 20 ? '…' : '');
                    }
                }

                if ($log_resultado === null) {
                    // Nem o radacct nem a leitura ao vivo acharam nada: concentrador realmente sem
                    // ninguém conectado, ou inalcançável. Mantém o diagnóstico do radacct (host/
                    // banco tentados) pra quem for investigar mais fundo.
                    $total_geral = 0;
                    $res_tot = @mysqli_query($link_db, "SELECT COUNT(*) c FROM radacct");
                    if ($res_tot) { $rt = mysqli_fetch_assoc($res_tot); $total_geral = (int)($rt['c'] ?? 0); }

                    $nas_encontrados = [];
                    $res_nas = @mysqli_query($link_db, "SELECT nasipaddress, COUNT(*) c FROM radacct GROUP BY nasipaddress ORDER BY c DESC LIMIT 5");
                    if ($res_nas) { while ($rn = mysqli_fetch_assoc($res_nas)) { $nas_encontrados[] = ($rn['nasipaddress'] ?: '(vazio)') . ' (' . $rn['c'] . ' registros)'; } }

                    $log_resultado = "[" . date('d/m/Y - H:i:s') . "] Nenhum registro de conexão encontrado para o concentrador {$ip_concentrador} (nem no radacct, nem na leitura ao vivo do concentrador).";
                    if ($total_geral === 0) {
                        $log_resultado .= "\n\nA tabela radacct (banco={$db_name}, host={$db_host}) está totalmente vazia — "
                            . "o accounting do FreeRADIUS não está gravando neste banco. Confira o módulo sql no site "
                            . "accounting do FreeRADIUS (freeradius/default) e se ele aponta pra este mesmo host/banco.";
                    } else {
                        $log_resultado .= "\n\nA tabela radacct tem {$total_geral} registro(s) no total (banco={$db_name}, "
                            . "host={$db_host}), mas nenhum com nasipaddress = '{$ip_concentrador}'. IPs que realmente "
                            . "aparecem lá:\n - " . (!empty($nas_encontrados) ? implode("\n - ", $nas_encontrados) : '(nenhum)')
                            . "\n\nSe o IP do concentrador acima não bate com o(s) IP(s) da lista, corrija o IP cadastrado "
                            . "do NAS (tela Rede -> NAS, ou Configurações -> Concentradores) para o valor que aparece aqui.";
                    }
                }
            }
            mysqli_close($link_db);
        }
        // (o caso de falha de conexão já foi tratado e encerrado a execução logo acima)

        echo json_encode(["status" => "ok", "log" => $log_resultado]);
        exit;
    }

    $user_to_drop = trim($_POST['username'] ?? '');
    if (empty($user_to_drop)) {
        echo json_encode(["status" => "error", "message" => "Username nao informado."]);
        exit;
    }

    $socket = @fsockopen($accel_ip, $accel_port, $errno, $errstr, 3);
    if (!$socket) {
        echo json_encode(["status" => "error", "message" => "Nao foi possivel conectar ao Accel CLI."]);
        exit;
    }

    fgets($socket);
    fputs($socket, "terminate username " . $user_to_drop . " hard\r\n");
    fgets($socket);
    fputs($socket, "exit\r\n");
    fclose($socket);

    echo json_encode(["status" => "sucesso", "message" => "Comando enviado via Telnet."]);
    exit;
}

// =========================================================================
// COLETA PADRÃO (GET / LOAD GERAL)
// =========================================================================
$socket = @fsockopen($accel_ip, $accel_port, $errno, $errstr, 3);
if (!$socket) {
    echo json_encode(["status" => "error", "message" => "Falha na conexao Telnet: $errstr"]);
    exit;
}

stream_set_timeout($socket, 2);
fgets($socket); 

$comando = "show sessions ifname,username,user-alias,calling-sid,ip,rate-limit,type,state,called-sid,uptime match state active\r\n";
fputs($socket, $comando);

$linhas_sessao = [];
while (!feof($socket)) {
    $linha = fgets($socket);
    if (strpos($linha, 'accel-ppp#') !== false || trim($linha) == "") {
        if (count($linhas_sessao) > 0) break;
    }
    if (strpos($linha, 'ifname') !== false || strpos($linha, '---------') !== false) {
        continue;
    }
    if (!empty(trim($linha))) {
        $linhas_sessao[] = trim($linha);
    }
}

fputs($socket, "exit\r\n");
fclose($socket);

$sessoes_ativas = [];
$usernames_para_busca = [];

foreach ($linhas_sessao as $linha) {
    $dados = explode('|', $linha);
    if (count($dados) < 10) continue;

    $ifname       = trim($dados[0]);
    $username     = trim($dados[1]);
    $user_alias   = trim($dados[2]);
    $calling_sid  = trim($dados[3]);
    $ip           = trim($dados[4]);
    $rate_limit   = trim($dados[5]);
    $type         = trim($dados[6]);
    $state        = trim($dados[7]);
    $called_sid   = trim($dados[8]);
    $uptime       = trim($dados[9]);

    $sessoes_ativas[$username] = [
        "login"        => $username,
        "ifname"       => $ifname,
        "user_alias"   => $user_alias,
        "mac"          => $calling_sid,
        "ip"           => $ip,
        "rate"         => $rate_limit,
        "vlan"         => str_replace('vlan', '', $called_sid),
        "uptime"       => $uptime,
        "concentrador" => $accel_ip,
        "tipo"         => strtoupper($type),
        "nome_completo"=> "Cliente Desconhecido",
        "nome_reduzido"=> !empty($user_alias) ? $user_alias : $username,
        "senha"        => "******",
        "plano"        => "N/A",
        "uuid"         => ""
    ];

    $usernames_para_busca[] = "'" . $username . "'";
}

$total_pppoe = 0;
$total_ipoe = 0;

if (!empty($usernames_para_busca)) {
    $mysqli = @new mysqli($db_host, $db_user, $db_pass, $db_name);
    if (!$mysqli->connect_error) {
        $mysqli->set_charset("utf8");
        $lista_usernames = implode(',', $usernames_para_busca);

        $mapa_adicionais = [];
        $titulares_para_buscar = [];

        $res_adicional = $mysqli->query("SELECT username, login, nome, nome_res FROM sis_adicional WHERE username IN ($lista_usernames)");
        if ($res_adicional) {
            while ($row = $res_adicional->fetch_assoc()) {
                $mapa_adicionais[$row['username']] = $row;
                $titulares_para_buscar[] = "'" . $row['login'] . "'";
            }
        }

        $lista_clientes = $lista_usernames;
        if (!empty($titulares_para_buscar)) {
            $lista_clientes .= ',' . implode(',', $titulares_para_buscar);
        }

        $mapa_clientes = [];
        $res_cliente = $mysqli->query("SELECT login, nome, plano, senha, uuid_cliente FROM sis_cliente WHERE login IN ($lista_clientes)");
        if ($res_cliente) {
            while ($row = $res_cliente->fetch_assoc()) {
                $mapa_clientes[$row['login']] = $row;
            }
        }
        $mysqli->close();

        foreach ($sessoes_ativas as $usr => &$sessao) {
            if ($sessao['tipo'] === 'PPPOE') { $total_pppoe++; }
            elseif ($sessao['tipo'] === 'IPOE') { $total_ipoe++; }

            if (isset($mapa_adicionais[$usr])) {
                $adicional = $mapa_adicionais[$usr];
                $login_titular = $adicional['login'];

                if (isset($mapa_clientes[$login_titular])) {
                    $titular = $mapa_clientes[$login_titular];
                    $sessao['nome_completo'] = strtoupper($adicional['nome']);
                    $sessao['nome_reduzido'] = !empty($adicional['nome_res']) ? $adicional['nome_res'] : $adicional['login'];
                    $sessao['plano']         = $titular['plano'];
                    $sessao['senha']         = $titular['senha'];
                    $sessao['uuid']          = $titular['uuid_cliente'];
                }
            } 
            elseif (isset($mapa_clientes[$usr])) {
                $cliente = $mapa_clientes[$usr];
                $sessao['nome_completo'] = strtoupper($cliente['nome']);
                $sessao['nome_reduzido'] = !empty($sessao['user_alias']) ? $sessao['user_alias'] : $usr;
                $sessao['plano']         = $cliente['plano'];
                $sessao['senha']         = $cliente['senha'];
                $sessao['uuid']          = $cliente['uuid_cliente'];
            }
        }
    }
}

// Resposta JSON final higienizada e com as chaves corretamente fechadas
echo json_encode([
    "totais" => [
        "pppoe" => $total_pppoe,
        "ipoe" => $total_ipoe,
        "todos" => ($total_pppoe + $total_ipoe)
    ],
    "sessoes" => array_values($sessoes_ativas)
]);
exit;