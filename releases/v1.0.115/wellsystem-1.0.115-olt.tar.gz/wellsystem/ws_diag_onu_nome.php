<?php
/* Diagnóstico SÓ LEITURA (07/10/2026): nome da ONU reaproveitada. Não grava nada. php ws_diag_onu_nome.php */
if (PHP_SAPI !== 'cli') exit;
require __DIR__ . '/config.php';
function hx($s){ $s=strtoupper(preg_replace('/[^0-9A-Za-z]/','',(string)$s)); if(preg_match('/^[A-Z0-9]{4}[0-9A-F]{8}$/',$s) && preg_match('/[G-Z]/',substr($s,0,4))) return strtoupper(bin2hex(substr($s,0,4))).substr($s,4); return $s; }
$dirs = array_unique(array_filter([__DIR__.'/cache_trafego', sys_get_temp_dir().'/wellsystem_olt', '/tmp/wellsystem_olt']));
foreach ($dirs as $d) foreach (['olt_cadastro.json','olt_autorizacoes.json','olt_onus_cache.json'] as $f) if (is_file("$d/$f")) echo "arquivo: $d/$f ", date('d/m H:i', filemtime("$d/$f")), ' ', filesize("$d/$f"), "b\n";
$cad = json_decode((string)@file_get_contents(__DIR__.'/cache_trafego/olt_cadastro.json'), true) ?: [];
$aut = json_decode((string)@file_get_contents(__DIR__.'/cache_trafego/olt_autorizacoes.json'), true) ?: [];
$lis = json_decode((string)@file_get_contents(__DIR__.'/cache_trafego/olt_onus_cache.json'), true) ?: [];
// 1) mesmo aparelho em 2 formatos no cadastro
$porHex = []; foreach ($cad as $k => $v) $porHex[hx($k)][] = $k;
$dup = array_filter($porHex, fn($a) => count($a) > 1);
echo "\n[1] cadastro com o MESMO aparelho em 2 formatos: ", count($dup), "\n";
foreach (array_slice($dup, 0, 15, true) as $h => $ks) { echo "  $h: "; foreach ($ks as $k) echo "[$k] nome=", $cad[$k]['nome'] ?? '-', '  '; echo "\n"; }
// 2) autorização mais recente x nome do cadastro
$ult = []; foreach ($aut as $k => $a) { $h = hx($a['sn'] ?? $k); if (!isset($ult[$h]) || ($a['data'] ?? '') > ($ult[$h]['data'] ?? '')) $ult[$h] = $a; }
$n2 = 0; echo "\n[2] serial cujo nome no CADASTRO difere da ÚLTIMA AUTORIZAÇÃO:\n";
foreach ($ult as $h => $a) { $c = null; foreach ([$h] as $k) if (isset($cad[$k])) $c = $cad[$k]; if (!$c) foreach ($porHex[$h] ?? [] as $k) $c = $cad[$k];
  $nc = trim((string)($c['nome'] ?? '')); $na = trim((string)($a['nome'] ?? ''));
  if ($nc !== '' && $na !== '' && mb_strtoupper($nc) !== mb_strtoupper($na)) { $n2++; if ($n2 <= 25) echo "  $h | autorizado ", $a['data'] ?? '?', " como \"$na\" | cadastro mostra \"$nc\"\n"; } }
echo "  total: $n2\n";
// 3) contratos (não cancelados) com o mesmo serial
$db = ws_db(); $cts = $db->query("SELECT ct.id, ct.status, ct.sn_onu, c.nome FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id WHERE ct.sn_onu IS NOT NULL AND ct.sn_onu<>''")->fetchAll(PDO::FETCH_ASSOC);
$porSn = []; foreach ($cts as $r) $porSn[hx($r['sn_onu'])][] = $r;
echo "\n[3] serial em MAIS DE UM contrato:\n"; $n3 = 0;
foreach ($porSn as $h => $rs) if (strlen($h) >= 12 && count($rs) > 1 && count(array_filter($rs, fn($r) => $r['status'] !== 'cancelado')) >= 1) { $n3++; if ($n3 <= 25) { echo "  $h: "; foreach ($rs as $r) echo "#{$r['id']} {$r['status']} {$r['nome']} | "; echo "\n"; } }
echo "  total: $n3\n";
