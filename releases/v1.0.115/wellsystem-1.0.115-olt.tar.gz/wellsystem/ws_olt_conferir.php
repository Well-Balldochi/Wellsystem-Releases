<?php
/**
 * CONFERÊNCIA DA OLT — a lista do WellSystem bate com a OLT de verdade?
 *
 * POR QUE EXISTE: o painel mostrava 696 ONUs e a OLT tinha 697. Sem saber QUAL faltava, não dá
 * para confiar em nada que a tela mostra. Este script pergunta à OLT ao vivo e compara com o
 * cache que a tela usa, dizendo exatamente qual serial está sobrando ou faltando, e em que porta.
 *
 * CONTAGEM INDEPENDENTE, DE PROPÓSITO: os seriais são extraídos da saída CRUA da OLT por
 * expressão regular própria, SEM passar pelo parser do módulo. Se o defeito estivesse no parser,
 * reusá-lo aqui esconderia o problema — a conferência precisa ser cega ao código que ela audita.
 *
 * SÓ LÊ. Não altera cache, não altera banco, não mexe na OLT (apenas comandos "display").
 *
 * USO:
 *   php ws_olt_conferir.php              -> confere todas as placas encontradas
 *   php ws_olt_conferir.php 5            -> confere só a placa 5
 *   php ws_olt_conferir.php --detalhe    -> lista TODOS os seriais divergentes, um por linha
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("Só por linha de comando.\n"); }

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/olt_nativo.php';
require_once __DIR__ . '/olt_link.php';

$ln       = fn($s = '') => print($s . "\n");
$detalhe  = in_array('--detalhe', $argv, true);
// --bruto: imprime a linha original da OLT das ONUs cujo serial não foi reconhecido.
$mostrarBruto = in_array('--bruto', $argv, true);
$placaSo  = null;
foreach (array_slice($argv, 1) as $a) { if (ctype_digit($a)) { $placaSo = (int)$a; break; } }

$ln('=== CONFERÊNCIA DA OLT — WellSystem x OLT ao vivo ===');
$ln('modo: somente leitura (nada é alterado)');

/* ---------------------------------------------------------------- 1. Conexão com a OLT --
 * Primeiro a configuração nativa do WellSystem; se não houver, a do módulo da OLT
 * (cache_trafego/olt_conexao.json), que é a que está em uso quando o addon foi instalado. */
$db = ws_db();
$cx = ws_olt_conexao($db);
if (empty($cx['ip'])) {
    foreach (ws_olt_cache_dirs() as $d) {
        $f = $d . '/olt_conexao.json';
        if (!is_file($f)) continue;
        $j = json_decode((string)@file_get_contents($f), true);
        if (is_array($j) && !empty($j['ip'])) {
            $cx = ['ip' => $j['ip'], 'porta' => (int)($j['porta'] ?? 23),
                   'user' => (string)($j['user'] ?? ''), 'pass' => (string)($j['pass'] ?? ''), 'timeout' => 8];
            $ln('conexão: ' . $f);
            break;
        }
    }
}
if (empty($cx['ip'])) exit("\nSem configuração de conexão da OLT. Configure em OLT › Conexão.\n");
$ln('OLT: ' . $cx['ip'] . ':' . (int)$cx['porta']);

/* ------------------------------------------------------------------- 2. Cache da tela --
 * É este arquivo que alimenta os cartões e a tabela. ws_olt_ler_json() escolhe o mais recente
 * entre as pastas de cache do módulo — a mesma regra que o addon usa para gravar. */
$cache = ws_olt_ler_json('olt_onus_cache.json');
$slots = (is_array($cache) && isset($cache['slots']) && is_array($cache['slots'])) ? $cache['slots'] : [];
if (!$slots) exit("\nCache de ONUs vazio ou ilegível. Abra a OLT uma vez e rode de novo.\n");

$norm = fn($s) => strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s));

$cachePorPlaca = [];   // placa => [ SERIAL => 'fsp id' ]
foreach ($slots as $sl => $arr) {
    if (!is_array($arr)) continue;
    foreach ($arr as $o) {
        if (!is_array($o)) continue;
        $sn = $norm($o['serial'] ?? '');
        if ($sn === '') { $cachePorPlaca[(string)$sl]['(sem serial)'] = ($o['fsp'] ?? '?') . ' id ' . ($o['id'] ?? '?'); continue; }
        $cachePorPlaca[(string)$sl][$sn] = ($o['fsp'] ?? '?') . ' id ' . ($o['id'] ?? '?');
    }
}
$ln('cache: ' . array_sum(array_map('count', $cachePorPlaca)) . ' ONUs em ' . count($cachePorPlaca) . ' placa(s)');

/* ------------------------------------------------------- 3. A OLT ao vivo, placa a placa --
 * "display ont info summary 0/<placa>" traz a placa inteira num comando só.
 *
 * DUAS CONTAGENS, de propósito:
 *
 *   a) por ONT-ID  — pega "F/S/P  ONT-ID" no começo da linha. É a contagem VERDADEIRA de ONUs
 *      registradas, porque independe de o serial existir ou estar num formato conhecido.
 *   b) por SERIAL  — 16 hexadecimais, ou vendor de 4 letras + 8 hexadecimais (MONU-00E14011).
 *      Serve para dizer QUAL ONU falta; mas se alguma tiver serial fora desses formatos, ela
 *      escapa daqui E do parser do módulo — e as duas contagens "bateriam" estando erradas.
 *
 * Quando (a) e (b) divergem, o problema é o formato do serial, não a varredura. Por isso as duas
 * aparecem no relatório: uma serve de controle da outra. */
function ws_conf_seriais_da_saida(string $bruto): array {
    $out = [];
    if (preg_match_all('/\b([0-9A-Fa-f]{16}|[A-Za-z]{4}-?[0-9A-Fa-f]{8})\b/', $bruto, $m)) {
        foreach ($m[1] as $s) $out[strtoupper(str_replace('-', '', $s))] = true;
    }
    return $out;
}
/**
 * O TOTAL QUE A PRÓPRIA OLT DECLARA, por porta.
 *
 * O "display ont info summary" abre cada porta com uma linha assim:
 *     In port 0/1/0, the total of ONTs are: 18, online: 16
 *
 * Esse número é da OLT, não de parser nenhum — é a única contagem nesta conferência que não
 * depende de eu conseguir interpretar as linhas de dados. Se ele diverge do que o WellSystem
 * mostra, dá para apontar a PORTA exata onde a ONU se perde, em vez de procurar na placa inteira.
 *
 * Devolve ['0/1/0' => ['total' => 18, 'online' => 16], ...].
 */
function ws_conf_totais_declarados(string $bruto): array {
    $bruto = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $bruto);
    $out = [];
    if (preg_match_all('#In\s+port\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s*,\s*the\s+total\s+of\s+ONTs?\s+are\s*:\s*(\d+)(?:\s*,\s*online\s*:\s*(\d+))?#i',
                       $bruto, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) {
            $out[$m[1] . '/' . $m[2] . '/' . $m[3]] = ['total' => (int)$m[4], 'online' => (int)($m[5] ?? 0)];
        }
    }
    return $out;
}

/** ONUs registradas por "F/S/P + ONT-ID" — a contagem que não depende do serial. */
function ws_conf_ontids_da_saida(string $bruto): array {
    $bruto = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $bruto);              // lixo de terminal
    $bruto = preg_replace('/(\d+\s*\/\s*\d+\s*\/\s*\d+\s+\d+\s)/', "\n$1", $bruto); // desgruda linhas coladas
    $out = [];
    foreach (explode("\n", $bruto) as $l) {
        if (preg_match('#^\s*(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s+(\d+)\b#', $l, $m)) {
            $out[$m[1] . '/' . $m[2] . '/' . $m[3] . '|' . $m[4]] = true;
        }
    }
    return $out;
}

/* PLACAS: perguntadas à OLT, NÃO tiradas do cache.
 *
 * A primeira versão deste script percorria só as placas presentes no cache — se a varredura nunca
 * tivesse visitado uma placa, ela ficava invisível para os dois lados e o relatório dizia "fiel"
 * sem ter olhado. "display board 0" lista o chassi inteiro; as placas GPON são as que interessam.
 * O que vier do cache é somado, para nunca perder uma placa que a OLT deixe de listar. */
$placas = [];
try {
    $rb = ws_olt_exec($cx['ip'], (int)$cx['porta'], (string)$cx['user'], (string)$cx['pass'],
                      ['enable', 'display board 0', 'quit'], (float)($cx['timeout'] ?? 8));
    $brutoB = is_array($rb) ? implode("\n", $rb) : (string)$rb;
    foreach (explode("\n", $brutoB) as $l) {
        // "  1   H805GPBD   Normal ..." -> placa 1, se a descrição indicar GPON/EPON/PON
        if (preg_match('/^\s*(\d{1,2})\s+(\S+)/', $l, $m) && preg_match('/G?[PE]?PON|GPBD|GPFD|EPBD|XGBD/i', $m[2])) {
            $placas[$m[1]] = true;
        }
    }
    $ln('placas na OLT (display board 0): ' . ($placas ? implode(', ', array_keys($placas)) : 'nenhuma reconhecida'));
} catch (Throwable $e) {
    $ln('placas na OLT: falha ao consultar (' . $e->getMessage() . ') — seguindo com as do cache');
}
foreach (array_keys($cachePorPlaca) as $sl) $placas[(string)$sl] = true;
$placas = array_keys($placas);
sort($placas, SORT_NATURAL);
if ($placaSo !== null) $placas = array_values(array_filter($placas, fn($p) => (int)$p === $placaSo));

$totCache = 0; $totOlt = 0; $totOntId = 0; $totDecl = 0;
$faltando = []; $sobrando = []; $semSerial = []; $portasTortas = [];

$ln('');
$ln(sprintf('%-8s %10s %10s %10s %10s   %s', 'PLACA', 'DECLARADO', 'ONT-ID', 'SERIAL', 'CACHE', 'situação'));
$ln(str_repeat('-', 84));

foreach ($placas as $sl) {
    $noCache = $cachePorPlaca[$sl] ?? [];
    try {
        $r = ws_olt_exec($cx['ip'], (int)$cx['porta'], (string)$cx['user'], (string)$cx['pass'],
                         ['enable', 'display ont info summary 0/' . $sl, 'quit'], (float)($cx['timeout'] ?? 8));
    } catch (Throwable $e) {
        $ln(sprintf('%-8s %10s %10s %10s %10d   ERRO: %s', $sl, '—', '—', '—', count($noCache), $e->getMessage()));
        continue;
    }
    $bruto  = is_array($r) ? implode("\n", $r) : (string)$r;
    $naOlt  = ws_conf_seriais_da_saida($bruto);       // por serial
    $ontIds = ws_conf_ontids_da_saida($bruto);        // por ONT-ID
    $decl   = ws_conf_totais_declarados($bruto);      // o que a OLT declara por porta
    $declTot = 0; foreach ($decl as $d) $declTot += $d['total'];
    $totDecl += $declTot;

    /* Porta a porta: o total declarado pela OLT bate com o que foi lido nas linhas?
       Isto aponta a PORTA exata onde a conta não fecha, em vez da placa inteira. */
    foreach ($decl as $fspPorta => $d) {
        $lidas = 0;
        foreach ($ontIds as $chave => $_) { if (strpos($chave, $fspPorta . '|') === 0) $lidas++; }
        if ($lidas !== $d['total']) $portasTortas[$fspPorta] = ['declarado' => $d['total'], 'lidas' => $lidas];
    }

    /* --bruto: imprime as linhas de ONU em que o serial NÃO foi reconhecido. É a única forma de
       descobrir o formato real sem adivinhar — com a linha na mão dá para ajustar o parser certo. */
    if ($mostrarBruto) {
        $ln("\n   --- placa $sl: linhas com ONT-ID e sem serial reconhecido ---");
        $achou = 0;
        $b = preg_replace('/\x1b?\[[0-9;]*[A-Za-z]/', ' ', $bruto);
        $b = preg_replace('/(\d+\s*\/\s*\d+\s*\/\s*\d+\s+\d+\s)/', "\n$1", $b);
        foreach (explode("\n", $b) as $l) {
            if (!preg_match('#^\s*\d+\s*/\s*\d+\s*/\s*\d+\s+\d+\b#', $l)) continue;
            if (preg_match('/\b([0-9A-Fa-f]{16}|[A-Za-z]{4}-?[0-9A-Fa-f]{8})\b/', $l)) continue;
            $ln('   | ' . rtrim($l)); $achou++;
        }
        if (!$achou) $ln('   (nenhuma — nesta placa todo ONT-ID tem serial reconhecido)');
        $ln('');
    }

    $falta = array_diff_key($naOlt, $noCache);    // a OLT tem, a tela não mostra
    $sobra = array_diff_key($noCache, $naOlt);    // a tela mostra, a OLT não tem mais

    $totOlt += count($naOlt); $totCache += count($noCache); $totOntId += count($ontIds);
    foreach ($falta as $sn => $_) $faltando[$sn] = $sl;
    foreach ($sobra as $sn => $onde) $sobrando[$sn] = $sl . '  (' . $onde . ')';

    // ONU registrada cujo serial não foi reconhecido: some das duas contagens por serial.
    $dif = count($ontIds) - count($naOlt);
    if ($dif > 0) $semSerial[$sl] = $dif;

    $difDecl = $declTot - count($ontIds);
    $sit = (!$falta && !$sobra && $dif <= 0 && $difDecl === 0) ? 'ok' : trim(
          ($difDecl !== 0 ? abs($difDecl) . ($difDecl > 0 ? ' nao lidas ' : ' a mais que o declarado ') : '')
        . (count($falta) ? count($falta) . ' faltando na tela ' : '')
        . (count($sobra) ? count($sobra) . ' a mais na tela '   : '')
        . ($dif > 0     ? $dif . ' sem serial reconhecido'      : ''));
    $ln(sprintf('%-8s %10d %10d %10d %10d   %s', $sl, $declTot, count($ontIds), count($naOlt), count($noCache), $sit));
}

$ln(str_repeat('-', 84));
$ln(sprintf('%-8s %10d %10d %10d %10d', 'TOTAL', $totDecl, $totOntId, $totOlt, $totCache));
$ln('');
$ln('   DECLARADO = "the total of ONTs are: N" — a própria OLT dizendo quantas tem na porta.');
$ln('               É a única contagem aqui que não passa por interpretação de linha.');

if ($portasTortas) {
    $ln("\nPORTAS ONDE A CONTA NÃO FECHA (declarado x lido):");
    foreach ($portasTortas as $fspPorta => $d) {
        $ln(sprintf('   %-12s declarado=%-4d lido=%-4d  diferença=%+d', $fspPorta, $d['declarado'], $d['lidas'], $d['lidas'] - $d['declarado']));
    }
    $ln("\n   Nestas portas a OLT anuncia um número e entrega outro nas linhas de dados.");
    $ln('   Rode com --bruto na placa correspondente para ver as linhas cruas.');
}
$ln('   ONT-ID = ONUs registradas na OLT (contagem verdadeira, independe do serial)');
$ln('   SERIAL = quantas dessas tiveram o serial reconhecido');
$ln('   CACHE  = o que a tela do WellSystem mostra');

/* ---------------------------------------------------- 4. Serial não reconhecido (o buraco) --
 * Quando ONT-ID > SERIAL, existe ONU registrada cujo serial não casa com nenhum formato conhecido.
 * Ela some da contagem por serial AQUI e no parser do módulo — é o caso que faz os dois lados
 * "baterem" estando os dois errados, e o total ficar menor que o do SmartOLT. */
if ($semSerial) {
    $ln("\nONU REGISTRADA COM SERIAL NÃO RECONHECIDO — é isto que falta na conta:");
    foreach ($semSerial as $sl => $q) $ln("   placa $sl: $q ONU(s)");
    $ln("\n   Para ver a linha crua dessas ONUs na OLT (troque a placa e a porta):");
    $ln('   php ws_olt_conferir.php ' . array_key_first($semSerial) . ' --bruto');
    $ln('   Me mande essa linha: com o formato real do serial em mãos eu ajusto o parser,');
    $ln('   em vez de adivinhar mais uma vez.');
}

/* ------------------------------------------------- 5. E se o SmartOLT discordar da OLT? --
 * O SmartOLT tem banco PRÓPRIO. ONU apagada direto na OLT (por Telnet, fora do SmartOLT) continua
 * contando lá como autorizada — e o total dele passa a ser maior que a realidade. Por isso, quando
 * a conferência acima fecha (declarado = lido = cache), o número do WellSystem é o da OLT, e uma
 * diferença para o SmartOLT é dele, não daqui. Este aviso existe para não ficar caçando no lugar
 * errado, como já aconteceu. */
if (!$portasTortas && !$faltando && !$sobrando && !$semSerial) {
    $ln("\nSe o SmartOLT mostrar um total DIFERENTE deste, o desencontro é do lado dele:");
    $ln('   a OLT declarou ' . $totDecl . ', foram lidas ' . $totOntId . ' e a tela mostra ' . $totCache . '.');
    $ln('   Para achar a ONU que só existe no SmartOLT, compare as duas listas de serial:');
    $ln('   olt_huawei.php?acao=smartolt_map   (no navegador, logado no painel)');
}

/* -------------------------------------------------------------------- 6. O que divergiu -- */
if (!$faltando && !$sobrando && !$semSerial && !$portasTortas) {
    $ln("\nA tela está fiel à OLT. Nenhuma divergência.");
    exit;
}
if ($faltando) {
    $ln("\nNA OLT MAS FORA DA TELA (" . count($faltando) . ') — é o que faz o total ficar menor:');
    $n = 0;
    foreach ($faltando as $sn => $sl) {
        if (!$detalhe && $n >= 20) { $ln('   ... e mais ' . (count($faltando) - 20) . '. Use --detalhe para ver todos.'); break; }
        $ln('   ' . $sn . '   placa ' . $sl); $n++;
    }
    $ln("\n   Estes seriais aparecem na saída da OLT e não estão no cache que a tela usa —");
    $ln('   ou seja, a varredura não os gravou. Rode uma varredura forçada e confira de novo:');
    $ln('   curl -s "http://127.0.0.1/admin/addons/wellsystem/olt_huawei.php?acao=cron_scan" >/dev/null');
}
if ($sobrando) {
    $ln("\nNA TELA MAS FORA DA OLT (" . count($sobrando) . ') — cache velho ou ONU removida:');
    $n = 0;
    foreach ($sobrando as $sn => $onde) {
        if (!$detalhe && $n >= 20) { $ln('   ... e mais ' . (count($sobrando) - 20) . '. Use --detalhe para ver todos.'); break; }
        $ln('   ' . $sn . '   placa ' . $onde); $n++;
    }
}
$ln("\n=== FIM ===");
