<?php
/* Ping da trava de tela (15/10/2026). Quem chama: js/wellsystem.js (todas as telas) e a página da OLT.
   Passando pelo config.php, a trava por inatividade decide: tela já trancada ou tempo vencido = 401 {"trancada":true}
   (o JS recarrega e aparece a tela de senha). ?uso=1 = o operador mexeu na tela (OLT, que não recarrega): renova o relógio. */
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
if (!empty($_GET['uso']) && !empty($_SESSION['ws_user']) && empty($_SESSION['ws_trancada'])) $_SESSION['ws_ativ_em'] = time();
echo json_encode(['ok' => true]);
