<?php
/**
 * WellSystem ERP — Cadastro de Zonas / áreas de atendimento.
 * Usadas no contrato (campo zona) e no espelho SmartOLT. Auto-cria a tabela.
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$db = ws_db();
$db->exec("CREATE TABLE IF NOT EXISTS ws_zona (
    id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(80) NOT NULL, descricao VARCHAR(160) DEFAULT NULL,
    cor VARCHAR(9) DEFAULT NULL, ativo TINYINT(1) NOT NULL DEFAULT 1, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_nome (nome)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$user = $_SESSION['ws_user']['nome'] ?? '';

if (($_POST['acao'] ?? '') === 'salvar') {
    $id = (int)($_POST['id'] ?? 0);
    $v = [strtoupper(trim($_POST['nome'] ?? '')), trim($_POST['descricao'] ?? '') ?: null, $_POST['cor'] ?: null, isset($_POST['ativo']) ? 1 : 0];
    if ($v[0] !== '') {
        $dup = ws_dup_nome($db, 'ws_zona', $v[0], $id);
        if ($dup !== '') {
            $_SESSION['ws_flash'] = "Já existe a zona \"$dup\". O sistema não aceita zona duplicada (mesmo com grafia/acento diferente) — use a existente ou edite-a.";
            header('Location: zonas.php'); exit;
        }
        try {
            if ($id) { $v[] = $id; $db->prepare("UPDATE ws_zona SET nome=?,descricao=?,cor=?,ativo=? WHERE id=?")->execute($v); }
            else $db->prepare("INSERT INTO ws_zona (nome,descricao,cor,ativo) VALUES (?,?,?,?)")->execute($v);
        } catch (Throwable $e) { $_SESSION['ws_flash'] = 'Zona já existe com esse nome.'; }
    }
    header('Location: zonas.php'); exit;
}
if (isset($_GET['del'])) { if (!ws_pode_deletar()) { header('Location: zonas.php'); exit; } $db->prepare("DELETE FROM ws_zona WHERE id=?")->execute([(int)$_GET['del']]); header('Location: zonas.php'); exit; }
// Exclusão em MASSA (checkbox único/todos).
if (($_POST['acao'] ?? '') === 'excluir_massa') {
    if (!ws_pode_deletar()) { header('Location: zonas.php'); exit; }
    ws_excluir_massa($db, 'ws_zona', (array)($_POST['ids'] ?? []));
    header('Location: zonas.php'); exit;
}

/* SINCRONISMO COM A OLT — "sincronizar agora" e o retrato da última execução.
 *
 * Quem cria zona de verdade é a OLT: o técnico escolhe a zona ao liberar a ONU. O zonas_sync.php
 * roda de 10 em 10 minutos pelo cron e traz as que faltam. Mostrar aqui QUANDO ele rodou não é
 * enfeite: sem isso, "a zona nova não apareceu" fica indistinguível de "o cron nunca rodou", e o
 * operador vai procurar defeito no lugar errado. O botão existe para quem não quer esperar os
 * 10 minutos depois de liberar uma ONU. */
if (isset($_GET['sincronizar']) && ws_user()['nivel'] === 'admin') {
    // O sincronizador é CLI (é tarefa de cron e mexe em cadastro). Aqui ele é carregado num
    // processo separado justamente para manter essa regra de pé, em vez de abrir uma exceção.
    $php = PHP_BINARY ?: 'php';
    @exec(escapeshellarg($php) . ' ' . escapeshellarg(__DIR__ . '/zonas_sync.php') . ' 2>&1', $saida, $rc);
    $j = @json_decode((string)@file_get_contents(WS_CACHE . '/zonas_sync.json'), true);
    $_SESSION['ws_flash'] = is_array($j)
        ? ('Sincronismo com a OLT: ' . (int)($j['zonas_novas'] ?? 0) . ' zona(s) nova(s), '
           . (int)($j['contratos'] ?? 0) . ' contrato(s) com zona preenchida.'
           . (!empty($j['erro']) ? ' — ' . $j['erro'] : ''))
        : 'Não consegui executar o sincronismo agora. Ele continua rodando sozinho pelo cron, de 10 em 10 minutos.';
    header('Location: zonas.php'); exit;
}
$sync = @json_decode((string)@file_get_contents(WS_CACHE . '/zonas_sync.json'), true);
if (!is_array($sync)) $sync = null;

$rows = $db->query("SELECT z.*, (SELECT COUNT(*) FROM ws_contrato ct WHERE ct.zona=z.nome AND ct.status<>'cancelado') clientes FROM ws_zona z ORDER BY z.nome")->fetchAll();
$ppZ = isset($_GET['pp']) ? (int)$_GET['pp'] : 25; if (!in_array($ppZ, [25, 50, 100, 0], true)) $ppZ = 25; $totZ = count($rows); $pgZ = max(1, (int)($_GET['pg'] ?? 1)); if ($ppZ > 0 && ($pgZ - 1) * $ppZ >= $totZ) $pgZ = max(1, (int)ceil($totZ / $ppZ)); $rowsPagZ = $ppZ > 0 ? array_slice($rows, ($pgZ - 1) * $ppZ, $ppZ) : $rows; $pagExtraZ = [];
$edit = null; if (isset($_GET['edit'])) { $st = $db->prepare("SELECT * FROM ws_zona WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch(); }
$flash = ''; if (!empty($_SESSION['ws_flash'])) { $flash = $_SESSION['ws_flash']; unset($_SESSION['ws_flash']); }
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Zonas</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('cadastros') ?></header>
<main class="ws-main">
<?php if ($flash): ?><div class="ws-alert"><?= $h($flash) ?></div><?php endif; ?>
<div class="ws-head-row"><h2>🗺️ Zonas / áreas de atendimento</h2>
  <?php if (ws_user()['nivel'] === 'admin'): ?>
  <a class="ws-btn" href="zonas.php?sincronizar=1" title="Lê as zonas conhecidas pela OLT e cria aqui as que faltarem, sem apagar nem renomear nada">🔄 Sincronizar com a OLT</a>
  <?php endif; ?>
</div>
<div class="ws-two">
  <div>
    <?= ws_paginacao_topo($totZ, $ppZ, $pgZ, $pagExtraZ, [25, 50, 100, 0]) ?>
    <form method="post" onsubmit="return wsDelMassa(this,'Excluir as zonas marcadas?')">
    <input type="hidden" name="acao" value="excluir_massa">
    <table class="ws-table"><thead><tr><th style="width:26px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todas"></th><th>Zona</th><th>Descrição</th><th>Clientes</th><th>Ativo</th><th>Ações</th></tr></thead><tbody>
    <?php foreach ($rowsPagZ as $r): ?>
      <tr><td><input type="checkbox" class="ws-chk-item" name="ids[]" value="<?= $r['id'] ?>"></td><td><span style="display:inline-block;width:12px;height:12px;border-radius:3px;background:<?= $h($r['cor'] ?: '#9E2A3B') ?>;margin-right:6px;vertical-align:middle"></span><b><?= $h($r['nome']) ?></b></td>
      <td><?= $h($r['descricao']) ?></td><td><?= (int)$r['clientes'] ?></td>
      <td><?= $r['ativo'] ? '<span class="ws-tag ativo">sim</span>' : '<span class="ws-tag inativo">não</span>' ?></td>
      <td><div class="ws-acoes"><a href="zonas.php?edit=<?= $r['id'] ?>">editar</a>
        <a href="zonas.php?del=<?= $r['id'] ?>" onclick="return confirm('Excluir esta zona?')" style="color:var(--err)">excluir</a></div></td></tr>
    <?php endforeach; if (!$rows) echo '<tr><td colspan="6" class="ws-muted">Nenhuma zona cadastrada.</td></tr>'; ?>
    </tbody></table>
    <?php if ($rows): ?><div style="margin-top:8px"><button class="ws-btn danger" style="padding:7px 12px;font-size:13px">🗑 Excluir selecionadas</button></div><?php endif; ?>
    </form>
    <?= ws_paginacao_html($totZ, $ppZ, $pgZ, $pagExtraZ + ['pp' => $ppZ]) ?>
  </div>
  <div class="ws-card">
    <h3><?= $edit ? 'Editar zona' : 'Nova zona' ?></h3>
    <form method="post" class="ws-form">
      <input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <label>Nome <input name="nome" required value="<?= $h($edit['nome'] ?? '') ?>" placeholder="Ex.: CENTRO, ZONA RURAL"></label>
      <label>Descrição <input name="descricao" value="<?= $h($edit['descricao'] ?? '') ?>"></label>
      <?php /* "?:" sozinho ainda LÊ a chave: com $edit null (cadastro novo, que é o caso comum ao
               abrir a tela), isso gerava aviso a cada carregamento. O "??" resolve porque não
               avalia o que não existe — e o "?:" continua para tratar a cor gravada como vazia.
               PARA ZONA NOVA (sem $edit) a cor não fica mais fixa em #9E2A3B pra todo mundo: gira
               pela mesma paleta de 12 cores usada na sincronização com a OLT, pela posição desta
               zona na lista — assim toda zona criada aqui já nasce com uma cor diferente da anterior,
               e ainda dá pra trocar à mão antes de salvar. */
           $paletaZonaCor = ['#9E2A3B','#2A6F9E','#2A9E6F','#9E7A2A','#6F2A9E','#2A9E9E',
                             '#9E2A7A','#5A9E2A','#9E5A2A','#2A5A9E','#7A2A9E','#2A9E5A'];
           $corSugerida = $edit ? '' : $paletaZonaCor[count($rows) % count($paletaZonaCor)];
      ?>
      <label>Cor <input type="color" name="cor" value="<?= $h(($edit['cor'] ?? '') ?: ($corSugerida ?: '#9E2A3B')) ?>"></label>
      <label><input type="checkbox" name="ativo" <?= (!$edit || ($edit['ativo'] ?? 1)) ? 'checked' : '' ?>> Ativa</label>
      <button class="ws-btn verde">Salvar zona</button>
      <?php if ($edit): ?><a class="ws-btn" href="zonas.php">Cancelar</a><?php endif; ?>
    </form>
  </div>
</div>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
