<?php
/**
 * WellSystem — sincroniza as ZONAS da OLT com a página Zonas. Roda pelo cron.
 *
 *     php zonas_sync.php            (uso normal — silencioso)
 *     php zonas_sync.php -v         (mostra o que fez, para conferir na mão)
 *
 * O PROBLEMA QUE ELE RESOLVE
 * A zona (o POP / a caixa / o ponto de concentração) nasce na OLT: é lá que o técnico escolhe a
 * zona ao liberar a ONU. No WellSystem ela vira um cadastro em ws_zona, usado para filtrar
 * clientes, montar relatório e enxergar quem cai junto quando uma zona tem problema.
 *
 * Até aqui esses dois lados só se encontravam na MIGRAÇÃO. Zona criada na OLT depois disso
 * simplesmente não existia na página Zonas, e o cliente ligado a ela aparecia sem zona — sem erro
 * nenhum na tela, o que é o pior tipo de defeito: silencioso e cumulativo.
 *
 * O QUE ELE FAZ
 *   1. Lê as ONUs conhecidas da OLT (autorizações do addon + do motor nativo + retrato das ONUs).
 *   2. Toda zona que aparecer lá e não existir em ws_zona é CRIADA.
 *   3. Todo contrato SEM zona cujo serial a OLT conhece recebe a zona da OLT.
 *
 * O QUE ELE NÃO FAZ — e é de propósito
 *   Não apaga zona nenhuma. Uma zona pode existir só no cadastro (ainda em obra, ou rádio, ou uma
 *   zona que a OLT deixou de reportar por estar fora do ar). Apagar o cadastro por causa de uma
 *   leitura incompleta levaria junto a zona de todos os clientes ligados a ela.
 *   Não renomeia zona existente, e não sobrescreve a zona já preenchida num contrato: quem digitou
 *   à mão tinha um motivo. A OLT só COMPLETA o que está vazio.
 *   Não fala com a OLT por Telnet. Trabalha sobre o cache que o módulo da OLT já mantém — assim
 *   rodar a cada poucos minutos não consome as poucas linhas VTY da OLT nem trava o painel.
 *
 * Deixa o resultado em cache/zonas_sync.json para a página Zonas mostrar quando foi a última vez.
 */

// CLI apenas: é tarefa de cron e mexe em cadastro. Pela web não roda.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

require __DIR__ . '/config.php'; require_once __DIR__ . '/espelho_lib.php'; ws_espelho_so_principal();   // ESPELHO (05/11/2026): rotina autom�tica - s� o servidor PRINCIPAL roda (a r�plica e a quarentena saem calados)
require __DIR__ . '/olt_link.php';
require_once __DIR__ . '/zonas_unificar_lib.php';

$verbose = in_array('-v', $argv ?? [], true);
$falar = static function (string $m) use ($verbose) { if ($verbose) echo $m . PHP_EOL; };

$res = ['em' => date('Y-m-d H:i:s'), 'zonas_novas' => 0, 'contratos' => 0, 'zonas_vistas' => 0, 'erro' => ''];

try {
    $db = ws_db();

    /* ---- 1) o que a OLT conhece -------------------------------------------------------------
     * Duas fontes, somadas: as AUTORIZAÇÕES (a zona que o técnico escolheu ao liberar a ONU — é a
     * intenção registrada) e o RETRATO das ONUs (o que a OLT respondeu na última leitura). A
     * autorização vale mais, por isso entra por último e sobrescreve. */
    $porSerial = [];      // SERIAL normalizado => zona
    $zonas     = [];      // nome da zona => true

    $norm = static fn(string $s): string => strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $s));

    $onus = ws_olt_ler_json('olt_onus_cache.json');
    if (is_array($onus)) {
        $lista = (isset($onus['onus']) && is_array($onus['onus'])) ? $onus['onus'] : $onus;
        foreach ($lista as $k => $o) {
            if (!is_array($o)) continue;
            $z = trim((string)($o['zona'] ?? ''));
            $sn = $norm((string)($o['sn'] ?? (is_string($k) ? $k : '')));
            if ($z !== '') { $zonas[$z] = true; if ($sn !== '') $porSerial[$sn] = $z; }
        }
    }
    foreach (ws_olt_autorizacoes() as $a) {
        $z = trim((string)($a['zona'] ?? ''));
        $sn = $norm((string)($a['sn'] ?? ''));
        if ($z !== '') { $zonas[$z] = true; if ($sn !== '') $porSerial[$sn] = $z; }
    }

    $res['zonas_vistas'] = count($zonas);
    $falar('OLT conhece ' . count($zonas) . ' zona(s) e ' . count($porSerial) . ' serial(is).');

    if (!$zonas) {
        // Sem leitura da OLT não há o que sincronizar — e isso NÃO é erro: pode ser um provedor
        // sem OLT, ou o cache ainda não gerado. Sai em silêncio, sem tocar em nada.
        $res['erro'] = 'Nenhuma zona encontrada no cache da OLT (o módulo da OLT ainda não leu, ou não há OLT).';
        $falar($res['erro']);
    } else {
        /* ---- 2) cria as zonas que faltam ---------------------------------------------------
         * A comparação é por nome sem diferenciar maiúscula/minúscula e sem espaço sobrando:
         * "POP CENTRO", "Pop Centro" e "pop centro " são a mesma zona. Sem isso o cadastro
         * encheria de duplicatas a cada leitura. */
        $jaTem = [];
        foreach ($db->query("SELECT nome FROM ws_zona")->fetchAll(PDO::FETCH_COLUMN) as $n) {
            $jaTem[ws_zb_chave((string)$n)] = true;   // (16/10/2026) mesma chave da unificação: "TAMATAUPE  1" = "TAMATAUPE 1" (antes só trim/minúscula e criava repetida)
        }
        /* Cor automática: sem isso toda zona criada pela OLT nascia com cor NULA, e a tela de Zonas
         * cai no MESMO cinza/vermelho padrão pra todas — impossível diferenciar zona por cor no mapa
         * e nas listas. Paleta fixa, ciclada pela quantidade de zonas já cadastradas (não pelo nome:
         * assim zonas criadas na mesma leitura já saem com cores diferentes entre si). */
        $paletaCores = ['#9E2A3B','#2A6F9E','#2A9E6F','#9E7A2A','#6F2A9E','#2A9E9E',
                        '#9E2A7A','#5A9E2A','#9E5A2A','#2A5A9E','#7A2A9E','#2A9E5A'];
        $corIdx = count($jaTem);
        $insZ = $db->prepare("INSERT INTO ws_zona (nome, descricao, cor, ativo) VALUES (?, ?, ?, 1)");
        foreach (array_keys($zonas) as $z) {
            $chave = ws_zb_chave(ws_zona_alias($z));
            if ($chave === '' || isset($jaTem[$chave])) continue;
            try {
                $cor = $paletaCores[$corIdx % count($paletaCores)];
                $insZ->execute([mb_substr(ws_zb_limpo(ws_zona_alias($z)), 0, 80), 'Criada automaticamente pela OLT', $cor]);
                $jaTem[$chave] = true;
                $corIdx++;
                $res['zonas_novas']++;
                $falar('  + zona criada: ' . $z . ' (cor ' . $cor . ')');
            } catch (Throwable $e) { /* corrida com outro processo: a zona passou a existir, tudo bem */ }
        }

        /* ---- 3) completa a zona dos contratos ----------------------------------------------
         * Só onde está VAZIA. O casamento é pelo serial da ONU, que é o único identificador que
         * os dois lados têm em comum e que não muda de nome. */
        if ($porSerial) {
            $upd = $db->prepare("UPDATE ws_contrato SET zona=? WHERE id=? AND (zona IS NULL OR zona='')");
            $q = $db->query("SELECT id, sn_onu FROM ws_contrato WHERE sn_onu IS NOT NULL AND sn_onu<>'' AND (zona IS NULL OR zona='')");
            foreach ($q as $ct) {
                $sn = $norm((string)$ct['sn_onu']);
                if ($sn === '' || !isset($porSerial[$sn])) continue;
                $upd->execute([mb_substr(ws_zona_alias($porSerial[$sn]), 0, 80), (int)$ct['id']]);
                if ($upd->rowCount() > 0) { $res['contratos']++; $falar('  ~ contrato ' . $ct['id'] . ' -> zona ' . $porSerial[$sn]); }
            }
        }
    }
    /* (16/10/2026) depois de ler a OLT: junta repetidas, acerta o texto dos contratos e dos clientes (idempotente; guarda o antes em cache/unificar_zonas_*.json). */
    try { $ru = ws_rural_bairro_da_zona($db, true); if ($ru) $res['rural_bairro'] = $ru; } catch (Throwable $e) {}   // ZONA RURAL -> bairro da localidade (16/10/2026)
    try { $u = ws_zonas_bairros_unificar($db, true); $res['unificado'] = ['zonas' => count($u['zonas_juntadas']), 'cidades' => count($u['cidades_juntadas']), 'bairros' => count($u['bairros_juntados']), 'contratos' => $u['contratos_acertados']]; if ($u['backup'] === '' || ($u['contratos_acertados'] + count($u['zonas_juntadas']) + count($u['cidades_juntadas']) + count($u['bairros_juntados']) + $u['clientes_bairro_acertados'] + count($u['zonas_criadas'])) === 0) { if ($u['backup'] !== '') @unlink((defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/' . $u['backup']); } } catch (Throwable $e) { $falar('unificar: ' . $e->getMessage()); }
} catch (Throwable $e) {
    $res['erro'] = $e->getMessage();
    $falar('ERRO: ' . $e->getMessage());
}

// Marca da última execução — a página Zonas lê isto para dizer quando sincronizou pela última vez.
// Sem essa marca, "a zona não apareceu" seria indistinguível de "o cron nunca rodou".
@file_put_contents(WS_CACHE . '/zonas_sync.json', json_encode($res, JSON_UNESCAPED_UNICODE));
@chmod(WS_CACHE . '/zonas_sync.json', 0640);

$falar('pronto: ' . $res['zonas_novas'] . ' zona(s) nova(s), ' . $res['contratos'] . ' contrato(s) atualizado(s).');
