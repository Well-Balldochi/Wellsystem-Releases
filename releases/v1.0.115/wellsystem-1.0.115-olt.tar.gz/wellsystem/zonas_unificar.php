<?php
/**
 * WellSystem — unifica zonas, bairros e cidades repetidos (CLI). Detalhes na zonas_unificar_lib.php.
 *     php zonas_unificar.php            só MOSTRA o que faria (nada é gravado)
 *     php zonas_unificar.php --aplicar  faz (guarda o antes em cache/unificar_zonas_*.json)
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php';
require __DIR__ . '/zonas_unificar_lib.php';
$aplicar = in_array('--aplicar', $argv ?? [], true);
$r = ws_zonas_bairros_unificar(ws_db(), $aplicar);
echo ($aplicar ? "APLICADO" : "SIMULAÇÃO (nada gravado)") . "\n";
foreach (['cidades_juntadas' => 'Cidades juntadas', 'zonas_juntadas' => 'Zonas juntadas', 'zonas_criadas' => 'Zonas criadas a partir dos contratos', 'zonas_prefixo' => 'Zonas truncadas completadas', 'zonas_ambiguas' => 'Zonas ambíguas (não mexi)', 'zonas_ignoradas' => 'Zonas ignoradas', 'vlan_zona' => 'Contratos acertados pela regra de VLAN', 'bairros_juntados' => 'Bairros juntados', 'bairros_criados' => 'Bairros criados no cadastro', 'bairros_sem_cadastro' => 'Bairros de cliente sem cadastro'] as $k => $t) {
    echo "\n== $t: " . count($r[$k]) . "\n"; foreach ($r[$k] as $l) echo "   - $l\n";
}
echo "\nContratos com texto de zona acertado: {$r['contratos_acertados']}\nClientes com texto de bairro acertado: {$r['clientes_bairro_acertados']} (pela regra de VLAN: {$r['vlan_bairro']})\nContratos ativos sem zona: {$r['sem_zona']}\n" . ($r['backup'] ? "Backup do antes: cache/{$r['backup']}\n" : '');
