<?php
// =============================================================================
// WELLSYSTEM — GERENCIADOR OLT HUAWEI  (página AUTÔNOMA)
// -----------------------------------------------------------------------------
// Funciona 100% SOZINHA. Requisitos mínimos na pasta:
//     olt.php  +  olt_huawei.php  +  olt_ui.js
//
// NÃO precisa do Radius (index.php), nem de banco de dados, nem de MK-Auth.
// Basta abrir esta página e informar em "Conexão da OLT":
//     IP/host · porta (23) · usuário · senha (root)
// A conexão passa a valer imediatamente ao salvar — sem editar código.
//
// Se o index.php (Radius Wellsystem) estiver na MESMA pasta, esta página passa
// a enriquecer a lista com o nome/uuid/IP do assinante automaticamente.
// =============================================================================

// Erros VISÍVEIS: se algo falhar, aparece a mensagem na tela em vez de página em
// branco. Depois de validar a instalação, troque o 1 por 0 se preferir.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: text/html; charset=utf-8');

// O Radius é OPCIONAL: só é usado se o index.php existir na pasta E for um arquivo
// DIFERENTE deste. Essa segunda checagem permite renomear este arquivo para
// index.php (para abrir como página padrão) sem ele "se detectar" como Radius.
$WS_RADIUS = is_file(__DIR__ . '/index.php')
          && (@realpath(__DIR__ . '/index.php') !== @realpath(__FILE__));

// Pasta de dados (mesma lógica do backend, para achar a logo desta página).
function oltp_cache_dir() {
    static $dir = null; if ($dir !== null) return $dir;
    $cands = [__DIR__ . '/cache_trafego', sys_get_temp_dir() . '/acellApp_cache_trafego'];
    foreach ($cands as $d) {
        if (!is_dir($d)) @mkdir($d, 0777, true);
        @chmod($d, 0777);
        $t = $d . '/.__w' . getmypid() . mt_rand();
        if (@file_put_contents($t, 'ok') !== false) { @unlink($t); $dir = $d; return $dir; }
    }
    $dir = $cands[0]; return $dir;
}
/* ============================================================================================
 * RODAPÉ PADRÃO DO CÓDIGO RAIZ NESTA PÁGINA.
 *
 * Esta página é autônoma: não carrega config.php nem css/wellsystem.css, justamente porque o
 * CSS do painel reescreveria a tela do gerenciador. Mas o rodapé é do sistema e tem que ser
 * IGUAL ao das outras telas, sem virar uma segunda versão que sai de sincronia. Por isso:
 *   • o HTML vem do próprio ws_footer_bar() (config.php), a mesma função de todas as páginas;
 *   • o CSS é LIDO de css/wellsystem.css e só as regras .ws-rodape* são aproveitadas.
 * Nada é copiado à mão: alterou o rodapé no código raiz, esta página acompanha sozinha.
 * ========================================================================================= */

/** Pasta do WellSystem — a OLT roda na raiz do addon E em olt/. Devolve null se não estiver junto. */
function oltp_raiz_ws() {
    static $r = false; if ($r !== false) return $r;
    foreach ([__DIR__, dirname(__DIR__)] as $d) {
        if (is_file($d . '/config.php') && is_file($d . '/erp.php')) { $r = $d; return $r; }
    }
    $r = null; return $r;
}

/** Só as regras .ws-rodape* do CSS do sistema, lidas do arquivo original.
 *  Os @media são removidos antes: sem o envelope, a regra de dentro valeria SEMPRE
 *  (o "esconder no celular" viraria "esconder sempre"). */
function oltp_css_rodape() {
    $raiz = oltp_raiz_ws(); if (!$raiz) return '';
    $f = $raiz . '/css/wellsystem.css'; if (!is_file($f)) return '';
    $css = (string)@file_get_contents($f);
    $css = preg_replace('/@media[^{]*\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}/s', '', $css);
    $out = '';
    if (preg_match_all('/([^{}]*\.ws-rodape[^{}]*)\{([^{}]*)\}/', $css, $m, PREG_SET_ORDER)) {
        foreach ($m as $r) {
            $sel = trim(preg_replace('/^.*[};]\s*/s', '', $r[1]));
            if ($sel === '') continue;
            $out .= $sel . '{' . trim($r[2]) . '}';
        }
    }
    return $out;
}

// Um módulo, um cache: antes de ler conexão/usuários, traz o que estava em olt/cache_trafego.
if (is_file(__DIR__ . '/olt_unificar.php')) { require_once __DIR__ . '/olt_unificar.php'; olt_unificar_cache(__DIR__); }

$__logo_olt = '';
$__lf = oltp_cache_dir() . '/wellsystem_logo_olt.txt';
if (is_file($__lf)) $__logo_olt = trim((string)@file_get_contents($__lf));

// LINK DA LOGO DO TOPO = site do PROVEDOR, o mesmo do ERP (Configurações > Geral > Marca, cache/branding.json).
// Lido direto do arquivo: aqui o config.php ainda não foi carregado. Vazio ou inválido = logo sem link.
$__logo_url = '';
foreach ([__DIR__ . '/cache/branding.json', '/var/tmp/wellsystem_cache_' . substr(md5(__DIR__), 0, 10) . '/branding.json'] as $__bj) {
    if (!is_file($__bj)) continue;
    $__bc = json_decode((string)@file_get_contents($__bj), true);
    $__u = trim((string)($__bc['logo_url'] ?? ''));
    if ($__u !== '' && preg_match('#^https?://#i', $__u) && filter_var($__u, FILTER_VALIDATE_URL)) $__logo_url = $__u;
    break;
}

// Backend obrigatório — sem ele a página não tem o que gerenciar.
$__backend_ok = is_file(__DIR__ . '/olt_huawei.php');
$__ui_ok      = is_file(__DIR__ . '/olt_ui.js');

// A conexão da OLT já foi configurada? Se NÃO, a página abre direto na janela de
// conexão, para o operador informar IP/porta/usuário/senha e conectar na hora.
$__conexao_ok = false; $__senha_olt_ok = false;
// VÁRIAS OLTs (20/11/2026): qual OLT está em uso (?olt= ou cookie WSOLT, validado na lista olt_lista.json). Vale para a checagem
// "conexão configurada" e para o AJAX (o olt_huawei.php lê o mesmo cookie). Sem OLT cadastrada ou id inválido = a principal, como sempre.
$__olt_sub = '';
$__lj = json_decode((string)@file_get_contents(oltp_cache_dir() . '/olt_lista.json'), true);
$__oid = preg_replace('/[^a-z0-9]/', '', strtolower((string)($_GET['olt'] ?? $_COOKIE['WSOLT'] ?? '')));
if ($__oid !== '' && is_array($__lj) && isset($__lj['olts'][$__oid])) {
    $__olt_sub = '/olt_' . $__oid;
    if (isset($_GET['olt'])) @setcookie('WSOLT', $__oid, time() + 31536000, '/');
} elseif (isset($_GET['olt']) || isset($_COOKIE['WSOLT'])) {
    @setcookie('WSOLT', '', time() - 3600, '/');   // OLT que não existe mais: volta para a principal
}
$__cf = oltp_cache_dir() . $__olt_sub . '/olt_conexao.json';
if (is_file($__cf)) {
    $__j = json_decode((string)@file_get_contents($__cf), true);
    $__conexao_ok   = (is_array($__j) && !empty($__j['ip']));
    // O 1º acesso compara com esta senha — sem ela o login não tem como validar.
    $__senha_olt_ok = (is_array($__j) && isset($__j['pass']) && $__j['pass'] !== '');
}
// Pasta de dados gravável? Sem isso a conexão não persiste.
$__grav = false; $__t = oltp_cache_dir() . '/.__wtest';
if (@file_put_contents($__t, 'ok') !== false) { $__grav = true; @unlink($__t); }

// AUTO-CONECTAR: quem ja esta logado no WellSystem entra DIRETO na OLT (padrao LIGADO). Desmarcado,
// a OLT volta a pedir login proprio (usuario root + senha do Telnet) mesmo com o painel aberto.
// A opcao aparece como caixa de marcar no card Aprovisionamento; o toggle chega por
// ?autoconnect=0|1, grava a preferencia no servidor (vale para todos os operadores) e recarrega.
$__acf = oltp_cache_dir() . '/olt_autoconnect.json';
if (isset($_GET['autoconnect'])) {
    @file_put_contents($__acf, json_encode(['auto' => ($_GET['autoconnect'] === '1')])); @chmod($__acf, 0666);
    // Preserva ?saiu=1 (desconectar e logar de novo) e ?aprov — grava e segue o fluxo que o usuario pediu.
    $__dest = 'olt.php' . (isset($_GET['saiu']) ? '?saiu=1' : (isset($_GET['aprov']) ? '?aprov=1' : ''));
    header('Location: ' . $__dest, true, 302); exit;
}
$__autoconn = true;
if (is_file($__acf)) {
    $__aj = json_decode((string)@file_get_contents($__acf), true);
    if (is_array($__aj) && array_key_exists('auto', $__aj)) $__autoconn = (bool)$__aj['auto'];
}

// Sessao do WellSystem (a do painel). Lida e FECHADA antes de abrir a sessao propria da OLT —
// sao dois cookies de sessao diferentes e nao podem ficar abertos ao mesmo tempo.
$__root_op = null;
if (session_status() === PHP_SESSION_NONE) {
    @session_start(); $__root_op = $_SESSION['ws_user'] ?? null;
    /* TRAVA POR INATIVIDADE TAMBÉM NA OLT (15/10/2026): a OLT tem sessão própria e nunca trancava. Operador do painel com a tela trancada ou parado além
       do tempo (Provedor → Recursos, trava_minutos) vai para a tela de senha do painel e volta aqui depois de destravar; abrir a OLT conta como uso. */
    if (!empty($__root_op)) {
        $__rj = json_decode((string)@file_get_contents(__DIR__ . '/cache/recursos.json'), true); $__tm = isset($__rj['trava_minutos']) ? max(0, (int)$__rj['trava_minutos']) : 120;
        $__ua = (int)($_SESSION['ws_ativ_em'] ?? 0);
        if (!empty($_SESSION['ws_trancada']) || ($__tm > 0 && $__ua > 0 && (time() - $__ua) > $__tm * 60)) {
            $_SESSION['ws_trancada'] = 1; $_SESSION['ws_ultima_tela'] = 'olt.php'; @session_write_close();
            if (empty($_GET['ajax'])) { header('Location: erp.php'); exit; }
        } else { $_SESSION['ws_ativ_em'] = time(); @session_write_close(); }
    } else { @session_write_close(); }
}

// --- Autenticação: há usuários? há sessão aberta? ---------------------------
$__auth_ativo = is_file(__DIR__ . '/olt_auth.php');
$__primeiro   = true; $__sessao = null;
if ($__auth_ativo) {
    $__uf = oltp_cache_dir() . '/olt_usuarios.json';
    $__us = is_file($__uf) ? json_decode((string)@file_get_contents($__uf), true) : [];
    $__primeiro = !(is_array($__us) && count($__us) > 0);
    if (session_status() === PHP_SESSION_NONE) { session_name('WSOLTSESS'); @session_start(); }
    // Rede de segurança do SAIR: o navegador redireciona sem esperar o servidor,
    // então garantimos aqui que a sessão termine mesmo se aquela chamada se perder.
    if (isset($_GET['saiu'])) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            @setcookie(session_name(), '', time() - 42000,
                $p['path'] ?? '/', $p['domain'] ?? '', $p['secure'] ?? false, $p['httponly'] ?? true);
        }
        @session_destroy();
        // LIMPA A URL na mesma hora. Se o "?saiu" permanecesse, todo recarregamento
        // desta página destruiria a sessão de novo — inclusive o reload feito logo
        // após o login, impedindo entrar sem apagar o parâmetro à mão.
        $__limpa = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
        if ($__limpa === '' || $__limpa === false) $__limpa = './';
        header('Location: ' . $__limpa, true, 302);
        exit;
    }
    if (!empty($_SESSION['ws_olt_login']) && isset($__us[$_SESSION['ws_olt_login']])) {
        $__lg = $_SESSION['ws_olt_login'];
        $__sessao = ['login' => $__lg, 'nome' => $__us[$__lg]['nome'] ?? $__lg,
                     'nivel' => (int)($__us[$__lg]['nivel'] ?? 1)];
    }
    // Operador do WellSystem logado -> entra direto, sem login separado da OLT (so com Auto-conectar
    // LIGADO; desligado, cai na tela de login root + senha do Telnet). O nivel da OLT ESPELHA o do painel:
    //   painel root/admin (nivel_acesso 99 ou 3) -> OLT 3 (Root)
    //   painel nivel 2 (operacao)                -> OLT 2 (opera e APROVISIONA, sem poderes de root)
    //   painel nivel 1 (leitura)                 -> OLT 1 (Leitura)
    // Com o auto-conectar DESLIGADO, apaga qualquer ponte antiga: senao o AJAX continuaria
    // autenticado por uma ponte velha e a tela de login seria inocua.
    if (!$__autoconn) { unset($_SESSION['ws_olt_bridge']); }
    if ($__sessao === null && !empty($__root_op) && $__autoconn) {
        $__na = (int)($__root_op['nivel_acesso'] ?? 0);
        if ($__na < 1 && ($__root_op['nivel'] ?? '') === 'admin') $__na = 99;
        $__olt_nv = ($__na >= 3) ? 3 : (($__na === 2) ? 2 : (($__na === 1) ? 1 : 2));  // sem nivel definido: operacao
        $__sessao = ['login' => (string)($__root_op['login'] ?? 'operador'),
                     'nome'  => (string)($__root_op['nome'] ?? 'Operador'),
                     'nivel' => $__olt_nv];
        // PONTE DE SESSAO: gravada na WSOLTSESS para o olt_huawei.php (AJAX) reconhecer o operador.
        // O autofind e' liberado para o cron, mas listar_slot/autorizar exigem sessao — sem esta
        // ponte a tela abre e depois responde "sessao expirou".
        $_SESSION['ws_olt_bridge'] = $__sessao;
    }
}
$__logado = ($__sessao !== null);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Wellsystem — Gerenciador OLT</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
    :root {
        --bg: #eef1f4; --surface: #ffffff; --surface-card: #ffffff;
        --border-color: #d0d7de; --text-main: #111827; --text-secondary: #374151;
        --accent-blue: #d32f2f;
    }
    * { box-sizing: border-box; }
    /* CORPO FIXO — sem pulo lateral: reserva o espaco da barra de rolagem, entao
       abrir/fechar conteudo nao muda a largura util e a pagina nao salta. */
    html { scrollbar-gutter: stable; }
    html, body {
        margin: 0; padding: 0; height: 100%;
        font-family: 'Plus Jakarta Sans', system-ui, -apple-system, 'Segoe UI', sans-serif;
        background: var(--bg); color: var(--text-main);
        -webkit-font-smoothing: subpixel-antialiased;
    }
    /* Relevo 3D das palavras das tarjas (mesmo tratamento da página principal) */
    [id$="Head"] > div > div:first-child, .ws-topo h1,
    #oltWinBody table.oltTbl thead th {
        text-shadow: 0 1px 0 rgba(0,0,0,.42), 0 2px 4px rgba(0,0,0,.28);
    }
    [id$="Head"] > div > div:first-child { font-weight: 700; letter-spacing: .01em; font-size: 14.5px; color: #fff !important; }
    /* Subtítulo da tarja: cor FIXA clara. Antes herdava a cor do tema e, no tema
       claro, ficava texto escuro sobre a tarja vermelha — ilegível. */
    [id$="Head"] > div > div:nth-child(2) {
        font-weight: 600; font-size: 11px; color: rgba(255,255,255,.90) !important;
        text-shadow: 0 1px 0 rgba(0,0,0,.35);
    }
    /* Ícones e botões do cabeçalho sempre brancos */
    [id$="Head"] > i, [id$="Head"] > button { color: #fff !important; }
    #oltWinBody table.oltTbl thead th { text-transform: uppercase; letter-spacing: .085em; font-weight: 800; font-size: .69rem; }

    .ws-topo {
        background: #3d434b; color: #fff; min-height: 64px; padding: 5px 26px;   /* altura livre: a logo maior fica DENTRO da faixa (antes 72 px fixos) */
        display: flex; align-items: center; gap: 14px;
        border-bottom: 3px solid #d32f2f; box-shadow: 0 2px 10px rgba(0,0,0,.16);
    }
    .ws-topo h1 { margin: 0; font-size: 16px; font-weight: 700; letter-spacing: .01em; }
    .ws-topo .sub { font-size: 11px; color: #d5dbe1; font-weight: 500; }
    .ws-corpo { padding: 26px; }
    .ws-abrir {
        cursor: pointer; padding: 14px 26px; border: none; border-radius: 10px;
        background: linear-gradient(180deg,#e64d4d 0%,#d32f2f 50%,#ab2323 100%); box-shadow: inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); color: #fff; font-weight: 800; font-size: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,.18); display: inline-flex; align-items: center; gap: 10px;
    }
    .ws-abrir:hover { background: #b62525; }
    .ws-aviso {
        background: #fff4f4; border: 1px solid #f0b4b4; color: #8a1f1f;
        padding: 14px 16px; border-radius: 10px; font-size: 13px; line-height: 1.6; max-width: 780px;
    }
    .ws-card {
        background: var(--surface-card); border: 1px solid var(--border-color);
        border-radius: 12px; padding: 18px 20px; max-width: 780px;
        box-shadow: 0 1px 3px rgba(16,24,40,.10); font-size: 13px; line-height: 1.65;
    }
    .ws-card b { color: #111827; }
    code { background: #eef1f4; padding: 1px 6px; border-radius: 5px; font-size: 12px; }

    /* ---------------- TELA DE LOGIN ---------------- */
    .lg-fundo {
        position: fixed; inset: 0; z-index: 999999;
        background: linear-gradient(150deg, #1b2430 0%, #121a24 55%, #0d141c 100%);
        display: flex; align-items: center; justify-content: center; padding: 20px;
    }
    .lg-caixa {
        width: 100%; max-width: 400px; background: #fff; border-radius: 16px;
        box-shadow: 0 24px 60px rgba(0,0,0,.45); overflow: hidden;
    }
    .lg-topo {
        background: linear-gradient(180deg,#e64d4d 0%,#d32f2f 50%,#ab2323 100%); box-shadow: inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); padding: 22px 24px; text-align: center; color: #fff;
    }
    .lg-topo img { max-height: 52px; max-width: 190px; object-fit: contain; margin-bottom: 10px; }
    .lg-topo .t { font-size: 17px; font-weight: 700; letter-spacing: .01em;
        text-shadow: 0 1px 0 rgba(0,0,0,.42), 0 2px 4px rgba(0,0,0,.28); }
    .lg-topo .s { font-size: 11.5px; opacity: .92; margin-top: 3px; }
    .lg-corpo { padding: 24px; }
    .lg-lb { display: block; font-size: 11.5px; font-weight: 700; color: #374151; margin: 0 0 5px; }
    .lg-in {
        width: 100%; box-sizing: border-box; padding: 11px 13px; font-size: 14px;
        border: 1px solid #d0d7de; border-radius: 9px; outline: none; margin-bottom: 14px;
        color: #111827; background: #fff; transition: border-color .15s, box-shadow .15s;
    }
    .lg-in:focus { border-color: #d32f2f; box-shadow: 0 0 0 3px rgba(211,47,47,.15); }
    .lg-bt {
        width: 100%; padding: 12px; border: none; border-radius: 9px; cursor: pointer;
        background: linear-gradient(180deg,#e64d4d 0%,#d32f2f 50%,#ab2323 100%); box-shadow: inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); color: #fff; font-weight: 800; font-size: 14px;
        display: flex; align-items: center; justify-content: center; gap: 9px;
        transition: background .15s;
    }
    .lg-bt:hover { background: #b62525; }
    .lg-msg { font-size: 12.5px; margin-top: 13px; text-align: center; min-height: 18px; }
    .lg-info {
        background: #eef4ff; border: 1px solid #c3d7fb; color: #1e40af;
        padding: 11px 13px; border-radius: 9px; font-size: 12px; line-height: 1.55; margin-bottom: 16px;
    }
    .lg-alerta {
        background: #fff4f4; border: 1px solid #f0b4b4; color: #8a1f1f;
        padding: 11px 13px; border-radius: 9px; font-size: 12px; line-height: 1.55; margin-bottom: 16px;
    }
    .lg-rodape { text-align: center; font-size: 10.5px; color: #9aa4b2; padding: 0 24px 18px; }
    /* Identificação do usuário na barra do topo */
    .ws-user { margin-left: auto; display: flex; align-items: center; gap: 12px; font-size: 12px; }
    .ws-user .nv { background: rgba(255,255,255,.16); padding: 3px 10px; border-radius: 20px; font-weight: 700; }
    .ws-sair {
        cursor: pointer; padding: 7px 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,.5);
        background: transparent; color: #fff; font-weight: 700; font-size: 12px;
    }
    .ws-sair:hover { background: rgba(255,255,255,.14); }
    /* Celular / tablet: a barra do topo quebra em linhas em vez de estourar para o lado. */
    @media (max-width: 760px) {
        .ws-topo { height: auto; min-height: 60px; flex-wrap: wrap; padding: 10px 14px; gap: 8px 12px; }
        .ws-topo img { height: 40px !important; max-width: 55vw !important; }
        .ws-topo h1 { font-size: 14px; }
        .ws-user { margin-left: 0; flex: 1 1 100%; flex-wrap: wrap; gap: 8px; }
        .ws-user .ws-sair { margin-left: auto; }
        .ws-corpo { padding: 14px; }
    }
/* LOGO DA OLT (21/11/2026, mesmo tratamento da logo do ERP): maior, inteira dentro da faixa do topo e com inclinação 3D e brilho ao passar o mouse */
.ws-topo > a:first-child,.ws-topo > span:first-child{perspective:520px}
.olt-logo{box-sizing:border-box;transition:transform .45s cubic-bezier(.2,.8,.2,1),box-shadow .45s;box-shadow:0 2px 8px rgba(0,0,0,.28);transform-style:preserve-3d}
.ws-topo > a:first-child:hover .olt-logo,.ws-topo > span:first-child:hover .olt-logo{transform:rotateY(16deg) rotateX(-7deg) scale(1.08);box-shadow:-7px 9px 20px rgba(211,47,47,.5)}
@media (prefers-reduced-motion:reduce){.olt-logo{transition:none}.ws-topo > a:first-child:hover .olt-logo,.ws-topo > span:first-child:hover .olt-logo{transform:none}}
</style>
</head>
<body>

<div class="ws-topo">
    <?php if ($__logo_olt !== ''): ?>
        <?php if ($__logo_url !== ''): ?><a href="<?= htmlspecialchars($__logo_url, ENT_QUOTES) ?>" target="_blank" rel="noopener" title="<?= htmlspecialchars(preg_replace('#^https?://#i', '', $__logo_url), ENT_QUOTES) ?>" style="display:inline-flex; line-height:0;"><?php else: ?><span style="display:inline-flex; line-height:0;"><?php endif; ?><img class="olt-logo" src="<?= htmlspecialchars($__logo_olt, ENT_QUOTES) ?>" alt="Logo" style="height:46px; max-width:180px; object-fit:contain;"><?= $__logo_url !== '' ? '</a>' : '</span>' ?>
    <?php else: ?>
        <i class="fa-solid fa-satellite-dish" style="font-size:20px; color:#d32f2f;"></i>
    <?php endif; ?>
    <div>
        <h1>Wellsystem — Gerenciador OLT</h1>
        <div class="sub">
            Monitoramento GPON ·
            <?= $WS_RADIUS ? 'integrado ao Radius Wellsystem' : 'modo independente (sem Radius)' ?>
        </div>
    </div>
    <?php if ($__auth_ativo && $__logado): ?>
    <div class="ws-user">
        <span><i class="fa-solid fa-user" style="opacity:.8"></i> <b><?= htmlspecialchars($__sessao['nome']) ?></b></span>
        <span class="nv"><?= [1=>'Leitura', 2=>'Operação', 3=>'Root'][$__sessao['nivel']] ?? $__sessao['nivel'] ?></span>
        <button class="ws-sair" onclick="wsSair()"><i class="fa-solid fa-right-from-bracket"></i> Sair</button>
    </div>
    <?php endif; ?>
</div>

<div class="ws-corpo">
<?php if (!$__backend_ok || !$__ui_ok): ?>
    <div class="ws-aviso">
        <b>Faltam arquivos do módulo nesta pasta:</b><br>
        <?php if (!$__backend_ok): ?>• <code>olt_huawei.php</code> — backend Telnet da OLT<br><?php endif; ?>
        <?php if (!$__ui_ok): ?>• <code>olt_ui.js</code> — interface do gerenciador<br><?php endif; ?>
        Copie-os para cá e recarregue esta página.
    </div>
<?php else: ?>
    <?php if (!$__grav): ?>
    <div class="ws-aviso" style="margin-bottom:18px;">
        <b>A pasta de dados não está gravável</b> — a conexão que você salvar será perdida ao reiniciar o servidor.<br>
        Rode antes de configurar:<br>
        <code>chmod -R 777 <?= htmlspecialchars(oltp_cache_dir()) ?></code>
    </div>
    <?php endif; ?>

    <?php
    // Nível do usuário: sem login ativo, trata como root (instalação sem olt_auth.php).
    $__nv = $__auth_ativo ? (int)($__sessao['nivel'] ?? 0) : 3;
    // Com a conexão pronta, o Gerenciador abre em tela cheia e ESTA tela não é
    // mais o ponto de partida — as opções de administração ficam no botão "Admin"
    // dentro do próprio gerenciador. Aqui sobra só o atalho de reabrir.
    $__tela_inicial = !$__conexao_ok;
    ?>
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="ws-abrir" onclick="abrirOltHuawei()">
            <i class="fa-solid fa-diagram-project"></i> Abrir Gerenciador OLT
        </button>
        <?php if ($__nv >= 3 && $__tela_inicial): /* só antes de haver conexão configurada */ ?>
        <button class="ws-abrir" style="background:#3d434b;" onclick="oltConexao()">
            <i class="fa-solid fa-network-wired"></i> Conexão da OLT
        </button>
        <?php endif; ?>
    </div>

    <?php if ($__tela_inicial): /* o texto de ajuda só faz sentido antes de configurar */ ?>
    <div class="ws-card" style="margin-top:22px;">
        <b>Primeiro acesso — configure a conexão.</b><br>
        A janela de <b>Conexão da OLT</b> abre automaticamente. Informe <b>IP/host</b>, <b>porta</b> (padrão 23),
        <b>usuário</b> e <b>senha</b> do Telnet e clique em <b>Salvar</b>: a conexão passa a valer na hora,
        sem editar nada no código.
        <?php if (!$WS_RADIUS): ?>
        <br><br><b>Modo independente:</b> o Radius (<code>index.php</code>) não está nesta pasta, então a coluna
        <b>Nome</b> usa o cadastro local da própria OLT. Se um dia você copiar o <code>index.php</code> para cá,
        os nomes dos assinantes passam a aparecer automaticamente — sem configurar nada.
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>
</div>

<?php if ($__auth_ativo && !$__logado): ?>
<!-- ===================== TELA DE LOGIN ===================== -->
<div class="lg-fundo" id="lgFundo">
  <div class="lg-caixa">
    <div class="lg-topo">
      <?php if ($__logo_olt !== ''): ?>
        <img src="<?= htmlspecialchars($__logo_olt, ENT_QUOTES) ?>" alt="Logo">
      <?php else: ?>
        <i class="fa-solid fa-satellite-dish" style="font-size:30px; margin-bottom:8px; display:block;"></i>
      <?php endif; ?>
      <div class="t">Wellsystem — Gerenciador OLT</div>
      <div class="s">Monitoramento GPON Huawei</div>
    </div>
    <div class="lg-corpo">
      <?php if ($__primeiro): ?>
        <?php if (!$__senha_olt_ok): ?>
          <div class="lg-alerta">
            <b>Falta a senha da OLT.</b><br>
            O primeiro acesso compara o que você digita com a <b>senha gravada na conexão</b>.
            <?= $__conexao_ok
                ? 'A conexão está salva, mas <b>sem senha</b> — o campo foi deixado em branco (em branco significa "manter a atual").'
                : 'Ainda não há conexão salva.' ?>
            Clique abaixo, <b>digite a senha</b> e salve.
          </div>
        <?php else: ?>
          <div class="lg-info">
            <b>Primeiro acesso.</b> Entre com o usuário <b>root</b> e a <b>senha da OLT</b>.
            O administrador será criado automaticamente com essa mesma senha.
          </div>
        <?php endif; ?>
        <!-- Sempre disponível no 1º acesso: é o único caminho para gravar/corrigir a senha. -->
        <button class="lg-bt" style="background:#3d434b; margin-bottom:16px;" onclick="oltConexao()">
          <i class="fa-solid fa-network-wired"></i> Configurar conexão da OLT
        </button>
      <?php endif; ?>

      <?php if (!$__primeiro || $__senha_olt_ok): ?>
      <form onsubmit="wsEntrar(event)" autocomplete="off">
        <label class="lg-lb" for="lgUser">Usuário</label>
        <input class="lg-in" id="lgUser" placeholder="<?= $__primeiro ? 'root' : 'seu usuário' ?>"
               value="<?= $__primeiro ? 'root' : '' ?>" autocomplete="username">
        <label class="lg-lb" for="lgPass">Senha</label>
        <input class="lg-in" id="lgPass" type="password"
               placeholder="<?= $__primeiro ? 'senha da OLT' : '••••••••' ?>" autocomplete="current-password">
        <button class="lg-bt" type="submit"><i class="fa-solid fa-right-to-bracket"></i> Entrar</button>
      </form>
      <div class="lg-msg" id="lgMsg"></div>
      <?php endif; ?>
    </div>
    <div class="lg-rodape">Wellsystem · acesso restrito</div>
  </div>
</div>
<script>
function wsEntrar(ev){
    ev.preventDefault();
    var m=document.getElementById('lgMsg');
    var u=document.getElementById('lgUser').value.trim();
    var p=document.getElementById('lgPass').value;
    m.innerHTML='<span style="color:#374151"><i class="fa-solid fa-spinner fa-spin"></i> Entrando…</span>';
    fetch('olt_huawei.php?acao=auth_login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'login='+encodeURIComponent(u)+'&senha='+encodeURIComponent(p)})
      .then(function(r){return r.json();}).then(function(d){
        if(d&&d.status==='ok'){
            m.innerHTML='<span style="color:#15803d"><i class="fa-solid fa-check"></i> '+(d.criado?'Administrador criado. Entrando…':'Bem-vindo!')+'</span>';
            setTimeout(function(){ location.reload(); },700);
        } else {
            m.innerHTML='<span style="color:#b91c1c">'+((d&&d.message)||'Falha ao entrar.')+'</span>';
        }
      }).catch(function(){ m.innerHTML='<span style="color:#b91c1c">Erro de comunicação com o servidor.</span>'; });
}
</script>
<?php endif; ?>

<script>
    // Sair: encerra a sessão IMEDIATAMENTE e vai para a tela de login.
    // Antes, os laços de fundo (varredura/sync) continuavam rodando durante a
    // saída e reabriam o gerenciador, exigindo várias tentativas.
    function wsSair(){
        if(!confirm('Encerrar a sessão?')) return;
        window.WS_SAINDO = true;                 // sinaliza para os laços pararem
        try {
            // 1) derruba tudo que roda em segundo plano
            window._oltSessao = (window._oltSessao || 0) + 1;   // invalida respostas pendentes
            window._oltPausarFundo = true;
            if (window._oltSyncTimer)   { clearInterval(window._oltSyncTimer);   window._oltSyncTimer = null; }
            if (window._oltPendTimer)   { clearInterval(window._oltPendTimer);   window._oltPendTimer = null; }
            if (window._oltUptimeTicker){ clearInterval(window._oltUptimeTicker); window._oltUptimeTicker = null; }
            if (window._oltResumoStatusTimer){ clearInterval(window._oltResumoStatusTimer); window._oltResumoStatusTimer = null; }
            if (window._oltJobs) { window._oltJobs.length = 0; }  // esvazia a fila da OLT
            // 2) não deixa nada reabrir sozinho na próxima carga
            sessionStorage.removeItem('oltAberto');
            sessionStorage.removeItem('oltFiltro');
            sessionStorage.removeItem('oltCat');
            // 3) some com a interface na hora (feedback imediato)
            var ov = document.getElementById('oltOverlay'); if (ov) ov.remove();
            document.body.style.overflow = '';
        } catch (e) {}
        // 4) encerra no servidor. keepalive garante o envio mesmo saindo da página,
        //    então NÃO precisamos esperar a resposta para redirecionar.
        try {
            fetch('olt_huawei.php?acao=auth_logout', {method:'POST', cache:'no-store', keepalive:true});
        } catch (e) {}
        // 5) vai para o login NA HORA. Sem timeout: qualquer espera abria corrida
        //    com outros redirecionamentos (o oltFechar recarregava em 80ms e
        //    desfazia a saída). Aqui o replace acontece já, e o ?saiu encerra a
        //    sessão no servidor mesmo se a chamada acima se perder.
        location.replace(location.pathname + '?saiu=' + Date.now());
    }
    // Informa ao módulo se há Radius nesta pasta (evita chamada inútil quando não há).
    window.WS_RADIUS  = <?= $WS_RADIUS ? 'true' : 'false' ?>;
    window.WS_SRV     = '';   // sem MK-Auth vinculado, não há link de cadastro
    window.WS_LOGO_OLT = <?= json_encode($__logo_olt, JSON_UNESCAPED_SLASHES) ?>;
    window.WS_LOGO_URL = <?= json_encode($__logo_url, JSON_UNESCAPED_SLASHES) ?>;   // link da logo do topo (site do provedor)
    window.WS_OLT_STANDALONE = true;   // esta é a página autônoma da OLT
    // Nível do usuário logado (1 leitura · 2 operação · 3 root). Sem login ativo = 3.
    // Serve só para OCULTAR o que a pessoa não pode usar; quem barra de verdade
    // é o servidor (olt_auth.php), que valida nível em cada endpoint.
    window.WS_NIVEL = <?= $__auth_ativo ? (int)($__sessao['nivel'] ?? 0) : 3 ?>;
    // PRIMEIRO ACESSO (nenhum usuário cadastrado ainda): a tela de login precisa
    // deixar configurar a conexão, porque a senha da OLT é o que valida esse
    // primeiro login. O servidor libera apenas conexao_get/conexao_set/fix_perms
    // nessa janela — todo o resto continua barrado lá.
    window.WS_PRIMEIRO = <?= ($__auth_ativo && $__primeiro) ? 'true' : 'false' ?>;
    window.WS_USUARIO = <?= json_encode($__sessao ?: null, JSON_UNESCAPED_UNICODE) ?>;
    window.WS_OLT_AUTOCONN  = <?= $__autoconn ? 'true' : 'false' ?>;   // auto-conectar (login do WellSystem) ligado?
    window.WS_OLT_CONECTADO = <?= $__conexao_ok ? 'true' : 'false' ?>; // OLT ja tem conexao configurada?
    // Ao fechar o gerenciador, não reabrir sozinho na recarga seguinte.
    try { sessionStorage.removeItem('oltAberto'); } catch (e) {}
</script>
<?php if ($__backend_ok && $__ui_ok): ?>
<?php /* Portas de acesso ao equipamento do cliente (Configurações → Geral, cache/equipamento.json) — lidas do arquivo:
   aqui o config.php ainda não foi carregado. Mesma regra de ws_equip_cfg(). */
$__eq = []; foreach ([(oltp_raiz_ws() ?: __DIR__) . '/cache/equipamento.json', __DIR__ . '/cache/equipamento.json'] as $__ef) { if (is_file($__ef)) { $__eq = json_decode((string)@file_get_contents($__ef), true) ?: []; break; } }
$__eqProto = (($__eq['proto'] ?? 'http') === 'https') ? 'https' : 'http'; $__eqP = (int)($__eq['porta'] ?? 80); $__eqA = array_key_exists('porta_alt', $__eq) ? (int)$__eq['porta_alt'] : 1080;
$__eqPad = $__eqProto === 'https' ? 443 : 80; ?>
<script>window.WS_EQUIP = <?= json_encode(['base' => $__eqProto . '://', 'porta' => ($__eqP > 0 && $__eqP !== $__eqPad) ? ':' . $__eqP : '', 'alt' => $__eqA > 0 ? ':' . $__eqA : '']) ?>;</script>
<script src="olt_ui.js?v=<?= @hash_file('crc32b', __DIR__ . '/olt_ui.js') ?: (@filemtime(__DIR__ . '/olt_ui.js') ?: time()) ?>"></script>
<?php /* VERSÃO CURTA da OLT no rodapé (oltFooter, olt_ui.js): data/hora do arquivo mais novo do módulo; o detalhe
   (arquivo, md5, data e endereço) aparece ao passar o mouse — p/ comparar abas (IP x domínio). */
   $__vMax = 0; $__vDet = [];
   foreach (['olt_ui.js', 'olt_huawei.php', 'olt_nativo.php', 'olt.php'] as $__vf) { $__vp = __DIR__ . '/' . $__vf; if (!is_file($__vp)) continue;
       $__vt = (int)filemtime($__vp); $__vMax = max($__vMax, $__vt); $__vDet[] = $__vf . ' ' . substr((string)@md5_file($__vp), 0, 8) . ' ' . date('d/m H:i', $__vt); }
   $__vDet[] = (string)($_SERVER['HTTP_HOST'] ?? ''); ?>
<?php // SELO do WellSystem no rodapé da OLT (o mesmo do rodapé do ERP)
   $__vSelo = function_exists('ws_selo_src') ? ws_selo_src() : (is_file(__DIR__ . '/img/wellsystem-selo.png') ? 'img/wellsystem-selo.png?v=' . (int)filemtime(__DIR__ . '/img/wellsystem-selo.png') : ''); ?>
<script>window.WS_OLT_VER = <?= json_encode(['selo' => $__vSelo, 'dono' => (function_exists('ws_dono_url') ? ws_dono_url() : (is_file(__DIR__ . '/marca_registro.php') && (require_once __DIR__ . '/marca_registro.php') && function_exists('ws_marca_dono_url') ? ws_marca_dono_url() : 'https://wellnet.com.br')), 'txt' => $__vMax ? 'v' . date('d.m.y', $__vMax) : '', 'tip' => 'Versão de ' . ($__vMax ? date('d/m/Y H:i', $__vMax) : '—') . "\n" . implode("\n", $__vDet)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;</script>
<script>
// Abertura automática:
//  • sem conexão configurada -> abre a janela "Conexão da OLT" para preencher IP/porta/usuário/senha;
//  • já configurada          -> abre o Gerenciador direto.
(function () {
    var jaConfigurado = <?= $__conexao_ok ? 'true' : 'false' ?>;
    var precisaLogin  = <?= ($__auth_ativo && !$__logado) ? 'true' : 'false' ?>;
    var faltaSenhaOlt = <?= ($__auth_ativo && !$__logado && $__primeiro && !$__senha_olt_ok) ? 'true' : 'false' ?>;
    // Com a tela de login aberta, nada é iniciado por trás dela — exceto a janela
    // de conexão no primeiro acesso, que é pré-requisito para o próprio login.
    if (precisaLogin) {
        if (faltaSenhaOlt) {
            setTimeout(function () { if (typeof oltConexao === 'function') oltConexao(); }, 350);
        }
        return;
    }
    function iniciar() {
        try {
            // A janela de conexão só abre sozinha para o ROOT. Para os demais
            // níveis, abre o gerenciador normalmente (o aviso de "não configurada"
            // aparece na lista, sem oferecer configuração que eles não podem fazer).
            if (!jaConfigurado && (window.WS_NIVEL || 0) >= 3) {
                if (typeof oltConexao === 'function') oltConexao();
            } else {
                if (typeof abrirOltHuawei === 'function') abrirOltHuawei();
            }
        } catch (e) {
            var d = document.createElement('div');
            d.className = 'ws-aviso';
            d.style.margin = '18px 26px';
            d.innerHTML = '<b>Falha ao iniciar o gerenciador:</b><br>' + (e && e.message ? e.message : e);
            document.body.appendChild(d);
        }
    }
    if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(iniciar, 60);
    else window.addEventListener('DOMContentLoaded', function () { setTimeout(iniciar, 60); });
})();
</script>
<?php endif; ?>
<?php
/* Rodapé do sistema. Fica no fim de propósito: a esta altura a sessão própria da OLT
   (WSOLTSESS) já foi resolvida, e o config.php não reabre sessão nenhuma — ele só cria a
   dele quando NÃO existe uma ativa. */
if (($__ws_raiz = oltp_raiz_ws()) !== null):
    // A página JÁ foi impressa aqui. Se o config.php emitir qualquer coisa ao carregar (um aviso
    // do PHP, por exemplo), sairia solto no meio do HTML. O buffer segura e descarta — o que
    // interessa dele são as funções, não saída.
    if (!defined('WS_SEM_TRAVA')) define('WS_SEM_TRAVA', 1);   // só o rodapé: a trava de inatividade do painel não roda aqui
    ob_start(); require_once $__ws_raiz . '/config.php'; ob_end_clean();
    if (function_exists('ws_edicao_tem') && !ws_edicao_tem('erp')) echo '<script>window._oltIsolada = true;</script>';   // edição OLT isolada: sem cadastro de clientes do ERP (o JS esconde "Cadastro")
    if (function_exists('ws_footer_bar')):
        // Nome do operador: a sessão ativa aqui é a da OLT, então ws_user() não acharia o do
        // painel. Emprestamos $__root_op (lido lá em cima, da sessão do WellSystem) só durante
        // a chamada e devolvemos como estava — nada é gravado na sessão da OLT.
        $__op_salvo = $_SESSION['ws_user'] ?? null;
        if (!empty($__root_op)) $_SESSION['ws_user'] = $__root_op;
        $__rod = ws_footer_bar();
        if ($__op_salvo === null) unset($_SESSION['ws_user']); else $_SESSION['ws_user'] = $__op_salvo;

        // O HTML do rodapé usa caminho relativo (img/…). Rodando em olt/, o certo é ../img/.
        if ($__ws_raiz !== __DIR__) $__rod = str_replace('src="img/', 'src="../img/', $__rod);

        // O destaque vermelho do "Versao Master Wellsystem" agora nasce no proprio
        // ws_footer_bar() (classe .ws-rodape-versao), valendo para TODAS as telas.
        // Aqui so' garantimos que a regra de cor exista, porque esta pagina nao carrega
        // o css/wellsystem.css inteiro - so' as regras .ws-rodape* que oltp_css_rodape() extrai.

        // Variáveis que as regras do rodapé esperam. Esta página tem paleta própria (sempre
        // clara), então elas recebem os MESMOS tons do tema claro do ERP — rodapé idêntico nos dois.
        $__css = oltp_css_rodape();
        if ($__css !== '') {
            echo '<style>:root{--top-bg:#ffffff;--muted:#6b6167;--border:#e6e2e3;'
               . '--surface:#ffffff;--text:#1a1416;'
               . '--grad-brand:linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%);}' // mesmo degradê do ERP (css/wellsystem.css)
               . $__css . '</style>';
        }
        echo $__rod;
    endif;
endif;
?>
<script>
/* Trava da OLT (15/10/2026): a página não recarrega sozinha; enquanto há uso (mouse/teclado) renova o relógio, parada além do tempo recarrega para a tela de senha. */
(function () {
  var uso = false; ['mousemove', 'mousedown', 'keydown', 'wheel', 'touchstart'].forEach(function (e) { window.addEventListener(e, function () { uso = true; }, { passive: true, capture: true }); });
  setInterval(function () {
    var u = uso; uso = false;
    try { fetch('ws_ping.php' + (u ? '?uso=1' : ''), { cache: 'no-store', credentials: 'same-origin' }).then(function (r) { if (r.status === 401 || r.status === 403) location.reload(); }).catch(function () {}); } catch (e) {}
  }, 60000);
})();
</script>
</body>
</html>
