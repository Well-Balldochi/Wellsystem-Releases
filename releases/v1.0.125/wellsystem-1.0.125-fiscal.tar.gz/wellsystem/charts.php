<?php
/**
 * WellSystem — Gráficos SVG nativos (sem libs externas, funcionam offline).
 * Usados pelo dashboard (erp.php / crm.php) e pelos relatórios (relatorios.php).
 *
 * VISUAL (revisão de elegância) — as ASSINATURAS das funções são as mesmas de sempre, então
 * nenhuma tela que chama um gráfico precisou mudar. O que mudou é só o desenho:
 *  - Paleta categórica única, em ORDEM FIXA e validada para daltonismo (azul, laranja, água,
 *    amarelo, magenta, verde, violeta, vermelho), com tons próprios no TEMA ESCURO. Gráfico de
 *    uma série só continua na cor da marca (var(--brand)).
 *  - Barras finas (≤24px), topo arredondado 4px e base reta; grade em linha fina e sólida, com
 *    valores "redondos" no eixo; linha zero marcada.
 *  - Número só onde conta (o MAIOR e o ÚLTIMO valor); os demais aparecem ao passar o mouse —
 *    antes havia um número em cada barra, e com muitas barras nenhum era lido.
 *  - Linha de 2px com área suave (~10%) e ponto final com anel; hover mostra guia + valor.
 *  - Pizza virou ROSCA: separação de 2px entre fatias, total no centro, legenda com valor e %.
 *    Mais de 8 fatias: o resto vira "Outros" (cor nunca é inventada nem repetida).
 *  - Texto (valores, eixos, legendas) sempre em cor de texto — a cor da série fica na marca.
 * Tooltip e estilos saem UMA vez por página (ws_viz_assets), inline — não dependem de css/ ou js/.
 */

/** CSS + JS do tooltip e da paleta — emitido uma vez por página, junto do 1º gráfico. */
function ws_viz_assets(): string {
    static $feito = false;
    if ($feito) return '';
    $feito = true;
    $claro  = '--c1:#2a78d6;--c2:#eb6834;--c3:#1baf7a;--c4:#eda100;--c5:#e87ba4;--c6:#008300;--c7:#4a3aa7;--c8:#e34948;--cOutros:#898781;';
    $escuro = '--c1:#3987e5;--c2:#d95926;--c3:#199e70;--c4:#c98500;--c5:#d55181;--c6:#008300;--c7:#9085e9;--c8:#e66767;--cOutros:#898781;';
    return '<style>
      .ws-viz{' . $claro . 'font-family:inherit}
      @media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])) .ws-viz{' . $escuro . '}}
      :root[data-theme="dark"] .ws-viz,body.dark-mode .ws-viz{' . $escuro . '}
      .ws-viz text{font-variant-numeric:tabular-nums}
      .ws-viz .vz-hit{cursor:default}
      .ws-viz .vz-hit .vz-on{opacity:0;transition:opacity .12s}
      .ws-viz .vz-hit:hover .vz-on{opacity:1}
      .ws-viz .vz-bar{transition:opacity .12s}
      .ws-viz:hover .vz-bar{opacity:.55}
      .ws-viz .vz-hit:hover .vz-bar,.ws-viz .vz-bar:hover{opacity:1}
      .ws-viz-leg{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:12px;color:var(--muted);margin:0 0 8px}
      .ws-viz-leg i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}
      .ws-viz-tip{position:fixed;z-index:2147483600;pointer-events:none;background:var(--surface,#fff);color:var(--text,#111);
        border:1px solid var(--border,#ddd);border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.18);padding:6px 10px;
        font-size:12px;line-height:1.35;white-space:nowrap;opacity:0;transition:opacity .08s}
      .ws-viz-tip b{font-weight:700}
      .ws-donut{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
      .ws-donut-leg{flex:1 1 180px;min-width:0}
      .ws-donut-leg div{display:flex;align-items:center;gap:8px;font-size:12.5px;padding:3px 0;border-bottom:1px solid var(--border)}
      .ws-donut-leg div:last-child{border-bottom:0}
      .ws-donut-leg i{width:10px;height:10px;border-radius:3px;flex:none}
      .ws-donut-leg span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text)}
      .ws-donut-leg em{font-style:normal;color:var(--muted);font-variant-numeric:tabular-nums;white-space:nowrap}
    </style><script>
    (function(){
      if(window.__wsVizTip) return; window.__wsVizTip=1;
      var tip=null;
      function el(){ if(!tip){ tip=document.createElement("div"); tip.className="ws-viz-tip"; document.body.appendChild(tip);} return tip; }
      document.addEventListener("mousemove",function(e){
        var t=e.target.closest?e.target.closest("[data-tip]"):null;
        if(!t){ if(tip) tip.style.opacity=0; return; }
        var d=el(); d.innerHTML=t.getAttribute("data-tip");
        var x=e.clientX+14, y=e.clientY+14, w=d.offsetWidth, h=d.offsetHeight;
        if(x+w>innerWidth-8) x=e.clientX-w-14; if(y+h>innerHeight-8) y=e.clientY-h-14;
        d.style.left=x+"px"; d.style.top=y+"px"; d.style.opacity=1;
      },{passive:true});
    })();
    </script>';
}

/** Id único por gráfico (gradientes) — dois gráficos na mesma página não se misturam. */
function ws_viz_id(): string { static $n = 0; return 'vz' . (++$n); }

/** Topo "redondo" do eixo: 1, 2, 2.5 ou 5 × 10^k acima do máximo. */
function ws_viz_nice(float $max): float {
    if ($max <= 0) return 1.0;
    $e = pow(10, floor(log10($max))); $f = $max / $e;
    foreach ([1, 2, 2.5, 5, 10] as $m) if ($f <= $m) return $m * $e;
    return 10 * $e;
}

/** Barra com topo arredondado (4px) e base reta; negativa arredonda embaixo. */
function ws_viz_bar(float $x, float $yTopo, float $w, float $h, string $fill, bool $neg = false): string {
    $h = max($h, 1.5); $r = min(4, $w / 2, $h);
    $x = round($x, 1); $w = round($w, 1); $y = round($yTopo, 1); $h = round($h, 1); $x2 = $x + $w; $y2 = $y + $h;
    $d = $neg
        ? "M$x,$y H$x2 V" . ($y2 - $r) . " Q$x2,$y2 " . ($x2 - $r) . ",$y2 H" . ($x + $r) . " Q$x,$y2 $x," . ($y2 - $r) . " Z"
        : "M$x,$y2 V" . ($y + $r) . " Q$x,$y " . ($x + $r) . ",$y H" . ($x2 - $r) . " Q$x2,$y $x2," . ($y + $r) . " V$y2 Z";
    return "<path class='vz-bar' d='$d' fill='$fill'/>";
}

/** Texto seguro para SVG/atributo. */
function ws_viz_h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Sparkline / linha com área. */
function ws_svg_linha(array $v, ?array $labels = null, ?callable $fmt = null, int $wBase = 720, int $hBase = 160): string {
    $v = array_values(array_map('floatval', $v));
    if (!$v) return '';
    $labels = $labels !== null ? array_values($labels) : null;
    $w = $wBase; $h = $hBase; $pl = $fmt ? 54 : ($labels ? 26 : 10); $pr = 16; $pt = 18; $pb = $labels ? 28 : 12; $n = count($v);   // (16/10/2026) com rótulos: eixo Y com valores e eixo X com nomes
    $fmtv = $fmt ?: fn($x) => number_format($x, 0, ',', '.');
    $max = max(max($v), 1);
    /* Linha mostra TENDÊNCIA: o eixo não precisa partir do zero. Com valores entre 400 e 500
       (clientes online, por ex.) partir do zero achatava tudo numa reta. Folga de metade da
       variação abaixo do menor valor, nunca abaixo de zero. */
    $vMin = min($v); $amp = max($max - $vMin, 1);
    $min = $vMin < 0 ? $vMin : max(0, $vMin - $amp * 0.5);
    $top = $max + $amp * 0.15;
    $x = fn($i) => $pl + ($n <= 1 ? ($w - $pl - $pr) / 2 : $i * ($w - $pl - $pr) / ($n - 1));
    $y = fn($val) => $pt + (1 - ($val - $min) / max($top - $min, 1)) * ($h - $pt - $pb);
    $P = []; foreach ($v as $i => $val) $P[] = [$x($i), $y($val)];
    // Curva suave (Catmull-Rom -> Bézier), traço de 2px.
    $d = 'M' . round($P[0][0], 1) . ',' . round($P[0][1], 1);
    for ($i = 0; $i < $n - 1; $i++) {
        $p0 = $P[max(0, $i - 1)]; $p1 = $P[$i]; $p2 = $P[$i + 1]; $p3 = $P[min($n - 1, $i + 2)];
        $d .= ' C' . round($p1[0] + ($p2[0] - $p0[0]) / 6, 1) . ',' . round($p1[1] + ($p2[1] - $p0[1]) / 6, 1)
            . ' ' . round($p2[0] - ($p3[0] - $p1[0]) / 6, 1) . ',' . round($p2[1] - ($p3[1] - $p1[1]) / 6, 1)
            . ' ' . round($p2[0], 1) . ',' . round($p2[1], 1);
    }
    $base = round($y(max($min, 0)), 1);
    $area = $d . ' L' . round($P[$n - 1][0], 1) . ",$base L" . round($P[0][0], 1) . ",$base Z";
    $id = ws_viz_id();
    $o  = ws_viz_assets() . "<svg class='ws-viz' viewBox='0 0 $w $h' role='img' aria-label='Gráfico de linha' style='width:100%;height:auto;max-width:800px;margin:0 auto;display:block'>";
    $o .= "<defs><linearGradient id='$id' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='var(--brand)' stop-opacity='.16'/><stop offset='1' stop-color='var(--brand)' stop-opacity='0'/></linearGradient></defs>";
    for ($g = 0; $g <= 3; $g++) { $gy = round($pt + $g * ($h - $pt - $pb) / 3, 1); $o .= "<line x1='$pl' y1='$gy' x2='" . ($w - $pr) . "' y2='$gy' stroke='var(--border)' stroke-width='1'/>"; }
    $o .= "<path d='$area' fill='url(#$id)'/>";
    $o .= "<path d='$d' fill='none' stroke='var(--brand)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/>";
    // Hover: coluna invisível por ponto, com guia vertical + ponto + valor no tooltip.
    $colW = $n > 1 ? ($w - $pl - $pr) / ($n - 1) : ($w - $pl - $pr);
    foreach ($P as $i => $p) {
        $cx = round($p[0], 1); $cy = round($p[1], 1);
        $tip = ws_viz_h('<b>' . $fmtv($v[$i]) . '</b> · ' . ($labels[$i] ?? ('ponto ' . ($i + 1) . ' de ' . $n)));
        $o .= "<g class='vz-hit' data-tip=\"$tip\"><rect x='" . round($cx - $colW / 2, 1) . "' y='0' width='" . round($colW, 1) . "' height='$h' fill='transparent'/>"
            . "<line class='vz-on' x1='$cx' y1='$pt' x2='$cx' y2='" . ($h - $pb) . "' stroke='var(--muted)' stroke-width='1'/>"
            . "<circle class='vz-on' cx='$cx' cy='$cy' r='4' fill='var(--brand)' stroke='var(--surface)' stroke-width='2'/></g>";
    }
    // Ponto final sempre visível (com anel) + rótulo do último valor e do pico.
    $last = $P[$n - 1];
    $o .= "<circle cx='" . round($last[0], 1) . "' cy='" . round($last[1], 1) . "' r='4' fill='var(--brand)' stroke='var(--surface)' stroke-width='2'/>";
    $o .= "<text x='" . ($w - $pr) . "' y='" . max(12, round($last[1] - 9, 1)) . "' fill='var(--text)' font-size='11' font-weight='700' text-anchor='end'>" . ws_viz_h($fmtv(end($v))) . "</text>";
    if (!$fmt) $o .= "<text x='$pl' y='12' fill='var(--muted)' font-size='10.5'>pico " . number_format($max, 0, ',', '.') . "</text>";
    // (16/10/2026) valores no eixo Y
    if ($fmt) for ($g = 0; $g <= 3; $g++) { $gv = $top - $g * ($top - $min) / 3; $gy = round($pt + $g * ($h - $pt - $pb) / 3, 1); $o .= "<text x='" . ($pl - 6) . "' y='" . ($gy + 3.5) . "' fill='var(--muted)' font-size='10' text-anchor='end'>" . ws_viz_h($fmtv($gv)) . "</text>"; }
    // nomes no eixo X (no máx. ~8) e valor em cada ponto quando são poucos
    if ($labels) { $passo = max(1, (int)ceil($n / 8)); foreach ($P as $i => $p) { if ($i % $passo === 0 || $i === $n - 1) $o .= "<text x='" . round($p[0], 1) . "' y='" . ($h - 8) . "' fill='var(--muted)' font-size='10.5' text-anchor='middle'>" . ws_viz_h($labels[$i] ?? '') . "</text>"; } }
    if ($n <= 8 && $n > 1) foreach ($P as $i => $p) { if ($i === $n - 1) continue; $o .= "<text x='" . round($p[0], 1) . "' y='" . round($p[1] - 8, 1) . "' fill='var(--text)' font-size='10' text-anchor='middle'>" . ws_viz_h($fmtv($v[$i])) . "</text>"; }
    return $o . "</svg>";
}

/** Barras simples (1 série). $fmt formata os valores (eixo, rótulos e tooltip). */
function ws_svg_barras(array $v, array $labels, ?callable $fmt = null, int $wBase = 720, bool $todos = false): string {
    $v = array_values(array_map('floatval', $v)); $labels = array_values($labels);
    if (!$v) return '';
    $fmt = $fmt ?: fn($x) => number_format($x / 1000, 1, ',', '.') . 'k';
    $n = count($v);
    /* Largura POR barra (não total fixa): com muitos meses/vencimentos o desenho cresce e o
       rótulo sempre cabe; como o SVG ocupa 100% da largura, tudo encolhe junto em vez de se
       sobrepor. Rótulos do eixo X são "raleados" quando há muitas barras. */
    $pl = 58; $pr = 12; $pt = 22; $pb = 26;
    $w = max($wBase, (int)($pl + $pr + $n * 30)); $h = 220;
    $top = ws_viz_nice(max($v));
    $areaH = $h - $pt - $pb;
    $slot = ($w - $pl - $pr) / $n; $bw = min(24, $slot * 0.62);
    $yv = fn($x) => $pt + (1 - $x / $top) * $areaH;
    $o = ws_viz_assets() . "<svg class='ws-viz' viewBox='0 0 $w $h' role='img' aria-label='Gráfico de barras' style='width:100%;height:auto;max-width:800px;margin:0 auto;display:block'>";
    // Grade + valores redondos no eixo.
    for ($g = 0; $g <= 4; $g++) {
        $tv = $top * $g / 4; $gy = round($yv($tv), 1);
        $o .= "<line x1='$pl' y1='$gy' x2='" . ($w - $pr) . "' y2='$gy' stroke='var(--border)' stroke-width='1'/>";
        $o .= "<text x='" . ($pl - 8) . "' y='" . ($gy + 3.5) . "' fill='var(--muted)' font-size='10' text-anchor='end'>" . ws_viz_h($fmt($tv)) . "</text>";
    }
    $iMax = array_search(max($v), $v, true); $iUlt = $n - 1;
    $passoRot = max(1, (int)ceil($n / 14));   // no máx. ~14 rótulos no eixo X
    foreach ($v as $i => $val) {
        $bx = $pl + $i * $slot + ($slot - $bw) / 2; $by = $yv(max($val, 0));
        $cx = round($bx + $bw / 2, 1);
        $tip = ws_viz_h('<b>' . ws_viz_h($labels[$i] ?? '') . '</b><br>' . ws_viz_h($fmt($val)));
        $o .= "<g class='vz-hit' data-tip=\"$tip\"><rect x='" . round($pl + $i * $slot, 1) . "' y='$pt' width='" . round($slot, 1) . "' height='$areaH' fill='transparent'/>"
            . ws_viz_bar($bx, $by, $bw, $yv(0) - $by, 'var(--brand)') . "</g>";
        if ($i % $passoRot === 0 || $i === $iUlt)
            $o .= "<text x='$cx' y='" . ($h - $pb + 15) . "' fill='var(--muted)' font-size='10.5' text-anchor='middle'>" . ws_viz_h($labels[$i] ?? '') . "</text>";
        if ($todos || $i === $iMax || $i === $iUlt)   // número só no maior e no último ($todos = em todas)
            $o .= "<text x='$cx' y='" . round($by - 6, 1) . "' fill='var(--text)' font-size='10.5' font-weight='700' text-anchor='middle'>" . ws_viz_h($fmt($val)) . "</text>";
    }
    $o .= "<line x1='$pl' y1='" . round($yv(0), 1) . "' x2='" . ($w - $pr) . "' y2='" . round($yv(0), 1) . "' stroke='var(--muted)' stroke-width='1' opacity='.6'/>";
    return $o . "</svg>";
}

/** Barras agrupadas (N séries) — ex.: Instalações x Cancelamentos x Saldo, todas juntas por mês.
 *  $series = ['Rótulo da série' => [valores por categoria em $labels], ...]. $cores opcional
 *  (quem passa cores próprias continua mandando nelas). */
function ws_svg_barras_n(array $labels, array $series, ?array $cores = null, int $wBase = 720): string {
    $labels = array_values($labels);
    if (!$labels || !$series) return '';
    $ns = count($series); $n = count($labels);
    $cores = $cores ?: array_map(fn($i) => 'var(--c' . ($i + 1) . ')', range(0, 7));
    $todos = []; foreach ($series as $vs) foreach ($vs as $x) $todos[] = (float)$x;
    $max = max(max($todos ?: [0]), 0); $min = min(min($todos ?: [0]), 0);
    $topP = $max > 0 ? ws_viz_nice($max) : 0; $topN = $min < 0 ? -ws_viz_nice(-$min) : 0;
    if ($topP == 0 && $topN == 0) $topP = 1;
    $pl = 44; $pr = 12; $pt = 16; $pb = 26;
    $w = max($wBase, (int)($pl + $pr + $n * ($ns * 22 + 20))); $h = 230;
    $areaH = $h - $pt - $pb;
    $yv = fn($x) => $pt + ($topP - $x) / ($topP - $topN) * $areaH;
    $slot = ($w - $pl - $pr) / $n; $bw = min(24, ($slot * 0.72) / $ns); $gap = 2;
    // Legenda em HTML acima do gráfico (≥2 séries: identidade nunca só pela cor).
    $leg = "<div class='ws-viz-leg'>";
    $si = 0; foreach (array_keys($series) as $nome) { $leg .= "<span><i style='background:" . $cores[$si % count($cores)] . "'></i>" . ws_viz_h($nome) . "</span>"; $si++; }
    $leg .= "</div>";
    $o = ws_viz_assets() . "<div class='ws-viz'>$leg<svg viewBox='0 0 $w $h' role='img' aria-label='Gráfico de barras agrupadas' style='width:100%;height:auto;max-width:800px;margin:0 auto;display:block'>";
    // Marcas do eixo: topo, meio, zero e o fundo negativo (sem a marca do meio negativo quando a
    // parte negativa é pequena — senão os números se amontoam logo abaixo do zero).
    $ticks = [$topP, $topP / 2, 0];
    if ($topN < 0) { if (-$topN >= $topP * 0.3) $ticks[] = $topN / 2; $ticks[] = $topN; }
    foreach (array_unique($ticks) as $tv) {
        if ($topP == 0 && $tv > 0) continue;
        if ($topN < 0 && -$topN < $topP * 0.12 && $tv == $topN) continue;   // negativo minúsculo: só o zero
        $gy = round($yv($tv), 1);
        $o .= "<line x1='$pl' y1='$gy' x2='" . ($w - $pr) . "' y2='$gy' stroke='var(--border)' stroke-width='1'/>";
        $o .= "<text x='" . ($pl - 8) . "' y='" . ($gy + 3.5) . "' fill='var(--muted)' font-size='10' text-anchor='end'>" . number_format($tv, 0, ',', '.') . "</text>";
    }
    $y0 = round($yv(0), 1);
    foreach ($labels as $i => $lbl) {
        $grpW = $ns * $bw + ($ns - 1) * $gap; $x0 = $pl + $i * $slot + ($slot - $grpW) / 2; $si = 0;
        $tipL = '<b>' . ws_viz_h($lbl) . '</b>';
        foreach ($series as $nome => $vals) $tipL .= '<br>' . ws_viz_h($nome) . ': <b>' . number_format((float)($vals[$i] ?? 0), 0, ',', '.') . '</b>';
        $o .= "<g class='vz-hit' data-tip=\"" . ws_viz_h($tipL) . "\"><rect x='" . round($pl + $i * $slot, 1) . "' y='$pt' width='" . round($slot, 1) . "' height='$areaH' fill='transparent'/>";
        foreach ($series as $nome => $vals) {
            $val = (float)($vals[$i] ?? 0); $cor = $cores[$si % count($cores)];
            $bx = $x0 + $si * ($bw + $gap);
            $o .= $val >= 0 ? ws_viz_bar($bx, $yv($val), $bw, $y0 - $yv($val), $cor) : ws_viz_bar($bx, $y0, $bw, $yv($val) - $y0, $cor, true);
            $si++;
        }
        $o .= "</g>";
        // Poucas categorias (ex.: "Total"): o valor de cada barra cabe e ajuda; muitas: só no tooltip.
        if ($n <= 3) { $si = 0; foreach ($series as $vals) { $val = (float)($vals[$i] ?? 0); $bx = $x0 + $si * ($bw + $gap) + $bw / 2;
            $o .= "<text x='" . round($bx, 1) . "' y='" . round($val >= 0 ? $yv($val) - 5 : $yv($val) + 12, 1) . "' fill='var(--text)' font-size='10.5' font-weight='700' text-anchor='middle'>" . number_format($val, 0, ',', '.') . "</text>"; $si++; } }
        $o .= "<text x='" . round($x0 + $grpW / 2, 1) . "' y='" . ($h - $pb + 15) . "' fill='var(--muted)' font-size='10.5' text-anchor='middle'>" . ws_viz_h($lbl) . "</text>";
    }
    $o .= "<line x1='$pl' y1='$y0' x2='" . ($w - $pr) . "' y2='$y0' stroke='var(--muted)' stroke-width='1' opacity='.6'/>";
    return $o . "</svg></div>";
}

/** Rosca (antiga pizza). $dados = ['Rótulo' => valor, ...]. Mais de 8 fatias: o resto vira "Outros". */
function ws_svg_pizza(array $dados): string {
    $dados = array_filter($dados, fn($v) => $v > 0);
    if (!$dados) return '';
    arsort($dados);
    if (count($dados) > 8) {
        $top = array_slice($dados, 0, 7, true);
        $top['Outros'] = array_sum(array_slice($dados, 7, null, true)) + ($top['Outros'] ?? 0);
        $dados = $top;
    }
    $total = array_sum($dados);
    $cx = 100; $cy = 100; $r = 86; $ri = 58; $ang = -90.0;
    $o = "<svg class='ws-viz' viewBox='0 0 200 200' role='img' aria-label='Gráfico de rosca' style='width:100%;height:auto;max-width:190px;display:block'>";
    $leg = ''; $i = 0;
    foreach ($dados as $lbl => $val) {
        $frac = $val / $total; $ang2 = $ang + $frac * 360;
        $cor = ($lbl === 'Outros' && $i === 7) ? 'var(--cOutros)' : 'var(--c' . ($i + 1) . ')';
        $pct = number_format($frac * 100, 1, ',', '.');
        $tip = ws_viz_h('<b>' . ws_viz_h($lbl) . '</b><br>' . number_format($val, 0, ',', '.') . " · $pct%");
        if ($frac >= 0.999) {
            $o .= "<g class='vz-hit' data-tip=\"$tip\"><circle cx='$cx' cy='$cy' r='" . (($r + $ri) / 2) . "' fill='none' stroke='$cor' stroke-width='" . ($r - $ri) . "'/></g>";
        } else {
            $a1 = deg2rad($ang); $a2 = deg2rad($ang2); $large = ($ang2 - $ang) > 180 ? 1 : 0;
            $p = fn($rr, $a) => round($cx + $rr * cos($a), 2) . ',' . round($cy + $rr * sin($a), 2);
            $d = 'M' . $p($r, $a1) . " A$r,$r 0 $large 1 " . $p($r, $a2) . ' L' . $p($ri, $a2) . " A$ri,$ri 0 $large 0 " . $p($ri, $a1) . ' Z';
            // Traço na cor da superfície = a separação de 2px entre fatias (nunca borda escura).
            $o .= "<g class='vz-hit' data-tip=\"$tip\"><path class='vz-bar' d='$d' fill='$cor' stroke='var(--surface)' stroke-width='2' stroke-linejoin='round'/></g>";
        }
        $leg .= "<div><i style='background:$cor'></i><span>" . ws_viz_h($lbl) . "</span><em>" . number_format($val, 0, ',', '.') . " · $pct%</em></div>";
        $ang = $ang2; $i++;
    }
    $o .= "<text x='$cx' y='" . ($cy - 2) . "' text-anchor='middle' fill='var(--text)' font-size='22' font-weight='700'>" . number_format($total, 0, ',', '.') . "</text>";
    $o .= "<text x='$cx' y='" . ($cy + 16) . "' text-anchor='middle' fill='var(--muted)' font-size='10.5'>total</text></svg>";
    return ws_viz_assets() . "<div class='ws-donut ws-viz'><div style='flex:none;width:190px;max-width:100%'>$o</div><div class='ws-donut-leg'>$leg</div></div>";
}

/** Duas séries lado a lado (ex.: Recebido x Previsto, Ativações x Desativações). */
function ws_svg_barras2(array $labels, array $a, array $b, string $labA, string $labB, ?callable $fmt = null, int $wBase = 720): string {
    $labels = array_values($labels); $a = array_values($a); $b = array_values($b);
    if (!$labels) return '';
    $fmt = $fmt ?: fn($x) => number_format((float)$x, 0, ',', '.');
    $n = count($labels);
    // Espaço POR grupo (não largura total fixa) — com muitos meses os rótulos não se sobrepõem.
    $pl = 58; $pr = 12; $pt = 16; $pb = 26;
    $w = max($wBase, (int)($pl + $pr + $n * 56)); $h = 230;
    $top = ws_viz_nice(max(max($a ?: [0]), max($b ?: [0]), 1));
    $areaH = $h - $pt - $pb;
    $yv = fn($x) => $pt + (1 - $x / $top) * $areaH;
    $slot = ($w - $pl - $pr) / $n; $bw = min(24, $slot * 0.34); $gap = 2;
    $leg = "<div class='ws-viz-leg'><span><i style='background:var(--c1)'></i>" . ws_viz_h($labA) . "</span><span><i style='background:var(--c2)'></i>" . ws_viz_h($labB) . "</span></div>";
    $o = ws_viz_assets() . "<div class='ws-viz'>$leg<svg viewBox='0 0 $w $h' role='img' aria-label='Gráfico comparativo' style='width:100%;height:auto;max-width:800px;margin:0 auto;display:block'>";
    for ($g = 0; $g <= 4; $g++) {
        $tv = $top * $g / 4; $gy = round($yv($tv), 1);
        $o .= "<line x1='$pl' y1='$gy' x2='" . ($w - $pr) . "' y2='$gy' stroke='var(--border)' stroke-width='1'/>";
        $o .= "<text x='" . ($pl - 8) . "' y='" . ($gy + 3.5) . "' fill='var(--muted)' font-size='10' text-anchor='end'>" . ws_viz_h($fmt($tv)) . "</text>";
    }
    $y0 = round($yv(0), 1);
    $passoRot = max(1, (int)ceil($n / 14));
    foreach ($labels as $i => $lb) {
        $va = (float)($a[$i] ?? 0); $vb = (float)($b[$i] ?? 0);
        $x0 = $pl + $i * $slot + ($slot - (2 * $bw + $gap)) / 2;
        $tip = ws_viz_h('<b>' . ws_viz_h($lb) . '</b><br>' . ws_viz_h($labA) . ': <b>' . ws_viz_h($fmt($va)) . '</b><br>' . ws_viz_h($labB) . ': <b>' . ws_viz_h($fmt($vb)) . '</b>');
        $o .= "<g class='vz-hit' data-tip=\"$tip\"><rect x='" . round($pl + $i * $slot, 1) . "' y='$pt' width='" . round($slot, 1) . "' height='$areaH' fill='transparent'/>"
            . ws_viz_bar($x0, $yv($va), $bw, $y0 - $yv($va), 'var(--c1)')
            . ws_viz_bar($x0 + $bw + $gap, $yv($vb), $bw, $y0 - $yv($vb), 'var(--c2)') . "</g>";
        if ($i % $passoRot === 0 || $i === $n - 1)
            $o .= "<text x='" . round($x0 + $bw + $gap / 2, 1) . "' y='" . ($h - $pb + 15) . "' fill='var(--muted)' font-size='10.5' text-anchor='middle'>" . ws_viz_h($lb) . "</text>";
    }
    $o .= "<line x1='$pl' y1='$y0' x2='" . ($w - $pr) . "' y2='$y0' stroke='var(--muted)' stroke-width='1' opacity='.6'/>";
    return $o . "</svg></div>";
}


/* ======================================================================================================
 * DASHBOARD DE GRÁFICOS (16/10/2026) — um só lugar para erp.php e crm.php (antes o mesmo bloco estava copiado nos dois).
 * Cada cartão: gráfico maior e legível (eixos com valores e nomes, valores nos pontos/barras), faixa com os números-chave
 * (agora, média, melhor, variação) e o mesmo tooltip de sempre. Dados sempre do banco; nada é estimado.
 * ====================================================================================================== */
function ws_dashboard_graficos(PDO $db): void {
    $rs  = fn($x) => 'R$ ' . number_format((float)$x, 2, ',', '.');
    $rsk = fn($x) => 'R$ ' . ($x >= 1000 ? number_format($x / 1000, 1, ',', '.') . 'k' : number_format($x, 0, ',', '.'));
    $mes = fn($ym) => substr($ym, 5, 2) . '/' . substr($ym, 2, 2);
    $stat = function (array $itens): string { $o = '<div class="ws-dash-stats">'; foreach ($itens as [$v, $t, $cor]) $o .= '<div><b' . ($cor ? ' style="color:' . $cor . '"' : '') . '>' . $v . '</b><span>' . $t . '</span></div>'; return $o . '</div>'; };
    $caixa = function (string $titulo, string $badge, string $corpo, string $extra = '') { return '<div class="ws-chart-box ' . $extra . '"><h3><span>' . $titulo . '</span><span class="badge">' . $badge . '</span></h3>' . $corpo . '</div>'; };
    echo '<style>.ws-dashboard-grid{grid-template-columns:repeat(auto-fit,minmax(min(440px,100%),1fr))!important}.ws-dashboard-grid .ws-span2{grid-column:span 2}@media(max-width:1000px){.ws-dashboard-grid .ws-span2{grid-column:auto}}'
       . '.ws-dash-stats{display:flex;flex-wrap:wrap;gap:8px 18px;margin:10px 0 0;padding-top:10px;border-top:1px solid var(--border)}.ws-dash-stats div{display:flex;flex-direction:column;min-width:70px}.ws-dash-stats b{font-size:15px;font-variant-numeric:tabular-nums}.ws-dash-stats span{font-size:11px;color:var(--muted)}'
       . '.ws-plano-tab{width:100%;border-collapse:collapse;margin-top:6px;font-size:13px}.ws-plano-tab th{font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);text-align:right;padding:4px 6px;border-bottom:1px solid var(--border)}.ws-plano-tab th:first-child,.ws-plano-tab td:first-child{text-align:left}.ws-plano-tab td{padding:5px 6px;border-bottom:1px solid var(--border);text-align:right;font-variant-numeric:tabular-nums}'
       . '.ws-plano-bar{display:inline-block;height:8px;border-radius:4px;background:var(--brand);vertical-align:middle;min-width:2px}.ws-plano-tab i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:7px;vertical-align:-1px}'
       . '.ws-plano-wrap.ws-plano-fecha{max-height:262px;overflow:hidden;position:relative}.ws-plano-wrap.ws-plano-fecha::after{content:"";position:absolute;left:0;right:0;bottom:0;height:46px;background:linear-gradient(180deg,transparent,var(--surface));pointer-events:none}.ws-plano-mais{text-align:center;padding-top:8px}</style>';
    echo '<div class="ws-dashboard-grid">';

    // ---- Clientes online (snapshots do cron) ----
    $hist = $db->query("SELECT ts, online FROM (SELECT id,ts,online FROM ws_online_hist ORDER BY id DESC LIMIT 48) t ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
    if ($hist) {
        $vals = array_map(fn($r) => (int)$r['online'], $hist); $labs = array_map(fn($r) => date('H:i', strtotime((string)$r['ts'])), $hist);
        $agora = end($vals); $pico = max($vals); $min = min($vals); $media = (int)round(array_sum($vals) / count($vals));
        $iPico = array_search($pico, $vals, true); $iMin = array_search($min, $vals, true);
        echo $caixa('📡 Clientes Online', 'últimas ' . count($vals) . ' leituras', ws_svg_linha($vals, $labs, fn($x) => number_format($x, 0, ',', '.'), 520, 230)
            . $stat([[$agora, 'agora (' . end($labs) . ')', ''], [$pico, 'pico às ' . $labs[$iPico], 'var(--ok)'], [$min, 'mínimo às ' . $labs[$iMin], 'var(--err)'], [$media, 'média', '']]));
    } else {
        echo $caixa('📡 Clientes Online', 'Snapshots', '<p class="ws-muted" style="font-size:13px;padding:20px 0;text-align:center">O gráfico de online aparece quando o cron <code>radius_sync.php</code> começar a rodar.</p>');
    }

    // ---- Faturamento: recebido x previsto, 6 meses ----
    $meses = []; for ($i = 5; $i >= 0; $i--) $meses[] = date('Y-m', strtotime(date('Y-m-01') . " -$i months"));
    $rec = array_fill_keys($meses, 0.0); $prv = $rec;
    foreach ($db->query("SELECT DATE_FORMAT(data_pgto,'%Y-%m') m, SUM(valor_pago) v FROM ws_pagamento WHERE data_pgto >= '" . $meses[0] . "-01' GROUP BY m")->fetchAll() as $r) if (isset($rec[$r['m']])) $rec[$r['m']] = (float)$r['v'];
    try { foreach ($db->query("SELECT DATE_FORMAT(vencimento,'%Y-%m') m, SUM(valor + COALESCE(taxa_emissao,0)) v FROM ws_fatura WHERE vencimento >= '" . $meses[0] . "-01' AND vencimento <= LAST_DAY(CURDATE()) AND (status='pago' OR (status IN ('aberto','vencido','processando')" . ws_sql_fatura_viva('ws_fatura') . ")) GROUP BY m")->fetchAll() as $r) if (isset($prv[$r['m']])) $prv[$r['m']] = (float)$r['v']; } catch (Throwable $e) {}
    $totRec = array_sum($rec); $melhorM = array_search(max($rec), $rec, true); $mediaRec = $totRec / count($rec); $totPrv = array_sum($prv);
    echo $caixa('💰 Faturamento', '6 meses', ws_svg_barras2(array_map($mes, $meses), array_values($rec), array_values($prv), 'Recebido', 'Previsto', $rsk, 480)
        . $stat([[$rs($totRec), 'recebido em 6 meses', ''], [$rs($mediaRec), 'média por mês', ''], [$mes($melhorM) . ' · ' . $rs($rec[$melhorM]), 'melhor mês', 'var(--ok)'], [$totPrv > 0 ? number_format($totRec / $totPrv * 100, 1, ',', '.') . '%' : '—', 'recebido ÷ previsto', '']]));

    // ---- Ticket médio mensal ----
    $tm = []; try { $tm = $db->query("SELECT DATE_FORMAT(data_pagamento,'%Y-%m') m, AVG(COALESCE(valor_pago,valor)) v FROM ws_fatura WHERE status='pago' AND data_pagamento >= '" . $meses[0] . "-01' GROUP BY m ORDER BY m")->fetchAll(); } catch (Throwable $e) {}
    if ($tm) {
        $tv = array_map(fn($r) => round((float)$r['v'], 2), $tm); $tl = array_map(fn($r) => $mes($r['m']), $tm);
        $atual = end($tv); $ant = $tv[count($tv) - 2] ?? null; $var = ($ant !== null && $ant > 0) ? round((($atual - $ant) / $ant) * 100, 1) : null;
        echo $caixa('📈 Ticket Médio Mensal', $var !== null ? '<span style="color:' . ($var >= 0 ? 'var(--ok)' : 'var(--err)') . '">' . ($var >= 0 ? '+' : '') . $var . '% vs mês anterior</span>' : 'mensal', ws_svg_linha($tv, $tl, $rs, 520, 230)
            . $stat([[$rs($atual), 'mês atual (' . end($tl) . ')', ''], [$ant !== null ? $rs($ant) : '—', 'mês anterior', ''], [$rs(array_sum($tv) / count($tv)), 'média do período', ''], [$rs(max($tv)), 'maior ticket', 'var(--ok)']]));
    }

    // ---- Saldo em conta (acumulado no ano; zera na virada) ----
    $sm = $db->query("SELECT DATE_FORMAT(data_pgto,'%Y-%m') m, SUM(valor_pago) v FROM ws_pagamento WHERE data_pgto >= DATE_FORMAT(CURDATE(),'%Y-01-01') GROUP BY m ORDER BY m")->fetchAll();
    if ($sm) {
        $acc = 0.0; $sv = []; $sl = []; foreach ($sm as $r) { $acc += (float)$r['v']; $sv[] = round($acc, 2); $sl[] = $mes($r['m']); }
        $noMes = (float)end($sm)['v'];
        echo $caixa('💳 Saldo em Conta', 'acumulado em ' . date('Y'), ws_svg_linha($sv, $sl, $rsk, 520, 230)
            . $stat([[$rs(end($sv)), 'acumulado no ano', ''], [$rs($noMes), 'entrou em ' . end($sl), 'var(--ok)'], [$rs(end($sv) / count($sv)), 'média por mês', '']]));
    }

    // ---- Planos ativos: clientes por plano ----
    $planos = []; try { $planos = $db->query("SELECT p.nome, p.valor, COUNT(*) n FROM ws_contrato ct JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.status='ativo' GROUP BY p.id ORDER BY n DESC")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) {}
    if ($planos) {
        $totC = array_sum(array_column($planos, 'n')); $maxN = max(array_column($planos, 'n')); $fat = 0.0; foreach ($planos as $p) $fat += (float)$p['valor'] * (int)$p['n'];
        $dados = []; foreach ($planos as $p) $dados[$p['nome']] = (int)$p['n'];
        $tab = '<table class="ws-plano-tab"><thead><tr><th>Plano</th><th>Clientes</th><th>%</th><th style="text-align:left;width:26%"></th><th>Mensalidade</th></tr></thead><tbody>';
        foreach ($planos as $i => $p) { $c = $i < 7 ? 'var(--c' . ($i + 1) . ')' : 'var(--cOutros)'; $pc = $p['n'] / $totC * 100;
            $tab .= '<tr><td><i style="background:' . $c . '"></i>' . ws_viz_h($p['nome']) . '</td><td><b>' . number_format($p['n'], 0, ',', '.') . '</b></td><td>' . number_format($pc, 1, ',', '.') . '%</td><td style="text-align:left"><span class="ws-plano-bar" style="width:' . max(2, round($p['n'] / $maxN * 100)) . '%;background:' . $c . '"></span></td><td>' . $rs($p['valor']) . '</td></tr>'; }
        $tab .= '<tr style="font-weight:800"><td>Total</td><td>' . number_format($totC, 0, ',', '.') . '</td><td>100%</td><td></td><td>' . $rs($fat) . '/mês</td></tr></tbody></table>';
        /* PLANOS ATIVOS COMPACTO (21/11/2026, pedido do dono): o cartão ficava bem mais alto que os do lado (Balanço de Clientes / Balanço Geral). Agora fica na MESMA altura deles e só expande ao clicar em "Ver todos os N planos"; com 5 planos ou menos aparece inteiro. */
        $corpoPl = '<div class="ws-plano-wrap' . (count($planos) > 5 ? ' ws-plano-fecha' : '') . '" id="wsPlanoWrap"><div style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start"><div style="flex:0 0 190px;max-width:100%">' . ws_svg_pizza_solo($dados) . '</div><div class="ws-viz" style="flex:1 1 280px;min-width:0;overflow-x:auto">' . $tab . '</div></div></div>';
        $maisPl = count($planos) > 5 ? '<div class="ws-plano-mais"><button type="button" class="ws-btn" id="wsPlanoBtn" onclick="var w=document.getElementById(\'wsPlanoWrap\');var f=w.classList.toggle(\'ws-plano-fecha\');this.textContent=f?\'Ver todos os ' . count($planos) . ' planos ▾\':\'Recolher ▴\';">Ver todos os ' . count($planos) . ' planos ▾</button></div>' : '';
        echo $caixa('🎯 Planos Ativos', count($planos) . ' planos · ' . number_format($totC, 0, ',', '.') . ' clientes', $corpoPl . $maisPl, 'ws-span2');
    }

    // ---- Balanço de clientes (6 meses) ----
    $lb = []; $at = []; $ca = []; $sd = [];
    for ($i = 5; $i >= 0; $i--) {
        $mi = date('Y-m-01', strtotime("-$i months")); $mf = date('Y-m-t', strtotime("-$i months")); $lb[] = $mes(date('Y-m', strtotime($mi)));
        $a = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE data_ativacao BETWEEN '$mi' AND '$mf'")->fetchColumn();
        $c = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE status='cancelado' AND data_cancelamento BETWEEN '$mi' AND '$mf'")->fetchColumn();
        $at[] = $a; $ca[] = $c; $sd[] = $a - $c;
    }
    if (array_sum($at) + array_sum($ca) > 0) {
        $tA = array_sum($at); $tC = array_sum($ca);
        echo $caixa('👥 Balanço de Clientes', 'por mês', ws_svg_barras_n($lb, ['Instalações + Reativações' => $at, 'Cancelamentos' => $ca, 'Saldo' => $sd], null, 480)
            . $stat([[$tA, 'instalações + reativações', 'var(--ok)'], [$tC, 'cancelamentos', 'var(--err)'], [($tA - $tC >= 0 ? '+' : '') . ($tA - $tC), 'saldo em 6 meses', '']]));
        echo $caixa('⚖️ Balanço Geral', '6 meses', ws_svg_barras_n(['Total'], ['Instalações + Reativações' => [$tA], 'Cancelamentos' => [$tC], 'Saldo' => [$tA - $tC]], null, 360));
    }
    echo '</div>';
}

/** Só a rosca (sem a legenda ao lado): o cartão de Planos mostra a tabela completa no lugar. */
function ws_svg_pizza_solo(array $dados): string {
    $html = ws_svg_pizza($dados);
    if (preg_match('#<svg.*?</svg>#s', $html, $m)) return ws_viz_assets() . '<div class="ws-viz">' . $m[0] . '</div>';
    return $html;
}
