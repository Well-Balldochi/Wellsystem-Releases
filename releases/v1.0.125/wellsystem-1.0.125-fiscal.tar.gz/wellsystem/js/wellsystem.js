/* WellSystem — roda a função quando o DOM está pronto. Se o DOMContentLoaded JÁ passou (ex.: o JS
   veio do cache e executou depois do evento), roda na hora — senão o menu/máscaras não montavam
   ao abrir a página (parecia "não funcionar" no Painel até navegar para outra tela). */
function wsReady(fn) {
  function run() { try { fn(); } catch (e) { if (window.console) console.error('WellSystem init falhou:', e); } }
  if (document.readyState !== 'loading') run(); else document.addEventListener('DOMContentLoaded', run);
}
/* localStorage à prova de exceção: em alguns contextos (HTTP, iframe, storage bloqueado) o acesso
   direto LANÇA erro e travava o script inteiro. Estes wrappers nunca lançam. */
function wsLSget(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function wsLSset(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

/* HOVER do menu por DELEGAÇÃO no documento — registrado UMA vez, no carregamento do script, e
   funciona para QUALQUER .ws-grp (mesmo os criados depois, em qualquer carga da página). Assim o
   dropdown abre ao passar o mouse já na PRIMEIRA abertura do Painel, sem depender de handler
   individual por item (que às vezes não estava pegando na 1ª carga). */
    // ALTURA REAL DO TOPO -> --ws-topo-h
    // Camadas em position:fixed (o gerenciador da OLT é uma delas) cobrem a tela inteira,
    // inclusive a navegação do sistema — e a tela passa a parecer "outra página". Publicando a
    // altura medida do topo numa variável CSS, essas camadas conseguem começar ABAIXO dele e a
    // navegação continua visível. Medido, não fixo no código: o topo muda de altura conforme a
    // largura da tela e o menu de cidades.
    (function () {
      function wsTopoAltura() {
        var t = document.querySelector('.ws-top-wrap') || document.querySelector('.ws-top');
        if (!t) return;
        var h = Math.round(t.getBoundingClientRect().height);
        if (h > 0) document.documentElement.style.setProperty('--ws-topo-h', h + 'px');
      }
      wsTopoAltura();
      window.addEventListener('resize', wsTopoAltura);
      window.addEventListener('load', wsTopoAltura);
      setInterval(wsTopoAltura, 1200);   // o topo muda de altura ao abrir/fechar o menu
    })();

(function () {
  function subDe(g) { return g ? g.querySelector('.ws-sub') : null; }
  function ajustarPosicao(g) {
    g.classList.remove('ws-flip');
    var sub = subDe(g); if (!sub) return;
    var prevDisplay = sub.style.display, prevVis = sub.style.visibility;
    sub.style.visibility = 'hidden'; sub.style.display = 'flex';
    var r = sub.getBoundingClientRect();
    if (r.right > window.innerWidth - 8) g.classList.add('ws-flip');
    sub.style.display = prevDisplay; sub.style.visibility = prevVis;
  }
  function abrir(g) {
    document.querySelectorAll('.ws-grp.open').forEach(function (x) {
      if (x !== g) { x.classList.remove('open'); var s = subDe(x); if (s) s.style.display = ''; }
    });
    g.classList.add('open');
    ajustarPosicao(g);
    var s = subDe(g); if (s) s.style.display = 'flex';
  }
  function fechar(g) { g.classList.remove('open'); var s = subDe(g); if (s) s.style.display = ''; }
  document.addEventListener('mouseover', function (e) {
    if (window.innerWidth <= 900) return; // no celular quem abre é o CLIQUE (acordeão), não o hover
    var alvo = e.target && e.target.closest ? e.target.closest('.ws-grp') : null;
    if (alvo) abrir(alvo);
  });
  document.addEventListener('mouseout', function (e) {
    if (window.innerWidth <= 900) return;
    var alvo = e.target && e.target.closest ? e.target.closest('.ws-grp') : null;
    if (!alvo) return;
    // Só fecha quando o mouse REALMENTE saiu do grupo (não ao mover entre o rótulo e o submenu).
    if (e.relatedTarget && alvo.contains(e.relatedTarget)) return;
    fechar(alvo);
  });
})();

/* WellSystem — Seleção em massa nos Cadastros: "marcar todas" + excluir selecionados.
   Uso: cabeçalho <input type="checkbox" onclick="wsChkAll(this)">, linhas com class "ws-chk-item"
   (name="ids[]") e o form com onsubmit="return wsDelMassa(this,'mensagem')". */
function wsChkAll(master) {
  var box = master.closest('form') || document;
  var itens = box.querySelectorAll('input.ws-chk-item');
  for (var i = 0; i < itens.length; i++) itens[i].checked = master.checked;
}
function wsDelMassa(form, msg) {
  var n = form.querySelectorAll('input.ws-chk-item:checked').length;
  if (!n) { alert('Marque pelo menos um item para excluir.'); return false; }
  return confirm((msg || 'Excluir os itens marcados?') + '\n\n(' + n + ' selecionado(s) — esta ação não pode ser desfeita.)');
}

/* WellSystem — Tema (cor + claro/escuro). Aplica o salvo e injeta o controle no topo. */
(function () {
  var root = document.documentElement;
  var cor = wsLSget('ws_cor') || window.WS_COR_PADRAO || 'vinho';
  var tema = wsLSget('ws_theme') || '';
  if (cor && cor !== 'vinho') root.setAttribute('data-cor', cor); else root.removeAttribute('data-cor');
  if (tema) root.setAttribute('data-theme', tema); else root.removeAttribute('data-theme');

  function aplicar(c, t) {
    if (c) { wsLSset('ws_cor', c); wsLSset('ws_cor_em', String(Math.max(Date.now(), (window.WS_COR_PADRAO_EM || 0) + 1))); if (c === 'vinho') root.removeAttribute('data-cor'); else root.setAttribute('data-cor', c); }
    if (t !== undefined) { wsLSset('ws_theme', t); if (t) root.setAttribute('data-theme', t); else root.removeAttribute('data-theme'); }
    marcar();
  }
  function marcar() {
    var atual = wsLSget('ws_cor') || window.WS_COR_PADRAO || 'vinho';
    document.querySelectorAll('.ws-tema b').forEach(function (b) { b.classList.toggle('on', b.dataset.cor === atual); });
  }
  wsReady(function () {
    // 1) Controle de tema (cores + claro/escuro) — isolado: se falhar, NÃO leva o rodapé junto.
    try {
      var top = document.querySelector('.ws-top-l1 .ws-user') || document.querySelector('.ws-top-l1') || document.querySelector('.ws-top');
      // Já existe o controle novo no cabeçalho (ws-btn-cor-top, ícone SVG) em toda página — só cai
      // pro botão de emergência (🎨 antigo) se o cabeçalho de verdade não tiver carregado.
      if (top && !document.body.classList.contains('ws-portal') && !document.querySelector('.ws-tema') && !document.querySelector('.ws-btn-cor-top')) {   // portal do assinante não usa o botão de emergência
        var box = document.createElement('span'); box.className = 'ws-tema';
        box.innerHTML = '<button type="button" class="ws-tema-btn" title="Aparência (cor e claro/escuro)">🎨</button>'
                      + '<span class="ws-tema-pop">'
                      + '<b class="c-vinho" data-cor="vinho" title="Vinho"></b>'
                      + '<b class="c-azul" data-cor="azul" title="Azul"></b>'
                      + '<b class="c-preto" data-cor="preto" title="Preto"></b>'
                      + '<b class="c-verde" data-cor="verde" title="Verde"></b>'
                      + '<button type="button" class="ws-tema-claroescuro" title="Claro/Escuro">🌓</button>'
                      + '</span>';
        box.querySelectorAll('b').forEach(function (b) { b.onclick = function () { aplicar(b.dataset.cor); }; });
        box.querySelector('.ws-tema-claroescuro').onclick = function () {
          var t = wsLSget('ws_theme');
          var isDark = t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme:dark)').matches);
          aplicar(undefined, isDark ? 'light' : 'dark');
        };
        box.querySelector('.ws-tema-btn').onclick = function (e) { e.stopPropagation(); box.classList.toggle('open'); };
        document.addEventListener('click', function (e) { if (!box.contains(e.target)) box.classList.remove('open'); });
        if (top.parentNode) top.parentNode.insertBefore(box, top);
        marcar();
      }
    } catch (e) { if (window.console) console.error('WellSystem tema:', e); }
    // 2) Rodapé elegante em toda página que ainda não tem (páginas longas precisam) — isolado.
    try {
      // EMBUTIDO (iframe): NÃO injeta rodapé. A página de fora já tem o dela — injetar aqui
      // produzia DOIS rodapés empilhados, um dentro do outro. Vale para o gerenciador da OLT e
      // para qualquer outra tela que venha a ser embutida.
      var wsEmbutido = false; try { wsEmbutido = (window.top !== window); } catch (e) { wsEmbutido = true; }
      if (!wsEmbutido && document.querySelector('.ws-main') && !document.querySelector('.ws-rodape')) {
        var rod = document.createElement('footer'); rod.className = 'ws-rodape';
        var ano = new Date().getFullYear();
        rod.innerHTML = '<div class="ws-rodape-in"><span class="ws-rodape-marca">WellSystem</span>'
          + '<span class="ws-rodape-mid">ERP para provedores de internet</span>'
          + '<span class="ws-rodape-meta">© ' + ano + ' · <a href="erp.php?p=dashboard">início</a></span></div>';
        var mn = document.querySelector('.ws-main');
        if (mn && mn.parentNode) mn.parentNode.insertBefore(rod, mn.nextSibling);
      }
    } catch (e) { if (window.console) console.error('WellSystem rodapé:', e); }
  });
})();

/* WellSystem — máscaras (CPF/CNPJ, CEP, telefone, valor em R$), botões salvar verdes e aba ativa. */
(function () {
  function so(v) { return (v || '').replace(/\D/g, ''); }
  function mCpfCnpj(v) {
    v = so(v).slice(0, 14);
    if (v.length <= 11) return v.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    return v.replace(/^(\d{2})(\d)/, '$1.$2').replace(/^(\d{2}\.\d{3})(\d)/, '$1.$2').replace(/\.(\d{3})(\d)/, '.$1/$2').replace(/(\d{4})(\d{1,2})$/, '$1-$2');
  }
  function mCep(v) { return so(v).slice(0, 8).replace(/(\d{5})(\d)/, '$1-$2'); }
  function mFone(v) {
    // Com o DDI 55 na frente (12 ou 13 dígitos, como o WhatsApp usa): +55 (11) 99999-0000. Antes cortava em
    // 11 e perdia o fim do número — "5511999990000" virava "(55) 81995-9640".
    var d = so(v);
    if (d.length >= 12 && d.slice(0, 2) === '55') { d = d.slice(0, 13); var l = d.slice(2);
      return '+55 ' + (l.length > 10 ? l.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3') : l.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3')); }
    v = d.slice(0, 11);
    if (v.length <= 10) return v.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{4})(\d)/, '$1-$2');
    return v.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d)/, '$1-$2');
  }
  // Máscara de dinheiro (R$): formata progressivamente enquanto digita (só os dígitos contam,
  // os 2 últimos são sempre os centavos) — ex.: digitar "199900" vira "1.999,00". O valor do
  // campo continua no formato "1.234,56" (sem "R$" dentro), igual o resto do código já espera
  // ao converter pra float — o "R$" aparece só visualmente, num rótulo do lado do campo.
  function mMoney(v) {
    var d = so(v).replace(/^0+(?=\d)/, '');
    if (d === '') return '';
    while (d.length < 3) d = '0' + d;
    var cents = d.slice(-2), whole = d.slice(0, -2).replace(/^0+(?=\d)/, '') || '0';
    whole = whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return whole + ',' + cents;
  }
  function isMoneyField(el) {
    if (el.dataset.wsNoMoney) return false; // escape hatch: data-ws-no-money="1" pra campos que não são dinheiro
    if (el.dataset.wsMoney) return true;    // marcação explícita: data-ws-money="1" (campo de R$ cujo nome/id não segue o padrão)
    var s = ((el.getAttribute('name') || '') + '|' + (el.id || '')).toLowerCase();
    if (/_pct\b|percent/.test(s)) return false; // são percentuais (ex.: multa_pct, juros_pct), não dinheiro
    return /valor|pre[cç]o|mensalidade|multa|_desc\b|acre|_mm\b|_vp\b|taxa/.test(s);
  }
  /** Insere o rótulo visual "R$" do lado do campo (não mexe no value/name — só aparência). */
  function envolverComRS(el) {
    if (el.dataset.wsMoneyWrapped || el.closest('.ws-money-wrap')) return;
    var wrap = document.createElement('span'); wrap.className = 'ws-money-wrap';
    el.parentNode.insertBefore(wrap, el);
    var pre = document.createElement('span'); pre.className = 'ws-money-pre'; pre.textContent = 'R$';
    wrap.appendChild(pre); wrap.appendChild(el);
    el.dataset.wsMoneyWrapped = '1';
    el.placeholder = el.placeholder || '0,00';
  }
  function aplica(el) {
    // Só campo de TEXTO recebe máscara/"R$". Caixa de marcar com "taxa" no id (ex.: bol_taxa_zero,
    // o "Zerar") ganhava um "R$" grudado por engano; data, rádio e oculto também não são digitáveis.
    if (/^(checkbox|radio|hidden|date|datetime-local|time|month|file|submit|button|range|color)$/i.test(el.type || '')) return;
    var n = (el.getAttribute('name') || '').toLowerCase();
    var f = null;
    // RG/IE usa o MESMO padrão de preenchimento do CPF/CNPJ (agrupa os dígitos com pontos/traço).
    if (/(cpf|cnpj)/.test(n) || n === 'rg_ie' || /(^|_)rg$|(^|_)ie$/.test(n)) f = mCpfCnpj;
    else if (/cep$/.test(n)) f = mCep;
    else if (/(celular|telefone|fone|whats)/.test(n)) f = mFone;
    else if (isMoneyField(el)) f = mMoney;
    if (!f) return;
    if (f === mMoney) { el.setAttribute('inputmode', 'decimal'); envolverComRS(el); }
    /* APAGAR NA MÁSCARA (30/09/2026): a máscara reformatava o campo inteiro a cada tecla e mandava o
       cursor para o fim — Backspace em cima de "-" / ")" / "." era recolocado na hora e parecia que o
       campo "não apagava" (só selecionando). Agora (telefone, CPF/CNPJ, CEP): o cursor volta para depois
       do mesmo número de dígitos, e Backspace num separador apaga o dígito anterior. R$ segue como antes. */
    var ap = f === mMoney ? function () { el.value = f(el.value); } : function (e) {
      var val = el.value, pos = el.selectionStart == null ? val.length : el.selectionStart;
      var antes = so(val.slice(0, pos)).length, dig = so(val);
      if (e && e.inputType === 'deleteContentBackward' && el._wsAnt != null && so(el._wsAnt).length === dig.length && antes > 0) {
        dig = dig.slice(0, antes - 1) + dig.slice(antes); antes--;   // apagou só o separador: apaga o dígito de antes
        val = dig;
      }
      var nv = f(val); el.value = nv; el._wsAnt = nv;
      if (document.activeElement === el) {
        var i = 0, c = 0; while (i < nv.length && c < antes) { if (/\d/.test(nv.charAt(i))) c++; i++; }
        try { el.setSelectionRange(i, i); } catch (x) {}
      }
    };
    el.addEventListener('input', ap); if (el.value) el.value = f(el.value); el._wsAnt = el.value;
  }
  wsReady(function () {
    // Máscaras e botões verdes ISOLADOS num try próprio: se algum campo raro der erro aqui,
    // NÃO pode impedir a montagem do menu (que vem logo abaixo).
    try {
      document.querySelectorAll('input').forEach(aplica);
      // Botões de salvar/receber/confirmar em verde
      document.querySelectorAll('button, input[type=submit]').forEach(function (b) {
        var t = (b.tagName === 'INPUT' ? b.value : b.textContent) || '';
        if (/salvar|gravar|receber|confirmar|cadastrar/i.test(t) && !/cancelar|excluir|deletar/i.test(t)) b.classList.add('verde');
      });
    } catch (e) { if (window.console) console.error('WellSystem máscaras:', e); }
    // O menu (dropdowns/mega-menu) agora é montado direto em PHP (config.php → ws_nav_completo()),
    // não mais aqui em JS — evita que um erro de JS derrube o menu inteiro pra uma versão sem
    // dropdown nenhum (o que estava acontecendo). Abrir/fechar ao passar o mouse é feito pelo
    // handler delegado de mouseover/mouseout lá no topo deste arquivo.
  });
})();

/* WellSystem — ao escolher o plano, puxa o valor fixado (editável). */
function wsPlanoValor(selId, valId) {
  var s = document.getElementById(selId), v = document.getElementById(valId);
  if (!s || !v) return;
  var val = s.options[s.selectedIndex] ? s.options[s.selectedIndex].getAttribute('data-valor') : '';
  if (val) v.value = val;   // sempre traz o valor do plano; usuário pode editar
}

/* WellSystem — copiar texto (PIX copia-e-cola) para a área de transferência. */
function wsCopiar(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const txt = el.innerText || el.value || '';
  const done = () => { const o = el.dataset; alert('Copiado!'); };
  if (navigator.clipboard) navigator.clipboard.writeText(txt).then(done, () => wsCopiarFallback(txt));
  else wsCopiarFallback(txt);
}
function wsCopiarFallback(txt) {
  const t = document.createElement('textarea');
  t.value = txt; document.body.appendChild(t); t.select();
  try { document.execCommand('copy'); alert('Copiado!'); } catch (e) {}
  document.body.removeChild(t);
}

/* WellSystem — autocompletar endereço por CEP (ViaCEP) em QUALQUER formulário.
   Funciona em todo input cujo name termine em "cep" (cep, inst_cep, ...). Preenche os
   campos irmãos do MESMO formulário: <prefixo>logradouro/bairro/cidade/uf. */
(function () {
  function preencher(cepEl) {
    const v = (cepEl.value || '').replace(/\D/g, '');
    if (v.length !== 8) return;
    const form = cepEl.form || document;
    // prefixo: "cep" -> ""  |  "inst_cep" -> "inst_"
    const nome = cepEl.getAttribute('name') || 'cep';
    const pref = nome.slice(0, nome.length - 3); // remove "cep"
    const set = (suf, val) => {
      const el = form.querySelector(`[name="${pref}${suf}"]`) || document.getElementById(suf);
      if (el && !el.value) el.value = val || '';
    };
    fetch(`https://viacep.com.br/ws/${v}/json/`).then(r => r.json()).then(d => {
      if (d.erro) return;
      set('logradouro', d.logradouro);
      set('bairro', d.bairro);
      set('cidade', d.localidade);
      set('uf', d.uf);
      // Se o formulário também tem lat/long (ex.: cadastro de cliente e de conexão), geocodifica
      // o endereço resolvido automaticamente — mesma ideia do "Localizar" da tela de Cidades,
      // só que disparado sozinho ao preencher o CEP, sem precisar clicar em nada.
      const latEl = form.querySelector('[name="lat"]') || document.getElementById('lat');
      const lonEl = form.querySelector('[name="lng"]') || document.getElementById('lng');
      // Recursos do sistema → Mapas: "Auto coordenadas = Não" desliga; OpenStreet ou Google conforme escolhido.
      const autoCoord = !window.WS_MAPA || !!window.WS_MAPA.auto;
      if (autoCoord && latEl && lonEl && !latEl.value && !lonEl.value && d.localidade) {
        const q = `${d.logradouro || ''}, ${d.localidade}, ${d.uf}, Brasil`;
        const busca = window.wsGeocodificar ? window.wsGeocodificar(q)
          : fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(q)}`, {headers:{'Accept':'application/json'}})
              .then(r => r.json()).then(g => (g && g[0]) ? {lat: +g[0].lat, lon: +g[0].lon} : null);
        busca.then(p => { if (p) { latEl.value = p.lat.toFixed(7); lonEl.value = p.lon.toFixed(7); } }).catch(() => {});
      }
    }).catch(() => {});
  }
  document.addEventListener('blur', function (e) {
    const el = e.target;
    if (el && el.tagName === 'INPUT' && /cep$/i.test(el.getAttribute('name') || '')) preencher(el);
  }, true);
})();

/* Auto-Mascara */
document.addEventListener('input', function(e) {
  var t = e.target;
  if (!t || t.tagName !== 'INPUT') return;
  var n = (t.name || '').toLowerCase();
  var v = t.value;
  if (n === 'cpf_cnpj' || n === 'cpf' || n === 'cnpj') {
    v = v.replace(/\D/g, '');
    if (v.length <= 11) {
      v = v.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    } else {
      v = v.replace(/^(\d{2})(\d)/, '$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3').replace(/\.(\d{3})(\d)/, '.$1/$2').replace(/(\d{4})(\d{1,2})$/, '$1-$2');
    }
    t.value = v;
  } else if (n === 'telefone' || n === 'celular' || n === 'whatsapp') {
    v = v.replace(/\D/g, '');
    if (v.length >= 12 && v.slice(0, 2) === '55') {           // com DDI: não corta (ver mFone)
      var l = v.slice(2, 13);
      t.value = '+55 ' + (l.length > 10 ? l.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3') : l.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3'));
    } else if (v.length > 10) {
      t.value = v.replace(/^(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
    } else if (v.length > 5) {
      t.value = v.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, '($1) $2-$3');
    } else if (v.length > 2) {
      t.value = v.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
    }
  } else if (n === 'cep') {
    v = v.replace(/\D/g, '');
    t.value = v.replace(/^(\d{5})(\d{1,3}).*/, '$1-$2');
  } else if (n === 'valor' || n.indexOf('valor_') === 0 || n === 'taxa_emissao') {
    var nums = v.replace(/\D/g, '');
    if (nums) {
      var val = (parseInt(nums, 10) / 100).toFixed(2).replace('.', ',');
      t.value = val.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    }
  } else if (n === 'uf' || n === 'estado') {
    t.value = v.replace(/[^A-Za-z]/g, '').substring(0, 2).toUpperCase();
  }
});

/* WellSystem — altura do topo (cabeçalho sticky) exposta como --ws-top-h, pra qualquer painel
   sticky (ex.: resumo da migração, barra de ações) colar LOGO ABAIXO do topo, sem ficar escondido. */
(function () {
  function ajustaTopH() {
    try {
      var top = document.querySelector('.ws-top-wrap');
      var h = top ? Math.round(top.getBoundingClientRect().height) : 0;
      document.documentElement.style.setProperty('--ws-top-h', (h || 92) + 'px');
    } catch (e) {}
  }
  ajustaTopH();   // já: o topo está lido acima deste script (evita o salto de 92px → altura real)
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ajustaTopH);
  window.addEventListener('resize', ajustaTopH);
  window.addEventListener('load', ajustaTopH);
})();

/* ===== Modais arrastáveis: segure o cabeçalho (faixa do título) e mova pra onde quiser. ===== */
(function () {
  function tornarArrastavel(modal) {
    if (modal._dragInit) return;
    /* MODAL QUE "SE MOVIA SOZINHO": os modais dentro de .ws-modal-ov já são arrastados pela "JANELA
       DOS MODAIS" (mais abaixo, com left/top). Este arraste antigo (transform) rodava junto — os dois
       se somavam, e a cada clique no cabeçalho a janela nova media a posição já deslocada pelo
       transform e pulava de novo. Aqui fica só para modal fora de .ws-modal-ov. */
    if (modal.closest('.ws-modal-ov')) { modal._dragInit = true; modal.style.transform = ''; return; }
    var alca = modal.querySelector('.ws-rc-head') || modal.querySelector('h3');
    if (!alca) return;
    modal._dragInit = true;
    alca.style.cursor = 'move';
    alca.style.touchAction = 'none';
    var ox = 0, oy = 0, bx = 0, by = 0, arrastando = false;
    alca.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button, a, input, select, textarea, label')) return; // não arrasta ao clicar em controles
      arrastando = true;
      ox = e.clientX; oy = e.clientY;
      var m = (modal.style.transform || '').match(/translate\(\s*(-?[\d.]+)px\s*,\s*(-?[\d.]+)px\s*\)/);
      bx = m ? parseFloat(m[1]) : 0; by = m ? parseFloat(m[2]) : 0;
      try { alca.setPointerCapture(e.pointerId); } catch (err) {}
      e.preventDefault();
    });
    alca.addEventListener('pointermove', function (e) {
      if (!arrastando) return;
      modal.style.transform = 'translate(' + (bx + e.clientX - ox) + 'px,' + (by + e.clientY - oy) + 'px)';
    });
    function fim() { arrastando = false; }
    alca.addEventListener('pointerup', fim);
    alca.addEventListener('pointercancel', fim);
  }
  function varrer() { document.querySelectorAll('.ws-modal').forEach(tornarArrastavel); }
  document.addEventListener('DOMContentLoaded', varrer);
  // Mensagens de sucesso/erro (flash) viram toast flutuante por 10s — visível em qualquer rolagem, fecha no clique.
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.ws-flash').forEach(function (f) {
      f.classList.add('ws-flash-toast');
      var fechar = function () { f.classList.add('hide'); setTimeout(function () { if (f.parentNode) f.parentNode.removeChild(f); }, 450); };
      var t = setTimeout(fechar, 10000);
      f.addEventListener('click', function () { clearTimeout(t); fechar(); });
    });
  });
  // Reaplica em modais que aparecem depois (abertos via clique).
  document.addEventListener('click', function () { setTimeout(varrer, 60); }, true);
})();

/* ============================================================================
   BOTÃO "VOLTAR AO TOPO" — GLOBAL (todas as páginas que carregam este JS).
   Pequeno, na cor do tema, aparece SÓ depois de rolar ~350px e some no topo.
   SVG próprio (não depende de Font Awesome). Uma única instância por página.
   ============================================================================ */
(function () {
  if (window.__wsGoTop) return; window.__wsGoTop = true;
  function init() {
    if (document.getElementById('wsGoTop')) return;
    var b = document.createElement('button');
    b.id = 'wsGoTop'; b.type = 'button'; b.className = 'ws-gotop';
    b.title = 'Voltar ao topo'; b.setAttribute('aria-label', 'Voltar ao topo');
    b.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>';
    b.addEventListener('click', function () { try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, 0); } });
    document.body.appendChild(b);
    var mostra = function () {
      var y = window.scrollY || document.documentElement.scrollTop || 0;
      if (y > 350) b.classList.add('on'); else b.classList.remove('on');
    };
    window.addEventListener('scroll', mostra, { passive: true });
    window.addEventListener('resize', mostra, { passive: true });
    mostra();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

/* =================================================================================================
 * JANELA DOS MODAIS — mover, maximizar e minimizar.
 * -------------------------------------------------------------------------------------------------
 * Todo modal do sistema usa a mesma marcação (.ws-modal-ov > .ws-modal > h3). Este trecho pega
 * QUALQUER um deles e transforma o título numa barra de janela: arrastar para mover, um botão para
 * ocupar a tela toda e outro para encolher até só a barra.
 *
 * POR QUE: formulário longo (Estoque, por exemplo) dentro de uma caixa centralizada obriga a rolar
 * às cegas em tela baixa, e não dá para conferir a lista atrás sem fechar e perder o que já foi
 * digitado. Minimizar resolve o segundo caso sem descartar nada; maximizar resolve o primeiro.
 *
 * Vale para modal criado DEPOIS do carregamento também: o observador abaixo prepara o que aparecer.
 * ============================================================================================== */
(function () {
  'use strict';

  function prepara(ov) {
    if (!ov || ov.dataset.wsJanela === '1') return;
    var cx = ov.querySelector(':scope > .ws-modal');
    if (!cx) return;
    var tit = cx.querySelector('h3');
    if (!tit) return;                       // sem título não há barra para arrastar
    ov.dataset.wsJanela = '1';

    // Envolve o <h3> numa barra e acrescenta os dois botões, sem tocar no resto do formulário.
    var cab = document.createElement('div');
    cab.className = 'ws-modal-cab';
    tit.parentNode.insertBefore(cab, tit);
    cab.appendChild(tit);

    var bMax = document.createElement('button');
    bMax.type = 'button'; bMax.className = 'ws-modal-btn';
    bMax.title = 'Maximizar / restaurar'; bMax.setAttribute('aria-label', 'Maximizar'); bMax.textContent = '⛶';

    var bMin = document.createElement('button');
    bMin.type = 'button'; bMin.className = 'ws-modal-btn';
    bMin.title = 'Minimizar / restaurar'; bMin.setAttribute('aria-label', 'Minimizar'); bMin.textContent = '—';

    /* FECHAR (×) na barra de título. O "Cancelar" fica no fim do formulário: com a janela
       maximizada ou com muitos campos, sair exigia rolar até o fim para achá-lo. O × usa o mesmo
       caminho do Cancelar quando ele existe (respeita qualquer limpeza que a tela faça ao fechar);
       só esconde o modal na mão se não houver Cancelar. */
    var bFec = document.createElement('button');
    bFec.type = 'button'; bFec.className = 'ws-modal-btn ws-modal-fechar';
    bFec.title = 'Fechar'; bFec.setAttribute('aria-label', 'Fechar'); bFec.textContent = '✕';
    bFec.addEventListener('click', function () {
      var alt = cx.querySelector('[onclick*="fechar"],[onclick*="Fechar"],[onclick*="display=\'none\'"]');
      if (alt) { alt.click(); return; }
      ov.style.display = 'none';
      ov.classList.remove('max', 'min', 'solta');
    });

    cab.appendChild(bMin); cab.appendChild(bMax); cab.appendChild(bFec);

    function limpaPos() {                    // volta ao centro do flex
      ov.classList.remove('solta');
      cx.style.left = ''; cx.style.top = '';
    }
    bMax.addEventListener('click', function () {
      ov.classList.remove('min');
      ov.classList.toggle('max');
      if (ov.classList.contains('max')) limpaPos();
    });
    bMin.addEventListener('click', function () {
      ov.classList.remove('max');
      ov.classList.toggle('min');
      if (ov.classList.contains('min')) limpaPos();
    });

    /* ARRASTAR pela barra de título. Pointer Events cobre mouse e toque com o mesmo código, e o
       setPointerCapture garante que soltar o botão fora da janela também encerre o arrasto — sem
       isso a janela fica "grudada" no cursor. */
    var arr = null;
    cab.addEventListener('pointerdown', function (ev) {
      if (ev.target.closest('.ws-modal-btn')) return;      // clique nos botões não arrasta
      if (ov.classList.contains('max') || ov.classList.contains('min')) return;
      var r = cx.getBoundingClientRect();
      ov.classList.add('solta');
      cx.style.left = r.left + 'px';
      cx.style.top  = r.top  + 'px';
      arr = { dx: ev.clientX - r.left, dy: ev.clientY - r.top };
      cab.setPointerCapture(ev.pointerId);
      ev.preventDefault();
    });
    cab.addEventListener('pointermove', function (ev) {
      if (!arr) return;
      // Presa à tela: pelo menos 60px da barra continuam visíveis, senão dá para "perder" a janela.
      var x = Math.min(Math.max(ev.clientX - arr.dx, -(cx.offsetWidth - 60)), window.innerWidth - 60);
      var y = Math.min(Math.max(ev.clientY - arr.dy, 0), window.innerHeight - 40);
      cx.style.left = x + 'px';
      cx.style.top  = y + 'px';
    });
    ['pointerup', 'pointercancel'].forEach(function (e) {
      cab.addEventListener(e, function () { arr = null; });
    });
  }

  function varrer() { document.querySelectorAll('.ws-modal-ov').forEach(prepara); }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', varrer);
  else varrer();

  // Modal criado por JS depois da carga (vários módulos fazem isso) também ganha os controles.
  try {
    new MutationObserver(varrer).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* navegador antigo: os modais do HTML inicial já foram preparados acima */ }
})();

/* =================================================================================================
 * CAMPO DE DINHEIRO — digitação da esquerda para a direita.
 * -------------------------------------------------------------------------------------------------
 * Num campo de texto comum, "R$ 5,00" obriga o operador a apagar o zero, posicionar o cursor e
 * lembrar da vírgula. Aqui ele só digita os números e o valor se monta sozinho a partir dos
 * centavos: 5 -> 0,05 · 50 -> 0,50 · 500 -> 5,00 · 12345 -> 123,45. Backspace desfaz na mesma
 * ordem. O cursor fica sempre no fim, que é onde o próximo dígito entra.
 *
 * Formato de saída: "1.234,56" — exatamente o que o PHP do Estoque já sabe normalizar ao salvar.
 * Aplica-se a qualquer <input class="ws-moeda">, sem o campo precisar saber nada disso.
 * ============================================================================================== */
(function () {
  'use strict';

  function formata(centavos) {
    var s = String(Math.max(0, centavos));
    while (s.length < 3) s = '0' + s;                       // garante ao menos "0,0X"
    var reais = s.slice(0, -2), cent = s.slice(-2);
    reais = reais.replace(/\B(?=(\d{3})+(?!\d))/g, '.');    // milhar: 1234 -> 1.234
    return reais + ',' + cent;
  }

  function liga(el) {
    if (!el || el.dataset.wsMoeda === '1') return;
    el.dataset.wsMoeda = '1';

    function aplica() {
      var so = (el.value || '').replace(/\D/g, '');
      // 12 dígitos = até 9.999.999.999,99. Sem o corte, colar um texto qualquer viraria um número
      // absurdo em vez de um valor.
      if (so.length > 12) so = so.slice(0, 12);
      el.value = formata(parseInt(so || '0', 10));
      // Cursor sempre no fim: é para lá que vai o próximo dígito, e evita o salto que acontece
      // quando o navegador tenta preservar a posição depois de reescrever o texto.
      try { var n = el.value.length; el.setSelectionRange(n, n); } catch (e) {}
    }

    /* CURSOR SEMPRE NO FIM — em qualquer forma de entrar no campo.
       Num campo de dinheiro o próximo dígito SEMPRE entra pela direita. Deixar o cursor cair onde
       o clique aconteceu (no meio de "1.234,56") faz o número seguinte aparecer no lugar errado e
       o valor virar outro sem o operador perceber. Por isso vale para foco, clique e toque —
       clicar no meio não é intenção de editar o meio, é só onde o dedo/mouse caiu.
       O setTimeout no clique existe porque o navegador posiciona o cursor DEPOIS do evento:
       mover antes disso não teria efeito. */
    function aoFim() { try { var n = el.value.length; el.setSelectionRange(n, n); } catch (e) {} }
    el.addEventListener('input', aplica);
    el.addEventListener('focus', aoFim);
    el.addEventListener('click', function () { setTimeout(aoFim, 0); });
    el.addEventListener('mouseup', function (ev) { ev.preventDefault(); setTimeout(aoFim, 0); });
    if ((el.value || '').trim() !== '') aplica();           // normaliza o que já veio preenchido
  }

  function varrer() { document.querySelectorAll('input.ws-moeda').forEach(liga); }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', varrer);
  else varrer();
  try {
    new MutationObserver(varrer).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* navegador antigo: os campos do HTML inicial já foram ligados */ }
})();

/* =================================================================================================
 * TEMPO DE CONEXÃO AO VIVO — leitura e dica que CONTA na tela.
 * -------------------------------------------------------------------------------------------------
 * Duas telas precisam do mesmo tempo correndo (a ficha do contrato e a coluna Situação da lista de
 * Clientes), então a conversão mora aqui, num lugar só.
 *
 * A dica NÃO usa o title do navegador de propósito: o title é desenhado uma vez, no instante em que
 * o mouse para em cima, e não muda mais enquanto está aberto — o relógio ficaria congelado
 * justamente enquanto a pessoa olha para ele. Esta dica é um elemento da página, e por isso pode
 * ser reescrita a cada segundo.
 * ============================================================================================== */
/** "02:38:04", "3d 02:38:04" ou "1.02:38:04" -> segundos (ou null). */
function wsUptimeSeg(txt) {
  txt = String(txt || '').trim(); if (!txt) return null;
  var dias = 0, m = txt.match(/^(\d+)\s*[d.]\s*(.+)$/i);
  if (m) { dias = parseInt(m[1], 10); txt = m[2]; }
  var p = txt.split(':').map(function (x) { return parseInt(x, 10) || 0; });
  if (p.length < 2) return null;
  var h  = p.length === 3 ? p[0] : 0,
      mi = p.length === 3 ? p[1] : p[0],
      s  = p.length === 3 ? p[2] : p[1];
  return dias * 86400 + h * 3600 + mi * 60 + s;
}
/** segundos -> "3d 02:38:04". */
function wsUptimeTxt(t) {
  t = Math.max(0, Math.floor(t));
  var d = Math.floor(t / 86400); t -= d * 86400;
  var h = Math.floor(t / 3600);  t -= h * 3600;
  var mi = Math.floor(t / 60),   s = t - mi * 60;
  var dp = function (n) { return (n < 10 ? '0' : '') + n; };
  return (d > 0 ? d + 'd ' : '') + dp(h) + ':' + dp(mi) + ':' + dp(s);
}

(function () {
  'use strict';
  var cx = null, alvo = null, tick = null;

  function caixa() {
    if (cx) return cx;
    cx = document.createElement('div');
    cx.className = 'ws-tip-live';
    document.body.appendChild(cx);
    return cx;
  }
  function texto(el) {
    var base = el.dataset.tipBase || '';
    var seg  = parseInt(el.dataset.tipSeg || '', 10);
    var em   = parseInt(el.dataset.tipEm  || '', 10);
    if (isNaN(seg)) return base || 'Sem sessão ativa no concentrador';
    // Soma o tempo passado desde a leitura: entre uma consulta e outra o relógio continua andando.
    var agora = seg + (em ? Math.floor((Date.now() - em) / 1000) : 0);
    return (base ? base + ' · ' : '') + 'Conectado há ' + wsUptimeTxt(agora);
  }
  function mostrar(el, ev) {
    alvo = el;
    var c = caixa();
    c.textContent = texto(el);
    c.style.display = 'block';
    var r = el.getBoundingClientRect();
    // Acima do elemento; se não couber (linha no topo da tela), desce para baixo dele.
    var top = r.top - c.offsetHeight - 8;
    if (top < 4) top = r.bottom + 8;
    var left = Math.min(Math.max(4, r.left), window.innerWidth - c.offsetWidth - 4);
    c.style.top = (top + window.scrollY) + 'px';
    c.style.left = (left + window.scrollX) + 'px';
    if (tick) clearInterval(tick);
    tick = setInterval(function () { if (alvo === el) c.textContent = texto(el); }, 1000);
  }
  function esconder() {
    alvo = null;
    if (tick) { clearInterval(tick); tick = null; }
    if (cx) cx.style.display = 'none';
  }

  // Delegação: vale para linhas que ainda nem existem quando o script carrega (paginação, filtro).
  document.addEventListener('mouseover', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-tip-live]') : null;
    if (el && el !== alvo) mostrar(el, e);
  });
  document.addEventListener('mouseout', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-tip-live]') : null;
    if (el && (!e.relatedTarget || !el.contains(e.relatedTarget))) esconder();
  });
  window.addEventListener('scroll', esconder, { passive: true });
})();

/* =================================================================================================
 * MODAL DE EXCLUSÃO DE TÍTULO — wsExcluirTitulo()
 * -------------------------------------------------------------------------------------------------
 * Chamado pelos botões "Excluir" nas páginas crm.php e erp.php (página do cliente, seção Títulos).
 * Abre um modal com dois campos: Motivo (texto livre, obrigatório) e Senha do operador logado.
 * Ao confirmar, envia um POST para a URL informada com os campos informados — nunca faz GET.
 *
 * Uso: wsExcluirTitulo({ url, titulo, mensagem, campos })
 *   url     — para onde POST vai (ex.: 'crm.php' ou 'erp.php')
 *   titulo  — texto do <h3> do modal
 *   mensagem — aviso de atenção exibido no topo do modal
 *   campos  — objeto com os campos hidden a incluir no POST (ex.: {acao, del_fatura, cliente})
 * ============================================================================================== */
function wsExcluirTitulo(opts) {
  'use strict';
  opts = opts || {};
  var url     = opts.url     || '';
  var titulo  = opts.titulo  || 'Excluir título';
  var msg     = opts.mensagem || 'Esta ação não pode ser desfeita.';
  var campos  = opts.campos  || {};

  // Remove modal anterior se houver (reuso seguro em múltiplos cliques)
  var anterior = document.getElementById('wsExcluirTituloOv');
  if (anterior) anterior.parentNode.removeChild(anterior);

  // Monta campos hidden
  var hiddens = '';
  Object.keys(campos).forEach(function (k) {
    hiddens += '<input type="hidden" name="' + k + '" value="' + String(campos[k]).replace(/"/g, '&quot;') + '">';
  });

  // Cria overlay + modal
  var ov = document.createElement('div');
  ov.id = 'wsExcluirTituloOv';
  ov.className = 'ws-modal-ov';
  ov.style.cssText = 'display:flex;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.55);align-items:center;justify-content:center;';
  ov.innerHTML =
    '<div class="ws-modal" style="background:var(--surface,#fff);color:var(--text,#1f2937);border:1px solid var(--border,#e5e7eb);'
    + 'border-radius:14px;padding:24px 28px;min-width:340px;max-width:460px;width:94vw;box-shadow:0 12px 40px rgba(0,0,0,.3)">'
    + '<h3 style="margin:0 0 12px;font-size:17px;color:var(--err,#dc2626)">' + titulo + '</h3>'
    + '<p style="margin:0 0 16px;font-size:13.5px;color:var(--muted,#6b7280)">⚠️ ' + msg + '</p>'
    + '<form id="wsExcluirTituloForm" method="post" action="' + url + '">'
    + hiddens
    + '<label style="display:block;margin-bottom:14px">'
    + '<span style="font-size:13px;font-weight:600;display:block;margin-bottom:4px">Motivo da exclusão <span style="color:var(--err,#dc2626)">*</span></span>'
    + '<input id="wsExcluirMotivo" name="motivo" type="text" required maxlength="250" autocomplete="off" '
    + 'placeholder="Ex.: emitido em duplicidade, valor errado…" '
    + 'style="width:100%;padding:9px 11px;border:1px solid var(--border,#e5e7eb);border-radius:9px;font-size:14px;background:var(--surface,#fff);color:var(--text,#1f2937)">'
    + '</label>'
    + '<label style="display:block;margin-bottom:20px">'
    + '<span style="font-size:13px;font-weight:600;display:block;margin-bottom:4px">Sua senha <span style="color:var(--err,#dc2626)">*</span></span>'
    + '<input id="wsExcluirSenha" name="senha" type="password" required autocomplete="current-password" '
    + 'placeholder="Senha do operador logado" '
    + 'style="width:100%;padding:9px 11px;border:1px solid var(--border,#e5e7eb);border-radius:9px;font-size:14px;background:var(--surface,#fff);color:var(--text,#1f2937)">'
    + '</label>'
    + '<div style="display:flex;gap:10px;justify-content:flex-end">'
    + '<button type="button" id="wsExcluirCancelar" '
    + 'style="padding:9px 20px;border:1px solid var(--border,#e5e7eb);border-radius:9px;background:var(--surface,#fff);color:var(--muted,#6b7280);font-size:14px;cursor:pointer">Cancelar</button>'
    + '<button type="submit" '
    + 'style="padding:9px 20px;border:0;border-radius:9px;background:#dc2626;color:#fff;font-size:14px;font-weight:700;cursor:pointer">🗑️ Confirmar exclusão</button>'
    + '</div>'
    + '</form>'
    + '</div>';

  document.body.appendChild(ov);

  // Foca o motivo ao abrir
  setTimeout(function () {
    var m = document.getElementById('wsExcluirMotivo');
    if (m) m.focus();
  }, 80);

  // Fechar ao clicar no cancelar ou fora do modal
  document.getElementById('wsExcluirCancelar').addEventListener('click', function () {
    ov.parentNode.removeChild(ov);
  });
  ov.addEventListener('click', function (e) {
    if (e.target === ov) ov.parentNode.removeChild(ov);
  });

  // Validação antes do submit
  document.getElementById('wsExcluirTituloForm').addEventListener('submit', function (e) {
    var motivo = (document.getElementById('wsExcluirMotivo').value || '').trim();
    var senha  = (document.getElementById('wsExcluirSenha').value  || '').trim();
    if (!motivo) { e.preventDefault(); document.getElementById('wsExcluirMotivo').focus(); alert('Informe o motivo da exclusão.'); return; }
    if (!senha)  { e.preventDefault(); document.getElementById('wsExcluirSenha').focus();  alert('Informe sua senha.'); return; }
  });
}

/* =================================================================================================
 * ROLAGEM HORIZONTAL AUTOMÁTICA NAS TABELAS
 *
 * O PROBLEMA
 * Um ERP tem tabelas largas — a de títulos tem 8 colunas, a de recibos 11. Numa tela estreita
 * (celular, notebook pequeno, janela dividida) uma tabela mais larga que a tela não se encolhe:
 * ela EMPURRA A PÁGINA INTEIRA para o lado. O menu sai do lugar, os cards ficam desalinhados e
 * aparece uma barra de rolagem horizontal no documento todo. A tela parece "quebrada", quando o
 * problema é uma tabela só.
 *
 * POR QUE AQUI, E NÃO NO HTML DE CADA PÁGINA
 * São 61 tabelas em 12 arquivos, e 39 delas não tinham o contêiner de rolagem. Corrigir uma a uma
 * é trabalho repetido que erra na próxima tabela que alguém escrever. Aqui a regra vale para todas
 * — inclusive as que ainda não existem.
 *
 * POR QUE NÃO FOI FEITO EM CSS
 * Não dá para envolver um elemento usando só CSS, e as alternativas quebram a tabela: `display:
 * block` no <table> separa o cabeçalho do corpo e as colunas deixam de casar; `overflow-x` no
 * painel que a contém também recorta na vertical (o navegador não deixa rolar só num eixo), o que
 * cortaria menus e dicas que passam da borda.
 *
 * SEM JAVASCRIPT a tabela continua aparecendo inteira, exatamente como hoje — isto melhora, não
 * é requisito para a página funcionar.
 * ============================================================================================== */
(function () {
  function envolverTabelas() {
    var tabelas = document.querySelectorAll('table.ws-table');
    for (var i = 0; i < tabelas.length; i++) {
      var t = tabelas[i], pai = t.parentNode;
      if (!pai || pai.nodeType !== 1) continue;
      if (pai.className && String(pai.className).indexOf('ws-tabela-rolagem') !== -1) continue;

      // Já está dentro de algo que rola (vários lugares já têm o <div style="overflow-x:auto">)?
      // Então não há nada a fazer — envolver de novo só criaria duas barras de rolagem.
      try {
        var ov = window.getComputedStyle(pai).overflowX;
        if (ov === 'auto' || ov === 'scroll') continue;
      } catch (e) {}

      var caixa = document.createElement('div');
      caixa.className = 'ws-tabela-rolagem';
      pai.insertBefore(caixa, t);
      caixa.appendChild(t);
    }
  }
  /* TABELA QUE NÃO CABE (01/10/2026, monitor 17"): em vez de barra de rolagem, a coluna de TEXTO longo
     (histórico, atividade, descrição...) passa a quebrar dentro da própria célula. Números, datas e
     botões continuam numa linha só. Só age quando a tabela realmente passa da largura. */
  function ajustarColunasLongas() {
    var caixas = document.querySelectorAll('.ws-tabela-rolagem, .ws-table-wrap, div[style*="overflow-x:auto"]');
    for (var i = 0; i < caixas.length; i++) {
      var cx = caixas[i], t = cx.querySelector('table.ws-table');
      if (!t || cx.scrollWidth <= cx.clientWidth + 2 || t.getAttribute('data-colunas-ok')) continue;
      t.setAttribute('data-colunas-ok', '1');
      var linhas = t.tBodies[0] ? t.tBodies[0].rows : [], max = Math.min(linhas.length, 30), soma = {};
      for (var r = 0; r < max; r++) for (var c = 0; c < linhas[r].cells.length; c++) {
        var cel = linhas[r].cells[c];
        if (cel.querySelector('button,input,select')) continue;
        soma[c] = Math.max(soma[c] || 0, (cel.textContent || '').trim().length);
      }
      for (var k in soma) if (soma[k] >= 40) {
        for (var r2 = 0; r2 < linhas.length; r2++) { var cl = linhas[r2].cells[k]; if (cl) { cl.style.whiteSpace = 'normal'; cl.style.minWidth = '220px';
          var tg = cl.querySelectorAll('.ws-tag'); for (var z = 0; z < tg.length; z++) { tg[z].style.whiteSpace = 'normal'; tg[z].style.display = 'inline-block'; } } }   // etiqueta comprida também quebra
      }
      // ainda não coube: a coluna de botões/links (Ações) passa a empilhar os botões, em vez de esticar a tabela
      if (cx.scrollWidth > cx.clientWidth + 2) for (var r3 = 0; r3 < linhas.length; r3++) {
        var ult = linhas[r3].cells[linhas[r3].cells.length - 1];
        if (ult && ult.querySelector('a,button') && !ult.querySelector('input,select')) { ult.style.whiteSpace = 'normal'; ult.style.minWidth = '120px'; }
      }
      // e o título comprido da coluna ("Pendente (competência)") quebra em duas linhas
      if (cx.scrollWidth > cx.clientWidth + 2) { var ths = t.querySelectorAll('thead th'); for (var h2 = 0; h2 < ths.length; h2++) ths[h2].style.whiteSpace = 'normal'; }
    }
  }
  function iniciarTabelas() { envolverTabelas(); try { ajustarColunasLongas(); } catch (e) {} }
  iniciarTabelas();   // JÁ, antes da primeira pintura (07/10/2026): a tabela não "se ajusta depois"
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciarTabelas);   // idempotente: pega tabela que veio depois deste script
})();

/* =====================================================================================================
   CONFIRMAÇÃO ANTES DE AÇÕES IMPORTANTES — regra única para o sistema inteiro.
   -----------------------------------------------------------------------------------------------------
   Pedido do provedor: pedir confirmação para excluir, cadastrar/salvar e outras ações que mexem em
   dado ou na conexão do cliente. Em vez de espalhar confirm() em centenas de botões (e esquecer
   algum), a regra fica aqui e vale em todas as telas que carregam este arquivo.

   - LINKS de ação (excluir, desbloquear, confiar, cancelar, estornar, restaurar...): pergunta antes
     de seguir. Bloquear/derrubar/excluir que JÁ tinham confirm() não perguntam duas vezes.
   - FORMULÁRIOS de gravação (acao=salvar_*, gerar_*, baixa_manual, del_*, ...): pergunta ao enviar.
     Formulário que já tinha confirm() no onsubmit segue como estava.
   - Só vale nas telas do OPERADOR (com o topo .ws-top-wrap): o portal/central do assinante não muda.
   - Para liberar um elemento específico: atributo data-sem-confirmar.
   Roda na fase de CAPTURA: se o operador cancelar, nada do clique/envio chega a acontecer.
   ===================================================================================================== */
(function () {
  if (window.__wsConfirmarAcoes) return; window.__wsConfirmarAcoes = true;
  function ativo() { return !!document.querySelector('.ws-top-wrap'); }
  function jaConfirma(el, attr) { var v = el.getAttribute(attr) || ''; return /confirm\s*\(|wsExcluirTitulo|prModalEstorno|wsConfianca/.test(v); }

  // Links: [padrão na URL, pergunta]
  var LINKS = [
    [/[?&](del|del_[a-z_]+|excluir|remover|apagar)=/i, 'Confirma a EXCLUSÃO? Essa ação não pode ser desfeita.'],
    [/[?&]cli_acao=desbloquear|[?&]desbloquear=/i,     'Confirma DESBLOQUEAR esta conexão?'],
    [/[?&]cli_acao=bloquear|[?&]bloquear=/i,           'Confirma BLOQUEAR esta conexão?'],
    [/[?&]cli_acao=derrubar|[?&]derrubar=/i,           'Confirma DERRUBAR a conexão? O cliente reconecta em seguida.'],
    [/[?&](cli_confiar|confiar)=/i,                   'Confirma liberar em CONFIANÇA?'],
    [/[?&](cancelar|estornar|estornar_fatura)=/i,      'Confirma esta ação (cancelar/estornar)?'],
    [/[?&]restaurar=/i,                                'Confirma abrir a RESTAURAÇÃO do backup?'],
    [/[?&](sync|sincronizar)[a-z_]*=/i,                'Confirma rodar a sincronização agora?']
  ];
  document.addEventListener('click', function (e) {
    if (!ativo() || e.defaultPrevented) return;
    var a = e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || a.hasAttribute('data-sem-confirmar') || jaConfirma(a, 'onclick')) return;
    var href = a.getAttribute('href') || '';
    if (href === '' || href.charAt(0) === '#' || /^javascript:/i.test(href)) return;
    for (var i = 0; i < LINKS.length; i++) {
      if (LINKS[i][0].test(href)) {
        if (!window.confirm(LINKS[i][1])) { e.preventDefault(); e.stopImmediatePropagation(); }
        return;
      }
    }
  }, true);

  // Formulários: valor do campo "acao" -> pergunta
  function perguntaForm(acao) {
    if (/^(del|excluir|remover|apagar)/i.test(acao))         return 'Confirma a EXCLUSÃO? Essa ação não pode ser desfeita.';
    if (/^baixa|^receber/i.test(acao))                       return 'Confirma o RECEBIMENTO deste título?';
    if (/^gerar/i.test(acao))                                return 'Confirma GERAR agora?';
    if (/^(estorn|cancel)/i.test(acao))                      return 'Confirma esta ação (cancelar/estornar)?';
    if (/^(salvar|cadastr|criar|novo|nova|add|editar|upload|importar|ligar)/i.test(acao)) return 'Confirma SALVAR as informações?';
    return '';
  }
  document.addEventListener('submit', function (e) {
    if (!ativo() || e.defaultPrevented) return;
    var f = e.target;
    if (!f || f.tagName !== 'FORM' || f.hasAttribute('data-sem-confirmar') || jaConfirma(f, 'onsubmit')) return;
    // Botão que já perguntou no onclick (ex.: "Excluir marcados") e a janela de senha root do
    // wsExcluirTitulo já SÃO a confirmação — não pergunta de novo.
    if (e.submitter && jaConfirma(e.submitter, 'onclick')) return;
    if (/^wsExcluirTitulo/.test(f.id || '')) return;
    if ((f.getAttribute('method') || 'get').toLowerCase() !== 'post') return;   // busca/filtro (GET) não pergunta
    var campo = f.querySelector('[name="acao"]'); if (!campo) return;
    var msg = perguntaForm(String(campo.value || ''));
    if (msg && !window.confirm(msg)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
})();

/* ================================================================================================
 * ATUALIZAÇÃO AUTOMÁTICA DAS TELAS (30/09/2026, pedido do provedor: "sem precisar dar F5").
 * A cada N segundos (Provedor → Recursos do sistema; window.WS_AUTO_ATUALIZAR, 0 = desligado) a tela
 * aberta se recarrega SOZINHA — mas só quando é seguro:
 *   aba visível · ninguém digitando/mexendo há 30 s · nenhum campo alterado · nenhuma janela aberta ·
 *   nenhum texto selecionado · tela que não seja de edição/impressão/ao vivo.
 * A recarga vai com ?_auto=1: o servidor NÃO conta como uso (a trava de tela por inatividade continua
 * valendo) nem como presença. Volta na mesma posição da rolagem. Voltar pelo navegador (cache) também
 * recarrega, para nunca mostrar dado velho.
 * ================================================================================================ */
(function () {
  try {
    var u = new URL(location.href);
    if (u.searchParams.has('_auto')) {               // limpa a marca da barra de endereço e volta à posição
      u.searchParams.delete('_auto'); history.replaceState(null, '', u.pathname + (u.search || '') + u.hash);
      var k = 'wsScroll:' + u.pathname + u.search, y = sessionStorage.getItem(k);
      if (y !== null) { sessionStorage.removeItem(k); window.addEventListener('load', function () { window.scrollTo(0, +y); }); }
    }
  } catch (e) {}
  window.addEventListener('pageshow', function (e) { if (e.persisted) location.reload(); });
  var seg = +(window.WS_AUTO_ATUALIZAR || 0);
  if (!(seg >= 30)) return;
  // telas que já se atualizam sozinhas, de impressão/edição longa ou públicas: nunca recarregar
  var fora = /(trafego_servidores|servidores|mk_monitor|olt|boleto|documentos|carne|recibo|chamado_tec|portal|central|backup|importar|manutencao|instalar|install|comandos|diag)[^/]*\.php$/i;
  if (fora.test(location.pathname) || document.body.hasAttribute('data-sem-auto')) return;
  var mexeu = Date.now(), alterou = false;
  ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'wheel'].forEach(function (ev) {
    window.addEventListener(ev, function () { mexeu = Date.now(); }, { passive: true, capture: true });
  });
  document.addEventListener('input', function (e) { if (e.target && e.target.closest && !e.target.closest('[data-busca-auto]')) alterou = true; }, true);
  document.addEventListener('change', function () { alterou = true; }, true);
  function janelaAberta() {
    if (document.querySelector('dialog[open]')) return true;
    var els = document.querySelectorAll('[role=dialog],.modal,.ws-modal,[id$="Ov"],[id*="modal"],[id*="Modal"],.ts-log.on');
    for (var i = 0; i < els.length; i++) { var cs = getComputedStyle(els[i]); if (cs.display !== 'none' && cs.visibility !== 'hidden' && els[i].offsetParent !== null) return true; }
    return false;
  }
  function podeAgora() {
    if (document.hidden || alterou) return false;
    if (Date.now() - mexeu < 30000) return false;
    var a = document.activeElement;
    if (a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable)) return false;
    if (String(window.getSelection ? window.getSelection() : '').length) return false;
    return !janelaAberta();
  }
  setInterval(function () {
    if (!podeAgora()) return;
    try {
      var u = new URL(location.href); u.searchParams.set('_auto', '1');
      sessionStorage.setItem('wsScroll:' + location.pathname + location.search, String(window.scrollY || 0));
      location.replace(u.toString());
    } catch (e) {}
  }, seg * 1000);
})();

/* 📋 COPIAR O NOME DO CLIENTE (01/10/2026, pedido do provedor): em TODAS as páginas, ao passar o mouse sobre o nome
 * de um cliente (link para a ficha, ?p=cliente&id=) aparece um ícone 📋 discreto ao lado; um clique copia o nome
 * para colar onde quiser. Fica oculto até o mouse passar por cima e não muda nada do que já existe (o link continua
 * abrindo a ficha e o resumo ao passar o mouse continua igual). */
(function () {
  if (window.wsCopiarNome) return; window.wsCopiarNome = true;
  var bt = document.createElement('button'), alvo = null, tFora = null;
  bt.type = 'button'; bt.textContent = '📋'; bt.title = 'Copiar o nome'; bt.setAttribute('aria-label', 'Copiar o nome');
  bt.style.cssText = 'position:absolute;z-index:99999;display:none;width:24px;height:24px;padding:0;border:1px solid var(--border,#ccc);border-radius:6px;background:var(--surface,#fff);color:var(--text,#111);font-size:12px;line-height:22px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.15)';
  function nomeDe(a) { return (a.textContent || '').replace(/\s+/g, ' ').trim(); }
  function serve(a) { if (a.closest('.ws-cp')) return false; var t = nomeDe(a); return t.length >= 3 && /[A-Za-zÀ-ú]{2}/.test(t) && !/^(abrir|ver|ficha|editar|cliente)\b/i.test(t) && !a.querySelector('img,svg'); }
  function mostra(a) {
    clearTimeout(tFora); alvo = a;
    if (!bt.parentNode) document.body.appendChild(bt);
    var r = a.getBoundingClientRect();
    bt.style.left = (window.scrollX + r.right + 4) + 'px';
    bt.style.top = (window.scrollY + r.top + (r.height - 24) / 2) + 'px';
    bt.textContent = '📋'; bt.style.display = 'block';
  }
  function esconde() { tFora = setTimeout(function () { bt.style.display = 'none'; alvo = null; }, 350); }
  document.addEventListener('mouseover', function (e) {
    if (e.target === bt) { clearTimeout(tFora); return; }
    var a = e.target.closest && e.target.closest('a[href*="p=cliente&id="]');
    if (a && serve(a)) mostra(a);
  });
  document.addEventListener('mouseout', function (e) {
    var a = e.target.closest && e.target.closest('a[href*="p=cliente&id="]');
    if ((a && a === alvo) || e.target === bt) esconde();
  });
  bt.addEventListener('click', function (e) {
    e.preventDefault(); e.stopPropagation(); if (!alvo) return;
    var t = nomeDe(alvo), ok = function () { bt.textContent = '✓'; setTimeout(function () { bt.textContent = '📋'; }, 1200); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(ok, velho); else velho();
    function velho() { var x = document.createElement('textarea'); x.value = t; x.style.position = 'fixed'; x.style.opacity = '0'; document.body.appendChild(x); x.select(); try { document.execCommand('copy'); ok(); } catch (err) { prompt('Copie:', t); } x.remove(); }
  });
  window.addEventListener('scroll', function () { bt.style.display = 'none'; alvo = null; }, true);
})();

/* NOTA DO CLIENTE NA LISTA (03/10/2026): "📝 Nota" no menu abaixo do nome abre esta janelinha; grava na Observação
   do cadastro (acao=cli_nota na própria página). */
function wsNotaCli(id, el) {
  var ov = document.getElementById('wsNotaOv');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'wsNotaOv'; ov.className = 'ws-modal-ov';
    ov.innerHTML = '<div class="ws-modal" style="max-width:460px"><h3 style="margin-top:0">📝 Nota do cliente</h3><div class="ws-muted" id="wsNotaNome" style="font-size:13px;margin:-6px 0 8px"></div>'
      + '<form method="post"><input type="hidden" name="acao" value="cli_nota"><input type="hidden" name="cliente_id"><input type="hidden" name="volta">'
      + '<textarea name="nota" maxlength="2000" style="width:100%;min-height:110px;padding:8px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--text)" placeholder="Escreva a nota (fica na Observação do cadastro)"></textarea>'
      + '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px"><button type="button" class="ws-btn" onclick="document.getElementById(\'wsNotaOv\').style.display=\'none\'">Cancelar</button><button class="ws-btn verde" data-sem-confirmar>Salvar nota</button></div></form></div>';
    document.body.appendChild(ov);
    ov.addEventListener('click', function (e) { if (e.target === ov) ov.style.display = 'none'; });
  }
  var f = ov.querySelector('form');
  f.cliente_id.value = id; f.nota.value = el.getAttribute('data-nota') || '';
  f.volta.value = location.pathname.split('/').pop() + location.search;
  document.getElementById('wsNotaNome').textContent = el.getAttribute('data-nome') || '';
  ov.style.display = 'flex'; setTimeout(function () { f.nota.focus(); }, 30);
}
/* Barrinha de carregamento ao trocar de página (07/10/2026): clique num link interno comum → aparece no topo até a próxima tela abrir.
   Não liga para nova aba, download, âncora (#), javascript:, Ctrl/Shift/clique do meio nem links de outro site. */
(function () {
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null; if (!a) return;
    var h = a.getAttribute('href') || '';
    if (!h || h.charAt(0) === '#' || /^(javascript|mailto|tel|whatsapp):/i.test(h) || a.hasAttribute('download') || (a.target && a.target !== '_self')) return;
    try { var u = new URL(a.href, location.href); if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search && u.hash)) return; } catch (err) { return; }
    document.documentElement.classList.add('ws-carregando');
    setTimeout(function () { document.documentElement.classList.remove('ws-carregando'); }, 8000);   // download/arquivo que não troca de tela
  });
  window.addEventListener('pageshow', function () { document.documentElement.classList.remove('ws-carregando'); });
})();

/* 🔒 TRAVA VISUAL DA ABA ESQUECIDA (15/10/2026): a tela de bloqueio só aparecia na próxima navegação — aba abandonada
 * continuava mostrando os dados. Passado o tempo da trava (Provedor → Recursos), a aba pergunta ao servidor (ws_ping.php,
 * que NÃO renova o relógio) e, se ele já trancou, recarrega para mostrar a tela de senha. Não muda quando o servidor tranca. */
(function () {
  var min = +(window.WS_TRAVA_MIN || 0); if (!(min > 0)) return;
  var ini = Date.now();
  setInterval(function () {
    if (Date.now() - ini < min * 60000) return;
    try { fetch('ws_ping.php', { cache: 'no-store', credentials: 'same-origin' }).then(function (r) { if (r.status === 401 || r.status === 403) location.reload(); }).catch(function () {}); } catch (e) {}
  }, 60000);
})();

/* VISUAL REFINADO — DEFINITIVO (21/11/2026, decisão do dono): sem botão, sem selo e sem chave para desligar. Põe a classe ws-refino no <html> e faz o agrupamento do topo (grupo de aparência, status na 1ª linha em tela larga, nome da página só quando acrescenta algo); o estilo está no fim do css/wellsystem.css. */
(function () {
  try {
    document.documentElement.classList.add('ws-refino');
    wsReady(function () {
      try {
        var t = document.querySelector('.ws-titulo-pagina .ws-pagina-atual'), tp = document.querySelector('.ws-titulo-pagina');
        if (t && tp) {
          var nome = t.textContent.replace(/\s+/g, ' ').trim().toLowerCase();
          var dup = Array.prototype.some.call(document.querySelectorAll('.ws-nav > a, .ws-nav .ws-grp-lbl'), function (x) { return x.textContent.replace(/\s+/g, ' ').trim().toLowerCase() === nome; });
          if (dup) tp.classList.add('ws-tit-dup');
        }
        /* tema, cor e reflexo: três ícones soltos viram UM grupo (mesmos botões, só agrupados) */
        var bt = document.querySelector('.ws-top-l1 .ws-btn-tema-top'), br = document.querySelector('.ws-top-l1 .ws-btn-reflexo-top');
        if (bt && br && !bt.parentNode.classList.contains('ws-grp-aparencia')) {
          var gp = document.createElement('span'); gp.className = 'ws-grp-aparencia'; bt.parentNode.insertBefore(gp, bt);
          var cur = bt, fim = br.nextSibling;
          while (cur && cur !== fim) { var prox = cur.nextSibling; if (cur.nodeType === 1 && cur.tagName !== 'SCRIPT') gp.appendChild(cur); cur = prox; }
        }
        /* ONLINE do status: ao passar o mouse mostra há quantos dias e horas o servidor está no ar (o texto "· há 5 dias 22h" fica escondido na cápsula do topo) */
        var net = document.querySelector('.ws-status-bar .ws-st-net');
        if (net && !net.dataset.wsTip) {
          net.dataset.wsTip = '1'; net.style.cursor = 'help';
          var tip = function () { var up = net.querySelector('.ws-st-up'); var tx = up ? up.textContent.replace(/^[\s·]+/, '').trim() : ''; net.title = tx ? 'Online ' + tx : 'Online'; };
          tip(); net.addEventListener('mouseenter', tip);
        }
        /* tela larga: a barra de status (RAM/CPU/disco/sessões/IP) ocupa o espaço vazio da 1ª linha em vez de uma faixa própria */
        if (window.innerWidth >= 1500) {
          var sb = document.querySelector('.ws-status-bar'), fl = document.querySelector('.ws-top-l1 .ws-top-fill');
          if (sb && fl && !fl.contains(sb)) { fl.appendChild(sb); document.documentElement.classList.add('ws-st-inline'); }
        }
      } catch (e) {}
    });
  } catch (e) {}
})();
