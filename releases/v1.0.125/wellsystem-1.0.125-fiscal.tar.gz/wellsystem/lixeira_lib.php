<?php
/**
 * WellSystem — RECUPERA DELETADO (ordem do dono, 20/11/2026: "qualquer coisa apagada será importante e poder devolvê-la").
 *
 * Como funciona: a conexão do banco (ws_db → WsPDO) olha todo `DELETE FROM <tabela> [WHERE…]` feito por um operador logado
 * e, ANTES de apagar, guarda uma cópia das linhas que serão apagadas — e das linhas filhas que o banco apagaria em cascata
 * (ON DELETE CASCADE) — em ws_lixeira_ponto / ws_lixeira_linha. Uma ação do operador (um pedido da tela) = um "ponto".
 * A tela recupera_deletado.php (nível 3+) mostra os 5 últimos pontos e devolve tudo de um deles ao banco.
 *
 * REGRAS DE SEGURANÇA DESTE ARQUIVO:
 *  - NUNCA pode quebrar nem atrasar a exclusão: tudo da captura roda dentro de try/catch e, se algo falhar, o DELETE segue normal.
 *  - Só captura pedido de tela (não CLI/cron/robô) com operador logado e fora do demo.
 *  - Não captura tabela de manutenção automática (RADIUS, logs, caches, histórico de online…) — ver ws_lixeira_ignora().
 *  - Exclusão em massa (mais de 1500 linhas numa instrução) não é guardada: é limpeza, não ação do operador.
 *  - Guarda 30 dias (ws_lixeira_limpar). Tabelas com COLLATE explícito (regra do projeto).
 */

if (!class_exists('WsStmt', false)) {
    /** Statement que, se for DELETE de tabela comum, guarda as linhas antes de executar. */
    class WsStmt extends PDOStatement {
        public $wsPdo = null; public $wsTab = ''; public $wsResto = ''; public $wsBind = [];
        protected function __construct() {}
        #[\ReturnTypeWillChange]
        public function bindValue($param, $value, $type = PDO::PARAM_STR) {
            if ($this->wsTab !== '') $this->wsBind[$param] = $value;
            return parent::bindValue($param, $value, $type);
        }
        #[\ReturnTypeWillChange]
        public function bindParam($param, &$var, $type = PDO::PARAM_STR, $maxLength = 0, $driverOptions = null) {
            if ($this->wsTab !== '') $this->wsBind[$param] = &$var;
            return parent::bindParam($param, $var, $type, $maxLength, $driverOptions);
        }
        #[\ReturnTypeWillChange]
        public function execute($params = null) {
            if ($this->wsTab !== '' && $this->wsPdo) ws_lixeira_capturar($this->wsPdo, $this->wsTab, $this->wsResto, $params !== null ? $params : $this->wsBind);
            return $params === null ? parent::execute() : parent::execute($params);
        }
    }
}
if (!class_exists('WsPDO', false)) {
    class WsPDO extends PDO {
        #[\ReturnTypeWillChange]
        public function prepare($query, $options = []) {
            $st = parent::prepare($query, $options);
            if ($st instanceof WsStmt && ($p = ws_lixeira_parse((string)$query))) { $st->wsPdo = $this; $st->wsTab = $p[0]; $st->wsResto = $p[1]; }
            return $st;
        }
        #[\ReturnTypeWillChange]
        public function exec($statement) {
            if (($p = ws_lixeira_parse((string)$statement))) ws_lixeira_capturar($this, $p[0], $p[1], []);
            return parent::exec($statement);
        }
        /** Uso interno (sem captura): prepara/executa consultas da própria lixeira. */
        public function wsRaw(string $q) { return parent::prepare($q); }
        public function wsExec(string $q) { return parent::exec($q); }
    }
}

/** Tabelas de manutenção automática/derivadas: nunca entram na lixeira. */
function ws_lixeira_ignora(string $t): bool {
    return (bool)preg_match('/^(rad|nas$|resumo_dia|ws_lixeira_|ws_evento|ws_online_hist|ws_cgnat_|ws_logradouro|ws_recibo_log|ws_rede_|ws_log|ws_sessao|ws_fila|ws_cache|ws_token|ws_otp)/i', $t);
}
function ws_lixeira_ativa(): bool {
    if (defined('WS_LIXEIRA_TESTE')) return true;   // só o teste isolado define isto (nunca em produção)
    if (PHP_SAPI === 'cli' || empty($_SESSION['ws_user'])) return false;
    if (function_exists('ws_em_demo') && ws_em_demo()) return false;
    return true;
}
/** [tabela, resto] se for um DELETE simples que vale guardar; senão null. */
function ws_lixeira_parse(string $q): ?array {
    if (stripos($q, 'delete') === false) return null;
    if (!preg_match('/^\s*DELETE\s+FROM\s+`?([A-Za-z0-9_]+)`?\s*(.*)$/is', $q, $m)) return null;
    $resto = trim($m[2]);
    if ($resto !== '' && !preg_match('/^(WHERE|ORDER\s+BY|LIMIT)\b/i', $resto)) return null;
    if (preg_match('/\b(JOIN|USING)\b/i', $resto) || ws_lixeira_ignora($m[1])) return null;
    return [$m[1], $resto];
}
function ws_lixeira_garantir(PDO $pdo): void {
    static $ok = false; if ($ok) return;
    /* CREATE TABLE faz COMMIT implícito (mesmo com IF NOT EXISTS): num pedido que apaga DENTRO de uma transação isso gravaria o que o
       chamador ainda podia desfazer com rollBack. Por isso: 1) só consulta o information_schema (sem DDL) quando as tabelas já existem;
       2) as tabelas são criadas pelo ws_selfheal() (fora de transação); 3) se faltarem e houver transação aberta, NÃO cria (a captura
       daquele pedido é pulada — a exclusão segue normal). */
    $q = $pdo->wsRaw("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('ws_lixeira_ponto','ws_lixeira_linha')");
    $q->execute();
    if ((int)$q->fetchColumn() >= 2) { $ok = true; return; }
    if ($pdo->inTransaction()) throw new RuntimeException('lixeira: tabelas ainda não existem e há transação aberta');
    $pdo->wsExec("CREATE TABLE IF NOT EXISTS ws_lixeira_ponto (
        id INT AUTO_INCREMENT PRIMARY KEY, em DATETIME NOT NULL, usuario_id INT NULL, usuario VARCHAR(120) NOT NULL DEFAULT '', nivel INT NOT NULL DEFAULT 0,
        tela VARCHAR(160) NOT NULL DEFAULT '', qtd INT NOT NULL DEFAULT 0, resumo VARCHAR(400) NOT NULL DEFAULT '',
        restaurado_em DATETIME NULL, restaurado_por VARCHAR(120) NULL, INDEX idx_em (em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->wsExec("CREATE TABLE IF NOT EXISTS ws_lixeira_linha (
        id INT AUTO_INCREMENT PRIMARY KEY, ponto_id INT NOT NULL, tabela VARCHAR(64) NOT NULL, qtd INT NOT NULL DEFAULT 0, dados LONGTEXT NOT NULL, INDEX idx_ponto (ponto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $ok = true;
}
/** Linhas -> JSON seguro (texto binário vira {"__b64":...}). */
function ws_lixeira_enc(array $rows): string {
    foreach ($rows as &$r) foreach ($r as $k => $v) if (is_string($v) && !mb_check_encoding($v, 'UTF-8')) $r[$k] = ['__b64' => base64_encode($v)];
    unset($r);
    return (string)json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
}
function ws_lixeira_dec($v) { return (is_array($v) && isset($v['__b64'])) ? base64_decode((string)$v['__b64']) : $v; }

/** Tabelas filhas que o banco apaga em cascata: [[tabela_filha, coluna_filha, coluna_referenciada], …]. */
function ws_lixeira_filhas(PDO $pdo, string $tab): array {
    static $c = [];
    if (isset($c[$tab])) return $c[$tab];
    $o = [];
    try {
        $q = $pdo->wsRaw("SELECT k.TABLE_NAME t, k.COLUMN_NAME c, k.REFERENCED_COLUMN_NAME rc FROM information_schema.KEY_COLUMN_USAGE k
            JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA=k.TABLE_SCHEMA AND r.CONSTRAINT_NAME=k.CONSTRAINT_NAME AND r.TABLE_NAME=k.TABLE_NAME
            WHERE k.TABLE_SCHEMA=DATABASE() AND k.REFERENCED_TABLE_NAME=? AND r.DELETE_RULE='CASCADE'");
        $q->execute([$tab]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) $o[] = [$r['t'], $r['c'], $r['rc']];
    } catch (Throwable $e) {}
    return $c[$tab] = $o;
}
function ws_lixeira_ponto(PDO $pdo): int {
    if (!empty($GLOBALS['ws_lix_ponto'])) return (int)$GLOBALS['ws_lix_ponto'];
    $u = function_exists('ws_user') ? (ws_user() ?: []) : [];
    $tela = basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) . (isset($_GET['p']) && is_string($_GET['p']) ? '?p=' . substr(preg_replace('/[^a-z0-9_]/i', '', $_GET['p']), 0, 30) : '');
    $st = $pdo->wsRaw('INSERT INTO ws_lixeira_ponto (em, usuario_id, usuario, nivel, tela) VALUES (NOW(), ?, ?, ?, ?)');
    $st->execute([(int)($u['id'] ?? 0) ?: null, mb_substr((string)($u['nome'] ?? $u['usuario'] ?? ''), 0, 120), function_exists('ws_nivel_acesso') ? ws_nivel_acesso() : 0, mb_substr($tela, 0, 160)]);
    return (int)($GLOBALS['ws_lix_ponto'] = (int)$pdo->lastInsertId());
}
/** Guarda $rows de $tab no ponto e desce para as filhas em cascata. */
function ws_lixeira_guardar(PDO $pdo, int $ponto, string $tab, array $rows, int $nivel): void {
    if (!$rows || $nivel > 4 || ($GLOBALS['ws_lix_total'] ?? 0) > 6000) return;
    $novas = [];
    foreach ($rows as $r) { $h = md5(serialize($r)); if (isset($GLOBALS['ws_lix_vistos'][$tab][$h])) continue; $GLOBALS['ws_lix_vistos'][$tab][$h] = 1; $novas[] = $r; }
    if (!$novas) return;
    $st = $pdo->wsRaw('INSERT INTO ws_lixeira_linha (ponto_id, tabela, qtd, dados) VALUES (?, ?, ?, ?)');
    $st->execute([$ponto, $tab, count($novas), ws_lixeira_enc($novas)]);
    $GLOBALS['ws_lix_total'] = ($GLOBALS['ws_lix_total'] ?? 0) + count($novas);
    $GLOBALS['ws_lix_cont'][$tab] = ($GLOBALS['ws_lix_cont'][$tab] ?? 0) + count($novas);
    if (!isset($GLOBALS['ws_lix_rot'][$tab])) $GLOBALS['ws_lix_rot'][$tab] = ws_lixeira_rotulo($novas[0]);
    foreach (ws_lixeira_filhas($pdo, $tab) as [$ft, $fc, $rc]) {
        if (ws_lixeira_ignora($ft)) continue;
        $vals = []; foreach ($novas as $r) if (isset($r[$rc]) && $r[$rc] !== null) $vals[(string)$r[$rc]] = $r[$rc];
        $vals = array_values($vals);
        for ($i = 0; $i < count($vals); $i += 400) {
            $parte = array_slice($vals, $i, 400);
            $q = $pdo->wsRaw("SELECT * FROM `$ft` WHERE `$fc` IN (" . implode(',', array_fill(0, count($parte), '?')) . ')');
            $q->execute($parte);
            ws_lixeira_guardar($pdo, $ponto, $ft, $q->fetchAll(PDO::FETCH_ASSOC), $nivel + 1);
        }
    }
}
function ws_lixeira_rotulo(array $r): string {
    foreach (['nome', 'titulo', 'descricao', 'razao', 'login', 'login_pppoe', 'login_ipoe', 'cidade', 'bairro', 'protocolo', 'numero', 'mac', 'serial', 'id'] as $k)
        if (isset($r[$k]) && trim((string)$r[$k]) !== '') return mb_substr(trim((string)$r[$k]), 0, 80);
    return '';
}
function ws_lixeira_nome_tabela(string $t): string {
    static $m = ['ws_cliente' => 'Cliente', 'ws_contrato' => 'Contrato', 'ws_fatura' => 'Fatura', 'ws_pagamento' => 'Pagamento', 'ws_chamado' => 'Chamado', 'ws_chamado_msg' => 'Mensagem de chamado',
        'ws_cidade' => 'Cidade', 'ws_bairro' => 'Bairro', 'ws_zona' => 'Zona', 'ws_ramal' => 'Ramal', 'ws_equipamento' => 'Equipamento', 'ws_usuario' => 'Operador', 'ws_usuario_ramal' => 'Acesso do operador',
        'ws_estoque' => 'Item de estoque', 'ws_plano' => 'Plano', 'ws_lead' => 'Lead', 'ws_banco' => 'Conta/Banco', 'ws_nota' => 'Nota fiscal', 'ws_nota_item' => 'Item de nota', 'ws_concentrador' => 'Concentrador',
        'ws_tecnico' => 'Técnico', 'ws_regua' => 'Régua', 'ws_comprovante' => 'Comprovante', 'ws_anexo' => 'Anexo', 'ws_cto' => 'CTO', 'ws_olt_generica' => 'Mini OLT', 'ws_solicitacao' => 'Solicitação', 'ws_produto' => 'Produto'];
    return $m[$t] ?? ucfirst(str_replace('_', ' ', preg_replace('/^ws_/', '', $t)));
}
function ws_lixeira_resumo_atualiza(PDO $pdo, int $ponto): void {
    $cont = $GLOBALS['ws_lix_cont'] ?? []; if (!$cont) return;
    $prio = ['ws_cliente', 'ws_contrato', 'ws_fatura', 'ws_chamado', 'ws_nota', 'ws_usuario']; $main = null;
    foreach ($prio as $p) if (isset($cont[$p])) { $main = $p; break; }
    if ($main === null) { reset($cont); $main = key($cont); }
    $t = ws_lixeira_nome_tabela($main) . ($cont[$main] > 1 ? ' ×' . $cont[$main] : '') . (($GLOBALS['ws_lix_rot'][$main] ?? '') !== '' ? ': ' . $GLOBALS['ws_lix_rot'][$main] : '');
    $mais = []; foreach ($cont as $k => $n) if ($k !== $main) $mais[] = $n . ' ' . mb_strtolower(ws_lixeira_nome_tabela($k));
    $res = $t . ($mais ? ' (junto: ' . implode(', ', $mais) . ')' : '');
    $pdo->wsRaw('UPDATE ws_lixeira_ponto SET qtd=?, resumo=? WHERE id=?')->execute([(int)array_sum($cont), mb_substr($res, 0, 400), $ponto]);
}
/** Chamada ANTES de cada DELETE de tabela comum: nunca lança erro. */
function ws_lixeira_capturar(PDO $pdo, string $tab, string $resto, $params): void {
    try {
        if (!ws_lixeira_ativa() || !($pdo instanceof WsPDO)) return;
        ws_lixeira_garantir($pdo);
        $sel = $pdo->wsRaw("SELECT * FROM `$tab` $resto");
        if (is_array($params)) { $n = 1; foreach ($params as $k => $v) { $sel->bindValue(is_int($k) ? $k + 1 : $k, $v); $n++; } }
        $sel->execute();
        $rows = $sel->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows || count($rows) > 1500) return;
        $ponto = ws_lixeira_ponto($pdo);
        ws_lixeira_guardar($pdo, $ponto, $tab, $rows, 0);
        ws_lixeira_resumo_atualiza($pdo, $ponto);
        if (mt_rand(1, 40) === 1) ws_lixeira_limpar($pdo);
    } catch (Throwable $e) { /* guardar é um extra: nunca atrapalha a exclusão */ }
}
/** Apaga pontos com mais de 30 dias. */
function ws_lixeira_limpar(PDO $pdo, int $dias = 30): void {
    try {
        ws_lixeira_garantir($pdo);
        $pdo->wsExec("DELETE l FROM ws_lixeira_linha l JOIN ws_lixeira_ponto p ON p.id=l.ponto_id WHERE p.em < (NOW() - INTERVAL " . (int)$dias . " DAY)");
        $pdo->wsExec("DELETE FROM ws_lixeira_ponto WHERE em < (NOW() - INTERVAL " . (int)$dias . " DAY)");
    } catch (Throwable $e) {}
}
/** Últimos pontos (mais novos primeiro), com o que cada um contém. */
function ws_lixeira_listar(PDO $pdo, int $n = 5): array {
    ws_lixeira_garantir($pdo);
    $ps = $pdo->wsRaw('SELECT * FROM ws_lixeira_ponto ORDER BY id DESC LIMIT ' . (int)$n); $ps->execute(); $ps = $ps->fetchAll(PDO::FETCH_ASSOC);
    foreach ($ps as &$p) {
        $q = $pdo->wsRaw('SELECT tabela, SUM(qtd) n FROM ws_lixeira_linha WHERE ponto_id=? GROUP BY tabela'); $q->execute([(int)$p['id']]);
        $p['itens'] = $q->fetchAll(PDO::FETCH_KEY_PAIR);
    }
    return $ps;
}
/** PRÉVIA do que um ponto contém, para o operador VER antes de recuperar (21/11/2026): por tabela (nome amigável), quantidade e até $max rótulos (nome, login, número…). */
function ws_lixeira_previa(PDO $pdo, int $ponto, int $max = 6): array {
    $out = [];
    try {
        $l = $pdo->wsRaw('SELECT tabela, qtd, dados FROM ws_lixeira_linha WHERE ponto_id=? ORDER BY id'); $l->execute([$ponto]);
        foreach ($l->fetchAll(PDO::FETCH_ASSOC) as $ln) {
            $nome = ws_lixeira_nome_tabela((string)$ln['tabela']);
            if (!isset($out[$nome])) $out[$nome] = ['n' => 0, 'itens' => []];
            foreach ((array)json_decode((string)$ln['dados'], true) as $row) {
                if (!is_array($row) || !$row) continue;
                $out[$nome]['n']++;
                if (count($out[$nome]['itens']) < $max) { $r = ws_lixeira_rotulo($row); if ($r !== '') $out[$nome]['itens'][] = $r; }
            }
        }
    } catch (Throwable $e) {}
    return $out;
}
/** Devolve ao banco tudo de um ponto. Retorna ['ok'=>inseridas,'ja'=>já existiam,'erros'=>[...]]. */
function ws_lixeira_restaurar(PDO $pdo, int $ponto, string $por): array {
    ws_lixeira_garantir($pdo);
    $res = ['ok' => 0, 'ja' => 0, 'erros' => []];
    $q = $pdo->wsRaw('SELECT * FROM ws_lixeira_ponto WHERE id=?'); $q->execute([$ponto]); $p = $q->fetch(PDO::FETCH_ASSOC);
    if (!$p) { $res['erros'][] = 'Ponto não encontrado.'; return $res; }
    if (!empty($p['restaurado_em'])) { $res['erros'][] = 'Este ponto já foi recuperado em ' . $p['restaurado_em'] . '.'; return $res; }
    $l = $pdo->wsRaw('SELECT tabela, dados FROM ws_lixeira_linha WHERE ponto_id=? ORDER BY id'); $l->execute([$ponto]); $linhas = $l->fetchAll(PDO::FETCH_ASSOC);
    $pdo->wsExec('SET FOREIGN_KEY_CHECKS=0');
    try {
        $pdo->beginTransaction();
        foreach ($linhas as $ln) {
            $tab = (string)$ln['tabela']; if (!preg_match('/^[A-Za-z0-9_]+$/', $tab)) continue;
            foreach ((array)json_decode((string)$ln['dados'], true) as $row) {
                if (!is_array($row) || !$row) continue;
                $cols = array_keys($row); $vals = array_map('ws_lixeira_dec', array_values($row));
                $st = $pdo->wsRaw("INSERT INTO `$tab` (`" . implode('`,`', $cols) . '`) VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')');
                try { $st->execute($vals); $res['ok']++; }
                catch (PDOException $e) { if ((string)$e->getCode() === '23000') $res['ja']++; else $res['erros'][] = $tab . ': ' . mb_substr($e->getMessage(), 0, 160); }
            }
        }
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $res['erros'][] = mb_substr($e->getMessage(), 0, 200); }
    $pdo->wsExec('SET FOREIGN_KEY_CHECKS=1');
    if ($res['ok'] > 0 || $res['ja'] > 0) $pdo->wsRaw('UPDATE ws_lixeira_ponto SET restaurado_em=NOW(), restaurado_por=? WHERE id=?')->execute([mb_substr($por, 0, 120), $ponto]);
    return $res;
}
