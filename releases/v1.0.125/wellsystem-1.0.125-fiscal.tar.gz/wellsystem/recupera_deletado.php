<?php
/**
 * WellSystem ERP — RECUPERA DELETADO (nível 3 ou mais).
 * Mostra as 5 últimas exclusões feitas por operadores (de qualquer tela) e devolve ao banco tudo de uma delas
 * (o registro e o que o banco apagou junto, como contratos e faturas de um cliente). As cópias ficam 30 dias (lixeira_lib.php).
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
if (!ws_pode_configurar()) { http_response_code(403); echo '<!doctype html><meta charset="utf-8"><p style="font:16px sans-serif;padding:30px">Acesso restrito: Recupera Deletado é do nível 3 em diante.</p>'; exit; }
$db = ws_db();
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
if (empty($_SESSION['ws_rd_tok'])) $_SESSION['ws_rd_tok'] = bin2hex(random_bytes(16));
$msg = ''; $msgTipo = 'ok';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'recuperar') {
    if (!hash_equals((string)$_SESSION['ws_rd_tok'], (string)($_POST['tok'] ?? ''))) { $msg = 'Sessão expirada: abra a página de novo.'; $msgTipo = 'err'; }
    else {
        $r = ws_lixeira_restaurar($db, (int)($_POST['ponto'] ?? 0), (string)(ws_user()['nome'] ?? 'operador'));
        if ($r['erros'] && !$r['ok'] && !$r['ja']) { $msg = implode(' ', $r['erros']); $msgTipo = 'err'; }
        else { $msg = '✅ Recuperado: ' . $r['ok'] . ' registro(s) devolvido(s)' . ($r['ja'] ? ' (' . $r['ja'] . ' já existia(m))' : '') . '.' . ($r['erros'] ? ' ⚠ Avisos: ' . implode(' ', $r['erros']) : ''); }
    }
}
try { $pontos = ws_lixeira_listar($db, 5); } catch (Throwable $e) { $pontos = []; }
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Recupera Deletado</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
  .rd-lista{display:flex;flex-direction:column;gap:12px;margin-top:14px}
  .rd-item{--rc:#e0525a;display:flex;flex-wrap:wrap;gap:10px 18px;align-items:center;justify-content:space-between;padding:14px 18px;border-radius:14px;border:1px solid var(--border,rgba(128,128,128,.3));background:var(--surface,#fff);box-shadow:inset 5px 0 0 var(--rc);transition:background .18s,box-shadow .18s,border-color .18s}
  .rd-item:hover{background:color-mix(in srgb,var(--rc) 6%,var(--surface,#fff));border-color:color-mix(in srgb,var(--rc) 45%,transparent);box-shadow:inset 7px 0 0 var(--rc),0 6px 18px color-mix(in srgb,var(--rc) 14%,transparent)}
  .rd-item.feito{--rc:#10b981;opacity:.75}
  .rd-q{font-weight:700;font-size:15px}.rd-m{display:block;font-size:12.5px;color:var(--muted,#667);margin-top:3px;line-height:1.5}
  .rd-n{display:inline-block;margin-left:8px;padding:2px 9px;border-radius:99px;background:rgba(224,82,90,.12);color:#c0414a;font-size:11.5px;font-weight:700}
  .rd-bt{padding:8px 18px;border-radius:10px;border:1px solid rgba(224,82,90,.5);background:#fff5f6;color:#c0414a;font:inherit;font-weight:700;font-size:13px;cursor:pointer;transition:background .15s,box-shadow .15s}
  .rd-bt:hover{background:#ffe8eb;box-shadow:0 4px 12px rgba(224,82,90,.18)}
  .rd-ok{color:#047857;font-weight:600;font-size:13px}
  .rd-item{align-items:flex-start}.rd-det{flex:1 1 100%;margin-top:2px}.rd-det summary{cursor:pointer;font-size:13px;font-weight:700;color:var(--brand);list-style:none;padding:4px 0}.rd-det summary::-webkit-details-marker{display:none}
  .rd-prev{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;margin:8px 0 12px}.rd-grp{background:color-mix(in srgb,var(--rc) 5%,var(--surface,#fff));border:1px solid var(--border,rgba(128,128,128,.3));border-radius:10px;padding:10px 12px;font-size:12.5px}
  .rd-grp ul{margin:6px 0 0;padding-left:18px;color:var(--muted,#667)}.rd-grp li{margin:2px 0;word-break:break-word}.rd-mais{list-style:none;margin-left:-18px;font-style:italic}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('') ?></header>
<main class="ws-main">
<?php if ($msg !== ''): ?><div class="ws-alert <?= $msgTipo === 'err' ? 'err' : 'ok' ?>"><?= $h($msg) ?></div><?php endif; ?>
<div class="ws-head-row"><h2>♻️ Recupera Deletado</h2></div>
<?php if (!$pontos): ?>
  <p class="ws-muted">Nenhuma exclusão guardada ainda. A partir de agora, tudo que um operador apagar fica aqui por 30 dias.</p>
<?php else: ?>
  <p class="ws-muted" style="margin:0">Últimas <?= count($pontos) ?> exclusões. Abra “Ver o que contém” para conferir e só então recupere:</p>
  <div class="rd-lista">
  <?php foreach ($pontos as $p): $feito = !empty($p['restaurado_em']); ?>
    <div class="rd-item<?= $feito ? ' feito' : '' ?>">
      <div>
        <span class="rd-q"><?= $h($p['resumo'] !== '' ? $p['resumo'] : 'Exclusão') ?><span class="rd-n"><?= (int)$p['qtd'] ?> registro(s)</span></span>
        <span class="rd-m">🕒 <?= $h(date('d/m/Y H:i', strtotime($p['em']))) ?> · 👤 <?= $h($p['usuario'] !== '' ? $p['usuario'] : '—') ?> · 📍 <?= $h($p['tela']) ?></span>
      </div>
      <?php if ($feito): ?>
        <span class="rd-ok">✔ Recuperado em <?= $h(date('d/m/Y H:i', strtotime($p['restaurado_em']))) ?> por <?= $h($p['restaurado_por']) ?></span>
      <?php endif; ?>
      <?php $prev = ws_lixeira_previa($db, (int)$p['id']); ?>
      <details class="rd-det"<?= $feito ? '' : '' ?>>
        <summary>👁️ Ver o que contém<?= $feito ? '' : ' e recuperar' ?></summary>
        <div class="rd-prev">
          <?php foreach ($prev as $tn => $pv): ?>
            <div class="rd-grp"><b><?= $h($tn) ?></b> <span class="rd-n"><?= (int)$pv['n'] ?></span>
              <?php if ($pv['itens']): ?><ul><?php foreach ($pv['itens'] as $it): ?><li><?= $h($it) ?></li><?php endforeach; ?><?php if ($pv['n'] > count($pv['itens'])): ?><li class="rd-mais">… e mais <?= (int)$pv['n'] - count($pv['itens']) ?></li><?php endif; ?></ul><?php endif; ?>
            </div>
          <?php endforeach; if (!$prev): ?><span class="ws-muted">Sem detalhes guardados.</span><?php endif; ?>
        </div>
        <?php if (!$feito): ?>
        <form method="post" onsubmit="return confirm('Devolver ao banco o que foi apagado neste ponto?\n\n<?= $h(addslashes(str_replace(["\n", "\r"], ' ', (string)$p['resumo']))) ?>\n\nAtenção: o que o sistema fez fora do banco (cobrança cancelada no CelCash/Lytex, conexão derrubada no RADIUS) não volta sozinho.')">
          <input type="hidden" name="acao" value="recuperar"><input type="hidden" name="tok" value="<?= $h($_SESSION['ws_rd_tok']) ?>"><input type="hidden" name="ponto" value="<?= (int)$p['id'] ?>">
          <button class="rd-bt" type="submit">♻️ Recuperar este ponto</button>
        </form>
        <?php endif; ?>
      </details>
    </div>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
</main>
<?= ws_footer_bar() ?>
</body></html>
