// =============================================================================
// WELLSYSTEM — GERENCIADOR OLT HUAWEI (módulo de interface autossuficiente)
// -----------------------------------------------------------------------------
// Este arquivo funciona em DOIS modos, sem alteração:
//   1) INTEGRADO  — carregado pelo index.php (Radius Wellsystem). Usa os dados de
//                   cliente do Radius (nome/uuid/ip) para enriquecer a lista.
//   2) INDEPENDENTE — carregado pelo olt.php sozinho. Não precisa do Radius:
//                   as funções abaixo detectam a ausência e seguem funcionando
//                   (a coluna Nome mostra o que estiver no cadastro local).
// Só depende de: olt_huawei.php (backend Telnet) + Font Awesome.
// =============================================================================

// --- RESPONSIVIDADE (celular/tablet) -----------------------------------------
// As janelas usam estilo inline (largura fixa/posição por px), então media query
// comum não pega. Aqui injetamos 1x um <style> com !important que, em telas
// pequenas, faz o window principal ocupar a tela toda e as janelas de ONU /
// secundárias caberem em 97vw sem estourar na horizontal. Não reescreve nenhuma
// Injeção de CSS responsivo avançado para todas as resoluções
(function _oltInjResp(){
  if (document.getElementById('oltRespCSS')) return;
  var st = document.createElement('style'); st.id = 'oltRespCSS';
  st.textContent =
    /* Gerenciador aberto: a página de trás não rola e não reserva a faixa da barra de rolagem
       (o html tem scrollbar-gutter:stable — sem isto sobrava uma faixa cinza à direita da janela). */
    'html.olt-aberto{overflow:hidden!important;scrollbar-gutter:auto!important}'+
    'html.olt-aberto body{overflow:hidden!important}'+
    /* Lista: a tabela rola de lado dentro da própria caixa; a coluna Nome nunca quebra letra a letra. */
    '#oltWinBody .oltXScroll{max-width:100%}'+
    '#oltWinBody table.oltTbl td.oltNomeTd{min-width:170px}'+
    /* botão Gerenciar sempre à vista: com a tabela rolando de lado (tela menor), a última coluna fica presa à direita */
    '#oltWinBody table.oltTbl td.oltAcaoTd{position:sticky;right:0;background:inherit;box-shadow:-6px 0 8px -6px rgba(0,0,0,.25)}'+
    '#oltWinBody table.oltTbl th.oltAcaoTh{position:sticky;right:0;background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%))}'+
    /* Notebook / monitor pequeno */
    '@media (max-width: 1200px) {'+
    '  #oltWinHead img{height:46px!important;max-width:240px!important}'+
    '  #oltWinBody table.oltTbl td, #oltWinBody table.oltTbl th{padding-left:6px!important;padding-right:6px!important}'+
    '}'+
    /* Tablet */
    '@media (max-width: 900px) {'+
    '  #oltWin { width: 100vw !important; height: 100vh !important; height: 100dvh !important; max-height: 100dvh !important; min-width: 0 !important; border-radius: 0 !important; left:0!important; top:0!important; }'+
    '  .oltMSWin, [id^="oltWin_"], #oltDocWin, #oltRelWin, #oltDescWin, #oltResumoWin, #oltIntWin, #oltPonWin, #oltApWin {'+
    '    left: 2vw !important; right: auto !important; top: 10px !important; width: 96vw !important; max-width: 96vw !important; min-width:0 !important; max-height: calc(100dvh - 20px) !important; margin:0 !important; resize: none !important;'+
    '  }'+
    '  #oltWinHead .oltBtnLbl{display:none}'+
    '  #oltWinValida{display:none!important}'+
    '  #oltWinBody{padding:10px!important}'+
    /* tabelas das janelas secundárias rolam de lado; a lista principal já tem a própria caixa de rolagem */
    '  .oltMSBody table, #oltWin table:not(.oltTbl), #oltDescBody table {'+
    '    display: block !important; overflow-x: auto !important; white-space: nowrap !important; max-width: 100% !important;'+
    '  }'+
    '  [style*="grid-template-columns"]:not(.oltFootGrid) { grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)) !important; }'+
    '  button[style*="min-width:115px"] { min-width: 0 !important; flex: 1 1 45% !important; }'+
    '  #olt_filtro{font-size:16px!important}'+   /* iPhone não dá zoom ao tocar no campo */
    '}'+
    /* Celular */
    '@media (max-width: 760px) {'+
    '  #oltWinHead{flex-wrap:wrap!important;gap:6px 8px!important;padding:8px 10px!important;border-bottom-width:3px!important;cursor:default!important}'+
    '  #oltWinHead img{height:36px!important;max-width:46vw!important}'+
    '  #oltWinHead > button{width:32px!important;height:30px!important;font-size:14px!important}'+
    '  #oltWinHead > button:first-of-type{margin-left:auto}'+
    '  #oltWinHead .oltWinTit{order:3;flex:1 1 45%!important;min-width:45%!important}'+
    '  #oltWinTitle{font-size:13.5px!important;letter-spacing:.2px!important}'+
    '  #oltWinSub{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'+
    '  #oltWinHead .oltUserBar{order:4;margin:0 0 0 auto!important}'+
    '  #oltWinHead .oltUserBar b{max-width:70px;overflow:hidden;text-overflow:ellipsis}'+
    '  #oltWinBody table.oltTbl{font-size:12px!important}'+
    '  #oltWinBody table.oltTbl td.oltNomeTd{min-width:140px}'+
    '  #oltWinBody table.oltTbl td.oltAcaoTd{padding:6px!important}'+
    '  #oltWinBody table.oltTbl td.oltAcaoTd .oltAcaoLbl{display:none}'+   /* no celular o botão vira só o ícone */
    '  #oltWinBody table.oltTbl td.oltAcaoTd button{padding:8px 11px!important;font-size:14px!important}'+
    '}'+
    '@media (max-width: 520px) {'+
    '  .oltMSWin, [id^="oltWin_"], #oltDocWin, #oltRelWin, #oltDescWin, #oltResumoWin, #oltIntWin, #oltPonWin, #oltApWin {'+
    '    left: 1vw !important; width: 98vw !important; max-width: 98vw !important; top: 4px !important; max-height: calc(100dvh - 8px) !important;'+
    '  }'+
    '  [style*="grid-template-columns"]:not(.oltFootGrid) { grid-template-columns: 1fr 1fr !important; }'+
    '  button[style*="min-width:115px"] { flex-basis: 100% !important; }'+
    '}';
  (document.head||document.documentElement).appendChild(st);
})();

// --- Compatibilidade: define o que normalmente vem da página Radius ----------
// Host do MK-Auth (link "abrir cadastro"). No modo independente fica vazio e os
// links de cadastro simplesmente não são gerados.
if (typeof window.WS_SRV === 'undefined') { window.WS_SRV = ''; }
if (typeof window.WS_LOGO_OLT === 'undefined') { window.WS_LOGO_OLT = ''; }
// Aviso simples (o Radius tem o seu próprio toast; aqui garantimos que exista).
if (typeof window.mostrarToast !== 'function') {
    window.mostrarToast = function (msg) {
        var c = document.getElementById('toast-container');
        if (!c) { c = document.createElement('div'); c.id = 'toast-container';
            c.style.cssText = 'position:fixed; bottom:55px; right:20px; z-index:99999999;'; document.body.appendChild(c); }
        var b = document.createElement('div');
        b.style.cssText = 'background:#1e293b; color:#fff; padding:10px 20px; border-radius:6px; margin-top:5px; box-shadow:0 6px 18px rgba(0,0,0,.35); font-size:13px;';
        b.innerText = msg; c.appendChild(b); setTimeout(function () { b.remove(); }, 3000);
    };
}
// Abrir o equipamento do cliente pelo IP (existe no Radius; replicado p/ o modo independente).
if (typeof window.testarEAbrirIP !== 'function') {
    window.testarEAbrirIP = function (ip) {
        window.mostrarToast('Abrindo console web p/ o IP: ' + ip);
        var E = window.WS_EQUIP || { base: 'http://', porta: '', alt: ':1080' };   // portas configuráveis (Configurações → Geral)
        var novaAba = window.open(E.base + ip + E.porta, '_blank');
        if (novaAba && E.alt) {
            var controller = new AbortController();
            var timeoutId = setTimeout(function () { controller.abort();
                try { novaAba.location.href = E.base + ip + E.alt; } catch (e) {} }, 600);
            fetch(E.base + ip + E.porta, { mode: 'no-cors', signal: controller.signal })
                .then(function () { clearTimeout(timeoutId); }).catch(function () {});
        }
    };
}

// OLT HUAWEI — Gerenciador GPON (janela própria, responsiva)
// =====================================================
// Temas do Gerenciador OLT — 2 cores base (neutro + acento) + status (verde/vermelho).
// Espelha os tokens do design system (:root) para o módulo OLT, que monta estilos por JS.
// CLARO é o tema PRINCIPAL: superfícies brancas, texto quase-preto, acentos saturados.
var OLT_TEMAS = {
  claro:  { bg:'#ffffff', bg2:'#f1f5f9', panel:'#e8edf3', line:'#cdd6e0', txt:'#0f172a', ink:'#0b1220', mut:'#475569', acc:'#2563eb', grn:'#16a34a', red:'#dc2626', redf:'#dc2626', amb:'#b45309', vio:'#7c3aed', nome:'#334155', shnum:'none' },
  // ESCURO redesenhado: slate profundo com texto quase-branco — nada apagado.
  // redf = vermelho de DESTAQUE (texto/ícone/borda sobre fundo escuro): mais claro p/ ficar nítido.
  escuro: { bg:'#3f454c', bg2:'#525a63', panel:'#4a525a', line:'#6e7883', txt:'#ffffff', ink:'#ffffff', mut:'#d9dfe5', acc:'#38bdf8', grn:'#22c55e', red:'#ef4444', redf:'#ff8585', amb:'#f59e0b', vio:'#a855f7', nome:'#ffffff', shnum:'0 1px 0 rgba(0,0,0,.45)' }
};
window._oltTemaAtual = (function(){ try{ return localStorage.getItem('oltTema')||'claro'; }catch(e){ return 'claro'; } })();
var OLTC = OLT_TEMAS[window._oltTemaAtual] || OLT_TEMAS.claro;
function oltTrocarTema(){
    var novo=(window._oltTemaAtual==='escuro')?'claro':'escuro';
    window._oltTemaAtual=novo; window.OLTC=OLT_TEMAS[novo]; OLTC=OLT_TEMAS[novo];
    try{ localStorage.setItem('oltTema',novo); }catch(e){}
    // #8: PRESERVA a geometria/estado antes de recriar (senão "minimizava"/perdia posição)
    var w=document.getElementById('oltWin');
    var g=null, bodyScroll=0;
    var pill=document.getElementById('oltPill'); var estavaMin=!!(pill && pill.style.display!=='none');
    if(w){ var r=w.getBoundingClientRect(); var bd0=document.getElementById('oltWinBody'); bodyScroll=bd0?bd0.scrollTop:0;
        g={ max:w.getAttribute('data-max'), pos:w.style.position, left:w.style.left, top:w.style.top,
            width:w.style.width, height:w.style.height, rw:r.width, rh:r.height, rl:r.left, rt:r.top }; }
    var ov=document.getElementById('oltOverlay'); if(ov) ov.remove(); // recria com as novas cores
    oltGetOverlay(); oltAbrir('Wellsystem OLT — Monitoramento GPON', '10.100.0.2');
    // Restaura a geometria exatamente como estava (maximizado/posição/tamanho)
    var nw=document.getElementById('oltWin'), nov=document.getElementById('oltOverlay');
    if(nw && g){
        if(g.max==='1'){ nw.setAttribute('data-max','1'); nw.style.position='fixed'; nw.style.left='0'; nw.style.top='0'; nw.style.width='100vw'; nw.style.height='100vh'; nw.style.maxHeight='100vh'; nw.style.borderRadius='0'; if(nov){ nov.style.alignItems='flex-start'; nov.style.justifyContent='flex-start'; } }
        else if(g.pos==='fixed'){ nw.style.position='fixed'; nw.style.left=(g.left||g.rl+'px'); nw.style.top=(g.top||g.rt+'px'); nw.style.width=(g.width||g.rw+'px'); nw.style.height=(g.height||g.rh+'px'); if(nov){ nov.style.alignItems='flex-start'; nov.style.justifyContent='flex-start'; } }
        else if(g.width||g.height){ nw.style.width=g.width; nw.style.height=g.height; }
    }
    oltCarregarStatus();
    // NÃO recarrega os dados: re-renderiza a lista que já está em memória (não zera)
    if(window._oltLista && window._oltLista.length){ oltRenderLista(); oltCheckPendentes(); oltIniciarAlertaPendentes(); }
    else { abrirOltHuawei(); }
    var nbd=document.getElementById('oltWinBody'); if(nbd) nbd.scrollTop=bodyScroll;
    if(estavaMin) oltMin(); // continuava minimizado -> permanece minimizado
}
var OLT_SLOTS = [1, 3, 5]; // apenas as placas GPON ativas (H805GPFD). 2 e 4 são vazias — não varrer à toa (velocidade).
// Limiar de sinal: -29.40 dBm. RX melhor/igual (>= -29.40) => "Sinal Bom";
// RX pior (< -29.40, mais negativo) => "Sinal Ruim". (Direção física correta;
// se quiser inverter os rótulos, troque o operador em _oltSinalClasse.)
var OLT_RX_LIMITE = -29.40;
// Classificação Bridge/Router PELO MODELO (Equipment-ID coletado da OLT). Tabela do
// cliente — chave normalizada (maiúsculas, só letras/números). Editável: é só
// adicionar "MODELO":"ONU"/"ONT" aqui conforme aparecerem modelos novos.
var OLT_MODELO_TIPO = {
    // ONU = Bridge
    'R1V2':'ONU', 'R2':'ONU', 'R1':'ONU', 'MONUMAXFIBER1000':'ONU', 'FIBERLINK101':'ONU', 'FIBERLINK100':'ONU', '310M':'ONU',
    // ONT = Router (M10G é router de verdade — confirmado pela config WAN da OLT/SmartOLT)
    'M10G':'ONT', 'MONUV112':'ONT', 'MONUV122':'ONT', 'FIBERLINK410':'ONT', 'FIBERLINK411':'ONT', 'FIBERLINK501':'ONT', 'FIBERLINK501REV2':'ONT', 'EG8145V5':'ONT', 'EG8145V5V2':'ONT', 'EG8145X6':'ONT', 'GPT2742GX4X5':'ONT', 'GPT2741GNACN2':'ONT', 'MULTILASER':'ONT', 'ONTMULTILESE':'ONT', '121AC':'ONT'
};
// NOMES das VLANs (enviados pelo cliente). Editável: é só ajustar/adicionar aqui.
var OLT_VLAN_NOMES = {
    '40':'VOIP-PABX',
    '50':'SLT3_BABI','51':'SLT5_LIMER','52':'SLT3_SERR','53':'SLT3_TAPN','54':'SLT3_L-RM','55':'SLT3_CAMAZ','56':'SLT3_MORJ',
    '150':'SLT1_HOSP','151':'SLT1_JUA1','152':'SLT1_JUA2','153':'SLT1_JC','154':'SLT1_ST FE','155':'SLT1_VILA1','156':'SLT1_VILA2','157':'SLT1_PARA1','158':'SLT1_PARA2','159':'SLT1_XXX','160':'SLT1_XXX','161':'SLT1_XXX','162':'SLT1_CENT','163':'SLT1_NATE','164':'SLT1_CAD1','165':'SLT1_CAD2',
    '250':'SLT3_BERND','251':'SLT3_JARDI','252':'SLT3_JOANA','253':'SLT3_TM 1','254':'SLT3_TM 2','255':'SLT3_XXX','256':'SLT3_XXX','257':'SLT3_XXX','258':'SLT3_MADAL','259':'SLT3_ALT1','260':'SLT3_ALT2','261':'SLT3_STN1','262':'SLT3_STN2','263':'SLT3_CHAN','264':'SLT3_5COR','265':'SLT3_DMT',
    '350':'SLT5_HOP-2','351':'SLT5_COST-P','352':'SLT5_LAUR','353':'SLT5-11_JULHO','354':'SLT5_ESCA','355':'SLT5_FEIR','356':'SLT5_VIERA','357':'SLT5_CELPE','358':'SLT5_R-RIO','359':'SLT5_WELL2','360':'SLT5_XXX','361':'SLT5_XXX','362':'SLT5_XXX','363':'SLT5_XXX','364':'SLT5_XXX','365':'SLT5_XXX',
    '2222':'ESCRITORIO','3333':'CASA_WELL'
};
// PON real de cada VLAN (Placa/Porta) — dos prints do SmartOLT. Faixas 150-165/250-265/350-365
// derivadas (porta = id - base); irregulares explicitas. Vazio = gestao/sem porta fixa.
var OLT_VLAN_PON = {'50':'3/13','51':'5/8','52':'3/10','53':'3/13','54':'3/14','55':'3/1','56':'3/14'};
function _oltVlanPon(id){ id=parseInt(id,10);
    if(OLT_VLAN_PON[id]) return OLT_VLAN_PON[id];
    if(id>=150&&id<=165) return '1/'+(id-150);
    if(id>=250&&id<=265) return '3/'+(id-250);
    if(id>=350&&id<=365) return '5/'+(id-350);
    return ''; }
function _oltVlanPonTxt(id){ var p=_oltVlanPon(id); if(!p) return ''; var a=p.split('/'); return 'Placa '+a[0]+' · Porta '+a[1]; }
function _oltVlanNome(id){ var m=window._oltVlanNomes||{}; return m[''+id]||OLT_VLAN_NOMES[''+id]||''; }
// ZONAS reais usadas (do SmartOLT) — opções do editor de Zona da lista da OLT.
var OLT_ZONAS = ['11 DE JULHO - BR 408','7 SETEMBRO','ALTO DA SANTA 1','ALTO DA SANTA 2','BERNARDO','CADEIA 1','CADEIA 2','CAJUEIRO','CELPE','CENTRO','CHAN BABILONIA','CHAN DEGUINHA','CHAN IRMAO IA - MESSIAS','CHAN LOURDINHA','CHAN TAPINASSU','COMPESA','COSTA PORTO','ENG-CAMARAZAL','ENG-LAGOA DO RAMOS','ENG-SERRA LAGOA','ERMIRIO COUTINHO - HOSPITAL','ESTACAO','JARDIM TAMATAUPE','JC','JOSE VIEIRA','JUA 1','JUA 2','LAURINDO','LOT 5CORACOES','LOT DIAMANTE','MADALENA','NATERCIA - SAO JOAO','PARAISO 1','PARAISO 2','PATIO FEIRA','PEDREGULHO','RUA DO SOL','RUA DO RIO','SANTA FE','SANTA JOANA - NOVA NAZARE','SANTA MARIA-JARDIM TM','SITIO NOVO 1','SITIO NOVO 2','TAMATAUPE 1','TAMATAUPE 2','VILA 1','VILA 2','VILA MALUCA'];
// VLAN -> ZONA (cada VLAN/PON atende uma zona). Deriva a zona da VLAN da ONU quando
// não há zona salva manualmente. Só os mapeamentos com CERTEZA (os ambíguos ficam de
// fora e continuam editáveis/"+ zona"). A edição manual (banco local) SEMPRE vence.
var OLT_VLAN_ZONA = {
    '150':'ERMIRIO COUTINHO - HOSPITAL','151':'JUA 1','152':'JUA 2','153':'JC','154':'SANTA FE','155':'VILA 1','156':'VILA 2','157':'PARAISO 1','158':'PARAISO 2','162':'CENTRO','163':'NATERCIA - SAO JOAO','164':'CADEIA 1','165':'CADEIA 2',
    '50':'CHAN BABILONIA','52':'ENG-SERRA LAGOA','53':'CHAN TAPINASSU','54':'ENG-LAGOA DO RAMOS','55':'ENG-CAMARAZAL',
    '250':'BERNARDO','251':'JARDIM TAMATAUPE','252':'SANTA JOANA - NOVA NAZARE','253':'TAMATAUPE 1','254':'TAMATAUPE 2','258':'MADALENA','259':'ALTO DA SANTA 1','260':'ALTO DA SANTA 2','261':'SITIO NOVO 1','262':'SITIO NOVO 2','264':'LOT 5CORACOES','265':'LOT DIAMANTE',
    '351':'COSTA PORTO','352':'LAURINDO','353':'11 DE JULHO - BR 408','354':'ESTACAO','355':'PATIO FEIRA','356':'JOSE VIEIRA','357':'CELPE','358':'RUA DO RIO'
};
function _oltZonaDoVlan(vlan){ var v=String(vlan||'').replace(/[^0-9]/g,''); return v?(OLT_VLAN_ZONA[v]||''):''; }
// ---- BANCO LOCAL por SN (olt_cadastro.json) — base do "SmartOLT alternativo" ----
function oltCarregarCadastro(){
    fetch('olt_huawei.php?acao=cadastro_get').then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.cadastro){ window._oltCadastro=d.cadastro; _oltAplicarCadastro(); if(oltGerenciadorAberto()) oltRenderLista(); }
    }).catch(function(){});
}
// ---- META: apelidos de Placa/Porta + VLAN padrão por porta (item 9) ----
window._oltMeta = window._oltMeta || {placa:{},porta:{},portavlan:{},portazona:{},portperfil:{}};
function _oltCarregarMeta(){
    fetch('olt_huawei.php?acao=meta_get').then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.meta){ window._oltMeta={placa:d.meta.placa||{},porta:d.meta.porta||{},portavlan:d.meta.portavlan||{},portazona:d.meta.portazona||{},portperfil:d.meta.portperfil||{}}; if(oltGerenciadorAberto()) oltRenderLista(); _oltResumoRefresh(); _oltInterrupcaoRefresh(); }
    }).catch(function(){});
}
function _oltPlacaNome(slot){ var m=window._oltMeta&&window._oltMeta.placa; return (m&&m[String(slot)])||''; }
function _oltPortaNome(fsp){ var m=window._oltMeta&&window._oltMeta.porta; return (m&&m[fsp])||''; }
/* PADRÃO DA PORTA (VLAN / zona / perfil) para o Aprovisionamento vir PREENCHIDO.
   1º o padrão cadastrado à mão para a porta (window._oltMeta); sem ele, INFERE das ONUs já
   autorizadas na MESMA PON (o valor mais usado ali). Antes, sem cadastro manual o card vinha vazio. */
/** Só o padrão CADASTRADO da porta (tela de configuração) — sem inferência. */
function _oltMetaPorta(campo, fsp){ var m=window._oltMeta&&window._oltMeta[campo]; return (m&&m[fsp])||''; }
function _oltMaisUsado(lista, campo){ var c={}, best='', n=0; lista.forEach(function(o){ var v=String((o&&o[campo])||'').trim(); if(!v) return; c[v]=(c[v]||0)+1; if(c[v]>n){ n=c[v]; best=v; } }); return best; }
function _oltDaPon(fsp){ return (window._oltLista||[]).filter(function(o){ return (o.fsp||'')===fsp; }); }
/* PORTA SEM NENHUMA ONU (30/09/2026): sem padrão cadastrado e sem vizinhas para copiar, a VLAN vinha
   em branco. Último recurso: a tabela VLAN -> PON do provedor (OLT_VLAN_PON + faixas 150/250/350),
   SÓ quando uma única VLAN aponta para a porta (ex.: 5/15 -> 365). Porta ambígua (5/8: 51 e 358) fica vazia. */
function _oltVlanDaTabela(fsp){
    var p=String(fsp||'').split('/'); if(p.length<3) return ''; var alvo=p[1]+'/'+p[2];
    var c={}, k, i; Object.keys(OLT_VLAN_PON).concat(Object.keys(OLT_VLAN_NOMES)).forEach(function(x){ c[x]=1; });
    for(i=150;i<=165;i++)c[i]=1; for(i=250;i<=265;i++)c[i]=1; for(i=350;i<=365;i++)c[i]=1;
    var achou=[]; for(k in c){ if(_oltVlanPon(k)===alvo) achou.push(String(parseInt(k,10))); }
    return achou.length===1?achou[0]:'';
}
function _oltPortaVlan(fsp){ var m=window._oltMeta&&window._oltMeta.portavlan; return (m&&m[fsp])||(_oltMaisUsado(_oltDaPon(fsp),'vlan').match(/\d+/)||[''])[0]||_oltVlanDaTabela(fsp); }
function _oltPortaZona(fsp){ var m=window._oltMeta&&window._oltMeta.portazona; return (m&&m[fsp])||_oltMaisUsado(_oltDaPon(fsp),'zona')||_oltZonaDoVlan(_oltPortaVlan(fsp)); }
/** Id do srv-profile pelo NOME (a lista da OLT tem nome → id). */
function _oltSrvIdPorNome(nm){ nm=String(nm||'').trim().toUpperCase(); if(!nm) return ''; var s=(window._oltPerfisOlt&&window._oltPerfisOlt.srv)||[]; for(var k=0;k<s.length;k++){ if(String(s[k].nome||'').trim().toUpperCase()===nm) return String(s[k].id); } return ''; }
/** Perfil: 1º o do MESMO MODELO (o que as outras ONUs desse modelo usam); 2º o padrão/mais usado da porta. */
/* ============================================================================================
 * PERFIL SUGERIDO NO APROVISIONAMENTO — VALIDADO (23/09/2026). NÃO MEXER SEM RODAR OS CASOS ABAIXO.
 * tp = 'router' | 'bridge' (pelo modelo: rede > tipo cadastrado do modelo > regra por nome) ou ''.
 * Ordem (vale o 1º candidato que for do tipo certo E estiver no menu):
 *   1) mais usado pelo MESMO MODELO na rede
 *   2) TABELA DO PROVEDOR (_oltPerfilTabela) — pelo modelo
 *   3) padrão da PORTA (Gerenciar Porta)
 *   4) mais usado do mesmo FABRICANTE (4 letras do modelo)
 *   5) mais usado na PON
 *   6) mais usado na OLT
 *   7) padrão do tipo: Router -> ONT-HUAWEI-v2 (68) · Bridge -> MAX1000 (11) — nunca em branco
 * Casos validados (dados simulados, porta com padrão MAX1000):
 *   MONUV112 -> ONT-MAX/Router · EG8145V5 -> ONT-HUAWEI-v2/Router (com e sem histórico)
 *   HG8245H -> ONT-HUAWEI-v2/Router · HG8010H -> HG8010H/Bridge · R1v2 -> INTEL-R1/Bridge
 *   MONUMAXFIBER1000 -> MAX1000/Bridge · FiberLink410 -> ONT-FIBERLINK/Router · FiberLink101 -> MAX-M10/Bridge
 *   modelo vazio -> MAX1000/Bridge · perfis não carregados -> branco com aviso
 *   121AC (ONT Intelbras) -> ONT-INTELBRAS-121/Router + genérico Generic_1_V<VLAN> (23/09/2026)
 *   Fiberlink501(Rev2) -> ONT-FIBERLINK/Router · MONUV122 -> ONT-MAX/Router (23/09/2026)
 * Sempre editável: escolha manual (perfil ou Tipo) vence.
 * ============================================================================================ */
/** Tabela do provedor: perfil pelo MODELO (e tipo, quando o mesmo fabricante tem Router e Bridge). */
function _oltPerfilTabela(md, tp){
    if(/^HG8010|^HG8310/.test(md) && tp!=='router') return 'HG8010H';                 // Huawei básica 1 porta
    if(/^(EG8|HG82|HG84|HG814|HS8|WA8)|HUAWEI/.test(md) && tp!=='bridge') return 'ONT-HUAWEI-v2';   // Huawei Wi-Fi
    if(/^121|INTELBRAS121|^ITBS121/.test(md) && tp!=='bridge') return 'ONT-INTELBRAS-121'; // Intelbras 121/121AC (ONT Router)
    if(/^R1|^R2|^INTEL|^ITBS/.test(md) && tp!=='router') return 'INTEL-R1';            // Intelbras R1/R2
    if(/^FIBERLINK[2-9]/.test(md) && tp!=='bridge') return 'ONT-FIBERLINK';              // Fiberlink 410/411/501 (Router)
    if(/^FIBERLINK[0-9]|^MG10|^M10G/.test(md) && tp!=='router') return 'MAX-M10';        // Fiberlink/MG10 (Bridge)
    if(/MULTI|^ML/.test(md) && tp!=='bridge') return 'ONT-MULTILESE';                    // Multilaser
    if(/^MONU|MAXPRINT|^MP/.test(md)){ if(tp==='router') return 'ONT-MAX'; if(tp==='bridge') return 'MAX1000'; }   // Maxprint
    return '';
}
function _oltPortaPerfil(fsp, modelo, tp){
    var _nm=function(x){ return String(x||'').toUpperCase().replace(/[^0-9A-Z]/g,''); };   // "MONU V112" = "MONUV112"
    var md=_nm(modelo), L=window._oltLista||[], srvL=(window._oltPerfisOlt&&window._oltPerfisOlt.srv)||[];
    var srvDe=function(o){ return String(o.srv||o.srvprofile||'').trim(); };
    var nomeDeId=function(id){ for(var k=0;k<srvL.length;k++){ if(String(srvL[k].id)===String(id)) return String(srvL[k].nome||''); } return ''; };
    var ok=function(nome){ if(!nome) return false; if(!tp) return true; var r=/^ONT/i.test(nome); return tp==='router'?r:!r; };
    var maisUsado=function(lista){ var c={}, best='', n=0; lista.forEach(function(o){ var v=srvDe(o); if(!v||!ok(v)) return; c[v]=(c[v]||0)+1; if(c[v]>n){ n=c[v]; best=v; } }); return best; };
    var cands=[], orig=[]; var add=function(n,o){ cands.push(n); orig.push(o); };
    if(md) add(maisUsado(L.filter(function(o){ return _nm(o.modelo)===md; })),'mesmo modelo na rede');   // 1
    if(md) add(_oltPerfilTabela(md, tp),'tabela do provedor');                                          // 2
    var m=window._oltMeta&&window._oltMeta.portperfil; if(m&&m[fsp]) add(nomeDeId(m[fsp]),'padrão da porta');   // 3
    var fab=md.slice(0,4); if(fab && tp) add(maisUsado(L.filter(function(o){ return _nm(o.modelo).slice(0,4)===fab; })),'mesmo fabricante');   // 4
    add(maisUsado(_oltDaPon(fsp)),'mais usado na PON');                                                  // 5
    if(tp) add(maisUsado(L),'mais usado na OLT');                                                        // 6
    add(tp==='router'?'ONT-HUAWEI-v2':'MAX1000','padrão '+(tp==='router'?'Router':'Bridge'));             // 7
    // só aceita perfil que APARECE na lista do aprovisionamento (curada) — senão pula p/ o próximo
    var noMenu={}; try{ _oltSrvCuradosAp().forEach(function(p){ noMenu[String(p.id)]=1; }); }catch(e){}
    window._oltPerfOrig='';
    if(!srvL.length){ window._oltPerfOrig='lista de perfis da OLT ainda não carregou'; return ''; }
    for(var i=0;i<cands.length;i++){ if(ok(cands[i])){ var id=_oltSrvIdPorNome(cands[i]); if(id && noMenu[id]){ window._oltPerfOrig=orig[i]+(md?(' · modelo '+md):'')+(tp?(' · '+tp):''); return id; } } }
    window._oltPerfOrig='nenhum perfil da lista combinou'+(md?(' (modelo '+md+')'):' (modelo não informado pela OLT)');
    return '';
}
function _oltMetaSet(grupo,chave,valor){
    window._oltMeta=window._oltMeta||{placa:{},porta:{},portavlan:{}}; window._oltMeta[grupo]=window._oltMeta[grupo]||{};
    if(valor==='') delete window._oltMeta[grupo][chave]; else window._oltMeta[grupo][chave]=valor;
    return fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=meta_set&grupo='+encodeURIComponent(grupo)+'&chave='+encodeURIComponent(chave)+'&valor='+encodeURIComponent(valor)})
        .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); if(oltGerenciadorAberto()) oltRenderLista(); _oltResumoRefresh(); _oltInterrupcaoRefresh(); return d; }).catch(function(){});
}
// Resolve/corrige a permissão de gravação AUTOMATICAMENTE (faz pelo usuário). Avisa só se não der.
function _oltCorrigirGravacao(){
    fetch('olt_huawei.php?acao=fix_perms').then(function(r){ return r.json(); }).then(function(d){
        if(!d) return;
        if(d.gravavel===false && !window._oltPermWarned){ window._oltPermWarned=true;
            alert('Não consegui gravar em disco em nenhuma pasta disponível.\n\nPasta testada: '+(d.dir||'cache_trafego')+(d.owner?('\nDono: '+d.owner):'')+'\n\nÚltimo recurso, rodar no servidor uma vez:\nchmod -R 777 "'+(d.dir||'cache_trafego')+'"');
            return; }
        // Gravável. Se caiu na pasta temporária do sistema, registra (funciona; p/ permanência total,
        // o ideal é liberar escrita na cache_trafego do addon — mas já grava sem você fazer nada).
        if(d.gravavel && d.dir && (''+d.dir).indexOf('addons')<0 && !window._oltTmpInfo){ window._oltTmpInfo=true;
            try{ console.log('[OLT] Gravação OK em pasta alternativa: '+d.dir+' — persiste normal. (Para 100% permanente mesmo após reboot, libere escrita na cache_trafego do addon.)'); }catch(e){}
        }
    }).catch(function(){});
}
// SEED (importação ÚNICA) do SmartOLT -> banco local. Casa por POSIÇÃO (F/S/P+ID) e,
// como fallback, por SN. Preenche Zona/Nome/Tipo SEM sobrescrever suas edições.
function oltSeedSmartOLT(){
    if(!window._oltLista || !window._oltLista.length){ alert('Abra/varra a lista da OLT antes de importar.'); return; }
    if(!confirm('Importar do SmartOLT (uma vez) para o banco local?\n\nPreenche Zona, Nome e Tipo das ONUs a partir do SmartOLT — SEM sobrescrever o que você já editou/autorizou aqui.\n\nContinuar?')) return;
    var btn=document.getElementById('oltSeedBtn'); if(btn){ btn.disabled=true; btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Importando...'; }
    fetch('olt_huawei.php?acao=smartolt_map').then(function(r){ return r.json(); }).then(function(d){
        var map=(d&&d.map)||{}; var itens=[];
        (window._oltLista||[]).forEach(function(o){
            if(!o.serial) return;
            var snK=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
            var rec=map['pos:'+(o.fsp||'')+'|'+(o.id||'')] || map['sn:'+snK] || map[snK] || null;
            if(!rec) return;
            var it={serial:o.serial};
            if(rec.zona) it.zona=rec.zona;
            if(rec.nome) it.nome=rec.nome;
            if(rec.tipo) it.tipo=rec.tipo;
            if(Object.keys(it).length>1) itens.push(it);
        });
        if(!itens.length){ alert('Nenhuma ONU casou com o SmartOLT. Verifique se a API está ativa (acao=smartolt_debug).'); _oltSeedReset(btn); return; }
        fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_seed&itens='+encodeURIComponent(JSON.stringify(itens))})
          .then(function(r){ return r.json(); }).then(function(res){
            oltCarregarCadastro();
            alert('Seed concluído.\n\nONUs preenchidas: '+(res.onus_gravadas||0)+'\nCampos gravados: '+(res.campos_gravados||0)+'\nTotal no banco local: '+(res.total||0)+'\n\nCasaram com o SmartOLT: '+itens.length+' de '+window._oltLista.length+'.');
            _oltSeedReset(btn);
          }).catch(function(){ alert('Falha ao gravar o seed no banco local.'); _oltSeedReset(btn); });
    }).catch(function(){ alert('Falha ao consultar o SmartOLT (API/token).'); _oltSeedReset(btn); });
}
function _oltSeedReset(btn){ if(btn){ btn.disabled=false; btn.innerHTML='<i class="fa-solid fa-cloud-arrow-down"></i> Atualizar do SmartOLT (nuvem)'; } }
// ===== Mkfiles — gerenciador de arquivos (fotos de modelos, logomarcas, etc.) =====
// Upload/lista/deleta arquivos gravados numa pasta "Mkfiles" no servidor. Serve as imagens
// por mkfiles_get (usado no <img src>). PNG/JPEG/WEBP/GIF/SVG/PDF até 5 MB.
/* alvo = modelo (chave da foto, ex.: "GPT-2741GNAC-N2") quando a janela é aberta pelo 📷 da lista ou pelo ícone do
 * topo do detalhe (oltModeloImg). Com alvo, CLICAR NUMA FOTO ANEXA ela ao modelo (_oltMkUsar). Sem alvo (menu), é só o
 * gerenciador de arquivos, como sempre foi. 24/09/2026: antes o clique só abria a foto em nova aba e nada anexava. */
function oltMkfiles(alvo){
    window._oltMkAlvo=alvo?String(alvo).toUpperCase().trim():null;
    var corpo=
        (window._oltMkAlvo?('<div style="margin-bottom:10px; padding:9px 11px; border-radius:8px; background:rgba(22,163,74,.12); color:'+OLTC.grn+'; font-size:12px; font-weight:700; line-height:1.5;"><i class="fa-solid fa-hand-pointer"></i> Clique numa foto para anexar ao modelo <b>'+_oltEsc(window._oltMkAlvo)+'</b> — ou envie uma nova e clique nela. <span id="oltMkUsarSt"></span></div>'):'')+
        '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:10px; line-height:1.5;">Envie fotos dos modelos de ONU/ONT, logomarcas e outros arquivos. Ficam gravados numa pasta <b>Mkfiles</b> no servidor (PNG, JPEG, WEBP, GIF, SVG ou PDF · até 5 MB).</div>'+
        '<div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin-bottom:12px;">'+
          '<label style="cursor:pointer; padding:9px 14px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:12.5px;"><i class="fa-solid fa-upload"></i> Enviar arquivo<input type="file" accept="image/*,application/pdf" multiple onchange="oltMkfilesUpload(this)" style="display:none;"></label>'+
          '<button onclick="oltMkfilesReload(this)" style="cursor:pointer; padding:9px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11.5px;"><i class="fa-solid fa-arrows-rotate"></i> Atualizar</button>'+
          '<span id="oltMkStatus" style="font-size:11px; color:'+OLTC.mut+';"></span>'+
        '</div>'+
        '<div id="oltMkBody"><div style="color:'+OLTC.mut+'; padding:10px;">Carregando…</div></div>';
    _oltModalSimples('fa-folder-open','Modelos ONT / ONU', corpo, false);
    oltMkfilesReload();
}
/* LISTAGEM DO MKFILES — com prazo e com o motivo do erro na tela.
 *
 * Tinha dois problemas, e os dois deixavam o operador sem informação nenhuma:
 *
 * 1. "Carregando…" ETERNO. Se a requisição ficasse pendurada (servidor sem responder, sessão
 *    redirecionando), nem o `then` nem o `catch` rodavam — a tela ficava com "Carregando…" para
 *    sempre, e a conclusão natural era "a tela está quebrada". Agora há PRAZO: passados 12s, a
 *    espera é abandonada e a tela diz que o servidor não respondeu.
 *
 * 2. "Falha ao listar os arquivos." e nada mais. Essa frase não permite consertar nada. As causas
 *    reais são distinguíveis e agora aparecem: HTTP 403 (a sessão perdeu o nível de acesso), HTTP
 *    500 (erro de PHP) ou uma resposta que não é JSON (redirecionamento para o login — o começo do
 *    corpo mostra isso na hora).
 *
 * Mostra também o CAMINHO da pasta e avisa quando ela não aceita escrita — sem isso, enviar um
 * arquivo "dava certo" e ele não aparecia, que é exatamente o defeito relatado.
 */
function oltMkfilesReload(btn){
    var ic=btn&&btn.querySelector('i'); if(ic) ic.classList.add('fa-spin');
    var pronto=false;
    var erro=function(msg){
        if(pronto) return; pronto=true;
        var b=document.getElementById('oltMkBody');
        if(b) b.innerHTML='<div style="color:'+OLTC.red+'; padding:12px; font-size:12px; line-height:1.6;">'+msg+'</div>';
        if(ic) ic.classList.remove('fa-spin');
    };
    // Prazo: nenhuma espera pode ser infinita numa tela de operação.
    setTimeout(function(){ erro('<b>O servidor não respondeu em 20 segundos.</b><br>A listagem é uma leitura de arquivos no próprio servidor e não deveria demorar. Recarregue a página; se repetir, o motivo estará no log de erro do Apache.'); }, 20000);

    /* FORA DA FILA SERIAL — e é esta linha que conserta o "não carregou".
     *
     * O oltFetch enfileira TODA requisição e executa uma por vez, com vigia de 25 segundos. Faz
     * sentido para o que fala com a OLT: a Huawei tem poucas sessões VTY e duas varreduras juntas
     * derrubam as duas. Mas listar arquivos é leitura do disco do próprio servidor — não toca na
     * OLT, e não tem razão nenhuma para esperar atrás de uma varredura Telnet que leva um minuto.
     *
     * Era isso que acontecia: a tela da OLT tinha uma varredura em andamento, o mkfiles_list ficava
     * na fila, e a vez dele nunca chegava dentro do prazo. O sintoma era "não carregou" — e não
     * havia erro nenhum, porque a requisição nem tinha sido enviada ainda. */
    _oltFetchDireto('olt_huawei.php?acao=mkfiles_list', 18000).then(function(r){
        return r.text().then(function(txt){
            if(!r.ok) throw new Error('O servidor respondeu HTTP '+r.status+'.'
                + (r.status===403?' Sua sessão não tem permissão para ver os arquivos — saia e entre de novo.':'')
                + (r.status===500?' Houve erro de PHP no servidor; o motivo está no log de erro do Apache.':''));
            try { return JSON.parse(txt); }
            catch(e){ throw new Error('A resposta não é JSON — provavelmente a sessão expirou e o servidor devolveu a tela de login.<br><br><code style="font-size:10.5px; opacity:.85;">'+_oltEsc(txt.slice(0,160))+'</code>'); }
        });
    }).then(function(d){
        if(pronto) return; pronto=true;
        var b=document.getElementById('oltMkBody');
        if(!b) return;
        var aviso='';
        if(d && d.gravavel===false){
            aviso='<div style="margin-bottom:10px; padding:9px 11px; border-radius:8px; background:rgba(220,38,38,.10); color:'+OLTC.red+'; font-size:11.5px; line-height:1.55;">'
                + '<b>A pasta não aceita gravação.</b> Enviar arquivo vai falhar. Caminho: <code>'+_oltEsc(d.caminho||'')+'</code>'
                + '<br>No servidor: <code>chown -R www-data:www-data</code> e <code>chmod 775</code> nessa pasta.</div>';
        }
        b.innerHTML=aviso+_oltMkfilesHtml((d&&d.arquivos)||[]);
        if(ic) ic.classList.remove('fa-spin');
    }).catch(function(e){
        erro('<b>Não consegui listar os arquivos.</b><br>'+(e&&e.message?e.message:'Erro de rede.'));
    });
}
function _oltMkfilesHtml(arr){
    if(!arr.length) return '<div style="color:'+OLTC.mut+'; padding:16px; text-align:center;">Nenhum arquivo ainda. Clique em <b>Enviar arquivo</b>.</div>';
    var kb=function(n){ return n<1024?(n+' B'):(n<1048576?((Math.round(n/102.4)/10)+' KB'):((Math.round(n/104857.6)/10)+' MB')); };
    return '<div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(128px,1fr)); gap:10px;">'+arr.map(function(f){
        var url='olt_huawei.php?acao=mkfiles_get&nome='+encodeURIComponent(f.nome);
        var isImg=/^(png|jpe?g|webp|gif|svg)$/i.test(f.ext||'');
        var thumb=isImg?('<img src="'+url+'" loading="lazy" style="width:100%; height:88px; object-fit:contain; background:'+OLTC.panel+'; border-radius:8px;">')
                       :('<div style="width:100%; height:88px; display:flex; align-items:center; justify-content:center; background:'+OLTC.panel+'; border-radius:8px; color:'+OLTC.mut+'; font-size:26px;"><i class="fa-solid fa-file-'+((f.ext||'')==='pdf'?'pdf':'lines')+'"></i></div>');
        return '<div style="border:1px solid '+OLTC.line+'; border-radius:10px; padding:8px; background:'+OLTC.bg2+';">'+
            ((window._oltMkAlvo && isImg)
              ? ('<div onclick="_oltMkUsar(\''+encodeURIComponent(f.nome)+'\')" title="Anexar esta foto ao modelo '+_oltEsc(window._oltMkAlvo)+'" style="cursor:pointer; outline:2px dashed '+OLTC.grn+'66; border-radius:8px;">'+thumb+'</div>')
              : ('<a href="'+url+'" target="_blank" title="Abrir em nova aba">'+thumb+'</a>'))+
            '<div title="'+_oltEsc(f.nome)+'" style="font-size:10.5px; color:'+OLTC.ink+'; font-weight:700; margin-top:6px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+_oltEsc(f.nome)+'</div>'+
            '<div style="display:flex; align-items:center; justify-content:space-between; margin-top:4px;">'+
              '<span style="font-size:10px; color:'+OLTC.mut+';">'+kb(f.tam||0)+'</span>'+
              '<span style="display:inline-flex; gap:9px;">'+
                '<i onclick="_oltCopiar(\''+_oltEsc(f.nome)+'\')" title="Copiar o nome do arquivo" class="fa-regular fa-copy" style="cursor:pointer; color:'+OLTC.acc+'; font-size:12px;"></i>'+
                '<i onclick="oltMkfilesDel(\''+_oltEsc(f.nome)+'\')" title="Excluir" class="fa-solid fa-trash" style="cursor:pointer; color:'+OLTC.red+'; font-size:12px;"></i>'+
              '</span>'+
            '</div>'+
        '</div>';
    }).join('')+'</div>';
}
/* Anexa a foto do Mkfiles ao modelo da janela (window._oltMkAlvo): lê a imagem, reduz para no máx. 800 px em JPEG
 * (o servidor aceita PNG/JPEG < 1,6 MB) e grava pelo MESMO modelo_img_set de sempre (olt_modelo_img.json, entra no backup). */
function _oltMkUsar(nomeEnc){
    var alvo=window._oltMkAlvo; if(!alvo) return; var nome=decodeURIComponent(nomeEnc);
    var st=document.getElementById('oltMkUsarSt'); var msg=function(h){ if(st) st.innerHTML=h; };
    msg('<i class="fa-solid fa-spinner fa-spin"></i> anexando…');
    var img=new Image();
    img.onload=function(){ try{
        var max=800, w=img.naturalWidth||img.width, h=img.naturalHeight||img.height, k=Math.min(1, max/Math.max(w,h));
        var c=document.createElement('canvas'); c.width=Math.max(1,Math.round(w*k)); c.height=Math.max(1,Math.round(h*k));
        var x=c.getContext('2d'); x.fillStyle='#fff'; x.fillRect(0,0,c.width,c.height); x.drawImage(img,0,0,c.width,c.height);
        var q=0.85, d=c.toDataURL('image/jpeg',q); while(d.length>1500000 && q>0.4){ q-=0.15; d=c.toDataURL('image/jpeg',q); }
        fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=modelo_img_set&chave='+encodeURIComponent(alvo)+'&img='+encodeURIComponent(d)})
          .then(function(r){return r.json();}).then(function(res){
            if(!(res&&res.saved)){ msg('<span style="color:'+OLTC.red+';">não gravou (permissão da pasta de cache da OLT).</span>'); return; }
            window._oltModeloImgCache=window._oltModeloImgCache||{}; window._oltModeloImgCache[alvo]=d;
            window._oltModeloImgKeys=window._oltModeloImgKeys||[]; if(window._oltModeloImgKeys.indexOf(alvo)<0) window._oltModeloImgKeys.push(alvo);
            msg('✅ anexada!');
            // ícone do topo do detalhe aberto (se for deste modelo) e a lista passam a mostrar a foto
            document.querySelectorAll('[id^="olt_hicon_"]').forEach(function(bx){ if(bx.getAttribute('data-mk')===alvo) bx.innerHTML='<img src="'+d+'" style="width:100%; height:100%; object-fit:contain; cursor:pointer;">'; });
            if(typeof oltRenderLista==='function'){ try{ oltRenderLista(); }catch(e){} }
          }).catch(function(){ msg('<span style="color:'+OLTC.red+';">erro ao gravar.</span>'); });
    }catch(e){ msg('<span style="color:'+OLTC.red+';">não consegui preparar esta imagem.</span>'); } };
    img.onerror=function(){ msg('<span style="color:'+OLTC.red+';">não consegui abrir esta imagem.</span>'); };
    img.src='olt_huawei.php?acao=mkfiles_get&nome='+encodeURIComponent(nome);
}
function oltMkfilesUpload(input){
    var files=input&&input.files; if(!files||!files.length) return;
    var st=document.getElementById('oltMkStatus'); var total=files.length, feito=0, erros=0;
    function up(idx){
        if(idx>=files.length){ if(st) st.textContent=feito+' enviado(s)'+(erros?(' · '+erros+' erro(s)'):''); input.value=''; oltMkfilesReload(); return; }
        var file=files[idx];
        if(file.size>5*1024*1024){ erros++; up(idx+1); return; }
        if(st) st.textContent='Enviando '+(idx+1)+'/'+total+'… '+file.name;
        var rd=new FileReader();
        rd.onload=function(){ var body='acao=mkfiles_upload&nome='+encodeURIComponent(file.name)+'&img='+encodeURIComponent(rd.result);
            fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body}).then(function(r){return r.json();}).then(function(d){ if(d&&d.saved) feito++; else { erros++; if(st&&d&&d.message) st.textContent=d.message; } up(idx+1); }).catch(function(){ erros++; up(idx+1); });
        };
        rd.onerror=function(){ erros++; up(idx+1); };
        rd.readAsDataURL(file);
    }
    up(0);
}
function oltMkfilesDel(nome){
    if(!confirm('Excluir o arquivo "'+nome+'"?')) return;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=mkfiles_del&nome='+encodeURIComponent(nome)}).then(function(r){return r.json();}).then(function(){ oltMkfilesReload(); }).catch(function(){ oltMkfilesReload(); });
}
// ---- Notificações de alerta (Telegram / WhatsApp) ----
function oltNotificacoes(){
    if(!_oltExigeNivel(2,'Configurar notificações')) return;
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483200; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.55);';
    var s=_oltInSt();
    var lbl=function(t,h){ return '<div style="font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700; margin:10px 0 3px;">'+t+(h?' <span style="text-transform:none; font-weight:400;">'+h+'</span>':'')+'</div>'; };
    ov.innerHTML='<div id="oltNtfBox" style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; width:min(96vw,520px); max-height:90vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+
        '<div id="oltNtfHead" style="flex:0 0 auto; padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:10px; cursor:move;"><i class="fa-solid fa-bell" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff;">Notificações de alerta (PON em queda)</div><button onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div style="flex:1 1 auto; overflow:auto; padding:14px 16px;">'+
          '<label style="display:flex; align-items:center; gap:8px; font-weight:700; color:'+OLTC.txt+';"><input type="checkbox" id="ntfAtivo"> Enviar automático quando uma PON cair / normalizar</label>'+
          lbl('Telegram — Bot Token','(1 vez, do @BotFather — só se usar Telegram)')+'<input id="ntfTgToken" placeholder="123456789:AAE..." style="'+s+' width:100%; box-sizing:border-box;">'+
          lbl('E-mails dos avisos','(opcional — vários separados por vírgula; sai pelo e-mail do ERP, o mesmo SMTP dos backups)')+'<input id="ntfEmails" placeholder="nome@empresa.com.br, outro@empresa.com.br" style="'+s+' width:100%; box-sizing:border-box;">'+
          lbl('Evolution API','(opcional — servidor WhatsApp próprio, 1 vez)')+
          '<div style="font-size:11px; color:'+OLTC.mut+'; margin:0 0 4px;">Só para o <b>WhatsApp comum</b> (número conectado pelo QR code). Instância principal envia; se ela não responder, a <b>reserva</b> assume. O <b>WhatsApp com API</b> não usa estes campos: vai pelo Servidor de WhatsApp do ERP.</div>'+
          '<div style="display:flex; gap:8px;"><input id="ntfEvoUrl" placeholder="URL (ex.: https://evo.seudominio.com)" style="'+s+' flex:2 1 auto; min-width:0;"></div>'+
          '<div style="display:flex; gap:8px; margin-top:6px;"><input id="ntfEvoInst" placeholder="instância principal" style="'+s+' flex:1 1 0; min-width:0;"><input id="ntfEvoInst2" placeholder="instância reserva (opcional)" style="'+s+' flex:1 1 0; min-width:0;"></div>'+
          '<input id="ntfEvoKey" placeholder="apikey da Evolution (Global/instância)" style="'+s+' width:100%; box-sizing:border-box; margin-top:6px;">'+
          '<div style="display:flex; align-items:center; justify-content:space-between; margin:14px 0 6px;"><div style="font-weight:800; color:'+OLTC.acc+'; font-size:12px;"><i class="fa-solid fa-users"></i> Destinatários</div><button onclick="_oltNotifAddRow()" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-plus"></i> Adicionar</button></div>'+
          '<div id="ntfDestinos"></div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:6px;">Cada destinatário: escolha o <b>canal</b> e ponha os celulares — <b>+ celular</b> acrescenta outro número na mesma linha; <b>+ Adicionar</b> cria outro destinatário. <b>WhatsApp com API</b> = pelo Servidor de WhatsApp do ERP (janela de 24h, template, duas instâncias). <b>WhatsApp comum</b> = pela Evolution da OLT acima, sempre texto. <b>Telegram</b> = Chat ID (via <b>@userinfobot</b>).</div>'+
          '<div id="ntfResult" style="margin-top:12px; font-size:12px;"></div>'+
        '</div>'+
        '<div style="flex:0 0 auto; padding:12px 16px; border-top:1px solid '+OLTC.line+'; display:flex; gap:8px; justify-content:flex-end;">'+
          '<button onclick="oltNotifDiag()" title="Envia usando EXATAMENTE a configuração salva — o mesmo caminho do alerta automático" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.amb+'; background:transparent; color:'+OLTC.amb+'; font-weight:800; margin-right:auto;"><i class="fa-solid fa-stethoscope"></i> Diagnóstico do alerta</button>'+
          '<button onclick="oltNotifTestar()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800;"><i class="fa-solid fa-paper-plane"></i> Testar</button>'+
          '<button onclick="oltNotifSalvar()" style="cursor:pointer; padding:9px 18px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>'+
        '</div>'+
    '</div>';
    document.body.appendChild(ov);
    (function(){ var box=document.getElementById('oltNtfBox'), hd=document.getElementById('oltNtfHead'); if(!box||!hd) return;
        hd.addEventListener('mousedown', function(e){ if(e.target.closest('button')) return; e.preventDefault();
            var r=box.getBoundingClientRect(); ov.style.alignItems='flex-start'; ov.style.justifyContent='flex-start';
            box.style.position='fixed'; box.style.margin='0'; box.style.left=r.left+'px'; box.style.top=r.top+'px';
            var sx=e.clientX, sy=e.clientY, ox=r.left, oy=r.top;
            function mv(ev){ box.style.left=Math.max(0,ox+ev.clientX-sx)+'px'; box.style.top=Math.max(0,oy+ev.clientY-sy)+'px'; }
            function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
            document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
        });
    })();
    fetch('olt_huawei.php?acao=notif_get').then(function(r){return r.json();}).then(function(d){ var c=(d&&d.cfg)||{}; window._oltErpMeta=!!(d&&d.erp_meta); window._oltIsolada=!!(d&&d.isolada); var g=function(id){return document.getElementById(id);};
        if(g('ntfAtivo')) g('ntfAtivo').checked=!!c.ativo; if(g('ntfTgToken')) g('ntfTgToken').value=c.tg_token||''; if(g('ntfEmails')) g('ntfEmails').value=c.emails||'';
        if(g('ntfEvoUrl')) g('ntfEvoUrl').value=c.evo_url||''; var _ins=String(c.evo_instance||'').split(/[,;\s]+/).filter(Boolean); if(g('ntfEvoInst')) g('ntfEvoInst').value=_ins[0]||''; if(g('ntfEvoInst2')) g('ntfEvoInst2').value=_ins.slice(1).join(', '); if(g('ntfEvoKey')) g('ntfEvoKey').value=c.evo_apikey||'';
        var dst=(c.destinos&&c.destinos.length)?c.destinos:[{canal:'sistema'}]; dst.forEach(function(x){ _oltNotifAddRow(x); });
    }).catch(function(){ _oltNotifAddRow({canal:'sistema'}); });
}
// --- destinatários (linhas dinâmicas) ---
function _oltNotifRow(d){ d=d||{}; var s=_oltInSt(); var canal=d.canal||'sistema';
    var showNum=(canal==='whatsapp'||canal==='ambos'||canal==='evolution'||canal==='sistema'), showKey=(canal==='whatsapp'||canal==='ambos'), showTg=(canal==='telegram'||canal==='ambos');
    return '<div class="ntf-row" style="border:1px solid '+OLTC.line+'; border-radius:10px; padding:10px; margin-bottom:8px; background:'+OLTC.bg2+';">'+
        '<div style="display:flex; gap:8px; align-items:center; margin-bottom:6px;">'+
          '<select class="ntf-canal" onchange="_oltNotifToggle(this)" style="'+s+' flex:0 0 190px;">'+((window._oltIsolada&&canal!=='sistema')?'':'<option value="sistema"'+(canal==='sistema'?' selected':'')+'>'+(window._oltErpMeta===false?'WhatsApp comum (servidor do ERP)':'WhatsApp com API (servidor do ERP)')+'</option>')+'<option value="evolution"'+(canal==='evolution'?' selected':'')+'>WhatsApp comum (Evolution da OLT)</option><option value="telegram"'+(canal==='telegram'?' selected':'')+'>Telegram</option>'+((canal==='whatsapp'||canal==='ambos')?'<option value="whatsapp"'+(canal==='whatsapp'?' selected':'')+'>CallMeBot (antigo)</option><option value="ambos"'+(canal==='ambos'?' selected':'')+'>CallMeBot + Telegram (antigo)</option>':'')+'</select>'+
          '<input class="ntf-nome" value="'+_oltEsc(d.nome||'')+'" placeholder="nome (opcional)" style="'+s+' flex:1 1 auto; min-width:0;">'+
          '<button onclick="this.closest(\'.ntf-row\').remove()" title="Remover" style="cursor:pointer; width:32px; height:32px; flex:0 0 auto; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.red+';"><i class="fa-solid fa-trash"></i></button>'+
        '</div>'+
        '<div class="ntf-num" style="margin-bottom:6px; display:'+(showNum?'block':'none')+';">'+
          (function(){ var l=String(d.phone||'').split(/[,;\s]+/).filter(Boolean); if(!l.length) l=['']; return l.map(function(t){ return _oltNotifCelular(t); }).join(''); })()+
          '<button type="button" class="ntf-mais" onclick="_oltNotifMaisCelular(this)" style="cursor:pointer; padding:4px 10px; border-radius:7px; border:1px dashed '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-size:11.5px; font-weight:700;"><i class="fa-solid fa-plus"></i> celular</button>'+
        '</div>'+
        '<input class="ntf-key" value="'+_oltEsc(d.apikey||'')+'" placeholder="apikey CallMeBot (só WhatsApp CallMeBot)" style="'+s+' width:100%; box-sizing:border-box; margin-bottom:6px; display:'+(showKey?'block':'none')+';">'+
        '<input class="ntf-chat" value="'+_oltEsc(d.chat||'')+'" placeholder="Telegram: Chat ID (ex.: 12345678)" style="'+s+' width:100%; box-sizing:border-box; display:'+(showTg?'block':'none')+';">'+
    '</div>';
}
// Um campo de celular (com botão de remover). Vários por destinatário.
function _oltNotifCelular(v){ var s=_oltInSt(); return '<div class="ntf-cel" style="display:flex; gap:6px; margin-bottom:5px;"><input class="ntf-cel-in" value="'+_oltEsc(v||'')+'" placeholder="celular c/ DDI (5581999999999)" style="'+s+' flex:1 1 auto; min-width:0; box-sizing:border-box;"><button type="button" onclick="var w=this.closest(\'.ntf-num\'); this.closest(\'.ntf-cel\').remove(); if(w&&!w.querySelector(\'.ntf-cel\')) _oltNotifMaisCelular(w.querySelector(\'.ntf-mais\'));" title="Remover este celular" style="cursor:pointer; width:30px; flex:0 0 auto; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.red+';"><i class="fa-solid fa-xmark"></i></button></div>'; }
function _oltNotifMaisCelular(btn){ if(!btn) return; var t=document.createElement('div'); t.innerHTML=_oltNotifCelular(''); btn.parentNode.insertBefore(t.firstChild, btn); var ins=btn.parentNode.querySelectorAll('.ntf-cel-in'); if(ins.length) ins[ins.length-1].focus(); }
function _oltNotifToggle(sel){ var row=sel.closest('.ntf-row'); if(!row) return; var c=sel.value; var num=row.querySelector('.ntf-num'), key=row.querySelector('.ntf-key'), tg=row.querySelector('.ntf-chat'); if(num) num.style.display=(c==='whatsapp'||c==='ambos'||c==='evolution'||c==='sistema')?'block':'none'; if(key) key.style.display=(c==='whatsapp'||c==='ambos')?'block':'none'; if(tg) tg.style.display=(c==='telegram'||c==='ambos')?'block':'none'; }
function _oltNotifAddRow(d){ var c=document.getElementById('ntfDestinos'); if(!c) return; var tmp=document.createElement('div'); tmp.innerHTML=_oltNotifRow(d); c.appendChild(tmp.firstChild); }
function _oltNotifColeta(){ var arr=[]; Array.prototype.forEach.call(document.querySelectorAll('#ntfDestinos .ntf-row'), function(row){ var q=function(cl){ var e=row.querySelector(cl); return e?e.value:''; }; arr.push({ canal:q('.ntf-canal')||'whatsapp', nome:q('.ntf-nome'), phone:Array.prototype.map.call(row.querySelectorAll('.ntf-cel-in'), function(e){ return (e.value||'').trim(); }).filter(Boolean).join(', '), apikey:q('.ntf-key'), chat:q('.ntf-chat') }); }); return arr; }
function _oltNotifBody(){ var v=function(id){var e=document.getElementById(id);return e?(e.value||''):'';}; return 'ativo='+(document.getElementById('ntfAtivo').checked?'1':'0')+'&tg_token='+encodeURIComponent(v('ntfTgToken'))+'&emails='+encodeURIComponent(v('ntfEmails'))+'&evo_url='+encodeURIComponent(v('ntfEvoUrl'))+'&evo_instance='+encodeURIComponent([v('ntfEvoInst'),v('ntfEvoInst2')].map(function(x){return x.trim();}).filter(Boolean).join(', '))+'&evo_apikey='+encodeURIComponent(v('ntfEvoKey'))+'&destinos='+encodeURIComponent(JSON.stringify(_oltNotifColeta())); }
function oltNotifSalvar(){
    var r=document.getElementById('ntfResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=notif_set&'+_oltNotifBody()})
      .then(function(rr){return rr.json();}).then(function(d){ if(r) r.innerHTML=(d&&d.saved!==false)?'<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Configuração salva.</span>':'<span style="color:'+OLTC.amb+';">Salvo na tela, mas não gravou em disco (permissão da pasta).</span>'; }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
// Diagnóstico REAL: usa a configuração GRAVADA e a mesma função do alerta
// automático. Diz exatamente onde a cadeia quebra.
function oltNotifDiag(){
    var r=document.getElementById('ntfResult');
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Verificando a configuração salva e enviando pelo caminho real…';
    // Salva antes, para diagnosticar exatamente o que está na tela.
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=notif_set&'+_oltNotifBody()})
      .then(function(){ return fetch('olt_huawei.php?acao=notif_diag&enviar=1'); })
      .then(function(rr){return rr.json();}).then(function(d){
        if(!r) return;
        if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
        var g=(d&&d.diag)||{}, e=(d&&d.envio)||null;
        var li=function(t,v,ok){ return '<div style="display:flex; gap:8px; align-items:flex-start; padding:4px 0; border-bottom:1px solid '+OLTC.line+'33;">'+
            '<i class="fa-solid '+(ok?'fa-circle-check':'fa-circle-xmark')+'" style="color:'+(ok?OLTC.grn:OLTC.red)+'; margin-top:2px; font-size:11px;"></i>'+
            '<div style="flex:1 1 auto; min-width:0;"><b style="font-size:11px; color:'+OLTC.ink+';">'+t+'</b>'+
            '<div style="font-size:10.5px; color:'+OLTC.mut+'; line-height:1.45;">'+v+'</div></div></div>'; };
        var h='';
        h+=li('Envio automático ligado', g.ativo?'SIM — a caixa "Enviar automático" está gravada como ativa.':'NÃO — marque a caixa e clique em Salvar.', !!g.ativo);
        h+=li('Arquivo de configuração', (g.arquivo_existe?'gravado':'NÃO existe')+' · pasta '+(g.pasta_gravavel?'gravável':'SEM PERMISSÃO'), !!g.arquivo_existe && !!g.pasta_gravavel);
        h+=li('Token do Telegram', String(g.tg_token||'—'), (String(g.tg_token||'').indexOf('definido')===0));
        h+=li('Destinatários salvos', (g.qtd_destinos||0)+' cadastrado(s)'+((g.destinos&&g.destinos.length)?(' · '+g.destinos.map(function(x){return x.canal+(x.tem_chat?' (chat ok)':'')+(x.tem_phone?' (nº ok)':'');}).join(', ')):''), (g.qtd_destinos||0)>0);
        if(e){
            var res=(e.resultado)||{}; var linhas=[];
            Object.keys(res).forEach(function(k){ var x=res[k];
                ['sistema','whatsapp','evolution','telegram'].forEach(function(cn){ if(x&&x[cn]){
                    linhas.push((cn==='telegram'?'Telegram':(cn==='evolution'?'WhatsApp comum':(cn==='sistema'?'WhatsApp com API':'CallMeBot')))+' #'+(parseInt(k,10)+1)+': '+
                      (x[cn].ok?'<span style="color:'+OLTC.grn+';">enviado ✓</span>':'<span style="color:'+OLTC.red+';">falhou — '+_oltEsc(String(x[cn].resp||'').substring(0,150))+'</span>'));
                }});
            });
            h+=li('Envio pelo caminho REAL', (e.enviado===false)?('não enviou — '+_oltEsc(e.motivo||'')):(linhas.join('<br>')||'sem destinatários'), e.enviado!==false);
        }
        h+='<div style="margin-top:9px; padding:8px 10px; background:'+OLTC.bg2+'; border-radius:8px; font-size:10.5px; color:'+OLTC.mut+'; line-height:1.5;">'+
            '<b style="color:'+OLTC.amb+';">Sobre o alerta de PON:</b> '+_oltEsc(g.obs_transicao||'')+
            ' Atualmente há <b>'+(g.pons_ja_em_queda||0)+'</b> PON(s) já registradas como em queda — essas não geram nova mensagem.</div>';
        r.innerHTML=h;
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao diagnosticar.</span>'; });
}
function oltNotifTestar(){
    var r=document.getElementById('ntfResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando e enviando teste…';
    // IMPORTANTE: salva ANTES de testar. O teste usa os campos da tela, mas o ALERTA REAL usa o
    // que está GRAVADO — testar sem salvar fazia o real nunca disparar.
    var body=_oltNotifBody();
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=notif_set&'+body})
      .then(function(){ return fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=notif_teste&'+body}); })
      .then(function(rr){return rr.json();}).then(function(d){ if(!r) return; var o=(d&&d.resultado)||{}; var linhas=[];
        Object.keys(o).forEach(function(k){ var x=o[k];
          if(k==='aviso'){ linhas.push('<span style="color:'+OLTC.amb+';">'+_oltEsc(''+x)+'</span>'); return; }
          ['sistema','whatsapp','evolution','telegram'].forEach(function(cn){ if(x&&x[cn]){ var nome=(cn==='sistema'?'WhatsApp com API':(cn==='whatsapp'?'CallMeBot':(cn==='evolution'?'WhatsApp comum':'Telegram')))+' #'+(parseInt(k,10)+1);
            linhas.push(nome+': '+(x[cn].ok?'<span style="color:'+OLTC.grn+';">enviado ✓</span>':('<span style="color:'+OLTC.red+';">falhou</span>'+(x[cn].resp?(' <span style="color:'+OLTC.mut+'; font-size:10px;">'+_oltEsc(''+x[cn].resp)+'</span>'):'')))); } });
        });
        var at=document.getElementById('ntfAtivo');
        if(at && !at.checked) linhas.push('<span style="color:'+OLTC.amb+';"><i class="fa-solid fa-triangle-exclamation"></i> <b>Atenção:</b> "Enviar automático" está DESMARCADO — o teste funciona, mas os alertas REAIS não serão enviados. Marque a caixa e salve.</span>');
        r.innerHTML=linhas.join('<br>')||'Sem destinatários configurados.';
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro no teste.</span>'; });
}
// ============================ DOCUMENTAÇÃO (Wellsystem) ============================
function _oltDocSec(ic,cor,titulo,corpo){ return '<div style="border-bottom:1px solid '+OLTC.line+'; padding:16px 18px;">'+
    '<div style="font-weight:800; color:'+OLTC.ink+'; font-size:14px; margin-bottom:9px; display:flex; align-items:center; gap:9px;"><i class="fa-solid '+ic+'" style="color:'+cor+';"></i> '+titulo+'</div>'+
    '<div style="font-size:12.5px; line-height:1.65; color:'+OLTC.txt+';">'+corpo+'</div></div>'; }
function _oltDocCode(t){ return '<pre style="white-space:pre-wrap; word-break:break-word; background:'+OLTC.panel+'; border:1px solid '+OLTC.line+'; border-radius:8px; padding:10px 12px; font-size:11.5px; color:'+OLTC.ink+'; margin:8px 0 4px; overflow:auto;">'+_oltEsc(t)+'</pre>'; }
function _oltDocConteudo(){
    var B='http://IP_DO_SERVIDOR/admin/addons/acellApp_conectado';
    var li=function(a){ return '<ul style="margin:6px 0 6px 4px; padding-left:16px;">'+a.map(function(x){return '<li style="margin-bottom:4px;">'+x+'</li>';}).join('')+'</ul>'; };
    var d='';
    // OBS: os <code> inline saíam brancos/invisíveis — força cor/fundo legíveis (nos 2 temas).
    d+='<style>#oltDocBody code{background:'+OLTC.panel+'; color:'+OLTC.acc+'; padding:1px 6px; border-radius:5px; font-family:monospace; font-size:.92em; border:1px solid '+OLTC.line+'; white-space:nowrap;} #oltDocBody pre code{background:none; border:none; padding:0; color:inherit; white-space:inherit;}</style>';
    d+='<div style="padding:18px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); color:#fff;">'+
        '<div style="font-size:20px; font-weight:800;"><i class="fa-solid fa-satellite-dish"></i> Wellsystem</div>'+
        '<div style="font-size:12px; opacity:.9; margin-top:4px;">Gerência e monitoramento de OLT Huawei — SmartOLT paralelo, <b>independente</b> (roda em qualquer radius/servidor próprio).</div></div>';
    d+=_oltDocSec('fa-circle-info', OLTC.acc, '1. O que é',
        'Plataforma que fala <b>direto com a OLT (Telnet)</b> para listar, aprovisionar, monitorar, bloquear e alarmar ONUs/ONTs — com <b>banco local próprio</b> (não depende do SmartOLT nem, obrigatoriamente, do MK-Auth).'+
        li(['<b>Independente:</b> pode rodar em outro radius ou servidor próprio.','O MK-Auth (ou outro radius) é usado <b>só</b> para puxar o <b>nome/IP</b> do cliente — opcional (dá pra editar o nome aqui pelo "+").']));
    d+=_oltDocSec('fa-folder-tree', OLTC.vio, '2. Arquivos do sistema',
        li(['<b>index.php</b> — a página (frontend + integrações).','<b>olt_huawei.php</b> — o backend (Telnet com a OLT + JSON).','<b>olt_monitor.sh</b> — arquivo ÚNICO de cron (vai no radius/servidor).','<b>cache_trafego/</b> — pasta de dados (cache, cadastro, zonas, notificações, relatório).']));
    d+=_oltDocSec('fa-server', OLTC.grn, '3. Requisitos do servidor da PÁGINA',
        li(['<b>PHP 7.4+</b> com Apache ou nginx.','Extensão <b>cURL</b> (para notificações WhatsApp/Telegram).','<b>Sockets</b> liberados (fsockopen) para Telnet na OLT.','Acesso de <b>rede até a OLT</b> (ver item 4).']));
    d+=_oltDocSec('fa-network-wired', OLTC.amb, '4. Rede / acesso à OLT (crítico)',
        'A OLT é <b>10.100.0.2 : 23 (Telnet)</b> — IP privado. O servidor da página PRECISA alcançar esse IP:'+
        li(['<b>Ideal:</b> servidor na mesma rede/roteada até a OLT.','<b>Servidor externo (nuvem):</b> criar <b>VPN/túnel</b> (WireGuard/OpenVPN) até a rede da OLT.','Existe o IP público da OLT, mas <b>não</b> exponha Telnet na internet — use VPN.']));
    d+=_oltDocSec('fa-lock', OLTC.red, '5. Permissões e liberações',
        li(['<b>Pasta de dados gravável:</b> o sistema tenta usar <code>cache_trafego</code>; se o PHP não puder gravar, cai automático numa pasta temporária. Para permanência total, libere:'])+
        _oltDocCode('chmod -R 775 '+B.replace('http://IP_DO_SERVIDOR','')+'/cache_trafego\nchown -R www-data:www-data '+B.replace('http://IP_DO_SERVIDOR','')+'/cache_trafego')+
        li(['<b>Saída HTTPS liberada</b> no servidor (para notificações): <code>api.telegram.org</code> e <code>api.callmebot.com</code>.','<b>Telnet 23</b> liberado do servidor da página até a OLT (10.100.0.2).','<b>Endpoint acessível ao cron</b> (o olt_huawei.php responder por HTTP para o radius).']));
    d+=_oltDocSec('fa-clock', OLTC.acc, '6. CRONS no servidor RADIUS (nova instalação)',
        'Use o arquivo <b>olt_monitor.sh</b> (um só, portátil). Ele agenda tudo e é independente do MK-Auth. Passos:'+
        _oltDocCode('# 1) copie o arquivo pro servidor\n/opt/olt_monitor.sh\n\n# 2) edite a URL BASE (linha BASE=...) apontando pro seu servidor\nBASE="'+B+'/olt_huawei.php"\n\n# 3) permissão + instalar os crons\nchmod +x /opt/olt_monitor.sh\n/opt/olt_monitor.sh install')+
        'Isso registra 2 crons (marcados com <code># OLT_MONITOR_WELLNET</code>):'+
        li(['<b>*/3 * * * *</b> → <b>scan</b>: varre a OLT, atualiza cache, detecta PON em queda, registra no relatório e <b>envia as notificações</b>.','<b>1 0 1 * * *</b> → <b>relatorio</b>: limpeza automática do relatório no dia 1, 00:01.'])+
        'Comandos: <code>install</code> · <code>uninstall</code> · <code>status</code> · <code>scan</code> (testar agora).<br>'+
        '<span style="color:'+OLTC.mut+';">Se editado no Windows e der "bad interpreter": <code>sed -i \'s/\\r$//\' /opt/olt_monitor.sh</code></span>');
    d+=_oltDocSec('fa-list-check', OLTC.grn, '7. Prioridades — ordem de instalação',
        li(['<b>1º</b> Subir a página (index.php + olt_huawei.php) num PHP.','<b>2º</b> Garantir <b>rota/VPN até a OLT</b> (10.100.0.2:23) — sem isso, nada funciona.','<b>3º</b> Abrir o Gerenciador 1x (popula o cache) e conferir se lista as ONUs.','<b>4º</b> Liberar a gravação da pasta (item 5) se aparecer aviso.','<b>5º</b> Configurar as <b>Notificações</b> (Menu → 🔔) e testar.','<b>6º</b> Instalar o <b>cron</b> no radius (item 6) → monitoramento 24/7.']));
    d+=_oltDocSec('fa-bell', OLTC.amb, '8. Notificações (WhatsApp / Telegram)',
        'Menu → <b>Notificações</b>. Lista de destinatários (cada um: canal + dados). Dispara automático quando uma PON cai/normaliza.'+
        li(['<b>Telegram:</b> Bot Token (1x, do @BotFather) + Chat ID de cada destino (via @userinfobot).','<b>WhatsApp (CallMeBot):</b> número c/ DDI + apikey (salve <b>+34 644 51 95 23</b> e envie "I allow callmebot to send me messages").','Precisa do <b>cron scan</b> rodando para disparar 24/7.']));
    d+=_oltDocSec('fa-gauge-high', OLTC.acc, '9. Monitoramento 24/7 (como funciona)',
        li(['O <b>cron scan</b> varre a OLT a cada 3 min → cache sempre fresco.','Detecta <b>PON em queda total</b> (≥3 ONUs 100% caídas — LOS ou falta de energia).','Registra no <b>Logs/Relatórios</b> (evento PON EM QUEDA / PON NORMALIZOU) e <b>envia a notificação</b>.','Alerta flutuante no topo (arrastável) aparece na página e na principal.']));
    d+=_oltDocSec('fa-screwdriver-wrench', OLTC.red, '10. Problemas comuns',
        li(['<b>Página gira/não abre + login lento:</b> processos do PHP presos numa varredura. Reinicie o serviço web: <code>systemctl restart apache2</code> (ou php-fpm). O cache persistente e o modo estável evitam isso.','<b>"Salvou mas não fixa":</b> pasta sem escrita → libere a permissão (item 5) ou o sistema usa a pasta temporária automática.','<b>Notificação falha:</b> saída HTTPS bloqueada no servidor → libere api.telegram.org / api.callmebot.com.']));
    d+=_oltDocSec('fa-arrows-turn-to-dots', OLTC.vio, '11. Migração / independência',
        'Para virar plataforma 100% própria: copie os 2 arquivos + pasta de dados pro seu servidor, garanta rota/VPN até a OLT, adicione um <b>login próprio</b>, aponte um subdomínio + HTTPS. Empacotamento tipo "executável" = <b>Docker</b>. O MK-Auth deixa de ser obrigatório.');
    d+=_oltDocSec('fa-gear', OLTC.acc, '12. Tela de CONFIGURAÇÕES (nenhum IP no código)',
        'Na <b>página principal → Menu → Configurações</b> ficam os dados que antes eram fixos no código. O que você salvar vale para a página inteira.'+
        li(['<b>Concentradores:</b> apelido + IP/host + porta do <b>accel-ppp</b> (padrão <b>2000</b>). É daqui que sai o estado <b>online/offline</b> de todo cliente (a página lê <code>show sessions ... match state active</code>).',
            '<b>Servidor web:</b> host do MK-Auth (usado por outras telas). O link "Abrir cadastro do cliente" NAO depende mais dele — vai direto para o cadastro do WellSystem, pelo serial da ONU.',
            '<b>Timeout:</b> segundos para conectar/ler o concentrador (1–15; use 2–3).',
            'Pode adicionar <b>quantos concentradores quiser</b> — todos são lidos e somados.'])+
        'Gravado em <code>cache_trafego/wellsystem_config.json</code>. Ao salvar, a página recarrega sozinha para aplicar.'+
        _oltDocCode('# conferir o arquivo gerado\ncat /opt/mk-auth/admin/addons/acellApp_conectado/cache_trafego/wellsystem_config.json')+
        '<b>Conexão da OLT</b> (Menu do Gerenciador → <i>Conexão da OLT</i>) é separada e guarda IP/porta/usuário/senha do Telnet da OLT em <code>olt_conexao.json</code> — a senha nunca volta em claro para a tela.');

    d+=_oltDocSec('fa-database', OLTC.grn, '13. Banco de dados — o que o sistema lê do RADIUS',
        'O Wellsystem <b>não escreve</b> no banco do MK-Auth: só faz <code>SELECT</code>. Tabelas usadas:'+
        li(['<b>sis_cliente</b> — titulares. Campos: <code>login</code>, <code>uuid_cliente</code>, <code>nome</code>, <code>nome_res</code>, <code>plano</code>, <code>ip</code>, <code>cli_ativado</code>. Só entram os ATIVOS (<code>cli_ativado</code> = s/sim/1).',
            '<b>sis_adicional</b> — clientes adicionais. <b>Atenção ao vínculo:</b> <code>username</code> = o login que <u>conecta</u>; <code>login</code> = o login do <u>titular</u>. Não existe <code>id_cliente</code>. O nome sai de <code>nome</code> (ou <code>nome_res</code>) e o <code>uuid</code> vem do titular via JOIN.',
            '<b>clientes_conectados</b> — usada só como fallback histórico. O <b>online real</b> vem do concentrador, não desta tabela.'])+
        _oltDocCode("-- vínculo do adicional (o que o sistema faz)\nSELECT a.username, a.login AS titular, a.nome, a.nome_res, c.uuid_cliente\n  FROM sis_adicional a\n  LEFT JOIN sis_cliente c ON c.login = a.login;")+
        'Se um cliente aparece <b>offline mesmo online</b>, o problema é acesso ao concentrador (IP/porta/timeout na tela de Configurações), não o banco.');

    d+=_oltDocSec('fa-list-ol', OLTC.vio, '14. Instalação do ZERO — passo a passo completo',
        li(['<b>1. Copiar os arquivos</b> para <code>/opt/mk-auth/admin/addons/acellApp_conectado/</code>: <code>index.php</code>, <code>olt_huawei.php</code>, <code>config.php</code>.',
            '<b>2. Criar a pasta de dados</b> e liberar escrita (é onde ficam TODAS as configurações):',
            '<b>3. Testar o acesso à OLT</b> a partir do servidor da página (Telnet 23).',
            '<b>4. Abrir a página</b> e ir em <i>Menu → Conexão da OLT</i>: preencher IP/porta/usuário/senha e salvar.',
            '<b>5. Menu → Configurações</b> (página principal): cadastrar os concentradores e o servidor web.',
            '<b>6. Varrer a OLT</b> pelo botão <i>Refresh</i> — isso popula o cache e a lista de ONUs.',
            '<b>7. Menu → Notificações</b>: cadastrar destinatários, <b>marcar "Enviar automático"</b> e <b>Salvar</b> (ver seção 8 — sem isso o alerta real não sai).',
            '<b>8. Instalar o cron</b> no servidor radius (seção 6) para o monitoramento 24/7.',
            '<b>9. Menu → Perfis ONU/ONT</b>: revisar os modelos capturados e dar nome/tipo a cada um.',
            '<b>10. Menu → Backup</b>: baixar um backup logo após configurar tudo.'])+
        _oltDocCode("# passo 2 — pasta de dados gravável\ncd /opt/mk-auth/admin/addons/acellApp_conectado\nmkdir -p cache_trafego\nchown -R www-data:www-data cache_trafego\nchmod -R 775 cache_trafego\n\n# passo 3 — testar Telnet até a OLT (troque o IP)\ntelnet 10.100.0.2 23")+
        '<b>Nada</b> precisa ser editado no código-fonte numa instalação nova: IP da OLT, concentradores e servidor web são todos por tela.');

    d+=_oltDocSec('fa-key', OLTC.amb, '15. O que precisa existir no RADIUS / MK-Auth',
        li(['<b>Acesso ao MySQL</b> — o <code>config.php</code> do addon já usa a conexão do MK-Auth (<code>$link</code>). Nenhuma tabela nova é criada.',
            '<b>Concentrador acessível por Telnet</b> na porta do accel-ppp (2000) a partir do servidor da página. Teste: <code>telnet IP_DO_CNC 2000</code>.',
            '<b>Usuário do accel-ppp</b> com permissão para <code>show sessions</code> (somente leitura já basta).',
            '<b>Firewall</b> liberando: página → OLT (23/tcp), página → concentradores (2000/tcp), página → internet (443) para as notificações.',
            '<b>PHP</b> com <code>mysqli</code>, <code>curl</code> (ou <code>allow_url_fopen</code>) e <code>fsockopen</code> habilitados.'])+
        _oltDocCode("# checar o que o PHP tem habilitado\nphp -m | grep -Ei 'mysqli|curl|sockets'\n\n# checar alcance aos serviços\nnc -vz 10.100.0.2 23      # OLT (telnet)\nnc -vz 192.0.2.21 2000   # concentrador (accel-ppp)"));

    d+=_oltDocSec('fa-shield-halved', OLTC.red, '16. Segurança e boas práticas',
        li(['A <b>senha da OLT</b> fica em <code>cache_trafego/olt_conexao.json</code> — a pasta <b>não deve</b> ser acessível pela web. Se estiver dentro do docroot, bloqueie com <code>.htaccess</code>.',
            'Use um usuário da OLT <b>dedicado</b> ao sistema, com permissão só do necessário.',
            'O <b>backup</b> (Menu → Backup) contém nomes, apelidos, notificações e fotos — guarde em local seguro. Ele <b>não</b> inclui a senha da OLT.',
            'Tokens de Telegram/Evolution ficam no servidor, nunca são expostos na página.'])+
        _oltDocCode('# bloquear a pasta de dados na web (Apache)\ncat > cache_trafego/.htaccess <<EOF\nRequire all denied\nEOF'));

    d+=_oltDocSec('fa-microchip', OLTC.acc, '17. Perfis ONU/ONT e modelos',
        'Menu → <b>Perfis ONU / ONT</b> mostra duas coisas:'+
        li(['<b>Perfis cadastrados na OLT</b> (line-profile / srv-profile) — lidos direto do equipamento; use ↻ para reler.',
            '<b>Modelos capturados</b> — cada modelo que a OLT reportou (ex.: <code>HG8310M</code>), com quantos equipamentos existem dele. Você define um <b>nome de exibição</b> (que passa a aparecer na coluna Modelo) e pode <b>forçar o tipo</b> (ONU·Bridge / ONT·Router) quando o service-profile da OLT informa errado. "Automático" mantém a detecção padrão.'])+
        'A <b>foto do modelo</b> (PNG/JPEG) é anexada pelo ícone 📷 na coluna Tipo e aparece na miniatura ao passar o mouse e no popup do Sinal. Tudo isso entra no backup.');

    d+=_oltDocSec('fa-window-restore', OLTC.grn, '18. Como usar a interface',
        li(['<b>Todas as janelas</b> arrastam pelo cabeçalho, redimensionam pelo canto, e têm minimizar/maximizar. <b>Maximizada não arrasta</b> (proposital).',
            '<b>Minimizar</b> manda a janela para uma pílula no <b>rodapé</b> — várias janelas minimizadas ficam lado a lado.',
            '<b>Clique no Sinal</b> de uma ONU: abre o uptime com contagem regressiva (atualiza a cada 60s) + foto do modelo.',
            '<b>Clique no Serial</b> (oculto; passe o mouse para ver): abre a <b>Ficha Técnica</b>. Pode abrir <b>VÁRIAS ao mesmo tempo</b> (uma por ONU) — clicar em outro Serial abre outra; no mesmo, atualiza. São <b>arrastáveis</b> e têm o botão <b>Gráfico</b> (consumo de banda da ONU em tempo real, Upload/Download, período Meia hora/Dia).',
            '<b>Menu › Consumo de Banda (ONUs)</b>: lista TODAS as ONUs em grade (busca + paginação, igual à de Sinal). Clique numa para ver o <b>consumo ao vivo</b>. Obs.: banda por ONU é via Telnet (1 de cada vez), por isso abre por clique, não todas juntas.',
            '<b>Resumo</b>: clique em qualquer item para filtrar a lista. O tamanho da janela e dos blocos fica gravado.',
            '<b>Logs/Relatórios</b>: os 4 cards são filtros — clique para filtrar por tipo e período; clique de novo para limpar.']));

    d+=_oltDocSec('fa-diagram-project', OLTC.acc, '19. Integração × Standalone × Deploy (arquitetura atual)',
        'O módulo funciona <b>embutido no Radius</b> OU <b>sozinho</b>. A pasta pode ter qualquer nome (ex.: <code>wellsystem_olt</code>, <code>wellsystem_crm</code>).'+
        li(['<b>Arquivos da OLT:</b> <code>olt.php</code> (página autônoma), <code>olt_huawei.php</code> (backend Telnet), <code>olt_ui.js</code> (interface), <code>olt_auth.php</code> (login/níveis — <b>opcional</b>), <code>olt_monitor.sh</code> (cron).',
            '<b>UNIFICADO (dentro do Radius):</b> basta os arquivos da OLT estarem na <b>mesma pasta</b> do <code>index.php</code> do Radius. O botão <b>OLT Huawei</b> passa a existir e abre a OLT em <b>nova aba</b> (<code>olt.php</code>), mantendo o Radius aberto. O login da OLT é feito na aba da OLT.',
            '<b>SEPARADO (só a OLT):</b> suba a pasta <b>sem</b> o <code>index.php</code> do Radius — o <code>olt.php</code> roda 100% sozinho, com login próprio.'])+
        '<b>Subir em OUTRO radius:</b> copie a pasta da OLT para <code>/opt/mk-auth/admin/addons/&lt;pasta&gt;/</code> do outro servidor. Nada de banco novo. Se quiser o online dos clientes, cadastre os concentradores em <i>Configurações</i>.'+
        '<b>Apontar para OUTRA OLT:</b> Menu → <b>Conexão da OLT</b> → informe IP/porta/usuário/senha e clique <b>Conectar</b> (salva e testa; verde = ok). Nenhum IP no código.'+
        _oltDocCode('# subir em outro servidor (exemplo)\ncd /opt/mk-auth/admin/addons\nmkdir -p wellsystem_olt && cd wellsystem_olt\n# copie: olt.php olt_huawei.php olt_ui.js olt_auth.php olt_monitor.sh\nchmod -R 775 cache_trafego 2>/dev/null || mkdir -p cache_trafego && chmod 775 cache_trafego'));
    d+=_oltDocSec('fa-user-shield', OLTC.vio, '20. Login e níveis de acesso (olt_auth.php)',
        'Com o <code>olt_auth.php</code> na pasta, o acesso passa a exigir <b>login</b> (cookie <code>WSOLTSESS</code>). Sem o arquivo, roda sem login (compatível com instalações antigas).'+
        li(['<b>1º acesso</b> (nenhum usuário): a tela de login <b>cria o administrador</b> usando a <b>senha da OLT</b> como validação.',
            '<b>Nível 1</b> — só leitura/monitoramento. <b>Nível 2</b> — operação na ONU (liberar/bloquear/reiniciar, Bridge/Router, controle de PON). <b>Nível 3</b> — tudo (conexão, notificações, backup, usuários, terminal).',
            'O servidor valida o nível em <b>cada</b> endpoint (nega por omissão). Menu → <b>Usuários e acessos</b> gerencia contas.']));
    d+=_oltDocSec('fa-terminal', OLTC.grn, '21. Terminal, Gráfico e Backup por e-mail (recursos novos)',
        li(['<b>Prompt de Comando (OLT)</b> — Menu (nível 3): pede login root e abre um terminal real da OLT (roda <code>display …</code> e comandos de config). Entra sozinho mesmo se a 1ª tentativa de Telnet falhar (VTY ocupada).',
            '<b>Gráfico — Status da rede</b> — Menu: mostra Online/Falha de Energia/LOS/N/A ao longo do tempo (hora/dia/semana/mês/ano). Alimenta-se do cron <b>e</b> do próprio gerenciador aberto (1 ponto/hora). Passe o mouse para ver os valores do momento; pico/vale destacados.',
            '<b>Backup automático por e-mail</b> — Menu → Backup: agende horário + e-mail. Se o servidor não tiver <code>mail()</code>/MTA, preencha o <b>SMTP</b> (ex.: Gmail <code>smtp.gmail.com</code> / 587 / TLS — exige <b>senha de app</b>; ou SSL / 465). Use <b>"Enviar teste agora"</b> para conferir; ele mostra o motivo real se falhar.']));
    d+=_oltDocSec('fa-right-left', OLTC.red, '22. Desativar o SmartOLT e ATIVAR esta página (migração)',
        'O Wellsystem <b>não depende</b> do SmartOLT — ele fala <b>direto com a OLT por Telnet</b>. Dá para rodar os dois em paralelo e desligar o SmartOLT quando estiver confiante. Passo a passo:'+
        li(['<b>1. Suba esta página</b> (arquivos da OLT) e valide a lista de ONUs (seções 14 e 19).',
            '<b>2. Conexão da OLT</b> (Menu → Conexão da OLT): informe IP/porta/usuário/senha e <b>Conectar</b> (verde = ok). É a <u>mesma</u> credencial Telnet que o SmartOLT usa.',
            '<b>3. (Opcional) Importe nomes do SmartOLT</b>: Menu → <i>Atualizar do SmartOLT (nuvem)</i> — puxa o mapa Serial→nome uma vez, para não redigitar. Depois disso o SmartOLT não é mais necessário.',
            '<b>4. Notificações</b> (Menu → 🔔) e <b>cron</b> (seção 6): ative o monitoramento 24/7 aqui.',
            '<b>5. Rodar em paralelo alguns dias</b>: confira contagem, quedas e sinal batendo com o SmartOLT.',
            '<b>6. Desativar o SmartOLT</b> com segurança:'])+
        li(['<b>Pare os automatismos</b> do SmartOLT (auto-provision/monitoramento) para ele não brigar pela sessão Telnet da OLT (a OLT tem VTY limitadas).',
            '<b>Aponte só um</b> para a OLT: idealmente deixe apenas o Wellsystem falando com a OLT (o SmartOLT em modo leitura ou desligado).',
            '<b>Cancele a assinatura</b> do SmartOLT quando não precisar mais — <b>nada</b> aqui depende da nuvem dele.',
            '<b>Backup antes</b>: Menu → Backup → baixar o <code>.json</code> (nomes, zonas, perfis, notificações).'])+
        '<b>Importante (sessões Telnet):</b> a OLT aceita poucas sessões Telnet simultâneas. Rodando SmartOLT + Wellsystem + terminal ao mesmo tempo pode dar "VTY ocupada". Por isso, ao migrar, reduza quem fala com a OLT.'+
        _oltDocCode('# checar quem está logado na OLT (dentro do terminal da OLT / Prompt de Comando)\ndisplay users\n\n# no Wellsystem: apontar para a OLT sem tocar em código\n# Menu → Conexão da OLT → IP/porta/usuário/senha → Conectar'));
    d+=_oltDocSec('fa-tower-broadcast', OLTC.red, '23. Alarmes REAIS da OLT (queda de PON / placa / energia)',
        'A OLT tem alarme próprio e o sistema lê direto dela — detecção <b>imediata e sem falso positivo</b> (não adivinha por contagem de sinal). Comando: <code>display alarm active all list</code>. Roda no <b>cron (servidor)</b>, então avisa mesmo com o <b>app fechado / deslogado</b>.'+
        li(['<b>PON caiu (LOS):</b> a OLT não recebe sinal óptico da porta (fibra tronco rompida). Alerta 🔴 com o F/S/P e nº de ONUs afetadas. <b>Porta vazia (sem ONU) NÃO alerta.</b>',
            '<b>PON caiu (ENERGIA em massa):</b> várias ONUs da mesma porta em <i>dying-gasp</i> (sem luz) ao mesmo tempo = queda de energia na área. Individual de 1 cliente NÃO vira alerta de PON (fica no card do topo).',
            '<b>PLACA caiu:</b> falha de comunicação da placa com a controladora (⛔). Alerta imediato.',
            '<b>Retorno:</b> quando volta, dispara 🟢 (PON/placa restabelecida).',
            'Tela: <b>Menu → Alarmes da OLT (PON/Placa)</b> — lista os alarmes ativos; ruído (LCDGi/config) fica separado, não notifica.'])+
        '<b>Cron:</b> o <code>olt_monitor.sh</code> chama <code>acao=alarmes_check</code> num ciclo ocioso (1 Telnet por ciclo, ~2 min), sem saturar a OLT.');
    d+=_oltDocSec('fa-wave-square', OLTC.grn, '24. Sinal óptico (cores) e Data de ativação',
        li(['<b>Cor do sinal</b> — referência é o <b>Rx OLT (o que volta)</b>: 🟢 verde OK · 🟡 âmbar pior que <b>-28 dBm</b> · 🔴 vermelho pior que <b>-29,1 dBm</b>. Vale na Ficha, na Lista (coluna Sinal) e nas Portas PON. Regra única — muda num lugar, vale em tudo.',
            '<b>Data de ativação (dd/mm/aaaa)</b> — vem da <b>data real de autorização</b> gravada pelo app (com backfill do que já existia). Aparece na <b>Ficha Técnica</b>, na janela <b>Gerenciar</b> (ao lado de Tráfego), no <b>chip do topo</b> e no <b>tooltip da coluna Modelo</b>.']));
    d+=_oltDocSec('fa-chart-line', OLTC.acc, '25. Gráficos — como abrem (rápido e verdadeiro)',
        'Todos abrem <b>na hora, do cache</b> (leitura direta, fura a fila) — o <b>cron</b> mantém os dados frescos, então é rápido <b>sem inventar</b> nada.'+
        li(['<b>Status da rede</b> — Online/Energia/LOS/N/A no tempo. Grava <b>1 ponto por minuto</b> (contagem viva do SNMP) → captura quedas curtas. Eixo por <b>hora</b> (00:00/03:00…), hover pelo horário, pico/vale destacados.',
            '<b>Gráficos por PON / Uplink</b> — tráfego (Upload/Download) por porta, agrupado por <b>PLACA</b>, com nome da PON. Atualiza a cada 45s.',
            '<b>Gráficos de Sinal (ONUs)</b> — Rx no tempo por ONU, agrupado por placa, pior sinal primeiro dentro da placa.',
            '<b>Consumo de Banda (ONUs)</b> — grade de todas as ONUs; clique numa para o consumo <b>ao vivo</b>.',
            'Passe o <b>mouse</b> em qualquer gráfico para ler os valores do ponto.']));
    d+=_oltDocSec('fa-gauge-high', OLTC.vio, '26. Consumo de banda por ONU (ao vivo)',
        'Esta OLT <b>não</b> expõe ONU no SNMP, então a banda por cliente é lida por <b>Telnet ao vivo</b>: <code>display service-port</code> + <code>display statistics service-port</code> → bytes ÷ tempo = bps.'+
        li(['Cada ponto precisa de <b>2 leituras</b>; o backend já faz 2 leituras rápidas na 1ª chamada → o valor aparece em ~2-3s.',
            'Janelas <b>multi-abertura</b> e <b>arrastáveis</b> (várias ONUs ao mesmo tempo); a mesma ONU só atualiza. Período <b>Hora</b> / <b>Dia</b>.',
            'As leituras vão por <b>fila serial</b> (1 por vez), mesmo com vários gráficos abertos — não saturam a OLT.']));
    d+=_oltDocSec('fa-id-card', OLTC.grn, '27. Cadastro do cliente (Radius) — automático e portável',
        'O botão <b>Cadastro</b> (Ficha e nome na lista) abre a ficha do cliente no radius. Resolve o vínculo <b>na hora do clique</b>, direto no banco.'+
        li(['<b>Como acha:</b> o backend consulta o banco do radius (<code>sis_cliente</code> por login=serial, e <code>sis_adicional</code> por username → uuid do titular). Tenta os dois formatos do serial (fabricante e hex).',
            '<b>Portável:</b> usa a mesma conexão do <code>config.php</code> (radius da tela, ou <code>WS_DB_*</code> do Docker) — sem IP fixo no código. Serve para este e outros radius/instalações.',
            '<b>URL do cadastro:</b> Menu → Sistema → <b>Link de Cadastro (Radius)</b>. Curingas: <code>{uuid}</code> <code>{login}</code> <code>{serial}</code> <code>{ip}</code> <code>{nome}</code>. Fica <b>salva no servidor</b> (vale p/ todos os usuários; abre no host certo mesmo acessando por domínio).',
            'Cliente sem vínculo no radius → aviso claro ("não cadastrado").']));
    d+=_oltDocSec('fa-arrow-down-wide-short', OLTC.amb, '28. Ordenar por "Recentes" (últimos aprovisionados)',
        'Uma seta ▾ discreta no cabeçalho <b>Nome</b> lista os <b>últimos aprovisionados primeiro</b> (pela data real de autorização). Clicar no card <b>Online</b> do topo também aplica a ordem Recentes (só nesse card). A precisão é total para as ONUs ativadas <b>a partir de agora</b>.');
    d+=_oltDocSec('fa-database', OLTC.acc, '29. Radius / banco — de A a Z (o que o sistema usa)',
        'O sistema conversa com o radius por <b>HTTP</b> (painéis) e lê o <b>banco</b> (MySQL do MK-Auth) para nomes/uuid. Nada obrigatório — sem radius, a OLT funciona 100% com o banco local.'+
        li(['<b>Conexão do banco:</b> <code>config.php</code> lê o radius ativo de <code>wellsystem_config.json</code> (tela de Configurações) → <code>WS_DB_*</code> (Docker) → local. Endpoints: <code>clientes_db</code> (mapa login→uuid/nome/ip, titulares + adicionais) e <code>cliente_uuid</code> (1 cliente).',
            '<b>Painéis do Radius / Emergência:</b> Menu → <i>Emergência Radius</i> (nível 2) fala DIRETO com cada concentrador (rad=3 "qualquer login" / rad=0 "radius"), independente do MK-Auth.',
            '<b>Nomes das ONUs offline:</b> vêm do <code>sis_cliente</code> (o app cruza serial↔login). O nome também pode ser editado localmente pelo "+".',
            '<b>Login = serial:</b> o padrão é o login do cliente ser o serial da ONU (formato do fabricante). Adicionais em <code>sis_adicional</code> herdam o uuid do titular.']));
    d+=_oltDocSec('fa-user-shield', OLTC.red, '30. Níveis de acesso (resumo prático)',
        li(['<b>Nível 1 (Leitura):</b> vê tudo (listas, gráficos, alarmes, ficha), não altera.',
            '<b>Nível 2 (Operação AMPLA):</b> quase todo o menu — autorizar/bloquear/reiniciar/deletar ONU, <b>VLAN do cliente</b>, cadastro/zona/perfis/modelos, logo, notificações, relatório, backup (salvar/agendar), todos os gráficos.',
            '<b>Nível 3 (Root):</b> o que compromete o sistema — <b>Conexão da OLT</b>, <b>Terminal</b>, <b>restaurar backup</b>, <b>criar usuários</b>, e mexer em <b>PLACA</b> / <b>VLAN de placa</b> (Gerenciar Placas / Uplink / VLANs). Validado no <b>servidor</b>, não só na tela.']));
    d+=_oltDocSec('fa-bars', OLTC.acc, '31. Mapa completo do Menu',
        '<b>Monitoramento (todos os níveis):</b>'+
        li(['<b>Resumo / Contagem</b> — total por placa/porta, online/offline, ONU×ONT, sinal bom/ruim.',
            '<b>Gráfico — Status da rede</b> — Online/Energia/LOS/N/A no tempo (1 ponto/min, eixo por hora).',
            '<b>Logs / Relatórios</b> — aprovisionamentos/retiradas do dia e do mês; vira-mês automático.',
            '<b>Alarmes da OLT (PON/Placa)</b> — alarmes reais ativos (LOS/energia/placa).',
            '<b>Emergência Radius</b> (nível 2) — "qualquer login" nos concentradores.'])+
        '<b>Cadastros (nível 2+):</b>'+
        li(['<b>Gerenciar Zonas</b> · <b>Portas PON</b> (apelido/VLAN/zona/perfil + ativar/desativar) · <b>Descrições das PONs</b> · <b>Perfis ONU/ONT</b> · <b>Perfis de velocidade</b>.',
            '<b>Gráficos:</b> por PON · Uplink · Sinal (ONUs) · Consumo de Banda (ONUs) · Temperatura · Autorizações por dia.',
            '<b>Atualizar do SmartOLT (nuvem)</b> — importa Serial→nome uma vez.'])+
        '<b>Sistema (nível 2+):</b> Notificações · Link de Cadastro (Radius) · Logomarca · Backup.<br>'+
        '<b>Administração (nível 3 / Root):</b> Gerenciar Placas · Uplink (VLANs) · Gerenciar VLANs · Conexão da OLT · Prompt de Comando (Terminal) · Usuários e acessos · Acessos e tempo de conexão.');
    d+=_oltDocSec('fa-table-cells', OLTC.grn, '32. Telas de Gerência (o que cada uma faz)',
        li(['<b>Gerenciar Portas PON</b> — todas as portas (0–15) por placa, com sinal médio (pelo retorno), Tx GBIC, online/total, apelido, VLAN, zona, perfil padrão e ativar/desativar. Portas vazias aparecem como reserva.',
            '<b>Portas ON/OFF</b> — grade rápida ON/OFF por porta (agrupada por placa); porta sem ONU aparece como <b>VAZIA</b> (cinza), não como OFF.',
            '<b>Gerenciar Placas</b> (root) — placas GPON/SCU/uplink; ligar/desligar placa (SNMP).',
            '<b>Gerenciar Uplink (VLANs)</b> (root) — portas ethernet de uplink e suas VLANs (config real na OLT).',
            '<b>Gerenciar VLANs</b> (root) — criar/nomear/excluir VLAN na OLT.',
            '<b>Perfis ONU/ONT</b> — perfis reais da OLT (Bridge=ONU / Router=ONT) + <b>nomear os modelos</b> capturados (v5, v6…).']));
    d+=_oltDocSec('fa-hard-drive', OLTC.vio, '33. Arquivos, cache e persistência (por que nada some no reboot)',
        'O sistema tem banco local próprio (JSON). O PHP-FPM às vezes não grava na pasta persistente (open_basedir), então grava no <code>/tmp</code>; o <b>cron</b> (CLI) converge <code>/tmp ↔ cache_trafego</code> a cada 1 min (<code>acao=cache_sync</code>) — por isso nada some no restart.'+
        li(['<b>Conexão da OLT:</b> <code>olt_conexao.json</code> (IP/porta/usuário/senha Telnet — senha nunca volta em claro).',
            '<b>Radius/banco:</b> <code>wellsystem_config.json</code> (radius ativo: host/user/pass/dbname/porta).',
            '<b>Persistem no cache_sync:</b> usuários, logo, cadastro/zonas/meta, notificações, agendamento de backup, lista de ONUs, placas, Tx, alarmes, URL de cadastro, histórico.',
            '<b>Regra:</b> todo arquivo novo que a tela grava e precisa sobreviver ao reboot entra na lista do <code>cache_sync</code>.']));
    d+=_oltDocSec('fa-list-check', OLTC.acc, '34. Seleção múltipla e ações em lote',
        'Na lista principal há uma <b>coluna de seleção</b> (checkbox). Marque ONUs e aplique uma ação em <b>todas de uma vez</b>: <b>Reiniciar · Ressincronizar · Bloquear · Liberar · Deletar</b>.'+
        li(['<b>Marcar todos:</b> o checkbox do cabeçalho marca <b>todas as ONUs do FILTRO atual</b> (todas as páginas), não só as visíveis.',
            '<b>Fluxo:</b> clique numa categoria do <i>Resumo</i> ou filtre por coluna (VLAN, Modelo, Zona…) → marcar todos → escolha a ação na barra que aparece.',
            '<b>Execução segura:</b> roda <b>uma ONU por vez</b>, com respiro (~350ms) e até 2 retentativas por ONU em caso de congestão de VTY — não esgota o Telnet. Mostra progresso ✓/✗.',
            '<b>Trocar de filtro ZERA a seleção</b> automaticamente — impossível agir numa ONU que saiu da tela sem você ver.']));
    d+=_oltDocSec('fa-filter', OLTC.grn, '35. Filtros precisos (evita ação na ONU errada)',
        'Os filtros por coluna e os cliques no <i>Resumo</i> listam <b>exatamente</b> o que foi pedido.'+
        li(['<b>Valor discreto</b> (Modelo, Tipo, VLAN, ID, PON, Status) casa por <b>token exato</b>: filtrar <code>R1</code> mostra só R1 — não pega R11/R110; <code>8</code> não pega 80/18; VLAN <code>358</code> não pega 3580.',
            '<b>Texto livre</b> (Nome, Zona, Serial) casa por parte do texto (útil pra buscar nomes).',
            '<b>Status no Resumo</b> usa a categoria precisa (online/offline/LOS/Desativada) — "Offline" não mistura LOS/Desativada.']));
    d+=_oltDocSec('fa-microchip', OLTC.red, '36. Perfil genérico — regra de segurança',
        '<b>Perfil genérico</b> (Generico_1) é para ONUs de outras marcas (Intelbras R1/R2 etc.).'+
        li(['<b>Aplicar SÓ no APROVISIONAMENTO</b> (ONU nova): no card de Aprovisionar, escolha o perfil genérico antes de autorizar. Seguro — a config é montada do zero.',
            '<b>⛔ NUNCA trocar o perfil de uma ONU JÁ ATIVA pelo app:</b> isso reescreve os GEM/T-CONT e deixa o <b>service-port órfão → derruba o tráfego</b> (só volta com resync no SmartOLT). Por isso a troca em lote/individual está <b>desativada</b> por segurança.',
            '<b>Identificação (só leitura):</b> na ficha, o card <b>Perfil ONT/ONU</b> mostra o perfil real; se contiver "Generico", ganha o selo <b>GENÉRICO</b>. Na lista aparece o chip <b>GEN</b>. Nada é alterado — só leitura.',
            '<b>Para as já ativas que precisam de genérico:</b> use o SmartOLT (ele recria o service-port corretamente).']));
    d+=_oltDocSec('fa-right-left', OLTC.vio, '37. Redundância App ↔ SmartOLT (via API)',
        '<b>Descoberta importante:</b> o SmartOLT <u>não lê</u> zona/modo/tipo da config da OLT — ele mostra do <b>banco de dados dele</b>. Por isso não adianta mexer na descrição/perfil da OLT pra ele espelhar. O espelho é feito pela <b>API do SmartOLT</b> (<code>onu/authorize_onu</code>).'+
        li(['<b>App → SmartOLT (automático):</b> ao clicar <b>Autorizar</b>, o app (1) provisiona na OLT — como sempre, <b>independente</b> — e (2) registra a ONU no SmartOLT via API com o <b>tipo</b> (onu_type), <b>modo</b> (Bridging/Routing), <b>zona</b>, VLAN e nome. Assim zona/modo/tipo saem <b>certos</b> no SmartOLT, sem resync. É <b>best-effort</b>: se o SmartOLT estiver fora, a ONU já ficou na OLT e o app avisa "sincronize depois".',
            '<b>O TIPO define o MODO no SmartOLT:</b> o modo (Ponte/Roteamento) vem do <code>onu_type</code> enviado — ex.: <code>MAX1000</code> = Bridging, <code>INTEL-R1</code> = Bridging, <code>ONT-*</code> = Routing. O nome do perfil escolhido no app é enviado como onu_type; ele precisa <b>casar</b> com um tipo cadastrado no SmartOLT.',
            '<b>SmartOLT → App:</b> uma ONU provisionada no SmartOLT aparece no app <b>sozinha</b> (a varredura Telnet lê a OLT direto: serial, sinal, VLAN, e a zona/nome da descrição). O botão <b>Atualizar do SmartOLT (nuvem)</b> completa com os campos estruturados (nome/zona/tipo) da API.',
            '<b>Config:</b> URL e token do SmartOLT ficam em <code>olt_huawei.php</code> ($smartolt_url / $smartolt_token). O <code>olt_id</code> é resolvido pela API (system/get_olts) e cacheado.',
            '<b>Rodando os dois juntos:</b> a OLT tem poucas VTYs; o app recua sozinho (backoff) e serializa por mutex pra não brigar com o SmartOLT pelo Telnet.']));
    d+=_oltDocSec('fa-folder-open', OLTC.amb, '38. Modelos ONT / ONU',
        'Menu → Sistema → <b>Modelos ONT / ONU</b>: envie fotos dos modelos de ONU/ONT, logomarcas e outros arquivos (PNG/JPEG/WEBP/GIF/SVG/PDF, até 5 MB).'+
        li(['Ficam gravados numa pasta <code>Mkfiles</code> dentro do addon no servidor (se o FPM não puder gravar lá, cai na pasta de cache gravável).',
            'Galeria com miniatura, nome e tamanho; copiar o nome, excluir e abrir em nova aba. Servidos por <code>mkfiles_get</code> (aparecem direto nas miniaturas).',
            'Permissões: ver/listar = nível 1; enviar/excluir = nível 2.']));
    d+=_oltDocSec('fa-gauge-high', OLTC.acc, '39. Desempenho e conexão com a OLT (VTY)',
        'A OLT aceita <b>poucas sessões Telnet (VTY)</b> ao mesmo tempo. O sistema é feito pra não esgotá-las.'+
        li(['<b>Mutex Telnet:</b> só UMA sessão por OLT de cada vez (app + cron), serializada por lock — evita congestionar as VTYs.',
            '<b>Backoff adaptativo:</b> se uma leitura falha (VTY cheia / "Placa não respondeu"), o auto-sync <b>recua</b> alguns ciclos pra a OLT (e o SmartOLT) respirarem, e volta ao normal quando responde.',
            '<b>Aprovisionamento enxuto:</b> reduzido para ~3-4 sessões por ONU (confirm + 1 re-checagem + 1 sessão que junta service-port, descrição e verificação) — segura a OLT bem menos tempo.',
            '<b>Delete idempotente:</b> se a ONU já não existe ("The ONT does not exist"), conta como sucesso.',
            '<b>Uptime ao vivo:</b> a coluna Tempo conta em tempo real (reancora a cada leitura da OLT).',
            '<b>Cache primeiro:</b> cards/páginas/gráficos abrem com o cache na hora e atualizam em 2º plano — nunca travam esperando a OLT.']));
    d+=_oltDocSec('fa-plug-circle-plus', OLTC.grn, '40. Aprovisionamento — fluxo e feedback',
        'Como o app se comporta ao aprovisionar e agir sobre as ONUs.'+
        li(['<b>ONU nova aparece ao vivo:</b> ao abrir o <b>Aprovisionar</b>, o app lê o autofind da OLT <b>ao vivo</b> (não só do cache) — a ONU recém-plugada aparece em segundos, sem relogar. A varredura de fundo <b>pausa</b> enquanto o Aprovisionar ou o Terminal estão abertos, pra o comando não falhar por VTY ocupada.',
            '<b>Aparece na hora após autorizar:</b> a ONU entra na lista imediatamente (inserção otimista) e o card <b>Aguardando Liberação</b> baixa na hora. Ela mostra <b>Inicializando…</b> (âmbar) nos primeiros ~3 min enquanto sobe de fato, contando como Offline (não "Desativada").',
            '<b>Zona/tipo/modo são ENVIADOS:</b> o Autorizar manda tudo pro backend — fsp, sn, nome, VLAN, <b>zona</b>, <b>modo</b> (Bridge/Router) e o tipo — pra gravar na OLT e registrar no SmartOLT.',
            '<b>Ações em lote com diálogo:</b> Reiniciar/Ressincronizar/Bloquear/Liberar/Deletar em várias ONUs mostram um <b>modal com barra de progresso</b>, cronômetro (segundos), nome da ONU atual e contadores ✓/✗. Roda uma a uma (respiro + retry) pra não congestionar.',
            '<b>Deletar não "volta":</b> ao deletar, a ONU é removida também do <b>cache</b> do backend — não reaparece na lista (volta só pro card de Aprovisionamento, que é o correto: o SN retorna ao autofind).']));
    d+='<div style="padding:14px 18px; color:'+OLTC.mut+'; font-size:11px;">Wellsystem · documentação — © 2026 Wellnet Telecom. Substitua <code>IP_DO_SERVIDOR</code> pelo endereço real da sua instalação.</div>';
    return d;
}
function oltDocumentacao(){
    var atual=document.getElementById('oltDocWin'); if(atual){ atual.style.display='flex'; atual.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); return; }
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltDocWin';
    var _l=Math.max(8, Math.round((window.innerWidth/2)-380));
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:40px; left:'+_l+'px; width:min(96vw,760px); max-height:calc(100vh - 60px); display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.6); overflow:hidden;';
    win.onmousedown=function(){ win.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); };
    win.innerHTML=
      '<div id="oltDocHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); cursor:move;">'+
        '<button onclick="var w=document.getElementById(\'oltDocWin\'); if(w) w.remove();" title="Voltar" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-book" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0; font-weight:800; color:#fff; font-size:13.5px;">Documentação — Wellsystem</div>'+
        '<button onclick="_oltJanMin(\'oltDocWin\',\'oltDocBody\',\'Documentação\',\'fa-book\')" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltDocMax()" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="var w=document.getElementById(\'oltDocWin\'); if(w) w.remove();" title="Fechar" style="'+_ctrl+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltDocBody" style="flex:1 1 auto; overflow:auto;">'+_oltDocConteudo()+'</div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltDocHead'));
    if(typeof oltResizify==='function') oltResizify(win, 420, 320);
}
function oltDocMax(){ var w=document.getElementById('oltDocWin'); if(!w) return;
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|'); w.style.top=g[0]||'40px'; w.style.left=g[1]||(Math.max(8,Math.round(window.innerWidth/2-380))+'px'); w.style.width=g[2]||'min(96vw,760px)'; w.style.height=g[3]||''; w.style.maxHeight='calc(100vh - 60px)'; w.style.borderRadius='14px'; w.setAttribute('data-max','0'); }
    else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height); w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1'); } }
// ---- MENU (organiza os utilitários, igual ao da página principal) ----
// Item do menu: ícone em "pastilha" própria, título e realce lateral no hover.
function _oltMenuItem(ic,txt,fn){
    return '<button onclick="_oltCloseMenu(); _oltTelaLembrar(\''+_oltB64(fn)+'\'); '+fn+'" '+
        'style="display:flex; align-items:center; gap:11px; width:100%; text-align:left; cursor:pointer; padding:9px 12px; border:none; border-left:3px solid transparent; background:transparent; color:'+OLTC.txt+'; font-size:12.5px; font-weight:600; letter-spacing:.005em; transition:background .13s ease, border-color .13s ease, padding-left .13s ease;" '+
        'onmouseover="this.style.background=\''+OLTC.bg2+'\'; this.style.borderLeftColor=\''+OLTC.acc+'\'; this.style.paddingLeft=\'15px\';" '+
        'onmouseout="this.style.background=\'transparent\'; this.style.borderLeftColor=\'transparent\'; this.style.paddingLeft=\'12px\';">'+
        '<span style="flex:0 0 auto; width:26px; height:26px; border-radius:7px; background:'+OLTC.redf+'26; display:inline-flex; align-items:center; justify-content:center;"><i class="fa-solid '+ic+'" style="color:'+OLTC.redf+'; font-size:12px;"></i></span>'+
        '<span title="'+String(txt).replace(/"/g,'&quot;')+'" style="flex:1 1 auto; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+txt+'</span>'+
        '<i class="fa-solid fa-chevron-right" style="flex:0 0 auto; font-size:9px; color:'+OLTC.mut+'; opacity:.55;"></i>'+
    '</button>';
}
// Separador com rótulo, para agrupar o menu por assunto.
function _oltMenuSep(txt){ return '<div style="padding:9px 13px 5px; font-size:8px; font-weight:800; letter-spacing:.1em; text-transform:uppercase; color:'+OLTC.mut+'; border-top:1px solid '+OLTC.line+'; margin-top:4px;">'+txt+'</div>'; }
function _oltMenuBtn(){
    return '<div style="position:relative; display:inline-block;">'+
        '<button onclick="oltToggleMenu(event)" style="cursor:pointer; padding:12px 20px; border-radius:10px; border:1px solid '+OLTC.line+'; background:'+OLTC.bg2+'; color:'+OLTC.txt+'; font-size:15px; font-weight:800;"><i class="fa-solid fa-bars" style="font-size:16px;"></i> Menu <i class="fa-solid fa-chevron-down" style="font-size:10px; margin-left:3px;"></i></button>'+
        '<div id="oltMenuDrop" style="display:none; position:fixed; top:0; left:0; z-index:2147482500; width:330px; max-width:calc(100vw - 16px); box-sizing:border-box; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; box-shadow:0 18px 44px rgba(0,0,0,0.30), 0 3px 10px rgba(0,0,0,0.16); overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain; padding:6px 0 8px;">'+
          // Itens de EDIÇÃO só aparecem para o Root (nível 3). Monitoramento e
          // documentação ficam para todos. O servidor valida de novo, sempre.
          _oltMenuSep('Monitoramento')+
          _oltMenuItem('fa-chart-pie','Resumo / Contagem','oltResumoContagem()')+
          _oltMenuItem('fa-chart-area','Gráfico — Status da rede','oltGrafico()')+
          _oltMenuItem('fa-file-lines','Logs / Relatórios','oltRelatorio()')+
          _oltMenuItem('fa-tower-broadcast','Alarmes da OLT (PON/Placa)','oltAlarmes()')+
          (_oltNivel()>=2 ? _oltMenuItem('fa-triangle-exclamation','Emergência Radius (Qualquer login)','oltRadiusEmergencia()') : '')+
          // NÍVEL 2+ : quase todo o menu (operação do dia a dia). O servidor valida de novo, sempre.
          (_oltNivel()>=2 ? (
            _oltMenuSep('Cadastros')+
            _oltMenuItem('fa-map-location-dot','Gerenciar Zonas','oltGerenciarZonas()')+
            _oltMenuItem('fa-ethernet','Gerenciar Portas PON','oltGerenciarPortas()')+
            _oltMenuItem('fa-tags','Descrições das PONs','oltGerenciarDescPon()')+
            _oltMenuItem('fa-signal','Limites de sinal (Rx)','oltLimitesSinal()')+
            _oltMenuItem('fa-microchip','Perfis ONU / ONT','oltGerenciarPerfis()')+
            _oltMenuItem('fa-gauge-high','Perfis de velocidade','oltPerfisVelocidade()')+
            _oltMenuItem('fa-chart-line','Gráficos por PON','oltGraficosPon()')+
            _oltMenuItem('fa-network-wired','Gráficos de Uplink','oltGraficosUplink()')+
            _oltMenuItem('fa-wave-square','Gráficos de Sinal (ONUs)','oltGraficosSinal()')+
            _oltMenuItem('fa-bolt','Oscilação de conexões (quedas)','oltOscilacao()')+
            _oltMenuItem('fa-clock-rotate-left','Histórico de conexões (por cliente)','oltHistoricoConexoes()')+
            _oltMenuItem('fa-gauge-high','Consumo de Banda (ONUs)','oltGraficosBanda()')+
            _oltMenuItem('fa-temperature-half','Gráfico — Temperatura da OLT','oltGraficoTemp()')+
            _oltMenuItem('fa-calendar-check','Autorizações por dia','oltGraficoAuth()')+
            _oltMenuItem('fa-cloud-arrow-down','Atualizar do SmartOLT (nuvem)','oltSeedSmartOLT()')+
            _oltMenuSep('Sistema')+
            _oltMenuItem('fa-bell','Notificações (WhatsApp/Telegram)','oltNotificacoes()')+
            _oltMenuItem('fa-id-card','Link de Cadastro (Radius)','oltConfigCadastro()')+
            _oltMenuItem('fa-image','Logomarca da OLT','oltLogoOlt()')+
            _oltMenuItem('fa-folder-open','Modelos ONT / ONU','oltMkfiles()')+
            _oltMenuItem('fa-database','Backup (salvar/restaurar)','oltBackup()')
          ) : '')+
          // NÍVEL 3 (ROOT) : SÓ o que pode comprometer — mexer em PLACA, VLAN de PLACA, conexão, terminal, usuários.
          (_oltNivel()>=3 ? (
            _oltMenuSep('Administração (Root)')+
            _oltMenuItem('fa-server','Gerenciar Placas','oltGerenciarPlacas()')+
            _oltMenuItem('fa-network-wired','Gerenciar Uplink (VLANs)','oltGerenciarUplink()')+
            _oltMenuItem('fa-network-wired','Gerenciar VLANs','oltGerenciarVlans()')+
            _oltMenuItem('fa-network-wired','Conexão da OLT','oltConexao()')+
            _oltMenuItem('fa-terminal','Prompt de Comando (OLT)','oltTerminal()')+
            _oltMenuItem('fa-users','Usuários e acessos','oltUsuarios()')+
            _oltMenuItem('fa-clock-rotate-left','Acessos e tempo de conexão','oltSessoes()')
          ) : '')+
          _oltMenuSep('Ajuda')+
          _oltMenuItem('fa-book','Documentação (Wellsystem)','oltDocumentacao()')+
        '</div>'+
    '</div>';
}
function oltToggleMenu(e){ if(e) e.stopPropagation(); var d=document.getElementById('oltMenuDrop'); if(!d) return;
    var show=(d.style.display==='none'||!d.style.display);
    d.style.display=show?'block':'none';
    if(show){
        // Ancora o menu na tela (fixed) logo abaixo do botão. Fica PARADO quando a
        // página rola, e as opções rolam DENTRO dele quando não cabem na altura.
        var btn=d.previousElementSibling; var r=btn.getBoundingClientRect();
        var maxH=Math.max(160, window.innerHeight - r.bottom - 16);
        d.style.top=Math.round(r.bottom+6)+'px';
        var left=r.left; if(left + d.offsetWidth > window.innerWidth-8) left=window.innerWidth-8-d.offsetWidth;
        d.style.left=Math.max(6, Math.round(left))+'px';
        d.style.maxHeight=maxH+'px';
        setTimeout(function(){ document.addEventListener('click', _oltCloseMenu); },0);
    }
}
function _oltCloseMenu(){ var d=document.getElementById('oltMenuDrop'); if(d) d.style.display='none'; document.removeEventListener('click', _oltCloseMenu); }
// ---- LOGS / RELATÓRIOS (janela flutuante, modelo do log da página principal) ----
function oltRelatorio(){
    var atual=document.getElementById('oltRelWin'); if(atual) atual.remove();
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltRelWin';
    var _rwL=Math.max(8, Math.round((window.innerWidth/2)-400)); // pixel inteiro: texto nitido (sem meio-pixel do calc)
    win.style.cssText='position:fixed; z-index:2147482000; top:70px; left:'+_rwL+'px; width:min(96vw,800px); max-height:86vh; display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.55); overflow:hidden;';
    win.onmousedown=function(){ win.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); };
    win.innerHTML=
      '<div id="oltRelHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); cursor:move;">'+
        '<button onclick="var w=document.getElementById(\'oltRelWin\'); if(w) w.remove();" title="Voltar (fecha e volta à tela anterior)" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-file-lines" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0;"><div style="font-weight:800; color:#fff; font-size:13.5px;">Logs / Relatórios da OLT</div><div style="font-size:10.5px; color:var(--text-secondary);">Aprovisionamentos e retiradas · dia e mês (reset automático dia 1)</div></div>'+
        '<button onclick="oltRelatorio()" title="Atualizar" style="'+_ctrl+'"><i class="fa-solid fa-rotate"></i></button>'+
        '<button onclick="oltRelLimpar()" title="Limpar / zerar o relatório" style="'+_ctrl+' border-color:rgba(245,158,11,0.7);"><i class="fa-solid fa-trash-can" style="color:#fbbf24;"></i></button>'+
        '<button onclick="_oltJanMin(\'oltRelWin\',\'oltRelBody\',\'Logs / Relatórios\',\'fa-file-lines\')" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltRelMax()" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="var w=document.getElementById(\'oltRelWin\'); if(w) w.remove();" title="Fechar" style="'+_ctrl+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltRelBody" style="flex:1 1 auto; overflow:auto; padding:14px;"><div style="text-align:center; color:'+OLTC.mut+'; padding:20px;"><i class="fa-solid fa-spinner fa-spin"></i> Carregando relatório…</div></div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltRelHead'));
    oltResizify(win, 380, 280); // arrastar o canto p/ aumentar/diminuir
    fetch('olt_huawei.php?acao=relatorio').then(function(r){ return r.json(); }).then(function(d){ _oltRelRender(d); }).catch(function(){ var b=document.getElementById('oltRelBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+'; padding:16px;">Falha ao carregar o relatório.</div>'; });
}
// Limpa/zera o relatório (contadores + eventos). Pede confirmação.
function oltRelLimpar(){
    if(!confirm('Limpar TODO o relatório?\n\nZera os contadores (dia e mês) e apaga o histórico de eventos (aprovisionamentos/retiradas).\n\nEsta ação não tem volta. Continuar?')) return;
    var b=document.getElementById('oltRelBody'); if(b) b.innerHTML='<div style="text-align:center; color:'+OLTC.mut+'; padding:20px;"><i class="fa-solid fa-spinner fa-spin"></i> Limpando…</div>';
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=relatorio_limpar'})
      .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); _oltRelRender(d); })
      .catch(function(){ var bb=document.getElementById('oltRelBody'); if(bb) bb.innerHTML='<div style="color:'+OLTC.red+'; padding:16px;">Falha ao limpar o relatório.</div>'; });
}
function oltRelMax(){ var w=document.getElementById('oltRelWin'); if(!w) return;
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|'); w.style.top=g[0]||'70px'; w.style.left=g[1]||'max(8px, calc(50% - 400px))'; w.style.width=g[2]||'min(96vw,800px)'; w.style.height=g[3]||''; w.style.maxHeight='86vh'; w.style.borderRadius='14px'; w.setAttribute('data-max','0'); }
    else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height); w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1'); } }
function _oltRelRender(d){
    var b=document.getElementById('oltRelBody'); if(!b) return;
    if(d) window._oltRelData=d; else d=window._oltRelData||{};
    var c=(d&&d.contadores)||{}; var ev=(d&&d.eventos)||[];
    window._oltRelEventos=ev;
    window._oltRelCF=window._oltRelCF||{tipo:'',per:''}; var cf=window._oltRelCF;
    // Cada card é um FILTRO: clique filtra os eventos por tipo+período; clicar de novo limpa.
    var card=function(rot,val,cor,ic,tipo,per){ var ativo=(cf.tipo===tipo&&cf.per===per);
        return '<div onclick="_oltRelCardFiltro(\''+tipo+'\',\''+per+'\')" title="Clique para filtrar os eventos por isto (clique de novo para limpar)" style="flex:1 1 150px; min-width:140px; background:'+OLTC.bg2+'; border:1px solid '+(ativo?cor:OLTC.line)+';'+(ativo?' box-shadow:0 0 0 2px '+cor+'55;':'')+' border-radius:12px; padding:12px 14px; display:flex; align-items:center; gap:12px; cursor:pointer; transition:border-color .12s, box-shadow .12s;" onmouseover="this.style.borderColor=\''+cor+'\'" onmouseout="this.style.borderColor=\''+(ativo?cor:OLTC.line)+'\'"><div style="width:38px; height:38px; flex:0 0 auto; border-radius:10px; background:'+cor+'22; display:flex; align-items:center; justify-content:center;"><i class="fa-solid '+ic+'" style="color:'+cor+'; font-size:16px;"></i></div><div style="min-width:0;"><div style="font-size:22px; font-weight:800; color:'+OLTC.ink+'; line-height:1;">'+val+'</div><div style="font-size:10px; color:'+(ativo?cor:OLTC.mut)+'; text-transform:uppercase; letter-spacing:.5px;">'+rot+(ativo?' <i class="fa-solid fa-filter"></i>':'')+'</div></div></div>'; };
    var counters='<div style="display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px;">'+
        card('Aprovisionados hoje', (c.aprov_dia||0), OLTC.grn, 'fa-plug-circle-plus','aprovisionamento','dia')+
        card('Aprovisionados no mês', (c.aprov_mes||0), OLTC.grn, 'fa-calendar-check','aprovisionamento','mes')+
        card('Retiradas hoje', (c.retirada_dia||0), OLTC.red, 'fa-plug-circle-minus','retirada','dia')+
        card('Retiradas no mês', (c.retirada_mes||0), OLTC.red, 'fa-calendar-xmark','retirada','mes')+
    '</div>';
    var limpar=(cf.tipo||cf.per)?'<button onclick="_oltRelCardFiltro(\'\',\'\')" title="Mostrar todos os eventos" style="cursor:pointer; padding:5px 10px; border-radius:7px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-size:10.5px; font-weight:800;"><i class="fa-solid fa-xmark"></i> Limpar filtro</button>':'';
    b.innerHTML=counters+
        '<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:6px; flex-wrap:wrap;">'+
          '<div style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.acc+';"><i class="fa-solid fa-clock-rotate-left"></i> Últimos eventos<span id="oltRelTag"></span></div>'+
          '<div style="display:flex; align-items:center; gap:6px;">'+limpar+
            '<input id="oltRelFiltro" value="'+_oltEsc(window._oltRelTxt||'')+'" oninput="_oltRelAplicar()" placeholder="filtrar…" style="'+_oltInSt()+' font-size:11px; padding:5px 9px; max-width:200px;">'+
          '</div>'+
        '</div>'+
        '<div id="oltRelLista" style="border:1px solid '+OLTC.line+'; border-radius:10px; overflow:hidden;"></div>';
    _oltRelAplicar();
}
function _oltRelLinha(e){
    var t=(e.tipo||''); var cor, ic, rot;
    if(t==='aprovisionamento'){ cor=OLTC.grn; ic='fa-plug-circle-plus'; rot='APROVISIONAMENTO'; }
    else if(t==='retirada'){ cor=OLTC.red; ic='fa-plug-circle-minus'; rot='RETIRADA'; }
    else if(t==='pon_queda'){ cor=OLTC.red; ic='fa-triangle-exclamation'; rot='PON EM QUEDA'; }
    else if(t==='pon_retorno'){ cor=OLTC.grn; ic='fa-circle-check'; rot='PON NORMALIZOU'; }
    else if(t==='temp_alta'){ cor=OLTC.red; ic='fa-temperature-full'; rot='TEMPERATURA ALTA'; }
    else if(t==='temp_normal'){ cor=OLTC.grn; ic='fa-temperature-half'; rot='TEMPERATURA OK'; }
    else if(t==='espelho_smartolt'){ cor=OLTC.acc; ic='fa-cloud-arrow-down'; rot='ESPELHO SMARTOLT'; }
    else if(t==='evento'){ cor=OLTC.vio; ic='fa-pen-to-square'; rot='ALTERAÇÃO'; }
    else if(t==='backup_auto'||t==='backup_teste'){ cor=OLTC.grn; ic='fa-envelope-circle-check'; rot='BACKUP ENVIADO'; }
    else if(t==='backup_auto_falha'||t==='backup_teste_falha'){ cor=OLTC.red; ic='fa-envelope'; rot='BACKUP FALHOU'; }
    else if(t==='backup_auto_info'){ cor=OLTC.amb; ic='fa-circle-info'; rot='BACKUP AUTO'; }
    else if(t==='radius_modo'){ cor=OLTC.amb; ic='fa-right-left'; rot='AUTENTICAÇÃO RADIUS'; }
    else { cor=OLTC.mut; ic='fa-circle-info'; rot=t.toUpperCase(); }
    return '<div style="display:flex; align-items:center; gap:10px; padding:7px 10px; border-bottom:1px solid '+OLTC.line+'33; font-size:12px;">'+
        '<i class="fa-solid '+ic+'" style="color:'+cor+'; width:16px; text-align:center;"></i>'+
        '<span style="color:'+OLTC.mut+'; font-family:monospace; white-space:nowrap;">'+_oltEsc(e.data||'')+'</span>'+
        '<span style="color:'+cor+'; font-weight:800; font-size:10px; white-space:nowrap;">'+rot+'</span>'+
        '<span style="color:'+OLTC.txt+'; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(e.desc||'')+(e.fsp?(' <span style="color:'+OLTC.mut+';">('+_oltEsc(e.fsp)+')</span>'):'')+'</span>'+
    '</div>';
}
// Aplica o filtro dos CARDS (tipo + dia/mês) + o filtro de texto, e redesenha a lista.
function _oltRelAplicar(){
    var lista=document.getElementById('oltRelLista'); if(!lista) return;
    var cf=window._oltRelCF||{tipo:'',per:''};
    var inp=document.getElementById('oltRelFiltro'); var txt=((inp&&inp.value)||'').toLowerCase(); window._oltRelTxt=(inp&&inp.value)||'';
    var dt=new Date(); var p2=function(n){ return (n<10?'0':'')+n; };
    var hoje=dt.getFullYear()+'-'+p2(dt.getMonth()+1)+'-'+p2(dt.getDate());  // eventos gravam 'Y-m-d H:i:s'
    var mes=dt.getFullYear()+'-'+p2(dt.getMonth()+1);
    var arr=(window._oltRelEventos||[]).filter(function(e){
        if(cf.tipo && (e.tipo||'')!==cf.tipo) return false;
        if(cf.per==='dia' && String(e.data||'').indexOf(hoje)!==0) return false;
        if(cf.per==='mes' && String(e.data||'').indexOf(mes)!==0) return false;
        if(txt && ((e.data||'')+' '+(e.tipo||'')+' '+(e.desc||'')+' '+(e.fsp||'')).toLowerCase().indexOf(txt)<0) return false;
        return true;
    });
    lista.innerHTML = arr.length ? arr.map(_oltRelLinha).join('')
        : '<div style="color:'+OLTC.mut+'; padding:16px; text-align:center;">'+((cf.tipo||cf.per||txt)?'Nenhum evento para este filtro.':'Sem eventos registrados ainda. Ao autorizar ou remover uma ONU, aparece aqui.')+'</div>';
    var tag=document.getElementById('oltRelTag');
    if(tag) tag.innerHTML='<span style="color:'+OLTC.mut+'; font-weight:600; text-transform:none; letter-spacing:0;"> — '+arr.length+' de '+(window._oltRelEventos||[]).length+'</span>';
}
function _oltRelCardFiltro(tipo,per){
    window._oltRelCF=window._oltRelCF||{tipo:'',per:''}; var cf=window._oltRelCF;
    if(cf.tipo===tipo && cf.per===per){ cf.tipo=''; cf.per=''; } else { cf.tipo=tipo; cf.per=per; }
    _oltRelRender(null); // redesenha (destaque do card) usando os dados já carregados
}
function _oltRelFiltrar(t){ var i=document.getElementById('oltRelFiltro'); if(i&&t!=null) i.value=t; _oltRelAplicar(); }
// Sobrepõe os campos salvos (zona, etc.) por SN na lista — o banco local sempre vence.
// Se não houver zona salva, PREENCHE derivando da VLAN (só onde há certeza). Manual > VLAN.
function _oltAplicarCadastro(){
    var cad=window._oltCadastro||{};
    (window._oltLista||[]).forEach(function(o){
        var sn=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var c=sn&&cad[sn];
        if(c && c.zona){ o.zona=c.zona; return; }            // edição manual sempre vence
        if(!o.zona){ var z=_oltZonaDoVlan(o.vlan); if(z) o.zona=z; } // preenche da VLAN
    });
}
/* Serial nos 2 formatos: hex (48575443101E497B) <-> fabricante (HWTC101E497B). O cadastro (zona/nome/tipo
   editados) podia estar num formato e a lista procurar no outro: a zona nova não aparecia e voltava a
   ANTIGA do equipamento reaproveitado. Agora procura nos dois; o formato hex (o da lista) vence. */
function _oltSnVariantes(serial){
    var sn=String(serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(!sn) return [];
    var v=[sn], m;
    if((m=sn.match(/^([A-Z0-9]{4})([0-9A-F]{8})$/)) && /[G-Z]/.test(m[1])){ var h=''; for(var i=0;i<4;i++) h+=('0'+m[1].charCodeAt(i).toString(16)).slice(-2).toUpperCase(); v.unshift(h+m[2]); }
    else if((m=sn.match(/^([0-9A-F]{8})([0-9A-F]{8})$/))){ var t=''; for(var j=0;j<8;j+=2) t+=String.fromCharCode(parseInt(m[1].substr(j,2),16)); if(/^[A-Z0-9]{4}$/.test(t)) v.push(t+m[2]); }
    return v;
}
function _oltCadDe(serial){ var cad=window._oltCadastro||{}; var vs=_oltSnVariantes(serial); for(var i=0;i<vs.length;i++){ if(cad[vs[i]]) return cad[vs[i]]; } return null; }
// Editor inline da Zona (clicar na célula) — grava no banco local por SN.
function oltEditarZona(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    if(!o.serial){ alert('Sem serial para gravar a zona.'); return; }
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var s=_oltInSt();
    var dl=OLT_ZONAS.map(function(z){ return '<option value="'+_oltEsc(z)+'"></option>'; }).join('');
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,380px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:6px;"><i class="fa-solid fa-map-location-dot" style="color:'+OLTC.acc+';"></i> Zona da ONU</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:10px;">'+_oltEsc(o.nome||o.serial)+' — escolha ou digite a zona (salva no banco local).</div>'+
        '<input id="oltZonaInp" list="oltZonaDL" value="'+_oltEsc(o.zona||'')+'" placeholder="Zona..." style="'+s+' width:100%; box-sizing:border-box; margin-bottom:12px;">'+
        '<datalist id="oltZonaDL">'+dl+'</datalist>'+
        '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltZonaSalvar(\''+_oltEsc(fsp)+'\',\''+_oltEsc(id)+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;">Salvar</button>'+
        '</div></div>';
    document.body.appendChild(ov);
    setTimeout(function(){ var i=document.getElementById('oltZonaInp'); if(i){ i.focus(); i.select(); } }, 30);
}
function oltZonaSalvar(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    var val=(document.getElementById('oltZonaInp')||{}).value||''; val=val.trim();
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    o.zona=val; // otimista
    var sn=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    window._oltCadastro=window._oltCadastro||{}; window._oltCadastro[sn]=window._oltCadastro[sn]||{}; window._oltCadastro[sn].zona=val;
    oltRenderLista();
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial)+'&campo=zona&valor='+encodeURIComponent(val)})
      .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); }).catch(function(){});
}
// Editor do NOME do cliente (ícone "+" no fim do nome na lista) — salva no banco local por SN.
function oltEditarNome(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    if(!o.serial){ alert('Sem serial para gravar o nome.'); return; }
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var s=_oltInSt();
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,400px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:6px;"><i class="fa-solid fa-user-pen" style="color:'+OLTC.acc+';"></i> Nome do cliente</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:10px;">SN '+_oltEsc(o.serial)+' — salva no banco local. Se errar, corrija aqui e ressincronize.</div>'+
        '<input id="oltNomeInp" value="'+_oltEsc(_oltNomeDe(o))+'" placeholder="Nome do cliente..." style="'+s+' width:100%; box-sizing:border-box; margin-bottom:12px;" onkeydown="if(event.key===\'Enter\')oltNomeSalvar(\''+_oltEsc(fsp)+'\',\''+_oltEsc(id)+'\')">'+
        '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltNomeSalvar(\''+_oltEsc(fsp)+'\',\''+_oltEsc(id)+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;">Salvar</button>'+
        '</div></div>';
    document.body.appendChild(ov);
    setTimeout(function(){ var i=document.getElementById('oltNomeInp'); if(i){ i.focus(); i.select(); } }, 30);
}
function oltNomeSalvar(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    var val=(document.getElementById('oltNomeInp')||{}).value||''; val=val.trim();
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    var sn=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    window._oltCadastro=window._oltCadastro||{}; window._oltCadastro[sn]=window._oltCadastro[sn]||{}; window._oltCadastro[sn].nome=val;
    oltRenderLista(); _oltResumoRefresh();
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial)+'&campo=nome&valor='+encodeURIComponent(val)})
      .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); }).catch(function(){});
}
// Editor da VLAN (ícone "+" na coluna VLAN) — nome local + (opcional) TROCA real da VLAN na OLT.
function oltEditarVlanNome(vlan, fsp, id){
    vlan=(''+vlan).replace(/[^0-9]/g,''); if(!vlan && !fsp){ alert('VLAN inválida.'); return; }   // sem VLAN mas com ONU: abre só pra criar o service-port
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var s=_oltInSt();
    var secOlt=(fsp&&id!==''&&id!=null)?(
        '<div style="margin-top:14px; padding-top:12px; border-top:1px solid '+OLTC.line+';">'+
          '<div style="font-size:11px; font-weight:800; color:'+OLTC.amb+'; margin-bottom:4px;"><i class="fa-solid fa-triangle-exclamation"></i> Trocar a VLAN desta ONU na OLT</div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-bottom:8px;">Reconfigura o service-port na OLT (remove o atual e cria com a nova VLAN). O cliente pode cair por alguns segundos. Afeta SÓ esta ONU.</div>'+
          '<div style="display:flex; gap:8px;">'+
            '<input id="oltVlanNovaInp" list="oltVlanDL2" value="'+vlan+'" inputmode="numeric" placeholder="nova VLAN" style="'+s+' flex:1 1 auto; min-width:0;">'+
            '<button type="button" onclick="oltTrocarVlanOlt(\''+_oltEsc(fsp)+'\',\''+_oltEsc(id)+'\')" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:none; background:'+OLTC.amb+'; color:#fff; font-weight:800; white-space:nowrap;">Aplicar na OLT</button>'+
          '</div><datalist id="oltVlanDL2">'+_oltVlanOltOpts()+'</datalist>'+
        '</div>'):'';
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,420px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:6px;"><i class="fa-solid fa-network-wired" style="color:'+OLTC.acc+';"></i> VLAN '+vlan+'</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:6px;">Nome da VLAN (salva no banco local — vale em toda a lista e no aprovisionamento).</div>'+
        '<input id="oltVlanNomeInp" value="'+_oltEsc(_oltVlanNome(vlan))+'" placeholder="nome da VLAN..." style="'+s+' width:100%; box-sizing:border-box; margin-bottom:12px;" onkeydown="if(event.key===\'Enter\')oltEditarVlanNomeSalvar(\''+vlan+'\')">'+
        '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltEditarVlanNomeSalvar(\''+vlan+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;">Salvar nome</button>'+
        '</div>'+secOlt+'</div>';
    document.body.appendChild(ov);
    setTimeout(function(){ var i=document.getElementById('oltVlanNomeInp'); if(i){ i.focus(); i.select(); } }, 30);
}
// TROCA REAL da VLAN da ONU na OLT (reconfigura service-port). Confirmação forte.
function oltTrocarVlanOlt(fsp,id){
    // Só o PRIMEIRO número: a sugestão vem como "350 - SLT5_XXX" e tirar tudo que não é dígito juntava o "5"
    // do nome ("3505"; "150 - SLT1…" virava "1501"). Bug corrigido 30/09/2026.
    var nova=((((document.getElementById('oltVlanNovaInp')||{}).value||'').match(/\d+/))||[''])[0];
    if(!nova){ alert('Informe a nova VLAN.'); return; }
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; });
    // Mesma VLAN = RECRIAR o service-port (ONU online sem navegar: service-port ausente na OLT).
    var mesma=(''+((o&&o.vlan)||'')).replace(/[^0-9]/g,'')===nova;
    if(!confirm((mesma?'RECRIAR o service-port da VLAN '+nova+' desta ONU na OLT?\n\nUse quando a ONU está online mas o cliente não navega (service-port ausente).':'TROCAR a VLAN desta ONU na OLT para '+nova+'?\n\nIsto reconfigura o service-port (remove o atual e recria com a VLAN '+nova+').')+' O cliente pode cair por alguns segundos.\n\nSó esta ONU. Continuar?')) return;
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    // fetch direto (sem a fila/watchdog de 25s): lê line-profile, GEMs, cria service-port e native-vlan
    window._oltPausarFundo=true;
    var pg=_oltSpProgresso(fsp,id,nova,mesma);
    _oltFetchDireto('olt_huawei.php?acao=onu_trocar_vlan&fsp='+encodeURIComponent(fsp)+'&id='+encodeURIComponent(id)+'&vlan='+encodeURIComponent(nova), 290000)
      .then(function(r){ window._oltPausarFundo=false; return r.json(); }, function(e){ window._oltPausarFundo=false; throw e; }).then(function(d){
        if(!d||d.status!=='ok'){ pg.fim(false,'Falha: '+((d&&d.message)||'erro ao trocar a VLAN'),d); return; }
        if(d.sucesso){ if(o){ o.vlan=nova; } if(oltGerenciadorAberto()) oltRenderLista(); _oltResumoRefresh(); }
        pg.fim(!!d.sucesso, d.sucesso?('Service-port da VLAN '+nova+' criado'+(d.sp_gem?' (gemport '+d.sp_gem+')':'')+(d.conferido?' e conferido na OLT.':' — confira a saída abaixo.'))
                                     :'A OLT recusou o service-port da VLAN '+nova+' — veja a saída abaixo.', d);
      }).catch(function(err){ pg.fim(false,'Erro: '+((err&&err.name==='AbortError')?'a OLT demorou mais de 290s para responder (pode ter aplicado — confira em VLAN / Service-port).':err), null); });
}
// JANELA DE PROCESSAMENTO da troca/recriação de VLAN: mostra cada etapa enquanto a OLT trabalha
// e, no fim, o resultado real (etapas marcadas pela saída da OLT) + conferência do service-port.
function _oltSpProgresso(fsp,id,vlan,mesma){
    var passos=['Conectando na OLT (sessão Telnet)','Lendo os service-ports atuais'+(mesma?'':' e removendo o antigo'),'Lendo o line-profile e os GEM da ONU','Criando o service-port VLAN '+vlan,'Aplicando native-vlan na LAN 1 (bridge)','Conferindo o service-port na OLT'];
    var tit=(mesma?'Recriando':'Trocando')+' VLAN — '+fsp+' · ONT '+id;
    var wid=_oltModalSimples('fa-network-wired',tit,'<div id="oltSpPg" style="padding:4px 2px;"></div>',false);
    var t0=Date.now(), feito=false;
    function ico(st){ return st==='ok'?'<i class="fa-solid fa-circle-check" style="color:'+OLTC.grn+';"></i>':st==='err'?'<i class="fa-solid fa-circle-xmark" style="color:'+OLTC.red+';"></i>':st==='run'?'<i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.acc+';"></i>':st==='pula'?'<i class="fa-solid fa-circle-minus" style="color:'+OLTC.mut+';"></i>':'<i class="fa-regular fa-circle" style="color:'+OLTC.mut+';"></i>'; }
    function render(sts,msg,cor,extra){
        var el=document.getElementById('oltSpPg'); if(!el) return;
        var h='';
        for(var i=0;i<passos.length;i++) h+='<div style="display:flex; gap:9px; align-items:center; padding:6px 4px; font-size:12.5px; color:'+OLTC.ink+'; border-bottom:1px solid '+OLTC.line+';">'+ico(sts[i])+'<span>'+_oltEsc(passos[i])+'</span></div>';
        h+='<div style="margin-top:10px; font-size:12.5px; font-weight:700; color:'+(cor||OLTC.mut)+';">'+msg+'</div>';
        el.innerHTML=h+(extra||'');
    }
    function tick(){
        if(feito) return;
        var s=Math.round((Date.now()-t0)/1000);
        var atual=Math.min(passos.length-1, Math.floor(s/5));   // avança o indicador enquanto a OLT responde
        var sts=[]; for(var i=0;i<passos.length;i++) sts.push(i<atual?'ok':i===atual?'run':'');
        render(sts,'<i class="fa-solid fa-hourglass-half"></i> Processando na OLT… '+s+'s (não feche a janela)');
        setTimeout(tick,1000);
    }
    tick();
    return { id:wid, fim:function(ok,msg,d){
        feito=true; d=d||{};
        var log=''+(d.sp_log||''), okResp=d.status==='ok', sts=[];
        sts[0]=okResp?'ok':'err';
        sts[1]=okResp?'ok':'';
        sts[2]=okResp?'ok':'';
        sts[3]=ok?'ok':(okResp?'err':'');
        sts[4]=/native-vlan/i.test(log)?'ok':(ok?'pula':'');
        sts[5]=d.conferido?'ok':(d.conferencia?'err':'');
        var s=Math.round((Date.now()-t0)/1000), extra='';
        if(d.conferencia) extra+='<div style="margin-top:10px; font-size:11px; font-weight:800; color:'+OLTC.mut+';">SERVICE-PORT NA OLT AGORA</div>'+_oltPre(d.conferencia);
        if(d.saida) extra+='<details style="margin-top:8px;"><summary style="cursor:pointer; font-size:11.5px; color:'+OLTC.acc+'; font-weight:700;">Saída completa da OLT</summary>'+_oltPre(d.saida)+'</details>';
        render(sts,'<i class="fa-solid '+(ok?'fa-circle-check':'fa-triangle-exclamation')+'"></i> '+_oltEsc(msg)+' <span style="font-weight:400; color:'+OLTC.mut+';">('+s+'s)</span>', ok?OLTC.grn:OLTC.red, extra);
    }};
}
function oltEditarVlanNomeSalvar(vlan){
    var val=(document.getElementById('oltVlanNomeInp')||{}).value||'';
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    oltVlanNomeSalvar((''+vlan).replace(/[^0-9]/g,''), val); // reusa: salva + confirma + re-render + datalist
}
// Editor da PORTA PON (ícone "+" na coluna PON) — apelido + VLAN + Zona padrão da porta (banco local).
// Dimensão DOMINANTE das ONUs de uma porta (zona/vlan mais comuns) — base do auto-preenchimento.
function _oltPortaDominante(fsp){
    var L=window._oltLista||[]; var zc={}, vc={};
    L.forEach(function(o){ if((o.fsp||'')!==fsp) return; var z=(o.zona||'').trim(); if(z) zc[z]=(zc[z]||0)+1; var v=(''+(o.vlan||'')).replace(/[^0-9]/g,''); if(v) vc[v]=(vc[v]||0)+1; });
    var top=function(m){ var k='',n=0; for(var x in m){ if(m[x]>n){ n=m[x]; k=x; } } return k; };
    return { zona:top(zc), vlan:top(vc) };
}
function oltEditarPorta(fsp){
    if(!fsp){ return; } var s=_oltInSt();
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var dlz='<datalist id="oltPortaZnDL">'+OLT_ZONAS.map(function(z){ return '<option value="'+_oltEsc(z)+'"></option>'; }).join('')+'</datalist>';
    var lbl=function(t){ return '<div style="font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700; margin:8px 0 2px;">'+t+'</div>'; };
    // AUTO-PREENCHE (editável): se o campo estiver vazio, sugere pela dimensão dominante da porta.
    var dom=_oltPortaDominante(fsp);
    var vAp=_oltPortaNome(fsp)||dom.zona; var vVl=_oltPortaVlan(fsp)||dom.vlan; var vZn=_oltPortaZona(fsp)||dom.zona;
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,420px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+dlz+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:2px;"><i class="fa-solid fa-ethernet" style="color:'+OLTC.acc+';"></i> Porta PON '+_oltEsc(fsp)+'</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+';">Padrões da porta (usados no aprovisionamento). Vem preenchido pela dimensão dominante — <b>edite se quiser</b>. Salva no banco local.</div>'+
        lbl('Apelido da porta')+'<input id="oltPortaApInp" value="'+_oltEsc(vAp)+'" placeholder="ex.: Centro" style="'+s+' width:100%; box-sizing:border-box;">'+
        lbl('VLAN padrão')+'<input id="oltPortaVlInp" value="'+_oltEsc(vVl)+'" inputmode="numeric" placeholder="ex.: 57" style="'+s+' width:100%; box-sizing:border-box;">'+
        lbl('Zona padrão')+'<input id="oltPortaZnInp" list="oltPortaZnDL" value="'+_oltEsc(vZn)+'" placeholder="ex.: ALTO DA SANTA 1" style="'+s+' width:100%; box-sizing:border-box;">'+
        '<div style="margin-top:10px; font-size:10.5px; color:'+OLTC.mut+'; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:8px; padding:8px 10px;"><i class="fa-solid fa-circle-info" style="color:'+OLTC.acc+';"></i> Para <b>mover a ONU para outra PORTA física</b> é preciso re-autorizar na porta nova (a fibra tem que estar naquela porta) — não dá pra mover só por software. Estes campos são os <b>padrões</b> da porta (apelido/VLAN/Zona).</div>'+
        '<div style="display:flex; gap:8px; justify-content:flex-end; margin-top:12px;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltEditarPortaSalvar(\''+_oltEsc(fsp)+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;">Salvar</button>'+
        '</div></div>';
    document.body.appendChild(ov);
    setTimeout(function(){ var i=document.getElementById('oltPortaApInp'); if(i) i.focus(); }, 30);
}
function oltEditarPortaSalvar(fsp){
    var ap=((document.getElementById('oltPortaApInp')||{}).value||'').trim();
    var vl=((((document.getElementById('oltPortaVlInp')||{}).value||'').match(/\d+/))||[''])[0];   // só o 1º número (ver oltVlanNovaInp)
    var zn=((document.getElementById('oltPortaZnInp')||{}).value||'').trim();
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    _oltMetaSet('porta', fsp, ap); _oltMetaSet('portavlan', fsp, vl); _oltMetaSet('portazona', fsp, zn);
}
// Espelhar as DESCRIÇÕES das PONs (nomes) — lista TODAS as portas 0-15 das placas 1/3/5,
// inclusive as vazias/RESERVA. Salva no banco local (aparece no alerta de PON em queda).
function oltGerenciarDescPon(){
    var slots=(typeof OLT_SLOTS!=='undefined'&&OLT_SLOTS&&OLT_SLOTS.length)?OLT_SLOTS:[1,3,5];
    var s=_oltInSt();
    var corpo=slots.map(function(sl){
        var linhas=''; for(var pt=0; pt<=15; pt++){ var fsp='0/'+sl+'/'+pt;
            linhas+='<div style="display:flex; align-items:center; gap:8px; padding:4px 0;">'+
                '<span style="flex:0 0 40px; font-weight:800; color:'+OLTC.acc+';">P'+pt+'</span>'+
                '<span style="flex:0 0 62px; font-family:monospace; font-size:10px; color:'+OLTC.mut+';">'+fsp+'</span>'+
                '<input value="'+_oltEsc(_oltPortaNome(fsp))+'" onchange="_oltMetaSet(\'porta\',\''+fsp+'\',this.value.trim())" placeholder="descrição da PON (ex.: HOSPITAL)" style="'+s+' flex:1 1 auto; min-width:0;">'+
            '</div>';
        }
        return '<div style="margin-bottom:14px;"><div style="font-size:11px; font-weight:800; text-transform:uppercase; color:'+OLTC.mut+'; border-bottom:1px solid '+OLTC.line+'; padding-bottom:4px; margin-bottom:6px;"><i class="fa-solid fa-server" style="color:'+OLTC.acc+';"></i> Placa '+sl+'</div>'+linhas+'</div>';
    }).join('');
    // Janela flutuante própria (com minimizar / maximizar / arrastar), no lugar do modal simples.
    var atual=document.getElementById('oltDescWin'); if(atual) atual.remove();
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltDescWin';
    var _dl=Math.max(8, Math.round((window.innerWidth/2)-320));
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:60px; left:'+_dl+'px; width:min(96vw,640px); max-height:86vh; display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.55); overflow:hidden;';
    win.onmousedown=function(){ win.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); };
    win.innerHTML=
      '<div id="oltDescHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); cursor:move;">'+
        '<button onclick="var w=document.getElementById(\'oltDescWin\'); if(w) w.remove(); var p=document.getElementById(\'oltDescPill\'); if(p) p.remove();" title="Voltar" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-tags" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0; font-weight:800; color:#fff; font-size:13.5px;">Descrições das PONs</div>'+
        '<button onclick="_oltJanMin(\'oltDescWin\',\'oltDescBody\',\'Descrições das PONs\',\'fa-tags\',\'oltGerenciarDescPon\')" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
          '<button onclick="_oltJanMax(\'oltDescWin\')" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
          '<button onclick="var el=document.activeElement; if(el&&el.blur) el.blur(); setTimeout(function(){ var w=document.getElementById(\'oltDescWin\'); if(w) w.remove(); var p=document.getElementById(\'oltDescPill\'); if(p) p.remove(); }, 150);" title="Salvar alterações e Fechar" style="cursor:pointer; height:30px; padding:0 12px; border-radius:7px; border:1px solid rgba(255,255,255,0.4); background:#10b981; color:#fff; font-size:12px; font-weight:800; margin-left:4px;"><i class="fa-solid fa-floppy-disk" style="margin-right:5px;"></i> Salvar</button>'+
          '<button onclick="var w=document.getElementById(\'oltDescWin\'); if(w) w.remove(); var p=document.getElementById(\'oltDescPill\'); if(p) p.remove();" title="Fechar sem salvar" style="'+_ctrl+' background:rgba(225,29,72,0.85); margin-left:4px;"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltDescBody" style="flex:1 1 auto; overflow:auto; padding:14px;">'+corpo+'</div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltDescHead'));
    if(typeof oltResizify==='function') oltResizify(win, 380, 280);
}
// Editor do TIPO (ícone "+" na coluna Tipo) — caixinha p/ escolher ONU (Bridge) / ONT (Router).
function oltEditarTipo(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    if(!o.serial){ alert('Sem serial para gravar o tipo.'); return; }
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var cur=_oltTipoDe(o);
    var opt=function(v,lbl,cor){ return '<button type="button" onclick="oltTipoSalvar(\''+_oltEsc(fsp)+'\',\''+_oltEsc(id)+'\',\''+v+'\')" style="cursor:pointer; padding:12px 10px; border-radius:9px; border:2px solid '+(cur===v?cor:OLTC.line)+'; background:'+(cur===v?cor+'22':'transparent')+'; color:'+cor+'; font-weight:800; font-size:13px; flex:1 1 auto;">'+lbl+(cur===v?' <i class="fa-solid fa-check"></i>':'')+'</button>'; };
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,360px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:4px;"><i class="fa-solid fa-diagram-project" style="color:'+OLTC.acc+';"></i> Tipo da ONU</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:12px;">'+_oltEsc(_oltNomeDe(o)||o.serial)+' — escolha o modo (salva no banco local, vale em toda a página).</div>'+
        '<div style="display:flex; gap:10px;">'+opt('ONU','ONU · Bridge',OLTC.acc)+opt('ONT','ONT · Router',OLTC.vio)+'</div>'+
        '<div style="text-align:right; margin-top:12px;"><button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Fechar</button></div>'+
    '</div>';
    document.body.appendChild(ov);
}
function oltTipoSalvar(fsp,id,tipo){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    var sn=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    window._oltCadastro=window._oltCadastro||{}; window._oltCadastro[sn]=window._oltCadastro[sn]||{}; window._oltCadastro[sn].tipo=tipo;
    var okKey=fsp+'|'+id; window._oltTipoOk=window._oltTipoOk||{}; window._oltTipoOk[okKey]=Date.now();
    oltRenderLista(); _oltResumoRefresh();
    setTimeout(function(){ if(window._oltTipoOk) delete window._oltTipoOk[okKey]; if(oltGerenciadorAberto()) oltRenderLista(); }, 3000);
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial)+'&campo=tipo&valor='+tipo})
      .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); }).catch(function(){});
}
// Avisa UMA vez se a OLT nao conseguiu gravar o cadastro em disco (permissao da pasta cache_trafego).
function _oltAvisaGravacao(d){
    if(d && d.saved===false && !window._oltCadWarned){ window._oltCadWarned=true;
        alert('A alteração apareceu na tela mas NÃO foi gravada no arquivo (cache_trafego/olt_cadastro.json sem permissão de escrita) — por isso ela some ao recarregar.\n\nDê permissão de escrita na pasta cache_trafego do addon (ex.: chown www-data / chmod 775).'); }
}
function _oltModeloTipo(m){
    var k=String(m||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
    if(!k) return '';
    if(OLT_MODELO_TIPO[k]) return OLT_MODELO_TIPO[k];            // tabela do cliente (prioridade)
    if(/^FIBERLINK1\d\d/.test(k)) return 'ONU';                // 100/101 = bridge
    if(/^FIBERLINK\d/.test(k)) return 'ONT';                    // 410/411/501(Rev2)… = router (501 é ONT — provedor, 23/09/2026)
    if(/^MONUV\d/.test(k)) return 'ONT';                        // Maxprint V112/V122… (Wi-Fi) = router
    if(/EG8|HG824|HG814|HG831/.test(k)) return 'ONT';           // heurística: roteadores comuns
    if(/MONU|MAXFIBER|^R\d|^ONU|310M/.test(k)) return 'ONU';    // heurística: bridge comuns
    return '';
}
// Tipo final de uma ONU: PELO MODELO (tabela) e, se o modelo não estiver na tabela,
// cai no que veio do service-profile da OLT (o.tipo).
function _oltTipoDe(o){ if(!o) return ''; var c=_oltCadDe(o.serial); if(c&&c.tipo) return String(c.tipo).toUpperCase();
    // Tipo forçado pelo operador na tela "Perfis ONU/ONT" (por MODELO) vence a detecção automática.
    var mi=(typeof _oltModeloInfo==='function')?_oltModeloInfo(o.modelo):null; if(mi&&mi.tipo) return String(mi.tipo).toUpperCase();
    var t=_oltModeloTipo(o.modelo); if(t) return t; return (o.tipo||'').toUpperCase(); }
// Nome de exibição do modelo (cadastrado na tela de Perfis); cai no modelo bruto se não houver.
function _oltModeloNome(mod){ var mi=(typeof _oltModeloInfo==='function')?_oltModeloInfo(mod):null; return (mi&&mi.nome)?mi.nome:(mod||''); }
// Inverte Bridge<->Router SÓ na exibição (override local por SN, no banco olt_cadastro).
function oltInverterTipo(fsp,id){
    var o=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===fsp && (''+x.id)===(''+id)) o=x; }); if(!o) return;
    if(!o.serial){ alert('Sem serial para gravar o tipo.'); return; }
    var atual=_oltTipoDe(o); var novo=(atual==='ONU')?'ONT':'ONU';
    var sn=String(o.serial).toUpperCase().replace(/[^0-9A-Z]/g,'');
    window._oltCadastro=window._oltCadastro||{}; window._oltCadastro[sn]=window._oltCadastro[sn]||{}; window._oltCadastro[sn].tipo=novo;
    var okKey=fsp+'|'+id; window._oltTipoOk=window._oltTipoOk||{}; window._oltTipoOk[okKey]=Date.now(); // ✓ por 3s
    oltRenderLista();
    setTimeout(function(){ if(window._oltTipoOk) delete window._oltTipoOk[okKey]; if(oltGerenciadorAberto()) oltRenderLista(); }, 3000);
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial)+'&campo=tipo&valor='+novo}).catch(function(){});
}
function _oltNum(v){ var m=String(v||'').match(/-?\d+(?:\.\d+)?/); return m?parseFloat(m[0]):null; }
function _oltRxNum(o){ return _oltNum(o&&o.rx); }
// Classifica pelo PIOR (mais negativo) entre o Rx da ONU e o Rx da OLT (upstream).
// (Todo sinal vem da OLT — SmartOLT saiu — então basta ter rx.)
function _oltSinalClasse(o){ if(!o) return '';
    if((o.status||'').toLowerCase().indexOf('online')<0) return ''; // offline não tem luz: NÃO classifica nem conta (o rx exibido é o ÚLTIMO)
    var a=_oltNum(o.rx), b=_oltNum(o.rx_olt); var vals=[]; if(a!=null)vals.push(a); if(b!=null)vals.push(b);
    if(!vals.length) return ''; var pior=Math.min.apply(null, vals);
    return (pior>=_oltLimBase(o))?'bom':'ruim'; }
// COR PADRÃO do sinal — REFERÊNCIA = o sinal que VOLTA (Rx OLT). Verde OK, âmbar atenção (<= -28 dBm),
// vermelho ruim (<= -29,1 dBm). null se não for número. Use _oltCorSinalDe(o) p/ pegar do Rx OLT da ONU.
function _oltCorSinal(v, base){ var n=(typeof v==='number')?v:parseFloat(String(v==null?'':v).replace(/[^0-9.\-]/g,'')); if(isNaN(n)) return null; var b=(base==null)?_oltLimBase(null):base; var vm=(b===OLT_RX_LIMITE)?-29.1:(b+0.3), am=(b===OLT_RX_LIMITE)?-28:(b+1.4); return (n<=vm?OLTC.redf:(n<=am?OLTC.amb:OLTC.grn)); }
// Cor do sinal DA ONU pela REFERÊNCIA correta: o Rx OLT (retorno). Só cai no Rx ONU se não houver retorno.
function _oltCorSinalDe(o){ if(!o) return null; var b=_oltLimBase(o); var c=_oltCorSinal(o.rx_olt,b); return (c!=null)?c:_oltCorSinal(o.rx,b); }
// YYYY-MM-DD -> dd/mm/aaaa (mantém o texto se não casar).
function _oltDMA(s){ var m=String(s||'').match(/(\d{4})-(\d{2})-(\d{2})/); return m?(m[3]+'/'+m[2]+'/'+m[1]):String(s||''); }
// Data de ATIVAÇÃO (dia/mês/ano): usa a data REAL de autorização (window._oltAutoriz[serial].data, gravada
// pelo app c/ backfill); se não houver, cai na 1ª vez que a ONU apareceu (window._oltVisto). '' se nada.
// Chave do "visto pela 1ª vez": o SERIAL (o aparelho), não a porta. Sem serial, cai na posição.
function _oltVistoKey(o){ var s=String((o&&o.serial)||'').toUpperCase().replace(/[^0-9A-Z]/g,''); return s ? ('sn:'+s) : (((o&&o.fsp)||'')+'|'+((o&&o.id)||'')); }
function _oltDataAtivacao(o){ try{ var k=String((o&&o.serial)||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var au=(window._oltAutoriz||{})[k]; if(au&&au.data) return _oltDMA(au.data);
    var v=(window._oltVisto||{})[_oltVistoKey(o)]; if(!v) return ''; var d=new Date(v); var p=function(x){return (x<10?'0':'')+x;}; return p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear(); }catch(e){ return ''; } }
// Timestamp de ativação (p/ ordenar "Recentes"): data real de autorização, senão a 1ª vez vista.
function _oltTsAtivacao(o){ try{ var k=String((o&&o.serial)||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var au=(window._oltAutoriz||{})[k]; if(au&&au.data){ var t=Date.parse(au.data); if(!isNaN(t)) return t; } return (window._oltVisto||{})[_oltVistoKey(o)]||0; }catch(e){ return 0; } }

// Ilustração vetorial (discreta) de um chassi OLT GPON p/ a tarja do topo.
// SVG próprio (sem marca/foto externa) — traço branco sobre o azul do cabeçalho.
function _oltChassiSVG(){
    return '<svg width="52" height="40" viewBox="0 0 52 40" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex:0 0 auto; opacity:.95;" aria-hidden="true">'+
        // orelhas de rack
        '<rect x="1" y="6" width="3" height="28" rx="1" fill="#ffffff" opacity=".55"/>'+
        '<rect x="48" y="6" width="3" height="28" rx="1" fill="#ffffff" opacity=".55"/>'+
        // corpo do chassi
        '<rect x="5" y="4" width="42" height="32" rx="3" fill="#ffffff" opacity=".10" stroke="#ffffff" stroke-width="1.4"/>'+
        // placas (cards verticais)
        '<g stroke="#ffffff" stroke-width="1" opacity=".7">'+
          '<line x1="12" y1="7" x2="12" y2="33"/><line x1="17" y1="7" x2="17" y2="33"/>'+
          '<line x1="22" y1="7" x2="22" y2="33"/><line x1="27" y1="7" x2="27" y2="33"/>'+
          '<line x1="32" y1="7" x2="32" y2="33"/><line x1="37" y1="7" x2="37" y2="33"/>'+
          '<line x1="42" y1="7" x2="42" y2="33"/>'+
        '</g>'+
        // LEDs de status
        '<circle cx="8.5" cy="9" r="1.5" fill="#34d399"><animate attributeName="opacity" values="1;.25;1" dur="2.2s" repeatCount="indefinite"/></circle>'+
        '<circle cx="8.5" cy="14" r="1.5" fill="#fbbf24" opacity=".85"/>'+
        // portas (base)
        '<g fill="#ffffff" opacity=".5"><rect x="9" y="29" width="4" height="3" rx="0.6"/><rect x="14" y="29" width="4" height="3" rx="0.6"/><rect x="19" y="29" width="4" height="3" rx="0.6"/></g>'+
    '</svg>';
}
// ===== FILA DE REQUISIÇÕES À OLT: só UMA conexão Telnet por vez =====
// A MA5683T tem poucas sessões VTY; disparar varredura + sinal + modelo + estado
// + autofind + sync ao mesmo tempo empilha sessões e trava tudo. Aqui serializamos
// TODA chamada que fala com a OLT (uma de cada vez, na ordem em que chegam).
// Fila com PRIORIDADE: ações do usuário (prio=true) furam a fila e rodam antes do
// carregamento de fundo (modelo/uptime/sinal). Assim "Autorizar/Gerenciar" respondem
// na hora, sem esperar a varredura de fundo. Uma conexão à OLT por vez.
window._oltJobs = window._oltJobs || [];
window._oltWorking = window._oltWorking || false;
// ms (opcional): limite próprio do job na fila (padrão 25s). A leitura de PLACA inteira precisa de
// mais: placa cheia + OLT ocupada passa de 25s e a tela marcava "Placa X não respondeu" sempre.
function oltFetch(url, opts, prio, ms){
    return new Promise(function(resolve, reject){
        var job={url:url, opts:opts, resolve:resolve, reject:reject, ms:ms};
        if(prio) window._oltJobs.unshift(job); else window._oltJobs.push(job);
        _oltDrain();
    });
}
// Marca/limpa o estado "OLT ainda não configurada" a partir da resposta do backend.
// Usado para a tela orientar a configurar em vez de mandar varrer uma OLT inexistente.
function _oltMarcarConfig(d){
    if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return d;
    var nc = !!(d && (d.nao_configurado || d.status === 'nao_configurado'));
    if (nc !== !!window._oltNaoConfigurado) { window._oltNaoConfigurado = nc; }
    return d;
}
function _oltDrain(){
    if(window._oltWorking) return;
    var job=window._oltJobs.shift();
    if(!job) return;
    window._oltWorking=true;
    // WATCHDOG: nenhuma requisição pode travar a FILA INTEIRA. Se não responder em 25s, aborta e libera
    // a próxima (antes, um request pendurado deixava TODOS os gráficos/telas "girando pra sempre").
    var ctrl=(typeof AbortController!=='undefined')?new AbortController():null;
    var opts=job.opts||{}; if(ctrl){ opts=Object.assign({}, opts, {signal:ctrl.signal}); }
    var pronto=false;
    var to=setTimeout(function(){ if(!pronto && ctrl){ try{ctrl.abort();}catch(e){} } }, job.ms||25000);
    fetch(job.url, opts).then(function(r){ job.resolve(r); }, function(e){ job.reject(e); })
        .then(function(){ pronto=true; clearTimeout(to); window._oltWorking=false; _oltDrain(); },
              function(){ pronto=true; clearTimeout(to); window._oltWorking=false; _oltDrain(); });
}
// Fetch DIRETO (fora da fila serial) com timeout — p/ leituras LEVES de cache (gráficos/histórico) que
// NÃO podem esperar atrás de uma varredura pesada. Abre na hora, independente do que a fila está fazendo.
function _oltFetchDireto(url, ms){
    var ctrl=(typeof AbortController!=='undefined')?new AbortController():null;
    var to=ctrl?setTimeout(function(){ try{ctrl.abort();}catch(e){} }, ms||15000):null;
    return fetch(url, ctrl?{signal:ctrl.signal}:undefined).then(function(r){ if(to)clearTimeout(to); return r; },
        function(e){ if(to)clearTimeout(to); throw e; });
}
// Token de sessão do Gerenciador: incrementa ao abrir; loops de fundo param quando muda/fecha.
window._oltSessao = window._oltSessao || 0;
function _oltAtivo(tok){ return oltGerenciadorAberto() && tok===window._oltSessao; }

function _oltEsc(s){ return (s==null?'':String(s)).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function _oltSpinner(msg){ return '<div style="text-align:center; padding:34px; color:'+OLTC.mut+';"><i class="fa-solid fa-spinner fa-spin" style="font-size:22px; color:'+OLTC.acc+';"></i><br><br>'+_oltEsc(msg)+'</div>'; }
function _oltHue(s){ s=(s||''); var h=0; for(var i=0;i<s.length;i++){ h=(h*31 + s.charCodeAt(i))%360; } return h; }

// ---------- Janela própria (overlay) — sizing + min/max/fechar ----------
function _oltCtrl(cor){ return 'cursor:pointer; width:34px; height:31px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+(cor||OLTC.txt)+'; font-size:15px; display:inline-flex; align-items:center; justify-content:center;'; }
function oltGetOverlay(){
    var ov=document.getElementById('oltOverlay');
    if(ov) return ov;
    ov=document.createElement('div');
    ov.id='oltOverlay';
    // Fundo TRANSPARENTE e "clicavel atraves" -> dá pra usar a pagina principal
    // com o Gerenciador aberto. Só a janela captura cliques; fecha só no (x).
    ov.style.cssText='position:fixed; inset:0; z-index:99999; display:none; align-items:center; justify-content:center; background:transparent; pointer-events:none;';
    ov.innerHTML =
      '<div id="oltWin" data-max="0" data-min="0" style="pointer-events:auto; display:flex; flex-direction:column; width:min(96vw,1150px); height:88vh; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.bg2+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.65); overflow:hidden;">'+
        '<div id="oltWinHead" style="flex:0 0 auto; display:flex; align-items:center; gap:9px; padding:12px 15px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.28), inset 0 -3px 8px rgba(0,0,0,.18); border-bottom:4px solid #ffffff; cursor:move;">'+
          (WS_LOGO_OLT ? (window.WS_LOGO_URL ? '<a href="'+_oltEsc(window.WS_LOGO_URL)+'" target="_blank" rel="noopener" title="'+_oltEsc(String(window.WS_LOGO_URL).replace(/^https?:\/\//i,''))+'" onmousedown="event.stopPropagation()" style="flex:0 0 auto; display:inline-flex; line-height:0;">' : '<span style="flex:0 0 auto; display:inline-flex; line-height:0;">')+'<img id="oltHdrLogo" src="'+WS_LOGO_OLT+'" alt="Logo" style="height:64px; margin:-9px 0; max-width:272px; object-fit:contain; display:block;">'+(window.WS_LOGO_URL ? '</a>' : '</span>') : _oltChassiSVG())+
          // Título com a MESMA identidade visual do título da página principal
          // (peso 700, letter-spacing .5px, branco; subtítulo em cinza var(--text-secondary)).
          '<div class="oltWinTit" style="flex:1 1 auto; min-width:0;"><div id="oltWinTitle" style="font-weight:700; font-size:16px; letter-spacing:.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:#ffffff;">Gerenciador OLT Huawei</div><div id="oltWinSub" style="font-size:11px; color:rgba(255,255,255,0.88);">Monitoramento GPON</div><div id="oltSelBox" onmousedown="event.stopPropagation()" style="display:none; align-items:center; gap:6px; margin-top:4px;"></div></div>'+
          '<div id="oltWinValida" title="Passe o mouse para ver a hora da informação + contagem até a próxima sincronização" onmouseenter="var i=document.getElementById(\'oltWinValidaInfo\'); if(i) i.style.display=\'inline-flex\';" onmouseleave="var i=document.getElementById(\'oltWinValidaInfo\'); if(i) i.style.display=\'none\';" style="flex:0 0 auto; display:none; align-items:center; gap:8px; margin-right:4px; padding:5px 11px; border-radius:20px; background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.22); color:#eaf3fb; font-size:11px; font-weight:700; white-space:nowrap; cursor:pointer;"><i class="fa-solid fa-eye" style="color:#7ee0a8; font-size:18px;"></i><span id="oltWinValidaInfo" style="display:none; align-items:center; gap:6px;"><i class="fa-regular fa-clock" style="color:#7ee0a8;"></i> <span id="oltWinValidaTxt">—</span> <span style="opacity:.5;">·</span> <i class="fa-solid fa-arrows-rotate" style="color:#7ee0a8; font-size:10px;"></i> <span id="oltWinUptime" title="Contagem regressiva até a próxima sincronização">sincroniza em 5s</span></span></div>'+
          _oltBarraUsuario()+
          '<button onclick="oltTrocarTema()" title="Alternar tema Claro/Escuro" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9);"><i class="fa-solid '+(window._oltTemaAtual==='escuro'?'fa-moon':'fa-sun')+'"></i></button>'+
          '<button onclick="oltMin()" title="Minimizar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9);"><i class="fa-solid fa-minus"></i></button>'+
          '<button onclick="oltMax()" title="Maximizar / Restaurar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9);"><i class="fa-solid fa-expand"></i></button>'+
          // Na página autônoma este botão é o SAIR (ícone de saída, encerra a
          // sessão e vai ao login). No modo integrado ele fecha o gerenciador (X).
          '<button onclick="'+(window.WS_OLT_STANDALONE?'wsSair()':'oltFechar()')+'" title="'+(window.WS_OLT_STANDALONE?'Sair do sistema':'Fechar')+'" style="'+_oltCtrl('#ffffff')+' border:2px solid #ffffff; background:#7a1010; color:#ffffff; font-size:16px; box-shadow:0 1px 3px rgba(0,0,0,.3);"><i class="fa-solid '+(window.WS_OLT_STANDALONE?'fa-right-from-bracket':'fa-xmark')+'"></i></button>'+
        '</div>'+
        '<div id="oltWinBody" style="flex:1 1 auto; overflow:auto; padding:14px; -webkit-overflow-scrolling:touch;"></div>'+
        '<div id="oltWinFoot" style="flex:0 0 auto; padding:9px 14px; background:'+OLTC.bg2+'; border-top:1px solid '+OLTC.line+';"></div>'+
      '</div>';
    document.body.appendChild(ov);
    var _bd=document.getElementById('oltWinBody');
    if(_bd){ _bd.addEventListener('scroll', function(){ try{ sessionStorage.setItem('oltScroll', _bd.scrollTop); }catch(e){} }); }
    var w=document.getElementById('oltWin'), hd=document.getElementById('oltWinHead');
    if(w && hd){ hd.addEventListener('mousedown', function(e){ if(e.target.closest('button')) return; if(w.getAttribute('data-max')==='1') return; e.preventDefault(); var r=w.getBoundingClientRect(); w.style.margin='0'; w.style.position='fixed'; var ox=r.left, oy=r.top, sx=e.clientX, sy=e.clientY; document.getElementById('oltOverlay').style.alignItems='flex-start'; document.getElementById('oltOverlay').style.justifyContent='flex-start'; w.style.left=ox+'px'; w.style.top=oy+'px'; function mv(ev){ w.style.left=(ox+ev.clientX-sx)+'px'; w.style.top=Math.max(0,(oy+ev.clientY-sy))+'px'; } function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); } document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up); }); }
    return ov;
}
function oltAbrir(titulo, sub){ var ov=oltGetOverlay(); ov.style.display='flex'; document.body.style.overflow='hidden'; document.documentElement.classList.add('olt-aberto'); /* obs4: sem barra de rolagem da página */ var pill=document.getElementById('oltPill'); if(pill) pill.style.display='none'; document.getElementById('oltWinBody').style.display='block'; if(titulo!=null) document.getElementById('oltWinTitle').textContent=titulo; if(sub!=null) document.getElementById('oltWinSub').textContent=sub; if(!window._oltSelOk){ window._oltSelOk=true; try{ oltSeletorCarregar(); }catch(e){} } }
function oltFechar(){ var ov=document.getElementById('oltOverlay'); if(ov) ov.style.display='none';
    // PÁGINA AUTÔNOMA (olt.php): fechar o gerenciador reabre a tela inicial da OLT
    // em vez de deixar uma página vazia. No modo integrado, volta para o Radius.
    /* Saindo do sistema: NÃO recarregar aqui — o logout é quem redireciona. */
    if(window.WS_OLT_STANDALONE && !window.WS_SAINDO){ setTimeout(function(){ if(!window.WS_SAINDO) location.reload(); }, 80); }
    document.body.style.overflow=''; document.documentElement.classList.remove('olt-aberto'); /* libera a rolagem da página */ var _al=document.getElementById('oltAlertaPon'); if(_al) _al.remove(); var pill=document.getElementById('oltPill'); if(pill) pill.style.display='none'; if(window._oltSyncTimer){ clearInterval(window._oltSyncTimer); window._oltSyncTimer=null; } if(window._oltPendTimer){ clearInterval(window._oltPendTimer); window._oltPendTimer=null; } try{ sessionStorage.removeItem('oltAberto'); }catch(e){} }
// F5 (30/10/2026): as telas abertas pelo MENU (Gerenciar Uplink, VLANs, Placas, gráficos...) também voltam: guarda a lista em sessionStorage 'oltTelas'
// (atualizada sempre que uma janela abre/fecha) e reabre cada uma depois do Gerenciador. Só aceita nome de função do próprio menu: nome(...).
function _oltB64(t){ try{ return btoa(t); }catch(e){ return ''; } }
function _oltTelaLembrar(b64){ try{ window._oltTelaPend=atob(b64); }catch(e){ window._oltTelaPend=''; } }
function _oltTelasSalvar(){ try{ var fns=[]; document.querySelectorAll('.oltMSWin').forEach(function(w){ var f=w.getAttribute('data-fn'); if(f && fns.indexOf(f)<0) fns.push(f); }); sessionStorage.setItem('oltTelas', JSON.stringify(fns)); }catch(e){} }
function _oltTelasReabrir(){ var fns=[]; try{ fns=JSON.parse(sessionStorage.getItem('oltTelas')||'[]'); }catch(e){ fns=[]; }
    fns=fns.filter(function(f){ return /^[A-Za-z_][A-Za-z0-9_]*\([^)]*\)$/.test(f) && typeof window[f.split('(')[0]]==='function'; });
    window._oltRestaurandoTelas=true;
    fns.forEach(function(f,i){ setTimeout(function(){ try{ window._oltTelaPend=f; window[f.split('(')[0]](); }catch(e){} }, i*400); });
    setTimeout(function(){ window._oltRestaurandoTelas=false; _oltTelasSalvar(); }, fns.length*400+1200); }
(function(){ try{ var pre=sessionStorage.getItem('oltTelas'); if(pre && pre!=='[]'){ window._oltRestaurandoTelas=true;   // F5: não apaga a lista guardada antes de reabrir as telas
        var t0=Date.now(), iv=setInterval(function(){ var pronto=document.getElementById('oltWinBody') && window._oltLista; if(pronto){ clearInterval(iv); setTimeout(_oltTelasReabrir, 1200); } else if(Date.now()-t0>40000){ clearInterval(iv); window._oltRestaurandoTelas=false; } }, 500); } }catch(e){}   // espera o Gerenciador abrir (auto-conexão ou reabertura) e a lista carregar
    var ini=function(){ try{ new MutationObserver(function(){ if(!window._oltRestaurandoTelas) _oltTelasSalvar(); }).observe(document.body,{childList:true}); }catch(e){} };
    if(document.body) ini(); else document.addEventListener('DOMContentLoaded', ini); })();
// F5: reabre o Gerenciador OLT automaticamente se estava aberto (não volta à principal)
function _oltReabrirSeAberto(){ try{ if(sessionStorage.getItem('oltAberto')==='1' && typeof abrirOltHuawei==='function'){ window._oltRestaurar=true; setTimeout(abrirOltHuawei, 250);
    setTimeout(function(){ var bd=document.getElementById('oltWinBody'); if(bd){ try{ bd.scrollTop=parseInt(sessionStorage.getItem('oltScroll')||'0',10)||0; }catch(e){} } }, 1600);
} }catch(e){} }
try { if(document.readyState==='complete'){ _oltReabrirSeAberto(); } else { window.addEventListener('load', _oltReabrirSeAberto); } } catch(e){}
// OBS1: clicar em QUALQUER janela flutuante a traz para a frente das demais.
if(!window._oltFrenteBound){ window._oltFrenteBound=true;
    document.addEventListener('mousedown', function(e){
        var sel='.oltMSWin, [id^="oltWin_"], [id^="modalGraficoRT_"], [id^="log_modal_"], #oltIntWin, #oltResumoWin, #oltPonWin, #oltApWin, #oltDescWin, #oltRelWin, #oltDocWin, #oltCxBox, #oltNtfBox';
        var w=e.target && e.target.closest ? e.target.closest(sel) : null;
        if(w){ window._oltMSZ=(window._oltMSZ||2147483000)+1; w.style.zIndex=window._oltMSZ; }
    }, true);
}

// ===== DESACOPLAMENTO F5: quando o Gerenciador está ABERTO, F5/Ctrl+R atualiza
// SÓ o Gerenciador (re-sincroniza), sem recarregar a página principal. =====
function oltGerenciadorAberto(){ var ov=document.getElementById('oltOverlay'); return !!(ov && ov.style.display!=='none'); }
document.addEventListener('keydown', function(e){
    var k=(e.key||'').toLowerCase();
    var eF5=(e.key==='F5' || e.keyCode===116);
    var eCtrlR=((e.ctrlKey||e.metaKey) && (k==='r'));
    if((eF5||eCtrlR) && oltGerenciadorAberto()){
        e.preventDefault(); e.stopPropagation();
        oltSincronizarGerenciador();   // atualiza só o Gerenciador
    }
}, true);
// Re-sincroniza o Gerenciador (nova varredura em modo merge) preservando estado
function oltSincronizarGerenciador(){
    window._oltEstadoFeito=false;
    var ws=document.getElementById('oltWinSub'); if(ws){ ws.insertAdjacentHTML('beforeend',' · <span id="olt_sync_flag"><i class="fa-solid fa-rotate fa-spin"></i> sincronizando…</span>'); }
    oltVarrerSlots(0);
    oltCheckPendentes();
}
// Toast simples (aviso flutuante que some sozinho) — feedback visível de ações rápidas.
function _oltToast(msg){
    var t=document.getElementById('oltToast');
    if(!t){ t=document.createElement('div'); t.id='oltToast'; document.body.appendChild(t); }
    t.innerHTML=msg;
    // Fundo ESCURO fixo (não usa OLTC.ink, que no tema escuro é branco -> ficava invisível).
    t.style.cssText='position:fixed; bottom:22px; left:50%; transform:translateX(-50%); z-index:2147483646; background:#1f2733; color:#ffffff; border:1px solid rgba(255,255,255,.18); padding:11px 18px; border-radius:24px; font-size:13px; font-weight:700; box-shadow:0 8px 26px rgba(0,0,0,.5); opacity:0; transition:opacity .2s; pointer-events:none; max-width:90vw; text-align:center;';
    requestAnimationFrame(function(){ t.style.opacity='1'; });
    clearTimeout(window._oltToastT); window._oltToastT=setTimeout(function(){ t.style.opacity='0'; }, 2400);
}
// Copia um texto pra área de transferência (clipboard) com aviso. Usado no serial da ONU (clicar=copiar).
function _oltCopiar(txt){
    txt=String(txt||''); var ok=function(){ try{ _oltToast('<i class="fa-solid fa-check"></i> Copiado: '+_oltEsc(txt)); }catch(e){} };
    var fb=function(){ try{ var ta=document.createElement('textarea'); ta.value=txt; ta.style.cssText='position:fixed;opacity:0;left:-9999px;'; document.body.appendChild(ta); ta.focus(); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); ok(); }catch(e){} };
    if(navigator.clipboard&&navigator.clipboard.writeText){ navigator.clipboard.writeText(txt).then(ok).catch(fb); } else { fb(); }
}
// F5 / Ctrl+R (com o Gerenciador ABERTO) => ATUALIZA os dados SEM recarregar a página (mantém as
// janelas abertas), com aviso visível. Ctrl+Shift+R continua sendo recarga REAL (pega código novo).
// Com o Gerenciador fechado, o F5 recarrega normal (padrão do navegador).
if(!window._oltF5Hook){ window._oltF5Hook=1;
    window.addEventListener('keydown', function(e){
        var isF5=(e.key==='F5' && !e.ctrlKey && !e.metaKey && !e.shiftKey);
        var isCtrlR=((e.key==='r'||e.key==='R') && (e.ctrlKey||e.metaKey) && !e.shiftKey);
        if((isF5||isCtrlR) && typeof oltGerenciadorAberto==='function' && oltGerenciadorAberto()){
            e.preventDefault();
            try{ _oltToast('<i class="fa-solid fa-rotate fa-spin"></i> Atualizando dados — janelas mantidas'); oltSincronizarGerenciador(); }catch(err){}
        }
    }, true);
}
function oltMax(){ var w=document.getElementById('oltWin'); var ov=document.getElementById('oltOverlay'); var m=w.getAttribute('data-max')==='1';
    if(m){ w.setAttribute('data-max','0'); w.style.position=''; w.style.left=''; w.style.top=''; w.style.width='min(96vw,1150px)'; w.style.height='88vh'; w.style.maxHeight=''; w.style.borderRadius='14px'; if(ov){ ov.style.alignItems='center'; ov.style.justifyContent='center'; } }
    else { w.setAttribute('data-max','1'); w.style.position='fixed'; w.style.left='0'; w.style.top='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; if(ov){ ov.style.alignItems='flex-start'; ov.style.justifyContent='flex-start'; } }
}
// Minimizar: esconde a janela e mostra uma pílula flutuante para restaurar.
function oltMin(){
    var ov=document.getElementById('oltOverlay'); if(ov) ov.style.display='none';
    document.body.style.overflow=''; document.documentElement.classList.remove('olt-aberto'); // minimizado -> a página volta a rolar normal
    var _al=document.getElementById('oltAlertaPon'); if(_al) _al.remove();
    var pill=document.getElementById('oltPill');
    if(!pill){
        pill=document.createElement('button'); pill.id='oltPill'; pill.className='oltMinPill';
        pill.onclick=oltRestaurar;
        pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:99999; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:'+OLTC.amb+'; color:#ffffff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
        pill.innerHTML='<i class="fa-solid fa-diagram-project"></i> OLT Huawei';
        document.body.appendChild(pill);
    }
    pill.style.display='flex'; if(typeof _oltPillsArrumar==='function') _oltPillsArrumar();
}
function oltRestaurar(){ var ov=document.getElementById('oltOverlay'); if(ov) ov.style.display='flex'; document.body.style.overflow='hidden'; document.documentElement.classList.add('olt-aberto'); var pill=document.getElementById('oltPill'); if(pill) pill.style.display='none'; if(typeof _oltPillsArrumar==='function') _oltPillsArrumar(); }
function oltBody(html){ var b=document.getElementById('oltWinBody'); if(b) b.innerHTML=html; }
/* RODAPÉ DA OLT: à esquerda o que a tela manda (html); à direita, SEPARADOS: o PROVEDOR (© ano Wellnet Telecom) e o
   BLOCO do sistema ([selo] WellSystem · Versão Master Wellsystem vDD.MM.AA — hora/arquivos ao passar o mouse). */
function oltFooter(html){ var f=document.getElementById('oltWinFoot'); if(!f) return;
    var V=window.WS_OLT_VER||{};
    // MESMOS valores do rodapé do ERP (ws_footer_bar + .ws-rodape-* do css/wellsystem.css): fonte 10px em tudo, 800 no bloco,
    // "Well" + "System" em degradê, vermelho fixo #cf1f1f na versão, © em versalete no centro.
    var ano=new Date().getFullYear(), esc=(window._oltTemaAtual==='escuro');
    var grad=esc?'linear-gradient(135deg,#e0687a 0%,#c94f63 55%,#eb8496 100%)':'linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)';
    var prov='<span title="© '+ano+' Wellnet Telecom — Todos os direitos reservados" style="white-space:nowrap; font-size:10px; font-weight:600; font-variant:small-caps; letter-spacing:1.2px; color:'+OLTC.mut+';">© '+ano+' Wellnet Telecom</span>';
    var bloco='<span title="WellSystem — ERP para provedores de internet" style="display:inline-flex; align-items:center; gap:6px; white-space:nowrap; padding:3px 10px; border:1px solid '+OLTC.line+'; border-radius:20px; font-size:10px; font-weight:800; letter-spacing:.2px; color:'+OLTC.ink+';">'
        +(V.selo?('<a href="'+_oltEsc(V.dono||'https://wellnet.com.br')+'" target="_blank" rel="noopener" title="'+_oltEsc(String(V.dono||'https://wellnet.com.br').replace(/^https?:\/\//i,''))+'" style="display:inline-flex; line-height:0;"><img src="'+_oltEsc(V.selo)+'" alt="WellSystem" style="width:20px; height:20px; object-fit:contain; border-radius:4px; box-shadow:0 1px 4px rgba(0,0,0,.25);"></a>'):'')
        +'<b style="font-weight:800; color:'+OLTC.ink+';">Well<span style="background:'+grad+'; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;">System</span></b>'
        +'<i style="opacity:.5; font-style:normal;">·</i><b style="color:#cf1f1f; font-weight:800;">Versão Master Wellsystem</b>'
        +(V.txt?('<span title="'+_oltEsc(V.tip||'')+'" style="font-size:10px; opacity:.8; font-weight:700; cursor:help; background:'+grad+'; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;">'+_oltEsc(V.txt)+'</span>'):'')+'</span>';
    // 3 COLUNAS iguais (igual ao rodapé do ERP): bloco do sistema | PROVEDOR no centro exato | avisos da tela
    if(!document.getElementById('oltFootCss')){ var st=document.createElement('style'); st.id='oltFootCss';
        st.textContent='.oltFootGrid{display:grid;grid-template-columns:minmax(max-content,1fr) auto minmax(0,1fr);align-items:center;gap:6px 14px}.oltFootGrid>.oltFootB{justify-self:start}.oltFootGrid>.oltFootP{justify-self:center;text-align:center}.oltFootGrid>.oltFootS{justify-self:end;text-align:right;min-width:0}@media(max-width:1100px){.oltFootGrid{display:flex;flex-wrap:wrap;justify-content:space-between}.oltFootGrid>.oltFootS{margin-left:auto}}@media(max-width:760px){.oltFootGrid{justify-content:center}.oltFootGrid>.oltFootS{margin-left:0;flex:1 1 100%}.oltFootGrid>*{text-align:center!important}}@media(max-width:520px){.oltFootGrid>.oltFootP{display:none}}';
        document.head.appendChild(st); }
    f.innerHTML='<div class="oltFootGrid" style="font-size:10px; color:'+OLTC.mut+'; letter-spacing:.3px;">'
        +'<div class="oltFootB">'+bloco+'</div><div class="oltFootP">'+prov+'</div><div class="oltFootS">'+(html||'')+'</div></div>';
    f.style.display='block'; window._oltFoot=true; }

// ---------- Lista geral: varredura progressiva slot a slot ----------
function abrirOltHuawei(){
    if(window.WS_SAINDO) return;   // saindo do sistema: não reabrir
    window._oltSessao=(window._oltSessao||0)+1; // nova sessão: invalida loops de fundo antigos
    oltAbrir('Wellsystem OLT — Monitoramento GPON', '10.100.0.2 · carregando...');
    oltJanelaTamanho('min(96vw,1150px)','88vh'); // janela ampla para a lista completa
    var _wMax=document.getElementById('oltWin'); if(_wMax && _wMax.getAttribute('data-max')!=='1') oltMax(); // abre MAXIMIZADO
    // Abre SEMPRE limpo (sem filtro/categoria) para nunca "esconder" a lista.
    try { sessionStorage.setItem('oltAberto','1'); } catch(e){}
    if(window._oltRestaurar){ // veio de F5 -> restaura filtro/categoria/pagina/scroll
        try{ window._oltFiltro=sessionStorage.getItem('oltFiltro')||''; window._oltCat=sessionStorage.getItem('oltCat')||''; window._oltPag=parseInt(sessionStorage.getItem('oltPag')||'1',10)||1; }
        catch(e){ window._oltFiltro=''; window._oltCat=''; window._oltPag=1; }
        window._oltRestaurar=false;
    } else { window._oltFiltro=''; window._oltCat=''; window._oltPag=1; }
    window._loginToIp=null; if(!window._oltPorPag) window._oltPorPag=50;
    // NÃO sondar a OLT só para exibir status: cada teste abre uma sessão Telnet e
    // a MA5683T tem poucas VTY — a sondagem disputava sessão com a varredura e
    // derrubava as duas. O status agora vem do RESULTADO das operações reais.
    window._oltAbertoEm = Date.now(); // uptime ao vivo da ressincronização
    oltFooter(''); oltCarregarStatus(); oltCarregarCadastro(); oltCarregarClientesDB(); _oltCarregarMeta(); _oltCorrigirGravacao(); _oltPreloadPerfis(); oltCarregarCadUrl(); _oltCarregarPerfisGen(); // banco local + clientes + meta + auto-corrige gravação + perfis prontos
    oltBody(_oltSpinner('Carregando...'));
    // ABERTURA INSTANTÂNEA: mostra TUDO do cache (modelo/sinal/uptime/estado já vêm juntos)
    // e NÃO re-varre no primeiro plano. A atualização acontece só no 5s (segundo plano).
    var _acCache=('AbortController' in window)?new AbortController():null;
    var _toCache=setTimeout(function(){ if(_acCache) _acCache.abort(); }, 20000); // não gira pra sempre
    fetch('olt_huawei.php?acao=cache_get', _acCache?{signal:_acCache.signal}:{})
      .then(function(r){ clearTimeout(_toCache); return r.json(); })
      .then(_oltMarcarConfig)
      .then(function(d){
        if(d&&d.status==='ok'&&d.onus&&d.onus.length){
            window._oltLista=d.onus; window._oltCacheIdade=d.idade;
            _oltMarcarAtualizado(new Date(Date.now() - ((d.idade||0)*1000))); // hora real do dado em cache
            oltRenderLista();                       // instantâneo, com cards/sinal/tipo já do cache
            // preenche só o que porventura faltar (em 2º plano, sem travar)
            oltEnriquecerEstadoOffline(); oltEnriquecerSinal(); oltEnriquecerDetalhe(); oltEnriquecerUptime();
        } else {
            window._oltLista=[]; oltVarrerSlots(0);  // 1ª vez (cache vazio): varre agora
        }
        oltCheckPendentes();
        oltIniciarAlertaPendentes();
        oltIniciarAutoSync();                        // 5s em 2º plano mantém tudo atualizado
      })
      .catch(function(){ clearTimeout(_toCache);
        // Servidor não respondeu (sobrecarga/PHP preso): NÃO dispara varredura nova (evita empilhar)
        // e mostra opção de tentar de novo, em vez de girar pra sempre.
        oltBody('<div style="text-align:center; padding:34px; color:'+OLTC.mut+';"><i class="fa-solid fa-triangle-exclamation" style="font-size:28px; color:'+OLTC.amb+';"></i><br><br>A OLT/servidor não respondeu a tempo.<br><span style="font-size:12px;">Use o diagnóstico abaixo: ele mostra em qual etapa para — rede, Telnet ou login.</span>'+
            '<div style="display:flex; gap:8px; justify-content:center; margin:18px 0 0; flex-wrap:wrap;">'+
              (_oltNivel()>=3 ? '<button onclick="oltConexao()" style="cursor:pointer; padding:10px 18px; border-radius:9px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;"><i class="fa-solid fa-stethoscope"></i> Diagnosticar conexão</button>' : '')+
              '<button onclick="abrirOltHuawei()" style="cursor:pointer; padding:10px 18px; border-radius:9px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+'; font-weight:800;"><i class="fa-solid fa-rotate"></i> Tentar de novo</button>'+
            '</div>'+
            '<div id="oltDiagRapido" style="max-width:520px; margin:18px auto 0; text-align:left;"></div></div>');
        // Diagnóstico automático: já mostra onde parou, sem o operador precisar clicar.
        setTimeout(function(){
            var alvo=document.getElementById('oltDiagRapido'); if(!alvo) return;
            alvo.innerHTML='<div style="text-align:center; font-size:11.5px; color:'+OLTC.mut+';"><i class="fa-solid fa-spinner fa-spin"></i> Verificando a conexão com a OLT…</div>';
            oltFetch('olt_huawei.php?acao=conexao_teste', null, true).then(function(r){return r.json();}).then(function(d){
                if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
                var ok=!!(d&&d.conectado); _oltStatusConexao(ok);
                var linhas=((d&&d.passos)||[]).map(function(p){
                    var c=p.ok?OLTC.grn:OLTC.red;
                    return '<div style="display:flex; gap:8px; align-items:flex-start; padding:6px 0; border-bottom:1px solid '+OLTC.line+'33;">'+
                        '<i class="fa-solid '+(p.ok?'fa-circle-check':'fa-circle-xmark')+'" style="color:'+c+'; margin-top:2px;"></i>'+
                        '<div><b style="color:'+OLTC.ink+'; font-size:11.5px;">'+_oltEsc(p.t)+'</b><div style="font-size:11px; color:'+OLTC.mut+'; line-height:1.5;">'+_oltEsc(p.msg)+'</div></div></div>';
                }).join('');
                alvo.innerHTML='<div style="border:1px solid '+(ok?OLTC.grn:OLTC.red)+'; border-radius:9px; padding:10px 12px; background:'+OLTC.bg2+';">'+
                    '<div style="font-weight:800; color:'+(ok?OLTC.grn:OLTC.red)+'; font-size:12.5px; margin-bottom:6px;">'+(ok?'Conexão OK — a OLT respondeu':'A conexão falhou nesta etapa:')+'</div>'+linhas+'</div>';
            }).catch(function(){ alvo.innerHTML=''; });
        }, 200);
      });
}
// Carrega o SmartOLT (VLAN, tipo ONU/ONT, zona, link) e enriquece a lista por SN
function oltCarregarSmartOLT(){
    if(window._oltSmartMap){ oltEnriquecerSmart(); return; }
    fetch('olt_huawei.php?acao=smartolt_map')
      .then(function(r){ return r.json(); })
      .then(function(d){ if(d&&d.status==='ok'&&d.map){ window._oltSmartMap=d.map; window._oltSmartUrl=d.url||''; oltEnriquecerSmart(); } })
      .catch(function(){});
}
// Apura o estado REAL (LOS x Desativada x Offline) das offline via Telnet (regra #7)
function oltEnriquecerEstadoOffline(){
    if(!window._oltLista || window._oltEstadoFeito || window._oltEstadoRodando) return;
    if(!oltGerenciadorAberto()) return;
    var off=window._oltLista.filter(function(o){ var st=(o.status||'').toLowerCase(); var e=(o.estado||''); return st.indexOf('online')<0 && e!=='los' && e!=='deactivated' && o.fsp && (o.id!==''&&o.id!=null); });
    if(!off.length) return;
    window._oltEstadoRodando=true;
    var itens=off.map(function(o){ return {fsp:o.fsp, id:o.id}; });
    oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=estado_offline&itens='+encodeURIComponent(JSON.stringify(itens))}, true, 90000)
      .then(function(r){ return r.json(); })
      .then(function(d){ window._oltEstadoRodando=false; if(d&&d.status==='ok'&&d.estados){ var mp=d.estados; (window._oltLista||[]).forEach(function(o){ var k=(o.fsp||'')+'|'+(o.id||''); if(mp[k]){ o.estado=mp[k].estado; o.causa=mp[k].causa||''; o._estadoReal=true; } }); window._oltEstadoFeito=true; oltRenderLista(); } })
      .catch(function(){ window._oltEstadoRodando=false; });
}
// IP do cliente pelo SN (login = SN). Usa a lista de clientes da pagina principal
// -> o nome no Gerenciador redireciona igual ao IP (testarEAbrirIP). #7
function _oltMapaClientes(){
    if(window._loginToIp && window._loginToNome && window._loginToUuid) return;
    // MEMÓRIA persistente (localStorage): lembra uuid/ip/nome de clientes já vistos ONLINE,
    // pra que o link do Nome continue funcionando quando o cliente estiver OFFLINE (não vem
    // na página "conectado"). Assim, com o tempo, todas as offline também ganham link.
    var mem={}; try{ mem=JSON.parse(localStorage.getItem('oltClientesMem')||'{}')||{}; }catch(e){ mem={}; }
    window._loginToIp={}; window._loginToNome={}; window._loginToUuid={};
    // IP NÃO vem da memória: o IP do PPPoE muda a cada reconexão e um IP velho pode já ser de outro cliente.
    Object.keys(mem).forEach(function(k){ var m=mem[k]||{}; if(m.nome)window._loginToNome[k]=m.nome; if(m.uuid)window._loginToUuid[k]=m.uuid; });
    var novo=false;
    try{ (dadosOriginais||[]).forEach(function(it){ var k=String(it.login||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(!k) return;
        var ip=it.ip||''; var nm=it.nome_completo||it.nome_reduzido||it.nome||''; var uu=String(it.uuid_cliente||it.uuid||'').trim();
        if(ip) window._loginToIp[k]=ip; if(nm) window._loginToNome[k]=nm; if(uu) window._loginToUuid[k]=uu;
        if(nm||uu){ var p=mem[k]||{}; mem[k]={nome:nm||p.nome||'', uuid:uu||p.uuid||''}; novo=true; }
    }); }catch(e){}
    if(novo){ try{ localStorage.setItem('oltClientesMem', JSON.stringify(mem)); }catch(e){} }
}
// Mapa COMPLETO de clientes (inclusive OFFLINE), vindo do banco (sis_cliente) via endpoint.
// É o que faz o link do Nome funcionar nas offline (a página "conectado" só tem online).
function oltCarregarClientesDB(){
    if(window._oltClientesDB && Object.keys(window._oltClientesDB).length) return; // já embutido pelo PHP
    // Carrega o mapa login->uuid/nome/ip do BACKEND (olt_huawei.php?acao=clientes_db) — funciona por IP E por
    // DOMÍNIO (lê o banco direto, não depende do index.php). Assim o clique no nome/serial abre INSTANTÂNEO.
    oltFetch('olt_huawei.php?acao=clientes_db', null, false).then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.clientes){ window._oltClientesDB=d.clientes; window._snToLoginWs=d.contratos||{}; if(oltGerenciadorAberto()) oltRenderLista(); }
    }).catch(function(){ window._oltClientesDB=window._oltClientesDB||{}; }); // radius indisponível -> segue sem nomes
}
// Converte o serial 16-hex da OLT (44443732E68F7909) p/ o formato do fabricante (DD72E68F7909):
// os 4 primeiros bytes viram ASCII (DD72), o resto continua hex. Cobre os dois formatos de login.
function _oltSnVendor(serial){ var h=String(serial||'').toUpperCase().replace(/[^0-9A-F]/g,''); if(h.length<16) return ''; var pre=''; for(var i=0;i<8;i+=2){ var c=parseInt(h.substr(i,2),16); if(c>=32&&c<=126) pre+=String.fromCharCode(c); else return ''; } return (pre+h.substr(8)).toUpperCase().replace(/[^0-9A-Z]/g,''); }
// Login AUTORITATIVO do serial: quando o CONTRATO do WellSystem vincula esse serial a um
// login_pppoe (mapa 'contratos' de clientes_db — ver olt_login_ws_por_sn no PHP), ele MANDA.
// Sem contrato pra esse serial, cai no comportamento antigo (assume login do radius = serial),
// então quem ainda não tem contrato cadastrado continua funcionando como antes.
// CRIADO PORQUE: antes disso, oltIpDoCliente/oltNomeDoCliente/oltUuidDoCliente assumiam sempre
// login=serial e podiam cair no cadastro de OUTRO cliente cujo login só por coincidência batia
// com o serial normalizado (foi o caso do IP 100.72.1.67 aparecendo no lugar do 100.72.1.10 real).
function _oltLoginResolvido(serial){
    var s=String(serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    var w=window._snToLoginWs||{};
    if(s&&w[s]) return String(w[s]).toUpperCase().replace(/[^0-9A-Z]/g,'');
    return s;
}
function _oltCliDB(serial){ var m=window._oltClientesDB||{}; var s=_oltLoginResolvido(serial); if(s&&m[s]) return m[s]; var sBruto=String(serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(sBruto&&m[sBruto]) return m[sBruto]; var v=_oltSnVendor(serial); if(v&&m[v]) return m[v]; return {}; }
// IP = sessão ATUAL: o backend (clientes_db) já manda o IP ao vivo (concentrador/radacct), por isso vem 1º.
function oltIpDoCliente(serial){ _oltMapaClientes(); var s=_oltLoginResolvido(serial); return _oltCliDB(serial).ip||(s&&window._loginToIp[s])||''; }
// Nome COMPLETO do cliente (página principal p/ online; banco sis_cliente p/ offline).
function oltNomeDoCliente(serial){ _oltMapaClientes(); var s=_oltLoginResolvido(serial); return (s&&window._loginToNome[s])||_oltCliDB(serial).nome||''; }
// Nome EXIBIDO: edição local (cadastro.nome) vence; senão o nome do cliente; senão a descrição da OLT.
function _oltNomeDe(o){ if(!o) return ''; var c=_oltCadDe(o.serial); return (c&&c.nome)||oltNomeDoCliente(o.serial)||o.nome||''; }
function oltUuidDoCliente(serial){ _oltMapaClientes(); var s=_oltLoginResolvido(serial); return (s&&window._loginToUuid[s])||_oltCliDB(serial).uuid||''; }
// Casa a ONU com o SmartOLT por SERIAL (sn:) OU por POSIÇÃO F/S/P+ONT-ID (pos:)
function _oltSmartRec(o){ var m=window._oltSmartMap; if(!m||!o) return null;
    var sn=(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    if(sn && m['sn:'+sn]) return m['sn:'+sn];   // formato novo (prefixado)
    if(sn && m[sn]) return m[sn];               // formato flat (compatibilidade)
    var k='pos:'+(o.fsp||'')+'|'+(o.id||''); if(m[k]) return m[k]; // por posição F/S/P
    return null;
}
// Link "abrir no SmartOLT" (só coleta de info; nunca autorização) — #8
// O id interno (/onu/view/<id>) não vem na API; usamos o atalho por external_id,
// Funções de integração legadas removidas (SmartOLT desativado).
function _oltSmartLink(o){ return ''; }
function _oltAplicarSmart(){ }
function oltEnriquecerSmart(){ }
// Ressincronização automática (15s) que COMPLEMENTA a lista (nunca reseta):
// atualiza os campos das ONUs existentes por F/S/P+ID e adiciona novas. #3/#6
// #3/#7: Sincronização automática (15s) que RE-VARRE de verdade a OLT (1 slot por
// ciclo, round-robin) via listar_slot — que atualiza o cache no servidor — e MESCLA
// só os dados alterados por F/S/P+ID. Preserva filtro, pesquisa, paginação, rolagem,
// seleção e janelas abertas (não reconstrói do zero, não reseta a lista).
var OLT_SYNC_MS = 22000; // intervalo da sincronização automática (22s) — mais espaçado p/ NÃO martelar a OLT
                         // (menos login falho/congestão). Urgência real vem do alarme, não do polling.
function oltIniciarAutoSync(){
    if(window._oltSyncTimer) clearInterval(window._oltSyncTimer);
    window._oltSyncSlot=0;
    window._oltProxSync = Date.now() + OLT_SYNC_MS; // p/ o contador regressivo do topo
    window._oltSyncTimer=setInterval(function(){
        window._oltProxSync = Date.now() + OLT_SYNC_MS; // reseta a contagem regressiva a cada ciclo
        var ov=document.getElementById('oltOverlay');
        if(!ov || ov.style.display==='none'){ clearInterval(window._oltSyncTimer); window._oltSyncTimer=null; return; }
        // (08/11/2026) aba escondida (ninguém olhando) -> não lê a placa: o cron do servidor já varre a OLT a cada 4 min, e esta leitura
        // só disputava a ÚNICA sessão Telnet com ele (leitura de placa média 14 s, repetindo a cada minuto com a tela esquecida aberta).
        if(document.hidden) return;
        var inp=document.getElementById('olt_filtro'); if(inp && document.activeElement===inp) return; // não mexe enquanto digita
        if(window._oltPausarFundo) return; // Aprovisionando -> PAUSA a varredura de fundo (libera o Telnet p/ o Autorizar não falhar na 1ª)
        if(document.getElementById('oltTermIn')||document.getElementById('oltTermUser')) return; // Terminal aberto -> pausa (libera Telnet p/ os comandos do terminal)
        if(window._oltSyncRodando) return; // evita sobreposição de ciclos
        // BACKOFF ADAPTATIVO: se a última leitura falhou (VTY congestionada / "Placa não respondeu"),
        // PULA alguns ciclos p/ a OLT (e o SmartOLT) respirarem — evita martelar e cascatear o erro.
        if(window._oltSyncSkip>0){ window._oltSyncSkip--; return; }
        // Sync PONDERADO: a última placa (a maior, ex.: 5) é a mais lenta de varrer ->
        // aparece com MENOS frequência na sequência p/ não pesar (Obs7/perf).
        var seq=window._oltSyncSeq || (window._oltSyncSeq = (OLT_SLOTS.length>1 ? OLT_SLOTS.concat(OLT_SLOTS.slice(0,-1)) : OLT_SLOTS.slice()));
        var slot=seq[window._oltSyncSlot % seq.length]; window._oltSyncSlot++;
        window._oltSyncRodando=true;
        window._oltSyncAtivo=slot; _oltTickUptime(); // mostra "sincronizando placa X..." (prova que roda)
        // (B) Na PLACA MAIOR (última do OLT_SLOTS), pula a VLAN na maioria dos ciclos (usa cache)
        //     e faz um refresh completo de VLAN a cada 4ª vez. Corta ~metade do trabalho da placa 5.
        var _big=OLT_SLOTS[OLT_SLOTS.length-1]; var _nv='';
        if(slot===_big){ window._oltBigN=(window._oltBigN||0)+1; if(window._oltBigN % 4 !== 0) _nv='&novlan=1'; }
        oltFetch('olt_huawei.php?acao=listar_slot&slot='+slot+_nv).then(function(r){ return r.json(); }).then(function(d){
            window._oltSyncRodando=false; window._oltSyncAtivo=0;
            if(d&&d.ms!=null){ window._oltSlotMs=window._oltSlotMs||{}; window._oltSlotMs[slot]=d.ms; if(d.ms>8000) try{ console.log('[OLT] placa '+slot+' levou '+d.ms+'ms'); }catch(e){} } // obs2: cronometra
            if(!(d&&d.status==='ok'&&d.onus)){ window._oltSyncSkip=Math.min(6,(window._oltSyncSkip||0)+2); return; } // leitura fraca/falha -> recua
            window._oltSyncSkip=0;   // leitura boa -> cadência normal de volta
            var idx={}; (window._oltLista||[]).forEach(function(o){ idx[(o.fsp||'')+'|'+o.id]=o; });
            var mudou=false;
            d.onus.forEach(function(n){ var k=(n.fsp||'')+'|'+n.id; var o=idx[k];
                if(o){
                    if(o.status!==n.status){ o.status=n.status; o._estadoReal=false; mudou=true; window._oltEstadoFeito=false; }
                    if(n.estado && !o._estadoReal && o.estado!==n.estado){ o.estado=n.estado; mudou=true; }
                    if(n.vlan && o.vlan!==n.vlan){ o.vlan=n.vlan; mudou=true; }
                    if(n.serial && !o.serial){ o.serial=n.serial; mudou=true; }
                    if(n.nome && !o.nome){ o.nome=n.nome; mudou=true; }
                    if(n.modelo && !o.modelo){ o.modelo=n.modelo; mudou=true; }
                    if(n.uptime && !o.uptime){ o.uptime=n.uptime; mudou=true; }
                    if((n.status||'').toLowerCase().indexOf('online')>-1){ if(o.downtime){ o.downtime=''; mudou=true; } } // voltou -> zera downtime
                    else if(n.downtime && o.downtime!==n.downtime){ o.downtime=n.downtime; mudou=true; }
                    if(n.modo && o.modo!==n.modo){ o.modo=n.modo; mudou=true; }
                    if(n.srv && !o.srv){ o.srv=n.srv; }
                    if(n.tipo && n.tipo_olt){ o.tipo=n.tipo; o._tipoOlt=true; }
                } else { window._oltLista.push(n); o=n; mudou=true; window._oltEstadoFeito=false; }
            });
            _oltMarcarAtualizado(); // dados frescos da OLT (sync deste slot) -> hora da informação
            if(mudou){ oltRenderLista(); oltEnriquecerEstadoOffline(); oltEnriquecerSinal(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
            else { _oltAtualizarValida(); }
        }).catch(function(){ window._oltSyncRodando=false; window._oltSyncAtivo=0; window._oltSyncSkip=Math.min(6,(window._oltSyncSkip||0)+2); }); // erro -> recua (backoff)
    }, OLT_SYNC_MS); // tempo real (round-robin por placa; não fecha/altera nada, só atualiza)
}
// #2/#3: SINAL óptico REAL da OLT (RX/TX) em massa via Telnet (display ont optical-info
// <porta> all). Enriquece a lista em segundo plano (não trava a abertura) e recalcula
// os cards Sinal Bom/Ruim a partir do estado REAL da OLT — nunca do SmartOLT.
function oltEnriquecerSinal(){
    if(!window._oltLista || window._oltSinalRodando || window._oltPausarFundo) return;
    if(!oltGerenciadorAberto()) return;
    // O resumo já traz o rx (lado ONU). Aqui só buscamos o rx_olt (lado OLT), e SOMENTE
    // das ONLINE (offline/desativada não têm luz). Cada ONU é tentada UMA vez (_sinalTentado),
    // senão as offline entrariam em loop infinito travando a fila (era a lentidão de 35min).
    // ONLINE que ainda não tem rx_olt OU nem rx (Obs8: garante que TODA online seja
    // classificada em Bom/Ruim; as offline não têm luz e ficam fora, é o esperado).
    var falta=function(o){ return o && o.fsp && (o.id!==''&&o.id!=null) && (o.status||'').toLowerCase().indexOf('online')>-1 && (!o.rx_olt || !o.rx) && !o._sinalTentado; };
    var alvo=window._oltLista.filter(falta).slice(0,150);
    if(!alvo.length){ window._oltSinalRodando=false; return; }
    window._oltSinalRodando=true;
    alvo.forEach(function(o){ o._sinalTentado=true; }); // não reconsulta em loop
    var itens=alvo.map(function(o){ return {fsp:o.fsp, id:o.id}; });
    oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=optico_massa&itens='+encodeURIComponent(JSON.stringify(itens))}, false, 90000)
      .then(function(r){ return r.json(); })
      .then(function(d){ window._oltSinalRodando=false;
        if(d&&d.status==='ok'&&d.sinais){ var mp=d.sinais; var mudou=false;
            (window._oltLista||[]).forEach(function(o){ var k=(o.fsp||'')+'|'+(o.id||''); if(mp[k]){ if(mp[k].rx && !o.rx){ o.rx=mp[k].rx; mudou=true; } if(mp[k].tx && !o.tx){ o.tx=mp[k].tx; } if(mp[k].rx_olt){ o.rx_olt=mp[k].rx_olt; mudou=true; } if(mp[k].dist && !o.dist){ o.dist=mp[k].dist; } } });
            if(mudou) oltRenderLista();
        }
        if(window._oltLista && window._oltLista.some(falta)) setTimeout(oltEnriquecerSinal, 300);
      })
      .catch(function(){ window._oltSinalRodando=false; });
}
// MODELO (Bridge/Router) — 1º tenta LOTE POR PORTA (rápido); se o comando não existir,
// cai no per-ONU. Enche todas as ONUs (pros cards) em 2º plano.
function oltEnriquecerDetalhe(){
    if(!window._oltLista || window._oltDetalheRodando || window._oltPausarFundo) return;
    if(!oltGerenciadorAberto()){ window._oltDetalheRodando=false; return; }
    var _tok=window._oltSessao;
    var falta=function(o){ return o && o.fsp && (o.id!==''&&o.id!=null) && !o.modelo; };
    var todas=(window._oltLista||[]).filter(falta);
    if(!todas.length) return;
    window._oltDetalheRodando=true;

    if(!window._oltVersaoBulkOff){
        // LOTE POR PORTA — manda um bloco grande (o backend agrupa em ~poucas portas)
        var alvoB=todas.slice(0,120);
        var itensB=alvoB.map(function(o){ return {fsp:o.fsp, id:o.id}; });
        oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=versao_massa&itens='+encodeURIComponent(JSON.stringify(itensB))}, false, 90000)
          .then(function(r){ return r.json(); })
          .then(function(d){ window._oltDetalheRodando=false;
            if(!_oltAtivo(_tok)) return;
            var got=0;
            if(d&&d.status==='ok'&&d.modelos){ var mp=d.modelos; (window._oltLista||[]).forEach(function(o){ var k=(o.fsp||'')+'|'+(o.id||''); if(mp[k]){ o.modelo=mp[k]; got++; } }); }
            if(got>0){ alvoB.forEach(function(o){ if(!o.modelo) o.modelo='—'; }); oltRenderLista(); } // marca os já consultados
            if(got===0 && d && d.status==='ok') window._oltVersaoBulkOff=true; // comando não suportado -> per-ONU (resposta de erro/ocupada NÃO desliga)
            if(got>0) window._oltVersaoFalhas=0;
            if(!(d&&d.status==='ok')){ if(_oltAtivo(_tok)) setTimeout(oltEnriquecerDetalhe, 8000); return; }
            if(_oltAtivo(_tok) && (window._oltLista||[]).some(falta)) setTimeout(oltEnriquecerDetalhe, 300);
          })
          .catch(function(){ window._oltDetalheRodando=false;   // falha passageira (OLT ocupada/tempo): NÃO desliga o lote rápido — tenta de novo em 8s
            window._oltVersaoFalhas=(window._oltVersaoFalhas||0)+1; if(window._oltVersaoFalhas>=4) window._oltVersaoBulkOff=true;
            if(_oltAtivo(_tok)) setTimeout(oltEnriquecerDetalhe, 8000); });
        return;
    }

    // FALLBACK per-ONU: página visível primeiro, depois o resto (pros cards)
    var arr=[]; try{ arr=_oltFiltradas(); }catch(e){ arr=window._oltLista||[]; }
    var pp=window._oltPorPag||50; var pg=window._oltPag||1;
    var page=(pp>=99999)?arr:arr.slice((pg-1)*pp,(pg-1)*pp+pp);
    var alvo=page.filter(falta).slice(0,20);
    if(alvo.length<20){ var vistos={}; alvo.forEach(function(o){ vistos[(o.fsp||'')+'|'+o.id]=1; }); todas.forEach(function(o){ if(alvo.length<20 && !vistos[(o.fsp||'')+'|'+o.id]) alvo.push(o); }); }
    if(!alvo.length){ window._oltDetalheRodando=false; return; }
    var itens=alvo.map(function(o){ return {fsp:o.fsp, id:o.id}; });
    oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=detalhe_massa&itens='+encodeURIComponent(JSON.stringify(itens))}, false, 90000)
      .then(function(r){ return r.json(); })
      .then(function(d){ window._oltDetalheRodando=false;
        if(!_oltAtivo(_tok)) return;
        var mudou=false;
        if(d&&d.status==='ok'&&d.detalhes){ var mp=d.detalhes; (window._oltLista||[]).forEach(function(o){ var k=(o.fsp||'')+'|'+(o.id||''); if(mp[k]&&mp[k].modelo){ o.modelo=mp[k].modelo; mudou=true; } }); }
        alvo.forEach(function(o){ if(!o.modelo){ o.modelo='—'; } });
        if(mudou) oltRenderLista();
        if(_oltAtivo(_tok) && (window._oltLista||[]).some(falta)) setTimeout(oltEnriquecerDetalhe, 500);
      })
      .catch(function(){ window._oltDetalheRodando=false; });
}
// UPTIME só da PÁGINA VISÍVEL (display ont info é pesado) e só das ONLINE.
function oltEnriquecerUptime(){
    if(!window._oltLista || window._oltUptimeRodando || window._oltPausarFundo) return;
    if(!oltGerenciadorAberto()) return;
    var _tok=window._oltSessao;
    var arr=[]; try{ arr=_oltFiltradas(); }catch(e){ arr=window._oltLista||[]; }
    var pp=window._oltPorPag||50; var pg=window._oltPag||1;
    var page=(pp>=99999)?arr:arr.slice((pg-1)*pp,(pg-1)*pp+pp);
    // Só uptime (se o resumo não trouxe) das visíveis online. Bridge/Router vem do modelo, não daqui.
    var falta=function(o){ return o && o.fsp && (o.id!==''&&o.id!=null) && !o.uptime && (o.status||'').toLowerCase().indexOf('online')>-1; };
    var alvo=page.filter(falta).slice(0,20);
    if(!alvo.length) return;
    window._oltUptimeRodando=true;
    var itens=alvo.map(function(o){ return {fsp:o.fsp, id:o.id}; });
    oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=uptime_massa&itens='+encodeURIComponent(JSON.stringify(itens))}, false, 90000)
      .then(function(r){ return r.json(); })
      .then(function(d){ window._oltUptimeRodando=false;
        if(!_oltAtivo(_tok)) return;
        var mudou=false;
        if(d&&d.status==='ok'&&d.detalhes){ var mp=d.detalhes; (window._oltLista||[]).forEach(function(o){ var k=(o.fsp||'')+'|'+(o.id||''); if(mp[k]){ if(mp[k].uptime){ o.uptime=mp[k].uptime; } if(mp[k].modo){ o.modo=mp[k].modo; } if(mp[k].srv){ o.srv=mp[k].srv; } if(mp[k].lineprofile!==undefined){ o.lineprofile=mp[k].lineprofile; } if(mp[k].srvprofile!==undefined){ o.srvprofile=mp[k].srvprofile; } mudou=true; } }); }
        alvo.forEach(function(o){ if(!o.uptime) o.uptime='-'; }); // marca p/ não repetir
        if(mudou) oltRenderLista();
        if(_oltAtivo(_tok) && page.some(falta)) setTimeout(oltEnriquecerUptime, 500);
      })
      .catch(function(){ window._oltUptimeRodando=false; });
}
// Verifica ONUs aguardando liberação e mostra alerta/contagem
// Botão-alerta de aprovisionamento (vermelho pulsante c/ total quando há pendências)
// CARD "Aguardando Liberação" (no topo, entre os tiles). Clique -> abre o Aprovisionamento.
// Mantém id="olt_apbtn" p/ o oltCheckPendentes atualizar o número sem re-renderizar tudo.
function _oltBotaoAprov(){
    var np=window._oltPendentes||0; var cor=np>0?OLTC.amb:OLTC.mut;
    // Piscar (alerta) quando HÁ ONU aguardando — keyframe injetado 1x.
    if(!document.getElementById('oltPendCss')){ var s=document.createElement('style'); s.id='oltPendCss';
        s.textContent='@keyframes oltPendPulse{0%,100%{box-shadow:0 0 0 0 rgba(245,158,11,0.55)}50%{box-shadow:0 0 0 6px rgba(245,158,11,0)}}'; document.head.appendChild(s); }
    var anim=np>0?' animation:oltPendPulse 1.4s infinite;':'';
    return '<div id="olt_apbtn" onclick="oltAprovisionamento()" title="Aprovisionamento — ONUs aguardando liberação" style="'+_oltTileEstilo(np>0?OLTC.amb:cor, np>0?OLTC.amb:OLTC.line, '0 1px 2px rgba(0,0,0,0.12)', np>0?'rgba(245,158,11,0.12)':OLTC.bg2)+' padding-right:30px; cursor:pointer;'+anim+'">'+
        // Buscar agora (resincroniza o card) — não abre o modal (stopPropagation).
        '<button onclick="event.stopPropagation(); oltCheckPendentes(); this.querySelector(\'i\').classList.add(\'fa-spin\'); var b=this; setTimeout(function(){var i=b.querySelector(\'i\'); if(i) i.classList.remove(\'fa-spin\');},1200);" title="Buscar ONUs agora" style="position:absolute; top:50%; right:6px; transform:translateY(-50%); cursor:pointer; width:20px; height:20px; border-radius:6px; border:1px solid '+OLTC.line+'; background:'+OLTC.bg2+'; color:'+OLTC.acc+'; font-size:9px; padding:0; line-height:1;"><i class="fa-solid fa-arrows-rotate"></i></button>'+
        _oltTileCorpo('fa-plug-circle-plus', cor, np, 'Aguardando liberação')+
    '</div>';
}
// CARD "PON em queda" (LOS / falta de energia) — antes do Total. Clique -> abre o Resumo (faixa vermelha).
function _oltTileAlerta(){
    var n=(_oltPonsEmAlerta()||[]).length; var alerta=n>0; var cor=alerta?OLTC.red:OLTC.mut;
    return '<div onclick="oltResumoContagem()" title="Portas PON em queda total (LOS ou falta de energia)" style="'+_oltTileEstilo(cor, alerta?OLTC.red:OLTC.line, '0 1px 2px rgba(0,0,0,0.12)', alerta?'rgba(239,68,68,0.14)':OLTC.bg2)+' cursor:pointer;'+(alerta?' animation:oltPulse 1.4s infinite;':'')+'">'+
        _oltTileCorpo('fa-triangle-exclamation', cor, n, 'PON em queda')+
    '</div>';
}
// Verifica pendências e ATUALIZA só o botão-alerta (sem re-renderizar a lista)
function oltCheckPendentes(){
    if(!oltGerenciadorAberto()) return;
    _oltFetchDireto('olt_huawei.php?acao=autofind', 15000)   // cache (sem Telnet): direto, fora da fila
      .then(function(r){ return r.json(); })
      .then(function(d){ var np=(d&&d.pendentes)?d.pendentes.length:0; if(np===window._oltPendentes){ if(window._oltPendentes===undefined){ window._oltPendentes=np; } return; } window._oltPendentes=np; var b=document.getElementById('olt_apbtn'); if(b) b.outerHTML=_oltBotaoAprov(); })
      .catch(function(){});
}
// Contador automático: revê pendências a cada 30s enquanto o Gerenciador está aberto
function oltIniciarAlertaPendentes(){
    if(window._oltPendTimer) clearInterval(window._oltPendTimer);
    window._oltPendTimer=setInterval(function(){
        var ov=document.getElementById('oltOverlay');
        if(!ov || ov.style.display==='none'){ clearInterval(window._oltPendTimer); window._oltPendTimer=null; return; }
        oltCheckPendentes();
    }, 30000);
}
// Força nova varredura na OLT (limpa o cache velho e revarre do zero)
function oltRescan(){
    window._oltLista=[]; window._oltCacheIdade=0; window._oltEstadoFeito=false; oltFooter('');
    oltBody(_oltSpinner('Limpando cache e iniciando nova varredura...'));
    fetch('olt_huawei.php?acao=cache_clear').then(function(){ oltVarrerSlots(0); }).catch(function(){ oltVarrerSlots(0); });
}
// Dedup DEFINITIVO por F/S/P+ID (chave única de cada ONU na OLT)
/* Remove ONUs repetidas da lista (a varredura pode devolver a mesma placa duas vezes).
 *
 * A CHAVE E' O SERIAL. Antes era fsp|id — posição na OLT — e isso ENGOLIA ONU: quando uma vinha
 * sem o id preenchido, a chave virava "0/1/1|" e a próxima também sem id caía na MESMA chave,
 * então uma das duas sumia da lista e do total. Era o total fechando 696 com a OLT dizendo 697.
 * O serial é único por equipamento, então não colide. Sem serial (caso raro), cai para a posição
 * de antes; sem os dois, cada entrada fica com uma chave própria e nenhuma é descartada.
 */
function _oltDedup(arr){
    var por={}, avulsas=[];
    (arr||[]).forEach(function(o){
        var sn=String((o&&o.serial)||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
        var k = sn ? ('sn:'+sn) : ((o&&(o.fsp||o.id!=null)) ? ('fsp:'+(o.fsp||'')+'|'+(o.id!=null?o.id:'')) : '');
        if(k===''){ avulsas.push(o); return; }          // sem serial e sem posição: não descarta
        if(!por[k]) por[k]=o;
    });
    return Object.keys(por).map(function(k){ return por[k]; }).concat(avulsas);
}

// Status da OLT no subtítulo do cabeçalho (uptime / temperatura)
function oltCarregarStatus(){
    oltFetch('olt_huawei.php?acao=olt_status')
      .then(function(r){ return r.json(); })
      .then(function(d){
        // O olt_status é a fonte natural do estado: se respondeu, está conectada.
        // Aproveita a MESMA sessão que já seria aberta — sem custo extra de VTY.
        if(!d||d.status!=='ok'){ if(d && (d.nao_configurado||d.status==='nao_configurado')) _oltStatusConexao(false,'OLT não configurada'); return; }
        _oltStatusConexao(true);
        window._oltStatus=d;
        var ws=document.getElementById('oltWinSub');
        if(ws){ var t=[]; t.push(''+(d.olt||'OLT')); if(d.versao) t.push('🧩 '+d.versao);
            if(d.uptime){ var _up=(''+d.uptime).replace(/\s*days?/gi,'d').replace(/\s*hours?/gi,'h').replace(/\s*minutes?/gi,'m').replace(/\s*seconds?/gi,'s').replace(/\s+/g,' ').trim(); t.push('⏱ '+_up); }
            if(d.temperatura){ var _tv=parseInt((''+d.temperatura).replace(/[^0-9\-]/g,''),10); t.push((!isNaN(_tv)&&_tv>=39?'🌡⚠ ':'🌡 ')+d.temperatura); }
            // CPU: mantém o ÚLTIMO valor bom (não some/pisca quando uma leitura vem vazia).
            var _cpu=(''+(d.cpu||'')).replace(/[^0-9]/g,''); if(_cpu!=='' && _cpu!=='0') window._oltCpuUlt=_cpu+'%'; if(window._oltCpuUlt){ var _cv=parseInt(window._oltCpuUlt,10); t.push((!isNaN(_cv)&&_cv>=85?'🧠⚠ ':'🧠 ')+'CPU '+window._oltCpuUlt); }
            ws.innerHTML=_oltEsc(t.join('  ·  ')); }
        // Versão ainda não detectada? tenta em 2º plano (não trava o topo). Se o Telnet estiver
        // congestionado (AUTH_RETRY), REPETE a cada 60s até conseguir — não desiste na 1ª falha.
        if(!d.versao){ var _now=Date.now(); if(!window._oltVerNext || _now>window._oltVerNext){ window._oltVerNext=_now+60000;
            fetch('olt_huawei.php?acao=versao_get').then(function(r){return r.json();}).then(function(vd){ if(vd&&vd.versao) oltCarregarStatus(); }).catch(function(){}); } }
        _oltResumoRefresh(); // atualiza o Monitoramento do Resumo (uptime/temperatura) se aberto
      }).catch(function(){});
}
function oltVarrerSlots(i, rapido){
    if(window.WS_SAINDO) return;   // saindo: aborta a varredura
    if(i>=OLT_SLOTS.length){ window._oltEstadoFeito=false; _oltMarcarAtualizado(); oltRenderLista(); oltEnriquecerEstadoOffline(); oltEnriquecerSinal(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); oltCheckPendentes(); return; }
    var slot=OLT_SLOTS[i];
    // Se a lista está vazia, mostra progresso; se já tem (cache), NÃO reseta — só mescla.
    if(!(window._oltLista&&window._oltLista.length)) oltRenderLista('Varrendo slot '+slot+'…');
    // 150s por placa (antes caía no limite de 25s da fila). rapido=1 -> releitura com VLAN do cache.
    oltFetch('olt_huawei.php?acao=listar_slot&slot='+slot+(rapido?'&novlan=1':''), null, true, 150000)
      .then(function(r){ return r.json(); })
      .then(function(d){
        if(d&&d.status==='ok'&&d.onus&&d.onus.length){
            var idx={}; (window._oltLista||[]).forEach(function(o){ idx[(o.fsp||'')+'|'+o.id]=o; });
            d.onus.forEach(function(n){ var k=(n.fsp||'')+'|'+n.id; var o=idx[k];
                if(o){ if(o.status!==n.status){ o.status=n.status; o._estadoReal=false; } if(n.estado && !o._estadoReal)o.estado=n.estado; if(n.serial)o.serial=n.serial; if(n.nome)o.nome=n.nome; if(n.modelo&&!o.modelo)o.modelo=n.modelo; if(n.uptime&&!o.uptime)o.uptime=n.uptime; if((n.status||'').toLowerCase().indexOf('online')>-1){o.downtime='';}else if(n.downtime){o.downtime=n.downtime;} if(n.tipo&&n.tipo_olt){o.tipo=n.tipo; o._tipoOlt=true;} }
                else { window._oltLista.push(n); }
            });
            oltRenderLista();
        }
        // Registra o resultado de CADA placa: antes, uma placa que falhava sumia
        // sem aviso e parecia que "só a placa 1 existe".
        window._oltSlotRes=window._oltSlotRes||{};
        window._oltSlotRes[slot]=(d&&d.onus)?d.onus.length:0;
        // STATUS pela realidade: a placa respondeu => a OLT está acessível.
        if(d && d.status==='ok') _oltStatusConexao(true);
        oltVarrerSlots(i+1);
      })
      .catch(function(){
        // 1 nova tentativa da MESMA placa, em modo rápido (VLAN do cache), após 5s — só depois
        // disso ela entra no aviso "não respondeu".
        if(!rapido){ setTimeout(function(){ oltVarrerSlots(i, true); }, 5000); return; }
        window._oltSlotRes=window._oltSlotRes||{}; window._oltSlotRes[slot]=-1; // -1 = falhou
        oltVarrerSlots(i+1);
      });
}
// Aviso quando alguma placa não respondeu (normalmente sessões VTY esgotadas na OLT).
function _oltAvisoSlots(){
    var r=window._oltSlotRes||{}; var falhas=[], vazias=[];
    OLT_SLOTS.forEach(function(s){ if(r[s]===-1) falhas.push(s); else if(r[s]===0) vazias.push(s); });
    if(!falhas.length && !vazias.length) return '';
    var txt='';
    if(falhas.length) txt+='<b>Placa '+falhas.join(', ')+'</b> não respondeu. ';
    if(vazias.length) txt+='<b>Placa '+vazias.join(', ')+'</b> respondeu sem ONUs. ';
    return '<div style="display:flex; align-items:flex-start; gap:9px; background:rgba(245,158,11,.12); border:1px solid '+OLTC.amb+'; border-radius:9px; padding:9px 12px; margin-bottom:12px; font-size:11.5px; color:'+OLTC.txt+';">'+
        '<i class="fa-solid fa-triangle-exclamation" style="color:'+OLTC.amb+'; margin-top:2px;"></i>'+
        '<div>'+txt+(falhas.length?'A OLT costuma limitar sessões Telnet simultâneas (VTY): aguarde ~1 min e clique em <b>Refresh</b>. Se insistir, verifique se outra ferramenta está conectada na OLT.':'')+'</div></div>';
}
// Normaliza p/ busca: minúsculas, sem acento, espaços únicos. Busca por PALAVRAS: todas precisam existir, em qualquer ordem.
function _oltNorm(t){ t=String(t==null?'':t).toLowerCase(); try{ t=t.normalize('NFD').replace(/[\u0300-\u036f]/g,''); }catch(e){} return t.replace(/\s+/g,' ').trim(); }
function _oltPalavras(alvo, termo){ var ps=_oltNorm(termo).split(' ').filter(Boolean); for(var i=0;i<ps.length;i++){ if(alvo.indexOf(ps[i])<0) return false; } return true; }
// Texto de cada coluna (para os filtros por coluna do cabeçalho).
function _oltColTexto(o, col){
    var pon=(o.fsp||'').split('/');
    if(col==='fsp') return o.fsp||'';
    if(col==='pon') return pon[2]||'';
    if(col==='id') return ''+(o.id||'');
    if(col==='nome') return (_oltNomeDe(o)||'');
    if(col==='zona') return o.zona||'';
    if(col==='vlan') return (o.vlan||'')+' '+_oltVlanNome(o.vlan||'');
    if(col==='serial') return o.serial||'';
    if(col==='modelo') return o.modelo||'';
    if(col==='tipo'){ var tp=_oltTipoDe(o); return tp+' '+(tp==='ONU'?'bridge':(tp==='ONT'?'router':'')); }
    if(col==='sinal'){ var sc=_oltSinalClasse(o); return sc+' '+(o.rx||'')+' '+(o.tx||'')+' '+(o.rx_olt||''); }
    if(col==='uptime') return (o.uptime||'')+' '+(o.downtime?('offline '+o.downtime):'');
    if(col==='status') return (o.status||'')+' '+(o.estado||'');
    return '';
}
// Casamento do FILTRO POR COLUNA. Colunas de VALOR DISCRETO (modelo, tipo, VLAN, id, PON, status)
// casam por TOKEN EXATO — assim "R1" NÃO pega "R11"/"R110", "8" NÃO pega "80". Colunas de texto
// livre (nome, zona, serial, fsp, sinal, uptime) continuam por substring (parte do texto).
function _oltColMatch(o, col, val){
    val=(''+val).toLowerCase().trim(); if(val==='') return true;
    var txt=(_oltColTexto(o,col)||'').toLowerCase();
    if(col==='modelo'||col==='tipo'||col==='pon'||col==='id'||col==='vlan'||col==='status'){
        var toks=txt.split(/[\s,;\/|]+/).filter(Boolean);
        return toks.indexOf(val)>-1;
    }
    if(col==='nome'||col==='zona') return _oltPalavras(_oltNorm(txt+' '+(col==='nome'?(o.nome||''):'')), val);
    return txt.indexOf(val)>-1;
}
// ONU recém-aprovisionada (≤3 min) ainda BOOTANDO: mostra "Inicializando" em vez de "Desativada/Offline"
// (o "ont confirm" registra na hora, mas a ONU leva 1-2 min pra subir de fato). O timestamp fica no
// objeto (_novoTs) e também em window._oltNovoTs[fsp|id] (sobrevive se o scan recriar o objeto).
function _oltEhInicializando(o){
    if(!o) return false;
    if((o.status||'').toLowerCase().indexOf('online')>-1) return false;
    var ts=o._novoTs || (window._oltNovoTs && window._oltNovoTs[(o.fsp||'')+'|'+o.id]);
    return !!(ts && (Date.now()-ts) < 180000);
}
/** Momento da autorização se foi nas últimas 24h (senão 0): pela sessão (_novoTs) ou pelo registro do
 *  servidor (olt_autorizacoes: 'data' COM hora — o backfill antigo só tem a data e não conta). */
function _oltTsAutRecente(o){
    if(!o) return 0; var ts=o._novoTs || (window._oltNovoTs && window._oltNovoTs[(o.fsp||'')+'|'+o.id]) || 0;
    if(!ts){ try{ var k=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var au=(window._oltAutoriz||{})[k];
        if(au && au.data && String(au.data).length>=16){ var t=Date.parse(String(au.data).replace(' ','T')); if(!isNaN(t)) ts=t; } }catch(e){} }
    return (ts && (Date.now()-ts) < 86400000) ? ts : 0;
}
function _oltFiltradas(){
    var t=(window._oltFiltro||'').toLowerCase();
    var cat=window._oltCat||'';
    var cf=window._oltColF||{}; var cfKeys=Object.keys(cf).filter(function(k){ return (''+cf[k]).trim()!==''; });
    function catDe(o){ if(_oltEhInicializando(o)) return 'offline'; var e=(o.estado||'').toLowerCase(); if(e) return e; return (o.status||'').toLowerCase().indexOf('online')>-1?'online':'offline'; }
    var tn=_oltNorm(t).replace(/\s+/g,''); // versão sem espaços p/ "pon 7" == "pon7"
    var arr=(window._oltLista||[]).filter(function(o){
        if(cat){
            if(cat.indexOf('tipo:')===0){ if(_oltTipoDe(o)!==cat.slice(5)) return false; }
            else if(cat.indexOf('sinal:')===0){ if(_oltSinalClasse(o)!==cat.slice(6)) return false; }
            else if(catDe(o)!==cat) return false;
        }
        for(var ci=0; ci<cfKeys.length; ci++){ var col=cfKeys[ci]; if(!_oltColMatch(o, col, cf[col])) return false; }
        var pon=(o.fsp||'').split('/'); var frame=pon[0]||'0', slot=pon[1]||'', porta=pon[2]||'';
        var login=''; try{ login=_oltLoginResolvido(o.serial)||''; }catch(e){}
        var alvo=_oltNorm((_oltNomeDe(o)||'')+' '+(o.nome||'')+' '+login+' '+(o.serial||'')+' '+(o.fsp||'')+' '+(o.zona||'')+' '+_oltVlanNome(o.vlan||'')+
            ' pon'+porta+' porta'+porta+' placa'+slot+' slot'+slot+' frame'+frame+
            ' vlan'+(o.vlan||'')+' id'+(o.id||'')+' ont'+(o.id||'')+' '+(o.status||'')+
            ' '+(o.modelo||'')+' '+(o.tipo||''));
        var alvoN=alvo.replace(/\s+/g,'');
        return !t || alvo.indexOf(_oltNorm(t))>-1 || alvoN.indexOf(tn)>-1 || _oltPalavras(alvo, t);
    });
    // RECÉM-AUTORIZADAS (últimas 24h) sempre no TOPO, da mais nova p/ a mais antiga; o resto A→Z.
    arr.sort(function(a,b){ var ta=_oltTsAutRecente(a), tb=_oltTsAutRecente(b); if(ta||tb) return (tb||0)-(ta||0);
        return (a.nome||'~').localeCompare((b.nome||'~'),'pt',{sensitivity:'base'}); });
    return arr;
}
function oltFiltrarCat(c){ window._oltSel={}; if(c==='TODOS')c=''; window._oltCat=(window._oltCat===c?'':c); window._oltPag=1; try{sessionStorage.setItem('oltCat',window._oltCat);}catch(e){}
    window._oltRecentes=(window._oltCat==='online');   // SÓ o card Online lista pelos RECENTES; os outros, ordem normal
    oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
// ---- RESUMO / CONTAGEM por dimensão (VLAN, PON, Zona, Placa, Modelo, Tipo, Status, Sinal) ----
function _oltContarPor(keyFn){ var m={}, tot=0; (window._oltLista||[]).forEach(function(o){ var k=keyFn(o); if(k===''||k==null) k='(vazio)'; m[k]=(m[k]||0)+1; tot++; }); var arr=Object.keys(m).map(function(k){return {k:k,n:m[k]};}); arr.sort(function(a,b){ return b.n-a.n || (''+a.k).localeCompare(''+b.k,'pt'); }); return {arr:arr, tot:tot}; }
// Painel de MONITORAMENTO da OLT (uptime, temperatura, contagens ao vivo) p/ o topo do Resumo.
// Detecta PONs (portas) em QUEDA TOTAL: todas as ONUs da porta caídas por LOS ou por
// falta de energia (dying-gasp/power-off). Indica corte de fibra / falta de luz na área.
// ---- UPTIME AO VIVO (coluna Tempo) -----------------------------------------
// Converte "9d 22h 47min 49s" (ou sem segundos) -> total de segundos. null se não parsear.
function _oltUptimeSec(str){
    if(!str) return null; var s=(''+str).toLowerCase(); var t=0, ok=false;
    var md=s.match(/(\d+)\s*d/);   if(md){ t+=(+md[1])*86400; ok=true; }
    var mh=s.match(/(\d+)\s*h/);   if(mh){ t+=(+mh[1])*3600;  ok=true; }
    var mm=s.match(/(\d+)\s*min/); if(mm){ t+=(+mm[1])*60;    ok=true; }
    else { var m2=s.match(/(\d+)\s*m(?!s)/); if(m2){ t+=(+m2[1])*60; ok=true; } }
    var ms=s.match(/(\d+)\s*s\b/); if(ms){ t+=(+ms[1]); ok=true; }
    return ok? t : null;
}
// Segundos -> "9d 22h 47min 49s" (compacto, sempre com segundos p/ dar o "tique").
function _oltUptimeFmt(sec){
    sec=Math.max(0,Math.floor(sec));
    var d=Math.floor(sec/86400); sec-=d*86400;
    var h=Math.floor(sec/3600);  sec-=h*3600;
    var m=Math.floor(sec/60);    var s=sec-m*60;
    var o=''; if(d)o+=d+'d '; if(d||h)o+=h+'h '; o+=m+'min '+s+'s'; return o.trim();
}
// Cronômetro global: a cada 1s incrementa todos os <span class="oltUpLive"> pela diferença
// entre agora e o instante em que aquele valor foi lido da OLT (data-at). Leve: se não há
// span vivo na tela, não faz nada. É reancorado sempre que a lista re-renderiza com valor novo.
function _oltUptimeTick(){
    var els=document.querySelectorAll('.oltUpLive'); if(!els.length) return; var now=Date.now();
    for(var i=0;i<els.length;i++){ var b=+els[i].getAttribute('data-base'), at=+els[i].getAttribute('data-at');
        if(isNaN(b)||isNaN(at)) continue; els[i].textContent=_oltUptimeFmt(b+Math.floor((now-at)/1000)); }
}
function _oltUptimeTimerOn(){ if(!window._oltUpTimer) window._oltUpTimer=setInterval(_oltUptimeTick,1000); }
function _oltPonsEmAlerta(){
    var L=window._oltLista||[]; var portas={};
    L.forEach(function(o){ var p=(o.fsp||''); if(!p) return; if(!portas[p]) portas[p]={total:0,down:0,los:0,off:0,desc:0,slot:(p.split('/')[1]||'')};
        var g=portas[p]; g.total++;
        var st=(o.status||'').toLowerCase(); var known=(st!==''); var isOn=st.indexOf('online')>-1;
        var e=(o.estado||'').toLowerCase();
        if(!known){ g.desc++; }                                  // status ainda NÃO lido -> não conta como queda
        else if(!isOn){ g.down++; if(e==='los')g.los++; else if(e!=='deactivated')g.off++; }
    });
    // Candidatas: porta com >=3 ONUs, TODAS com status conhecido e 100% caídas (ignora desativadas
    // manuais). Se houver QUALQUER ONU sem status (leitura parcial), a porta NÃO entra -> anti-falso.
    var cand=[]; var porSlot={}, totPonSlot={};
    Object.keys(portas).forEach(function(p){ var g=portas[p]; totPonSlot[g.slot]=(totPonSlot[g.slot]||0)+1;
        if(g.total>=3 && g.desc===0 && g.down>=g.total){ cand.push(p); porSlot[g.slot]=(porSlot[g.slot]||0)+1; }
    });
    // ANTI-FALSO-POSITIVO DE PLACA INTEIRA: se TODAS as PONs (>=3) do mesmo slot caíram juntas, é
    // glitch de leitura/varredura — placa REALMENTE caída vem do alarme AUTORITATIVO da OLT
    // (olt_alarmes_check), não desta inferência. Descarta o slot inteiro.
    var alertas=[];
    cand.forEach(function(p){ var g=portas[p];
        if(porSlot[g.slot]>=3 && porSlot[g.slot]>=(totPonSlot[g.slot]||99)) return;   // slot inteiro -> ignora (glitch)
        alertas.push({pon:p, nome:(_oltPortaNome(p)||_oltPortaDominante(p).zona), tipo:(g.los>=g.off?'los':'energia'), total:g.total, slot:g.slot, porta:(p.split('/')[2]||'')});
    });
    return alertas;
}
// Alerta FLUTUANTE no TOPO (arrastável). Clique no texto -> abre a janela "Atenção PON".
// Renderiza/atualiza/remove o alerta flutuante PON. Recebe a lista de alertas (de qualquer fonte).
// O bloco INTEIRO é arrastável (mouse e toque); clique SEM arrastar abre a Atenção PON.
// Botão "Atenção PON" PULSA com contador enquanto houver PON em queda (tela local OU detectores do
// servidor: Telnet/SNMP/alarmes via pon_alertas). Antes o botão ficava parado mesmo com alerta.
function _oltBtnIntPulso(){
    var b=document.getElementById('oltBtnIntPon'); if(!b) return;
    // + quedas pelos ALARMES da OLT (pon_alertas → "alarmes"): antes o botão não pulsava na "PON CAIU (ENERGIA)"
    var n=Math.max((window._oltAlertas||[]).length, (window._oltAlertasSrv||[]).length) + (window._oltAlarmesSrv||[]).length;
    if(!document.getElementById('oltBtnIntCss')){ var s=document.createElement('style'); s.id='oltBtnIntCss';
        s.textContent='@keyframes oltBtnIntPulse{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,.65);transform:scale(1)}50%{box-shadow:0 0 0 7px rgba(239,68,68,0);transform:scale(1.05)}}.oltBtnIntOn{animation:oltBtnIntPulse 1.2s infinite;background:#dc2626 !important;color:#fff !important;border-color:#dc2626 !important;}';
        document.head.appendChild(s); }
    b.classList.toggle('oltBtnIntOn', n>0);
    var bd=b.querySelector('.oltBtnIntN'); if(n>0){ if(!bd){ bd=document.createElement('span'); bd.className='oltBtnIntN'; bd.style.cssText='margin-left:6px; padding:0 6px; border-radius:9px; background:#fff; color:#dc2626; font-size:10.5px; font-weight:800;'; b.appendChild(bd); } bd.textContent=n; }
    else if(bd) bd.remove();
}
function _oltRenderAlertaPon(alertas){
    var el=document.getElementById('oltAlertaPon');
    window._oltAlertas=alertas||[];
    try{ _oltBtnIntPulso(); }catch(e){}
    if(!alertas || !alertas.length){ if(el) el.remove(); return; }
    // A: enquanto a janela Atenção PON está ABERTA, o alerta fica OCULTO (volta ao fechar).
    var intWin=document.getElementById('oltIntWin');
    if(intWin && intWin.style.display!=='none'){ if(el) el.style.display='none'; return; }
    if(!document.getElementById('oltAlertaCss')){ var s=document.createElement('style'); s.id='oltAlertaCss'; s.textContent='@keyframes oltAlertaPulse{0%,100%{box-shadow:0 6px 20px rgba(239,68,68,0.40)}50%{box-shadow:0 6px 34px rgba(239,68,68,0.80)}}'; document.head.appendChild(s); }
    if(!el){
        el=document.createElement('div'); el.id='oltAlertaPon';
        // B: ícone menor + fonte mais leve (cores iguais).
        el.style.cssText='position:fixed; top:12px; left:50%; z-index:2147483600; padding:8px 13px; border-radius:11px; border:1px solid #ef4444; background:linear-gradient(135deg,#7f1d1d,#d32f2f); color:#fff; font-weight:600; font-size:12.5px; display:flex; align-items:flex-start; gap:9px; max-width:min(92vw,430px); animation:oltAlertaPulse 1.3s infinite; max-width:94vw; cursor:move; user-select:none; touch-action:none;';
        el.innerHTML='<span title="Arraste para mover" style="flex:0 0 auto; color:#fca5a5; font-size:11px; opacity:.8; margin-top:2px;"><i class="fa-solid fa-up-down-left-right"></i></span>'+
            '<i class="fa-solid fa-triangle-exclamation" style="font-size:14px; flex:0 0 auto; color:#fecaca; margin-top:1px;"></i>'+
            '<div id="oltAlertaTxt" style="min-width:0;" title="Clique para abrir a Atenção PON · arraste para mover"></div>';
        document.body.appendChild(el);
        el.style.left=Math.max(6, Math.round(window.innerWidth/2 - el.offsetWidth/2))+'px';
        // Arrasta o alerta INTEIRO; clique sem mover (>3px) abre a janela. Mouse + toque.
        var moved=false, sx=0, sy=0, ox=0, oy=0;
        var iniciar=function(cx,cy){ moved=false; sx=cx; sy=cy; var r=el.getBoundingClientRect(); ox=r.left; oy=r.top; };
        var mover=function(cx,cy){ if(Math.abs(cx-sx)>3||Math.abs(cy-sy)>3){ moved=true; el.style.left=(ox+cx-sx)+'px'; el.style.top=Math.max(0,(oy+cy-sy))+'px'; } };
        el.addEventListener('mousedown', function(e){ if(e.button!==0) return; if(e.target.closest && e.target.closest('button')) return; e.preventDefault(); iniciar(e.clientX,e.clientY);
            function mv(ev){ mover(ev.clientX,ev.clientY); }
            function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
            document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
        });
        el.addEventListener('click', function(e){ if(e.target.closest && e.target.closest('button')) return; if(!moved){ if(window._oltAlertaMin){ oltAlertaMax(); } else { oltInterrupcaoPon(); } } });
        el.addEventListener('touchstart', function(e){ if(e.target.closest && e.target.closest('button')) return; var t=e.touches[0]; iniciar(t.clientX,t.clientY);
            function tm(ev){ var tt=ev.touches[0]; mover(tt.clientX,tt.clientY); if(moved) ev.preventDefault(); }
            function te(){ el.removeEventListener('touchmove',tm); el.removeEventListener('touchend',te); if(!moved){ if(window._oltAlertaMin){ oltAlertaMax(); } else { oltInterrupcaoPon(); } } }
            el.addEventListener('touchmove',tm,{passive:false}); el.addEventListener('touchend',te);
        }, {passive:true});
    }
    el.style.display='flex'; el.style.alignItems='center';
    if(window._oltAlertaMin){   // MINIMIZADO/FECHADO: pill compacto PULSANTE (mantém o aviso) — clique expande
        el.style.padding='6px 11px'; el.style.cursor='pointer';
        el.innerHTML='<i class="fa-solid fa-triangle-exclamation" style="font-size:14px; color:#fecaca;"></i>'+
            '<span style="font-weight:800; font-size:12px; margin-left:7px;">'+alertas.length+' PON'+(alertas.length>1?'s':'')+' em queda</span>'+
            '<span style="font-size:10px; opacity:.8; margin-left:6px;">(abrir)</span>';
        return;
    }
    el.style.padding='8px 13px'; el.style.alignItems='flex-start';
    var MAX=6;
    var itens=alertas.slice(0,MAX).map(function(a){
        var nm=a.nome||_oltPortaNome(a.pon);
        var tp=(a.tipo==='los'?'LOS':'energia');
        return '<div style="display:flex; align-items:center; gap:6px; white-space:nowrap; line-height:1.5;">'+
            '<i class="fa-solid fa-circle" style="font-size:5px; color:#fecaca; flex:0 0 auto;"></i>'+
            '<span style="font-weight:700;">'+_oltEsc(a.pon)+'</span>'+
            (nm?'<span style="opacity:.92;">'+_oltEsc(nm)+'</span>':'')+
            '<span style="opacity:.8;">('+tp+')</span>'+
        '</div>';
    }).join('');
    var resto=alertas.length-Math.min(alertas.length,MAX);
    var _bstop='onmousedown="event.stopPropagation();" ontouchstart="event.stopPropagation();" ontouchend="event.stopPropagation();"';
    var ctrl='<div style="display:flex; flex-direction:column; gap:4px; margin-left:6px; flex:0 0 auto;" '+_bstop+'>'+
        '<button '+_bstop+' onclick="event.stopPropagation(); event.preventDefault(); oltAlertaMin(); return false;" title="Minimizar" style="cursor:pointer; width:22px; height:22px; border-radius:6px; border:1px solid rgba(255,255,255,.5); background:rgba(0,0,0,.15); color:#fff; font-size:14px; line-height:1; padding:0;">–</button>'+
        '<button '+_bstop+' onclick="event.stopPropagation(); event.preventDefault(); oltAlertaMin(); return false;" title="Fechar (fica um aviso pulsante)" style="cursor:pointer; width:22px; height:22px; border-radius:6px; border:1px solid rgba(255,255,255,.5); background:rgba(0,0,0,.15); color:#fff; font-size:12px; line-height:1; padding:0;"><i class="fa-solid fa-xmark"></i></button>'+
    '</div>';
    el.innerHTML='<span title="Arraste para mover" style="flex:0 0 auto; color:#fca5a5; font-size:11px; opacity:.8; margin-top:2px;"><i class="fa-solid fa-up-down-left-right"></i></span>'+
        '<i class="fa-solid fa-triangle-exclamation" style="font-size:14px; flex:0 0 auto; color:#fecaca; margin-top:1px;"></i>'+
        '<div style="min-width:0; flex:1 1 auto;" title="Clique para abrir a Atenção PON · arraste para mover">'+
            '<div style="white-space:nowrap; font-weight:800; font-size:12px; margin-bottom:3px;">'+alertas.length+' PON'+(alertas.length>1?'s':'')+' em queda total</div>'+
            '<div style="font-size:10.5px; font-weight:500; opacity:.95;">'+itens+
              (resto>0?'<div style="opacity:.8; margin-top:2px;">+'+resto+' outra'+(resto>1?'s':'')+'</div>':'')+
              '<div style="opacity:.75; margin-top:4px;">clique p/ ver</div>'+
            '</div>'+
        '</div>'+ctrl;
}
// Minimiza/fecha o alerta -> vira um pill pulsante (o aviso NÃO some). Maximiza volta ao box completo.
function oltAlertaMin(){ window._oltAlertaMin=true; _oltAtualizarAlertaPon(); }
function oltAlertaMax(){ window._oltAlertaMin=false; _oltAtualizarAlertaPon(); }
// No GERENCIADOR: usa os dados vivos (window._oltLista).
function _oltAtualizarAlertaPon(){ oltIniciarAlertaTopo(); if(window._oltLista&&window._oltLista.length){ _oltRenderAlertaPon(_oltPonsEmAlerta()); } }
function oltIniciarAlertaTopo(){ if(window._oltAlertaTopoTimer) return; window._oltAlertaTopoTimer=setInterval(function(){ try{ _oltAtualizarAlertaPon(); }catch(e){} }, 15000); }
// Poll do backend pon_alertas. IMPORTANTE: é este endpoint que detecta as
// transições (queda/normalização) e DISPARA as notificações (Telegram/WhatsApp).
// Por isso ele precisa rodar SEMPRE — inclusive com o Gerenciador aberto. Antes
// abortava quando o Gerenciador estava aberto, então o alerta aparecia na tela
// mas nada era notificado automaticamente.
function _oltMainAlertaPon(){
    fetch('olt_huawei.php?acao=pon_alertas').then(function(r){ return r.json(); }).then(function(d){
        if(!d||d.status!=='ok') return;
        window._oltAlertasSrv=d.alertas||[]; window._oltAlarmesSrv=d.alarmes||[]; try{ _oltBtnIntPulso(); }catch(e){}
        // Visual: com o Gerenciador aberto, ele já desenha pelos dados vivos.
        // Fechado (página principal), usamos a resposta do cache.
        if(!(window._oltLista&&window._oltLista.length)) _oltRenderAlertaPon(d.alertas||[]);
    }).catch(function(){});
}
// Liga o poll do alerta na página principal (roda sempre que a página carrega).
if(!window._oltMainAlertaTimer){ window._oltMainAlertaTimer=setInterval(function(){ try{ _oltMainAlertaPon(); }catch(e){} }, 30000); setTimeout(function(){ try{ _oltMainAlertaPon(); }catch(e){} }, 3500); }
// Agrupa as ONUs por situação de interrupção (base da janela "Atenção PON").
function _oltInterrupcaoDados(){
    var L=window._oltLista||[]; var portas={};
    L.forEach(function(o){ var p=o.fsp||''; if(!p) return; if(!portas[p]) portas[p]={total:0,los:0,off:0,des:0,on:0};
        var g=portas[p]; g.total++;
        var e=(o.estado||'').toLowerCase(); var isOn=(o.status||'').toLowerCase().indexOf('online')>-1;
        if(e==='los') g.los++; else if(e==='deactivated') g.des++; else if(!isOn) g.off++; else g.on++;
    });
    var losTotal=[], energia=[], losParcial=[];
    Object.keys(portas).forEach(function(p){ var g=portas[p]; var down=g.los+g.off;
        if(g.total>=3 && down>=g.total){ if(g.los>=g.off) losTotal.push({pon:p,qtd:g.total}); else energia.push({pon:p,qtd:g.total}); }
        else if(g.los>0){ losParcial.push({pon:p,qtd:g.los}); }
    });
    var byPon=function(a,b){ return String(a.pon).localeCompare(String(b.pon)); };
    losTotal.sort(byPon); energia.sort(byPon); losParcial.sort(byPon);
    var sinal=L.filter(function(o){ return _oltSinalClasse(o)==='ruim'; });
    var offNA=L.filter(function(o){ var e=(o.estado||'').toLowerCase(); var isOn=(o.status||'').toLowerCase().indexOf('online')>-1; return !isOn && e!=='los' && e!=='deactivated'; });
    return { losTotal:losTotal, energia:energia, losParcial:losParcial, sinal:sinal, offNA:offNA };
}
// Uma seção colapsável da janela Atenção PON.
function _oltIntSecao(ic,cor,titulo,itensHtml,qtd){
    var vazio=(qtd===0);
    var head='<div data-sec="'+_oltEsc(titulo)+'" onclick="_oltIntToggle(this)" style="cursor:pointer; display:flex; align-items:center; gap:10px; padding:12px 14px; border-bottom:1px solid '+OLTC.line+';">'+
        '<i class="fa-solid fa-caret-down oltIntCaret" style="color:'+OLTC.mut+'; transition:transform .15s; transform:rotate(-90deg);"></i>'+
        '<i class="fa-solid '+ic+'" style="color:'+cor+'; font-size:15px;"></i>'+
        '<span style="font-weight:800; color:'+OLTC.ink+'; flex:1 1 auto;">'+_oltEsc(titulo)+'</span>'+
        '<span style="font-size:11px; font-weight:800; color:#fff; background:'+(vazio?OLTC.grn:cor)+'; border-radius:20px; padding:2px 10px; min-width:22px; text-align:center;">'+(vazio?'<i class="fa-solid fa-check"></i>':qtd)+'</span>'+
    '</div>';
    // Sempre COLAPSADO por padrão — o conteúdo só aparece quando clica na seção.
    var corpo='<div style="display:none; padding:0;">'+
        (vazio?'<div style="text-align:center; padding:22px; color:'+OLTC.mut+';"><i class="fa-solid fa-circle-check" style="font-size:26px; color:'+OLTC.grn+';"></i><br><br>Tudo certo. Sem alertas ativos.</div>':itensHtml)+
    '</div>';
    return '<div style="border:1px solid '+OLTC.line+'; border-radius:10px; overflow:hidden; margin-bottom:10px; background:'+OLTC.bg2+';">'+head+corpo+'</div>';
}
function _oltIntLinhasPon(arr){ // linhas PON (clicáveis -> filtram a lista)
    return arr.map(function(a){ return '<div onclick="oltResumoFiltrar(\'fsp\',\''+_oltEsc(a.pon)+'\')" title="Filtrar a lista por esta PON" style="cursor:pointer; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:8px 10px; border-radius:8px;" onmouseover="this.style.background=\''+OLTC.panel+'\'" onmouseout="this.style.background=\'transparent\'">'+
        '<span style="font-family:monospace; font-weight:800; color:'+OLTC.txt+';"><i class="fa-solid fa-ethernet" style="color:'+OLTC.acc+';"></i> PON '+_oltEsc(a.pon)+(_oltPortaNome(a.pon)?(' <span style="font-family:inherit; color:'+OLTC.mut+'; font-weight:600;">· '+_oltEsc(_oltPortaNome(a.pon))+'</span>'):'')+'</span>'+
        '<span style="font-size:11px; font-weight:800; color:'+OLTC.acc+'; background:'+OLTC.acc+'22; border-radius:20px; padding:2px 10px;">'+a.qtd+' ONU'+(a.qtd>1?'s':'')+'</span>'+
    '</div>'; }).join('');
}
function _oltIntLinhasOnu(arr){ // linhas ONU (nome/serial) — com sinal entrada (↓Rx) e saída (↑Tx)
    return arr.slice(0,120).map(function(o){ var sig=(o.rx?(' · ↓'+_oltEsc((''+o.rx).replace(/\s*dBm/i,''))):'')+(o.tx?(' ↑'+_oltEsc((''+o.tx).replace(/\s*dBm/i,''))):''); return '<div style="display:flex; align-items:center; justify-content:space-between; gap:10px; padding:7px 10px; border-radius:8px;">'+
        '<span style="color:'+OLTC.txt+'; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(_oltNomeDe(o)||o.serial||'—')+'</span>'+
        '<span style="font-family:monospace; font-size:11px; color:'+OLTC.mut+'; white-space:nowrap;">'+_oltEsc(o.fsp||'')+sig+'</span>'+
    '</div>'; }).join('')+(arr.length>120?'<div style="text-align:center; color:'+OLTC.mut+'; font-size:11px; padding:6px;">… +'+(arr.length-120)+'</div>':'');
}
function _oltInterrupcaoConteudo(){
    var d=_oltInterrupcaoDados();
    var totalPon=d.losTotal.length+d.energia.length;
    // ALERTA DE TEMPERATURA DA OLT (>= 39 °C) — faixa vermelha fixa no topo desta página.
    var _tAl=''; var _st=window._oltStatus;
    if(_st && _st.temperatura){ var _tv=parseInt((''+_st.temperatura).replace(/[^0-9\-]/g,''),10);
        if(!isNaN(_tv) && _tv>=39){
            _tAl='<div style="display:flex; align-items:center; gap:10px; background:rgba(239,68,68,0.14); border:1px solid '+OLTC.red+'; border-radius:10px; padding:10px 12px; margin-bottom:10px;">'+
                '<i class="fa-solid fa-temperature-full" style="color:'+OLTC.red+'; font-size:18px;"></i>'+
                '<div style="flex:1 1 auto; min-width:0;"><div style="font-weight:800; color:'+OLTC.red+'; font-size:12.5px;">TEMPERATURA ALTA NA OLT — '+_oltEsc(_st.temperatura)+'</div>'+
                '<div style="font-size:11px; color:'+OLTC.mut+';">Limite de alerta: 39 °C. Verifique ventilação/refrigeração do rack.</div></div>'+
            '</div>';
        }
    }
    return '<div style="padding:12px;">'+_tAl+
        _oltIntSecao('fa-signal', OLTC.grn, 'Variações de sinal', _oltIntLinhasOnu(d.sinal), d.sinal.length)+
        _oltIntSecao('fa-sun', OLTC.amb, 'LOS parcial', _oltIntLinhasPon(d.losParcial), d.losParcial.length)+
        _oltIntSecao('fa-sun', OLTC.red, 'LOS total do PON', _oltIntLinhasPon(d.losTotal), d.losTotal.length)+
        _oltIntSecao('fa-plug-circle-xmark', OLTC.acc, 'Falha de energia', _oltIntLinhasPon(d.energia), d.energia.length)+
        _oltIntSecao('fa-circle-question', OLTC.mut, 'Offline N/A', _oltIntLinhasOnu(d.offNA), d.offNA.length)+
    '</div>';
}
// Abre/fecha SÓ a seção clicada (bug: antes o refresh reconstruía tudo e reabria "Variações de sinal").
function _oltIntToggle(head){ var b=head.nextElementSibling; if(!b) return; var abrir=(b.style.display==='none');
    b.style.display=abrir?'block':'none'; b.style.padding=abrir?'8px':'0';
    var c=head.querySelector('.oltIntCaret'); if(c) c.style.transform=abrir?'none':'rotate(-90deg)';
    // guarda o estado por título p/ sobreviver ao refresh
    window._oltIntAbertos=window._oltIntAbertos||{}; window._oltIntAbertos[head.getAttribute('data-sec')]=abrir;
}
function _oltInterrupcaoRefresh(){ var b=document.getElementById('oltIntBody'); if(!b || b.style.display==='none') return;
    // preserva quais seções estão abertas ANTES de reconstruir
    var abertos={}; Array.prototype.forEach.call(b.querySelectorAll('[data-sec]'), function(h){ var c=h.nextElementSibling; abertos[h.getAttribute('data-sec')]=(c && c.style.display!=='none'); });
    var sc=b.scrollTop; b.innerHTML=_oltInterrupcaoConteudo(); b.scrollTop=sc;
    // reaplica o estado (o que estava aberto continua aberto; o que estava fechado, fechado)
    Array.prototype.forEach.call(b.querySelectorAll('[data-sec]'), function(h){ var t=h.getAttribute('data-sec'); if(t in abertos){ var c=h.nextElementSibling; if(c){ c.style.display=abertos[t]?'block':'none'; c.style.padding=abertos[t]?'8px':'0'; var ca=h.querySelector('.oltIntCaret'); if(ca) ca.style.transform=abertos[t]?'none':'rotate(-90deg)'; } } });
}
// Janela DEDICADA "Atenção PON" (independente, com minimizar/maximizar/fechar).
// Entrada: se a lista da OLT ainda não estiver carregada (ex.: chamada da PÁGINA PRINCIPAL sem
// abrir o Gerenciador), carrega do CACHE antes de montar — assim mostra dados reais, não "tudo certo".
function oltInterrupcaoPon(){
    var atual=document.getElementById('oltIntWin'); if(atual){ atual.style.display='flex'; oltFrenteInt(); _oltInterrupcaoRefresh(); return; }
    if(!(window._oltLista&&window._oltLista.length)){
        fetch('olt_huawei.php?acao=cache_get').then(function(r){ return r.json(); }).then(function(d){
            if(d&&d.onus&&d.onus.length){ window._oltLista=d.onus;
                if(typeof _oltAplicarCadastro==='function') _oltAplicarCadastro();
                if(typeof _oltAplicarSmart==='function') try{ _oltAplicarSmart(); }catch(e){} }
            _oltInterrupcaoAbrir();
        }).catch(function(){ _oltInterrupcaoAbrir(); });
        return;
    }
    _oltInterrupcaoAbrir();
}
function _oltInterrupcaoAbrir(){
    var atual=document.getElementById('oltIntWin'); if(atual){ atual.style.display='flex'; oltFrenteInt(); return; }
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltIntWin';
    var _l=Math.max(8, Math.round((window.innerWidth/2)-320));
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:56px; left:'+_l+'px; width:min(96vw,640px); max-height:calc(100vh - 80px); display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.6); overflow:hidden;';
    win.onmousedown=function(){ oltFrenteInt(); };
    win.innerHTML=
      '<div id="oltIntHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); cursor:move;">'+
        '<button onclick="_oltVoltarCard(\'oltIntWin\')" title="Voltar (fecha e volta à tela anterior)" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-heart-crack" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0;"><div style="font-weight:800; color:#fff; font-size:13.5px;">Atenção PON</div><div style="font-size:10.5px; color:#fecaca;">Portas PON · ONU · quantidades — clique numa PON p/ filtrar</div></div>'+
        '<button onclick="oltIntMin()" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltIntMax()" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="var w=document.getElementById(\'oltIntWin\'); if(w) w.remove(); _oltRenderAlertaPon(window._oltAlertas||[]);" title="Fechar" style="'+_ctrl+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltIntNotif" style="flex:0 0 auto;"></div>'+
      '<div id="oltIntBody" style="flex:1 1 auto; overflow:auto;">'+_oltInterrupcaoConteudo()+'</div>';
    document.body.appendChild(win);
    _oltIntNotifStatus();
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltIntHead'));
    if(typeof oltResizify==='function') oltResizify(win, 380, 300);
}
// Faixa "Avisos WhatsApp/Telegram" na Atenção PON: mostra se está ATIVO, quantos destinatários e os
// últimos envios com o resultado real (enviado / falhou / motivo) — prova de que o alerta saiu.
function _oltIntNotifStatus(){
    var el=document.getElementById('oltIntNotif'); if(!el) return;
    fetch('olt_huawei.php?acao=notif_log').then(function(r){ return r.json(); }).then(function(d){
        if(!d||d.status!=='ok'){ el.innerHTML=''; return; }
        var cor=(d.ativo&&d.destinos)?OLTC.grn:OLTC.red;
        var st=!d.ativo?'DESATIVADOS — ative em Notificações da OLT':(!d.destinos?'ATIVOS, mas sem destinatário cadastrado':'ATIVOS · '+d.destinos+' destinatário'+(d.destinos>1?'s':''));
        var ult=(d.log||[]).slice(0,5).map(function(x){
            var ok=x.enviado&&x.ok>0&&!x.falha, cx=ok?OLTC.grn:(x.enviado&&x.ok>0?OLTC.amb:OLTC.red);
            var res=ok?'enviado':(x.motivo?x.motivo:(x.ok+' ok · '+x.falha+' falha'));
            return '<div style="display:flex; gap:6px; font-size:11px; padding:2px 0; color:'+OLTC.ink+';"><span style="color:'+OLTC.mut+'; white-space:nowrap;">'+_oltEsc(x.data||'')+'</span><span style="flex:1 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="'+_oltEsc(x.msg||'')+'">'+_oltEsc((x.msg||'').replace(/\s+/g,' '))+'</span><b style="color:'+cx+'; white-space:nowrap;">'+_oltEsc(res)+'</b></div>';
        }).join('');
        el.innerHTML='<div style="padding:8px 14px; border-bottom:1px solid '+OLTC.line+'; background:'+OLTC.panel+';">'+
            '<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;"><div style="font-size:11.5px; font-weight:800; color:'+cor+';"><i class="fa-brands fa-whatsapp"></i> <i class="fa-brands fa-telegram"></i> Avisos: '+_oltEsc(st)+'</div>'+
            // Acesso DIRETO à configuração dos avisos (antes só pelo Menu → Sistema ou Administração).
            (_oltNivel()>=3?'<button onclick="oltNotificacoes()" style="cursor:pointer; padding:3px 10px; border-radius:7px; border:1px solid '+cor+'; background:transparent; color:'+cor+'; font-size:11px; font-weight:800;"><i class="fa-solid fa-bell"></i> '+(d.ativo?'Configurar':'Ativar / configurar')+'</button>':'')+'</div>'+
            (ult?'<div style="margin-top:4px;">'+ult+'</div>':'<div style="font-size:11px; color:'+OLTC.mut+'; margin-top:3px;">Nenhum envio registrado ainda.</div>')+
        '</div>';
    }).catch(function(){});
}
function oltFrenteInt(){ var w=document.getElementById('oltIntWin'); if(w) w.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); }
function oltIntMin(){ _oltJanMin('oltIntWin','oltIntBody','Atenção PON','fa-heart-crack'); }
function oltIntMax(){ var w=document.getElementById('oltIntWin'); if(!w) return; var b=document.getElementById('oltIntBody'); if(b) b.style.display='block';
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|'); w.style.top=g[0]||'56px'; var rl=Math.max(8,Math.round((window.innerWidth/2)-320)); w.style.left=g[1]||(rl+'px'); w.style.width=g[2]||'min(96vw,640px)'; w.style.height=g[3]||''; w.style.maxHeight='calc(100vh - 80px)'; w.style.borderRadius='14px'; w.setAttribute('data-max','0'); }
    else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height); w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1'); } }
function _oltMonitorHtml(){
    var st=window._oltStatus||{}; var L=window._oltLista||[];
    var on=0,off=0,los=0,des=0,bom=0,ruim=0;
    L.forEach(function(o){ var e=(o.estado||'').toLowerCase(); var isOn=(o.status||'').toLowerCase().indexOf('online')>-1;
        if(e==='los')los++; else if(e==='deactivated')des++; else if(!isOn)off++; else on++;
        var sc=_oltSinalClasse(o); if(sc==='bom')bom++; else if(sc==='ruim')ruim++; });
    // fcol/fval: se passados, o card fica CLICÁVEL e filtra a lista (igual aos blocos de dimensão).
    var card=function(ic,rot,val,cor,fcol,fval){
        var clic=!!fcol;
        var oc=clic?(fcol==='__clear'?' onclick="oltResumoLimpar()"':' onclick="oltResumoFiltrar(\''+fcol+'\',\''+fval+'\')"'):'';
        var hov=clic?' onmouseover="this.style.borderColor=\''+cor+'\'" onmouseout="this.style.borderColor=\''+OLTC.line+'\'"':'';
        return '<div'+oc+(clic?' title="Filtrar a lista por isto"':'')+hov+' style="flex:1 1 130px; min-width:118px; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:11px 13px; display:flex; align-items:center; gap:11px;'+(clic?' cursor:pointer; transition:border-color .12s;':'')+'"><div style="width:34px; height:34px; flex:0 0 auto; border-radius:9px; background:'+cor+'22; display:flex; align-items:center; justify-content:center;"><i class="fa-solid '+ic+'" style="color:'+cor+'; font-size:15px;"></i></div><div style="min-width:0;"><div style="font-size:16px; font-weight:800; color:'+OLTC.ink+'; line-height:1.05; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+val+'</div><div style="font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; letter-spacing:.5px;">'+rot+'</div></div></div>';
    };
    return '<div style="margin-bottom:14px;">'+
        '<div style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.acc+'; margin-bottom:8px;"><i class="fa-solid fa-gauge-high"></i> Monitoramento da OLT</div>'+
        '<div style="display:flex; flex-wrap:wrap; gap:10px;">'+
          card('fa-server','OLT', _oltEsc(st.olt||'MA5683T'), OLTC.acc)+
          card('fa-clock','Uptime da OLT', _oltEsc(st.uptime||'—'), OLTC.grn)+
          (function(){ var tv=parseInt((''+(st.temperatura||'')).replace(/[^0-9\-]/g,''),10); var quente=(!isNaN(tv)&&tv>=39); return card('fa-temperature-half', quente?'Temperatura ⚠ ALTA':'Temperatura', _oltEsc(st.temperatura||'—'), quente?OLTC.red:OLTC.amb); })()+
          card('fa-diagram-project','Total', L.length, OLTC.acc, '__clear')+
          card('fa-circle-check','Online', on, OLTC.grn, 'status','online')+
          card('fa-circle-xmark','Offline/LOS', (off+los), OLTC.red, 'status','offline')+
          card('fa-power-off','Desativada', des, OLTC.mut, 'status','desativada')+
          card('fa-signal','Sinal Bom', bom, OLTC.grn, 'sinal','bom')+
          card('fa-triangle-exclamation','Sinal Ruim', ruim, OLTC.red, 'sinal','ruim')+
        '</div>'+
    '</div>';
}
// "Total" no topo: limpa o filtro e mostra a lista completa (recolhe o Resumo pro pill).
function oltResumoLimpar(){
    window._oltColF={}; window._oltColFVis=false; window._oltPag=1; oltRenderLista();
    var w=document.getElementById('oltResumoWin');
    if(w){ w.style.display='none';
        var pill=document.getElementById('oltResumoPill');
        if(!pill){ pill=document.createElement('button'); pill.id='oltResumoPill'; pill.className='oltMinPill';
            pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:2147483300; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#dc2626; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
            pill.innerHTML='<i class="fa-solid fa-chart-pie"></i> Abrir Resumo';
            pill.onclick=function(){ var ww=document.getElementById('oltResumoWin'); if(ww) ww.style.display='flex'; pill.remove(); _oltPillsArrumar(); };
            document.body.appendChild(pill);
        } else pill.style.display='flex';
        _oltPillsArrumar();
    }
}
function oltResumoFiltrar(col, valor){
    window._oltSel={};   // muda o filtro -> zera a seleção (nunca agir em ONU que saiu da tela)
    if(col==='status'){
        // Status usa a CATEGORIA precisa (mesma dos tiles do topo): online/offline/los/deactivated.
        // Evita "Offline" pegar LOS/Desativada e o "Desativada" (pt) não casar com "deactivated" (en).
        var map={online:'online', offline:'offline', los:'los', desativada:'deactivated', deactivated:'deactivated'};
        window._oltCat=map[(''+valor).toLowerCase()]||''; window._oltColF={}; window._oltColFVis=false; window._oltPag=1;
        window._oltRecentes=(window._oltCat==='online'); try{sessionStorage.setItem('oltCat',window._oltCat);}catch(e){}
    } else {
        window._oltColF=window._oltColF||{}; window._oltColF[col]=(valor==='(vazio)'?'':valor); window._oltColFVis=true; window._oltPag=1; window._oltCat='';
    }
    oltRenderLista();
    // REDIRECIONA de verdade: recolhe o Resumo pra um pill pra a lista filtrada aparecer (antes ele
    // cobria a tela maximizado e parecia que "não ia pra lugar nenhum").
    var w=document.getElementById('oltResumoWin');
    if(w){ w.style.display='none';
        var pill=document.getElementById('oltResumoPill');
        if(!pill){ pill=document.createElement('button'); pill.id='oltResumoPill'; pill.className='oltMinPill';
            pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:2147483300; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#dc2626; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
            pill.innerHTML='<i class="fa-solid fa-chart-pie"></i> Abrir Resumo';
            pill.onclick=function(){ var ww=document.getElementById('oltResumoWin'); if(ww) ww.style.display='flex'; pill.remove(); _oltPillsArrumar(); };
            document.body.appendChild(pill);
        } else pill.style.display='flex';
        _oltPillsArrumar();
    }
}
// Conteúdo (monitor + tarja + grade de contagem) — separado p/ poder RE-RENDERIZAR ao vivo.
// Conteúdo da janela "Portas ON/OFF": grade compacta de chips por PON física (ON/OFF + online/total + diferença).
// Clicar numa PON: filtra a lista E fecha a janela (senão, maximizada, ela tampava a lista filtrada).
function _oltPonFiltrar(fsp){ var w=document.getElementById('oltPonWin'); if(w) w.remove(); oltResumoFiltrar('fsp', fsp); }
// Clicar na QUANTIDADE de ONUs (badge) em "Gerenciar Portas PON": fecha o modal e redireciona
// pra lista já filtrada por esta PON (mesmo comportamento do Resumo / Portas ON/OFF).
function _oltPortaFiltrar(el, fsp){ var m=(el&&el.closest)?el.closest('.oltMSWin'):null; if(m) m.remove(); oltResumoFiltrar('fsp', fsp); }
function _oltPortasOnOffConteudo(){
    var L=window._oltLista||[]; var portas={};
    L.forEach(function(o){ var p=o.fsp||''; if(!p) return; if(!portas[p]) portas[p]={total:0,on:0}; portas[p].total++; if((o.status||'').toLowerCase().indexOf('online')>-1) portas[p].on++; });
    // TODAS as portas REAIS de cada placa (nº do placas_detect) — inclui as VAZIAS (reserva/sem ONU).
    (window._oltPlacasDet||[]).forEach(function(b){ if(b&&b.gpon){ var np=parseInt(b.portas,10)||0; for(var i=0;i<np;i++){ var f='0/'+b.slot+'/'+i; if(!portas[f]) portas[f]={total:0,on:0}; } } });
    if(!window._oltPlacasDet && !window._oltPonDetTried){ window._oltPonDetTried=1; var _pf=(typeof _oltFetchDireto==='function')?_oltFetchDireto('olt_huawei.php?acao=placas_detect',15000):fetch('olt_huawei.php?acao=placas_detect'); _pf.then(function(r){return r.json();}).then(function(d){ if(d&&d.placas&&d.placas.length){ window._oltPlacasDet=d.placas; if(typeof _oltPortasOnOffRefresh==='function') _oltPortasOnOffRefresh(); } }).catch(function(){}); }
    var fsps=Object.keys(portas).sort(function(a,b){ var pa=a.split('/'),pb=b.split('/'); return (+pa[1]-+pb[1])||(+pa[2]-+pb[2]); });
    var offCount=0; var porPlaca={}; var ordemPlaca=[];
    fsps.forEach(function(f){ var sl=(f.split('/')[1]||'?'); if(!porPlaca[sl]){ porPlaca[sl]=[]; ordemPlaca.push(sl); } porPlaca[sl].push(f); });
    var chip=function(f){ var g=portas[f]; var vazia=(g.total===0); var off=g.total-g.on; var isOn=g.on>0; if(!vazia && !isOn) offCount++; var nm=_oltPortaNome(f);
        var brd=vazia?OLTC.line:(isOn?OLTC.line:OLTC.red); var bg=vazia?OLTC.panel:(isOn?OLTC.bg2:'rgba(239,68,68,0.10)');
        var bcor=vazia?OLTC.mut:(isOn?OLTC.grn:OLTC.red); var btxt=vazia?'VAZIA':(isOn?'ON':'OFF');
        return '<div onclick="_oltPonFiltrar(\''+f+'\')" title="Filtrar a lista por esta PON" style="cursor:pointer; display:flex; flex-direction:column; gap:5px; padding:11px 13px; border-radius:11px; border:1px solid '+brd+'; background:'+bg+'; opacity:'+(vazia?'.72':'1')+'; transition:border-color .12s;" onmouseover="this.style.borderColor=\''+OLTC.acc+'\'" onmouseout="this.style.borderColor=\''+brd+'\'">'+
            '<div style="display:flex; align-items:center; gap:7px;">'+
              '<span style="font-size:10px; font-weight:800; color:#fff; background:'+bcor+'; border-radius:6px; padding:2px 8px;">'+btxt+'</span>'+
              '<span style="font-family:monospace; font-weight:800; font-size:13px; color:'+OLTC.txt+';">'+_oltEsc(f)+'</span>'+
            '</div>'+
            (nm?('<div style="font-size:11px; color:'+OLTC.mut+'; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(nm)+'</div>'):'')+
            (vazia?('<div style="font-size:12px; color:'+OLTC.mut+';">sem ONU (reserva)</div>')
                  :('<div style="font-size:12px;"><span style="color:'+OLTC.grn+'; font-weight:800;">'+g.on+'</span><span style="color:'+OLTC.mut+';"> online · '+g.total+' total</span>'+(off>0?(' · <span style="color:'+OLTC.red+'; font-weight:800;">'+off+' off</span>'):'')+'</div>'))+
        '</div>';
    };
    var blocos=ordemPlaca.map(function(sl){ var ap=_oltPlacaNome(sl);
        var cards=porPlaca[sl].map(chip).join('');
        return '<div style="margin-bottom:14px;">'+
            '<div style="display:flex; align-items:center; gap:8px; margin-bottom:8px; padding-bottom:5px; border-bottom:1px solid '+OLTC.line+';">'+
              '<i class="fa-solid fa-server" style="color:'+OLTC.acc+';"></i>'+
              '<span style="font-weight:800; font-size:13px; color:'+OLTC.ink+';">Placa '+_oltEsc(sl)+(ap?(' — '+_oltEsc(ap)):'')+'</span>'+
              '<span style="font-size:10.5px; color:'+OLTC.mut+';">'+porPlaca[sl].length+' portas</span>'+
            '</div>'+
            '<div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(210px,1fr)); gap:10px;">'+cards+'</div>'+
        '</div>';
    }).join('');
    return '<div style="padding:12px 16px; display:flex; align-items:center; gap:10px; border-bottom:1px solid '+OLTC.line+'; position:sticky; top:0; background:'+OLTC.bg+'; z-index:2;">'+
            '<span style="font-size:12px; font-weight:800; color:'+OLTC.ink+';">'+fsps.length+' portas PON</span>'+
            (offCount>0?('<span style="font-size:11px; font-weight:800; color:#fff; background:'+OLTC.red+'; border-radius:20px; padding:2px 10px;">'+offCount+' OFF</span>'):'<span style="font-size:11px; font-weight:800; color:#fff; background:'+OLTC.grn+'; border-radius:20px; padding:2px 10px;">todas ON</span>')+
            '<span style="flex:1 1 auto;"></span><span style="font-size:10px; color:'+OLTC.acc+';"><i class="fa-solid fa-hand-pointer"></i> clique numa porta p/ filtrar</span>'+
        '</div>'+
        '<div style="padding:14px 16px;">'+(blocos||'<div style="color:'+OLTC.mut+';">Sem portas.</div>')+'</div>';
}
function _oltFrentePon(){ var w=document.getElementById('oltPonWin'); if(w) w.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); }
function _oltPortasOnOffRefresh(){ var b=document.getElementById('oltPonBody'); if(!b || b.style.display==='none') return; var sc=b.scrollTop; b.innerHTML=_oltPortasOnOffConteudo(); b.scrollTop=sc; }
function oltPortasOnOff(){
    var atual=document.getElementById('oltPonWin'); if(atual){ atual.style.display='flex'; _oltFrentePon(); _oltPortasOnOffRefresh(); return; }
    if(!(window._oltLista&&window._oltLista.length)){
        fetch('olt_huawei.php?acao=cache_get').then(function(r){return r.json();}).then(function(d){ if(d&&d.onus&&d.onus.length){ window._oltLista=d.onus; if(typeof _oltAplicarCadastro==='function') _oltAplicarCadastro(); } _oltPortasOnOffAbrir(); }).catch(function(){ _oltPortasOnOffAbrir(); });
        return;
    }
    _oltPortasOnOffAbrir();
}
function _oltPortasOnOffAbrir(){
    var atual=document.getElementById('oltPonWin'); if(atual){ atual.style.display='flex'; _oltFrentePon(); return; }
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltPonWin';
    var _l=Math.max(8, Math.round((window.innerWidth/2)-430));
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:56px; left:'+_l+'px; width:min(96vw,860px); max-height:calc(100vh - 80px); display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.6); overflow:hidden;';
    win.onmousedown=function(){ _oltFrentePon(); };
    win.innerHTML=
      '<div id="oltPonHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); cursor:move;">'+
        '<button onclick="_oltVoltarCard(\'oltPonWin\')" title="Voltar" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-plug-circle-bolt" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0;"><div style="font-weight:800; color:#fff; font-size:13.5px;">Portas ON/OFF</div><div style="font-size:10.5px; color:var(--text-secondary);">Online × Offline por porta · clique p/ filtrar</div></div>'+
        '<button onclick="oltPonMin()" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltPonMax()" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="var w=document.getElementById(\'oltPonWin\'); if(w) w.remove();" title="Fechar" style="'+_ctrl+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltPonBody" style="flex:1 1 auto; overflow:auto;">'+_oltPortasOnOffConteudo()+'</div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltPonHead'));
    if(typeof oltResizify==='function') oltResizify(win, 380, 300);
}
function oltPonMin(){ _oltJanMin('oltPonWin','oltPonBody','Portas ON/OFF','fa-plug-circle-bolt'); }
function oltPonMax(){ var w=document.getElementById('oltPonWin'); if(!w) return; var b=document.getElementById('oltPonBody'); if(b) b.style.display='block';
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|'); w.style.top=g[0]||'56px'; var rl=Math.max(8,Math.round((window.innerWidth/2)-330)); w.style.left=g[1]||(rl+'px'); w.style.width=g[2]||'min(96vw,660px)'; w.style.height=g[3]||''; w.style.maxHeight='calc(100vh - 80px)'; w.style.borderRadius='14px'; w.setAttribute('data-max','0'); }
    else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height); w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1'); } }
function _oltResumoConteudo(){
    var dims=[
        {t:'Placa', ic:'fa-server', col:'fsp', f:function(o){ var p=(o.fsp||'').split('/'); if(!p[1])return '—'; var ap=_oltPlacaNome(p[1]); return 'Placa '+p[1]+(ap?(' — '+ap):''); }, v:function(k){ var m=k.match(/Placa\s+(\d+)/); return m?('0/'+m[1]+'/'):''; }},
        {t:'Porta PON', ic:'fa-ethernet', col:'pon', f:function(o){ var p=(o.fsp||'').split('/'); return p[2]!=null&&p[2]!==''?('Porta '+p[2]):'—'; }, v:function(k){ return k.replace('Porta ',''); }},
        {t:'VLAN', ic:'fa-network-wired', col:'vlan', f:function(o){ var v=o.vlan||''; if(!v) return '(sem VLAN)'; var nm=_oltVlanNome(v); return v+(nm?(' — '+nm):''); }, v:function(k){ return (k.match(/\d+/)||[''])[0]; }},
        {t:'Zona', ic:'fa-map-location-dot', col:'zona', f:function(o){ return o.zona||'(sem zona)'; }, v:function(k){ return k==='(sem zona)'?'':k; }},
        {t:'Modelo', ic:'fa-microchip', col:'modelo', f:function(o){ return o.modelo||'(sem modelo)'; }, v:function(k){ return k==='(sem modelo)'?'':k; }},
        {t:'Tipo', ic:'fa-diagram-project', col:'tipo', f:function(o){ var tp=_oltTipoDe(o); return tp==='ONU'?'ONU · Bridge':(tp==='ONT'?'ONT · Router':'(indefinido)'); }, v:function(k){ return k.indexOf('ONU')>-1?'ONU':(k.indexOf('ONT')>-1?'ONT':''); }},
        {t:'Status', ic:'fa-circle-dot', col:'status', f:function(o){ var e=(o.estado||'').toLowerCase(); if(e==='los')return 'LOS'; if(e==='deactivated')return 'Desativada'; if(e==='offline')return 'Offline'; return (o.status||'').toLowerCase().indexOf('online')>-1?'Online':'Offline'; }, v:function(k){ return k.toLowerCase(); }},
        {t:'Sinal', ic:'fa-signal', col:'sinal', f:function(o){ var s=_oltSinalClasse(o); return s==='bom'?'Bom':(s==='ruim'?'Ruim':'(sem luz / offline)'); }, v:function(k){ return k==='Bom'?'bom':(k==='Ruim'?'ruim':''); }}
    ];
    var corpo=dims.map(function(d){
        var r=_oltContarPor(d.f);
        if(d.col==='tipo'){ r.arr=r.arr.filter(function(it){ return it.k!=='(indefinido)'; }); } // remove card "Indefinido"
        var linhas=r.arr.map(function(it){
            var alvo=d.v(it.k); var clicavel=(alvo!==''&&alvo!=null);
            var clic=clicavel?(' onclick="oltResumoFiltrar(\''+d.col+'\',\''+_oltEsc((''+alvo).replace(/'/g,''))+'\')"'):'';
            return '<div'+clic+' title="'+(clicavel?'Filtrar a lista por isto':'')+'" style="display:flex; align-items:center; justify-content:space-between; gap:10px; padding:6px 8px; border-radius:8px; '+(clicavel?'cursor:pointer;':'')+' transition:background .12s;"'+(clicavel?' onmouseover="this.style.background=\''+OLTC.panel+'\'" onmouseout="this.style.background=\'transparent\'"':'')+'>'+
                '<span style="color:'+OLTC.txt+'; font-size:12.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(it.k)+'</span>'+
                '<span style="flex:0 0 auto; min-width:24px; text-align:center; background:#ffffff; color:#334155; border:1px solid rgba(0,0,0,.12); box-shadow:0 1px 2px rgba(0,0,0,.10); font-weight:800; font-size:11.5px; padding:2px 9px; border-radius:20px;">'+it.n+'</span>'+
            '</div>';
        }).join('');
        var _tam=window._oltResumoTam||(window._oltResumoTam=_oltResumoTamLoad()); return '<div class="oltDimCard" data-col="'+d.col+'" style="flex:1 1 '+_tam.w+'px; height:'+_tam.h+'px; resize:vertical; overflow:hidden; display:flex; flex-direction:column; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:12px; min-width:150px; min-height:130px;">'+
            '<div style="flex:0 0 auto; display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 12px; background:'+OLTC.panel+'; border-bottom:1px solid '+OLTC.line+';">'+
              '<span style="display:inline-flex; align-items:center; gap:8px; font-size:11.5px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.ink+';"><span style="flex:0 0 auto; width:24px; height:24px; border-radius:50%; background:#ffffff; box-shadow:0 1px 2px rgba(0,0,0,.18); display:inline-flex; align-items:center; justify-content:center;"><i class="fa-solid '+(d.ic||'fa-list')+'" style="color:'+OLTC.acc+'; font-size:12px;"></i></span>'+d.t+'</span>'+
              '<span style="display:inline-flex; align-items:center; gap:6px;">'+
                (d.col==='vlan'?'<button onclick="event.stopPropagation(); oltGerenciarVlans();" title="Editar nomes das VLANs" style="cursor:pointer; border:1px solid '+OLTC.line+'; background:'+OLTC.bg2+'; color:'+OLTC.acc+'; border-radius:6px; width:22px; height:22px; font-size:10px; padding:0;"><i class="fa-solid fa-pen"></i></button>':'')+
                (d.col==='zona'?'<button onclick="event.stopPropagation(); oltGerenciarZonas();" title="Editar nomes das Zonas" style="cursor:pointer; border:1px solid '+OLTC.line+'; background:'+OLTC.bg2+'; color:'+OLTC.acc+'; border-radius:6px; width:22px; height:22px; font-size:10px; padding:0;"><i class="fa-solid fa-pen"></i></button>':'')+
                '<span style="font-size:10px; color:'+OLTC.mut+'; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; padding:1px 8px; border-radius:20px; white-space:nowrap;">'+r.arr.length+'</span>'+
              '</span>'+
            '</div>'+
            '<div style="flex:1 1 auto; min-height:0; overflow:auto; padding:6px;">'+linhas+'</div>'+
        '</div>';
    }).join('');
    // Seção VERMELHA de alerta no topo do Resumo — PONs em queda total (clicável p/ filtrar).
    // (A faixa vermelha de "PONs em queda" foi REMOVIDA daqui — já existe o botão "Atenção PON".)
    // Envolve tudo num flex-column que ocupa 100% da altura -> quando maximizado (ou janela alta),
    // o grid de dimensoes ESTICA e preenche a tela toda (sem sobrar o vazio preto embaixo).
    return '<div style="display:flex; flex-direction:column; min-height:100%; box-sizing:border-box;">'+
        _oltMonitorHtml()+
        '<div style="flex:0 0 auto; display:flex; align-items:center; gap:10px; margin:4px 0 14px; padding-top:12px; border-top:1px solid '+OLTC.line+';">'+
          '<span style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.acc+'; white-space:nowrap;"><i class="fa-solid fa-layer-group"></i> Contagem por dimensão</span>'+
          '<button onclick="window._oltResumoOrigem=true; oltInterrupcaoPon()" title="Abrir Atenção PON (portas em queda, LOS, energia)" style="flex:0 0 auto; cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.redf+'; background:'+OLTC.redf+'24; color:'+OLTC.redf+'; font-size:11px; font-weight:800; white-space:nowrap;"><i class="fa-solid fa-heart-crack"></i> Atenção PON</button>'+
          '<button onclick="window._oltResumoOrigem=true; oltPortasOnOff()" title="Comparativo Online/Offline por porta (ON/OFF)" style="flex:0 0 auto; cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:'+OLTC.acc+'1f; color:'+OLTC.acc+'; font-size:11px; font-weight:800; white-space:nowrap;"><i class="fa-solid fa-plug-circle-bolt"></i> Portas ON/OFF</button>'+
          '<span style="flex:1 1 auto; height:1px; background:'+OLTC.line+';"></span>'+
          '<span style="font-size:10px; color:'+OLTC.acc+'; font-weight:700; white-space:nowrap;"><i class="fa-solid fa-hand-pointer"></i> clique num item para filtrar a lista</span>'+
        '</div>'+
        // Container FLEX-WRAP: cada bloco tem tamanho PRÓPRIO e é REDIMENSIONÁVEL (alça no canto
        // inferior direito — resize:both). O tamanho que você escolher fica salvo e o conteúdo rola
        // por dentro. Os cards quebram linha responsivamente.
'<div style="flex:1 1 auto; min-height:0; display:flex; flex-wrap:wrap; gap:10px; align-content:flex-start;">'+corpo+'</div>'+
    '</div>';
}
// Re-renderiza o conteúdo do Resumo AO VIVO (sem recriar a janela), preservando o scroll.
function _oltResumoRefresh(){
    var w=document.getElementById('oltResumoWin'), b=document.getElementById('oltResumoBody'); if(!w||!b) return;
    if(b.style.display==='none') return; // minimizado: não mexe
    var foco=document.activeElement; if(foco && b.contains(foco)) return; // não atrapalha se estiver interagindo
    var sc=b.scrollTop; b.innerHTML=_oltResumoConteudo(); b.scrollTop=sc;
    _oltResumoAttachResize();
}
// Guarda o tamanho que você deu a cada bloco (por dimensão) e reaplica após cada atualização,
// pra o tamanho escolhido NÃO resetar quando o Resumo re-renderiza no sync.
// Geometria da JANELA do Resumo (posição/tamanho/maximizado): gravada no navegador.
function _oltResumoGeoSave(){ var w=document.getElementById('oltResumoWin'); if(!w) return;
    // "Maximizado" é decidido pelo TAMANHO REAL (não pelo atributo): se você arrastou
    // o canto e diminuiu, salva como tamanho custom (max:0) — e reabre nesse tamanho.
    var isMax=(w.offsetWidth>=window.innerWidth-6 && w.offsetHeight>=window.innerHeight-6);
    // NÃO grava estado colapsado/minimizado (senão reabre achatado a 2px). Só salva tamanho sano.
    if(!isMax && (w.offsetWidth<300 || w.offsetHeight<200)) return;
    if(!isMax) w.setAttribute('data-max','0');
    try{ localStorage.setItem('oltResumoGeo', JSON.stringify({ top:w.style.top, left:w.style.left, width:(w.style.width||w.offsetWidth+'px'), height:w.offsetHeight+'px', max:isMax?1:0 })); }catch(e){} }
function _oltResumoGeoLoad(){ try{ var s=localStorage.getItem('oltResumoGeo'); if(s){ var o=JSON.parse(s); if(o) return o; } }catch(e){} return null; }
// Tamanho dos blocos: fica GRAVADO no navegador (localStorage) — sobrevive ao reload/F5.
function _oltResumoTamLoad(){ try{ var s=localStorage.getItem('oltResumoTam'); if(s){ var o=JSON.parse(s); if(o&&o.h>0) return {w:(o.w||220), h:o.h}; } }catch(e){} return {w:220,h:280}; }
function _oltResumoTamSave(){ try{ localStorage.setItem('oltResumoTam', JSON.stringify(window._oltResumoTam||{w:220,h:280})); }catch(e){} }
function _oltResumoAttachResize(){
    var b=document.getElementById('oltResumoBody'); if(!b) return;
    if(typeof ResizeObserver==='undefined') return;
    window._oltResumoTam=window._oltResumoTam||_oltResumoTamLoad();
    if(window._oltResumoRO){ try{ window._oltResumoRO.disconnect(); }catch(e){} }
    window._oltResumoRO=new ResizeObserver(function(ents){
        if(window._oltResumoAplicando) return;       // já estou aplicando nos irmãos: ignora
        var el=ents[ents.length-1].target;            // o bloco que você acabou de arrastar (só ALTURA)
        var h=Math.round(el.offsetHeight);
        if(h===window._oltResumoTam.h) return;        // altura não mudou
        window._oltResumoTam.h=h;                     // ALTURA ÚNICA p/ todos (largura preenche sozinha)
        _oltResumoTamSave();                          // GRAVA o tamanho escolhido (persiste no F5)
        window._oltResumoAplicando=true;
        var cards=document.querySelectorAll('#oltResumoBody .oltDimCard');
        for(var i=0;i<cards.length;i++){ cards[i].style.height=h+'px'; }
        requestAnimationFrame(function(){ window._oltResumoAplicando=false; }); // libera após aplicar
    });
    var cards=b.querySelectorAll('.oltDimCard'); for(var i=0;i<cards.length;i++){ window._oltResumoRO.observe(cards[i]); }
    // REFORÇO: ao soltar o mouse, lê a altura REAL dos blocos e grava. Não depende do
    // ResizeObserver (que em alguns navegadores não dispara no fim do arraste da alça).
    if(!window._oltResumoMouseUp){
        window._oltResumoMouseUp=function(){
            var bb=document.getElementById('oltResumoBody'); if(!bb) return;
            var cs=bb.querySelectorAll('.oltDimCard'); if(!cs.length) return;
            var maior=0; for(var k=0;k<cs.length;k++){ var hh=Math.round(cs[k].offsetHeight); if(hh>maior) maior=hh; }
            if(maior>60 && maior!==(window._oltResumoTam&&window._oltResumoTam.h)){
                window._oltResumoTam=window._oltResumoTam||_oltResumoTamLoad(); window._oltResumoTam.h=maior; _oltResumoTamSave();
                for(var j=0;j<cs.length;j++){ cs[j].style.height=maior+'px'; }
            }
        };
        document.addEventListener('mouseup', window._oltResumoMouseUp);
    }
}
// Voltar de uma janela aberta a partir do Resumo: fecha e REABRE o Resumo (se veio dele).
function _oltVoltarCard(winId){
    var w=document.getElementById(winId); if(w) w.remove();
    if(typeof _oltRenderAlertaPon==='function'){ try{ _oltRenderAlertaPon(window._oltAlertas||[]); }catch(e){} }
    if(window._oltResumoOrigem){ window._oltResumoOrigem=false;
        var rw=document.getElementById('oltResumoWin');
        if(rw){ rw.style.display='flex'; rw.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1);
            var pp=document.getElementById('oltResumoPill'); if(pp) pp.remove(); }
        else if(typeof oltResumoContagem==='function') oltResumoContagem();
    }
}
function oltResumoContagem(){
    // JANELA FLUTUANTE (não bloqueia a página — dá pra abrir outros ícones/janelas junto), arrastável.
    var atual=document.getElementById('oltResumoWin'); if(atual) atual.remove();
    oltCarregarStatus(); // atualiza uptime/temperatura ao abrir
    var _ctrl='cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id='oltResumoWin';
    var _rwL2=Math.max(8, Math.round((window.innerWidth/2)-470)); // pixel inteiro: texto nitido (sem meio-pixel do calc)
    win.style.cssText='position:fixed; z-index:2147482000; top:50px; left:'+_rwL2+'px; width:min(96vw,940px); max-height:calc(100vh - 66px); display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.55); overflow:hidden;';
    win.onmousedown=function(){ win.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); }; // contador próprio (não cai atrás)
    win.innerHTML=
      '<div id="oltResumoHead" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); cursor:move;">'+
        '<button onclick="var w=document.getElementById(\'oltResumoWin\'); if(w) w.remove(); var p=document.getElementById(\'oltResumoPill\'); if(p) p.remove();" title="Voltar (fecha e volta à tela anterior)" style="cursor:pointer; border:none; background:transparent; color:rgba(255,255,255,0.92); font-size:15px; padding:2px 4px;"><i class="fa-solid fa-arrow-left"></i></button>'+
        '<i class="fa-solid fa-chart-pie" style="color:#fff; font-size:15px;"></i>'+
        '<div style="flex:1 1 auto; min-width:0;"><div style="font-weight:800; color:#fff; font-size:13.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">Resumo — equipamentos por dimensão</div><div style="font-size:10.5px; color:var(--text-secondary);">atualiza automático · clique num item para filtrar</div></div>'+
        '<button onclick="oltResumoMin()" title="Minimizar" style="'+_ctrl+'"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltResumoMax()" title="Maximizar / Restaurar" style="'+_ctrl+'"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="var w=document.getElementById(\'oltResumoWin\'); if(w) w.remove(); var p=document.getElementById(\'oltResumoPill\'); if(p) p.remove();" title="Fechar" style="'+_ctrl+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltResumoBody" style="flex:1 1 auto; overflow:auto; padding:14px;">'+_oltResumoConteudo()+'</div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltResumoHead'));
    oltResizify(win, 380, 280); // arrastar o canto p/ aumentar/diminuir
    // GEOMETRIA GRAVADA: reabre do jeito que você deixou (posição/tamanho/maximizado).
    var _g=_oltResumoGeoLoad();
    // Blindagem: só restaura tamanho custom se for SANO (>=300x200). Geometria minúscula
    // salva por engano (ex.: janela colapsada a 2px) é ignorada -> abre MAXIMIZADO.
    var _gw=parseInt((_g&&_g.width)||'0',10)||0, _gh=parseInt((_g&&_g.height)||'0',10)||0;
    if(_g && !_g.max && _gw>=300 && _gh>=200){ win.style.top=_g.top||'50px'; win.style.left=_g.left||(_rwL2+'px'); win.style.width=_g.width; win.style.height=_g.height; win.style.maxHeight='none'; win.setAttribute('data-max','0'); }
    else { oltResumoMax(); } // 1ª vez, salvo maximizado, ou geometria inválida -> tela cheia
    // Salva a geometria ao redimensionar/arrastar (debounce).
    if(typeof ResizeObserver!=='undefined'){ if(window._oltResumoWinRO){ try{ window._oltResumoWinRO.disconnect(); }catch(e){} }
        window._oltResumoWinRO=new ResizeObserver(function(){ clearTimeout(window._oltResumoGeoT); window._oltResumoGeoT=setTimeout(_oltResumoGeoSave, 400); });
        window._oltResumoWinRO.observe(win); }
    // Grava também ao ARRASTAR (mover não dispara o ResizeObserver).
    win.addEventListener('mouseup', function(){ clearTimeout(window._oltResumoGeoT); window._oltResumoGeoT=setTimeout(_oltResumoGeoSave, 200); });
    win.addEventListener('mouseup', function(){ setTimeout(_oltResumoGeoSave, 60); });
    _oltResumoAttachResize(); // liga o salvar-tamanho dos blocos redimensionáveis
    // Refresh do uptime/temperatura a cada 30s enquanto o Resumo estiver aberto (as contagens
    // já atualizam junto com o sync via _oltResumoRefresh no oltRenderLista).
    if(window._oltResumoStatusTimer) clearInterval(window._oltResumoStatusTimer);
    window._oltResumoStatusTimer=setInterval(function(){ if(!document.getElementById('oltResumoWin')){ clearInterval(window._oltResumoStatusTimer); window._oltResumoStatusTimer=null; return; } oltCarregarStatus(); }, 30000);
}
function oltResumoMin(id){ _oltJanMin('oltResumoWin','oltResumoBody','Resumo','fa-chart-pie'); }
function oltResumoMax(){ var w=document.getElementById('oltResumoWin'); if(!w) return; var b=document.getElementById('oltResumoBody'); if(b) b.style.display='block';
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|'); w.style.top=g[0]||'70px'; w.style.left=g[1]||'max(8px, calc(50% - 470px))'; w.style.width=g[2]||'min(96vw,940px)'; w.style.height=g[3]||''; w.style.maxHeight='86vh'; w.style.borderRadius='14px'; w.setAttribute('data-max','0'); }
    else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height); w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1'); }
    _oltResumoGeoSave(); }
function oltRenderLista(progresso){
    _oltUptimeTimerOn();   // cronômetro do uptime ao vivo (liga 1x)
    if(window._oltModeloImgKeys==null){ window._oltModeloImgKeys=[]; oltCarregarModeloImgs(); } // fotos dos modelos (1x)
    if(window._oltModelos==null){ window._oltModelos={}; _oltModelosCarregar(function(){ oltRenderLista(); }); } // nomes/tipos por modelo (1x)
    window._oltLista=_oltDedup(window._oltLista||[]); // garante contagem única
    _oltAplicarSmart();                                // VLAN/tipo/zona do SmartOLT
    _oltAplicarCadastro();                             // banco local (zona editada) sempre vence
    var todas=window._oltLista;
    // Registra a PRIMEIRA VEZ que cada ONU aparece -> base do "Recentes" (últimos aprovisionados). Persistente.
    (function(){ try{ var vis=JSON.parse(localStorage.getItem('oltVisto')||'{}')||{}; var mud=false, agora=Date.now();
        // Chave = SERIAL do aparelho (_oltVistoKey). Era "F/S/P|ID": ONU nova instalada na mesma porta
        // de uma ONT retirada herdava a data antiga ("como se fosse de X dias atrás").
        todas.forEach(function(o){ var k=_oltVistoKey(o); if(k && k!=='|' && !vis[k]){ vis[k]=agora; mud=true; } });
        if(mud){ try{ localStorage.setItem('oltVisto', JSON.stringify(vis)); }catch(e){} } window._oltVisto=vis;
        // SINCRONIZA com o servidor (1x por carga): manda o que este navegador sabe e recebe o mapa comum
        // (menor data de cada ONU) — IP, domínio e outros computadores passam a ter a MESMA ordem Recentes.
        if(!window._oltVistoSync){ window._oltVistoSync=true;
            fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=visto_sync&vis='+encodeURIComponent(JSON.stringify(vis))})
              .then(function(r){ return r.json(); }).then(function(d){ if(d&&d.vis){ var v=window._oltVisto||{}; Object.keys(d.vis).forEach(function(k){ var t=+d.vis[k]; if(t>0 && (!v[k] || t<v[k])) v[k]=t; });
                  window._oltVisto=v; try{ localStorage.setItem('oltVisto', JSON.stringify(v)); }catch(e){} if(oltGerenciadorAberto()) oltRenderLista(); } }).catch(function(){ window._oltVistoSync=false; }); }
    }catch(e){ window._oltVisto=window._oltVisto||{}; } })();
    // Data REAL de autorização (p/ Ativação e Recentes). Carrega 1x e re-renderiza.
    if(!window._oltAutoriz){ window._oltAutoriz={}; try{ fetch('olt_huawei.php?acao=auth_get').then(function(r){return r.json();}).then(function(d){ if(d&&d.autoriz){ window._oltAutoriz=d.autoriz; if(oltGerenciadorAberto()) oltRenderLista(); } }).catch(function(){}); }catch(e){} }
    var wt=document.getElementById('oltWinTitle'); if(wt) wt.textContent='Wellsystem OLT — Monitoramento GPON';
    var ws=document.getElementById('oltWinSub');
    if(ws){ var st=window._oltStatus; if(st){ var t=[''+(st.olt||'OLT')];
        if(st.versao) t.push('🧩 '+st.versao);
        if(st.uptime){ var _up=(''+st.uptime).replace(/system\s+up\s*time\s*:?/i,'').replace(/\s*days?/gi,'d').replace(/\s*hours?/gi,'h').replace(/\s*minutes?/gi,'m').replace(/\s*seconds?/gi,'s').replace(/\s+/g,' ').trim(); t.push('⏱ '+_up); }
        if(st.temperatura){ var _tv=parseInt((''+st.temperatura).replace(/[^0-9\-]/g,''),10); t.push((!isNaN(_tv)&&_tv>=39?'🌡⚠ ':'🌡 ')+st.temperatura); }
        ws.innerHTML=_oltEsc(t.join('  ·  ')); } else { ws.textContent='OLT'; } }
    _oltAtualizarValida();
    function _cat(o){ if(_oltEhInicializando(o)) return 'offline'; var e=(o.estado||'').toLowerCase(); if(e) return e; return (o.status||'').toLowerCase().indexOf('online')>-1?'online':'offline'; }
    var cnt={online:0,offline:0,los:0,deactivated:0}, onuC=0, ontC=0, sBom=0, sRuim=0;
    todas.forEach(function(o){ var c=_cat(o); if(cnt[c]==null)cnt[c]=0; cnt[c]++; var tp=_oltTipoDe(o); if(tp==='ONU')onuC++; else if(tp==='ONT')ontC++; var sc=_oltSinalClasse(o); if(sc==='bom')sBom++; else if(sc==='ruim')sRuim++; });
    var idadeTxt = (window._oltCacheIdade!=null && !progresso) ? (' · cache '+_oltIdade(window._oltCacheIdade)) : '';
    var cat=window._oltCat||'';

    var barra=(!progresso && typeof _oltAvisoSlots==='function' ? _oltAvisoSlots() : '') + (progresso ? '<div style="display:flex; align-items:center; gap:8px; background:rgba(56,189,248,0.12); border:1px solid rgba(56,189,248,0.35); border-radius:8px; padding:8px 12px; margin-bottom:12px; font-size:12px; color:'+OLTC.acc+';"><i class="fa-solid fa-spinner fa-spin"></i> '+_oltEsc(progresso)+' ('+todas.length+' até agora)</div>' : '');

    var tiles='<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(118px,1fr)); gap:6px; margin-bottom:10px;">'+   // cards em linha (_oltTile)
        _oltBotaoAprov()+
        _oltTile('Total'+idadeTxt, todas.length, OLTC.amb, 'fa-diagram-project', 'TODOS', cat==='')+
        _oltTile('Online', cnt.online, OLTC.grn, 'fa-circle-check', 'online', cat==='online')+
        _oltTile('Offline', cnt.offline, OLTC.red, 'fa-circle-xmark', 'offline', cat==='offline')+
        _oltTile('LOS', cnt.los, OLTC.red, 'fa-bolt', 'los', cat==='los')+
        _oltTile('Desativada', cnt.deactivated, OLTC.mut, 'fa-power-off', 'deactivated', cat==='deactivated')+
        _oltTile('ONU·Bridge', onuC, OLTC.acc, 'fa-ethernet', 'tipo:ONU', cat==='tipo:ONU')+
        _oltTile('ONT·Router', ontC, OLTC.vio, 'fa-wifi', 'tipo:ONT', cat==='tipo:ONT')+
        _oltTile('Sinal Bom', sBom, OLTC.grn, 'fa-signal', 'sinal:bom', cat==='sinal:bom')+
        _oltTile('Sinal Ruim', sRuim, OLTC.red, 'fa-triangle-exclamation', 'sinal:ruim', cat==='sinal:ruim')+
    '</div>';

    if(todas.length===0){
        // INSTALAÇÃO NOVA: o backend respondeu "nao_configurado" -> orienta a configurar
        // em vez de mandar varrer uma OLT que ainda não existe.
        var _vazio = window._oltNaoConfigurado
          ? '<div style="text-align:center; padding:30px; color:'+OLTC.txt+';">'+
              '<i class="fa-solid fa-plug-circle-xmark" style="font-size:34px; color:'+OLTC.amb+';"></i>'+
              '<div style="font-weight:800; font-size:15px; margin:12px 0 6px;">OLT não configurada</div>'+
              '<div style="font-size:12.5px; color:'+OLTC.mut+'; line-height:1.6; max-width:430px; margin:0 auto 16px;">'+
                (_oltNivel()>=3
                  ? 'Esta instalação ainda não tem uma OLT vinculada. Informe <b>IP/host</b>, <b>porta</b>, <b>usuário</b> e <b>senha</b> do Telnet para começar.'
                  : 'Esta instalação ainda não tem uma OLT vinculada. Peça a um usuário <b>Root</b> para configurar a conexão.')+'</div>'+
              (_oltNivel()>=3
                ? '<button onclick="oltConexao()" style="cursor:pointer; padding:11px 20px; border-radius:9px; border:none; background:linear-gradient(180deg,#e64d4d 0%,#d32f2f 50%,#ab2323 100%); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); color:#fff; font-weight:800;"><i class="fa-solid fa-network-wired"></i> Configurar conexão da OLT</button>'
                : '')+
            '</div>'
          : '<div style="text-align:center; padding:26px; color:'+OLTC.mut+';">Nenhuma ONU na lista (cache vazio).<br><br><button onclick="oltRescan()" style="cursor:pointer; padding:10px 18px; border-radius:9px; border:none; background:linear-gradient(180deg,#e64d4d 0%,#d32f2f 50%,#ab2323 100%); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); color:#fff; font-weight:800;"><i class="fa-solid fa-rotate"></i> Varrer a OLT agora</button></div>';
        oltBody(barra+tiles+(progresso?'':_vazio)); oltFooter(''); return;
    }

    var arr=_oltFiltradas();
    if(window._oltRecentes){ arr=arr.slice().sort(function(a,b){ return _oltTsAtivacao(b)-_oltTsAtivacao(a); }); }   // últimos aprovisionados primeiro (data real de autorização)
    var pp=window._oltPorPag||50; var todos=pp>=99999;
    var totalPag=todos?1:Math.max(1, Math.ceil(arr.length/pp));
    if(window._oltPag>totalPag) window._oltPag=totalPag; if(window._oltPag<1) window._oltPag=1;
    var ini=(window._oltPag-1)*pp; var page=todos?arr:arr.slice(ini,ini+pp);
    window._oltArrFiltrado=arr;   // lista JÁ filtrada (todas as páginas) — usada pelo "marcar todos" do lote

    // Menu ANTES do campo de busca. (Aprovisionar/Alerta viraram cards no topo.)
    var _pulseCss='<style>@keyframes oltPulse{0%,100%{box-shadow:0 0 0 3px rgba(239,68,68,0.25)}50%{box-shadow:0 0 0 6px rgba(239,68,68,0.10)}}</style>';
    var _ppOpts=[['25','25 por pág.'],['50','50 por pág.'],['100','100 por pág.'],['99999','Ver Tudo']].map(function(v){ return '<option value="'+v[0]+'" '+(((window._oltPorPag||50)+'')===v[0]?'selected':'')+'>'+v[1]+'</option>'; }).join('');
    var busca='<div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin-bottom:10px;">'+
        _oltMenuBtn()+
        '<div style="position:relative; flex:0 1 320px; min-width:180px;">'+
          '<i class="fa-solid fa-magnifying-glass" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:'+OLTC.mut+'; font-size:13px; pointer-events:none;"></i>'+
          '<input id="olt_filtro" type="text" value="'+_oltEsc(window._oltFiltro||'')+'" placeholder="Buscar por Nome, Login, Serial, VLAN, Zona..." oninput="oltFiltrar(this.value)" style="width:100%; box-sizing:border-box; padding:9px 12px 9px 36px; border-radius:8px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.txt+'; font-size:13px; outline:none; transition:border .2s;">'+
        '</div>'+
        '<button onclick="oltVoltarInicio()" title="Voltar ao início da lista (limpar filtros)" style="width:38px; height:38px; flex:0 0 auto; border-radius:8px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.mut+'; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .2s;" onmouseover="this.style.color=\''+OLTC.acc+'\';this.style.borderColor=\''+OLTC.acc+'\'" onmouseout="this.style.color=\''+OLTC.mut+'\';this.style.borderColor=\''+OLTC.line+'\'"><i class="fa-solid fa-arrow-rotate-left"></i></button>'+
        '<div style="margin-left:auto; display:flex; align-items:center; gap:8px;">'+
          '<button id="oltBtnIntPon" onclick="oltInterrupcaoPon()" title="Atenção PON — portas em queda (LOS / falta de energia)" style="cursor:pointer; padding:7px 11px; border-radius:8px; border:1px solid '+OLTC.redf+'; background:'+OLTC.redf+'24; color:'+OLTC.redf+'; font-size:11.5px; font-weight:700; white-space:nowrap;"><i class="fa-solid fa-heart-crack" style="font-size:11px;"></i> Atenção PON</button>'+
          '<button onclick="oltExportarCsv()" title="Exportar a lista (com os filtros atuais) em CSV, para abrir no Excel" style="cursor:pointer; padding:7px 11px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.mut+'; font-size:11.5px; font-weight:500; white-space:nowrap;"><i class="fa-solid fa-file-csv"></i> CSV</button>'+
          '<button onclick="oltRescan()" title="Refresh — nova varredura completa da OLT (limpa o cache e re-varre)" style="cursor:pointer; padding:7px 11px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.mut+'; font-size:11.5px; font-weight:500; white-space:nowrap;"><i class="fa-solid fa-rotate" style="font-size:11px;"></i> Refresh</button>'+
          '<select onchange="oltPorPagina(this.value)" style="background:'+OLTC.panel+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:6px; padding:8px 12px; font-size:12px; font-weight:600; outline:none; cursor:pointer;">'+_ppOpts+'</select>'+
        '</div>'+
    '</div>';
    busca=_pulseCss+busca;

    /* TARJA IDÊNTICA à do ERP, mas AUTÔNOMA: olt.php não carrega css/wellsystem.css, então o estilo vai no próprio th (mesmos valores do .ws-table th: gradiente da marca em cada célula, 13px, peso 500, maiúsculas, 0,4px). Dentro do ERP as regras responsivas do CSS (com !important) ainda ajustam padding/fonte por largura de tela. */
    var _th='color:#fff; padding:10px 12px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); font-weight:500; text-transform:uppercase; font-size:13px; letter-spacing:.4px; border-bottom:none; white-space:nowrap;';
    var _cols=[['F/S/P','fsp'],['PON','pon'],['ID','id'],['Nome','nome'],['Zona','zona'],['VLAN','vlan'],['Serial','serial'],['Modelo','modelo'],['Tipo','tipo'],['Sinal ↓Rx ↑Rx','sinal'],['Uptime','uptime'],['Status','status']];
    var cf=window._oltColF||{}; var nAtivos=Object.keys(cf).filter(function(k){ return (''+cf[k]).trim()!==''; }).length;
    var funil='<button onclick="oltColFiltroToggle()" title="Filtros por coluna" style="cursor:pointer; padding:5px 9px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:'+(window._oltColFVis?'rgba(255,255,255,0.22)':'transparent')+'; color:#fff; font-size:12px; font-weight:800;"><i class="fa-solid fa-filter"></i>'+(nAtivos?' <span style="background:#fff; color:#d32f2f; border-radius:20px; padding:0 6px;">'+nAtivos+'</span>':'')+'</button>';
    var headRow='<tr style="color:#fff; text-align:center;">'+
        '<th style="'+_th+' width:32px; border-top-left-radius:8px; border-bottom-left-radius:8px;"><input type="checkbox" id="oltSelAll" onclick="oltSelAllToggle(this)" title="Marcar/desmarcar TODAS do filtro atual (todas as páginas)" style="cursor:pointer; width:15px; height:15px; vertical-align:middle;"></th>'+
        _cols.map(function(c){ var extra=''; if(c[1]==='nome'){ var _on=window._oltRecentes; extra=' <span onclick="event.stopPropagation(); oltRecentesToggle()" title="'+(_on?'Ordenado por Recentes (últimos aprovisionados) — clique p/ voltar ao normal':'Mostrar os últimos aprovisionados (Recentes)')+'" style="cursor:pointer; color:'+(_on?'#ffe08a':'rgba(255,255,255,.72)')+'; font-size:11px;"><i class="fa-solid fa-caret-down"></i>'+(_on?' recentes':'')+'</span>'; } return '<th style="'+_th+((c[1]==='nome'||c[1]==='zona')?' text-align:center;':'')+'">'+c[0]+extra+'</th>'; }).join('')+'<th class="oltAcaoTh" style="'+_th+' text-align:right; border-top-right-radius:8px; border-bottom-right-radius:8px;">'+funil+'</th></tr>';
    var _fin='width:100%; box-sizing:border-box; padding:5px 7px; border-radius:6px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.txt+'; font-size:11px; outline:none; font-weight:400; text-transform:none; letter-spacing:0;';
    var filtRow = window._oltColFVis ? ('<tr style="background:'+OLTC.bg2+'; border-bottom:1px solid '+OLTC.line+';">'+
        '<th style="padding:5px 6px;"></th>'+
        _cols.map(function(c){ var v=cf[c[1]]||''; return '<th style="padding:5px 6px;"><input id="oltCF_'+c[1]+'" value="'+_oltEsc(v)+'" oninput="oltColFiltrar(\''+c[1]+'\',this.value)" placeholder="filtrar…" style="'+_fin+'"></th>'; }).join('')+
        '<th style="padding:5px 6px; text-align:center;"><button onclick="oltColFiltroLimpar()" title="Limpar filtros das colunas" style="cursor:pointer; padding:5px 9px; border-radius:7px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.mut+'; font-size:11px; font-weight:700;"><i class="fa-solid fa-eraser"></i></button></th></tr>') : '';
    var thead='<thead>'+headRow+filtRow+'</thead>';
    /* SERIAL SEM MEXER A TABELA.
     *
     * O PROBLEMA
     * A máscara ("••••••••", 8 caracteres) é bem mais estreita que o serial real (16 caracteres em
     * monoespaçado). Trocar uma pela outra com display:none mudava a largura da célula, e como a
     * tabela usa table-layout:auto, o navegador recalculava TODAS as colunas: a linha inteira dava
     * um salto a cada vez que o mouse passava pelo olho. Com 50 linhas na tela, a página parecia
     * tremer — e clicar em algo depois virava tentativa e erro, porque o alvo se movia.
     *
     * A CORREÇÃO, em duas partes (as duas são necessárias)
     * 1. A célula tem LARGURA RESERVADA (17ch em monoespaçado = o serial mais largo que existe,
     *    mais uma folga). A coluna deixa de depender do que está visível dentro dela.
     * 2. Máscara e serial ficam EMPILHADOS no mesmo lugar (position:absolute no mesmo box) e a
     *    troca é por `visibility`, não por `display`. visibility:hidden mantém a caixa ocupando o
     *    espaço; display:none a remove do layout — e é essa remoção que provoca o recálculo.
     *
     * Por isso 17ch e não pixels: a coluna é monoespaçada, então `ch` é exatamente a largura de um
     * caractere. Em pixels, qualquer troca de fonte ou zoom voltaria a cortar ou a sobrar. */
    var tabela='<style>#oltWinBody table.oltTbl tbody td{ text-align:center; vertical-align:middle; }'
      + ' .oltSerialCell{ width:17ch; }'
      + ' .oltSerialSwap{ position:relative; display:block; width:100%; height:1.25em; }'
      + ' .oltSerialSwap > span{ position:absolute; left:0; right:0; top:0; text-align:center; white-space:nowrap; }'
      + ' .oltSerialCell .oltSerialReal{ visibility:hidden; }'
      + ' .oltSerialCell:hover .oltSerialReal{ visibility:visible; }'
      + ' .oltSerialCell:hover .oltSerialMask{ visibility:hidden; }'
      + '</style><div class="oltXScroll" style="overflow-x:auto; -webkit-overflow-scrolling:touch; border:1px solid '+OLTC.line+'; border-radius:10px;"><table class="oltTbl" style="width:100%; border-collapse:collapse; font-size:12.5px; table-layout:auto;">'+thead+'<tbody>'+_oltLinhas(page)+'</tbody></table></div>';

    var _sc=(document.getElementById('oltWinBody')||{}).scrollTop||0; // preserva o scroll no re-render
    /* (09/10/2026) a tabela é RECRIADA a cada render (Recentes, filtro, ordem…): a nova nascia com a rolagem horizontal em 0 e a página "andava para o lado" a cada clique.
       Guarda e devolve a rolagem horizontal da janela e da tabela (.oltXScroll) junto com a vertical. */
    var _bx=(document.getElementById('oltWinBody')||{}).scrollLeft||0, _xsEl=document.querySelector('.oltXScroll'), _xs=_xsEl?_xsEl.scrollLeft:0;
    oltBody(barra+tiles+busca+'<div id="oltBulkBar">'+_oltBulkBarHtml()+'</div>'+tabela);
    var _b=document.getElementById('oltWinBody'); if(_b){ _b.scrollTop=_sc; _b.scrollLeft=_bx; }
    var _xn=document.querySelector('.oltXScroll'); if(_xn && _xs) _xn.scrollLeft=_xs;
    /* colunas que não encolhem entre renders (09/10/2026): com table-layout:auto a largura de cada coluna depende dos nomes da página atual — ao trocar Recentes/filtro/ordem as colunas "andavam" para os lados.
       Cada coluna guarda a MAIOR largura já vista nesta sessão e a usa como mínimo. */
    try{ var _ths=document.querySelectorAll('.oltTbl thead th'), _w=window._oltColW; if(!_w||_w.length!==_ths.length){ _w=window._oltColW=[]; }
      for(var _i=0;_i<_ths.length;_i++){ _ths[_i].style.boxSizing='border-box'; if(_w[_i]) _ths[_i].style.minWidth=_w[_i]+'px'; }
      for(var _j=0;_j<_ths.length;_j++){ _w[_j]=Math.max(_w[_j]||0, _ths[_j].offsetWidth); } }catch(_e){}
    oltFooter(progresso ? '' : _oltPaginacao(arr.length, totalPag));
    _oltResumoRefresh(); // se o Resumo estiver aberto, atualiza junto (ao vivo)
    _oltInterrupcaoRefresh(); // janela Atenção PON ao vivo (se aberta)
    if(typeof _oltPortasOnOffRefresh==='function') _oltPortasOnOffRefresh(); // janela Portas ON/OFF ao vivo
    _oltAtualizarAlertaPon(); // alerta flutuante de PON em queda total
    if(typeof _oltSelAllSync==='function') _oltSelAllSync(); // sincroniza o "marcar todos" com o que está marcado
}
// ===== SELEÇÃO MÚLTIPLA + AÇÕES EM LOTE =====================================
// Marca ONUs na lista (checkbox) e aplica reiniciar/resync/bloquear/liberar/deletar em todas de uma
// vez, UMA A UMA (com respiro + retry, igual à migração) pra não esgotar as VTYs. A seleção fica em
// window._oltSel {"fsp|id":1} e sobrevive ao re-render (os checkboxes são remarcados a partir dela).
function _oltSelCount(){ var s=window._oltSel||{}, n=0; for(var k in s){ if(s[k]) n++; } return n; }
function oltSelToggle(chk){ window._oltSel=window._oltSel||{}; var k=chk.getAttribute('data-k'); if(chk.checked) window._oltSel[k]=1; else delete window._oltSel[k]; _oltBulkBarRefresh(); _oltSelAllSync(); }
function oltSelAllToggle(chk){ window._oltSel=window._oltSel||{};
    // Marca/desmarca TODAS as ONUs do FILTRO ATUAL (todas as páginas), não só as visíveis. Assim,
    // ao clicar numa categoria do Resumo (ou filtrar por VLAN/modelo), "marcar todos" pega o grupo inteiro.
    var arr=window._oltArrFiltrado||[];
    arr.forEach(function(o){ if(o&&o.fsp&&(o.id!==undefined&&o.id!=='')){ var k=(o.fsp||'')+'|'+o.id; if(chk.checked) window._oltSel[k]=1; else delete window._oltSel[k]; } });
    var els=document.querySelectorAll('.oltSelChk'); for(var i=0;i<els.length;i++){ els[i].checked=chk.checked; }
    _oltBulkBarRefresh();
}
function oltSelLimpar(){ window._oltSel={}; var els=document.querySelectorAll('.oltSelChk'); for(var i=0;i<els.length;i++) els[i].checked=false; var a=document.getElementById('oltSelAll'); if(a){ a.checked=false; a.indeterminate=false; } _oltBulkBarRefresh(); }
// Botão "Marcar todos" da barra de busca: marca/desmarca TODAS as ONUs do filtro atual (todas as
// páginas). Toggle: se já estão todas marcadas, desmarca. Abre a barra de ações em lote.
function oltMarcarTodosFiltro(){
    window._oltSel=window._oltSel||{};
    var arr=(window._oltArrFiltrado||[]).filter(function(o){ return o&&o.fsp&&(o.id!==undefined&&o.id!==''); });
    if(!arr.length){ return; }
    var todasMarc=arr.every(function(o){ return window._oltSel[(o.fsp||'')+'|'+o.id]; });
    arr.forEach(function(o){ var k=(o.fsp||'')+'|'+o.id; if(todasMarc) delete window._oltSel[k]; else window._oltSel[k]=1; });
    var els=document.querySelectorAll('.oltSelChk'); for(var i=0;i<els.length;i++) els[i].checked=!todasMarc;
    var a=document.getElementById('oltSelAll'); if(a){ a.checked=!todasMarc; a.indeterminate=false; }
    _oltBulkBarRefresh();
}
function _oltSelAllSync(){ var a=document.getElementById('oltSelAll'); if(!a) return; var els=document.querySelectorAll('.oltSelChk'); var t=els.length, c=0; for(var i=0;i<els.length;i++) if(els[i].checked) c++; a.checked=(t>0&&c===t); a.indeterminate=(c>0&&c<t); }
function _oltBulkBarRefresh(){ var b=document.getElementById('oltBulkBar'); if(b) b.innerHTML=_oltBulkBarHtml(); _oltRowAcoesSync(); }
/* AÇÕES NA LINHA (07/10/2026): os botões Reiniciar / Ressincronizar / Bloquear / Liberar / Deletar saíram da barra do topo e aparecem ABAIXO DO NOME
   da ONU marcada (igual à lista de clientes do ERP). Continuam valendo para TODAS as marcadas (o número aparece no botão quando são 2 ou mais). */
function _oltRowAcoesBtns(){
    var n=_oltSelCount();
    var _b=function(ic,txt,tipo,bg){ return '<button type="button" onclick="oltBulkAcao(\''+tipo+'\')" title="'+txt+(n>1?' — aplica às '+n+' selecionadas':'')+'" aria-label="'+txt+'" style="cursor:pointer; flex:0 0 auto; width:30px; height:26px; padding:0; border-radius:6px; border:none; background:'+bg+'; color:#fff; font-size:13px; line-height:1; display:inline-flex; align-items:center; justify-content:center;"><i class="fa-solid '+ic+'"></i></button>'; };
    return _b('fa-rotate-right','Reiniciar','reboot',OLTC.amb)+_b('fa-arrows-rotate','Ressincronizar','resync',OLTC.acc)+_b('fa-ban','Bloquear','block',OLTC.red)+_b('fa-circle-check','Liberar','unblock',OLTC.grn)+_b('fa-trash','Deletar','delete','#b91c1c');
}
function _oltRowAcoesSync(){
    var els=document.querySelectorAll('.oltRowAcoes'), sel=window._oltSel||{}, html=null;
    for(var i=0;i<els.length;i++){ var c=els[i], k=c.getAttribute('data-k');
        if(sel[k]){ if(html===null) html=_oltRowAcoesBtns(); c.innerHTML=html; c.style.marginTop='6px'; } else { c.innerHTML=''; c.style.marginTop='0'; } }
}
function _oltBulkBarHtml(){
    var n=_oltSelCount(); if(n<2) return '';   // 1 marcada: os botões já estão abaixo do nome, nada no topo
    return '<div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin:0 0 8px; font-size:12px; color:'+OLTC.mut+';">'+
        '<b style="color:'+OLTC.ink+';"><i class="fa-solid fa-list-check" style="color:'+OLTC.acc+';"></i> '+n+' selecionadas</b>'+
        '<span>os ícones abaixo do nome valem para todas (passe o mouse para ver o nome)</span>'+
        '<button onclick="oltSelLimpar()" style="cursor:pointer; padding:4px 10px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.mut+'; font-size:11px; font-weight:700;">Limpar seleção</button>'+
    '</div>';
}
function oltBulkAcao(tipo){
    var sel=window._oltSel||{}; var mapa={reboot:'Reiniciar', resync:'Ressincronizar', block:'Bloquear (corta o sinal)', unblock:'Liberar', delete:'DELETAR (irreversível)'};
    var lista=[]; (window._oltLista||[]).forEach(function(o){ if(o&&sel[(o.fsp||'')+'|'+o.id] && o.fsp && (o.id!==undefined&&o.id!=='')) lista.push(o); });
    if(!lista.length) return;
    if(!confirm(mapa[tipo]+' — '+lista.length+' ONU'+(lista.length>1?'s':'')+' selecionada'+(lista.length>1?'s':'')+'.\n\nRoda uma a uma (com retry). Confirmar?')) return;
    window._oltBulkRunning=true;   // pausa o re-render automático da lista enquanto roda
    var i=0, ok=0, err=0, det=[], tent=0, _t0=Date.now(), _cur='', _tick=null;
    var _lbl=mapa[tipo]||tipo;
    var _ic={reboot:'fa-rotate-right',resync:'fa-arrows-rotate',block:'fa-ban',unblock:'fa-circle-check',delete:'fa-trash'}[tipo]||'fa-gear';
    var _cor=(tipo==='delete')?'#b91c1c':(tipo==='block'?OLTC.red:OLTC.acc);
    // DIÁLOGO (modal) mostrando o que está acontecendo — barra de progresso, contadores e log ao vivo.
    function _modal(html){ var ov=document.getElementById('oltBulkOv'); if(!ov){ ov=document.createElement('div'); ov.id='oltBulkOv'; ov.style.cssText='position:fixed; inset:0; z-index:2147483600; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.55);'; document.body.appendChild(ov); } ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:14px; padding:18px 20px; width:min(94vw,460px); box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+html+'</div>'; }
    function paint(fim){
        var seg=Math.round((Date.now()-_t0)/1000);
        var atual=Math.min(i+1,lista.length);   // ONU sendo processada agora (1-based)
        // Progresso: quando termina cada ONU, a barra "vaza" um pouco enquanto a atual roda (feedback).
        var pct=fim?100:Math.round((i + 0.4)/lista.length*100);
        var sub=fim?('Ação aplicada · '+lista.length+' ONU'+(lista.length>1?'s':'')+' · '+seg+'s')
                   :('Processando '+atual+' de '+lista.length+' · '+seg+'s'+(_cur?(' · '+_oltEsc((''+_cur).slice(0,26))):''));
        var cab='<div style="display:flex; align-items:center; gap:11px; margin-bottom:12px;"><span style="flex:0 0 auto; width:38px; height:38px; border-radius:50%; background:'+_cor+'22; display:inline-flex; align-items:center; justify-content:center;"><i class="fa-solid '+(fim?'fa-circle-check':_ic)+(fim?'':' fa-fade')+'" style="color:'+_cor+'; font-size:16px;"></i></span><div style="min-width:0;"><div style="font-weight:800; color:'+OLTC.ink+'; font-size:14px;">'+(fim?'Concluído':_oltEsc(_lbl))+'</div><div style="font-size:11.5px; color:'+OLTC.mut+';">'+sub+'</div></div></div>';
        var barra='<div style="height:8px; background:'+OLTC.bg2+'; border-radius:20px; overflow:hidden; margin-bottom:9px;"><div style="height:100%; width:'+pct+'%; background:'+_cor+'; transition:width .3s;"></div></div>';
        var tally='<div style="font-size:12.5px; margin-bottom:8px;"><b style="color:'+OLTC.grn+';">✓ '+ok+' ok</b> · <span style="color:'+OLTC.red+';">✗ '+err+' erro</span></div>';
        var log=det.length?('<div style="max-height:160px; overflow:auto; font-size:10.5px; line-height:1.6; border-top:1px solid '+OLTC.line+'; padding-top:8px;">'+det.slice(-40).join('')+'</div>'):'';
        var rod=fim?('<div style="display:flex; justify-content:flex-end; margin-top:12px;"><button onclick="var e=document.getElementById(\'oltBulkOv\'); if(e)e.remove();" style="cursor:pointer; padding:9px 18px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;">Fechar</button></div>'):'<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:6px;">Uma a uma para não congestionar a OLT — aguarde.</div>';
        _modal(cab+barra+tally+log+rod);
    }
    function prox(){ i++; tent=0; setTimeout(passo, 350); }
    function passo(){
        if(i>=lista.length){ if(_tick){ clearInterval(_tick); _tick=null; } paint(true); window._oltBulkRunning=false; if(tipo==='delete'){ oltSelLimpar(); if(typeof oltRenderLista==='function') oltRenderLista(); } return; }
        var o=lista[i]; var nm=_oltNomeDe(o)||o.serial||(o.fsp+' id'+o.id); _cur=nm;
        var body=new URLSearchParams({ acao:'onu_acao', tipo:tipo, fsp:o.fsp, id:o.id }).toString();
        fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body}).then(function(r){return r.json();}).then(function(d){
            if(d&&d.status==='ok'&&d.sucesso){ ok++; det.push('<div style="color:'+OLTC.grn+';">✓ '+_oltEsc(nm)+'</div>');
                if(tipo==='delete'&&window._oltLista){ var kk=(o.fsp||'')+'|'+o.id; window._oltLista=window._oltLista.filter(function(x){ return ((x.fsp||'')+'|'+x.id)!==kk; }); delete (window._oltSel||{})[kk]; }
                paint(); prox();
            } else {
                var msg=(d&&(d.message||d.saida))||'falha';
                if(/AUTH_RETRY|comunicar|prompt|VTY|timeout/i.test(msg)&&tent<2){ tent++; paint(); setTimeout(passo,900); return; }
                err++; det.push('<div style="color:'+OLTC.red+';">✗ '+_oltEsc(nm)+' — '+_oltEsc((''+msg).slice(0,80))+'</div>'); paint(); prox();
            }
        }).catch(function(){ if(tent<2){ tent++; setTimeout(passo,900); return; } err++; det.push('<div style="color:'+OLTC.red+';">✗ '+_oltEsc(nm)+' — sem resposta</div>'); paint(); prox(); });
    }
    paint();
    _tick=setInterval(function(){ if(!document.getElementById('oltBulkOv') || !window._oltBulkRunning){ clearInterval(_tick); _tick=null; return; } paint(); }, 1000); // cronômetro vivo
    passo();
}
// Alterna a ordenação "Recentes" (últimos aprovisionados primeiro) — pela 1ª vez que cada ONU apareceu.
function oltRecentesToggle(){ window._oltRecentes=!window._oltRecentes; window._oltPag=1; if(typeof oltGerenciadorAberto==='function'?oltGerenciadorAberto():true) oltRenderLista(); }
/* CARD DO TOPO — visual em LINHA (24/09/2026, pedido do provedor: "informação bagunçada no quadrado, algo moderno
 * arrumado, ícones menores"): ícone pequeno à esquerda, número + nome à direita, faixa da cor na borda esquerda.
 * Mesmo clique/filtro de antes (oltFiltrarCat); _oltBotaoAprov e _oltTileAlerta usam o mesmo desenho (_oltTileCorpo). */
function _oltTileCorpo(ic,cor,val,rot){
    return '<span style="flex:0 0 auto; display:inline-flex; align-items:center; justify-content:center; width:22px; height:22px; border-radius:6px; background:'+cor+'22;"><i class="fa-solid '+ic+'" style="color:'+cor+'; font-size:11px;"></i></span>'+
        '<span style="min-width:0; display:flex; flex-direction:column; line-height:1.1;">'+
          '<span style="font-size:16px; font-weight:800; color:'+cor+'; letter-spacing:-.01em;">'+val+'</span>'+
          '<span title="'+String(rot).replace(/"/g,'&quot;')+'" style="font-size:9px; color:'+OLTC.mut+'; text-transform:uppercase; letter-spacing:.3px; line-height:1.15;">'+rot+'</span>'+   // quebra em 2 linhas entre palavras (nunca "…")
        '</span>';
}
function _oltTileEstilo(cor,brd,sombra,fundo){
    return 'position:relative; display:flex; align-items:center; gap:8px; min-width:0; background:'+(fundo||OLTC.bg2)+'; border:1px solid '+brd+'; border-left:3px solid '+cor+'; box-shadow:'+sombra+'; border-radius:10px; padding:7px 9px; text-align:left;';
}
function _oltTile(rot,val,cor,ic,cat,ativo){
    var clicavel=(cat!=null && cat!=='');
    var clic=clicavel?(' onclick="oltFiltrarCat(\''+cat+'\')" '):'';
    var brd=ativo?cor:OLTC.line;
    var sombra=ativo?('0 0 0 2px '+cor+'55'):'0 1px 2px rgba(0,0,0,0.12)';
    return '<div'+clic+' style="'+_oltTileEstilo(cor,brd,sombra)+' cursor:'+(clicavel?'pointer':'default')+'; transition:transform .12s, box-shadow .12s;"'+
        (clicavel?' onmouseover="this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.transform=\'\'"':'')+'>'+
        _oltTileCorpo(ic,cor,val,rot)+'</div>'; }
function _oltTipo(t){ t=(t||'').toUpperCase(); if(t==='ONT') return '<span style="padding:2px 7px; border-radius:20px; background:rgba(167,139,250,0.20); color:'+OLTC.vio+'; font-size:10px; font-weight:800; white-space:nowrap;">ONT·Router</span>'; if(t==='ONU') return '<span style="padding:2px 7px; border-radius:20px; background:rgba(56,189,248,0.20); color:'+OLTC.acc+'; font-size:10px; font-weight:800; white-space:nowrap;">ONU·Bridge</span>'; return '<span style="color:'+OLTC.mut+';">—</span>'; }
function _oltIdade(seg){ if(seg==null) return ''; if(seg<60) return 'agora'; if(seg<3600) return Math.floor(seg/60)+' min'; if(seg<86400) return Math.floor(seg/3600)+' h'; return Math.floor(seg/86400)+' d'; }
// "Informação válida às HH:MM" — hora a que a informação exibida pertence.
function _oltMarcarAtualizado(dt){ window._oltDataHora = dt || new Date(); _oltAtualizarValida(); }
function _oltAtualizarValida(){
    var el=document.getElementById('oltWinValida'), tx=document.getElementById('oltWinValidaTxt'); if(!el||!tx) return;
    var d=window._oltDataHora; if(!d){ el.style.display='none'; return; }
    var hh=('0'+d.getHours()).slice(-2), mm=('0'+d.getMinutes()).slice(-2);
    tx.textContent='Informação válida às '+hh+':'+mm; el.style.display='inline-flex';
    if(!window._oltUptimeTicker) window._oltUptimeTicker=setInterval(_oltTickUptime, 250); // contagem regressiva
}
// CONTAGEM REGRESSIVA até a próxima sincronização automática + estado "sincronizando".
function _oltTickUptime(){
    var el=document.getElementById('oltWinUptime'); if(!el){ return; }
    if(!oltGerenciadorAberto()){ if(window._oltUptimeTicker){ clearInterval(window._oltUptimeTicker); window._oltUptimeTicker=null; } return; }
    if(window._oltSyncAtivo){ el.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> sincronizando placa '+window._oltSyncAtivo+'…'; return; }
    var prox=window._oltProxSync||(Date.now()+(window.OLT_SYNC_MS||15000));
    var restante=Math.max(0, Math.ceil((prox-Date.now())/1000));
    el.textContent='sincroniza em '+restante+'s';
}
function _oltLinhas(onus){
    if(!onus.length) return '<tr><td colspan="14" style="padding:16px; color:'+OLTC.mut+'; text-align:center;">Nenhum resultado para o filtro.</td></tr>';
    return onus.map(function(o,idx){
        var _ini=_oltEhInicializando(o);
        var stCor=_ini?OLTC.amb:((o.status||'').toLowerCase().indexOf('online')>-1?OLTC.grn:OLTC.red);
        var stTxt=_ini?'Inicializando…':(o.status||'-');
        var pon=(o.fsp||'').split('/')[2]||'-';
        var vlanBadge=o.vlan?('<span style="background:'+OLTC.redf+'2b; color:'+OLTC.redf+'; border-radius:5px; padding:1px 5px; font-weight:700; font-size:10px; white-space:nowrap;">'+_oltEsc(o.vlan)+'</span>'):'<span style="color:'+OLTC.mut+';">—</span>';
        var _isOff=(o.status||'').toLowerCase().indexOf('online')<0;
        // Sinal Rx ONU / Rx OLT (+ distância) — cor por classe (Bom/Ruim) quando ONLINE;
        // se OFFLINE, mostra o ÚLTIMO sinal conhecido em COR DIFERENTE (roxo, itálico) c/ "(último)". (Obs4)
        var sc=_oltSinalClasse(o);
        var rxCor=_isOff?OLTC.vio:(_oltCorSinalDe(o)||OLTC.mut);   // cor pela REFERÊNCIA = Rx OLT (retorno)
        var rxOnu=o.rx?_oltEsc((''+o.rx).replace(/\s*dBm/i,'')):'';
        var txOnu=o.tx?_oltEsc((''+o.tx).replace(/\s*dBm/i,'')):'';
        var rxOlt=o.rx_olt?_oltEsc((''+o.rx_olt).replace(/\s*dBm/i,'')):'';
        var distTxt=o.dist?(' · '+_oltEsc(o.dist)+'m'):'';
        var rxCell = (rxOnu||rxOlt)
            ? '<div title="↓ Rx = sinal recebido na ONU · ↑ Rx = retorno na OLT'+(_isOff&&!sc?' — último conhecido (offline)':'')+'" style="font-family:monospace; font-size:12px; line-height:1.45; white-space:nowrap; text-align:left; display:inline-block; '+((_isOff&&!sc)?'font-style:italic;':'')+'">'+
                '<div style="color:'+rxCor+'; font-weight:'+(sc?'800':'600')+';">↓'+(rxOnu||'—')+'</div>'+
                '<div style="color:'+rxCor+'; font-weight:'+(sc?'800':'600')+'; font-size:11px;">↑'+(rxOlt||'—')+'<span style="color:'+OLTC.mut+'; font-weight:400; font-size:10px;">'+distTxt+(_isOff&&!sc?' (últ.)':'')+'</span></div>'+
              '</div>'
            : '<span style="color:'+OLTC.mut+';">—</span>';
        var _dtAtiv=_oltDataAtivacao(o); var _dtTt=(_dtAtiv?(' · Ativação: '+_dtAtiv):'');
        var modeloTxt=(o.modelo&&o.modelo!=='—')?('<span title="Modelo na OLT: '+_oltEsc(o.modelo)+_dtTt+'">'+_oltEsc(_oltModeloNome(o.modelo))+'</span>'):('<span title="Modelo não identificado'+_dtTt+'" style="color:'+OLTC.mut+';">—</span>');
        // Uptime: ONLINE mostra tempo ligada; OFFLINE mostra "offline há X" (âmbar) usando o downtime. (Obs4)
        var upTxt;
        if(o.uptime&&o.uptime!=='-'){ var _us=_oltUptimeSec(o.uptime); upTxt=(_us!=null&&!_isOff)?('<span class="oltUpLive" data-base="'+_us+'" data-at="'+Date.now()+'">'+_oltEsc(_oltUptimeFmt(_us))+'</span>'):_oltEsc(o.uptime); }
        else if(_isOff&&o.downtime){ var _dtAb=(''+o.downtime).replace(/\s+/g,'').replace(/minutos?|mins?/gi,'m').replace(/horas?|hrs?/gi,'h').replace(/dias?/gi,'d').replace(/segundos?|segs?/gi,'s'); upTxt='<span style="color:'+OLTC.amb+'; font-weight:700; white-space:nowrap;" title="Offline há '+_oltEsc(o.downtime)+'"><i class="fa-regular fa-clock"></i> off '+_oltEsc(_dtAb)+'</span>'; }
        else upTxt='<span style="color:'+OLTC.mut+';">—</span>';
        // Bridge/Router pelo MODELO (o service-profile da OLT MENTE — ex.: M10G router com srv MAX1000).
        var tp=_oltTipoDe(o); // ONU(Bridge) / ONT(Router) pelo modelo
        var tipoBadge=(tp==='ONU')?'<span style="padding:2px 8px; border-radius:20px; background:rgba(56,189,248,0.18); color:'+OLTC.acc+'; font-size:10px; font-weight:800; white-space:nowrap;">ONU·Bridge</span>'
                    :(tp==='ONT')?'<span style="padding:2px 8px; border-radius:20px; background:rgba(167,139,250,0.20); color:'+OLTC.vio+'; font-size:10px; font-weight:800; white-space:nowrap;">ONT·Router</span>'
                    :'<span style="color:'+OLTC.mut+';">—</span>';
        var _okK=(o.fsp||'')+'|'+(o.id||''); var _tipoOk=(window._oltTipoOk&&window._oltTipoOk[_okK]&&(Date.now()-window._oltTipoOk[_okK]<3000))?'<i class="fa-solid fa-check" title="Alterado" style="color:'+OLTC.grn+'; margin-left:2px;"></i>':'';
        var _temImg=_oltTemImg(o); var _imgKeyEnc=encodeURIComponent(_oltImgKey(o)); var _hov=_temImg?(' onmouseenter="_oltImgHover(\''+_imgKeyEnc+'\',this)" onmouseleave="_oltImgHoverOut()"'):''; var _imgIco='<span onclick="oltModeloImg(\''+_imgKeyEnc+'\',event)"'+_hov+' title="'+(_temImg?'Passe o mouse p/ ver · clique p/ alterar':'Anexar foto do modelo (PNG/JPEG)')+'" style="cursor:pointer; color:'+(_temImg?OLTC.grn:OLTC.mut)+'; font-size:12px;"><i class="fa-solid '+(_temImg?'fa-image':'fa-camera')+'"></i></span>';
        var tipoCell='<span style="display:inline-flex; align-items:center; gap:5px;">'+tipoBadge+'<span onclick="oltEditarTipo(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\')" title="Trocar o tipo (Bridge/Router)" style="cursor:pointer; color:'+OLTC.mut+'; font-weight:800; font-size:12px;">+</span>'+_imgIco+_tipoOk+'</span>';
        // Apenas 2 cores: zebra (fundo) + borda de acento — sem arco-íris (#1)
        var par=(idx%2===0);
        var _selK=(o.fsp||'')+'|'+o.id; var _selCh=(window._oltSel&&window._oltSel[_selK])?' checked':'';
        var _nmCtr=true, _znCtr=true;   // Nome e Zona sempre centralizados (08/10/2026): a regra curto=centro/longo=esquerda foi desfeita a pedido
        var _rowAc='<div class="oltRowAcoes" data-k="'+_oltEsc(_selK)+'" style="display:flex; flex-wrap:nowrap; justify-content:'+(_nmCtr?'center':'flex-start')+'; gap:8px; margin-top:'+(_selCh?'6px':'0')+';">'+(_selCh?_oltRowAcoesBtns():'')+'</div>';
        return '<tr style="background:'+(par?OLTC.bg:OLTC.bg2)+'; border-bottom:1px solid '+OLTC.line+';">'+
            '<td style="padding:8px 6px; text-align:center;"><input type="checkbox" class="oltSelChk" data-k="'+_oltEsc(_selK)+'" onclick="oltSelToggle(this)"'+_selCh+' style="cursor:pointer; width:15px; height:15px; vertical-align:middle;"></td>'+
            (function(){ var pp=(o.fsp||'').split('/'); var placaNum=(pp[1]!=null&&pp[1]!=='')?pp[1]:'—'; var pl=_oltPlacaNome(pp[1]||''); var tip='Placa '+_oltEsc(placaNum)+(pl?' — '+_oltEsc(pl):''); return '<td title="'+tip+'" style="padding:8px 9px; white-space:nowrap; color:'+OLTC.txt+';">'+_oltEsc(o.fsp)+'</td>'; })()+
            (function(){ var po=_oltPortaNome(o.fsp||''); var tip=po?_oltEsc(po):('Porta PON '+_oltEsc(pon)); return '<td style="padding:8px 9px; color:'+OLTC.txt+'; font-weight:700; white-space:nowrap;"><span title="'+tip+'">'+_oltEsc(pon)+'</span> <span onclick="oltEditarPorta(\''+_oltEsc(o.fsp)+'\')" title="Editar apelido / VLAN / Zona padrão desta porta PON" style="cursor:pointer; color:'+OLTC.mut+'; font-weight:800; font-size:12px;">+</span></td>'; })()+
            '<td style="padding:8px 9px; color:'+OLTC.txt+';">'+_oltEsc(o.id)+'</td>'+
            '<td class="oltNomeTd" style="padding:8px 9px; min-width:170px; max-width:320px; text-align:'+(_nmCtr?'center':'left')+';"><div style="display:flex; align-items:center; justify-content:'+(_nmCtr?'center':'flex-start')+'; gap:4px; min-width:0;"><span title="'+_oltEsc(_oltNomeDe(o)||'-')+'" style="flex:0 1 auto; min-width:0; font-weight:700; text-transform:uppercase; color:'+OLTC.nome+'; white-space:normal; overflow-wrap:break-word; line-height:1.25;">'+(function(){ var nm=_oltEsc(_oltNomeDe(o)||'-'); return '<span class="olt-cli-nome" data-olt-login="'+_oltEsc(_oltLoginResolvido(o.serial)||o.serial)+'" onclick="oltAbrirCadastro(\''+_oltEsc(o.serial)+'\')" title="Abrir cadastro do cliente" style="cursor:pointer; color:'+OLTC.nome+';">'+nm+'</span>'; })()+_oltGenChip(o)+'</span><span onclick="oltEditarNome(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\')" title="Editar/trocar o nome (salva local; se errar, corrija e ressincronize)" style="flex:0 0 auto; cursor:pointer; color:'+OLTC.mut+'; font-weight:800; font-size:13px; line-height:1;">+</span></div>'+_rowAc+'</td>'+
            '<td style="padding:8px 9px; min-width:96px; line-height:1.3; text-align:'+(_znCtr?'center':'left')+';"><span style="color:'+(o.zona?OLTC.txt:OLTC.mut)+';">'+_oltEsc(o.zona||'—')+'</span>&nbsp;<span onclick="oltEditarZona(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\')" title="Editar a zona" style="cursor:pointer; color:'+OLTC.mut+'; font-weight:800; font-size:12px;">+</span></td>'+
            '<td style="padding:8px 9px; white-space:nowrap;">'+vlanBadge+' <span onclick="oltEditarVlanNome(\''+(('' +(o.vlan||'')).replace(/[^0-9]/g,''))+'\',\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\')" title="Editar nome da VLAN / trocar a VLAN na OLT" style="cursor:pointer; color:'+OLTC.mut+'; font-weight:800; font-size:12px;">+</span></td>'+
            '<td style="padding:8px 9px; font-family:monospace; font-size:11px;"><span class="oltSerialCell" onclick="oltFichaTecnica(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\')" title="Passe o mouse p/ ver o serial · clique = ficha técnica" style="cursor:pointer; display:inline-flex; flex-direction:column; align-items:center; gap:3px; color:'+OLTC.acc+';"><i class="fa-solid fa-eye" style="font-size:11px; opacity:.65;"></i><span class="oltSerialSwap"><span class="oltSerialReal" style="text-decoration:underline; text-decoration-style:dotted;">'+_oltEsc(o.serial||'—')+'</span><span class="oltSerialMask" style="letter-spacing:2px; color:'+OLTC.mut+';">••••••••</span></span></span></td>'+
            '<td style="padding:8px 9px; color:'+OLTC.txt+'; white-space:nowrap; font-size:11px;">'+modeloTxt+'</td>'+
            '<td title="'+((o.modelo&&o.modelo!=='—')?'Modelo: '+_oltEsc(o.modelo):'Modelo não identificado')+'" style="padding:8px 9px; white-space:nowrap; cursor:help;">'+tipoCell+'</td>'+
            '<td onclick="oltUptimePopup(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\',event)" title="Clique para ver o uptime (atualiza a cada 60s)" style="padding:8px 6px; white-space:nowrap; cursor:pointer;">'+rxCell+'</td>'+
            '<td style="padding:8px 9px; color:'+OLTC.mut+'; white-space:nowrap; font-size:11px;">'+upTxt+'</td>'+
            '<td style="padding:8px 9px; font-weight:800; color:'+stCor+'; white-space:nowrap;"><i class="fa-solid '+(_ini?'fa-spinner fa-spin':'fa-circle')+'" style="font-size:'+(_ini?'11px':'7px')+'; vertical-align:middle;"></i> '+_oltEsc(stTxt)+'</td>'+
            '<td class="oltAcaoTd" style="padding:8px 6px;"><button onclick="oltAbrirONU(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\',\''+_oltEsc(o.serial)+'\',\''+_oltEsc(o.status)+'\',\''+encodeURIComponent(o.nome||'')+'\',\''+encodeURIComponent(o.zona||'')+'\',\''+_oltEsc(o.vlan||'')+'\',true)" style="cursor:pointer; padding:4px 8px; border-radius:7px; border:none; background:#243447; color:#ffffff; font-size:10.5px; font-weight:600; white-space:nowrap;" title="Gerenciar a ONU"><i class="fa-solid fa-sliders"></i><span class="oltAcaoLbl"> Gerenciar</span></button></td>'+
        '</tr>';
    }).join('');
}
function oltFiltrar(t){ window._oltSel={}; window._oltFiltro=t; window._oltPag=1; try{sessionStorage.setItem('oltFiltro',t);}catch(e){} oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); var inp=document.getElementById('olt_filtro'); if(inp){ inp.focus(); var v=inp.value; inp.value=''; inp.value=v; } }
// Clicar na CONTAGEM de um modelo (em Perfis ONT/ONU) filtra a lista por aquele modelo.
function oltFiltrarModelo(ke){ var k=decodeURIComponent(ke||''); if(!k) return; window._oltSel={}; window._oltColF={modelo:k}; window._oltFiltro=''; window._oltCat=''; window._oltPag=1; window._oltColFVis=true; try{sessionStorage.setItem('oltFiltro','');sessionStorage.setItem('oltCat','');}catch(e){} oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
// Botão "voltar ao início" (↺) — limpa busca, filtros de coluna, categoria e volta à pág. 1.
function oltVoltarInicio(){ window._oltSel={}; window._oltFiltro=''; window._oltCat=''; window._oltColF={}; window._oltPag=1; try{sessionStorage.setItem('oltFiltro','');sessionStorage.setItem('oltCat','');}catch(e){} oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
// Filtro POR COLUNA (linha de filtros no cabeçalho). Preserva o foco no campo digitado.
function oltColFiltrar(col, val){ window._oltSel={}; window._oltColF=window._oltColF||{}; window._oltColF[col]=val; window._oltPag=1; oltRenderLista(); var inp=document.getElementById('oltCF_'+col); if(inp){ inp.focus(); var v=inp.value; inp.value=''; inp.value=v; } }
function oltColFiltroLimpar(){ window._oltSel={}; window._oltColF={}; window._oltPag=1; oltRenderLista(); }
function oltColFiltroToggle(){ window._oltColFVis=!window._oltColFVis; oltRenderLista(); }
function _oltPaginacao(total, totalPag){
    var p=window._oltPag||1;
    function b(lbl,pg,dis,ativo){ return '<button '+(dis?'disabled':'onclick="oltIrPag('+pg+')"')+' style="cursor:'+(dis?'default':'pointer')+'; min-width:32px; height:30px; border-radius:7px; border:1px solid '+OLTC.line+'; background:'+(ativo?OLTC.acc:'transparent')+'; color:'+(ativo?'#ffffff':(dis?OLTC.line:OLTC.txt))+'; font-size:12px; font-weight:700; margin:0 2px;">'+lbl+'</button>'; }
    var nav=b('<i class="fa-solid fa-angle-left"></i>', p-1, p<=1, false);
    var ini=Math.max(1,p-2), fim=Math.min(totalPag,ini+4); ini=Math.max(1,fim-4);
    for(var i=ini;i<=fim;i++){ nav+=b(i,i,false,i===p); }
    nav+=b('<i class="fa-solid fa-angle-right"></i>', p+1, p>=totalPag, false);
    return '<div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; font-size:12px; color:'+OLTC.mut+';">'+
        '<div style="display:flex; align-items:center;">'+nav+'</div>'+
        '<div>'+total+' registro(s) · pág. '+p+'/'+totalPag+'</div></div>';
}
function oltIrPag(p){ window._oltPag=p; try{sessionStorage.setItem('oltPag',p);}catch(e){} oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
function oltPorPagina(v){ window._oltPorPag=parseInt(v,10)||50; window._oltPag=1; oltRenderLista(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }

// ---------- Aprovisionamento: ONUs novas (autofind) + autorização ----------
// Aprovisionamento como MODAL FLUTUANTE (não substitui a lista) — #2
function oltAprovisionamento(){
    var ov=document.getElementById('oltApModal'); if(ov) ov.remove();
    ov=document.createElement('div'); ov.id='oltApModal';
    // Fundo transparente e clicavel-atraves -> nao bloqueia a pagina principal (#5)
    ov.style.cssText='position:fixed; inset:0; z-index:100050; display:flex; align-items:center; justify-content:center; background:transparent; pointer-events:none;';
    ov.innerHTML='<div id="oltApWin" data-max="0" style="pointer-events:auto; display:flex; flex-direction:column; width:min(96vw,820px); height:auto; max-height:88vh; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.5); overflow:hidden;">'+
        '<div id="oltApHead" style="flex:0 0 auto; display:flex; align-items:center; gap:10px; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-bottom:3px solid #a82424; cursor:move;">'+
          '<i class="fa-solid fa-plug-circle-plus" style="color:#ffffff;"></i>'+
          '<div style="flex:1 1 auto; font-weight:800; color:#ffffff;">Aprovisionamento — ONUs aguardando liberação</div>'+
          '<button onclick="oltApMin()" title="Minimizar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9);"><i class="fa-solid fa-minus"></i></button>'+
          '<button onclick="oltApMax()" title="Maximizar / Restaurar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9);"><i class="fa-solid fa-expand"></i></button>'+
          '<button onclick="oltFecharAprov()" title="Fechar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button>'+
        '</div>'+
        '<div id="oltApBody" style="flex:1 1 auto; overflow:auto; padding:14px;"></div></div>';
    document.body.appendChild(ov);
    // Torna o modal ARRASTÁVEL (pega pela barra de título azul)
    (function(){ var w=document.getElementById('oltApWin'), h=document.getElementById('oltApHead'), ov2=document.getElementById('oltApModal');
        if(!w||!h) return;
        h.addEventListener('mousedown', function(e){ if(e.target.closest('button')) return; if(w.getAttribute('data-max')==='1') return; e.preventDefault();
            var r=w.getBoundingClientRect(); if(ov2){ ov2.style.alignItems='flex-start'; ov2.style.justifyContent='flex-start'; }
            w.style.position='fixed'; w.style.margin='0'; w.style.left=r.left+'px'; w.style.top=r.top+'px';
            var sx=e.clientX, sy=e.clientY, ox=r.left, oy=r.top;
            function mv(ev){ w.style.left=(ox+ev.clientX-sx)+'px'; w.style.top=Math.max(0,(oy+ev.clientY-sy))+'px'; }
            function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
            document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
        });
    })();
    _oltApBody(_oltSpinner('Procurando ONUs novas na OLT (display ont autofind)...'));
    window._oltPausarFundo=true; // pausa o carregamento de fundo enquanto libera ONU
    // Nomes de VLAN salvos (aprendidos) — mescla com os fixos e re-renderiza
    fetch('olt_huawei.php?acao=vlan_nomes_get').then(function(r){ return r.json(); }).then(function(d){ if(d&&d.nomes){ window._oltVlanNomes=d.nomes; if(document.getElementById('oltApModal') && window._oltAutofindCache) oltRenderAutofind(window._oltAutofindCache); } }).catch(function(){});
    // ABRIU o Aprovisionar: mostra o CACHE na hora (instantâneo, nunca falha) e, POR CIMA, faz uma
    // (DIRETO, fora da fila oltFetch: antes o cache esperava atrás de leitura de placa/lotes — demorava a exibir)
    // leitura AO VIVO em 2º plano. Se a leitura viva falhar (OLT congestionada), MANTÉM o cache —
    // NUNCA joga "Erro/AbortError" na cara (era o bug: a leitura viva abortava e substituía a tela).
    _oltFetchDireto('olt_huawei.php?acao=autofind', 15000).then(function(r){ return r.json(); }).then(function(d){
        oltRenderAutofind(d||{pendentes:[]}); window._oltApSig=(((d&&d.pendentes)||[]).map(function(p){return (p.sn||p.serial||'');}).sort().join('|'));
    }).catch(function(){ oltRenderAutofind({pendentes:[]}); });
    _oltFetchDireto('olt_huawei.php?acao=autofind&force=1', 90000).then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.pendentes!=null){ oltRenderAutofind(d); window._oltApSig=((d.pendentes||[]).map(function(p){return (p.sn||p.serial||'');}).sort().join('|')); }
    }).catch(function(){});   // leitura viva falhou -> silêncio, fica o cache
    // AUTO-REFRESH: enquanto o modal está aberto, revê o autofind a cada 20s e re-renderiza SÓ quando
    // a lista muda (ONU nova apareceu ou foi liberada) — a ONU aparece sozinha, sem sair e voltar.
    if(window._oltApTimer) clearInterval(window._oltApTimer);
    window._oltApTimer=setInterval(function(){
        if(!document.getElementById('oltApModal')){ clearInterval(window._oltApTimer); window._oltApTimer=null; return; }
        // Periódico = CACHE (leve). Não usa force pra NÃO competir com o Autorizar pelo Telnet (era o
        // "só autoriza na 2ª tentativa"). O cron mantém o cache do autofind fresco; a leitura viva é só
        // na abertura. Se quiser forçar, feche e reabra o Aprovisionar.
        _oltFetchDireto('olt_huawei.php?acao=autofind', 15000).then(function(r){return r.json();}).then(function(d){
            var sig=((d&&d.pendentes)||[]).map(function(p){return (p.sn||p.serial||'');}).sort().join('|');
            if(window._oltApSig!=null && sig!==window._oltApSig){ window._oltApSig=sig; oltRenderAutofind(d); }
            else { window._oltApSig=sig; }
        }).catch(function(){});
    }, 20000);
}
function oltFecharAprov(){ var ov=document.getElementById('oltApModal'); if(ov) ov.remove(); var pill=document.getElementById('oltApPill'); if(pill) pill.remove(); if(window._oltApTimer){ clearInterval(window._oltApTimer); window._oltApTimer=null; } window._oltPausarFundo=false; oltEnriquecerSinal(); oltEnriquecerDetalhe(); oltEnriquecerUptime(); }
function oltApMax(){ var w=document.getElementById('oltApWin'), ov=document.getElementById('oltApModal'); if(!w||!ov) return; var m=w.getAttribute('data-max')==='1';
    if(m){ // RESTAURAR: limpa a posição fixa (se foi arrastado) p/ voltar a centralizar pelo flex
        w.setAttribute('data-max','0'); w.style.width='min(96vw,820px)'; w.style.height='auto'; w.style.maxHeight='88vh'; w.style.borderRadius='14px';
        w.style.position=''; w.style.left=''; w.style.top=''; w.style.margin='';
        ov.style.alignItems='center'; ov.style.justifyContent='center'; }
    else { // MAXIMIZAR: cola no canto 0,0 — se tinha sido arrastado, o left/top antigo jogava a janela p/ FORA da tela
        w.setAttribute('data-max','1'); w.style.position='fixed'; w.style.left='0'; w.style.top='0'; w.style.margin='0';
        w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0';
        ov.style.alignItems='flex-start'; ov.style.justifyContent='flex-start'; } }
function oltApMin(){ var ov=document.getElementById('oltApModal'); if(ov) ov.style.display='none'; var pill=document.getElementById('oltApPill');
    if(!pill){ pill=document.createElement('button'); pill.id='oltApPill'; pill.className='oltMinPill'; pill.onclick=function(){ var o=document.getElementById('oltApModal'); if(o) o.style.display='flex'; pill.style.display='none'; _oltPillsArrumar(); };
        pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:100060; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#dc2626; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
        pill.innerHTML='<i class="fa-solid fa-plug-circle-plus"></i> Aprovisionamento'; document.body.appendChild(pill); }
    pill.style.display='flex'; _oltPillsArrumar(); }
function _oltApBody(html){ var b=document.getElementById('oltApBody'); if(b) b.innerHTML=html; }
/* ATUALIZAR BUSCA — refaz o autofind na OLT e redesenha o card NO LUGAR.
 *
 * POR QUE ASSIM: a versao anterior recarregava a pagina (location=...) ou fechava e reabria o
 * modal. As duas coisas davam o "pisca branco" — o navegador descarta o documento e monta tudo
 * de novo. Aqui nada e' navegado nem removido: so o corpo do card (#oltApBody) e' reescrito,
 * exatamente como o pooling de 20s ja faz sozinho. O unico retorno visual e' o icone girando
 * no proprio botao, e a lista so troca quando a resposta chega.
 *
 * force=1 obriga a OLT a ser consultada por Telnet agora (sem force, vem do cache do cron).
 */
function oltApAtualizarBusca(bt){
    if(window._oltApBuscando) return;                 // clique repetido nao empilha consulta
    window._oltApBuscando=true;
    var ic = bt && bt.querySelector ? bt.querySelector('i') : null;
    if(ic) ic.className='fa-solid fa-arrows-rotate fa-spin';
    var solta=function(){ window._oltApBuscando=false; };
    /* ESPELHO DO SMARTOLT junto: sem isto o botao so' refazia o autofind da OLT.
       oltCarregarSmartOLT() guarda o mapa em window._oltSmartMap e NUNCA rebusca enquanto a pagina
       estiver aberta — entao VLAN, tipo ONU/ONT e zona vindos do SmartOLT ficavam congelados no que
       foi carregado na abertura. Zerando a variavel, a proxima chamada busca de novo; do lado do
       servidor, smartolt_mapa() reconstroi da API quando o cache passa de 10 minutos. */
    try{ window._oltSmartMap = null; if(typeof oltCarregarSmartOLT==='function') oltCarregarSmartOLT(); }catch(e){}
    _oltFetchDireto('olt_huawei.php?acao=autofind&force=1', 90000)
      .then(function(r){ return r.json(); })
      .then(function(d){
          if(d && d.pendentes!=null){
              window._oltApSig=(d.pendentes||[]).map(function(p){ return (p.sn||p.serial||''); }).sort().join('|');
              oltRenderAutofind(d);                   // reescreve so o corpo do card
          } else if(ic) { ic.className='fa-solid fa-arrows-rotate'; }
          solta();
      })
      .catch(function(){ if(ic) ic.className='fa-solid fa-arrows-rotate'; solta(); });
}
function oltRenderAutofind(d){
    window._oltAutofindCache=d; // guarda p/ re-render quando os perfis da OLT carregarem
    // Barra de gerenciadores no topo do Aprovisionamento (editam e sincronizam a página) — item 9.
    var _gbtn=function(ic,txt,fn){ return '<button onclick="'+fn+'" style="cursor:pointer; padding:9px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-size:11.5px; font-weight:800; white-space:nowrap; display:flex; align-items:center; justify-content:center; gap:7px; width:100%;"><i class="fa-solid '+ic+'"></i> '+txt+'</button>'; };
    var voltar='<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:8px; margin-bottom:12px;">'+
        _gbtn('fa-map-location-dot','Gerenciar Zona','oltGerenciarZonas()')+
        _gbtn('fa-server','Gerenciar Placa','oltGerenciarPlacas()')+
        _gbtn('fa-ethernet','Gerenciar Porta','oltGerenciarPortas()')+
        _gbtn('fa-network-wired','Gerenciar VLAN','oltGerenciarVlans()')+
        _gbtn('fa-microchip','Gerenciar Perfil ONT/ONU','oltGerenciarPerfis()')+
    '</div>';
    /* Liga/desliga o auto-conectar recarregando a PROPRIA pagina com ?autoconnect=0|1.
   Antes ia fixo para 'olt.php': no menu OLT e no Painel dos Concentradores isso tirava o
   operador da tela em que ele estava. Mantem os demais parametros da URL (p=painel, etc.);
   quem grava a preferencia e' o PHP de cada pagina, sempre no mesmo arquivo em disco. */
function _oltAutoConnToggle(cx){
    var on = cx && cx.checked ? '1' : '0';
    try{
        var u = new URL(location.href);
        u.searchParams.set('autoconnect', on);
        if(/\/olt\.php$/i.test(u.pathname)) u.searchParams.set('aprov','1');   // pagina autonoma reabre o card
        location.href = u.toString();
    }catch(e){
        var base = location.href.replace(/[?&]autoconnect=[01]/g,'');
        location.href = base + (base.indexOf('?')>-1 ? '&' : '?') + 'autoconnect=' + on;
    }
}
/* AUTO-CONECTAR — quem ja esta logado no WellSystem entra direto na OLT (padrao LIGADO).

       Desmarcado, a OLT volta a pedir login proprio (usuario root + senha do Telnet). A caixa
       recarrega a pagina com ?autoconnect=0|1: a preferencia e' gravada NO SERVIDOR
       (cache_trafego/olt_autoconnect.json), entao vale para todos os operadores, nao so para
       este navegador. Fica aqui no card por ser onde o operador ja esta quando decide isso. */
    var _autoc = (typeof window.WS_OLT_AUTOCONN==='undefined') ? true : !!window.WS_OLT_AUTOCONN;
    var conx = '<div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:flex-start; text-align:left; gap:8px 14px; margin-bottom:12px; padding:8px 10px 8px 0; border:1px solid '+OLTC.line+'; border-radius:10px; background:'+OLTC.bg2+';">'+
        '<label style="display:inline-flex; align-items:center; gap:7px; margin-left:0; padding-left:8px; cursor:pointer; font-size:12px; font-weight:700; color:'+OLTC.txt+';">'+
          '<input type="checkbox" '+(_autoc?'checked':'')+' onchange="_oltAutoConnToggle(this)" style="width:15px; height:15px; cursor:pointer;">'+
          '<i class="fa-solid fa-bolt" style="color:'+OLTC.amb+';"></i> Auto-conectar <span style="font-weight:600; color:'+OLTC.mut+';">(usa o login do WellSystem)</span></label>'+
        '<span style="font-size:11px; color:'+OLTC.mut+';">Desmarcado: pede login manual — usuario <b>root</b> + senha do Telnet.</span>'+
        (window.WS_OLT_UNIFICADA ? '' : '<button type="button" onclick="oltApAtualizarBusca(this)" title="Consultar a OLT agora e atualizar a lista de ONUs aguardando liberacao" style="margin-left:auto; cursor:pointer; padding:7px 12px; border-radius:8px; border:1px solid '+OLTC.red+'; background:'+OLTC.red+'; color:#ffffff; font-size:11.5px; font-weight:800; white-space:nowrap;"><i class="fa-solid fa-arrows-rotate"></i> Atualizar busca</button>')+
    '</div>';
    var pend=(d&&d.pendentes)||[];
    window._oltApPend=pend;   // guardado p/ o preenchimento automático (modelo de cada ONU nova → perfil)
    if(!pend.length){
        _oltApBody(voltar+conx+'<div style="text-align:center; padding:30px; color:'+OLTC.mut+';"><i class="fa-solid fa-circle-check" style="font-size:28px; color:'+OLTC.grn+';"></i><br><br>Nenhuma ONU nova aguardando liberação.</div>'+
            (d&&d.saida?'<details style="margin-top:10px;"><summary style="cursor:pointer; color:'+OLTC.mut+'; font-size:11px;">Ver saída da OLT</summary><pre style="white-space:pre-wrap !important; font-size:11px; color:'+OLTC.ink+' !important; background:'+OLTC.panel+' !important; border:1px solid '+OLTC.line+'; padding:10px; border-radius:8px; margin-top:6px;">'+_oltEsc(d.saida)+'</pre></details>':''));
        return;
    }
    var inSt='padding:9px 12px; border-radius:8px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.txt+'; font-size:13px;';
    var op=window._oltOpcoes||{};
    var cartoes=pend.map(function(o,i){
        var p=(o.fsp||'0/0/0').split('/');
        // #1 Tipo PON / Canal GPON (padrão GPON, mas selecionáveis) + #2 uso da PON detectada.
        var _fUso='0/'+(p[1]||'0')+'/'+(p[2]||'0');
        var _usados=(window._oltLista||[]).filter(function(x){return (x.fsp||'')===_fUso;}).length;
        var _max=128, _pct=Math.min(100,Math.round(_usados/_max*100)), _livre=Math.max(0,_max-_usados);
        var _corUso=(_pct>=90?OLTC.red:(_pct>=70?OLTC.amb:OLTC.grn));
        var _rad=function(nm,val,lbl,chk){ return '<label style="cursor:pointer; margin-right:12px; white-space:nowrap;"><input type="radio" name="'+nm+'_'+i+'" value="'+val+'"'+(chk?' checked':'')+' style="vertical-align:-1px; margin-right:3px;">'+lbl+'</label>'; };
        var extras='<div style="background:'+OLTC.panel+'; border:1px solid '+OLTC.acc+'55; border-radius:10px; padding:10px 12px; margin-bottom:12px;">'+
          '<div style="display:flex; flex-wrap:wrap; gap:6px 24px; align-items:center; margin-bottom:9px; font-size:12px; color:'+OLTC.txt+';">'+
            '<span><b style="color:'+OLTC.acc+'; font-size:10px; text-transform:uppercase; margin-right:6px;">Tipo PON</b>'+_rad('oltTipoPon','gpon','GPON',true)+_rad('oltTipoPon','epon','EPON',false)+'</span>'+
            '<span><b style="color:'+OLTC.acc+'; font-size:10px; text-transform:uppercase; margin-right:6px;">Canal GPON</b>'+_rad('oltCanal','gpon','GPON',true)+_rad('oltCanal','xgpon','XG-PON',false)+_rad('oltCanal','xgspon','XGS-PON',false)+'</span>'+
          '</div>'+
          '<div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; font-size:11.5px; margin-bottom:9px;">'+
            '<b style="color:'+OLTC.acc+'; font-size:10px; text-transform:uppercase;">Uso da PON '+_oltEsc(_fUso)+'</b>'+
            '<div style="flex:0 0 130px; height:9px; background:'+OLTC.bg2+'; border-radius:20px; overflow:hidden;"><div style="height:100%; width:'+_pct+'%; background:'+_corUso+';"></div></div>'+
            '<span style="font-weight:800; color:'+_corUso+';">'+_livre+' livre</span><span style="color:'+OLTC.mut+';">·</span><span style="color:'+OLTC.txt+';">'+_usados+' / '+_max+' ('+_pct+'%)</span>'+
          '</div>'+
          // Perfil GENÉRICO (outras marcas · Intelbras R1/R2) — fica aqui, junto das portas PON. Já vem listado (Generic_1/2/3…); só escolher.
          '<div style="display:flex; align-items:center; gap:10px; flex-wrap:nowrap; font-size:11.5px;">'+
            '<b style="color:'+OLTC.acc+'; font-size:10px; text-transform:uppercase; white-space:nowrap; flex:0 0 auto;" title="Perfil genérico da OLT para ONUs de outras marcas (Intelbras R1/R2 etc.)">Perfil genérico</b>'+
            '<div style="flex:0 1 240px; max-width:240px; min-width:0;">'+_oltPerfilCombo(i)+'</div>'+
            '<span style="color:'+OLTC.mut+'; font-size:10.5px; white-space:nowrap; flex:0 0 auto;">Marcas : Intelbras R1/R2 e etc</span>'+
          '</div>'+
          '</div>';
        return '<div style="background:'+OLTC.bg2+'; border:1px solid '+OLTC.amb+'55; border-radius:12px; padding:14px; margin-bottom:12px;">'+
            '<div style="display:flex; flex-wrap:wrap; gap:14px; align-items:center; margin-bottom:12px;">'+
              '<span style="color:'+OLTC.amb+'; font-weight:800;"><i class="fa-solid fa-plug-circle-plus"></i> ONU nova</span>'+
              (function(){ var _sn=String(o.sn||'').toLowerCase(); return '<span style="color:'+OLTC.txt+'; font-family:monospace;"><b>SN:</b> <span onclick="_oltCopiar(\''+_oltEsc(_sn)+'\')" title="Clique para copiar o serial" style="cursor:pointer; text-transform:lowercase; border-bottom:1px dotted '+OLTC.mut+';">'+_oltEsc(_sn)+' <i class="fa-regular fa-copy" style="font-size:11px; color:'+OLTC.grn+'; opacity:.85;"></i></span></span>'; })()+
              (o.modelo?'<span style="color:'+OLTC.mut+';"><b>Modelo:</b> '+_oltEsc(o.modelo)+'</span>':'')+
              (o.tempo?'<span style="color:'+OLTC.mut+';"><b>Detectada:</b> '+_oltEsc(String(o.tempo).split(/[\r\n]/)[0].replace(/[\s-]+$/,''))+'</span>':'')+
            '</div>'+
            // Placa/Porta vêm AUTOMÁTICAS do autofind, mas agora dá p/ TROCAR (Obs10).
            '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:8px;"><i class="fa-solid fa-location-dot" style="color:'+OLTC.acc+';"></i> Local detectado: <b style="color:'+OLTC.txt+';">Placa '+_oltEsc(p[1]||'-')+' · Porta PON '+_oltEsc(p[2]||'-')+'</b> — pode trocar abaixo se precisar.</div>'+
            _oltApMovidaHtml(o,i)+
            extras+
            '<div style="display:flex; flex-wrap:wrap; align-items:stretch; gap:14px 8px; margin-bottom:8px;">'+   // 14px entre linhas: cabe a dica "sugerido" do Perfil sem desalinhar
              _oltCampo('Placa (auto · pode trocar)','<select id="olt_slot_'+i+'" onchange="_oltAprovVlanAuto('+i+')" style="'+inSt+' width:100%;">'+_oltSlotOpts(p[1])+'</select>')+
              _oltCampo('Porta PON (auto · pode trocar)','<select id="olt_port_'+i+'" onchange="_oltAprovVlanAuto('+i+')" style="'+inSt+' width:100%;">'+_oltPortaOpts(p[2])+'</select>')+
              '<div style="flex:1 1 100%;"><label style="display:block; font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700; margin-bottom:2px;">Nome do Cliente</label><input id="olt_nome_'+i+'" type="text" placeholder="Nome completo" value="'+_oltEsc(((o.movida||o.movidaFeita)&&(o.movida||o.movidaFeita).nome)||'')+'" style="'+inSt+' width:100%; box-sizing:border-box; font-size:15px; padding:12px 14px; font-weight:600;"></div>'+
              _oltCampo('VLAN (nº + nome opcional)','<input id="olt_vlan_'+i+'" list="oltVlanDL" type="text" autocomplete="off" oninput="this.setAttribute(\'data-auto\',\'0\')" onchange="try{_oltAprovGenericoAuto('+i+', ((window._oltApPend||[])['+i+']||{}).modelo||\'\');}catch(e){}" placeholder="Ex.: 56 Rota de tal lugar" style="'+inSt+' width:100%; box-sizing:border-box;">')+
              _oltCampo('Tipo (grava na OLT)','<select id="olt_modo_'+i+'" onchange="this.setAttribute(\'data-manual\',\'1\'); _oltAprovPerfilAuto('+i+')" style="'+inSt+' width:100%;"><option value="bridge">Bridge (ONU)</option><option value="router">Router (ONT)</option></select>')+
              _oltCampo('Perfil ONU/ONT (cadastrado)','<select id="olt_srv_'+i+'" class="olt-srv-ap" onfocus="if(this.options.length<=1)_oltPreencherSrvAp()" onmousedown="if(this.options.length<=1)_oltPreencherSrvAp()" onchange="this.setAttribute(\'data-auto\',\'0\'); _oltSrvApChange(this,'+i+')" style="'+inSt+' width:100%;"><option value="">— usar o Tipo acima —</option></select>')+
              _oltCampo('Zona (+ todas do sistema)','<input id="olt_zona_'+i+'" list="oltZonaDLAp" type="text" autocomplete="off" oninput="this.setAttribute(\'data-auto\',\'0\')" placeholder="escolha ou digite a zona" style="'+inSt+' width:100%; box-sizing:border-box;">')+
            '</div>'+
            '<div id="olt_apbtns_'+i+'" style="display:'+(o.movida?'none':'flex')+'; justify-content:flex-end; margin-top:6px;">'+
              '<button onclick="oltAutorizar(\''+_oltEsc(o.sn)+'\','+i+')" style="cursor:pointer; padding:10px 20px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#ffffff; font-size:12.5px; font-weight:800;"><i class="fa-solid fa-circle-check"></i> Autorizar</button>'+
            '</div>'+
            '<div id="olt_autres_'+i+'" style="margin-top:8px;"></div>'+
        '</div>';
    }).join('');
    var datalist='<datalist id="oltVlanDL">'+_oltVlanOltOpts()+'</datalist>'+
                 '<datalist id="oltZonaDLAp">'+OLT_ZONAS.map(function(z){ return '<option value="'+_oltEsc(z)+'"></option>'; }).join('')+'</datalist>';
    _oltApBody(voltar+conx+datalist+'<div style="display:inline-flex; align-items:center; gap:6px; font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:12px;"><i class="fa-solid fa-circle" style="font-size:7px; color:'+OLTC.amb+';"></i> '+pend.length+' aguardando liberação — preencha o nome, escolha a VLAN/zona e autorize.</div>'+cartoes);
    _oltPreencherSrvAp(); // carrega os perfis ONU/ONT cadastrados nos selects
    _oltPerfisOltRefrescar(false); // cache rápido (sem Telnet) — evita contenção durante a varredura
    pend.forEach(function(_,i){ _oltAprovVlanAuto(i); }); // pré-preenche a VLAN pela VLAN padrão da porta
}
/* ONU MOVIDA DE PORTA (30/09/2026) — já liberada numa PON/VLAN e ligada em OUTRA. O autofind
   (olt_huawei.php, acao=autofind) manda 'movida' = {fsp,id,vlan,nome,status} de onde ela está
   cadastrada. A OLT não aceita o mesmo SN em duas portas: primeiro apaga o cadastro antigo (a MESMA
   exclusão da ficha: onu_acao/delete = undo service-port + deactivate + delete), depois autoriza aqui.
   "Mover" = apaga + abre a autorização (nome antigo já preenchido; VLAN = a da porta nova).
   "Deletar da porta antiga" = só apaga; o Autorizar normal do cartão aparece em seguida. */
function _oltApMovidaHtml(o,i){
    var m=o&&o.movida; if(!m) return '';
    var p=String(m.fsp||'').split('/');
    var vl=m.vlan?('VLAN '+_oltEsc(m.vlan)+(_oltVlanNome(m.vlan)?(' — '+_oltEsc(_oltVlanNome(m.vlan))):'')):'sem VLAN';
    var bt=function(fn,cor,bg,ic,txt){ return '<button onclick="'+fn+'" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+cor+'; background:'+bg+'; color:'+(bg==='transparent'?cor:'#ffffff')+'; font-size:12px; font-weight:800;"><i class="fa-solid '+ic+'"></i> '+txt+'</button>'; };
    return '<div id="olt_movida_'+i+'" style="background:rgba(245,158,11,.10); border:1px solid '+OLTC.amb+'; border-radius:10px; padding:10px 12px; margin-bottom:12px; font-size:12px; color:'+OLTC.txt+';">'+
        '<div style="font-weight:800; color:'+OLTC.amb+'; margin-bottom:4px;"><i class="fa-solid fa-right-left"></i> ONU já cadastrada em outra porta</div>'+
        '<div>Liberada em <b>Placa '+_oltEsc(p[1]||'-')+' · Porta '+_oltEsc(p[2]||'-')+'</b> (ID '+_oltEsc(m.id)+', '+vl+')'+(m.nome?(' — <b>'+_oltEsc(m.nome)+'</b>'):'')+(m.status?(' · '+_oltEsc(m.status)):'')+
        '. Foi ligada aqui, em outra porta/VLAN.</div>'+
        '<div style="display:flex; flex-wrap:wrap; gap:8px; justify-content:flex-end; margin-top:9px;">'+
          bt('oltApMovida('+i+',false)',OLTC.red,'transparent','fa-trash','Deletar da porta antiga')+
          bt('oltApMovida('+i+',true)',OLTC.grn,OLTC.grn,'fa-right-left','Mover para esta porta')+
        '</div><div id="olt_movres_'+i+'" style="margin-top:6px;"></div></div>';
}
function oltApMovida(i, autorizar){
    var o=(window._oltApPend||[])[i]; if(!o||!o.movida) return;
    var m=o.movida;
    if(autorizar && !_oltVal('olt_nome_'+i)){ var ni=document.getElementById('olt_nome_'+i); if(ni){ ni.focus(); ni.style.borderColor=OLTC.red; } return; }
    if(!confirm((autorizar?'MOVER':'DELETAR DA PORTA ANTIGA')+' — ONU '+o.sn+
        '\n\nApaga o cadastro antigo em '+m.fsp+' (ID '+m.id+(m.vlan?(', VLAN '+m.vlan):'')+'): service-port, desativar e deletar.'+
        (autorizar?'\nEm seguida AUTORIZA nesta porta com os dados do cartão (nome, VLAN, zona, tipo e perfil).':'\nDepois é só conferir os campos e Autorizar nesta porta.')+'\n\nConfirmar?')) return;
    // Guarda o formulário AGORA: a exclusão demora e o cartão pode ser redesenhado no meio (perfis/VLANs
    // terminam de carregar) — antes o nome sumia e a autorização parava calada. Repõe tudo antes de autorizar.
    var _ids=['olt_nome_','olt_vlan_','olt_zona_','olt_slot_','olt_port_','olt_modo_','olt_srv_','olt_perfil_'], _form={};
    _ids.forEach(function(p){ var el=document.getElementById(p+i); if(el) _form[p]={v:el.value, m:el.getAttribute('data-manual'), a:el.getAttribute('data-auto')}; });
    var _repor=function(){ _ids.forEach(function(p){ var el=document.getElementById(p+i), f=_form[p]; if(!el||!f||f.v==null) return;
        if(el.tagName==='SELECT'){ var tem=false; for(var k=0;k<el.options.length;k++){ if(el.options[k].value===f.v){ tem=true; break; } } if(!tem) return; }
        el.value=f.v; el.setAttribute('data-manual','1'); if(f.a!=null) el.setAttribute('data-auto','0'); }); };
    var res=document.getElementById('olt_movres_'+i);
    if(res) res.innerHTML='<span style="color:'+OLTC.acc+'; font-weight:700;"><i class="fa-solid fa-spinner fa-spin"></i> Apagando o cadastro antigo na OLT...</span>';
    var body=new URLSearchParams({ acao:'onu_acao', tipo:'delete', fsp:m.fsp, id:m.id }).toString();
    window._oltPausarFundo=true;
    var tenta=function(n){
        _oltFetchDireto('olt_huawei.php?'+body, 240000).then(function(r){ return r.json(); }).then(function(d){
            if(d && d.status!=='ok' && /OLT ocupada/i.test(d.message||'') && n<3){ setTimeout(function(){ tenta(n+1); }, 4000); return; }
            window._oltPausarFundo=false;
            if(!d || d.status!=='ok' || !d.sucesso){
                if(res) res.innerHTML='<div style="color:'+OLTC.red+'; font-weight:700;"><i class="fa-solid fa-triangle-exclamation"></i> A OLT não apagou o cadastro antigo — nada foi autorizado.</div>'+_oltPre((d&&(d.saida||d.message))||'sem resposta');
                return;
            }
            var k=m.fsp+'|'+m.id;
            if(window._oltLista){ window._oltLista=window._oltLista.filter(function(x){ return ((x.fsp||'')+'|'+x.id)!==k; }); try{ if(oltGerenciadorAberto()) oltRenderLista(); }catch(e){} }
            o.movida=null; o.movidaFeita=m;   // o nome/zona antigos continuam valendo se o cartão for redesenhado
            _repor();
            var bx=document.getElementById('olt_movida_'+i);
            if(bx) bx.innerHTML='<div style="color:'+OLTC.grn+'; font-weight:800;"><i class="fa-solid fa-circle-check"></i> Cadastro antigo removido de '+_oltEsc(m.fsp)+' (ID '+_oltEsc(m.id)+').'+(autorizar?' Autorizando nesta porta…':' Agora é só Autorizar nesta porta.')+'</div>';
            var bts=document.getElementById('olt_apbtns_'+i); if(bts) bts.style.display='flex';
            if(autorizar){
                if(!_oltVal('olt_nome_'+i)){ if(res) res.innerHTML='<div style="color:'+OLTC.red+'; font-weight:700;"><i class="fa-solid fa-triangle-exclamation"></i> Cadastro antigo apagado, mas o nome ficou vazio — preencha e clique em Autorizar.</div>'; return; }
                oltAutorizar(o.sn, i, true);   // já confirmado no "Mover": autoriza com os dados do cartão
            }
        }).catch(function(){
            window._oltPausarFundo=false;
            if(res) res.innerHTML='<div style="color:'+OLTC.amb+'; font-weight:700;"><i class="fa-solid fa-hourglass-end"></i> A OLT não respondeu a tempo — o cadastro antigo pode ter sido apagado. Clique em "Atualizar busca" antes de repetir.</div>';
        });
    };
    tenta(0);
}
// Porta PON (0-15) p/ o cartão de aprovisionamento — auto vem selecionada. (Placa usa _oltSlotOpts.)
function _oltPortaOpts(sel){ var o=''; for(var p=0;p<=15;p++){ o+='<option value="'+p+'"'+((''+p)===(''+sel)?' selected':'')+'>Porta '+p+'</option>'; } return o; }
/* Molde de UM campo do formulário (rótulo em cima, campo embaixo).
 *
 * ALINHAMENTO: os campos ficam numa grade de colunas automáticas, e os rótulos têm tamanhos
 * diferentes — "Placa (auto · pode trocar)" quebra em duas linhas, "VLAN" não. Como cada célula
 * crescia sozinha, os inputs começavam em alturas diferentes e a linha saía torta.
 * A correção é estrutural, não por medida fixa: cada célula vira uma coluna flex e o campo leva
 * margin-top:auto, então é EMPURRADO para a base da célula. Todas as células de uma linha da
 * grade já têm a mesma altura (stretch), logo todos os campos ficam na mesma linha de base —
 * com rótulo de uma, duas ou três linhas, e em qualquer largura de tela.
 */
function _oltCampo(label, inner, i, full){
    // flex:1 1 200px -> em linha flex o campo CRESCE e divide a largura por igual; com a janela
    // maximizada isso evita o que acontecia na grade de 150px: campos espremidos a esquerda e
    // o resto da linha vazio. Em contexto de grade (outras telas) a regra e' simplesmente ignorada.
    return '<div style="display:flex; flex-direction:column; min-width:0; flex:1 1 200px;'+(full?' margin-bottom:8px;':'')+'">'
         + '<label style="display:block; font-size:10px; line-height:1.3; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700; margin-bottom:4px;">'+label+'</label>'
         + '<div style="margin-top:auto;">'+inner+'</div>'
         + '</div>';
}

function _oltVal(id){ var el=document.getElementById(id); return el?(''+el.value).trim():''; }
function _oltVlanOpts(){ var v=[40]; var i; for(i=50;i<=60;i++)v.push(i); for(i=150;i<=165;i++)v.push(i); for(i=250;i<=265;i++)v.push(i); for(i=350;i<=365;i++)v.push(i); return v.map(function(x){return '<option value="'+x+'">'+x+'</option>';}).join(''); }
// Opções da VLAN (curada) com o NOME de cada uma — usadas no <datalist> (campo editável).
function _oltVlanOltOpts(){
    var v=[40]; var i; for(i=50;i<=60;i++)v.push(i); for(i=150;i<=165;i++)v.push(i); for(i=250;i<=265;i++)v.push(i); for(i=350;i<=365;i++)v.push(i);
    // inclui também qualquer VLAN que tenha nome mas esteja fora da faixa curada
    var extra=Object.keys(OLT_VLAN_NOMES).concat(Object.keys(window._oltVlanNomes||{}));
    extra.forEach(function(k){ var n=parseInt(k,10); if(n>0 && v.indexOf(n)<0) v.push(n); });
    v.sort(function(a,b){ return a-b; });
    // valor da opção = "56 - Nome" (aparece o nome na lista). O número é extraído na autorização.
    return v.map(function(x){ var nm=_oltVlanNome(x); var rot=x+(nm?(' - '+nm):''); return '<option value="'+_oltEsc(rot)+'"></option>'; }).join('');
}
// --- Gerenciador de VLANs (nomes editáveis, agrupados por placa/PON) -----------
function _oltVlanGrupo(id){ var p=_oltVlanPon(id); if(p) return 'Placa '+p.split('/')[0]; return 'Gestão / sem porta fixa'; }
function oltGerenciarVlans(){
    // reúne todas as VLANs: faixas curadas + as que têm nome + as lidas da OLT
    var set={}; var add=function(n){ n=parseInt(n,10); if(n>0&&n<=4094) set[n]=1; };
    add(40); var i; for(i=50;i<=60;i++)add(i); for(i=150;i<=165;i++)add(i); for(i=250;i<=265;i++)add(i); for(i=350;i<=365;i++)add(i); add(2222); add(3333);
    Object.keys(OLT_VLAN_NOMES).forEach(add); Object.keys(window._oltVlanNomes||{}).forEach(add);
    // VLANs da OLT podem vir como ARRAY [{id..}|id] OU como OBJETO {id:nome} — trata os dois
    // (antes, quando vinha objeto, o .forEach estourava e a página não abria).
    var _vo=window._oltVlansOlt;
    if(Array.isArray(_vo)) _vo.forEach(function(x){ add(x&&x.id!=null?x.id:x); });
    else if(_vo && typeof _vo==='object') Object.keys(_vo).forEach(add);
    var ids=Object.keys(set).map(function(k){return parseInt(k,10);}).sort(function(a,b){return a-b;});
    // agrupa por placa/faixa
    var grupos={}; var ordem=[];
    ids.forEach(function(id){ var g=_oltVlanGrupo(id); if(!grupos[g]){ grupos[g]=[]; ordem.push(g); } grupos[g].push(id); });
    var ordFixa=['Placa 1','Placa 3','Placa 5','Gestão / sem porta fixa'];
    ordem.sort(function(a,b){ var ia=ordFixa.indexOf(a), ib=ordFixa.indexOf(b); return (ia<0?99:ia)-(ib<0?99:ib); });
    var s=_oltInSt();
    var corpo=ordem.map(function(g){
        var linhas=grupos[g].map(function(id){
            var nm=_oltVlanNome(id); var pon=_oltVlanPon(id);
            return '<div style="display:flex; align-items:center; gap:10px; padding:5px 0;">'+
                '<span style="flex:0 0 50px; font-weight:800; font-family:monospace; color:'+OLTC.acc+';">'+id+'</span>'+
                '<span style="flex:0 0 78px; font-size:11px; color:'+OLTC.mut+'; white-space:nowrap;">'+(pon?('<i class="fa-solid fa-ethernet"></i> '+_oltEsc(pon)):'—')+'</span>'+
                '<input id="oltVlN_'+id+'" value="'+_oltEsc(nm)+'" placeholder="nome da VLAN..." onchange="oltVlanNomeSalvar('+id+',this.value)" style="'+s+' flex:1 1 auto; min-width:0;">'+
                '<span id="oltVlOk_'+id+'" style="flex:0 0 auto; width:18px; color:'+OLTC.grn+'; font-size:13px;"></span>'+
                '<button onclick="oltExcluirVlan('+id+')" title="Excluir a VLAN '+id+' da OLT" style="flex:0 0 auto; cursor:pointer; width:26px; height:26px; border-radius:6px; border:1px solid '+OLTC.redf+'; background:transparent; color:'+OLTC.redf+'; font-size:11px;"><i class="fa-solid fa-trash"></i></button>'+
            '</div>';
        }).join('');
        return '<div style="margin-bottom:14px;"><div style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.mut+'; border-bottom:1px solid '+OLTC.line+'; padding-bottom:4px; margin-bottom:6px;">'+_oltEsc(g)+'</div>'+linhas+'</div>';
    }).join('');
    // Barra de ações no topo: ADICIONAR VLAN de verdade na OLT (editar nome = campo; excluir = lixeira).
    var topo='<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:12px; padding-bottom:10px; border-bottom:1px solid '+OLTC.line+';">'+
        '<span style="font-size:11px; color:'+OLTC.mut+'; flex:1 1 auto;">Editar nome = campo · Excluir = <i class="fa-solid fa-trash" style="color:'+OLTC.red+';"></i> · Criar grava na OLT:</span>'+
        '<button onclick="oltCriarVlan()" style="cursor:pointer; padding:7px 12px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:11px;"><i class="fa-solid fa-plus"></i> Adicionar VLAN na OLT</button>'+
    '</div>';
    _oltModalSimples('fa-network-wired', 'Gerenciar VLANs — criar / nomear / excluir', topo+corpo);
    // Carrega as VLANs reais da OLT em 2º plano p/ INCLUIR extras na PRÓXIMA vez.
    // NÃO reconstrói o modal aberto (isso apagava o que estava sendo digitado — bug).
    if(!window._oltVlansOlt){ fetch('olt_huawei.php?acao=vlans_olt').then(function(r){return r.json();}).then(function(d){ var vl=(d&&(d.nomes||d.vlans)); if(vl) window._oltVlansOlt=vl; }).catch(function(){}); }
}
function oltVlanNomeSalvar(id, val){
    val=(''+val).trim();
    window._oltVlanNomes=window._oltVlanNomes||{}; window._oltVlanNomes[''+id]=val;
    var ok=document.getElementById('oltVlOk_'+id); if(ok){ ok.innerHTML='<i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+';"></i>'; }
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=vlan_nomes_add&vlan='+encodeURIComponent(id)+'&nome='+encodeURIComponent(val)})
      .then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.nomes){ window._oltVlanNomes=d.nomes; }
        window._oltVlanNomes[''+id]=val; // mantém local mesmo que o backend não devolva no mapa
        // ✓ verde SÓ se o servidor confirmou (senão avisa: pode ser permissão de gravação)
        var confirmou=!!(d&&d.nomes&&(''+(d.nomes[''+id]||''))===val);
        if(ok){ ok.innerHTML=confirmou?'<i class="fa-solid fa-check" style="color:'+OLTC.grn+';"></i>':'<i class="fa-solid fa-triangle-exclamation" style="color:'+OLTC.amb+';" title="Não confirmou a gravação no servidor"></i>'; setTimeout(function(){ if(ok) ok.innerHTML=''; }, 2500); }
        // Atualiza JÁ o datalist do aprovisionamento e a lista principal (antes não listava o novo nome)
        var dl=document.getElementById('oltVlanDL'); if(dl) dl.innerHTML=_oltVlanOltOpts();
        if(oltGerenciadorAberto()) oltRenderLista(); _oltResumoRefresh();
        if(!confirmou) _oltCorrigirGravacao(); // dispara o auto-corretor/aviso de permissão
      }).catch(function(){ if(ok) ok.innerHTML='<i class="fa-solid fa-xmark" style="color:'+OLTC.red+';"></i>'; });
}
// Editor de ZONAS (espelha o de VLANs): renomeia uma zona e aplica em TODAS as ONUs dela.
function oltGerenciarZonas(){
    var lista=window._oltLista||[];
    var zonas={}; lista.forEach(function(o){ var z=(o.zona||'').trim(); if(z){ zonas[z]=(zonas[z]||0)+1; } });
    // Inclui zonas cadastradas SEM ONU ainda (opções locais salvas) -> aparecem pra usar/editar.
    (window._oltZonasOpc||[]).forEach(function(z){ z=(''+z).trim(); if(z && zonas[z]==null) zonas[z]=0; });
    var nomes=Object.keys(zonas).sort(function(a,b){ return a.localeCompare(b,'pt'); });
    var s=_oltInSt();
    var linhas=nomes.length?nomes.map(function(z){
        return '<div style="display:flex; align-items:center; gap:10px; padding:5px 0;">'+
            '<span style="flex:0 0 auto; min-width:34px; text-align:center; background:'+OLTC.acc+'22; color:'+OLTC.acc+'; font-weight:800; font-size:11px; padding:2px 9px; border-radius:20px;">'+zonas[z]+'</span>'+
            '<input value="'+_oltEsc(z)+'" data-zona-old="'+_oltEsc(z)+'" onchange="oltZonaRenomear(this)" placeholder="nome da zona..." style="'+s+' flex:1 1 auto; min-width:0;">'+
            '<span class="oltZnOk" style="flex:0 0 auto; width:18px; color:'+OLTC.grn+'; font-size:13px;"></span>'+
            '<button onclick="oltZonaExcluir(\''+_oltEsc((''+z).replace(/'/g,''))+'\')" title="Excluir esta zona" style="flex:0 0 auto; cursor:pointer; width:26px; height:26px; border-radius:6px; border:1px solid '+OLTC.redf+'; background:transparent; color:'+OLTC.redf+'; font-size:11px;"><i class="fa-solid fa-trash"></i></button>'+
        '</div>';
    }).join(''):'<div style="color:'+OLTC.mut+'; font-size:12px; padding:8px 0;">Nenhuma zona cadastrada ainda.</div>';
    var topo='<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:12px; padding-bottom:10px; border-bottom:1px solid '+OLTC.line+';">'+
        '<span style="font-size:11px; color:'+OLTC.mut+'; flex:1 1 auto;">Zona é um rótulo local (não vai pra OLT). Editar = campo · Excluir = <i class="fa-solid fa-trash" style="color:'+OLTC.redf+';"></i></span>'+
        '<button onclick="oltZonaAdicionar()" style="cursor:pointer; padding:7px 12px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:11px;"><i class="fa-solid fa-plus"></i> Adicionar zona</button>'+
    '</div>';
    _oltModalSimples('fa-map-location-dot', 'Gerenciar Zonas — adicionar / nomear / excluir', topo+linhas);
    if(!window._oltZonasOpc){ fetch('olt_huawei.php?acao=opcoes_get').then(function(r){return r.json();}).then(function(d){ var z=(d&&d.opcoes&&d.opcoes.zona)||[]; window._oltZonasOpc=z; if(z.length){ var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarZonas(); } } }).catch(function(){ window._oltZonasOpc=[]; }); }
}
// Adiciona uma zona LOCAL (fica salva em opções; aparece nos datalists e no aprovisionamento).
function oltZonaAdicionar(){
    var z=prompt('Nome da nova zona:',''); if(z===null) return; z=(''+z).trim(); if(!z){ return; }
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=opcoes_add&campo=zona&valor='+encodeURIComponent(z)})
      .then(function(r){return r.json();}).then(function(d){ window._oltZonasOpc=(d&&d.opcoes&&d.opcoes.zona)||window._oltZonasOpc||[];
        try{ if(OLT_ZONAS.indexOf(z)<0){ OLT_ZONAS.push(z); OLT_ZONAS.sort(function(a,b){return a.localeCompare(b,'pt');}); } }catch(e){}
        var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarZonas(); }
      }).catch(function(){ alert('Erro ao salvar a zona.'); });
}
// Exclui a zona: tira das opções e limpa das ONUs que a usam (zona vira vazio).
function oltZonaExcluir(z){
    z=(''+z).trim(); if(!z) return;
    var lista=window._oltLista||[]; var usando=lista.filter(function(o){ return (o.zona||'').trim()===z; }).length;
    if(!confirm('Excluir a zona "'+z+'"?'+(usando?('\n\n'+usando+' cliente(s) estão nessa zona — eles ficarão SEM zona.'):''))) return;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=opcoes_del&campo=zona&valor='+encodeURIComponent(z)})
      .then(function(r){return r.json();}).then(function(d){ window._oltZonasOpc=(d&&d.opcoes&&d.opcoes.zona)||[]; }).catch(function(){});
    try{ var ix=OLT_ZONAS.indexOf(z); if(ix>-1) OLT_ZONAS.splice(ix,1); }catch(e){}
    // limpa das ONUs que a usam
    window._oltCadastro=window._oltCadastro||{};
    lista.forEach(function(o){ if((o.zona||'').trim()===z){ o.zona='';
        var snK=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(snK){ window._oltCadastro[snK]=window._oltCadastro[snK]||{}; window._oltCadastro[snK].zona=''; }
        fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial||'')+'&campo=zona&valor='}).catch(function(){});
    }});
    if(typeof oltRenderLista==='function' && oltGerenciadorAberto()) oltRenderLista(); _oltResumoRefresh();
    var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarZonas(); }
}
function oltZonaRenomear(inp){
    var novo=(''+inp.value).trim(); var velho=inp.getAttribute('data-zona-old')||'';
    if(!novo || novo===velho){ inp.value=velho; return; }
    var lista=window._oltLista||[]; window._oltCadastro=window._oltCadastro||{};
    lista.forEach(function(o){ if((o.zona||'').trim()===velho){
        o.zona=novo;
        var snK=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(!snK) return;
        window._oltCadastro[snK]=window._oltCadastro[snK]||{}; window._oltCadastro[snK].zona=novo;
        fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(o.serial||'')+'&campo=zona&valor='+encodeURIComponent(novo)})
          .then(function(r){ return r.json(); }).then(function(d){ _oltAvisaGravacao(d); }).catch(function(){});
    }});
    inp.setAttribute('data-zona-old', novo);
    var ok=inp.parentNode.querySelector('.oltZnOk'); if(ok){ ok.innerHTML='<i class="fa-solid fa-check"></i>'; setTimeout(function(){ if(ok) ok.innerHTML=''; }, 1500); }
    if(typeof oltRenderLista==='function' && oltGerenciadorAberto()) oltRenderLista();
    _oltResumoRefresh();
}
// Lista (HTML) dos perfis ONT/ONU curados p/ o gerenciador de perfis.
// ---- MODELOS capturados da OLT: nome de exibição + tipo, editáveis --------------
function _oltModelosCarregar(cb){
    fetch('olt_huawei.php?acao=modelos_get').then(function(r){return r.json();}).then(function(d){
        window._oltModelos=(d&&d.modelos)||{}; if(cb) cb();
    }).catch(function(){ window._oltModelos=window._oltModelos||{}; if(cb) cb(); });
}
function _oltModeloInfo(mod){ var k=String(mod||'').toUpperCase().trim(); var m=window._oltModelos||{}; return m[k]||null; }
// Lista os modelos REAIS que a OLT reportou (a partir da lista carregada) + os já cadastrados.
function _oltModelosListaHtml(){
    var cont={}; (window._oltLista||[]).forEach(function(o){
        var m=String(o.modelo||'').trim(); if(!m||m==='—') return;
        var k=m.toUpperCase(); cont[k]=(cont[k]||0)+1;
    });
    var salvos=window._oltModelos||{};
    Object.keys(salvos).forEach(function(k){ if(cont[k]==null) cont[k]=0; });
    var ks=Object.keys(cont).sort();
    if(!ks.length) return '<div style="color:'+OLTC.mut+'; padding:12px; text-align:center; font-size:12px;">Nenhum modelo capturado ainda. Abra a lista de ONUs para a OLT reportar os modelos.</div>';
    var s=_oltInSt();
    return ks.map(function(k){
        var inf=salvos[k]||{nome:'',tipo:''}; var ke=encodeURIComponent(k);
        return '<div style="display:flex; align-items:center; gap:8px; padding:6px 0; flex-wrap:wrap;">'+
            '<span title="Modelo reportado pela OLT" style="flex:0 0 132px; font-family:monospace; font-weight:800; color:'+OLTC.ink+'; font-size:11.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(k)+'</span>'+
            '<span onclick="oltFiltrarModelo(\''+ke+'\'); var w=this.closest(\'.oltMSWin\'); if(w) w.remove();" title="Clique para ver as ONUs/ONTs deste modelo na lista" style="cursor:pointer; flex:0 0 auto; min-width:30px; text-align:center; background:'+OLTC.acc+'22; color:'+OLTC.acc+'; font-weight:800; font-size:10.5px; padding:2px 8px; border-radius:20px; transition:transform .1s;" onmouseover="this.style.transform=\'scale(1.12)\'" onmouseout="this.style.transform=\'\'">'+cont[k]+'</span>'+
            '<input id="oltMdN_'+ke+'" value="'+_oltEsc(inf.nome||'')+'" placeholder="nome de exibição (ex.: Intelbras 110B)" style="'+s+' flex:2 1 170px; min-width:0;">'+
            '<select id="oltMdT_'+ke+'" style="'+s+' flex:0 0 120px;">'+
              '<option value=""'+(!inf.tipo?' selected':'')+'>— automático —</option>'+
              '<option value="ONU"'+(inf.tipo==='ONU'?' selected':'')+'>ONU · Bridge</option>'+
              '<option value="ONT"'+(inf.tipo==='ONT'?' selected':'')+'>ONT · Router</option>'+
            '</select>'+
            '<button onclick="_oltModeloSalvar(\''+ke+'\',this)" title="Salvar este modelo" style="cursor:pointer; flex:0 0 auto; width:32px; height:32px; border-radius:7px; border:1px solid '+OLTC.grn+'; background:transparent; color:'+OLTC.grn+';"><i class="fa-solid fa-floppy-disk"></i></button>'+
        '</div>';
    }).join('');
}
function _oltModeloSalvar(keyEnc, btn){
    var k=decodeURIComponent(keyEnc);
    var n=document.getElementById('oltMdN_'+keyEnc), t=document.getElementById('oltMdT_'+keyEnc);
    var ic=btn&&btn.querySelector('i'); if(ic){ ic.className='fa-solid fa-spinner fa-spin'; }
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'acao=modelos_set&chave='+encodeURIComponent(k)+'&nome='+encodeURIComponent(n?n.value:'')+'&tipo='+encodeURIComponent(t?t.value:'')})
      .then(function(r){return r.json();}).then(function(d){
        window._oltModelos=(d&&d.modelos)||window._oltModelos;
        if(ic){ ic.className='fa-solid fa-check'; setTimeout(function(){ ic.className='fa-solid fa-floppy-disk'; },1400); }
        if(typeof oltRenderLista==='function') oltRenderLista();
      }).catch(function(){ if(ic) ic.className='fa-solid fa-triangle-exclamation'; });
}
function _oltPerfListaHtml(){
    var srv=_oltSrvCuradosAp();
    if(!srv.length) return '<div style="color:'+OLTC.mut+'; padding:12px; text-align:center;">Nenhum perfil carregado ainda. Clique em recarregar (↻) pra ler da OLT.</div>';
    return srv.map(function(p){ var isR=/^ONT/i.test(p.nome);
        return '<div style="display:flex; align-items:center; justify-content:space-between; gap:10px; padding:8px 10px; border-radius:8px; background:'+OLTC.bg2+'; margin-bottom:6px;">'+
            '<span style="font-weight:700; color:'+OLTC.txt+';"><i class="fa-solid '+(isR?'fa-wifi':'fa-ethernet')+'" style="color:'+(isR?OLTC.vio:OLTC.acc)+';"></i> '+_oltEsc(p.nome)+'</span>'+
            '<span style="font-size:11px; font-weight:800; color:#fff; background:'+(isR?OLTC.vio:OLTC.acc)+'; border-radius:20px; padding:2px 10px; white-space:nowrap;">'+(isR?'Router (ONT)':'Bridge (ONU)')+' · id '+p.id+'</span>'+
        '</div>';
    }).join('');
}
// Gráficos por PON (tráfego SNMP) — um mini-gráfico por porta, estilo SmartOLT.
function _oltGrafSVG(titulo, pts){
    var W=340,H=118,pad=7;
    if(!pts.length) return '';
    var maxv=1; pts.forEach(function(p){ maxv=Math.max(maxv,p.up,p.down); });
    var n=pts.length, x=function(i){ return pad+(W-2*pad)*(n<2?0:(i/(n-1))); }, y=function(v){ return (H-pad)-(H-2*pad)*(v/maxv); };
    var line=function(key,cor){ var d=''; pts.forEach(function(p,i){ d+=(i?'L':'M')+x(i).toFixed(1)+' '+y(p[key]).toFixed(1)+' '; }); return '<path d="'+d+'" fill="none" stroke="'+cor+'" stroke-width="1.7"/>'; };
    var fmt=function(v){ return v>=1e6?((v/1e6).toFixed(1)+' Mbps'):(v>=1e3?((v/1e3).toFixed(0)+' kbps'):(Math.round(v)+' bps')); };
    // HOVER: faixas transparentes por ponto com <title> -> passar o mouse mostra hora · ↓ · ↑.
    var hv=''; for(var hi=0;hi<n;hi++){ var xc=x(hi); var x0=hi?(x(hi-1)+xc)/2:xc-1; var x1=(hi<n-1)?(xc+x(hi+1))/2:xc+1; var tt=(pts[hi].ts?(_oltHm(pts[hi].ts)+'  ·  '):'')+'↓ '+fmt(pts[hi].down)+'   ↑ '+fmt(pts[hi].up); hv+='<rect x="'+x0.toFixed(1)+'" y="'+pad+'" width="'+Math.max(1,x1-x0).toFixed(1)+'" height="'+(H-2*pad)+'" fill="transparent" style="cursor:crosshair;"><title>'+tt+'</title></rect>'; }
    var cur=pts[n-1]||{up:0,down:0};
    return '<div style="background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:10px; padding:10px;">'+
        '<div style="font-size:12px; font-weight:800; color:'+OLTC.acc+'; margin-bottom:5px;">'+_oltEsc(titulo)+'</div>'+
        '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%; height:96px; display:block; background:'+OLTC.bg+'; border-radius:6px;">'+line('down','#3b82f6')+line('up','#f59e0b')+hv+'</svg>'+
        '<div style="display:flex; flex-wrap:wrap; gap:12px; font-size:10.5px; margin-top:5px;"><span style="color:#f59e0b; font-weight:700;">■ Upload '+fmt(cur.up)+'</span><span style="color:#3b82f6; font-weight:700;">■ Download '+fmt(cur.down)+'</span><span style="color:'+OLTC.mut+';">pico '+fmt(maxv)+'</span></div>'+
    '</div>';
}
// Gráfico de SINAL óptico (Rx) no tempo — 1 série, valores negativos (dBm). Autoescala.
function _oltGrafSinalSVG(serie){
    if(!serie || serie.length<2) return '<div style="font-size:11px; color:'+OLTC.mut+'; padding:6px 0;">Ainda sem histórico de sinal — a coleta SNMP roda a cada ~3 min. Volte em alguns minutos.</div>';
    var W=340,H=88,pad=8;
    var min=Math.min.apply(null,serie), max=Math.max.apply(null,serie);
    if(min===max){ min-=1; max+=1; } else { var m=(max-min)*0.15; min-=m; max+=m; }
    var n=serie.length, x=function(i){ return pad+(W-2*pad)*(n<2?0:i/(n-1)); }, y=function(v){ return (H-pad)-(H-2*pad)*((v-min)/(max-min)); };
    var d=''; serie.forEach(function(v,i){ d+=(i?'L':'M')+x(i).toFixed(1)+' '+y(v).toFixed(1)+' '; });
    var area='M'+x(0).toFixed(1)+' '+(H-pad).toFixed(1)+' '; serie.forEach(function(v,i){ area+='L'+x(i).toFixed(1)+' '+y(v).toFixed(1)+' '; }); area+='L'+x(n-1).toFixed(1)+' '+(H-pad).toFixed(1)+' Z';
    var cur=serie[n-1], melhor=Math.max.apply(null,serie), pior=Math.min.apply(null,serie);
    var cor=_oltCorSinal(cur)||OLTC.grn;
    // HOVER: faixa por amostra com <title> -> passar o mouse mostra o Rx (dBm) daquele ponto.
    var hv=''; for(var hi=0;hi<n;hi++){ var xc=x(hi); var x0=hi?(x(hi-1)+xc)/2:xc-1; var x1=(hi<n-1)?(xc+x(hi+1))/2:xc+1; hv+='<rect x="'+x0.toFixed(1)+'" y="0" width="'+Math.max(1,x1-x0).toFixed(1)+'" height="'+H+'" fill="transparent" style="cursor:crosshair;"><title>Rx '+serie[hi].toFixed(2)+' dBm</title></rect>'; }
    return '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%; height:74px; display:block; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:6px;">'+
        '<line x1="'+pad+'" y1="'+(H/2).toFixed(1)+'" x2="'+(W-pad)+'" y2="'+(H/2).toFixed(1)+'" stroke="'+OLTC.line+'" stroke-width="0.7" stroke-dasharray="3 3"/>'+
        '<path d="'+area+'" fill="'+cor+'" opacity="0.12"/>'+
        '<path d="'+d+'" fill="none" stroke="'+cor+'" stroke-width="1.8"/>'+
        '<circle cx="'+x(n-1).toFixed(1)+'" cy="'+y(cur).toFixed(1)+'" r="2.6" fill="'+cor+'"/>'+hv+'</svg>'+
        '<div style="display:flex; flex-wrap:wrap; gap:12px; font-size:10.5px; margin-top:5px;"><span style="color:'+cor+'; font-weight:800;"><i class="fa-solid fa-wave-square"></i> Rx '+cur.toFixed(2)+' dBm</span><span style="color:'+OLTC.mut+';">melhor '+melhor.toFixed(2)+' · pior '+pior.toFixed(2)+' · '+n+' amostras</span></div>';
}
// PON = portas cujo SLOT é GPON (OLT_SLOTS, ex.: 1/3/5). Uplink = as demais (ethernet, slot 6/7).
function _oltSlotDe(k){ var p=(''+k).split('/'); return (p.length>=2)?parseInt(p[1],10):NaN; }
function _oltEhGpon(k){ try{ return (OLT_SLOTS||[]).indexOf(_oltSlotDe(k))>-1; }catch(e){ return true; } }
function oltGraficosPon(){ _oltGraficosTraf('pon'); }
function oltGraficosUplink(){ _oltGraficosTraf('uplink'); }
// PERFORMANCE: abre INSTANTÂNEO do cache e só auto-atualiza a cada 45s enquanto a janela ficar aberta.
// NÃO dispara mais "snmp_coletar" ao abrir (era pesado — varre 695 ONUs — e deixava a página lenta).
// O cron já coleta a cada 1 min, então o cache está sempre fresco (no máx. 1 min de atraso).
function _oltGrafAutoColeta(bodyId, load){
    load();   // mostra na hora o que já está no cache (rápido)
    var t=setInterval(function(){ if(!document.getElementById(bodyId)){ clearInterval(t); return; } load(); }, 45000);
}
// Renderiza os gráficos de tráfego (mesmo histórico SNMP) filtrando PON x Uplink.
function _oltGraficosTraf(modo){
    var up=(modo==='uplink');
    var tit=up?'Gráficos de Uplink (tráfego via SNMP)':'Gráficos por PON (tráfego via SNMP)';
    var ic=up?'fa-network-wired':'fa-chart-line';
    _oltModalSimples(ic, tit, '<div id="oltGpBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Coletando SNMP e carregando...')+'</div>', false);
    var load=function(){
        _oltFetchDireto('olt_huawei.php?acao=snmp_traf_hist', 15000).then(function(r){return r.json();}).then(function(d){
            var b=document.getElementById('oltGpBody'); if(!b) return;
            var h=(d&&d.hist)||[];
            if(h.length<2){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px; line-height:1.7;">Coletando… assim que houver 2 amostras (poucos minutos) o gráfico aparece sozinho. Esta janela atualiza a cada 45s.</div>'; return; }
            var portas={}; h.forEach(function(s){ for(var k in s){ if(k!=='ts') portas[k]=1; } });
            // ordena por PLACA/porta (numérico, não alfabético: 0/1/2 antes de 0/1/10)
            var keys=Object.keys(portas).filter(function(k){ return up? !_oltEhGpon(k) : _oltEhGpon(k); }).sort(function(a,b){ var pa=a.split('/'),pb=b.split('/'); return ((+pa[1]||0)-(+pb[1]||0))||((+pa[2]||0)-(+pb[2]||0))||a.localeCompare(b); });
            if(!keys.length){ b.innerHTML='<div style="color:'+OLTC.mut+'; padding:10px;">'+(up?'Nenhuma porta de uplink no histórico ainda.':'Nenhuma porta PON no histórico ainda.')+'</div>'; return; }
            // insere um cabeçalho "PLACA X" (linha inteira) quando a placa muda — só no modo PON.
            var _lastSl=null, _prim=true;
            var cards=keys.map(function(k){ var pts=[]; h.forEach(function(s){ if(s[k]) pts.push({up:s[k][0], down:s[k][1], ts:s.ts}); });
                var sep='';
                if(!up){ var sl=(k.split('/')[1]||'?'); if(sl!==_lastSl){ _lastSl=sl;
                    sep='<div style="grid-column:1/-1; margin:'+(_prim?'0':'10px')+' 0 2px; padding:7px 12px; background:'+OLTC.acc+'14; border-left:4px solid '+OLTC.acc+'; border-radius:8px; font-weight:800; color:'+OLTC.acc+'; font-size:13px; letter-spacing:.5px;"><i class="fa-solid fa-server"></i> PLACA '+sl+'</div>'; _prim=false; } }
                var titk=(up?'uplink ':'gpon ')+k; if(!up){ var pn=(typeof _oltPortaNome==='function'?(_oltPortaNome(k)||''):''); if(pn) titk+=' — '+pn; }
                return sep+_oltGrafSVG(titk, pts); }).join('');
            b.style.textAlign='left';
            b.innerHTML='<div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:12px;">'+cards+'</div>'+
                '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:10px;"><i class="fa-solid fa-arrows-rotate"></i> Atualiza sozinho a cada 45s · Upload = tráfego → OLT · Download = OLT → destino.</div>';
        }).catch(function(){ var b=document.getElementById('oltGpBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha ao carregar o histórico.</div>'; });
    };
    _oltGrafAutoColeta('oltGpBody', load);
}
// ===== Gráficos de SINAL (Rx por ONU no tempo) — grade filtrável, estilo SmartOLT =====
function oltGraficosSinal(){
    window._oltGsPag=1; window._oltGsQ=null;   // começa sempre na página 1
    _oltModalSimples('fa-wave-square','Gráficos de Sinal — Rx por ONU (SNMP)',
      '<div style="margin-bottom:10px; position:relative; max-width:340px;"><i class="fa-solid fa-magnifying-glass" style="position:absolute; left:11px; top:50%; transform:translateY(-50%); color:'+OLTC.mut+'; font-size:12px; pointer-events:none;"></i><input id="oltGsFiltro" oninput="oltGsRender()" placeholder="filtrar por nome, F/S/P ou zona..." style="'+_oltInSt()+' width:100%; box-sizing:border-box; padding-left:32px;"></div>'+
      '<div id="oltGsBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Coletando SNMP e carregando...')+'</div>', false);
    var load=function(){
        _oltFetchDireto('olt_huawei.php?acao=snmp_sinal_hist', 15000).then(function(r){return r.json();}).then(function(d){
            window._oltSigHist=(d&&d.v)||{}; oltGsRender();
        }).catch(function(){ var b=document.getElementById('oltGsBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha ao carregar.</div>'; });
    };
    _oltGrafAutoColeta('oltGsBody', load);
}
function oltGsRender(){
    var b=document.getElementById('oltGsBody'); if(!b) return;
    var hist=window._oltSigHist||{}; var lista=window._oltLista||[];
    var q=((document.getElementById('oltGsFiltro')||{}).value||'').toLowerCase().trim();
    var info={}; lista.forEach(function(o){ info[(o.fsp||'')+'|'+o.id]=o; });
    var keys=Object.keys(hist);
    if(!keys.length){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px;">Ainda sem histórico de sinal (a coleta SNMP roda a cada ~3 min). Volte em alguns minutos.</div>'; return; }
    // Agrupa por PLACA/porta e, DENTRO da placa, "pior Rx primeiro" (mantém o diagnóstico).
    keys.sort(function(a,b){ var pa=(a.split('|')[0]||'').split('/'),pb=(b.split('|')[0]||'').split('/');
        var d=((+pa[1]||0)-(+pb[1]||0))||((+pa[2]||0)-(+pb[2]||0)); if(d) return d;
        var sa=hist[a], sb=hist[b]; return (sa[sa.length-1])-(sb[sb.length-1]); });
    // Reseta a página quando o FILTRO muda (senão fica numa página que não existe mais no resultado filtrado).
    if(window._oltGsQ!==q){ window._oltGsQ=q; window._oltGsPag=1; }
    var filtrados=[];
    for(var i=0;i<keys.length;i++){ var k=keys[i]; var o=info[k]||{}; var nome=(typeof _oltNomeDe==='function'?_oltNomeDe(o):'')||o.serial||k;
        var hay=_oltNorm(nome+' '+(o.nome||'')+' '+k+' '+(o.zona||'')); if(q && !_oltPalavras(hay,q)) continue;
        filtrados.push({k:k, o:o, nome:nome});
    }
    var total=filtrados.length, pp=48;
    var totalPag=Math.max(1, Math.ceil(total/pp));
    if(!window._oltGsPag || window._oltGsPag>totalPag) window._oltGsPag=Math.min(window._oltGsPag||1, totalPag);
    if(window._oltGsPag<1) window._oltGsPag=1;
    var ini=(window._oltGsPag-1)*pp, page=filtrados.slice(ini, ini+pp);
    var _lastSl=null;
    var cards=page.map(function(it){ var k=it.k, o=it.o, nome=it.nome;
        var fsp=(k.split('|')[0]||''); var sl=(fsp.split('/')[1]||'?'); var sep='';
        if(sl!==_lastSl){ _lastSl=sl; sep='<div style="grid-column:1/-1; margin:'+(_lastSl===null?'0':'6px')+' 0 2px; padding:7px 12px; background:'+OLTC.acc+'14; border-left:4px solid '+OLTC.acc+'; border-radius:8px; font-weight:800; color:'+OLTC.acc+'; font-size:13px; letter-spacing:.5px;"><i class="fa-solid fa-server"></i> PLACA '+sl+'</div>'; }
        var pnome=(typeof _oltPortaNome==='function'?(_oltPortaNome(fsp)||''):'');
        return sep+'<div style="background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:10px; padding:8px 10px;"><div style="font-size:11.5px; font-weight:800; color:'+OLTC.acc+'; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="'+_oltEsc(nome)+'">'+_oltEsc(nome)+'</div><div style="font-size:8px; color:'+OLTC.mut+'; margin-bottom:4px;">'+_oltEsc(k)+(pnome?(' · <b style="color:'+OLTC.txt+';">'+_oltEsc(pnome)+'</b>'):'')+(o.zona?(' · '+_oltEsc(o.zona)):'')+'</div>'+_oltGrafSinalSVG(hist[k])+'</div>';
    });
    b.style.textAlign='left'; b.style.padding='0';
    b.innerHTML='<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-bottom:8px;">'+total+' ONU(s) · ordenadas por Rx (pior primeiro)</div>'+
        '<div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:10px;">'+cards.join('')+'</div>'+
        (total>pp ? '<div style="margin-top:14px; padding-top:12px; border-top:1px solid '+OLTC.line+';">'+_oltGsPaginacao(total, totalPag)+'</div>' : '');
}
// Pager MODERNO do rodapé dos Gráficos de Sinal (mesmo visual do da lista principal).
function _oltGsPaginacao(total, totalPag){
    var p=window._oltGsPag||1;
    function b(lbl,pg,dis,ativo){ return '<button '+(dis?'disabled':'onclick="oltGsIrPag('+pg+')"')+' style="cursor:'+(dis?'default':'pointer')+'; min-width:32px; height:30px; border-radius:7px; border:1px solid '+OLTC.line+'; background:'+(ativo?OLTC.acc:'transparent')+'; color:'+(ativo?'#ffffff':(dis?OLTC.line:OLTC.txt))+'; font-size:12px; font-weight:700; margin:0 2px;">'+lbl+'</button>'; }
    var nav=b('<i class="fa-solid fa-angle-left"></i>', p-1, p<=1, false);
    var ini=Math.max(1,p-2), fim=Math.min(totalPag,ini+4); ini=Math.max(1,fim-4);
    for(var i=ini;i<=fim;i++){ nav+=b(i,i,false,i===p); }
    nav+=b('<i class="fa-solid fa-angle-right"></i>', p+1, p>=totalPag, false);
    return '<div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; font-size:12px; color:'+OLTC.mut+';">'+
        '<div style="display:flex; align-items:center;">'+nav+'</div>'+
        '<div>'+total+' ONU(s) · pág. '+p+'/'+totalPag+'</div></div>';
}
function oltGsIrPag(p){ window._oltGsPag=p; oltGsRender(); }
// ===== CONSUMO DE BANDA (ONUs) — lista TODAS as ONUs; clicar abre a banda AO VIVO daquela ONU (Telnet). =====
// Não dá pra mostrar as ~695 ONUs com banda ao mesmo tempo (banda por ONU é Telnet, 1 de cada vez, senão
// trava a OLT). Então lista todas (busca+paginação, igual à de sinal) e a banda ao vivo abre por clique.
function oltGraficosBanda(){
    window._oltGbPag=1; window._oltGbQ=null;
    _oltModalSimples('fa-gauge-high','Consumo de Banda — por ONU (clique p/ ver ao vivo)',
      '<div style="margin-bottom:10px; position:relative; max-width:340px;"><i class="fa-solid fa-magnifying-glass" style="position:absolute; left:11px; top:50%; transform:translateY(-50%); color:'+OLTC.mut+'; font-size:12px; pointer-events:none;"></i><input id="oltGbFiltro" oninput="oltGbRender()" placeholder="filtrar por nome, F/S/P ou zona..." style="'+_oltInSt()+' width:100%; box-sizing:border-box; padding-left:32px;"></div>'+
      '<div id="oltGbBody" style="text-align:left;"></div>', false);
    oltGbRender();
}
function oltGbRender(){
    var b=document.getElementById('oltGbBody'); if(!b) return;
    var lista=window._oltLista||[];
    var q=((document.getElementById('oltGbFiltro')||{}).value||'').toLowerCase().trim();
    if(window._oltGbQ!==q){ window._oltGbQ=q; window._oltGbPag=1; }
    var arr=lista.filter(function(o){ var nome=(typeof _oltNomeDe==='function'?_oltNomeDe(o):'')||o.serial||''; var hay=_oltNorm(nome+' '+(o.nome||'')+' '+(o.fsp||'')+'|'+(o.id||'')+' '+(o.zona||'')); return !q || _oltPalavras(hay,q); })
        .sort(function(a,b){ var pa=(a.fsp||'').split('/'),pb=(b.fsp||'').split('/'); return ((+pa[1]||0)-(+pb[1]||0))||((+pa[2]||0)-(+pb[2]||0))||((+a.id||0)-(+b.id||0)); });   // por PLACA/porta/id
    if(!lista.length){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px;">Lista de ONUs ainda não carregou. Abra o gerenciador e aguarde a varredura.</div>'; return; }
    var total=arr.length, pp=60, totalPag=Math.max(1,Math.ceil(total/pp));
    if(window._oltGbPag>totalPag) window._oltGbPag=totalPag; if(window._oltGbPag<1) window._oltGbPag=1;
    var ini=(window._oltGbPag-1)*pp, page=arr.slice(ini,ini+pp);
    // GRADE de cards. Cabeçalho PLACA X (linha inteira) sempre que a placa muda — cada página já começa
    // mostrando a placa. Cada card = uma ONU; clicar abre a banda AO VIVO dela.
    var _lastSl=null;
    var cards=page.map(function(o){ var nome=(typeof _oltNomeDe==='function'?_oltNomeDe(o):'')||o.serial||(o.fsp+'|'+o.id); var on=((o.status||'').toLowerCase().indexOf('online')>-1);
        var sl=((o.fsp||'').split('/')[1]||'?'); var sep='';
        if(sl!==_lastSl){ _lastSl=sl; sep='<div style="grid-column:1/-1; margin:'+(_lastSl===null?'0':'6px')+' 0 2px; padding:7px 12px; background:'+OLTC.acc+'14; border-left:4px solid '+OLTC.acc+'; border-radius:8px; font-weight:800; color:'+OLTC.acc+'; font-size:13px; letter-spacing:.5px;"><i class="fa-solid fa-server"></i> PLACA '+sl+'</div>'; }
        var pnome=(typeof _oltPortaNome==='function'?(_oltPortaNome(o.fsp||'')||''):'');
        return sep+'<div onclick="oltGrafCliente(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\',\''+encodeURIComponent(nome)+'\')" title="Ver a banda AO VIVO desta ONU" style="cursor:pointer; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:11px; padding:12px 14px;" onmouseover="this.style.borderColor=\''+OLTC.acc+'\'" onmouseout="this.style.borderColor=\''+OLTC.line+'\'">'+
            '<div style="font-size:13px; font-weight:800; color:'+OLTC.acc+'; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="'+_oltEsc(nome)+'"><i class="fa-solid fa-circle" style="font-size:8px; color:'+(on?OLTC.grn:OLTC.red)+';"></i> '+_oltEsc(nome)+'</div>'+
            '<div style="font-size:11px; color:'+OLTC.mut+'; margin:3px 0 10px;">'+_oltEsc(o.fsp||'')+' · ID '+_oltEsc(o.id||'')+(pnome?(' · <b style="color:'+OLTC.txt+';">'+_oltEsc(pnome)+'</b>'):'')+(o.zona?(' · '+_oltEsc(o.zona)):'')+'</div>'+
            '<div style="text-align:center; font-size:12px; font-weight:800; color:#d32f2f; background:#fff; border:1.5px solid #e64d4d; border-radius:8px; padding:10px 8px;"><i class="fa-solid fa-gauge-high"></i> ver banda ao vivo</div>'+
        '</div>'; }).join('');
    b.innerHTML='<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:10px;">'+total+' ONU(s) · clique numa para ver o <b>consumo ao vivo</b> (Upload/Download em tempo real).</div>'+
        '<div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(290px,1fr)); gap:12px;">'+cards+'</div>'+
        (total>pp ? '<div style="margin-top:12px; padding-top:10px; border-top:1px solid '+OLTC.line+';">'+_oltGbPaginacao(total,totalPag)+'</div>' : '');
}
function _oltGbPaginacao(total, totalPag){
    var p=window._oltGbPag||1;
    function bt(lbl,pg,dis,ativo){ return '<button '+(dis?'disabled':'onclick="oltGbIrPag('+pg+')"')+' style="cursor:'+(dis?'default':'pointer')+'; min-width:32px; height:30px; border-radius:7px; border:1px solid '+OLTC.line+'; background:'+(ativo?OLTC.acc:'transparent')+'; color:'+(ativo?'#fff':(dis?OLTC.line:OLTC.txt))+'; font-size:12px; font-weight:700; margin:0 2px;">'+lbl+'</button>'; }
    var nav=bt('<i class="fa-solid fa-angle-left"></i>',p-1,p<=1,false); var i0=Math.max(1,p-2),f0=Math.min(totalPag,i0+4); i0=Math.max(1,f0-4);
    for(var i=i0;i<=f0;i++){ nav+=bt(i,i,false,i===p); } nav+=bt('<i class="fa-solid fa-angle-right"></i>',p+1,p>=totalPag,false);
    return '<div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; font-size:12px; color:'+OLTC.mut+';"><div>'+nav+'</div><div>'+total+' ONU(s) · pág. '+p+'/'+totalPag+'</div></div>';
}
function oltGbIrPag(p){ window._oltGbPag=p; oltGbRender(); }
// ===== Gráfico de TEMPERATURA da OLT no tempo =====
function oltGraficoTemp(){
    _oltModalSimples('fa-temperature-half','Temperatura da OLT (no tempo)', '<div id="oltGtBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Carregando temperatura...')+'</div>', false);
    _oltFetchDireto('olt_huawei.php?acao=olt_temp_hist', 15000).then(function(r){return r.json();}).then(function(d){ var b=document.getElementById('oltGtBody'); if(!b) return;
        var t=(d&&d.temp)||[]; if(t.length<2){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px; line-height:1.7;">Ainda sem histórico suficiente. A temperatura é amostrada enquanto o sistema está aberto (topo/Resumo). Deixe aberto uns minutos e volte.</div>'; return; }
        b.style.textAlign='left'; b.innerHTML='<div style="background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:10px; padding:12px;">'+_oltGrafTempSVG(t)+'</div>';
    }).catch(function(){ var b=document.getElementById('oltGtBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha.</div>'; });
}
// ===== #7 Autorizações por dia (barras) =====
function oltGraficoAuth(){
    _oltModalSimples('fa-calendar-check','Autorizações de ONU por dia', '<div id="oltGaBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Carregando...')+'</div>', false);
    _oltFetchDireto('olt_huawei.php?acao=auth_dia', 15000).then(function(r){return r.json();}).then(function(d){ var b=document.getElementById('oltGaBody'); if(!b) return;
        var dias=(d&&d.dias)||{}; var ks=Object.keys(dias); if(!ks.length){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px;">Ainda sem autorizações registradas no relatório.</div>'; return; }
        var max=1; ks.forEach(function(k){ max=Math.max(max,dias[k]); });
        var W=Math.max(360, ks.length*46), H=200, pad=26, bw=Math.min(34,(W-2*pad)/ks.length-6);
        var bars=ks.map(function(k,i){ var v=dias[k]; var x=pad+i*((W-2*pad)/ks.length); var h=(H-2*pad)*(v/max); var y=(H-pad)-h;
            return '<rect x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="3" fill="'+OLTC.acc+'"></rect>'+
                '<text x="'+(x+bw/2).toFixed(1)+'" y="'+(y-3).toFixed(1)+'" text-anchor="middle" font-size="10" font-weight="800" fill="'+OLTC.ink+'">'+v+'</text>'+
                '<text x="'+(x+bw/2).toFixed(1)+'" y="'+(H-pad+12).toFixed(1)+'" text-anchor="middle" font-size="8" fill="'+OLTC.mut+'">'+_oltEsc(k.slice(5))+'</text>'; }).join('');
        b.style.textAlign='left'; b.innerHTML='<div style="overflow-x:auto;"><svg viewBox="0 0 '+W+' '+H+'" style="width:100%; min-width:'+W+'px; height:'+H+'px; display:block;"><line x1="'+pad+'" y1="'+(H-pad)+'" x2="'+(W-4)+'" y2="'+(H-pad)+'" stroke="'+OLTC.line+'"/>'+bars+'</svg></div><div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:6px;">ONUs liberadas por dia (últimos '+ks.length+' dias com registro).</div>';
    }).catch(function(){ var b=document.getElementById('oltGaBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha ao carregar.</div>'; });
}
function _oltGrafTempSVG(serie){
    var W=520,H=140,pad=10;
    var min=Math.min.apply(null,serie), max=Math.max.apply(null,serie); if(min===max){min-=1;max+=1;} else {var m=(max-min)*0.2; min-=m; max+=m;}
    var n=serie.length, x=function(i){return pad+(W-2*pad)*(n<2?0:i/(n-1));}, y=function(v){return (H-pad)-(H-2*pad)*((v-min)/(max-min));};
    var d=''; serie.forEach(function(v,i){ d+=(i?'L':'M')+x(i).toFixed(1)+' '+y(v).toFixed(1)+' '; });
    var cur=serie[n-1], mx=Math.max.apply(null,serie); var cor=(mx>=39?OLTC.redf:OLTC.acc);
    return '<div style="font-size:12.5px; font-weight:800; color:'+cor+'; margin-bottom:6px;">Temperatura — atual '+cur+'°C · pico '+mx+'°C · '+n+' amostras</div><svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%; height:120px; display:block; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:6px;"><path d="'+d+'" fill="none" stroke="'+cor+'" stroke-width="2"/></svg>';
}
// Perfis de VELOCIDADE (traffic-table da OLT) — tabela estilo SmartOLT.
// Alarmes REAIS da OLT (a própria OLT detecta): PON caída (LOS ou energia em massa), placa caída, LOS de
// ONU. Cache-primeiro (abre na hora, leitura direta). QUEM ALERTA é o cron (WhatsApp/Telegram) — aqui é só a visão.
function oltAlarmes(forcar){
    var jaAberto=document.getElementById('oltAlBody');
    if(!jaAberto) _oltModalSimples('fa-tower-broadcast','Alarmes da OLT — PON / Placa (tempo real)','<div id="oltAlBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner(forcar?'Lendo os alarmes direto da OLT...':'Carregando alarmes...')+'</div>', false);
    else jaAberto.innerHTML='<div style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner(forcar?'Lendo os alarmes direto da OLT...':'Carregando alarmes...')+'</div>';
    var url='olt_huawei.php?acao=alarmes'+(forcar?'&force=1':'');
    // cache = leitura direta/rápida; force = lê da OLT por Telnet (vai pela fila, pode levar alguns segundos).
    var f=forcar?oltFetch(url,null,false):((typeof _oltFetchDireto==='function')?_oltFetchDireto(url,20000):oltFetch(url,null,false));
    f.then(function(r){return r.json();}).then(function(d){
        var al=(d&&d.al)||[];
        if(!al.length && !forcar){ return oltAlarmes(true); }   // cache vazio -> lê da OLT AGORA (1x)
        _oltAlRender(al, !!forcar);
    }).catch(function(){ var b=document.getElementById('oltAlBody'); if(b) b.innerHTML='<div style="padding:10px;"><div style="color:'+OLTC.amb+';"><i class="fa-solid fa-hourglass-half"></i> OLT ocupada — não deu pra ler agora.</div><button onclick="oltAlarmes(true)" style="margin-top:10px; cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:12px;"><i class="fa-solid fa-arrows-rotate"></i> Ler da OLT agora</button></div>'; });
}
function _oltAlRender(al, live){
    var b=document.getElementById('oltAlBody'); if(!b) return; b.style.textAlign='left';
    var botao='<button onclick="oltAlarmes(true)" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-arrows-rotate"></i> Ler da OLT agora</button>';
    var topo='<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:10px;"><span style="font-size:11px; color:'+OLTC.mut+';">'+(live?'<i class="fa-solid fa-bolt" style="color:'+OLTC.grn+';"></i> lido da OLT agora':'do cache (o cron atualiza sozinho)')+'</span>'+botao+'</div>';
    if(!al.length){ b.innerHTML=topo+'<div style="color:'+OLTC.grn+'; padding:10px; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Nenhum alarme ativo na OLT.</div>'; return; }
    // roster: nº de ONUs por PON (da lista). Porta VAZIA (0 ONU) não conta como "PON caiu" — o feeder LOS
    // dela é só "sem ONT conectada" (era o falso 0/1/9). Sem lista carregada, não filtra (mostra tudo).
    var rost={}; (window._oltLista||[]).forEach(function(o){ var f=o.fsp||''; if(f) rost[f]=(rost[f]||0)+1; });
    var temRost=Object.keys(rost).length>0;
    var pon={}, placa=[], losonu=[], ener={}, ruido=0;
    al.forEach(function(a){
        if(a.tipo==='los_pon' && a.fsp && (!temRost || (rost[a.fsp]||0)>0)){ pon[a.fsp]=pon[a.fsp]||{fsp:a.fsp,los:false,ener:0,afet:0}; pon[a.fsp].los=true; pon[a.fsp].afet=a.afet||0; }
        else if(a.tipo==='energia'){ if(a.fsp) ener[a.fsp]=(ener[a.fsp]||0)+1; }
        else if(a.tipo==='placa'){ placa.push(a); }
        else if(a.tipo==='los_onu'){ losonu.push(a); }
        else ruido++;
    });
    Object.keys(ener).forEach(function(f){ if(ener[f]>=4){ pon[f]=pon[f]||{fsp:f,los:false,ener:0,afet:0}; pon[f].ener=ener[f]; } });
    var esc=_oltEsc, html=topo;
    html+='<div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px;">'+
        _oltAlChip((Object.keys(pon).length+placa.length)>0?OLTC.red:OLTC.grn, (Object.keys(pon).length+placa.length), 'PON/Placa caídas')+
        _oltAlChip(OLTC.amb, losonu.length, 'LOS de ONU')+
        _oltAlChip(OLTC.mut, ruido, 'Ruído (LCDGi/config)')+'</div>';
    placa.forEach(function(a){ html+=_oltAlCard(OLTC.red,'fa-server','PLACA CAIU — slot '+esc(''+a.slot)+(a.board?(' ('+esc(a.board)+')'):''),'Comunicação da placa com a controladora falhou.',a.hora); });
    Object.keys(pon).forEach(function(f){ var p=pon[f]; var mot=p.los?('LOS — sem sinal óptico'+(p.afet?(' · '+p.afet+' ONUs'):'')):''; if(p.ener) mot+=(mot?' + ':'')+('ENERGIA — '+p.ener+' ONUs sem luz'); html+=_oltAlCard(OLTC.red,(p.los?'fa-bolt':'fa-plug-circle-xmark'),'PON CAIU — '+esc(f),mot,''); });
    if(losonu.length){ html+='<div style="font-size:11px; font-weight:800; color:'+OLTC.amb+'; margin:12px 0 6px; text-transform:uppercase;">LOS de ONU (individual)</div>'; losonu.forEach(function(a){ html+=_oltAlLinha(OLTC.amb, esc(a.fsp)+' · ONT '+esc(''+a.ont), a.hora); }); }
    html+='<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:14px; line-height:1.5;">São os <b>alarmes reais da OLT</b>. O <b>alerta no WhatsApp/Telegram</b> quem dispara é o servidor (cron), na hora, mesmo com o app fechado. O liga/desliga individual de ONU fica nos <b>cards do topo</b>.</div>';
    b.innerHTML=html;
}
function _oltAlChip(cor,n,txt){ return '<span style="display:inline-flex; align-items:center; gap:6px; background:'+cor+'1f; color:'+cor+'; border-radius:20px; padding:4px 11px; font-size:12px; font-weight:800;">'+n+' <span style="font-weight:600; font-size:11px;">'+txt+'</span></span>'; }
function _oltAlCard(cor,ico,tit,sub,hora){ return '<div style="border:1px solid '+cor+'55; background:'+cor+'12; border-radius:10px; padding:9px 12px; margin-bottom:8px;"><div style="font-weight:800; color:'+cor+'; font-size:13px;"><i class="fa-solid '+ico+'"></i> '+tit+'</div>'+(sub?'<div style="font-size:11.5px; color:'+OLTC.txt+'; margin-top:2px;">'+sub+'</div>':'')+(hora?'<div style="font-size:10px; color:'+OLTC.mut+'; margin-top:2px;"><i class="fa-regular fa-clock"></i> '+_oltEsc(hora)+'</div>':'')+'</div>'; }
function _oltAlLinha(cor,txt,hora){ return '<div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px solid '+OLTC.line+'33; font-size:12px;"><span style="font-family:monospace; color:'+cor+'; font-weight:700;">'+txt+'</span><span style="color:'+OLTC.mut+'; font-size:10.5px;">'+_oltEsc(hora||'')+'</span></div>'; }
function oltPerfisVelocidade(){
    _oltModalSimples('fa-gauge-high','Perfis de velocidade (traffic-table da OLT)', '<div id="oltPvBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Carregando perfis...')+'</div>', false);
    // CACHE-PRIMEIRO (abre na hora, leitura direta/rápida do cache) e ATUALIZA da OLT em 2º plano (Telnet,
    // via fila). Dado sempre REAL — só a ordem muda: mostra o cache agora, refina quando a leitura nova chega.
    var _dir=(typeof _oltFetchDireto==='function')?_oltFetchDireto('olt_huawei.php?acao=perfis_veloc',15000):oltFetch('olt_huawei.php?acao=perfis_veloc',null,false);
    _dir.then(function(r){return r.json();}).then(function(d){ _oltPvRender((d&&d.perfis)||[], (d&&d.raw)||'', true); })
        .catch(function(){ _oltPvRender([], '', true); })
        .then(function(){   // ATUALIZA da OLT (força Telnet) em 2º plano -> refina com o dado fresco, real
            oltFetch('olt_huawei.php?acao=perfis_veloc&force=1', null, false).then(function(r){return r.json();}).then(function(d2){ if(d2&&d2.perfis&&d2.perfis.length) _oltPvRender(d2.perfis, d2.raw||'', false); }).catch(function(){});
        });
}
function _oltPvRender(ps, raw, aindaAtualizando){
    var b=document.getElementById('oltPvBody'); if(!b) return;
    if(!ps.length){ b.innerHTML = aindaAtualizando ? ('<div style="text-align:center; color:'+OLTC.mut+'; padding:14px;">'+_oltSpinner('Lendo perfis da OLT...')+'</div>') : ('<div style="color:'+OLTC.amb+'; padding:8px 0;">Nenhum perfil interpretado. Saída bruta da OLT:</div>'+_oltPre(raw||'')); return; }
    var kb=function(v){ v=(''+v).toLowerCase().trim(); if(v==='off'||v===''||v==='-') return '<span style="color:'+OLTC.mut+';">ilimitado</span>'; var n=parseInt(v,10); if(isNaN(n)) return _oltEsc(v); return (n>=1000?((Math.round(n/100)/10)+' Mbps'):(n+' kbps')); };
    var thb=function(al){ return 'padding:9px 11px; text-align:'+al+'; font-size:10px; text-transform:uppercase; letter-spacing:.4px; color:'+OLTC.mut+'; background:'+OLTC.panel+'; border-bottom:2px solid '+OLTC.line+'; position:sticky; top:0; white-space:nowrap;'; };
    var tdb=function(al){ return 'padding:9px 11px; font-size:12px; color:'+OLTC.ink+'; border-bottom:1px solid '+OLTC.line+'; text-align:'+al+'; vertical-align:middle;'; };
    var rows=ps.map(function(p){ return '<tr><td style="'+tdb('left')+' font-family:monospace; color:'+OLTC.mut+';">'+_oltEsc(p.tid)+'</td><td style="'+tdb('left')+' font-weight:800;"><i class="fa-solid fa-gauge-high" style="color:'+OLTC.acc+'; margin-right:6px;"></i>'+_oltEsc(p.name)+'</td><td style="'+tdb('right')+' font-weight:700; color:'+OLTC.grn+';">'+kb(p.cir)+'</td><td style="'+tdb('right')+' font-weight:700; color:'+OLTC.vio+';">'+kb(p.pir)+'</td><td style="'+tdb('center')+' font-weight:700;">'+_oltEsc(p.ref||'-')+'</td></tr>'; }).join('');
    b.innerHTML='<div style="overflow:auto; border:1px solid '+OLTC.line+'; border-radius:10px;"><table style="width:100%; border-collapse:collapse; background:'+OLTC.bg+';"><thead><tr><th style="'+thb('left')+'">ID</th><th style="'+thb('left')+'">Nome do perfil</th><th style="'+thb('right')+'">Garantido (CIR)</th><th style="'+thb('right')+'">Máximo (PIR)</th><th style="'+thb('center')+'">Refs</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
        '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-top:9px; line-height:1.5;"><b>CIR</b> = banda garantida · <b>PIR</b> = banda máxima · <b>Refs</b> = quantos service-ports usam o perfil (proxy do nº de ONUs, sem varredura pesada).</div>';
}
// Gerenciador de Perfil ONT/ONU (item 9): lista os perfis usados na autorização; recarrega da OLT.
function oltGerenciarPerfis(){
    var corpo=
        '<div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">'+
          '<span style="flex:1 1 auto; font-size:11px; color:'+OLTC.mut+';">São os perfis usados na autorização (Bridge = ONU · Router = ONT).</span>'+
          '<button onclick="oltGerenciarPerfisReload(this)" title="Recarregar da OLT" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-arrows-rotate"></i> Recarregar</button>'+
        '</div>'+
        '<div id="oltPerfBody">'+_oltPerfListaHtml()+'</div>'+
        // ---- MIGRAÇÃO EM LOTE: R1/R2 (Intelbras/outras) -> Generic_1 ----
        '<div style="margin-top:16px; padding-top:12px; border-top:1px solid '+OLTC.line+';">'+
          '<div style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.acc+'; margin-bottom:4px;"><i class="fa-solid fa-right-left"></i> Migrar perfil em lote</div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-bottom:8px; line-height:1.5;">Em <b>Origem</b>, escolha o <b>modelo</b> da ONU/ONT (121AC, 310M…). Em <b>Destino</b>, o <b>genérico</b>. O <b>Migrar agora</b> aplica o genérico em <b>todas as ONUs daquele modelo</b>, uma a uma.</div>'+
          '<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:8px;">'+
            '<label style="font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700;">Modelo</label>'+
            '<select id="oltMigOrigem" title="Modelo da ONU/ONT (lido da OLT)" style="'+_oltInSt()+' min-width:170px;"></select>'+
            '<label style="font-size:10px; color:'+OLTC.mut+'; text-transform:uppercase; font-weight:700;">Destino</label>'+
            '<select id="oltMigDestino" style="'+_oltInSt()+' min-width:150px;"></select>'+
            '<button onclick="oltMigrarGenerico(this)" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:11.5px;"><i class="fa-solid fa-right-left"></i> Migrar agora</button>'+
          '</div>'+
          '<div id="oltMigRes" style="font-size:11px; color:'+OLTC.mut+';"></div>'+
        '</div>'+
        '<div style="margin-top:16px; padding-top:12px; border-top:1px solid '+OLTC.line+';">'+
          '<div style="font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; color:'+OLTC.acc+'; margin-bottom:4px;"><i class="fa-solid fa-microchip"></i> Modelos capturados da OLT</div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin-bottom:8px; line-height:1.5;">O modelo à esquerda é o que a <b>OLT reporta</b>. Defina um <b>nome de exibição</b> e, se quiser, force o <b>tipo</b> (quando o service-profile da OLT informa errado). Deixe "automático" para usar a detecção padrão.</div>'+
          '<div id="oltMdBody">'+_oltModelosListaHtml()+'</div>'+
        '</div>';
    _oltModalSimples('fa-microchip', 'Perfis ONT / ONU (cadastrados na OLT)', corpo);
    if(!(window._oltPerfisOlt&&window._oltPerfisOlt.srv&&window._oltPerfisOlt.srv.length)) oltGerenciarPerfisReload();
    _oltMigDestinoFill();
    _oltPerfisOltRefrescar(true);   // relê a OLT em 2º plano: perfil/modelo novo aparece sozinho
    _oltModelosCarregar(function(){ var b=document.getElementById('oltMdBody'); if(b) b.innerHTML=_oltModelosListaHtml(); });
}
// Preenche o dropdown "Destino" da migração com os genéricos REAIS da OLT (line+srv
// pareados). Pré-seleciona o Generic_1 se existir.
function _oltMigDestinoFill(){
    var sel=document.getElementById('oltMigDestino');
    if(sel){
        sel.innerHTML=_oltPerfilOpts();
        // pré-seleciona Generic_1 (ou o 1º genérico com lp+sp válidos)
        var alvo='';
        for(var k=0;k<sel.options.length;k++){ var o=sel.options[k]; if(!o.value) continue;
            if(o.getAttribute('data-lp') && o.getAttribute('data-sp')){ if(alvo==='') alvo=o.value; if(/gener\w*[_\s]*0*1\b/i.test(o.value)){ alvo=o.value; break; } } }
        if(alvo) sel.value=alvo;
    }
    // Origem = lista de TODOS os perfis reais da OLT (line+srv), pra escolher de qual migrar.
    var so=document.getElementById('oltMigOrigem');
    if(so){ var v=so.value; so.innerHTML=_oltMigOrigemOpts(); if(v) so.value=v; }
}
// AUTO-REFRESH dos perfis/modelos da OLT: relê perfis_olt e REPOVOA todos os selects que
// usam a lista (aprovisionamento, migração origem+destino, picker da ficha, lista de perfis).
// Assim, todo perfil/modelo novo aparece AUTOMATICAMENTE nesses locais, sem clicar em ↻.
function _oltPerfisAplicarUI(){
    if(typeof _oltPreencherSrvAp==='function') _oltPreencherSrvAp();       // combos do aprovisionamento (srv + genérico)
    if(typeof _oltMigDestinoFill==='function') _oltMigDestinoFill();        // migração: Origem (ONUs) + Destino (genéricos)
    var pb=document.getElementById('oltPerfBody'); if(pb&&typeof _oltPerfListaHtml==='function') pb.innerHTML=_oltPerfListaHtml();
    var pg=document.getElementById('oltPgSel'); if(pg&&typeof _oltPerfilOpts==='function'){ var v=pg.value; pg.innerHTML=_oltPerfilOpts(); if(v) pg.value=v; }
}
// force=true relê AO VIVO da OLT (throttle de 25s p/ não martelar o Telnet). Sem force usa o
// cache rápido do backend. Sempre repovoa a UI quando volta.
function _oltPerfisOltRefrescar(force, cb){
    if(force){ var ag=Date.now(); if(window._oltPerfisLastForce && (ag-window._oltPerfisLastForce)<25000) force=false; else window._oltPerfisLastForce=ag; }
    oltFetch('olt_huawei.php?acao=perfis_olt'+(force?'&force=1':''), null, false).then(function(r){return r.json();}).then(function(d){
        if(d&&d.srv&&d.srv.length){ window._oltPerfisOlt={line:d.line||[],srv:d.srv}; _oltPerfisAplicarUI(); }
        if(cb) cb();
    }).catch(function(){ if(cb) cb(); });
}
// Opções de ORIGEM: união dos nomes de line+srv-profile da OLT (R1, R2, Generic_x…),
// mais o atalho "R1/R2 (padrão)" e "Todas".
function _oltMigOrigemOpts(){
    // Lista TODAS as ONUs/ONTs do sistema, em ordem alfabética, pra escolher qual receberá
    // o genérico. Valor = "fsp|id". No topo, opções em lote por perfil (R1/R2 e Todas).
    // MODELOS distintos das ONUs/ONTs (o que a OLT reporta: 121AC, 310M…), com a contagem.
    var mods={}; (window._oltLista||[]).forEach(function(o){ var m=(o&&o.modelo)?String(o.modelo).trim():''; if(m && m!=='-') mods[m]=(mods[m]||0)+1; });
    var arr=Object.keys(mods).sort(function(a,b){ return String(a).localeCompare(String(b),'pt',{sensitivity:'base',numeric:true}); });
    var opts=arr.map(function(m){ return '<option value="modelo:'+_oltEsc(m)+'">'+_oltEsc(m)+' ('+mods[m]+' ONU'+(mods[m]>1?'s':'')+')</option>'; }).join('');
    return '<option value="" disabled selected>— escolha o modelo —</option>'+opts;
}
// MIGRAÇÃO EM LOTE R1/R2 -> genérico: percorre a lista de ONUs (window._oltLista) e
// chama generico_migrar UMA A UMA (serial, com progresso). O backend lê o perfil real
// de cada ONU e só migra as que casam com a "Origem" — as outras são puladas.
function oltMigrarGenerico(btn){
    // ⛔ DESATIVADO por segurança: trocar o perfil de ONUs já ativas DERRUBA o serviço (service-port
    // órfão) — só volta com resync no SmartOLT. Aplique o genérico apenas no APROVISIONAMENTO.
    alert('⛔ Migração de perfil DESATIVADA por segurança.\n\nTrocar o perfil (line/srv) de uma ONU que já está funcionando REESCREVE os GEM/T-CONT e derruba o tráfego (o service-port fica órfão) — foi o que quebrou as ONUs.\n\nO perfil genérico deve ser aplicado SÓ no APROVISIONAMENTO da ONU. Para as já ativas, exclua a ONU e autorize novamente com o novo perfil.');
    return;
    var sel=document.getElementById('oltMigDestino'); var res=document.getElementById('oltMigRes');
    var opt=(sel&&sel.selectedOptions&&sel.selectedOptions[0])?sel.selectedOptions[0]:null;
    var lp=opt?opt.getAttribute('data-lp'):''; var sp=opt?opt.getAttribute('data-sp'):'';
    var origem=(document.getElementById('oltMigOrigem')||{}).value||'';
    if(!lp||!sp){ if(res) res.innerHTML='<span style="color:'+OLTC.red+';">Escolha um destino genérico válido (com line+srv). Recarregue os perfis da OLT se a lista estiver vazia.</span>'; return; }
    if(!origem){ if(res) res.innerHTML='<span style="color:'+OLTC.amb+';">Escolha na Origem a ONU/ONT (ou "Todas R1/R2") que vai receber o genérico.</span>'; return; }
    var lista, alvoTxt;
    if(origem.indexOf('modelo:')===0){   // TODAS as ONUs de um MODELO
        var mod=origem.slice(7);
        lista=(window._oltLista||[]).filter(function(o){ return String(o.modelo||'').trim()===mod && o.fsp && (o.id!==undefined&&o.id!==''); });
        alvoTxt='modelo "'+mod+'"'; origem='.*'; // aplica direto (por modelo, sem filtrar por perfil atual)
    } else {                              // LOTE por perfil (R1|R2 ou .*) — compat
        lista=(window._oltLista||[]).filter(function(o){ return o&&o.fsp&&(o.id!==undefined&&o.id!==''); });
        alvoTxt='perfil "'+origem+'"';
    }
    if(!lista.length){ if(res) res.innerHTML='<span style="color:'+OLTC.amb+';">Nenhuma ONU desse modelo na lista. Abra a lista de ONUs primeiro.</span>'; return; }
    if(!confirm('Aplicar o genérico "'+sel.value+'" em '+lista.length+' ONU'+(lista.length>1?'s':'')+' do '+alvoTxt+' (uma a uma)?')) return;
    if(btn){ btn.disabled=true; btn.style.opacity='.6'; }
    var i=0, mig=0, pul=0, err=0, det=[], tent=0;
    function paint(extra){ if(!res) return; res.innerHTML='<div style="margin-bottom:4px;">Verificando '+(i)+'/'+lista.length+' · <b style="color:'+OLTC.grn+';">'+mig+' migradas</b> · '+pul+' ignoradas · <span style="color:'+OLTC.red+';">'+err+' erro</span></div>'+(extra||'')+'<div style="max-height:140px; overflow:auto; font-size:10.5px; line-height:1.5;">'+det.slice(-40).join('')+'</div>'; }
    function proximo(){ i++; tent=0; setTimeout(passo, 300); }   // respiro de 300ms entre ONUs (deixa a VTY liberar)
    function passo(){
        if(i>=lista.length){ if(btn){ btn.disabled=false; btn.style.opacity='1'; }
            paint('<div style="margin:6px 0; color:'+OLTC.grn+'; font-weight:800;">Concluído. '+mig+' migrada(s).</div>');
            if(mig>0 && typeof oltVarrerSlots==='function'){ setTimeout(function(){ try{ oltVarrerSlots(0); }catch(e){} },600); }
            return; }
        var o=lista[i]; var nm=_oltNomeDe(o)||o.serial||(o.fsp+' id'+o.id);
        var body='acao=generico_migrar&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id)+'&lp='+encodeURIComponent(lp)+'&sp='+encodeURIComponent(sp)+'&origem='+encodeURIComponent(origem);
        fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body}).then(function(r){return r.json();}).then(function(d){
            if(d&&d.migrado){ mig++; det.push('<div style="color:'+OLTC.grn+';">✓ '+_oltEsc(nm)+' <span style="color:'+OLTC.mut+';">('+_oltEsc(o.fsp)+')</span></div>'); paint(); proximo(); }
            else if(d&&d.status==='ok'&&d.motivo==='nao_e_alvo'){ pul++; paint(); proximo(); }
            else {
                var msg=(d&&d.message)||'falha';
                if(/AUTH_RETRY|comunicar|prompt|VTY|timeout/i.test(msg) && tent<2){ tent++; paint('<div style="color:'+OLTC.amb+'; font-size:10px;">tentando de novo '+_oltEsc(nm)+' ('+tent+'/2)…</div>'); setTimeout(passo, 900); return; }
                err++; det.push('<div style="color:'+OLTC.red+';">✗ '+_oltEsc(nm)+' — '+_oltEsc(msg)+'</div>'); paint(); proximo();
            }
        }).catch(function(){
            if(tent<2){ tent++; setTimeout(passo, 900); return; }   // sem resposta -> retenta a MESMA ONU
            err++; det.push('<div style="color:'+OLTC.red+';">✗ '+_oltEsc(nm)+' — sem resposta</div>'); paint(); proximo();
        });
    }
    paint(); passo();
}
function oltGerenciarPerfisReload(btn){
    var ic=btn&&btn.querySelector('i'); if(ic) ic.classList.add('fa-spin');
    _oltFetchDireto('olt_huawei.php?acao=perfis_olt&force=1', 60000).then(function(r){return r.json();}).then(function(d){
        if(d&&d.srv&&d.srv.length){ window._oltPerfisOlt={line:d.line||[],srv:d.srv}; _oltPreencherSrvAp(); }
        var b=document.getElementById('oltPerfBody'); if(b) b.innerHTML=_oltPerfListaHtml();
        _oltMigDestinoFill();
    }).catch(function(){}).then(function(){ if(ic) ic.classList.remove('fa-spin'); });
}
// Modal simples reutilizável (cabeçalho azul + corpo rolável) p/ os gerenciadores.
// Janela flutuante reutilizável (Zona/Placa/Porta/VLAN etc.): agora com
// minimizar / maximizar, arraste (apenas quando NÃO maximizada) e traz-para-frente
// no clique. Cada abertura ganha um id próprio para várias poderem coexistir.
var _oltMS_seq=0;
function _oltModalSimples(ic,titulo,corpoHtml,hint){
    // ANTI-DUPLICATA: se a MESMA página já está aberta, NÃO abre outra — traz a existente pra frente,
    // restaura se estava minimizada, e ATUALIZA o conteúdo dela (clicar de novo = atualizar a mesma).
    // Busca por LOOP (querySelector com o título no seletor podia quebrar em títulos com "—","(",")").
    var _gk='oltGeo_'+titulo; var _ex=null;
    try{ var _all=document.querySelectorAll('.oltMSWin');
        for(var _i=0;_i<_all.length;_i++){ if(_all[_i].getAttribute('data-geokey')===_gk){ _ex=_all[_i]; break; } }
    }catch(e){ _ex=null; }
    if(_ex){
        window._oltTelaPend='';
        if(_ex.getAttribute('data-min')==='1'){ try{ _oltMSMin(_ex.id); }catch(e){} }   // restaura se minimizada
        _ex.style.zIndex=(window._oltMSZ=(window._oltMSZ||2147483000)+1);                 // traz pra frente
        var _b=_ex.querySelector('.oltMSBody');                                           // ATUALIZA o conteúdo
        if(_b){ _b.innerHTML=(hint===false?'':'<div style="padding:8px 16px 0; font-size:11px; color:'+OLTC.mut+';">Edite e saia do campo (Tab/clique) — salva em banco local e sincroniza a página.</div>')+'<div style="padding:'+(hint===false?'12px':'6px')+' 16px 16px;">'+corpoHtml+'</div>'; }
        return _ex.id;
    }
    var id='oltMS_'+(++_oltMS_seq);
    var _c='cursor:pointer; width:29px; height:27px; border-radius:6px; border:1px solid rgba(255,255,255,0.6); background:transparent; color:#fff; font-size:13px; display:inline-flex; align-items:center; justify-content:center;';
    var win=document.createElement('div'); win.id=id; win.className='oltMSWin';
    var _z=(window._oltMSZ=(window._oltMSZ||2147483000)+1);
    var _l=Math.max(8, Math.round(window.innerWidth/2-280));
    win.style.cssText='position:fixed; top:56px; left:'+_l+'px; width:min(96vw,560px); max-height:86vh; z-index:'+_z+'; display:flex; flex-direction:column; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; box-shadow:0 24px 70px rgba(0,0,0,0.55); resize:both; overflow:hidden; min-width:300px; min-height:180px;';
    win.setAttribute('data-geokey','oltGeo_'+titulo);   // OBS5: chave p/ gravar tamanho/posição
    window._oltTelaTit=window._oltTelaTit||{}; var _fnT=window._oltTelaPend||''; if(_fnT) window._oltTelaTit[titulo]=_fnT; else _fnT=window._oltTelaTit[titulo]||''; window._oltTelaPend='';
    win.setAttribute('data-fn',_fnT);   // F5: a tela aberta pelo menu é lembrada e reaberta (_oltTelasSalvar / _oltReabrirSeAberto)
    // traz para a FRENTE ao clicar em qualquer ponto da janela
    win.addEventListener('mousedown', function(){ win.style.zIndex=(window._oltMSZ=(window._oltMSZ||2147483000)+1); });
    win.innerHTML=
        '<div class="oltMSHead" style="flex:0 0 auto; padding:12px 14px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:9px; cursor:move;">'+
          '<button onclick="_oltMSVoltar(\''+id+'\')" title="Voltar (fecha e volta à tela anterior)" style="'+_c+' border-color:rgba(255,255,255,0.45);"><i class="fa-solid fa-arrow-left"></i></button>'+
          '<i class="fa-solid '+ic+'" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff; font-size:13.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+_oltEsc(titulo)+'</div>'+
          '<button onclick="_oltMSMin(\''+id+'\')" title="Minimizar" style="'+_c+'"><i class="fa-solid fa-minus"></i></button>'+
          '<button onclick="_oltMSMax(\''+id+'\')" title="Maximizar / Restaurar" style="'+_c+'"><i class="fa-solid fa-expand"></i></button>'+
          '<button onclick="var el=document.activeElement; if(el&&el.blur) el.blur(); setTimeout(function(){ var w=document.getElementById(\''+id+'\'); if(w) w.remove(); }, 150);" title="Salvar e Fechar" style="cursor:pointer; height:30px; padding:0 12px; border-radius:7px; border:1px solid rgba(255,255,255,0.4); background:#10b981; color:#fff; font-size:12px; font-weight:800; margin-left:4px;"><i class="fa-solid fa-floppy-disk" style="margin-right:5px;"></i> Salvar</button>'+'<button onclick="document.getElementById(\''+id+'\').remove()" title="Fechar sem salvar" style="'+_c+' background:rgba(0,0,0,0.28); margin-left:4px;"><i class="fa-solid fa-xmark"></i></button>'+
        '</div>'+
        '<div class="oltMSBody" style="flex:1 1 auto; overflow:auto;">'+
          (hint===false ? '' : '<div style="padding:8px 16px 0; font-size:11px; color:'+OLTC.mut+';">Edite e saia do campo (Tab/clique) — salva em banco local e sincroniza a página.</div>')+
          '<div style="padding:'+(hint===false?'12px':'6px')+' 16px 16px;">'+corpoHtml+'</div>'+
        '</div>';
    document.body.appendChild(win);
    // OBS5: restaura tamanho/posição da última vez — mas SÓ se for um tamanho razoável
    // (ignora geometrias minúsculas salvas por engano, que faziam a janela abrir reduzida).
    (function(){ var key=win.getAttribute('data-geokey');
        try{ var g=JSON.parse(localStorage.getItem(key)||'null');
            if(g && parseInt(g.w,10)>=400 && parseInt(g.h,10)>=280){
                win.style.width=g.w; win.style.height=g.h; win.style.left=g.l; win.style.top=g.t; win.style.margin='0'; win.style.maxHeight='none';
            }
        }catch(e){}
        var salvar=function(){ if(win.getAttribute('data-max')==='1'||win.getAttribute('data-min')==='1') return;
            if(win.offsetWidth<400 || win.offsetHeight<280) return;   // não grava tamanho pequeno
            try{ localStorage.setItem(key, JSON.stringify({w:win.offsetWidth+'px', h:win.offsetHeight+'px', l:win.style.left, t:win.style.top})); }catch(e){} };
        win.addEventListener('mouseup', function(){ setTimeout(salvar, 30); });
    })();
    // Arraste pelo cabeçalho — BLOQUEADO quando maximizada.
    var hd=win.querySelector('.oltMSHead');
    hd.addEventListener('mousedown', function(e){
        if(e.target.closest('button')) return;
        if(win.getAttribute('data-max')==='1') return;   // maximizada: não arrasta
        e.preventDefault();
        var r=win.getBoundingClientRect(); var sx=e.clientX, sy=e.clientY, ox=r.left, oy=r.top;
        win.style.margin='0';
        function mv(ev){ win.style.left=Math.max(0,(ox+ev.clientX-sx))+'px'; win.style.top=Math.max(0,(oy+ev.clientY-sy))+'px'; }
        function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
        document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
    });
    return id;
}
function _oltMSMax(id){ var w=document.getElementById(id); if(!w) return;
    var b=w.querySelector('.oltMSBody'); if(b) b.style.display='';   // SEMPRE mostra o corpo
    w.style.bottom='';                                               // limpa ancoragem do rodapé
    var estavaMin=(w.getAttribute('data-min')==='1');
    if(estavaMin) w.setAttribute('data-min','0');                   // sai do modo minimizado
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|');
        w.style.top=g[0]||'56px'; w.style.left=g[1]||'50%'; w.style.width=g[2]||'min(96vw,560px)'; w.style.height=g[3]||''; w.style.maxHeight='86vh'; w.style.borderRadius='12px'; w.setAttribute('data-max','0');
    } else {
        // Ao maximizar a partir do rodapé, guarda a geometria ORIGINAL (não a docada).
        var geo = estavaMin ? (w.getAttribute('data-minGeo')||'') : (w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height);
        w.setAttribute('data-geo', geo);
        w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1');
    }
    if(estavaMin) _oltMSDockLayout();   // reorganiza as que continuam no rodapé
    w.style.zIndex=(window._oltMSZ=(window._oltMSZ||2147483000)+1);
}
// Voltar = fecha a janela atual e volta à tela anterior (outra janela aberta ou o Menu).
function _oltMSVoltar(id){ var w=document.getElementById(id); if(w) w.remove();
    var outras=document.querySelectorAll('.oltMSWin');
    if(outras.length){ var u=outras[outras.length-1]; u.style.zIndex=(window._oltMSZ=(window._oltMSZ||2147483000)+1); }
    else { var d=document.getElementById('oltMenuDrop'); if(d && typeof oltToggleMenu==='function'){ oltToggleMenu(); } }
}
// Minimizar = DOCA a janela no RODAPÉ (embaixo), lado a lado. Restaurar volta ao lugar.
function _oltMSDockLayout(){
    var docked=document.querySelectorAll('.oltMSWin[data-min="1"]'); var x=8;
    docked.forEach(function(w){ w.style.top='auto'; w.style.bottom='6px'; w.style.left=x+'px'; w.style.width='232px'; w.style.height='auto'; w.style.maxHeight='none'; x+=240; });
}
function _oltMSMin(id){ var w=document.getElementById(id); if(!w) return; var b=w.querySelector('.oltMSBody'); if(!b) return;
    if(w.getAttribute('data-min')==='1'){ // restaurar
        w.setAttribute('data-min','0'); b.style.display='';
        var g=(w.getAttribute('data-minGeo')||'').split('|');
        w.style.top=g[0]||'56px'; w.style.bottom=''; w.style.left=g[1]||'50%'; w.style.width=g[2]||'min(96vw,560px)'; w.style.height=g[3]||''; w.style.maxHeight='86vh';
        _oltMSDockLayout();
    } else { // minimizar -> rodapé
        w.setAttribute('data-minGeo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height);
        w.setAttribute('data-min','1'); b.style.display='none'; w.style.maxHeight='none';
        _oltMSDockLayout();
    }
}
// ============================ BACKUP (salvar / restaurar) ============================
// Terminal de comandos da OLT (usa a conexão já salva). Janela flutuante com
// move/max/min via _oltModalSimples. Só nível 3.
function oltTerminal(){
    if(!_oltExigeNivel(3,'Terminal da OLT')) return;
    window._oltTermCreds=null;   // exige login a cada abertura
    // Tela de LOGIN (usuário/senha root) — como um console real da OLT.
    var corpo=
        '<div id="oltTermLogin">'+
          '<div style="background:#0b0f14; color:#9fe3aa; font-family:monospace; font-size:12.5px; line-height:1.6; padding:14px 16px; border-radius:8px; border:1px solid #1e2a36;">'+
            'Wellsystem — Console da OLT ('+_oltEsc((window._oltStatus&&window._oltStatus.olt)||'MA5683T')+')<br>Autentique-se para acessar o terminal.<br><br>'+
            '<div style="color:#c8d2dc;">Login:</div>'+
            '<input id="oltTermUser" value="root" autocomplete="off" style="'+_oltInSt()+' width:100%; box-sizing:border-box; margin:4px 0 10px; font-family:monospace;">'+
            '<div style="color:#c8d2dc;">Senha:</div>'+
            '<input id="oltTermPass" type="password" autocomplete="new-password" onkeydown="if(event.key===\'Enter\')_oltTermLogar()" style="'+_oltInSt()+' width:100%; box-sizing:border-box; margin:4px 0 12px; font-family:monospace;">'+
            '<button onclick="_oltTermLogar()" style="cursor:pointer; padding:9px 20px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-right-to-bracket"></i> Entrar</button>'+
            '<span id="oltTermMsg" style="margin-left:12px; font-family:sans-serif; font-size:12px;"></span>'+
          '</div>'+
        '</div>'+
        '<div id="oltTermConsole" style="display:none;">'+
          '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:8px;">Logado como <b style="color:'+OLTC.ink+';">root</b>. Digite um comando — ex.: <b style="color:'+OLTC.acc+'; font-family:monospace;">display board 0</b> — e pressione <b style="color:'+OLTC.ink+';">Enter</b>.</div>'+
          '<div id="oltTermOut" style="background:#0b0f14; color:#7fe08a; font-family:monospace; font-size:12px; line-height:1.45; padding:10px 12px; border-radius:8px; height:min(52vh,420px); overflow:auto; white-space:pre-wrap; border:1px solid #1e2a36;">Wellsystem — Terminal OLT. Pronto.\n</div>'+
          '<div style="display:flex; gap:8px; margin-top:8px;">'+
            '<span style="color:'+OLTC.grn+'; font-family:monospace; font-weight:800; align-self:center;">OLT#</span>'+
            '<input id="oltTermIn" placeholder="digite o comando e Enter" onkeydown="if(event.key===\'Enter\')_oltTermRun()" style="'+_oltInSt()+' flex:1 1 auto; min-width:0; font-family:monospace;">'+
            '<button onclick="_oltTermRun()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:none; background:'+OLTC.acc+'; color:#fff; font-weight:800;"><i class="fa-solid fa-play"></i></button>'+
          '</div>'+
        '</div>';
    _oltModalSimples('fa-terminal','Prompt de Comando — OLT', corpo, false);
    setTimeout(function(){ var i=document.getElementById('oltTermUser'); if(i){ i.focus(); i.select(); } }, 100);
}
// Autentica no terminal: roda um comando de teste com as credenciais digitadas.
function _oltTermLogar(tent){
    tent = tent||1;
    var u=(document.getElementById('oltTermUser')||{}).value||'', p=(document.getElementById('oltTermPass')||{}).value||'';
    var msg=document.getElementById('oltTermMsg');
    if(!u||!p){ if(msg){ msg.style.color='#fca5a5'; msg.textContent='Informe usuário e senha.'; } return; }
    if(msg){ msg.style.color='#9fd0ff'; msg.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> autenticando…'+(tent>1?(' (tentativa '+tent+')'):''); }
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=terminal_exec&cmd='+encodeURIComponent('display board 0')+'&u='+encodeURIComponent(u)+'&p='+encodeURIComponent(p)})
      .then(function(r){return r.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        var s=(d&&d.saida)||'';
        var authFail=/failure|denied|username or password|authentication fail|login incorrect/i.test(s);
        var transiente=(!s) || /\[falha\]/i.test(s);   // Telnet/VTY ocupada → vale re-tentar
        if(!authFail && !transiente){   // OLT respondeu de verdade → entra e já mostra a saída
            window._oltTermCreds={u:u,p:p};
            var lg=document.getElementById('oltTermLogin'), co=document.getElementById('oltTermConsole');
            if(lg) lg.style.display='none'; if(co) co.style.display='';
            var o=document.getElementById('oltTermOut');
            if(o) o.innerHTML='Wellsystem — Terminal OLT. Login OK ('+_oltEsc(u)+').\n\n<span style="color:#9fd0ff;">OLT# display board 0</span>\n'+_oltEsc(s)+'\n';
            var i=document.getElementById('oltTermIn'); if(i) i.focus();
        } else if(transiente && tent<3){   // re-tenta sozinho (entra de primeira p/ o usuário)
            setTimeout(function(){ _oltTermLogar(tent+1); }, 500);
        } else if(msg){ msg.style.color='#fca5a5'; msg.textContent = authFail ? 'Usuário ou senha inválidos.' : (s ? s.replace('[falha] ','').substr(0,90) : 'OLT não respondeu.'); }
      }).catch(function(){ if(tent<3){ setTimeout(function(){ _oltTermLogar(tent+1); }, 500); } else if(msg){ msg.style.color='#fca5a5'; msg.textContent='Erro de comunicação.'; } });
}
function _oltTermRun(){
    var i=document.getElementById('oltTermIn'), o=document.getElementById('oltTermOut'); if(!i||!o) return;
    if(!window._oltTermCreds){ return; }
    var cmd=(i.value||'').trim(); if(!cmd) return; i.value='';
    o.innerHTML+='\n<span style="color:#9fd0ff;">OLT# '+_oltEsc(cmd)+'</span>\n<span style="color:#6b7683;">executando…</span>';
    o.scrollTop=o.scrollHeight;
    var cr=window._oltTermCreds;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=terminal_exec&cmd='+encodeURIComponent(cmd)+'&u='+encodeURIComponent(cr.u)+'&p='+encodeURIComponent(cr.p)})
      .then(function(r){return r.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        o.innerHTML=o.innerHTML.replace(/<span style="color:#6b7683;">executando…<\/span>$/,'')+_oltEsc((d&&d.saida)||'(sem saída)')+'\n'; o.scrollTop=o.scrollHeight;
      }).catch(function(){ o.innerHTML+='\n<span style="color:#f87171;">erro de comunicação</span>\n'; o.scrollTop=o.scrollHeight; });
}
// ===================== GRÁFICO — Status da rede ==============================
// Área verde = Online · linhas azul/laranja/cinza = Falha de Energia / LOS / N/A.
// Fonte: histórico horário gravado pelo cron (olt_hist.json). Modos: hora / dia /
// semana / mês / ano (janela + granularidade). Sem dados = aviso honesto.
var _oltGrafModos={hora:{lbl:'Gráfico por hora',dia:false,janela:120},dia:{lbl:'Gráfico diário',dia:false,janela:480},semana:{lbl:'Gráfico semanal',dia:true,janela:7},mes:{lbl:'Gráfico mensal',dia:true,janela:30},ano:{lbl:'Gráfico anual',dia:true,janela:365}};
function oltGrafico(){
    if(!_oltExigeNivel(1,'Status da rede')) return;
    var ex=document.getElementById('oltGrafWin'); if(ex){ ex.style.display='flex'; ex.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); return; }
    // Janela FLUTUANTE própria (solta na página): arrasta pelo cabeçalho, redimensiona
    // pelo canto, grava tamanho/posição, e tem cara de "card" (cabeçalho escuro).
    var win=document.createElement('div'); win.id='oltGrafWin';
    var g=null; try{ g=JSON.parse(localStorage.getItem('oltGrafGeo')||'null'); }catch(e){}
    var ww=(g&&g.w)?g.w:(Math.min(760,Math.round(window.innerWidth*0.92))+'px');
    var hh=(g&&g.h)?g.h:(Math.min(470,Math.round(window.innerHeight*0.8))+'px');
    var ll=(g&&g.l)?g.l:(Math.max(8,Math.round((window.innerWidth-parseInt(ww))/2))+'px');
    var tt=(g&&g.t)?g.t:'60px';
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:'+tt+'; left:'+ll+'; width:'+ww+'; height:'+hh+'; display:flex; flex-direction:column; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.5); overflow:hidden; resize:both; min-width:360px; min-height:260px;';
    win.onmousedown=function(){ win.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); };
    win.innerHTML=
        '<div id="oltGrafHead" style="flex:0 0 auto; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:12px 16px; background:#33383f; cursor:move;">'+
          '<div style="font-weight:800; color:#fff; font-size:14px;"><i class="fa-solid fa-chart-column" style="color:#9fe3aa;"></i> Status da rede</div>'+
          '<div style="display:flex; align-items:center; gap:8px; position:relative;">'+
            '<button onclick="_oltGrafMenu()" style="cursor:pointer; padding:7px 12px; border-radius:7px; border:1px solid rgba(255,255,255,.35); background:rgba(255,255,255,.08); color:#fff; font-weight:700; font-size:12px;">Mais gráficos <i class="fa-solid fa-caret-down"></i></button>'+
            '<div id="oltGrafDrop" style="display:none; position:absolute; right:34px; top:110%; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:9px; box-shadow:0 12px 34px rgba(0,0,0,.3); z-index:5; overflow:hidden; min-width:170px;">'+
            Object.keys(_oltGrafModos).map(function(k){return '<div onclick="_oltGrafSet(\''+k+'\')" style="padding:9px 14px; cursor:pointer; font-size:12.5px; color:'+OLTC.ink+';" onmouseover="this.style.background=\''+OLTC.bg2+'\'" onmouseout="this.style.background=\'transparent\'">'+_oltGrafModos[k].lbl+'</div>';}).join('')+
            '</div>'+
            '<button onclick="_oltGrafMin()" title="Minimizar" style="cursor:pointer; width:30px; height:28px; border-radius:6px; border:1px solid rgba(255,255,255,.35); background:transparent; color:#fff; font-size:13px;"><i class="fa-solid fa-minus"></i></button>'+
            '<button onclick="_oltGrafMax()" title="Maximizar / Restaurar" style="cursor:pointer; width:30px; height:28px; border-radius:6px; border:1px solid rgba(255,255,255,.35); background:transparent; color:#fff; font-size:13px;"><i class="fa-solid fa-expand"></i></button>'+
            '<button onclick="var w=document.getElementById(\'oltGrafWin\'); if(w) w.remove(); if(window._oltGrafTimer){clearInterval(window._oltGrafTimer); window._oltGrafTimer=null;}" title="Fechar" style="cursor:pointer; width:30px; height:28px; border-radius:6px; border:1px solid rgba(255,255,255,.35); background:rgba(0,0,0,.28); color:#fff; font-size:13px;"><i class="fa-solid fa-xmark"></i></button>'+
          '</div>'+
        '</div>'+
        '<div style="flex:1 1 auto; overflow:hidden; padding:14px 16px; min-height:0;"><div id="oltGrafArea" style="height:100%;"><div style="text-align:center; color:'+OLTC.mut+'; padding:60px 0;"><i class="fa-solid fa-spinner fa-spin"></i> Carregando histórico…</div></div></div>';
    document.body.appendChild(win);
    if(typeof oltDragify==='function') oltDragify(win, document.getElementById('oltGrafHead'));
    if(typeof oltResizify==='function') oltResizify(win, 360, 260);
    var _grafSalvar=function(){ try{ localStorage.setItem('oltGrafGeo', JSON.stringify({w:win.style.width, h:win.offsetHeight+'px', l:win.style.left, t:win.style.top})); }catch(e){} };
    win.addEventListener('mouseup', function(){ clearTimeout(window._oltGrafGeoT); window._oltGrafGeoT=setTimeout(_grafSalvar, 200); });
    if(typeof ResizeObserver!=='undefined'){ var ro=new ResizeObserver(function(){ clearTimeout(window._oltGrafGeoT); window._oltGrafGeoT=setTimeout(_grafSalvar, 300); }); ro.observe(win); }
    window._oltGrafModo='dia';   // abre já mostrando as variações do dia (buffer fino)
    _oltGrafBuscar(true);
    if(window._oltGrafTimer){ clearInterval(window._oltGrafTimer); }
    window._oltGrafTimer=setInterval(function(){
        if(!document.getElementById('oltGrafArea')){ clearInterval(window._oltGrafTimer); window._oltGrafTimer=null; return; }
        _oltGrafBuscar(false);
    }, 60000);
}
function _oltGrafMax(){ var w=document.getElementById('oltGrafWin'); if(!w) return;
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|');
        w.style.top=g[0]||'60px'; w.style.left=g[1]||'8px'; w.style.width=g[2]||'760px'; w.style.height=g[3]||'470px'; w.style.borderRadius='14px'; w.style.resize='both'; w.setAttribute('data-max','0');
    } else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height);
        w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.borderRadius='0'; w.style.resize='none'; w.setAttribute('data-max','1'); }
    w.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1);
    setTimeout(function(){ try{ _oltGrafRender(); }catch(e){} }, 40);
}
function _oltGrafMin(){ var w=document.getElementById('oltGrafWin'); if(!w) return;
    w.style.display='none';
    var pid='oltGrafPill', old=document.getElementById(pid); if(old) old.remove();
    var pill=document.createElement('button'); pill.id=pid; pill.className='oltMinPill';
    pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:2147483300; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#33383f; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
    pill.innerHTML='<i class="fa-solid fa-chart-column"></i> Status da rede';
    pill.onclick=function(){ w.style.display='flex'; w.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); pill.remove(); if(typeof _oltPillsArrumar==='function') _oltPillsArrumar(); };
    document.body.appendChild(pill);
    if(typeof _oltPillsArrumar==='function') _oltPillsArrumar();
}
function _oltGrafBuscar(mostrarErro){
    (typeof _oltFetchDireto==='function'?_oltFetchDireto('olt_huawei.php?acao=grafico_dados',15000):fetch('olt_huawei.php?acao=grafico_dados')).then(function(r){return r.json();}).then(function(d){
        window._oltHist=(d&&d.hist)||[]; window._oltHistDia=(d&&d.hist_dia)||[]; _oltGrafRender();
    }).catch(function(){ if(mostrarErro){ var a=document.getElementById('oltGrafArea'); if(a) a.innerHTML='<div style="text-align:center; color:'+OLTC.red+'; padding:50px 0;">Erro ao carregar o histórico.</div>'; } });
}
function _oltGrafMenu(){ var d=document.getElementById('oltGrafDrop'); if(d) d.style.display=(d.style.display==='none'?'block':'none'); }
function _oltGrafSet(m){ window._oltGrafModo=m; var d=document.getElementById('oltGrafDrop'); if(d) d.style.display='none'; _oltGrafRender(); }
function _oltGrafAgrupa(cfg){
    var out=[];
    if(cfg.dia){ // semana/mês/ano: usa o RESUMO DIÁRIO (1 ponto/dia)
        (window._oltHistDia||[]).forEach(function(p){ var d=p.d||''; var t=Date.parse((d||'1970-01-01')+'T12:00:00')/1000||0; out.push({lbl:d.substr(8,2)+'/'+d.substr(5,2), t:t, dia:true, on:p.on||0, en:p.en||0, los:p.los||0, na:p.na||0, tot:p.tot||0, dn:p.dn||0}); });
    } else { // hora/dia: usa o BUFFER FINO (por minuto) — mostra as variações reais
        (window._oltHist||[]).forEach(function(p){ var t=(+p.t||0)||(Date.parse(String(p.h||'').replace(' ','T'))/1000)||0; out.push({lbl:(p.h||'').substr(11,5), t:t, dia:false, on:p.on||0, en:p.en||0, los:p.los||0, na:p.na||0, tot:p.tot||0, dn:p.dn||0}); });
    }
    return out.slice(-cfg.janela);
}
function _oltGrafRender(){
    var a=document.getElementById('oltGrafArea'); if(!a) return;
    var cfg=_oltGrafModos[window._oltGrafModo||'mes'], pts=_oltGrafAgrupa(cfg);
    if(pts.length<1){ a.innerHTML='<div style="text-align:center; color:'+OLTC.mut+'; padding:46px 14px; line-height:1.6;"><i class="fa-solid fa-hourglass-half" style="font-size:22px; opacity:.5;"></i><br><b>Ainda coletando dados.</b><br><span style="font-size:12px;">Abra o gerenciador (ou deixe o monitor rodar) — os pontos vão aparecendo. Volte em alguns minutos.</span></div>'; return; }
    var W=820,H=280,pl=46,pr=14,ptp=14,pb=26, iw=W-pl-pr, ih=H-ptp-pb;
    var ymax=0; pts.forEach(function(p){ ymax=Math.max(ymax,p.tot,p.on); }); ymax=Math.max(10,Math.ceil(ymax/50)*50);
    var _t0=pts[0].t||0, _t1=pts[pts.length-1].t||0; if(!(_t1>_t0)) _t1=_t0+1;   // eixo por TEMPO (igual SmartOLT)
    var X=function(i){ var t=pts[i].t||_t0; return pl+iw*Math.max(0,Math.min(1,(t-_t0)/(_t1-_t0))); }, Y=function(v){ return ptp+ih-ih*v/ymax; };
    var linha=function(campo,cor,larg){ var d=pts.map(function(p,i){return (i?'L':'M')+X(i).toFixed(1)+' '+Y(p[campo]).toFixed(1);}).join(' '); return '<path d="'+d+'" fill="none" stroke="'+cor+'" stroke-width="'+larg+'" stroke-linejoin="round"/>'; };
    var areaOn=(function(){ var d='M'+X(0).toFixed(1)+' '+Y(0).toFixed(1); pts.forEach(function(p,i){ d+=' L'+X(i).toFixed(1)+' '+Y(p.on).toFixed(1); }); d+=' L'+X(pts.length-1).toFixed(1)+' '+Y(0).toFixed(1)+' Z'; return '<path d="'+d+'" fill="rgba(46,160,67,.16)" stroke="#2ea043" stroke-width="2"/>'; })();
    // grade + eixo Y
    var grid=''; for(var g=0;g<=3;g++){ var v=ymax*g/3, yy=Y(v); grid+='<line x1="'+pl+'" y1="'+yy.toFixed(1)+'" x2="'+(W-pr)+'" y2="'+yy.toFixed(1)+'" stroke="'+OLTC.line+'" stroke-width="1" opacity=".5"/>'+'<text x="'+(pl-6)+'" y="'+(yy+3).toFixed(1)+'" text-anchor="end" font-size="10" fill="'+OLTC.mut+'">'+Math.round(v)+'</text>'; }
    // rótulos X por TEMPO (espaçados por igual — 00:00/03:00... como o SmartOLT), não por índice de ponto
    var xl=''; var _NL=6; for(var _k=0;_k<=_NL;_k++){ var _xx=pl+iw*_k/_NL; var _tt=_t0+(_t1-_t0)*_k/_NL; var _dd=new Date(_tt*1000);
        var _lb=pts[0].dia?(('0'+_dd.getDate()).slice(-2)+'/'+('0'+(_dd.getMonth()+1)).slice(-2)):(('0'+_dd.getHours()).slice(-2)+':'+('0'+_dd.getMinutes()).slice(-2));
        xl+='<text x="'+_xx.toFixed(1)+'" y="'+(H-8)+'" text-anchor="middle" font-size="10" fill="'+OLTC.mut+'">'+_lb+'</text>'; }
    // pico e vale de Online
    var iMax=0,iMin=0; pts.forEach(function(p,i){ if(p.on>pts[iMax].on)iMax=i; if(p.on<pts[iMin].on)iMin=i; });
    var mk=function(idx,cor,rr){ return '<circle cx="'+X(idx).toFixed(1)+'" cy="'+Y(pts[idx].on).toFixed(1)+'" r="'+(rr||3.5)+'" fill="'+cor+'" stroke="#fff" stroke-width="'+(rr?2:1.5)+'"/>'; };
    var ult=pts[pts.length-1];
    // Guia vertical + ponto (vermelho vivo) que seguem o cursor; tooltip via JS.
    var svg='<svg id="oltGrafSvg" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%; height:100%; display:block;">'+grid+areaOn+
        linha('en',OLTC.acc||'#1877f2',1.8)+linha('los','#e0a800',1.6)+linha('na','#8a94a6',1.4)+
        '<line id="oltGrafGuide" x1="0" y1="'+ptp+'" x2="0" y2="'+(ptp+ih)+'" stroke="#ff2d2d" stroke-width="1" opacity="0"/>'+
        '<circle id="oltGrafDot" r="4.5" fill="#ff2d2d" stroke="#fff" stroke-width="1.5" opacity="0"/>'+
        mk(iMax,'#2ea043')+mk(iMin,'#ff2d2d',5)+xl+'</svg>';
    var leg=function(cor,txt,val){ return '<span style="display:inline-flex; align-items:center; gap:6px; font-size:12px; color:'+OLTC.ink+'; margin:0 10px;"><span style="width:11px; height:11px; border-radius:50%; background:'+cor+'; display:inline-block;"></span>'+txt+' ('+val+')</span>'; };
    // Coluna que preenche a janela: gráfico (flex) + legenda + pico/vale — SEM barra de rolagem.
    a.innerHTML='<div style="display:flex; flex-direction:column; height:100%;">'+
        '<div id="oltGrafWrap" style="position:relative; flex:1 1 auto; min-height:0;" onmousemove="_oltGrafHover(event)" onmouseleave="_oltGrafLeave()">'+svg+
        '<div id="oltGrafTip" style="position:absolute; display:none; pointer-events:none; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:8px; box-shadow:0 8px 24px rgba(0,0,0,.35); padding:8px 10px; font-size:11.5px; color:'+OLTC.ink+'; z-index:10; white-space:nowrap;"></div></div>'+
        '<div style="flex:0 0 auto; text-align:center; margin-top:8px;">'+leg('#2ea043','Online',ult.on)+leg(OLTC.acc||'#1877f2','Falha de Energia',ult.en)+leg('#e0a800','LOS',ult.los)+leg('#8a94a6','N/A',ult.na)+'</div>'+
        '<div style="flex:0 0 auto; text-align:center; font-size:11px; color:'+OLTC.mut+'; margin-top:6px;">Pico <b style="color:#2ea043;">'+pts[iMax].on+'</b> ('+pts[iMax].lbl+') · Vale <b style="color:#ff2d2d;">'+pts[iMin].on+'</b> ('+pts[iMin].lbl+') · '+_oltGrafModos[window._oltGrafModo].lbl+'</div>'+
      '</div>';
    window._oltGrafPts=pts; window._oltGrafGeo={W:W,H:H,pl:pl,iw:iw,ptp:ptp,ih:ih,ymax:ymax,t0:_t0,t1:_t1};
}
// Passar o mouse pelo gráfico → detalha o momento sob o cursor (guia + ponto + tooltip).
function _oltGrafHover(e){
    var wrap=document.getElementById('oltGrafWrap'), svg=document.getElementById('oltGrafSvg'), tip=document.getElementById('oltGrafTip');
    var pts=window._oltGrafPts, G=window._oltGrafGeo; if(!wrap||!svg||!tip||!pts||!pts.length||!G) return;
    var rect=svg.getBoundingClientRect(); if(!rect.width) return;
    var sx=(e.clientX-rect.left)/rect.width*G.W;
    var frac=Math.max(0,Math.min(1,(sx-G.pl)/(G.iw||1))); var ct=(G.t0||0)+((G.t1||1)-(G.t0||0))*frac;   // TEMPO sob o cursor
    var i=0, best=1e18; for(var _j=0;_j<pts.length;_j++){ var _dt=Math.abs((pts[_j].t||G.t0)-ct); if(_dt<best){ best=_dt; i=_j; } }   // ponto de tempo mais próximo
    var p=pts[i], X=G.pl+G.iw*Math.max(0,Math.min(1,((pts[i].t||G.t0)-(G.t0||0))/(((G.t1||1)-(G.t0||0))||1))), Yon=G.ptp+G.ih-G.ih*p.on/G.ymax;
    var guide=document.getElementById('oltGrafGuide'), dot=document.getElementById('oltGrafDot');
    if(guide){ guide.setAttribute('x1',X); guide.setAttribute('x2',X); guide.setAttribute('opacity','.55'); }
    if(dot){ dot.setAttribute('cx',X); dot.setAttribute('cy',Yon); dot.setAttribute('opacity','1'); }
    tip.innerHTML='<b>'+_oltEsc(p.lbl)+'</b><br><span style="color:#2ea043;">● Online: <b>'+p.on+'</b></span><br><span style="color:'+(OLTC.acc||'#1877f2')+';">● Energia: <b>'+p.en+'</b></span><br><span style="color:#e0a800;">● LOS: <b>'+p.los+'</b></span><br><span style="color:#8a94a6;">● N/A: <b>'+p.na+'</b></span>';
    tip.style.display='block';
    var wb=wrap.getBoundingClientRect(); var wl=e.clientX-wb.left+14, wt=e.clientY-wb.top+12;
    if(wl+160>wrap.offsetWidth) wl=wl-176;
    tip.style.left=Math.max(0,wl)+'px'; tip.style.top=Math.max(0,wt)+'px';
}
function _oltGrafLeave(){ var t=document.getElementById('oltGrafTip'); if(t) t.style.display='none';
    var g=document.getElementById('oltGrafGuide'); if(g) g.setAttribute('opacity','0');
    var d=document.getElementById('oltGrafDot'); if(d) d.setAttribute('opacity','0'); }
// ===================== EMERGÊNCIA DO RADIUS (Qualquer login) =================
// Fala DIRETO com o painel de cada concentrador (independe do Radius): loga e
// posta rad=3 (Qualquer login) ou rad=0 (Radius). Config e credenciais na tela.
function oltRadiusEmergencia(){
    if(!_oltExigeNivel(2,'Emergência do Radius')) return;
    var corpo=
      '<div style="border:1px solid #b71c1c; background:linear-gradient(180deg,#d32f2f,#a31515); border-radius:10px; padding:12px 14px; margin-bottom:14px; font-size:12.5px; color:#fff; line-height:1.55; text-shadow:0 1px 1px rgba(0,0,0,.35);">'+
        '<b style="color:#fff; font-size:13px;"><i class="fa-solid fa-triangle-exclamation"></i> Modo de emergência.</b> "Qualquer login" faz os clientes autenticarem <b style="color:#ffe08a;">sem passar pelo Radius</b> (inclusive bloqueados). Use só quando o Radius estiver com problema e <b style="color:#ffe08a;">volte ao Radius</b> depois.'+
      '</div>'+
      '<div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:14px;">'+
        '<button onclick="_oltRadAcao(\'emergencia\')" style="flex:1 1 220px; cursor:pointer; padding:14px; border-radius:10px; border:none; background:linear-gradient(180deg,#e64d4d,#ab2323); color:#fff; font-weight:800; font-size:13px;"><i class="fa-solid fa-bolt"></i> ATIVAR Qualquer login</button>'+
        '<button onclick="_oltRadAcao(\'radius\')" style="flex:1 1 220px; cursor:pointer; padding:14px; border-radius:10px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:13px;"><i class="fa-solid fa-shield-halved"></i> VOLTAR ao Radius</button>'+
      '</div>'+
      '<div id="oltRadResult" style="font-size:12.5px; margin-bottom:14px;"></div>'+
      '<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; font-size:13px;">Painéis dos concentradores</div>'+
        '<button onclick="_oltRadAddRow()" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-plus"></i> Adicionar</button>'+
      '</div>'+
      '<div id="oltRadList"></div>'+
      '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin:6px 0 12px;">URL até <b>/adm</b> (ex.: http://192.0.2.21:8086/adm) · usuário/senha do painel · <b>dmco/inter/defrat</b> = os mesmos valores do Aplicar (não alteram o resto da config).</div>'+
      '<button onclick="_oltRadSalvar()" style="cursor:pointer; padding:9px 18px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-floppy-disk"></i> Salvar painéis</button>';
    _oltModalSimples('fa-triangle-exclamation','Emergência do Radius — Qualquer login', corpo, false);
    fetch('olt_huawei.php?acao=radius_panel_get').then(function(r){return r.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        var ps=(d&&d.paineis)||[]; if(!ps.length) ps=[{}]; ps.forEach(function(p){ _oltRadAddRow(p); });
    }).catch(function(){ _oltRadAddRow({}); });
}
function _oltRadRow(p){ p=p||{}; var s=_oltInSt();
    return '<div class="oltRadRow" style="border:1px solid '+OLTC.line+'; border-radius:9px; padding:10px; margin-bottom:8px; background:'+OLTC.bg2+';">'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">'+
        '<label title="Aplicar a ação neste concentrador" style="display:flex; align-items:center; gap:5px; font-size:11px; font-weight:700; color:'+OLTC.txt+'; flex:0 0 auto; white-space:nowrap;"><input type="checkbox" class="rp_sel" checked> aplicar</label>'+
        '<input class="rp_nome" value="'+_oltEsc(p.nome||'')+'" placeholder="apelido (ex.: Concentrador 1)" style="'+s+' flex:1 1 130px; min-width:0;">'+
        '<input class="rp_base" value="'+_oltEsc(p.base||'')+'" placeholder="http://IP:porta/adm" style="'+s+' flex:2 1 180px; min-width:0;">'+
        '<button onclick="var b=this.closest(\'.oltRadRow\').querySelector(\'.rp_base\').value; if(b) window.open(b.replace(/\\/[^\\/]*\\.php.*$/i,\'\'),\'_blank\');" title="Abrir o painel deste concentrador para trocar manualmente" style="cursor:pointer; flex:0 0 auto; padding:7px 10px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:700; font-size:11px; white-space:nowrap;"><i class="fa-solid fa-up-right-from-square"></i> Abrir painel</button>'+
        '<button onclick="this.closest(\'.oltRadRow\').remove()" title="Remover" style="cursor:pointer; flex:0 0 auto; width:34px; border-radius:8px; border:1px solid '+OLTC.red+'; background:transparent; color:'+OLTC.red+';"><i class="fa-solid fa-trash"></i></button>'+
      '</div>'+
      '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:8px;">'+
        '<input class="rp_user" value="'+_oltEsc(p.user||'')+'" placeholder="usuário do painel" style="'+s+' flex:1 1 120px; min-width:0;">'+
        '<input class="rp_pass" type="password" autocomplete="new-password" placeholder="'+(p.tem_pass?'•••• (salva — vazio mantém)':'senha do painel')+'" style="'+s+' flex:1 1 120px; min-width:0;">'+
        '<input class="rp_dmco" value="'+_oltEsc(p.dmco||'')+'" placeholder="dmco" style="'+s+' flex:0 1 80px;" title="DM / CoA (ex.: 3799)">'+
        '<input class="rp_inter" value="'+_oltEsc(p.inter||'')+'" placeholder="inter" style="'+s+' flex:0 1 80px;" title="Tempo de atualização (ex.: 300)">'+
        '<select class="rp_defrat" title="Velocidade (Limite padrão) aplicada a todos no modo Qualquer login" style="'+s+' flex:0 1 130px;">'+
          ['1|50 mega','2|100 mega','3|200 mega'].map(function(o){ var a=o.split('|'); return '<option value="'+a[0]+'"'+((''+(p.defrat||'3'))===a[0]?' selected':'')+'>'+a[1]+'</option>'; }).join('')+
        '</select>'+
      '</div>'+
    '</div>';
}
function _oltRadAddRow(p){ var l=document.getElementById('oltRadList'); if(l) l.insertAdjacentHTML('beforeend', _oltRadRow(p)); }
function _oltRadColeta(){ var out=[]; document.querySelectorAll('#oltRadList .oltRadRow').forEach(function(r){
    var g=function(c){ var e=r.querySelector('.'+c); return e?e.value.trim():''; };
    var base=g('rp_base'); if(!base) return;
    out.push({nome:g('rp_nome'), base:base, user:g('rp_user'), pass:(r.querySelector('.rp_pass')||{}).value||'', dmco:g('rp_dmco'), inter:g('rp_inter'), defrat:g('rp_defrat')});
}); return out; }
function _oltRadSalvar(cb){ var r=document.getElementById('oltRadResult'); if(r&&typeof cb!=='function') r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    fetch('olt_huawei.php?acao=radius_panel_set',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'paineis='+encodeURIComponent(JSON.stringify(_oltRadColeta()))})
      .then(function(rr){return rr.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(typeof cb==='function'){ if(d&&d.saved) cb(); else if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Não gravou os painéis.</span>'; return; }
        if(r) r.innerHTML=(d&&d.saved)?'<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Painéis salvos.</span>':'<span style="color:'+OLTC.red+';">Não gravou.</span>';
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
function _oltRadAcao(modo){
    var emerg=(modo==='emergencia');
    var r0=document.getElementById('oltRadResult');
    // Índices marcados (alinhados com a lista salva = linhas com URL preenchida).
    var alvos=[], idx=0;
    document.querySelectorAll('#oltRadList .oltRadRow').forEach(function(rw){
        var base=(rw.querySelector('.rp_base')||{}).value; if(!base||!base.trim()) return;
        var chk=rw.querySelector('.rp_sel'); if(!chk||chk.checked) alvos.push(idx); idx++;
    });
    if(!alvos.length){ if(r0) r0.innerHTML='<span style="color:'+OLTC.red+';">Marque ao menos um concentrador (caixa "aplicar").</span>'; return; }
    if(!confirm((emerg? 'ATIVAR "Qualquer login"' : 'VOLTAR ao Radius')+' em '+alvos.length+' concentrador(es)?'+(emerg?'\n\nTODOS os clientes conectam SEM passar pelo Radius (inclusive bloqueados). Use só em emergência.':''))) return;
    if(emerg && !confirm('Confirma mesmo? Libera geral até você voltar ao Radius.')) return;
    _oltRadSalvar(function(){   // salva antes de aplicar
        var r=document.getElementById('oltRadResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Aplicando…';
        fetch('olt_huawei.php?acao=radius_emergencia',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'modo='+encodeURIComponent(modo)+'&alvos='+encodeURIComponent(alvos.join(','))})
          .then(function(rr){return rr.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
            if(d&&d.status==='erro'){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">'+_oltEsc(d.message||'Falha.')+'</span>'; return; }
            var linhas=((d&&d.resultados)||[]).map(function(x){ return '<div style="padding:3px 0;"><i class="fa-solid '+(x.ok?'fa-circle-check':'fa-circle-xmark')+'" style="color:'+(x.ok?OLTC.grn:OLTC.red)+';"></i> '+_oltEsc(x.nome)+' — '+_oltEsc(x.msg)+(x.diag?('<div style="font-size:10px; color:'+OLTC.mut+'; font-family:monospace; margin-left:20px; word-break:break-all;">'+_oltEsc(x.diag)+'</div>'):'')+'</div>'; }).join('');
            if(r) r.innerHTML='<div style="display:inline-block; font-weight:800; color:#fff; background:'+(emerg?'#d32f2f':'#15803d')+'; padding:4px 12px; border-radius:20px; margin-bottom:8px; text-shadow:0 1px 1px rgba(0,0,0,.35);">'+(emerg?'Modo QUALQUER LOGIN aplicado':'Modo RADIUS restaurado')+'</div>'+linhas;
          }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro de comunicação.</span>'; });
    });
}
function oltBackup(){
    if(!_oltExigeNivel(2,'Backup do sistema')) return;
    _oltFecharConfigs('oltBkOv');
    var s=_oltInSt();
    var box=function(ic,cor,tit,sub,btnHtml){ return '<div style="border:1px solid '+OLTC.line+'; border-radius:10px; padding:14px; margin-bottom:12px; background:'+OLTC.bg2+';">'+
        '<div style="font-weight:900; color:'+OLTC.ink+'; font-size:15px; display:flex; align-items:center; gap:9px; margin-bottom:5px;"><i class="fa-solid '+ic+'" style="color:'+cor+'; font-size:16px;"></i> '+tit+'</div>'+
        '<div style="font-size:11.5px; color:'+OLTC.txt+'; line-height:1.5; margin-bottom:10px;">'+sub+'</div>'+btnHtml+'</div>'; };
    var corpo=
          '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:12px;">O backup inclui: <b>nomes/descrições das ONUs</b>, <b>apelidos/VLAN/Zona das placas e portas</b>, <b>notificações</b>, <b>relatório</b>, <b>estado das PONs</b> e <b>perfis</b>.</div>'+
          box('fa-download',OLTC.grn,'Baixar backup','Gera um arquivo <b style="color:'+OLTC.acc+'; font-family:monospace;">ponto json</b> com todas as configurações atuais.',
              '<button onclick="oltBackupBaixar(this)" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-download"></i> Baixar backup agora</button>')+
          box('fa-upload',OLTC.amb,'Restaurar backup','Selecione um arquivo de backup. <b>Substitui</b> as configurações atuais.',
              '<input type="file" id="oltBkFile" accept="application/json,.json" style="display:none;" onchange="oltBackupRestaurar(this)">'+
              '<button onclick="document.getElementById(\'oltBkFile\').click()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.amb+'; background:transparent; color:'+OLTC.amb+'; font-weight:800;"><i class="fa-solid fa-upload"></i> Escolher arquivo…</button>')+
          box('fa-clock',OLTC.acc,'Backup automático diário (por e-mail)',
              'Envia o backup por e-mail todo dia no horário marcado (depende do cron instalado no servidor).',
              '<label style="display:flex; align-items:center; gap:8px; font-weight:700; color:'+OLTC.txt+'; margin-bottom:8px;"><input type="checkbox" id="bkAgAtivo"> Ativar envio diário</label>'+
              '<div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">'+
                '<span style="font-size:11px; color:'+OLTC.mut+';">Horário:</span><input type="time" id="bkAgHora" value="03:00" style="'+s+' flex:0 0 110px;">'+
                '<input type="email" id="bkAgEmail" placeholder="e-mail de destino" style="'+s+' flex:1 1 170px; min-width:0;">'+
                '<button onclick="_oltBkAgSalvar()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>'+
                '<button onclick="_oltBkAgTestar()" title="Envia um e-mail de teste agora para conferir se o servidor entrega" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800;"><i class="fa-solid fa-paper-plane"></i> Enviar teste agora</button>'+
              '</div>'+
              '<div style="margin-top:12px; border-top:1px dashed '+OLTC.line+'; padding-top:10px;">'+
                '<div style="font-size:11.5px; color:'+OLTC.txt+'; font-weight:700; margin-bottom:6px;">Servidor SMTP <span style="font-weight:400; color:'+OLTC.mut+';">(preencha se o servidor não envia e-mail sozinho — ex.: Gmail smtp.gmail.com / 587 / TLS)</span></div>'+
                '<div style="display:flex; gap:8px; flex-wrap:wrap;">'+
                  '<input id="bkSmtpHost" placeholder="smtp.host.com" style="'+s+' flex:2 1 160px; min-width:0;">'+
                  '<input id="bkSmtpPort" inputmode="numeric" placeholder="587" style="'+s+' flex:0 0 70px;">'+
                  '<select id="bkSmtpSeg" style="'+s+' flex:0 0 90px;"><option value="tls">TLS</option><option value="ssl">SSL</option><option value="none">Nenhuma</option></select>'+
                '</div>'+
                '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:8px;">'+
                  '<input id="bkSmtpUser" placeholder="usuário / e-mail de login" style="'+s+' flex:1 1 160px; min-width:0;">'+
                  '<input id="bkSmtpPass" type="password" autocomplete="new-password" placeholder="senha (em branco = manter)" style="'+s+' flex:1 1 130px; min-width:0;">'+
                '</div>'+
                '<input id="bkSmtpFrom" placeholder="remetente (From) — ex.: seu@email.com" style="'+s+' width:100%; box-sizing:border-box; margin-top:8px;">'+
              '</div>')+
          '<div id="oltBkResult" style="font-size:12px; margin-top:4px;"></div>';
    _oltModalSimples('fa-database','Backup — salvar / restaurar', corpo, false);
    // carrega o agendamento salvo
    fetch('olt_huawei.php?acao=backup_ag_get').then(function(r){return r.json();}).then(function(d){ var a=(d&&d.cfg)||{};
        var g=function(id){return document.getElementById(id);};
        if(g('bkAgAtivo')) g('bkAgAtivo').checked=!!a.ativo; if(g('bkAgHora')&&a.hora) g('bkAgHora').value=a.hora; if(g('bkAgEmail')) g('bkAgEmail').value=a.email||'';
        if(g('bkSmtpHost')) g('bkSmtpHost').value=a.smtp_host||''; if(g('bkSmtpPort')) g('bkSmtpPort').value=a.smtp_port||''; if(g('bkSmtpSeg')&&a.smtp_seg) g('bkSmtpSeg').value=a.smtp_seg;
        if(g('bkSmtpUser')) g('bkSmtpUser').value=a.smtp_user||''; if(g('bkSmtpFrom')) g('bkSmtpFrom').value=a.smtp_from||'';
        if(a.tem_smtp_pass && g('bkSmtpPass')) g('bkSmtpPass').placeholder='•••••• (senha salva — em branco = manter)';
    }).catch(function(){});
}
function _oltBkAgSalvar(cb){
    var r=document.getElementById('oltBkResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    var g=function(id){var e=document.getElementById(id);return e?e.value:'';};
    var body='ativo='+(document.getElementById('bkAgAtivo').checked?'1':'0')+'&hora='+encodeURIComponent(g('bkAgHora'))+'&email='+encodeURIComponent(g('bkAgEmail'))
        +'&smtp_host='+encodeURIComponent(g('bkSmtpHost'))+'&smtp_port='+encodeURIComponent(g('bkSmtpPort'))+'&smtp_seg='+encodeURIComponent(g('bkSmtpSeg'))
        +'&smtp_user='+encodeURIComponent(g('bkSmtpUser'))+'&smtp_pass='+encodeURIComponent(g('bkSmtpPass'))+'&smtp_from='+encodeURIComponent(g('bkSmtpFrom'));
    fetch('olt_huawei.php?acao=backup_ag_set',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
      .then(function(rr){return rr.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(r) r.innerHTML=(d&&d.saved)?'<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Agendamento salvo.</span>':'<span style="color:'+OLTC.red+';">Não gravou.</span>';
        if(typeof cb==='function' && d && d.saved) cb();
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
function _oltBkAgTestar(){
    var r=document.getElementById('oltBkResult');
    var email=(document.getElementById('bkAgEmail')||{}).value||'';
    if(!email){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Informe o e-mail de destino primeiro.</span>'; return; }
    // Salva antes (persiste o SMTP) e só então dispara o teste.
    _oltBkAgSalvar(function(){ _oltBkAgTestEnviar(email); });
}
function _oltBkAgTestEnviar(email){
    var r=document.getElementById('oltBkResult');
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Enviando teste para '+_oltEsc(email)+'…';
    fetch('olt_huawei.php?acao=backup_ag_testar',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'email='+encodeURIComponent(email)})
      .then(function(rr){return rr.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d&&d.enviado){ if(r) r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> E-mail aceito pelo servidor. Confira a caixa de entrada (e o spam).</span>'; }
        else { if(r) r.innerHTML='<span style="color:'+OLTC.red+';"><i class="fa-solid fa-triangle-exclamation"></i> Não enviou: '+_oltEsc((d&&d.motivo)||'motivo desconhecido')+'</span>'; }
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro de comunicação.</span>'; });
}
function oltBackupBaixar(btn){
    var r=document.getElementById('oltBkResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Gerando…';
    fetch('olt_huawei.php?acao=backup_export').then(function(rr){return rr.text();}).then(function(txt){
        try{ JSON.parse(txt); }catch(e){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Falha ao gerar backup.</span>'; return; }
        var d=new Date(); var pad=function(n){return (n<10?'0':'')+n;};
        var nome='wellsystem-backup-'+d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+'-'+pad(d.getHours())+pad(d.getMinutes())+'.json';
        var blob=new Blob([txt],{type:'application/json'}); var url=URL.createObjectURL(blob);
        var a=document.createElement('a'); a.href=url; a.download=nome; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){URL.revokeObjectURL(url);},1500);
        if(r) r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Backup baixado: '+_oltEsc(nome)+'</span>';
    }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao baixar.</span>'; });
}
function oltBackupRestaurar(input){
    var r=document.getElementById('oltBkResult'); var f=input&&input.files&&input.files[0]; if(!f){ return; }
    if(!confirm('Restaurar este backup vai SUBSTITUIR as configurações atuais (nomes, apelidos, notificações, relatório…). Deseja continuar?')){ input.value=''; return; }
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Restaurando…';
    var fr=new FileReader();
    fr.onload=function(){ var dados=fr.result;
        try{ var j=JSON.parse(dados); if(!j||!j._wellsystem_backup) throw 0; }catch(e){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Arquivo inválido (não é um backup do Wellsystem).</span>'; input.value=''; return; }
        fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=backup_import&dados='+encodeURIComponent(dados)})
          .then(function(rr){return rr.json();}).then(function(d){ input.value='';
            if(d&&(d.status==='ok'||d.status==='parcial')){ var n=(d.restaurados||[]).length; r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Restaurado ('+n+' arquivo(s)).'+((d.falhou&&d.falhou.length)?' Falhou: '+_oltEsc(d.falhou.join(', ')):'')+'</span><br><span style="color:'+OLTC.mut+'; font-size:11px;">Recarregue/atualize o Resumo para ver os dados.</span>';
                alert('✅ Backup restaurado com sucesso!\n\n'+n+' arquivo(s) importado(s).'+((d.falhou&&d.falhou.length)?('\n⚠️ Falhou: '+d.falhou.join(', ')):'')+'\n\nRecarregue a página (F5) para ver os dados restaurados.'); }
            else { r.innerHTML='<span style="color:'+OLTC.red+';">'+_oltEsc((d&&d.msg)||'Falha ao restaurar.')+'</span>'; alert('❌ Falha ao restaurar o backup.\n\n'+((d&&d.msg)||'Arquivo inválido ou sem permissão.')); }
          }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao restaurar.</span>'; input.value=''; });
    };
    fr.readAsText(f);
}
// ============================ CONEXÃO DA OLT ============================
// ============ LOGOMARCA DO GERENCIADOR OLT (independente da página principal) ============
// Grava em cache_trafego/wellsystem_logo_olt.txt — arquivo SEPARADO do logo da principal.
function oltLogoOlt(){
    if(!_oltExigeNivel(2,'Alterar a logomarca')) return;
    _oltFecharConfigs('oltLogoOv');
    var ov=document.createElement('div'); ov.id='oltLogoOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483200; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.55);';
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; width:min(96vw,460px); display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+
        '<div style="flex:0 0 auto; padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-image" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff; font-size:13.5px;">Logomarca do Gerenciador OLT</div><button onclick="document.getElementById(\'oltLogoOv\').remove()" style="cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div style="flex:1 1 auto; padding:16px; text-align:center;">'+
          '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:12px; line-height:1.5; text-align:left;">Esta logo é <b>exclusiva desta página</b> — não depende da página principal. Aparece na tarja do topo do Gerenciador OLT. PNG, JPEG, SVG ou WEBP (até ~650 KB).</div>'+
          '<div id="oltLogoPrev" style="min-height:70px; display:flex; align-items:center; justify-content:center; border:1px dashed '+OLTC.line+'; border-radius:10px; padding:8px; margin-bottom:14px; background:'+OLTC.bg2+';"><span style="font-size:11.5px; color:'+OLTC.mut+';">sem logo</span></div>'+
          '<input type="file" id="oltLogoFile" accept="image/png,image/jpeg,image/svg+xml,image/webp,.png,.jpg,.jpeg,.svg,.webp" style="display:none;" onchange="_oltLogoEnviar(this)">'+
          '<div style="display:flex; gap:8px; justify-content:center; flex-wrap:wrap;">'+
            '<button onclick="document.getElementById(\'oltLogoFile\').click()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800;"><i class="fa-solid fa-upload"></i> Escolher logo</button>'+
            '<button onclick="_oltLogoRemover()" style="cursor:pointer; padding:9px 14px; border-radius:8px; border:1px solid '+OLTC.red+'; background:transparent; color:'+OLTC.red+'; font-weight:800;"><i class="fa-solid fa-trash"></i> Remover</button>'+
          '</div>'+
          '<div id="oltLogoResult" style="font-size:11.5px; margin-top:12px;"></div>'+
        '</div>'+
    '</div>';
    document.body.appendChild(ov);
    fetch('olt_huawei.php?acao=logo_get', {cache:'no-store'}).then(function(r){return r.json();})
      .then(function(d){ _oltLogoMostrar((d&&d.logo)||''); }).catch(function(){});
}
function _oltLogoMostrar(src){ var p=document.getElementById('oltLogoPrev'); if(!p) return;
    p.innerHTML = src ? '<img src="'+src+'" alt="Logo" style="max-height:56px; max-width:180px; object-fit:contain;">'
                      : '<span style="font-size:11.5px; color:'+OLTC.mut+';">sem logo</span>'; }
function _oltLogoEnviar(input){
    var f=input&&input.files&&input.files[0]; var r=document.getElementById('oltLogoResult'); if(!f) return;
    if(!/image\/(png|jpe?g|svg\+xml|webp)/i.test(f.type)){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Use PNG, JPEG, SVG ou WEBP.</span>'; input.value=''; return; }
    if(f.size>650000){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Imagem muito grande (máx. ~650 KB).</span>'; input.value=''; return; }
    var fr=new FileReader();
    fr.onload=function(){ _oltLogoMostrar(fr.result);
        if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Enviando…';
        fetch('olt_huawei.php?acao=logo_set', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'alvo=olt&img='+encodeURIComponent(fr.result)})
          .then(function(rr){return rr.json();}).then(function(d){
            if(d&&d.saved){ window.WS_LOGO_OLT=d.logo||''; if(r) r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Logo salva. Recarregando…</span>'; setTimeout(function(){ location.reload(); },1100); }
            else { if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Não gravou (formato/tamanho ou permissão da pasta).</span>'; }
          }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao enviar.</span>'; });
        input.value='';
    };
    fr.readAsDataURL(f);
}
function _oltLogoRemover(){ var r=document.getElementById('oltLogoResult');
    if(!confirm('Remover a logomarca do Gerenciador OLT?')) return;
    fetch('olt_huawei.php?acao=logo_del', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'alvo=olt'})
      .then(function(rr){return rr.json();}).then(function(){ _oltLogoMostrar('');
        if(r) r.innerHTML='<span style="color:'+OLTC.grn+';">Removida. Recarregando…</span>'; setTimeout(function(){ location.reload(); },1000);
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao remover.</span>'; });
}
// Sair: definido pela página (olt.php). No modo integrado não existe login, então
// esta versão de reserva evita erro caso o botão seja acionado.
if (typeof window.wsSair !== 'function') {
    window.wsSair = function () {
        if (!confirm('Encerrar a sessão?')) return;
        fetch('olt_huawei.php?acao=auth_logout', {method: 'POST'})
          .then(function () { location.reload(); })
          .catch(function () { location.reload(); });
    };
}
// Barra do usuário no cabeçalho do Gerenciador: nome, nível e, para o Root,
// um botão "Administração" com as opções que antes só existiam na tela inicial.
// Assim as opções continuam à mão mesmo com o gerenciador aberto em tela cheia.
/* VÁRIAS OLTs (20/11/2026): seletor no cabeçalho do Gerenciador. Cada OLT cadastrada tem a sua conexão, ONUs e histórico; a
   principal é a de sempre. A escolha vale por navegador (cookie WSOLT) e a tela recarrega com a OLT escolhida. Só aparece se houver
   mais de uma OLT, ou para o Root (que vê o "+" para cadastrar outra). */
function oltTrocar(id){ document.cookie='WSOLT='+encodeURIComponent(id||'')+'; path=/; max-age=31536000; SameSite=Lax'; location.reload(); }
function oltSeletorCarregar(){
    var box=document.getElementById('oltSelBox'); if(!box) return;
    fetch('olt_huawei.php?acao=olts_lista').then(function(r){ return r.json(); }).then(function(d){
        if(!d||d.status!=='ok'||!d.olts) return;
        var root=(_oltNivel()>=3);
        if(d.olts.length<2 && !root) return;
        var h='';
        if(d.olts.length>1){
            h+='<select title="OLT em uso" onchange="oltTrocar(this.value)" style="height:24px; border-radius:7px; border:1px solid rgba(255,255,255,0.9); background:rgba(255,255,255,0.14); color:#fff; font-weight:700; font-size:11.5px; padding:0 6px; max-width:200px;">';
            d.olts.forEach(function(o){ h+='<option style="color:#111" value="'+_oltEsc(o.id)+'"'+(o.id===d.atual?' selected':'')+'>'+_oltEsc(o.nome)+'</option>'; });
            h+='</select>';
        }
        if(d.olts.length===1 && d.olts[0].nome) h+='<span title="OLT em uso" style="color:#fff; font-weight:700; font-size:12px; padding:0 4px; max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">'+_oltEsc(d.olts[0].nome)+'</span>';   /* com uma só OLT não há seletor: mostra o nome (ex.: Nazaré da Mata-PE) */
        if(root){ var _cur=''; d.olts.forEach(function(o){ if(o.id===d.atual) _cur=o.nome; }); window._oltAtualNome=_cur; window._oltAtualId=d.atual||'';
            h+='<button onclick="oltRenomear()" title="Renomear esta OLT (ex.: nome da cidade)" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); width:26px; height:24px; font-size:12px; padding:0; line-height:1;"><i class="fa-solid fa-pen"></i></button>'
            + (window._oltAtualId!=='' ? '<button onclick="oltExcluirOlt()" title="Excluir esta OLT da lista (cadastrada errada)" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); width:26px; height:24px; font-size:12px; padding:0; line-height:1;"><i class="fa-solid fa-trash"></i></button>' : ''); }
        if(root) h+='<button onclick="oltNovaOlt()" title="Cadastrar outra OLT" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); font-weight:800; width:26px; height:24px; font-size:15px; padding:0; line-height:1;">+</button>';
        box.innerHTML=h; box.style.display='inline-flex';
    }).catch(function(){});
}
function oltExcluirOlt(){
    var id=window._oltAtualId||''; if(id==='') return;
    if(!confirm('Excluir a OLT "'+(window._oltAtualNome||id)+'" da lista?'+String.fromCharCode(10,10)+'Os dados dela ficam guardados no servidor; nenhum cliente é alterado.')) return;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=olt_del&id='+encodeURIComponent(id)})
      .then(function(r){ return r.json(); }).then(function(d){ if(d&&d.status==='ok'){ document.cookie='WSOLT=; path=/; max-age=0'; location.reload(); } else alert((d&&d.message)||'Não foi possível excluir.'); })
      .catch(function(){ alert('Sem resposta do servidor.'); });
}
function oltRenomear(){
    var nome=prompt('Novo nome desta OLT (ex.: Nazaré da Mata-PE):', window._oltAtualNome||''); if(!nome||!nome.trim()) return;
    var id=window._oltAtualId||'';
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=olt_ren&nome='+encodeURIComponent(nome.trim())+'&id='+encodeURIComponent(id)+(id===''?'&principal=1':'')})
      .then(function(r){ return r.json(); }).then(function(d){ if(d&&d.status==='ok') location.reload(); else alert((d&&d.message)||'Não foi possível renomear.'); })
      .catch(function(){ alert('Sem resposta do servidor.'); });
}
function oltNovaOlt(){
    var nome=prompt('Nome da nova OLT (ex.: cidade ou localidade):'); if(!nome||!nome.trim()) return;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=olt_add&nome='+encodeURIComponent(nome.trim())})
      .then(function(r){ return r.json(); }).then(function(d){
        if(d&&d.status==='ok'){ document.cookie='WSOLT='+encodeURIComponent(d.id)+'; path=/; max-age=31536000; SameSite=Lax'; location.reload(); }
        else alert((d&&d.message)||'Não foi possível cadastrar a OLT.');
      }).catch(function(){ alert('Sem resposta do servidor.'); });
}
function _oltBarraUsuario(){
    var u=window.WS_USUARIO; if(!u || !u.login) return '';   // sem login ativo: não mostra nada
    var rot={1:'Leitura',2:'Operação',3:'Root'};
    var adm = (_oltNivel()>=3)
      ? '<button onclick="oltNotificacoes()" title="Avisos da OLT (WhatsApp/Telegram): ativar, destinatários, testar" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); width:auto; padding:0 10px; gap:6px;"><i class="fa-solid fa-bell"></i> <span class="oltBtnLbl" style="font-size:11.5px; font-weight:700;">Avisos</span></button>'
        + '<button onclick="oltAdmMenu(event)" title="Administração do sistema (conexão, usuários, backup, notificações)" style="'+_oltCtrl('#ffffff')+' border-color:rgba(255,255,255,0.9); width:auto; padding:0 12px; gap:7px;"><i class="fa-solid fa-gears"></i> <span class="oltBtnLbl" style="font-size:11.5px; font-weight:700;">Administração</span></button>'
      : '';
    // Nome curto: "Administrador" vira "Admin"; nomes longos são reduzidos ao
    // primeiro nome + inicial, para a barra do topo não estourar.
    var nm=String(u.nome||u.login);
    if(/^administrador$/i.test(nm)) nm='Admin';
    else if(nm.length>18){ var p=nm.split(/\s+/); nm=p[0]+(p[1]?(' '+p[1].charAt(0)+'.'):''); }
    // Usuário e nível AGRUPADOS numa única pastilha — menos peças soltas no topo.
    return '<div class="oltUserBar" style="flex:0 0 auto; display:flex; align-items:center; gap:7px; margin-right:4px;">'+
        '<span title="'+_oltEsc(u.nome||u.login)+' · nível '+(rot[u.nivel]||u.nivel)+'" style="display:inline-flex; align-items:center; gap:7px; padding:4px 10px 4px 8px; border-radius:20px; background:rgba(255,255,255,.14); color:#fff; font-size:11.5px; white-space:nowrap;">'+
          '<i class="fa-solid fa-circle-user" style="opacity:.9; font-size:12px;"></i><b>'+_oltEsc(nm)+'</b>'+
          '<span style="background:rgba(255,255,255,.22); padding:1px 8px; border-radius:20px; font-size:8px; font-weight:800; letter-spacing:.04em;">'+(rot[u.nivel]||u.nivel)+'</span>'+
        '</span>'+ adm +
        // O botão Sair foi UNIFICADO com o X do canto (vermelho), para não repetir.
    '</div>';
}
// Menu suspenso de Administração (só Root) — reúne o que havia na tela inicial.
function oltAdmMenu(e){
    if(e) e.stopPropagation();
    var old=document.getElementById('oltAdmDrop'); if(old){ old.remove(); return; }
    var d=document.createElement('div'); d.id='oltAdmDrop';
    d.style.cssText='position:fixed; top:56px; right:14px; z-index:2147483250; min-width:250px; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; box-shadow:0 18px 44px rgba(0,0,0,.32); overflow:hidden; padding:6px 0 8px;';
    d.innerHTML=
        _oltMenuSep('Administração')+
        _oltMenuItem('fa-network-wired','Conexão da OLT','oltConexao()')+
        _oltMenuItem('fa-users','Usuários e acessos','oltUsuarios()')+
        _oltMenuItem('fa-clock-rotate-left','Acessos e tempo de conexão','oltSessoes()')+
        _oltMenuItem('fa-image','Logomarca da OLT','oltLogoOlt()')+
        _oltMenuItem('fa-database','Backup (salvar/restaurar)','oltBackup()')+
        _oltMenuItem('fa-bell','Notificações','oltNotificacoes()');
    document.body.appendChild(d);
    setTimeout(function(){ document.addEventListener('click', _oltAdmFechar); },0);
}
function _oltAdmFechar(){ var d=document.getElementById('oltAdmDrop'); if(d) d.remove(); document.removeEventListener('click', _oltAdmFechar); }
// Nível do usuário logado. Sem login ativo (instalação sem olt_auth.php) = 3.
function _oltNivel(){ var n=window.WS_NIVEL; return (n===undefined||n===null) ? 3 : (parseInt(n,10)||0); }
// Barra a abertura de janelas restritas. É apenas a 1ª camada: o servidor
// (olt_auth.php) revalida o nível em cada endpoint e devolve 403 se não bater.
function _oltExigeNivel(min, oque){
    // Instalação virgem: liberar a configuração da conexão é obrigatório, senão o
    // sistema se tranca (o 1º login usa a senha da OLT). O servidor continua
    // permitindo SÓ os endpoints de conexão nessa janela.
    if(window.WS_PRIMEIRO === true) return true;
    if(_oltNivel() >= min) return true;
    var rot={1:'Leitura',2:'Operação',3:'Root'};
    alert('Acesso restrito.\n\n'+(oque||'Esta função')+' exige o nível '+(rot[min]||min)+'.\n'+
          'Seu nível atual: '+(rot[_oltNivel()]||_oltNivel())+'.');
    return false;
}
// Fecha TODAS as janelas de configuração antes de abrir outra — evita empilhamento
// (uma por cima da outra) e a sensação de tela travada.
// Depois de salvar a conexão: fecha a janela e segue o fluxo natural —
//  • na tela de LOGIN (1º acesso) recarrega, para o login já aceitar a nova senha;
//  • já logado, abre o Gerenciador e dispara a varredura.
// Desconecta a OLT: apaga credenciais e cache, voltando ao estado de instalação
// nova. Não mexe em usuários, relatório, apelidos nem perfis.
function oltDesconectar(){
    if(!_oltExigeNivel(3,'Desconectar a OLT')) return;
    if(!confirm('Desconectar a OLT?\n\nSerão apagados: IP, usuário, senha e o cache de ONUs.\n' +
                'Usuários do sistema, relatório e apelidos são preservados.\n\n' +
                'Você poderá configurar outra OLT em seguida.')) return;
    var r=document.getElementById('cxResult');
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Desconectando…';
    oltFetch('olt_huawei.php?acao=conexao_desconectar', {method:'POST'}, true)
      .then(function(rr){return rr.json();}).then(function(d){
        if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
        if(d && d.desconectado){
            window._oltLista=[]; window._oltNaoConfigurado=true; window._oltSlotRes={};
            _oltStatusConexao(false,'OLT não configurada');
            if(r) r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Desconectada. Recarregando…</span>';
            setTimeout(function(){ location.reload(); }, 900);
        } else if(r){ r.innerHTML='<span style="color:'+OLTC.red+';">Não foi possível desconectar.</span>'; }
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao desconectar.</span>'; });
}
// Testa a conexão e mostra o resultado PASSO A PASSO (rede -> telnet -> login),
// para saber exatamente onde para quando a lista não carrega.
function oltConexaoTestar(){
    var r=document.getElementById('cxResult');
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Testando conexão com a OLT…';
    oltFetch('olt_huawei.php?acao=conexao_teste', null, true).then(function(rr){return rr.json();}).then(function(d){
        if(!r) return;
        if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
        var linhas=((d&&d.passos)||[]).map(function(p){
            var c=p.ok?OLTC.grn:OLTC.red, ic=p.ok?'fa-circle-check':'fa-circle-xmark';
            return '<div style="display:flex; gap:8px; align-items:flex-start; padding:5px 0; border-bottom:1px solid '+OLTC.line+'33;">'+
                '<i class="fa-solid '+ic+'" style="color:'+c+'; margin-top:2px;"></i>'+
                '<div style="flex:1 1 auto; min-width:0;"><b style="color:'+OLTC.ink+'; font-size:11.5px;">'+_oltEsc(p.t)+'</b>'+
                '<div style="font-size:11px; color:'+OLTC.mut+'; line-height:1.5;">'+_oltEsc(p.msg)+'</div></div></div>';
        }).join('');
        var ok=!!(d&&d.conectado);
        _oltStatusConexao(ok);
        r.innerHTML='<div style="border:1px solid '+(ok?OLTC.grn:OLTC.red)+'; border-radius:9px; padding:10px 12px; background:'+OLTC.bg2+';">'+
            '<div style="font-weight:800; color:'+(ok?OLTC.grn:OLTC.red)+'; font-size:12.5px; margin-bottom:6px;">'+
            '<i class="fa-solid '+(ok?'fa-plug-circle-check':'fa-plug-circle-exclamation')+'"></i> '+
            (ok?'CONECTADO À OLT':'NÃO CONECTOU')+(d&&d.ms?(' <span style="color:'+OLTC.mut+'; font-weight:600;">· '+d.ms+'ms</span>'):'')+'</div>'+
            linhas+'</div>';
    }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao testar (o servidor não respondeu).</span>'; });
}
// Pastilha de STATUS no cabeçalho do Gerenciador: verde conectado / vermelho sem conexão.
function _oltStatusConexao(ok, txt){
    // Selo FIXO logo ABAIXO da linha do IP. Fica em elemento PRÓPRIO (irmão do
    // subtítulo), por isso não é apagado quando o subtítulo é reescrito com
    // uptime/temperatura. Verde = conectada · vermelho = desconectada.
    var el=document.getElementById('oltStatusCx');
    if(!el){
        var sub=document.getElementById('oltWinSub');
        if(!sub || !sub.parentNode) return;
        el=document.createElement('div'); el.id='oltStatusCx';
        sub.parentNode.appendChild(el);          // 3ª linha: título · IP · SELO
    }
    el.style.cssText='display:inline-flex; align-items:center; gap:6px; margin-top:2px;'+
        ' padding:2px 10px; border-radius:20px; font-size:10px; font-weight:800;'+
        ' letter-spacing:.05em; white-space:nowrap; color:#fff; text-shadow:none;'+
        ' background:'+(ok?'#15803d':'#b3261e')+'; box-shadow:0 1px 3px rgba(0,0,0,.4);';
    el.innerHTML='<i class="fa-solid fa-circle" style="font-size:6px;"></i> '+
        (txt || (ok?'OLT CONECTADA':'OLT DESCONECTADA'));
    return;
    // Pastilha FIXA no topo, ao lado do título — sempre visível, verde quando
    // conectada e vermelha quando não. Fica no cabeçalho (não no subtítulo),
    // para não sumir quando o subtítulo é reescrito pelo status da OLT.
    var el=document.getElementById('oltStatusCx');
    if(!el){
        var alvo=document.getElementById('oltWinValida');
        if(alvo && alvo.parentNode){
            el=document.createElement('span'); el.id='oltStatusCx';
            alvo.parentNode.insertBefore(el, alvo);
        } else {
            var sub=document.getElementById('oltWinSub'); if(!sub) return;
            el=document.createElement('span'); el.id='oltStatusCx';
            sub.appendChild(document.createTextNode(' ')); sub.appendChild(el);
        }
    }
    // Fundo sólido + texto branco: legível sobre qualquer cor de cabeçalho.
    el.style.cssText='display:inline-flex; align-items:center; gap:6px; padding:4px 11px; border-radius:20px;'+
        ' font-size:10.5px; font-weight:800; letter-spacing:.04em; white-space:nowrap; flex:0 0 auto;'+
        ' margin-right:8px; color:#fff; background:'+(ok?'#15803d':'#b3261e')+';'+
        ' box-shadow:0 1px 3px rgba(0,0,0,.4); text-shadow:none;';
    el.innerHTML='<i class="fa-solid fa-circle" style="font-size:7px;"></i> '+(txt || (ok?'OLT CONECTADA':'OLT DESCONECTADA'));
}
// Verifica o status em segundo plano e atualiza a pastilha (sem travar a tela).
function oltVerificarConexao(){
    oltFetch('olt_huawei.php?acao=conexao_teste', null, true).then(function(r){return r.json();}).then(function(d){
        _oltStatusConexao(!!(d&&d.conectado), (d&&d.conectado)?'OLT conectada':((d&&d.etapa==='rede')?'OLT inacessível':'Falha de login na OLT'));
    }).catch(function(){ _oltStatusConexao(false,'Servidor não respondeu'); });
}
function _oltAposConexaoSalva(){
    var ov=document.getElementById('oltCxOv'); if(ov) ov.remove();
    if(document.getElementById('lgFundo')){ location.reload(); return; }   // tela de login aberta
    if(typeof abrirOltHuawei==='function'){
        window._oltNaoConfigurado=false;
        if(!document.getElementById('oltWin') || !oltGerenciadorAberto()) abrirOltHuawei();
        else if(typeof oltRescan==='function') oltRescan();
    }
}
function _oltFecharConfigs(exceto){
    ['oltAddOv','oltBkOv','oltCxOv','oltFtOv','oltImgOv','oltLogoOv','oltUsrOv'].forEach(function(id){
        if(id===exceto) return;
        var e=document.getElementById(id); if(e) e.remove();
    });
}
// ==================== USUÁRIOS E NÍVEIS DE ACESSO (somente Root) ====================
// Os níveis são validados NO SERVIDOR (olt_auth.php). Esta tela é só o cadastro.
var OLT_NIVEIS = {1:'1 — Leitura (não altera nada)', 2:'2 — Operação (libera/bloqueia ONU)', 3:'3 — Root (acesso total)'};
// ---------- RELATÓRIO DE ACESSOS: quem está online + tempo de conexão ----------
function _oltDur(seg){
    seg=Math.max(0, parseInt(seg,10)||0);
    var d=Math.floor(seg/86400), h=Math.floor((seg%86400)/3600), m=Math.floor((seg%3600)/60), s=seg%60;
    if(d) return d+'d '+h+'h '+m+'min';
    if(h) return h+'h '+m+'min';
    if(m) return m+'min '+s+'s';
    return s+'s';
}
function _oltHora(ts){ if(!ts) return '—'; var d=new Date(ts*1000); var p=function(n){return (n<10?'0':'')+n;};
    return p(d.getDate())+'/'+p(d.getMonth()+1)+' '+p(d.getHours())+':'+p(d.getMinutes()); }
// Maximizar / restaurar e minimizar a janela de acessos.
function _oltSesMax(){
    var b=document.getElementById('oltSesBox'); if(!b) return;
    if(b.getAttribute('data-max')==='1'){
        b.style.width='min(96vw,760px)'; b.style.height=''; b.style.maxHeight='90vh'; b.style.borderRadius='12px';
        b.setAttribute('data-max','0');
    } else {
        b.style.width='98vw'; b.style.height='96vh'; b.style.maxHeight='96vh'; b.style.borderRadius='10px';
        b.setAttribute('data-max','1');
    }
}
function _oltSesMin(){
    var b=document.getElementById('oltSesBox'), c=document.getElementById('oltSesBody'); if(!b||!c) return;
    if(c.style.display==='none'){ c.style.display=''; b.style.height=b.getAttribute('data-h')||''; }
    else { b.setAttribute('data-h', b.style.height||''); c.style.display='none'; b.style.height='auto'; b.style.maxHeight='none'; }
}
function oltSessoes(){
    if(!_oltExigeNivel(3,'Ver o relatório de acessos')) return;
    _oltFecharConfigs('oltSesOv');
    var ov=document.createElement('div'); ov.id='oltSesOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483200; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.55);';
    var _c='cursor:pointer; width:29px; height:27px; border-radius:6px; border:1px solid rgba(255,255,255,0.6); background:transparent; color:#fff; font-size:13px; display:inline-flex; align-items:center; justify-content:center;';
    ov.innerHTML='<div id="oltSesBox" style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; width:min(96vw,760px); max-height:90vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+
        '<div style="flex:0 0 auto; padding:13px 15px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:8px;"><i class="fa-solid fa-clock-rotate-left" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff; font-size:13.5px;">Acessos e tempo de conexão</div>'+
          '<button onclick="oltSessoes()" title="Atualizar" style="'+_c+'"><i class="fa-solid fa-rotate"></i></button>'+
          '<button onclick="_oltSesMin()" title="Minimizar" style="'+_c+'"><i class="fa-solid fa-minus"></i></button>'+
          '<button onclick="_oltSesMax()" title="Maximizar / Restaurar" style="'+_c+'"><i class="fa-solid fa-expand"></i></button>'+
          '<button onclick="document.getElementById(\'oltSesOv\').remove()" title="Fechar" style="'+_c+' background:rgba(225,29,72,0.85);"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div id="oltSesBody" style="flex:1 1 auto; overflow:auto; padding:16px;"><i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+';"></i> Carregando…</div>'+
    '</div>';
    document.body.appendChild(ov);
    fetch('olt_huawei.php?acao=sessoes_get').then(function(r){return r.json();}).then(function(d){
        var b=document.getElementById('oltSesBody'); if(!b) return;
        if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
        var rot={1:'Leitura',2:'Operação',3:'Root'}, cor={1:OLTC.mut,2:OLTC.amb,3:OLTC.red};
        var sec=function(t,ic){ return '<div style="font-weight:800; color:'+OLTC.acc+'; font-size:11px; text-transform:uppercase; letter-spacing:.07em; margin:14px 0 7px;"><i class="fa-solid '+ic+'"></i> '+t+'</div>'; };
        var linha=function(r,online){
            return '<div style="display:flex; align-items:center; gap:10px; padding:8px 10px; border-bottom:1px solid '+OLTC.line+'44; font-size:12.5px;">'+
                '<span style="flex:0 0 auto; width:9px; height:9px; border-radius:50%; background:'+(online?'#22c55e':OLTC.mut)+'; box-shadow:'+(online?'0 0 6px #22c55e88':'none')+';"></span>'+
                '<span style="flex:1 1 auto; min-width:0;"><b style="color:'+OLTC.ink+';">'+_oltEsc(r.nome||r.login)+'</b> '+
                  '<span style="color:'+OLTC.mut+'; font-family:monospace; font-size:11px;">('+_oltEsc(r.login)+')</span>'+
                  (r.ip?'<span style="color:'+OLTC.mut+'; font-size:10.5px;"> · '+_oltEsc(r.ip)+'</span>':'')+'</span>'+
                '<span style="flex:0 0 auto; background:'+(cor[r.nivel]||OLTC.mut)+'22; color:'+(cor[r.nivel]||OLTC.mut)+'; font-weight:800; font-size:10px; padding:2px 8px; border-radius:20px;">'+(rot[r.nivel]||r.nivel)+'</span>'+
                '<span style="flex:0 0 132px; text-align:right; color:'+OLTC.mut+'; font-size:11px;">'+_oltHora(r.inicio)+(r.fim?(' → '+_oltHora(r.fim)):'')+'</span>'+
                '<span style="flex:0 0 96px; text-align:right; font-weight:800; color:'+(online?'#22c55e':OLTC.txt)+'; font-size:11.5px;">'+_oltDur(r.duracao)+'</span>'+
            '</div>';
        };
        var at=(d&&d.ativas)||[], hi=(d&&d.historico)||[], to=(d&&d.totais)||[];
        var html='';
        html+=sec('Conectados agora ('+at.length+')','fa-circle-user');
        html+= at.length ? at.map(function(r){ return linha(r,true); }).join('')
                         : '<div style="color:'+OLTC.mut+'; font-size:12px; padding:8px 10px;">Ninguém conectado no momento.</div>';
        html+=sec('Tempo acumulado por usuário','fa-hourglass-half');
        html+= to.length ? to.map(function(t){
                 return '<div style="display:flex; align-items:center; gap:10px; padding:7px 10px; border-bottom:1px solid '+OLTC.line+'44; font-size:12.5px;">'+
                   '<i class="fa-solid fa-user" style="color:'+OLTC.mut+'; width:14px;"></i>'+
                   '<span style="flex:1 1 auto;"><b style="color:'+OLTC.ink+';">'+_oltEsc(t.nome||t.login)+'</b></span>'+
                   '<span style="flex:0 0 auto; color:'+OLTC.mut+'; font-size:11px;">'+t.acessos+' acesso'+(t.acessos>1?'s':'')+'</span>'+
                   '<span style="flex:0 0 110px; text-align:right; font-weight:800; color:'+OLTC.acc+';">'+_oltDur(t.total)+'</span></div>';
               }).join('') : '<div style="color:'+OLTC.mut+'; font-size:12px; padding:8px 10px;">Sem registros.</div>';
        html+=sec('Histórico de acessos','fa-list');
        html+= hi.length ? hi.map(function(r){ return linha(r,false); }).join('')
                         : '<div style="color:'+OLTC.mut+'; font-size:12px; padding:8px 10px;">Sem histórico.</div>';
        b.innerHTML=html;
    }).catch(function(){ var b=document.getElementById('oltSesBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha ao carregar o relatório.</div>'; });
}
function oltUsuarios(){
    if(!_oltExigeNivel(3,'Gerenciar usuários')) return;
    _oltFecharConfigs('');
    var s=_oltInSt();
    var corpo=
          '<div style="font-size:11.5px; color:'+OLTC.mut+'; line-height:1.6; margin-bottom:14px;">'+
            '<b>Nível 1 — Leitura:</b> consulta tudo, não altera nada.<br>'+
            '<b>Nível 2 — Operação:</b> autoriza, bloqueia, desbloqueia, reinicia ONU e troca modo (Bridge/Router). Não edita apelidos, zonas, VLANs, perfis, notificações nem conexão.<br>'+
            '<b>Nível 3 — Root:</b> acesso total, inclusive usuários e backup.</div>'+
          '<div style="font-weight:800; color:'+OLTC.acc+'; font-size:11.5px; text-transform:uppercase; letter-spacing:.06em; margin-bottom:8px;"><i class="fa-solid fa-user-plus"></i> Novo usuário / alterar senha</div>'+
          '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px;">'+
            '<input id="usrLogin" placeholder="login (ex.: joao)" style="'+s+' flex:1 1 130px; min-width:0;">'+
            '<input id="usrNome" placeholder="nome completo" style="'+s+' flex:1 1 150px; min-width:0;">'+
          '</div>'+
          '<div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px;">'+
            '<input id="usrSenha" type="password" placeholder="senha (mín. 4)" style="'+s+' flex:1 1 130px; min-width:0;">'+
            '<select id="usrNivel" style="'+s+' flex:1 1 190px;"><option value="1">'+OLT_NIVEIS[1]+'</option><option value="2">'+OLT_NIVEIS[2]+'</option><option value="3">'+OLT_NIVEIS[3]+'</option></select>'+
            '<button onclick="_oltUsrSalvar()" style="cursor:pointer; flex:0 0 auto; padding:9px 16px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>'+
          '</div>'+
          '<div id="usrResult" style="font-size:12px; margin-bottom:14px;"></div>'+
          '<div style="font-weight:800; color:'+OLTC.acc+'; font-size:11.5px; text-transform:uppercase; letter-spacing:.06em; margin-bottom:6px;"><i class="fa-solid fa-list"></i> Cadastrados</div>'+
          '<div id="usrLista"><i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+';"></i></div>';
    _oltModalSimples('fa-users','Usuários e níveis de acesso', corpo, false);
    _oltUsrCarregar();
}
function _oltUsrCarregar(){
    fetch('olt_huawei.php?acao=usuarios_get').then(function(r){return r.json();}).then(function(d){
        var l=document.getElementById('usrLista'); if(!l) return;
        if(!d||!d.usuarios||!d.usuarios.length){ l.innerHTML='<div style="color:'+OLTC.mut+'; font-size:12px;">Nenhum usuário.</div>'; return; }
        var cor={1:OLTC.mut,2:OLTC.amb,3:OLTC.red};
        l.innerHTML=d.usuarios.map(function(u){
            return '<div style="display:flex; align-items:center; gap:10px; padding:8px 10px; border-bottom:1px solid '+OLTC.line+'44; font-size:12.5px;">'+
                '<i class="fa-solid fa-user" style="color:'+OLTC.mut+'; width:14px;"></i>'+
                '<span style="flex:1 1 auto; min-width:0;"><b>'+_oltEsc(u.nome)+'</b> <span style="color:'+OLTC.mut+'; font-family:monospace; font-size:11px;">('+_oltEsc(u.login)+')</span></span>'+
                '<span style="flex:0 0 auto; background:'+(cor[u.nivel]||OLTC.mut)+'; color:#fff; font-weight:800; font-size:10.5px; padding:2px 10px; border-radius:20px; text-shadow:0 1px 1px rgba(0,0,0,.35);">Nível '+u.nivel+'</span>'+
                (u.login==='root' ? '<span style="flex:0 0 32px;"></span>'
                 : '<button onclick="_oltUsrRemover(\''+_oltEsc(u.login)+'\')" title="Remover" style="cursor:pointer; flex:0 0 auto; width:30px; height:30px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.red+';"><i class="fa-solid fa-trash"></i></button>')+
            '</div>';
        }).join('');
    }).catch(function(){});
}
function _oltUsrSalvar(){
    var r=document.getElementById('usrResult');
    var g=function(id){ var e=document.getElementById(id); return e?e.value:''; };
    var login=g('usrLogin').trim();
    if(!login){ r.innerHTML='<span style="color:'+OLTC.red+';">Informe o login.</span>'; return; }
    r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    fetch('olt_huawei.php?acao=usuarios_add',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'login='+encodeURIComponent(login)+'&nome='+encodeURIComponent(g('usrNome'))+'&senha='+encodeURIComponent(g('usrSenha'))+'&nivel='+encodeURIComponent(g('usrNivel'))})
      .then(function(rr){return rr.json();}).then(function(d){
        if(d&&d.saved){ r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Usuário salvo.</span>';
            document.getElementById('usrLogin').value=''; document.getElementById('usrNome').value=''; document.getElementById('usrSenha').value='';
            _oltUsrCarregar(); }
        else { r.innerHTML='<span style="color:'+OLTC.red+';">'+((d&&d.message)||'Não foi possível salvar.')+'</span>'; }
      }).catch(function(){ r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
function _oltUsrRemover(login){
    if(!confirm('Remover o usuário "'+login+'"?')) return;
    fetch('olt_huawei.php?acao=usuarios_del',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'login='+encodeURIComponent(login)})
      .then(function(r){return r.json();}).then(function(){ _oltUsrCarregar(); }).catch(function(){});
}
// Trata respostas 401/403 do backend: sessão caiu ou nível insuficiente.
function _oltAuthErro(d){
    if(d && d.nao_autenticado){
        try{ sessionStorage.removeItem('oltAberto'); }catch(e){}   // não reabrir sozinho e realimentar o loop
        // LOGIN NA PROPRIA PAGINA — nas DUAS telas (autonoma e unificada).
        // Antes, na pagina autonoma isto dava alert + location.reload(): o navegador descartava o
        // documento e o operador via a TELA BRANCA do recarregamento a cada resposta 401 — inclusive
        // ao clicar em "Atualizar busca". O login embutido resolve sem descartar a pagina, sem perder
        // o que ja estava carregado e sem risco de loop de reload.
        if(typeof _oltLoginModal==='function'){ _oltLoginModal(); }
        else {
            // Ultimo recurso (JS do login ausente): so entao recarrega, no maximo 1 vez a cada 8s.
            var now=Date.now(), last=0; try{ last=+sessionStorage.getItem('_oltAuthRl')||0; }catch(e){}
            if(now-last < 8000){ return true; }
            try{ sessionStorage.setItem('_oltAuthRl', String(now)); }catch(e){}
            location.reload();
        }
        return true;
    }
    if(d && d.sem_permissao){ alert(d.message || 'Seu nível de acesso não permite esta ação.'); return true; }
    return false;
}
// Login da OLT embutido (usado na página unificada). Autentica pelo mesmo endpoint
// do olt.php (auth_login → cria sessão WSOLTSESS). Ao entrar, abre o gerenciador.
function _oltLoginModal(){
    if(document.getElementById('oltLoginOv')) return;   // já aberto: não empilha
    var ov=document.createElement('div'); ov.id='oltLoginOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483600; display:flex; align-items:center; justify-content:center; background:rgba(9,13,22,0.78);';
    var s=(typeof _oltInSt==='function')?_oltInSt():'padding:10px 12px; border-radius:8px; border:1px solid #ccc; background:#fff; color:#111;';
    ov.innerHTML='<div style="width:min(94vw,360px); background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.6); overflow:hidden;">'+
      '<div style="padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); color:#fff; font-weight:800; display:flex; align-items:center; gap:9px;"><i class="fa-solid fa-diagram-project"></i> Gerenciador OLT — acesso</div>'+
      '<div style="padding:16px;">'+
        '<div style="font-size:12px; color:'+OLTC.mut+'; margin-bottom:12px;">Entre com seu usuário e senha do Gerenciador OLT.</div>'+
        '<input id="oltLgUser" placeholder="usuário" autocomplete="username" style="'+s+' width:100%; box-sizing:border-box; margin-bottom:10px;">'+
        '<input id="oltLgPass" type="password" placeholder="senha" autocomplete="current-password" onkeydown="if(event.key===\'Enter\')_oltLoginEnviar()" style="'+s+' width:100%; box-sizing:border-box;">'+
        '<button onclick="_oltLoginEnviar()" style="cursor:pointer; margin-top:12px; width:100%; padding:10px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-right-to-bracket"></i> Entrar</button>'+
        '<div id="oltLgMsg" style="font-size:12px; margin-top:10px; min-height:16px;"></div>'+
      '</div>'+
    '</div>';
    document.body.appendChild(ov);
    setTimeout(function(){ var i=document.getElementById('oltLgUser'); if(i) i.focus(); }, 80);
}
function _oltLoginEnviar(){
    var m=document.getElementById('oltLgMsg');
    var u=((document.getElementById('oltLgUser')||{}).value||'').trim(); var p=(document.getElementById('oltLgPass')||{}).value||'';
    if(!u||!p){ if(m) m.innerHTML='<span style="color:'+OLTC.red+';">Informe usuário e senha.</span>'; return; }
    if(m) m.innerHTML='<span style="color:'+OLTC.mut+';"><i class="fa-solid fa-spinner fa-spin"></i> Entrando…</span>';
    fetch('olt_huawei.php?acao=auth_login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'login='+encodeURIComponent(u)+'&senha='+encodeURIComponent(p)})
      .then(function(r){return r.json();}).then(function(d){
        if(d&&d.status==='ok'){
            try{ sessionStorage.removeItem('_oltAuthRl'); }catch(e){}
            var ov=document.getElementById('oltLoginOv'); if(ov) ov.remove();
            if(typeof abrirOltHuawei==='function') setTimeout(abrirOltHuawei, 120);
        } else { if(m) m.innerHTML='<span style="color:'+OLTC.red+';">'+_oltEsc((d&&d.message)||'Falha ao entrar.')+'</span>'; }
      }).catch(function(){ if(m) m.innerHTML='<span style="color:'+OLTC.red+';">Erro de comunicação com o servidor.</span>'; });
}
function oltConexao(){
    if(!_oltExigeNivel(3,'Configurar a conexão da OLT')) return;
    _oltFecharConfigs('oltCxOv');
    var s=_oltInSt();
    var ov=document.createElement('div'); ov.id='oltCxOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.5);';
    var fld=function(id,lbl,ph,extra){ return '<div style="margin-bottom:10px;"><div style="font-size:11.5px; font-weight:700; color:'+OLTC.txt+'; margin-bottom:4px;">'+lbl+'</div><input id="'+id+'" placeholder="'+ph+'" '+(extra||'')+' style="'+s+' width:100%; box-sizing:border-box;"></div>'; };
    ov.innerHTML='<div id="oltCxBox" style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; width:min(96vw,480px); max-height:88vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+
        '<div id="oltCxHead" style="flex:0 0 auto; padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:10px; cursor:move;"><i class="fa-solid fa-network-wired" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff;">Conexão da OLT</div><button onclick="document.getElementById(\'oltCxOv\').remove()" style="cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div style="flex:1 1 auto; overflow:auto; padding:14px 16px;">'+
          '<div style="font-size:11.5px; color:'+OLTC.mut+'; margin-bottom:12px;">Dados de acesso Telnet da OLT. Salvos em banco local — <b>o IP nunca precisa ser mexido no código</b>. Deixe a senha em branco para manter a atual.</div>'+
          '<div style="display:flex; gap:10px;"><div style="flex:2 1 auto;">'+fld('cxIp','IP / Host','ex.: 10.100.0.2')+'</div><div style="flex:1 1 90px;">'+fld('cxPorta','Porta','23','inputmode="numeric"')+'</div></div>'+
          fld('cxUser','Usuário','ex.: root')+
          fld('cxPass','Senha','•••••• (em branco = manter)','type="password" autocomplete="new-password"')+
          '<div style="width:120px;">'+fld('cxTimeout','Timeout (s)','8','inputmode="numeric"')+'</div>'+
          '<div style="margin-top:6px; padding-top:10px; border-top:1px solid '+OLTC.line+'; font-size:11.5px; font-weight:800; color:'+OLTC.mut+';"><i class="fa-solid fa-wifi" style="color:'+OLTC.acc+';"></i> SNMP (gráficos e sinal em tempo real)</div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin:2px 0 8px;">Comunidade SÓ-LEITURA e porta UDP do SNMP da OLT (os mesmos que o SmartOLT usa). Sem isso, os gráficos ficam vazios.</div>'+
          '<div style="display:flex; gap:10px;"><div style="flex:2 1 auto;">'+fld('cxSnmpComm','Comunidade SNMP (leitura)','ex.: public')+'</div><div style="flex:1 1 90px;">'+fld('cxSnmpPort','Porta SNMP','161','inputmode="numeric"')+'</div></div>'+
          fld('cxSnmpRw','Comunidade SNMP (escrita) — p/ ativar/desativar porta','opcional')+
          '<div id="cxResult" style="font-size:12px; margin-top:4px;"></div>'+
        '</div>'+
        '<div style="flex:0 0 auto; padding:12px 16px; border-top:1px solid '+OLTC.line+'; display:flex; gap:8px; justify-content:flex-end;">'+
          '<button id="cxBtnConectar" onclick="oltConectar()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.grn+'; background:transparent; color:'+OLTC.grn+'; font-weight:800;"><i class="fa-solid fa-plug"></i> Conectar</button>'+
          '<button onclick="oltConexaoTestar()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800;"><i class="fa-solid fa-plug-circle-check"></i> Testar conexão</button>'+
          '<button onclick="oltDesconectar()" title="Apaga IP, usuário, senha e o cache — volta ao estado de instalação nova" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.red+'; background:rgba(211,47,47,0.10); color:'+OLTC.red+'; font-weight:900; margin-right:auto;"><i class="fa-solid fa-plug-circle-xmark"></i> Desconectar</button>'+
          '<button onclick="oltConexaoSalvar()" style="cursor:pointer; padding:9px 18px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>'+
        '</div>'+
    '</div>';
    document.body.appendChild(ov);
    // Janela ARRASTÁVEL pela barra vermelha (o overlay centraliza; ao arrastar,
    // a caixa passa a ter posição própria e segue o mouse).
    (function(){
        var box=document.getElementById('oltCxBox'), hd=document.getElementById('oltCxHead');
        if(!box||!hd) return;
        hd.addEventListener('mousedown', function(e){
            if(e.target.closest('button')) return;
            e.preventDefault();
            var r=box.getBoundingClientRect();
            ov.style.alignItems='flex-start'; ov.style.justifyContent='flex-start';
            box.style.position='fixed'; box.style.margin='0';
            box.style.left=r.left+'px'; box.style.top=r.top+'px';
            var sx=e.clientX, sy=e.clientY, ox=r.left, oy=r.top;
            function mv(ev){
                box.style.left=Math.max(0, ox+ev.clientX-sx)+'px';
                box.style.top =Math.max(0, oy+ev.clientY-sy)+'px';
            }
            function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
            document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
        });
    })();
    fetch('olt_huawei.php?acao=conexao_get').then(function(r){return r.json();}).then(function(d){ var c=(d&&d.cfg)||{}; var g=function(id){return document.getElementById(id);};
        if(g('cxIp')) g('cxIp').value=c.ip||''; if(g('cxPorta')) g('cxPorta').value=c.porta||23; if(g('cxUser')) g('cxUser').value=c.user||''; if(g('cxTimeout')) g('cxTimeout').value=c.timeout||8;
        if(g('cxSnmpComm')) g('cxSnmpComm').value=c.snmp_comm||''; if(g('cxSnmpPort')) g('cxSnmpPort').value=c.snmp_port||161; if(g('cxSnmpRw')) g('cxSnmpRw').value=c.snmp_comm_rw||'';
        if(c.tem_senha && g('cxPass')) g('cxPass').placeholder='•••••• (senha configurada — em branco = manter)';
        // Já configurada = CONECTADA: botão mostra "Conectado" e fica indisponível.
        // Só volta a ficar disponível depois de clicar em Desconectar.
        var b=g('cxBtnConectar');
        if(b && c.ip && c.tem_senha){ b.disabled=true; b.style.cursor='default'; b.style.background=OLTC.grn; b.style.color='#fff'; b.style.opacity='0.9'; b.innerHTML='<i class="fa-solid fa-plug-circle-check"></i> Conectado'; }
    }).catch(function(){});
}
// Botão Conectar → testa a conexão; se OK vira "Conectado" (verde cheio).
function oltConectar(){
    var b=document.getElementById('cxBtnConectar'); if(!b) return;
    var r=document.getElementById('cxResult');
    var v=function(id){var e=document.getElementById(id);return e?(e.value||''):'';};
    b.disabled=true; b.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Conectando…';
    if(r) r.innerHTML='<span style="color:'+OLTC.mut+';"><i class="fa-solid fa-spinner fa-spin"></i> Salvando dados e testando…</span>';
    // 1) SALVA os dados digitados (senão o teste usaria a conexão antiga/vazia);
    // 2) TESTA a conexão com eles. Assim o Conectar já conecta, sem depender do Salvar.
    var body='acao=conexao_set&ip='+encodeURIComponent(v('cxIp'))+'&porta='+encodeURIComponent(v('cxPorta'))+'&user='+encodeURIComponent(v('cxUser'))+'&pass='+encodeURIComponent(v('cxPass'))+'&timeout='+encodeURIComponent(v('cxTimeout'))+'&snmp_comm='+encodeURIComponent(v('cxSnmpComm'))+'&snmp_port='+encodeURIComponent(v('cxSnmpPort'))+'&snmp_comm_rw='+encodeURIComponent(v('cxSnmpRw'));
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
      .then(function(rr){return rr.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d)) return null;
        if(d&&d.status==='erro'){ b.disabled=false; b.innerHTML='<i class="fa-solid fa-plug"></i> Conectar'; if(r) r.innerHTML='<span style="color:'+OLTC.red+';">'+_oltEsc(d.message||'Não salvou.')+'</span>'; return null; }
        return oltFetch('olt_huawei.php?acao=conexao_teste', null, true).then(function(rr){return rr.json();});
      }).then(function(d){ if(!d) return;
        if(typeof _oltAuthErro==='function' && _oltAuthErro(d)) return;
        var ok=!!(d&&d.conectado); _oltStatusConexao(ok); b.disabled=false;
        if(ok){ b.style.background=OLTC.grn; b.style.color='#fff'; b.innerHTML='<i class="fa-solid fa-plug-circle-check"></i> Conectado';
            if(r) r.innerHTML='<span style="color:'+OLTC.grn+'; font-weight:800;"><i class="fa-solid fa-circle-check"></i> Conectado com sucesso à OLT.</span>'; }
        else { b.style.background='transparent'; b.style.color=OLTC.red; b.style.borderColor=OLTC.red; b.innerHTML='<i class="fa-solid fa-plug-circle-xmark"></i> Sem conexão';
            if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Sem conexão — verifique IP, usuário e senha.</span>'; }
    }).catch(function(){ b.disabled=false; b.innerHTML='<i class="fa-solid fa-plug"></i> Conectar'; if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao conectar.</span>'; });
}
function oltConexaoSalvar(){
    var r=document.getElementById('cxResult'); if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    var v=function(id){var e=document.getElementById(id);return e?(e.value||''):'';};
    var body='acao=conexao_set&ip='+encodeURIComponent(v('cxIp'))+'&porta='+encodeURIComponent(v('cxPorta'))+'&user='+encodeURIComponent(v('cxUser'))+'&pass='+encodeURIComponent(v('cxPass'))+'&timeout='+encodeURIComponent(v('cxTimeout'))+'&snmp_comm='+encodeURIComponent(v('cxSnmpComm'))+'&snmp_port='+encodeURIComponent(v('cxSnmpPort'))+'&snmp_comm_rw='+encodeURIComponent(v('cxSnmpRw'));
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
      .then(function(rr){return rr.json();}).then(function(d){ if(!r) return;
        if(d&&d.saved){ var p=document.getElementById('cxPass'); if(p) p.value='';
            var n=5; var pinta=function(){ if(r) r.innerHTML='<span style="color:'+OLTC.grn+'; font-weight:800;"><i class="fa-solid fa-check"></i> Conexão salva. Fechando em <b>'+n+'</b>s…</span>'; };
            pinta(); var _iv=setInterval(function(){ n--; if(n<=0){ clearInterval(_iv); _oltAposConexaoSalva(); } else { pinta(); } }, 1000); }
        else if(d&&d.message){ r.innerHTML='<span style="color:'+OLTC.red+';">'+_oltEsc(d.message)+'</span>'; }
        else { r.innerHTML='<span style="color:'+OLTC.red+';">Não gravou (permissão da pasta de dados).</span>'; }
      }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
// ============================ FICHA TÉCNICA (aberta pelo SERIAL) ============================
function _oltOnuPorChave(fsp,id){ var L=window._oltLista||[]; for(var i=0;i<L.length;i++){ if((L[i].fsp||'')===fsp && (''+(L[i].id||''))===(''+id)) return L[i]; } return null; }
// Abre o CADASTRO do cliente — PLURAL e CONFIGURÁVEL (serve p/ QUALQUER radius). Resolve o vínculo NA HORA
// DO CLIQUE (o mapa serial↔cliente carrega async). Se houver uma URL configurada (curingas {serial} {login}
// {ip} {nome} {cpf} {uuid}), abre por ela; senão usa o padrão: o cadastro do WELLSYSTEM, pelo serial da ONU.
/* ============================================================================================
 * CADASTRO DO CLIENTE — abre no WELLSYSTEM, nunca mais no MK-Auth antigo.
 *
 * ANTES: o link ia para /admin/cliente_alt.hhvm?uuid=... (cadastro antigo). O endereco vinha
 * de TRES lugares — o template salvo no localStorage, o mesmo template guardado no servidor
 * (cache_trafego/olt_cad_url.json, reinjetado a cada carregamento) e um fallback fixo aqui no
 * codigo. Por isso limpar o cache do navegador nao resolvia: voltava na proxima abertura.
 *
 * AGORA: a OLT conhece o SERIAL da ONU, e o WellSystem acha o cliente por ele em
 * erp.php?p=clientes&campo=mac&q=<serial> — essa busca cobre ws_contrato.sn_onu E ont_id, em
 * QUALQUER situacao (ativo, bloqueado, cancelado), o que tambem atende ONU reaproveitada.
 * Sem serial, cai para a busca por login.
 *
 * A base sai do proprio endereco da pagina porque a OLT roda em DOIS lugares:
 * /wellsystem/olt.php (raiz) e /wellsystem/olt/olt.php (dentro do menu Servidores). Caminho
 * relativo resolveria diferente em cada um.
 * ========================================================================================= */
function _oltBaseWs(){
    var p=String(location.pathname||''); var i=p.toLowerCase().indexOf('/wellsystem/');
    if(i>=0) return location.origin+p.substring(0,i+12);
    var dir = p.substring(0, p.lastIndexOf('/') + 1); if (dir) return location.origin + dir; return location.origin + '/';
}
function _oltUrlCadastroWs(serial,login){
    var b=_oltBaseWs();
    if(serial) return b+'erp.php?p=clientes&campo=mac&q='+encodeURIComponent(serial);
    return b+'erp.php?p=clientes&campo=login&q='+encodeURIComponent(login||'');
}
/* Template legado = o do cadastro antigo. Enquanto existir (localStorage ou servidor) ele
   ganharia do padrao novo, entao e' descartado na leitura. */
function _oltTplLegado(tpl){
    return /cliente_alt\.hhvm|hhvm\?uuid/i.test(String(tpl||''));
}
function oltAbrirCadastro(serial){
    if(window._oltIsolada) return;   // edição OLT isolada: não existe cadastro de clientes do ERP
    var s=serial||'';
    // Tenta abrir com o que já se sabe. Retorna false se PRECISA do uuid e ainda não tem (aí buscamos ao vivo).
    var open1=function(){
        var uu=(typeof oltUuidDoCliente==='function')?(oltUuidDoCliente(s)||''):'';
        var ip=(typeof oltIpDoCliente==='function')?(oltIpDoCliente(s)||''):'';
        var nome=(typeof oltNomeDoCliente==='function')?(oltNomeDoCliente(s)||''):'';
        var login=(typeof _oltSnVendor==='function'?(_oltSnVendor(s)||''):'')||String(s).toUpperCase().replace(/[^0-9A-Z]/g,'');
        var tpl=''; try{ tpl=localStorage.getItem('oltCadUrl')||''; }catch(e){}
        if(_oltTplLegado(tpl)) tpl='';   // aponta pro cadastro antigo -> ignora e usa o do WellSystem
        if(tpl){
            if(tpl.indexOf('{uuid}')>=0 && !uu) return false;   // template usa {uuid} e ainda não temos -> busca
            window.open(tpl.replace(/\{uuid\}/g,encodeURIComponent(uu)).replace(/\{login\}/g,encodeURIComponent(login)).replace(/\{serial\}/g,encodeURIComponent(s)).replace(/\{serial_vendor\}/g,encodeURIComponent(login)).replace(/\{ip\}/g,encodeURIComponent(ip)).replace(/\{nome\}/g,encodeURIComponent(nome)).replace(/\{cpf\}/g,''),'_blank'); return true;
        }
        window.open(_oltUrlCadastroWs(s,login),'_blank'); return true;   // WELLSYSTEM (era /admin/cliente_alt.hhvm do MK-Auth; uuid nao e' mais necessario)
        if(ip){ if(typeof testarEAbrirIP==='function') testarEAbrirIP(ip); else window.open('http://'+ip,'_blank'); return true; }
        return false;
    };
    /* QUEM E' O DONO ATUAL DESTE SERIAL — sempre perguntado AO VIVO, nunca lembrado.
     *
     * Os dois bancos rodam em paralelo: um cliente pode estar so' no WellSystem, so' no MK-Auth,
     * ou nos dois. Entao a busca e' em cadeia, e cada etapa consulta o banco na hora:
     *
     *   1) WellSystem (acao=ws_cliente_sn) -> abre erp.php?p=cliente&id=N
     *      Ignora contrato cancelado, entao ONU reaproveitada cai no dono NOVO.
     *   2) MK-Auth (acao=cliente_uuid) -> abre /admin/cliente_alt.hhvm?uuid=... no host do radius
     *      Consulta sis_cliente e sis_adicional pelo login/serial, no momento do clique.
     *   3) Nada encontrado -> busca por serial dentro do WellSystem, para o operador ver a situacao.
     *
     * O QUE MUDOU: antes o uuid vinha de window._loginToUuid / localStorage 'oltClientesMem', uma
     * memoria por serial que NUNCA expira. ONU reaproveitada carregava o uuid do dono anterior e
     * abria o cadastro errado — no MK-Auth e em qualquer lugar que usasse esse uuid. Aqui essa
     * memoria nao participa da decisao: ela continua servindo para exibir nome/IP na lista, mas
     * quem manda no link e' a resposta do banco.
     */
    var _login=(typeof _oltSnVendor==='function'?(_oltSnVendor(s)||''):'')||String(s).toUpperCase().replace(/[^0-9A-Z]/g,'');
    var _busca=function(){ window.open(_oltUrlCadastroWs(s,_login),'_blank'); };

    // Etapa 2 — MK-Auth ao vivo. So' roda se o WellSystem nao conhecer o serial.
    var _mkauth=function(){
        oltFetch('olt_huawei.php?acao=cliente_uuid&login='+encodeURIComponent(_login)+'&sn='+encodeURIComponent(s), null, true)
          .then(function(r){ return r.json(); })
          .then(function(d){
              if(d && d.host){ window._oltCadBase='http://'+d.host; }   // cadastro abre no host do radius
              if(d && d.uuid){
                  // Atualiza a memoria com o dono ATUAL, para a lista parar de exibir o anterior.
                  try{
                      window._oltClientesDB=window._oltClientesDB||{};
                      window._oltClientesDB[_login]={uuid:d.uuid, nome:(d.nome||''), ip:(d.ip||'')};
                      if(window._loginToUuid) window._loginToUuid[_login]=d.uuid;
                      if(window._loginToNome && d.nome) window._loginToNome[_login]=d.nome;
                      var _m=JSON.parse(localStorage.getItem('oltClientesMem')||'{}')||{};
                      _m[_login]={nome:(d.nome||''), uuid:d.uuid};   // sem IP: ele muda a cada reconexão
                      localStorage.setItem('oltClientesMem', JSON.stringify(_m));
                  }catch(e){}
                  window.open((window._oltCadBase||(window.WS_SRV||''))+'/admin/cliente_alt.hhvm?uuid='+encodeURIComponent(d.uuid),'_blank');
                  return;
              }
              _busca();   // etapa 3
          })
          .catch(_busca);
    };

    // Etapa 1 — WellSystem.
    try{
        fetch('olt_huawei.php?acao=ws_cliente_sn&sn='+encodeURIComponent(s), {cache:'no-store'})
          .then(function(r){ return r.json(); })
          .then(function(d){
              if(d && d.ok && d.cliente_id){ window.open(_oltBaseWs()+d.url,'_blank'); return; }
              _mkauth();
          })
          .catch(_mkauth);
    }catch(e){ _mkauth(); }
    return;
    // Faltou o uuid -> pede ao BACKEND o uuid pelo LOGIN (=serial) direto no banco do radius (sis_cliente).
    // Robusto: não depende do index.php nem do host. Com o uuid, abre a ficha no host atual (domínio ou IP).
    var login=(typeof _oltSnVendor==='function'?(_oltSnVendor(s)||''):'')||String(s).toUpperCase().replace(/[^0-9A-Z]/g,'');
    oltFetch('olt_huawei.php?acao=cliente_uuid&login='+encodeURIComponent(login)+'&sn='+encodeURIComponent(s), null, true).then(function(r){return r.json();}).then(function(d){
        if(d&&d.host){ window._oltCadBase='http://'+d.host; }   // host do radius (IP) p/ abrir o cadastro
        if(d&&d.uuid){ window._oltClientesDB=window._oltClientesDB||{}; window._oltClientesDB[login]={uuid:d.uuid, nome:(d.nome||''), ip:(d.ip||'')}; }
        if(open1()) return;
        if(confirm('Cliente não localizado no radius para o login/serial: '+login+'.\n'+((d&&d.msg)?('('+d.msg+')\n'):'')+'Quer ajustar a URL do cadastro?')) oltConfigCadastro(login);
    }).catch(function(){
        if(confirm('Não consegui consultar o banco do radius agora. Ajustar a URL do cadastro?')) oltConfigCadastro(login);
    });
}
// Configura (1x) a URL do cadastro do radius — fica salva e o botão Cadastro passa a usar. Curingas plurais.
function oltConfigCadastro(exemplo){
    var atual=''; try{ atual=localStorage.getItem('oltCadUrl')||''; }catch(e){}
    var v=prompt('URL do cadastro do cliente no SEU radius.\nUse curingas: {serial} {login} {ip} {nome} {cpf} {uuid}\n\nExemplos:\n• MK-Auth (uuid): http://SEU_IP/admin/cliente_alt.hhvm?uuid={uuid}\n• Busca por login/serial: http://SEU_IP/admin/clientes?busca={login}\n• Por IP: http://SEU_IP/admin/clientes?busca={ip}', atual);
    if(v===null) return; v=(''+v).trim();
    try{ localStorage.setItem('oltCadUrl', v); }catch(e){}
    try{ oltFetch('olt_huawei.php?acao=cad_url_set&url='+encodeURIComponent(v), null, false); }catch(e){}   // salva no SERVIDOR (vale p/ IP e domínio, todos os usuários)
    alert(v?('Salvo. O botão Cadastro passa a abrir por essa URL'+(exemplo?(' (ex.: '+exemplo+')'):'')+'.'):'URL limpa — o botão volta ao padrão (segue o host atual: domínio ou IP).');
}
// Carrega a URL do cadastro salva no SERVIDOR (vale p/ todos os usuários e p/ acesso por IP ou domínio).
function oltCarregarCadUrl(){
    try{ oltFetch('olt_huawei.php?acao=cad_url_get', null, false).then(function(r){return r.json();}).then(function(d){
        if(d && typeof d.url==='string' && d.url && !_oltTplLegado(d.url)){ try{ localStorage.setItem('oltCadUrl', d.url); }catch(e){} }
        else if(d && _oltTplLegado(d.url||'')){ try{ localStorage.removeItem('oltCadUrl'); }catch(e){} }   // servidor ainda guarda a URL antiga: descarta em vez de reinjetar
        if(d && d.host){ window._oltCadBase='http://'+d.host; }   // abre o cadastro no HOST do radius (IP), não no domínio do app
    }).catch(function(){}); }catch(e){}
}
function oltFichaTecnica(fsp,id){
    var o=_oltOnuPorChave(fsp,id); if(!o){ return; }
    var atual=document.getElementById('oltFtOv'); if(atual) atual.remove();
    var isOn=(o.status||'').toLowerCase().indexOf('online')>-1;
    var tp=_oltTipoDe(o); var tipoTxt=(tp==='ONU')?'ONU · Bridge':(tp==='ONT')?'ONT · Router':'—';
    var pp=(o.fsp||'').split('/'); var pl=_oltPlacaNome(pp[1]||''); var po=_oltPortaNome(o.fsp||'');
    var ip=oltIpDoCliente(o.serial), uu=oltUuidDoCliente(o.serial);
    var nz=function(v){ return (v==null||v===''||v==='—')?'—':_oltEsc(''+v); };
    // Cor do sinal pela REFERÊNCIA = Rx OLT (retorno): verde OK · âmbar <= -28 · vermelho <= -29,1 dBm.
    var _corSin=_oltCorSinalDe(o);
    var sinal=function(v){ return _corSin?('<b style="color:'+_corSin+';">'+nz(v)+'</b>'):nz(v); };
    var linha=function(rot,val,mono){ return '<div style="display:flex; gap:10px; padding:7px 0; border-bottom:1px solid '+OLTC.line+';">'+
        '<div style="flex:0 0 132px; font-size:11.5px; color:'+OLTC.mut+'; font-weight:700;">'+rot+'</div>'+
        '<div style="flex:1 1 auto; font-size:12.5px; color:'+OLTC.txt+'; word-break:break-word;'+(mono?' font-family:monospace;':'')+'">'+val+'</div></div>'; };
    var _ipId='oltFtIp_'+String(o.fsp).replace(/[^0-9]/g,'_')+'_'+String(o.id).replace(/[^0-9]/g,'_');
    var _ipHtml=function(v){ return '<span onclick="testarEAbrirIP(\''+_oltEsc(v)+'\')" style="cursor:pointer; color:'+OLTC.acc+'; text-decoration:underline;">'+_oltEsc(v)+' — abrir equipamento</span>'; };
    // IP AO VIVO: pergunta na hora (acao=ip_vivo) pelo login do CONTRATO e a sessão atual. Corrige o
    // que veio do mapa carregado com a página (o IP do PPPoE muda a cada reconexão).
    try{
        oltFetch('olt_huawei.php?acao=ip_vivo&sn='+encodeURIComponent(o.serial||'')+'&login='+encodeURIComponent(_oltSnVendor(o.serial)||''), null, true)
          .then(function(r){ return r.json(); })
          .then(function(d){
              if(!d||!d.ok) return;   // nenhuma fonte ao vivo respondeu -> mantém o que já está na tela
              var el=document.getElementById(_ipId); if(!el) return;
              if(d.ip){ el.innerHTML=linha('IP', _ipHtml(d.ip),true); el.style.display=''; }
              else el.style.display='none';   // offline: não mostra IP antigo (pode ser de outro cliente)
              var m=window._oltClientesDB; var kl=_oltLoginResolvido(o.serial); if(m&&kl&&m[kl]) m[kl].ip=d.ip||'';
          }).catch(function(){});
    }catch(e){}
    var body=''+
        linha('Serial','<b>'+nz(o.serial)+'</b>',true)+
        linha('Nome', nz(_oltNomeDe(o)))+
        linha('Status', '<span style="color:'+(isOn?OLTC.grn:OLTC.red)+'; font-weight:800;"><i class="fa-solid fa-circle" style="font-size:7px;"></i> '+nz(o.status)+'</span>'+(o.estado?' <span style="color:'+OLTC.mut+';">('+_oltEsc(o.estado)+')</span>':''))+
        linha('Modelo', nz(o.modelo))+
        linha('Tipo', tipoTxt)+
        linha('F/S/P', nz(o.fsp)+(pl?' <span style="color:'+OLTC.mut+';">· Placa: '+_oltEsc(pl)+'</span>':''), true)+
        linha('Porta PON', nz(pp[2])+(po?' <span style="color:'+OLTC.mut+';">— '+_oltEsc(po)+'</span>':''))+
        linha('ID (ont)', nz(o.id), true)+
        linha('VLAN', nz(o.vlan))+
        linha('Zona', nz(o.zona))+
        linha('Rx ONU (↓)', sinal(o.rx), true)+
        linha('Tx ONU (↑)', nz(o.tx), true)+
        linha('Rx OLT (retorno)', sinal(o.rx_olt), true)+
        linha('Distância', o.dist?(_oltEsc(o.dist)+' m'):'—')+
        linha('Uptime', nz(o.uptime)+(o.downtime&&!isOn?' <span style="color:'+OLTC.amb+';">(offline há '+_oltEsc(o.downtime)+')</span>':''))+
        linha('Ativação (dia/mês/ano)', '<b style="color:'+OLTC.grn+';"><i class="fa-solid fa-calendar-check"></i> '+_oltEsc(_oltDataAtivacao(o)||'—')+'</b>')+
        '<div id="'+_ipId+'"'+(ip?'':' style="display:none;"')+'>'+linha('IP', _ipHtml(ip),true)+'</div>';
    // MULTI-JANELA: cada ONU tem seu id próprio (por F/S/P+ID). Abrir OUTRO Serial abre OUTRA ficha (várias ao
    // mesmo tempo); abrir o MESMO que já está aberto só ATUALIZA e traz pra frente. Cards flutuantes, arrastáveis,
    // 100% responsivos (largura min(96vw,480px)). Rodapé com botões iguais e flex-wrap (quebra no mobile).
    var wid='oltFt_'+String(o.fsp).replace(/[^0-9]/g,'_')+'_'+String(o.id).replace(/[^0-9]/g,'_');
    var _btFt='cursor:pointer; flex:1 1 120px; max-width:180px; padding:10px 12px; border-radius:8px; font-weight:800; display:inline-flex; align-items:center; justify-content:center; gap:7px; white-space:nowrap;';
    var acoes='<button onclick="var w=document.getElementById(\''+wid+'\'); if(w)w.remove(); oltAbrirONU(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\',\''+_oltEsc(o.serial)+'\',\''+_oltEsc(o.status)+'\',\''+encodeURIComponent(o.nome||'')+'\',\''+encodeURIComponent(o.zona||'')+'\',\''+_oltEsc(o.vlan||'')+'\',true)" style="'+_btFt+' border:none; background:#243447; color:#fff;"><i class="fa-solid fa-sliders"></i> Gerenciar</button>'+
        '<button onclick="oltGrafCliente(\''+_oltEsc(o.fsp)+'\',\''+_oltEsc(o.id)+'\',\''+encodeURIComponent(_oltNomeDe(o)||o.serial||'')+'\')" style="'+_btFt+' border:1px solid '+OLTC.vio+'; background:transparent; color:'+OLTC.vio+';"><i class="fa-solid fa-chart-line"></i> Gráfico</button>'+
        (window._oltIsolada?'':'<button onclick="oltAbrirCadastro(\''+_oltEsc(o.serial)+'\')" title="Abrir o cadastro do cliente" style="'+_btFt+' border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+';"><i class="fa-solid fa-user"></i> Cadastro</button>');
    var inner='<div id="'+wid+'_head" style="flex:0 0 auto; padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:10px; cursor:move;"><i class="fa-solid fa-microchip" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">Ficha Técnica — '+nz(o.serial)+'</div><button onclick="var w=document.getElementById(\''+wid+'\'); if(w)w.remove()" style="cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div style="flex:1 1 auto; overflow:auto; padding:12px 16px;">'+body+'</div>'+
        '<div style="flex:0 0 auto; padding:12px 16px; border-top:1px solid '+OLTC.line+'; display:flex; flex-wrap:wrap; gap:8px; justify-content:center; align-items:stretch;">'+acoes+'</div>';
    var exist=document.getElementById(wid);
    if(exist){   // MESMA ONU já aberta -> ATUALIZA o conteúdo e traz pra frente (não abre duplicada)
        exist.innerHTML=inner; exist.style.zIndex=(window._oltFtZ=(window._oltFtZ||2147483000)+1);
        if(typeof oltDragify==='function') oltDragify(exist, document.getElementById(wid+'_head'));
        return;
    }
    // OUTRA ONU -> NOVA ficha flutuante (cascata pra não empilhar exatamente em cima).
    var card=document.createElement('div'); card.id=wid;
    var nAb=document.querySelectorAll('[id^="oltFt_"]').length, off=(nAb%6)*26;
    card.style.cssText='position:fixed; z-index:'+(window._oltFtZ=(window._oltFtZ||2147483000)+1)+'; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:14px; width:min(94vw,430px); max-height:88vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);';
    card.onmousedown=function(){ card.style.zIndex=(window._oltFtZ=(window._oltFtZ||2147483000)+1); };   // clicar traz pra frente
    card.innerHTML=inner;
    document.body.appendChild(card);
    card.style.left=Math.round(Math.max(6,(window.innerWidth-card.offsetWidth)/2+off))+'px';
    card.style.top=Math.round(Math.max(6,(window.innerHeight-card.offsetHeight)/2-40+off))+'px';
    if(typeof oltDragify==='function') oltDragify(card, document.getElementById(wid+'_head'));
}
// Gráfico do cliente — CONSUMO DE BANDA (tráfego up/down) da PON do cliente. TEMPO REAL: rele o histórico
// SNMP a cada 15s enquanto a janela fica aberta. Seletor de PERÍODO: Meia hora / Dia (filtra por timestamp).
// Abre a partir da Ficha Técnica (leitura direta, fora da fila). Janela ARRASTÁVEL. 100% responsivo.
// MULTI-JANELA: uma por ONU (id = oltGc_fsp_id). Abrir OUTRA ONU abre OUTRO gráfico (vários ao mesmo tempo);
// a MESMA já aberta só ATUALIZA e vem pra frente. Cards flutuantes (não bloqueiam a tela), arrastáveis,
// 100% responsivos. As leituras Telnet vão pela FILA serial -> mesmo com vários abertos, 1 leitura por vez.
window._oltGcWins = window._oltGcWins || {};
function oltGrafCliente(fsp,id,nomeEnc){
    var nome=decodeURIComponent(nomeEnc||'')||fsp||'Cliente';
    var wid='oltGc_'+String(fsp).replace(/[^0-9]/g,'_')+'_'+String(id).replace(/[^0-9]/g,'_');
    var st=window._oltGcWins[wid];
    if(st && document.getElementById(wid)){   // MESMA ONU já aberta -> ATUALIZA + traz pra frente (não duplica)
        st.nome=nome; document.getElementById(wid).style.zIndex=(window._oltGcZ=(window._oltGcZ||2147483200)+1); _oltGcRender(wid); return;
    }
    st={fsp:fsp,id:id,nome:nome,per:(window._oltGcPer==='dia'?'dia':'h1'),timer:null,restante:4,fast:2}; window._oltGcWins[wid]=st;
    var pBt=function(k,lbl){ var on=(st.per===k); return '<button id="oltGcP_'+k+'_'+wid+'" onclick="oltGcPeriodo(\''+wid+'\',\''+k+'\')" style="cursor:pointer; padding:3px 9px; border-radius:20px; border:1px solid rgba(255,255,255,.55); background:'+(on?'rgba(255,255,255,.28)':'transparent')+'; color:#fff; font-size:10px; font-weight:800;">'+lbl+'</button>'; };
    var card=document.createElement('div'); card.id=wid;
    var nAb=document.querySelectorAll('[id^="oltGc_"]').length, off=(nAb%6)*26;
    card.style.cssText='pointer-events:auto; position:fixed; z-index:'+(window._oltGcZ=(window._oltGcZ||2147483200)+1)+'; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:14px; width:min(94vw,430px); max-height:88vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);';
    card.onmousedown=function(){ card.style.zIndex=(window._oltGcZ=(window._oltGcZ||2147483200)+1); };
    card.innerHTML='<div id="'+wid+'_head" style="flex:0 0 auto; padding:8px 10px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); border-radius:14px 14px 0 0; display:flex; align-items:center; gap:5px; cursor:move; flex-wrap:nowrap;"><i class="fa-solid fa-gauge-high" style="color:#fff; font-size:12px;"></i><div style="flex:1 1 40px; font-weight:700; font-size:12px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; min-width:0;">'+_oltEsc(nome)+'</div>'+
            '<span style="display:inline-flex; align-items:center; gap:4px; flex:0 0 auto;"><span style="display:inline-flex; align-items:center; gap:3px; color:#fff; font-size:9px; font-weight:700; background:rgba(0,0,0,.18); border-radius:20px; padding:2px 6px; white-space:nowrap;"><i class="fa-solid fa-circle" style="font-size:5px; color:#7ee0a8;"></i> <span id="oltGcCd_'+wid+'">30</span>s</span>'+pBt('h1','Hora')+pBt('dia','Dia')+'</span>'+
            '<button onclick="oltGcFechar(\''+wid+'\')" style="cursor:pointer; flex:0 0 auto; width:26px; height:26px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff; font-size:12px;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div id="oltGcBody_'+wid+'" style="flex:1 1 auto; overflow:auto; padding:16px; text-align:center; color:'+OLTC.mut+';">'+_oltSpinner('Carregando consumo de banda...')+'</div>';
    document.body.appendChild(card);
    card.style.left=Math.round(Math.max(6,(window.innerWidth-card.offsetWidth)/2+off))+'px';
    card.style.top=Math.round(Math.max(6,(window.innerHeight-card.offsetHeight)/2-40+off))+'px';
    if(typeof oltDragify==='function') oltDragify(card, document.getElementById(wid+'_head'));
    // TEMPO REAL: 2 primeiras leituras rápidas (6s) pro gráfico aparecer logo; depois 30s (Telnet, reduz colisão).
    st.timer=setInterval(function(){ if(!document.getElementById(wid)){ clearInterval(st.timer); delete window._oltGcWins[wid]; return; }
        st.restante--; var cd=document.getElementById('oltGcCd_'+wid); if(cd) cd.textContent=(st.restante>0?st.restante:0);
        if(st.restante<=0){ if(st.fast>0){ st.restante=4; st.fast--; } else { st.restante=30; } _oltGcRender(wid); } },1000);
    _oltGcRender(wid);
}
function oltGcFechar(wid){ var st=window._oltGcWins[wid]; if(st&&st.timer) clearInterval(st.timer); delete window._oltGcWins[wid]; var el=document.getElementById(wid); if(el) el.remove(); }
// Helpers de hora (HH:MM e HH:MM:SS) a partir de um timestamp em segundos.
function _oltHm(ts){ var d=new Date((+ts||0)*1000); var p=function(x){return (x<10?'0':'')+x;}; return p(d.getHours())+':'+p(d.getMinutes()); }
function _oltHms(ts){ var d=new Date((+ts||0)*1000); var p=function(x){return (x<10?'0':'')+x;}; return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds()); }
// Gráfico de banda INTUITIVO: eixo X com HORÁRIOS, eixo Y em Mbps (grade), área preenchida, ponto atual
// destacado, valores grandes (↓ Download / ↑ Upload) + pico + hora da última leitura. pts=[{up,down,ts}].
function _oltGcGrafico(pts){
    if(!pts||pts.length<2) return '';
    var W=480,H=210,padL=48,padR=12,padT=14,padB=26, pw=W-padL-padR, ph=H-padT-padB, n=pts.length;
    var maxreal=1; pts.forEach(function(p){ maxreal=Math.max(maxreal,p.up,p.down); });
    var nice=function(v){ if(v<=0)return 1; var e=Math.pow(10,Math.floor(Math.log(v)/Math.LN10)); var m=v/e; var nm=(m<=1?1:m<=2?2:m<=5?5:10); return nm*e; };
    var maxv=nice(maxreal);
    var X=function(i){ return padL+pw*(n<2?0:i/(n-1)); };
    var Y=function(v){ return padT+ph*(1-Math.max(0,Math.min(1,v/maxv))); };
    var fmtE=function(v){ return v>=1e6?((v/1e6).toFixed(v>=1e7?0:1)+'M'):(v>=1e3?((v/1e3).toFixed(0)+'k'):(''+Math.round(v))); };
    var fmt2=function(v){ return v>=1e6?((v/1e6).toFixed(1)+' Mbps'):(v>=1e3?((v/1e3).toFixed(0)+' kbps'):(Math.round(v)+' bps')); };
    var grid='', ylab='';
    [0,0.5,1].forEach(function(f){ var vy=padT+ph*(1-f);
        grid+='<line x1="'+padL+'" y1="'+vy.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+vy.toFixed(1)+'" stroke="'+OLTC.line+'" stroke-width="1"'+(f>0?' stroke-dasharray="3 3"':'')+'/>';
        ylab+='<text x="'+(padL-6)+'" y="'+(vy+3).toFixed(1)+'" text-anchor="end" font-size="9" fill="'+OLTC.mut+'">'+fmtE(maxv*f)+'bps</text>';
    });
    var xlab='';
    [0,0.34,0.67,1].forEach(function(f){ var i=Math.round(f*(n-1)); var ts=pts[i]&&pts[i].ts; if(!ts)return; var xx=X(i);
        xlab+='<line x1="'+xx.toFixed(1)+'" y1="'+(padT+ph)+'" x2="'+xx.toFixed(1)+'" y2="'+(padT+ph+3)+'" stroke="'+OLTC.mut+'" stroke-width="1"/>'+
              '<text x="'+xx.toFixed(1)+'" y="'+(H-8)+'" text-anchor="'+(f===0?'start':f>=1?'end':'middle')+'" font-size="9" fill="'+OLTC.mut+'">'+_oltHm(ts)+'</text>';
    });
    var lineP=function(key){ var d=''; pts.forEach(function(p,i){ d+=(i?'L':'M')+X(i).toFixed(1)+' '+Y(p[key]).toFixed(1)+' '; }); return d; };
    var areaP=function(key){ var d='M'+X(0).toFixed(1)+' '+Y(0).toFixed(1)+' '; pts.forEach(function(p,i){ d+='L'+X(i).toFixed(1)+' '+Y(p[key]).toFixed(1)+' '; }); return d+'L'+X(n-1).toFixed(1)+' '+Y(0).toFixed(1)+' Z'; };
    // HOVER: faixas transparentes por ponto com <title> nativo -> passar o mouse mostra hora · ↓ · ↑.
    var hover=''; for(var hi=0;hi<n;hi++){ var xc=X(hi); var x0=hi?(X(hi-1)+xc)/2:xc-1; var x1=(hi<n-1)?(xc+X(hi+1))/2:xc+1;
        hover+='<rect x="'+x0.toFixed(1)+'" y="'+padT+'" width="'+Math.max(1,x1-x0).toFixed(1)+'" height="'+ph+'" fill="transparent" style="cursor:crosshair;"><title>'+_oltHm(pts[hi].ts)+'  ·  ↓ '+fmt2(pts[hi].down)+'   ↑ '+fmt2(pts[hi].up)+'</title></rect>'; }
    var cur=pts[n-1]||{up:0,down:0,ts:0};
    return '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%; height:auto; display:block; background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:8px;">'+
        grid+ylab+
        '<path d="'+areaP('down')+'" fill="#3b82f6" opacity="0.10"/>'+
        '<path d="'+areaP('up')+'" fill="#f59e0b" opacity="0.10"/>'+
        '<path d="'+lineP('down')+'" fill="none" stroke="#3b82f6" stroke-width="2"/>'+
        '<path d="'+lineP('up')+'" fill="none" stroke="#f59e0b" stroke-width="2"/>'+
        '<circle cx="'+X(n-1).toFixed(1)+'" cy="'+Y(cur.down).toFixed(1)+'" r="3.2" fill="#3b82f6"/>'+
        '<circle cx="'+X(n-1).toFixed(1)+'" cy="'+Y(cur.up).toFixed(1)+'" r="3.2" fill="#f59e0b"/>'+
        xlab+hover+
    '</svg>'+
    '<div style="display:flex; flex-wrap:wrap; gap:14px; align-items:center; margin-top:8px;">'+
        '<span style="font-size:14px; font-weight:800; color:#3b82f6;"><i class="fa-solid fa-download"></i> '+fmt2(cur.down)+'</span>'+
        '<span style="font-size:14px; font-weight:800; color:#f59e0b;"><i class="fa-solid fa-upload"></i> '+fmt2(cur.up)+'</span>'+
        '<span style="font-size:10.5px; color:'+OLTC.mut+';">pico '+fmt2(maxreal)+'</span>'+
        (cur.ts?'<span style="font-size:10.5px; color:'+OLTC.mut+'; margin-left:auto; white-space:nowrap;"><i class="fa-regular fa-clock"></i> '+_oltHms(cur.ts)+'</span>':'')+
    '</div>';
}
// Troca o período (Meia hora / Dia) DESTA janela e re-desenha.
function oltGcPeriodo(wid,k){ var st=window._oltGcWins[wid]; if(!st) return; st.per=k; window._oltGcPer=k;
    ['h1','dia'].forEach(function(x){ var b=document.getElementById('oltGcP_'+x+'_'+wid); if(b) b.style.background=(x===k?'rgba(255,255,255,.28)':'transparent'); });
    _oltGcRender(wid);
}
// Busca o histórico da ONU DESTA janela e desenha só o período escolhido (filtra por timestamp de cada amostra).
function _oltGcRender(wid){
    var st=window._oltGcWins[wid]; if(!st) return; var fsp=st.fsp, id=st.id;
    // TRÁFEGO POR ONU via Telnet. Vai pela FILA serial (1 leitura por vez, mesmo com vários gráficos abertos).
    oltFetch('olt_huawei.php?acao=onu_traf&fsp='+encodeURIComponent(fsp)+'&id='+encodeURIComponent(id), null, true).then(function(r){return r.json();}).then(function(d){
        var bd=document.getElementById('oltGcBody_'+wid); if(!bd) return; bd.style.textAlign='left';
        var serie=(d&&d.serie)||[]; var agora=Math.floor(Date.now()/1000);
        var jan=(st.per==='dia')?86400:3600;   // dia (24h) ou 1 hora
        var pts=[]; serie.forEach(function(v){ if(!v||v.length<2) return; var ts=(+v[2]||0); if(ts && (agora-ts)>jan) return; pts.push({up:v[0], down:v[1], ts:ts}); });
        var perTxt=(st.per==='dia')?'últimas 24h':'última 1 hora';
        var ocup=(d&&(d.status==='ocupado'||d.status==='erro'));
        // "ocupado" = o Telnet estava ocupado AGORA (o cron também usa). NÃO é falha: mostra o que já tem e
        // tenta no próximo ciclo. Só se ainda não houver 2 pontos é que fica no "coletando".
        if(pts.length<2){
            var nota=ocup?('<br><span style="color:'+OLTC.amb+';"><i class="fa-solid fa-hourglass-half"></i> '+_oltEsc((d&&d.msg)||'OLT ocupada — tentando de novo')+'</span>'):'';
            if(pts.length===1){   // JÁ tem 1 leitura de bps -> mostra os VALORES na hora (a linha aparece na próxima)
                var c1=pts[0], fx=function(v){ return v>=1e6?((v/1e6).toFixed(1)+' Mbps'):(v>=1e3?((v/1e3).toFixed(0)+' kbps'):(Math.round(v)+' bps')); };
                bd.innerHTML='<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:6px;">Consumo do <b>cliente</b> (ONU '+_oltEsc(fsp)+':'+_oltEsc(id)+') · '+perTxt+'</div>'+
                    '<div style="display:flex; gap:18px; flex-wrap:wrap; align-items:center; padding:8px 0 6px;"><span style="font-size:13px; font-weight:800; color:#3b82f6;"><i class="fa-solid fa-download"></i> '+fx(c1.down)+'</span><span style="font-size:13px; font-weight:800; color:#f59e0b;"><i class="fa-solid fa-upload"></i> '+fx(c1.up)+'</span></div>'+
                    '<div style="font-size:11px; color:'+OLTC.amb+';"><i class="fa-solid fa-hourglass-half"></i> montando o gráfico ao vivo… (mais 1 leitura)'+nota+'</div>'; return;
            }
            bd.innerHTML='<div style="color:'+OLTC.mut+'; padding:6px 0; line-height:1.7;">Coletando o consumo da ONU <b>'+_oltEsc(fsp)+':'+_oltEsc(id)+'</b> via Telnet — o valor aparece já na <b>2ª leitura</b> (poucos segundos).'+nota+'</div>'; return; }
        var aoVivo=ocup?'<span style="color:'+OLTC.amb+'; font-weight:700;"><i class="fa-solid fa-hourglass-half"></i> OLT ocupada — mostrando o último; atualiza no próximo ciclo</span>'
                        :'atualiza sozinho';
        bd.innerHTML='<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:8px;">Consumo do <b>cliente</b> (ONU '+_oltEsc(fsp)+':'+_oltEsc(id)+') · '+perTxt+' · '+aoVivo+'.</div>'+_oltGcGrafico(pts);
    }).catch(function(){ var bd=document.getElementById('oltGcBody_'+wid); if(bd && bd.innerHTML.indexOf('svg')<0){ bd.style.textAlign='left'; bd.innerHTML='<div style="color:'+OLTC.amb+'; padding:6px 0;"><i class="fa-solid fa-hourglass-half"></i> Rede/OLT ocupada — tentando no próximo ciclo. O gráfico segue quando responder.</div>'; } });
}
// ============ UPTIME por ONU/ONT — popup ao clicar no SINAL (atualiza a cada 60s) ============
function oltUptimePopup(fsp,id,ev){
    if(ev){ ev.stopPropagation(); }
    var o=_oltOnuPorChave(fsp,id); if(!o){ return; }
    _oltFecharUpPop();
    var tp=_oltTipoDe(o); var tipoTxt=(tp==='ONU')?'ONU · Bridge':(tp==='ONT')?'ONT · Router':'ONU / ONT';
    var isOn=(o.status||'').toLowerCase().indexOf('online')>-1;
    var box=document.createElement('div'); box.id='oltUpPop';
    var px=(ev&&ev.clientX!=null)?ev.clientX:200, py=(ev&&ev.clientY!=null)?ev.clientY:200;
    var x=Math.max(8, Math.min(px, window.innerWidth-224)); var y=Math.max(8, Math.min(py+14, window.innerHeight-130));
    box.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; left:'+x+'px; top:'+y+'px; width:206px; background:'+OLTC.bg+'; border:1px solid '+OLTC.acc+'; border-radius:10px; box-shadow:0 14px 40px rgba(0,0,0,0.5); padding:10px 12px; font-size:12px; color:'+OLTC.txt+';';
    box.innerHTML='<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:6px;"><span style="font-weight:800; color:'+OLTC.acc+'; font-size:10.5px; text-transform:uppercase; letter-spacing:.4px;"><i class="fa-solid fa-clock"></i> '+tipoTxt+'</span><span onclick="_oltFecharUpPop()" style="cursor:pointer; color:'+OLTC.mut+'; font-weight:800;">✕</span></div>'+
        '<div style="font-size:10px; color:'+OLTC.mut+';">Tempo ligada (uptime)</div>'+
        '<div id="oltUpPopVal" style="font-size:15px; font-weight:800; color:'+(isOn?OLTC.ink:OLTC.mut)+'; font-family:monospace; margin:1px 0 6px;">'+_oltEsc(o.uptime||(isOn?'…':'— (offline)'))+'</div>'+
        '<div style="font-size:10px; color:'+OLTC.mut+';">atualização em <span id="oltUpPopCnt" style="color:'+OLTC.acc+'; font-weight:800;">60</span>s</div>'+
        (_oltTemImg(o)?'<div id="oltUpPopImg" style="margin-top:8px; text-align:center;"></div>':'');
    document.body.appendChild(box);
    if(_oltTemImg(o)){ var _ck=_oltImgKey(o); window._oltModeloImgCache=window._oltModeloImgCache||{};
        var _showImg=function(src){ var c=document.getElementById('oltUpPopImg'); if(c&&src) c.innerHTML='<img src="'+src+'" style="max-width:100%; max-height:120px; border-radius:6px; border:1px solid '+OLTC.line+';">'; };
        if(window._oltModeloImgCache[_ck]!=null) _showImg(window._oltModeloImgCache[_ck]);
        else fetch('olt_huawei.php?acao=modelo_img_get&chave='+encodeURIComponent(_ck),null,true).then(function(r){return r.json();}).then(function(d){ var src=(d&&d.img)||''; window._oltModeloImgCache[_ck]=src; _showImg(src); }).catch(function(){});
    }
    var refetch=function(){ if((o.status||'').toLowerCase().indexOf('online')<0) return; oltFetch('olt_huawei.php?acao=onu_uptime&fsp='+encodeURIComponent(fsp)+'&id='+encodeURIComponent(id), null, true).then(function(r){return r.json();}).then(function(d){ var v=document.getElementById('oltUpPopVal'); if(v&&d&&d.uptime){ v.textContent=d.uptime; var oo=_oltOnuPorChave(fsp,id); if(oo)oo.uptime=d.uptime; } }).catch(function(){}); };
    if(isOn && !o.uptime) refetch();
    var cnt=60;
    window._oltUpPopTimer=setInterval(function(){ if(!document.getElementById('oltUpPop')){ _oltFecharUpPop(); return; } cnt--; var c=document.getElementById('oltUpPopCnt'); if(c)c.textContent=cnt; if(cnt<=0){ cnt=60; refetch(); } }, 1000);
    setTimeout(function(){ document.addEventListener('click', _oltUpPopOutside); },0);
}
function _oltUpPopOutside(e){ var b=document.getElementById('oltUpPop'); if(b && !b.contains(e.target)) _oltFecharUpPop(); }
function _oltFecharUpPop(){ if(window._oltUpPopTimer){ clearInterval(window._oltUpPopTimer); window._oltUpPopTimer=null; } var b=document.getElementById('oltUpPop'); if(b) b.remove(); document.removeEventListener('click', _oltUpPopOutside); }
// ============ FOTO do MODELO do equipamento (anexar PNG/JPEG na coluna TIPO) ============
function _oltImgKey(o){ return ((o.modelo&&o.modelo!=='—')?o.modelo:(o.serial||'')).toUpperCase().trim(); }
function _oltTemImg(o){ var k=_oltImgKey(o); return !!(k && window._oltModeloImgKeys && window._oltModeloImgKeys.indexOf(k)>-1); }
function oltCarregarModeloImgs(){ if(window._oltModeloImgsCarregando) return; window._oltModeloImgsCarregando=true;
    fetch('olt_huawei.php?acao=modelo_img_get').then(function(r){return r.json();}).then(function(d){ window._oltModeloImgKeys=(d&&d.chaves)||[]; if(typeof oltRenderLista==='function') oltRenderLista(); }).catch(function(){ window._oltModeloImgKeys=window._oltModeloImgKeys||[]; });
}
function _oltImgHover(keyEnc,elem){
    var chave=decodeURIComponent(keyEnc); window._oltImgHoverKey=chave; window._oltModeloImgCache=window._oltModeloImgCache||{};
    var show=function(src){ if(!src || window._oltImgHoverKey!==chave) return; _oltImgHoverOut(); var r=elem.getBoundingClientRect(); var box=document.createElement('div'); box.id='oltImgHover'; box.style.cssText='position:fixed; z-index:2147483300; left:'+Math.max(8,Math.min(r.left, window.innerWidth-190))+'px; top:'+Math.max(8, Math.min(r.bottom+6, window.innerHeight-170))+'px; background:'+OLTC.bg+'; border:1px solid '+OLTC.acc+'; border-radius:8px; padding:5px; box-shadow:0 12px 34px rgba(0,0,0,0.5); pointer-events:none;'; box.innerHTML='<img src="'+src+'" style="max-width:170px; max-height:150px; display:block; border-radius:5px;">'; document.body.appendChild(box); };
    if(window._oltModeloImgCache[chave]!=null){ show(window._oltModeloImgCache[chave]); return; }
    fetch('olt_huawei.php?acao=modelo_img_get&chave='+encodeURIComponent(chave),null,true).then(function(r){return r.json();}).then(function(d){ var src=(d&&d.img)||''; window._oltModeloImgCache[chave]=src; show(src); }).catch(function(){});
}
function _oltImgHoverOut(){ window._oltImgHoverKey=null; var b=document.getElementById('oltImgHover'); if(b) b.remove(); }
function oltModeloImg(keyEnc,ev){ if(ev) ev.stopPropagation(); _oltImgHoverOut(); return oltMkfiles(decodeURIComponent(keyEnc||'')); }   // Mkfiles no modo "anexar ao modelo"
function __old_oltModeloImg(keyEnc,ev){
    if(ev){ ev.stopPropagation(); }
    _oltImgHoverOut();
    var chave=decodeURIComponent(keyEnc); if(!chave){ alert('Sem modelo/serial para associar a foto.'); return; }
    _oltFecharConfigs('oltImgOv');
    var ov=document.createElement('div'); ov.id='oltImgOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483200; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.55);';
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; width:min(96vw,420px); max-height:90vh; display:flex; flex-direction:column; box-shadow:0 24px 70px rgba(0,0,0,0.55);">'+
        '<div style="flex:0 0 auto; padding:14px 16px; background:var(--grad-brand,linear-gradient(135deg,#9e2a3b 0%,#b23c4d 55%,#7f2230 100%)); box-shadow:inset 0 1px 0 rgba(255,255,255,.22), inset 0 -2px 5px rgba(0,0,0,.22); border-radius:12px 12px 0 0; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-image" style="color:#fff;"></i><div style="flex:1 1 auto; font-weight:800; color:#fff; font-size:13px;">Foto do modelo — '+_oltEsc(chave)+'</div><button onclick="document.getElementById(\'oltImgOv\').remove()" style="cursor:pointer; width:30px; height:30px; border-radius:7px; border:1px solid rgba(255,255,255,0.5); background:transparent; color:#fff;"><i class="fa-solid fa-xmark"></i></button></div>'+
        '<div style="flex:1 1 auto; overflow:auto; padding:14px 16px; text-align:center;">'+
          '<div id="oltImgPrev" style="min-height:120px; display:flex; align-items:center; justify-content:center; border:1px dashed '+OLTC.line+'; border-radius:10px; padding:8px; margin-bottom:12px; background:'+OLTC.bg2+';"><i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+';"></i></div>'+
          '<input type="file" id="oltImgFile" accept="image/png,image/jpeg,.png,.jpg,.jpeg" style="display:none;" onchange="_oltImgPreview(this)">'+
          '<button onclick="document.getElementById(\'oltImgFile\').click()" style="cursor:pointer; padding:9px 16px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800;"><i class="fa-solid fa-upload"></i> Escolher imagem</button>'+
          '<div id="oltImgResult" style="font-size:11.5px; color:'+OLTC.mut+'; margin-top:8px;"></div>'+
        '</div>'+
        '<div style="flex:0 0 auto; padding:12px 16px; border-top:1px solid '+OLTC.line+'; display:flex; gap:8px; justify-content:space-between;">'+
          '<button onclick="_oltImgRemover(\''+encodeURIComponent(chave)+'\')" style="cursor:pointer; padding:9px 14px; border-radius:8px; border:1px solid '+OLTC.red+'; background:transparent; color:'+OLTC.red+'; font-weight:800;"><i class="fa-solid fa-trash"></i> Remover</button>'+
          '<button id="oltImgSalvar" onclick="_oltImgSalvar(\''+encodeURIComponent(chave)+'\')" disabled style="cursor:pointer; padding:9px 18px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; opacity:.5;"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>'+
        '</div>'+
    '</div>';
    document.body.appendChild(ov);
    // carrega a imagem atual (se houver)
    fetch('olt_huawei.php?acao=modelo_img_get&chave='+encodeURIComponent(chave), null, false).then(function(r){return r.json();}).then(function(d){ var p=document.getElementById('oltImgPrev'); if(!p) return; if(d&&d.img){ p.innerHTML='<img src="'+d.img+'" style="max-width:100%; max-height:220px; border-radius:8px;">'; } else { p.innerHTML='<span style="color:'+OLTC.mut+'; font-size:12px;">Nenhuma foto anexada.</span>'; } }).catch(function(){});
}
function _oltImgPreview(input){ var f=input&&input.files&&input.files[0]; var r=document.getElementById('oltImgResult'); if(!f) return;
    if(!/image\/(png|jpe?g)/i.test(f.type)){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Só PNG ou JPEG.</span>'; input.value=''; return; }
    if(f.size>1200000){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Imagem muito grande (máx. ~1,2 MB). Reduza e tente de novo.</span>'; input.value=''; return; }
    var fr=new FileReader(); fr.onload=function(){ window._oltImgTmp=fr.result; var p=document.getElementById('oltImgPrev'); if(p) p.innerHTML='<img src="'+fr.result+'" style="max-width:100%; max-height:220px; border-radius:8px;">'; var b=document.getElementById('oltImgSalvar'); if(b){ b.disabled=false; b.style.opacity='1'; } if(r) r.textContent=''; }; fr.readAsDataURL(f);
}
function _oltImgSalvar(keyEnc){ var chave=decodeURIComponent(keyEnc); var r=document.getElementById('oltImgResult'); if(!window._oltImgTmp){ return; }
    if(r) r.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando…';
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=modelo_img_set&chave='+encodeURIComponent(chave)+'&img='+encodeURIComponent(window._oltImgTmp)})
      .then(function(rr){return rr.json();}).then(function(d){ if(d&&d.saved){ window._oltModeloImgCache=window._oltModeloImgCache||{}; window._oltModeloImgCache[chave.toUpperCase()]=window._oltImgTmp; window._oltImgTmp=null; window._oltModeloImgKeys=window._oltModeloImgKeys||[]; if(window._oltModeloImgKeys.indexOf(chave.toUpperCase())<0) window._oltModeloImgKeys.push(chave.toUpperCase()); if(r) r.innerHTML='<span style="color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Foto salva.</span>'; if(typeof oltRenderLista==='function') oltRenderLista(); }
        else { if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Falha ao salvar (formato/tamanho ou permissão da pasta).</span>'; } }).catch(function(){ if(r) r.innerHTML='<span style="color:'+OLTC.red+';">Erro ao salvar.</span>'; });
}
function _oltImgRemover(keyEnc){ var chave=decodeURIComponent(keyEnc); var r=document.getElementById('oltImgResult'); if(!confirm('Remover a foto do modelo '+chave+'?')) return;
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=modelo_img_del&chave='+encodeURIComponent(chave)})
      .then(function(rr){return rr.json();}).then(function(d){ if(d&&d.saved){ window._oltModeloImgKeys=(window._oltModeloImgKeys||[]).filter(function(k){ return k!==chave.toUpperCase(); }); if(window._oltModeloImgCache) delete window._oltModeloImgCache[chave.toUpperCase()]; var p=document.getElementById('oltImgPrev'); if(p) p.innerHTML='<span style="color:'+OLTC.mut+'; font-size:12px;">Nenhuma foto anexada.</span>'; if(r) r.innerHTML='<span style="color:'+OLTC.grn+';">Removida.</span>'; if(typeof oltRenderLista==='function') oltRenderLista(); } }).catch(function(){});
}
// Gerenciar PLACAS — apelido por placa (item 9).
// Desativa/ativa TODAS as ONTs de uma PORTA, de uma PLACA, ou de TODAS as placas.
// Operação de alto impacto (corta serviço) -> confirmação dupla + nível 2.
// AJUSTE VISUAL (sem mexer em função): após aplicar Ativar/Desativar, o botão da ação
// aplicada fica indisponível e o par volta a ficar disponível — evita confusão de estado.
// Acha os botões pelo próprio onclick, então não precisa mexer no HTML deles.
function _oltPonVisual(escopo, alvo, op){
    if(op!=='activate' && op!=='deactivate') return;   // Reiniciar não muda estado
    try{
        var tag="'"+escopo+"','"+alvo+"'";   // ex.: 'placa','5' · 'porta','0/5/3' · 'todas',''
        document.querySelectorAll('button[onclick*="_oltPonControl"]').forEach(function(b){
            var oc=b.getAttribute('onclick')||''; if(oc.indexOf(tag)<0) return;
            if(oc.indexOf("'activate'")>-1){ var a=(op==='activate'); b.disabled=a; b.style.opacity=a?'0.45':'1'; b.style.cursor=a?'default':'pointer'; }
            if(oc.indexOf("'deactivate'")>-1){ var d=(op==='deactivate'); b.disabled=d; b.style.opacity=d?'0.45':'1'; b.style.cursor=d?'default':'pointer'; }
        });
    }catch(e){}
}
function _oltPonControl(escopo, alvo, op){
    var _rot={deactivate:'Desativar', activate:'Ativar', reboot:'Reiniciar'};
    if(!_oltExigeNivel(2, (_rot[op]||'Controlar')+' PON')) return;
    var L=window._oltLista||[];
    var acao = (op==='deactivate') ? 'DESATIVAR' : (op==='reboot' ? 'REINICIAR' : 'ATIVAR');
    var corta = (op==='deactivate');
    var alvoTxt='', qtd=0, body=null;

    if(escopo==='porta'){
        alvoTxt='a porta PON '+alvo;
        qtd=L.filter(function(o){ return (o.fsp||'')===alvo; }).length;
        body='op='+op+'&fsp='+encodeURIComponent(alvo);
    } else if(escopo==='placa'){
        alvoTxt='TODA a placa '+alvo;
        var portas=[];
        L.forEach(function(o){ var p=(o.fsp||'').split('/'); if(p[1]===String(alvo)){ if(portas.indexOf(p[2])<0) portas.push(p[2]); qtd++; } });
        body='op='+op+'&slot='+encodeURIComponent(alvo)+'&portas='+encodeURIComponent(portas.join(','));
    } else { // todas
        alvoTxt='TODAS as placas da OLT';
        qtd=L.length;
        var slots={};
        L.forEach(function(o){ var p=(o.fsp||'').split('/'); if(p[1]!=null&&p[1]!==''){ (slots[p[1]]=slots[p[1]]||[]); if(slots[p[1]].indexOf(p[2])<0) slots[p[1]].push(p[2]); } });
    }

    var complemento = corta ? '.\n\nISSO CORTA O SERVIÇO desses clientes imediatamente.'
                    : (op==='reboot' ? '.\n\nAs ONTs vão reiniciar (o serviço cai por ~1-2 min e volta).' : ' (reativa o serviço).');
    var aviso=acao+' vai afetar '+alvoTxt+' — cerca de '+qtd+' ONU/ONT'+complemento;
    if(!confirm(aviso+'\n\nDeseja continuar?')) return;
    if(corta){
        var c=prompt('Confirmação final: digite DESATIVAR para '+acao.toLowerCase()+' '+alvoTxt+'.');
        if(String(c||'').trim().toUpperCase()!=='DESATIVAR') return;
    }

    // "todas": dispara placa por placa em sequência.
    if(escopo==='todas'){
        var slots2={};
        L.forEach(function(o){ var p=(o.fsp||'').split('/'); if(p[1]!=null&&p[1]!==''){ (slots2[p[1]]=slots2[p[1]]||[]); if(slots2[p[1]].indexOf(p[2])<0) slots2[p[1]].push(p[2]); } });
        var keys=Object.keys(slots2); var i=0; var oks=0;
        (function next(){
            if(i>=keys.length){ _oltPonVisual('todas','',op); alert(acao+' concluído em '+oks+'/'+keys.length+' placa(s). Atualize a lista (Refresh).'); return; }
            var sl=keys[i++];
            oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=pon_control&op='+op+'&slot='+encodeURIComponent(sl)+'&portas='+encodeURIComponent(slots2[sl].join(','))}, true, 200000)
              .then(function(r){return r.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return; if(d&&d.sucesso) oks++; next(); })
              .catch(function(){ next(); });
        })();
        return;
    }

    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=pon_control&'+body}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d&&d.sucesso){ _oltPonVisual(escopo, alvo, op); alert(acao+' aplicado em '+alvoTxt+'.\nAtualize a lista (Refresh) para ver o novo estado.'); }
        else { alert('A OLT retornou erro:\n'+((d&&d.saida)||'sem detalhe')); }
      }).catch(function(){ alert('Erro de comunicação ao '+acao.toLowerCase()+'.'); });
}
// Estado de um conjunto de ONUs: 'deactivated' se TODAS estão desativadas, senão 'active'.
function _oltEstadoDe(onus){ if(!onus||!onus.length) return 'active'; var des=0; onus.forEach(function(o){ if((o.estado||'').toLowerCase()==='deactivated') des++; }); return des===onus.length ? 'deactivated' : 'active'; }
// Botões Reiniciar/Desativar/Ativar já com o ESTADO ATUAL: o botão da situação vigente
// fica apagado (disabled) para não confundir. small=true reduz ícone/fonte (Portas PON).
function _oltAtivDesBtns(escopo, alvo, est, small){
    var fs=small?'10px':'11px', pd=small?'5px 8px':'6px 10px', ae=_oltEsc(alvo);
    var deDis=(est==='deactivated'), atDis=(est==='active');
    return '<button onclick="_oltPonControl(\''+escopo+'\',\''+ae+'\',\'reboot\')" title="Reiniciar" style="cursor:pointer; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.amb+'; background:transparent; color:'+OLTC.amb+'; font-weight:800; font-size:'+fs+';"><i class="fa-solid fa-rotate-right"></i> Reiniciar</button>'+
        '<button'+(deDis?' disabled':'')+' onclick="_oltPonControl(\''+escopo+'\',\''+ae+'\',\'deactivate\')" title="Desativar" style="cursor:'+(deDis?'default':'pointer')+'; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.red+'; background:transparent; color:'+OLTC.red+'; font-weight:800; font-size:'+fs+'; opacity:'+(deDis?'0.4':'1')+';"><i class="fa-solid fa-power-off"></i> Desativar</button>'+
        '<button'+(atDis?' disabled':'')+' onclick="_oltPonControl(\''+escopo+'\',\''+ae+'\',\'activate\')" title="Ativar" style="cursor:'+(atDis?'default':'pointer')+'; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.grn+'; background:transparent; color:'+OLTC.grn+'; font-weight:800; font-size:'+fs+'; opacity:'+(atDis?'0.4':'1')+';"><i class="fa-solid fa-play"></i> Ativar</button>';
}
// Detecta as placas GPON reais da OLT (display board 0). Cacheia em window._oltPlacasDet e
// amplia OLT_SLOTS (união) pra que placas NOVAS também entrem na varredura — sem hardcode.
function _oltPlacasDetectar(cb, force){
    oltFetch('olt_huawei.php?acao=placas_detect'+(force?'&force=1':''), null, true)
      .then(function(r){return r.json();}).then(function(d){
        if(d && d.placas && d.placas.length){ window._oltPlacasDet=d.placas; window._oltPlacasDetTs=Date.now();
            // Só as placas GPON entram na varredura de ONUs (as de controle/uplink não têm cliente).
            try{ var det=d.placas.filter(function(b){return b.gpon;}).map(function(b){return +b.slot;}); var u={}; (OLT_SLOTS||[]).concat(det).forEach(function(s){ u[s]=1; }); OLT_SLOTS=Object.keys(u).map(Number).sort(function(a,b){return a-b;}); }catch(e){}
        }
        if(cb) cb(window._oltPlacasDet||[]);
      }).catch(function(){ if(cb) cb(window._oltPlacasDet||[]); });
}
// Cria uma VLAN DE VERDADE na OLT (vlan <id> smart). O nome fica salvo local. defVlan = sugestão.
function oltCriarVlan(defVlan){
    var v=prompt('Criar VLAN na OLT — número (1 a 4094):', defVlan||''); if(v===null) return;
    v=(''+v).replace(/[^0-9]/g,''); var n=parseInt(v,10);
    if(!n || n<1 || n>4094){ alert('VLAN inválida. Use um número de 1 a 4094.'); return; }
    var nome=prompt('Nome/descrição da VLAN '+n+' (opcional — fica salvo local):','')||'';
    if(!confirm('Criar a VLAN '+n+' na OLT agora?\n\n(É seguro: criar VLAN não derruba clientes.)')) return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=vlan_criar&vlan='+encodeURIComponent(n)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.criada){ if(nome.trim()!=='') oltVlanNomeSalvar(n, nome.trim());
            window._oltVlansOlt=null; // força recarregar a lista de VLANs da OLT
            alert('VLAN '+n+(d.ja_existia?' já existia na OLT.':' criada na OLT com sucesso.'));
            var m=document.querySelector('.oltMSWin'); if(m){ var t=(m.getAttribute('data-geokey')||''); if(t.indexOf('VLAN')>-1 && typeof oltGerenciarVlans==='function'){ m.remove(); oltGerenciarVlans(); } else if(typeof oltGerenciarPlacas==='function'){ m.remove(); oltGerenciarPlacas(); } }
        } else { alert('A OLT recusou a criação da VLAN '+n+':\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,500)); }
      }).catch(function(){ alert('Erro de comunicação ao criar a VLAN.'); });
}
// Exclui uma VLAN DE VERDADE da OLT (undo vlan <id>). Se estiver em uso, a OLT recusa (não força).
function oltExcluirVlan(id){
    id=parseInt(id,10); if(!id) return;
    if(!confirm('EXCLUIR a VLAN '+id+' da OLT?\n\nSe ela estiver em uso por algum cliente (service-port), a OLT recusa e nada é removido.')) return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=vlan_excluir&vlan='+id}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.excluida){ oltVlanNomeSalvar(id,''); window._oltVlansOlt=null;
            alert('VLAN '+id+' removida da OLT.');
            var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarVlans(); }
        } else if(d && d.em_uso){ alert('VLAN '+id+' está EM USO por clientes (service-port) — a OLT não deixou remover.'); }
        else { alert('Não foi possível remover a VLAN '+id+':\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,400)); }
      }).catch(function(){ alert('Erro de comunicação ao excluir a VLAN.'); });
}
function oltGerenciarPlacas(){
    var L=window._oltLista||[]; var set={};
    L.forEach(function(o){ var p=(o.fsp||'').split('/'); if(p[1]!=null&&p[1]!=='') set[p[1]]=(set[p[1]]||0)+1; });
    // Placas GPON DETECTADAS na OLT entram mesmo sem ONU (placa nova recém-instalada).
    var det=window._oltPlacasDet||[]; var bySlot={}; det.forEach(function(b){ bySlot[String(b.slot)]=b; if(set[String(b.slot)]==null) set[String(b.slot)]=0; });
    var s=_oltInSt();
    var det=(window._oltPlacasDet||[]).slice().sort(function(a,b){ return (+a.slot)-(+b.slot); });
    var atual=window._oltPlacasDetTs?new Date(window._oltPlacasDetTs).toLocaleString('pt-BR'):'agora';
    var sw=(window._oltStatus&&window._oltStatus.versao)?window._oltStatus.versao:'';
    var th=function(t,al){ return '<th style="text-align:'+(al||'center')+'; padding:9px 8px; font-size:10px; text-transform:uppercase; letter-spacing:.3px; color:'+OLTC.mut+'; border-bottom:2px solid '+OLTC.line+'; white-space:nowrap;">'+t+'</th>'; };
    var td=function(c,ex){ return '<td style="padding:9px 8px; font-size:12px; color:'+OLTC.txt+'; border-bottom:1px solid '+OLTC.line+'33; text-align:center; vertical-align:middle; '+(ex||'')+'">'+c+'</td>'; };
    // Trio de botões IGUAL em toda placa (Reiniciar/Desativar/Ativar). GPON opera nas ONUs;
    // controle/uplink operam nas PORTAS da placa via SNMP (ifAdminStatus). Mesma aparência.
    // Trio p/ controle/uplink com A MESMA lógica de habilitar/desabilitar das GPON:
    // se a placa está ATIVA, "Ativar" fica apagado; se DESATIVADA, "Desativar" fica apagado.
    var trioNaoGpon=function(sl,tipo,main,est){ var ae=_oltEsc(sl), te=_oltEsc(tipo), fs='10px', pd='5px 8px';
        var deDis=(est==='deactivated'), atDis=(est==='active');
        return '<button onclick="oltReiniciarPlaca(\''+ae+'\',\''+te+'\','+(main?'1':'0')+')" title="Reiniciar (reset board)" style="cursor:pointer; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.amb+'; background:transparent; color:'+OLTC.amb+'; font-weight:800; font-size:'+fs+';"><i class="fa-solid fa-rotate-right"></i> Reiniciar</button>'+
            '<button'+(deDis?' disabled':'')+' onclick="_oltPlacaEstado(\''+ae+'\',0,\''+te+'\','+(main?'1':'0')+')" title="Desativar todas as portas da placa" style="cursor:'+(deDis?'default':'pointer')+'; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.red+'; background:transparent; color:'+OLTC.red+'; font-weight:800; font-size:'+fs+'; opacity:'+(deDis?'0.4':'1')+';"><i class="fa-solid fa-power-off"></i> Desativar</button>'+
            '<button'+(atDis?' disabled':'')+' onclick="_oltPlacaEstado(\''+ae+'\',1,\''+te+'\','+(main?'1':'0')+')" title="Ativar todas as portas da placa" style="cursor:'+(atDis?'default':'pointer')+'; flex:0 0 auto; padding:'+pd+'; border-radius:7px; border:1px solid '+OLTC.grn+'; background:transparent; color:'+OLTC.grn+'; font-weight:800; font-size:'+fs+'; opacity:'+(atDis?'0.4':'1')+';"><i class="fa-solid fa-play"></i> Ativar</button>'; };
    var rows=det.map(function(bd){ var sl=bd.slot; var ctrl=/SCU/.test(bd.tipo||''); var isMain=(bd.funcao==='Main'); var btns;
        if(bd.gpon){ var est=_oltEstadoDe(L.filter(function(o){ return (o.fsp||'').split('/')[1]===String(sl); }));
            // GPON: Reiniciar/Desativar/Ativar operam nas ONUs da placa (dado REAL).
            btns=_oltAtivDesBtns('placa', sl, est, true); }
        else {
            // Controle/Uplink: MESMO trio e MESMA lógica. Placa "Normal/Active/Standby" = ativa.
            var estNG=(/normal|active|up|standby/i.test(bd.estado||'')?'active':'deactivated');
            btns=trioNaoGpon(sl,bd.tipo,isMain,estNG); }
        var acao='<div style="display:flex; gap:5px; justify-content:center; flex-wrap:wrap;">'+btns+'</div>';
        return '<tr>'+
            td('<b style="color:'+OLTC.acc+'; font-size:13px;">'+_oltEsc(sl)+'</b>')+
            td('<b>'+_oltEsc(bd.tipo||'')+'</b>')+ td(_oltEsc(bd.tipo||''))+
            td(bd.portas!==''?_oltEsc(''+bd.portas):'—')+
            td(ctrl&&sw?_oltEsc(sw):'—','color:'+OLTC.mut+'; font-size:11px;')+
            td('<span style="color:'+(/normal/i.test(bd.estado||'')?OLTC.grn:OLTC.amb)+'; font-weight:700;">'+_oltEsc(bd.estado||'Normal')+'</span>')+
            td(bd.funcao?('<span style="font-weight:800; color:'+(bd.funcao==='Main'?OLTC.grn:OLTC.mut)+';">'+_oltEsc(bd.funcao)+'</span>'):'—')+
            td('<span style="font-size:10px; color:'+OLTC.mut+';">'+_oltEsc(atual)+'</span>')+
            td(acao)+
        '</tr>';
    }).join('');
    var tabela=det.length?('<div style="overflow-x:auto;"><table style="width:100%; border-collapse:collapse; min-width:680px;"><thead><tr>'+th('Slot')+th('Tipo')+th('Tipo real')+th('Portas')+th('SW')+th('Status')+th('Função')+th('Informações atualizadas')+th('Ações')+'</tr></thead><tbody>'+rows+'</tbody></table></div>'):'<div style="color:'+OLTC.mut+'; padding:10px;">Nenhuma placa detectada — clique em "Detectar/Atualizar placas".</div>';
    var gpon=det.filter(function(b){return b.gpon;});
    var apelidos=gpon.length?('<div style="margin-top:12px; padding-top:10px; border-top:1px solid '+OLTC.line+';"><div style="font-size:9px; font-weight:800; text-transform:uppercase; color:'+OLTC.mut+'; margin-bottom:6px;">Apelido das placas GPON</div>'+gpon.map(function(b){ return '<div style="display:flex; gap:8px; align-items:center; padding:3px 0;"><span style="flex:0 0 66px; font-weight:800; color:'+OLTC.acc+';">Placa '+_oltEsc(b.slot)+'</span><input value="'+_oltEsc(_oltPlacaNome(b.slot))+'" onchange="_oltMetaSet(\'placa\',\''+_oltEsc(b.slot)+'\',this.value.trim())" placeholder="apelido (ex.: Centro)" style="'+s+' flex:1 1 auto; max-width:320px;"></div>'; }).join('')+'</div>'):'';
    var topo='<div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom:10px;">'+
        '<button onclick="_oltPlacasDetectar(function(){ var m=document.querySelector(\'.oltMSWin\'); if(m){ m.remove(); oltGerenciarPlacas(); } }, true)" style="cursor:pointer; padding:7px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-arrows-rotate"></i> Detectar / Atualizar placas</button>'+
        '<button onclick="oltCriarVlan()" style="cursor:pointer; padding:7px 12px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800; font-size:11px;"><i class="fa-solid fa-plus"></i> Criar VLAN na OLT</button>'+
    '</div>';
    _oltModalSimples('fa-server','Placas OLT', topo+tabela+apelidos);
    if(!window._oltPlacasDet){ _oltPlacasDetectar(function(placas){ if(placas&&placas.length){ var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarPlacas(); } } }); }
}
// Ativa/Desativa TODAS as portas de uma placa via SNMP (ifAdminStatus). Confirmação forte;
// EXTRA para a placa de controle ATIVA (Main), que pode isolar a gerência da OLT.
function _oltPlacaEstado(sl, on, tipo, isMain){
    var acao=on?'ATIVAR':'DESATIVAR';
    var av=acao+' TODAS as portas da placa '+sl+' ('+tipo+')?';
    if(!on){ av+='\n\n⚠️ Desativar derruba TODO o tráfego que passa por esta placa.'; }
    if((isMain==1||isMain==='1')){ av+='\n\n🚨 É a placa de CONTROLE ATIVA (Main) — pode ISOLAR a gerência/derrubar a OLT.'; }
    if(!confirm(av+'\n\nContinuar?')) return;
    if(!on){ var c=prompt('Confirmação final: digite DESATIVAR para desligar as portas da placa '+sl+'.'); if(String(c||'').trim().toUpperCase()!=='DESATIVAR') return; }
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=placa_estado&slot='+encodeURIComponent(sl)+'&on='+(on?1:0)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.ok){ alert('OK — placa '+sl+' '+(on?'ativada':'desativada')+' ('+(d.portas||0)+' portas'+(d.erros?(', '+d.erros+' com erro'):'')+').'); var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarPlacas(); } }
        else { alert((d&&d.msg)?d.msg:'A OLT/SNMP retornou erro.'); }
      }).catch(function(){ alert('Erro de comunicação.'); });
}
// Reinicia uma placa (reset board) — pede confirmação FORTE (a Main/controle derruba a OLT).
function oltReiniciarPlaca(sl, tipo, isMain){
    var av='Reiniciar a placa '+sl+' ('+tipo+')?';
    if(isMain==1||isMain==='1'){ av+='\n\n⚠️ ATENÇÃO: é a placa de CONTROLE ATIVA (Main). Reiniciar pode DERRUBAR A OLT INTEIRA.'; }
    if(!confirm(av+'\n\nContinuar?')) return;
    var c=prompt('Confirmação final: digite REINICIAR para reiniciar a placa '+sl+'.'); if(String(c||'').trim().toUpperCase()!=='REINICIAR') return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=placa_reset&slot='+encodeURIComponent(sl)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){ if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return; alert(d&&d.ok?('Reinício enviado à placa '+sl+'.'):('A OLT retornou:\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,300))); }).catch(function(){ alert('Erro de comunicação.'); });
}
// ===== GERENCIAR UPLINK — portas ethernet de uplink + VLANs que saem por cada uma =====
function oltGerenciarUplink(){
    _oltModalSimples('fa-network-wired','Gerenciar Uplink — portas ethernet (dados reais da OLT)',
      '<div id="oltUpkBody" style="text-align:center; color:'+OLTC.mut+'; padding:16px;">'+_oltSpinner('Lendo portas de uplink da OLT (display board)...')+'</div>');
    var _to=setTimeout(function(){ var b=document.getElementById('oltUpkBody'); if(b&&b.innerHTML.indexOf('spinner')>-1) b.innerHTML='<div style="color:'+OLTC.amb+'; padding:10px; line-height:1.6;">O Telnet da OLT está ocupado agora. Feche e abra de novo em ~1 min (a leitura fica em cache e abre na hora depois).</div>'; },35000);
    var _fq=window._oltUpkForce?'&force=1':''; window._oltUpkForce=0;
    ((_fq||typeof _oltFetchDireto!=='function')?oltFetch('olt_huawei.php?acao=uplink_listar'+_fq, null, false):_oltFetchDireto('olt_huawei.php?acao=uplink_listar',60000)).then(function(r){return r.json();}).then(function(d){ clearTimeout(_to);
        var b=document.getElementById('oltUpkBody'); if(!b) return;
        var ps=(d&&d.portas)||[];
        if(!ps.length){ b.innerHTML='<div style="color:'+OLTC.mut+'; padding:10px;">Nenhuma porta de uplink encontrada.</div>'; return; }
        b.style.textAlign='left'; b.style.padding='0';
        var th=function(t,al){ return '<th style="text-align:'+(al||'left')+'; padding:9px 8px; font-size:10.5px; text-transform:uppercase; letter-spacing:.3px; color:'+OLTC.mut+'; border-bottom:2px solid '+OLTC.line+'; white-space:nowrap;">'+t+'</th>'; };
        var td=function(c,ex){ return '<td style="padding:9px 8px; border-bottom:1px solid '+OLTC.line+'33; vertical-align:middle; '+(ex||'')+'">'+c+'</td>'; };
        // 30/10/2026: portas agrupadas por PLACA (estado da placa + quantas online/offline); offline esmaecida, online em verde.
        var _placasInfo={}; (d.placas||[]).forEach(function(x){ _placasInfo[String(x.slot)]=x; });
        var _porSlot={}; ps.forEach(function(p){ var sl=String(p.fsp).split('/')[1]; if(!_porSlot[sl]) _porSlot[sl]={on:0,off:0}; if(p.link==='online') _porSlot[sl].on++; else _porSlot[sl].off++; });
        var _nOn=0,_nOff=0; ps.forEach(function(p){ if(p.link==='online') _nOn++; else _nOff++; });
        var _slotAnt=null;
        var _cabPlaca=function(sl,pi,c){ var est=String(pi.estado||'').replace(/_/g,' '); var ok=/normal|active/i.test(est); var cor=ok?OLTC.grn:OLTC.amb;
            return '<tr><td colspan="9" style="padding:12px 8px 6px; border-bottom:2px solid '+OLTC.line+'; font-size:12px; font-weight:800; color:'+OLTC.ink+';"><i class="fa-solid fa-server" style="color:'+OLTC.acc+';"></i> Placa '+_oltEsc(sl)+(pi.tipo?(' · '+_oltEsc(pi.tipo)):'')+' · <span style="color:'+cor+';">'+_oltEsc(est||'—')+'</span>'+(c?(' &nbsp;—&nbsp; <span style="color:'+OLTC.grn+';">'+c.on+' online</span> · <span style="color:'+OLTC.mut+';">'+c.off+' offline</span>'):' &nbsp;—&nbsp; <span style="color:'+OLTC.mut+';">placa reserva, sem portas em uso</span>')+'</td></tr>'; };
        var trs=ps.map(function(p){
            var _sl=String(p.fsp).split('/')[1]; var _cab=''; if(_sl!==_slotAnt){ _slotAnt=_sl; _cab=_cabPlaca(_sl,_placasInfo[_sl]||{},_porSlot[_sl]); }
            var chips=(p.vlans&&p.vlans.length)?p.vlans.map(function(v){ return '<span style="display:inline-block; font-size:11.5px; font-weight:800; color:'+OLTC.acc+'; background:'+OLTC.acc+'1f; border-radius:6px; padding:2px 8px; margin:1px 3px 1px 0;">'+_oltEsc(v)+'</span>'; }).join(''):'<span style="font-size:12px; color:'+OLTC.mut+';">—</span>';
            var fe=_oltEsc(p.fsp);
            window._oltUpkMap=window._oltUpkMap||{}; window._oltUpkMap[p.fsp]=(p.vlans||[]).join(',');
            var up=(p.link==='online'); var stCor=up?OLTC.grn:OLTC.mut;
            var optCor=(p.optic&&/normal/i.test(p.optic))?OLTC.grn:OLTC.mut;
            var hab=(p.admin==='Habilitado'); var admCor=hab?OLTC.grn:OLTC.redf;
            var bt=function(oc,cor,ico,tt){ return '<button onclick="'+oc+'" title="'+tt+'" style="cursor:pointer; width:32px; height:30px; border-radius:7px; border:1px solid '+cor+'; background:transparent; color:'+cor+'; font-weight:800; font-size:13px;"><i class="fa-solid '+ico+'"></i></button>'; };
            return _cab+'<tr style="'+(up?'':'opacity:.62;')+'">'+
                td('<span style="font-weight:800; color:'+OLTC.ink+'; font-size:13px; white-space:nowrap;"><i class="fa-solid fa-ethernet" style="color:'+(up?OLTC.grn:OLTC.acc)+';"></i> '+_oltEsc(p.nome)+'</span>')+
                td('<input value="'+_oltEsc(_oltPortaNome(p.fsp))+'" onchange="_oltMetaSet(\'porta\',\''+_oltEsc(p.fsp)+'\',this.value.trim())" placeholder="apelido (ex.: operadora)" title="Apelido da porta (só no WellSystem)" style="'+_oltInSt()+' width:150px; box-sizing:border-box;">')+
                td('<span style="display:inline-block; font-size:11.5px; font-weight:800; color:'+stCor+'; background:'+stCor+'1f; border-radius:20px; padding:3px 10px;">'+(up?('● ONLINE · '+_oltEsc(p.vel||'')):'○ OFFLINE')+'</span>','text-align:center;')+
                td('<span style="font-size:12.5px; color:'+OLTC.txt+';">'+_oltEsc(p.neg||'—')+'</span>')+
                td('<span style="font-size:12.5px; color:'+OLTC.mut+';">'+_oltEsc(p.duplex||'—')+'</span>','text-align:center;')+
                td('<span style="font-size:12.5px; font-weight:700; color:'+optCor+';">'+_oltEsc(p.optic||'—')+'</span>','text-align:center;')+
                td('<span style="font-size:12px; font-weight:800; color:'+admCor+';">'+_oltEsc(p.admin||'—')+'</span>','text-align:center;')+
                td(chips)+
                td('<div style="display:flex; gap:5px; justify-content:center;">'+
                    bt('oltUplinkVlan(\''+fe+'\',\'add\')',OLTC.acc,'fa-plus','Adicionar VLAN')+
                    bt('oltUplinkEditar(\''+fe+'\')',OLTC.amb,'fa-pen','Editar VLANs (trocar)')+
                    bt('oltUplinkVlan(\''+fe+'\',\'del\')',OLTC.redf,'fa-minus','Remover VLAN')+
                    (hab?bt('oltUplinkEstado(\''+fe+'\',0)',OLTC.red,'fa-power-off','Desativar porta'):bt('oltUplinkEstado(\''+fe+'\',1)',OLTC.grn,'fa-play','Ativar porta'))+
                    bt('oltReiniciarPortaUplink(\''+fe+'\')',OLTC.amb,'fa-rotate-right','Reiniciar (bounce: desativa e reativa)')+
                '</div>','text-align:center; white-space:nowrap;')+
            '</tr>';
        }).join('');
        var _reservas=(d.placas||[]).filter(function(x){ return !_porSlot[String(x.slot)]; }).map(function(x){ return _cabPlaca(String(x.slot),x,null); }).join('');
        var topo='<div style="display:flex; justify-content:space-between; align-items:center; gap:8px; padding:8px 8px; flex-wrap:wrap;"><span style="font-size:12px; font-weight:800; color:'+OLTC.ink+';"><span style="color:'+OLTC.grn+';">● '+_nOn+' online</span> &nbsp;·&nbsp; <span style="color:'+OLTC.mut+';">○ '+_nOff+' offline</span> <span style="font-weight:400; color:'+OLTC.mut+';">&nbsp;'+(d.cache?'· do cache':'· leitura nova')+'</span></span><button onclick="var m=document.querySelector(\'.oltMSWin\'); if(m)m.remove(); window._oltUpkForce=1; oltGerenciarUplink();" style="cursor:pointer; padding:6px 12px; border-radius:8px; border:1px solid '+OLTC.acc+'; background:transparent; color:'+OLTC.acc+'; font-weight:800; font-size:11px;"><i class="fa-solid fa-arrows-rotate"></i> Atualizar</button></div>';
        b.innerHTML=topo+'<div style="overflow-x:auto;"><table style="width:100%; border-collapse:collapse; min-width:900px;"><thead><tr>'+th('Porta')+th('Apelido')+th('Status','center')+th('Negociação')+th('Duplex','center')+th('Óptico','center')+th('Admin','center')+th('VLANs marcadas')+th('Ações','center')+'</tr></thead><tbody>'+trs+_reservas+'</tbody></table></div>';
    }).catch(function(){ clearTimeout(_to); var b=document.getElementById('oltUpkBody'); if(b) b.innerHTML='<div style="color:'+OLTC.red+';">Falha ao ler as portas de uplink.</div>'; });
}
// Ativa/desativa uma porta de uplink (SNMP SET — não usa Telnet). Confirmação forte (pode cortar tráfego).
function oltUplinkEstado(fsp, on){
    var acao=on?'ATIVAR':'DESATIVAR';
    if(!confirm(acao+' a porta de uplink ethernet'+fsp+'?\n\n⚠️ Desativar uma porta de tronco pode DERRUBAR o tráfego que passa por ela.')) return;
    if(!on){ var c=prompt('Confirmação final: digite DESATIVAR para desligar a porta ethernet'+fsp+'.'); if(String(c||'').trim().toUpperCase()!=='DESATIVAR') return; }
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=uplink_estado&fsp='+encodeURIComponent(fsp)+'&on='+(on?1:0)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.ok){ alert('OK — porta ethernet'+fsp+' '+(on?'ativada':'desativada')+'.'); window._oltUpkForce=1; var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarUplink(); } }
        else { alert((d&&d.msg)?d.msg:('A OLT/SNMP retornou:\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,300))); }
      }).catch(function(){ alert('Erro de comunicação.'); });
}
// Reinicia (bounce) a porta de uplink: desativa e reativa via SNMP (admin down -> up).
function oltReiniciarPortaUplink(fsp){
    if(!confirm('REINICIAR a porta de uplink ethernet'+fsp+'?\n\n⚠️ A porta é DESATIVADA e reativada em seguida — o tráfego que passa por ela cai por alguns segundos.')) return;
    var c=prompt('Confirmação final: digite REINICIAR para reiniciar a porta ethernet'+fsp+'.'); if(String(c||'').trim().toUpperCase()!=='REINICIAR') return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=uplink_estado&fsp='+encodeURIComponent(fsp)+'&on=0'}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(!(d&&d.ok)){ alert('Falha ao desativar:\n\n'+(''+((d&&d.saida)||(d&&d.msg)||'sem detalhe')).slice(0,300)); return; }
        setTimeout(function(){
          oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=uplink_estado&fsp='+encodeURIComponent(fsp)+'&on=1'}, true, 200000)
            .then(function(r){return r.json();}).then(function(d2){
              if(d2 && d2.ok){ alert('OK — porta ethernet'+fsp+' reiniciada (desativada e reativada).'); }
              else { alert('⚠️ A porta foi DESATIVADA mas falhou ao reativar. Reative manualmente!\n\n'+(''+((d2&&d2.saida)||(d2&&d2.msg)||'sem detalhe')).slice(0,300)); }
              window._oltUpkForce=1; var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarUplink(); }
            }).catch(function(){ alert('⚠️ A porta foi desativada mas houve erro ao reativar. Reative manualmente!'); });
        }, 2500);
      }).catch(function(){ alert('Erro de comunicação.'); });
}
// EDITAR as VLANs de uma porta de uplink (30/10/2026): mostra a lista atual, o operador troca/ajusta e só o que MUDOU vai para a OLT (entra a nova, sai a velha; o que continua não é tocado).
function oltUplinkEditar(fsp){
    var antes=(window._oltUpkMap&&window._oltUpkMap[fsp])||'';
    var v=prompt('EDITAR as VLANs da porta ethernet'+fsp+'\n\nEdite a lista completa (ex.: 40,50-60,150-165). O que você apagar sai da porta; o que acrescentar entra:',antes); if(v===null) return;
    v=(''+v).replace(/[^0-9,\- ]/g,'').trim().replace(/\s+/g,''); if(!v){ alert('Lista vazia — para tirar todas use o botão de remover.'); return; }
    if(v===antes.replace(/\s+/g,'')){ alert('Nada foi alterado.'); return; }
    if(!confirm('CONFIRMA trocar as VLANs da porta de uplink ethernet'+fsp+'?\n\nDe:   '+(antes||'(nenhuma)')+'\nPara: '+v+'\n\n⚠️ Isto altera o tronco de saída da OLT — se errar, pode cortar tráfego.')) return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=uplink_vlan&fsp='+encodeURIComponent(fsp)+'&op=edit&antes='+encodeURIComponent(antes)+'&vlans='+encodeURIComponent(v)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.ok){ alert('OK — VLANs da porta ethernet'+fsp+' atualizadas.'); window._oltUpkForce=1; var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarUplink(); } }
        else { alert('A OLT retornou aviso/erro:\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,400)); }
      }).catch(function(){ alert('Erro de comunicação.'); });
}
// Adiciona/remove VLAN(s) numa porta de uplink (config REAL na OLT). Pede confirmação forte.
function oltUplinkVlan(fsp, op){
    var acao=(op==='del')?'REMOVER':'ADICIONAR';
    var v=prompt(acao+' VLAN(s) na porta ethernet'+fsp+'\n\nDigite a(s) VLAN(s) — ex.: 40  ou  50-60  ou  40,150,250-265:',''); if(v===null) return;
    v=(''+v).replace(/[^0-9,\- ]/g,'').trim(); if(!v){ alert('VLAN inválida.'); return; }
    if(!confirm('CONFIRMA '+acao+' a(s) VLAN(s) "'+v+'" na porta de uplink ethernet'+fsp+'?\n\n⚠️ Isto altera o tronco de saída da OLT — se errar, pode cortar tráfego.')) return;
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=uplink_vlan&fsp='+encodeURIComponent(fsp)+'&op='+op+'&vlans='+encodeURIComponent(v)}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        if(typeof _oltAuthErro==='function'&&_oltAuthErro(d))return;
        if(d && d.ok){ alert('OK — '+acao.toLowerCase()+' aplicado na porta ethernet'+fsp+'.\n\n'+(''+(d.saida||'')).slice(0,300)); var m=document.querySelector('.oltMSWin'); if(m){ m.remove(); oltGerenciarUplink(); } }
        else { alert('A OLT retornou aviso/erro:\n\n'+(''+((d&&d.saida)||'sem detalhe')).slice(0,400)); }
      }).catch(function(){ alert('Erro de comunicação.'); });
}
// Gerenciar PORTAS PON — apelido + VLAN + Zona + Perfil padrão por porta (item 9).
// Carrega o Tx do GBIC (cache) DIRETO (fora da fila serial -> instantâneo) e preenche só as células de Tx,
// sem re-renderizar a tabela. Se o cache não tiver a porta, mostra "—" (não fica girando). O cron atualiza
// o Tx real por Telnet a cada ~20 min; aqui a TELA só lê o cache, então abre na hora.
function _oltPortasCarregarTx(){
    var acabaSpinners=function(){ var sp=document.querySelectorAll('[id^="oltTxCell_"]'); for(var i=0;i<sp.length;i++){ var el=sp[i]; if(el.querySelector('.fa-spinner')){ el.innerHTML='—'; el.style.color=OLTC.mut; } } };
    var fn=(typeof _oltFetchDireto==='function')?_oltFetchDireto('olt_huawei.php?acao=pon_tx',15000):oltFetch('olt_huawei.php?acao=pon_tx',null,false);
    fn.then(function(r){return r.json();}).then(function(d){
        var tx=(d&&d.tx)?d.tx:{}; window._oltPonTx=tx;
        Object.keys(tx).forEach(function(f){ var el=document.getElementById('oltTxCell_'+String(f).replace(/[^0-9]/g,'_')); if(el){ el.innerHTML='<i class="fa-solid fa-arrow-up-from-bracket" style="font-size:9px;"></i> '+_oltEsc(tx[f]); el.style.color=OLTC.vio; } });
        acabaSpinners();
    }).catch(acabaSpinners);
}
function oltGerenciarPortas(){
    var _dir=function(u){ return (typeof _oltFetchDireto==='function')?_oltFetchDireto(u,15000):oltFetch(u,null,false); };
    // 1ª abertura desta sessão: carrega Tx do GBIC + nº REAL de portas das placas — AMBOS do CACHE, leitura
    // DIRETA (fora da fila = rápida) — ANTES de desenhar. Assim TODAS as portas (0-15) vêm JUNTAS e REAIS
    // (as vazias 9-15 vêm do tipo real da placa, H805GPFD=16). Depois fica em memória -> instantâneo.
    if(window._oltPonTx===undefined || window._oltPlacasDet===undefined){
        _oltModalSimples('fa-ethernet','Gerenciar Portas PON — sinal, Tx GBIC, VLAN, Zona, Perfil, ativar/desativar','<div style="text-align:center; color:'+OLTC.mut+'; padding:24px;">'+_oltSpinner('Carregando portas (Tx + placas)...')+'</div>');
        Promise.all([
            _dir('olt_huawei.php?acao=pon_tx').then(function(r){return r.json();}).then(function(d){ window._oltPonTx=(d&&d.tx)?d.tx:{}; }).catch(function(){ window._oltPonTx={}; }),
            _dir('olt_huawei.php?acao=placas_detect').then(function(r){return r.json();}).then(function(d){ window._oltPlacasDet=(d&&d.placas)?d.placas:[]; }).catch(function(){ window._oltPlacasDet=[]; })
        ]).then(function(){ var m=document.querySelector('.oltMSWin'); if(m) m.remove(); oltGerenciarPortas(); });
        return;
    }
    var L=window._oltLista||[]; var set={};
    L.forEach(function(o){ var f=o.fsp||''; if(f) set[f]=(set[f]||0)+1; });
    // TAMBÉM as portas PON ATIVAS na placa mesmo SEM ONU (ex.: placa 5 portas 9-15). Fontes automáticas:
    //  1) o Tx (display port state all) já lista TODAS as portas de cada placa GPON com ONU;
    //  2) as placas GPON detectadas (placas_detect) — cobre placa NOVA recém-instalada, sem ONU ainda.
    Object.keys(window._oltPonTx||{}).forEach(function(f){ if(f && set[f]==null) set[f]=0; });
    // Portas VAZIAS vêm de fontes REAIS (nada assumido): o Tx (display port state all = portas reais da placa)
    // e o placas_detect (nº REAL de portas informado pela OLT). Se o placas_detect ainda não veio, é buscado
    // em 2º plano e a página se atualiza quando chegar — real, sem inventar porta que não existe.
    (window._oltPlacasDet||[]).forEach(function(b){ if(b&&b.gpon){ var np=parseInt(b.portas,10)||0; for(var i=0;i<np;i++){ var f='0/'+b.slot+'/'+i; if(set[f]==null) set[f]=0; } } });
    var fsps=Object.keys(set).sort(function(a,b){ var pa=a.split('/'),pb=b.split('/'); return (+pa[1]-+pb[1])||(+pa[2]-+pb[2]); });
    // Estilo de campo MENOR só desta janela (obs3: ícones e fontes um pouco menores).
    var s='padding:6px 9px; border-radius:7px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.txt+'; font-size:11.5px;';
    var dlz='<datalist id="oltPortaZonaDL">'+OLT_ZONAS.map(function(z){ return '<option value="'+_oltEsc(z)+'"></option>'; }).join('')+'</datalist>';
    var bIco=function(f,op,cor,ico,dis){ var ae=_oltEsc(f); return '<button'+(dis?' disabled':'')+' onclick="_oltPonControl(\'porta\',\''+ae+'\',\''+op+'\')" title="'+op+'" style="cursor:'+(dis?'default':'pointer')+'; flex:0 0 auto; width:28px; height:28px; font-size:11px; border-radius:6px; border:1px solid '+cor+'; background:transparent; color:'+cor+'; opacity:'+(dis?'0.4':'1')+';"><i class="fa-solid '+ico+'"></i></button>'; };
    var th=function(t,al,w){ return '<th style="text-align:'+(al||'left')+'; padding:8px 7px; font-size:8px; text-transform:uppercase; letter-spacing:.3px; color:'+OLTC.mut+'; border-bottom:2px solid '+OLTC.line+'; white-space:nowrap;'+(w?(' width:'+w+';'):'')+'">'+t+'</th>'; };
    var td=function(c,ex){ return '<td style="padding:5px 7px; border-bottom:1px solid '+OLTC.line+'33; vertical-align:middle; '+(ex||'')+'">'+c+'</td>'; };
    var _lastSlot=null;   // p/ inserir um CABEÇALHO "PLACA X" quando a placa (slot) muda (1, 3, 5… automático)
    var trs=fsps.length?fsps.map(function(f){
        var _slot=(f.split('/')[1]||'?'); var _sep='';
        if(_slot!==_lastSlot){ _lastSlot=_slot; var _np=fsps.filter(function(x){ return (x.split('/')[1]||'')===_slot; }).length;
            _sep='<tr><td colspan="10" style="padding:11px 12px 7px; background:'+OLTC.acc+'14; border-top:2px solid '+OLTC.acc+'; border-bottom:1px solid '+OLTC.line+';"><span style="font-weight:800; font-size:13px; color:'+OLTC.acc+'; letter-spacing:.5px;"><i class="fa-solid fa-server"></i> PLACA '+_oltEsc(_slot)+'</span> <span style="font-size:10.5px; color:'+OLTC.mut+'; font-weight:600; margin-left:8px;">'+_np+' porta(s) GPON</span></td></tr>';
        }
        var _pon=L.filter(function(o){ return (o.fsp||'')===f; });
        var est=_oltEstadoDe(_pon); var deDis=(est==='deactivated'), atDis=(est==='active');
        var _on=_pon.filter(function(o){ return (o.status||'').toLowerCase().indexOf('online')>-1; }).length;
        var _rxs=_pon.map(function(o){ return parseFloat((''+((o.rx_olt||o.rx)||'')).replace(/[^0-9.\-]/g,'')); }).filter(function(v){ return !isNaN(v) && v<0 && v>-40; });   // REFERÊNCIA = Rx OLT (retorno)
        var _med=_rxs.length?(_rxs.reduce(function(a,b){return a+b;},0)/_rxs.length):null;
        var _mc=(_med==null)?OLTC.mut:(_oltCorSinal(_med)||OLTC.grn);
        return _sep+'<tr>'+
            td('<span style="font-family:monospace; font-weight:800; font-size:11.5px; color:'+OLTC.acc+'; white-space:nowrap;"><i class="fa-solid fa-ethernet"></i> '+_oltEsc(f)+'</span>','text-align:center;')+
            td('<div style="display:inline-flex; flex-direction:column; align-items:center; gap:3px;">'+
                '<span onclick="_oltPortaFiltrar(this,\''+_oltEsc(f)+'\')" title="Ver estas '+set[f]+' ONUs na lista" style="cursor:pointer; display:inline-block; min-width:26px; text-align:center; background:'+OLTC.acc+'22; color:'+OLTC.acc+'; font-weight:800; font-size:10px; padding:2px 7px; border-radius:20px;">'+set[f]+'</span>'+
                (function(){ var us=set[f], mx=128, pc=Math.min(100,Math.round(us/mx*100)), cor=(pc>=90?OLTC.red:(pc>=70?OLTC.amb:OLTC.grn)); return '<div title="'+us+'/'+mx+' ('+pc+'%) · '+(mx-us)+' livre" style="width:48px; height:5px; background:'+OLTC.panel+'; border-radius:6px; overflow:hidden;"><div style="height:100%; width:'+pc+'%; background:'+cor+';"></div></div><span style="font-size:8.5px; font-weight:700; color:'+cor+';">'+pc+'% · '+(mx-us)+' livre</span>'; })()+
              '</div>','text-align:center;')+
            td('<span style="font-size:10.5px; font-weight:800; color:'+OLTC.grn+'; white-space:nowrap;"><i class="fa-solid fa-circle" style="font-size:6px;"></i> '+_on+'/'+set[f]+'</span>','text-align:center;')+
            td('<span style="font-size:10.5px; font-weight:800; color:'+_mc+'; background:'+_mc+'1f; border-radius:20px; padding:2px 8px; white-space:nowrap;">'+(_med==null?'—':(_med.toFixed(2)+' dBm'))+'</span>','text-align:center;')+
            td((function(){ var tx=(window._oltPonTx||{})[f]; var cid='oltTxCell_'+String(f).replace(/[^0-9]/g,'_'); return '<span id="'+cid+'" style="font-size:10.5px; font-weight:800; color:'+(tx?OLTC.vio:OLTC.mut)+'; white-space:nowrap;">'+(tx?('<i class="fa-solid fa-arrow-up-from-bracket" style="font-size:9px;"></i> '+_oltEsc(tx)):'<i class="fa-solid fa-spinner fa-spin" style="font-size:9px; opacity:.6;"></i>')+'</span>'; })(),'text-align:center;')+
            td('<input value="'+_oltEsc(_oltPortaNome(f))+'" onchange="_oltMetaSet(\'porta\',\''+_oltEsc(f)+'\',this.value.trim())" placeholder="apelido" style="'+s+' width:100%; box-sizing:border-box;">')+
            td('<input value="'+_oltEsc(_oltMetaPorta('portavlan',f))+'" onchange="_oltMetaSet(\'portavlan\',\''+_oltEsc(f)+'\',this.value.replace(/[^0-9]/g,\'\'))" placeholder="VLAN" inputmode="numeric" style="'+s+' width:100%; box-sizing:border-box;">')+
            td('<input value="'+_oltEsc(_oltMetaPorta('portazona',f))+'" list="oltPortaZonaDL" onchange="_oltMetaSet(\'portazona\',\''+_oltEsc(f)+'\',this.value.trim())" placeholder="Zona" style="'+s+' width:100%; box-sizing:border-box;">')+
            td('<select class="olt-portperfil" data-val="'+_oltEsc(_oltMetaPorta('portperfil',f))+'" onchange="_oltMetaSet(\'portperfil\',\''+_oltEsc(f)+'\',this.value)" title="Perfil ONT/ONU padrão" style="'+s+' width:100%; box-sizing:border-box;">'+_oltSrvOptsApHtml()+'</select>')+
            td('<div style="display:flex; gap:4px; justify-content:center;">'+bIco(f,'reboot',OLTC.amb,'fa-rotate-right',false)+bIco(f,'deactivate',OLTC.red,'fa-power-off',deDis)+bIco(f,'activate',OLTC.grn,'fa-play',atDis)+'</div>','white-space:nowrap; text-align:center;')+
        '</tr>';
    }).join(''):'';
    var tabela=fsps.length?('<div style="overflow-x:auto;">'+dlz+'<table style="width:100%; border-collapse:collapse; min-width:820px; table-layout:fixed;"><thead><tr>'+
        th('F/S/P','center','9%')+th('ONUs','center','6%')+th('Online','center','7%')+th('Sinal médio Rx','center','10%')+th('Tx GBIC','center','8%')+th('Apelido','center','17%')+th('VLAN','center','6%')+th('Zona','center','12%')+th('Perfil padrão','center','14%')+th('Ações','center','11%')+
        '</tr></thead><tbody>'+trs+'</tbody></table></div>'):'<div style="color:'+OLTC.mut+'; padding:10px;">Nenhuma porta na lista ainda.</div>';
    _oltModalSimples('fa-ethernet','Gerenciar Portas PON — sinal, Tx GBIC, VLAN, Zona, Perfil, ativar/desativar', tabela);
    _oltAplicarPortPerfilSelects(); // marca o perfil salvo em cada select
    // Atualiza o Tx (cache, direto/rápido) e preenche as células — mantém o valor fresco a cada abertura.
    _oltPortasCarregarTx();
    // Se os perfis ainda não vieram, carrega e repovoa os selects abertos (sem re-abrir o modal).
    if(!(window._oltPerfisOlt&&window._oltPerfisOlt.srv&&window._oltPerfisOlt.srv.length)){
        _oltFetchDireto('olt_huawei.php?acao=perfis_olt', 15000).then(function(r){return r.json();}).then(function(d){
            if(d&&d.srv&&d.srv.length){ window._oltPerfisOlt={line:d.line||[],srv:d.srv};
                var sels=document.querySelectorAll('.oltMSWin select.olt-portperfil');
                for(var k=0;k<sels.length;k++){ var val=sels[k].getAttribute('data-val')||''; sels[k].innerHTML=_oltSrvOptsApHtml(); sels[k].value=val; }
            }
        }).catch(function(){});
    }
}
function _oltAplicarPortPerfilSelects(){ var sels=document.querySelectorAll('.oltMSWin select.olt-portperfil'); for(var k=0;k<sels.length;k++){ sels[k].value=sels[k].getAttribute('data-val')||''; } }
// --- ComboBox com "+" (cadastro rápido) ---
function _oltInSt(){ return 'padding:9px 12px; border-radius:8px; border:1px solid '+OLTC.line+'; background:'+OLTC.panel+'; color:'+OLTC.txt+'; font-size:13px;'; }
function _oltOpts(lista, sel){ return (lista||[]).map(function(v){ return '<option value="'+_oltEsc(v)+'"'+((sel!=null&&(''+sel)===(''+v))?' selected':'')+'>'+_oltEsc(v)+'</option>'; }).join(''); }
function _oltCombo(campo, id, optsHtml){ var s=_oltInSt(); return '<div style="display:flex; gap:6px;"><select id="'+id+'" style="'+s+' flex:1 1 auto; min-width:0;">'+optsHtml+'</select><button type="button" onclick="oltAddOpcao(\''+campo+'\',\''+id+'\')" title="Cadastrar novo" style="flex:0 0 auto; cursor:pointer; width:34px; border-radius:8px; border:1px solid '+OLTC.line+'; background:'+OLTC.bg2+'; color:'+OLTC.acc+'; font-weight:800; font-size:16px; line-height:1;">+</button></div>'; }
function oltAddOpcao(campo, selId){
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(92vw,340px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:10px;"><i class="fa-solid fa-plus" style="color:'+OLTC.acc+';"></i> Cadastrar '+_oltEsc(campo)+'</div>'+
        '<input id="oltAddInp" type="text" placeholder="Novo valor" style="'+_oltInSt()+' width:100%; box-sizing:border-box; margin-bottom:12px;">'+
        '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltAddOpcaoSalvar(\''+campo+'\',\''+selId+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;">Salvar</button>'+
        '</div></div>';
    document.body.appendChild(ov);
    var inp=document.getElementById('oltAddInp'); if(inp){ inp.focus(); inp.onkeydown=function(e){ if(e.key==='Enter') oltAddOpcaoSalvar(campo, selId); if(e.key==='Escape') ov.remove(); }; }
}
function oltAddOpcaoSalvar(campo, selId){
    var inp=document.getElementById('oltAddInp'); var val=inp?(''+inp.value).trim():''; if(!val) return;
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=opcoes_add&campo='+encodeURIComponent(campo)+'&valor='+encodeURIComponent(val)})
      .then(function(r){ return r.json(); })
      .then(function(d){ if(d&&d.opcoes) window._oltOpcoes=d.opcoes;
        var sel=document.getElementById(selId);
        if(sel){ var ex=false,k; for(k=0;k<sel.options.length;k++){ if(sel.options[k].value===val){ ex=true; break; } } if(!ex){ var op=document.createElement('option'); op.value=val; op.textContent=val; sel.appendChild(op); } sel.value=val; }
        var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
      })
      .catch(function(){ var ov=document.getElementById('oltAddOv'); if(ov) ov.remove(); });
}
// Opções de line/srv-profile lidas da OLT (só seleção; nada de digitar ID)
function _oltPerfilOltOpts(lista, defId){
    if(!lista || !lista.length) return '<option value="'+defId+'">(carregando perfis da OLT…) '+defId+'</option>';
    return lista.map(function(p){ return '<option value="'+p.id+'"'+((''+p.id)===(''+defId)?' selected':'')+'>'+_oltEsc(p.nome)+' ('+p.id+')</option>'; }).join('');
}
// --- Perfil de provisionamento (Generic_1..6 / personalizados) com "+" ---
// Combo de perfil GENÉRICO já pronto (Generic_1/2/3…): lê os perfis REAIS da OLT
// (window._oltPerfisOlt = display ont-lineprofile/ont-srvprofile gpon all) e pareia
// line+srv pelo nome. Sem digitar nada — o operador só escolhe qual genérico aplicar.
function _oltPerfilOpts(){
    var po=window._oltPerfisOlt||{line:[],srv:[]};
    var lines=po.line||[], srvs=po.srv||[];
    function lineId(nm){
        var i,n=String(nm||'').toLowerCase();
        for(i=0;i<lines.length;i++){ if(String(lines[i].nome||'').toLowerCase()===n) return lines[i].id; }
        var num=(n.match(/(\d+)\s*$/)||[])[1];
        if(num){ for(i=0;i<lines.length;i++){ if((String(lines[i].nome||'').match(/(\d+)\s*$/)||[])[1]===num) return lines[i].id; } }
        return '';
    }
    var gen=srvs.filter(function(p){ return /gener/i.test(p.nome||''); });
    var lista=gen.length?gen:srvs; // se a OLT não nomear "generic", mostra todos os srv reais
    lista=lista.slice().sort(function(a,b){ return String(a.nome).localeCompare(String(b.nome),undefined,{numeric:true}); });
    return '<option value="">— sem genérico (usa o Tipo) —</option>'+lista.map(function(p){
        var lp=lineId(p.nome);
        return '<option value="'+_oltEsc(p.nome)+'" data-lp="'+_oltEsc(lp)+'" data-sp="'+_oltEsc(p.id)+'">'+_oltEsc(p.nome)+'</option>';
    }).join('');
}
function _oltPerfilCombo(i){
    var s=_oltInSt();
    return '<select id="olt_perfil_'+i+'" class="olt-perfil-ap" onchange="this.setAttribute(\'data-manual\',\'1\')" style="'+s+' width:100%;">'+_oltPerfilOpts()+'</select>';
}
// Chip pequeno "GEN" na coluna Nome quando a ONU está num perfil genérico (só quando já
// conhecemos o perfil — enriquecido pelo uptime_massa/ficha). Não polui as demais.
function _oltGenChip(o){
    if(!o||!/gener/i.test(((o.lineprofile||'')+' '+(o.srvprofile||'')))) return '';
    return ' <span title="Perfil genérico ('+_oltEsc(o.lineprofile||o.srvprofile||'')+')" style="display:inline-block; padding:0 5px; border-radius:20px; background:'+OLTC.grn+'; color:#fff; font-size:8.5px; font-weight:800; vertical-align:1px; letter-spacing:.3px;">GEN</span>';
}
// Selo do perfil atual da ONU na ficha: line/srv + badge verde GENÉRICO quando é genérico.
// fim=true: a leitura da OLT já terminou (ok ou falha) -> nunca mais spinner: mostra o srv-profile
// que a lista já conhece (o.srv) ou "não lido". Antes girava pra sempre se o combo falhasse/demorasse.
function _oltPerfilBadge(o, fim){
    var ln=(o&&o.lineprofile)||''; var sv=(o&&o.srvprofile)||'';
    if(!ln && !sv && o && o.srv) sv=o.srv;   // srv-profile já conhecido pela lista/cache
    if(!ln && !sv && o){ try{ var _au=(window._oltAutoriz||{})[String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'')]; if(_au&&_au.srv) sv=_au.srv; }catch(e){} }   // perfil gravado na AUTORIZAÇÃO
    if(!ln && !sv) return fim?'<span style="color:'+OLTC.mut+'; font-weight:400;" title="A OLT não respondeu agora — clique em Obter Status para reler">não lido</span>':'<i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+'; font-size:11px;"></i>';
    var gen=/gener/i.test(ln+' '+sv);
    var txt=!ln?_oltEsc(sv):_oltEsc(ln)+((sv&&sv!==ln)?(' <span style="color:'+OLTC.mut+';">/</span> '+_oltEsc(sv)):'');
    var badge=gen?(' <span style="display:inline-block; padding:1px 7px; border-radius:20px; background:'+OLTC.grn+'; color:#fff; font-size:8px; font-weight:800; vertical-align:1px;">GENÉRICO</span>'):'';
    return txt+badge;
}
// Trocar/adicionar perfil GENÉRICO numa ONU JÁ aprovisionada (força, sem filtro de origem).
// Abre um seletor com os genéricos reais da OLT; ao aplicar, chama generico_migrar&forcar=1.
function oltTrocarPerfilGen(id){
    // ⛔ DESATIVADO por segurança (mesmo motivo do lote): trocar perfil de ONU ativa derruba o serviço.
    alert('⛔ Trocar perfil genérico DESATIVADO por segurança.\n\nNuma ONU já funcionando isso reescreve os GEM/T-CONT e derruba o tráfego (service-port órfão). Aplique o genérico só no APROVISIONAMENTO; para as já ativas, exclua a ONU e autorize novamente com o novo perfil.');
    return;
    var o=window._oltWins[id]; if(!o) return;
    function abrir(){
        var atual=document.getElementById('oltPgOv'); if(atual) atual.remove();
        var ov=document.createElement('div'); ov.id='oltPgOv';
        ov.style.cssText='position:fixed; inset:0; z-index:2147483600; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
        ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,400px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
            '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:4px;"><i class="fa-solid fa-microchip" style="color:'+OLTC.acc+';"></i> Aplicar perfil genérico</div>'+
            '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:6px;">ONU <b>'+_oltEsc(_oltNomeDe(o)||o.serial||'')+'</b> ('+_oltEsc(o.fsp||'')+' · ID '+_oltEsc(o.id||'')+'). Perfil atual: <b>'+_oltPerfilBadge(o)+'</b></div>'+
            '<select id="oltPgSel" style="'+_oltInSt()+' width:100%; box-sizing:border-box; margin-bottom:12px;">'+_oltPerfilOpts()+'</select>'+
            '<div id="oltPgRes" style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:8px;"></div>'+
            '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
              '<button type="button" onclick="document.getElementById(\'oltPgOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
              '<button type="button" onclick="oltTrocarPerfilGenAplicar(\''+id+'\',this)" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;">Aplicar</button>'+
            '</div></div>';
        document.body.appendChild(ov);
        // pré-seleciona o 1º genérico com line+srv válidos
        var sel=document.getElementById('oltPgSel');
        for(var k=0;k<sel.options.length;k++){ var op=sel.options[k]; if(op.value&&op.getAttribute('data-lp')&&op.getAttribute('data-sp')){ sel.value=op.value; break; } }
    }
    if(window._oltPerfisOlt&&window._oltPerfisOlt.srv&&window._oltPerfisOlt.srv.length){ abrir(); _oltPerfisOltRefrescar(false); } // abre já e atualiza pelo cache rápido (sem Telnet)
    else oltFetch('olt_huawei.php?acao=perfis_olt', null, true).then(function(r){return r.json();}).then(function(d){ if(d&&d.srv&&d.srv.length) window._oltPerfisOlt={line:d.line||[],srv:d.srv||[]}; abrir(); }).catch(abrir);
}
function oltTrocarPerfilGenAplicar(id,btn){
    var o=window._oltWins[id]; if(!o) return;
    var sel=document.getElementById('oltPgSel'); var res=document.getElementById('oltPgRes');
    var op=(sel&&sel.selectedOptions&&sel.selectedOptions[0])?sel.selectedOptions[0]:null;
    var lp=op?op.getAttribute('data-lp'):''; var sp=op?op.getAttribute('data-sp'):''; var nm=sel?sel.value:'';
    if(!lp||!sp){ if(res) res.innerHTML='<span style="color:'+OLTC.red+';">Escolha um perfil genérico válido.</span>'; return; }
    if(btn){ btn.disabled=true; btn.style.opacity='.6'; btn.textContent='Aplicando…'; }
    var body='acao=generico_migrar&forcar=1&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id)+'&lp='+encodeURIComponent(lp)+'&sp='+encodeURIComponent(sp);
    fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body}).then(function(r){return r.json();}).then(function(d){
        if(d&&d.migrado){
            o.lineprofile=nm; o.srvprofile=nm; // reflete o novo perfil na ficha e na lista
            (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===(o.fsp||'') && (''+x.id)===(''+o.id)){ x.lineprofile=nm; x.srvprofile=nm; } });
            var pe=document.getElementById('olt_perf_'+id); if(pe) pe.innerHTML=_oltPerfilBadge(o);
            var ov=document.getElementById('oltPgOv'); if(ov) ov.remove();
            if(typeof oltToast==='function') oltToast('Perfil aplicado: '+nm);
        } else { if(res) res.innerHTML='<span style="color:'+OLTC.red+';">Falha: '+_oltEsc((d&&(d.message||d.saida))||'a OLT recusou')+'</span>'; if(btn){ btn.disabled=false; btn.style.opacity='1'; btn.textContent='Aplicar'; } }
    }).catch(function(){ if(res) res.innerHTML='<span style="color:'+OLTC.red+';">Sem resposta da OLT.</span>'; if(btn){ btn.disabled=false; btn.style.opacity='1'; btn.textContent='Aplicar'; } });
}
// Carrega os perfis GENÉRICOS cadastrados (olt_perfis.json) -> window._oltPerfis. Se o card de
// aprovisionamento estiver aberto, re-renderiza pra o combo já aparecer preenchido.
function _oltCarregarPerfisGen(){
    if(window._oltPerfis) return;
    oltFetch('olt_huawei.php?acao=perfis_get', null, false).then(function(r){return r.json();}).then(function(d){
        window._oltPerfis=(d&&d.perfis)||[];
        if(document.getElementById('oltApModal') && window._oltAutofindCache && typeof oltRenderAutofind==='function') oltRenderAutofind(window._oltAutofindCache);
    }).catch(function(){ window._oltPerfis=window._oltPerfis||[]; });
}
function oltAddPerfil(i){
    var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
    var ov=document.createElement('div'); ov.id='oltAddOv';
    ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
    var s=_oltInSt();
    ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,400px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
        '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:4px;"><i class="fa-solid fa-plus" style="color:'+OLTC.acc+';"></i> Cadastrar perfil de provisionamento</div>'+
        '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:10px;">IDs de <b>ont-lineprofile</b> e <b>ont-srvprofile</b> da OLT (veja em <code>display ont-srvprofile gpon all</code>).</div>'+
        '<input id="oltPfNome" placeholder="Nome (ex.: Generic_1)" style="'+s+' width:100%; box-sizing:border-box; margin-bottom:8px;">'+
        '<div style="display:flex; gap:8px;">'+
          '<input id="oltPfLp" type="number" placeholder="Line-profile ID" style="'+s+' flex:1; box-sizing:border-box;">'+
          '<input id="oltPfSp" type="number" placeholder="Srv-profile ID" style="'+s+' flex:1; box-sizing:border-box;">'+
        '</div>'+
        '<select id="oltPfModo" style="'+s+' width:100%; box-sizing:border-box; margin:8px 0 12px;"><option value="bridge">Bridge</option><option value="router">Router</option></select>'+
        '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
          '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
          '<button type="button" onclick="oltAddPerfilSalvar('+i+')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.grn+'; color:#fff; font-weight:800;">Salvar</button>'+
        '</div></div>';
    document.body.appendChild(ov);
    var n=document.getElementById('oltPfNome'); if(n) n.focus();
}
function oltAddPerfilSalvar(i){
    var nome=_oltVal('oltPfNome'), lp=_oltVal('oltPfLp'), sp=_oltVal('oltPfSp'), modo=(document.getElementById('oltPfModo')||{}).value||'';
    if(!nome||!lp||!sp) return;
    fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=perfis_add&nome='+encodeURIComponent(nome)+'&lp='+encodeURIComponent(lp)+'&sp='+encodeURIComponent(sp)+'&modo='+encodeURIComponent(modo)})
      .then(function(r){ return r.json(); })
      .then(function(d){ if(d&&d.perfis) window._oltPerfis=d.perfis;
        var sel=document.getElementById('olt_perfil_'+i);
        if(sel){ var op=document.createElement('option'); op.value=nome; op.setAttribute('data-lp',lp); op.setAttribute('data-sp',sp); op.textContent=nome+' (L'+lp+'/S'+sp+(modo?' · '+modo:'')+')'; sel.appendChild(op); sel.value=nome; }
        var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
      })
      .catch(function(){ var ov=document.getElementById('oltAddOv'); if(ov) ov.remove(); });
}
function _oltSlotOpts(sel){ var o=''; [1,2,3,4,5].forEach(function(s){ o+='<option value="'+s+'" '+((sel+'')===(s+'')?'selected':'')+'>Placa '+s+'</option>'; }); return o; }
function _oltPortOpts(sel){ var o=''; for(var s=0;s<=15;s++){ o+='<option value="'+s+'" '+((sel+'')===(s+'')?'selected':'')+'>Porta '+s+'</option>'; } return o; }
function oltAutorizar(sn, i, semConfirm){   // semConfirm: vindo do "Mover" (já confirmado lá)
    var nome=_oltVal('olt_nome_'+i);
    var slot=_oltVal('olt_slot_'+i), port=_oltVal('olt_port_'+i);
    var zonaAp=_oltVal('olt_zona_'+i);
    var vlanRaw=_oltVal('olt_vlan_'+i);
    var vlan=(vlanRaw.match(/\d+/)||[''])[0];                       // número (vai pra OLT)
    var vlanNome=vlanRaw.replace(/^\s*\d+\s*[-–—:]?\s*/,'').trim(); // nome livre depois do número
    // Aprende/salva o nome que você escreveu pra essa VLAN (aparece da próxima vez)
    if(vlan && vlanNome && vlanNome!==_oltVlanNome(vlan)){
        window._oltVlanNomes=window._oltVlanNomes||{}; window._oltVlanNomes[vlan]=vlanNome;
        fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=vlan_nomes_add&vlan='+encodeURIComponent(vlan)+'&nome='+encodeURIComponent(vlanNome)}).catch(function(){});
    }
    if(!nome){ var inp=document.getElementById('olt_nome_'+i); if(inp){ inp.focus(); inp.style.borderColor=OLTC.red; } return; }
    if(!vlan){ if(!confirm('Nenhuma VLAN foi informada.\n\nSem VLAN, a OLT NÃO cria o service-port — a ONU fica autorizada mas SEM conexão nenhuma até o concentrador (o cliente não vai navegar mesmo com contrato ativo).\n\nAutorizar mesmo assim?')) { var vi=document.getElementById('olt_vlan_'+i); if(vi){ vi.focus(); vi.style.borderColor=OLTC.red; } return; } }
    var fsp='0/'+slot+'/'+port;
    // Perfil ONU/ONT especifico escolhido (lista curada, igual ao "Trocar modo"). Se escolhido,
    // ele MANDA no srv-profile aplicado; o modo (Bridge/Router) vem do proprio perfil.
    var srvEl=document.getElementById('olt_srv_'+i);
    var srvId=srvEl?(''+srvEl.value).trim():'';
    var srvModo=(srvId&&srvEl.selectedOptions&&srvEl.selectedOptions[0])?(srvEl.selectedOptions[0].getAttribute('data-modo')||''):'';
    var srvNome=(srvId&&srvEl.selectedOptions&&srvEl.selectedOptions[0])?(srvEl.selectedOptions[0].textContent||'').split(' — ')[0].trim():'';
    var modoSel=srvId?srvModo:_oltVal('olt_modo_'+i); // perfil especifico define o modo
    if(!semConfirm && !confirm('Autorizar a ONU '+sn+'\nPlaca/Porta: '+fsp+'  ·  VLAN: '+vlan+'\nTipo: '+(modoSel==='router'?'Router (ONT)':'Bridge (ONU)')+(srvId?('\nPerfil: '+srvNome):'')+'\nCliente: '+nome+'\n\nConfirmar?')) return;
    var res=document.getElementById('olt_autres_'+i);
    if(res) res.innerHTML='<span style="color:'+OLTC.grn+'; font-weight:700; font-size:12px;"><i class="fa-solid fa-spinner fa-spin"></i> Autorizando na OLT (aguarde a verificação)...</span>';
    // Se escolheu um perfil especifico: manda srvprofile e modo VAZIO (senao o backend sobrescreve
    // o srv-profile pelo padrao Bridge/Router). Senao: fluxo antigo por modo.
    // Perfil GENÉRICO (outras marcas · Intelbras R1/R2): manda o LINE+SRV-profile dele — é o que faz a ONU
    // não-OMCI funcionar. Tem PRIORIDADE sobre o srv-profile/modo.
    var pfEl=document.getElementById('olt_perfil_'+i); var pfOpt=(pfEl&&pfEl.value&&pfEl.selectedOptions&&pfEl.selectedOptions[0])?pfEl.selectedOptions[0]:null;
    var pfLp=pfOpt?(pfOpt.getAttribute('data-lp')||''):''; var pfSp=pfOpt?(pfOpt.getAttribute('data-sp')||''):''; var pfModo=pfOpt?(pfOpt.getAttribute('data-modo')||''):'';
    var body=new URLSearchParams({ acao:'autorizar', fsp:fsp, sn:sn, nome:nome, vlan:vlan });
    if(zonaAp) body.set('zona', zonaAp);   // ENVIA a zona -> o backend grava NOME_zone_ZONA na descrição (SmartOLT lê a zona). Faltava isso!
    // REDUNDÂNCIA SmartOLT: manda o TIPO de ONU (nome do perfil, ex.: MAX1000) e o MODO (Bridging/Routing).
    // O backend registra a ONU no SmartOLT via API com esses valores -> zona/modo/tipo saem CERTOS lá.
    (function(){ var stType=srvNome||''; if(!stType&&pfOpt){ stType=((pfOpt.value||pfOpt.textContent||'').split('(')[0].trim()); }
        if(stType) body.set('st_onu_type', stType);
        body.set('st_mode', (modoSel==='router')?'Routing':'Bridging'); })();
    if(pfLp && pfSp){ body.set('lineprofile', pfLp); body.set('srvprofile', pfSp); body.set('modo', pfModo||''); }
    else if(srvId){ body.set('srvprofile', srvId); body.set('modo',''); }
    else { body.set('modo', modoSel); }
    // Aprovisionar é LONGO (confirm + retries + service-port + verificação): fetch direto com
    // timeout de 50s (a fila comum aborta em 25s -> era o "AbortError" nas 1ªs tentativas). O
    // backend serializa via mutex, então não colide com as varreduras.
    (function(){ var ctrl=('AbortController' in window)?new AbortController():null;
        var to=ctrl?setTimeout(function(){ try{ctrl.abort();}catch(e){} },290000):null;   // 290s (era 180s): confirm + verificação + service-port com GEM real (olt_sp_criar) passa de 50s com a OLT ocupada
        var opts={ method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body.toString() };
        if(ctrl) opts.signal=ctrl.signal;
        return fetch('olt_huawei.php', opts).then(function(r){ if(to)clearTimeout(to); return r; });
    })()
      .then(function(r){ return r.json(); })
      .then(function(d){
        if(!res) return;
        if(!d||d.status!=='ok'){ res.innerHTML='<span style="color:'+OLTC.red+'; font-size:12px;">'+_oltEsc((d&&d.message)||'Falha ao autorizar.')+'</span>'; return; }
        var cor=d.sucesso?OLTC.grn:OLTC.red, ic=d.sucesso?'fa-circle-check':'fa-triangle-exclamation';
        var msg=d.sucesso?('ONU autorizada e confirmada na OLT ('+(d.tentativas||1)+' verificação).')
                          :(d.ainda_pendente?'A OLT aceitou o comando mas a ONU AINDA aparece como pendente — confira a saída.':'A OLT retornou aviso/erro — confira abaixo.');
        // Mostra o que REALMENTE ficou gravado na OLT (srv-profile aplicado) e se bateu com a escolha
        var grav='';
        if(d.sucesso){
            var esc=(modoSel==='router')?'ONT':'ONU';
            var apl=(d.tipo_aplicado||'').toUpperCase();
            if(apl===''){
                // Não deu pra reler o perfil AGORA (ONU recém-criada) — NÃO é erro. Mostra neutro.
                grav='<div style="margin-top:6px; font-size:12px; color:'+OLTC.mut+';"><i class="fa-solid fa-circle-info"></i> Tipo escolhido: <b>'+(esc==='ONT'?'Router (ONT)':'Bridge (ONU)')+'</b> · a releitura do perfil na OLT sai no próximo ciclo (ONU recém-criada).</div>';
            } else {
                var bateu=(apl===esc);
                grav='<div style="margin-top:6px; font-size:12px; color:'+(bateu?OLTC.grn:OLTC.amb)+';"><i class="fa-solid '+(bateu?'fa-check':'fa-triangle-exclamation')+'"></i> Gravado na OLT: <b>'+(apl==='ONT'?'Router (ONT)':'Bridge (ONU)')+'</b>'+(d.srv_aplicado?(' · srv-profile <b>'+_oltEsc(d.srv_aplicado)+'</b> (id '+_oltEsc(d.srv_id||'')+')'):'')+(bateu?' — confere com a escolha':' — ATENÇÃO: diferente do que você escolheu ('+(esc==='ONT'?'Router':'Bridge')+')')+'</div>';
            }
        }
        // Resultado da redundância (removido, SmartOLT não é mais usado)
        var stM='';
        // AVISO DE RADIUS: a ONU foi autorizada na OLT (nível óptico), mas isso NÃO cria/confirma o
        // login PPPoE/IPoE no RADIUS — sem essa credencial ela não autentica no concentrador.
        var radM='';
        if(d.radius_aviso){ radM='<div style="margin-top:6px; font-size:12px; color:'+OLTC.red+'; font-weight:600;"><i class="fa-solid fa-triangle-exclamation"></i> RADIUS: '+_oltEsc(d.radius_aviso)+'</div>'; }
        // AVISO DE VLAN: sem VLAN, não houve service-port -> a ONU não tem caminho de dados nenhum
        // até o concentrador, mesmo aparecendo "autorizada" aqui em cima.
        var vlanM='';
        if(d.vlan_aviso){ vlanM='<div style="margin-top:6px; font-size:12px; color:'+OLTC.red+'; font-weight:600;"><i class="fa-solid fa-triangle-exclamation"></i> VLAN/service-port: '+_oltEsc(d.vlan_aviso)+'</div>'; }
        // (03/10/2026) ONU Bridge: o roteador do cliente é comodato? (lista do cadastro de equipamentos)
        var rotM=''; if(d.sucesso && d.equip && d.equip.perguntar_roteador){ rotM='<div id="olt_rot_box" style="margin-top:8px; padding:8px 10px; border:1px solid '+OLTC.line+'; border-radius:8px; font-size:12.5px;"><b>📶 ONU em Bridge — o roteador do cliente é comodato?</b><div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:6px; align-items:center;"><button type="button" style="cursor:pointer; padding:5px 11px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+'; font-size:12px; font-weight:700;" onclick="_oltRoteador('+d.equip.contrato_id+',1)">Sim, é comodato</button><button type="button" style="cursor:pointer; padding:5px 11px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+'; font-size:12px; font-weight:700;" onclick="_oltRoteador('+d.equip.contrato_id+',0)">Não (é do cliente)</button><select id="olt_rot_modelo" style="display:none; min-width:200px;"></select><button type="button" id="olt_rot_salvar" style="cursor:pointer; padding:5px 11px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+'; font-size:12px; font-weight:700;" style="display:none;" onclick="_oltRoteadorSalvar('+d.equip.contrato_id+')">Salvar</button></div><div id="olt_rot_msg" style="margin-top:4px; color:'+OLTC.mut+';"></div></div>'; }
        else if(d.sucesso && d.equip){ rotM='<div style="margin-top:6px; font-size:12px; color:'+OLTC.grn+';"><i class="fa-solid fa-check"></i> Contrato: '+_oltEsc(d.equip.modo)+' · comodato Sim</div>'; }
        res.innerHTML='<div style="color:'+cor+'; font-weight:700; font-size:12.5px;"><i class="fa-solid '+ic+'"></i> '+msg+'</div>'+grav+stM+radM+vlanM+rotM+
            '<pre style="white-space:pre-wrap !important; font-size:11px; color:'+OLTC.ink+' !important; background:'+OLTC.panel+' !important; border:1px solid '+OLTC.line+'; padding:8px; border-radius:7px; margin-top:6px;">'+_oltEsc(d.saida||'')+'</pre>';
        if(d.sucesso){
            var snK=String(sn).toUpperCase().replace(/[^0-9A-Z]/g,'');
            window._oltCadastro=window._oltCadastro||{}; window._oltCadastro[snK]=window._oltCadastro[snK]||{};
            // Grava a ZONA escolhida no banco local por SN -> preenche a coluna Zona (Obs10)
            if(zonaAp){
                window._oltCadastro[snK].zona=zonaAp;
                fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(sn)+'&campo=zona&valor='+encodeURIComponent(zonaAp)}).catch(function(){});
            }
            // Grava o TIPO ESCOLHIDO (Bridge->ONU / Router->ONT) -> a coluna Tipo mostra sua escolha.
            // Grava NUM POST só (zona+tipo) e CONFIRMA se salvou (se falhar em disco, o front avisa —
            // era isso que fazia "autorizar Bridge e o Tipo/Smart voltar Router e não gravar nada").
            var tipoEsc=(modoSel==='router')?'ONT':'ONU';
            window._oltCadastro[snK].tipo=tipoEsc;
            // Salva TAMBÉM o NOME DO CLIENTE aprovisionado no cadastro local (tem prioridade máxima em
            // _oltNomeDe) -> a página principal mostra o nome CERTO, sobrescrevendo o cliente ANTERIOR de
            // um ONU reusado (o bug era não gravar o nome aqui -> caía no mapa/descrição antiga).
            window._oltCadastro[snK].nome=nome;
            var _dad={tipo:tipoEsc, nome:nome}; if(zonaAp) _dad.zona=zonaAp;
            fetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=cadastro_set&serial='+encodeURIComponent(sn)+'&dados='+encodeURIComponent(JSON.stringify(_dad))})
              .then(function(r){ return r.json(); }).then(function(dd){ _oltAvisaGravacao(dd); if(oltGerenciadorAberto()) oltRenderLista(); }).catch(function(){});
            // APARECER JÁ (otimista): insere a ONU recém-autorizada na lista na hora (não espera a
            // varredura cheia, que demorava minutos) e dispara um refresh SÓ do slot em seguida.
            if(d.ont_id!=null && d.ont_id!==''){
                window._oltLista=window._oltLista||[]; var _k=fsp+'|'+d.ont_id, _ex=null;
                for(var _z=0;_z<window._oltLista.length;_z++){ var _x=window._oltLista[_z]; if((_x.fsp||'')+'|'+_x.id===_k){ _ex=_x; break; } }
                var _srvA=(d.srv_aplicado||srvNome||''); if(!_ex){ window._oltLista.push({ srv:_srvA, srvprofile:_srvA, modo:(/^ONT/i.test(_srvA)?'ONT':(_srvA?'ONU':'')), fsp:fsp, id:''+d.ont_id, serial:sn, status:'online', estado:'online', nome:nome, zona:zonaAp||'', vlan:vlan||'', modelo:'', _novo:1, _novoTs:Date.now() }); }
                else { _ex.serial=sn; _ex.nome=nome; if(zonaAp)_ex.zona=zonaAp; _ex._novoTs=Date.now(); if(_srvA){ _ex.srv=_srvA; _ex.srvprofile=_srvA; _ex.lineprofile=''; } if(!_ex.status){ _ex.status='online'; _ex.estado='online'; } }
                try{ window._oltNovoTs=window._oltNovoTs||{}; window._oltNovoTs[_k]=Date.now(); window._oltAutoriz=window._oltAutoriz||{}; var _d=new Date(); _d.setMinutes(_d.getMinutes()-_d.getTimezoneOffset()); window._oltAutoriz[snK]=Object.assign({}, window._oltAutoriz[snK]||{}, {data:_d.toISOString().slice(0,19).replace('T',' '), nome:nome}); window._oltPag=1; }catch(e){}   // topo da lista, pág. 1   // persiste o "recém-provisionada" mesmo se o objeto for recriado no scan
                if(oltGerenciadorAberto()) oltRenderLista();
            }
            if(typeof oltAtualizarSlot==='function') setTimeout(function(){ try{ oltAtualizarSlot(parseInt(slot,10)); }catch(e){} }, 1500);
            // BAIXA o card "Aguardando Liberação" NA HORA (o backend já tirou o SN do autofind) e remove
            // a ONU da lista de pendentes do modal — antes só sumia quando você atualizava.
            try{
                var _snN=String(sn).toUpperCase().replace(/[^0-9A-Z]/g,'');
                var _mSn=function(p){ return String((p&&(p.sn||p.serial))||'').toUpperCase().replace(/[^0-9A-Z]/g,''); };
                if(window._oltAutofindCache && window._oltAutofindCache.pendentes){ window._oltAutofindCache.pendentes=window._oltAutofindCache.pendentes.filter(function(p){ return _mSn(p)!==_snN; }); }
                window._oltPendentes=Math.max(0,(window._oltPendentes||1)-1);
                var _ab=document.getElementById('olt_apbtn'); if(_ab) _ab.outerHTML=_oltBotaoAprov();
            }catch(e){}
            oltCountdownFechar(res, parseInt(slot,10), (d.vlan_aviso||d.radius_aviso||(d.equip&&d.equip.perguntar_roteador))?90:30); // 30s p/ ler o resultado (60s se houver aviso de VLAN/RADIUS), com Pausar/Fechar
        }
      }).catch(function(err){ if(!res) return;
        // Tempo esgotado NÃO quer dizer que falhou: a OLT pode ter autorizado. Não reautorizar às cegas.
        if(err&&err.name==='AbortError'){ _oltConfereAutorizacao(res, sn, slot); return; }
        res.innerHTML='<span style="color:'+OLTC.red+';">Erro: '+_oltEsc(err)+'</span>'; });
}
// Tempo da tela esgotou durante a autorização: a OLT pode ter concluído. CONFERE de verdade — lê o
// autofind AO VIVO e a lista: se o SN saiu dos pendentes e/ou está na lista, mostra "autorizada"
// (antes mostrava erro com a ONU já autorizada). NÃO REMOVER.
function _oltConfereAutorizacao(res, sn, slot){
    var snN=String(sn||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    var mSn=function(x){ return String(x||'').toUpperCase().replace(/[^0-9A-Z]/g,''); };
    res.innerHTML='<span style="color:'+OLTC.acc+'; font-weight:600;"><i class="fa-solid fa-spinner fa-spin"></i> A OLT demorou para responder — conferindo se a ONU foi autorizada...</span>';
    _oltFetchDireto('olt_huawei.php?acao=autofind&force=1', 120000).then(function(r){ return r.json(); }).then(function(d){
        var pend=((d&&d.pendentes)||[]).some(function(p){ return mSn(p.sn||p.serial)===snN; });
        if(d && d.pendentes!=null && !pend){
            res.innerHTML='<div style="color:'+OLTC.grn+'; font-weight:700; font-size:12.5px;"><i class="fa-solid fa-circle-check"></i> ONU AUTORIZADA (confirmado na OLT: saiu da lista de pendentes). A resposta completa demorou; confira a ficha em instantes.</div>';
            try{ if(window._oltAutofindCache&&window._oltAutofindCache.pendentes){ window._oltAutofindCache.pendentes=window._oltAutofindCache.pendentes.filter(function(p){ return mSn(p.sn||p.serial)!==snN; }); }
                window._oltPendentes=Math.max(0,(window._oltPendentes||1)-1); var _ab=document.getElementById('olt_apbtn'); if(_ab) _ab.outerHTML=_oltBotaoAprov(); }catch(e){}
            if(typeof oltAtualizarSlot==='function') setTimeout(function(){ try{ oltAtualizarSlot(parseInt(slot,10)); }catch(e){} }, 1500);
        } else if(d && d.pendentes!=null){
            res.innerHTML='<span style="color:'+OLTC.red+'; font-weight:600;"><i class="fa-solid fa-triangle-exclamation"></i> A OLT não concluiu: a ONU continua pendente. Pode autorizar de novo.</span>';
        } else {
            res.innerHTML='<span style="color:'+OLTC.amb+'; font-weight:600;"><i class="fa-solid fa-hourglass-end"></i> Não foi possível confirmar agora (OLT ocupada). Atualize a lista antes de tentar de novo.</span>';
        }
    }).catch(function(){ res.innerHTML='<span style="color:'+OLTC.amb+'; font-weight:600;"><i class="fa-solid fa-hourglass-end"></i> Não foi possível confirmar agora (OLT ocupada). Atualize a lista antes de tentar de novo.</span>'; });
}
// Contagem regressiva de N segundos para fechar o modal, com Pausar e Fechar agora.
function oltCountdownFechar(res, slot, seg){
    if(!res) return;
    var restante=seg, pausado=false, timer=null;
    var barra=document.createElement('div');
    barra.style.cssText='display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin-top:10px; padding:9px 12px; border-radius:9px; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+';';
    barra.innerHTML='<span style="color:'+OLTC.mut+'; font-size:12px;">Fechando em <b id="olt_cd_n" style="color:'+OLTC.acc+'; font-size:14px;">'+restante+'</b>s…</span>'+
        '<button id="olt_cd_pause" style="cursor:pointer; padding:6px 12px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+'; font-size:12px; font-weight:700;"><i class="fa-solid fa-pause"></i> Pausar</button>'+
        '<button id="olt_cd_close" style="cursor:pointer; padding:6px 14px; border-radius:7px; border:none; background:'+OLTC.acc+'; color:#fff; font-size:12px; font-weight:800;"><i class="fa-solid fa-xmark"></i> Fechar agora</button>';
    res.appendChild(barra);
    function fechar(){ if(timer) clearInterval(timer); oltFecharAprov(); var ov=document.getElementById('oltOverlay'); if(ov && ov.style.display!=='none'){ oltAtualizarSlot(slot); oltCheckPendentes(); } }
    barra.querySelector('#olt_cd_close').onclick=fechar;
    var pb=barra.querySelector('#olt_cd_pause');
    pb.onclick=function(){ pausado=!pausado; pb.innerHTML=pausado?'<i class="fa-solid fa-play"></i> Retomar':'<i class="fa-solid fa-pause"></i> Pausar'; var n=barra.querySelector('#olt_cd_n'); if(n) n.style.color=pausado?OLTC.amb:OLTC.acc; };
    timer=setInterval(function(){ if(pausado) return; restante--; var n=barra.querySelector('#olt_cd_n'); if(n) n.textContent=restante; if(restante<=0) fechar(); }, 1000);
}
// Atualiza SÓ uma placa (merge) — usado após autorizar (rápido, sem varrer tudo)
function oltAtualizarSlot(slot){
    oltFetch('olt_huawei.php?acao=listar_slot&slot='+slot, null, true).then(function(r){ return r.json(); }).then(function(d){
        if(!(d&&d.status==='ok'&&d.onus)) return;
        var idx={}; (window._oltLista||[]).forEach(function(o){ idx[(o.fsp||'')+'|'+o.id]=o; });
        d.onus.forEach(function(n){ var k=(n.fsp||'')+'|'+n.id; var o=idx[k]; if(o){ if(o.status!==n.status){ o.status=n.status; o._estadoReal=false; } if(n.estado && !o._estadoReal)o.estado=n.estado; if(n.serial)o.serial=n.serial; if(n.nome)o.nome=n.nome; if(n.modelo&&!o.modelo)o.modelo=n.modelo; if(n.uptime&&!o.uptime)o.uptime=n.uptime; if((n.status||'').toLowerCase().indexOf('online')>-1){o.downtime='';}else if(n.downtime){o.downtime=n.downtime;} if(n.tipo&&n.tipo_olt){o.tipo=n.tipo; o._tipoOlt=true;} } else { window._oltLista.push(n); } });
        window._oltEstadoFeito=false; oltRenderLista(); oltEnriquecerEstadoOffline(); oltEnriquecerSinal(); oltEnriquecerDetalhe(); oltEnriquecerUptime();
    }).catch(function(){});
}

// ---------- Cliente: busca por SN e abre o dashboard ----------
function oltJanelaTamanho(w,h){ var el=document.getElementById('oltWin'); if(el && el.getAttribute('data-max')!=='1'){ el.style.width=w; el.style.height=h; } }
// Abre pelo ícone do cliente -> janela flutuante própria (não mexe na lista)
function abrirOltCliente(login, nomeCompletoEnc){
    var nome=decodeURIComponent(nomeCompletoEnc||login||'');
    // serial já na criação -> a janela ÚNICA por cliente funciona (não colide com outro cliente em loading). (#6)
    var id=oltNovaJanelaONU({ fsp:'', id:'', serial:(login||''), status:'', nome:nome, zona:'', vlan:'', uptime:'', rx:'', tx:'', _loading:true });
    if(window._oltWins[id] && !window._oltWins[id]._loading){ return; } // já estava aberta p/ este cliente -> só trouxe pra frente
    var sn=String(login||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
    // 1) INSTANTÂNEO: se a ONU já está na lista em memória (cache), abre na hora.
    var achou=null; (window._oltLista||[]).forEach(function(o){ if(String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'')===sn) achou=o; });
    if(achou){ var o2={}; for(var kk in achou) o2[kk]=achou[kk]; o2.nome=nome||o2.nome; window._oltWins[id]=o2; oltRenderDash(id); return; }
    var bd=document.getElementById('oltWinBody_'+id); if(bd) bd.innerHTML=_oltSpinner('Localizando ONU do cliente...');
    // 2) tenta o cache do servidor (rápido, sem OLT)
    fetch('olt_huawei.php?acao=cache_get').then(function(r){ return r.json(); }).then(function(c){
        // Sem sessão do Gerenciador OLT (login separado do WellSystem): fecha esta janelinha e
        // abre o login embutido da OLT — em vez de mostrar a mensagem crua "Sessão expirada...".
        // Ao entrar, é só clicar no ícone de novo.
        if(_oltAuthErro(c)){ oltFecharJanela(id); return; }
        var found=null; if(c&&c.onus) c.onus.forEach(function(o){ if(String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'')===sn) found=o; });
        if(found){ found.nome=nome||found.nome; window._oltWins[id]=found; oltRenderDash(id); return; }
        // 3) fallback: consulta direta na OLT (prioridade)
        oltFetch('olt_huawei.php?acao=buscar_cliente&login='+encodeURIComponent(login||''), null, true)
          .then(function(r){ return r.json(); })
          .then(function(d){ var b=document.getElementById('oltWinBody_'+id);
            if(_oltAuthErro(d)){ oltFecharJanela(id); return; }
            if(!d||d.status!=='ok'||!d.onu){ if(b) b.innerHTML='<div style="color:'+OLTC.amb+'; padding:20px;"><i class="fa-solid fa-triangle-exclamation"></i> '+_oltEsc((d&&d.message)||'ONU não localizada.')+'</div>'; return; }
            d.onu.nome=d.onu.nome||nome; window._oltWins[id]=d.onu; oltRenderDash(id); })
          .catch(function(err){ var b=document.getElementById('oltWinBody_'+id); if(b) b.innerHTML='<div style="color:'+OLTC.red+'; padding:20px;">Erro: '+_oltEsc(err)+'</div>'; });
    }).catch(function(){
        oltFetch('olt_huawei.php?acao=buscar_cliente&login='+encodeURIComponent(login||''), null, true).then(function(r){ return r.json(); }).then(function(d){ var b=document.getElementById('oltWinBody_'+id);
            if(_oltAuthErro(d)){ oltFecharJanela(id); return; }
            if(d&&d.status==='ok'&&d.onu){ d.onu.nome=d.onu.nome||nome; window._oltWins[id]=d.onu; oltRenderDash(id); } else if(b){ b.innerHTML='<div style="color:'+OLTC.amb+'; padding:20px;">ONU não localizada.</div>'; } });
    });
}
// Abre pela lista -> janela flutuante própria; a lista continua aberta
function oltAbrirONU(fsp,id,serial,status,nomeEnc,zonaEnc,vlan){
    var full=null; (window._oltLista||[]).forEach(function(o){ if((o.fsp||'')===fsp && (''+(o.id))===(''+id)) full=o; });
    var o = full || { fsp:fsp, id:id, serial:serial, status:status, nome:decodeURIComponent(nomeEnc||''), zona:decodeURIComponent(zonaEnc||''), vlan:vlan||'' };
    oltNovaJanelaONU({ fsp:o.fsp, id:o.id, serial:o.serial, status:o.status, nome:o.nome, zona:o.zona, vlan:o.vlan, modelo:o.modelo||'', uptime:o.uptime||'', rx:o.rx||'', tx:o.tx||'' });
}

// ================= JANELAS FLUTUANTES POR ONU (múltiplas simultâneas) =========
window._oltWins = window._oltWins || {};
window._oltWinSeq = window._oltWinSeq || 0;
window._oltZ = window._oltZ || 100000;

function oltNovaJanelaONU(o){
    // Janela ÚNICA por cliente: se já há uma aberta para esta ONU (mesmo serial ou F/S/P+ID),
    // traz pra frente em vez de abrir outra. Clientes diferentes abrem janelas simultâneas. (#6)
    var _chave=(o&&o.serial)?('sn:'+String(o.serial).toUpperCase().replace(/[^0-9A-Z]/g,'')):('fi:'+((o&&o.fsp)||'')+'|'+((o&&o.id)||''));
    for(var _wid in window._oltWins){ var _wo=window._oltWins[_wid]; if(!_wo) continue;
        var _wk=_wo.serial?('sn:'+String(_wo.serial).toUpperCase().replace(/[^0-9A-Z]/g,'')):('fi:'+(_wo.fsp||'')+'|'+(_wo.id||''));
        if(_wk===_chave && document.getElementById('oltWin_'+_wid)){ oltFrente(_wid); var _b=document.getElementById('oltWinBody_'+_wid); if(_b && _b.style.display==='none'){ _oltJanMostrarCorpo(_wid); } return _wid; }
    }
    var id='w'+(++window._oltWinSeq);
    window._oltWins[id]=o;
    var n=Object.keys(window._oltWins).length;
    var off=((n-1)%7)*26;
    var win=document.createElement('div');
    win.id='oltWin_'+id;
    // Posicao em pixel INTEIRO (Math.round) — evita meio-pixel do calc(50%...) que borra o texto no Chrome/Windows.
    var _wLeft=Math.round((window.innerWidth/2) - 280) + off; if(_wLeft<8) _wLeft=8;
    win.style.cssText='position:fixed; z-index:'+(window._oltResumoZ=(window._oltResumoZ||2147482000)+1)+'; top:'+(56+off)+'px; left:'+_wLeft+'px; width:min(92vw,560px); max-height:82vh; display:flex; flex-direction:column; background:'+OLTC.bg+'; color:'+OLTC.txt+'; border:1px solid '+OLTC.bg2+'; border-radius:14px; box-shadow:0 24px 70px rgba(0,0,0,0.6); overflow:hidden;';
    win.onmousedown=function(){ oltFrente(id); };
    var bt='cursor:pointer; width:28px; height:26px; border-radius:7px; border:1px solid '+OLTC.line+'; background:transparent;';
    win.innerHTML=
      '<div id="oltWinHead_'+id+'" style="flex:0 0 auto; display:flex; align-items:center; gap:8px; padding:11px 14px; background:'+OLTC.bg2+'; border-bottom:1px solid '+OLTC.line+'; cursor:move;">'+
        '<i class="fa-solid fa-diagram-project" style="color:'+OLTC.amb+';"></i>'+
        '<div style="flex:1 1 auto; min-width:0;"><div id="oltWinTit_'+id+'" style="font-weight:800; font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:'+OLTC.ink+';">'+_oltEsc(_oltNomeDe(o)||o.serial||'ONU')+'</div><div id="oltWinSubT_'+id+'" style="font-size:10.5px; color:'+OLTC.mut+';">'+_oltEsc((o.fsp||'')+((o.id!==''&&o.id!=null)?(' · ID '+o.id):''))+'</div></div>'+
        '<span id="oltWinCd_'+id+'" title="Atualização automática da informação (sem fechar a janela)" style="flex:0 0 auto; display:inline-flex; align-items:center; gap:5px; font-size:10.5px; font-weight:700; color:'+OLTC.acc+'; background:'+OLTC.panel+'; border:1px solid '+OLTC.line+'; border-radius:20px; padding:3px 9px; white-space:nowrap;"><i class="fa-solid fa-rotate"></i> atualiza em <span id="oltWinCdN_'+id+'">15</span>s</span>'+
        '<button onclick="oltJanMin(\''+id+'\')" title="Minimizar" style="'+bt+' color:'+OLTC.txt+';"><i class="fa-solid fa-minus"></i></button>'+
        '<button onclick="oltJanMax(\''+id+'\')" title="Maximizar / Restaurar" style="'+bt+' color:'+OLTC.acc+';"><i class="fa-solid fa-expand"></i></button>'+
        '<button onclick="oltFecharJanela(\''+id+'\')" title="Fechar esta ONU" style="'+bt+' color:'+OLTC.red+';"><i class="fa-solid fa-xmark"></i></button>'+
      '</div>'+
      '<div id="oltWinBody_'+id+'" style="flex:1 1 auto; overflow:auto; padding:10px;"></div>';
    document.body.appendChild(win);
    oltDragify(win, document.getElementById('oltWinHead_'+id));
    oltResizify(win, 380, 260); // arrastar o canto p/ aumentar/diminuir
    if(!o._loading) oltRenderDash(id);
    oltJanIniciarTimer(id);
    return id;
}
// Countdown + auto-atualização da janela da ONU (sem fechar). Usa os dados já frescos
// do auto-sync de 5s (window._oltLista) — não abre conexão extra na OLT.
window._oltWinTimers = window._oltWinTimers || {};
function oltJanIniciarTimer(id){
    if(window._oltWinTimers[id]) clearInterval(window._oltWinTimers[id]);
    var restante=15;
    window._oltWinTimers[id]=setInterval(function(){
        if(!document.getElementById('oltWin_'+id)){ clearInterval(window._oltWinTimers[id]); delete window._oltWinTimers[id]; return; }
        restante--;
        var cd=document.getElementById('oltWinCdN_'+id); if(cd) cd.textContent=(restante>0?restante:0);
        if(restante<=0){ restante=15; oltJanAtualizar(id);
            // TEMPO REAL: relê o sinal óptico (rx/tx/rx-olt) + uptime direto da OLT a cada ciclo (15s),
            // não só do cache — essencial pra atendimento. Atualiza os cards do topo mesmo com painel aberto.
            var _o=window._oltWins[id];
            // Não relê enquanto uma consulta manual (Service-port, Portas LAN...) está na OLT: as duas
            // disputavam a pouca sessão Telnet da MA5683T e o login falhava ("nao chegou ao prompt").
            if(_o && !window._oltPausarFundo && (''+(_o.status||'')).toLowerCase().indexOf('online')>-1 && typeof oltCarregarComboW==='function') oltCarregarComboW(id);
        }
    },1000);
}
function oltJanAtualizar(id){
    var o=window._oltWins[id]; if(!o) return;
    var fresh=null; (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===(o.fsp||'') && (''+x.id)===(''+o.id)) fresh=x; });
    if(!fresh) return;
    var mudou=(o.status!==fresh.status)||(o.estado!==fresh.estado)||(o.rx!==fresh.rx)||(o.rx_olt!==fresh.rx_olt)||(o.uptime!==fresh.uptime)||(o.vlan!==fresh.vlan);
    o.status=fresh.status; o.estado=fresh.estado; o.rx=fresh.rx; o.rx_olt=fresh.rx_olt; o.uptime=fresh.uptime; o.vlan=fresh.vlan; o.modelo=fresh.modelo||o.modelo; o.nome=fresh.nome||o.nome; o.zona=fresh.zona||o.zona;
    var painel=document.getElementById('olt_painel_'+id);
    var painelAtivo = painel && painel.style.display!=='none' && painel.innerHTML.replace(/\s/g,'')!=='';
    if(mudou && !painelAtivo) oltRenderDash(id); // só re-renderiza se mudou e não há resultado aberto
}
function _oltJanMostrarCorpo(id){ var b=document.getElementById('oltWinBody_'+id); if(!b) return; b.style.display='block'; if(!b.innerHTML.replace(/\s/g,'') && window._oltWins[id] && window._oltWins[id].fsp) oltRenderDash(id); }
function oltJanMax(id){ var w=document.getElementById('oltWin_'+id); if(!w) return; var mx=w.getAttribute('data-max')==='1'; if(mx){ w.setAttribute('data-max','0'); w.style.width='min(94vw,640px)'; w.style.height=''; w.style.maxHeight='86vh'; w.style.top='56px'; var _rl=Math.round((window.innerWidth/2)-320); if(_rl<8)_rl=8; w.style.left=_rl+'px'; w.style.borderRadius='14px'; } else { w.setAttribute('data-max','1'); w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.top='0'; w.style.left='0'; w.style.borderRadius='0'; } _oltJanMostrarCorpo(id); oltFrente(id); }
function oltJanMin(id){ var w=document.getElementById('oltWin_'+id); if(!w) return;
    // Minimiza a JANELA INTEIRA pra uma pílula no rodapé (igual às outras janelas), não só recolhe o corpo.
    w.style.display='none';
    var o=window._oltWins[id]||{}; var tit=(_oltNomeDe(o)||o.serial||'ONU'); var pid='oltWin_'+id+'Pill';
    var old=document.getElementById(pid); if(old) old.remove();
    var pill=document.createElement('button'); pill.id=pid; pill.className='oltMinPill';
    pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:2147483300; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#dc2626; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap; max-width:240px; overflow:hidden; text-overflow:ellipsis;';
    pill.innerHTML='<i class="fa-solid fa-microchip"></i> '+_oltEsc(tit)+' <i class="fa-solid fa-up-right-and-down-left-from-center" style="font-size:10px; opacity:.8;"></i>';
    pill.onclick=function(){ var ww=document.getElementById('oltWin_'+id); if(ww){ ww.style.display='flex'; ww.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); } pill.remove(); _oltPillsArrumar(); };
    document.body.appendChild(pill); _oltPillsArrumar();
}
function oltFecharJanela(id){ var w=document.getElementById('oltWin_'+id); if(w) w.remove(); delete window._oltWins[id]; if(window._oltWinTimers&&window._oltWinTimers[id]){ clearInterval(window._oltWinTimers[id]); delete window._oltWinTimers[id]; } }
function oltFrente(id){ var w=document.getElementById('oltWin_'+id); if(w) w.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); }
// Maximizar/restaurar GENÉRICO. Maximizada => data-max="1" e o arraste fica BLOQUEADO.
function _oltJanMax(id){ var w=document.getElementById(id); if(!w) return;
    var h=w.querySelector('[id$="Head"]');
    if(w.getAttribute('data-max')==='1'){ var g=(w.getAttribute('data-geo')||'').split('|');
        w.style.top=g[0]||'60px'; w.style.left=g[1]||'60px'; w.style.width=g[2]||'min(96vw,640px)'; w.style.height=g[3]||''; w.style.maxHeight='86vh'; w.style.borderRadius='14px'; w.setAttribute('data-max','0');
        if(h) h.style.cursor='move';
    } else { w.setAttribute('data-geo', w.style.top+'|'+w.style.left+'|'+w.style.width+'|'+w.style.height);
        w.style.top='0'; w.style.left='0'; w.style.width='100vw'; w.style.height='100vh'; w.style.maxHeight='100vh'; w.style.borderRadius='0'; w.setAttribute('data-max','1');
        if(h) h.style.cursor='default';
    } }
// Minimizar GENÉRICO: esconde a janela e deixa uma "pílula" ancorada na PARTE DE BAIXO da página.
function _oltJanMin(winId, bodyId, titulo, icone){
    var w=document.getElementById(winId); if(!w) return;
    w.style.display='none';
    var pid=winId+'Pill'; var old=document.getElementById(pid); if(old) old.remove();
    var pill=document.createElement('button'); pill.id=pid; pill.className='oltMinPill';
    pill.style.cssText='position:fixed; bottom:14px; left:14px; z-index:2147483300; cursor:pointer; padding:10px 16px; border-radius:30px; border:none; background:#dc2626; color:#fff; font-weight:800; font-size:12.5px; box-shadow:0 6px 20px rgba(0,0,0,0.4); display:flex; align-items:center; gap:8px; white-space:nowrap;';
    pill.innerHTML='<i class="fa-solid '+icone+'"></i> '+titulo+' <i class="fa-solid fa-up-right-and-down-left-from-center" style="font-size:10px; opacity:.8;"></i>';
    pill.onclick=function(){ var ww=document.getElementById(winId); if(ww){ ww.style.display='flex'; ww.style.zIndex=(window._oltResumoZ=(window._oltResumoZ||2147482000)+1); } pill.remove(); _oltPillsArrumar(); };
    document.body.appendChild(pill);
    _oltPillsArrumar();
}
// Empilha as pílulas minimizadas lado a lado no rodapé, sem sobrepor.
function _oltPillsArrumar(){ var ps=document.querySelectorAll('.oltMinPill'); var x=14;
    for(var i=0;i<ps.length;i++){ var p=ps[i];
        if(p.style.display==='none'){ continue; }               // pílula escondida não ocupa lugar
        p.style.bottom='14px'; p.style.left=x+'px'; p.style.right='auto'; p.style.transform='none';
        x+=p.offsetWidth+10;
        if(x>window.innerWidth-120){ x=14; }                    // quebra se encher a linha
    } }
function oltDragify(win, handle){
    if(!handle) return;
    handle.addEventListener('mousedown', function(e){
        if(e.target.closest('button')) return;
        if(win.getAttribute('data-max')==='1') return; // MAXIMIZADA: não arrasta
        e.preventDefault();
        var sx=e.clientX, sy=e.clientY, r=win.getBoundingClientRect(), ox=r.left, oy=r.top;
        win.style.left=ox+'px'; win.style.top=oy+'px'; win.style.right='auto';
        function mv(ev){ win.style.left=(ox+ev.clientX-sx)+'px'; win.style.top=Math.max(0,(oy+ev.clientY-sy))+'px'; }
        function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
        document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
    });
}
// Redimensionar arrastando: adiciona uma alça no canto inferior direito da janela.
function oltResizify(win, minW, minH){
    if(!win) return; minW=minW||320; minH=minH||200;
    var h=document.createElement('div'); h.className='oltResizeGrip';
    h.style.cssText='position:absolute; right:1px; bottom:1px; width:18px; height:18px; cursor:nwse-resize; z-index:6; display:flex; align-items:flex-end; justify-content:flex-end;';
    h.innerHTML='<svg width="14" height="14" viewBox="0 0 14 14" style="opacity:.55;"><path d="M13 5 L5 13 M13 9 L9 13" stroke="'+OLTC.mut+'" stroke-width="1.4" fill="none" stroke-linecap="round"/></svg>';
    h.addEventListener('mousedown', function(e){ e.preventDefault(); e.stopPropagation();
        var r=win.getBoundingClientRect(); var sx=e.clientX, sy=e.clientY, sw=r.width, sh=r.height;
        win.style.maxHeight='none'; win.style.maxWidth='none'; // libera p/ crescer além dos limites iniciais
        function mv(ev){ win.style.width=Math.max(minW, sw+(ev.clientX-sx))+'px'; win.style.height=Math.max(minH, sh+(ev.clientY-sy))+'px'; }
        function up(){ document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); }
        document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
    });
    win.appendChild(h);
}
function _oltCard(rot,val,mono,full,wrap){ var plain=(''+val).replace(/<[^>]*>/g,'');
    var _pal=[OLTC.acc, OLTC.grn, OLTC.red, OLTC.amb, OLTC.vio]; var _cor=_pal[(window._oltCardIdx=(window._oltCardIdx||0))%_pal.length]; window._oltCardIdx++;
    return '<div style="background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+'; border-radius:5px; padding:4px 6px; min-width:0;'+(full?' grid-column:1/-1;':'')+'"><div title="'+_oltEsc(rot)+'" style="font-size:8px; color:'+_cor+'; font-weight:800; text-transform:uppercase; letter-spacing:.3px; margin-bottom:1px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+rot+'</div><div title="'+_oltEsc(plain)+'" style="font-size:10.5px; font-weight:700; color:'+OLTC.ink+'; '+(mono?'font-family:monospace;':'')+' white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+val+'</div></div>'; }
// Preenche (1x) a data de autorização das ONUs SEM registro com a data de HOJE (congelada).
// Daqui pra frente cada liberação pelo app grava a data real. Atualiza em memória e chama cb.
function _oltAuthBackfillHoje(cb){
    if(window._oltAuthBkDone){ if(cb) cb(); return; }
    window._oltAuthBkDone=1;
    var L=window._oltLista||[]; var A=window._oltAutoriz||{}; var faltam=[];
    L.forEach(function(o){ var k=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); if(k && !(A[k]&&A[k].data)) faltam.push(o.serial); });
    if(!faltam.length){ if(cb) cb(); return; }
    var hoje=new Date().toISOString().slice(0,10);   // YYYY-MM-DD
    oltFetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=auth_backfill&sns='+encodeURIComponent(JSON.stringify(faltam))}, true, 200000)
      .then(function(r){return r.json();}).then(function(d){
        faltam.forEach(function(sn){ var k=String(sn).toUpperCase().replace(/[^0-9A-Z]/g,''); if(!window._oltAutoriz[k]) window._oltAutoriz[k]={sn:sn}; if(!window._oltAutoriz[k].data) window._oltAutoriz[k].data=hoje; });
        if(cb) cb();
      }).catch(function(){ if(cb) cb(); });
}
function oltRenderDash(id){
    var o=window._oltWins[id]; if(!o) return;
    var b=document.getElementById('oltWinBody_'+id); if(!b) return;
    var t=document.getElementById('oltWinTit_'+id); if(t) t.textContent=(_oltNomeDe(o)||o.serial||'ONU');
    var s=document.getElementById('oltWinSubT_'+id); if(s){ s.textContent=(o.fsp||'')+((o.id!==''&&o.id!=null)?(' · ID '+o.id):''); }   // sem serial no topo (fica só no card)
    var pon=(o.fsp||'').split('/'); var C=_oltCard; window._oltCardIdx=0;   // reinicia a rotação de cores dos rótulos
    var info='<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(88px,1fr)); gap:4px; margin-bottom:5px;">'+
        C('Status','<span style="color:'+((o.status||'').toLowerCase().indexOf('online')>-1?OLTC.grn:OLTC.red)+';">'+_oltEsc(o.status||'-')+'</span>')+
        C('Tempo online','<span id="olt_uptime_'+id+'">'+_oltEsc(o.uptime||'—')+'</span>')+
        C('Zona', _oltEsc(o.zona||'-'))+
        C('Placa', _oltEsc(pon[1]||'-'))+
        C('Porta PON', _oltEsc(pon[2]||'-'))+
        C('ID ONT', _oltEsc(o.id||'-'))+
        C('VLAN', _oltEsc(o.vlan||'-'))+
        C('Status Porta WAN', '<span id="olt_wan_'+id+'"><i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+'; font-size:11px;"></i></span>')+
        C('Perfil ONT/ONU', '<span id="olt_perf_'+id+'">'+_oltPerfilBadge(o)+'</span>', false, true)+
        C('Serial', _oltEsc(o.serial||'-'), true)+
        C('Rx ONU (entrada ↓)', '<span id="olt_rx_'+id+'">'+_oltEsc(o.rx||'—')+'</span>')+
        C('Tx ONU (saída ↑)', '<span id="olt_tx_'+id+'">'+_oltEsc(o.tx||'—')+'</span>')+
        C('Rx OLT (retorno ↩)', '<span id="olt_rxolt_'+id+'">'+_oltEsc(o.rx_olt||'—')+'</span>')+
        C('Descrição na OLT', _oltEsc(_oltNomeDe(o)||o.nome||'-'), false, true)+
    '</div>';
    window._oltBtnIdx=0;   // reinicia a rotação de cores dos botões de INFORMAÇÕES
    var btInfo='<div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:9px;">'+
        _oltBtnO('fa-circle-info','Obter Status',"oltInfoW('"+id+"','onu_uptime')")+
        _oltBtnO('fa-wave-square','Sinal óptico',"oltInfoW('"+id+"','onu_optico')")+
        _oltBtnO('fa-network-wired','VLAN / Service-port',"oltInfoW('"+id+"','onu_vlan')")+
        _oltBtnO('fa-ethernet','Portas LAN',"oltInfoW('"+id+"','onu_portas')")+
        _oltBtnO('fa-gauge-high','Tráfego',"oltInfoW('"+id+"','onu_trafego')")+
        '<div title="Data de ativação (dia/mês/ano)" style="flex:1 1 auto; min-width:132px; padding:7px 10px; border-radius:8px; border:1px solid '+OLTC.grn+'; background:'+OLTC.grn+'12; color:'+OLTC.ink+'; display:flex; align-items:center; justify-content:center; gap:6px; font-size:11px; font-weight:700; white-space:nowrap;"><i class="fa-solid fa-calendar-check" style="color:'+OLTC.grn+';"></i> Ativação: '+_oltEsc(_oltDataAtivacao(o)||'—')+'</div>'+
    '</div>';
    var desativada=(o.estado||'').toLowerCase()==='deactivated';
    var btAcao='<div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:9px;">'+
        _oltBtnS('fa-rotate-right','Reiniciar',"oltControleW('"+id+"','reboot','Reiniciar (reboot) esta ONU?')", OLTC.amb, '#ffffff')+
        _oltBtnS('fa-arrows-rotate','Ressincronizar',"oltControleW('"+id+"','resync','Ressincronizar (desativar e reativar) esta ONU?')", OLTC.acc, '#ffffff')+
        _oltBtnS('fa-ban', desativada?'Já desativada':'Bloquear',"oltControleW('"+id+"','block','BLOQUEAR o cliente (corta o sinal)?')", OLTC.red, '#ffffff', desativada)+
        _oltBtnS('fa-circle-check', desativada?'Liberar':'Já liberada',"oltControleW('"+id+"','unblock','Liberar (desbloquear) o cliente?')", OLTC.grn, '#ffffff', !desativada)+
        _oltBtnS('fa-right-left','Trocar modo',"oltTrocarModo('"+id+"')", OLTC.vio, '#ffffff')+
        // Trocar/recriar VLAN (service-port) na OLT — mesma tela do "+" da coluna VLAN da lista
        _oltBtnS('fa-network-wired','Trocar VLAN',"oltEditarVlanNome('"+_oltEsc(((''+(o.vlan||'')).replace(/[^0-9]/g,''))||_oltPortaVlan(o.fsp||''))+"','"+_oltEsc(o.fsp||'')+"','"+_oltEsc(o.id)+"')", OLTC.amb, '#ffffff')+
        _oltBtnS('fa-microchip','Perfil genérico',"oltTrocarPerfilGen('"+id+"')", OLTC.acc, '#ffffff')+
        _oltBtnS('fa-triangle-exclamation','Reset de fábrica',"oltControleW('"+id+"','factory','ATENCAO: RESET DE FABRICA apaga a config da ONU. Continuar?')", '#9a3412', '#ffffff')+
        _oltBtnS('fa-trash','Deletar',"oltControleW('"+id+"','delete','DELETAR esta ONU da OLT? Ação irreversível.')", '#b91c1c', '#ffffff')+
    '</div>';
    var painel='<div id="olt_painel_'+id+'" style="display:none; background:'+OLTC.panel+'; border:1px solid '+OLTC.line+'; border-radius:10px; padding:12px;"></div>';
    var lbl=function(x){ return '<div style="font-size:11px; color:'+OLTC.mut+'; text-transform:uppercase; letter-spacing:.5px; margin-bottom:7px; font-weight:700;">'+x+'</div>'; };
    // CABEÇALHO estilo SmartOLT: equipamento + nome + chips de estado/sinal/modo/VLAN.
    var _on=(o.status||'').toLowerCase().indexOf('online')>-1; var _tp=(_oltTipoDe(o)||'ONU'); var _sig=o.rx_olt||o.rx||'';
    var _chip=function(txt,cor,bg){ return '<span style="display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:800; color:'+cor+'; background:'+bg+'; border:1px solid '+cor+'44;">'+txt+'</span>'; };
    var header='<div style="display:flex; gap:14px; align-items:center; margin-bottom:14px; padding:14px; border-radius:12px; background:'+OLTC.bg2+'; border:1px solid '+OLTC.line+';">'+
        '<div id="olt_hicon_'+id+'" data-mk="'+_oltEsc(_oltImgKey(o))+'" onclick="oltModeloImg(\''+encodeURIComponent(_oltImgKey(o))+'\',event)" style="cursor:pointer; flex:0 0 auto; width:62px; height:62px; border-radius:12px; background:'+OLTC.panel+'; overflow:hidden; display:flex; align-items:center; justify-content:center; border:1px solid '+OLTC.line+';"><i class="fa-solid '+(_tp==='ONT'?'fa-wifi':'fa-network-wired')+'" style="font-size:26px; color:'+OLTC.acc+';"></i></div>'+
        '<div style="flex:1 1 auto; min-width:0;">'+
          '<div style="font-size:15px; font-weight:800; color:'+OLTC.ink+'; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+(function(){ var _nm=_oltNomeDe(o)||o.serial||'ONU'; return '<span onclick="oltAbrirCadastro(\''+_oltEsc(o.serial)+'\')" title="Abrir cadastro no ERP" style="cursor:pointer; text-decoration:underline;">'+_oltEsc(_nm)+'</span> <i class="fa-regular fa-copy" onclick="_oltCopiar(\''+_oltEsc(_nm).replace(/'/g,"\\'")+'\')" title="Clique para copiar o nome" style="cursor:pointer; font-size:12px; color:'+OLTC.grn+'; opacity:.85; margin-left:4px;"></i>'; })()+'</div>'+
          '<div style="font-size:10.5px; color:'+OLTC.mut+'; margin:2px 0 9px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">'+(function(){ var _sn=String(o.serial||'').toLowerCase(); return _sn?('<span onclick="_oltCopiar(\''+_oltEsc(_sn)+'\')" title="Clique para copiar o serial" style="cursor:pointer; text-transform:lowercase; border-bottom:1px dotted '+OLTC.mut+';">'+_oltEsc(_sn)+'<i class="fa-regular fa-copy" style="font-size:11px; color:'+OLTC.grn+'; opacity:.85; margin-left:6px;"></i></span>'):''; })()+' · '+_oltEsc(o.fsp||'')+((o.id!==''&&o.id!=null)?(' · ID '+o.id):'')+'</div>'+
          '<div style="display:flex; flex-wrap:nowrap; gap:6px; overflow-x:auto; align-items:center; padding-bottom:2px;">'+
            _chip('<i class="fa-solid fa-circle" style="font-size:7px;"></i> '+(_on?'ONLINE':'OFFLINE'), _on?OLTC.grn:OLTC.red, (_on?OLTC.grn:OLTC.red)+'1f')+
            '<span id="olt_hsig_'+id+'">'+(_sig?_chip('<i class="fa-solid fa-wave-square"></i> '+_oltEsc((''+_sig).replace(/\s*dBm/i,''))+' dBm', OLTC.acc, OLTC.acc+'1f'):'')+'</span>'+
            _chip('<i class="fa-solid fa-right-left"></i> '+(_tp==='ONT'?'Router':'Bridge'), OLTC.vio, OLTC.vio+'1f')+
            (o.vlan?_chip('VLAN '+_oltEsc(o.vlan), OLTC.mut, OLTC.panel):'')+
            (function(){ var _k=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var _au=(window._oltAutoriz||{})[_k]; return (_au&&_au.data)?('<span title="Ativação (dia/mês/ano)">'+_chip('<i class="fa-solid fa-calendar-check"></i> '+_oltEsc(_oltDMA(_au.data)), OLTC.grn, OLTC.grn+'1f')+'</span>'):''; })()+
          '</div>'+
        '</div>'+
    '</div>';
    // (Gráfico de histórico de sinal REMOVIDO da janela — o card Rx/Tx já atualiza em tempo real via
    //  Telnet a cada 15s. O histórico continua na página "Gráficos de Sinal".)
    b.innerHTML=header+info+lbl('Informações')+btInfo+lbl('Controle da ONU')+btAcao+painel;
    // #8: carrega as autorizações 1x (data de liberação por serial) e re-renderiza p/ mostrar o card.
    if(!window._oltAutoriz){ window._oltAutoriz={}; fetch('olt_huawei.php?acao=auth_get').then(function(r){return r.json();}).then(function(d){ if(d&&d.autoriz){ window._oltAutoriz=d.autoriz; } _oltAuthBackfillHoje(function(){ if(document.getElementById('oltWinBody_'+id)) oltRenderDash(id); }); }).catch(function(){}); }
    // Foto do modelo (mesma do cadastro) no lugar do ícone. Tenta a chave do MODELO e, se não
    // houver cadastro nela, tenta a chave do SERIAL (a foto pode ter sido salva por qualquer uma).
    (function(){ window._oltModeloImgCache=window._oltModeloImgCache||{}; var K=window._oltModeloImgKeys||[];
        var _cands=[]; var _mk=(o.modelo&&o.modelo!=='—')?String(o.modelo).toUpperCase().trim():''; var _sk=String(o.serial||'').toUpperCase().trim();
        if(_mk && K.indexOf(_mk)>-1) _cands.push(_mk); if(_sk && K.indexOf(_sk)>-1 && _cands.indexOf(_sk)<0) _cands.push(_sk);
        if(!_cands.length) return;
        var _hput=function(src){ if(!src) return; var bx=document.getElementById('olt_hicon_'+id); if(bx) { bx.innerHTML='<img src="'+src+'" style="width:100%; height:100%; object-fit:contain; cursor:pointer;">'; bx.onclick=function(ev){oltModeloImg(encodeURIComponent(_oltImgKey(o)),ev)}; } };
        var _tenta=function(i){ if(i>=_cands.length) return; var k=_cands[i];
            if(window._oltModeloImgCache[k]!=null){ if(window._oltModeloImgCache[k]) _hput(window._oltModeloImgCache[k]); else _tenta(i+1); return; }
            fetch('olt_huawei.php?acao=modelo_img_get&chave='+encodeURIComponent(k),null,true).then(function(r){return r.json();}).then(function(d){ var src=(d&&d.img)||''; window._oltModeloImgCache[k]=src; if(src) _hput(src); else _tenta(i+1); }).catch(function(){ _tenta(i+1); });
        }; _tenta(0);
    })();
    if(o.fsp && o.id!=='' && o.id!=null){
        oltCarregarComboW(id); // 1 sessão Telnet: sinal + uptime + status da porta WAN (bem mais rápido)
    }
}
// Card "Status Porta WAN": velocidade do uplink do cliente.
//  • ONT (Router): não tem WAN elétrica — o uplink é a ÓPTICA (SFP). Se online = Giga 1000.
//  • ONU (Bridge): a porta LAN vai no cabo até a WAN do roteador — lê a velocidade REAL negociada
//    da porta LAN (1000 ou 100) via "display ont port state ... eth-port all".
function oltCarregarWanW(id){
    var o=window._oltWins[id]; if(!o||!o.fsp||o.id===''||o.id==null) return;
    var el=document.getElementById('olt_wan_'+id); if(!el) return;
    var online=(o.status||'').toLowerCase().indexOf('online')>-1;
    if(!online){ el.innerHTML='<span style="color:'+OLTC.mut+';">— (offline)</span>'; return; }
    var _dot='<i class="fa-solid fa-circle" style="font-size:7px; vertical-align:middle;"></i> ';
    if(_oltTipoDe(o)==='ONT'){ // Router -> uplink óptico (SFP) = Giga 1000
        el.innerHTML='<span style="color:'+OLTC.grn+'; font-weight:800;">'+_dot+'UP</span> <span style="color:'+OLTC.mut+'; font-weight:600; font-size:10.5px;">1000M · óptica</span>';
        return;
    }
    // ONU Bridge -> lê a porta LAN (velocidade negociada com a WAN do roteador)
    window._oltWinWan=window._oltWinWan||{};
    // Mostra o ÚLTIMO valor bom enquanto relê (evita "piscar" pra DOWN sem motivo).
    el.innerHTML=window._oltWinWan[id]||'<i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+'; font-size:11px;"></i>';
    oltFetch('olt_huawei.php?acao=onu_portas&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id), null, true)
      .then(function(r){ return r.json(); }).then(function(d){ _oltAplicarWanRaw(id,(d&&d.saida)||''); })
      .catch(function(){ _manterUltimoWan(id); });
}
// Formata o card "Status Porta WAN" a partir da saída crua de "ont port state ... eth-port all".
// Separado do fetch pra ser reaproveitado pelo COMBO (evita 2ª sessão Telnet).
function _oltManterUltimoWan(id){ var e=document.getElementById('olt_wan_'+id); if(!e) return; window._oltWinWan=window._oltWinWan||{}; e.innerHTML=window._oltWinWan[id]||'<span style="color:'+OLTC.mut+';">—</span>'; }
var _manterUltimoWan=_oltManterUltimoWan;
function _oltAplicarWanRaw(id,raw){
        if(!window._oltWins[id]) return;
        var e2=document.getElementById('olt_wan_'+id); if(!e2) return;
        window._oltWinWan=window._oltWinWan||{};
        var _manterUltimo=function(e){ if(!e) return; e.innerHTML=window._oltWinWan[id]||'<span style="color:'+OLTC.mut+';">—</span>'; };
        var _dot='<i class="fa-solid fa-circle" style="font-size:7px; vertical-align:middle;"></i> ';
        // Leitura vazia / erro / ONU não respondeu o comando -> NÃO marca DOWN, mantém o último bom.
        if(!raw || /offline|does not exist|can\s*not|cannot|failure|invalid|error|n[aã]o\s+exist/i.test(raw)){ _manterUltimo(e2); return; }
        // Coleta as PORTAS reais (linhas com estado up/down). Se não achar nenhuma -> inconclusivo.
        var portas=[];
        raw.split(/\r?\n/).forEach(function(ln){
            var isDown=/\bdown\b|link.?down|no\s*link/i.test(ln);
            var isUp=/\bup\b|link.?up/i.test(ln);
            var m=ln.match(/\b(10000|2500|1000|100|10)\b/);
            // Linha com velocidade negociada e SEM "down" = porta em link (UP), mesmo que
            // a palavra "up" não venha exatamente cercada de espaços (formatos variam).
            if(m && !isDown) isUp=true;
            if(isUp) portas.push({st:'up', sp:(m?parseInt(m[1],10):0)});
            else if(isDown) portas.push({st:'down', sp:0});
        });
        if(!portas.length){ _manterUltimo(e2); return; } // inconclusivo -> mantém último bom
        window._oltWanDownCnt=window._oltWanDownCnt||{};
        var ups=portas.filter(function(p){ return p.st==='up'; }); var html;
        if(ups.length){ var spd=0; ups.forEach(function(p){ if(p.sp>spd) spd=p.sp; });
            var cor=(spd>=1000?OLTC.grn:(spd>=100?OLTC.amb:OLTC.red));
            var aviso=(spd&&spd<1000)?' <span style="color:'+OLTC.amb+'; font-size:10px;">⚠ não fechou Giga</span>':'';
            html='<span style="color:'+cor+'; font-weight:800;">'+_dot+'UP</span> <span style="color:'+cor+'; font-weight:700;">'+(spd?spd+'M':'—')+'</span> <span style="color:'+OLTC.mut+'; font-size:10px;">· LAN</span>'+aviso;
            window._oltWanDownCnt[id]=0; window._oltWinWan[id]=html; e2.innerHTML=html; // UP -> confirma e guarda como último bom
        } else { // achou portas e TODAS down -> só marca DOWN após 2 leituras seguidas (evita falso-DOWN por leitura truncada da OLT ocupada)
            window._oltWanDownCnt[id]=(window._oltWanDownCnt[id]||0)+1;
            if(window._oltWanDownCnt[id]>=2){ html='<span style="color:'+OLTC.red+'; font-weight:800;">'+_dot+'DOWN</span> <span style="color:'+OLTC.mut+'; font-size:10px;">(sem link)</span>'; window._oltWinWan[id]=html; e2.innerHTML=html; }
            else { _manterUltimo(e2); } // 1ª leitura down -> aguarda confirmar, mantém o último UP conhecido
        }
}
function _oltBtnO(ic,label,onclick){
    var _pal=[OLTC.acc, OLTC.grn, OLTC.red, OLTC.amb, OLTC.vio]; var _cor=_pal[(window._oltBtnIdx=(window._oltBtnIdx||0))%_pal.length]; window._oltBtnIdx++;
    return '<button onclick="'+onclick+'" style="flex:1 1 auto; min-width:115px; cursor:pointer; padding:6px 9px; border-radius:6px; border:1px solid '+_cor+'; background:'+OLTC.panel+'; color:'+OLTC.ink+'; font-size:11px; font-weight:600; letter-spacing:.2px; -webkit-font-smoothing:antialiased; display:flex; align-items:center; justify-content:center; gap:5px; white-space:nowrap;"><i class="fa-solid '+ic+'" style="color:'+_cor+';"></i> '+label+'</button>'; }
function _oltBtnS(ic,label,onclick,bg,fg,dis){ var _base='flex:1 1 auto; min-width:115px; padding:7px 8px; border-radius:7px; font-size:11px; font-weight:700; letter-spacing:.2px; -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility; display:flex; align-items:center; justify-content:center; gap:5px; white-space:nowrap;'; if(dis){ return '<button disabled style="'+_base+' cursor:not-allowed; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.mut+'; opacity:0.55;"><i class="fa-solid '+ic+'"></i> '+label+'</button>'; } return '<button onclick="'+onclick+'" style="'+_base+' cursor:pointer; border:none; background:'+bg+'; color:'+fg+'; box-shadow:0 1px 4px rgba(0,0,0,0.22);"><i class="fa-solid '+ic+'"></i> '+label+'</button>'; }
function _oltPre(txt){ return '<pre style="white-space:pre-wrap !important; word-break:break-word; margin:0; padding:10px; font-size:11.5px; line-height:1.5; color:'+OLTC.ink+' !important; background:'+OLTC.panel+' !important; border:1px solid '+OLTC.line+'; border-radius:8px; max-height:360px; overflow:auto;">'+_oltEsc(txt)+'</pre>'; }
function _oltPainelW(id,html){ var p=document.getElementById('olt_painel_'+id); if(p){ p.style.display='block'; p.innerHTML=html; } }
function oltCarregarSinalW(id){
    var o=window._oltWins[id]; if(!o) return;
    oltFetch('olt_huawei.php?acao=onu_optico&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id), null, true)
      .then(function(r){ return r.json(); })
      .then(function(d){ if(d&&d.status==='ok'&&window._oltWins[id]){ var rx=document.getElementById('olt_rx_'+id),tx=document.getElementById('olt_tx_'+id),ro=document.getElementById('olt_rxolt_'+id); if(rx&&d.rx)rx.textContent=d.rx; if(tx&&d.tx)tx.textContent=d.tx; if(ro&&d.rx_olt)ro.textContent=d.rx_olt; var W=window._oltWins[id]; if(d.rx)W.rx=d.rx; if(d.tx)W.tx=d.tx; if(d.rx_olt)W.rx_olt=d.rx_olt; if(d.dist)W.dist=d.dist; } }).catch(function(){});
}
// Uptime + PERFIL (o mesmo "display ont info"). fim(): chamado ao terminar (encerra o spinner do perfil).
function oltCarregarUptimeW(id, fim){
    var o=window._oltWins[id]; if(!o){ if(fim) fim(); return; }
    oltFetch('olt_huawei.php?acao=onu_uptime&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id), null, true, 95000)
      .then(function(r){ return r.json(); })
      .then(function(d){ var W=window._oltWins[id]; if(d&&d.status==='ok'&&W){
            if(d.uptime){ var el=document.getElementById('olt_uptime_'+id); if(el)el.textContent=d.uptime; W.uptime=d.uptime; }
            if(d.lineprofile||d.srvprofile){ W.lineprofile=d.lineprofile||''; W.srvprofile=d.srvprofile||''; var pe=document.getElementById('olt_perf_'+id); if(pe) pe.innerHTML=_oltPerfilBadge(W);
                (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===(W.fsp||'') && (''+x.id)===(''+W.id)){ x.lineprofile=W.lineprofile; x.srvprofile=W.srvprofile; x.srv=W.srvprofile||x.srv; } }); } }
        if(fim) fim(); }).catch(function(){ if(fim) fim(); });
}
// COMBO: 1 sessão Telnet traz sinal (Rx/Tx/RxOLT) + uptime + portas WAN de uma vez.
// Substitui as 3 chamadas separadas ao abrir a janela (cada uma abria um login novo)
// -> a janela "Gerenciar" carrega MUITO mais rápido. Fallback: chamadas individuais.
function oltCarregarComboW(id){
    var o=window._oltWins[id]; if(!o||!o.fsp||o.id===''||o.id==null) return;
    var online=(o.status||'').toLowerCase().indexOf('online')>-1;
    if(!online){ oltCarregarWanW(id); var _pe=document.getElementById('olt_perf_'+id); if(_pe && _pe.querySelector('.fa-spinner')) _pe.innerHTML=_oltPerfilBadge(o, true); return; } // offline: WAN mostra "offline"; sem sinal/uptime a buscar
    var _perfFim=function(){ var pe=document.getElementById('olt_perf_'+id); if(pe && pe.querySelector('.fa-spinner')) pe.innerHTML=_oltPerfilBadge(window._oltWins[id]||o, true); };
    var _indiv=function(){ if(!o.rx&&!o.tx) oltCarregarSinalW(id); oltCarregarUptimeW(id, _perfFim); oltCarregarWanW(id); };   // uptime traz o perfil (display ont info)
    oltFetch('olt_huawei.php?acao=onu_combo&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id), null, true, 95000)
      .then(function(r){ return r.json(); })
      .then(function(d){
        if(!d||d.status!=='ok'||!window._oltWins[id]){ _indiv(); return; }
        setTimeout(_perfFim, 0);   // se o combo não trouxe o perfil, encerra o spinner
        var W=window._oltWins[id];
        var rx=document.getElementById('olt_rx_'+id),tx=document.getElementById('olt_tx_'+id),ro=document.getElementById('olt_rxolt_'+id);
        if(rx&&d.rx)rx.textContent=d.rx; if(tx&&d.tx)tx.textContent=d.tx; if(ro&&d.rx_olt)ro.textContent=d.rx_olt;
        if(d.rx)W.rx=d.rx; if(d.tx)W.tx=d.tx; if(d.rx_olt)W.rx_olt=d.rx_olt; if(d.dist)W.dist=d.dist;
        // Grava a leitura viva na LISTA (mesmo fsp|id) -> a tela principal passa a mostrar o valor novo
        // (o backend já salvou no cache de sinal; aqui reflete na hora sem esperar nova varredura).
        (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===(W.fsp||'') && (''+x.id)===(''+W.id)){ if(d.rx)x.rx=d.rx; if(d.tx)x.tx=d.tx; if(d.rx_olt)x.rx_olt=d.rx_olt; if(d.dist)x.dist=d.dist; if(d.uptime)x.uptime=d.uptime; } });
        if(d.uptime){ var el=document.getElementById('olt_uptime_'+id); if(el)el.textContent=d.uptime; W.uptime=d.uptime; }
        // Perfil ONT/ONU atual (line/srv) — mostra selo GENÉRICO e reflete na lista.
        if(d.lineprofile!==undefined||d.srvprofile!==undefined){ W.lineprofile=d.lineprofile||''; W.srvprofile=d.srvprofile||'';
            var pe=document.getElementById('olt_perf_'+id); if(pe) pe.innerHTML=_oltPerfilBadge(W);
            (window._oltLista||[]).forEach(function(x){ if((x.fsp||'')===(W.fsp||'') && (''+x.id)===(''+W.id)){ x.lineprofile=W.lineprofile; x.srvprofile=W.srvprofile; } }); }
        // Status Porta WAN: ONT(Router)=óptica (sem telnet); ONU(Bridge)=saída de portas do combo (sem 2ª sessão).
        if(_oltTipoDe(o)==='ONT'){ oltCarregarWanW(id); }
        else { window._oltWinWan=window._oltWinWan||{}; var e=document.getElementById('olt_wan_'+id); if(e&&!window._oltWinWan[id])e.innerHTML='<i class="fa-solid fa-spinner fa-spin" style="color:'+OLTC.mut+'; font-size:11px;"></i>'; _oltAplicarWanRaw(id, d.portas||''); }
      }).catch(function(){ _indiv(); });
}
function oltInfoW(id,endpoint){
    var o=window._oltWins[id]; if(!o) return;
    var tit={ onu_optico:'Sinal óptico', onu_vlan:'VLAN / Service-port', onu_trafego:'Tráfego', onu_uptime:'Tempo ONU ligada / Detalhes', onu_portas:'Status das portas LAN' };
    _oltPainelW(id,_oltSpinner('Consultando '+(tit[endpoint]||'')+' na OLT...'));
    /* CONSULTA MANUAL FORA DA FILA. Antes ia pela fila serial (oltFetch), a mesma das varreduras de
       fundo, com vigia de 25s: com a OLT ocupada varrendo placas o clique esperava na fila e morria
       com "AbortError: signal is aborted without reason". Agora: fetch DIRETO com até 70s, pausa o
       fundo enquanto roda (menos disputa pela sessão Telnet) e tenta 1x de novo se estourar. */
    var url='olt_huawei.php?acao='+endpoint+'&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id);
    var pausaAnt=window._oltPausarFundo; window._oltPausarFundo=true;
    // Uma só chamada, com folga de 150s: o servidor já espera a vez na trava do Telnet (até 75s) e
    // tenta o login 2x — se a OLT recusar, volta a MENSAGEM REAL dela, não um "AbortError".
    _oltPainelW(id,_oltSpinner('Consultando '+(tit[endpoint]||'')+' na OLT (aguardando a vez na OLT, pode levar até 1 min)...'));
    var tentar=function(){
        return _oltFetchDireto(url, 150000).catch(function(e){
            if(e && e.name==='AbortError') throw new Error('a OLT não respondeu em 150s (sessões Telnet ocupadas por varredura/cron). Feche outras fichas da OLT e tente de novo.');
            throw e;
        });
    };
    // Ao terminar a consulta, a ficha relê o sinal/uptime da OLT NA HORA — a pausa do ciclo de 15s
    // (para não disputar a sessão Telnet) nunca deixa a ficha com dado velho.
    var retomar=function(){ window._oltPausarFundo=pausaAnt;
        var _o=window._oltWins[id]; if(_o && (''+(_o.status||'')).toLowerCase().indexOf('online')>-1 && typeof oltCarregarComboW==='function') setTimeout(function(){ oltCarregarComboW(id); }, 300); };
    tentar()
      .then(function(r){ retomar(); return r.json(); }, function(e){ retomar(); throw e; })
      .then(function(d){
        if(!d||d.status!=='ok'){ _oltPainelW(id,'<div style="color:'+OLTC.red+';">'+_oltEsc((d&&d.message)||'Falha na consulta.')+'</div>'); return; }
        var cab='<div style="font-weight:800; color:'+OLTC.acc+'; margin-bottom:8px;"><i class="fa-solid fa-circle-info"></i> '+(tit[endpoint]||'')+'</div>';
        if(endpoint==='onu_uptime'&&(d.lineprofile||d.srvprofile)){ o.lineprofile=d.lineprofile||''; o.srvprofile=d.srvprofile||''; var _pe=document.getElementById('olt_perf_'+id); if(_pe) _pe.innerHTML=_oltPerfilBadge(o); }
        /* (09/11/2026) Sinal óptico: mostra SÓ esta ONU em cartões (Rx/Tx/retorno na OLT/distância, cor pelo limite da ONU).
           A saída crua da OLT é a PON INTEIRA ("optical-info <porta> all") e confundia — fica recolhida em "Saída completa da OLT". */
        if(endpoint==='onu_optico'&&(d.rx||d.tx||d.rx_olt)){
            var bS=_oltLimBase(o), cel=function(rot,v,cor){ return '<div style="flex:1 1 110px; padding:8px 10px; border:1px solid '+OLTC.line+'; border-radius:8px; background:'+OLTC.panel+';"><div style="font-size:11px; color:'+OLTC.ink+'; opacity:.75;">'+rot+'</div><div style="font-weight:800; font-size:15px; color:'+(cor||OLTC.ink)+';">'+_oltEsc(v||'—')+'</div></div>'; };
            cab+='<div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:8px;">'+cel('Rx ONU (entrada)', d.rx, _oltCorSinal(d.rx,bS))+cel('Tx ONU (saída)', d.tx)+cel('Rx OLT (retorno)', d.rx_olt, _oltCorSinal(d.rx_olt,bS))+cel('Distância', d.dist?(d.dist+' m'):'')+'</div>';
            _oltPainelW(id,cab+'<details><summary style="cursor:pointer; font-size:12px; color:'+OLTC.acc+';">Saída completa da OLT</summary>'+_oltPre(d.saida||'(sem saída)')+'</details>');
            return;
        }
        _oltPainelW(id,cab+_oltPre(d.saida||'(sem saída)'));
      }).catch(function(err){ _oltPainelW(id,'<div style="color:'+OLTC.red+';">Erro: '+_oltEsc(err)+'</div>'); });
}
// Trocar modo Bridge<->Router: escolhe um novo srv-profile (da OLT) e aplica via ont modify.
// ---- Perfis ONU/ONT cadastrados (mesma lista curada do "Trocar modo") para o Aprovisionamento ----
// COMO FUNCIONA (não remover — a tabela completa e o fluxo estão em olt_huawei.php, "PERFIS NA AUTORIZAÇÃO"):
//   BRIDGE: MAX-M10 (14) · MAX1000 (11) · HG8010H (1) · INTEL-R1 (18) · FIBERLINK · UBIQUIT
//   ROUTER: ONT-MAX (15) · ONT-HUAWEI-v2 (68) · ONT-MULTILESE (80) · ONT-FIBERLINK · ONT-INTELBRAS-121 ...
//   Regra: nome começa com "ONT" = Router (data-modo="router"); o resto = Bridge. É a MESMA regra do
//   backend (olt_srv_tipo) — mudar aqui exige mudar lá.
//   Perfil escolhido -> a autorização manda srvprofile=ID e modo='' (vazio DE PROPÓSITO: com modo
//   preenchido o backend trocaria pelo padrão 11/68). Em branco -> manda o Tipo (bridge/router).
//   O campo vem preenchido sozinho (_oltAprovPerfilAuto: mais usado do mesmo modelo, depois da PON),
//   mas é editável: escolha manual sempre vence (data-auto).
//   Para incluir um perfil novo na lista: acrescente a chave (sem traço/espaço) em _oltSrvUsadosAp.
var _oltSrvUsadosAp={'FIBERLINK':1,'HG8010H':1,'INTELR1':1,'M10G':1,'MAXM10':1,'MAX1000':1,'ONTFIBERLINK':1,'ONTHUAWEIV2':1,'ONTHUAWEIV5':1,'ONTHUAWEIV6':1,'ONTVIVO':1,'ONTINTELBRAS121':1,'ONTMAX':1,'ONTMULTILESE':1,'UBIQUIT':1};
function _oltSrvKeyAp(n){ return String(n||'').toUpperCase().replace(/[^0-9A-Z]/g,''); }
function _oltSrvCuradosAp(){
    var srvAll=(window._oltPerfisOlt&&window._oltPerfisOlt.srv)||[];
    var srv=srvAll.filter(function(p){ return _oltSrvUsadosAp[_oltSrvKeyAp(p.nome)]; });
    if(!srv.length) srv=srvAll; // fallback: nenhum bateu -> mostra todos
    return srv.slice().sort(function(a,b){ var ra=/^ONT/i.test(a.nome)?1:0, rb=/^ONT/i.test(b.nome)?1:0; return ra-rb || String(a.nome).localeCompare(String(b.nome)); });
}
function _oltSrvOptsApHtml(){
    var srv=_oltSrvCuradosAp();
    var o='<option value="">— usar o Tipo acima —</option>';
    o+=srv.map(function(p){ var isR=/^ONT/i.test(p.nome); return '<option value="'+p.id+'" data-modo="'+(isR?'router':'bridge')+'">'+_oltEsc(p.nome)+' — '+(isR?'Router (ONT)':'Bridge (ONU)')+' ('+p.id+')</option>'; }).join('');
    return o;
}
// Carrega os perfis da OLT (se ainda nao carregou) e preenche os selects de perfil do aprovisionamento
// Pré-carrega os perfis da OLT em 2º plano ao abrir o Gerenciador -> quando o aprovisionamento
// abre, o select de Perfil já vem preenchido (corrige o "só aparece depois de vários cliques").
function _oltPreloadPerfis(){
    if(window._oltPerfisOlt&&window._oltPerfisOlt.srv&&window._oltPerfisOlt.srv.length) return;
    _oltFetchDireto('olt_huawei.php?acao=perfis_olt', 15000).then(function(r){return r.json();}).then(function(d){
        if(d&&d.srv&&d.srv.length){ window._oltPerfisOlt={line:d.line||[],srv:d.srv}; _oltPreencherSrvAp(); }
        else { _oltFetchDireto('olt_huawei.php?acao=perfis_olt&force=1', 60000).then(function(r){return r.json();}).then(function(d2){ if(d2&&d2.srv&&d2.srv.length){ window._oltPerfisOlt={line:d2.line||[],srv:d2.srv}; _oltPreencherSrvAp(); } }).catch(function(){}); }
    }).catch(function(){});
}
function _oltPreencherSrvAp(){
    function fill(){ var els=document.querySelectorAll('select.olt-srv-ap'); for(var k=0;k<els.length;k++){ var v=els[k].value; els[k].innerHTML=_oltSrvOptsApHtml(); els[k].value=v; var mi=(els[k].id||'').match(/olt_srv_(\d+)/); if(mi) _oltAprovPerfilAuto(+mi[1]); }
        var gs=document.querySelectorAll('select.olt-perfil-ap'); for(var g=0;g<gs.length;g++){ var gv=gs[g].value; gs[g].innerHTML=_oltPerfilOpts(); gs[g].value=gv;
            var mg=(gs[g].id||'').match(/olt_perfil_(\d+)/); if(mg){ try{ _oltAprovGenericoAuto(+mg[1], ((window._oltApPend||[])[+mg[1]]||{}).modelo||''); }catch(e){} } } }   // genérico automático DEPOIS de carregar as opções
    if(window._oltPerfisOlt&&window._oltPerfisOlt.srv&&window._oltPerfisOlt.srv.length){ fill(); return; }
    // 1ª tentativa: cache rápido do backend. Se vier vazio, FORÇA releitura na OLT (force=1).
    _oltFetchDireto('olt_huawei.php?acao=perfis_olt', 15000).then(function(r){return r.json();}).then(function(d){
        var srv=(d&&d.srv)||[];
        if(srv.length){ window._oltPerfisOlt={line:d.line||[],srv:srv}; fill(); return; }
        // vazio -> tenta forçar a leitura real (perfis podem não ter cache ainda)
        _oltFetchDireto('olt_huawei.php?acao=perfis_olt&force=1', 60000).then(function(r){return r.json();}).then(function(d2){
            if(d2&&d2.srv&&d2.srv.length) window._oltPerfisOlt={line:d2.line||[],srv:d2.srv}; fill();
        }).catch(fill);
    }).catch(fill);
}
// Ao escolher um perfil especifico, reflete o Tipo (Bridge/Router) no select de cima
function _oltSrvApChange(sel,i){ var m=(sel&&sel.value&&sel.selectedOptions&&sel.selectedOptions[0])?sel.selectedOptions[0].getAttribute('data-modo'):''; var mo=document.getElementById('olt_modo_'+i); if(mo&&m){ mo.value=m; } }
// Preenche a VLAN automaticamente pela VLAN padrão da PORTA escolhida (Gerenciar Porta). Não sobrescreve
// o que foi digitado à mão (data-auto marca quando o valor veio automático).
function _oltAprovVlanAuto(i){
    var slot=_oltVal('olt_slot_'+i), port=_oltVal('olt_port_'+i); if(slot===''||port==='') return;
    var fsp='0/'+slot+'/'+port;
    // VLAN padrão da porta
    var v=_oltPortaVlan(fsp);
    if(v){ var inp=document.getElementById('olt_vlan_'+i);
        if(inp && (( ''+inp.value).trim()==='' || inp.getAttribute('data-auto')==='1')){ var nm=_oltVlanNome(v); inp.value=v+(nm?(' — '+nm):''); inp.setAttribute('data-auto','1'); } }
    // Zona padrão da porta (editável — só preenche se vazio ou ainda automático)
    var z=_oltPortaZona(fsp);
    // ONU MOVIDA de porta: sem zona pela porta nova, usa a zona do cadastro antigo (banco local por SN).
    if(!z){ var _pm=(window._oltApPend||[])[i]; var _mv=_pm&&(_pm.movida||_pm.movidaFeita); if(_mv){ var _sk=String(_pm.sn||'').toUpperCase().replace(/[^0-9A-Z]/g,''); var _cd=(window._oltCadastro||{})[_sk]; z=(_cd&&_cd.zona)||_mv.zona||''; } }
    if(z){ var zi=document.getElementById('olt_zona_'+i);
        if(zi && (( ''+zi.value).trim()==='' || zi.getAttribute('data-auto')==='1')){ zi.value=z; zi.setAttribute('data-auto','1'); } }
    _oltAprovPerfilAuto(i); // perfil ONT/ONU padrão da porta
}
// Preenche o Perfil ONT/ONU padrão da porta no aprovisionamento (editável — respeita escolha manual).
/** 'router' | 'bridge' | '' — maioria das ONUs do MESMO modelo já na rede. */
function _oltTipoPorModelo(modelo){
    var nm=function(x){ return String(x||'').toUpperCase().replace(/[^0-9A-Z]/g,''); }, md=nm(modelo); if(!md) return '';
    var r=0, b=0, cad=window._oltCadastro||{};
    (window._oltLista||[]).forEach(function(o){ if(nm(o.modelo)!==md) return;
        var sn=String(o.serial||'').toUpperCase().replace(/[^0-9A-Z]/g,'');
        var t=String((cad[sn]&&cad[sn].tipo)||o.modo||'').toUpperCase();
        var _sv=String(o.srv||o.srvprofile||''); if(!t && _sv && !/^GENERIC/i.test(_sv)) t=/^ONT/i.test(_sv)?'ONT':'ONU';   // Generic_* não diz o tipo: ignora
        if(t==='ONT') r++; else if(t==='ONU') b++; });
    if(r||b) return r>b?'router':'bridge';
    // SEM ONUs desse modelo na rede: usa a MESMA regra da coluna Tipo da lista (tipo cadastrado p/ o modelo
    // em "Perfis ONU/ONT" ou a regra por nome: EG8/HG824.. = Router). Antes caía no perfil mais usado da PON
    // e Huawei nova (EG8145V5) saía Bridge/MAX1000.
    try{ var mi=(typeof _oltModeloInfo==='function')?_oltModeloInfo(modelo):null; var t2=String((mi&&mi.tipo)||_oltModeloTipo(modelo)||'').toUpperCase(); if(t2==='ONT') return 'router'; if(t2==='ONU') return 'bridge'; }catch(e){}
    return '';
}
// PERFIL JÁ PREENCHIDO (editável): o mais usado pelo MESMO MODELO na OLT; senão o mais usado na PON.
// Escolha manual sempre vence (data-auto). Se a lista de ONUs ainda não carregou (aprovisionamento
// aberto pela página principal), carrega do cache UMA vez e repete — antes o campo ficava em branco.
/* PERFIL GENÉRICO AUTOMÁTICO (Intelbras R1/R2/121) — função SEPARADA do perfil (validado, não mexe nele).
   Na OLT do provedor os genéricos são POR VLAN: "Generic_<N>_V<VLAN>" (line e srv com o mesmo nome; criados pelo
   SmartOLT). Confirmado 23/09/2026: Intelbras que conectam usam Generic_1_V250 (VLAN 250), Generic_1_V252,
   Generic_1_V351, Generic_1_V355… Sem o genérico, a Intelbras ia com o line-profile padrão (SMARTOLT_FLEXIBLE_GPON):
   autorizava e NÃO conectava.
   Regra: modelo Intelbras (R1/R2/INTEL/ITBS/121) ou o mesmo modelo já usando genérico → "Generic_<N>_V<VLAN do
   formulário>"; N = o que as ONUs do mesmo modelo usam (senão as Intelbras da rede; senão 1). Se a VLAN mudar, o
   genérico acompanha. Não existe esse genérico na OLT → campo vazio + aviso (não escolhe errado). Não Intelbras =
   vazio (igual antes). Escolha manual vence (data-manual). */
function _oltAprovGenericoAuto(i, modelo){
    var g=document.getElementById('olt_perfil_'+i); if(!g || g.getAttribute('data-manual')==='1') return;
    if(g.options.length<=1) return;                                   // opções ainda não carregadas (roda de novo quando carregar)
    var nm=function(x){ return String(x||'').toUpperCase().replace(/[^0-9A-Z]/g,''); }, md=nm(modelo);
    // TODA Intelbras leva genérico: ONU R1/R2 (Bridge) E ONT 121/121AC (Router) — confirmado pelo provedor em
    // 23/09/2026 (a ONT 121AC sem genérico não conectava). O perfil da ONT continua ONT-INTELBRAS-121.
    var ehIntel=function(m){ return /^R1|^R2|^INTEL|^ITBS|^121/.test(m); };
    // Vivo MitraStar GPT-2741 (SN MSTC…): VALIDADO 30/09/2026 — com ONT-MAX dava "Match state: mismatch"
    // (4 ETH + 2 POTS) e nada subia; com Generic_1_V<VLAN> casou e conectou. Leva genérico também.
    var ehVivo=function(m){ return /^GPT27/.test(m); };
    var tipoN=function(p){ var mm=String(p||'').match(/Generic_(\d+)_V\d+/i); return mm?mm[1]:''; };
    // N (tipo do genérico): mesmo modelo > Intelbras da rede > 1
    var cont=function(filtro){ var c={}, best='', n=0; (window._oltLista||[]).forEach(function(o){ if(!filtro(nm(o.modelo))) return;
        [o.lineprofile, o.srvprofile, o.srv].forEach(function(p){ var t=tipoN(p); if(!t) return; c[t]=(c[t]||0)+1; if(c[t]>n){ n=c[t]; best=t; } }); }); return best; };
    var nMod=md?cont(function(m){ return m===md; }):'';
    var alvoIntel=ehIntel(md) || ehVivo(md) || nMod!=='';
    var marca=ehIntel(md)?'Intelbras':(ehVivo(md)?'Vivo':'mesmo modelo');
    var hint=function(txt, cor){ try{ var hn=document.getElementById('olt_genhint_'+i); if(!hn && g.parentNode){ hn=document.createElement('span'); hn.id='olt_genhint_'+i; hn.style.cssText='font-size:10px; font-weight:700; margin-left:6px;'; g.parentNode.insertBefore(hn, g.nextSibling); }
        if(hn){ hn.textContent=txt; hn.style.color=cor||OLTC.grn; } }catch(e){} };
    if(!alvoIntel){ if(g.getAttribute('data-auto')==='1'){ g.value=''; g.removeAttribute('data-auto'); hint(''); } return; }
    var vlan=(String(_oltVal('olt_vlan_'+i)||'').match(/\d+/)||[''])[0];
    if(!vlan){ hint(marca+': informe a VLAN p/ escolher o genérico', OLTC.amb); return; }
    var N=nMod || (ehIntel(md)?cont(ehIntel):'') || '1';
    var alvo=('GENERIC_'+N+'_V'+vlan);
    var val=''; for(var k=0;k<g.options.length;k++){ if(String(g.options[k].value).toUpperCase()===alvo){ val=g.options[k].value; break; } }
    if(!val){ if(g.getAttribute('data-auto')==='1'){ g.value=''; g.removeAttribute('data-auto'); }
        hint('⚠ não existe Generic_'+N+'_V'+vlan+' na OLT — escolha à mão', OLTC.red); return; }
    g.value=val; g.setAttribute('data-auto','1');
    hint('✓ automático ('+marca+' · VLAN '+vlan+')');
}
function _oltAprovPerfilAuto(i){
    var slot=_oltVal('olt_slot_'+i), port=_oltVal('olt_port_'+i); if(slot===''||port==='') return;
    if(!(window._oltLista&&window._oltLista.length)){
        if(window._oltApListaCarregando) return; window._oltApListaCarregando=true;
        fetch('olt_huawei.php?acao=cache_get').then(function(r){ return r.json(); }).then(function(d){
            if(d&&d.onus&&d.onus.length&&!(window._oltLista&&window._oltLista.length)) window._oltLista=d.onus;
            (window._oltApPend||[]).forEach(function(_,k){ try{ _oltAprovVlanAuto(k); }catch(e){} });
        }).catch(function(){}).then(function(){ window._oltApListaCarregando=false; });
        return;
    }
    var pd=(window._oltApPend||[])[i]||{};
    // TIPO pelo MODELO (mesmo sem perfil): ONUs iguais já na rede dizem se é Router (ONT) ou Bridge (ONU)
    // — pelo tipo gravado (modo/cadastro) ou pelo srv-profile ("ONT-*" = Router). Manual vence (data-manual).
    var tp=_oltTipoPorModelo(pd.modelo||''), mo=document.getElementById('olt_modo_'+i);
    if(tp && mo && mo.getAttribute('data-manual')!=='1') mo.value=tp;
    var efTp=(mo&&mo.getAttribute('data-manual')==='1')?mo.value:tp;   // Tipo manual vence o do modelo
    try{ _oltAprovGenericoAuto(i, pd.modelo||''); }catch(e){}   // Intelbras R1/R2: PERFIL GENÉRICO também (separado; não mexe no perfil)
    var sel=document.getElementById('olt_srv_'+i); if(!sel) return;
    // perfil AUTOMÁTICO de outro tipo (ex.: trocou o Tipo à mão) -> limpa, p/ não gravar Router com perfil Bridge
    if(efTp && sel.value!=='' && sel.getAttribute('data-auto')==='1' && sel.selectedOptions[0] && sel.selectedOptions[0].getAttribute('data-modo')!==efTp){ sel.value=''; }
    var pid=_oltPortaPerfil('0/'+slot+'/'+port, pd.modelo||'', efTp);   // modelo da ONU nova (autofind) + tipo
    // DICA visível: de onde veio a sugestão (ou por que não veio) — sem precisar abrir console
    try{ var hn=document.getElementById('olt_srvhint_'+i); if(!hn && sel.parentNode){ hn=document.createElement('div'); hn.id='olt_srvhint_'+i; sel.parentNode.style.position='relative';
            // FLUTUANDO abaixo do campo (absolute): não aumenta a altura do Perfil -> VLAN/Tipo/Perfil ficam alinhados
            hn.style.cssText='position:absolute; left:0; right:0; top:100%; margin-top:1px; font-size:9.5px; line-height:12px; color:'+OLTC.mut+'; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; pointer-events:none;'; sel.parentNode.appendChild(hn); }
        if(hn && sel.getAttribute('data-auto')!=='0'){ hn.textContent=pid?('sugerido: '+(window._oltPerfOrig||'')):('sem sugestão: '+(window._oltPerfOrig||'—')); hn.title=hn.textContent; sel.title=hn.textContent; } }catch(e){}
    if(!pid) return;
    if(sel.value!=='' && sel.getAttribute('data-auto')!=='1') return; // já escolhido à mão
    var has=false; for(var k=0;k<sel.options.length;k++){ if(sel.options[k].value===String(pid)){ has=true; break; } }
    if(!has) return; // opção ainda não carregada
    // perfil sugerido de OUTRO tipo (ex.: modelo é ONT mas a PON usa perfil Bridge) -> não aplica; fica o Tipo pelo modelo
    var _opt=null; for(var q=0;q<sel.options.length;q++){ if(sel.options[q].value===String(pid)){ _opt=sel.options[q]; break; } }
    if(efTp && _opt && _opt.getAttribute('data-modo') && _opt.getAttribute('data-modo')!==efTp) return;
    sel.value=String(pid); sel.setAttribute('data-auto','1'); _oltSrvApChange(sel,i); // reflete o Tipo (Bridge/Router)
}
function oltTrocarModo(id){
    var o=window._oltWins[id]; if(!o) return;
    // Perfis srv REALMENTE usados (cadastrados na OLT) — evita mostrar centenas de inuteis.
    var _srvUsados={'FIBERLINK':1,'HG8010H':1,'INTELR1':1,'M10G':1,'MAXM10':1,'MAX1000':1,'ONTFIBERLINK':1,'ONTHUAWEIV2':1,'ONTINTELBRAS121':1,'ONTMAX':1,'ONTMULTILESE':1,'UBIQUIT':1};
    function _srvKey(n){ return String(n||'').toUpperCase().replace(/[^0-9A-Z]/g,''); }
    function abrir(){
        var srvAll=(window._oltPerfisOlt&&window._oltPerfisOlt.srv)||[];
        // Bridge (ONU) primeiro, Router (ONT-) depois; só os usados. Fallback = todos.
        var srv=srvAll.filter(function(p){ return _srvUsados[_srvKey(p.nome)]; });
        var _todos=false; if(!srv.length){ srv=srvAll; _todos=true; }
        srv=srv.slice().sort(function(a,b){ var ra=/^ONT/i.test(a.nome)?1:0, rb=/^ONT/i.test(b.nome)?1:0; return ra-rb || String(a.nome).localeCompare(String(b.nome)); });
        var atual=document.getElementById('oltAddOv'); if(atual) atual.remove();
        var ov=document.createElement('div'); ov.id='oltAddOv';
        ov.style.cssText='position:fixed; inset:0; z-index:2147483000; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.45);';
        var s=_oltInSt();
        var opts=srv.length?srv.map(function(p){ var tp=/^ONT/i.test(p.nome)?'Router':'Bridge'; return '<option value="'+p.id+'">'+_oltEsc(p.nome)+' — '+tp+' ('+p.id+')</option>'; }).join(''):'<option value="">(sem perfis carregados)</option>';
        ov.innerHTML='<div style="background:'+OLTC.bg+'; border:1px solid '+OLTC.line+'; border-radius:12px; padding:16px; width:min(94vw,380px); box-shadow:0 20px 60px rgba(0,0,0,0.5);">'+
            '<div style="font-weight:800; color:'+OLTC.ink+'; margin-bottom:6px;"><i class="fa-solid fa-right-left" style="color:'+OLTC.vio+';"></i> Trocar modo da ONU</div>'+
            '<div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:10px;">Escolha o <b>Srv-profile</b> (Bridge ou Router) e aplique. ONU: '+_oltEsc(o.nome||o.serial)+(_todos?'<br><span style="color:'+OLTC.amb+';">(nenhum perfil na lista de usados bateu — exibindo todos)</span>':'')+'</div>'+
            '<select id="oltModoSp" style="'+s+' width:100%; box-sizing:border-box; margin-bottom:12px;">'+opts+'</select>'+
            '<div style="display:flex; gap:8px; justify-content:flex-end;">'+
              '<button type="button" onclick="document.getElementById(\'oltAddOv\').remove()" style="cursor:pointer; padding:8px 14px; border-radius:8px; border:1px solid '+OLTC.line+'; background:transparent; color:'+OLTC.txt+';">Cancelar</button>'+
              '<button type="button" onclick="oltTrocarModoAplicar(\''+id+'\')" style="cursor:pointer; padding:8px 16px; border-radius:8px; border:none; background:'+OLTC.vio+'; color:#fff; font-weight:800;">Aplicar</button>'+
            '</div></div>';
        document.body.appendChild(ov);
    }
    if(window._oltPerfisOlt&&window._oltPerfisOlt.srv){ abrir(); }
    else { oltFetch('olt_huawei.php?acao=perfis_olt', null, true).then(function(r){return r.json();}).then(function(d){ if(d&&d.status==='ok') window._oltPerfisOlt={line:d.line||[],srv:d.srv||[]}; abrir(); }).catch(abrir); }
}
function oltTrocarModoAplicar(id){
    var o=window._oltWins[id]; if(!o) return;
    var sp=(document.getElementById('oltModoSp')||{}).value||''; if(!sp) return;
    var ov=document.getElementById('oltAddOv'); if(ov) ov.remove();
    _oltPainelW(id,_oltSpinner('Aplicando novo perfil (ont modify) na OLT...'));
    oltFetch('olt_huawei.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'acao=onu_modo&fsp='+encodeURIComponent(o.fsp)+'&id='+encodeURIComponent(o.id)+'&srvprofile='+encodeURIComponent(sp)}, true, 200000)
      .then(function(r){ return r.json(); })
      .then(function(d){
        if(!d||d.status!=='ok'){ _oltPainelW(id,'<div style="color:'+OLTC.red+';">'+_oltEsc((d&&d.message)||'Falha.')+'</div>'); return; }
        var cor=d.sucesso?OLTC.grn:OLTC.red, ic=d.sucesso?'fa-circle-check':'fa-triangle-exclamation';
        _oltPainelW(id,'<div style="color:'+cor+'; font-weight:800; margin-bottom:8px;"><i class="fa-solid '+ic+'"></i> '+(d.sucesso?'Perfil alterado (srv-profile '+d.srvprofile+'). Ressincronize se necessário.':'A OLT retornou aviso/erro.')+'</div>'+_oltPre(d.saida||''));
        if(d.sucesso){
            // limpa o modo/uptime da ONU alterada p/ re-ler o service-profile real da OLT
            var kk=(o.fsp||'')+'|'+o.id;
            (window._oltLista||[]).forEach(function(x){ if(((x.fsp||'')+'|'+x.id)===kk){ x.modo=''; x.srv=''; x.uptime=''; } });
            oltEnriquecerUptime();
        }
      }).catch(function(err){ _oltPainelW(id,'<div style="color:'+OLTC.red+';">Erro: '+_oltEsc(err)+'</div>'); });
}
// _tent: nova tentativa automática quando a OLT responde "ocupada" (sem perguntar de novo)
function oltControleW(id,tipo,confirmMsg,_tent){
    var o=window._oltWins[id]; if(!o) return;
    _tent=_tent||0;
    if(!_tent && !confirm(confirmMsg+'\n\nONU: '+(o.nome||o.serial)+'  ('+o.fsp+' · ID '+o.id+')')) return;
    _oltPainelW(id,_oltSpinner(_tent?('OLT ocupada com outra consulta — tentando de novo ('+(_tent+1)+'/4)...'):'Enviando comando à OLT...'));
    // Timeout de segurança: se o Telnet estiver congestionado e não voltar em 45s, para de girar e avisa.
    window._oltCtrlTO=window._oltCtrlTO||{};
    if(window._oltCtrlTO[id]) clearTimeout(window._oltCtrlTO[id]);
    window._oltCtrlTO[id]=setTimeout(function(){ var pn=document.getElementById('olt_painel_'+id); if(pn && pn.innerHTML.indexOf('spinner')>-1) _oltPainelW(id,'<div style="color:'+OLTC.amb+'; line-height:1.6;">A OLT não respondeu a tempo — o <b>Telnet está congestionado</b> (poucas sessões livres). O comando pode ter sido aplicado mesmo assim. Aguarde ~1 min e tente de novo.</div>'); }, 245000);
    var body=new URLSearchParams({ acao:'onu_acao', tipo:tipo, fsp:o.fsp, id:o.id });
    // FETCH DIRETO (180s), fora da fila: a fila aborta em 25s e o DELETE (undo service-port +
    // delete) passa disso — a OLT deletava, mas a tela mostrava "AbortError". Pausa o fundo.
    window._oltPausarFundo=true;
    _oltFetchDireto('olt_huawei.php?'+body.toString(), 240000)
      .then(function(r){ window._oltPausarFundo=false; return r.json(); }, function(e){ window._oltPausarFundo=false; throw e; })
      .then(function(d){
        if(window._oltCtrlTO&&window._oltCtrlTO[id]){ clearTimeout(window._oltCtrlTO[id]); window._oltCtrlTO[id]=null; }
        // OLT ocupada (a vez estava com outra consulta): tenta de novo sozinho até 3x, em vez de parar no erro
        if(d && d.status!=='ok' && /OLT ocupada/i.test(d.message||'') && _tent<3){ setTimeout(function(){ oltControleW(id,tipo,confirmMsg,_tent+1); }, 4000); return; }
        if(!d||d.status!=='ok'){ _oltPainelW(id,'<div style="color:'+OLTC.red+';">'+_oltEsc((d&&d.message)||'Falha ao executar.')+'</div>'); return; }
        var cor=d.sucesso?OLTC.grn:OLTC.red, ic=d.sucesso?'fa-circle-check':'fa-triangle-exclamation';
        var msg=d.sucesso?'Comando executado com sucesso.':'A OLT retornou um aviso/erro — confira a saída.';
        var painelHtml='<div style="color:'+cor+'; font-weight:800; margin-bottom:8px;"><i class="fa-solid '+ic+'"></i> '+msg+'</div><div style="font-size:11px; color:'+OLTC.mut+'; margin-bottom:6px;">Comando: <code style="color:'+OLTC.ink+' !important; background:'+OLTC.panel+' !important; padding:2px 6px; border-radius:5px; border:1px solid '+OLTC.line+';">'+_oltEsc(d.comando)+'</code></div>'+_oltPre(d.saida||'(sem saída)');
        _oltPainelW(id,painelHtml);
        var k=(o.fsp||'')+'|'+o.id;
        // Após DELETAR com sucesso: remove a ONU da lista e fecha a janela.
        if(tipo==='delete' && d.sucesso){
            if(window._oltLista){ window._oltLista=window._oltLista.filter(function(x){ return ((x.fsp||'')+'|'+x.id)!==k; }); oltRenderLista(); }
            setTimeout(function(){ oltFecharJanela(id); }, 2500);
        }
        // Bloquear/Liberar: atualiza o estado LOCAL na hora p/ os botões inverterem (bloq<->apto)
        if((tipo==='block'||tipo==='unblock') && d.sucesso){
            if(tipo==='block'){ o.estado='deactivated'; o.status='offline'; }
            else { o.estado='offline'; o.status='offline'; } // volta a apto (reconecta no auto-sync)
            (window._oltLista||[]).forEach(function(x){ if(((x.fsp||'')+'|'+x.id)===k){ x.estado=o.estado; x.status=o.status; x._estadoReal=true; } });
            oltRenderDash(id); _oltPainelW(id,painelHtml); oltRenderLista(); // re-render inverte os botões; reexibe a mensagem
        }
      }).catch(function(err){ if(window._oltCtrlTO&&window._oltCtrlTO[id]){ clearTimeout(window._oltCtrlTO[id]); window._oltCtrlTO[id]=null; } _oltPainelW(id,'<div style="color:'+OLTC.red+';">'+((err&&err.name==='AbortError')?'A OLT não respondeu em 4 min. O comando pode ter sido aplicado — atualize a lista antes de repetir.':('Erro: '+_oltEsc(err)))+'</div>'); });
}

/* =================================================================================================
 * TABELA QUE "PULA PARA O LADO" AO CLICAR NUMA COLUNA
 *
 * A lista de ONUs fica dentro de um container com rolagem horizontal (overflow-x:auto). Quando se
 * clica numa célula que contém botão ou link, o navegador dá foco nesse elemento e ROLA o container
 * para trazê-lo à vista — mesmo que ele já estivesse visível. Na prática, a tabela salta de lado a
 * cada clique, e quem está conferindo uma coluna perde a posição.
 *
 * Não há CSS que desligue isso: a rolagem para o elemento focado é comportamento do navegador. O
 * jeito é guardar a posição no instante do clique e devolvê-la logo depois.
 *
 * Só age quando a posição realmente mudou, e só dentro da tabela marcada com .oltXScroll — rolagem
 * feita pelo usuário (arrastar, roda do mouse, barra) não é tocada.
 * ============================================================================================== */
(function () {
    var alvo = null, posX = null;

    document.addEventListener('mousedown', function (e) {
        var el = e.target && e.target.closest ? e.target.closest('.oltXScroll') : null;
        if (el) { alvo = el; posX = el.scrollLeft; } else { alvo = null; posX = null; }
    }, true);

    document.addEventListener('click', function () {
        if (!alvo || posX === null) return;
        var el = alvo, x = posX;
        alvo = null; posX = null;
        // No quadro seguinte: o navegador já aplicou a rolagem do foco, e aqui ela é desfeita.
        requestAnimationFrame(function () { if (el.scrollLeft !== x) el.scrollLeft = x; });
    }, true);
})();

/* (03/10/2026) Roteador do cliente na autorização de ONU Bridge: Sim → escolhe o modelo da lista; Não → grava na hora. */
function _oltRoteador(cid, com){
  var msg=document.getElementById('olt_rot_msg'), sel=document.getElementById('olt_rot_modelo'), sv=document.getElementById('olt_rot_salvar');
  var pb=document.getElementById('olt_cd_pause'); if(pb && pb.innerHTML.indexOf('Pausar')>-1) pb.click();   // pausa o fechamento automático enquanto responde
  if(!com){ fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=contrato_roteador&contrato_id='+cid+'&comodato=0'}).then(function(r){return r.json();}).then(function(){ msg.textContent='✔ Gravado: roteador do cliente (não é comodato).'; sel.style.display='none'; sv.style.display='none'; }); return; }
  msg.textContent='Carregando modelos…';
  fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=contrato_roteador&contrato_id='+cid+'&listar=1'}).then(function(r){return r.json();}).then(function(d){
    sel.innerHTML='<option value="">— modelo do roteador —</option>'+((d&&d.modelos)||[]).map(function(m){ return '<option>'+String(m).replace(/</g,'&lt;')+'</option>'; }).join('');
    sel.style.display=''; sv.style.display=''; msg.textContent='Escolha o modelo e clique em Salvar.';
  }).catch(function(){ msg.textContent='Não consegui carregar a lista.'; });
}
function _oltRoteadorSalvar(cid){
  var sel=document.getElementById('olt_rot_modelo'), msg=document.getElementById('olt_rot_msg');
  fetch('olt_huawei.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'acao=contrato_roteador&contrato_id='+cid+'&comodato=1&modelo='+encodeURIComponent(sel.value||'')}).then(function(r){return r.json();}).then(function(d){ msg.textContent=d&&d.ok?'✔ Gravado: roteador em comodato'+(sel.value?' ('+sel.value+')':'')+'.':'Não gravou.'; });
}

/* RESUMO DO CLIENTE AO PASSAR O MOUSE NO NOME (21/10/2026): o mesmo cartão da lista do ERP (erp.php?ajax=resumo_cli), agora na lista de ONUs.
   Só LEITURA e totalmente à parte: escuta o mouse sobre .olt-cli-nome (data-olt-login) e mostra o cartão. Qualquer falha aqui fica quieta e não toca o resto da página. */
(function(){
  try {
    var box = null, timer = null, tHide = null, alvo = null, cache = {};
    function cor(k, pad){ try { return (window.OLTC && window.OLTC[k]) || pad; } catch(e){ return pad; } }
    function caixa(){
      if (box) return box;
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;z-index:2147483000;width:max-content;max-width:min(560px,94vw);min-width:230px;border-radius:10px;padding:10px 13px;font-size:12.5px;line-height:1.45;box-shadow:0 8px 28px rgba(0,0,0,.28);display:none;pointer-events:auto;';
      box.addEventListener('mouseenter', function(){ clearTimeout(tHide); });
      box.addEventListener('mouseleave', agenda);
      document.body.appendChild(box); return box;
    }
    function pinta(b){ b.style.background = cor('bg2', cor('card', '#ffffff')); b.style.color = cor('ink', '#111827'); b.style.border = '1px solid ' + cor('line', '#d1d5db'); }
    function pos(el){
      var r = el.getBoundingClientRect(), b = caixa(), w = b.offsetWidth, h = b.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
      var topo = (r.bottom - 2 + h <= vh - 8) ? r.bottom - 2 : Math.max(4, r.top + 2 - h);
      b.style.left = Math.max(8, Math.min(r.left, vw - w - 8)) + 'px'; b.style.top = topo + 'px';
    }
    function mostra(el){
      var lg = el.getAttribute('data-olt-login'); if (!lg) return; var b = caixa(); pinta(b);
      if (cache[lg]) { b.innerHTML = cache[lg]; b.style.display = 'block'; pos(el); return; }
      b.innerHTML = '<span style="opacity:.7">Carregando…</span>'; b.style.display = 'block'; pos(el);
      fetch('erp.php?ajax=resumo_cli&login=' + encodeURIComponent(lg), {credentials: 'same-origin'}).then(function(r){ return r.text(); })
        .then(function(t){ cache[lg] = t; if (alvo === el) { b.innerHTML = t; pos(el); } })
        .catch(function(){ b.innerHTML = '<span style="opacity:.7">Não consegui carregar.</span>'; });
    }
    function esconde(){ clearTimeout(timer); clearTimeout(tHide); alvo = null; if (box) box.style.display = 'none'; }
    function agenda(){ clearTimeout(timer); clearTimeout(tHide); tHide = setTimeout(esconde, 150); }
    document.addEventListener('mouseover', function(e){
      var el = e.target.closest && e.target.closest('.olt-cli-nome'); if (el) clearTimeout(tHide);
      if (!el || el === alvo) return;
      alvo = el; clearTimeout(timer); timer = setTimeout(function(){ if (alvo === el) mostra(el); }, 350);
    });
    document.addEventListener('mouseout', function(e){
      var el = e.target.closest && e.target.closest('.olt-cli-nome'); if (!el) return;
      var p = e.relatedTarget; if (p && (el.contains(p) || (box && box.contains(p)))) return; agenda();
    });
    document.addEventListener('click', function(e){ if (e.target.closest && e.target.closest('.olt-cli-nome')) esconde(); }, true);
  } catch (err) {}
})();

/* EXPORTAR A LISTA DE ONUs EM CSV (21/10/2026): leva exatamente o que está na tela (busca, filtros de coluna e card selecionado), sem senha nem dado
   sensível. Separador ";" e BOM UTF-8 (o Excel brasileiro abre direto, com acentos). Só LEITURA e totalmente à parte: não grava nada, não chama servidor. */
function oltExportarCsv(){
  try {
    var arr = []; try { arr = _oltFiltradas(); } catch (e) { arr = window._oltLista || []; }
    if (!arr.length) { alert('Não há ONUs na lista para exportar.'); return; }
    var cab = ['F/S/P', 'PON', 'ID', 'Nome', 'Zona', 'VLAN', 'Serial', 'Modelo', 'Tipo', 'Rx ONU (dBm)', 'Tx ONU (dBm)', 'Rx OLT (dBm)', 'Uptime', 'Status'];
    function cel(v){ v = (v == null) ? '' : String(v).replace(/\r?\n/g, ' ').trim(); if (/^[=+@]/.test(v) || (/^-/.test(v) && !/^-\d+([.,]\d+)?$/.test(v))) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
    function dbm(v){ var m = String(v == null ? '' : v).match(/-?\d+(\.\d+)?/); return m ? m[0].replace('.', ',') : ''; }
    var linhas = [cab.map(cel).join(';')];
    arr.forEach(function(o){
      var pon = (o.fsp || '').split('/');
      var tp = ''; try { tp = _oltTipoDe(o); } catch (e) {}
      var nome = ''; try { nome = _oltNomeDe(o) || ''; } catch (e) { nome = o.nome || ''; }
      var vl = o.vlan || ''; try { var vn = _oltVlanNome(vl); if (vn) vl = vl + ' ' + vn; } catch (e) {}
      linhas.push([o.fsp || '', pon[2] || '', o.id || '', nome, o.zona || '', vl, o.serial || '', o.modelo || '', tp, dbm(o.rx), dbm(o.tx), dbm(o.rx_olt),
        (o.uptime || '') + (o.downtime ? (' offline ' + o.downtime) : ''), o.status || ''].map(cel).join(';'));
    });
    var d = new Date(), p2 = function(n){ return (n < 10 ? '0' : '') + n; };
    var nome_arq = 'onus-' + d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + '_' + p2(d.getHours()) + p2(d.getMinutes()) + '.csv';
    var blob = new Blob(['\ufeff' + linhas.join('\r\n')], {type: 'text/csv;charset=utf-8'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nome_arq; document.body.appendChild(a); a.click();
    setTimeout(function(){ try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 1500);
  } catch (err) { try { alert('Não consegui gerar o CSV: ' + err.message); } catch (e2) {} }
}

/* OSCILAÇÃO DE CONEXÕES (21/10/2026): quais conexões mais CAEM em um período (a partir do histórico de sessões do RADIUS, via olt_oscilacao.php — só leitura).
   Bloco independente: abre uma janela própria, não mexe na lista, nos filtros nem na coleta da OLT. Qualquer falha fica dentro da janela. */
function oltOscilacao(){
  try {
    var ant = document.getElementById('oltOscOverlay'); if (ant) ant.remove();
    var C = window.OLTC || {};
    function cor(k, p){ return C[k] || p; }
    var ov = document.createElement('div'); ov.id = 'oltOscOverlay';
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147482000;background:rgba(0,0,0,.5);display:flex;align-items:flex-start;justify-content:center;padding:4vh 12px;overflow:auto;';
    var pn = document.createElement('div');
    pn.style.cssText = 'background:' + cor('bg', '#fff') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:12px;width:min(1180px,100%);box-shadow:0 14px 44px rgba(0,0,0,.4);padding:16px 18px;';
    var sel = 'background:' + cor('panel', '#e8edf3') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:8px;padding:7px 10px;font-size:12.5px;';
    var bt = 'cursor:pointer;padding:7px 13px;border-radius:8px;border:1px solid ' + cor('line', '#cdd6e0') + ';background:transparent;color:' + cor('txt', '#0f172a') + ';font-size:12.5px;font-weight:600;';
    pn.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px;">' +
        '<div style="font-size:17px;font-weight:800;flex:1 1 auto;">⚡ Oscilação de conexões</div>' +
        '<select id="oltOscDias" style="' + sel + '"><option value="1">Últimas 24 h</option><option value="7" selected>Últimos 7 dias</option><option value="15">Últimos 15 dias</option><option value="30">Últimos 30 dias</option></select>' +
        '<label style="font-size:12.5px;display:flex;align-items:center;gap:6px;">mínimo de quedas <input id="oltOscMin" type="number" min="1" max="50" value="3" style="' + sel + 'width:64px;"></label>' +
        '<button id="oltOscAtu" style="' + bt + '">Atualizar</button>' +
        '<button id="oltOscCsv" style="' + bt + '">CSV</button>' +
        '<button id="oltOscFechar" style="' + bt + '">✕</button>' +
      '</div>' +
      '<div id="oltOscInfo" style="font-size:12px;color:' + cor('mut', '#475569') + ';margin-bottom:10px;line-height:1.5;"></div>' +
      '<div id="oltOscCorpo" style="overflow:auto;max-height:68vh;"><div style="padding:18px;opacity:.7;">Carregando…</div></div>';
    ov.appendChild(pn); document.body.appendChild(ov);
    var dados = [];
    function fechar(){ try { ov.remove(); document.removeEventListener('keydown', esc, true); } catch (e) {} }
    function esc(e){ if (e.key === 'Escape') fechar(); }
    document.addEventListener('keydown', esc, true);
    ov.addEventListener('click', function(e){ if (e.target === ov) fechar(); });
    pn.querySelector('#oltOscFechar').onclick = fechar;
    function dma(s){ var m = String(s || '').match(/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})/); return m ? (m[3] + '/' + m[2] + ' ' + m[4] + ':' + m[5]) : String(s || ''); }
    function dur(s){ s = +s || 0; if (s <= 0) return '—'; var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h > 0 ? (h + 'h ' + m + 'min') : (m + 'min'); }
    function onuDe(login){
      try {
        var alvo = String(login || '').toUpperCase().replace(/[^0-9A-Z]/g, ''); if (!alvo) return null;
        var l = window._oltLista || [];
        for (var i = 0; i < l.length; i++) { var o = l[i]; if (_oltLoginResolvido(o.serial) === alvo || String(o.serial || '').toUpperCase().replace(/[^0-9A-Z]/g, '') === alvo) return o; }
      } catch (e) {}
      return null;
    }
    function monta(){
      var corpo = pn.querySelector('#oltOscCorpo');
      if (!dados.length) { corpo.innerHTML = '<div style="padding:18px;opacity:.8;">Nenhuma conexão com o mínimo de quedas escolhido neste período.</div>'; return; }
      var th = 'text-align:left;padding:8px 10px;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';position:sticky;top:0;background:' + cor('bg', '#fff') + ';';
      var h = '<table style="width:100%;border-collapse:collapse;font-size:12.5px;"><thead><tr>' +
        ['Cliente', 'Login', 'PON / ONU', 'Sinal Rx OLT', 'Quedas', 'Perda de sinal', 'Causa mais comum', 'Última queda', 'Sessão média'].map(function(t){ return '<th style="' + th + '">' + t + '</th>'; }).join('') + '</tr></thead><tbody>';
      dados.forEach(function(r){
        var o = onuDe(r.login); var rx = o ? (o.rx_olt || o.rx || '') : '';
        var cq = r.quedas >= 10 ? cor('redf', '#dc2626') : (r.quedas >= 5 ? cor('amb', '#d97706') : cor('txt', '#0f172a'));
        var cp = r.perdas > 0 ? cor('redf', '#dc2626') : cor('mut', '#475569');
        var td = 'padding:7px 10px;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';vertical-align:middle;';
        h += '<tr><td style="' + td + 'font-weight:700;"><span class="olt-cli-nome" data-olt-login="' + _oltEsc(r.login) + '" style="cursor:default;">' + _oltEsc(r.nome || '—') + '</span></td>' +
          '<td style="' + td + 'font-family:monospace;font-size:11.5px;">' + _oltEsc(r.login) + '</td>' +
          '<td style="' + td + '">' + (o ? _oltEsc((o.fsp || '') + ' · ID ' + (o.id || '')) : '<span style="opacity:.55">—</span>') + '</td>' +
          '<td style="' + td + '">' + _oltEsc(rx || '—') + '</td>' +
          '<td style="' + td + 'font-weight:800;color:' + cq + ';">' + r.quedas + '</td>' +
          '<td style="' + td + 'font-weight:700;color:' + cp + ';">' + r.perdas + '</td>' +
          '<td style="' + td + '">' + _oltEsc(r.causa || '—') + '</td>' +
          '<td style="' + td + '">' + _oltEsc(dma(r.ultima)) + '</td>' +
          '<td style="' + td + '">' + dur(r.dur_media_s) + '</td></tr>';
      });
      corpo.innerHTML = h + '</tbody></table>';
      [].forEach.call(corpo.querySelectorAll('tbody tr'), function(tr, i){ if (!dados[i]) return; tr.style.cursor = 'pointer'; tr.title = 'Clique para ver o histórico de conexões deste cliente'; tr.onclick = function(){ try { oltHistoricoConexoes(dados[i].login); } catch (e) {} }; });
    }
    function carregar(){
      var dias = pn.querySelector('#oltOscDias').value, min = Math.max(1, Math.min(50, parseInt(pn.querySelector('#oltOscMin').value, 10) || 3));
      var info = pn.querySelector('#oltOscInfo'), corpo = pn.querySelector('#oltOscCorpo');
      corpo.innerHTML = '<div style="padding:18px;opacity:.7;">Carregando…</div>';
      fetch('olt_oscilacao.php?dias=' + encodeURIComponent(dias) + '&min=' + min, {credentials: 'same-origin'}).then(function(r){ return r.json(); }).then(function(d){
        if (!d || !d.ok) { dados = []; info.textContent = ''; corpo.innerHTML = '<div style="padding:18px;color:' + cor('redf', '#dc2626') + ';">' + _oltEsc((d && d.erro) || 'Não consegui carregar.') + '</div>'; return; }
        dados = d.itens || [];
        info.innerHTML = '<b>' + dados.length + '</b> conexão(ões) com <b>' + min + '</b> ou mais quedas desde ' + _oltEsc(dma(d.desde)) + '. Cada queda é uma sessão que terminou; <b>perda de sinal</b> = o concentrador perdeu o cliente (cabo/ONU/energia). Quem reiniciou o próprio roteador entra em "quedas", mas não em "perda de sinal". Bloqueios e derrubadas feitos pelo sistema não contam.' +
          (d.sem_historico ? '<br><b>Atenção:</b> o histórico do RADIUS neste servidor começa em ' + _oltEsc(dma(d.primeira_sessao)) + ' — o relatório fica mais completo a cada dia.' : '');
        monta();
      }).catch(function(){ corpo.innerHTML = '<div style="padding:18px;color:' + cor('redf', '#dc2626') + ';">Não consegui carregar o relatório.</div>'; });
    }
    pn.querySelector('#oltOscAtu').onclick = carregar;
    pn.querySelector('#oltOscDias').onchange = carregar;
    pn.querySelector('#oltOscCsv').onclick = function(){
      try {
        if (!dados.length) { alert('Não há dados para exportar.'); return; }
        function cel(v){ v = (v == null) ? '' : String(v).replace(/\r?\n/g, ' ').trim(); if (/^[=+@]/.test(v) || (/^-/.test(v) && !/^-\d+([.,]\d+)?$/.test(v))) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
        var L = [['Cliente', 'Login', 'F/S/P', 'ID', 'Sinal Rx OLT', 'Quedas', 'Perda de sinal', 'Causa mais comum', 'Última queda', 'Sessão média (min)'].map(cel).join(';')];
        dados.forEach(function(r){ var o = onuDe(r.login); var rx = o ? (o.rx_olt || o.rx || '') : ''; var m = String(rx).match(/-?\d+(\.\d+)?/);
          L.push([r.nome || '', r.login, o ? (o.fsp || '') : '', o ? (o.id || '') : '', m ? m[0].replace('.', ',') : '', r.quedas, r.perdas, r.causa || '', r.ultima || '', Math.round((+r.dur_media_s || 0) / 60)].map(cel).join(';')); });
        var d = new Date(), p2 = function(n){ return (n < 10 ? '0' : '') + n; };
        var blob = new Blob(['﻿' + L.join('\r\n')], {type: 'text/csv;charset=utf-8'});
        var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'oscilacao-conexoes-' + d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + '.csv';
        document.body.appendChild(a); a.click(); setTimeout(function(){ try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 1500);
      } catch (e) { alert('Não consegui gerar o CSV.'); }
    };
    carregar();
  } catch (err) { try { alert('Não consegui abrir o relatório: ' + err.message); } catch (e2) {} }
}

/* LIMITES DE SINAL (21/10/2026): o operador define o sinal BASE de aceitação (dBm) — da OLT toda e, se quiser, por PON. Abaixo da base a ONU é RUIM; vermelho até
   base+0,3 e âmbar até base+1,4 (com a base padrão -29,4 são exatamente os -29,1 / -28 de sempre). Sem nada salvo, o comportamento NÃO muda.
   Dados em olt_limites.php (cache_trafego/olt_limites_sinal.json, entra no backup). Estas funções só são consultadas por _oltSinalClasse / _oltCorSinal(De). */
function _oltLimBase(o){
  try {
    var L = window._oltLimites || {};
    if (o && o.fsp && L.pon && L.pon[o.fsp] != null && !isNaN(+L.pon[o.fsp])) return +L.pon[o.fsp];
    if (L.global != null && !isNaN(+L.global)) return +L.global;
  } catch (e) {}
  return OLT_RX_LIMITE;
}
function _oltLimitesCarregar(depois){
  try {
    fetch('olt_limites.php', {credentials: 'same-origin'}).then(function(r){ return r.json(); }).then(function(d){
      if (!d || !d.ok) return;
      var antes = JSON.stringify(window._oltLimites || {});
      window._oltLimites = {global: (d.global == null ? null : +d.global), pon: d.pon || {}};
      var temCustom = (window._oltLimites.global != null) || (Object.keys(window._oltLimites.pon).length > 0);
      if (temCustom && antes !== JSON.stringify(window._oltLimites)) { try { if (typeof oltGerenciadorAberto === 'function' && oltGerenciadorAberto() && typeof oltRenderLista === 'function') oltRenderLista(); } catch (e2) {} }
      if (typeof depois === 'function') depois();
    }).catch(function(){});
  } catch (e) {}
}
setTimeout(function(){ _oltLimitesCarregar(); }, 1500);

function oltLimitesSinal(){
  try {
    var ant = document.getElementById('oltLimOverlay'); if (ant) ant.remove();
    var C = window.OLTC || {}; function cor(k, p){ return C[k] || p; }
    var ov = document.createElement('div'); ov.id = 'oltLimOverlay';
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147482000;background:rgba(0,0,0,.5);display:flex;align-items:flex-start;justify-content:center;padding:4vh 12px;overflow:auto;';
    var pn = document.createElement('div');
    pn.style.cssText = 'background:' + cor('bg', '#fff') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:12px;width:min(760px,100%);box-shadow:0 14px 44px rgba(0,0,0,.4);padding:16px 18px;';
    var inp = 'background:' + cor('panel', '#e8edf3') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:8px;padding:7px 10px;font-size:13px;width:92px;';
    var bt = 'cursor:pointer;padding:8px 15px;border-radius:8px;border:1px solid ' + cor('line', '#cdd6e0') + ';background:transparent;color:' + cor('txt', '#0f172a') + ';font-size:12.5px;font-weight:600;';
    pn.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;"><div style="font-size:17px;font-weight:800;flex:1;">📶 Limites de sinal (Rx)</div><button id="oltLimX" style="' + bt + '">✕</button></div>' +
      '<div style="font-size:12px;color:' + cor('mut', '#475569') + ';line-height:1.5;margin-bottom:12px;">Defina o <b>sinal base de aceitação</b> (dBm). ONU com sinal <b>abaixo</b> da base é classificada como <b>RUIM</b>; fica vermelha até 0,3 dB acima da base e âmbar até 1,4 dB acima. ' +
        'Deixe em branco para usar o padrão (<b>-29,4 dBm</b>). Pode definir uma base diferente para uma PON específica. Valores entre -45 e -10.</div>' +
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;"><label style="font-weight:700;font-size:13px;">Base da OLT toda (dBm)</label><input id="oltLimGlobal" type="text" inputmode="decimal" placeholder="-29,4" style="' + inp + '"><span id="oltLimGinfo" style="font-size:12px;color:' + cor('mut', '#475569') + ';"></span></div>' +
      '<div style="font-weight:700;font-size:13px;margin:6px 0;">Base por PON <span style="font-weight:400;color:' + cor('mut', '#475569') + ';">(opcional — vale no lugar da base da OLT)</span></div>' +
      '<div id="oltLimLista" style="max-height:46vh;overflow:auto;border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:8px;"></div>' +
      '<div style="display:flex;align-items:center;gap:10px;margin-top:12px;"><button id="oltLimSalvar" style="' + bt + 'background:' + cor('grn', '#16a34a') + ';color:#fff;border-color:transparent;">Salvar</button><span id="oltLimMsg" style="font-size:12.5px;"></span></div>';
    ov.appendChild(pn); document.body.appendChild(ov);
    function fechar(){ try { ov.remove(); document.removeEventListener('keydown', esc, true); } catch (e) {} }
    function esc(e){ if (e.key === 'Escape') fechar(); }
    document.addEventListener('keydown', esc, true);
    ov.addEventListener('click', function(e){ if (e.target === ov) fechar(); });
    pn.querySelector('#oltLimX').onclick = fechar;
    function f2(n){ return String(n).replace('.', ','); }
    function pons(){
      var m = {}; (window._oltLista || []).forEach(function(o){ var k = o.fsp || ''; if (!k) return; if (!m[k]) m[k] = {k: k, n: 0, ruins: 0}; m[k].n++; });
      return Object.keys(m).sort(function(a, b){ var x = a.split('/').map(Number), y = b.split('/').map(Number); for (var i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; }).map(function(k){ return m[k]; });
    }
    function desenha(){
      var L = window._oltLimites || {global: null, pon: {}}; var g = pn.querySelector('#oltLimGlobal'); g.value = (L.global == null ? '' : f2(L.global));
      pn.querySelector('#oltLimGinfo').textContent = 'em uso agora: ' + f2(L.global != null ? L.global : OLT_RX_LIMITE) + ' dBm';
      var td = 'padding:6px 10px;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';font-size:12.5px;';
      var h = '<table style="width:100%;border-collapse:collapse;"><thead><tr><th style="' + td + 'text-align:left;">PON (F/S/P)</th><th style="' + td + 'text-align:left;">ONUs</th><th style="' + td + 'text-align:left;">Base desta PON (dBm)</th></tr></thead><tbody>';
      pons().forEach(function(p){
        var v = (L.pon && L.pon[p.k] != null) ? f2(L.pon[p.k]) : '';
        h += '<tr><td style="' + td + 'font-family:monospace;">' + _oltEsc(p.k) + '</td><td style="' + td + '">' + p.n + '</td><td style="' + td + '"><input data-pon="' + _oltEsc(p.k) + '" type="text" inputmode="decimal" value="' + _oltEsc(v) + '" placeholder="padrão" style="' + inp + '"></td></tr>';
      });
      pn.querySelector('#oltLimLista').innerHTML = h + '</tbody></table>';
    }
    _oltLimitesCarregar(desenha); desenha();
    pn.querySelector('#oltLimSalvar').onclick = function(){
      var msg = pn.querySelector('#oltLimMsg'); msg.style.color = cor('mut', '#475569'); msg.textContent = 'Salvando…';
      var pon = {}; pn.querySelectorAll('input[data-pon]').forEach(function(i){ var v = i.value.trim(); if (v !== '') pon[i.getAttribute('data-pon')] = v; });
      var corpo = 'global=' + encodeURIComponent(pn.querySelector('#oltLimGlobal').value.trim()) + '&pon=' + encodeURIComponent(JSON.stringify(pon));
      fetch('olt_limites.php', {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Olt-Limites': '1'}, body: corpo}).then(function(r){ return r.json(); }).then(function(d){
        if (!d || !d.ok) { msg.style.color = cor('redf', '#dc2626'); msg.textContent = (d && d.erro) || 'Não salvou.'; return; }
        window._oltLimites = {global: (d.global == null ? null : +d.global), pon: d.pon || {}};
        msg.style.color = cor('grn', '#16a34a'); msg.textContent = '✔ Salvo e aplicado na lista.'; desenha();
        try { if (typeof oltRenderLista === 'function') oltRenderLista(); } catch (e) {}
      }).catch(function(){ msg.style.color = cor('redf', '#dc2626'); msg.textContent = 'Não consegui salvar.'; });
    };
  } catch (err) { try { alert('Não consegui abrir os limites de sinal: ' + err.message); } catch (e2) {} }
}

/* LOGO DO TOPO SEM FUNDO BRANCO (21/10/2026): qualquer logo enviada em "Logomarca da OLT" (redonda, quadrada, retangular) que tenha FUNDO BRANCO nos 4 cantos
   (JPEG, por exemplo) fica com o fundo transparente no cabeçalho da OLT — sem a "caixa" branca. Logo que já é transparente (PNG) não é tocada. Feito só na tela
   (a imagem guardada no servidor não muda). Qualquer falha mantém a logo original. */
function _oltLogoLimparSrc(src, cb){
  try {
    var im = new Image();
    im.onload = function(){
      try {
        var W = im.naturalWidth, H = im.naturalHeight; if (!W || !H) { cb(null); return; }
        var esc = Math.min(1, 320 / Math.max(W, H)), w = Math.max(1, Math.round(W * esc)), h = Math.max(1, Math.round(H * esc));
        var c = document.createElement('canvas'); c.width = w; c.height = h; var x = c.getContext('2d'); x.drawImage(im, 0, 0, w, h);
        var id = x.getImageData(0, 0, w, h), d = id.data;
        function claro(i){ return d[i + 3] > 240 && d[i] >= 235 && d[i + 1] >= 235 && d[i + 2] >= 235; }
        if (![0, (w - 1) * 4, ((h - 1) * w) * 4, (h * w - 1) * 4].every(claro)) { cb(null); return; }
        var vis = new Uint8Array(w * h), pilha = [], k;
        for (k = 0; k < w; k++) { pilha.push(k, 0, k, h - 1); } for (k = 0; k < h; k++) { pilha.push(0, k, w - 1, k); }
        while (pilha.length) {
          var yy = pilha.pop(), xx = pilha.pop(); if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
          var p = yy * w + xx; if (vis[p]) continue; var i = p * 4; if (!claro(i)) continue;
          vis[p] = 1; d[i + 3] = 0; pilha.push(xx + 1, yy, xx - 1, yy, xx, yy + 1, xx, yy - 1);
        }
        for (var y = 1; y < h - 1; y++) { for (var x2 = 1; x2 < w - 1; x2++) {
          var q = y * w + x2, j = q * 4; if (d[j + 3] === 0) continue;
          if (vis[q - 1] || vis[q + 1] || vis[q - w] || vis[q + w]) { var lum = (d[j] + d[j + 1] + d[j + 2]) / 3; if (lum > 170) d[j + 3] = Math.max(0, Math.min(255, Math.round((255 - lum) * 3.2))); }
        } }
        x.putImageData(id, 0, 0); cb(c.toDataURL('image/png'));
      } catch (e) { cb(null); }
    };
    im.onerror = function(){ cb(null); };
    im.src = src;
  } catch (e) { cb(null); }
}
(function(){
  try {
    var tent = 0, t = setInterval(function(){
      tent++; var img = document.getElementById('oltHdrLogo');
      if (img && !img.getAttribute('data-limpa')) {
        img.setAttribute('data-limpa', '1');
        _oltLogoLimparSrc(img.getAttribute('src') || img.src, function(novo){ if (novo) { try { img.src = novo; } catch (e) {} } });
      }
      if (tent > 60 || (img && img.getAttribute('data-limpa'))) clearInterval(t);
    }, 700);
  } catch (e) {}
})();

/* HISTÓRICO DE CONEXÕES POR CLIENTE/ONU (21/10/2026): linha do tempo das sessões do RADIUS de um login (conectou, caiu, por quê, quanto durou), via olt_historico.php
   — só leitura. Janela independente (não mexe na lista nem na coleta da OLT). Abre pelo Menu (com busca por nome/login) ou ao clicar numa linha do relatório de oscilação. */
function oltHistoricoConexoes(loginIni){
  try {
    var ant = document.getElementById('oltHisOverlay'); if (ant) ant.remove();
    var C = window.OLTC || {}; function cor(k, p){ return C[k] || p; }
    var ov = document.createElement('div'); ov.id = 'oltHisOverlay';
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147482100;background:rgba(0,0,0,.5);display:flex;align-items:flex-start;justify-content:center;padding:4vh 12px;overflow:auto;';
    var pn = document.createElement('div');
    pn.style.cssText = 'background:' + cor('bg', '#fff') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:12px;width:min(980px,100%);box-shadow:0 14px 44px rgba(0,0,0,.4);padding:16px 18px;';
    var inp = 'background:' + cor('panel', '#e8edf3') + ';color:' + cor('txt', '#0f172a') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:8px;padding:8px 11px;font-size:13px;';
    var bt = 'cursor:pointer;padding:7px 13px;border-radius:8px;border:1px solid ' + cor('line', '#cdd6e0') + ';background:transparent;color:' + cor('txt', '#0f172a') + ';font-size:12.5px;font-weight:600;';
    pn.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;">' +
        '<div style="font-size:17px;font-weight:800;flex:1 1 auto;">🕘 Histórico de conexões</div>' +
        '<select id="oltHisDias" style="' + inp + '"><option value="7">Últimos 7 dias</option><option value="30" selected>Últimos 30 dias</option><option value="90">Últimos 90 dias</option></select>' +
        '<button id="oltHisCsv" style="' + bt + '">CSV</button><button id="oltHisX" style="' + bt + '">✕</button>' +
      '</div>' +
      '<div style="position:relative;margin-bottom:10px;"><input id="oltHisBusca" type="text" autocomplete="off" placeholder="Digite o nome, o login ou o serial do cliente…" style="' + inp + 'width:100%;box-sizing:border-box;">' +
        '<div id="oltHisSug" style="display:none;position:absolute;left:0;right:0;top:100%;z-index:5;background:' + cor('bg', '#fff') + ';border:1px solid ' + cor('line', '#cdd6e0') + ';border-radius:8px;box-shadow:0 8px 22px rgba(0,0,0,.25);max-height:260px;overflow:auto;"></div></div>' +
      '<div id="oltHisInfo" style="font-size:12.5px;color:' + cor('mut', '#475569') + ';margin-bottom:8px;line-height:1.5;"></div>' +
      '<div id="oltHisCorpo" style="overflow:auto;max-height:62vh;"><div style="padding:16px;opacity:.7;">Escolha um cliente acima.</div></div>';
    ov.appendChild(pn); document.body.appendChild(ov);
    var dados = [], loginAtual = '', nomeAtual = '';
    function fechar(){ try { ov.remove(); document.removeEventListener('keydown', esc, true); } catch (e) {} }
    function esc(e){ if (e.key === 'Escape') fechar(); }
    document.addEventListener('keydown', esc, true);
    ov.addEventListener('click', function(e){ if (e.target === ov) fechar(); });
    pn.querySelector('#oltHisX').onclick = fechar;
    function dma(s){ var m = String(s || '').match(/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})/); return m ? (m[3] + '/' + m[2] + ' ' + m[4] + ':' + m[5]) : (s ? String(s) : '—'); }
    function dur(s){ s = +s || 0; if (s <= 0) return '—'; var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60); return d > 0 ? (d + 'd ' + h + 'h') : (h > 0 ? (h + 'h ' + m + 'min') : (m + 'min')); }
    function carregar(login){
      loginAtual = login; var dias = pn.querySelector('#oltHisDias').value, info = pn.querySelector('#oltHisInfo'), corpo = pn.querySelector('#oltHisCorpo');
      corpo.innerHTML = '<div style="padding:16px;opacity:.7;">Carregando…</div>'; info.textContent = '';
      fetch('olt_historico.php?login=' + encodeURIComponent(login) + '&dias=' + encodeURIComponent(dias), {credentials: 'same-origin'}).then(function(r){ return r.json(); }).then(function(d){
        if (!d || !d.ok) { dados = []; corpo.innerHTML = '<div style="padding:16px;color:' + cor('redf', '#dc2626') + ';">' + _oltEsc((d && d.erro) || 'Não consegui carregar.') + '</div>'; return; }
        dados = d.itens || []; nomeAtual = d.nome || '';
        info.innerHTML = '<b>' + _oltEsc(d.nome || login) + '</b> <span style="font-family:monospace;font-size:11.5px;">(' + _oltEsc(login) + ')</span> — ' + d.resumo.sessoes + ' sessão(ões), <b>' + d.resumo.quedas + '</b> queda(s), <b style="color:' + (d.resumo.perdas ? cor('redf', '#dc2626') : 'inherit') + ';">' + d.resumo.perdas + '</b> por perda de sinal, nos últimos ' + d.dias + ' dias. ' +
          '<span style="opacity:.8;">Derrubadas feitas pelo sistema e reinícios do concentrador não contam como queda.</span>';
        if (!dados.length) { corpo.innerHTML = '<div style="padding:16px;opacity:.8;">Nenhuma sessão deste login no período (o histórico do RADIUS só existe de quando ele passou a receber a contabilização).</div>'; return; }
        var th = 'text-align:left;padding:8px 10px;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';position:sticky;top:0;background:' + cor('bg', '#fff') + ';';
        var td = 'padding:6px 10px;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';';
        var h = '<table style="width:100%;border-collapse:collapse;font-size:12.5px;"><thead><tr>' + ['Conectou', 'Caiu', 'Duração', 'Motivo', 'IP', 'Concentrador'].map(function(t){ return '<th style="' + th + '">' + t + '</th>'; }).join('') + '</tr></thead><tbody>';
        dados.forEach(function(s){
          var ruim = /^(Lost-|Port-Error|NAS-Error)/.test(s.causa_cod || ''); var vivo = !s.fim;
          h += '<tr><td style="' + td + '">' + _oltEsc(dma(s.inicio)) + '</td><td style="' + td + '">' + (vivo ? '<b style="color:' + cor('grn', '#16a34a') + ';">conectado</b>' : _oltEsc(dma(s.fim))) + '</td><td style="' + td + '">' + (vivo ? '' : dur(s.dur_s)) + '</td>' +
            '<td style="' + td + 'font-weight:' + (ruim ? '800' : '500') + ';color:' + (ruim ? cor('redf', '#dc2626') : 'inherit') + ';">' + _oltEsc(s.causa || '—') + '</td><td style="' + td + 'font-family:monospace;font-size:11.5px;">' + _oltEsc(s.ip || '') + '</td><td style="' + td + '">' + _oltEsc(s.nas || '') + '</td></tr>';
        });
        corpo.innerHTML = h + '</tbody></table>';
      }).catch(function(){ corpo.innerHTML = '<div style="padding:16px;color:' + cor('redf', '#dc2626') + ';">Não consegui carregar o histórico.</div>'; });
    }
    pn.querySelector('#oltHisDias').onchange = function(){ if (loginAtual) carregar(loginAtual); };
    // busca por nome/login/serial na lista de ONUs já carregada na tela
    var busca = pn.querySelector('#oltHisBusca'), sug = pn.querySelector('#oltHisSug');
    function sugere(){
      var q = busca.value.trim().toLowerCase(); if (q.length < 2) { sug.style.display = 'none'; return; }
      var achou = [], l = window._oltLista || [];
      for (var i = 0; i < l.length && achou.length < 8; i++) {
        var o = l[i], nm = ''; try { nm = _oltNomeDe(o) || ''; } catch (e) { nm = o.nome || ''; }
        var lg = ''; try { lg = _oltLoginResolvido(o.serial); } catch (e) { lg = o.serial || ''; }
        if (_oltPalavras(_oltNorm(nm + ' ' + (o.nome || '') + ' ' + (o.serial || '') + ' ' + lg), q)) achou.push({nm: nm || o.serial, lg: lg || o.serial, fsp: o.fsp || ''});
      }
      if (!achou.length) { sug.innerHTML = '<div style="padding:9px 12px;opacity:.7;">Nada encontrado na lista. Digite o login e tecle Enter.</div>'; sug.style.display = 'block'; return; }
      sug.innerHTML = achou.map(function(a, i){ return '<div data-i="' + i + '" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid ' + cor('line', '#cdd6e0') + ';"><b>' + _oltEsc(a.nm) + '</b> <span style="font-family:monospace;font-size:11px;opacity:.75;">' + _oltEsc(a.lg) + ' · ' + _oltEsc(a.fsp) + '</span></div>'; }).join('');
      sug.style.display = 'block';
      [].forEach.call(sug.querySelectorAll('div[data-i]'), function(dv){ dv.onclick = function(){ var a = achou[+dv.getAttribute('data-i')]; busca.value = a.nm; sug.style.display = 'none'; carregar(a.lg); }; });
    }
    busca.addEventListener('input', sugere);
    busca.addEventListener('keydown', function(e){ if (e.key === 'Enter') { var v = busca.value.trim(); if (v) { sug.style.display = 'none'; carregar(v); } } });
    pn.querySelector('#oltHisCsv').onclick = function(){
      try {
        if (!dados.length) { alert('Não há dados para exportar.'); return; }
        function cel(v){ v = (v == null) ? '' : String(v).replace(/\r?\n/g, ' ').trim(); if (/^[=+@]/.test(v) || (/^-/.test(v) && !/^-\d+([.,]\d+)?$/.test(v))) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
        var L = [['Conectou', 'Caiu', 'Duração (min)', 'Motivo', 'IP', 'Concentrador'].map(cel).join(';')];
        dados.forEach(function(s){ L.push([s.inicio, s.fim, s.fim ? Math.round((+s.dur_s || 0) / 60) : '', s.causa, s.ip, s.nas].map(cel).join(';')); });
        var d = new Date(), p2 = function(n){ return (n < 10 ? '0' : '') + n; };
        var blob = new Blob(['﻿' + L.join('\r\n')], {type: 'text/csv;charset=utf-8'});
        var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'historico-conexoes-' + String(loginAtual).replace(/[^0-9A-Za-z_.-]/g, '') + '-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '.csv';
        document.body.appendChild(a); a.click(); setTimeout(function(){ try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 1500);
      } catch (e) { alert('Não consegui gerar o CSV.'); }
    };
    if (loginIni) { busca.value = String(loginIni); carregar(String(loginIni)); } else { setTimeout(function(){ try { busca.focus(); } catch (e) {} }, 100); }
  } catch (err) { try { alert('Não consegui abrir o histórico: ' + err.message); } catch (e2) {} }
}
/* 15/11/2026: Exportar CSV + Imprimir em toda tabela de dados da OLT (mesmo script das demais telas). */
(function () { if (window.__wsTabelas || document.querySelector('script[src*="ws_tabelas.js"]')) return; var s = document.createElement('script'); s.src = 'js/ws_tabelas.js'; (document.head || document.documentElement).appendChild(s); })();
