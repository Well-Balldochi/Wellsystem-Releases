/* WellSystem — caixinha "Salvando…" (26/11/2026, pedido do dono: em TODAS as páginas, ao salvar, mostrar o processo para acompanhar).
   Aparece no canto inferior direito: giro + nome da ação + segundos; ao terminar vira "✔ Salvo" (some em 2,5 s) ou "✘ Falhou: motivo" (fica 9 s).
   Cobre: (1) formulários POST do sistema (a caixa fica até a página recarregar); (2) gravações por fetch da OLT (olt_huawei.php) e do painel do concentrador (?api=conc_*).
   Não mexe em nada do que a tela faz: só observa. Um arquivo só, sem dependência; funciona com o tema claro/escuro (usa as cores da própria caixa). */
(function () {
    if (window.__wsSalvando) return; window.__wsSalvando = 1;
    var ROT = {
        uplink_vlan: 'VLAN da porta de uplink', uplink_estado: 'porta de uplink', vlan_criar: 'criando VLAN na OLT', vlan_excluir: 'excluindo VLAN da OLT',
        vlan_nomes_add: 'nome da VLAN', perfis_add: 'perfil', perfis_del: 'perfil', opcoes_add: 'opção da lista', opcoes_del: 'opção da lista',
        meta_set: 'cadastro da PON', cadastro_set: 'cadastro do cliente', conexao_set: 'conexão com a OLT', notif_set: 'avisos', modelos_set: 'modelo',
        modelos_del: 'modelo', usuarios_add: 'usuário', usuarios_del: 'usuário', olt_add: 'cadastro da OLT', olt_ren: 'nome da OLT', olt_del: 'removendo OLT',
        smartolt_cfg_set: 'SmartOLT', radius_panel_set: 'painel Radius', backup_import: 'restaurando backup', backup_ag_set: 'agendamento do backup',
        logo_set: 'logomarca', onu_modo: 'modo da ONU', onu_trocar_vlan: 'VLAN da ONU', onu_acao: 'ação na ONU', autorizar: 'autorizando ONU',
        criar_service_port: 'service-port', pon_control: 'controle da PON', placa_estado: 'placa', placa_reset: 'reiniciando placa', cad_url_set: 'link de cadastro',
        onu_desc_smart: 'descrição da ONU', generico_migrar: 'migração', modelo_img_set: 'imagem do modelo', modelo_img_del: 'imagem do modelo',
        mkfiles_upload: 'arquivo', mkfiles_del: 'arquivo', conc_salvar: 'configuração do concentrador', conc_reiniciar: 'reiniciando o concentrador'
    };
    var OLT_ESCRITA = /^(uplink_vlan|uplink_estado|vlan_criar|vlan_excluir|vlan_nomes_add|perfis_add|perfis_del|opcoes_add|opcoes_del|meta_set|cadastro_set|conexao_set|notif_set|modelos_set|modelos_del|usuarios_add|usuarios_del|olt_add|olt_ren|olt_del|smartolt_cfg_set|radius_panel_set|backup_import|backup_ag_set|logo_set|onu_modo|onu_trocar_vlan|onu_acao|autorizar|criar_service_port|pon_control|placa_estado|placa_reset|cad_url_set|onu_desc_smart|generico_migrar|modelo_img_set|modelo_img_del|mkfiles_upload|mkfiles_del)$/;
    var box = null, jobs = {}, seq = 0, tHide = null, tTick = null;

    function pronto(fn) { if (document.body) fn(); else document.addEventListener('DOMContentLoaded', fn); }
    function garante() {
        if (box && document.body.contains(box)) return box;
        box = document.createElement('div'); box.id = 'ws-salvando'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite');
        box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483600;max-width:min(360px,calc(100vw - 32px));display:none;flex-direction:column;gap:6px;' +
            'padding:10px 14px;border-radius:12px;background:#0f172a;color:#fff;font:600 13px/1.35 system-ui,Segoe UI,Arial,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.18)';
        if (!document.getElementById('ws-salvando-css')) {
            var st = document.createElement('style'); st.id = 'ws-salvando-css';
            st.textContent = '@keyframes wsSalvGira{to{transform:rotate(360deg)}}#ws-salvando .gira{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.35);border-top-color:#fff;border-radius:50%;animation:wsSalvGira .8s linear infinite;vertical-align:-2px;margin-right:8px}' +
                '#ws-salvando .ok{color:#4ade80}#ws-salvando .er{color:#fca5a5}#ws-salvando small{opacity:.75;font-weight:500;margin-left:6px}';
            document.head.appendChild(st);
        }
        document.body.appendChild(box); return box;
    }
    function desenha() {
        pronto(function () {
            var b = garante(), ks = Object.keys(jobs);
            if (!ks.length) { b.style.display = 'none'; return; }
            var agora = Date.now();
            b.innerHTML = ks.map(function (k) {
                var j = jobs[k], s = Math.max(0, Math.round((agora - j.t0) / 1000));
                if (j.fim === 'ok') return '<div class="ok">✔ Salvo — ' + esc(j.rot) + '</div>';
                if (j.fim === 'er') return '<div class="er">✘ Não salvou — ' + esc(j.rot) + (j.msg ? '<br><small>' + esc(j.msg) + '</small>' : '') + '</div>';
                return '<div><span class="gira"></span>Salvando — ' + esc(j.rot) + '<small>' + s + ' s</small></div>';
            }).join('');
            b.style.display = 'flex';
        });
    }
    function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
    function tick() {
        var ativos = Object.keys(jobs).some(function (k) { return !jobs[k].fim; });
        if (ativos && !tTick) tTick = setInterval(desenha, 1000);
        if (!ativos && tTick) { clearInterval(tTick); tTick = null; }
    }
    function inicia(rot) { var id = ++seq; jobs[id] = { rot: rot, t0: Date.now(), fim: '' }; desenha(); tick(); return id; }
    function termina(id, ok, msg) {
        var j = jobs[id]; if (!j) return; j.fim = ok ? 'ok' : 'er'; j.msg = msg || ''; desenha(); tick();
        setTimeout(function () { delete jobs[id]; desenha(); }, ok ? 2500 : 9000);
    }
    window.wsSalvandoIniciar = inicia; window.wsSalvandoTerminar = termina;

    // ---- (2) gravações por fetch (OLT e painel do concentrador) -----------------------------------------------------------
    function acaoDe(url, body) {
        var u = String(url || ''), m;
        if (u.indexOf('olt_huawei.php') > -1) {
            m = /(?:^|[?&])acao=([a-z_0-9]+)/.exec(u) || (typeof body === 'string' ? /(?:^|&)acao=([a-z_0-9]+)/.exec(body) : null);
            return m && OLT_ESCRITA.test(m[1]) ? m[1] : '';
        }
        m = /[?&]api=(conc_[a-z_0-9]+)/.exec(u);
        return m ? m[1] : '';
    }
    function falhou(d) {
        if (!d || typeof d !== 'object') return '';
        if (d.ok === false || d.saved === false || d.criada === false || d.excluida === false) return d.message || d.msg || (d.saved === false ? 'a OLT/servidor não gravou' : 'a resposta indica falha');
        if (d.status && /^(erro|error|nao_autenticado)$/i.test(d.status)) return d.message || d.mensagem || 'erro';
        return '';
    }
    if (window.fetch && !window.fetch.__wsSalv) {
        var f0 = window.fetch;
        window.fetch = function (url, opt) {
            var met = ((opt && opt.method) || (url && url.method) || 'GET').toUpperCase(), ac = '';
            try { if (met === 'POST' || /(?:^|[?&])acao=/.test(String(url && url.url || url))) ac = acaoDe(url && url.url || url, opt && opt.body); } catch (e) { ac = ''; }
            if (!ac) return f0.apply(this, arguments);
            var id = inicia(ROT[ac] || ac.replace(/_/g, ' '));
            return f0.apply(this, arguments).then(function (r) {
                try { r.clone().json().then(function (d) { var m = falhou(d); termina(id, !m && r.ok, m || (r.ok ? '' : 'HTTP ' + r.status)); }, function () { termina(id, r.ok, r.ok ? '' : 'HTTP ' + r.status); }); }
                catch (e) { termina(id, r.ok, ''); }
                return r;
            }, function (e) { termina(id, false, 'sem resposta do servidor'); throw e; });
        };
        window.fetch.__wsSalv = 1;
    }

    // ---- (1) formulários POST: a caixa fica até a página trocar -----------------------------------------------------------
    document.addEventListener('submit', function (e) {
        var f = e.target; if (!f || e.defaultPrevented || !f.tagName || f.tagName !== 'FORM') return;
        if (String(f.method || 'get').toLowerCase() !== 'post' || f.target === '_blank' || f.hasAttribute('data-sem-salvando')) return;
        var rot = (f.getAttribute('data-salvando') || (e.submitter && (e.submitter.textContent || e.submitter.value || '').trim()) || 'alterações').slice(0, 40);
        var id = inicia(rot);
        setTimeout(function () { if (jobs[id] && !jobs[id].fim) { delete jobs[id]; desenha(); tick(); } }, 25000);   // download/resposta sem recarregar: não fica preso
    }, false);
    window.addEventListener('pageshow', function () { jobs = {}; desenha(); tick(); });
})();
