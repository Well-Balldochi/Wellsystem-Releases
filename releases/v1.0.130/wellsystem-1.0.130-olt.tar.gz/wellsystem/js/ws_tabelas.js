/* WellSystem — EXPORTAR CSV E IMPRIMIR EM TODA TABELA DE DADOS (15/11/2026, pedido do dono: "em toda página e aba que tem dados tem que ter exportar CSV e imprimir").
 * Carregado pelo rodapé padrão (ws_footer_bar) e pelos painéis independentes (Servidor de Log, DNS). Sem dependências.
 *
 * O que faz: toda <table> com cabeçalho (thead com 2+ colunas) e linhas de dados ganha, acima dela, a barra  [⬇ Exportar CSV] [🖨 Imprimir].
 *  · Exporta/imprime o que está NA TELA: linhas escondidas por filtro/busca ficam de fora; se houver linhas SELECIONADAS (caixa marcada na linha, ou Ctrl+clique),
 *    só elas saem — a barra mostra "N selecionada(s)" e o botão "limpar".
 *  · Colunas de ação (botões, caixas de seleção, cabeçalho vazio) não entram. Paginação do servidor: sai a página aberta (use "Todos" no rodapé para tudo).
 *  · Se a tela já tem seu próprio "CSV"/"Exportar"/"Imprimir" junto da tabela, o botão equivalente NÃO é repetido.
 *  · Tabela que não deve ter a barra: classe ws-sem-export na tabela ou em um ancestral.
 *  · CSV: UTF-8 com BOM e separador ";" (abre direto no Excel em português). Impressão: documento limpo (título, data/hora, tabela), em paisagem quando larga.
 */
(function () {
  'use strict';
  if (window.__wsTabelas) return; window.__wsTabelas = 1;

  var RE_CSV = /csv|exportar|baixar planilha|planilha/i, RE_PRINT = /imprimir|impress|print/i;

  function txt(el) { return ((el.innerText != null ? el.innerText : el.textContent) || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim(); }
  function visivel(el) { return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function agora() { var d = new Date(); return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function hojeArq() { var d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

  function cabecalho(t) {
    var th = t.querySelector('thead tr:last-child') || (function () { var r = t.rows[0]; return r && r.querySelector('th') ? r : null; })();
    return th ? [].slice.call(th.children) : [];
  }
  function linhasDados(t) {
    var out = [], tb = t.tBodies && t.tBodies.length ? [].slice.call(t.tBodies) : [t];
    tb.forEach(function (b) { [].slice.call(b.rows).forEach(function (r) { if (r.parentNode.tagName !== 'THEAD' && !r.querySelector('th[scope=col]') && r.cells.length) out.push(r); }); });
    return out;
  }
  function elegivel(t) {
    if (t.getAttribute('data-ws-tab') || t.closest('.ws-sem-export,[data-ws-sem-export],.ws-tab-bar,.no-print')) return false;
    var h = cabecalho(t); if (h.length < 2) return false;
    var ls = linhasDados(t); if (!ls.length) return false;
    if (ls.length === 1 && ls[0].cells.length === 1) return false;   // "nenhum registro"
    if (ls.length === 1 && ls[0].cells[0] && ls[0].cells[0].colSpan >= h.length) return false;
    var nIn = t.querySelectorAll('input[type=text],input[type=number],input[type=password],input[type=email],textarea,select').length;
    if (nIn > ls.length * 2 || (nIn >= ls.length && h.length <= 4)) return false;   // tabela de preenchimento (campo/valor), não de dados
    return true;
  }

  function colunasUteis(t, cab, linhas) {
    var uteis = [];
    cab.forEach(function (c, i) {
      var nome = txt(c);
      var soCaixa = !!c.querySelector('input[type=checkbox]') && nome === '';
      var acao = /^(a[cç][oõ]es?|op[cç][oõ]es|⋯|\.\.\.)$/i.test(nome);
      var vazioTodas = linhas.length > 0 && linhas.slice(0, 40).every(function (r) { var x = r.cells[i]; return !x || (txt(x) === '' && !x.querySelector('input:not([type=checkbox]):not([type=hidden]),img[alt]:not([alt=""])')); });
      var soBotoes = linhas.length > 0 && linhas.slice(0, 40).every(function (r) { var x = r.cells[i]; return !x || (x.querySelector('button,a.ws-btn,input[type=checkbox]') && txt(x).length <= 3); });
      if (soCaixa || acao || (nome === '' && (vazioTodas || soBotoes))) return;
      uteis.push(i);
    });
    return uteis;
  }
  function valorCelula(c) {
    if (!c) return '';
    var i = c.querySelector('input:not([type=checkbox]):not([type=hidden]),select,textarea');
    if (i && txt(c) === '') return i.tagName === 'SELECT' ? ((i.options[i.selectedIndex] || {}).text || '') : i.value;
    return txt(c);
  }
  function selecionada(r) {
    if (r.classList.contains('ws-linha-sel')) return true;
    var cx = r.querySelector('input[type=checkbox]'); return !!(cx && cx.checked && !cx.closest('.ws-tab-bar'));
  }
  /* Matriz [cabeçalhos, linhas…] do que está na tela (e só o selecionado, se houver seleção). */
  function matriz(t) {
    var cab = cabecalho(t), todas = linhasDados(t).filter(function (r) { return visivel(r); });
    var uteis = colunasUteis(t, cab, todas);
    var sel = todas.filter(selecionada), usar = sel.length ? sel : todas;
    var m = [uteis.map(function (i) { return txt(cab[i]); })];
    usar.forEach(function (r) { m.push(uteis.map(function (i) { return valorCelula(r.cells[i]); })); });
    return { dados: m, selecionadas: sel.length, total: todas.length };
  }

  function titulo(t) {
    var el = t, h = '';
    for (var k = 0; k < 6 && el && !h; k++) {
      var p = el.previousElementSibling;
      while (p && !h) { if (/^H[1-4]$/.test(p.tagName)) h = txt(p); else { var q = p.querySelector && p.querySelector('h1,h2,h3,h4'); if (q && !p.contains(t)) h = txt(q); } p = p.previousElementSibling; }
      el = el.parentElement;
    }
    if (!h) { var g = document.querySelector('main h1,main h2,h1,h2'); h = g ? txt(g) : ''; }
    var pg = (document.title || '').replace(/^\s*(WellSystem|Wellnet)[^A-Za-zÀ-ú0-9]+/i, '').trim();
    h = h.replace(/\s+/g, ' ').slice(0, 90);
    return { pagina: pg || 'WellSystem', secao: h };
  }
  function slug(s) { return (s || 'tabela').normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'tabela' : 'tabela'; }

  function baixarCsv(t) {
    var r = matriz(t), tt = titulo(t);
    var csv = r.dados.map(function (l) { return l.map(function (v) { v = String(v).replace(/\r?\n/g, ' '); return /[";\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(';'); }).join('\r\n');
    var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = slug(tt.secao || tt.pagina) + '-' + hojeArq() + '.csv';
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  function imprimir(t) {
    var r = matriz(t), tt = titulo(t), cols = r.dados[0].length;
    var corpo = '<table><thead><tr>' + r.dados[0].map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr></thead><tbody>'
      + r.dados.slice(1).map(function (l) { return '<tr>' + l.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>';
    var nome = (document.querySelector('.ws-rodape-marca b') ? 'WellSystem' : (window.WS_SISTEMA || 'WellSystem'));
    var html = '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>' + esc(tt.secao || tt.pagina) + '</title><style>'
      + '@page{margin:12mm;size:' + (cols > 8 ? 'landscape' : 'portrait') + '}*{box-sizing:border-box}body{font:11px/1.35 "Segoe UI",Arial,sans-serif;color:#111;margin:0}'
      + 'h1{font-size:15px;margin:0 0 2px}.sub{color:#555;font-size:10.5px;margin:0 0 10px}table{width:100%;border-collapse:collapse}'
      + 'th{background:#e9eef6;text-align:left}th,td{border:1px solid #b9c4d6;padding:3px 5px;vertical-align:top;word-break:break-word}tr{page-break-inside:avoid}thead{display:table-header-group}'
      + '</style></head><body><h1>' + esc(tt.secao || tt.pagina) + '</h1><p class="sub">' + esc(nome) + ' · ' + esc(tt.pagina) + ' · ' + (r.dados.length - 1) + ' linha(s)' + (r.selecionadas ? ' (selecionadas)' : '') + ' · impresso em ' + agora() + '</p>' + corpo + '</body></html>';
    var f = document.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
    document.body.appendChild(f);
    var d = f.contentWindow.document; d.open(); d.write(html); d.close();
    var feito = false; function go() { if (feito) return; feito = true; try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { window.print(); } setTimeout(function () { f.remove(); }, 60000); }
    f.onload = go; setTimeout(go, 400);
  }

  window.wsTabelaImprimir = function (t) { imprimir(t); };   /* telas com botão Imprimir próprio (OLT) chamam a mesma impressão */
  function jaTem(t) {
    /* o "card" da tabela: sobe até 3 níveis procurando botão/link próprio de CSV ou Imprimir FORA da tabela */
    var el = t.parentElement, csv = false, prt = false;
    for (var k = 0; k < 3 && el && el !== document.body; k++, el = el.parentElement) {
      [].slice.call(el.querySelectorAll('button,a,input[type=button],input[type=submit]')).forEach(function (b) {
        if (t.contains(b) || b.closest('.ws-tab-bar') || b.closest('.ws-rodape,.ws-top-wrap,header,nav')) return;
        var s = (b.innerText || b.value || b.title || '').trim(); if (!s || s.length > 40) return;
        if (RE_CSV.test(s)) csv = true; if (RE_PRINT.test(s)) prt = true;
      });
    }
    return { csv: csv, print: prt };
  }

  var CSS = '.ws-tab-bar{display:flex;gap:6px;align-items:center;justify-content:flex-end;flex-wrap:wrap;margin:4px 0 6px;font:12px/1.2 system-ui,Segoe UI,sans-serif}'
    + '.ws-tab-bar button{font:inherit;padding:4px 10px;border:1px solid var(--border,#c7d0de);border-radius:8px;background:transparent;color:var(--text,inherit);cursor:pointer;font-weight:600}'
    + '.ws-tab-bar button:hover{border-color:var(--brand,#2563eb);color:var(--brand,#2563eb)}.ws-tab-bar .ws-tab-sel{color:var(--muted,#6b7a93);font-weight:600}'
    + 'tr.ws-linha-sel>td,tr.ws-linha-sel>th{background:color-mix(in srgb,var(--brand,#2563eb) 14%,transparent)!important}@media print{.ws-tab-bar{display:none!important}}';

  function montar(t) {
    if (!elegivel(t)) return;
    var tem = jaTem(t); if (tem.csv && tem.print) { t.setAttribute('data-ws-tab', 'x'); return; }
    t.setAttribute('data-ws-tab', '1');
    var bar = document.createElement('div'); bar.className = 'ws-tab-bar no-print';
    var sel = document.createElement('span'); sel.className = 'ws-tab-sel'; bar.appendChild(sel);
    var lim = document.createElement('button'); lim.type = 'button'; lim.textContent = 'limpar seleção'; lim.style.display = 'none'; bar.appendChild(lim);
    function atualiza() { var n = linhasDados(t).filter(selecionada).length; sel.textContent = n ? n + ' selecionada(s)' : ''; lim.style.display = n ? '' : 'none'; }
    lim.onclick = function () { linhasDados(t).forEach(function (r) { r.classList.remove('ws-linha-sel'); var c = r.querySelector('input[type=checkbox]'); if (c) { c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); } }); atualiza(); };
    if (!tem.csv) { var b1 = document.createElement('button'); b1.type = 'button'; b1.textContent = '⬇ Exportar CSV'; b1.title = 'Baixa o que está na tela (só as linhas selecionadas, se houver)'; b1.onclick = function () { baixarCsv(t); }; bar.appendChild(b1); }
    if (!tem.print) { var b2 = document.createElement('button'); b2.type = 'button'; b2.textContent = '🖨 Imprimir'; b2.title = 'Imprime o que está na tela (só as linhas selecionadas, se houver). Ctrl+clique numa linha seleciona.'; b2.onclick = function () { imprimir(t); }; bar.appendChild(b2); }
    t.addEventListener('click', function (e) {
      if (!(e.ctrlKey || e.metaKey)) { return; }
      var tr = e.target.closest && e.target.closest('tr'); if (!tr || !t.contains(tr) || tr.parentNode.tagName === 'THEAD') return;
      e.preventDefault(); tr.classList.toggle('ws-linha-sel'); atualiza();
    }, true);
    t.addEventListener('change', function (e) { if (e.target && e.target.type === 'checkbox') atualiza(); });
    var ref = t, p = t.parentElement;
    if (p && p !== document.body && p.children.length <= 2 && /(auto|scroll)/.test(getComputedStyle(p).overflowX) && p.parentElement) ref = p;   // fica acima do contêiner rolável
    ref.parentNode.insertBefore(bar, ref);
  }

  function varrer() { [].slice.call(document.querySelectorAll('table')).forEach(montar); }
  function iniciar() {
    var s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
    varrer();
    var tmr = null, obs = new MutationObserver(function (muts) {
      if (muts.every(function (m) { return [].slice.call(m.addedNodes).every(function (n) { return n.nodeType !== 1 || (n.classList && n.classList.contains('ws-tab-bar')); }); })) return;
      clearTimeout(tmr); tmr = setTimeout(varrer, 500);
    });
    obs.observe(document.body, { childList: true, subtree: true });
    window.wsTabelas = { varrer: varrer, csv: baixarCsv, imprimir: imprimir };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
