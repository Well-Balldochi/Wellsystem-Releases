<?php
/**
 * WellSystem — HORA CERTA e LOGS DESTE SERVIDOR PARA O SERVIDOR DE LOGS (31/10/2026).
 *
 * Roda como ROOT, a cada minuto, chamado por atualizar_run.php (a web só grava a configuração em cache/logs_servidor.json).
 *   1) HORA: o servidor precisa ter a hora certa — sem ela o registro de conexão perde valor. Garante o chrony (instala se faltar) com as
 *      fontes da NTP.br; se o servidor de logs estiver configurado e "usar a hora dele" ligado, ele entra como UMA fonte a mais (nunca a única).
 *   2) LOGS: com o envio ligado, o rsyslog manda ao servidor de logs (TCP, com fila em disco: se o destino cair, nada se perde) o log do
 *      FreeRADIUS, os acessos ao servidor (auth) e os REGISTROS DE CONEXÃO (3).
 *   3) CONEXÕES: cada sessão do radacct vira uma linha "CONEXAO INICIO/FIM login= ip= nas= ..." no syslog (facility local6). O radacct é o banco
 *      do RADIUS que autentica — o do próprio WellSystem ou, ao lado do MK-Auth, o mkradius — então o MK-Auth entra pelo mesmo caminho.
 * Só aplica quando a configuração MUDA (hash em cache/logs_envio.hash) e nunca derruba nada: valida o rsyslog antes de reiniciar.
 */
if (!defined('WS_CACHE')) require_once __DIR__ . '/config.php';

function ws_logs_envio_cfg(): array {
    $c = json_decode((string)@file_get_contents(WS_CACHE . '/logs_servidor.json'), true);
    $e = is_array($c) && is_array($c['envio'] ?? null) ? $c['envio'] : [];
    $proto = strtolower((string)($e['proto'] ?? 'tcp'));
    return ['ativo' => !empty($e['ativo']), 'host' => trim((string)($e['host'] ?? '')),
            'porta' => max(1, min(65535, (int)($e['porta'] ?? 514))), 'proto' => in_array($proto, ['tcp', 'udp'], true) ? $proto : 'tcp',
            'hora' => !array_key_exists('hora', $e) || !empty($e['hora'])];
}
function ws_logs_envio_host_ok(string $h): bool { return $h !== '' && strlen($h) <= 120 && (bool)preg_match('/^[A-Za-z0-9]([A-Za-z0-9.\-]*[A-Za-z0-9])?$/', $h); }
function ws_logs_envio_salvar(array $e): bool {
    $f = WS_CACHE . '/logs_servidor.json';
    $c = json_decode((string)@file_get_contents($f), true); $c = is_array($c) ? $c : [];
    $c['envio'] = $e;
    $ok = @file_put_contents($f, json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    @chmod($f, 0660);
    @unlink(WS_CACHE . '/logs_envio.hash');   // a rotina do root reaplica em até 1 minuto
    return $ok;
}
function ws_logs_envio_estado(): array {
    $e = json_decode((string)@file_get_contents(WS_CACHE . '/logs_envio_estado.json'), true);
    return is_array($e) ? $e : [];
}
function ws_logs_envio_estado_gravar(array $novo): void {
    $e = ws_logs_envio_estado() + [];
    $e = array_merge($e, $novo, ['em' => date('Y-m-d H:i:s')]);
    @file_put_contents(WS_CACHE . '/logs_envio_estado.json', json_encode($e, JSON_UNESCAPED_UNICODE), LOCK_EX); @chmod(WS_CACHE . '/logs_envio_estado.json', 0664);
}
function ws_logs_envio_sh(string $cmd, ?int &$rc = null): string { $o = []; exec($cmd . ' 2>&1', $o, $rc); return trim(implode("\n", $o)); }

/** Chrony instalado, ativo e com as fontes da NTP.br (+ servidor de logs, se pedido). Idempotente. */
function ws_logs_hora_garantir(array $cfg): array {
    $tem = trim((string)@shell_exec('command -v chronyd 2>/dev/null')) !== '';
    if (!$tem) {
        $tent = WS_CACHE . '/logs_envio.hora_tentativa';
        if (is_file($tent) && time() - (int)@filemtime($tent) < 6 * 3600) return ['ok' => false, 'msg' => 'chrony ainda não instalado (nova tentativa em algumas horas)'];
        @touch($tent);
        ws_logs_envio_sh('DEBIAN_FRONTEND=noninteractive apt-get install -y -qq chrony', $rc);
        $tem = trim((string)@shell_exec('command -v chronyd 2>/dev/null')) !== '';
        if (!$tem) return ['ok' => false, 'msg' => 'não consegui instalar o chrony (servidor sem internet?)'];
    }
    $dir = is_dir('/etc/chrony/sources.d') && preg_match('/^\s*sourcedir\s+\/etc\/chrony\/sources\.d/m', (string)@file_get_contents('/etc/chrony/chrony.conf')) ? '/etc/chrony/sources.d' : '';
    $linhas = ["# WellSystem — gerado por logs_envio_lib.php (não editar à mão)", 'server a.st1.ntp.br iburst', 'server b.st1.ntp.br iburst', 'server c.st1.ntp.br iburst'];
    if ($cfg['ativo'] && $cfg['hora'] && ws_logs_envio_host_ok($cfg['host'])) $linhas[] = 'server ' . $cfg['host'] . ' iburst';
    $conteudo = implode("\n", $linhas) . "\n";
    if ($dir !== '') $alvo = $dir . '/wellsystem-hora.sources';
    else { @mkdir('/etc/chrony/conf.d', 0755, true); $alvo = '/etc/chrony/conf.d/wellsystem-hora.conf'; }
    $mudou = (string)@file_get_contents($alvo) !== $conteudo;
    if ($mudou) @file_put_contents($alvo, $conteudo);
    ws_logs_envio_sh('systemctl enable chrony >/dev/null 2>&1 || systemctl enable chronyd >/dev/null 2>&1');
    $ativo = ws_logs_envio_sh('systemctl is-active chrony 2>/dev/null || systemctl is-active chronyd 2>/dev/null') === 'active';
    if (!$ativo || ($mudou && $dir === '')) ws_logs_envio_sh('systemctl restart chrony 2>/dev/null || systemctl restart chronyd 2>/dev/null');
    elseif ($mudou) ws_logs_envio_sh('chronyc reload sources');
    return ['ok' => true, 'msg' => 'hora: chrony ativo'];
}

/** Conteúdo do /etc/rsyslog.d/90-wellsystem-logs.conf para o destino configurado. */
function ws_logs_envio_rsyslog_conf(array $cfg): string {
    $c = ["# WellSystem — gerado por logs_envio_lib.php (não editar à mão): envia ao servidor de logs.",
          'ruleset(name="ws_envio_logs") {',
          '  action(type="omfwd" target="' . $cfg['host'] . '" port="' . $cfg['porta'] . '" protocol="' . $cfg['proto'] . '"',
          '    action.resumeRetryCount="-1" action.resumeInterval="30" queue.type="LinkedList" queue.filename="ws_envio_logs"',
          '    queue.maxdiskspace="268435456" queue.size="50000" queue.saveonshutdown="on")',
          '}',
          'if prifilt("local6.*") then { call ws_envio_logs }',
          'if prifilt("auth,authpriv.*") then { call ws_envio_logs }'];
    if (is_file('/var/log/freeradius/radius.log')) {
        array_splice($c, 1, 0, ['module(load="imfile" PollingInterval="5")']);
        $c[] = 'input(type="imfile" File="/var/log/freeradius/radius.log" Tag="freeradius:" Severity="info" Facility="local5" ruleset="ws_envio_logs" addMetadata="off" freshStartTail="on")';
    }
    return implode("\n", $c) . "\n";
}

/** Liga/desliga o envio do rsyslog conforme a configuração. */
function ws_logs_envio_aplicar(array $cfg): array {
    $arq = '/etc/rsyslog.d/90-wellsystem-logs.conf';
    if (!$cfg['ativo']) {
        if (is_file($arq)) { @unlink($arq); if (trim((string)@shell_exec('command -v rsyslogd 2>/dev/null')) !== '') ws_logs_envio_sh('systemctl restart rsyslog'); return ['ok' => true, 'msg' => 'Envio desligado.']; }
        return ['ok' => true, 'msg' => 'Envio desligado.'];
    }
    if (!ws_logs_envio_host_ok($cfg['host'])) return ['ok' => false, 'msg' => 'Endereço do servidor de logs inválido ou vazio.'];
    if (trim((string)@shell_exec('command -v rsyslogd 2>/dev/null')) === '') {
        ws_logs_envio_sh('DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rsyslog', $rc);
        if (trim((string)@shell_exec('command -v rsyslogd 2>/dev/null')) === '') return ['ok' => false, 'msg' => 'Não consegui instalar o rsyslog (servidor sem internet?).'];
    }
    $antes = is_file($arq) ? (string)file_get_contents($arq) : null;
    @file_put_contents($arq, ws_logs_envio_rsyslog_conf($cfg));
    $v = ws_logs_envio_sh('rsyslogd -N1', $rc);
    if ($rc !== 0) {   // configuração inválida: volta ao que estava, nada é reiniciado com erro
        if ($antes === null) @unlink($arq); else @file_put_contents($arq, $antes);
        return ['ok' => false, 'msg' => 'Configuração recusada pelo rsyslog: ' . mb_substr($v, -200)];
    }
    ws_logs_envio_sh('systemctl enable rsyslog >/dev/null 2>&1; systemctl restart rsyslog', $rc);
    if ($rc !== 0) return ['ok' => false, 'msg' => 'rsyslog não reiniciou.'];
    return ['ok' => true, 'msg' => 'Enviando ao servidor de logs ' . $cfg['host'] . ':' . $cfg['porta'] . ' (' . strtoupper($cfg['proto']) . ').'];
}

/** Banco do RADIUS que autentica (o do WellSystem ou, ao lado do MK-Auth, o mkradius). */
function ws_logs_rad_db(): PDO {
    $db = ws_db();
    if (is_file(__DIR__ . '/mkauth_bridge.php')) { require_once __DIR__ . '/mkauth_bridge.php'; if (function_exists('ws_mk_presente') && ws_mk_presente()) return ws_mk_db(); }
    return $db;
}
function ws_logs_linha(array $a): string { $o = []; foreach ($a as $k => $v) { $v = trim(str_replace(["\r", "\n", '"'], ' ', (string)$v)); if ($v === '') $v = '-'; $o[] = $k . '=' . (strpbrk($v, ' ') ? '"' . $v . '"' : $v); } return implode(' ', $o); }

/** FOTO DAS SESSÕES ABERTAS (31/10/2026): uma linha "CONEXAO ABERTA" para cada sessão que está conectada AGORA, com o horário REAL de início (inicio=)
 *  e a última atualização do concentrador (atualizada=). A linha do syslog traz a hora em que foi registrada; o início verdadeiro é o campo inicio=.
 *  Sem isto, quem está conectado há dias nunca apareceria no servidor de logs (INICIO só sai quando a sessão COMEÇA). Motivos: ativacao | diario | pedido. */
function ws_logs_conexao_abertas(string $motivo): int {
    $rad = ws_logs_rad_db(); $n = 0;
    $q = $rad->query('SELECT radacctid, acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime, acctupdatetime FROM radacct WHERE acctstoptime IS NULL ORDER BY radacctid LIMIT 100000');
    openlog('wellsystem-conexao', LOG_PID, LOG_LOCAL6);
    while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
        syslog(LOG_INFO, 'CONEXAO ABERTA ' . ws_logs_linha(['motivo' => $motivo, 'login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'],
            'sessao' => $r['acctsessionid'], 'inicio' => $r['acctstarttime'], 'atualizada' => $r['acctupdatetime']]));
        $n++;
    }
    closelog();
    return $n;
}

/** Sessões novas (INICIO) e encerradas (FIM) do radacct viram linhas de syslog. Primeira execução não despeja o histórico. */
function ws_logs_conexao_emitir(): int {
    $cf = WS_CACHE . '/logs_conexao.cursor.json'; $cur = json_decode((string)@file_get_contents($cf), true); $rad = ws_logs_rad_db();
    $agora = (string)$rad->query('SELECT NOW()')->fetchColumn();
    if (!is_array($cur) || !isset($cur['id_ini'])) {
        $max = (int)$rad->query('SELECT COALESCE(MAX(radacctid),0) FROM radacct')->fetchColumn();
        @file_put_contents($cf, json_encode(['id_ini' => $max, 'fim_ts' => $agora, 'fim_ids' => []]), LOCK_EX); @chmod($cf, 0664);
        return 0;
    }
    $n = 0; openlog('wellsystem-conexao', LOG_PID, LOG_LOCAL6);
    $q = $rad->prepare('SELECT radacctid, acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime FROM radacct WHERE radacctid > ? ORDER BY radacctid LIMIT 1000');
    $q->execute([(int)$cur['id_ini']]);
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        syslog(LOG_INFO, 'CONEXAO INICIO ' . ws_logs_linha(['login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'], 'sessao' => $r['acctsessionid'], 'inicio' => $r['acctstarttime']]));
        $cur['id_ini'] = (int)$r['radacctid']; $n++;
    }
    $vistos = array_map('intval', (array)($cur['fim_ids'] ?? []));
    $q = $rad->prepare('SELECT radacctid, acctsessionid, username, framedipaddress, nasipaddress, callingstationid, acctstarttime, acctstoptime, acctterminatecause, acctinputoctets, acctoutputoctets
                          FROM radacct WHERE acctstoptime >= ? AND acctstoptime <= NOW() ORDER BY acctstoptime, radacctid LIMIT 1000');
    $q->execute([(string)$cur['fim_ts']]);
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $id = (int)$r['radacctid'];
        if ($r['acctstoptime'] === $cur['fim_ts'] && in_array($id, $vistos, true)) continue;
        syslog(LOG_INFO, 'CONEXAO FIM ' . ws_logs_linha(['login' => $r['username'], 'ip' => $r['framedipaddress'], 'nas' => $r['nasipaddress'], 'mac' => $r['callingstationid'], 'sessao' => $r['acctsessionid'],
            'inicio' => $r['acctstarttime'], 'fim' => $r['acctstoptime'], 'causa' => $r['acctterminatecause'], 'subiu' => $r['acctinputoctets'], 'desceu' => $r['acctoutputoctets']]));
        if ($r['acctstoptime'] !== $cur['fim_ts']) { $cur['fim_ts'] = $r['acctstoptime']; $vistos = []; }
        $vistos[] = $id; $n++;
    }
    $cur['fim_ids'] = array_slice($vistos, -200);
    closelog();
    @file_put_contents($cf, json_encode($cur), LOCK_EX); @chmod($cf, 0664);
    return $n;
}

/** PRAZO LEGAL (01/11/2026): registro de conexão só pelo prazo da lei — Marco Civil da Internet (Lei 12.965/2014, art. 13): 1 ano. Passou do prazo, o mais antigo sai
 *  para dar lugar ao novo. Só apaga sessão JÁ ENCERRADA há mais de 1 ano (sessão aberta nunca) e tentativas de autenticação antigas. 1x/dia depois das 03:10 ou a pedido da Manutenção. */
if (!defined('WS_LOGS_RETENCAO_DIAS')) define('WS_LOGS_RETENCAO_DIAS', 396);
function ws_logs_retencao(): array {
    $lim = date('Y-m-d H:i:s', strtotime('-' . WS_LOGS_RETENCAO_DIAS . ' days')); $r = ['radacct' => 0, 'radpostauth' => 0, 'arquivos' => 0, 'erro' => ''];
    try {
        $rad = ws_logs_rad_db();
        foreach (['radacct' => 'acctstoptime IS NOT NULL AND acctstoptime < ?', 'radpostauth' => 'authdate < ?'] as $tab => $cond) {
            try { for ($i = 0; $i < 40; $i++) { $st = $rad->prepare("DELETE FROM $tab WHERE $cond LIMIT 5000"); $st->execute([$lim]); $n = $st->rowCount(); $r[$tab] += $n; if ($n < 5000) break; } }
            catch (Throwable $e) { $r['erro'] .= $tab . ': ' . mb_substr($e->getMessage(), 0, 80) . ' '; }
        }
    } catch (Throwable $e) { $r['erro'] .= mb_substr($e->getMessage(), 0, 100); }
    // CGNAT: o histórico de sessões importado (ws_cgnat_hist) também fica só 1 ano, trocando as mais velhas sozinho.
    try { require_once __DIR__ . '/cgnat_lib.php'; $dbc = ws_db(); ws_cgnat_hist_sincronizar($dbc); $r['cgnat_hist'] = ws_cgnat_hist_retencao($dbc, WS_LOGS_RETENCAO_DIAS); $r['cgnat_consultas'] = ws_cgnat_consulta_retencao($dbc, WS_LOGS_RETENCAO_DIAS); }
    catch (Throwable $e) { $r['erro'] .= 'cgnat_hist: ' . mb_substr($e->getMessage(), 0, 80) . ' '; }
    $dir = '/var/log/freeradius/radacct';
    if (is_dir($dir)) { $o = []; exec('find ' . escapeshellarg($dir) . ' -type f -mtime +' . (int)WS_LOGS_RETENCAO_DIAS . ' -print -delete 2>/dev/null', $o); $r['arquivos'] = count($o); }
    $r += ['prazo' => WS_LOGS_RETENCAO_DIAS, 'dia' => date('Y-m-d'), 'em' => date('Y-m-d H:i:s')];
    @file_put_contents(WS_CACHE . '/logs_retencao.json', json_encode($r), LOCK_EX); @chmod(WS_CACHE . '/logs_retencao.json', 0664);
    if (function_exists('ws_atu_log')) ws_atu_log('Retenção legal (1 ano): apagou ' . $r['radacct'] . ' sessão(ões), ' . ($r['cgnat_hist'] ?? 0) . ' do histórico CGNAT, ' . $r['radpostauth'] . ' tentativa(s), ' . $r['arquivos'] . ' arquivo(s)' . ($r['erro'] ? ' — erro: ' . $r['erro'] : ''));
    return $r;
}

/** Chamada por atualizar_run.php (root, 1/min). Nunca lança erro para quem chamou. */
function ws_logs_envio_rodar(): void {
    try {
        if (function_exists('posix_geteuid') && posix_geteuid() !== 0) return;
        putenv('PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin');   // o cron só traz /usr/bin:/bin — sem isso não acha rsyslogd/chronyd
        $cfg = ws_logs_envio_cfg();
        $arqHash = WS_CACHE . '/logs_envio.hash';
        $guard = json_decode((string)@file_get_contents($arqHash), true); $guard = is_array($guard) ? $guard : [];
        $hh = md5(json_encode([$cfg['ativo'], $cfg['hora'], $cfg['host']]) . '|h1');
        $he = md5(json_encode($cfg) . '|' . (is_file('/var/log/freeradius/radius.log') ? 'r' : '') . '|e3');
        $nov = [];
        if (($guard['hora'] ?? '') !== $hh) {
            $h = ws_logs_hora_garantir($cfg);
            $nov += ['hora_ok' => $h['ok'], 'hora_msg' => $h['msg']];
            if ($h['ok']) $guard['hora'] = $hh;
            if (function_exists('ws_atu_log')) ws_atu_log('Hora: ' . $h['msg']);
        }
        if (($guard['envio'] ?? '') !== $he) {
            $r = ws_logs_envio_aplicar($cfg);
            $nov += ['envio_ok' => $r['ok'], 'envio_msg' => $r['msg']];
            if ($r['ok']) $guard['envio'] = $he;
            if (function_exists('ws_atu_log')) ws_atu_log('Logs: ' . $r['msg']);
        }
        if ($nov) { ws_logs_envio_estado_gravar($nov); @file_put_contents($arqHash, json_encode($guard), LOCK_EX); @chmod($arqHash, 0664); }
        // teste pedido na tela: uma linha com o código, que o painel deve mostrar no servidor de logs
        $pt = WS_CACHE . '/logs_envio_teste.pedido';
        if (is_file($pt)) {
            $p = json_decode((string)@file_get_contents($pt), true); @unlink($pt);
            $cod = preg_replace('/[^A-Za-z0-9\-]/', '', (string)($p['codigo'] ?? ''));
            if ($cod !== '' && time() - (int)($p['em'] ?? 0) < 600) { openlog('wellsystem-teste', LOG_PID, LOG_LOCAL6); syslog(LOG_INFO, 'TESTE-ENVIO ' . $cod); closelog(); }
        }
        if ($cfg['ativo']) {
            $n = ws_logs_conexao_emitir(); if ($n) ws_logs_envio_estado_gravar(['ultimo_envio_conexoes' => date('Y-m-d H:i:s'), 'conexoes_ultimo_lote' => $n]);
            // foto das sessões abertas: na ativação, todo dia depois das 00:05 e quando pedida na tela
            $sf = WS_CACHE . '/logs_conexao.snapshot.json'; $sn = json_decode((string)@file_get_contents($sf), true); $sn = is_array($sn) ? $sn : [];
            $ped = WS_CACHE . '/logs_snapshot.pedido'; $motivo = '';
            if (is_file($ped)) { $motivo = 'pedido'; @unlink($ped); }
            elseif (empty($sn['ultimo'])) $motivo = 'ativacao';
            elseif (($sn['dia'] ?? '') !== date('Y-m-d') && date('H:i') >= '00:05') $motivo = 'diario';
            if ($motivo !== '') {
                $qt = ws_logs_conexao_abertas($motivo);
                @file_put_contents($sf, json_encode(['desde' => (string)($sn['desde'] ?? date('Y-m-d')), 'dia' => date('Y-m-d'), 'ultimo' => date('Y-m-d H:i:s'), 'motivo' => $motivo, 'n' => $qt]), LOCK_EX); @chmod($sf, 0664);
                ws_logs_envio_estado_gravar(['snapshot_em' => date('Y-m-d H:i:s'), 'snapshot_n' => $qt, 'snapshot_motivo' => $motivo]);
            }
        }
        // prazo legal: 1x/dia depois das 03:10 (ou a pedido da Manutenção)
        $rp = WS_CACHE . '/logs_retencao.pedido'; $rj = json_decode((string)@file_get_contents(WS_CACHE . '/logs_retencao.json'), true); $rj = is_array($rj) ? $rj : [];
        if (is_file($rp)) { @unlink($rp); ws_logs_retencao(); }
        elseif (($rj['dia'] ?? '') !== date('Y-m-d') && date('H:i') >= '03:10') ws_logs_retencao();
    } catch (Throwable $e) { if (function_exists('ws_atu_log')) ws_atu_log('Logs/hora: erro ' . mb_substr($e->getMessage(), 0, 150)); }
}

/** Quebra uma linha do servidor de logs em campos (tela e CSV). Mesmo critério do painel do servidor de logs. */
function ws_logs_parse_linha(string $l): array {
    $p = explode(' ', rtrim($l), 3); $dt = str_replace('T', ' ', substr($p[0] ?? '', 0, 19)); $resto = $p[2] ?? '';
    $tipo = 'Outro'; $acao = '';
    if (preg_match('/CONEXAO (INICIO|FIM|ABERTA) /', $resto, $m)) { $tipo = 'Conexão'; $acao = ['INICIO' => 'Início', 'FIM' => 'Fim', 'ABERTA' => 'Já aberta'][$m[1]]; }
    elseif (stripos($resto, 'freeradius') !== false) $tipo = 'RADIUS';
    elseif (stripos($resto, 'sshd') !== false) $tipo = 'SSH';
    elseif (preg_match('/NAT \(|srcnat|dstnat|CGNAT|\bnat=\d+\.\d+\.\d+\.\d+:\d+/', $resto)) $tipo = 'NAT';
    $kv = []; if ($tipo === 'Conexão') { preg_match_all('/(\w+)=("[^"]*"|\S+)/', $resto, $mm, PREG_SET_ORDER); foreach ($mm as $x) $kv[$x[1]] = trim($x[2], '"'); }
    if ($tipo === 'NAT') {   // MikroTik: "..., 10.0.0.2:51234->8.8.8.8:53, NAT (10.0.0.2:51234->200.1.1.1:40001)->8.8.8.8:53"
        if (preg_match('/NAT \((\d+\.\d+\.\d+\.\d+):(\d+)->(\d+\.\d+\.\d+\.\d+):(\d+)\)->(\d+\.\d+\.\d+\.\d+):(\d+)/', $resto, $n)) $kv = ['ip' => $n[1], 'porta' => $n[2], 'publico' => $n[3] . ':' . $n[4], 'destino' => $n[5] . ':' . $n[6]];
        elseif (preg_match('/(\d+\.\d+\.\d+\.\d+):(\d+)->(\d+\.\d+\.\d+\.\d+):(\d+)/', $resto, $n)) $kv = ['ip' => $n[1], 'porta' => $n[2], 'destino' => $n[3] . ':' . $n[4]];
        // Formato chave=valor de equipamento CGNAT: "src=IP:porta dst=IP:porta nat=IP:porta user=assinante"
        if (!$kv && preg_match('/\bsrc=(\d+\.\d+\.\d+\.\d+):(\d+)/', $resto, $a) && preg_match('/\bnat=(\d+\.\d+\.\d+\.\d+):(\d+)/', $resto, $b)) {
            $c = []; preg_match('/\bdst=(\d+\.\d+\.\d+\.\d+):(\d+)/', $resto, $c); $u = []; preg_match('/\buser=("[^"]*"|\S+)/', $resto, $u);
            $kv = ['ip' => $a[1], 'porta' => $a[2], 'publico' => $b[1] . ':' . $b[2], 'destino' => $c ? $c[1] . ':' . $c[2] : '', 'usuario' => $u ? trim($u[1], '"') : ''];
        }
    }
    return ['dt' => $dt, 'origem' => $p[1] ?? '', 'tipo' => $tipo, 'acao' => $acao, 'kv' => $kv, 'msg' => $resto];
}
/** Data/hora no formato do Brasil (dia/mês/ano). Aceita "AAAA-MM-DD HH:MM:SS" ou ISO; outro texto volta como veio. */
function ws_logs_br($s): string {
    $s = (string)$s; if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?/', $s, $m)) return $s;
    return "$m[3]/$m[2]/$m[1]" . (isset($m[4]) ? ' ' . $m[4] : '');
}
function ws_logs_dur($ini, $fim): string {
    $a = strtotime((string)$ini); $b = strtotime((string)$fim); if (!$a || !$b || $b < $a) return '';
    $d = $b - $a; return ($d >= 86400 ? intdiv($d, 86400) . 'd ' : '') . sprintf('%02dh%02dm', intdiv($d % 86400, 3600), intdiv($d % 3600, 60));
}
/** Com horário informado: fica a linha cujo horário cai na janela OU a sessão (início..fim) que cobre a janela — igual ao painel do servidor de logs. */
function ws_logs_filtra_horario(array $linhas, int $ini, int $fim): array {
    $ps = []; $fimSes = [];
    foreach ($linhas as $x) { $p = ws_logs_parse_linha($x); $ps[] = [$x, $p]; $k = $p['kv'];
        if ($p['tipo'] === 'Conexão' && $p['acao'] === 'Fim' && !empty($k['sessao']) && !empty($k['fim'])) $fimSes[$k['sessao']] = strtotime($k['fim']); }
    $out = [];
    foreach ($ps as [$x, $p]) {
        $t = strtotime($p['dt']);
        if ($t !== false && $t >= $ini && $t <= $fim) { $out[] = $x; continue; }
        if ($p['tipo'] !== 'Conexão') continue;
        $k = $p['kv']; $s = !empty($k['inicio']) ? strtotime($k['inicio']) : false; if (!$s) continue;
        $e = ($p['acao'] === 'Fim' && !empty($k['fim'])) ? strtotime($k['fim']) : ($fimSes[$k['sessao'] ?? ''] ?? PHP_INT_MAX);
        if ($e && $s <= $fim && $e >= $ini) $out[] = $x;
    }
    return $out;
}
/** Busca por CLIENTE: fica só o que é do cliente (conexão com login exatamente igual a um dos logins dele; outras linhas que citam o login inteiro).
 *  O IP não prova nada sozinho: o CGNAT reaproveita o mesmo 100.71.x para clientes diferentes. */
function ws_logs_filtra_logins(array $linhas, array $logins): array {
    $logins = array_values(array_filter(array_map('strval', $logins), fn($l) => $l !== '')); $set = array_flip(array_map('strtolower', $logins)); $out = [];
    $re = $logins ? '/(?<![\w.\-])(' . implode('|', array_map(fn($l) => preg_quote($l, '/'), $logins)) . ')(?![\w.\-])/i' : null;
    foreach ($linhas as $x) { $p = ws_logs_parse_linha($x);
        if ($p['tipo'] === 'Conexão') { if (isset($set[strtolower($p['kv']['login'] ?? '')])) $out[] = $x; }
        elseif ($re && preg_match($re, $p['msg'])) $out[] = $x; }
    return $out;
}
/** IP entregue ao cliente (100.71.x) => [IP público do CGNAT], pela TABELA de CGNAT do WellSystem (versão que valia no fim do período).
 *  Não existe log de NAT por conexão: o CGNAT é fixo (IP público + faixa de portas por cliente). IP fora do CGNAT não aparece no mapa. */
function ws_logs_publicos(array $ips, string $ate): array {
    $map = [];
    $ips = array_values(array_unique(array_filter($ips, fn($i) => filter_var($i, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4))));
    if (!$ips) return $map;
    try {
        require_once __DIR__ . '/cgnat_lib.php'; $db = ws_db();
        $v = ws_cgnat_versao_em($db, (preg_match('/^\d{4}-\d{2}-\d{2}$/', $ate) ? $ate : date('Y-m-d')) . ' 23:59:59');
        if (!$v) return $map;
        foreach (array_slice($ips, 0, 300) as $ip) { $pub = ws_cgnat_publico($db, (int)$v['id'], (int)ip2long($ip)); if ($pub) $map[$ip] = [long2ip((int)$pub['ip_publico'])]; }
    } catch (Throwable $e) {}
    return $map;
}
/** login (minúsculo) => ['id','nome','status'] direto do banco do WellSystem. */
function ws_logs_nomes_login(array $logins): array {
    $logins = array_values(array_unique(array_filter(array_map('strtolower', $logins), fn($l) => $l !== '' && $l !== '-'))); $out = [];
    if (!$logins) return $out;
    try {
        $db = ws_db();
        foreach (array_chunk($logins, 200) as $lote) {
            $in = implode(',', array_fill(0, count($lote), '?'));
            $st = $db->prepare("SELECT c.id, c.nome, ct.status, ct.login_pppoe, ct.login_ipoe FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id = c.id WHERE LOWER(ct.login_pppoe) IN ($in) OR LOWER(ct.login_ipoe) IN ($in)");
            $st->execute(array_merge($lote, $lote));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) foreach (['login_pppoe', 'login_ipoe'] as $k) { $l = strtolower(trim((string)$r[$k])); if ($l !== '' && in_array($l, $lote, true) && !isset($out[$l])) $out[$l] = ['id' => (int)$r['id'], 'nome' => (string)$r['nome'], 'status' => (string)$r['status']]; }
        }
    } catch (Throwable $e) {}
    return $out;
}
function ws_logs_rotulo_cli(?array $d): string { return $d ? ($d['nome'] . ' (nº ' . (int)$d['id'] . ')' . (($d['status'] ?? '') === 'cancelado' ? ' — desativado' : '')) : ''; }
/**
 * FALHAS DE LOGIN PPPoE e IPoE (31/10/2026): lê as recusas do FreeRADIUS (radius.log atual, .1 e os .gz) entre dois dias e diz quem errou.
 * Linha: "Sat Oct 31 06:42:15 2026 : Auth: (N) Login incorrect (motivo): [login] (from client NAS port P cli MAC-ou-IP)" ou "Invalid user (...)".
 * Devolve as mais novas primeiro. Cada item: dt, login, tipo (PPPoE/IPoE/Não identificado), motivo (texto claro), cliente (nome ou ''), parece (nome provável
 * quando o login veio digitado com lixo, ex.: "~ljosefernande"), nas, origem (MAC ou IP de quem tentou), externo (true quando a origem é um IP de fora).
 */
function ws_logs_falhas_login(string $de, string $ate, int $limite = 3000, bool $comRobos = false): array {
    $arqs = []; $dir = '/var/log/freeradius';
    foreach (['radius.log', 'radius.log.1', 'radius.log.2.gz', 'radius.log.3.gz', 'radius.log.4.gz', 'radius.log.5.gz', 'radius.log.6.gz', 'radius.log.7.gz'] as $n) if (is_file("$dir/$n") && is_readable("$dir/$n")) $arqs[] = "$dir/$n";
    $ini = strtotime($de . ' 00:00:00'); $fim = strtotime($ate . ' 23:59:59'); $bruto = [];
    foreach ($arqs as $a) {
        $gz = substr($a, -3) === '.gz'; $h = $gz ? @gzopen($a, 'r') : @fopen($a, 'r'); if (!$h) continue;
        while (($l = $gz ? gzgets($h) : fgets($h)) !== false) {
            if (strpos($l, ' Auth: ') === false || (strpos($l, 'Login incorrect') === false && strpos($l, 'Invalid user') === false)) continue;
            if (!preg_match('/^\w{3} (\w{3} +\d+ [\d:]{8} \d{4}) : Auth: \(\d+\) (?:Login incorrect|Invalid user) \((.*?)\): \[(.*)\] \(from client (\S+) port \S+(?: cli (\S+))?\)/', $l, $m)) continue;
            $t = strtotime($m[1]); if (!$t || $t < $ini || $t > $fim) continue;
            if (!$comRobos && isset($m[5]) && filter_var($m[5], FILTER_VALIDATE_IP) !== false) continue;   // tentativa vinda de IP de fora = robô (só aparece se pedir)
            $bruto[] = ['t' => $t, 'motivo' => $m[2], 'login' => $m[3], 'nas' => $m[4], 'origem' => $m[5] ?? ''];
        }
        $gz ? gzclose($h) : fclose($h);
    }
    usort($bruto, function ($x, $y) { return $y['t'] <=> $x['t']; });
    $bruto = array_slice($bruto, 0, $limite);
    $conh = []; $todos = [];
    try {
        $db = ws_db();
        foreach ($db->query("SELECT c.nome, ct.login_pppoe lp, ct.login_ipoe li FROM ws_contrato ct JOIN ws_cliente c ON c.id = ct.cliente_id WHERE ct.status <> 'cancelado'")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            foreach (['lp' => 'PPPoE', 'li' => 'IPoE'] as $k => $tp) { $lg = strtolower(trim((string)$r[$k])); if ($lg === '') continue; $conh[$lg] = ['nome' => (string)$r['nome'], 'tipo' => $tp]; if (strlen($lg) >= 6) $todos[$lg] = $conh[$lg]; }
        }
    } catch (Throwable $e) {}
    $out = []; $cacheParece = [];
    foreach ($bruto as $b) {
        $lg = strtolower(trim($b['login'])); $c = $conh[$lg] ?? null; $parece = '';
        $ext = $b['origem'] !== '' && filter_var($b['origem'], FILTER_VALIDATE_IP) !== false;
        if (!$c && !$ext && strlen($lg) >= 6) {
            if (!isset($cacheParece[$lg])) { $cacheParece[$lg] = ''; foreach ($todos as $k => $v) if (strpos($lg, (string)$k) !== false) { $cacheParece[$lg] = $v['nome'] . ' (' . $k . ')'; break; } }
            $parece = $cacheParece[$lg];
        }
        if (stripos($b['motivo'], 'password is incorrect') !== false || stripos($b['motivo'], 'MS-CHAP2-Response is incorrect') !== false) $mot = 'Senha errada';
        elseif ($c) $mot = 'Login existe, mas o RADIUS não aceitou (senha errada ou cadastro sem senha)';
        else $mot = $ext ? 'Login não cadastrado — tentativa de fora (robô)' : 'Login não cadastrado (digitado errado)';
        $out[] = ['dt' => date('Y-m-d H:i:s', $b['t']), 'login' => $b['login'], 'tipo' => $c['tipo'] ?? 'Não identificado', 'motivo' => $mot, 'cliente' => $c['nome'] ?? '', 'parece' => $parece, 'nas' => $b['nas'], 'origem' => $b['origem'], 'externo' => $ext];
    }
    return $out;
}
