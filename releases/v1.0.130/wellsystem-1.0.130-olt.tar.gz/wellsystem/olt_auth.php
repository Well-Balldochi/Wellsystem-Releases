<?php
// =============================================================================
// WELLSYSTEM OLT — AUTENTICAÇÃO E NÍVEIS DE ACESSO
// -----------------------------------------------------------------------------
// PRIMEIRO ACESSO: não existindo usuários, o login aceita "root" + a SENHA DA OLT
// (a que está gravada em olt_conexao.json). Nesse momento o usuário root é criado
// definitivamente, com a mesma senha, e o atalho deixa de valer.
//
// NÍVEIS:
//   1 — Leitura:   vê tudo, não altera nada.
//   2 — Operação:  nível 1 + autorizar / bloquear / desbloquear / reiniciar ONU.
//                  NÃO edita apelidos, zonas, VLANs, perfis, notificações, conexão.
//   3 — Root:      acesso total, incluindo cadastro de usuários e backup.
//
// A checagem é feita NO SERVIDOR (olt_auth_exigir), em todo endpoint que altera
// algo. Esconder botão no JavaScript não protege nada — aqui é o que vale.
// =============================================================================

if (session_status() === PHP_SESSION_NONE) {
    session_name('WSOLTSESS');
    @session_start();
}

// Pastas de dados: a PERSISTENTE do addon (sobrevive ao reboot) + a temporária. Grava nas DUAS e lê a
// mais nova. Assim o cadastro de usuários NÃO volta atrás no reboot (o que ia só pro /tmp era apagado).
/* Usuários, sessões, chave do cron e auto-conectar valem para TODAS as OLTs (várias OLTs: olt_cache_dir_g = pasta comum). */
function olt_auth_dir_g() { return function_exists('olt_cache_dir_g') ? olt_cache_dir_g() : (function_exists('olt_cache_dir') ? olt_cache_dir() : __DIR__ . '/cache_trafego'); }
function olt_auth_dirs() {
    if (function_exists('olt_cache_dirs_g')) return olt_cache_dirs_g();
    if (function_exists('olt_cache_dirs')) return olt_cache_dirs();
    $a = array(); if (function_exists('olt_cache_dir')) $a[] = olt_cache_dir();
    $addon = __DIR__ . '/cache_trafego'; $tmp = sys_get_temp_dir() . '/acellApp_cache_trafego';
    foreach (array($addon, $tmp) as $d) { if (!in_array($d, $a, true)) $a[] = $d; }
    return $a;
}
function olt_auth_arquivo() { return olt_auth_dir_g() . '/olt_usuarios.json'; }   // (compat)

// AUTO-CONECTAR: preferência gravada pela tela Gerência OLT (padrão LIGADO — ver olt.php). Lida
// aqui de novo pra valer em QUALQUER porta de entrada, não só em quem abriu aquela tela.
function olt_auth_autoconn_ligado() {
    $f = olt_auth_dir_g() . '/olt_autoconnect.json';
    if (!is_file($f)) return true;
    $j = json_decode((string)@file_get_contents($f), true);
    return !(is_array($j) && array_key_exists('auto', $j) && $j['auto'] === false);
}


function olt_auth_usuarios() {
    $best = null; $bts = -1;
    foreach (olt_auth_dirs() as $d) { $f = $d . '/olt_usuarios.json';
        if (is_file($f)) { $t = (int)@filemtime($f); if ($t >= $bts) { $u = json_decode((string)@file_get_contents($f), true); if (is_array($u)) { $best = $u; $bts = $t; } } } }
    return is_array($best) ? $best : array();
}

function olt_auth_salvar($u) {
    $j = json_encode($u, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); $ok = false;
    foreach (olt_auth_dirs() as $d) { if (!is_dir($d)) @mkdir($d, 0777, true); $f = $d . '/olt_usuarios.json';
        if (@file_put_contents($f, $j) !== false) { @chmod($f, 0600); $ok = true; } }   // grava na PERSISTENTE também
    return $ok;
}

// Senha atual da OLT (usada só no primeiro acesso).
function olt_auth_senha_olt() {
    $f = olt_auth_dir_g() . '/olt_conexao.json';   // 1º acesso: senha da OLT principal
    if (!is_file($f)) return '';
    $c = json_decode((string)@file_get_contents($f), true);
    return (is_array($c) && isset($c['pass'])) ? (string)$c['pass'] : '';
}

function olt_auth_primeiro_acesso() { return count(olt_auth_usuarios()) === 0; }

// =============================================================================
// AUDITORIA DE SESSÕES — quem entrou, quando, de onde e por quanto tempo.
// Guarda em olt_sessoes.json. Uma sessão é considerada ATIVA enquanto não tem
// "fim" e teve atividade nos últimos 5 minutos (o "ultimo" é atualizado no
// máximo 1x por minuto, para não ficar gravando em disco a cada clique).
// =============================================================================
define('OLT_SESSAO_ATIVA_SEG', 300);

function olt_sessoes_arquivo() { return olt_auth_dir_g() . '/olt_sessoes.json'; }

function olt_sessoes_ler() {
    $f = olt_sessoes_arquivo();
    $d = is_file($f) ? json_decode((string)@file_get_contents($f), true) : [];
    $d = is_array($d) ? $d : [];
    return olt_sessoes_rollover($d);
}

// LIMPEZA AUTOMÁTICA — todo dia 1, a partir de 00:01, o histórico é zerado.
// Roda "no acesso": ao ler o arquivo, se o mês virou desde a última limpeza,
// limpa e registra a marca. Não depende de cron. As sessões AINDA ABERTAS são
// preservadas, para ninguém sumir da lista de "conectados agora".
function olt_sessoes_rollover($d) {
    $marca = olt_auth_dir_g() . '/olt_sessoes_mes.txt';
    $mesAtual = date('Y-m');
    $ultimo = is_file($marca) ? trim((string)@file_get_contents($marca)) : '';
    if ($ultimo === $mesAtual) return $d;                 // já limpou neste mês
    if ((int)date('j') < 1) return $d;                    // segurança
    // Só limpa a partir do dia 1 às 00:01 (o minuto 0 do dia 1 ainda não conta).
    if ((int)date('j') === 1 && (int)date('G') === 0 && (int)date('i') < 1) return $d;
    $abertas = [];
    foreach ($d as $s) { if (empty($s['fim'])) $abertas[] = $s; }   // mantém quem está online
    @file_put_contents($marca, $mesAtual);
    @chmod($marca, 0600);
    $f = olt_sessoes_arquivo();
    @file_put_contents($f, json_encode($abertas, JSON_UNESCAPED_UNICODE));
    return $abertas;
}

function olt_sessoes_gravar($d) {
    // Mantém os 400 registros mais recentes — histórico útil sem crescer sem fim.
    if (count($d) > 400) $d = array_slice($d, -400);
    $f = olt_sessoes_arquivo();
    $r = @file_put_contents($f, json_encode($d, JSON_UNESCAPED_UNICODE));
    if ($r !== false) @chmod($f, 0600);
    return $r !== false;
}

function olt_sessao_ip() {
    foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) { $v = explode(',', $_SERVER[$k])[0]; return substr(trim($v), 0, 45); }
    }
    return '';
}

// Abre um registro de sessão no login.
function olt_sessao_abrir($login, $nome, $nivel) {
    $d = olt_sessoes_ler();
    $id = uniqid('s', true);
    $d[] = ['id' => $id, 'login' => $login, 'nome' => $nome, 'nivel' => (int)$nivel,
            'ip' => olt_sessao_ip(), 'inicio' => time(), 'ultimo' => time(), 'fim' => null];
    olt_sessoes_gravar($d);
    $_SESSION['ws_olt_sid'] = $id;
}

// Marca atividade (throttle de 60s) — é o que define "está online agora".
function olt_sessao_ping() {
    if (empty($_SESSION['ws_olt_sid'])) return;
    $ult = $_SESSION['ws_olt_ping'] ?? 0;
    if ((time() - $ult) < 60) return;              // ainda dentro da janela: não grava
    $_SESSION['ws_olt_ping'] = time();
    $d = olt_sessoes_ler(); $mudou = false;
    foreach ($d as &$s) {
        if (($s['id'] ?? '') === $_SESSION['ws_olt_sid'] && empty($s['fim'])) { $s['ultimo'] = time(); $mudou = true; break; }
    }
    unset($s);
    if ($mudou) olt_sessoes_gravar($d);
}

// Fecha o registro no logout.
function olt_sessao_fechar() {
    if (empty($_SESSION['ws_olt_sid'])) return;
    $d = olt_sessoes_ler();
    foreach ($d as &$s) {
        if (($s['id'] ?? '') === $_SESSION['ws_olt_sid'] && empty($s['fim'])) { $s['fim'] = time(); $s['ultimo'] = time(); break; }
    }
    unset($s);
    olt_sessoes_gravar($d);
    unset($_SESSION['ws_olt_sid']);
}

// Sessão corrente (ou null).
function olt_auth_sessao() {
    // 1) Login proprio da OLT (usuario cadastrado em olt_usuarios.json) — tem prioridade.
    if (!empty($_SESSION['ws_olt_login'])) {
        $u = olt_auth_usuarios();
        $lg = $_SESSION['ws_olt_login'];
        if (isset($u[$lg])) return ['login' => $lg, 'nome' => $u[$lg]['nome'] ?? $lg, 'nivel' => (int)($u[$lg]['nivel'] ?? 1)];
        unset($_SESSION['ws_olt_login']);
    }
    // 2) PONTE DO WELLSYSTEM: operador ja logado no painel entrou por "Auto-conectar" — o olt.php
    //    grava a ponte na sessao WSOLTSESS. Sem isto o AJAX (listar_slot, autorizar, etc.) nao
    //    reconhece o operador e a tela responde "sessao expirou" mesmo com a pagina aberta.
    if (!empty($_SESSION['ws_olt_bridge']) && is_array($_SESSION['ws_olt_bridge'])) {
        $b = $_SESSION['ws_olt_bridge'];
        return ['login' => (string)($b['login'] ?? 'operador'),
                'nome'  => (string)($b['nome'] ?? 'Operador'),
                'nivel' => (int)($b['nivel'] ?? 2)];
    }
    // 3) AUTO-CONECTAR NA HORA: antes, essa ponte só nascia se o operador tivesse passado pela
    //    tela Gerência OLT primeiro — quem chegava direto por outro caminho (ex.: o ícone "Ver
    //    ONU/ONT" em Clientes/Servidores, que fala com esta OLT direto por AJAX) caía sem ponte e
    //    a tela pedia login/senha da OLT de novo, mesmo com a conexão já configurada. Agora, com
    //    auto-conectar LIGADO (padrão) e o operador já logado no WellSystem — capturado ANTES da
    //    troca pra esta sessão própria da OLT, ver topo de olt_huawei.php — a ponte nasce aqui,
    //    na hora, em QUALQUER endpoint: não tem mais "precisar abrir a Gerência OLT primeiro".
    global $__ws_olt_root_op;
    if (!empty($__ws_olt_root_op) && olt_auth_autoconn_ligado()) {
        $na = (int)($__ws_olt_root_op['nivel_acesso'] ?? 0);
        if ($na < 1 && ($__ws_olt_root_op['nivel'] ?? '') === 'admin') $na = 99;
        $nv = ($na >= 3) ? 3 : (($na === 2) ? 2 : (($na === 1) ? 1 : 2));
        $b = ['login' => (string)($__ws_olt_root_op['login'] ?? 'operador'),
              'nome'  => (string)($__ws_olt_root_op['nome'] ?? 'Operador'),
              'nivel' => $nv];
        $_SESSION['ws_olt_bridge'] = $b;
        return $b;
    }
    return null;
}

function olt_auth_nivel() { $s = olt_auth_sessao(); return $s ? (int)$s['nivel'] : 0; }

// --- Mapa de permissão: ação -> nível MÍNIMO exigido -------------------------
// Tudo que não estiver aqui exige nível 3 (padrão seguro: nega por omissão).
function olt_auth_nivel_exigido($acao) {
    static $map = null;
    if ($map === null) {
        $map = [];
        // Nível 1 — somente leitura / consulta
        foreach ([
            'cache_get','listar_slot','olt_status','pon_alertas','relatorio','autofind',
            'onu_optico','onu_portas','onu_trafego','onu_uptime','onu_vlan','detalhe_massa',
            'optico_massa','uptime_massa','versao_massa','estado_offline','buscar_cliente',
            'cadastro_get','meta_get','modelos_get','modelo_img_get','logo_get','perfis_get',
            'perfis_olt','vlans_olt','vlan_nomes_get','opcoes_get','conexao_get','notif_get','conexao_teste',
            'smartolt_map','fix_perms','grafico_dados','alarmes','cad_url_get','cliente_uuid','clientes_db','ip_vivo',
            'mkfiles_list','mkfiles_get','smartolt_prov_info','olts_lista',
        ] as $a) $map[$a] = 1;

        // Nível 2 — OPERAÇÃO AMPLA: quase todo o menu do dia a dia — autorizar/bloquear/reiniciar/deletar ONU,
        // trocar a VLAN do CLIENTE, editar cadastro/zona/tipo, perfis de velocidade, modelos, logo, notificações,
        // relatório, backup (export/agendamento). NÃO inclui o que compromete o sistema.
        foreach (['autorizar','onu_acao','cache_clear','pon_control','onu_modo','onu_trocar_vlan','generico_migrar','onu_desc_smart',
                  'radius_panel_get','radius_panel_set','radius_emergencia',
                  'meta_set','modelos_set','modelos_del','modelo_img_set','modelo_img_del',
                  'logo_set','logo_del','notif_set','notif_teste','notif_diag','relatorio_limpar',
                  'perfis_add','perfis_del','cadastro_set','cadastro_seed','opcoes_add','smartolt_debug',
                  'backup_export','backup_ag_get','backup_ag_set','backup_ag_testar','cad_url_set',
                  'mkfiles_upload','mkfiles_del','smartolt_authorize'] as $a) $map[$a] = 2;

        // Nível 3 (ROOT) — SÓ o que pode COMPROMETER o sistema: conexão/credenciais da OLT, terminal cru,
        // RESTAURAR backup e nomear VLAN. Também são nível 3 POR OMISSÃO (o padrão nega o que não está mapeado):
        //   · placa_estado (ligar/desligar PLACA)  · uplink_vlan (VLAN da PLACA)  · usuarios_add/del (criar usuário).
        // Ou seja: VLAN do CLIENTE = nível 2; VLAN da PLACA e mexer/deletar PLACA = nível 3.
        foreach (['conexao_set','conexao_desconectar','terminal_exec','backup_import','vlan_nomes_add','cron_scan','olt_add','olt_del','olt_ren','smartolt_cfg_get','smartolt_cfg_set'] as $a) $map[$a] = 3;
    }
    return $map[$acao] ?? 3;
}

// Ações que NÃO exigem login (a própria autenticação e o diagnóstico da sessão).
function olt_auth_publica($acao) {
    return in_array($acao, ['auth_login', 'auth_sessao', 'auth_logout'], true);
}

// Porteiro: aborta com JSON claro quando não autenticado ou sem nível.
function olt_auth_exigir($acao) {
    if (olt_auth_publica($acao)) return;

    // INSTALAÇÃO VIRGEM (nenhum usuário ainda): é preciso poder configurar a
    // conexão da OLT ANTES do primeiro login, porque o primeiro login usa
    // justamente a senha da OLT. Sem esta exceção o sistema se trancaria.
    // A janela é mínima: só a conexão e o diagnóstico, e some assim que o
    // usuário root é criado.
    if (olt_auth_primeiro_acesso()
        && in_array($acao, ['conexao_get', 'conexao_set', 'fix_perms'], true)) {
        return;
    }

    // CRON 24/7: o monitor roda sem navegador, logo sem sessão. Liberamos as
    // ações do cron quando a chamada vem do PRÓPRIO servidor (localhost) ou traz
    // a chave secreta gerada em cache_trafego/olt_cron_key.txt. Nada além dessas
    // três ações passa por aqui.
    if (in_array($acao, ['cron_scan', 'pon_alertas', 'relatorio', 'backup_diag', 'backup_run', 'snmp_coletar', 'snmp_hunt', 'snmp_find', 'pon_tx', 'pon_tx_debug', 'uplink_listar', 'autofind', 'cache_sync', 'alarmes_check', 'alarmes', 'rescan_pendente', 'olts_ids', 'smartolt_map', 'infra_alerta'], true)) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if ($ip === '127.0.0.1' || $ip === '::1' || $ip === ($_SERVER['SERVER_ADDR'] ?? '~')) return;
        $kf = olt_auth_dir_g() . '/olt_cron_key.txt';
        if (!is_file($kf)) { @file_put_contents($kf, bin2hex(random_bytes(16))); @chmod($kf, 0600); }
        $chave = trim((string)@file_get_contents($kf));
        $env   = (string)($_GET['key'] ?? $_POST['key'] ?? '');
        if ($chave !== '' && hash_equals($chave, $env)) return;
    }

    // ROBÔ DO WHATSAPP (01/10/2026): o diagnóstico de "sem internet" pode localizar a ONU do cliente e
    // REINICIÁ-LA ou RESSINCRONIZÁ-LA — e nada além disso (nunca excluir, VLAN, autorizar). Exige as duas
    // coisas: chamada do PRÓPRIO servidor E a chave secreta do robô (gerada sozinha, fora do alcance da web).
    if ($acao === 'onu_localizar' || ($acao === 'onu_acao' && in_array((string)($_POST['tipo'] ?? $_GET['tipo'] ?? ''), ['reboot', 'resync'], true))) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if ($ip === '127.0.0.1' || $ip === '::1' || $ip === ($_SERVER['SERVER_ADDR'] ?? '~')) {
            $kf = (defined('WS_CACHE') ? WS_CACHE : olt_cache_dir()) . '/olt_robo_key.txt';
            $chave = trim((string)@file_get_contents($kf));
            $env   = (string)($_POST['robo_key'] ?? $_GET['robo_key'] ?? '');
            if (strlen($chave) >= 32 && hash_equals($chave, $env)) return;
        }
    }

    $s = olt_auth_sessao();
    if (!$s) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['status' => 'nao_autenticado', 'nao_autenticado' => true,
            'message' => 'Sessão expirada ou inexistente. Faça login novamente.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    olt_sessao_ping();   // marca atividade (define quem está "online agora")

    // LIBERA A TRAVA DA SESSÃO AGORA.
    // O PHP mantém o arquivo de sessão bloqueado até o fim da requisição. Como a
    // varredura da OLT leva dezenas de segundos via Telnet, qualquer outra
    // requisição do mesmo usuário (inclusive o LOGOUT) ficava parada esperando.
    // Já lemos tudo o que precisávamos da sessão, então fechamos para escrita:
    // as ações seguem normalmente e o resto da interface deixa de travar.
    if (session_status() === PHP_SESSION_ACTIVE) { @session_write_close(); }

    $exig = olt_auth_nivel_exigido($acao);
    if ((int)$s['nivel'] < $exig) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        $rot = [1 => 'Leitura', 2 => 'Operação', 3 => 'Root'];
        echo json_encode(['status' => 'sem_permissao', 'sem_permissao' => true,
            'message' => 'Seu nível de acesso (' . ($rot[$s['nivel']] ?? $s['nivel']) . ') não permite esta ação. ' .
                         'Necessário: ' . ($rot[$exig] ?? $exig) . '.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// --- Endpoints de autenticação ----------------------------------------------
function olt_auth_endpoints($acao) {
    if ($acao === 'auth_sessao') {
        header('Content-Type: application/json; charset=utf-8');
        $s = olt_auth_sessao();
        echo json_encode(['status' => 'ok', 'logado' => (bool)$s, 'sessao' => $s,
            'primeiro_acesso' => olt_auth_primeiro_acesso(),
            'tem_conexao' => (olt_auth_senha_olt() !== '')], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($acao === 'auth_logout') {
        header('Content-Type: application/json; charset=utf-8');
        olt_sessao_fechar();
        $_SESSION = [];
        // Expira também o COOKIE — só destruir a sessão deixava o navegador
        // reenviando o mesmo id, e em alguns casos a saída não "pegava".
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'] ?? '/', $p['domain'] ?? '', $p['secure'] ?? false, $p['httponly'] ?? true);
        }
        @session_destroy();
        echo json_encode(['status' => 'ok', 'logado' => false], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($acao === 'auth_login') {
        header('Content-Type: application/json; charset=utf-8');
        $login = strtolower(trim((string)($_POST['login'] ?? '')));
        $senha = (string)($_POST['senha'] ?? '');
        $users = olt_auth_usuarios();

        // Pequena proteção contra força bruta: 1s de espera a cada falha.
        $falhar = function ($msg) { sleep(1); echo json_encode(['status' => 'erro', 'message' => $msg], JSON_UNESCAPED_UNICODE); exit; };

        if ($login === '' || $senha === '') $falhar('Informe usuário e senha.');

        // PRIMEIRO ACESSO: root + senha da OLT -> cria o root definitivo.
        if (!$users) {
            $sOlt = olt_auth_senha_olt();
            if ($sOlt === '') {
                $cf = olt_auth_dir_g() . '/olt_conexao.json';
                $temArq = is_file($cf);
                $falhar($temArq
                    ? 'A conexão da OLT está salva, mas SEM SENHA gravada. Clique em "Configurar conexão da OLT", digite a senha (não deixe em branco) e salve. Depois entre com root + essa senha.'
                    : 'Nenhuma conexão da OLT configurada. Clique em "Configurar conexão da OLT", preencha os dados e salve. Depois entre com root + a senha da OLT.');
            }
            if ($login !== 'root') $falhar('No primeiro acesso o usuário é exatamente "root" (minúsculas).');
            if (!hash_equals($sOlt, $senha)) {
                $falhar('Senha diferente da que está gravada na conexão da OLT (' . strlen($sOlt) . ' caracteres). '
                      . 'Se não lembra, reabra "Configurar conexão da OLT", digite uma senha e salve — ela passa a valer para este primeiro acesso.');
            }
            $users['root'] = ['nome' => 'Administrador', 'nivel' => 3,
                'hash' => password_hash($senha, PASSWORD_DEFAULT), 'criado' => date('c')];
            if (!olt_auth_salvar($users)) $falhar('Não foi possível gravar os usuários (permissão da pasta cache_trafego).');
            $_SESSION['ws_olt_login'] = 'root';
            olt_sessao_abrir('root', 'Administrador', 3);
            echo json_encode(['status' => 'ok', 'criado' => true,
                'sessao' => ['login' => 'root', 'nome' => 'Administrador', 'nivel' => 3]], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (!isset($users[$login]) || !password_verify($senha, (string)($users[$login]['hash'] ?? ''))) {
            $falhar('Usuário ou senha inválidos.');
        }
        $_SESSION['ws_olt_login'] = $login;
        olt_sessao_abrir($login, $users[$login]['nome'] ?? $login, (int)($users[$login]['nivel'] ?? 1));
        echo json_encode(['status' => 'ok', 'sessao' => [
            'login' => $login, 'nome' => $users[$login]['nome'] ?? $login,
            'nivel' => (int)($users[$login]['nivel'] ?? 1)]], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // --- Relatório de sessões: quem está online e histórico de acessos -------
    if ($acao === 'sessoes_get') {
        header('Content-Type: application/json; charset=utf-8');
        if (olt_auth_nivel() < 3) {
            http_response_code(403);
            echo json_encode(['status' => 'sem_permissao', 'message' => 'Apenas o nível Root vê o relatório de acessos.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $agora = time();
        $d = olt_sessoes_ler();
        $ativas = []; $hist = [];
        foreach (array_reverse($d) as $s) {          // mais recentes primeiro
            $fim   = $s['fim'] ?? null;
            $ult   = (int)($s['ultimo'] ?? $s['inicio'] ?? 0);
            $online = (!$fim && ($agora - $ult) <= OLT_SESSAO_ATIVA_SEG);
            $dur   = ($fim ? (int)$fim : $ult) - (int)($s['inicio'] ?? $ult);
            $reg = [
                'login' => $s['login'] ?? '', 'nome' => $s['nome'] ?? '',
                'nivel' => (int)($s['nivel'] ?? 1), 'ip' => $s['ip'] ?? '',
                'inicio' => (int)($s['inicio'] ?? 0), 'fim' => $fim ? (int)$fim : null,
                'ultimo' => $ult, 'duracao' => max(0, $dur), 'online' => $online,
                'encerrada' => (bool)$fim,
            ];
            if ($online) $ativas[] = $reg; else $hist[] = $reg;
        }
        // Total acumulado por usuário (soma das durações).
        $tot = [];
        foreach (array_merge($ativas, $hist) as $r) {
            $k = $r['login'];
            if (!isset($tot[$k])) $tot[$k] = ['login' => $k, 'nome' => $r['nome'], 'acessos' => 0, 'total' => 0];
            $tot[$k]['acessos']++; $tot[$k]['total'] += $r['duracao'];
        }
        usort($tot, function ($a, $b) { return $b['total'] <=> $a['total']; });
        echo json_encode(['status' => 'ok', 'agora' => $agora, 'ativas' => $ativas,
            'historico' => array_slice($hist, 0, 120), 'totais' => array_values($tot)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // --- Gestão de usuários (somente nível 3) --------------------------------
    if ($acao === 'usuarios_get' || $acao === 'usuarios_add' || $acao === 'usuarios_del') {
        header('Content-Type: application/json; charset=utf-8');
        if (olt_auth_nivel() < 3) {
            http_response_code(403);
            echo json_encode(['status' => 'sem_permissao', 'message' => 'Apenas o nível Root gerencia usuários.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $users = olt_auth_usuarios();
        $saved = null;

        if ($acao === 'usuarios_add') {
            $login = strtolower(trim((string)($_POST['login'] ?? '')));
            $nome  = trim((string)($_POST['nome'] ?? ''));
            $senha = (string)($_POST['senha'] ?? '');
            $nivel = (int)($_POST['nivel'] ?? 1);
            if ($nivel < 1 || $nivel > 3) $nivel = 1;
            if (!preg_match('/^[a-z0-9._-]{3,20}$/', $login)) {
                echo json_encode(['status' => 'erro', 'message' => 'Login inválido: use 3 a 20 caracteres (letras, números, ponto, hífen ou sublinhado).'], JSON_UNESCAPED_UNICODE); exit;
            }
            $novo = !isset($users[$login]);
            if ($novo && strlen($senha) < 4) {
                echo json_encode(['status' => 'erro', 'message' => 'A senha precisa ter ao menos 4 caracteres.'], JSON_UNESCAPED_UNICODE); exit;
            }
            // Protege o root: não permite rebaixá-lo (evita ficar sem administrador).
            if ($login === 'root' && $nivel < 3) $nivel = 3;
            $users[$login] = [
                'nome'  => ($nome !== '' ? substr($nome, 0, 60) : $login),
                'nivel' => $nivel,
                'hash'  => ($senha !== '' ? password_hash($senha, PASSWORD_DEFAULT) : ($users[$login]['hash'] ?? '')),
                'criado' => $users[$login]['criado'] ?? date('c'),
            ];
            $saved = olt_auth_salvar($users);
        } elseif ($acao === 'usuarios_del') {
            $login = strtolower(trim((string)($_POST['login'] ?? $_GET['login'] ?? '')));
            if ($login === 'root') {
                echo json_encode(['status' => 'erro', 'message' => 'O usuário root não pode ser removido.'], JSON_UNESCAPED_UNICODE); exit;
            }
            unset($users[$login]);
            $saved = olt_auth_salvar($users);
        }

        // Nunca devolve o hash das senhas.
        $lista = [];
        foreach ($users as $lg => $d) {
            $lista[] = ['login' => $lg, 'nome' => $d['nome'] ?? $lg, 'nivel' => (int)($d['nivel'] ?? 1), 'criado' => $d['criado'] ?? ''];
        }
        echo json_encode(['status' => 'ok', 'saved' => $saved, 'usuarios' => $lista], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
