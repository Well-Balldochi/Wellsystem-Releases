<?php
/** WellSystem — schema do banco (compartilhado por install.php e install_cli.php). */

// As tabelas do FreeRADIUS vivem em arquivo próprio porque agora moram em banco próprio.
require_once __DIR__ . '/schema_radius.php';

/** Migrações idempotentes: adiciona colunas novas a tabelas já existentes. */
function ws_migracoes(PDO $db): void {
    $addCol = function (string $tabela, string $coluna, string $ddl) use ($db) {
        // Só age se a tabela existir (algumas tabelas — ex.: ws_equipamento — são criadas pelo
        // selfheal em runtime, não pelo install); e nunca deixa um ALTER derrubar a migração.
        $tb = $db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $tb->execute([$tabela]);
        if ((int)$tb->fetchColumn() === 0) return;
        $st = $db->prepare("SELECT COUNT(*) FROM information_schema.columns
                            WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
        $st->execute([$tabela, $coluna]);
        if ((int)$st->fetchColumn() === 0) { try { $db->exec("ALTER TABLE `$tabela` ADD COLUMN $ddl"); } catch (Throwable $e) {} }
    };

    /* ÍNDICES — a lista inteira, com o porquê de cada um, vive em ws_indices_garantir()
     * (config.php). Ela ficava só aqui, e aqui só roda no INSTALADOR: quem atualizava do jeito
     * normal, trocando os arquivos do addon, nunca ganhava índice nenhum — e a tela de clientes
     * ia ficando lenta sem motivo aparente. Agora o ws_selfheal() chama a MESMA função depois de
     * cada atualização, e o instalador continua chamando por aqui. Uma lista só, dois caminhos. */
    ws_indices_garantir($db);

    /* PRESENÇA DO OPERADOR — alimenta a tela de "atendentes online". Carimbo atualizado a cada
       página aberta (no máximo 1x por minuto, ver ws_marcar_presenca() no config.php). O índice
       desta coluna está na lista acima. */
    $addCol('ws_usuario', 'visto_em', "visto_em DATETIME DEFAULT NULL");

    // 2FA no usuário
    $addCol('ws_usuario', 'twofa_secret',  "twofa_secret VARCHAR(64) DEFAULT NULL");
    $addCol('ws_usuario', 'twofa_enabled', "twofa_enabled TINYINT(1) NOT NULL DEFAULT 0");
    $addCol('ws_usuario', 'twofa_recovery', "twofa_recovery TEXT DEFAULT NULL");
    // Nome resumido + vínculo de ADICIONAL ao titular (cliente que é adicional de outro)
    $addCol('ws_cliente', 'nome_resumido', "nome_resumido VARCHAR(60) DEFAULT NULL");
    $addCol('ws_cliente', 'inscricao_municipal', "inscricao_municipal VARCHAR(30) DEFAULT NULL");   // 13/11/2026: IM do tomador (nota fiscal)
    $addCol('ws_cliente', 'titular_id', "titular_id INT DEFAULT NULL");
    $addCol('ws_cliente', 'apto_casa', "apto_casa VARCHAR(20) DEFAULT NULL");   // 19/11/2026: apartamento ou casa (endereço)
    $addCol('ws_cliente', 'cob_apto_casa', "cob_apto_casa VARCHAR(20) DEFAULT NULL");   // 19/11/2026: apartamento ou casa (cobrança)
    $addCol('ws_cliente', 'cob_lat', "cob_lat VARCHAR(20) DEFAULT NULL");   // 19/11/2026: latitude da cobrança
    $addCol('ws_cliente', 'cob_lng', "cob_lng VARCHAR(20) DEFAULT NULL");   // 19/11/2026: longitude da cobrança
    // Conexão IPoE/PPPoE: VLAN e ONT-ID (vindos da autorização da OLT)
    $addCol('ws_contrato', 'vlan',   "vlan INT DEFAULT NULL");
    $addCol('ws_contrato', 'ont_id', "ont_id VARCHAR(20) DEFAULT NULL");
    // Desbloqueio em CONFIANÇA: libera o inadimplente até esta data/hora; o cron re-bloqueia ao vencer.
    $addCol('ws_contrato', 'confianca_ate', "confianca_ate DATETIME DEFAULT NULL");
    // Recibo de pagamento enviado (WhatsApp) — evita reenvio no disparo em massa.
    $addCol('ws_fatura', 'recibo_em', "recibo_em DATETIME DEFAULT NULL");
    // Numeração do boleto ("nosso número"). Antes o boleto só tinha o id da fatura, então o
    // relatório não conseguia mostrar a numeração usada — e conferência com o banco depende dela.
    $addCol('ws_fatura', 'nosso_numero', "nosso_numero VARCHAR(20) DEFAULT NULL");
    // Anotação livre presa ao boleto/fatura.
    $addCol('ws_fatura', 'obs', "obs VARCHAR(255) DEFAULT NULL");
    // Categoria do título (mensalidade | servico | venda | outros) — definida no "Tipo" ao gerar.
    $addCol('ws_fatura', 'categoria', "categoria VARCHAR(20) DEFAULT NULL");
    // Conta do boleto ESCOLHIDA neste título. Em branco = usa a conta salva no cadastro do contrato.
    // Fica na fatura porque um título avulso pode sair por outra conta sem mexer no cadastro.
    $addCol('ws_fatura', 'banco_id', "banco_id INT DEFAULT NULL");
    // Lytex: ID da fatura na Lytex (_hashId) — título emitido pela conta com Emissão = Lytex (lytex.php).
    $addCol('ws_fatura', 'lytex_id', "lytex_id VARCHAR(255) DEFAULT NULL");
    // Cidades (ramais) de cada operador: principal = cidade do login; demais = acesso extra. Sem linha = só a 1ª cidade; nível 3 vê todas.
    $db->exec("CREATE TABLE IF NOT EXISTS ws_usuario_ramal (usuario_id INT NOT NULL, ramal_id INT NOT NULL,
               PRIMARY KEY (usuario_id, ramal_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $addCol('ws_usuario_ramal', 'principal', "principal TINYINT(1) NOT NULL DEFAULT 0");
    // Agente coletor que recebeu o pagamento (aparece no caixa e no recibo).
    $addCol('ws_pagamento', 'coletor', "coletor VARCHAR(80) DEFAULT NULL");
    // Tipo da chave PIX (formata o QR corretamente).
    $addCol('ws_banco', 'tipo_chave', "tipo_chave VARCHAR(12) DEFAULT NULL");
    $addCol('ws_banco', 'multa_pct', "multa_pct DECIMAL(5,2) NOT NULL DEFAULT 2.00");
    $addCol('ws_banco', 'juros_pct', "juros_pct DECIMAL(5,2) NOT NULL DEFAULT 1.00");
    $addCol('ws_banco', 'local_pgto', "local_pgto VARCHAR(160) DEFAULT NULL");
    $addCol('ws_banco', 'exibir_mes_ref', "exibir_mes_ref TINYINT(1) NOT NULL DEFAULT 1");
    $addCol('ws_banco', 'taxa_cobranca_ativa', "taxa_cobranca_ativa TINYINT(1) NOT NULL DEFAULT 0");
    $addCol('ws_banco', 'taxa_cobranca_valor', "taxa_cobranca_valor DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    $addCol('ws_banco', 'max_dias_recalc', "max_dias_recalc INT NOT NULL DEFAULT 0");
    $addCol('ws_banco', 'emissao', "emissao VARCHAR(10) DEFAULT NULL");
    // ONU/ONT + concentradores no contrato.
    $addCol('ws_contrato', 'placa_pon', "placa_pon VARCHAR(20) DEFAULT NULL");
    $addCol('ws_contrato', 'pon', "pon VARCHAR(20) DEFAULT NULL");
    $addCol('ws_contrato', 'rx_sinal', "rx_sinal VARCHAR(20) DEFAULT NULL");
    $addCol('ws_contrato', 'tx_sinal', "tx_sinal VARCHAR(20) DEFAULT NULL");
    /* rx_sinal  = potência que a ONU RECEBE (downstream, medida na casa do cliente).
       rx_olt    = potência que a OLT RECEBE da ONU (upstream, medida no equipamento).
       São as duas pontas do mesmo enlace e diagnosticam coisas diferentes: RX ruim na ONU aponta
       para a fibra até a casa; RX ruim na OLT aponta para o laser da ONU ou emenda no retorno. */
    $addCol('ws_contrato', 'rx_olt', "rx_olt VARCHAR(20) DEFAULT NULL");
    $addCol('ws_contrato', 'equipamento', "equipamento VARCHAR(40) DEFAULT NULL");
    $addCol('ws_contrato', 'concentradores', "concentradores VARCHAR(255) DEFAULT NULL");
    $addCol('ws_contrato', 'banco_id', "banco_id INT DEFAULT NULL");
    $addCol('ws_contrato', 'emissao_boleto', "emissao_boleto VARCHAR(10) DEFAULT NULL");
    // Login/senha específicos de IPoE (independentes do PPPoE — pedido: campos próprios no cadastro).
    $addCol('ws_contrato', 'login_ipoe', "login_ipoe VARCHAR(60) DEFAULT NULL");
    $addCol('ws_contrato', 'senha_ipoe', "senha_ipoe VARCHAR(60) DEFAULT NULL");
    // Acesso simultâneo (titular/adicional) + vínculo do cliente a um ramal (cidade)
    $addCol('ws_cliente', 'acesso_simultaneo', "acesso_simultaneo TINYINT(1) NOT NULL DEFAULT 0");
    $addCol('ws_cliente', 'ramal_id', "ramal_id INT DEFAULT NULL");
    $addCol('ws_contrato', 'onu_ativa', "onu_ativa TINYINT(1) NOT NULL DEFAULT 1");
    // Comodato (equipamento emprestado) + dados do aparelho entregue, presos ao contrato.
    // Cadastro de RUAS (registro automático ao digitar endereço). Uma rua por CEP (mesmo CEP não
    // duplica); a mesma rua pode existir em ramal/cidade diferente (CEP diferente).
    $db->exec("CREATE TABLE IF NOT EXISTS ws_rua (
        id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(160) NOT NULL, cep VARCHAR(10) DEFAULT NULL,
        cidade VARCHAR(80) DEFAULT NULL, ramal_id INT DEFAULT NULL, ativo TINYINT(1) NOT NULL DEFAULT 1,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_cep (cep), INDEX idx_cidade (cidade)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Data em que o cliente foi DESATIVADO (status cancelado) — alimenta a página "Clientes desativados".
    $addCol('ws_cliente', 'data_desativacao', "data_desativacao DATE DEFAULT NULL");
    // Cadastro INTERNO (equipe/teste, ex.: conta "Suporte" usada só pra testar o Portal/Central) —
    // não é cliente de verdade. Sem esta flag, esse tipo de cadastro contaminava contadores e
    // relatórios (ex.: apareceu como "cliente que acessou a Central" no card do Painel).
    $addCol('ws_cliente', 'interno', "interno TINYINT(1) NOT NULL DEFAULT 0");
    // Endereço de COBRANÇA (01/10/2026): opcional, separado do de instalação; o cliente pede a troca pela Central.
    $addCol('ws_cliente', 'cob_cep', "cob_cep VARCHAR(10) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_logradouro', "cob_logradouro VARCHAR(160) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_numero', "cob_numero VARCHAR(20) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_complemento', "cob_complemento VARCHAR(80) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_bairro', "cob_bairro VARCHAR(80) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_cidade', "cob_cidade VARCHAR(80) DEFAULT NULL");
    $addCol('ws_cliente', 'cob_uf', "cob_uf VARCHAR(2) DEFAULT NULL");
    // Roteador do cliente quando a ONU é Bridge (03/10/2026): é comodato? qual modelo?
    $addCol('ws_contrato', 'roteador_comodato', "roteador_comodato TINYINT(1) DEFAULT NULL");
    $addCol('ws_contrato', 'roteador_modelo', "roteador_modelo VARCHAR(80) DEFAULT NULL");
    // Quem fez o pagamento (02/10/2026): nome informado no Receber; aparece no Histórico do Caixa no lugar do login.
    $addCol('ws_pagamento', 'pago_por', "pago_por VARCHAR(120) DEFAULT NULL");
    // Código do cliente (01/10/2026): todo cliente tem um; o que falta é gerado (id com 6 dígitos).
    $addCol('ws_cliente', 'codigo', "codigo VARCHAR(20) DEFAULT NULL");
    try { $db->exec("UPDATE ws_cliente SET codigo=LPAD(id,6,'0') WHERE codigo IS NULL OR codigo=''"); } catch (Throwable $e) {}
    // CEP geral da cidade (auto-preenche o CEP no cadastro ao digitar cidade/UF; editável).
    $addCol('ws_cidade', 'cep', "cep VARCHAR(10) DEFAULT NULL");
    // Foto do equipamento (comodato) — hover do "Modelo do equip." e Estoque.
    $addCol('ws_equipamento', 'foto', "foto VARCHAR(255) DEFAULT NULL");
    $addCol('ws_contrato', 'equip_foto', "equip_foto VARCHAR(255) DEFAULT NULL");
    $addCol('ws_estoque', 'foto', "foto VARCHAR(255) DEFAULT NULL");
    $addCol('ws_contrato', 'bloqueio_manual', "bloqueio_manual TINYINT(1) NOT NULL DEFAULT 0");
    /* ÚLTIMA CONEXÃO VISTA NO CONCENTRADOR.
     * O IP do cliente é DINÂMICO: muda a cada reconexão e muda de faixa quando ele troca de
     * concentrador. Sem gravar, o IP só existe enquanto a sessão está de pé — e a tela fica sem
     * nada para mostrar de quem caiu. Estas colunas guardam o que foi visto por último, para o
     * IP continuar visível (em cinza, "desabilitado") depois que o cliente desconecta.
     * Quem grava é ws_conexao_registrar() (radius_lib.php), na MESMA leitura que já é feita
     * para montar o painel — não há coleta extra. */
    $addCol('ws_contrato', 'ip6_fixo',     "ip6_fixo VARCHAR(64) DEFAULT NULL");
    $addCol('ws_contrato', 'ultimo_ip',    "ultimo_ip VARCHAR(45) DEFAULT NULL");
    $addCol('ws_contrato', 'ultimo_ip_em', "ultimo_ip_em DATETIME DEFAULT NULL");
    $addCol('ws_contrato', 'ultimo_cnc',   "ultimo_cnc VARCHAR(45) DEFAULT NULL");
    $addCol('ws_contrato', 'comodato', "comodato TINYINT(1) NOT NULL DEFAULT 0");
    $addCol('ws_contrato', 'equip_modelo', "equip_modelo VARCHAR(60) DEFAULT NULL");
    $addCol('ws_contrato', 'equip_serial', "equip_serial VARCHAR(60) DEFAULT NULL");
    $addCol('ws_contrato', 'equip_mac', "equip_mac VARCHAR(20) DEFAULT NULL");
    // Tipo do CPE em comodato (ONT/ROUTER/ONU). Fica no CONTRATO porque é o equipamento DAQUELE
    // cliente; Cadastros › Equipamentos guarda só o catálogo de modelos.
    $addCol('ws_contrato', 'equip_tipo', "equip_tipo VARCHAR(20) DEFAULT NULL");
    // Estoque: quantidade, condição (novo/usado) e destino da saída (venda/comodato/defeito).
    $addCol('ws_estoque', 'quantidade', "quantidade INT NOT NULL DEFAULT 1");
    $addCol('ws_estoque', 'condicao', "condicao VARCHAR(10) NOT NULL DEFAULT 'novo'");
    $addCol('ws_estoque', 'destino_saida', "destino_saida VARCHAR(12) DEFAULT NULL");
    $addCol('ws_estoque', 'fornecedor', "fornecedor VARCHAR(120) DEFAULT NULL");
    $addCol('ws_estoque', 'local_estoque', "local_estoque VARCHAR(80) DEFAULT NULL");
    $addCol('ws_estoque', 'estoque_min', "estoque_min INT NOT NULL DEFAULT 0");
    // Livro de movimentações do estoque (auditoria: entrada/saída/devolução/ajuste).
    $db->exec("CREATE TABLE IF NOT EXISTS ws_estoque_mov (
        id INT AUTO_INCREMENT PRIMARY KEY, estoque_id INT NOT NULL, tipo VARCHAR(16) NOT NULL,
        qtd INT NOT NULL DEFAULT 0, valor DECIMAL(10,2) DEFAULT 0, cliente VARCHAR(120) DEFAULT NULL,
        destino VARCHAR(16) DEFAULT NULL, obs VARCHAR(250) DEFAULT NULL, usuario VARCHAR(120) DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_est (estoque_id), INDEX idx_tipo (tipo)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* SAÍDAS DO CAIXA (24/09/2026): tarifa do gateway lançada no retorno (ex.: "Tarifa paga no retorno do
       GalaxPay"), como o MK-Auth faz. UNIQUE (origem, ref): o mesmo retorno reenviado não lança duas vezes. */
    // Modelo B da taxa de emissão: marca no banco (ver ws_faturas_modelo_b_converter no config.php).
    try { $db->exec("ALTER TABLE ws_fatura ADD COLUMN valor_modelo TINYINT NULL DEFAULT NULL"); } catch (Throwable $e) {}
    try { $db->exec("ALTER TABLE ws_fatura ALTER valor_modelo SET DEFAULT 2"); } catch (Throwable $e) {}
    $db->exec("CREATE TABLE IF NOT EXISTS ws_caixa_saida (
            id INT AUTO_INCREMENT PRIMARY KEY,
            data DATE NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            historico VARCHAR(255) NOT NULL,
            fatura_id INT DEFAULT NULL,
            origem VARCHAR(30) NOT NULL DEFAULT 'manual',
            ref VARCHAR(80) DEFAULT NULL,
            usuario VARCHAR(80) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_origem_ref (origem, ref), INDEX idx_data (data), INDEX idx_fatura (fatura_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* LANÇAMENTOS EXTRAS DO CAIXA (25/11/2026): valor que ENTRA ou SAI do fechamento do dia sem ser pagamento de boleto
       (ex.: venda de um roteador = entrada; depósito do dinheiro = saída). Lançado à mão na tela Caixa (nível 3+). */
    $db->exec("CREATE TABLE IF NOT EXISTS ws_caixa_extra (
            id INT AUTO_INCREMENT PRIMARY KEY,
            data DATE NOT NULL,
            tipo ENUM('entrada','saida') NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            historico VARCHAR(255) NOT NULL,
            usuario VARCHAR(80) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_data (data), INDEX idx_tipo (tipo)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Status do cliente: MK-Auth não tem "inativo" — troca por "observacao".
    $tipo = $db->query("SELECT COLUMN_TYPE FROM information_schema.columns
                        WHERE table_schema=DATABASE() AND table_name='ws_cliente' AND column_name='status'")->fetchColumn();
    if ($tipo && strpos($tipo, 'observacao') === false) {
        $db->exec("ALTER TABLE ws_cliente MODIFY status ENUM('ativo','bloqueado','cancelado','observacao','inativo') NOT NULL DEFAULT 'ativo'");
        $db->exec("UPDATE ws_cliente SET status='observacao' WHERE status='inativo'");
    }

    /* POOL PRÓPRIA do assinante (radreply → Framed-Pool). Tira este cliente da pool geral e o põe
     * numa faixa específica: bloco público, faixa de empresa, CGNAT separado, rede de teste. Antes,
     * separar um cliente de faixa só era possível mexendo no concentrador à mão — e o que se faz à
     * mão fora do sistema se perde na próxima migração. Ver ws_rad_sync_contrato(). */
    $addCol('ws_contrato', 'pool', "pool VARCHAR(60) DEFAULT NULL");

    /* PLANO EM USO: troca o vínculo antigo (SET NULL) pelo que BLOQUEIA a exclusão (RESTRICT).
     * Instalação que já existia foi criada com SET NULL, e nela apagar um plano continuaria zerando
     * o plano dos contratos em silêncio. Recriar a restrição é o único jeito de mudar a regra —
     * MySQL não altera a ação de uma FK existente.
     * Feito com try em cada passo: num banco onde a FK tenha outro nome, ou onde já exista contrato
     * apontando para plano inexistente (lixo de importação), a recriação falha — e falhar aqui não
     * pode derrubar o carregamento da página. */
    try {
        $acao = (string)$db->query("SELECT delete_rule FROM information_schema.referential_constraints
                                    WHERE constraint_schema=DATABASE() AND constraint_name='fk_ct_plano'")->fetchColumn();
        if ($acao !== '' && strtoupper($acao) !== 'RESTRICT' && strtoupper($acao) !== 'NO ACTION') {
            $db->exec("ALTER TABLE ws_contrato DROP FOREIGN KEY fk_ct_plano");
            $db->exec("ALTER TABLE ws_contrato ADD CONSTRAINT fk_ct_plano
                       FOREIGN KEY (plano_id) REFERENCES ws_plano(id) ON DELETE RESTRICT");
        }
    } catch (Throwable $e) {}

    /* PORTA DO CoA — nossa, não do FreeRADIUS.
     * Saiu da tabela `nas` (que é do FreeRADIUS) e passou para ws_concentrador, que é nossa. O
     * valor é copiado da coluna antiga quando ela ainda existir, para nenhum concentrador perder a
     * porta configurada na mudança. Ver o comentário de `nas` no schema_radius.php. */
    $addCol('ws_concentrador', 'coa_port', "coa_port INT NOT NULL DEFAULT 3799");
    try {
        $temAntiga = (int)$db->query("SELECT COUNT(*) FROM information_schema.columns
                                      WHERE table_schema=DATABASE() AND table_name='nas' AND column_name='coa_port'")->fetchColumn();
        if ($temAntiga) {
            $db->exec("UPDATE ws_concentrador c JOIN nas n ON n.nasname=c.host
                       SET c.coa_port = COALESCE(NULLIF(n.coa_port,0), 3799)
                       WHERE COALESCE(c.coa_port,0) IN (0,3799)");
        }
    } catch (Throwable $e) {}

    // Fecha o buraco estrutural descrito em ws_reconciliar_colunas(): tudo que o schema declara
    // e a tabela não tem. Roda por último, depois das migrações escritas à mão acima.
    ws_reconciliar_colunas($db);

    // Tabelas do FreeRADIUS (banco próprio + visões). Idempotente, ver schema_radius.php.
    try { ws_radius_preparar($db); } catch (Throwable $e) {}

    /* Tabelas de ENDEREÇO normalizado (uf/cep/cidade/bairro/logradouro) + as colunas de vínculo.
     * Só a ESTRUTURA aqui — a migração dos endereços que já existem em texto é pesada (um resolve
     * por cliente) e roda no cron, em lotes. Ver schema_endereco.php. */
    try {
        require_once __DIR__ . '/schema_endereco.php';
        ws_endereco_preparar($db);
    } catch (Throwable $e) {}
}

/**
 * COLUNA DECLARADA NO SCHEMA QUE A TABELA NÃO TEM — cria sozinha.
 *
 * O PROBLEMA QUE ISTO RESOLVE, E POR QUE ELE SE REPETIA
 * `CREATE TABLE IF NOT EXISTS` só cria a tabela quando ela NÃO existe. Acrescentar uma coluna ao
 * CREATE não faz efeito nenhum em quem já tem a tabela — e todo servidor em produção já tem.
 * Então cada coluna nova precisava ser escrita em DOIS lugares: no CREATE (para instalação nova)
 * e à mão numa migração (para instalação existente). Esquecer o segundo não dá erro em lugar
 * nenhum: dá uma tela em branco, meses depois, em quem atualizou.
 *
 * Foi exatamente o que aconteceu com ws_contrato.data_ativacao e data_cancelamento: estavam no
 * CREATE, nunca numa migração. O relatório de Ativação/Desativação consultava colunas que só
 * existiam em instalação nova — e abria vazio em toda instalação antiga, sem dizer por quê.
 *
 * COMO FUNCIONA
 * Lê os próprios CREATE TABLE do ws_schema_sql(), extrai as colunas declaradas e compara com o
 * que a tabela realmente tem. O que faltar é acrescentado com o MESMO trecho de DDL escrito no
 * CREATE — não há uma segunda definição para divergir da primeira.
 *
 * O QUE ELA NÃO FAZ, de propósito
 * Não remove coluna, não altera tipo, não mexe em índice nem em chave estrangeira. Só ACRESCENTA
 * o que falta. Uma rotina automática que apaga ou converte coluna em banco de produção é um risco
 * que não se justifica; acrescentar é a única operação que não pode destruir dado.
 *
 * Cada ALTER tem seu próprio try/catch: uma coluna que não entra não pode impedir as outras, nem
 * derrubar o carregamento da página.
 */
function ws_reconciliar_colunas(PDO $db): void {
    foreach (ws_schema_sql() as $sql) {
        if (!preg_match('/CREATE TABLE IF NOT EXISTS\s+`?(\w+)`?\s*\((.*)\)\s*ENGINE/s', $sql, $m)) continue;
        $tabela = $m[1];

        // Tabela que ainda não existe será criada inteira pelo próprio CREATE — nada a reconciliar.
        try {
            $tb = $db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
            $tb->execute([$tabela]);
            if ((int)$tb->fetchColumn() === 0) continue;

            $atuais = [];
            $st = $db->prepare("SELECT LOWER(column_name) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=?");
            $st->execute([$tabela]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $c) $atuais[$c] = true;
        } catch (Throwable $e) { continue; }

        /* A leitura é LINHA A LINHA, nunca por vírgula: um ENUM('aberto','pago',...) tem vírgulas
         * dentro e seria partido ao meio, gerando DDL sem sentido. O schema escreve uma coluna por
         * linha, então a linha é a unidade certa. */
        foreach (preg_split('/\r?\n/', $m[2]) as $linha) {
            $linha = trim(preg_replace('#/\*.*?\*/#s', '', $linha));          // tira comentário na linha
            $linha = rtrim($linha, ',');
            if ($linha === '') continue;
            // Índices, chaves e restrições não são colunas.
            if (preg_match('/^(PRIMARY|UNIQUE|KEY|INDEX|CONSTRAINT|FOREIGN|CHECK)\b/i', $linha)) continue;
            if (!preg_match('/^`?([a-z_][a-z0-9_]*)`?\s+\S/i', $linha, $c)) continue;

            $coluna = strtolower($c[1]);
            if (isset($atuais[$coluna])) continue;

            /* UNIQUE junto da coluna vira índice, e um índice único sobre dados já existentes pode
             * falhar por duplicata — o que derrubaria a criação da coluna. A coluna entra sem ele;
             * quem precisa do índice o declara no addIdx, onde a falha é tratada. */
            $ddl = preg_replace('/\s+UNIQUE\b/i', '', $linha);
            try { $db->exec("ALTER TABLE `$tabela` ADD COLUMN $ddl"); $atuais[$coluna] = true; }
            catch (Throwable $e) { /* tipo não suportado ou corrida com outro processo: segue */ }
        }
    }
}

/** DDL de todas as tabelas da fase 1. Cada item é um CREATE TABLE idempotente. */
function ws_schema_sql(): array {
    return [
        // Operadores do sistema (login do painel)
        "CREATE TABLE IF NOT EXISTS ws_usuario (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            login VARCHAR(60) NOT NULL UNIQUE,
            senha_hash VARCHAR(255) NOT NULL,
            nivel ENUM('admin','financeiro','tecnico','atendente') NOT NULL DEFAULT 'atendente',
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Concentradores (RouterOS/accel-ppp) — usado pelo módulo Radius
        "CREATE TABLE IF NOT EXISTS ws_concentrador (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            tipo ENUM('mikrotik','accel') NOT NULL DEFAULT 'mikrotik',
            host VARCHAR(120) NOT NULL,
            porta INT NOT NULL DEFAULT 8728,
            usuario VARCHAR(80) DEFAULT NULL,
            senha VARCHAR(120) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Planos de velocidade
        "CREATE TABLE IF NOT EXISTS ws_plano (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            down_kbps INT NOT NULL DEFAULT 0,
            up_kbps INT NOT NULL DEFAULT 0,
            valor DECIMAL(10,2) NOT NULL DEFAULT 0,
            descricao VARCHAR(255) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Clientes (pessoa)
        "CREATE TABLE IF NOT EXISTS ws_cliente (
            id INT AUTO_INCREMENT PRIMARY KEY,
            tipo ENUM('PF','PJ') NOT NULL DEFAULT 'PF',
            nome VARCHAR(160) NOT NULL,
            cpf_cnpj VARCHAR(20) DEFAULT NULL,
            rg_ie VARCHAR(30) DEFAULT NULL,
            inscricao_municipal VARCHAR(30) DEFAULT NULL,
            email VARCHAR(160) DEFAULT NULL,
            celular VARCHAR(20) DEFAULT NULL,
            telefone VARCHAR(20) DEFAULT NULL,
            data_nasc DATE DEFAULT NULL,
            cep VARCHAR(10) DEFAULT NULL,
            logradouro VARCHAR(160) DEFAULT NULL,
            numero VARCHAR(20) DEFAULT NULL,
            complemento VARCHAR(80) DEFAULT NULL,
            bairro VARCHAR(80) DEFAULT NULL,
            cidade VARCHAR(80) DEFAULT NULL,
            uf CHAR(2) DEFAULT NULL,
            lat DECIMAL(10,7) DEFAULT NULL,
            lng DECIMAL(10,7) DEFAULT NULL,
            status ENUM('ativo','inativo','bloqueado','cancelado') NOT NULL DEFAULT 'ativo',
            obs TEXT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_nome (nome),
            INDEX idx_cpf (cpf_cnpj)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Contratos (ponto de instalação) — elo com Radius (login) e OLT (sn_onu)
        "CREATE TABLE IF NOT EXISTS ws_contrato (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT NOT NULL,
            plano_id INT DEFAULT NULL,
            concentrador_id INT DEFAULT NULL,
            login_pppoe VARCHAR(80) DEFAULT NULL UNIQUE,
            senha_pppoe VARCHAR(120) DEFAULT NULL,
            tipo_conexao ENUM('pppoe','ipoe','hotspot') NOT NULL DEFAULT 'pppoe',
            ip_fixo VARCHAR(45) DEFAULT NULL,
            sn_onu VARCHAR(40) DEFAULT NULL,
            dia_vencimento TINYINT NOT NULL DEFAULT 10,
            valor DECIMAL(10,2) DEFAULT NULL,
            inst_cep VARCHAR(10) DEFAULT NULL,
            inst_logradouro VARCHAR(160) DEFAULT NULL,
            inst_numero VARCHAR(20) DEFAULT NULL,
            inst_complemento VARCHAR(80) DEFAULT NULL,
            inst_bairro VARCHAR(80) DEFAULT NULL,
            inst_cidade VARCHAR(80) DEFAULT NULL,
            inst_uf CHAR(2) DEFAULT NULL,
            lat DECIMAL(10,7) DEFAULT NULL,
            lng DECIMAL(10,7) DEFAULT NULL,
            zona VARCHAR(80) DEFAULT NULL,
            data_ativacao DATE DEFAULT NULL,
            data_cancelamento DATE DEFAULT NULL,
            status ENUM('ativo','suspenso','bloqueado','cancelado') NOT NULL DEFAULT 'ativo',
            obs TEXT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_cliente (cliente_id),
            INDEX idx_login (login_pppoe),
            INDEX idx_sn (sn_onu),
            CONSTRAINT fk_ct_cliente FOREIGN KEY (cliente_id) REFERENCES ws_cliente(id) ON DELETE CASCADE,
            /* PLANO EM USO NÃO PODE SER APAGADO — RESTRICT, não SET NULL.
             *
             * Com SET NULL, apagar um plano zerava o plano de todo contrato que o usava. Em
             * silêncio: nenhum erro na tela, nenhum aviso, e os clientes daquele plano ficavam sem
             * plano — sem velocidade no RADIUS e sem valor na fatura. É o mesmo estrago que o
             * MK-Auth faz, e por isso o vínculo agora BLOQUEIA a exclusão: o banco recusa apagar um
             * plano que tenha contrato, e a tela diz quantos contratos o usam.
             *
             * O caminho certo passa a ser trocar o plano dos contratos primeiro (ou desativar o
             * plano, que ele tem a coluna `ativo` justamente para isso) e só então apagar. */
            CONSTRAINT fk_ct_plano   FOREIGN KEY (plano_id)   REFERENCES ws_plano(id)   ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- FASE 2: Financeiro (boleto+PIX via CelCash) ----------
        // Fatura = uma cobrança mensal do contrato. Guarda a referência da cobrança no CelCash
        // e os dados prontos pro cliente pagar (linha digitável, URL do boleto, PIX copia-e-cola).
        "CREATE TABLE IF NOT EXISTS ws_fatura (
            id INT AUTO_INCREMENT PRIMARY KEY,
            contrato_id INT DEFAULT NULL,
            cliente_id INT NOT NULL,
            competencia CHAR(7) DEFAULT NULL,            /* AAAA-MM */
            vencimento DATE NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            desconto DECIMAL(10,2) NOT NULL DEFAULT 0,
            status ENUM('aberto','processando','pago','vencido','cancelado') NOT NULL DEFAULT 'aberto',
            celcash_my_id VARCHAR(60) DEFAULT NULL UNIQUE,   /* nosso id enviado ao gateway */
            celcash_charge_id VARCHAR(60) DEFAULT NULL,       /* id gerado pelo CelCash */
            linha_digitavel VARCHAR(80) DEFAULT NULL,
            boleto_url VARCHAR(255) DEFAULT NULL,
            pix_emv TEXT DEFAULT NULL,                         /* PIX copia-e-cola */
            pix_qr_url VARCHAR(255) DEFAULT NULL,
            data_pagamento DATE DEFAULT NULL,
            valor_pago DECIMAL(10,2) DEFAULT NULL,
            gateway_raw MEDIUMTEXT DEFAULT NULL,              /* resposta crua p/ conferência/debug */
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_contrato (contrato_id),
            INDEX idx_status (status),
            INDEX idx_venc (vencimento),
            INDEX idx_charge (celcash_charge_id),
            CONSTRAINT fk_ft_contrato FOREIGN KEY (contrato_id) REFERENCES ws_contrato(id) ON DELETE SET NULL,
            CONSTRAINT fk_ft_cliente  FOREIGN KEY (cliente_id)  REFERENCES ws_cliente(id)  ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Pagamento = baixa de uma fatura (via webhook do CelCash ou manual).
        "CREATE TABLE IF NOT EXISTS ws_pagamento (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fatura_id INT NOT NULL,
            data_pgto DATE NOT NULL,
            valor_pago DECIMAL(10,2) NOT NULL,
            forma VARCHAR(20) NOT NULL DEFAULT 'dinheiro',
            origem ENUM('webhook','manual') NOT NULL DEFAULT 'webhook',
            obs VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_fatura (fatura_id),
            CONSTRAINT fk_pg_fatura FOREIGN KEY (fatura_id) REFERENCES ws_fatura(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",


        // ---------- FASE 4: Régua de cobrança + notificações ----------
        // Regras da régua: quando enviar (dias em relação ao vencimento) e o texto.
        "CREATE TABLE IF NOT EXISTS ws_regua (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            dias INT NOT NULL DEFAULT 0,             /* negativo=antes, 0=no venc, positivo=depois */
            usar_template TINYINT(1) NOT NULL DEFAULT 0,  /* 1 = template oficial (fora da janela 24h) */
            texto TEXT NOT NULL,                     /* aceita {nome} {valor} {vencimento} {linha} {pix} {link} */
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Log de notificações (auditoria + evita reenvio no mesmo dia/regra).
        "CREATE TABLE IF NOT EXISTS ws_notificacao (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fatura_id INT DEFAULT NULL,
            contrato_id INT DEFAULT NULL,
            regua_id INT DEFAULT NULL,
            canal ENUM('whatsapp') NOT NULL DEFAULT 'whatsapp',
            destino VARCHAR(30) DEFAULT NULL,
            status ENUM('enviado','erro') NOT NULL DEFAULT 'enviado',
            retorno TEXT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_dedupe (fatura_id, regua_id),
            INDEX idx_data (criado_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- Anexos (documentos/fotos do cliente) ----------
        "CREATE TABLE IF NOT EXISTS ws_anexo (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT NOT NULL,
            contrato_id INT DEFAULT NULL,
            tipo ENUM('documento','foto_instalacao','onu','contrato','outro') NOT NULL DEFAULT 'outro',
            nome_original VARCHAR(200) DEFAULT NULL,
            arquivo VARCHAR(120) NOT NULL,           /* nome físico em uploads/ (aleatório) */
            mime VARCHAR(80) DEFAULT NULL,
            tamanho INT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cli (cliente_id),
            CONSTRAINT fk_anx_cliente FOREIGN KEY (cliente_id) REFERENCES ws_cliente(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- Chamados / Ordem de Serviço ----------
        "CREATE TABLE IF NOT EXISTS ws_chamado (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT NOT NULL,
            contrato_id INT DEFAULT NULL,
            tipo VARCHAR(60) NOT NULL DEFAULT 'suporte',
            titulo VARCHAR(160) NOT NULL,
            descricao TEXT DEFAULT NULL,
            prioridade ENUM('baixa','normal','alta','urgente') NOT NULL DEFAULT 'normal',
            status ENUM('aberto','em_andamento','agendado','resolvido','cancelado') NOT NULL DEFAULT 'aberto',
            tecnico_id INT DEFAULT NULL,
            agendado_para DATETIME DEFAULT NULL,
            aberto_por INT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            fechado_em DATETIME DEFAULT NULL,
            tec_concluido_em DATETIME DEFAULT NULL,   -- técnico concluiu pelo link; o chamado espera a validação do provedor
            pesquisa_em DATETIME DEFAULT NULL,        -- pesquisa de satisfação enviada ao cliente (satisfacao_lib.php)
            /* Avaliação que o cliente dá pelo portal (central do assinante). Nasce aqui E no
               ws_selfheal() do config.php: instalação nova cria pela tabela, instalação antiga
               ganha por migração. Antes só o portal.php criava, com um ALTER solto — quem nunca
               tinha aberto o portal ficava sem as colunas e as telas de satisfação viam vazio. */
            avaliacao TINYINT DEFAULT NULL,
            avaliacao_comentario VARCHAR(300) DEFAULT NULL,
            avaliacao_em DATETIME DEFAULT NULL,
            causa_raiz VARCHAR(60) DEFAULT NULL,
            /* Telefones que recebem o aviso DESTE chamado (o técnico que vai atender). Fica no
               chamado, e não no cadastro do operador, porque quem vai a campo muda de um chamado
               para o outro — é terceirizado, é o plantonista da noite, é quem estava perto. */
            notificar_fones VARCHAR(255) DEFAULT NULL,
            /* Técnico de CAMPO do cadastro de técnicos (ws_tecnico) — não é usuário do sistema.
               tecnico_id (usuário) fica só como histórico dos chamados antigos. */
            tecnico_cad_id INT DEFAULT NULL,
            INDEX idx_cli (cliente_id), INDEX idx_status (status), INDEX idx_tec (tecnico_id), INDEX idx_tec_cad (tecnico_cad_id),
            CONSTRAINT fk_ch_cliente FOREIGN KEY (cliente_id) REFERENCES ws_cliente(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        /* TÉCNICOS DE CAMPO (instalação/suporte) — cadastro próprio, separado dos usuários (atendimento).
           funcao: instalacao · suporte · ambos. avisar = recebe no WhatsApp os chamados dele. */
        "CREATE TABLE IF NOT EXISTS ws_tecnico (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            celular VARCHAR(20) DEFAULT NULL,
            email VARCHAR(160) DEFAULT NULL,
            funcao VARCHAR(12) NOT NULL DEFAULT 'ambos',
            avisar TINYINT(1) NOT NULL DEFAULT 1,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            obs VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_ativo (ativo, nome)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        /* VISITAS À CENTRAL DO ASSINANTE.
         * Uma linha por SESSÃO de visitante, não por página aberta: o assinante entra, vê o
         * status, pega a 2ª via e abre um chamado — isso é UMA visita, não quatro. Contar por
         * página transformaria o número do Painel em "quantos cliques a central exige", que é o
         * oposto do que ele deve dizer.
         * cliente_id só é preenchido quando o assinante faz login (visitante que só olhou a tela
         * de entrada continua contando, com cliente_id nulo). */
        "CREATE TABLE IF NOT EXISTS ws_central_visita (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT DEFAULT NULL,
            origem VARCHAR(20) NOT NULL DEFAULT 'portal',
            ip VARCHAR(45) DEFAULT NULL,
            ua VARCHAR(160) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_data (criado_em), INDEX idx_cli (cliente_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS ws_chamado_msg (
            id INT AUTO_INCREMENT PRIMARY KEY,
            chamado_id INT NOT NULL,
            usuario_id INT DEFAULT NULL,
            autor_tipo ENUM('operador','cliente','sistema') NOT NULL DEFAULT 'operador',
            mensagem TEXT NOT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ch (chamado_id),
            CONSTRAINT fk_chm_chamado FOREIGN KEY (chamado_id) REFERENCES ws_chamado(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Timeline / auditoria — eventos do cliente (cadastro, contrato, fatura, bloqueio, chamado…)
        "CREATE TABLE IF NOT EXISTS ws_evento (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT DEFAULT NULL,
            usuario_id INT DEFAULT NULL,
            tipo VARCHAR(40) NOT NULL,
            texto VARCHAR(255) NOT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cli (cliente_id), INDEX idx_data (criado_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- NFSe (nota fiscal de serviço, via agregador multi-cidade) ----------
        "CREATE TABLE IF NOT EXISTS ws_nfse (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fatura_id INT DEFAULT NULL,
            cliente_id INT NOT NULL,
            valor DECIMAL(10,2) NOT NULL DEFAULT 0,
            status ENUM('pendente','processando','autorizada','erro','cancelada') NOT NULL DEFAULT 'pendente',
            numero VARCHAR(30) DEFAULT NULL,
            codigo_verificacao VARCHAR(60) DEFAULT NULL,
            provider_id VARCHAR(80) DEFAULT NULL,
            url_pdf VARCHAR(255) DEFAULT NULL,
            url_xml VARCHAR(255) DEFAULT NULL,
            retorno_raw MEDIUMTEXT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_fatura (fatura_id), INDEX idx_cli (cliente_id), INDEX idx_status (status),
            CONSTRAINT fk_nf_cliente FOREIGN KEY (cliente_id) REFERENCES ws_cliente(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- NF-e modelo 55 (venda de produto; emissão DIRETA na SEFAZ autorizadora do emissor, 11/11/2026) ----------
        "CREATE TABLE IF NOT EXISTS ws_ncm (codigo CHAR(8) NOT NULL PRIMARY KEY, descricao TEXT NOT NULL, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",   // 13/11/2026: tabela oficial de NCM (Siscomex)
        "CREATE TABLE IF NOT EXISTS ws_produto (id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(30) DEFAULT NULL, descricao VARCHAR(120) NOT NULL, ncm CHAR(8) NOT NULL DEFAULT '', cest VARCHAR(7) DEFAULT NULL, cfop CHAR(4) NOT NULL DEFAULT '5102', csosn VARCHAR(4) NOT NULL DEFAULT '400', origem CHAR(1) NOT NULL DEFAULT '0', unidade VARCHAR(6) NOT NULL DEFAULT 'UN', preco DECIMAL(12,2) NOT NULL DEFAULT 0, ativo TINYINT(1) NOT NULL DEFAULT 1, obs VARCHAR(255) DEFAULT NULL, fonte VARCHAR(10) NOT NULL DEFAULT 'manual', criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_prod_desc (descricao), INDEX idx_prod_ncm (ncm)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",   // 13/11/2026: produtos com classificação fiscal (Fiscal → Produtos)
        "CREATE TABLE IF NOT EXISTS ws_tomador (id INT AUTO_INCREMENT PRIMARY KEY, cliente_id INT NOT NULL, origem VARCHAR(10) NOT NULL DEFAULT 'nota', criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_tomador_cliente (cliente_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",   // 13/11/2026: tomadores (Fiscal → Tomadores): clientes que ganharam nota ou foram cadastrados lá
        "CREATE TABLE IF NOT EXISTS ws_nfcom (id INT AUTO_INCREMENT PRIMARY KEY, nota_id INT DEFAULT NULL, cliente_id INT NOT NULL, valor DECIMAL(10,2) NOT NULL DEFAULT 0, status ENUM('pendente','processando','autorizada','erro','cancelada') NOT NULL DEFAULT 'pendente', numero INT DEFAULT NULL, chave_acesso CHAR(44) DEFAULT NULL, protocolo VARCHAR(30) DEFAULT NULL, codigo_status VARCHAR(6) DEFAULT NULL, motivo VARCHAR(255) DEFAULT NULL, url_xml VARCHAR(255) DEFAULT NULL, retorno_raw MEDIUMTEXT DEFAULT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_nota (nota_id), INDEX idx_cli (cliente_id), UNIQUE INDEX idx_chave (chave_acesso)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS ws_nfe55 (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nota_id INT DEFAULT NULL,
            cliente_id INT NOT NULL,
            valor DECIMAL(10,2) NOT NULL DEFAULT 0,
            status ENUM('pendente','processando','autorizada','rejeitada','denegada','erro','cancelada') NOT NULL DEFAULT 'pendente',
            serie VARCHAR(5) NOT NULL DEFAULT '1',
            numero INT DEFAULT NULL,
            chave_acesso CHAR(44) DEFAULT NULL,
            protocolo VARCHAR(30) DEFAULT NULL,
            codigo_status VARCHAR(6) DEFAULT NULL,
            motivo VARCHAR(255) DEFAULT NULL,
            url_xml VARCHAR(255) DEFAULT NULL,
            retorno_raw MEDIUMTEXT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_nota (nota_id), INDEX idx_cli (cliente_id), INDEX idx_status (status), UNIQUE INDEX idx_chave (chave_acesso),
            CONSTRAINT fk_nfe55_cliente FOREIGN KEY (cliente_id) REFERENCES ws_cliente(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- Notas fiscais editáveis (rascunho com VÁRIOS itens por nota) ----------
        "CREATE TABLE IF NOT EXISTS ws_nota (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cliente_id INT NOT NULL,
            fatura_id INT DEFAULT NULL,
            tipo VARCHAR(10) NOT NULL DEFAULT 'nfse',
            status VARCHAR(20) NOT NULL DEFAULT 'rascunho',
            observacao TEXT DEFAULT NULL,
            total DECIMAL(12,2) NOT NULL DEFAULT 0,
            observacao_interna TEXT DEFAULT NULL,
            nfse_id INT DEFAULT NULL,
            nfe55_id INT DEFAULT NULL,
            nfcom_id INT DEFAULT NULL,
            regime VARCHAR(12) DEFAULT NULL,
            banco_id INT DEFAULT NULL,
            sem_cobranca TINYINT(1) NOT NULL DEFAULT 0,
            usuario VARCHAR(80) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_cli (cliente_id), INDEX idx_fat (fatura_id), INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS ws_nota_item (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nota_id INT NOT NULL,
            ordem INT NOT NULL DEFAULT 1,
            tipo VARCHAR(10) NOT NULL DEFAULT 'servico',
            descricao VARCHAR(255) NOT NULL,
            qtd DECIMAL(12,3) NOT NULL DEFAULT 1,
            valor_unit DECIMAL(12,2) NOT NULL DEFAULT 0,
            desconto DECIMAL(12,2) NOT NULL DEFAULT 0,
            ncm VARCHAR(8) DEFAULT NULL,
            cfop VARCHAR(4) DEFAULT NULL,
            csosn VARCHAR(4) DEFAULT NULL,
            cest VARCHAR(7) DEFAULT NULL,
            unidade VARCHAR(6) NOT NULL DEFAULT 'UN',
            INDEX idx_nota (nota_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- Comercial: leads / funil de vendas ----------
        "CREATE TABLE IF NOT EXISTS ws_lead (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(160) NOT NULL,
            telefone VARCHAR(20) DEFAULT NULL,
            email VARCHAR(160) DEFAULT NULL,
            cidade VARCHAR(80) DEFAULT NULL,
            bairro VARCHAR(80) DEFAULT NULL,
            endereco VARCHAR(200) DEFAULT NULL,
            lat DECIMAL(10,7) DEFAULT NULL,
            lng DECIMAL(10,7) DEFAULT NULL,
            origem VARCHAR(60) DEFAULT NULL,
            plano_interesse INT DEFAULT NULL,
            etapa ENUM('novo','contato','viabilidade','proposta','ganho','perdido') NOT NULL DEFAULT 'novo',
            valor_estimado DECIMAL(10,2) DEFAULT NULL,
            responsavel_id INT DEFAULT NULL,
            obs TEXT DEFAULT NULL,
            cliente_id INT DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_etapa (etapa)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Bancos / contas do provedor (para boleto/conciliação)
        "CREATE TABLE IF NOT EXISTS ws_banco (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            codigo VARCHAR(10) DEFAULT NULL,
            agencia VARCHAR(20) DEFAULT NULL,
            conta VARCHAR(30) DEFAULT NULL,
            titular VARCHAR(120) DEFAULT NULL,
            pix VARCHAR(140) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Histórico de online (snapshot do cron) — alimenta o gráfico do painel.
        "CREATE TABLE IF NOT EXISTS ws_online_hist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ts DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            online INT NOT NULL DEFAULT 0,
            INDEX idx_ts (ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",


        // Zonas / áreas de atendimento (usadas no contrato e na OLT/SmartOLT).
        "CREATE TABLE IF NOT EXISTS ws_zona (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            descricao VARCHAR(160) DEFAULT NULL,
            cor VARCHAR(9) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_nome (nome)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Estoque de equipamentos (ONUs, roteadores, cabos...) — entrada/saída.
        "CREATE TABLE IF NOT EXISTS ws_estoque (
            id INT AUTO_INCREMENT PRIMARY KEY,
            tipo VARCHAR(40) NOT NULL DEFAULT 'ONU',
            modelo VARCHAR(80) DEFAULT NULL,
            mac VARCHAR(40) DEFAULT NULL,
            data_entrada DATE DEFAULT NULL,
            valor_entrada DECIMAL(10,2) DEFAULT 0,
            status VARCHAR(30) NOT NULL DEFAULT 'em estoque',
            obs TEXT,
            data_saida DATE DEFAULT NULL,
            valor_saida DECIMAL(10,2) DEFAULT 0,
            cliente_saida VARCHAR(120) DEFAULT NULL,
            retirado_por VARCHAR(120) DEFAULT NULL,
            obs_saida VARCHAR(250) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_status (status), INDEX idx_mac (mac)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Cidades atendidas (cadastro unificado multi-cidade).
        "CREATE TABLE IF NOT EXISTS ws_cidade (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            uf VARCHAR(2) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Ramais: separam o cadastro por filial dentro de cada cidade, no mesmo sistema unificado.
        "CREATE TABLE IF NOT EXISTS ws_ramal (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cidade_id INT NOT NULL,
            nome VARCHAR(120) NOT NULL,
            codigo VARCHAR(20) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            CONSTRAINT fk_ramal_cidade FOREIGN KEY (cidade_id) REFERENCES ws_cidade(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        /* COMPROVANTES PIX do robô do WhatsApp (Financeiro → Comprovantes PIX). Definição única em
           comprovantes_lib.php (ws_comp_sql), a mesma usada pelo ws_selfheal() do config.php. */
        (function () { require_once __DIR__ . '/comprovantes_lib.php'; return ws_comp_sql(); })(),
        // SELO ANTIFRAUDE dos comprovantes (permanente) — mesma definição do ws_selfheal().
        (function () { require_once __DIR__ . '/comprovantes_lib.php'; return ws_comp_selo_sql(); })(),
        // PEDIDO DE CONFIRMAÇÃO DO PIX a quem tem acesso ao banco (comprovantes_lib.php) — mesma definição do ws_selfheal().
        (function () { require_once __DIR__ . '/comprovantes_lib.php'; return ws_pixped_sql(); })(),
        // PIX recebidos lidos na API do Banco do Brasil (bb_pix.php) — mesma definição do ws_selfheal().
        (function () { require_once __DIR__ . '/bb_pix.php'; return ws_bb_sql(); })(),
        // CGNAT determinístico (cgnat_lib.php): tabela versionada IP público+portas <-> IP privado e auditoria das consultas — mesma definição do ws_selfheal().
        (function () { require_once __DIR__ . '/cgnat_lib.php'; return ws_cgnat_sql()[0]; })(),
        (function () { require_once __DIR__ . '/cgnat_lib.php'; return ws_cgnat_sql()[1]; })(),
        (function () { require_once __DIR__ . '/cgnat_lib.php'; return ws_cgnat_sql()[2]; })(),
        (function () { require_once __DIR__ . '/cgnat_lib.php'; return ws_cgnat_sql()[3]; })(),
        (function () { require_once __DIR__ . '/cgnat_lib.php'; return ws_cgnat_sql()[4]; })(),
    ];
}
