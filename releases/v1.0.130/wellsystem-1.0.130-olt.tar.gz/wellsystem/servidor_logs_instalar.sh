#!/bin/bash
# WellSystem — SERVIDOR DE HORA E LOGS (Debian 13). Monta/repara o servidor inteiro; pode rodar de novo (idempotente).
# Uso (root, na VM do servidor de logs, com servidor_logs_painel.php e servidor_logs_ctl.php na mesma pasta deste arquivo):
#   bash servidor_logs_instalar.sh [senha-do-painel] [community-snmp] [ip-do-zabbix-dude=172.20.1.5] [dominio, ex.: log.wellnet.com.br]
#   (dominio = HTTPS com certificado Let's Encrypt que renova sozinho; fica gravado em /var/lib/timelogs/dominio e vale nas próximas rodadas.
#    Precisa do nome apontando para o IP público e das portas 80 e 443 encaminhadas até esta VM; sem isso o painel segue só em http:8086.)
#   (a senha só é pedida se ainda não existir login do painel; usuário: admin. A community NÃO fica gravada neste arquivo: é informada na instalação;
#    sem ela o SNMP não é mexido. SNMP = somente leitura, respondendo só ao IP do monitoramento e ao próprio servidor.)
# Faz: nginx+PHP (painel nas portas 80 e 8086, /ctl livre), syslog-ng recebendo UDP e TCP 514 e gravando no MariaDB (banco "syslog", tabela logs
# no formato host/facility/priority/level/tag/date/time/program/msg, 1 partição por dia) + arquivo reserva /var/log/remoto/<IP>/<AAAA-MM-DD>.log,
# tabela de CGNAT versionada no banco (IP público + portas -> IP privado), nginx também por syslog, chrony (hora certa para a rede),
# controle Ativo/Desativado por equipamento (1/min), compactação, hash diário e retenção de 30 dias (arquivos e banco), terminal colorido.
# (14/11/2026: rsyslog substituído pelo syslog-ng — os dois não convivem no Debian; o apt remove o rsyslog sozinho.)
set -u
[ "$(id -u)" = 0 ] || { echo "rode como root"; exit 1; }
AQUI="$(cd "$(dirname "$0")" && pwd)"; SENHA="${1:-}"; COMUNIDADE="${2:-}"; MONITOR="${3:-172.20.1.5}"   # 2º parâmetro: community SNMP (só leitura); 3º: IP do Zabbix/Dude
DOMINIO="${4:-$(cat /var/lib/timelogs/dominio 2>/dev/null)}"; DOMINIO="$(printf '%s' "$DOMINIO" | tr -cd 'a-zA-Z0-9.-' | tr 'A-Z' 'a-z')"   # 4º: nome para o HTTPS (08/11/2026)
export DEBIAN_FRONTEND=noninteractive
apt-get install -y -qq nginx php-fpm php-cli php-curl php-mbstring php-mysql mariadb-server syslog-ng-core syslog-ng-mod-sql libdbd-mysql chrony apache2-utils nftables tcpdump >/dev/null || { echo "falha ao instalar pacotes"; exit 1; }
PHPV=$(ls /etc/php | sort -V | tail -1)
mkdir -p /var/www/logs /var/log/remoto /var/lib/timelogs/hash

# kernel: rajada de UDP (syslog/CGNAT) e muitos arquivos abertos
cat > /etc/sysctl.d/90-wellsystem-logs.conf <<'EOF'
# WellSystem — servidor de logs (gerado por servidor_logs_instalar.sh)
fs.file-max = 2097152
net.core.rmem_max = 16777216
net.core.rmem_default = 4194304
net.core.netdev_max_backlog = 50000
EOF
sysctl --system >/dev/null 2>&1

[ -f "$AQUI/servidor_logs_painel.php" ] && cp "$AQUI/servidor_logs_painel.php" /var/www/logs/index.php
[ -f "$AQUI/servidor_logs_ctl.php" ] && cp "$AQUI/servidor_logs_ctl.php" /var/www/logs/ctl.php
# marca do provedor (08/11/2026): logo.png (horizontal, tela de entrada) e icone.png (cabeçalho e aba) ao lado deste arquivo — o painel usa se existirem
for img in logo.png icone.png; do [ -f "$AQUI/$img" ] && cp "$AQUI/$img" /var/www/logs/$img; done
chown -R www-data:www-data /var/lib/timelogs; chmod 750 /var/lib/timelogs
chown root:www-data /var/log/remoto; chmod 2770 /var/log/remoto
chgrp -R www-data /var/log/remoto; chmod -R g+rX /var/log/remoto

# login do painel (usuário admin)
if [ -n "$SENHA" ]; then printf '%s\n' "$SENHA" | htpasswd -i -c /etc/nginx/logs.htpasswd admin >/dev/null
elif [ ! -f /etc/nginx/logs.htpasswd ]; then echo "AVISO: sem login do painel. Rode de novo com a senha:  bash $0 SENHA"; fi

# painel: as mesmas regras servem ao http (80/8086, rede interna e API do WellSystem) e ao https (443, acesso externo pelo nome)
mkdir -p /etc/nginx/snippets /var/www/acme
cat > /etc/nginx/snippets/logs-painel.conf <<EOF
# WellSystem — regras do painel de logs (gerado por servidor_logs_instalar.sh)
root /var/www/logs;
index index.php;
# login: tela propria no painel (servidor_logs_painel.php, sessao) + Basic para a API; usa a lista /etc/nginx/logs.htpasswd
location = /ctl {
    auth_basic off;
    fastcgi_pass unix:/run/php/php${PHPV}-fpm.sock;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME \$document_root/ctl.php;
}
location / { try_files \$uri \$uri/ /index.php?\$query_string; }
location ~ \.php\$ {
    fastcgi_pass unix:/run/php/php${PHPV}-fpm.sock;
    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param REMOTE_USER \$remote_user;
    fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
}
EOF
cat > /etc/nginx/sites-available/logs.conf <<EOF
# WellSystem — painel do servidor de hora e logs (gerado por servidor_logs_instalar.sh)
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    listen 8086 default_server;
    listen [::]:8086 default_server;
    server_name _;
    location ^~ /.well-known/acme-challenge/ { root /var/www/acme; default_type text/plain; }   # validação do certificado (Let's Encrypt)
    include /etc/nginx/snippets/logs-ip-*.conf;   # 17/11/2026: IP -> HTTPS no nome (só existe depois que o certificado do nome sai)
    include snippets/logs-painel.conf;
}
EOF
rm -f /etc/nginx/sites-enabled/default; ln -sf /etc/nginx/sites-available/logs.conf /etc/nginx/sites-enabled/logs.conf

# terminal colorido (padrão Wellnet em todo servidor): pasta, arquivo e executável com cores no ls/grep
cat > /etc/profile.d/wellnet-cores.sh <<'EOF'
# Wellnet: cores no terminal (diretorio, arquivo, executavel, link) para ls e grep.
if [ -n "$BASH_VERSION" ] && [ -t 1 ]; then
    command -v dircolors >/dev/null 2>&1 && eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    alias ll='ls --color=auto -lh'
    alias la='ls --color=auto -lha'
    alias grep='grep --color=auto'
fi
EOF
chmod 644 /etc/profile.d/wellnet-cores.sh
grep -q wellnet-cores /root/.bashrc 2>/dev/null || echo '[ -f /etc/profile.d/wellnet-cores.sh ] && . /etc/profile.d/wellnet-cores.sh' >> /root/.bashrc

# banco de logs (MariaDB enxuto: VM pequena e disco lento; só escuta localhost)
cat > /etc/mysql/mariadb.conf.d/60-wellnet-logs.cnf <<'EOF'
# WellSystem — servidor de logs: MariaDB enxuto (VM de ~1 GB e disco lento). Gerado por servidor_logs_instalar.sh
[mysqld]
bind-address = 127.0.0.1
skip-name-resolve
performance_schema = OFF
max_connections = 40
innodb_buffer_pool_size = 192M
innodb_log_file_size = 128M
innodb_log_buffer_size = 16M
innodb_flush_log_at_trx_commit = 2
innodb_file_per_table = ON
innodb_compression_algorithm = zlib
table_open_cache = 1200
table_definition_cache = 800
innodb_open_files = 1200
tmp_table_size = 32M
max_heap_table_size = 32M
key_buffer_size = 8M
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
EOF
systemctl enable mariadb >/dev/null 2>&1
cmp -s /etc/mysql/mariadb.conf.d/60-wellnet-logs.cnf /var/lib/timelogs/.mariadb-cnf-aplicado 2>/dev/null || { systemctl restart mariadb && cp /etc/mysql/mariadb.conf.d/60-wellnet-logs.cnf /var/lib/timelogs/.mariadb-cnf-aplicado; }
systemctl is-active --quiet mariadb || systemctl start mariadb || { echo "MariaDB não subiu"; exit 1; }

# estrutura do banco (tabelas, partições diárias, usuários, senhas em /etc/syslog-ng/wellnet-banco.conf e /etc/wellnet-logs/banco.json)
cat > /usr/local/sbin/ws-logs-banco.php <<'EOF'
#!/usr/bin/php
<?php
// WellSystem — servidor de logs: banco MariaDB "syslog" (gerado por servidor_logs_instalar.sh — não editar à mão).
// Uso (root):  ws-logs-banco.php              -> cria/repara estrutura, partições (hoje+7), retenção de 30 dias, resumo por dia, tabelas de CGNAT
//              ws-logs-banco.php importar "AAAA-MM-DD HH:MM:SS.uuuuuu"  -> copia para o banco as linhas dos arquivos /var/log/remoto ANTERIORES
//                                                                       a esse instante (história de antes do syslog-ng); não repete arquivo já importado
// PRAZO: log de equipamento serve para achar falhas: 30 dias (decisão do dono, 14/11/2026), mesma regra dos arquivos (ws-logs-manter.sh).
// O dia mais antigo sai sozinho (DROP PARTITION). EXCEÇÃO LEGAL: as linhas de autenticação do FreeRADIUS e de conexão de cliente ficam também na
// tabela logs_auth por 1 ano (Marco Civil art. 13), com um arquivo diário compactado + hash (SHA-256, imutável) em /var/log/remoto-auth.
if (PHP_SAPI !== 'cli') exit;
date_default_timezone_set('America/Recife');
const RETENCAO_DIAS = 30;        // logs de equipamento (tabela logs)
const RETENCAO_AUTH_DIAS = 396;  // autenticação do RADIUS + conexão de cliente (tabela logs_auth): Marco Civil da Internet, art. 13 — 1 ano
// linhas guardadas por 1 ano: o que o FreeRADIUS registra de cada autenticação e as linhas CONEXAO (início/fim de sessão) do WellSystem
const FILTRO_AUTH = "(program LIKE 'freeradius%' OR program = 'wellsystem-conexao')";
const DIAS_FRENTE = 7;
$B = '/var/log/remoto'; $CG = '/var/lib/timelogs/cgnat';

function db(): mysqli {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $m = new mysqli('localhost', 'root', '', '', 0, '/run/mysqld/mysqld.sock');
    $m->set_charset('utf8mb4'); $m->query("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    return $m;
}
function q(mysqli $m, string $s) { return $m->query($s); }
function um(mysqli $m, string $s) { $r = $m->query($s); $l = $r ? $r->fetch_row() : null; return $l ? $l[0] : null; }
function pnome(string $dia): string { return 'p' . str_replace('-', '', $dia); }
function prox(string $dia): string { return date('Y-m-d', strtotime("$dia +1 day")); }
function primeiro_dia_arquivo(string $B): string {
    $min = date('Y-m-d');
    foreach (glob("$B/*/????-??-??.log*") ?: [] as $f) { $d = substr(basename($f), 0, 10); if ($d < $min) $min = $d; }
    return $min;
}
function senha_de(string $arq, string $chave): string {
    $t = (string)@file_get_contents($arq);
    if ($chave === 'json') { $j = json_decode($t, true); return (string)($j['senha'] ?? ''); }
    return preg_match('/@define\s+ws_db_senha\s+"([0-9a-f]{16,})"/', $t, $m) ? $m[1] : '';
}

/** Cria uma tabela de logs no formato do SRouter (host, facility, priority, level, tag, date, time, program, pid, msg), 1 partição por dia
 *  (retenção = DROP PARTITION), a partir do dia $ini até hoje+7. Usada pela tabela logs (30 dias) e pela logs_auth (1 ano). */
function criar_logs(mysqli $m, string $tabela, string $ini): void {
    $fim = date('Y-m-d', strtotime('+' . DIAS_FRENTE . ' day'));
    $p = ["PARTITION pantigo VALUES LESS THAN ('$ini')"];
    for ($d = $ini; $d <= $fim; $d = prox($d)) $p[] = 'PARTITION ' . pnome($d) . " VALUES LESS THAN ('" . prox($d) . "')";
    $p[] = 'PARTITION pmax VALUES LESS THAN (MAXVALUE)';
        q($m, "CREATE TABLE $tabela (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            host VARCHAR(64) NULL DEFAULT '',
            facility VARCHAR(10) NULL DEFAULT '',
            priority VARCHAR(10) NULL DEFAULT '',
            level VARCHAR(10) NULL DEFAULT '',
            tag VARCHAR(10) NULL DEFAULT '',
            date DATE NOT NULL,
            time TIME NOT NULL,
            program VARCHAR(64) NULL DEFAULT '',
            pid VARCHAR(20) NULL DEFAULT '',
            msg TEXT,
            PRIMARY KEY (id, date),
            KEY host_dt (host, date, time),
            KEY program_dt (program, date, time),
            KEY dt (date, time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci PAGE_COMPRESSED=1
        PARTITION BY RANGE COLUMNS(date) (" . implode(",\n", $p) . ")");
}

/** Banco, tabelas (sempre utf8mb4_unicode_ci), usuários e arquivos de senha. Idempotente. */
function estrutura(mysqli $m, string $B): void {
    q($m, "CREATE DATABASE IF NOT EXISTS syslog CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    q($m, "USE syslog");
    if (!um($m, "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='syslog' AND TABLE_NAME='logs'")) {
        criar_logs($m, 'logs', primeiro_dia_arquivo($B));
        if (!glob("$B/*/????-??-??.log*")) historico_ok(date('Y-m-d H:i:s'));   // instalação nova: não há história em arquivo para importar
    }
    // autenticação do RADIUS + conexão de cliente: 1 ano (Marco Civil). Tabela própria; a história que já está em logs é copiada na criação.
    if (!um($m, "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='syslog' AND TABLE_NAME='logs_auth'")) {
        criar_logs($m, 'logs_auth', (string)(um($m, "SELECT MIN(date) FROM logs") ?: date('Y-m-d')));
        q($m, "INSERT INTO logs_auth (host, facility, priority, level, tag, date, time, program, pid, msg)
               SELECT host, facility, priority, level, tag, date, time, program, pid, msg FROM logs WHERE " . FILTRO_AUTH);
        echo "logs_auth criada e preenchida com o que já estava em logs (" . um($m, "SELECT COUNT(*) FROM logs_auth") . " linhas)\n";
    }
    // o syslog-ng manda campo vazio como NULL (ex.: mensagem sem PID): as colunas de texto aceitam NULL
    if (um($m, "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='syslog' AND TABLE_NAME='logs' AND COLUMN_NAME IN ('host','facility','priority','level','tag','program','pid') AND IS_NULLABLE='NO'"))
        q($m, "ALTER TABLE logs MODIFY host VARCHAR(64) NULL DEFAULT '', MODIFY facility VARCHAR(10) NULL DEFAULT '', MODIFY priority VARCHAR(10) NULL DEFAULT '', MODIFY level VARCHAR(10) NULL DEFAULT '', MODIFY tag VARCHAR(10) NULL DEFAULT '', MODIFY program VARCHAR(64) NULL DEFAULT '', MODIFY pid VARCHAR(20) NULL DEFAULT ''");
    // sessão de cliente não fica aqui (é do RADIUS/WellSystem); a tabela antiga sai
    q($m, "DROP TABLE IF EXISTS conexoes");
    try { q($m, "REVOKE ALL PRIVILEGES ON syslog.conexoes FROM 'syslogng'@'localhost'"); } catch (Throwable $e) {}   // permissão da tabela antiga
    // CGNAT determinístico, versionado: cada versão vale a partir de "vigente_desde" até a próxima
    q($m, "CREATE TABLE IF NOT EXISTS cgnat_versao (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, vigente_desde DATETIME NOT NULL, linhas INT UNSIGNED NOT NULL DEFAULT 0,
        ips_publicos INT UNSIGNED NOT NULL DEFAULT 0, arquivo VARCHAR(255) NOT NULL DEFAULT '', sha256 CHAR(64) NOT NULL DEFAULT '',
        criado_em DATETIME NOT NULL, criado_por VARCHAR(64) NOT NULL DEFAULT '', UNIQUE KEY vigente (vigente_desde)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    q($m, "CREATE TABLE IF NOT EXISTS cgnat_faixa (
        versao_id INT UNSIGNED NOT NULL, ip_publico INT UNSIGNED NOT NULL, porta_ini SMALLINT UNSIGNED NOT NULL, porta_fim SMALLINT UNSIGNED NOT NULL,
        ip_privado INT UNSIGNED NOT NULL, PRIMARY KEY (versao_id, ip_publico, porta_ini), KEY privado (versao_id, ip_privado)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    q($m, "ALTER TABLE cgnat_versao ADD COLUMN IF NOT EXISTS arquivo_gz MEDIUMBLOB NULL");   // o arquivo original da tabela (compactado), para baixar
    // resumo por dia e equipamento (tela Armazenamento): total, erros e avisos; o dia de hoje a tela conta ao vivo
    q($m, "CREATE TABLE IF NOT EXISTS resumo_dia (
        date DATE NOT NULL, host VARCHAR(64) NOT NULL, n INT UNSIGNED NOT NULL DEFAULT 0, erros INT UNSIGNED NULL, avisos INT UNSIGNED NULL,   -- NULL = dia sem nível gravado (histórico importado dos arquivos)
        
        PRIMARY KEY (date, host)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    q($m, "ALTER TABLE resumo_dia MODIFY erros INT UNSIGNED NULL, MODIFY avisos INT UNSIGNED NULL");
    q($m, "CREATE TABLE IF NOT EXISTS importacao (
        arquivo VARCHAR(255) NOT NULL PRIMARY KEY, linhas INT UNSIGNED NOT NULL, ate VARCHAR(40) NOT NULL, em DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    q($m, "ALTER TABLE importacao DROP COLUMN IF EXISTS conexoes");

    // usuários: syslogng (só grava logs) e painel (lê tudo; grava só a tabela de CGNAT)
    @mkdir('/etc/wellnet-logs', 0750, true);
    $sSng = senha_de('/etc/syslog-ng/wellnet-banco.conf', 'sng') ?: bin2hex(random_bytes(16));
    $sPai = senha_de('/etc/wellnet-logs/banco.json', 'json') ?: bin2hex(random_bytes(16));
    foreach (['syslogng' => $sSng, 'painel' => $sPai] as $u => $s) {
        q($m, "CREATE USER IF NOT EXISTS '$u'@'localhost' IDENTIFIED BY '$s'");
        q($m, "ALTER USER '$u'@'localhost' IDENTIFIED BY '$s'");
    }
    q($m, "GRANT SELECT, INSERT ON syslog.logs TO 'syslogng'@'localhost'");
    q($m, "GRANT SELECT, INSERT ON syslog.logs_auth TO 'syslogng'@'localhost'");
    q($m, "GRANT SELECT ON syslog.* TO 'painel'@'localhost'");
    q($m, "GRANT INSERT ON syslog.cgnat_versao TO 'painel'@'localhost'");
    q($m, "GRANT INSERT ON syslog.cgnat_faixa TO 'painel'@'localhost'");
    $ip = trim((string)@shell_exec("ip -4 -o route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \\([0-9.]*\\).*/\\1/p'")) ?: '127.0.0.1';
    $conf = "# WellSystem — senha do banco para o syslog-ng (gerado por ws-logs-banco.php; só root lê)\n@define ws_db_senha \"$sSng\"\n@define ws_ip_local \"$ip\"\n";
    if ((string)@file_get_contents('/etc/syslog-ng/wellnet-banco.conf') !== $conf) { @mkdir('/etc/syslog-ng', 0755, true); file_put_contents('/etc/syslog-ng/wellnet-banco.conf', $conf); }
    chmod('/etc/syslog-ng/wellnet-banco.conf', 0600);
    file_put_contents('/etc/wellnet-logs/banco.json', json_encode(['usuario' => 'painel', 'senha' => $sPai, 'banco' => 'syslog', 'ip_local' => $ip]));
    chmod('/etc/wellnet-logs/banco.json', 0640); @chgrp('/etc/wellnet-logs/banco.json', 'www-data'); @chgrp('/etc/wellnet-logs', 'www-data');
}

/** Garante partição de cada dia até hoje+7 (tirando de pmax) e apaga as que passaram do prazo da tabela (logs = 30 dias; logs_auth = 1 ano). */
function particoes(mysqli $m, string $tabela = 'logs', int $retencao = RETENCAO_DIAS): void {
    q($m, "USE syslog");
    $r = $m->query("SELECT PARTITION_NAME FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA='syslog' AND TABLE_NAME='$tabela' AND PARTITION_NAME REGEXP '^p[0-9]{8}$' ORDER BY PARTITION_NAME");
    $dias = []; while ($l = $r->fetch_row()) $dias[] = substr($l[0], 1, 4) . '-' . substr($l[0], 5, 2) . '-' . substr($l[0], 7, 2);
    $ult = $dias ? end($dias) : date('Y-m-d', strtotime('-1 day')); $alvo = date('Y-m-d', strtotime('+' . DIAS_FRENTE . ' day'));
    $novas = [];
    for ($d = prox($ult); $d <= $alvo; $d = prox($d)) $novas[] = 'PARTITION ' . pnome($d) . " VALUES LESS THAN ('" . prox($d) . "')";
    if ($novas) q($m, "ALTER TABLE $tabela REORGANIZE PARTITION pmax INTO (" . implode(', ', $novas) . ", PARTITION pmax VALUES LESS THAN (MAXVALUE))");
    $limite = date('Y-m-d', strtotime('-' . $retencao . ' day'));
    foreach ($dias as $d) if ($d < $limite) { q($m, "ALTER TABLE $tabela DROP PARTITION " . pnome($d)); echo "$tabela: apagado (prazo de $retencao dias): $d\n"; }
    // pantigo guarda o que for anterior à 1ª partição diária; quando o limite passa dela, é esvaziada (a partição continua, vazia)
    $lim1 = um($m, "SELECT PARTITION_DESCRIPTION FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA='syslog' AND TABLE_NAME='$tabela' AND PARTITION_NAME='pantigo'");
    if ($lim1 && trim($lim1, "'") <= $limite && um($m, "SELECT 1 FROM $tabela PARTITION (pantigo) LIMIT 1")) q($m, "ALTER TABLE $tabela TRUNCATE PARTITION pantigo");
    if ($tabela === 'logs') q($m, "DELETE FROM resumo_dia WHERE date < '$limite'");
    q($m, "ANALYZE TABLE $tabela");   // estatística dos índices em dia (o volume muda todo dia)
}

/** Tabela de CGNAT (estática; só muda se o dono alterar e cadastrar outra versão). Importa /var/lib/timelogs/cgnat/AAAAMMDDHHMM.txt
 *  ("IP_PUBLICO PORTA_INI-PORTA_FIM IP_PRIVADO") para o banco, guarda o ARQUIVO ORIGINAL (compactado) para baixar na tela e só então tira o arquivo do disco. */
function cgnat(mysqli $m, string $CG): void {
    q($m, "USE syslog");
    foreach (glob("$CG/*.txt") ?: [] as $f) {
        if (!preg_match('/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})\.txt$/', $f, $x)) continue;
        $desde = "$x[1]-$x[2]-$x[3] $x[4]:$x[5]:00";
        $conteudo = (string)file_get_contents($f); $sha = hash('sha256', $conteudo); $gz = gzencode($conteudo, 9);
        $id = um($m, "SELECT id FROM cgnat_versao WHERE vigente_desde='$desde'");
        if (!$id) {
            $vals = []; $pubs = [];
            foreach (preg_split('/\r\n|\r|\n/', $conteudo) as $l) {
                $p = preg_split('/[\s;,]+/', trim(preg_replace('/#.*/', '', $l)));
                if (count($p) !== 3 || !preg_match('/^(\d{1,5})-(\d{1,5})$/', $p[1], $pp) || ip2long($p[0]) === false || ip2long($p[2]) === false) continue;
                $vals[] = sprintf('(%%V%%,%u,%d,%d,%u)', ip2long($p[0]), (int)$pp[1], (int)$pp[2], ip2long($p[2])); $pubs[$p[0]] = 1;
            }
            if (!$vals) continue;
            $m->begin_transaction();
            $st = $m->prepare("INSERT INTO cgnat_versao (vigente_desde, linhas, ips_publicos, arquivo, sha256, criado_em, criado_por, arquivo_gz) VALUES (?, ?, ?, ?, ?, NOW(), 'arquivo', ?)");
            $n = count($vals); $np = count($pubs); $nome = basename($f);
            $st->bind_param('siisss', $desde, $n, $np, $nome, $sha, $gz); $st->execute();
            $id = $m->insert_id;
            foreach (array_chunk($vals, 1000) as $lote) q($m, 'INSERT INTO cgnat_faixa (versao_id, ip_publico, porta_ini, porta_fim, ip_privado) VALUES ' . str_replace('%V%', (string)$id, implode(',', $lote)));
            $m->commit();
            echo "CGNAT: versão vigente desde $desde gravada no banco ($n faixas)\n";
        } else {
            $st = $m->prepare("UPDATE cgnat_versao SET arquivo_gz = ? WHERE id = ? AND arquivo_gz IS NULL AND sha256 = ?");
            $idn = (int)$id; $st->bind_param('sis', $gz, $idn, $sha); $st->execute();
        }
        // só tira o arquivo do disco depois de conferir que o banco guardou exatamente o mesmo conteúdo
        $guard = um($m, "SELECT sha256 FROM cgnat_versao WHERE vigente_desde='$desde' AND arquivo_gz IS NOT NULL");
        if ($guard === $sha) { @unlink($f); echo "CGNAT: $desde guardada no banco (arquivo para baixar); cópia em disco removida\n"; }
    }
}

/** Resumo por dia e equipamento (total, erros, avisos) dos últimos 30 dias, para a tela Armazenamento: calcula os dias fechados que faltam
 *  (um dia = uma leitura da partição). Hoje fica de fora: a tela conta ao vivo. */
function resumo(mysqli $m): void {
    q($m, "USE syslog");
    for ($k = RETENCAO_DIAS; $k >= 1; $k--) {
        $dia = date('Y-m-d', strtotime("-$k day"));
        if ($k > 1 && um($m, "SELECT 1 FROM resumo_dia WHERE date='$dia' LIMIT 1")) continue;   // ontem recalcula (fecha o dia); os mais velhos só se faltar
        if (!um($m, "SELECT 1 FROM logs WHERE date='$dia' LIMIT 1")) continue;
        q($m, "INSERT INTO resumo_dia (date, host, n, erros, avisos)
               SELECT date, host, COUNT(*), IF(SUM(priority <> '') = 0, NULL, SUM(priority IN ('emerg','alert','crit','err','error'))), IF(SUM(priority <> '') = 0, NULL, SUM(priority IN ('warning','warn')))
               FROM logs WHERE date='$dia' GROUP BY date, host
               ON DUPLICATE KEY UPDATE n=VALUES(n), erros=VALUES(erros), avisos=VALUES(avisos)");
        echo "resumo do dia $dia gravado\n";
    }
}

/** Arquivo diário das linhas de autenticação/conexão: /var/log/remoto-auth/AAAA-MM-DD.log.gz + manifesto SHA-256 (440, imutável) em
 *  /var/lib/timelogs/hash-auth. Só dias fechados; 1 ano. Mesma prova de integridade que os arquivos de log tinham antes. */
function exportar_auth(mysqli $m): void {
    q($m, "USE syslog"); $dir = '/var/log/remoto-auth'; $hdir = '/var/lib/timelogs/hash-auth';
    @mkdir($dir, 0750, true); @mkdir($hdir, 0750, true); @chgrp($dir, 'www-data'); @chgrp($hdir, 'www-data');
    for ($k = RETENCAO_AUTH_DIAS; $k >= 1; $k--) {
        $dia = date('Y-m-d', strtotime("-$k day")); $f = "$dir/$dia.log.gz"; $h = "$hdir/$dia.sha256";
        if (is_file($f) && is_file($h)) continue;
        if (!um($m, "SELECT 1 FROM logs_auth WHERE date='$dia' LIMIT 1")) continue;
        $tmp = "$f.tmp"; $gz = gzopen($tmp, 'wb9'); $n = 0;
        $r = $m->query("SELECT time, host, program, pid, msg FROM logs_auth WHERE date='$dia' ORDER BY time, id", MYSQLI_USE_RESULT);
        while ($x = $r->fetch_assoc()) { gzwrite($gz, "$dia $x[time] $x[host] " . ($x['program'] !== '' ? $x['program'] . ($x['pid'] !== '' ? "[$x[pid]]" : '') . ': ' : '') . $x['msg'] . "\n"); $n++; }
        $r->free(); gzclose($gz); rename($tmp, $f); chmod($f, 0640); @chgrp($f, 'www-data');
        file_put_contents($h, hash_file('sha256', $f) . "  $f\n"); chmod($h, 0440);
        @exec('chattr +i ' . escapeshellarg($f) . ' ' . escapeshellarg($h) . ' 2>/dev/null');
        echo "autenticação $dia: $n linhas -> $f (hash gravado)\n";
    }
    $lim = date('Y-m-d', strtotime('-' . RETENCAO_AUTH_DIAS . ' day'));
    foreach (glob("$dir/????-??-??.log.gz") ?: [] as $f) { $d = substr(basename($f), 0, 10); if ($d < $lim) { @exec('chattr -i ' . escapeshellarg($f) . " $hdir/$d.sha256 2>/dev/null"); @unlink($f); @unlink("$hdir/$d.sha256"); echo "autenticação: arquivo de $d apagado (1 ano)\n"; } }
}

/** Marca que o banco já tem a história inteira dos arquivos: só então o painel busca no banco em vez dos arquivos. */
function historico_ok(string $ate): void {
    @mkdir('/etc/wellnet-logs', 0750, true);
    file_put_contents('/etc/wellnet-logs/historico.json', json_encode(['ate' => $ate, 'em' => date('c')]));
    chmod('/etc/wellnet-logs/historico.json', 0640); @chgrp('/etc/wellnet-logs/historico.json', 'www-data');
}
/** Copia para o banco as linhas dos arquivos ANTES de $ate (história anterior ao syslog-ng). Facility/nível não existem no arquivo: ficam vazios. */
function importar(mysqli $m, string $B, string $ate): void {
    q($m, "USE syslog"); q($m, "SET SESSION sql_mode=''"); q($m, "SET SESSION unique_checks=0");
    $diaAte = substr($ate, 0, 10);
    $arqs = glob("$B/*/????-??-??.log*") ?: []; sort($arqs);
    foreach ($arqs as $f) {
        $dia = substr(basename($f), 0, 10); if ($dia > $diaAte) continue;
        $chave = $m->real_escape_string(basename(dirname($f)) . '/' . $dia);   // host/dia: o .log de hoje vira .log.gz amanhã e não pode ser importado de novo
        if (um($m, "SELECT 1 FROM importacao WHERE arquivo='$chave'")) continue;
        $fh = substr($f, -3) === '.gz' ? gzopen($f, 'rb') : fopen($f, 'rb'); if (!$fh) continue;
        $lote = []; $n = 0;
        $grava = function () use ($m, &$lote) {
            if ($lote) { q($m, 'INSERT INTO logs (host, facility, priority, level, tag, date, time, program, pid, msg) VALUES ' . implode(',', $lote)); $lote = []; }
        };
        $m->begin_transaction();
        while (($l = (substr($f, -3) === '.gz' ? gzgets($fh) : fgets($fh))) !== false) {
            $l = ltrim(rtrim($l, "\r\n"), "\0"); if ($l === '') continue;   // bytes nulos no começo = sobra de desligamento brusco; a linha vale
            $p = explode(' ', $l, 3); if (count($p) < 2 || !preg_match('/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})(\.\d+)?/', $p[0], $t)) continue;
            $ts = $t[1] . ' ' . $t[2] . ($t[3] ?? ''); if (strcmp($ts, $ate) >= 0) continue;   // dali em diante quem gravou foi o syslog-ng
            $resto = $p[2] ?? ''; $prog = ''; $pid = ''; $msg = $resto;
            if (preg_match('/^([^\s\[\]:]{1,64})(?:\[([^\]]{0,20})\])?: ?(.*)$/s', $resto, $g)) { $prog = $g[1]; $pid = $g[2] ?? ''; $msg = $g[3]; }
            $e = fn($v) => "'" . $m->real_escape_string((string)$v) . "'";
            $lote[] = '(' . $e($p[1]) . ",'','','',''," . $e($t[1]) . ',' . $e($t[2]) . ',' . $e($prog) . ',' . $e($pid) . ',' . $e($msg) . ')'; $n++;
            if (count($lote) >= 1000) $grava();
        }
        $grava();
        q($m, "INSERT INTO importacao (arquivo, linhas, ate, em) VALUES ('$chave', $n, " . "'" . $m->real_escape_string($ate) . "', NOW())");
        $m->commit();
        substr($f, -3) === '.gz' ? gzclose($fh) : fclose($fh);
        echo "importado: $f ($n linhas)\n";
    }
    historico_ok($ate);
}

$m = db();
$cmd = $argv[1] ?? '';
if ($cmd === 'importar') {
    $ate = (string)($argv[2] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(\.\d+)?$/', $ate)) { fwrite(STDERR, "informe o instante: \"AAAA-MM-DD HH:MM:SS.uuuuuu\"\n"); exit(1); }
    importar($m, $B, $ate); exit(0);
}
estrutura($m, $B);
particoes($m);
particoes($m, 'logs_auth', RETENCAO_AUTH_DIAS);
cgnat($m, $CG);
resumo($m);
exportar_auth($m);
EOF
chmod 750 /usr/local/sbin/ws-logs-banco.php
/usr/bin/php /usr/local/sbin/ws-logs-banco.php || { echo "falha ao montar o banco de logs"; exit 1; }

# recepção dos logs: syslog-ng em UDP e TCP 514 (switch e roteador mandam em UDP; servidores com fila mandam em TCP) -> banco + arquivo reserva
mkdir -p /etc/syslog-ng/conf.d /var/lib/syslog-ng
[ -f /etc/syslog-ng/wellnet-bloqueados.conf ] || printf '%s\n' '# WellSystem — gerado por ws-logs-aplicar.php (não editar à mão)' '# nenhum equipamento desativado' 'filter f_ws_permitido { not netmask("255.255.255.255/32"); };' > /etc/syslog-ng/wellnet-bloqueados.conf
cat > /etc/syslog-ng/conf.d/wellnet.conf <<'EOF'
# WellSystem — servidor de logs: recebe syslog (UDP/TCP 514) e grava no banco MariaDB "syslog" (tabela logs) + arquivo reserva
# /var/log/remoto/<IP>/<AAAA-MM-DD>.log. Gerado por servidor_logs_instalar.sh — não editar à mão.
@include "/etc/syslog-ng/wellnet-banco.conf"
@include "/etc/syslog-ng/wellnet-bloqueados.conf"

# Equipamentos da rede: host = IP de origem; data/hora = hora em que ESTE servidor recebeu (hora certa pelo chrony), não a do equipamento.
source s_ws_rede {
    network(transport("udp") port(514) so-rcvbuf(16777216) keep-hostname(no) keep-timestamp(no) flags(no-multi-line));
    network(transport("tcp") port(514) max-connections(500) log-iw-size(50000) keep-hostname(no) keep-timestamp(no) flags(no-multi-line));
};
# nginx deste servidor (access/error) por syslog local
source s_ws_nginx { network(ip("127.0.0.1") transport("udp") port(5141) keep-timestamp(no)); };
rewrite r_ws_local { set("`ws_ip_local`" value("HOST")); };

destination d_ws_arquivo {
    file("/var/log/remoto/${HOST}/${S_YEAR}-${S_MONTH}-${S_DAY}.log"
         template("${S_ISODATE} ${HOST} ${MSGHDR}${MSG}\n") frac-digits(6)
         create-dirs(yes) dir-owner("root") dir-group("www-data") dir-perm(02750) owner("root") group("www-data") perm(0640));
};
destination d_ws_logs {
    sql(type(mysql) host("localhost") username("syslogng") password("`ws_db_senha`") database("syslog") table("logs")
        columns("host", "facility", "priority", "level", "tag", "date", "time", "program", "pid", "msg")
        values("${HOST}", "${FACILITY}", "${PRIORITY}", "${LEVEL}", "${TAG}", "${S_YEAR}-${S_MONTH}-${S_DAY}", "${S_HOUR}:${S_MIN}:${S_SEC}", "${PROGRAM}", "${PID}", "${MSG}")
        indexes() flags(explicit-commits) batch-lines(500) batch-timeout(1000) retries(5) time-reopen(10)
        session-statements("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci", "SET SESSION sql_mode=''")
        disk-buffer(reliable(yes) capacity-bytes(2GiB) dir("/var/lib/syslog-ng")));
};
# autenticação do FreeRADIUS e linhas CONEXAO do WellSystem: também na tabela logs_auth, que guarda 1 ano (Marco Civil da Internet, art. 13)
filter f_ws_auth { program("^freeradius") or program("^wellsystem-conexao$"); };
destination d_ws_auth {
    sql(type(mysql) host("localhost") username("syslogng") password("`ws_db_senha`") database("syslog") table("logs_auth")
        columns("host", "facility", "priority", "level", "tag", "date", "time", "program", "pid", "msg")
        values("${HOST}", "${FACILITY}", "${PRIORITY}", "${LEVEL}", "${TAG}", "${S_YEAR}-${S_MONTH}-${S_DAY}", "${S_HOUR}:${S_MIN}:${S_SEC}", "${PROGRAM}", "${PID}", "${MSG}")
        indexes() flags(explicit-commits) batch-lines(500) batch-timeout(1000) retries(5) time-reopen(10)
        session-statements("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci", "SET SESSION sql_mode=''")
        disk-buffer(reliable(yes) capacity-bytes(2GiB) dir("/var/lib/syslog-ng")));
};
log {
    source(s_ws_rede);
    filter(f_ws_permitido);
    log { destination(d_ws_arquivo); };
    log { destination(d_ws_logs); };
    log { filter(f_ws_auth); destination(d_ws_auth); };
    flags(final);
};
log {
    source(s_ws_nginx);
    rewrite(r_ws_local);
    log { destination(d_ws_arquivo); };
    log { destination(d_ws_logs); };
    flags(final);
};
EOF
chmod 600 /etc/syslog-ng/conf.d/wellnet.conf
# o rsyslog saiu (conflita com o syslog-ng): as regras antigas dele não servem mais
dpkg -s rsyslog >/dev/null 2>&1 || rm -f /etc/rsyslog.d/90-wellsystem-recebe.conf /etc/rsyslog.d/05-wellsystem-bloqueados.conf
# o próprio servidor aparece na tela de Log (nginx) com nome
php -r '$f="/var/lib/timelogs/nomes.json"; $c=json_decode((string)@file_get_contents("/etc/wellnet-logs/banco.json"),true); $ip=$c["ip_local"]??""; $n=json_decode((string)@file_get_contents($f),true); $n=is_array($n)?$n:[]; if($ip!==""&&!isset($n[$ip])){$n[$ip]=["nome"=>"Servidor de Log (este)","tipo"=>"Servidor"]; file_put_contents($f,json_encode($n,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));}'
chown www-data:www-data /var/lib/timelogs/nomes.json 2>/dev/null

# nginx deste servidor também vai para o syslog -> banco
cat > /etc/nginx/conf.d/ws-syslog.conf <<'EOF'
# WellSystem — o nginx deste servidor também manda access/error para o syslog-ng (porta local 5141) -> banco de logs (gerado por servidor_logs_instalar.sh)
# Os arquivos /var/log/nginx continuam. A atualização "ao vivo" da tela de Log (?vivo=1, a cada 3 s) não entra, para não encher o banco.
map $arg_vivo $ws_syslog_acesso { default 1; "1" 0; }
access_log syslog:server=127.0.0.1:5141,facility=local7,tag=nginx,severity=info combined if=$ws_syslog_acesso;
error_log /var/log/nginx/error.log;
error_log syslog:server=127.0.0.1:5141,facility=local7,tag=nginx_error warn;
EOF

# controle Ativo/Desativado: IP desativado no painel = o servidor descarta o log dele (vale para qualquer equipamento; filtro do syslog-ng)
cat > /usr/local/sbin/ws-logs-aplicar.php <<'EOF'
#!/usr/bin/php
<?php
// Lê /var/lib/timelogs/controle.json (gravado pelo painel) e descarta no syslog-ng o log dos IPs desativados.
// Só mexe quando a lista muda; configuração recusada = volta a anterior.
if (PHP_SAPI !== 'cli') exit;
$ctl = json_decode((string)@file_get_contents('/var/lib/timelogs/controle.json'), true); $ctl = is_array($ctl) ? $ctl : [];
$ips = [];
foreach ($ctl as $ip => $c) if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && ($c['envio'] ?? '') === 'desligado') $ips[] = $ip;
sort($ips);

// syslog-ng
$f = '/etc/syslog-ng/wellnet-bloqueados.conf';
if (is_dir('/etc/syslog-ng')) {
    $l = ['# WellSystem — gerado por ws-logs-aplicar.php (não editar à mão)', $ips ? '# equipamentos desativados: ' . implode(', ', $ips) : '# nenhum equipamento desativado'];
    $l[] = $ips ? 'filter f_ws_permitido { not (' . implode(' or ', array_map(fn($i) => "netmask(\"$i/32\")", $ips)) . '); };' : 'filter f_ws_permitido { not netmask("255.255.255.255/32"); };';
    $novo = implode("\n", $l) . "\n"; $ant = (string)@file_get_contents($f);
    if ($ant !== $novo) {
        file_put_contents($f, $novo);
        exec('/usr/sbin/syslog-ng --syntax-only 2>&1', $o, $rc);
        if ($rc !== 0) file_put_contents($f, $ant !== '' ? $ant : "filter f_ws_permitido { not netmask(\"255.255.255.255/32\"); };\n");
        elseif (trim((string)shell_exec('systemctl is-active syslog-ng 2>/dev/null')) === 'active') exec('/usr/sbin/syslog-ng-ctl reload 2>&1');
    }
}

EOF
chmod 750 /usr/local/sbin/ws-logs-aplicar.php

# manutenção diária: compacta os dias fechados, assina (sha256) e apaga só o que passou do prazo da lei
cat > /usr/local/sbin/ws-logs-manter.sh <<'EOF'
#!/bin/bash
# WellSystem — compacta dias fechados, grava o hash (prova de que o arquivo não mudou) e apaga o dia mais antigo quando passa do prazo (30 dias).
# PRAZO: log de equipamento serve para achar falhas: 30 dias (decisão do dono, 14/11/2026); o dia mais antigo sai sozinho. Sessão de cliente (1 ano) é do RADIUS/WellSystem.
RETENCAO_DIAS=30
B=/var/log/remoto; H=/var/lib/timelogs/hash; HOJE=$(date +%F); LIMITE=$(date -d "-${RETENCAO_DIAS} days" +%F); mkdir -p "$H"
for f in "$B"/*/????-??-??.log; do [ -f "$f" ] || continue; d=$(basename "$f" .log); [ "$d" \< "$HOJE" ] && gzip -f "$f"; done
for dia in $(ls "$B"/*/ 2>/dev/null | grep -E '^[0-9]{4}-[0-9]{2}-[0-9]{2}\.log\.gz$' | sed 's/\.log\.gz//' | sort -u); do
    if [ ! -f "$H/$dia.sha256" ]; then   # manifesto do dia: só leitura (440, dono root) e imutável (chattr +i); os .gz do dia também ficam imutáveis
        sha256sum "$B"/*/"$dia".log.gz > "$H/$dia.sha256" 2>/dev/null && chown root:www-data "$H/$dia.sha256" && chmod 440 "$H/$dia.sha256" && chattr +i "$H/$dia.sha256" "$B"/*/"$dia".log.gz 2>/dev/null
    fi
done
for f in "$B"/*/????-??-??.log.gz "$B"/*/????-??-??.log "$H"/????-??-??.sha256; do [ -f "$f" ] || continue; d=$(basename "$f"); d=${d:0:10}; [ "$d" \< "$LIMITE" ] && { chattr -i "$f" 2>/dev/null; rm -f "$f"; }; done
find "$B" -mindepth 1 -maxdepth 1 -type d -empty -mtime +${RETENCAO_DIAS} -exec rmdir {} \; 2>/dev/null
chgrp -R www-data "$B"; chmod -R g+rX "$B"
EOF
chmod 750 /usr/local/sbin/ws-logs-manter.sh
printf '* * * * * root /usr/bin/php /usr/local/sbin/ws-logs-aplicar.php >/dev/null 2>&1\n15 3 * * * root /usr/local/sbin/ws-logs-manter.sh >/dev/null 2>&1\n25 3 * * * root /usr/bin/php /usr/local/sbin/ws-logs-banco.php >/dev/null 2>&1\n' > /etc/cron.d/ws-logs; chmod 644 /etc/cron.d/ws-logs

# hora certa para a rede (NTP.br; serve UDP 123)
mkdir -p /etc/chrony/conf.d
cat > /etc/chrony/conf.d/wellsystem-servidor.conf <<'EOF'
# WellSystem — hora oficial (NTP.br) entregue à rede (gerado por servidor_logs_instalar.sh)
server a.st1.ntp.br iburst
server b.st1.ntp.br iburst
server c.st1.ntp.br iburst
allow
ratelimit interval 1 burst 16
makestep 1.0 3
EOF

# guarda do chrony (16/11/2026): em 15/11 o chrony ficou ~1 h ativo e com a hora certa, mas com TODAS as fontes em "waiting update" (nenhuma ^* ou ^+),
# e o painel marcou "Hora certa" como parada. Se ficar 15 min sem fonte selecionada, reinicia o chrony (no máximo 1 vez a cada 30 min) e registra no syslog.
cat > /usr/local/sbin/ws-chrony-guarda.sh <<'EOFGUARDA'
#!/bin/bash
# WellSystem — guarda do chrony (gerado por servidor_logs_instalar.sh; cron a cada 5 min)
E="${WS_GUARDA_DIR:-/run/ws-chrony-guarda}"; mkdir -p "$E"
agora=$(date +%s)
if ! systemctl is-active --quiet chrony; then logger -t ws-chrony-guarda "chrony parado: iniciando"; systemctl start chrony; rm -f "$E/sem"; exit 0; fi
if chronyc sources 2>/dev/null | grep -q '^\^[*+]'; then rm -f "$E/sem"; exit 0; fi      # há fonte selecionada: tudo certo
[ -f "$E/sem" ] || echo "$agora" > "$E/sem"
ini=$(cat "$E/sem" 2>/dev/null || echo "$agora")
[ $((agora - ini)) -ge 900 ] || exit 0                                                  # menos de 15 min sem fonte: espera
ult=$(cat "$E/ult" 2>/dev/null || echo 0)
[ $((agora - ult)) -ge 1800 ] || exit 0                                                 # já reiniciou há menos de 30 min: não insiste
logger -t ws-chrony-guarda "sem fonte selecionada ha $((agora - ini)) s: reiniciando o chrony"
systemctl restart chrony; echo "$agora" > "$E/ult"; rm -f "$E/sem"
EOFGUARDA
chmod 750 /usr/local/sbin/ws-chrony-guarda.sh
printf '*/5 * * * * root /usr/local/sbin/ws-chrony-guarda.sh >/dev/null 2>&1\n' > /etc/cron.d/ws-chrony-guarda; chmod 644 /etc/cron.d/ws-chrony-guarda

# firewall: recebimento de log (514) e hora (123) só das redes internas e do bloco público do provedor — ninguém de fora forja registro.
# Painel (80/8086) e SSH ficam como estão (protegidos por login/chave). Equipamento com IP fora da lista: acrescentar em "liberados" e rodar: systemctl reload nftables
cat > /etc/nftables.conf <<'EOF'
#!/usr/sbin/nft -f
# WellSystem — gerado por servidor_logs_instalar.sh
table inet wellsystem
delete table inet wellsystem
table inet wellsystem {
    set liberados { type ipv4_addr; flags interval; elements = { 127.0.0.0/8, 10.0.0.0/8, 100.64.0.0/10, 172.16.0.0/12, 192.168.0.0/16, 138.0.60.0/22 } }
    chain entrada {
        type filter hook input priority 0; policy accept;
        ip saddr @liberados accept
        ip6 saddr ::1 accept
        tcp dport 514 drop
        udp dport { 514, 123 } drop
    }
}
EOF
nft -c -f /etc/nftables.conf || { echo "nftables recusou a configuração"; exit 1; }
systemctl enable nftables >/dev/null 2>&1; systemctl restart nftables
rm -f /root/.logs_painel_senha_atual

# SNMP somente leitura para o Zabbix/Dude (a community vem do parâmetro, nunca do código)
if [ -n "$COMUNIDADE" ]; then
    apt-get install -y -qq snmpd snmp >/dev/null 2>&1
    cat > /etc/snmp/snmpd.conf <<EOF
# WellSystem — SNMP somente leitura (gerado por servidor_logs_instalar.sh); responde só ao monitoramento e ao próprio servidor
agentaddress udp:161,udp6:[::1]:161
sysLocation Central TI
sysContact suporte@wellnet.com.br
sysServices 72
rocommunity $COMUNIDADE 127.0.0.1
rocommunity $COMUNIDADE $MONITOR
EOF
    chmod 600 /etc/snmp/snmpd.conf; systemctl enable snmpd >/dev/null 2>&1; systemctl restart snmpd
fi

# HTTPS pelo nome (08/11/2026): certificado Let's Encrypt (validação pela porta 80) que renova sozinho (certbot.timer, 2x/dia) e recarrega o nginx.
# O http interno (80/8086) continua igual — o WellSystem e os equipamentos usam ele pela rede interna.
rm -f /etc/nginx/sites-enabled/logs-ssl.conf
if [ -n "$DOMINIO" ]; then
    echo "$DOMINIO" > /var/lib/timelogs/dominio
    apt-get install -y -qq certbot >/dev/null 2>&1 || echo "AVISO: não consegui instalar o certbot"
    mkdir -p /etc/letsencrypt/renewal-hooks/deploy
    printf '#!/bin/sh\n# WellSystem — recarrega o nginx quando o certificado renova (gerado por servidor_logs_instalar.sh)\nsystemctl reload nginx\n' > /etc/letsencrypt/renewal-hooks/deploy/ws-nginx-reload.sh
    chmod 755 /etc/letsencrypt/renewal-hooks/deploy/ws-nginx-reload.sh
    if [ ! -f "/etc/letsencrypt/live/$DOMINIO/fullchain.pem" ] && command -v certbot >/dev/null; then
        nginx -t >/dev/null 2>&1 && { systemctl reload nginx 2>/dev/null || systemctl restart nginx; }
        certbot certonly --webroot -w /var/www/acme -d "$DOMINIO" --non-interactive --agree-tos -m suporte@wellnet.com.br --no-eff-email -q \
            || echo "AVISO: o certificado de $DOMINIO ainda não saiu — confira se o nome aponta para o IP público e se as portas 80 e 443 chegam até esta VM; depois rode este instalador de novo"
    fi
    if [ -f "/etc/letsencrypt/live/$DOMINIO/fullchain.pem" ]; then
        # 17/11/2026 (dono): quem digita o IP (de fora ou de dentro) cai em HTTPS no NOME (o certificado só vale para o nome); a API do ERP (?api=1) segue direta
        cat > /etc/nginx/snippets/logs-ip-https.conf <<EOF
set \$wn_ip 1;
if (\$arg_api) { set \$wn_ip 0; }
if (\$wn_ip) { return 301 https://$DOMINIO\$request_uri; }
EOF
        cat > /etc/nginx/sites-available/logs-ssl.conf <<EOF
# WellSystem — painel de logs por HTTPS (gerado por servidor_logs_instalar.sh)
server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    server_name _;
    ssl_certificate /etc/letsencrypt/live/$DOMINIO/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMINIO/privkey.pem;
    return 301 https://$DOMINIO\$request_uri;   # IP -> nome
}
server {
    listen 80;
    listen [::]:80;
    server_name $DOMINIO;
    location ^~ /.well-known/acme-challenge/ { root /var/www/acme; default_type text/plain; }
    location / { return 301 https://\$host\$request_uri; }
}
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name $DOMINIO;
    ssl_certificate /etc/letsencrypt/live/$DOMINIO/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMINIO/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    add_header Strict-Transport-Security "max-age=31536000" always;
    include snippets/logs-painel.conf;
}
EOF
        ln -sf /etc/nginx/sites-available/logs-ssl.conf /etc/nginx/sites-enabled/logs-ssl.conf
    fi
    systemctl enable --now certbot.timer >/dev/null 2>&1
    # enquanto o certificado não existe, tenta 1x/hora sozinho (só o certbot; o instalador roda de novo apenas quando o certificado sair, para ligar o https)
    [ "$(readlink -f "$0")" != /usr/local/sbin/ws-logs-instalar.sh ] && cp "$0" /usr/local/sbin/ws-logs-instalar.sh && chmod 750 /usr/local/sbin/ws-logs-instalar.sh
    printf '%s\n' '# WellSystem — 1a emissão do certificado do painel de logs (gerado por servidor_logs_instalar.sh)' \
      '23 * * * * root D=$(cat /var/lib/timelogs/dominio 2>/dev/null); [ -n "$D" ] && [ ! -f /etc/letsencrypt/live/$D/fullchain.pem ] && certbot certonly --webroot -w /var/www/acme -d "$D" --non-interactive --agree-tos -m suporte@wellnet.com.br --no-eff-email -q && bash /usr/local/sbin/ws-logs-instalar.sh "" "" "" >/dev/null 2>&1' \
      > /etc/cron.d/ws-logs-https; chmod 644 /etc/cron.d/ws-logs-https
fi

/usr/sbin/syslog-ng --syntax-only >/dev/null 2>&1 || { echo "syslog-ng recusou a configuração"; exit 1; }
nginx -t >/dev/null 2>&1 || { echo "nginx recusou a configuração"; exit 1; }
systemctl enable nginx "php${PHPV}-fpm" syslog-ng mariadb chrony >/dev/null 2>&1
systemctl restart "php${PHPV}-fpm" syslog-ng chrony; systemctl reload nginx 2>/dev/null || systemctl restart nginx
echo "pronto: painel em http://<ip>:8086 (usuário admin) · logs UDP/TCP 514 -> banco syslog (MariaDB) + arquivo reserva · hora UDP 123"
[ -n "$DOMINIO" ] && { [ -f "/etc/letsencrypt/live/$DOMINIO/fullchain.pem" ] && echo "https: https://$DOMINIO (certificado renova sozinho)" || echo "https: $DOMINIO aguardando o certificado (portas 80/443)"; }
