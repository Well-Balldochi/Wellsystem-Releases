#!/bin/bash
# =================================================================================================
# WellSystem — CONEXÕES DO FREERADIUS COM O BANCO (pool do módulo sql)
#
# O PROBLEMA (medido em 28/11/2026)
#   O módulo sql vinha com "max = 10" conexões. Quando o banco atrasa alguns segundos (backup da VM,
#   disco ocupado), as 10 ficam presas na contabilidade (accounting) dos clientes, o FreeRADIUS
#   registra "Cannot open new connection, already at max" / "unfinished request in component
#   accounting module sql" e para de responder também às autenticações. O concentrador marca o
#   RADIUS principal como FORA e passa para o reserva (aparecia toda noite no diagnóstico).
#
# O QUE ESTE ARQUIVO FAZ
#   No bloco pool { } do mods-available/sql deixa: start = 5, min = 4, max = 32, spare = 10.
#   Só AUMENTA: se o servidor já tem um max maior que 32, nada muda.
#
# SEGURANÇA — nada aqui pode derrubar autenticação
#   · cópia do arquivo antes de mexer (/var/backups/wellsystem/freeradius);
#   · "freeradius -CX" valida; falhou = o original volta sozinho;
#   · reiniciou e não subiu = o original volta e o serviço sobe de novo;
#   · já está assim = não reinicia nada.
#
# USO
#   bash ws-radius-pool.sh                  ajusta e reinicia se mudou
#   bash ws-radius-pool.sh --sem-reiniciar  grava e valida, sem reiniciar (usado pelo INSTALAR)
#   bash ws-radius-pool.sh --auto           só age se este FreeRADIUS é do WellSystem (não MK-Auth)
# =================================================================================================
set -u

AUTO=0; REINICIAR=1
while [ $# -gt 0 ]; do
    case "$1" in
        --auto)          AUTO=1 ;;
        --sem-reiniciar) REINICIAR=0 ;;
        -h|--help)       sed -n '2,25p' "$0"; exit 0 ;;
        *)               echo "opcao desconhecida: $1 (veja --help)" >&2; exit 2 ;;
    esac
    shift
done

ok()   { echo "    $*"; }
aviso(){ echo "    AVISO: $*" >&2; }

# ---- 1) FreeRADIUS local ------------------------------------------------------------------------
FR=""
for d in ${WS_FR_DIR:-} /etc/freeradius/3.0 /etc/freeradius /etc/raddb; do
    [ -f "$d/radiusd.conf" ] && { FR="$d"; break; }
done
if [ -z "$FR" ]; then ok 'conexoes do RADIUS com o banco: sem FreeRADIUS neste servidor — nada a fazer'; exit 0; fi
RADBIN=""
for c in ${WS_RADBIN:-} freeradius radiusd /usr/sbin/freeradius /usr/sbin/radiusd; do
    command -v "$c" >/dev/null 2>&1 && { RADBIN="$(command -v "$c")"; break; }
done
[ -n "$RADBIN" ] || { aviso 'binario do FreeRADIUS nao encontrado — nada alterado'; exit 0; }

if [ -d /opt/mk-auth ] && [ "$AUTO" = 1 ]; then
    ok 'conexoes do RADIUS com o banco: FreeRADIUS do MK-Auth — nao alterado'
    exit 0
fi
[ -e "$FR/mods-enabled/sql" ] || { ok 'conexoes do RADIUS com o banco: modulo sql nao habilitado — nada a fazer'; exit 0; }
ALVO="$(readlink -f "$FR/mods-enabled/sql")"

# ---- 2) monta o arquivo novo: só dentro do bloco "pool {" do módulo sql --------------------------
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
awk '
    function valor(l) { sub(/^[^=]*=[[:space:]]*/, "", l); sub(/[[:space:]#].*$/, "", l); return l + 0 }
    /^[[:space:]]*pool[[:space:]]*\{/ { dentro = 1; achou = 1; print; next }
    dentro && /^[[:space:]]*\}/ { dentro = 0; print; next }
    dentro && /^[[:space:]]*max[[:space:]]*=/   { if (valor($0) < 32) { sub(/=.*/, "= 32") }; print; next }
    dentro && /^[[:space:]]*start[[:space:]]*=/ { if (valor($0) < 5)  { sub(/=.*/, "= 5") };  print; next }
    dentro && /^[[:space:]]*min[[:space:]]*=/   { if (valor($0) < 4)  { sub(/=.*/, "= 4") };  print; next }
    dentro && /^[[:space:]]*spare[[:space:]]*=/ { if (valor($0) < 10) { sub(/=.*/, "= 10") }; print; next }
    { print }
    END { if (!achou) exit 3; if (dentro) exit 5 }
' "$ALVO" > "$TMPD/novo"
RC=$?
case $RC in
    0) ;;
    3) aviso "bloco pool { } nao encontrado em $ALVO — nada alterado"; exit 1 ;;
    *) aviso "nao consegui montar o arquivo novo (codigo $RC) — nada alterado"; exit 1 ;;
esac

if cmp -s "$TMPD/novo" "$ALVO"; then
    ok 'conexoes do RADIUS com o banco: ja estao ajustadas'
    exit 0
fi

# ---- 3) grava com cópia, valida, e volta sozinho se algo falhar ---------------------------------
BK="${WS_FR_BACKUP:-/var/backups/wellsystem/freeradius}"
mkdir -p "$BK" && chmod 700 "$BK"
COPIA="$BK/sql.$(date +%Y%m%d-%H%M%S).pool"
cp -a "$ALVO" "$COPIA"
ls -1t "$BK"/sql.*.pool 2>/dev/null | tail -n +11 | xargs -r rm -f
cat "$TMPD/novo" > "$ALVO"

if ! "$RADBIN" -CX > "$TMPD/check.log" 2>&1; then
    cat "$COPIA" > "$ALVO"
    aviso 'a configuracao nova nao passou no teste do FreeRADIUS — arquivo original restaurado. Erro:'
    tail -15 "$TMPD/check.log" >&2
    exit 1
fi
ok "conexoes do RADIUS com o banco ajustadas (max = 32; copia do original: $COPIA)"

if [ "$REINICIAR" = 1 ]; then
    reiniciar() {
        if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q '^freeradius\.service'; then
            systemctl restart freeradius; sleep 2; systemctl is-active --quiet freeradius
        else
            service freeradius restart >/dev/null 2>&1; sleep 2; pgrep -x 'freeradius|radiusd' >/dev/null
        fi
    }
    if reiniciar; then
        ok 'FreeRADIUS reiniciado com as conexoes novas'
    else
        cat "$COPIA" > "$ALVO"; reiniciar
        aviso 'o FreeRADIUS nao subiu com as conexoes novas — original restaurado e servico reiniciado'
        exit 1
    fi
fi
exit 0
