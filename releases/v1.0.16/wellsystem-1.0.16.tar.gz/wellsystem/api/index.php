<?php
/**
 * WellSystem — /api/ no formato da API do MK-Auth, para o robô de atendimento (Typebot/n8n).
 * Toda a regra está em api_chatbot.php (raiz); aqui só o roteamento.
 */
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/api_chatbot.php';
require_once dirname(__DIR__) . '/pix.php';
require_once dirname(__DIR__) . '/celcash.php';

$resp = function (int $code, $corpo, string $tipo = 'application/json') {
    http_response_code($code);
    header('Content-Type: ' . $tipo . '; charset=utf-8');
    header('Cache-Control: no-store');
    echo is_string($corpo) ? $corpo : json_encode($corpo, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

$cfg = ws_chatbot_cfg();
if (empty($cfg['ativo']) || $cfg['auth_hash'] === '')
    $resp(503, ['erro' => 'API do chatbot desligada. Ligue em Mensagens → Servidor → API do chatbot.']);

// caminho depois de /api/
$uri = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
$pos = strpos($uri, '/api/');
$rota = trim($pos === false ? '' : substr($uri, $pos + 5), '/');
/* (02/10/2026) guarda o endereço por onde o robô chama a API: é o mesmo que a Evolution usa para entregar a mídia
   (ws_midia_webhook_url). Assim a instalação nova liga a entrega sozinha, sem ninguém digitar endereço. */
if ($rota !== '' && $pos !== false && preg_match('/^[a-z0-9.\-]+(:\d+)?$/i', (string)($_SERVER['HTTP_HOST'] ?? ''))) {
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $baseApi = ($https ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . substr($uri, 0, $pos);
    if (!filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP) && @file_get_contents(WS_CACHE . '/api_base.txt') !== $baseApi) { @file_put_contents(WS_CACHE . '/api_base.txt', $baseApi); @chmod(WS_CACHE . '/api_base.txt', 0640); }
}
$auth = ws_chatbot_header_auth();

// GET /api/  → token (texto puro, como o MK-Auth: o bot guarda o corpo inteiro como token)
if ($rota === '' || $rota === 'index.php') {
    if (!hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')))
        $resp(401, ['erro' => 'credencial inválida']);
    $resp(200, ws_chatbot_token_emitir($cfg), 'text/plain');
}

// GET /api/pix/pagar/<título>-<assinatura> → página do PIX do título (o link que o robô manda abaixo do QR).
// Regras em ws_chatbot_link_proprio() (api_chatbot.php). Sem token: a assinatura protege o número do título.
if (preg_match('#^pix/pagar/(\d+)-([a-f0-9]{16})$#', $rota, $mp)) {
    $fid = (int)$mp[1];
    $pag = function (string $corpo) {
        header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store');   // o código (200/404/500) é de quem chama
        $prov = @json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
        $nome = htmlspecialchars((string)(($prov['fantasia'] ?? '') ?: (($prov['razao'] ?? '') ?: 'Pagamento PIX')), ENT_QUOTES, 'UTF-8');
        echo '<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
           . '<title>PIX — ' . $nome . '</title><style>'
           . ':root{--bg:#f4f5f7;--card:#fff;--tx:#1f2430;--mu:#6b7280;--br:#e5e7eb;--pri:#9b1c31}'
           . '@media(prefers-color-scheme:dark){:root{--bg:#15161a;--card:#1f2127;--tx:#eceef2;--mu:#9aa0ab;--br:#33363e;--pri:#e0566e}}'
           . 'body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}'
           . '.c{max-width:420px;margin:18px auto;padding:0 16px}.k{background:var(--card);border:1px solid var(--br);border-radius:16px;padding:20px;text-align:center}'
           . 'h1{font-size:18px;margin:0 0 4px}.m{color:var(--mu);font-size:13px}.v{font-size:28px;font-weight:800;margin:10px 0 2px}'
           . 'img{width:100%;max-width:280px;background:#fff;border-radius:10px;padding:8px;margin:14px auto;display:block}'
           . 'textarea{width:100%;box-sizing:border-box;height:84px;font:12px monospace;border:1px solid var(--br);border-radius:10px;padding:8px;background:var(--bg);color:var(--tx);resize:none}'
           . 'button{margin-top:10px;width:100%;padding:13px;border:0;border-radius:10px;background:var(--pri);color:#fff;font-size:16px;font-weight:700}'
           . '</style></head><body><div class="c"><div class="k"><h1>' . $nome . '</h1>' . $corpo . '</div></div></body></html>';
        exit;
    };
    if (!hash_equals(ws_chatbot_link_sig($fid), $mp[2])) { http_response_code(404); $pag('<p class="m">Link inválido.</p>'); }
    try {
        $db = ws_db();
        $sf = $db->prepare("SELECT * FROM ws_fatura WHERE id=?"); $sf->execute([$fid]); $f = $sf->fetch(PDO::FETCH_ASSOC);
        if (!$f) $pag('<p class="m">Título não encontrado.</p>');
        if (($f['status'] ?? '') === 'pago') $pag('<p class="v">✅ Pago</p><p class="m">Este título já está pago. Obrigado!</p>');
        $px = ws_fatura_pix_png($db, $fid);
        if (!$px) $pag('<p class="m">Este título não tem PIX. Fale com o atendimento.</p>');
        $venc = date('d/m/Y', strtotime((string)$f['vencimento']));
        /* (15/10) aviso para não pagar o título errado: diz se este está VENCIDO e se há boleto mais ANTIGO em aberto. */
        $avisoQ = '';
        try { $qa = $db->prepare("SELECT COUNT(*), MIN(vencimento) FROM ws_fatura WHERE cliente_id=? AND id<>? AND status IN ('aberto','vencido') AND vencimento < ?"); $qa->execute([(int)$f['cliente_id'], $fid, $f['vencimento']]); [$nA, $mA] = $qa->fetch(PDO::FETCH_NUM);
            if ((int)$nA > 0) $avisoQ = '<p class="m" style="color:#b45309;font-weight:700">⚠️ Você tem ' . (int)$nA . ' boleto(s) mais antigo(s) em aberto (o mais antigo venceu em ' . date('d/m/Y', strtotime((string)$mA)) . '). Confira se é este que você quer pagar.</p>'; } catch (Throwable $e) {}
        if (substr((string)$f['vencimento'], 0, 10) < date('Y-m-d')) $avisoQ = '<p class="m" style="color:#b91c1c;font-weight:700">Boleto VENCIDO</p>' . $avisoQ;
        $pag($avisoQ . '<p class="m">Vencimento ' . $venc . '</p><p class="v">R$ ' . number_format(ws_fatura_valor_cobrado($f), 2, ',', '.') . '</p>'
           . '<img alt="QR Code PIX" src="data:image/png;base64,' . base64_encode($px['png']) . '">'
           . '<p class="m">Abra o app do banco → PIX → <b>Ler QR Code</b>, ou copie o código abaixo (<b>PIX copia e cola</b>).</p>'
           . '<textarea id="e" readonly>' . htmlspecialchars($px['emv'], ENT_QUOTES, 'UTF-8') . '</textarea>'
           . '<button type="button" onclick="var e=document.getElementById(\'e\');e.select();(navigator.clipboard?navigator.clipboard.writeText(e.value):Promise.reject()).catch(function(){document.execCommand(\'copy\')});this.textContent=\'✅ Código copiado\'">📋 Copiar código PIX</button>');
    } catch (Throwable $e) {
        http_response_code(500); $pag('<p class="m">Não foi possível abrir agora. Tente de novo em instantes.</p>');
    }
}

// GET /api/pix/qrcode.png[?valor=73.50] → imagem do QR da chave PIX (bloco "QR Code Manual" do robô).
// Sem token: o WhatsApp baixa a imagem direto. Regras em ws_chatbot_pix_manual() (api_chatbot.php).
// ?cpf=<números> → QR do título em aberto mais antigo desse cliente, com valor (ws_chatbot_pix_cpf_png);
// sem título em aberto, cai no QR da chave. É o bloco do QR manual do robô, depois de pedir o CPF.
/* O CPF vai NO CAMINHO (/api/pix/qrcode/05410068432.png) e não em ?cpf= (24/09/2026): a Evolution descobre o
   tipo do arquivo pelo FIM do endereço. Com "qrcode.png?cpf=..." ela não reconhecia como imagem e o QR parou de
   chegar no WhatsApp. O ?cpf= continua aceito (teste no navegador). "qrcode/.png" (CPF vazio) = QR da chave. */
if (preg_match('#^pix/qrcode/(\d*)\.png$#', $rota, $mq)) { $_GET['cpf'] = $mq[1]; $rota = 'pix/qrcode.png'; }
if ($rota === 'pix/qrcode.png') {
    $png = null;
    if (trim((string)($_GET['cpf'] ?? '')) !== '') {
        try { $png = ws_chatbot_pix_cpf_png(ws_db(), (string)$_GET['cpf']); if ($png !== null) ws_sessao_concluir_cpf(ws_db(), (string)$_GET['cpf']); } catch (Throwable $e) {}
    }
    if ($png === null) {
        $valor = (float)str_replace(',', '.', (string)($_GET['valor'] ?? '0'));
        $r = null;
        try { $r = ws_chatbot_pix_manual(ws_db(), (int)($cfg['pix_manual_banco'] ?? 0), $valor); } catch (Throwable $e) {}
        if (!$r) $resp(404, ['erro' => 'nenhuma conta com chave PIX cadastrada']);
        $png = $r['png'];
    }
    http_response_code(200);
    header('Content-Type: image/png');
    header('Content-Length: ' . strlen($png));
    // o QR de um cliente muda a cada título: não guarda. O da chave pode ficar 5 min.
    header(isset($_GET['cpf']) ? 'Cache-Control: no-store' : 'Cache-Control: public, max-age=300');
    echo $png;
    exit;
}

// GET|POST /api/cpf[/{texto}] → VALIDA O CPF/CNPJ DIGITADO NO ROBÔ (01/10/2026). Mesma credencial do robô (Basic ou token).
// Corpo/consulta: {cpf, remoteJid}. Resposta: valido (true = é cliente, segue o fluxo), situacao e mensagem pronta:
//   ok            = cliente da base (cancelado/desativado não conta) → "cpf" volta só com números;
//   menu          = digitou 0 → o robô volta ao menu;
//   cpf_invalido  = número com dígito errado;
//   sugestao      = não é cliente, mas o WhatsApp que está falando tem cadastro → mostra o CPF PARCIAL para completar;
//   nao_cadastrado = não achou nada.
if (preg_match('#^cpf(?:/(.*))?$#', $rota, $mcpf)) {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $corpo = json_decode((string)file_get_contents('php://input'), true); if (!is_array($corpo)) $corpo = $_POST;
    $txt = trim((string)($mcpf[1] ?? '') !== '' ? rawurldecode((string)$mcpf[1]) : ($corpo['cpf'] ?? ($_GET['cpf'] ?? '')));
    $doc = preg_replace('/\D/', '', $txt);
    try { $jCpf = (string)($corpo['remoteJid'] ?? ($_GET['remoteJid'] ?? '')); if ($jCpf !== '' && strpos($jCpf, '{{') === false && strlen($doc) >= 11) ws_sessao_concluir($jCpf); } catch (Throwable $e) {}   // CPF dado: o fluxo segue e entrega sozinho
    /* NOME NÃO SE PERGUNTA DE NOVO (13/10/2026, caso Leide Jane): quem se identificou pelo CPF (2ª via, PIX, central) e depois pede atendente ouvia "Qual o nome do cliente?" — o número dela não está no
       cadastro, então o fluxo não tinha o nome. Agora a resposta traz "nome_cadastro" (nome do cadastro achado pelo CPF) e o fluxo o guarda em nome_cad_ws, que as telas de atendimento já usam para pular a
       pergunta. Se este CPF não gerar nome novo, devolve o que o fluxo mandou ("nome_cad") para não apagar um nome já conhecido. */
    $nomeJa = strpos((string)($corpo['nome_cad'] ?? ''), '{{') !== false ? '' : trim((string)($corpo['nome_cad'] ?? ''));
    $fim = function (bool $ok, string $sit, string $msg, array $extra = []) use ($resp, $doc, $nomeJa) {
        $nomeCad = $nomeJa;
        if ($ok && strlen($doc) >= 11) { try { $qn = ws_db()->prepare("SELECT nome FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','') = ? AND status NOT IN ('cancelado','desativado') ORDER BY (titular_id IS NULL) DESC, id LIMIT 1"); $qn->execute([$doc]); $nn = trim((string)$qn->fetchColumn()); if ($nn !== '') $nomeCad = function_exists('ws_chatbot_acabamento') ? ws_chatbot_acabamento($nn, 'nome') : $nn; } catch (Throwable $e) {} }
        $resp(200, ['ok' => $ok, 'valido' => $ok, 'situacao' => $sit, 'cpf' => $ok ? $doc : '', 'mensagem' => $msg, 'nome_cadastro' => $nomeCad] + $extra);
    };
    if ($doc === '0' || preg_match('/^\s*(0|menu|voltar|sair)\s*$/i', $txt)) $fim(false, 'menu', '↩️ Voltando ao menu.');
    try {
        $db = ws_db();
        $vivo = " AND COALESCE(c.status,'') NOT IN ('cancelado','desativado')";
        if (strlen($doc) === 11 || strlen($doc) === 14) {
            $st = $db->prepare("SELECT c.nome FROM ws_cliente c WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=?$vivo ORDER BY (c.titular_id IS NOT NULL), c.id LIMIT 1");
            $st->execute([$doc]); $nm = $st->fetchColumn();
            if ($nm !== false) $fim(true, 'ok', '✅ Cadastro localizado: *' . explode(' ', trim((string)$nm))[0] . '*.', ['nome' => explode(' ', trim((string)$nm))[0]]);
        }
        $docOk = function_exists('ws_cpf_cnpj_valido') ? ws_cpf_cnpj_valido($doc) : (strlen($doc) === 11 || strlen($doc) === 14);
        /* não é cliente: procura o cadastro pelo WhatsApp que está falando E pelo NOME que o cliente informou no robô
           (02/10/2026) → mostra o CPF PARCIAL (•••.456.789-••, padrão LGPD) para o cliente completar. Pelo nome só vale
           nome com 2+ palavras que bata inteiro (cada palavra), no máximo 3 cadastros — ninguém "pesca" CPF por sobrenome. */
        $mascara = function (string $d): string { $d = preg_replace('/\D/', '', $d);
            return strlen($d) === 11 ? '•••.' . substr($d, 3, 3) . '.' . substr($d, 6, 3) . '-••' : (strlen($d) === 14 ? '••.' . substr($d, 2, 3) . '.' . substr($d, 5, 3) . '/••••-••' : ''); };
        $porNome = [];
        $nomeInf = trim((string)($corpo['nome'] ?? ($_GET['nome'] ?? '')));
        if ($nomeInf !== '' && strpos($nomeInf, '{{') === false && stripos($nomeInf, 'Message|') === false) {
            $pal = array_values(array_filter(preg_split('/\s+/', ws_chatbot_norm($nomeInf)), fn($w) => mb_strlen($w) >= 2 && !in_array($w, ['da', 'de', 'do', 'das', 'dos', 'e'], true)));
            if (count($pal) >= 2) {
                $cond = implode(' AND ', array_fill(0, count($pal), "CONCAT(' ', LOWER(c.nome), ' ') LIKE ?"));
                $st = $db->prepare("SELECT c.nome, c.cpf_cnpj FROM ws_cliente c WHERE $cond$vivo AND COALESCE(c.cpf_cnpj,'')<>'' AND c.titular_id IS NULL LIMIT 4");
                $st->execute(array_map(fn($w) => '% ' . $w . ' %', $pal));
                $rows = $st->fetchAll(PDO::FETCH_ASSOC);
                if (count($rows) <= 3) foreach ($rows as $r) { $m = $mascara((string)$r['cpf_cnpj']); if ($m !== '') $porNome[$m] = $m; }
            }
        }
        $tel = preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ($_GET['remoteJid'] ?? '')))[0]);
        /* (16/10/2026, caso Ednalva Brito) CPF válido que NÃO está no cadastro e o cliente acabou de mandar um comprovante (≤ 3 h, ainda sem CPF): o CPF digitado fica guardado no comprovante para o financeiro conferir —
           antes era descartado com "CPF não cadastrado" e o cliente digitava de novo, de novo e de novo. */
        $cpfGuardado = false;
        if ($docOk && strlen($tel) >= 10) { try { $gu = $db->prepare("UPDATE ws_comprovante SET cpf=? WHERE RIGHT(telefone,8)=? AND status='novo' AND (cpf IS NULL OR cpf='') AND criado_em >= (NOW() - INTERVAL 3 HOUR) ORDER BY id DESC LIMIT 1"); $gu->execute([$doc, substr($tel, -8)]); $cpfGuardado = $gu->rowCount() > 0; } catch (Throwable $e) {} }
        if (strlen($tel) < 10 && $porNome) $fim(false, 'sugestao', "❌ CPF não cadastrado.\nEncontrei cadastro em nome de *" . ws_chatbot_acabamento($nomeInf, 'nome') . "* com o CPF " . implode(' ou ', $porNome) . ".\nDigite o CPF *completo* (só números) para confirmar, ou *0* para voltar ao menu.", ['dica' => implode(' / ', $porNome)]);
        if (strlen($tel) >= 10) {
            $fimTel = substr($tel, -8);
            $st = $db->prepare("SELECT c.cpf_cnpj FROM ws_cliente c WHERE (RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.celular,''),' ',''),'-',''),'(',''),')',''),8)=?
                                OR RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.telefone,''),' ',''),'-',''),'(',''),')',''),8)=?)$vivo AND COALESCE(c.cpf_cnpj,'')<>'' LIMIT 3");
            $st->execute([$fimTel, $fimTel]);
            $dicasTel = [];
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $d) { $m = $mascara((string)$d); if ($m !== '') $dicasTel[$m] = $m; }
            // nome informado E WhatsApp: o que bate nos dois vem primeiro; depois o do nome; depois o do WhatsApp
            $ambos = array_intersect_key($porNome, $dicasTel);
            $dicas = array_values(array_unique(array_merge(array_values($ambos), array_values($porNome), array_values($dicasTel))));
            $dicas = array_slice($dicas, 0, 3);
            if ($dicas) {
                $onde = $porNome && $dicasTel ? 'em nome de *' . ws_chatbot_acabamento($nomeInf, 'nome') . '* e neste WhatsApp' : ($porNome ? 'em nome de *' . ws_chatbot_acabamento($nomeInf, 'nome') . '*' : 'neste WhatsApp');
                $fim(false, 'sugestao', "❌ CPF não cadastrado.\nEncontrei cadastro $onde com o CPF " . implode(' ou ', $dicas) . ".\nDigite o CPF *completo* (só números) para confirmar, ou *0* para voltar ao menu.", ['dica' => implode(' / ', $dicas)]);
            }
        }
        if (strlen($doc) !== 11 && strlen($doc) !== 14) $fim(false, 'cpf_invalido', "⚠️ Digite o CPF (11 números) ou CNPJ (14 números) do titular, ou *0* para voltar ao menu.");
        if (!$docOk) $fim(false, 'cpf_invalido', "⚠️ Esse CPF/CNPJ não é válido.\nConfira os números e digite de novo, ou *0* para voltar ao menu.");
        if ($cpfGuardado) $fim(false, 'nao_cadastrado', "❌ Esse CPF não está no nosso cadastro, mas *anotei o número que você informou* junto com o seu comprovante — o financeiro vai conferir e dar baixa.\nSe quiser tentar outro CPF, digite agora; ou *0* para voltar ao menu.");
        $fim(false, 'nao_cadastrado', "❌ CPF não cadastrado.\nConfira e digite novamente, ou *0* para voltar ao menu.");
    } catch (Throwable $e) {
        $resp(500, ['ok' => false, 'valido' => false, 'situacao' => 'erro', 'mensagem' => 'Não consegui consultar agora. Tente de novo em instantes.']);
    }
}

// POST /api/precadastro → PRÉ-CADASTRO feito pelo robô (Typebot: "Dados cadastro" → "Ficha cadastral"). 01/10/2026.
// Mesma credencial Basic do robô. Corpo JSON (todos opcionais menos nome): {nome, cpf, nascimento, whatsapp, endereco,
// numero, bairro, cidade, referencia, email, plano, vencimento, remoteJid, pushName}.
// Grava em Comercial (ws_lead, etapa "novo", origem "WhatsApp (robô)") — o operador confere e usa "converter em cliente".
// Mesmo telefone nas últimas 24 h = ATUALIZA o pré-cadastro (cliente que corrigiu os dados), não duplica.
// A equipe recebe um aviso curto no WhatsApp (números de Suporte → Notificações de chamado).
if ($rota === 'precadastro') {
    if (!hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')))
        $resp(401, ['erro' => 'credencial inválida']);
    $d = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($d)) $d = $_POST;
    $c = fn(string $k, int $max = 160) => mb_substr(trim((string)($d[$k] ?? '')), 0, $max);
    $nome = $c('nome');
    if ($nome === '' || mb_strlen($nome) < 3) $resp(200, ['ok' => false, 'valido' => false, 'mensagem' => 'Informe o nome completo para o cadastro.']);
    /* (07/10/2026) "Já tenho cadastro" virou NOME de pré-cadastro. Frase/assunto no lugar do nome não grava nada: quem já é cliente
       volta ao menu (boleto, suporte, PIX… pedem o CPF e acham o cadastro); senão pede o nome de novo. */
    if (function_exists('ws_chatbot_nao_e_nome') && ws_chatbot_nao_e_nome($nome)) {
        $jaCli = function_exists('ws_chatbot_ja_cliente') && ws_chatbot_ja_cliente($nome);
        $resp(200, ['ok' => false, 'valido' => false, 'ja_cliente' => $jaCli, 'desvio_opcao' => $jaCli ? '0' : '',
            'mensagem' => $jaCli ? "😊 Entendi, você já é nosso cliente! Não precisa fazer cadastro novo.\nDigite *0* para voltar ao menu e escolher o que precisa (2ª via, PIX, suporte…) — lá eu peço o seu CPF e encontro o seu cadastro."
                                 : 'Não entendi o nome. Informe o *nome completo* do titular para o cadastro.']);
    }
    $doc = preg_replace('/\D/', '', $c('cpf', 20));
    $tel = preg_replace('/\D/', '', $c('whatsapp', 20));
    if (strlen($tel) < 10) $tel = preg_replace('/\D/', '', explode('@', $c('remoteJid', 60))[0]);
    if (strlen($tel) >= 12 && substr($tel, 0, 2) === '55') $tel = substr($tel, 2);
    $docOk = $doc !== '' && function_exists('ws_cpf_cnpj_valido') && ws_cpf_cnpj_valido($doc);
    $obs = implode("\n", array_filter([
        'Pré-cadastro pelo robô do WhatsApp em ' . date('d/m/Y H:i') . '.',
        $doc !== '' ? 'CPF/CNPJ: ' . $doc . ($docOk ? '' : ' (⚠️ número não confere — confirmar)') : '',
        $c('nascimento', 20) !== '' ? 'Nascimento: ' . $c('nascimento', 20) : '',
        $c('referencia') !== '' ? 'Ponto de referência: ' . $c('referencia') : '',
        $c('vencimento', 40) !== '' ? 'Vencimento escolhido: ' . $c('vencimento', 40) : '',
        $c('plano', 120) !== '' ? 'Plano escolhido no robô: ' . $c('plano', 120) : '',
        $c('pushName', 80) !== '' ? 'Nome no WhatsApp: ' . $c('pushName', 80) : '',
    ]));
    $end = trim($c('endereco') . ($c('numero', 20) !== '' ? ', ' . $c('numero', 20) : ''));
    try {
        $db = ws_db();
        $id = 0;
        // Já existe cadastro com esse CPF ou WhatsApp? Grava assim mesmo (pode ser um 2º ponto), mas avisa na observação.
        try {
            $ja = null;
            if ($doc !== '') { $q = $db->prepare("SELECT id, nome FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/','')=? LIMIT 1"); $q->execute([$doc]); $ja = $q->fetch(PDO::FETCH_ASSOC) ?: null; }
            if (!$ja && strlen($tel) >= 10) { $q = $db->prepare("SELECT id, nome FROM ws_cliente WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''), 8)=? AND status NOT IN('cancelado','desativado') LIMIT 1"); $q->execute([substr($tel, -8)]); $ja = $q->fetch(PDO::FETCH_ASSOC) ?: null; }
            if ($ja) $obs .= "\n⚠️ JÁ É CLIENTE: cadastro #{$ja['id']} ({$ja['nome']}) com o mesmo " . ($doc !== '' ? 'CPF/WhatsApp' : 'WhatsApp') . " — conferir se é um novo ponto ou se a pessoa só queria atendimento.";
        } catch (Throwable $e) {}
        if ($tel !== '') {
            $q = $db->prepare("SELECT id FROM ws_lead WHERE telefone=? AND cliente_id IS NULL AND criado_em >= NOW() - INTERVAL 1 DAY ORDER BY id DESC LIMIT 1");
            $q->execute([$tel]); $id = (int)$q->fetchColumn();
        }
        // plano_interesse guarda o CÓDIGO do plano: acha pelo número de Mega/Giga do texto escolhido no robô ("100 Mega" → plano 100Mega)
        $planoId = null;
        if (preg_match('/(\d{2,4})\s*(mega|mb|giga|gb)?/i', $c('plano', 120), $pm)) {
            $num = (int)$pm[1]; if (preg_match('/^g/i', (string)($pm[2] ?? ''))) $num *= 1000;
            try { $qp = $db->prepare("SELECT id FROM ws_plano WHERE ativo=1 AND down_kbps BETWEEN ? AND ? ORDER BY (nome LIKE '%Wellnet%') DESC, id LIMIT 1");
                  $qp->execute([$num * 1000, $num * 1024]); $planoId = (int)$qp->fetchColumn() ?: null; } catch (Throwable $e) {}
        }
        $vals = [$nome, $tel ?: null, $c('email') ?: null, $c('cidade', 80) ?: null, $c('bairro', 80) ?: null, $end ?: null, $planoId, $obs];
        if ($id) $db->prepare("UPDATE ws_lead SET nome=?, telefone=?, email=?, cidade=?, bairro=?, endereco=?, plano_interesse=?, obs=? WHERE id=?")->execute(array_merge($vals, [$id]));
        else { $db->prepare("INSERT INTO ws_lead (nome, telefone, email, cidade, bairro, endereco, plano_interesse, obs, origem, etapa) VALUES (?,?,?,?,?,?,?,?, 'WhatsApp (robô)', 'novo')")->execute($vals); $id = (int)$db->lastInsertId(); }
        // aviso curto à equipe (mesma lista fixa dos avisos de chamado)
        // Aviso ao PROVEDOR (não à gerência): número do provedor; se falhar, na conversa do cliente — aviso_provedor_lib.php
        if (is_file(dirname(__DIR__) . '/aviso_provedor_lib.php')) {
            require_once dirname(__DIR__) . '/aviso_provedor_lib.php';
            $txt = "🆕 *Pré-cadastro pelo robô* — protocolo L{$id}\n👤 {$nome}\n📞 " . ($tel ?: '—') . "\n🏠 " . trim($end . ' — ' . $c('bairro', 80) . ' — ' . $c('cidade', 80), ' —')
                 . "\n📶 " . ($c('plano', 80) ?: '—') . "\n\nAprovar ou recusar: aviso 🆕 no topo do sistema (Comercial).";
            try { ws_aviso_provedor($txt, (string)$tel, (string)($d['instanceName'] ?? '')); } catch (Throwable $e) {}
        }
        $resp(200, ['ok' => true, 'valido' => true, 'id' => $id, 'protocolo' => 'L' . $id, 'cpf_valido' => $docOk,
            'mensagem' => "📝 Cadastro recebido! Protocolo *L{$id}*.\nNossa equipe vai conferir a viabilidade e entrar em contato para agendar a instalação."]);
    } catch (Throwable $e) {
        $resp(500, ['ok' => false, 'erro' => 'falha ao gravar o pré-cadastro']);
    }
}

/* =====================================================================================================================
 * DIAGNÓSTICO DA CONEXÃO PELO ROBÔ (01/10/2026). Mesma credencial do robô (Basic do "GERA TOKEN" ou o token).
 *   GET  /api/conexao/{cpf}        → situação de cada contrato + mensagem pronta. Situações (campo "situacao"):
 *        bloqueado   = pendência financeira: valor em aberto + PIX do título mais antigo (liberação automática ao pagar);
 *        rota_presa  = contrato liberado, mas o equipamento ainda segura o endereço de bloqueio (faixa de corte) →
 *                      o robô JÁ CORRIGE na hora (derruba a sessão; o equipamento volta com endereço normal);
 *        online      = conectado agora (IP) → oferece reconectar / chamado;
 *        sem_sinal   = a ONU não responde na OLT (fibra/energia) → reiniciar remoto não adianta → oferece chamado;
 *        offline     = ONU com sinal, mas sem autenticar → oferece reiniciar o equipamento remotamente.
 *   POST /api/conexao/reconectar   {cpf} → online: derruba a sessão; offline: REINICIA A ONU pela OLT (ont reset) e
 *                                    derruba a sessão. "tipo":"resync" ressincroniza a ONU. Até 2x por hora por contrato.
 *   POST /api/conexao/confianca    {cpf} → bloqueado: libera 1 DIA em confiança, no máximo 1 vez por ciclo (mesmo ciclo da
 *                                    Central, padrão 1 mês; qualquer confiança no ciclo conta). Passou do limite → vira pedido em
 *                                    Suporte → Solicitações (a equipe valida) e a equipe é avisada.
 *   Tudo o que o robô faz fica em Relatórios → Monitor do robô / Central (ws_evento tipo 'robo'/'confianca').
 *   POST /api/conexao/chamado      {cpf, relato} → abre chamado de SUPORTE já com o diagnóstico e avisa a equipe.
 * A OLT só é tocada por localizar/reiniciar/ressincronizar (passagem restrita em olt_auth.php: localhost + chave).
 * ================================================================================================================== */
if (preg_match('#^conexao(?:/(reconectar|chamado|confianca))?(?:/([0-9.\-/]+))?$#', $rota, $mc)) {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $acaoC = $mc[1] ?? '';
    $corpo = json_decode((string)file_get_contents('php://input'), true); if (!is_array($corpo)) $corpo = $_POST;
    $doc = preg_replace('/\D/', '', (string)($mc[2] ?? ($corpo['cpf'] ?? ($_GET['cpf'] ?? ''))));
    if (strlen($doc) !== 11 && strlen($doc) !== 14) $resp(200, ['ok' => false, 'situacao' => 'cpf_invalido', 'mensagem' => 'Informe o CPF ou CNPJ do titular (só números).']);
    try {
        $db = ws_db();
        if (is_file(dirname(__DIR__) . '/radius_lib.php')) require_once dirname(__DIR__) . '/radius_lib.php';
        $st = $db->prepare("SELECT ct.*, c.nome, c.id cid FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                            WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? ORDER BY (ct.status='cancelado'), ct.id");
        $st->execute([$doc]); $cts = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$cts) $resp(200, ['ok' => false, 'situacao' => 'nao_encontrado', 'mensagem' => 'Não encontrei cadastro com esse CPF/CNPJ. Confira o número ou fale com o atendimento.']);
        $vivos = function_exists('ws_conexao_viva') ? (ws_conexao_viva(20) ?: []) : [];
        $faixa = function_exists('ws_conexao_faixa_corte') ? ws_conexao_faixa_corte($db, $vivos) : [];
        $norm = fn($s) => strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)$s));
        $lista = [];
        foreach ($cts as $ct) {
            if ($ct['status'] === 'cancelado') continue;
            $login = trim((string)($ct['login_pppoe'] ?: $ct['login_ipoe']));
            $viva = null; foreach ([$ct['login_pppoe'], $ct['login_ipoe']] as $l) { $k = $norm($l); if ($k !== '' && isset($vivos[$k])) { $viva = $vivos[$k]; break; } }
            $ip = is_array($viva) ? (string)($viva['ip'] ?? '') : '';
            $lista[] = ['contrato' => (int)$ct['id'], 'cliente_id' => (int)$ct['cid'], 'nome' => $ct['nome'], 'login' => $login, 'status' => $ct['status'],
                        'sn' => trim((string)($ct['sn_onu'] ?? '')), 'online' => $viva !== null, 'ip' => $ip,
                        'presa' => $ct['status'] !== 'bloqueado' && $ip !== '' && in_array(implode('.', array_slice(explode('.', $ip), 0, 3)), $faixa, true)];
        }
        if (!$lista) $resp(200, ['ok' => false, 'situacao' => 'cancelado', 'mensagem' => 'Seu contrato está desativado. Fale com o atendimento para reativar.']);
        $bloq = array_values(array_filter($lista, fn($x) => $x['status'] === 'bloqueado'));
        $nome1 = explode(' ', trim((string)$lista[0]['nome']))[0];
        // Estado da ONU na OLT (lista em cache — leitura rápida, sem Telnet). '' = sem SN / não achou.
        $onuEstado = function (array $x): string {
            if ($x['sn'] === '' || !function_exists('ws_onu_robo')) return '';
            $r = ws_onu_robo($x['sn'], 'localizar');
            if (empty($r['ok'])) return '';
            if (preg_match('/online|up/i', (string)$r['estado'])) return 'online';
            // QUEDA EM MASSA: a PON inteira desta ONU caiu (detector da OLT) → é falha na região, não no cliente.
            return (function_exists('ws_olt_pon_quedas') && isset(ws_olt_pon_quedas()[(string)$r['fsp']])) ? 'queda' : 'sem_sinal';
        };
        // Limite de ações do robô: 2 por hora por contrato (reconectar, reiniciar e correção de rota presa).
        $limArq = WS_CACHE . '/robo_reconectar.json';
        $lim = json_decode((string)@file_get_contents($limArq), true) ?: [];
        $limOk = function (int $ctId) use (&$lim): bool { $lim[$ctId] = array_values(array_filter((array)($lim[$ctId] ?? []), fn($t) => $t > time() - 3600)); return count($lim[$ctId]) < 2; };
        $limUsa = function (int $ctId) use (&$lim, $limArq): void { $lim[$ctId][] = time(); @file_put_contents($limArq, json_encode($lim)); @chmod($limArq, 0640); };
        $evento = function (array $x, string $txt) use ($db): void { if (function_exists('ws_evento')) ws_evento($db, $x['cliente_id'], 'robo', $txt . ' (robô do WhatsApp, login ' . ($x['login'] ?: '—') . ').'); };

        // Monitor: diagnóstico e toda recusa do robô vão ao log (ações bem-sucedidas já registram o próprio evento).
        $respOrig = $resp;
        $resp = function (int $c, $b) use ($respOrig, $lista, $db, $acaoC) {
            if (is_array($b) && !empty($b['situacao']) && ($acaoC === '' || empty($b['ok'])) && function_exists('ws_evento'))
                ws_evento($db, $lista[0]['cliente_id'], 'robo', 'Robô do WhatsApp — ' . ($acaoC ?: 'diagnóstico') . ': ' . str_replace('_', ' ', (string)$b['situacao'])
                    . ' · ' . implode(', ', array_map(fn($x) => 'contrato ' . $x['contrato'] . ' ' . $x['status'] . ($x['online'] ? ' online' . ($x['ip'] !== '' ? ' ' . $x['ip'] : '') : ' sem sessão'), $lista)));
            $respOrig($c, $b);
        };

        if ($acaoC === 'reconectar') {
            $tipoOnu = ($corpo['tipo'] ?? '') === 'resync' ? 'resync' : 'reboot';
            $feitos = []; $limitado = false;
            // Vários contratos no mesmo CPF: mexe SÓ no que está sem conexão (nunca derruba o que está funcionando).
            // Todos conectados (cliente diz que está lento) → reconecta todos.
            $alvos = array_values(array_filter($lista, fn($x) => $x['status'] !== 'bloqueado' && ($x['login'] !== '' || $x['sn'] !== '')));
            $semCon = array_values(array_filter($alvos, fn($x) => !$x['online'] || $x['presa']));
            if ($semCon) $alvos = $semCon;
            foreach ($alvos as $x) {
                if (!$limOk($x['contrato'])) { $limitado = true; continue; }
                $oque = '';
                if (!$x['online'] && $x['sn'] !== '' && $onuEstado($x) === 'online') {
                    // Em segundo plano (a OLT pode levar até 1 min); o resultado real vai ao histórico do cliente.
                    if (function_exists('ws_onu_robo_bg') && ws_onu_robo_bg($x['sn'], $tipoOnu, $x['cliente_id'], $x['login'])) $oque = 'onu';
                }
                if ($oque === '' && $x['login'] !== '' && function_exists('ws_rad_disconnect')) { try { ws_rad_disconnect($db, $x['login']); } catch (Throwable $e) {} }
                $limUsa($x['contrato']);
                $evento($x, $oque !== '' ? ($tipoOnu === 'resync' ? 'Ressincronização' : 'Reinício') . ' da ONU pedido pelo cliente — enviado à OLT' : 'Reconexão (sessão derrubada) a pedido do cliente');
                $feitos[] = $oque;
            }
            if (!$feitos && $limitado) $resp(200, ['ok' => false, 'situacao' => 'limite', 'mensagem' => 'Já refiz a sua conexão agora há pouco e ela ainda não voltou. Digite 2 para eu abrir um chamado técnico.']);
            if (!$feitos) $resp(200, ['ok' => false, 'situacao' => $bloq ? 'bloqueado' : 'sem_login', 'mensagem' => $bloq ? "Certo! O *boleto/PIX* está na mensagem acima. 👆

⚠️ Atenção: pagando por boleto, a baixa leva até *2 dias úteis*. Se precisar da internet até lá, digite *2* para liberar em confiança (1 dia). Pelo PIX a liberação é imediata." : 'Não achei o cadastro da sua conexão. Vou te passar para o atendimento.']);
            $reiniciou = (bool)array_filter($feitos);
            $resp(200, ['ok' => true, 'situacao' => $reiniciou ? 'reiniciando' : 'reconectando', 'mensagem' => $reiniciou
                ? "🔄 Pronto, $nome1! *Reiniciei seu equipamento* remotamente.\nEle leva uns *3 minutos* para voltar — as luzes vão piscar, é normal.\n\nDepois teste a internet. Se não voltar, digite 2 para eu abrir um chamado técnico."
                : "🔄 Pronto, $nome1! Reconectei sua internet.\nAguarde *2 minutos* e teste.\n\nSe não voltar, digite 2 para eu abrir um chamado técnico."]);
        }

        if ($acaoC === 'confianca') {
            if (!$bloq) $resp(200, ['ok' => false, 'situacao' => 'nao_bloqueado', 'mensagem' => "✅ $nome1, sua internet não está bloqueada — não precisa de liberação."]);
            if (!function_exists('ws_rad_confiar')) $resp(200, ['ok' => false, 'situacao' => 'indisponivel', 'mensagem' => 'Não consigo liberar por aqui agora. Vou te passar para o atendimento.']);
            if (is_file(dirname(__DIR__) . '/central_recursos.php')) require_once dirname(__DIR__) . '/central_recursos.php';
            $ciclo = function_exists('ws_central_param') ? max(1, ws_central_param('confianca_ciclo_meses')) : 1;
            $resultado = [];
            /* LIBERAÇÃO EM CONFIANÇA (10/10/2026): o robô só libera 1 DIA, 1 vez por ciclo. Pediu MAIS de 1 dia ("deixa liberada até segunda", "3 dias", "semana que vem")
               ou já usou o do mês → vira SOLICITAÇÃO (Suporte → Solicitações, aviso ao provedor): só o provedor libera mais de 1 dia. O cliente é avisado do encaminhamento,
               com texto diferente dentro e fora do horário de atendimento. */
            $relatoC = ws_chatbot_norm((string)($corpo['relato'] ?? ''));
            $maisDias = (bool)preg_match('/ (ate|so) .{0,25}(segunda|terca|quarta|quinta|sexta|sabado|domingo|semana|fim de semana|final de semana|dia \d{1,2}|amanha|depois de amanha|proximo mes|mes que vem) | (\d{1,2}|dois|tres|quatro|cinco|seis|sete|uma semana|duas semanas|quinze|varios) dias | semana que vem | fim de semana | final de semana /', ' ' . $relatoC . ' ');
            $abertoC = function_exists('ws_atendimento_aberto') ? !empty(ws_atendimento_aberto()['aberto']) : true;
            $avisoEnc = $abertoC ? 'O provedor já foi avisado e entra em contato com você em breve.' : 'Estamos fora do horário de atendimento — a solicitação já está registrada e o provedor entra em contato assim que o atendimento abrir.';
            $criarSol = function (array $x, string $motivo) use ($db, $corpo) {
                $solId = 0;
                if (is_file(dirname(__DIR__) . '/solicitacoes_lib.php')) {
                    require_once dirname(__DIR__) . '/solicitacoes_lib.php';
                    try { $solId = ws_sol_criar($db, $x['cliente_id'], $x['contrato'], 'confianca', ['situação' => ['de' => 'bloqueado', 'para' => 'liberar em confiança'], 'login' => ['de' => $x['login'], 'para' => $x['login']]], '', $motivo . (trim((string)($corpo['relato'] ?? '')) !== '' ? ' Cliente disse: "' . mb_substr(trim((string)$corpo['relato']), 0, 200) . '"' : '')); } catch (Throwable $e) {}
                }
                if ($solId && is_file(dirname(__DIR__) . '/aviso_provedor_lib.php')) {
                    require_once dirname(__DIR__) . '/aviso_provedor_lib.php';
                    try { ws_aviso_provedor("🔓 *Pedido de confiança #$solId* (robô)
👤 {$x['nome']}
" . $motivo . "
Validar em Suporte → Solicitações.", (function () use ($db, $corpo, $x) { $j = preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ''))[0]); if ($j !== '') return $j; $q = $db->prepare("SELECT celular FROM ws_cliente WHERE id=?"); $q->execute([(int)$x['cliente_id']]); return (string)$q->fetchColumn(); })(), (string)($corpo['instanceName'] ?? '')); } catch (Throwable $e) {}
                }
                if ($solId) ws_robo_log((string)($corpo['remoteJid'] ?? ''), 'pedido de confiança #' . $solId . ' encaminhado ao provedor — ' . $motivo, (int)$x['cliente_id']);
                return $solId;
            };
            foreach ($bloq as $x) {
                $q = $db->prepare("SELECT * FROM ws_contrato WHERE id=?"); $q->execute([$x['contrato']]); $ct = $q->fetch(PDO::FETCH_ASSOC);
                if (!$ct) continue;
                // Já usou no ciclo? Confiança vigente/recente no contrato (Central) OU qualquer liberação em confiança registrada
                // para o cliente (robô, Central ou operador) dentro do ciclo — o registro fica mesmo depois que o pagamento limpa a data.
                $usou = function_exists('ws_central_confianca_no_ciclo') && ws_central_confianca_no_ciclo($ct, 1);
                if (!$usou) {
                    $u = $db->prepare("SELECT MAX(criado_em) FROM ws_evento WHERE cliente_id=? AND (tipo='confianca' OR texto LIKE 'Desbloqueio em confiança%' OR texto LIKE 'Desbloqueio de confiança%' OR texto LIKE '%liberado em confiança%')");
                    $u->execute([$x['cliente_id']]); $ult = (string)$u->fetchColumn();
                    $usou = $ult !== '' && strtotime($ult . " +$ciclo month") > time();
                }
                if ($usou) {
                    $solId = 0;
                    if (is_file(dirname(__DIR__) . '/solicitacoes_lib.php')) {
                        require_once dirname(__DIR__) . '/solicitacoes_lib.php';
                        try { $solId = ws_sol_criar($db, $x['cliente_id'], $x['contrato'], 'confianca', ['situação' => ['de' => 'bloqueado', 'para' => 'liberar em confiança'], 'login' => ['de' => $x['login'], 'para' => $x['login']]], '', 'Pedido pelo robô do WhatsApp — já usou o desbloqueio automático do ciclo (' . $ciclo . ' mês).'); } catch (Throwable $e) {}
                    }
                    // Aviso ao PROVEDOR (não à gerência) — aviso_provedor_lib.php
                    if ($solId && is_file(dirname(__DIR__) . '/aviso_provedor_lib.php')) {
                        require_once dirname(__DIR__) . '/aviso_provedor_lib.php';
                        try { ws_aviso_provedor("🔓 *Pedido de confiança #$solId* (robô)\n👤 {$x['nome']}\nJá usou o desbloqueio do mês — validar em Suporte → Solicitações.", (function () use ($db, $corpo, $x) { $j = preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ''))[0]); if ($j !== '') return $j; $q = $db->prepare("SELECT celular FROM ws_cliente WHERE id=?"); $q->execute([(int)$x['cliente_id']]); return (string)$q->fetchColumn(); })(), (string)($corpo['instanceName'] ?? '')); } catch (Throwable $e) {}
                    }
                    if ($solId) ws_robo_log((string)($corpo['remoteJid'] ?? ''), 'pedido de confiança #' . $solId . ' encaminhado ao provedor — já usou o desbloqueio automático do mês.', (int)$x['cliente_id']);
                    $resultado[] = ['pedido', $solId];
                    continue;
                }
                if (ws_rad_confiar($db, $ct, 1)) {
                    if (function_exists('ws_evento')) ws_evento($db, $x['cliente_id'], 'confianca', 'Desbloqueio em confiança pelo robô do WhatsApp (1 dia, contrato ' . $x['contrato'] . ').');
                    $resultado[] = ['liberado', 0];
                    if ($maisDias) $resultado[] = ['pedido_extra', $criarSol($x, 'Pediu MAIS de 1 dia de confiança (liberado o 1 dia automático).')];
                } else {
                    $resultado[] = ['recusado', ws_rad_confiar_aviso()];
                }
            }
            $lib = array_filter($resultado, fn($r) => $r[0] === 'liberado');
            $ped = array_values(array_filter($resultado, fn($r) => $r[0] === 'pedido'));
            $extra = array_values(array_filter($resultado, fn($r) => $r[0] === 'pedido_extra'));
            if ($lib && $extra) $resp(200, ['ok' => true, 'situacao' => 'confianca_liberada', 'mensagem' => "🔓 Pronto, $nome1! Liberei sua internet em confiança por *1 dia* (até " . date('d/m H:i', strtotime('+1 day')) . ").
Aguarde 2 minutos e teste.

📝 Você pediu mais tempo: encaminhei a solicitação *nº " . (int)$extra[0][1] . "*. " . $avisoEnc . "

Se pagar pelo PIX, a liberação é automática."]);
            if ($lib) $resp(200, ['ok' => true, 'situacao' => 'confianca_liberada', 'mensagem' => "🔓 Pronto, $nome1! Sua internet foi *liberada em confiança por 1 dia* (até " . date('d/m H:i', strtotime('+1 day')) . ").\nAguarde 2 minutos e teste.\n\n⚠️ Pague até lá para não bloquear de novo — o PIX que enviei continua valendo."]);
            if ($ped) $resp(200, ['ok' => true, 'situacao' => 'confianca_pedido', 'mensagem' => "📝 $nome1, encaminhei o seu pedido de liberação (solicitação *nº " . (int)$ped[0][1] . "*) ao provedor, que vai analisar. " . $avisoEnc . "\n\nSe pagar pelo PIX, a liberação é *automática*."]);
            $resp(200, ['ok' => false, 'situacao' => 'confianca_recusada', 'mensagem' => 'Não consegui liberar em confiança: ' . (string)($resultado[0][1] ?? 'fale com o atendimento')]);
        }

        if ($acaoC === 'chamado') {
            $x = $lista[0];
            $est = (!$x['online'] && $x['status'] !== 'bloqueado') ? $onuEstado($x) : '';
            $diag = 'Diagnóstico automático do robô em ' . date('d/m/Y H:i') . ': ' . ($x['status'] === 'bloqueado' ? 'contrato BLOQUEADO'
                  : ($x['online'] ? 'conexão ONLINE (IP ' . $x['ip'] . ')' . ($x['presa'] ? ' — na faixa de bloqueio (rota presa)' : '')
                  : ($est === 'queda' ? 'PON EM QUEDA TOTAL (falha na região)' : ($est === 'sem_sinal' ? 'ONU SEM SINAL na OLT (fibra/energia)' : ($est === 'online' ? 'ONU com sinal, mas SEM autenticar' : 'equipamento SEM conexão')))))
                  . ' · login ' . ($x['login'] ?: '—') . ($x['sn'] !== '' ? ' · ONU ' . $x['sn'] : '') . '.';
            $relato = mb_substr(trim((string)($corpo['relato'] ?? '')), 0, 500);
            /* CHAMADO JÁ ABERTO (12/10/2026): quem já tem chamado aberto (enquanto estiver aberto — fechado libera abrir outro) e pede de novo NÃO ganha outro: o relato novo entra no chamado existente e o robô avisa que já está aberto e agradece o contato. */
            /* UM CHAMADO POR VEZ (13/10/2026): "já existe? → se não, cria" não era atômico; duas chamadas juntas criavam dois chamados e dois avisos. A trava (por WhatsApp) solta sozinha quando a resposta sai. */
            try { $jT = preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ''))[0]); if ($jT === '') { $qT = $db->prepare("SELECT celular FROM ws_cliente WHERE id=?"); $qT->execute([$x['cliente_id']]); $jT = (string)$qT->fetchColumn(); } ws_trava_tel($db, $jT); } catch (Throwable $e) {}
            $pendC = ws_pendencia_aberta($db, (int)$x['cliente_id']);   // em QUALQUER número/cadastro do mesmo cliente
            if ($pendC && $pendC['tipo'] !== 'chamado') $resp(200, ['ok' => true, 'situacao' => 'pendencia', 'chamado' => 0, 'existia' => true, 'mensagem' => ws_pendencia_msg($pendC, (string)$nome1)]);
            $jaR = $pendC ? ['id' => $pendC['id'], 'criado_em' => $pendC['criado']] : []; $chId = (int)($jaR['id'] ?? 0);
            if ($chId) {
                if ($relato !== '') { try { $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, usuario_id, autor_tipo, mensagem) VALUES (?, NULL, 'cliente', ?)")->execute([$chId, mb_substr($relato, 0, 1500)]); } catch (Throwable $e) {} }
                if (function_exists('ws_evento')) { try { ws_evento($db, (int)$x['cliente_id'], 'robo', 'Robô — cliente pediu chamado técnico de novo; já existe o chamado #' . $chId . ' aberto, avisei e agradeci o contato.'); } catch (Throwable $e) {} }
                $resp(200, ['ok' => true, 'situacao' => 'chamado', 'chamado' => $chId, 'existia' => true, 'mensagem' => "ℹ️ $nome1, você já tem o chamado *#$chId* aberto (desde " . date('d/m H:i', strtotime((string)$jaR['criado_em'])) . ").\nNossa equipe já foi avisada e entra em contato assim que possível.\nAgradecemos o seu contato! 🙏"]);
            }
            if (!$chId) {
                $db->prepare("INSERT INTO ws_chamado (cliente_id, contrato_id, tipo, titulo, descricao, prioridade, status) VALUES (?,?, 'suporte', ?, ?, ?, 'aberto')")
                   ->execute([$x['cliente_id'], $x['contrato'], 'Sem internet (aberto pelo robô)', trim(($relato !== '' ? "Relato do cliente: $relato\n\n" : '') . $diag), ($est === 'sem_sinal' || preg_match('/urgent|absurdo|vergonha|ninguem resolve|nada resolve|procon|anatel|cancel|ha \d+ (dias|semanas)|trabalho|home ?office|dias sem/', ws_chatbot_norm($relato))) ? 'alta' : 'normal']);   // tom de urgência/insatisfação sobe a prioridade (08/10/2026)
                $chId = (int)$db->lastInsertId();
                try { require_once dirname(__DIR__) . '/chamado_causa_lib.php'; ws_chamado_causa($db, $chId, false); } catch (Throwable $e) {}   // causa provável já na abertura
                // Aviso ao PROVEDOR (não à gerência nem à lista de técnicos) — aviso_provedor_lib.php
                if (is_file(dirname(__DIR__) . '/aviso_provedor_lib.php')) {
                    require_once dirname(__DIR__) . '/aviso_provedor_lib.php';
                    try { ws_aviso_provedor("🛠️ *Chamado #$chId* aberto pelo robô\n👤 {$x['nome']}\n$diag", (function () use ($db, $corpo, $x) { $j = preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ''))[0]); if ($j !== '') return $j; $q = $db->prepare("SELECT celular FROM ws_cliente WHERE id=?"); $q->execute([(int)$x['cliente_id']]); return (string)$q->fetchColumn(); })(), (string)($corpo['instanceName'] ?? '')); } catch (Throwable $e) {}
                }
            }
            $resp(200, ['ok' => true, 'situacao' => 'chamado', 'chamado' => $chId, 'mensagem' => "🛠️ Chamado *#$chId* aberto, $nome1. Nossa equipe técnica já foi avisada e vai entrar em contato."]);
        }

        // ---- diagnóstico
        if ($bloq) {
            $tit = function_exists('ws_chatbot_titulos') ? ws_chatbot_titulos($db, $doc, 'vencido') : [];
            $total = 0; foreach ($tit as $t) $total += (float)$t['valor'];
            $t0 = $tit[0] ?? null;
            $pix = (string)($t0['pix'] ?? ''); $link = (string)($t0['pix_link'] ?? '');
            // Título sem PIX (boleto sem QR): PIX da conta própria com o valor do título e o nome do cliente no identificador.
            if ($t0 && $pix === '' && function_exists('ws_chatbot_pix_manual')) {
                if (is_file(dirname(__DIR__) . '/pix.php')) require_once dirname(__DIR__) . '/pix.php';
                $txid = function_exists('ws_pix_txid_nome') ? ws_pix_txid_nome((string)$t0['nome'], (int)$t0['titulo']) : '***';
                $pm = ws_chatbot_pix_manual($db, 0, (float)$t0['valor'], $txid);
                if ($pm) $pix = (string)$pm['emv'];
            }
            $vt = $t0 ? 'do título de ' . date('d/m/Y', strtotime($t0['datavenc'])) . ' — R$ ' . number_format((float)$t0['valor'], 2, ',', '.') : '';
            $msg = "🔒 $nome1, sua internet está *bloqueada* por pendência financeira."
                 . ($tit ? "\nEm aberto: *R$ " . number_format($total, 2, ',', '.') . '* (' . count($tit) . ' título' . (count($tit) > 1 ? 's' : '') . ').' : '')
                 . ($pix !== '' ? "\n\nPague pelo PIX (copia e cola) $vt:\n\n$pix" . ($link !== '' ? "\n\nOu abra o QR Code: $link" : '')
                     . "\n\nAssim que o pagamento for confirmado, a liberação é *automática*.\nSe pagar por outro meio, mande o comprovante aqui."
                   : ($link !== '' ? "\n\nPague $vt por aqui: $link\n\nAssim que o pagamento for confirmado, a liberação é *automática*." : "\n\nPara a 2ª via, volte ao menu e escolha Boletos."))
                 . "\n\nDigite ou fale a opção que prefere: 👇\n\n1️⃣ - 📄 Receber o *boleto* (a baixa leva até *2 dias úteis*)\n2️⃣ - 🔓 Liberar 1 dia em confiança";   // (16/10/2026) mesmas opções do Suporte inteligente: 1 e 2, sem o 3
            $resp(200, ['ok' => true, 'situacao' => 'bloqueado', 'contratos' => $lista, 'valor_aberto' => round($total, 2), 'pix' => $pix, 'pix_link' => $link, 'mensagem' => $msg]);
        }
        $presas = array_values(array_filter($lista, fn($x) => $x['presa']));
        if ($presas) {
            // Rota presa: o próprio robô corrige (é exatamente o que o técnico faria) — derruba a sessão presa.
            $corrigiu = false;
            foreach ($presas as $x) if ($x['login'] !== '' && $limOk($x['contrato']) && function_exists('ws_rad_disconnect')) {
                try { ws_rad_disconnect($db, $x['login']); $corrigiu = true; } catch (Throwable $e) {}
                $limUsa($x['contrato']); $evento($x, 'Rota presa corrigida: sessão na faixa de bloqueio (IP ' . $x['ip'] . ') com contrato liberado foi derrubada');
            }
            $resp(200, ['ok' => true, 'situacao' => 'rota_presa', 'contratos' => $lista, 'mensagem' => $corrigiu
                ? "🔧 $nome1, achei o problema: sua internet já estava *liberada*, mas o seu equipamento ainda estava preso na conexão antiga de bloqueio.\n\n*Já corrigi.* Aguarde *2 minutos* e teste. Se não voltar, digite 2 para eu abrir um chamado técnico."
                : "🔧 $nome1, sua internet já está liberada, mas o equipamento ainda está preso na conexão de bloqueio. Desligue o roteador da tomada por 1 minuto e ligue de novo. Se não voltar, digite 2 para eu abrir um chamado técnico."]);
        }
        $on = array_values(array_filter($lista, fn($x) => $x['online']));
        if ($on) $resp(200, ['ok' => true, 'situacao' => 'online', 'contratos' => $lista, 'mensagem' => "✅ $nome1, sua conexão está *ativa* agora" . ($on[0]['ip'] !== '' ? ' (IP ' . $on[0]['ip'] . ')' : '') . ".\n\nSe está lenta ou sem navegar:\n1️⃣ - 🔄 Reconectar minha internet\n2️⃣ - 🛠️ Abrir chamado técnico"]);
        $est = $onuEstado($lista[0]);
        if ($est === 'queda') $resp(200, ['ok' => true, 'situacao' => 'queda_regiao', 'contratos' => $lista, 'mensagem' => "🚧 $nome1, identificamos uma *falha na rede da sua região* — não é no seu equipamento.

Nossa equipe técnica *já foi avisada* e está trabalhando para normalizar. Não precisa abrir chamado nem reiniciar nada: a internet volta sozinha assim que o reparo terminar.

Pedimos desculpas pelo transtorno 🙏"]);
        if ($est === 'sem_sinal') $resp(200, ['ok' => true, 'situacao' => 'sem_sinal', 'contratos' => $lista, 'mensagem' => "📡 $nome1, o seu equipamento de fibra (ONU) *não está respondendo* na nossa central.\n\nConfira:\n• se está ligado na tomada;\n• se tem alguma luz *vermelha* (LOS) acesa — isso indica problema no cabo de fibra.\n\nSe estiver tudo ligado e mesmo assim não voltar em 5 minutos:\n2️⃣ - 🛠️ Abrir chamado técnico"]);
        $resp(200, ['ok' => true, 'situacao' => 'offline', 'contratos' => $lista, 'mensagem' => "⚠️ $nome1, seu equipamento " . ($est === 'online' ? 'está *ligado e com sinal*, mas *não conectou* na internet.' : '*não está conectado* no momento.')
            . "\n\nPosso resolver daqui:\n1️⃣ - 🔄 " . ($est === 'online' ? 'Reiniciar meu equipamento remotamente' : 'Reconectar minha internet') . "\n2️⃣ - 🛠️ Abrir chamado técnico"]);
    } catch (Throwable $e) {
        $resp(500, ['ok' => false, 'erro' => 'falha no diagnóstico']);
    }
}

// TROCA DE VENCIMENTO E DE PLANO PELO ROBÔ (01/10/2026). Mesma credencial do robô.
//   GET  /api/vencimento/{cpf}            → dia atual + dias disponíveis (os que o provedor já usa) — mensagem pronta.
//   POST /api/vencimento  {cpf, dia}      → vira pedido em Suporte → Solicitações; a equipe aprova e o sistema aplica.
//   GET  /api/plano/{cpf}                 → planos oferecidos, numerados, com o atual marcado.
//   POST /api/plano       {cpf, opcao}    → pedido de troca de plano (ao aprovar: plano, velocidade na hora e mensalidade).
// Planos oferecidos = ativos, com valor, sem "bloq" no nome e em uso por 3+ contratos (só o que o provedor vende).
if (preg_match('#^(vencimento|plano)(?:/([0-9.\-/]+))?$#', $rota, $mv)) {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $qual = $mv[1];
    $corpo = json_decode((string)file_get_contents('php://input'), true); if (!is_array($corpo)) $corpo = $_POST;
    $doc = preg_replace('/\D/', '', (string)($mv[2] ?? ($corpo['cpf'] ?? '')));
    if (strlen($doc) !== 11 && strlen($doc) !== 14) $resp(200, ['ok' => false, 'mensagem' => 'Informe o CPF ou CNPJ do titular (só números).']);
    try {
        $db = ws_db();
        $st = $db->prepare("SELECT ct.*, c.nome FROM ws_contrato ct JOIN ws_cliente c ON c.id=ct.cliente_id
                            WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND ct.status<>'cancelado' ORDER BY ct.id LIMIT 1");
        $st->execute([$doc]); $ct = $st->fetch(PDO::FETCH_ASSOC);
        if (!$ct) $resp(200, ['ok' => false, 'mensagem' => 'Não encontrei contrato ativo com esse CPF/CNPJ. Confira o número ou fale com o atendimento.']);
        $nome1 = explode(' ', trim((string)$ct['nome']))[0];
        $pedido = function (string $tipo, array $campos, string $resumo) use ($db, $ct, $corpo) {
            require_once dirname(__DIR__) . '/solicitacoes_lib.php';
            $id = ws_sol_criar($db, (int)$ct['cliente_id'], (int)$ct['id'], $tipo, $campos, '', 'Pedido pelo robô do WhatsApp');
            // Aviso ao PROVEDOR (não à gerência) — aviso_provedor_lib.php
            if ($id && is_file(dirname(__DIR__) . '/aviso_provedor_lib.php')) {
                require_once dirname(__DIR__) . '/aviso_provedor_lib.php';
                $fc = ''; try { $q = $db->prepare("SELECT celular FROM ws_cliente WHERE id=?"); $q->execute([(int)$ct['cliente_id']]); $fc = (string)$q->fetchColumn(); } catch (Throwable $e) {}
                try { ws_aviso_provedor("📝 *Solicitação #$id* (robô)\n👤 {$ct['nome']}\n$resumo\nValidar em Suporte → Solicitações.", (string)(preg_replace('/\D/', '', explode('@', (string)($corpo['remoteJid'] ?? ''))[0]) ?: $fc), (string)($corpo['instanceName'] ?? '')); } catch (Throwable $e) {}
            }
            return $id;
        };
        if ($qual === 'vencimento') {
            $tot = (int)$db->query("SELECT COUNT(*) FROM ws_contrato WHERE status<>'cancelado'")->fetchColumn();
            $dias = array_map('intval', $db->query("SELECT dia_vencimento FROM ws_contrato WHERE status<>'cancelado' AND dia_vencimento BETWEEN 1 AND 30 GROUP BY dia_vencimento HAVING COUNT(*) >= " . max(1, (int)ceil($tot * 0.02)) . " ORDER BY dia_vencimento")->fetchAll(PDO::FETCH_COLUMN));
            $atual = (int)$ct['dia_vencimento'];
            if ($_SERVER['REQUEST_METHOD'] !== 'POST')
                $resp(200, ['ok' => true, 'dia_atual' => $atual, 'dias' => $dias, 'mensagem' => "📅 $nome1, hoje o seu vencimento é todo *dia $atual*.\n\nDias disponíveis: *" . implode(', ', array_diff($dias, [$atual])) . "*\n\nDigite o novo dia (ou 0 para voltar):"]);
            $dia = (int)preg_replace('/\D/', '', (string)($corpo['dia'] ?? ''));
            if (!in_array($dia, $dias, true) || $dia === $atual) $resp(200, ['ok' => false, 'mensagem' => "Esse dia não está disponível. Escolha um destes: " . implode(', ', array_diff($dias, [$atual])) . '.']);
            $id = $pedido('vencimento', ['dia' => ['de' => (string)$atual, 'para' => (string)$dia]], "Trocar vencimento do dia $atual para o dia $dia");
            $resp(200, ['ok' => true, 'solicitacao' => $id, 'mensagem' => "✅ Pedido *nº $id* registrado, $nome1: vencimento do dia $atual para o *dia $dia*.\nNossa equipe confere e confirma por aqui. As faturas já emitidas mantêm a data atual."]);
        }
        // plano
        $planos = $db->query("SELECT p.id, p.nome, p.valor, p.down_kbps FROM ws_plano p WHERE COALESCE(p.ativo,1)=1 AND p.valor > 0 AND p.nome NOT LIKE '%bloq%'
                              AND (SELECT COUNT(*) FROM ws_contrato x WHERE x.plano_id=p.id AND x.status<>'cancelado') >= 3 ORDER BY p.valor, p.down_kbps")->fetchAll(PDO::FETCH_ASSOC);
        // Mesma velocidade com preços diferentes (planos especiais/empresariais): oferece só o mais barato — o atual do cliente sempre aparece.
        $vistos = []; $planos = array_values(array_filter($planos, function ($p) use (&$vistos, $ct) { $k = (int)$p['down_kbps']; if ((int)$p['id'] === (int)$ct['plano_id']) return true; if (isset($vistos[$k])) return false; $vistos[$k] = 1; return true; }));
        $vel = fn($k) => ($m = (int)round((int)$k / 1000)) >= 1000 ? rtrim(rtrim(number_format($m / 1000, 1, ',', ''), '0'), ',') . ' Giga' : $m . ' Mega';
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $l = []; foreach ($planos as $i => $p) $l[] = ($i + 1) . ' - ' . $vel($p['down_kbps']) . ' — R$ ' . number_format((float)$p['valor'], 2, ',', '.') . ((int)$p['id'] === (int)$ct['plano_id'] ? '  ✅ (seu plano atual)' : '');
            $resp(200, ['ok' => true, 'mensagem' => "🚀 $nome1, estes são os nossos planos:\n\n" . implode("\n", $l) . "\n\nDigite o número do plano que deseja (ou 0 para voltar):"]);
        }
        $op = (int)preg_replace('/\D/', '', (string)($corpo['opcao'] ?? ''));
        $pl = $planos[$op - 1] ?? null;
        if (!$pl) $resp(200, ['ok' => false, 'mensagem' => 'Opção inválida. Digite o número de um dos planos da lista.']);
        if ((int)$pl['id'] === (int)$ct['plano_id']) $resp(200, ['ok' => false, 'mensagem' => 'Esse já é o seu plano atual. 😉']);
        $id = $pedido('plano', ['plano_id' => ['de' => (string)$ct['plano_id'], 'para' => (string)$pl['id']], 'plano' => ['de' => '', 'para' => $vel($pl['down_kbps']) . ' — R$ ' . number_format((float)$pl['valor'], 2, ',', '.')]], 'Trocar para o plano ' . $pl['nome']);
        $resp(200, ['ok' => true, 'solicitacao' => $id, 'mensagem' => "✅ Pedido *nº $id* registrado, $nome1: troca para o plano de *" . $vel($pl['down_kbps']) . "* (R$ " . number_format((float)$pl['valor'], 2, ',', '.') . ").\nNossa equipe confirma por aqui; a nova velocidade entra assim que aprovada."]);
    } catch (Throwable $e) {
        $resp(500, ['ok' => false, 'erro' => 'falha']);
    }
}

// POST /api/evolution/{token} → a Evolution entrega aqui a MÍDIA que o cliente mandou (02/10/2026). Só guarda áudio/imagem/
// documento recebidos (2 h, cache/midia_recebida) para o robô (/api/audio) e os comprovantes. Token = ws_midia_token().
if (preg_match('#^evolution/([a-f0-9]{32})$#', $rota, $mev)) {
    if (!hash_equals(ws_midia_token(), $mev[1])) $resp(401, ['erro' => 'token inválido']);
    $ev = json_decode((string)file_get_contents('php://input'), true);
    $lista = is_array($ev['data'] ?? null) ? (isset($ev['data'][0]) ? $ev['data'] : [$ev['data']]) : [];
    $n = 0;
    foreach ($lista as $d) {
        if (!is_array($d) || !empty($d['key']['fromMe'])) continue;
        if (strpos((string)($d['key']['remoteJid'] ?? ''), '@g.us') !== false) continue;   // (15/10/2026) GRUPO: só mensagem bruta — nada do fluxo/robô/comprovante/boleto pendente roda para grupo
        $id = (string)($d['key']['id'] ?? ''); $msg = (array)($d['message'] ?? []);
        $tipo = ''; foreach (['audioMessage', 'imageMessage', 'documentMessage', 'videoMessage', 'documentWithCaptionMessage'] as $k) if (!empty($msg[$k])) { $tipo = $k; break; }
        // (02/10/2026) última mensagem de cada número: o /api/primeira sabe se o atendimento começou por áudio
        $jidU = preg_replace('/\D/', '', explode('@', (string)($d['key']['remoteJid'] ?? ''))[0]);
        $repetida = ($id !== '' && $tipo === '' && ws_msg_ja_vista($id));   // mesma mensagem de TEXTO entregue de novo: não repete o que já foi feito com ela (mídia é idempotente por id e segue normal)
        /* UMA CONVERSA SÓ (14/10/2026): o que o cliente escreve na instância da API (Wellnet-02) com conversa viva na comum (Wellnet-01) é levado para a conversa da 01 e a da 02 é encerrada (unificar_run.php, em segundo plano). */
        try {
            $instEv = (string)($ev['instance'] ?? ($ev['instanceName'] ?? ''));
            if ($instEv !== '' && $jidU !== '' && !$repetida && is_file(dirname(__DIR__) . '/unificar_run.php')) {
                require_once dirname(__DIR__) . '/whatsapp.php'; $wcU = ws_wa_config();
                if (ws_wa_modo_api($wcU) !== '' && $instEv === ws_wa_modo_api($wcU)) {   // só o que chega na instância da API vai para a conversa da comum (botão de emergência desliga)
                    $txU0 = $tipo === '' ? trim((string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ''))) : ['audioMessage' => '[áudio]', 'imageMessage' => '[imagem]', 'documentMessage' => '[documento]', 'documentWithCaptionMessage' => '[documento]', 'videoMessage' => '[vídeo]'][$tipo];
                    if ($tipo !== '' && !empty($msg[$tipo]['caption'])) $txU0 .= ' ' . trim((string)$msg[$tipo]['caption']);
                    $phpBin = is_executable('/usr/bin/php') ? '/usr/bin/php' : 'php';
                    @exec('nohup ' . $phpBin . ' ' . escapeshellarg(dirname(__DIR__) . '/unificar_run.php') . ' ' . escapeshellarg($instEv) . ' ' . escapeshellarg($jidU) . ' ' . escapeshellarg(mb_substr($txU0, 0, 500)) . ' ' . escapeshellarg($id) . ' ' . escapeshellarg($tipo) . ' >/dev/null 2>&1 &');
                }
            }
        } catch (Throwable $e) {}
        // cliente respondeu ao modelo da cobrança: entrega o boleto + PIX que ficaram guardados (em segundo plano, ~7 s depois do texto do n8n)
        try {
            if (!$repetida && $jidU !== '' && is_file(dirname(__DIR__) . '/pendente_entregar_run.php')) {
                require_once dirname(__DIR__) . '/whatsapp.php';
                /* (15/10, casos Fernando Ursulino e Deibson Bezerra) quem responde ao modelo com um COMPROVANTE (foto/PDF) já pagou: NÃO entrega o boleto/PIX guardado — e descarta o pendente, para ele não chegar depois, num "ok/obrigado". */
                if (in_array($tipo, ['imageMessage', 'documentMessage', 'documentWithCaptionMessage'], true)) { if (ws_wa_pendente_existe($jidU)) { @unlink(ws_wa_pendente_arq($jidU)); } }
                elseif (ws_wa_pendente_existe($jidU)) { $phpBin = is_executable('/usr/bin/php') ? '/usr/bin/php' : 'php'; @exec('nohup ' . $phpBin . ' ' . escapeshellarg(dirname(__DIR__) . '/pendente_entregar_run.php') . ' ' . escapeshellarg($jidU) . ' >/dev/null 2>&1 &'); }
            }
        } catch (Throwable $e) {}
        if ($jidU !== '' && $id !== '') { $uf = ws_midia_dir() . '/ult_' . sha1($jidU) . '.json'; $txtU = $tipo === '' ? mb_substr(trim((string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ''))), 0, 300) : ''; $antU = json_decode((string)@file_get_contents($uf), true) ?: []; $histU = array_values(array_filter((array)($antU['hist'] ?? []), fn($h) => is_array($h) && time() - (int)($h[0] ?? 0) <= 300)); $capU = in_array($tipo, ['imageMessage', 'documentMessage', 'videoMessage'], true) ? mb_substr(trim((string)($msg[$tipo]['caption'] ?? '')), 0, 300) : ($tipo === 'documentWithCaptionMessage' ? mb_substr(trim((string)($msg[$tipo]['message']['documentMessage']['caption'] ?? '')), 0, 300) : ''); /* legenda da imagem/arquivo (12/10/2026, caso Edineide): é o relato do cliente; entra só no histórico das falas */ if ($txtU !== '' || $capU !== '') $histU = array_slice(array_merge($histU, [[time(), $txtU !== '' ? $txtU : $capU]]), -6); $midU = in_array($tipo, ['imageMessage', 'documentMessage', 'documentWithCaptionMessage'], true) ? ['id' => $id, 'tipo' => $tipo === 'imageMessage' ? 'imageMessage' : 'documentMessage', 'em' => time()] : (is_array($antU['midia'] ?? null) && time() - (int)($antU['midia']['em'] ?? 0) <= 300 ? $antU['midia'] : null); @file_put_contents($uf, json_encode(['id' => $id, 'tipo' => $tipo ?: 'texto', 'txt' => $txtU, 'em' => time(), 'hist' => $histU, 'midia' => $midU])); @chmod($uf, 0640); }
        // resposta à pergunta "para quem é esse pagamento?" (comprovantes_lib.php): só olha o texto quando há pergunta esperando (arquivo pequeno)
        // a fala do cliente depois de abrir o atendimento (fora do horário etc.) entra no CHAMADO e vira o tipo certo (mudança de endereço, instalação, cancelamento, suporte)
        if ($tipo === '' && $jidU !== '' && !$repetida) { $txCh = trim((string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ''))); if ($txCh !== '') { try { ws_chamado_robo_anexar(ws_db(), $jidU, $txCh); } catch (Throwable $e) { @error_log('[chamado_robo] ' . $e->getMessage()); } } }
        if ($tipo === '' && $jidU !== '' && !$repetida && (is_file(WS_CACHE . '/comp_perguntas.json') || preg_match('/(?<!\d)(?:\d[\d.\-\s\/]{9,20}\d)(?!\d)/', (string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ''))))) { $txR = trim((string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ''))); if ($txR !== '') { try { require_once dirname(__DIR__) . '/comprovantes_lib.php'; if (ws_comp_pergunta_resposta(ws_db(), $jidU, $txR) === null) ws_comp_juntar_texto(ws_db(), $jidU, $txR); } catch (Throwable $e) {} } }
        if ($id === '' || $tipo === '') continue;
        $x = $tipo === 'documentWithCaptionMessage' ? (array)($msg[$tipo]['message']['documentMessage'] ?? []) : (array)$msg[$tipo];
        $mime = (string)($x['mimetype'] ?? ''); $nome = (string)($x['fileName'] ?? '');
        $b64 = (string)($msg['base64'] ?? ($d['base64'] ?? ''));
        $bin = $b64 !== '' ? base64_decode(preg_replace('#^data:[^,]*,#', '', $b64), true) : false;
        if (($bin === false || strlen($bin) < 100) && preg_match('#^https?://#i', (string)($msg['mediaUrl'] ?? ''))) {
            $ch = curl_init((string)$msg['mediaUrl']); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3]);
            $bin = curl_exec($ch); if ((int)curl_getinfo($ch, CURLINFO_HTTP_CODE) !== 200) $bin = false; curl_close($ch);
        }
        if (is_string($bin) && strlen($bin) >= 100) {
            ws_midia_guardar($id, $bin, $mime, $nome); $n++;
            // imagem/PDF fora do fluxo do robô (ex.: atendimento humano): anota quem mandou; 10 min depois o que for comprovante é registrado sozinho
            if (in_array($tipo, ['imageMessage', 'documentMessage', 'documentWithCaptionMessage'], true)) { try { require_once dirname(__DIR__) . '/comprovantes_lib.php'; ws_comp_pendente_add($id, (string)($d['key']['remoteJid'] ?? ''), (string)($d['pushName'] ?? ''), $tipo === 'imageMessage' ? 'imageMessage' : 'documentMessage'); } catch (Throwable $e) {} }
        }
    }
    // há mídia esperando há 10+ min? processa em segundo plano (OCR demora; o webhook não pode esperar)
    try {
        require_once dirname(__DIR__) . '/comprovantes_lib.php';
        if (ws_comp_pendentes_prontos()) { $phpBin = is_executable('/usr/bin/php') ? '/usr/bin/php' : 'php'; @exec('nohup ' . $phpBin . ' ' . escapeshellarg(dirname(__DIR__) . '/comprovantes_orfas_run.php') . ' >/dev/null 2>&1 &'); }
    } catch (Throwable $e) {}
    $resp(200, ['ok' => true, 'guardadas' => $n]);
}

// POST /api/horario → estamos em horário de atendimento? (07/10/2026). Mesma credencial do robô. Resposta {ok, fora:"sim"|"nao", motivo}.
// O fluxo grava "fora" na variável fora_horario e desvia para o aviso de fora do horário. Regra e ajustes: ws_atendimento_aberto() (api_chatbot.php).
if ($rota === 'horario') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $h = ws_atendimento_aberto();
    $resp(200, ['ok' => true, 'fora' => $h['aberto'] ? 'nao' : 'sim', 'motivo' => $h['motivo']]);
}
/* POST /api/comp-api/{token} (14/10/2026) — INTERNA (token = ws_midia_token(), chamada pelo unificar_run.php): comprovante (foto/PDF) que o cliente mandou na instância da API. O robô da API fica DESLIGADO (silêncio em laço, ver
   CHANGELOG) — então o sistema lê o arquivo, registra em Financeiro → Comprovantes PIX e RESPONDE pela instância COMUM (sem custo na API). Corpo {id, tipo, jid, push}. Foto que não é comprovante: nada. */
if (preg_match('#^comp-api/([a-f0-9]{32})$#', $rota, $mca)) {
    if (!hash_equals(ws_midia_token(), $mca[1])) $resp(401, ['erro' => 'token inválido']);
    $bC = json_decode((string)file_get_contents('php://input'), true); if (!is_array($bC)) $resp(200, ['ok' => false]);
    $idC0 = (string)($bC['id'] ?? ''); $jidC = preg_replace('/\D/', '', (string)($bC['jid'] ?? '')); $tipoC = (string)($bC['tipo'] ?? 'imageMessage');
    if ($idC0 === '' || strlen($jidC) < 10) $resp(200, ['ok' => false, 'motivo' => 'dados']);
    try {
        require_once dirname(__DIR__) . '/whatsapp.php'; require_once dirname(__DIR__) . '/comprovantes_lib.php';
        /* UMA RESPOSTA SÓ (17/10/2026): o cliente que já está no robô (menu "8" na 01) manda o comprovante na 02 e a MESMA foto chegava por 2 caminhos (esta rota e o fluxo do Typebot) — o cliente recebia 2 respostas, uma dizendo "já foi recebido".
           Se o número está em conversa viva com o robô (≤30 min), espera 8 s; se o fluxo do robô registrou comprovante desse número nos últimos 3 min, ele responde e aqui fica em silêncio. */
        $t8C = substr($jidC, -8);
        $sessC = json_decode((string)@file_get_contents(WS_CACHE . '/robo_sessoes.json'), true);
        $sC = is_array($sessC) ? ($sessC[$t8C] ?? null) : null;
        if (is_array($sC) && empty($sC['concl']) && time() - (int)($sC['em'] ?? 0) <= 1800) {
            sleep(8);   // dá tempo do fluxo do robô registrar a mesma foto; se não registrar, segue e responde daqui (nada se perde)
            $dbC0 = ws_db(); $rq0 = $dbC0->prepare("SELECT COUNT(*) FROM ws_comprovante WHERE criado_em >= NOW() - INTERVAL 3 MINUTE AND RIGHT(REPLACE(COALESCE(telefone,''),'+',''),8)=?"); $rq0->execute([$t8C]);
            if ((int)$rq0->fetchColumn() > 0) $resp(200, ['ok' => true, 'comprovante' => true, 'robo_responde' => true]);
        }
        $lkC = WS_CACHE . '/comp_api_' . sha1($idC0) . '.lock'; if (is_file($lkC) && time() - filemtime($lkC) < 3600) $resp(200, ['ok' => true, 'repetido' => true]); @touch($lkC);
        $arqC = ws_midia_pegar($idC0, 12); if (!$arqC) $resp(200, ['ok' => false, 'motivo' => 'arquivo não chegou']);
        $tmpC = tempnam(sys_get_temp_dir(), 'wscp'); file_put_contents($tmpC, $arqC[0]);
        $mimeC = $arqC[1] ?: ($tipoC === 'imageMessage' ? 'image/jpeg' : 'application/pdf');
        $txC = ws_comp_ler($tmpC, $mimeC); @unlink($tmpC); $lxC = ws_comp_extrair($txC);
        $ehCompC = $lxC['e2e'] || preg_match('/\b(pix|comprovante|transfer[eê]ncia|pagamento efetuado|pagamento realizado|favorecido|recebedor|destinat[aá]rio|autentica[cç][aã]o)\b/iu', $txC);
        if (!$ehCompC) $resp(200, ['ok' => true, 'comprovante' => false]);
        $dbC = ws_db(); ws_selfheal($dbC);
        $idCmp = ws_comp_receber($dbC, ['comprovante' => $tipoC . '|' . $idC0, 'remoteJid' => $jidC . '@s.whatsapp.net', 'pushName' => (string)($bC['push'] ?? '')]);
        $rcC = ws_api_comp_resposta($dbC, $idCmp);
        $cliC = trim((string)$rcC['cliente']);
        $msgC = (($cliC !== '' && stripos($cliC, 'não identificado') === false) ? "Certo!! Pagamento refere-se ao cliente:\n\n✅ " . $cliC . "\n\n" : '') . (string)$rcC['mensagem'];
        $rsC = ws_wa_enviar_conversa($jidC, $msgC, ['evento' => 'robo_concluiu']);
        ws_robo_log($jidC, 'comprovante recebido — registrado (#' . $idCmp . ') e respondido ao cliente.');
        $resp(200, ['ok' => true, 'comprovante' => true, 'id' => $idCmp]);
    } catch (Throwable $e) { @error_log('[comp-api] ' . $e->getMessage()); $resp(200, ['ok' => false]); }
}
/* POST /api/midia-bot (14/10/2026) → {ok, mensagem}. O Typebot (os DOIS fluxos) chama esta rota no lugar de enviar imagem/áudio/vídeo pela conversa: o ARQUIVO sai pelo número oficial (API) — ws_wa_midia_url_api — e o robô só diz
   ao cliente onde olhar. {remoteJid, tipo (image|video|audio|document), url, legenda}. */
if ($rota === 'midia-bot') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $jidM = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]);
    try {
        require_once dirname(__DIR__) . '/whatsapp.php'; require_once dirname(__DIR__) . '/api_chatbot.php';
        $lkM = WS_CACHE . '/midia_bot_' . sha1($jidM . '|' . (string)($b['url'] ?? '')) . '.lock';
        if (is_file($lkM) && time() - filemtime($lkM) < 120) $resp(200, ['ok' => true, 'repetido' => 'sim', 'mensagem' => '']);   // o mesmo arquivo ao mesmo cliente em 2 min: não reenvia
        $rM = ws_wa_midia_url_api($jidM, (string)($b['tipo'] ?? 'image'), (string)($b['url'] ?? ''), (string)($b['legenda'] ?? ''));
        if (!empty($rM['ok'])) { @touch($lkM); if (!preg_match('/^558100000/', $jidM)) ws_robo_log($jidM, 'arquivo (' . ($b['tipo'] ?? 'imagem') . ') enviado pelo número oficial' . (!empty($rM['template']) ? ' — aguardando o cliente tocar em "Sim"' : '') . '.'); }
        $resp(200, ['ok' => !empty($rM['ok']), 'mensagem' => (string)$rM['mensagem']]);
    } catch (Throwable $e) { @error_log('[midia-bot] ' . $e->getMessage()); $resp(200, ['ok' => false, 'mensagem' => '']); }
}
/* POST /api/boleto-enviar (14/10/2026) → o PDF do boleto pedido no robô sai PELA INSTÂNCIA DA API (a 02), mesmo que o cliente esteja conversando na 01. {remoteJid, titulo (id da fatura), nome}
   Janela de 24 h da API aberta → texto + PDF direto. Fechada → só o modelo da Meta sai agora e o PDF fica guardado (cache/meta_pendente) para ser entregue quando o cliente tocar em "Sim"
   (webhook da Evolution → pendente_entregar_run.php). Devolve {ok, mensagem}: o texto que o robô mostra ao cliente dizendo ONDE olhar (o boleto vem do número oficial). Cliente em dobro: 1 envio por fatura a cada 10 min. */
if ($rota === 'boleto-enviar') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $fidB = (int)preg_replace('/\D/', '', (string)($b['titulo'] ?? '')); $jidB = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]);
    $semB = ['ok' => false, 'mensagem' => '📎 Não consegui montar o PDF agora.\nSe precisar, digite 7 para falar com o atendimento.'];
    if ($fidB <= 0 || strlen($jidB) < 10) $resp(200, $semB);
    try {
        require_once dirname(__DIR__) . '/whatsapp.php'; require_once dirname(__DIR__) . '/boleto_pdf.php'; require_once dirname(__DIR__) . '/api_chatbot.php';
        $dbB = ws_db();
        $lkB = WS_CACHE . '/boleto_env_' . $fidB . '_' . substr($jidB, -8) . '.lock';
        if (is_file($lkB) && time() - filemtime($lkB) < 600) $resp(200, ['ok' => true, 'repetido' => 'sim', 'mensagem' => '📎 O boleto em PDF já foi enviado há pouco pelo nosso número oficial.\nConfira as mensagens do WhatsApp.']);
        $pdfB = ws_pdf_faturas($dbB, [$fidB], 'boleto');
        if (!$pdfB) $resp(200, $semB);
        $nomeB = trim(explode(' ', trim((string)($b['nome'] ?? '')))[0]);
        /* (15/10) o PDF diz de QUAL boleto é (vencimento e valor) e avisa se há boleto mais ANTIGO em aberto — evita pagar o título errado. */
        $infoB = '';
        try { $sfB = $dbB->prepare("SELECT cliente_id, vencimento, valor, valor_pago, desconto FROM ws_fatura WHERE id=?"); $sfB->execute([$fidB]); $fB = $sfB->fetch(PDO::FETCH_ASSOC);
            if ($fB) { $infoB = "\n📅 Vencimento *" . date('d/m/Y', strtotime((string)$fB['vencimento'])) . "* — 💰 *R$ " . number_format((float)$fB['valor'], 2, ',', '.') . "*";
                $qaB = $dbB->prepare("SELECT COUNT(*), MIN(vencimento) FROM ws_fatura WHERE cliente_id=? AND id<>? AND status IN ('aberto','vencido') AND vencimento < ?"); $qaB->execute([(int)$fB['cliente_id'], $fidB, $fB['vencimento']]); [$nAnt, $mAnt] = $qaB->fetch(PDO::FETCH_NUM);
                if ((int)$nAnt > 0) $infoB .= "\n\n⚠️ Atenção: você tem *" . (int)$nAnt . " boleto(s) mais antigo(s)* em aberto (o mais antigo venceu em " . date('d/m/Y', strtotime((string)$mAnt)) . "). Confira antes de pagar."; } } catch (Throwable $e) {}
        $txtB = '📄 ' . ($nomeB !== '' ? $nomeB . ', aqui' : 'Aqui') . " está o seu boleto em PDF." . $infoB . "\nSe preferir pagar pelo PIX, é só pedir por aqui. 😉";
        $rB = ws_wa_enviar($jidB, $txtB, false, ['evento' => 'boleto', 'automatica' => false]);   // só pela API (instancia_api); janela fechada vira modelo
        if (empty($rB['ok'])) { ws_robo_log($jidB, 'boleto pedido no robô — não consegui enviar o PDF agora (confira o número oficial de WhatsApp).'); $resp(200, $semB); }
        @touch($lkB);
        if (!empty($rB['template'])) {
            ws_wa_pendente_guardar($jidB, [['tipo' => 'document', 'nome' => $pdfB['nome'], 'b64' => base64_encode($pdfB['pdf']), 'legenda' => '']], [$fidB]);
            ws_robo_log($jidB, 'boleto pedido no robô — enviado o aviso; o PDF segue assim que o cliente tocar em "Sim".');
            $resp(200, ['ok' => true, 'template' => 'sim', 'mensagem' => "📎 O boleto em PDF foi enviado pelo nosso número da central de envio:\n— toque em \"Sim\" e receba o PDF do seu boleto"]);
        }
        $rM = ws_wa_midia($jidB, 'document', $pdfB['nome'], base64_encode($pdfB['pdf']), '', ['evento' => 'boleto']);
        ws_robo_log($jidB, 'boleto pedido no robô — PDF ' . (!empty($rM['ok']) ? 'enviado' : 'não enviado (confira o número oficial de WhatsApp)') . '.');
        $resp(200, ['ok' => !empty($rM['ok']), 'mensagem' => !empty($rM['ok']) ? "📎 O boleto em PDF foi enviado pelo nosso *número oficial* — confira as mensagens do WhatsApp (se não achar, procure a conversa com a Wellnet)." : $semB['mensagem']]);
    } catch (Throwable $e) { @error_log('[boleto-enviar] ' . $e->getMessage()); $resp(200, $semB); }
}
/* POST /api/avaliar-pular (13/10/2026) → {pular:"sim"|"nao"}. O robô oferecia a pesquisa de satisfação ao fim de TODA interação (mesmo 3 vezes no dia), o que cansa o cliente e
   deixa o fluxo com cara de robô. Regra: no máximo 1 pesquisa por número a cada 12 h; as demais finalizações encerram direto (sem pesquisa). O Typebot (os DOIS fluxos) chama
   esta rota no início de cada grupo "Avaliação atendimento". Falha/erro = "nao" (oferece, como sempre). */
if ($rota === 'avaliar-pular') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $jA = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]); $pular = 'nao';
    /* (15/10, caso Samuel) cliente que acabou de ter um CHAMADO aberto pelo robô para o atendimento humano (últimos 30 min) não recebe a pesquisa: ele está esperando a equipe, não terminou o atendimento. */
    if ($jA !== '') { try { $qh = ws_db()->prepare("SELECT 1 FROM ws_chamado ch JOIN ws_cliente cl ON cl.id=ch.cliente_id WHERE ch.status IN ('aberto','em_andamento') AND ch.titulo LIKE '%robô%' AND ch.criado_em > NOW() - INTERVAL 30 MINUTE AND RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cl.celular,''),' ',''),'-',''),'(',''),')',''),8)=? LIMIT 1"); $qh->execute([substr($jA, -8)]); if ($qh->fetchColumn()) $resp(200, ['ok' => true, 'pular' => 'sim']); } catch (Throwable $e) {} }
    if ($jA !== '') {
        try {
            $fA = ws_midia_dir() . '/aval_ult.json'; $fh = @fopen($fA, 'c+');
            if ($fh && flock($fh, LOCK_EX)) {
                $mp = json_decode((string)stream_get_contents($fh), true); if (!is_array($mp)) $mp = [];
                $k = substr($jA, -8); $agora = time();
                foreach ($mp as $kk => $vv) if ($agora - (int)$vv > 86400) unset($mp[$kk]);
                if (isset($mp[$k]) && $agora - (int)$mp[$k] < 43200) $pular = 'sim'; else $mp[$k] = $agora;
                ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($mp)); flock($fh, LOCK_UN); fclose($fh);
            }
        } catch (Throwable $e) {}
    }
    $resp(200, ['ok' => true, 'pular' => $pular]);
}
/* POST /api/sessao-fim (14/10/2026) → o fluxo (os 2 Typebots, grupo "fecha a sessão") avisa que a conversa terminou nesta instância; libera a outra instância para este cliente. {remoteJid, instanceName} */
if ($rota === 'sessao-fim') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $jF = (string)($b['remoteJid'] ?? ''); if ($jF !== '' && strpos($jF, '{{') === false) ws_conversa_inst_fim($jF, (string)($b['instanceName'] ?? ''));
    $resp(200, ['ok' => true]);
}
/* GET /api/cobranca-aberta/{token}?n=<telefone> (15/10/2026) — usada pelo n8n ("Abridor templete_chat") antes de entregar o texto da cobrança guardado: {aberta: true|false, achou: true|false}. aberta=false = o cliente (e a conta dele: titular/adicionais)
   NÃO tem mais fatura em aberto/vencida ou vencendo em até 5 dias — então não faz sentido mandar a cobrança velha; o n8n só agradece ("já identificamos o pagamento"). Não achou cadastro pelo telefone = aberta=true (na dúvida, entrega). */
if (preg_match('#^cobranca-aberta/([a-f0-9]{32})$#', $rota, $mcb)) {
    if (!hash_equals(ws_midia_token(), $mcb[1])) $resp(401, ['erro' => 'token inválido']);
    $fCb = substr(preg_replace('/\D/', '', (string)($_GET['n'] ?? '')), -8);
    if (strlen($fCb) < 8) $resp(200, ['aberta' => true, 'achou' => false]);
    try {
        $dbCb = ws_db(); $ids = [];
        $q = $dbCb->prepare("SELECT id, COALESCE(NULLIF(titular_id,0), id) tit FROM ws_cliente WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''),8)=? OR RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(telefone,''),' ',''),'-',''),'(',''),')',''),8)=?");
        $q->execute([$fCb, $fCb]); $tits = [];
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $ids[(int)$r['id']] = 1; $tits[(int)$r['tit']] = 1; }
        if (!$ids) $resp(200, ['aberta' => true, 'achou' => false]);
        foreach (array_keys($tits) as $t) { $ids[$t] = 1; foreach ($dbCb->query("SELECT id FROM ws_cliente WHERE titular_id=" . (int)$t)->fetchAll(PDO::FETCH_COLUMN) as $ad) $ids[(int)$ad] = 1; }
        $in = implode(',', array_map('intval', array_keys($ids)));
        $ab = (int)$dbCb->query("SELECT COUNT(*) FROM ws_fatura WHERE cliente_id IN ($in) AND status IN ('aberto','vencido','processando') AND vencimento <= CURDATE() + INTERVAL 5 DAY")->fetchColumn();
        $resp(200, ['aberta' => $ab > 0, 'achou' => true, 'qtd' => $ab]);
    } catch (Throwable $e) { $resp(200, ['aberta' => true, 'achou' => false]); }
}
/* POST /api/cwproxy/{token}/{instância} (14/10/2026) — INTERMEDIÁRIO das respostas do atendente. O Chatwoot avisa a Evolution (webhook da caixa) quando o atendente digita; a caixa da API (Wellnet-02) apontava
   para /chatwoot/webhook/Wellnet-02, ou seja, a resposta saía PELA API (paga). Agora a caixa da API aponta para cá e a resposta é entregue à Evolution pela instância COMUM (grátis). Botão de emergência
   ligado (ou sem comum) = entrega pela própria instância, como era. Falhou a entrega pela comum → entrega pela original (o atendente nunca fica sem enviar). */
if (preg_match('#^cwproxy/([a-f0-9]{32})/([A-Za-z0-9_\-]{1,40})$#', $rota, $mcp)) {
    if (!hash_equals(ws_midia_token(), $mcp[1])) $resp(401, ['erro' => 'token inválido']);
    $corpoCw = (string)file_get_contents('php://input');
    require_once dirname(__DIR__) . '/whatsapp.php'; $wcP = ws_wa_config();
    $orig = $mcp[2];
    /* TEXTO sempre pela comum, online ou offline (regra do provedor: conversa não é paga na API). Se a comum estiver offline a mensagem falha no Chatwoot — o conserto é reconectar a comum, nunca cair para a API.
       ARQUIVO digitado pelo atendente (PDF, recibo, boleto, print, áudio) (23/10/2026): SEMPRE pela API (Wellnet-02), nunca pela comum (risco de banimento), sem queda para a comum se falhar — ver ws_cwproxy_alvo(). */
    [$alvo, $podeVoltar] = ws_cwproxy_alvo($wcP, $orig, (array)json_decode($corpoCw, true));
    $envia = function (string $inst) use ($wcP, $corpoCw): int {
        $ch = curl_init(rtrim((string)$wcP['url'], '/') . '/chatwoot/webhook/' . rawurlencode($inst));
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_POSTFIELDS => $corpoCw]);
        curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return $s;
    };
    $st = $envia($alvo);
    if (($st < 200 || $st >= 300) && $alvo !== $orig && $podeVoltar) $st = $envia($orig);
    http_response_code($st >= 200 && $st < 300 ? 200 : 502); header('Content-Type: application/json'); echo json_encode(['ok' => $st >= 200 && $st < 300, 'via' => $alvo]);
    /* MESMA CAIXA (14/10): a resposta digitada na caixa da API sai pela comum, mas a Evolution só a mostra na caixa de ONDE foi digitada. Aqui ela também entra na conversa da caixa da comum como NOTA INTERNA (não envia nada ao
       cliente — só para quem atende ver tudo num lugar só). Só o que um ATENDENTE digitou (sem source_id: o que o sistema/Evolution grava — recibo, boleto, modelo — vem com source_id e NUNCA é espelhado, fica só na caixa da API); só quando saiu pela comum e deu certo; sem conversa na comum, abre uma. Falha aqui nunca afeta o envio (já respondido). */
    if ($st >= 200 && $st < 300 && $alvo !== $orig) {
        if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
        try {
            $pl = json_decode($corpoCw, true);
            $txCw = trim((string)($pl['content'] ?? '')); $fCw = substr(preg_replace('/\D/', '', (string)($pl['conversation']['meta']['sender']['phone_number'] ?? '')), -8);
            if (($pl['event'] ?? '') === 'message_created' && ($pl['message_type'] ?? '') === 'outgoing' && empty($pl['private']) && empty($pl['source_id']) && strlen($fCw) === 8 && ($txCw !== '' || !empty($pl['attachments']))) {
                require_once dirname(__DIR__) . '/aviso_provedor_lib.php'; $cfsCw = ws_cw_cfg(); $cwC = $cfsCw[$alvo] ?? ($cfsCw[$orig] ?? null);
                if ($cwC) {
                    $baseC = rtrim((string)$cwC['url'], '/') . '/api/v1/accounts/' . rawurlencode((string)$cwC['conta']);
                    $hC = function (string $m, string $p, ?array $b = null) use ($baseC, $cwC): array { $ch = curl_init($baseC . $p); $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_TIMEOUT => 15, CURLOPT_HTTPHEADER => ['api_access_token: ' . (string)$cwC['token'], 'Content-Type: application/json']]; if ($b !== null) $o[CURLOPT_POSTFIELDS] = json_encode($b, JSON_UNESCAPED_UNICODE); curl_setopt_array($ch, $o); $r = curl_exec($ch); $sc = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$sc, json_decode((string)$r, true)]; };
                    [, $jI] = $hC('GET', '/inboxes'); $idC = 0; foreach ((array)($jI['payload'] ?? []) as $ib) if ((string)$ib['name'] === $alvo) $idC = (int)$ib['id'];
                    [, $jc] = $hC('GET', '/contacts/search?q=' . rawurlencode($fCw)); $cidC = 0; foreach ((array)($jc['payload'] ?? []) as $ct) if (substr(preg_replace('/\D/', '', (string)($ct['phone_number'] ?? '')), -8) === $fCw) { $cidC = (int)$ct['id']; break; }
                    if ($idC && $cidC) {
                        [, $jv] = $hC('GET', "/contacts/$cidC/conversations"); $convC = 0; $uC = 0;
                        foreach ((array)($jv['payload'] ?? []) as $v) if ((int)($v['inbox_id'] ?? 0) === $idC && in_array((string)($v['status'] ?? ''), ['open', 'pending'], true) && (int)($v['last_activity_at'] ?? 0) >= $uC) { $convC = (int)$v['id']; $uC = (int)($v['last_activity_at'] ?? 0); }
                        if (!$convC) { [$sN, $jN] = $hC('POST', '/conversations', ['inbox_id' => $idC, 'contact_id' => $cidC, 'status' => 'open']); if ($sN >= 200 && $sN < 300) $convC = (int)($jN['id'] ?? 0); }
                        if ($convC) $hC('POST', "/conversations/$convC/messages", ['content' => '↪️ ' . ($txCw !== '' ? $txCw : '[arquivo]'), 'message_type' => 'outgoing', 'private' => true]);
                    }
                }
            }
        } catch (Throwable $e) { @error_log('[cwproxy] espelho: ' . $e->getMessage()); }
    }
    exit;
}
// POST /api/suporte → GESTOR do "estou sem internet" (08/10/2026). Mesma credencial do robô. Corpo: {remoteJid, texto, novo (1 = começo), cpf, nome}.
// Resposta: {ok, mensagem, acao: continuar|fim, desvio_opcao ("7" atendente, "8" comprovante, "3" PIX, "0" menu, "" = fica aqui), cpf, nome, chamado}.
// Identifica pelo WhatsApp, diagnostica, entende o cliente (texto/áudio já transcrito) e executa reconectar / chamado técnico / confiança. Ver ws_sup_* (api_chatbot.php).
if ($rota === 'suporte') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $limpa = fn($v) => strpos((string)$v, '{{') !== false ? '' : trim((string)$v);
    $jid = preg_replace('/\D/', '', explode('@', $limpa($b['remoteJid'] ?? ''))[0]);
    $texto = $limpa($b['texto'] ?? ''); $audioMarc = ''; $midiaMarc = '';
    if (preg_match('/^(\w+Message)\|/', $texto, $mmS)) { if ($mmS[1] === 'audioMessage') $audioMarc = $texto; else $midiaMarc = $texto; $texto = ''; }   // só áudio é "áudio": imagem/arquivo tem tratamento próprio (caso Edineide, 12/10)
    if ($audioMarc !== '') { try { $falaS = ws_sup_audio_texto($audioMarc, $b); if ($falaS !== '') $texto = $falaS; } catch (Throwable $e) {} }   // 12/10/2026: áudio de até 180 s é entendido aqui (o /api/audio corta em 75 s)
    if ($midiaMarc !== '' && $jid !== '') { $legS = ws_sup_legenda($jid); if ($legS !== '') $texto = $legS; }   // a imagem veio com legenda ("nem está aparecendo a minha rede"): a legenda é o que o cliente disse
    if ($jid !== '') ws_sessao_concluir($jid);   // o suporte inteligente conduz e conclui a própria conversa
    $db = ws_db();
    $arq = WS_CACHE . '/suporte_sessao.json'; $todas = json_decode((string)@file_get_contents($arq), true); if (!is_array($todas)) $todas = [];
    foreach ($todas as $kk => $vv) if (time() - (int)($vv['em'] ?? 0) > 1800) unset($todas[$kk]);
    $k = substr(sha1($jid !== '' ? $jid : 'anon'), 0, 16);
    $st = (!empty($b['novo']) || !isset($todas[$k])) ? ['etapa' => 'inicio', 'cpf' => '', 'nome' => '', 'sit' => '', 'reiniciou' => 0, 'chamado' => 0, 'duvidas' => 0] : $todas[$k];
    $fim = function (string $msg, string $acao = 'continuar', string $desvio = '') use (&$todas, $k, &$st, $arq, $resp) {
        $st['em'] = time(); $todas[$k] = $st; @file_put_contents($arq, json_encode($todas)); @chmod($arq, 0640);
        $resp(200, ['ok' => true, 'mensagem' => $msg, 'acao' => $acao, 'desvio_opcao' => $desvio, 'cpf' => $st['cpf'], 'nome' => $st['nome'], 'chamado' => (int)$st['chamado']]);
    };
    $primeiro = fn($n) => mb_convert_case(mb_strtolower(explode(' ', trim((string)$n))[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
    /* RELATO NÃO SE PERDE (12/10/2026, caso Nailma Cristina): o que o cliente disse ao pedir suporte ("estamos sem internet") fica guardado; se ele não for identificado e cair no atendente,
       o chamado/aviso ao provedor leva esse relato. */
    if ($st['etapa'] === 'inicio' && empty($st['relato'])) {
        $rel0 = mb_strlen($texto) >= 8 && !preg_match('/^\s*(menu|voltar|sair|inicio|início)\s*$/iu', $texto) ? $texto : ws_sup_relato_inicial($jid);
        if ($rel0 !== '') { $st['relato'] = mb_substr($rel0, 0, 480); ws_sup_relato_guardar($jid, $rel0); }
    }
    /* O PEDIDO DE QUEM ABRE O SUPORTE NÃO PODE SER IGNORADO (13/10/2026, caso Rogério: "tem como vocês mudarem a senha da minha internet?" → o robô só mostrou o diagnóstico "se está lenta…"):
       na 1ª chamada o fluxo não manda o texto; a fala que o cliente acabou de escrever (guardada acima) passa a valer como o que ele pediu. */
    if ($st['etapa'] === 'inicio' && $texto === '' && !empty($st['relato'])) $texto = (string)$st['relato'];
    if (preg_match('/^\s*(menu|voltar|inicio|início|sair)\s*$/iu', $texto)) $fim('Tudo bem, voltando ao menu.', 'fim', '0');
    if (preg_match('/^\s*7\s*$/', $texto)) $fim('Certo! Vou te passar para o *atendimento*.', 'fim', '7');   // "7" do menu principal digitado dentro do suporte (14/10)
    /* MUDOU DE ASSUNTO NA IDENTIFICAÇÃO (14/10/2026): o suporte pediu "diga o primeiro nome / CPF" (etapa 'cpf') e o cliente respondeu "quero boleto" / "manda o pix" / "o valor não caiu": isso NÃO é nome nem CPF.
       Leva ao menu certo (2 boleto, 3 PIX, 8 comprovante) em vez de repetir a pergunta e, na 3ª vez, chamar atendente. Só na etapa 'cpf' (cliente já identificado pelo WhatsApp segue o tratamento próprio do suporte). */
    if ($st['etapa'] === 'cpf' && $st['cpf'] === '' && $texto !== '' && !preg_match('/^\d{1,2}$/', $texto) && ws_chatbot_nao_e_nome($texto) && !in_array(strlen(preg_replace('/\D/', '', $texto)), [11, 14], true)) {
        $dvI = ''; try { $dvI = ws_chatbot_desvio($texto, '', ['tipo' => 'menu', 'opcoes' => '', 'menu_principal' => '']); } catch (Throwable $e) {}
        if (in_array($dvI, ['2', '3', '8'], true)) { $st['etapa'] = 'inicio'; $fim(['2' => 'Certo! Vou te levar para o *boleto*.', '3' => 'Certo! Vou te levar para o *PIX*.', '8' => 'Certo! Vou te levar para o *envio do comprovante*.'][$dvI], 'fim', $dvI); }
    }
    // 1) quem é
    $doc = preg_replace('/\D/', '', $limpa($b['cpf'] ?? ''));
    if ($st['cpf'] === '' && in_array(strlen($doc), [11, 14], true)) $st['cpf'] = $doc;
    if ($st['cpf'] === '' && $st['etapa'] === 'inicio') {
        $ach = ws_sup_clientes_por_whats($db, $jid);
        if (count($ach) === 1) { $st['cpf'] = $ach[0]['cpf']; $st['nome'] = $primeiro($ach[0]['nome']); $st['zap'] = 1; }   // zap = identificado pelo próprio WhatsApp cadastrado
        elseif (count($ach) > 1) $st['cands'] = array_map(fn($x) => ['cpf' => $x['cpf'], 'nome' => $primeiro($x['nome'])], $ach);   // o número está em mais de um cadastro: pergunta qual
    }
    // respondeu só o primeiro nome ("Wellington") quando o número tem mais de um cadastro
    if ($st['cpf'] === '' && !empty($st['cands']) && $texto !== '') {
        $nt = ' ' . ws_chatbot_norm($texto) . ' '; $ac = [];
        foreach ($st['cands'] as $cd) if (strpos($nt, ' ' . ws_chatbot_norm($cd['nome']) . ' ') !== false) $ac[] = $cd;
        if (count($ac) === 1) { $st['cpf'] = $ac[0]['cpf']; $st['nome'] = $ac[0]['nome']; $st['zap'] = 1; }
    }
    if ($st['cpf'] === '' && $texto !== '') {
        $dg = preg_replace('/\D/', '', ws_chatbot_resposta($texto, '', 'numero'));
        if (in_array(strlen($dg), [11, 14], true)) $st['cpf'] = $dg;
    }
    // o cliente disse o NOME ("escola paulo freire continua sem internet") em vez do CPF: acha pelo nome (08/10/2026)
    if ($st['cpf'] === '' && $texto !== '' && $st['etapa'] === 'cpf') {
        $ac = ws_sup_clientes_por_nome($db, $texto);
        if (count($ac) === 1) { $st['cpf'] = $ac[0]['cpf']; $st['nome'] = $primeiro($ac[0]['nome']); $st['cands'] = []; }
        elseif (count($ac) > 1) $st['cands'] = array_map(fn($x) => ['cpf' => $x['cpf'], 'nome' => $x['nome']], $ac);
        else $st['falhas'] = (int)($st['falhas'] ?? 0) + 1;
        if ($st['cpf'] === '' && (int)($st['falhas'] ?? 0) >= 2) $fim('Não consegui localizar seu cadastro por aqui. Vou chamar um atendente para te ajudar agora mesmo. 🙏', 'fim', '7');
    }
    /* CLIENTE NÃO IDENTIFICADO QUE PEDE TÉCNICO/ATENDENTE (12/10/2026, caso Cristina: "Está num vermelho" → "Pode mandar alguém vim aqui" e o robô repetiu o pedido de CPF duas vezes, sem avisar ninguém):
       o pedido nunca fica sem resposta — a equipe é avisada na hora, com o relato, e o robô diz isso; o CPF/nome continua sendo pedido só para agilizar. Avisa uma vez só por conversa. */
    if ($st['cpf'] === '' && $st['etapa'] === 'cpf' && $texto !== '' && empty($st['avisado']) && empty($st['pediu1']) && in_array(ws_sup_intencao($texto, ''), ['chamado', 'humano', 'outro'], true)) {
        /* 1º pedido de técnico SEM identificação: o procedimento de suporte vem primeiro (reiniciar, ressincronizar, e só se não normalizar abrir o chamado) e ele depende de saber QUEM é o cliente
           (contrato/ONU). O robô explica isso e pede o CPF/nome; a equipe só é avisada se o cliente insistir sem se identificar (2º pedido, abaixo). */
        $st['pediu1'] = 1; $st['etapa'] = 'cpf';
        $fim("Entendi" . ($st['nome'] !== '' ? ", {$st['nome']}" : '') . ". Antes de mandar alguém, eu mesmo faço o *procedimento de suporte* aqui: verifico sua conexão, *reinicio e ressincronizo* o seu equipamento e, *se não normalizar, abro o chamado técnico* na hora. 🔧\n\nMas preciso saber quem é você — este número não está no nosso cadastro. Digite o *CPF/CNPJ* ou o *nome completo do titular*.");
    }
    if ($st['cpf'] === '' && $st['etapa'] === 'cpf' && $texto !== '' && empty($st['avisado']) && in_array(ws_sup_intencao($texto, ''), ['chamado', 'humano', 'outro'], true)) {
        $relCr = trim(($st['relato'] ?? '') . ((($st['relato'] ?? '') !== '' && stripos((string)$st['relato'], $texto) === false) ? ' · ' . $texto : ''));
        try { ws_chatbot_atendimento_abrir($db, ['jid' => $jid, 'motivo' => 'pedido', 'assunto' => 'Sem internet — pediu técnico (cliente não identificado)', 'relato' => $relCr !== '' ? $relCr : $texto]); } catch (Throwable $e) {}
        $st['avisado'] = 1; $st['etapa'] = 'cpf';
        $fim("Entendi" . ($st['nome'] !== '' ? ", {$st['nome']}" : '') . ". Não consegui identificar o cadastro por este número, mas *já avisei nossa equipe* com o seu pedido" . ($relCr !== '' ? " (\"" . mb_substr($relCr, 0, 100) . "\")" : '') . " e entraremos em contato assim que possível. 🙏\n\nPara agilizar, digite o *CPF/CNPJ* ou o *nome completo do titular*.");
    }
    if ($st['cpf'] === '') {
        $st['etapa'] = 'cpf';
        $qual = !empty($st['cands']) ? "Este número está em mais de um cadastro (" . implode(', ', array_unique(array_column($st['cands'], 'nome'))) . "). Diga o *primeiro nome* do titular ou digite o *CPF/CNPJ* (só números)." : "🔎 Para verificar sua conexão agora, digite o *CPF ou CNPJ* do titular (só números) ou o *nome completo do titular*.";
        $fim($qual . "

Se preferir, digite *menu* para voltar.");
    }
    /* PORTÃO DO SUPORTE (13/10/2026, caso Leonardo Ribeiro): quem entra no suporte e JÁ tem chamado aberto, solicitação pendente ou comprovante em conferência — em qualquer número/cadastro dele —
       NÃO abre outro: o robô informa o que está em andamento e que é só aguardar o retorno do provedor. O que o cliente escreveu agora entra no chamado existente. */
    if (($st['etapa'] === 'inicio' || $st['etapa'] === 'cpf') && $st['cpf'] !== '') {
        try {
            $qG = $db->prepare("SELECT id FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? AND status NOT IN ('cancelado','desativado') ORDER BY (titular_id IS NULL) DESC, id LIMIT 1");
            $qG->execute([$st['cpf']]); $cidG = (int)$qG->fetchColumn();
            $pendG = $cidG ? ws_pendencia_aberta($db, $cidG) : null;
            if ($pendG) {
                if ($pendG['tipo'] === 'chamado' && mb_strlen($texto) >= 4) { $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, usuario_id, autor_tipo, mensagem) VALUES (?, NULL, 'cliente', ?)")->execute([(int)$pendG['id'], mb_substr($texto, 0, 1500)]); }
                ws_robo_log($jid, 'entrou no suporte, mas já há ' . ($pendG['tipo'] === 'chamado' ? 'o chamado #' : ($pendG['tipo'] === 'solicitacao' ? 'a solicitação nº ' : 'um comprovante em conferência #')) . (int)$pendG['id'] . ' em andamento — informei e não abri outro.', $cidG);
                $st['chamado'] = $pendG['tipo'] === 'chamado' ? (int)$pendG['id'] : 0;
                $fim(ws_pendencia_msg($pendG, (string)$st['nome']), 'fim');
            }
        } catch (Throwable $eG) { @error_log('[suporte-portao] ' . $eG->getMessage()); }
    }
    // 2) diagnóstico (no começo, ou logo depois de receber o CPF)
    if ($st['etapa'] === 'inicio' || $st['etapa'] === 'cpf') {
        if ($st['etapa'] === 'cpf' && preg_match('/^\s*(menu|voltar|sair)\s*$/i', $texto)) $fim('Tudo bem, voltando ao menu.', 'fim', '0');
        $r = ws_sup_http('GET', 'conexao/' . $st['cpf']);
        if (empty($r['ok']) && in_array((string)($r['situacao'] ?? ''), ['cpf_invalido', 'nao_encontrado'], true)) {
            $st['cpf'] = ''; $st['etapa'] = 'cpf';
            $fim('⚠️ ' . (string)($r['mensagem'] ?? 'Não consegui achar esse CPF/CNPJ.') . "\n\nDigite o CPF ou CNPJ do titular de novo (só números), ou *menu* para voltar.");
        }
        $st['sit'] = (string)($r['situacao'] ?? ''); $st['etapa'] = 'acao';
        if ($st['nome'] === '' && !empty($r['contratos'][0]['nome'])) $st['nome'] = $primeiro($r['contratos'][0]['nome']);
        /* OPÇÕES SÓ QUANDO FAZEM SENTIDO (12/10/2026, casos José Eduardo e Zuleide): conectado NÃO oferece "liberar em confiança"; "chamado técnico" só quando o cliente relatou algo da internet ou o diagnóstico achou
           problema; bloqueado por pendência não oferece reiniciar/chamado técnico e ganha o BOLETO (baixa em até 2 dias úteis) como opção. Pedido fora da alçada vai direto ao atendimento humano. */
        $msgD = (string)($r['mensagem'] ?? 'Não consegui consultar agora.');
        $relD = ' ' . ws_chatbot_norm($texto) . ' ';
        $falouNet = trim($relD) === '' || (bool)preg_match('/ (internet|net|sinal|lent[ao]|caiu|cai|conexao|navega\w*|wifi|wi fi|sem|fora do ar|parou|travand\w*|oscil\w*|cai e volta) /', $relD);
        /* (15/10, caso Gessica Thais) internet ATIVA + problema em UM aparelho ("o celular pega, a TV não"): em vez do diagnóstico genérico ("reiniciar ou chamado técnico?") o robô ORIENTA o aparelho e oferece o chamado se continuar. */
        if ($texto !== '' && $st['sit'] === 'online' && ws_sup_intencao($texto, $st['sit']) === 'orientar') {
            $st['orient'] = 1;
            $fim(($st['nome'] !== '' ? "Olá, *{$st['nome']}*! " : '') . "Já verifiquei sua conexão agora: ✅ sua internet está *ativa* e chegando normalmente.

" . ws_sup_orientar($texto) . "

Se depois disso *continuar sem funcionar* — ou se preferir — é só me dizer *chamado*: eu abro um chamado e nossa equipe entra em contato com você. 🙏");
        }
        if ($texto !== '' && in_array(ws_sup_intencao($texto, $st['sit']), ['outro', 'wifi'], true)) { /* segue ao passo 3: abre o chamado / troca o Wi-Fi, sem despejar diagnóstico */ }
        else {
            if ($st['sit'] === 'bloqueado') {
                /* (17/10/2026, caso Laudicea) a mensagem do diagnóstico JÁ traz "Digite ou fale a opção… 1 boleto / 2 confiança"; sem tirar, as opções saíam em dobro. */
                $msgD = preg_replace('/\n+Digite ou fale a opção que prefere:.*$/su', '', (string)$msgD);
                $msgD = preg_replace('/\n+[^\n]*Liberar 1 dia em confian[^\n]*\n[^\n]*Abrir chamado t[^\n]*/u', '', $msgD)
                      . "\n\nDigite ou fale a opção que prefere: 👇\n\n1️⃣ - 📄 Receber o *boleto* (a baixa leva até *2 dias úteis*)\n2️⃣ - 🔓 Liberar 1 dia em confiança";
                $fraseD = '';
            } elseif ($st['sit'] === 'online' && !$falouNet) {
                $msgD = preg_replace('/\n+Se está lenta ou sem navegar:\n[^\n]*Reconectar minha internet\n[^\n]*Abrir chamado t[^\n]*/u', '', $msgD);
                $fraseD = 'Em que posso te ajudar?';
            } else $fraseD = 'Pode me dizer o que prefere (ou digitar o número): *reiniciar* ou *abrir chamado técnico*.';
            $fim(($st['nome'] !== '' ? "Olá, *{$st['nome']}*! " : '') . "Já verifiquei sua conexão agora:\n\n" . $msgD . ($fraseD !== '' ? "\n\n" . $fraseD : ''));
        }
    }
    // 3) entende e executa
    /* ÁUDIO QUE NÃO FOI ENTENDIDO (12/10/2026): não pede para repetir (o cliente já falou e pode ser um áudio longo): abre o chamado para o atendimento humano e avisa. */
    if ($texto === '' && $audioMarc !== '') {
        $pp = ws_sup_chamado_pedido($db, $jid, 'O cliente enviou um áudio que o robô não conseguiu ouvir/transcrever (provável áudio longo). Ouvir o áudio na conversa.');
        if (!empty($pp['pend_msg'])) $fim((string)$pp['pend_msg'], 'fim');
        if (!empty($pp['chamado'])) $fim(!empty($pp['existia'])
            ? "ℹ️ Recebi seu áudio, " . ($st['nome'] ?: 'tudo bem') . ", mas não consegui ouvir por aqui. Você já tem o chamado *#" . (int)$pp['chamado'] . "* aberto (desde " . $pp['desde'] . ") e anexei o aviso do seu áudio nele.\nNossa equipe entra em contato assim que possível.\nAgradecemos o seu contato! 🙏"
            : "Recebi seu áudio, " . ($st['nome'] ?: 'tudo bem') . ", mas não consegui ouvir por aqui. Para esse tipo de solicitação você precisa do *atendimento humano*: já abri o chamado *#" . (int)$pp['chamado'] . "* e, assim que possível, nossa equipe entrará em contato. 🙏", 'fim');
    }
    if ($texto === '' && $midiaMarc !== '') $fim('Recebi sua ' . (strpos($midiaMarc, 'image') === 0 ? 'imagem' : 'mensagem') . ', ' . ($st['nome'] ?: 'tudo bem') . '! 📷 Para eu te ajudar, me conte em poucas palavras o que está acontecendo (por exemplo: *sem internet*, *lenta* ou *luz vermelha no aparelho*). Ou diga *atendente*.');   // imagem sem legenda não é áudio
    if ($texto === '') $fim('Não consegui ouvir/ler sua resposta. Pode repetir? Diga *reiniciar*, *chamado técnico* ou *menu*.');
    /* NÚMERO DO MENU PRINCIPAL DIGITADO NO SUPORTE (13/10/2026, caso Rogério: digitou "7" — Falar com Atendente — duas vezes e ouviu "não entendi bem"): 4 a 9 são as opções do menu; o fluxo desvia para elas. */
    if (preg_match('/^\s*([4-9])\s*$/', $texto, $mdg)) $fim($mdg[1] === '7' ? 'Certo, vou chamar um atendente.' : 'Certo!', 'fim', $mdg[1]);
    $it = ws_sup_intencao($texto, $st['sit']);
    if (!empty($st['orient'])) {   // já recebeu a orientação do aparelho (15/10)
        $nO = ' ' . ws_chatbot_norm($texto) . ' ';
        if (preg_match('/ (continua|continuou|persiste|persistiu|nao resolveu|nao deu certo|nao adiantou|ainda nao|mesma coisa|nao foi|nao funcionou) /', $nO) || ($it === 'orientar' && (int)$st['orient'] >= 2)) $it = 'chamado';
        elseif ($it === 'orientar') { $st['orient'] = (int)$st['orient'] + 1; $fim(ws_sup_orientar($texto) . "

Se continuar sem funcionar, é só me dizer *chamado* que eu abro e nossa equipe entra em contato com você. 🙏"); }
    } elseif ($it === 'orientar') { $st['orient'] = 1; $fim(ws_sup_orientar($texto) . "

Se continuar sem funcionar — ou se preferir — é só me dizer *chamado*: eu abro um chamado e nossa equipe entra em contato com você. 🙏"); }
    $noturno = !ws_atendimento_aberto()['aberto'];
    if (($st['etapa'] ?? '') === 'wifi' && !in_array($it, ['menu', 'humano', 'resolvido', 'comprovante', 'pix'], true)) $it = 'wifi';   // está no meio do pedido de Wi-Fi
    /* TOM DO CLIENTE (08/10/2026): irritado/urgente ganha uma frase de empatia (uma vez); o relato acumulado sobe a prioridade do chamado */
    if (mb_strlen($texto) >= 12 && !in_array($it, ['menu', 'resolvido'], true)) $st['relato'] = mb_substr(trim(($st['relato'] ?? '') . ' ' . $texto), -480);
    $irr = (bool)preg_match('/absurd|vergonh|palhac|pessim|horriv|ridicul|cansad|farto|saco cheio|urgent|trabalho|home ?office|aula|semana|ninguem resolve|nada resolve|toda hora|procon|anatel|cancelar|!!/', ws_chatbot_norm($texto) . ($texto !== '' && substr_count($texto, '!') >= 2 ? ' !!' : ''));
    $emp = function (string $m) use (&$st, $irr): string { if (!$irr || !empty($st['emp'])) return $m; $st['emp'] = 1; return 'Sinto muito pelo transtorno' . ($st['nome'] !== '' ? ", {$st['nome']}" : '') . ' — entendi que é urgente e vou tratar com prioridade. 🙏' . "\n\n" . $m; };
    if ($it === 'menu') $fim('Certo, voltando ao menu.', 'fim', '0');
    if ($it === 'humano') $fim('Certo, vou chamar um atendente.', 'fim', '7');
    if ($it === 'comprovante') $fim('Certo! Vamos enviar o comprovante para eu conferir.', 'fim', '8');
    if ($it === 'pix') $fim('Certo, vamos ao pagamento pelo PIX.', 'fim', '3');
    if ($it === 'boleto') $fim("Certo! Vou te enviar o *boleto*.\n\n⚠️ Atenção: pagando por boleto, a baixa leva até *2 dias úteis*. Se precisar da internet até lá, depois diga *liberar em confiança* (1 dia). Pelo PIX a liberação é imediata.", 'fim', '2');
    if ($it === 'outro') {   // fora da alçada do robô (equipamento extra, comodato, mudança de endereço, instalação…): atendimento humano + chamado (ou aviso de que já existe um)
        $pp = ws_sup_chamado_pedido($db, $jid, $texto);
        if (!empty($pp['pend_msg'])) $fim((string)$pp['pend_msg'], 'fim');
        if (empty($pp['chamado'])) $fim('Esse tipo de solicitação precisa do *atendimento humano*. Vou chamar um atendente para você. 🙏', 'fim', '7');
        $st['chamado'] = (int)$pp['chamado'];
        if (!empty($pp['existia'])) $fim("ℹ️ " . ($st['nome'] ?: 'Tudo bem') . ", você já tem o chamado *#" . (int)$pp['chamado'] . "* aberto (desde " . $pp['desde'] . ").\nAnexei este novo pedido nele e nossa equipe entra em contato assim que possível.\nAgradecemos o seu contato! 🙏", 'fim');
        /* (15/10, caso Samuel) mudança de endereço / instalação nova: o robô já pede os dados do local (o atendente não precisa perguntar) e o chamado leva o tipo certo. */
        try { $tpC = $db->prepare("SELECT tipo FROM ws_chamado WHERE id=?"); $tpC->execute([(int)$pp['chamado']]); $tpC = (string)$tpC->fetchColumn(); } catch (Throwable $e) { $tpC = ''; }
        if ($tpC === 'mudana_de_endereo' || $tpC === 'instalacao') $fim("✅ Entendi, " . ($st['nome'] ?: 'tudo bem') . ": você quer " . ($tpC === 'instalacao' ? '*instalar a internet em um endereço novo*' : '*levar a internet para outro endereço*') . ". Já abri o chamado *#" . (int)$pp['chamado'] . "* para o nosso atendimento.

📍 Para agilizar, me envie aqui: *rua, número, bairro e um ponto de referência* do endereço novo (pode mandar também a localização do WhatsApp)." . ($noturno ? "

🌙 Estamos fora do horário comercial: o chamado fica registrado e é tratado assim que o atendimento abrir." : ''), 'fim');
        $fim($emp("Para esse tipo de solicitação você precisa do *atendimento humano*. Já estou *abrindo um chamado* (*#" . (int)$pp['chamado'] . "*) e, assim que possível, nossa equipe entrará em contato com você. 🙏" . ($noturno ? "\n\n🌙 Estamos fora do horário comercial: o chamado fica registrado e é tratado assim que o atendimento abrir." : '')), 'fim');
    }
    if ($it === 'resolvido') $fim("Que bom que normalizou, " . ($st['nome'] ?: 'tudo certo') . "! 🎉 Se precisar, é só chamar.", 'fim');
    if ($it === 'wifi') {   // TROCA DE WI-FI PELO ACS EMBUTIDO (08/10/2026): só quem fala do WhatsApp cadastrado; senha nunca aparece na resposta
        require_once dirname(__DIR__) . '/acs_lib.php';
        if (empty($st['zap'])) $fim('Por segurança, a troca de Wi-Fi só é feita pelo WhatsApp cadastrado do titular. Se preferir, diga *atendente* que eu chamo alguém.');
        $dv = ws_acs_do_cpf($db, $st['cpf']);
        if (!$dv) { $st['etapa'] = 'acao'; $fim('Seu equipamento ainda não está habilitado para troca remota do Wi-Fi. Posso abrir um *chamado técnico* para a equipe fazer isso — quer? (diga *chamado*)'); }
        $ped = ws_acs_wifi_pedido($texto);
        if (!isset($ped['senha']) && !isset($ped['ssid']) && !isset($ped['canal'])) { $st['etapa'] = 'wifi'; $fim('Claro! O que quer mudar no Wi-Fi? Diga, por exemplo: *senha MinhaSenha123* (8 ou mais caracteres), *nome MinhaRede* ou *canal 6*. Para a rede 5G, diga "5g" junto. Ou *menu* para sair.'); }
        $v = ws_acs_wifi_validar($ped);
        if (!$v['ok']) { $st['etapa'] = 'wifi'; $fim('⚠️ ' . $v['erro']); }
        ws_acs_enfileirar($db, (int)$dv['id'], 'wifi', ['q' => $v['q']], 'robô');
        $st['etapa'] = 'pos';
        $min = max(1, (int)ceil((int)ws_acs_cfg()['intervalo'] / 60));
        $off = empty($dv['ultimo_inform']) || (time() - strtotime((string)$dv['ultimo_inform'])) > 3 * (int)ws_acs_cfg()['intervalo'];
        $oq = array_filter([isset($v['q']['ssid']) ? 'o nome da rede para *' . $v['q']['ssid'] . '*' : '', isset($v['q']['senha']) ? 'a senha' : '', isset($v['q']['canal']) ? ($v['q']['canal'] ? 'o canal para *' . $v['q']['canal'] . '*' : 'o canal para automático') : '']);
        $fim($emp('✅ Pedido enviado ao seu equipamento: vou trocar ' . implode(', ', $oq) . ' (rede ' . ($v['q']['banda'] === '5' ? '5G' : '2,4G') . ").\n\nEle aplica em até {$min} min" . ($off ? ' (ele está sem falar conosco há um tempo — se não mudar, ligue o roteador na tomada e me avise)' : '') . ". Seus aparelhos vão desconectar do Wi-Fi por alguns segundos e será preciso entrar de novo com os dados novos."));
    }
    if ($it === 'confianca') {
        $r = ws_sup_http('POST', 'conexao/confianca', ['cpf' => $st['cpf'], 'relato' => (string)($st['relato'] ?? '')]);
        $fim($emp((string)($r['mensagem'] ?? 'Não consegui liberar agora.') . "\n\nDepois me diga se voltou, ou peça um *chamado técnico*."));
    }
    /* NÃO ABRIR CHAMADO DE IMEDIATO (15/10/2026, caso Daniele: reclamação vaga de lentidão → o robô reconectou e, quando ela repetiu o texto, já abriu o chamado sem saber se tinha resolvido): chamado técnico só quando o cliente PEDE ou diz que
       continua/já tentou. Reclamação vaga: 1º tenta resolver (reconectar); depois de reconectar, pergunta se voltou e só abre o chamado se persistir. */
    if ($it === 'chamado' && $st['sit'] !== 'bloqueado') {
        $nP = ' ' . ws_chatbot_norm($texto) . ' ';
        $explicito = preg_match('/^\s*2\s*$/', trim($texto)) || preg_match('/ (chamado|tecnico|tecnica|visita|continua|continuo|persiste|persistiu|ainda (sem|nao)|nao (voltou|resolveu|adiantou|funcionou|deu certo)|ja (reinici|deslig|religu|tent|fiz|troquei|testei)|reiniciei|desliguei|religuei|tentei|testei) /', $nP);
        if (!$explicito) {
            if (!empty($st['reiniciou'])) { $st['etapa'] = 'pos'; $fim("Antes de abrir um chamado, quero confirmar: depois de reconectar, a sua internet *melhorou*? Responda *voltou* (se normalizou) ou *continua sem* / *chamado* (se persiste — aí eu abro o chamado técnico). 🙏"); }
            $it = 'reconectar';   // tenta resolver primeiro
        }
    }
    if ($it === 'reconectar') {
        if ($st['sit'] === 'bloqueado') $fim("Sua internet está *bloqueada por pendência* — reiniciar não resolve. Pague pelo PIX que enviei acima (a liberação é automática) ou diga *liberar em confiança*.");
        if (!empty($st['reiniciou'])) $fim("Já reiniciei sua conexão há pouco. Se continua sem internet, posso abrir um *chamado técnico* para a equipe ir até você — quer? (diga *chamado*)");
        $r = ws_sup_http('POST', 'conexao/reconectar', ['cpf' => $st['cpf']]);
        if (!empty($r['ok'])) $st['reiniciou'] = 1;
        $st['etapa'] = 'pos';
        $fim($emp((string)($r['mensagem'] ?? 'Pedi a reconexão.') . "\n\nDepois de 2 minutos, teste e me diga: *voltou* ou *continua sem*."));
    }
    if ($it === 'chamado' || ($it === '' && ++$st['duvidas'] >= 3)) {
        $rel = mb_substr(trim((string)($st['relato'] ?? '')), 0, 480);
        $r = ws_sup_http('POST', 'conexao/chamado', ['cpf' => $st['cpf'], 'relato' => $rel]);
        $st['chamado'] = (int)($r['chamado'] ?? 0);
        $msg = (string)($r['mensagem'] ?? 'Abri o chamado técnico.');
        if ($noturno && empty($r['existia'])) $msg .= "\n\n🌙 Estamos fora do horário comercial: o chamado já está aberto e a equipe técnica trata assim que iniciar o expediente.";
        $fim(empty($r['existia']) ? $emp($msg) : $msg, 'fim');
    }
    $fim($st['sit'] === 'bloqueado' ? "Não entendi bem. Posso te enviar o *boleto* ou *liberar em confiança* (1 dia). O que prefere?" : "Não entendi bem. Posso *reiniciar* sua conexão ou abrir um *chamado técnico* (visita). O que prefere?");
}

// POST /api/pos-atendimento → (12/10/2026) o cliente escreveu algo DEPOIS de o atendimento ser aberto (fora do horário/atendente). Corpo {remoteJid}. Resposta {ok, acao: "suporte"|"continuar"}:
// "suporte" = é problema de internet → o fluxo pula para o Suporte inteligente; "continuar" = segue como atendimento humano. Ver ws_sup_pos_atendimento_acao().
if ($rota === 'pos-atendimento') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $jidPA = strpos((string)($b['remoteJid'] ?? ''), '{{') !== false ? '' : trim((string)($b['remoteJid'] ?? ''));
    $protoPA = strpos((string)($b['protocolo'] ?? ''), '{{') !== false ? '' : trim((string)($b['protocolo'] ?? ''));
    $rPA = ['acao' => 'continuar', 'mensagem' => ws_sup_msg_humano($protoPA)];
    try { if ($jidPA !== '') $rPA = ws_sup_pos_atendimento($jidPA, $protoPA); } catch (Throwable $e) {}
    $acaoPA = $rPA['acao'];
    try {
        if ($acaoPA === 'suporte') ws_robo_log($jidPA, 'cliente falou de problema na internet depois de abrir o atendimento — levei ao suporte inteligente (disse: "' . mb_substr(ws_sup_ultima_fala($jidPA), 0, 70) . '").');
        elseif ($acaoPA === 'recibo' || $acaoPA === 'comprovante') ws_robo_log($jidPA, 'cliente pediu ' . ($acaoPA === 'recibo' ? 'recibo' : 'para enviar comprovante') . ' depois de abrir o atendimento — informei boletos em aberto/pagamento e que o recibo vai após a conferência.');
    } catch (Throwable $e) {}
    $resp(200, ['ok' => true, 'acao' => $acaoPA, 'mensagem' => $rPA['mensagem'], 'desvio_opcao' => (string)($rPA['desvio_opcao'] ?? '')]);
}
// POST /api/atendimento → o robô avisa que passou o cliente para uma PESSOA (07/10/2026). Mesma credencial do robô.
// Corpo: {remoteJid, nome, assunto (nº da opção do menu ou texto), motivo (fora_horario|escalada), protocolo}. Abre/reaproveita o chamado
// (cliente identificado pelo WhatsApp), grava UMA linha no log e avisa a equipe. Resposta {ok, chamado}. Ver ws_chatbot_atendimento_abrir().
if ($rota === 'atendimento') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $limpa = fn($v) => strpos((string)$v, '{{') !== false ? '' : trim((string)$v);
    $ass = $limpa($b['assunto'] ?? '');
    ws_sessao_concluir($limpa($b['remoteJid'] ?? ''));   // atendimento passado a uma pessoa = conversa concluída
    if (preg_match('/^\d$/', $ass)) { foreach (explode('|', ws_chatbot_menu_principal_padrao()) as $op) if (preg_match('/^' . $ass . '=(.+)$/u', $op, $mo)) $ass = $mo[1]; }
    try { $r = ws_chatbot_atendimento_abrir(ws_db(), ['jid' => $limpa($b['remoteJid'] ?? ''), 'nome' => $limpa($b['nome'] ?? ''), 'assunto' => $ass, 'motivo' => in_array(($b['motivo'] ?? ''), ['escalada', 'fora_horario'], true) ? $b['motivo'] : 'fora_horario', 'protocolo' => $limpa($b['protocolo'] ?? ''), 'audio' => !empty($b['audio']), 'relato' => ws_sup_relato_sessao($limpa($b['remoteJid'] ?? ''))]); }
    catch (Throwable $e) { $r = ['chamado' => 0]; }
    /* ATENDIMENTO PEDIDO DE NOVO EM MENOS DE 1 HORA (12/10/2026): o fluxo mostra só o aviso curto ("fora do horário… seu chamado está aberto") em vez de repetir as 5 mensagens (Olá, Obrigado, horário,
       Central, aviso) — cada mensagem enviada custa. "repetido" = "sim" quando este número já pediu atendente na última hora. */
    $repAt = 'nao';
    try {
        $jRA = preg_replace('/\D/', '', explode('@', $limpa($b['remoteJid'] ?? ''))[0]);
        if ($jRA !== '' && !preg_match('/^558100000/', $jRA)) {
            $fRA = WS_CACHE . '/robo_atend_ult.json'; $xRA = json_decode((string)@file_get_contents($fRA), true); if (!is_array($xRA)) $xRA = [];
            foreach ($xRA as $kk => $tt) if (time() - (int)$tt > 7200) unset($xRA[$kk]);
            $kRA = substr(sha1($jRA), 0, 16); if (isset($xRA[$kRA]) && time() - (int)$xRA[$kRA] < 3600) $repAt = 'sim';
            $xRA[$kRA] = time(); @file_put_contents($fRA, json_encode($xRA)); @chmod($fRA, 0640);
        }
    } catch (Throwable $e) {}
    $pendA = (string)($r['pendencia'] ?? '');   // já tem chamado/solicitação/comprovante aberto (em qualquer número do cliente): o fluxo mostra ESTA mensagem e não repete o atendimento
    if ($pendA !== '') $repAt = 'sim';
    $resp(200, ['ok' => true, 'chamado' => (int)($r['chamado'] ?? 0), 'repetido' => $repAt, 'pendente' => $pendA !== '' ? 'sim' : 'nao', 'mensagem_pendente' => $pendA]);
}
// POST /api/primeira → o atendimento COMEÇOU por áudio? (02/10/2026). Corpo {remoteJid, opcoes}. Se a última mensagem do
// número (≤ 60 s, entregue pelo webhook da Evolution) foi um ÁUDIO ainda não usado, transcreve e devolve a opção do menu
// ({texto:"2"}); senão {texto:""} na hora (começo por texto não espera nada). Cada áudio é usado uma vez só.
if ($rota === 'primeira') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    if (strpos((string)($b['remoteJid'] ?? ''), '@g.us') !== false) $resp(200, ['texto' => '', 'silencio' => 'sim']);   // (15/10/2026) grupo nunca recebe menu nem fluxo
    $jidP = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]);
    if ($jidP === '') $resp(200, ['texto' => '']);
    /* NOME DO CADASTRO (10/10/2026): o WhatsApp já identifica o cliente — o robô não precisa perguntar "Qual o nome do cliente?" de novo. Toda resposta
       desta rota leva "nome_cadastro" (vazio = número desconhecido → o fluxo pergunta como sempre). */
    $nomeCadP = '';
    try {
        $qN = ws_db()->prepare("SELECT nome FROM ws_cliente WHERE status NOT IN ('cancelado','inativo','desativado') AND RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''),8)=? ORDER BY (titular_id IS NULL) DESC, id LIMIT 1");
        $qN->execute([substr($jidP, -8)]); $nN = (string)$qN->fetchColumn();
        if ($nN !== '') $nomeCadP = ws_chatbot_acabamento($nN, 'nome');
    } catch (Throwable $e) {}
    $resp0 = $resp; $resp = function (int $code, array $arr) use ($resp0, $nomeCadP) { if (!isset($arr['nome_cadastro'])) $arr['nome_cadastro'] = $nomeCadP; if ($code === 200 && !isset($arr['ok_primeira'])) $arr['ok_primeira'] = 'sim'; $resp0($code, $arr); };   /* ok_primeira (14/10): resposta BOA desta rota; o fluxo termina em silêncio se ela falhar/for recusada (503 do quebra-laço) em vez de seguir para o menu */
    /* ANTI-DUPLICAÇÃO (13/10/2026): o mesmo número abrindo 2 atendimentos quase juntos (webhook em dobro / 2 instâncias / cliente mandando 2 mensagens
       antes do robô responder) gerava olá+menu em dobro. Trava atômica por número: a 1ª chamada segue; outra em até 15 s fica CALADA (silencio=sim, dup=sim). */
    try {
        $lkDir = ws_midia_dir() . '/lock'; if (!is_dir($lkDir)) @mkdir($lkDir, 0775, true);
        $lkF = $lkDir . '/p_' . sha1($jidP . '|' . trim((string)($b['instanceName'] ?? ''))) . '.lock'; /* por número E instância: o silêncio de uma instância não suprime o início do robô da outra (14/10) */ $fhL = @fopen($lkF, 'c+');
        if ($fhL && flock($fhL, LOCK_EX)) {
            $tL = (int)trim((string)stream_get_contents($fhL)); $agoraL = time();
            if ($tL > 0 && $agoraL - $tL <= 15) { flock($fhL, LOCK_UN); fclose($fhL); /* QUEBRA-LAÇO (14/10/2026): às 04:15 o teste do cliente na API gerou um laço (Typebot/Evolution chamando /api/primeira ~60×/s por 1h40, 230 mil linhas no histórico) que só se mantinha enquanto a resposta era "silêncio com sucesso".
               Início duplicado legítimo: silêncio (200), SEM gravar histórico por chamada. Mais de 5 chamadas do mesmo número em 10 s = laço: responde 503 (o laço morre) e grava UMA linha por minuto. */
                $rf = WS_CACHE . '/primeira_taxa_' . substr(sha1($jidP . '|' . trim((string)($b['instanceName'] ?? ''))), 0, 12) . '.json'; $rt = json_decode((string)@file_get_contents($rf), true); if (!is_array($rt) || time() - (int)($rt['t0'] ?? 0) > 10) $rt = ['t0' => time(), 'n' => 0, 'log' => (int)($rt['log'] ?? 0)];
                $rt['n']++;
                if ($rt['n'] > 5) { if (time() - (int)$rt['log'] >= 60) { $rt['log'] = time(); ws_robo_log($jidP, 'mensagens repetidas do mesmo número foram barradas (várias chamadas em poucos segundos).'); } @file_put_contents($rf, json_encode($rt));
                    /* O laço se mantém enquanto o fluxo guarda silencio_ws="sim" e termina sem esperar resposta. Resposta que SOBRESCREVE o silêncio ('nao') faz o fluxo seguir ao menu normal (que espera o cliente) e o laço morre — custo: no máximo 1 menu. */
                    $resp(200, ['texto' => '', 'silencio' => 'nao', 'dup' => 'nao', 'laco' => 'sim']); }
                @file_put_contents($rf, json_encode($rt));
                try { ws_conversa_inst_dup($jidP); } catch (Throwable $e) {} $resp(200, ['texto' => '', 'silencio' => 'sim', 'dup' => 'sim']); }
            ftruncate($fhL, 0); rewind($fhL); fwrite($fhL, (string)$agoraL); flock($fhL, LOCK_UN); fclose($fhL);
        }
    } catch (Throwable $e) {}
    /* UMA CONVERSA POR VEZ ENTRE AS INSTÂNCIAS (14/10/2026): outra instância já está com a conversa viva deste cliente → esta fica calada (o atendente vê tudo no Chatwoot). */
    try {
        $instP = trim((string)($b['instanceName'] ?? ''));
        require_once dirname(__DIR__) . '/whatsapp.php';
        $donaP = ($instP !== '' && $instP === ws_wa_modo_api(ws_wa_config())) ? '' : ws_conversa_inst_abrir($jidP, $instP);   // a instância da API não "toma" a conversa: o robô dela fica calado e a conversa vai para a comum (abaixo)
        if ($donaP !== '') { ws_robo_log($jidP, 'ficou calado: o cliente já está em atendimento em outro número (uma conversa por vez).'); $resp(200, ['texto' => '', 'silencio' => 'sim', 'outra_instancia' => $donaP]); }
    } catch (Throwable $e) {}
    $uf = ws_midia_dir() . '/ult_' . sha1($jidP) . '.json'; $u = null;
    for ($k = 0; $k < 6; $k++) {   // o webhook corre junto com o início do robô: até ~2,4 s para a última mensagem aparecer
        $u = json_decode((string)@file_get_contents($uf), true);
        if (is_array($u) && (time() - (int)($u['em'] ?? 0) <= 60 || (!empty($u['calado']) && time() - (int)($u['em'] ?? 0) <= 900))) break;   // 'calado': já silenciamos ESTA fala — o fluxo chama de novo e não pode mandar olá+menu 1 min depois (caso Daniele, aniversário)
        $u = null; usleep(400000);
    }
    /* RESPOSTA AO PIX QUE O ROBÔ ACABOU DE MANDAR (14/10/2026, caso Ronaldo Adriano): o menu "1 QR Code / 2 Chave PIX / 3 Falar com Financeiro" ficou sem resposta, o sistema mandou o PIX sozinho e,
       no mesmo minuto, o cliente digitou "1" — o robô abriu com "Olá" + o menu principal inteiro. Se o número recebeu o PIX automático nos últimos 60 min e a 1ª fala é só "1"/"2"/"3",
       a resposta é no contexto: 1/2 = "o PIX está logo acima" (sem menu); 3 = atendente/financeiro. */
    try {
        $txA = trim((string)($u['txt'] ?? ''));
        if ($u && ($u['tipo'] ?? '') === 'texto' && preg_match('/^[1-3]$/', $txA) && time() - (int)($u['em'] ?? 0) <= 120) {
            $mjA = json_decode((string)@file_get_contents(WS_CACHE . '/robo_pix_auto.json'), true);
            if (is_array($mjA) && isset($mjA[substr($jidP, -8)]) && time() - (int)$mjA[substr($jidP, -8)] <= 3600) {
                if ($txA === '3') { ws_robo_log($jidP, 'resposta "3" logo após o PIX automático → atendente/financeiro (sem reabrir o menu).'); $resp(200, ['texto' => '7']); }
                require_once dirname(__DIR__) . '/whatsapp.php';
                ws_robo_log($jidP, 'resposta "' . $txA . '" logo após o PIX automático → lembrou que o PIX já foi enviado (sem reabrir o menu).');
                try { $semJanela = function_exists('ws_wa_pendente_existe') && ws_wa_pendente_existe($jidP);   /* PIX ficou guardado atrás do "Sim" do modelo (janela fechada): não dizer "logo acima" */
                    ws_wa_enviar_conversa($jidP, $semJanela ? "✅ O PIX da sua fatura foi enviado pelo nosso número da central de envio.\nToque em *Sim* na mensagem de lá para receber. 😉\n\nDepois, mande o comprovante por aqui que eu confirmo para você." : "✅ O PIX da sua fatura já está logo acima, é só pagar. 😉\n\nDepois, mande o comprovante por aqui que eu confirmo para você.", ['evento' => 'robo_concluiu']); } catch (Throwable $e) {}   /* (17/10/2026) resposta de CONVERSA: sai pela comum (01), onde o cliente está falando — antes ia pela API e, com a janela fechada, virava mais um MODELO cobrado (4º no caso Laudicea) */
                $resp(200, ['texto' => '', 'silencio' => 'sim']);
            }
        }
    } catch (Throwable $e) {}
    /* "DIGITE 1 PRA LIBERAR" (16/10/2026): o robô ofereceu a liberação em confiança junto do comprovante; o "1" do cliente (até 30 min depois) libera 1 dia — chama a MESMA rota de sempre
       (/api/conexao/confianca/{cpf}: 1 vez por ciclo, mais que isso vira pedido ao provedor). Sem oferta recente, o "1" continua sendo a opção 1 do menu. */
    try {
        $txO = trim((string)($u['txt'] ?? ''));
        if ($u && ($u['tipo'] ?? '') === 'texto' && in_array($txO, ['1', '1️⃣'], true) && time() - (int)($u['em'] ?? 0) <= 120) {
            $fo = WS_CACHE . '/robo_oferta_confianca.json'; $oj = json_decode((string)@file_get_contents($fo), true); $f8o = substr($jidP, -8);
            if (is_array($oj) && isset($oj[$f8o]) && time() - (int)$oj[$f8o] <= 1800) {
                $msgO = ws_api_liberar_confianca(ws_db(), $jidP);
                unset($oj[$f8o]); @file_put_contents($fo, json_encode($oj), LOCK_EX);
                if ($msgO !== null && $msgO !== '') {
                    require_once dirname(__DIR__) . '/whatsapp.php';
                    ws_robo_log($jidP, 'cliente respondeu "1" à oferta de confiança do comprovante → ' . mb_substr(preg_replace('/\s+/', ' ', $msgO), 0, 120));
                    try { ws_wa_enviar($jidP, $msgO, false, ['evento' => 'robo_concluiu']); } catch (Throwable $e) {}
                    $resp(200, ['texto' => '', 'silencio' => 'sim']);
                }
            }
        }
    } catch (Throwable $e) {}
    /* COMPROVANTE ANTES DA CONVERSA (07/10/2026): o cliente abriu mandando a FOTO ou o PDF do pagamento. Se o arquivo (≤ 90 s, ainda não
       usado) for mesmo comprovante (lido por OCR/PDF: E2E, valor ou palavras de PIX/transferência), ele é registrado em Financeiro →
       Comprovantes PIX no cliente certo (CPF/telefone) e o robô vai direto à opção 8 com o resultado — sem pedir o arquivo de novo.
       Foto que não é comprovante (ex.: do roteador) segue o fluxo normal. */
    $mdP = is_array($u['midia'] ?? null) ? $u['midia'] : null;
    if (!$mdP) { $uu = json_decode((string)@file_get_contents($uf), true); $mdP = is_array($uu['midia'] ?? null) ? $uu['midia'] : null; }
    /* RESPOSTA SÓ COM NÚMERO NÃO É COMPROVANTE (13/10/2026, caso Edvaldo Germano): o cliente digitou "2" (nota da avaliação) e o robô leu a foto de 1 min antes como se ela tivesse acabado
       de chegar — respondeu "comprovante já recebido" no lugar da avaliação. Se a última fala é só 1–2 dígitos (avaliação/menu), a foto não puxa o fluxo do comprovante. */
    $uUlt = json_decode((string)@file_get_contents($uf), true);
    $soNumero = is_array($uUlt) && ($uUlt['tipo'] ?? '') === 'texto' && preg_match('/^\s*\d{1,2}\s*$/', (string)($uUlt['txt'] ?? ''));
    if ($soNumero && $mdP && empty($mdP['usado'])) ws_robo_log($jidP, 'não tratou a foto como comprovante: o cliente respondeu só com o número "' . trim((string)$uUlt['txt']) . '" (avaliação/menu).');
    if ($mdP && empty($mdP['usado']) && !$soNumero && time() - (int)($mdP['em'] ?? 0) <= 90) {
        $uu = json_decode((string)@file_get_contents($uf), true) ?: []; $uu['midia']['usado'] = 1; @file_put_contents($uf, json_encode($uu));
        try {
            require_once dirname(__DIR__) . '/whatsapp.php'; require_once dirname(__DIR__) . '/comprovantes_lib.php';
            $arqP = ws_midia_pegar((string)$mdP['id'], 8); $ehComp = false;
            if ($arqP) {
                $tmpP = tempnam(sys_get_temp_dir(), 'wscp'); file_put_contents($tmpP, $arqP[0]);
                $mimeP = $arqP[1] ?: ($mdP['tipo'] === 'imageMessage' ? 'image/jpeg' : 'application/pdf');
                $txP = ws_comp_ler($tmpP, $mimeP); @unlink($tmpP); $lxP = ws_comp_extrair($txP);
                $ehComp = $lxP['e2e'] || preg_match('/\b(pix|comprovante|transfer[eê]ncia|pagamento efetuado|pagamento realizado|favorecido|recebedor|destinat[aá]rio|autentica[cç][aã]o)\b/iu', $txP);
            }
            if ($ehComp) {
                $dbP = ws_db(); ws_selfheal($dbP);
                $idP = ws_comp_receber($dbP, ['comprovante' => $mdP['tipo'] . '|' . $mdP['id'], 'remoteJid' => (string)($b['remoteJid'] ?? ''), 'pushName' => (string)($b['pushName'] ?? '')]);
                $rc = ws_api_comp_resposta($dbP, $idP);
                /* COMPROVANTE RECEBIDO NA INSTÂNCIA DA API (14/10/2026): o sistema registra e a resposta ao cliente sai pela instância COMUM (a API cobra cada mensagem). O robô da API fica calado; a conversa vai para a comum (unificar_run.php). */
                try {
                    $instC = trim((string)($b['instanceName'] ?? '')); $wcC = ws_wa_config();
                    if ($instC !== '' && ws_wa_modo_api($wcC) === $instC) {
                        $cliC = trim((string)$rc['cliente']); $msgC = (($cliC !== '' && stripos($cliC, 'não identificado') === false) ? "Certo!! Pagamento refere-se ao cliente:

✅ " . $cliC . "

" : '') . (string)$rc['mensagem'];
                        $rsC = ws_wa_enviar_conversa($jidP, $msgC, ['evento' => 'robo_concluiu']);
                        ws_robo_log($jidP, 'comprovante recebido — resposta enviada ao cliente.');
                        if (!empty($rsC['ok'])) $resp(200, ['texto' => '', 'silencio' => 'sim', 'conversa_na_comum' => 'sim']);
                    }
                } catch (Throwable $e) {}
                $resp(200, ['texto' => '8', 'comp' => 'sim', 'comp_cliente' => $rc['cliente'], 'comp_msg' => $rc['mensagem'],
                            'comp_valido' => $rc['repetido'] ? 'false' : 'true', 'comp_repetido' => $rc['repetido'] ? 'true' : 'false', 'comp_reenvio' => (!empty($rc['reenvio']) && empty($rc['repetido'])) ? 'true' : 'false']);
            }
        } catch (Throwable $e) { @error_log('[primeira] comprovante: ' . $e->getMessage()); }
    }
    /* RESPOSTA AO MODELO DE COBRANÇA (10/10/2026): com a janela de 24 h fechada a cobrança sai como modelo da Meta com botão "Sim"; o cliente toca em "Sim"
       (a Evolution entrega como botão, sem texto) e o robô entrava com "Olá, bom dia" + "Agradece seu contato" + menu, sem ter o que dizer. Se a conversa
       começou por um "Sim"/"ok" e este número recebeu mensagem automática nas últimas 3 h, o robô fica CALADO (silencio=sim; o fluxo encerra sem falar). */
    try {
        $txS = trim((string)($u['txt'] ?? ''));
        /* AGRADECIMENTO À MENSAGEM AUTOMÁTICA (aniversário, "conexão ONLINE", boas-vindas…): "obrigado", "valeu", "amém", 🙏 — sem pedido nenhum — não abre atendimento.
           Só com mensagem automática nossa nas últimas 24 h e SEM palavra de assunto (boleto, pix, internet, atendente…) nem pergunta. Com assunto, o robô responde. */
        $ehObrig = $txS !== '' && mb_strlen($txS) <= 90 && preg_match('/(obrigad|valeu|vlw|agrade[cç]|gratid|amem|deus|parab|feliz|igualmente|bjo|beijo|abra[cç]o|🙏|❤|😊|😍|🥰|👏|👍|😀|😁|🎉)/iu', $txS)
            && !preg_match('/(boleto|fatura|pix|pag|internet|net\b|sinal|wifi|wi-fi|roteador|cancel|atendente|plano|comprovante|suporte|ajuda|problema|caiu|lenta|chamado|tecnic|segunda via|\?)/iu', $txS);
        $ehSimOk = $txS === '' || preg_match('/^(sim|ok|okay|certo|blz|beleza|entendi|tudo bem)[\s!.]*$/iu', $txS);
        if ($u && ($u['tipo'] ?? '') === 'texto' && (time() - (int)($u['em'] ?? 0) <= 60 || !empty($u['calado'])) && ($ehSimOk || $ehObrig)) {
            $qS = ws_db()->prepare("SELECT COUNT(*) FROM ws_recibo_log WHERE tipo='mensagem' AND enviado=1 AND forma LIKE 'msg:%' AND telefone LIKE ? AND criado_em > NOW() - INTERVAL " . ($ehObrig ? 24 : 72) . " HOUR");
            $qS->execute(['%' . substr($jidP, -8)]);
            if ((int)$qS->fetchColumn() > 0) { ws_robo_log($jidP, $ehObrig ? 'ficou calado: o cliente só agradeceu a mensagem automática.' : 'ficou calado: o cliente tocou em "Sim" no modelo da cobrança (o sistema entrega a cobrança; robô não repete).'); if (empty($u['calado'])) { $u['calado'] = 1; @file_put_contents($uf, json_encode($u)); } $resp(200, ['texto' => '', 'silencio' => 'sim']); }
        }
    } catch (Throwable $e) {}
    /* "TÁ CERTO" DEPOIS DE ATENDENTE (16/10/2026, caso Kássia): agradecimento/confirmação solta ("tá certo", "ok", "obrigada", 👍) logo depois que uma PESSOA atendeu não reabre o robô (antes vinha saudação + despedida a cada "tá certo"). Só com atendente humano nas últimas 12 h; com assunto/pergunta o robô responde normal. */
    try {
        $txH = trim((string)($u['txt'] ?? ''));
        if ($u && ($u['tipo'] ?? '') === 'texto' && $txH !== '' && mb_strlen($txH) <= 40 && time() - (int)($u['em'] ?? 0) <= 60
            && preg_match('/^(t[aá] (certo|bom|ok|joia|bem)|certo|ok|okay|beleza|blz|combinado|fechado|show|perfeito|entendi|obrigad[oa]s?|valeu|vlw|muito obrigad[oa]|👍|🙏|😊)[\s!.🙏👍😊]*$/iu', $txH)
            && is_file(dirname(__DIR__) . '/aviso_provedor_lib.php') && (require_once dirname(__DIR__) . '/aviso_provedor_lib.php') !== null && ws_cw_humano_falou_recente($jidP, 12)) {
            ws_robo_log($jidP, 'ficou calado: o cliente só confirmou («' . mb_substr($txH, 0, 20) . '») depois de ser atendido por uma pessoa.');
            $resp(200, ['texto' => '', 'silencio' => 'sim']);
        }
    } catch (Throwable $e) {}
    /* CONVERSA SÓ PELA COMUM (14/10/2026): o robô da instância da API NÃO conversa (a Meta cobra cada mensagem enviada por ela): ele fica calado e o unificar_run.php leva a conversa para a comum —
       espelha a fala do cliente na conversa da 01 e inicia o robô pela 01. Comprovante, resposta ao modelo da cobrança e botão de emergência ligado seguem como antes (tratados acima/abaixo). */
    try {
        $instP2 = trim((string)($b['instanceName'] ?? ''));
        if ($instP2 !== '' && strpos($instP2, '{{') === false) {
            require_once dirname(__DIR__) . '/whatsapp.php';
            $apiP = ws_wa_modo_api(ws_wa_config());
            if ($apiP !== '' && $instP2 === $apiP) { $lgP = WS_CACHE . '/primeira_log_' . substr(sha1($jidP), 0, 12); if (!is_file($lgP) || time() - filemtime($lgP) > 60) { @touch($lgP); ws_robo_log($jidP, 'ficou calado: a conversa segue no número de atendimento.'); } $resp(200, ['texto' => '', 'silencio' => 'sim', 'conversa_na_comum' => 'sim']); }
        }
    } catch (Throwable $e) {}
    /* "Boa noite" + "Estamos sem internet" (07/10/2026): a queixa pode não ser a ÚLTIMA fala — qualquer fala dos últimos 90 s vale. */
    if (function_exists('ws_chatbot_sem_internet') && ($supP = ws_chatbot_opcao_suporte((string)($b['opcoes'] ?? ''))) !== '') {
        foreach (ws_chatbot_hist($jidP) as $hP) if (time() - (int)$hP[0] <= 90 && ws_chatbot_sem_internet((string)$hP[1])) {
            if ($u && ($u['tipo'] ?? '') === 'texto') { $u['usado'] = 1; @file_put_contents($uf, json_encode($u)); }
            $resp(200, ['texto' => $supP, 'transcricao' => (string)$hP[1]]);
        }
    }
    /* COMEÇOU DIGITANDO (07/10/2026): "quero a segunda via", "minha internet caiu" já cai na opção certa, sem passar pelo menu. Saudação ("oi", "boa noite") e número solto não contam. */
    if ($u && ($u['tipo'] ?? '') === 'texto' && empty($u['usado']) && trim((string)($u['txt'] ?? '')) !== '') {
        /* TUDO O QUE O CLIENTE FALOU (10/10/2026): o atendimento começa na 1ª mensagem ("Bom dia!") e o assunto vem nas seguintes ("Como normalmente
           faço", "Realizei o pagamento de R$ 70,00") — antes só a 1ª era olhada, o robô mostrava o menu e o cliente tinha de digitar número.
           Agora junta as falas dos últimos 90 s; se só houve saudação, espera até 4 s pelo assunto antes de decidir. */
        $saudS = fn($t) => !preg_match('/[a-zA-ZÀ-ú]{3}/u', $t) || preg_match('/^\s*(oi+|ol[aá]+|bom\s*dia|boa\s*tarde|boa\s*noite|tudo\s*(bem|bom)|e\s*a[ií]|opa|eae)[\s!.,?]*$/iu', $t);
        $falasT = function () use ($jidP, $saudS) { $o = []; foreach (ws_chatbot_hist($jidP) as $h) { $x = trim((string)($h[1] ?? '')); if (time() - (int)($h[0] ?? 0) <= 90 && $x !== '' && !$saudS($x) && !preg_match('/^\s*\d{1,2}\s*$/', $x)) $o[] = $x; } return $o; };
        $falasU = $falasT();
        for ($k = 0; !$falasU && $k < 8; $k++) { usleep(500000); $falasU = $falasT(); }
        $u2 = json_decode((string)@file_get_contents($uf), true) ?: $u; $u2['usado'] = 1; @file_put_contents($uf, json_encode($u2));
        $fT = trim(implode('. ', array_slice($falasU, -3)));
        if ($fT === '') $resp(200, ['texto' => '']);
        /* "JÁ PAGUEI" COM COMPROVANTE JÁ ENVIADO (10/10/2026): o cliente escreve "realizei o pagamento de R$ 70,00" depois de já ter mandado o
           comprovante. Antes o robô despejava o menu e pedia o comprovante de novo. Agora responde COM O QUE JÁ SABE (quando chegou, em que
           pé está, valor lido x fatura) pelo mesmo caminho do comprovante recebido — nada de pedir o arquivo outra vez. */
        try {
            if (preg_match('/\b(pagu[eéi]|paguei|pagamento|pix|transfer|comprovante|recibo)/iu', $fT)) {
                $dbC = ws_db(); require_once dirname(__DIR__) . '/comprovantes_lib.php';
                $fim8 = substr($jidP, -8);
                $cq = $dbC->prepare("SELECT c.id, c.criado_em, c.status, c.cliente_id, cl.nome, s.valor FROM ws_comprovante c
                                     LEFT JOIN ws_cliente cl ON cl.id=c.cliente_id LEFT JOIN ws_pix_selo s ON s.comprovante_id=c.id
                                     WHERE c.criado_em > NOW() - INTERVAL 36 HOUR AND RIGHT(c.telefone,8)=?
                                       AND (c.status IN ('novo','conferido','baixado') OR c.conferido_por='Automático (reenvio)')
                                     ORDER BY (c.status='recusado'), c.id DESC LIMIT 1");
                $cq->execute([$fim8]); $cc = $cq->fetch(PDO::FETCH_ASSOC);
                if ($cc) {
                    $quando = (date('Y-m-d', strtotime($cc['criado_em'])) === date('Y-m-d') ? 'hoje' : 'ontem') . ' às ' . date('H:i', strtotime($cc['criado_em']));
                    $vPago = $cc['valor'] !== null ? (float)$cc['valor'] : null;
                    $msgC = 'Já tenho o seu comprovante, enviado ' . $quando . ($vPago ? ' (R$ ' . number_format($vPago, 2, ',', '.') . ')' : '') . '. '
                          . (in_array($cc['status'], ['conferido', 'baixado'], true) ? 'A baixa já foi feita.' : 'Ele está em análise pelo provedor e, assim que for conferido, você recebe o recibo aqui.')
                          . "\n✅ Não precisa enviar de novo.";   // ✅ sempre no COMEÇO da frase (12/10/2026)
                    if ($vPago && (int)$cc['cliente_id'] > 0 && function_exists('ws_fatura_valor_cobrado')) {
                        $fq = $dbC->prepare("SELECT valor, taxa_emissao FROM ws_fatura WHERE cliente_id=? AND status IN ('aberto','vencido') ORDER BY vencimento LIMIT 1");
                        $fq->execute([(int)$cc['cliente_id']]); $fx = $fq->fetch(PDO::FETCH_ASSOC);
                        if ($fx && abs(ws_fatura_valor_cobrado($fx) - $vPago) >= 0.5 && !in_array($cc['status'], ['conferido', 'baixado'], true))
                            $msgC .= "\n\nObservação: a fatura em aberto é de R$ " . number_format(ws_fatura_valor_cobrado($fx), 2, ',', '.') . "; o financeiro confere a diferença e te avisa.";
                    }
                    ws_robo_log($jidP, 'cliente disse que pagou — já havia comprovante (' . $quando . '); informou a situação, sem pedir o arquivo de novo.', (int)$cc['cliente_id'] ?: null);
                    $resp(200, ['texto' => '8', 'comp' => 'sim', 'comp_cliente' => trim((string)$cc['nome']) ?: 'não identificado pelo CPF/telefone (o financeiro vai conferir)',
                                'comp_msg' => $msgC, 'comp_valido' => 'true', 'comp_repetido' => 'false', 'comp_reenvio' => 'false', 'transcricao' => $fT]);
                }
            }
        } catch (Throwable $e) { @error_log('[primeira] ja pagou: ' . $e->getMessage()); }
        $outT = (ws_chatbot_fora_alcance(ws_chatbot_norm($fT)) && ($opAt = ws_chatbot_opcao_atendente((string)($b['opcoes'] ?? ''))) !== '') ? $opAt : ws_chatbot_menu_resposta($fT, (string)($b['opcoes'] ?? ''), 'assunto do cliente', 'O cliente acabou de iniciar a conversa com o provedor de internet. Menu principal.');   /* horário/vaga/wifi → atendente (14/10) */
        if ($outT === 'IGNORAR') { ws_robo_log($jidP, 'ficou calado: mensagem que não é do provedor ("' . mb_substr($fT, 0, 70) . '").'); $resp(200, ['texto' => '', 'silencio' => 'sim', 'transcricao' => $fT]); }
        if (preg_match('/^\d$/', $outT)) { $rotulo = ''; foreach (explode('|', (string)($b['opcoes'] ?? '')) as $op) if (preg_match('/^\s*' . $outT . '\s*=\s*(.+)$/u', $op, $mo)) $rotulo = trim($mo[1]); ws_robo_log($jidP, 'entendeu o assunto e foi direto a «' . ($rotulo !== '' ? $rotulo : 'opção ' . $outT) . '» (cliente disse: "' . mb_substr($fT, 0, 70) . '\').'); }   // spam / conversa pessoal: robô calado
        /* CONCLUIR O PEDIDO DE PIX (10/10/2026): "o PIX pra me pagar" de um cliente já identificado, com fatura em aberto, deixava só o menu "QR Code / Chave PIX / Financeiro" e a
           conversa parava aí. Agora o robô JÁ MANDA o PIX da fatura mais atrasada (QR + copia e cola) e encerra — sem menu, sem perguntar nada. */
        if (preg_match('/^\d$/', $outT)) ws_sessao_toque($jidP, (string)($b['opcoes'] ?? ''), $outT);
        $ehPixPed = isset($rotulo) && preg_match('/pagar com pix/iu', (string)$rotulo); $ehViaPed = isset($rotulo) && preg_match('/2.{0,3}via/iu', (string)$rotulo) && !preg_match('/\d|janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro/iu', $fT);   // 2ª via sem data pedida = a fatura mais atrasada
        if (preg_match('/^\d$/', $outT) && ($ehPixPed || $ehViaPed) && $nomeCadP !== '') {
            try {
                require_once dirname(__DIR__) . '/whatsapp.php'; $dbX = ws_db();
                /* SEM REPETIR (15/10/2026): o cliente que acabou de receber o PIX/2ª via do robô e continua escrevendo ("Boa noite", "3", "Ok") reiniciava o robô a cada mensagem, e a cada reinício
                   o PIX saía de novo (Adylla: 4 vezes em 1 minuto). Entregue há menos de 15 min = não reenvia; o robô só fica calado. */
                $mjP = json_decode((string)@file_get_contents(WS_CACHE . '/robo_pix_auto.json'), true); $tPix = is_array($mjP) ? (int)($mjP[substr($jidP, -8)] ?? 0) : 0;
                if ($tPix > 0 && (time() - $tPix) < 900) { ws_robo_log($jidP, 'cliente já recebeu o PIX/2ª via há poucos minutos — não reenviei (evita repetição); só ficou calado.'); $resp(200, ['texto' => '', 'silencio' => 'sim', 'transcricao' => $fT]); }
                $qf = $dbX->prepare("SELECT f.* FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.celular,''),' ',''),'-',''),'(',''),')',''),8)=? AND c.status NOT IN ('cancelado','inativo','desativado') AND f.status IN ('aberto','vencido') ORDER BY (f.vencimento > CURDATE()), f.vencimento LIMIT 1");
                $qf->execute([substr($jidP, -8)]); $ff = $qf->fetch(PDO::FETCH_ASSOC);
                $pxX = $ff ? ws_fatura_pix_png($dbX, (int)$ff['id']) : null;
                if ($ff && $pxX) {
                    $vX = function_exists('ws_fatura_valor_cobrado') ? ws_fatura_valor_cobrado($ff) : (float)$ff['valor'];
                    ws_wa_enviar($jidP, 'Aqui está o PIX da sua fatura de *R$ ' . number_format($vX, 2, ',', '.') . '* (vencimento ' . date('d/m', strtotime((string)$ff['vencimento'])) . "). 😉\nDepois de pagar, é só mandar o comprovante por aqui.", false, ['evento' => 'pix_pedido']);
                    if (is_file(dirname(__DIR__) . '/boleto_pdf.php')) { require_once dirname(__DIR__) . '/boleto_pdf.php'; try { $pdfX = ws_pdf_faturas($dbX, [(int)$ff['id']], 'boleto'); if ($pdfX) ws_wa_midia($jidP, 'document', $pdfX['nome'], base64_encode($pdfX['pdf']), '', ['evento' => 'pix_pedido']); } catch (Throwable $e) {} }   // 2ª via: o PDF do boleto também
                    ws_wa_midia($jidP, 'image', 'pix.png', base64_encode($pxX['png']), "PIX copia e cola:\n" . $pxX['emv'], ['evento' => 'pix_pedido']);
                    try { $mf = WS_CACHE . '/robo_pix_auto.json'; $mj = json_decode((string)@file_get_contents($mf), true); if (!is_array($mj)) $mj = []; foreach ($mj as $k => $t0) if (time() - (int)$t0 > 7200) unset($mj[$k]); $mj[substr($jidP, -8)] = time(); @file_put_contents($mf, json_encode($mj), LOCK_EX); } catch (Throwable $e) {}
                    ws_robo_log($jidP, 'cliente pediu ' . ($ehViaPed ? 'a 2ª via — enviei o boleto em PDF + PIX' : 'o PIX — enviei o QR + copia e cola') . ' da fatura #' . (int)$ff['id'] . ' (R$ ' . number_format($vX, 2, ',', '.') . ', venc. ' . date('d/m', strtotime((string)$ff['vencimento'])) . ') e concluí o pedido.');
                    $resp(200, ['texto' => '', 'silencio' => 'sim', 'transcricao' => $fT]);
                }
            } catch (Throwable $e) { @error_log('[primeira] pix direto: ' . $e->getMessage()); }
        }
        $resp(200, ['texto' => preg_match('/^\d$/', $outT) ? $outT : '', 'transcricao' => $fT]);
    }
    if (!$u || ($u['tipo'] ?? '') !== 'audioMessage' || !empty($u['usado']) || ws_chatbot_openai_key() === '') $resp(200, ['texto' => '']);
    $u['usado'] = 1; @file_put_contents($uf, json_encode($u));
    $aud = ws_midia_pegar((string)$u['id'], 6);
    if (!$aud) $resp(200, ['texto' => '']);
    $errP = ''; $falaP = ws_chatbot_transcrever($aud[0], $aud[1] ?: 'audio/ogg', $errP);
    if ($falaP === '') $resp(200, ['texto' => '', 'erro' => $errP]);
    ws_audio_guardar((string)($b['remoteJid'] ?? ''), $falaP, 'primeira');
    $outP = ws_chatbot_resposta($falaP, (string)($b['opcoes'] ?? ''), 'menu');
    try { ws_chatbot_resumo('audio'); } catch (Throwable $e) {}   // síntese do dia, sem linha por áudio
    $resp(200, ['texto' => preg_match('/^\d$/', $outP) ? $outP : '', 'transcricao' => $falaP]);
}

// POST /api/audio → resposta do menu dada por ÁUDIO (01/10/2026). Mesma credencial do robô.
// Corpo: {texto, opcoes, tipo (menu|numero), remoteJid, instanceName, serverUrl, apiKey}. Devolve {texto} — o Typebot grava
// de volta na mesma variável. Texto digitado volta igual (nada muda). Regras em ws_chatbot_resposta() (api_chatbot.php).
if ($rota === 'audio') {
    $okAuth = hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')) || ws_chatbot_token_valido($auth, $cfg);
    if (!$okAuth) $resp(401, ['erro' => 'credencial inválida']);
    $b = json_decode((string)file_get_contents('php://input'), true); if (!is_array($b)) $b = $_POST;
    $texto = trim((string)($b['texto'] ?? ''));
    try { if (!empty($b['instanceName']) && !empty($b['remoteJid'])) ws_conversa_inst_toque((string)$b['remoteJid'], (string)$b['instanceName']); } catch (Throwable $e) {}   // renova o prazo da conversa desta instância (14/10)
    // CONCLUSÃO POR INATIVIDADE (10/10/2026): registra o toque e o assunto da escolha de menu; a resposta da avaliação encerra a conversa
    try { $jS = (string)($b['remoteJid'] ?? ''); if ($jS !== '' && strpos($jS, '{{') === false) { if (preg_match('/avalia/iu', (string)($b['campo'] ?? ''))) ws_sessao_concluir($jS); else ws_sessao_toque($jS, (string)($b['opcoes'] ?? ''), (string)(($b['tipo'] ?? 'menu') === 'menu' ? $texto : '')); } } catch (Throwable $e) {}
    /* CADASTRO: vários dados numa fala só (03/10/2026). Com multi=1 o fluxo manda o que já tem (atuais) e as listas;
       toda resposta desta rota passa a levar "extra" com TODOS os campos — o robô grava e pula o que já foi dito. */
    $fala = '';
    /* DESVIO GLOBAL (07/10/2026): toda resposta desta rota leva "desvio_opcao" — se o cliente, no meio de qualquer pergunta,
       pediu OUTRO assunto do menu principal ("1".."9", "0" = menu) o fluxo pula para lá; vazio = segue normal. Regras em ws_chatbot_desvio(). */
    $respDv = $resp;
    $resp = function (int $code, $corpo, string $tipo = 'application/json') use ($respDv, $b, &$fala, &$texto) {
        if ($code === 200 && is_array($corpo) && array_key_exists('texto', $corpo)) {
            $fonteDv = $fala !== '' ? $fala : (preg_match('/^\w+Message\|/', $texto) ? '' : $texto);
            $dv = ''; try { $dv = ws_chatbot_desvio($fonteDv, (string)$corpo['texto'], $b); } catch (Throwable $e) {}
            /* 3ª resposta seguida que a pergunta não entendeu → encaminha ao atendente (7) em vez de insistir (ws_chatbot_erros). */
            try { $jidE = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]);
                if ($jidE !== '' && $fonteDv !== '') { $invE = $dv === '' && ws_chatbot_resposta_invalida($fonteDv, (string)$corpo['texto'], $b); $corpo['invalido'] = $invE ? 'sim' : ''; $corpo['motivo'] = $invE ? ws_chatbot_motivo_invalido($b) : ''; $nE = ws_chatbot_erros($jidE, $invE); if ($dv === '' && $nE >= 3) { $dv = '7'; ws_chatbot_erros($jidE, false); try { ws_chatbot_atendimento_abrir(ws_db(), ['jid' => $jidE, 'motivo' => 'escalada', 'assunto' => (string)($b['campo'] ?? '') !== '' ? (string)$b['campo'] : mb_substr((string)($b['pergunta'] ?? ''), 0, 60), 'audio' => $fala !== '']); } catch (Throwable $e) {} } }
            } catch (Throwable $e) {}
            $corpo['desvio_opcao'] = $dv;
            if ($dv !== '') { $corpo['invalido'] = ''; $corpo['motivo'] = ''; } elseif (!isset($corpo['invalido'])) { $corpo['invalido'] = ''; $corpo['motivo'] = ''; }   // o fluxo repete a pergunta quando invalido = sim
            if ($dv !== '') { try { ws_chatbot_resumo('desvio'); } catch (Throwable $e) {} }   // só conta
            // LOG CURTO (10/10/2026): mudança de assunto e resposta não entendida ficam registradas na linha do tempo do cliente
            try {
                $jidL = (string)($b['remoteJid'] ?? '');
                if ($dv !== '' && $jidL !== '') { $rotL = ''; foreach (explode('|', ws_chatbot_menu_principal_padrao()) as $opL) if (preg_match('/^\s*' . preg_quote($dv, '/') . '\s*=\s*(.+)$/u', $opL, $moL)) $rotL = trim($moL[1]); ws_robo_log($jidL, 'cliente mudou de assunto → ' . ($dv === '0' ? 'voltou ao menu' : ($rotL !== '' ? '«' . $rotL . '»' : 'opção ' . $dv)) . ' (disse: "' . mb_substr($fonteDv, 0, 60) . '").'); }
                elseif (($corpo['invalido'] ?? '') === 'sim' && $jidL !== '') ws_robo_log($jidL, 'resposta não entendida em «' . mb_substr((string)($b['campo'] ?? ($b['pergunta'] ?? '')), 0, 40) . '» (' . mb_substr($fonteDv, 0, 40) . '); explicou e pediu de novo.');
            } catch (Throwable $e) {}
        }
        $respDv($code, $corpo, $tipo);
    };
    if (!empty($b['multi'])) {
        $respBase = $resp;
        $resp = function (int $code, $corpo, string $tipo = 'application/json') use ($respBase, $b, &$fala, &$texto) {
            if ($code === 200 && is_array($corpo) && array_key_exists('texto', $corpo)) {
                $listas = []; foreach ((array)($b['listas'] ?? []) as $k => $v) $listas[$k] = array_values(array_filter(array_map('trim', explode('|', (string)$v)), fn($x) => $x !== '' && strpos($x, '{{') === false));
                $fonte = $fala !== '' ? $fala : (preg_match('/^\w+Message\|/', $texto) ? '' : $texto);
                /* "JÁ INFORMEI" (08/10/2026): quem fala TUDO num áudio longo e depois ouve mais uma pergunta responde "eu já informei os dados acima" — o robô
                   guardava só o campo perguntado e repetia tudo. Agora guarda a última fala longa do número (30 min) e, nesse caso, extrai DE NOVO dela. */
                $valorM = (string)$corpo['texto'];
                try {
                    $jidM = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]); $arqM = WS_CACHE . '/multi_ultimo.json';
                    $memM = json_decode((string)@file_get_contents($arqM), true); if (!is_array($memM)) $memM = [];
                    foreach ($memM as $kk => $vv) if (time() - (int)($vv['em'] ?? 0) > 1800) unset($memM[$kk]);
                    if ($jidM !== '' && $fonte !== '') {
                        if (count(preg_split('/\s+/', trim($fonte))) >= 12) { $memM[$jidM] = ['t' => $fonte, 'em' => time()]; @file_put_contents($arqM, json_encode($memM, JSON_UNESCAPED_UNICODE)); @chmod($arqM, 0640); }
                        elseif (isset($memM[$jidM]) && preg_match('/\bj[aá]\b.*(inform|falei|disse|passei|mandei|enviei)|acabei de (falar|dizer|informar)|dados acima|j[aá] (te )?(falei|disse)/iu', $fonte)) { $fonte = $memM[$jidM]['t']; $valorM = ''; }
                    }
                } catch (Throwable $e) {}
                $corpo['extra'] = ws_chatbot_multi($fonte, (array)($b['atuais'] ?? []), $listas, (string)($b['chave'] ?? ''), $valorM);
                try { $jX = (string)($b['remoteJid'] ?? ''); if ($jX !== '' && strpos($jX, '{{') === false) ws_sessao_toque($jX, '', '', 'cadastro', array_filter(array_merge((array)($b['atuais'] ?? []), (array)$corpo['extra']), fn($v) => $v !== null && $v !== '' && !is_array($v))); } catch (Throwable $e) {}   // guarda o que o cadastro já tem, para concluir se o cliente parar
            }
            $respBase($code, $corpo, $tipo);
        };
    }
    /* (02/10/2026) campo/pergunta/itens: o fluxo informa O QUE perguntou, para a resposta ser entendida pelo sentido.
       tipo: menu (opções numeradas) | numero (CPF etc.) | escolha (lista de itens exatos: cidade, plano, dia) | texto (nome, data…) */
    $tipoA = in_array(($b['tipo'] ?? ''), ['numero', 'escolha', 'texto'], true) ? $b['tipo'] : 'menu';
    $campoA = mb_substr(trim((string)($b['campo'] ?? '')), 0, 60); $pergA = mb_substr(trim((string)($b['pergunta'] ?? '')), 0, 600);
    $itensA = array_values(array_filter(array_map('trim', explode('|', (string)($b['itens'] ?? ''))), fn($x) => $x !== ''));
    if (!preg_match('/^audioMessage\|(\S+)/', $texto, $ma)) {
        /* DIGITADO também é entendido (02/10/2026): "quero meu boleto" no menu vira 2; "nazaré" na lista vira o item;
           data/e-mail/nome digitados ganham o acabamento. Número já certo passa direto (sem custo). A IA só entra
           quando a regra simples não resolve uma resposta de menu/lista. */
        if ($texto === '' || preg_match('/^(imageMessage|documentMessage|videoMessage|stickerMessage)\|/', $texto)) $resp(200, ['texto' => $texto, 'audio' => false]);
        if ($tipoA === 'escolha' && $itensA) {
            $it = ws_chatbot_escolher_item($texto, $itensA, $campoA, $pergA, true);
            $resp(200, ['texto' => $it !== '' ? $it : $texto, 'audio' => false]);
        }
        if ($tipoA === 'menu' && trim((string)($b['opcoes'] ?? '')) !== '' && !preg_match('/^\s*\d{1,2}\s*$/', $texto)) {
            /* "Estamos sem internet" + "No sítio" (07/10/2026): a fala vaga que vem logo depois da queixa vai para o SUPORTE, não para a IA adivinhar. */
            $supH = ws_chatbot_opcao_suporte((string)$b['opcoes']);
            if ($supH !== '' && !ws_chatbot_sem_internet($texto) && count(array_filter(explode(' ', ws_chatbot_norm($texto)))) <= 4 && !preg_match('/^\d{1,2}$/', ws_chatbot_resposta($texto, (string)$b['opcoes'], 'menu'))) {
                foreach (ws_chatbot_hist((string)($b['remoteJid'] ?? '')) as $hh) if (time() - (int)$hh[0] <= 180 && ws_chatbot_sem_internet((string)$hh[1])) $resp(200, ['texto' => $supH, 'audio' => false]);
            }
            $o = ws_chatbot_menu_resposta($texto, (string)$b['opcoes'], $campoA, $pergA);   // IA pelo sentido; regra de palavras de reserva
            $resp(200, ['texto' => preg_match('/^\d{1,2}$/', $o) ? $o : $texto, 'audio' => false]);
        }
        /* WhatsApp do cadastro: "este mesmo" / "esse número" = o número de onde o cliente está falando */
        /* RESPOSTA À PERGUNTA "PARA QUEM É ESSE PAGAMENTO?" DADA NO LUGAR ERRADO (10/10/2026): o cliente manda o comprovante, o robô não o identifica e já está na pergunta de avaliação;
           ele escreve "CPF … / Cliente …". Antes: "Não entendi, escolha uma das opções". Agora o texto vai para o comprovante (liga ao cadastro pelo CPF/nome) e a avaliação é dada como
           "Não avaliar", para o atendimento seguir e fechar normalmente. */
        if ($tipoA === 'texto' && preg_match('/avalia/iu', $campoA) && $texto !== '' && !preg_match('/^\s*[1-5]\s*$/', $texto)) {
            try {
                require_once dirname(__DIR__) . '/comprovantes_lib.php'; $jA = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]); $f8 = substr($jA, -8);
                $pend = false; foreach (ws_comp_perguntas_ler() as $tk => $vk) if (substr((string)$tk, -8) === $f8 && time() - (int)($vk['em'] ?? 0) < 86400) { $pend = true; break; }
                $recente = $f8 !== '' && is_file(WS_CACHE . '/comp_resp_' . $f8 . '.txt') && time() - (int)@filemtime(WS_CACHE . '/comp_resp_' . $f8 . '.txt') < 60;
                if ($pend) ws_comp_pergunta_resposta(ws_db(), $jA, $texto);
                elseif (!$recente && ws_comp_juntar_texto(ws_db(), $jA, $texto) !== null) $recente = true;   // texto solto com CPF/nome: junta as peças
                if ($pend || $recente) { ws_robo_log($jA, 'resposta de "para quem é o pagamento" veio na pergunta de avaliação — liguei ao comprovante e segui sem "não entendi".'); $resp(200, ['texto' => '5', 'audio' => false]); }
            } catch (Throwable $e) { @error_log('[audio] pergunta comp: ' . $e->getMessage()); }
        }
        if ($tipoA === 'texto' && preg_match('/whats|celular|telefone/i', $campoA) && !preg_match('/\d/', $texto) && preg_match('/\b(es[st]e|mesmo|daqui|deste|desse|atual|meu n[uú]mero)\b/iu', $texto)) {
            $jw = preg_replace('/\D/', '', explode('@', (string)($b['remoteJid'] ?? ''))[0]); if (strlen($jw) >= 12 && substr($jw, 0, 2) === '55') $jw = substr($jw, 2);
            if (strlen($jw) === 10 && preg_match('/^\d\d[6-9]/', $jw)) $jw = substr($jw, 0, 2) . '9' . substr($jw, 2);   // celular sem o 9º dígito (JID antigo do WhatsApp)
            if (strlen($jw) >= 10) $resp(200, ['texto' => $jw, 'audio' => false]);
        }
        if ($tipoA === 'texto') $resp(200, ['texto' => ws_chatbot_texto_entender($texto, $campoA, $pergA) ?: $texto, 'audio' => false]);   // digitado também passa pela IA quando não está no formato do campo
        $resp(200, ['texto' => $texto, 'audio' => false]);
    }    $quem = preg_replace('/@.*/', '', (string)($b['remoteJid'] ?? ''));
    $logA = function (string $txt) { try { if (preg_match('/^(falha|não consegui|áudio longo|teto|recebido, mas)/u', $txt)) ws_chatbot_resumo('falha', $txt); else ws_chatbot_resumo('audio'); } catch (Throwable $e) {} };   // síntese, não uma linha por áudio (07/10/2026)
    if (ws_chatbot_openai_key() === '') { $logA('recebido, mas a transcrição está desligada (falta a chave da OpenAI em Mensagens → API do chatbot).'); $resp(200, ['texto' => $texto, 'audio' => true, 'erro' => 'transcricao_desligada']); }
    // Evolution: a que o Typebot informou (instância que recebeu a mensagem); senão a do WhatsApp do sistema.
    $srvA = (string)($b['serverUrl'] ?? ''); $keyA = (string)($b['apiKey'] ?? ''); $instA = (string)($b['instanceName'] ?? '');
    if ($srvA === '' || $keyA === '' || strpos($srvA . $keyA . $instA, '{{') !== false) {
        if (is_file(dirname(__DIR__) . '/whatsapp.php')) { require_once dirname(__DIR__) . '/whatsapp.php'; $wc = ws_wa_config(); $srvA = (string)$wc['url']; $keyA = (string)$wc['apikey']; if ($instA === '' || strpos($instA, '{{') !== false) $instA = (string)$wc['instance']; }
    }
    $aud = ws_chatbot_audio_baixar($ma[1], $instA, $srvA, $keyA);
    if (!$aud) { $logA('não consegui baixar o áudio na Evolution (instância ' . $instA . '; ref ' . mb_substr($ma[1], 0, 90) . ' · ' . strlen($texto) . ' bytes).'); $resp(200, ['texto' => $texto, 'audio' => true, 'erro' => 'download']); }
    /* MODO ECONÔMICO (01/10/2026): resposta de menu é curta. Áudio com mais de ~1 minuto não é transcrito (o menu segue como
       texto não entendido) e há um TETO MENSAL de minutos (Mensagens → API do chatbot; padrão 1.000 min ≈ US$ 3,00). A duração é
       estimada pelo tamanho do arquivo (áudio de WhatsApp ≈ 2 KB por segundo). Uso do mês em cache/audio_uso.json. */
    $segA = (int)ceil(strlen($aud[0]) / 2000);
    $tetoMin = max(0, (int)(ws_chatbot_cfg()['audio_teto_min'] ?? 1000));   // padrão 1.000 min/mês (02/10/2026)
    $usoF = WS_CACHE . '/audio_uso.json'; $uso = json_decode((string)@file_get_contents($usoF), true) ?: [];
    if (($uso['mes'] ?? '') !== date('Y-m')) $uso = ['mes' => date('Y-m'), 'seg' => 0, 'qtd' => 0];
    if ($segA > 75) { $logA('áudio longo (~' . $segA . ' s) não transcrito — modo econômico.'); $resp(200, ['texto' => $texto, 'audio' => true, 'erro' => 'longo']); }
    if ($tetoMin > 0 && ($uso['seg'] + $segA) > $tetoMin * 60) { $logA('teto mensal de ' . $tetoMin . ' min de áudio atingido — não transcrito.'); $resp(200, ['texto' => $texto, 'audio' => true, 'erro' => 'teto']); }
    $errT = ''; $fala = ws_chatbot_transcrever($aud[0], $aud[1], $errT, ws_chatbot_dica_transcricao($pergA !== '' ? 'Pergunta: ' . mb_substr($pergA, 0, 200) . '.' : ''));
    if ($fala !== '') { $uso['seg'] += $segA; $uso['qtd']++; @file_put_contents($usoF, json_encode($uso)); @chmod($usoF, 0640); }
    if ($fala === '') { $logA('falha na transcrição: ' . $errT); $resp(200, ['texto' => $texto, 'audio' => true, 'erro' => 'transcricao']); }
    ws_audio_guardar((string)($b['remoteJid'] ?? ''), $fala, 'fluxo');
    $opA = (string)($b['opcoes'] ?? '');
    if ($tipoA === 'escolha' && $itensA) {
        $out = ws_chatbot_escolher_item($fala, $itensA, $campoA, $pergA);
        if ($out === '') $out = $fala;
    } elseif ($tipoA === 'texto') {
        $out = ws_chatbot_ia($fala, $campoA, $pergA, '', 'texto') ?: $fala;
    } else {
        $out = $tipoA === 'numero' ? ws_chatbot_resposta($fala, $opA, 'numero') : ($opA !== '' ? ws_chatbot_menu_resposta($fala, $opA, $campoA, $pergA) : ws_chatbot_resposta($fala, $opA, 'menu'));
        // regra simples não resolveu → IA pelo sentido (menu: número da opção; número: CPF/telefone ditado por extenso)
        $ok = $tipoA === 'numero' ? in_array(strlen(preg_replace('/\D/', '', $out)), [10, 11, 14], true) : preg_match('/^\d{1,2}$/', $out);
        if (!$ok) { $ia = ws_chatbot_ia($fala, $campoA ?: ($tipoA === 'numero' ? 'CPF ou CNPJ' : 'opção do menu'), $pergA, $opA, $tipoA === 'numero' ? 'número (só dígitos)' : 'opções numeradas'); if ($ia !== '') $out = $tipoA === 'numero' ? preg_replace('/\D/', '', $ia) : $ia; }
    }    $logA('"' . mb_substr($fala, 0, 120) . '"' . ($out !== $fala ? " → entendido como \"$out\"" : ''));
    $resp(200, ['texto' => $out, 'transcricao' => $fala, 'audio' => true]);
}

/** Libera em confiança pelo WhatsApp (16/10/2026): acha o cliente bloqueado deste número e chama a rota /api/conexao/confianca/{cpf} do próprio sistema (token assinado na hora, só do servidor).
 *  Devolve o texto para o cliente ou null se não achou cliente bloqueado com CPF neste número. */
function ws_api_liberar_confianca(PDO $db, string $jid): ?string {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); if (strlen($f8) < 8) return null;
    $q = $db->prepare("SELECT c.cpf_cnpj FROM ws_cliente c JOIN ws_contrato ct ON ct.cliente_id=c.id WHERE ct.status='bloqueado' AND COALESCE(c.cpf_cnpj,'')<>'' AND (RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.celular,''),' ',''),'-',''),'(',''),')',''),8)=? OR RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.telefone,''),' ',''),'-',''),'(',''),')',''),8)=?) ORDER BY ct.id LIMIT 1");
    $q->execute([$f8, $f8]); $doc = preg_replace('/\D/', '', (string)$q->fetchColumn()); if (strlen($doc) !== 11 && strlen($doc) !== 14) return null;
    $cfg = ws_chatbot_cfg(); $p = ws_chatbot_b64url(json_encode(['exp' => time() + 120])); $tok = $p . '.' . ws_chatbot_b64url(hash_hmac('sha256', $p, $cfg['chave'], true));
    $ch = curl_init('https://127.0.0.1/api/conexao/confianca/' . $doc);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_TIMEOUT => 40, CURLOPT_POST => 1, CURLOPT_POSTFIELDS => json_encode(['remoteJid' => $jid, 'relato' => '']),
        CURLOPT_HTTPHEADER => ['Host: ' . ($_SERVER['HTTP_HOST'] ?? 'localhost'), 'Content-Type: application/json', 'Authorization: Bearer ' . $tok]]);
    $r = json_decode((string)curl_exec($ch), true); curl_close($ch);
    return is_array($r) ? (string)($r['mensagem'] ?? '') : null;
}

/** OFERTA DE CONFIANÇA NO COMPROVANTE (13/10/2026): o cliente manda o comprovante e a internet continua bloqueada até a baixa (boleto leva até 2 dias úteis).
 *  Se ele está BLOQUEADO e ainda NÃO usou o desbloqueio em confiança no ciclo (mesma regra do /api/conexao/confianca: confiança vigente no contrato OU qualquer
 *  liberação registrada no ciclo), devolve o texto que OFERECE a liberação de 1 dia. Já usou, não está bloqueado ou algo falhou → '' (não diz nada). Não libera nada aqui. */
function ws_api_comp_oferta_confianca(PDO $db, int $clienteId): string {
    try {
        if (is_file(dirname(__DIR__) . '/radius_lib.php')) require_once dirname(__DIR__) . '/radius_lib.php';
        if (is_file(dirname(__DIR__) . '/central_recursos.php')) require_once dirname(__DIR__) . '/central_recursos.php';
        if (!function_exists('ws_rad_confiar')) return '';
        $q = $db->prepare("SELECT * FROM ws_contrato WHERE cliente_id=? AND status='bloqueado'");
        $q->execute([$clienteId]); $cts = $q->fetchAll(PDO::FETCH_ASSOC);
        if (!$cts) return '';
        $ciclo = function_exists('ws_central_param') ? max(1, (int)ws_central_param('confianca_ciclo_meses')) : 1;
        $u = $db->prepare("SELECT MAX(criado_em) FROM ws_evento WHERE cliente_id=? AND (tipo='confianca' OR texto LIKE 'Desbloqueio em confiança%' OR texto LIKE 'Desbloqueio de confiança%' OR texto LIKE '%liberado em confiança%')");
        $u->execute([$clienteId]); $ult = (string)$u->fetchColumn();
        $usouEvento = $ult !== '' && strtotime($ult . " +$ciclo month") > time();
        foreach ($cts as $ct) {
            $usou = $usouEvento || (function_exists('ws_central_confianca_no_ciclo') && ws_central_confianca_no_ciclo($ct, 1));
            if (!$usou) {   // basta um contrato bloqueado que ainda possa usar
                /* (16/10/2026) formato do provedor: aviso do bloqueio, linha em branco, pergunta e "Digite 1 pra Liberar." (o "1" é tratado em /api/primeira, até 30 min depois) */
                return "🔒 Sua internet está bloqueada por pendência até a baixa do pagamento.\n\n"
                     . "🔓 Gostaria de desbloquear em confiança por 1 dia enquanto o pagamento é confirmado?\n"
                     . "Digite 1 pra Liberar.";
            }
        }
    } catch (Throwable $e) {}
    return '';
}

/** Resposta do robô para um comprovante já registrado (usada por /api/comprovante e pelo comprovante enviado antes da conversa). */
function ws_api_comp_resposta(PDO $db, int $id): array {
    $r = ws_api_comp_resposta_base($db, $id);
    /* ANTI-REPETIÇÃO (13/10/2026): cliente que manda o MESMO comprovante 3 vezes seguidas (ou nos 2 WhatsApps) recebia o aviso longo "já recebido" 3 vezes. Se o mesmo número já levou esse aviso nos
       últimos 10 min, a resposta vira uma linha curta (menos mensagens = menos custo na Meta e menos cara de robô). */
    try {
        if (!empty($r['reenvio']) && empty($r['repetido'])) {
            $tq = $db->prepare("SELECT telefone FROM ws_comprovante WHERE id=?"); $tq->execute([$id]); $tel8 = substr(preg_replace('/\D/', '', (string)$tq->fetchColumn()), -8);
            if (strlen($tel8) === 8) {
                $rq = $db->prepare("SELECT COUNT(*) FROM ws_comprovante WHERE id<>? AND status='recusado' AND conferido_por='Automático (reenvio)' AND criado_em >= NOW() - INTERVAL 10 MINUTE AND RIGHT(REPLACE(COALESCE(telefone,''),'+',''),8)=?");
                $rq->execute([$id, $tel8]);
                if ((int)$rq->fetchColumn() > 0) $r['mensagem'] = "✅ Já está com a gente — não precisa enviar de novo.\nAssim que for conferido você recebe a confirmação. 🙏";
            }
        }
    } catch (Throwable $e) {}
    /* CHAMADO ABERTO NA RESPOSTA (13/10/2026): o comprovante lembra o chamado aberto do cliente — uma mensagem só, com o que importa (bloqueio/confiança: ws_api_comp_oferta_confianca, abaixo) */
    try {
        if (empty($r['repetido']) && empty($r['reenvio'])) {
            $cs = $db->prepare("SELECT c.cliente_id, cl.status FROM ws_comprovante c LEFT JOIN ws_cliente cl ON cl.id=c.cliente_id WHERE c.id=?"); $cs->execute([$id]); $csr = $cs->fetch(PDO::FETCH_ASSOC) ?: [];
            if (!empty($csr['cliente_id'])) {
                $extra = '';
                $pd0 = function_exists('ws_pendencia_aberta') ? ws_pendencia_aberta($db, (int)$csr['cliente_id']) : null;
                if ($pd0 && $pd0['tipo'] === 'chamado') $extra .= "\n🛠️ Seu chamado *#" . (int)$pd0['id'] . "* continua aberto — a equipe já está de olho.";
                if ($extra !== '') { $r['mensagem'] = (string)($r['mensagem'] ?? '') . $extra; $r['situacao'] = trim($extra); }
            }
        }
    } catch (Throwable $e) {}
    try {
        $q = $db->prepare("SELECT telefone, cliente_id FROM ws_comprovante WHERE id=?"); $q->execute([$id]); $cr = $q->fetch(PDO::FETCH_ASSOC) ?: [];
        $msg = (string)($r['mensagem'] ?? '');
        $o = !empty($r['reenvio']) ? (!empty($r['repetido']) ? 'comprovante já enviado por OUTRO número — barrado, informou que já foi recebido' : 'comprovante repetido — informou que já foi recebido, sem registrar de novo')
            : (strpos($msg, 'já foi identificado') !== false ? 'comprovante de pagamento que a API já baixou — informou a baixa feita'
            : (!empty($r['repetido']) ? 'comprovante recusado (selo/duplicado) — avisou o cliente' : (strpos($msg, 'confirmado no banco') !== false ? 'comprovante confirmado no banco (baixa automática)' : 'comprovante recebido — aguardando conferência do financeiro')));
        // Bloqueado e ainda sem usar a confiança do mês → o robô OFERECE a liberação (só depois que o comprovante foi aceito: não vale para repetido/recusado/não achado no banco/já baixado).
        if (!empty($cr['cliente_id']) && empty($r['repetido']) && empty($r['reenvio']) && strpos($msg, 'já foi identificado') === false && strpos($msg, 'Não encontramos') === false) {
            $of = ws_api_comp_oferta_confianca($db, (int)$cr['cliente_id']);
            if ($of !== '') { $r['mensagem'] = rtrim($msg) . "\n\n" . $of; $r['oferta_confianca'] = true;
                try { $fo = WS_CACHE . '/robo_oferta_confianca.json'; $oj = json_decode((string)@file_get_contents($fo), true); if (!is_array($oj)) $oj = []; foreach ($oj as $kk => $tt) if (time() - (int)$tt > 3600) unset($oj[$kk]); $oj[substr(preg_replace('/\D/', '', (string)($cr['telefone'] ?? '')), -8)] = time(); @file_put_contents($fo, json_encode($oj), LOCK_EX); @chmod($fo, 0640); } catch (Throwable $e) {} $o .= ' · cliente bloqueado: ofereceu liberação em confiança'; }
        }
        ws_robo_log((string)($cr['telefone'] ?? ''), $o . ' (#' . $id . ').', !empty($cr['cliente_id']) ? (int)$cr['cliente_id'] : null);
        /* 17/10/2026: NÃO pergunta mais CPF/nome aqui. A resposta do robô já diz "Certo!! Pagamento refere-se ao cliente: ✅ NOME (nome do comprovante — o financeiro confere o cadastro)"; a pergunta junto era a 2ª mensagem contraditória para o mesmo comprovante. */
    } catch (Throwable $e) {}
    return $r;
}
function ws_api_comp_resposta_base(PDO $db, int $id): array {
        // "arquivo" e "motivo" aparecem nos logs do Typebot: dá para saber, sem abrir o sistema, se a imagem veio
        $sx = $db->prepare("SELECT c.baixado, c.erro, cl.nome FROM ws_comprovante c LEFT JOIN ws_cliente cl ON cl.id=c.cliente_id WHERE c.id=?");
        $sx->execute([$id]); $x = $sx->fetch(PDO::FETCH_ASSOC) ?: [];
        /* "cliente" = nome do CADASTRO (achado pelo CPF digitado ou pelo telefone). O robô mostra em
           "Pagamento refere-se ao cliente: ✅ ..." no lugar de perguntar o nome (pedido de 24/09/2026). */
        $cliNome = trim((string)($x['nome'] ?? ''));
        /* NÃO IDENTIFICADO PELO CPF/TELEFONE (15/10/2026): mostra o nome que está no PRÓPRIO COMPROVANTE (pagador lido); se não der para ler, o nome do WhatsApp — nunca só "não identificado".
           Só para exibição ao cliente: o vínculo com o cadastro continua sendo do CPF/telefone/pergunta, e o financeiro confere. */
        $cliTxt = $cliNome;
        if ($cliNome === '') {
            try {
                $dd = function_exists('ws_comp_detalhes') ? ws_comp_detalhes($db, $id, true) : null; $pn = trim((string)($dd['pagador_nome'] ?? ''));
                if ($pn !== '' && mb_strlen($pn) >= 5) $cliTxt = mb_strtoupper($pn) . ' (nome do comprovante — o financeiro confere o cadastro)';   // texto EXATO pedido pelo dono (17/10/2026)
                else { $nw = trim((string)$db->query("SELECT nome_whats FROM ws_comprovante WHERE id=" . (int)$id)->fetchColumn()); if ($nw !== '') $cliTxt = $nw . ' (nome do WhatsApp — o financeiro confere o cadastro)'; }
            } catch (Throwable $e) {}
        }
        // SELO ANTIFRAUDE: lido na chegada (ws_comp_baixar → ws_comp_selar). Repetido = o robô avisa o cliente.
        $selo = null; $fraude = '';
        // REENVIO (09/10/2026): o mesmo comprovante do mesmo cliente já está registrado (ex.: mandou nos 2 WhatsApps) — não é fraude
        $reenv = function_exists('ws_comp_reenvio_msg') ? ws_comp_reenvio_msg($db, $id) : '';
        if ($reenv !== '') return ['ok' => true, 'valido' => true, 'id' => $id, 'arquivo' => $x['baixado'] ?? '', 'motivo' => 'reenvio',
            'cliente' => $cliTxt !== '' ? $cliTxt : 'não identificado pelo CPF/telefone (o financeiro vai conferir)',
            'selo' => null, 'repetido' => strpos($reenv, '⚠️') === 0, 'reenvio' => true, 'mensagem' => $reenv];   // de OUTRO número = repetido (o robô barra e pede o comprovante certo)
        try { $sq = $db->prepare("SELECT * FROM ws_pix_selo WHERE comprovante_id=?"); $sq->execute([$id]); $selo = $sq->fetch(PDO::FETCH_ASSOC) ?: null;
              if ($selo) $fraude = ws_comp_selo_fraude($db, $selo); } catch (Throwable $e) {}
        /* JÁ BAIXADO PELA API (10/10/2026): o cliente manda o comprovante de um pagamento que o gateway/banco JÁ baixou sozinho (sem nada vencido em aberto e
           título pago nos últimos 2 dias) — o robô diz isso, em vez de "o financeiro vai conferir". O comprovante continua registrado para o financeiro. */
        $jaPagoMsg = '';
        try {
            $cidP = (int)$db->query("SELECT cliente_id FROM ws_comprovante WHERE id=" . (int)$id)->fetchColumn();
            if ($cidP > 0) {
                $ab = $db->prepare("SELECT COUNT(*) FROM ws_fatura WHERE cliente_id=? AND status IN ('aberto','vencido','processando') AND vencimento <= CURDATE()"); $ab->execute([$cidP]);
                if ((int)$ab->fetchColumn() === 0) {
                    $pg = $db->prepare("SELECT data_pagamento, (gateway_raw IS NOT NULL AND gateway_raw<>'') api FROM ws_fatura WHERE cliente_id=? AND status='pago' AND data_pagamento >= CURDATE() - INTERVAL 2 DAY ORDER BY data_pagamento DESC, id DESC LIMIT 1");
                    $pg->execute([$cidP]); $pgr = $pg->fetch(PDO::FETCH_ASSOC);
                    if ($pgr) $jaPagoMsg = 'Seu pagamento já foi identificado' . ((int)$pgr['api'] === 1 ? ' automaticamente' : '') . ' e a fatura foi baixada em ' . date('d/m', strtotime((string)$pgr['data_pagamento'])) . ".\n✅ Não precisa aguardar conferência — sua conexão já está regularizada.";
                }
            }
        } catch (Throwable $e) {}
        /* BOLETO PAGO (10/10/2026): comprovante de pagamento de BOLETO (código de barras) — compensa em até 2 dias úteis e a baixa é automática pelo gateway; o robô diz isso. */
        $boletoMsg = '';
        try { $detB = ws_comp_detalhes($db, $id, true);
            if (!empty($detB['boleto'])) { $bo = $detB['boleto']; $boletoMsg = '💳 É pagamento de *boleto*' . ($bo['venc'] ? ' (venc. ' . date('d/m', strtotime($bo['venc'])) . ')' : '') . ($bo['valor'] ? ' de R$ ' . number_format($bo['valor'], 2, ',', '.') : '') . '.' . "\n" . (!empty($bo['agendado']) ? '⏳ O pagamento está *agendado* para *' . date('d/m', strtotime($bo['agendado'])) . '* (o dinheiro só sai da sua conta nessa data).' . "\n" . 'Depois do débito o banco compensa em até *2 dias úteis*, a baixa é *automática* e você recebe o *recibo de pagamento* aqui.' : '✅ O pagamento foi identificado pela *API do banco* e está *aguardando a confirmação* (compensação, até *2 dias úteis*).' . "\n" . 'Assim que confirmar, a baixa é *automática* e você recebe o *recibo de pagamento* aqui.'); }
        } catch (Throwable $e) {}
        /* QUANDO O RECIBO CHEGA (12/10/2026, caso Gilvanilda): o fluxo mandava SEMPRE o texto fixo "Após a conferência PIX, o recibo será enviado…", mesmo para boleto pago pela API. Regra do provedor:
           PIX com baixa automática = recibo de imediato; boleto (código de barras) = até 2 dias úteis; PIX sem baixa automática = depois da conferência. Cada resposta já traz a frase certa (o texto fixo saiu do fluxo). */
        if ($jaPagoMsg !== '') $jaPagoMsg .= $boletoMsg !== ''
            ? "\n🧾 Como o pagamento foi por *boleto*, o *recibo de pagamento* chega em até *2 dias úteis*, automaticamente, neste WhatsApp."
            : "\n🧾 O *recibo de pagamento* é enviado *de imediato*, automaticamente, para o WhatsApp cadastrado no sistema.";
        if ($jaPagoMsg === '' && $boletoMsg !== '' && $fraude === '' && ($selo['leitura'] ?? '') !== 'banco_nao') $jaPagoMsg = $boletoMsg;
        if ($jaPagoMsg !== '' && $fraude === '' && ($selo['leitura'] ?? '') !== 'banco_nao') {
            return ['ok' => true, 'valido' => true, 'id' => $id, 'arquivo' => $x['baixado'] ?? '', 'motivo' => $x['erro'] ?? null,
                'cliente' => $cliTxt !== '' ? $cliTxt : 'não identificado pelo CPF/telefone (o financeiro vai conferir)',
                'selo' => $selo['selo'] ?? null, 'repetido' => false, 'mensagem' => $jaPagoMsg];
        }
        return ['ok' => true, 'valido' => true, 'id' => $id, 'arquivo' => $x['baixado'] ?? '', 'motivo' => $x['erro'] ?? null,
            'cliente' => $cliTxt !== '' ? $cliTxt : 'não identificado pelo CPF/telefone (o financeiro vai conferir)',
            'selo' => $selo['selo'] ?? null, 'repetido' => $fraude !== '',
            // banco_nao/banco_ok só existem com a API PIX do Banco do Brasil ligada (bb_pix.php); sem ela, segue a conferência do financeiro
            'mensagem' => ($selo['leitura'] ?? '') === 'banco_nao' ? 'Não encontramos este pagamento na nossa conta. Confira o comprovante ou fale com o financeiro.'
                        : ($fraude !== '' ? 'Este comprovante já foi enviado e utilizado anteriormente. Envie o comprovante deste pagamento.'
                        : (($selo['leitura'] ?? '') === 'banco_ok'
                            ? '🏦 Pagamento confirmado no banco! ' . (!empty($selo['selo']) ? 'Selo ' . $selo['selo'] . '. ' : '') . 'A baixa é automática e o recibo chega em instantes.'
                            : (!empty($selo['selo']) ? '✅ Selo de segurança ' . $selo['selo'] . '. ' : '') . "O financeiro vai conferir e dar baixa.\n\n🧾 Após a conferência PIX, o recibo será enviado automaticamente para o número de WhatsApp cadastrado no sistema.\n\nObrigado.🤝"))];
}
// POST /api/comprovante → comprovante PIX que o cliente mandou no robô (Financeiro → Comprovantes PIX).
// Mesma credencial Basic do "GERA TOKEN". Corpo JSON: {comprovante, nome_informado, remoteJid, pushName, cpf}.
// O caminho completo (e de onde sai o arquivo) está no topo de comprovantes_lib.php.
if ($rota === 'comprovante') {
    if (!hash_equals($cfg['auth_hash'], ws_chatbot_auth_hash(preg_match('/^\s*basic\s/i', $auth) ? $auth : '')))
        $resp(401, ['erro' => 'credencial inválida']);
    $bruto = (string)file_get_contents('php://input');
    $d = json_decode($bruto, true);
    if (!is_array($d)) $d = $_POST;
    // JSON quebrado (ex.: quebra de linha entre duas imagens sem escape): aproveita o que dá para ler do texto
    if (!is_array($d) || !$d) {
        $d = ['comprovante' => $bruto];
        if (preg_match('/"remoteJid"\s*:\s*"([^"]*)"/', $bruto, $x)) $d['remoteJid'] = $x[1];
        if (preg_match('/"nome_informado"\s*:\s*"([^"]*)"/', $bruto, $x)) $d['nome_informado'] = $x[1];
        if (preg_match('/"pushName"\s*:\s*"([^"]*)"/', $bruto, $x)) $d['pushName'] = $x[1];
    }
    try {
        require_once dirname(__DIR__) . '/whatsapp.php';
        require_once dirname(__DIR__) . '/comprovantes_lib.php';
        $db = ws_db();
        ws_selfheal($db);   // instalação que ainda não abriu tela nenhuma depois de atualizar: cria a tabela
        try { if (!empty($d['remoteJid'])) ws_sessao_concluir((string)$d['remoteJid']); } catch (Throwable $e) {}   // conclusão por inatividade: o cliente mandou o comprovante
        /* SÓ FOTO (print) OU PDF (30/09/2026): texto, áudio, vídeo ou figurinha não viram comprovante. O robô recebe
           valido=false + a mensagem e repete a pergunta até vir o arquivo (condição no Typebot: {{valido}} = false). */
        $tipos = array_column(ws_comp_parse((string)($d['comprovante'] ?? '')), 'tipo');
        if (!$tipos || array_diff($tipos, ['image', 'document', 'url']))
            $resp(200, ['ok' => false, 'valido' => false, 'mensagem' => 'Envie a FOTO (print) ou o PDF do comprovante de pagamento. Texto, áudio ou figurinha não são aceitos.']);
        $id = ws_comp_receber($db, $d);
        $resp(200, ws_api_comp_resposta($db, $id));
    } catch (Throwable $e) {
        $resp(500, ['erro' => 'falha ao guardar o comprovante']);
    }
}

// GET /api/titulo/aberto/{cpf} · /api/titulo/vencido/{cpf}
/* O CPF/CNPJ vem do jeito que o cliente digitou no chat ("111.111.111-71", "CPF: 111 111 111 71",
   "12.345.678/0001-90"): aceita qualquer texto — ws_chatbot_titulos() fica só com os números e confere 11/14 dígitos. */
if (preg_match('#^titulo/(aberto|vencido|todos)/(.+)$#', $rota, $m)) {
    if (!ws_chatbot_token_valido($auth, $cfg)) $resp(401, ['erro' => 'token inválido ou vencido']);
    try {
        $resp(200, ['titulos' => ws_chatbot_titulos(ws_db(), rawurldecode($m[2]), $m[1])]);
    } catch (Throwable $e) {
        $resp(500, ['erro' => 'falha ao consultar os títulos']);
    }
}

$resp(404, ['erro' => 'endereço não existe nesta API']);
