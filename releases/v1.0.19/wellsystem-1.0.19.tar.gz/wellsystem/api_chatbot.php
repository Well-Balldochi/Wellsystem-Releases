<?php
/**
 * WellSystem — API DO CHATBOT, compatível com a API do MK-Auth (24/09/2026).
 *
 * O robô de atendimento (Typebot + n8n) buscava a 2ª via no MK-Auth. Com o financeiro.wellnet.com.br
 * apontando para o WellSystem, os MESMOS endereços passam a ser atendidos aqui — sem mudar nada no bot:
 *
 *   GET /api/                          Authorization: Basic <client_id:client_secret>  → token (texto puro)
 *   GET /api/titulo/aberto/{cpf}       Authorization: Bearer <token>  → {"titulos":[...]} todos em aberto
 *   GET /api/titulo/vencido/{cpf}      Authorization: Bearer <token>  → {"titulos":[...]} só os vencidos
 *   GET /boleto/boleto.hhvm?titulo=ID&contrato=LOGIN                  → HTML do boleto (o n8n vira PDF)
 *
 * Campos de cada título = os que o bot lê (script "Filtra os boletos selecionado"): uuid, login, nome,
 * titulo, status, cli_ativado, tipo, valor, linhadig, datavenc, cpf_cnpj, pix, pix_link, pix_qr.
 *
 * SEGURANÇA: a credencial Basic não fica gravada — só o SHA-256 dela (Mensagens → Servidor → API do
 * chatbot). O token é assinado (HMAC com chave própria deste servidor) e vale 1 h. O boleto.hhvm só abre
 * título EM ABERTO cujo login confere com um contrato do cliente, e só com a API ligada.
 *
 * DATA: "datavenc" sai SEMPRE como AAAA-MM-DD. Quem converte para o cliente ver (e aceita a resposta
 * dele em qualquer formato: 1/1/2025, 01-01-2025, 01.01.25 ou o número da opção) são os scripts do
 * Typebot — texto completo em INTEGRACOES.md (Documentação → INTEGRAÇÕES). Não mude este formato: os
 * scripts recortam a data do texto justamente para não depender de fuso horário.
 */

function ws_chatbot_arquivo(): string { return WS_CACHE . '/api_chatbot.json'; }

function ws_chatbot_cfg(): array {
    $c = @json_decode((string)@file_get_contents(ws_chatbot_arquivo()), true);
    $c = (is_array($c) ? $c : []) + ['ativo' => 0, 'auth_hash' => '', 'chave' => ''];
    if ($c['chave'] === '') { $c['chave'] = bin2hex(random_bytes(32)); ws_chatbot_salvar($c); }
    return $c;
}

function ws_chatbot_salvar(array $c): void {
    @file_put_contents(ws_chatbot_arquivo(), json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    @chmod(ws_chatbot_arquivo(), 0640);
}

/** Hash da credencial. Aceita o valor inteiro do header ("Basic xxxx") ou só a parte depois do "Basic". */
function ws_chatbot_auth_hash(string $valor): string {
    $v = trim(preg_replace('/^\s*basic\s+/i', '', trim($valor)));
    return $v === '' ? '' : hash('sha256', $v);
}

/** Header Authorization da requisição (PHP-FPM às vezes só entrega pelo REDIRECT_…). */
function ws_chatbot_header_auth(): string {
    foreach (['HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION'] as $k) if (!empty($_SERVER[$k])) return (string)$_SERVER[$k];
    if (function_exists('getallheaders')) foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') return (string)$v;
    return '';
}

function ws_chatbot_b64url(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }

function ws_chatbot_token_emitir(array $c): string {
    $p = ws_chatbot_b64url(json_encode(['exp' => time() + 3600, 'n' => bin2hex(random_bytes(6))]));
    return $p . '.' . ws_chatbot_b64url(hash_hmac('sha256', $p, $c['chave'], true));
}

function ws_chatbot_token_valido(string $token, array $c): bool {
    $token = trim(preg_replace('/^\s*bearer\s+/i', '', $token));
    if (substr_count($token, '.') !== 1) return false;
    [$p, $sig] = explode('.', $token);
    if (!hash_equals(ws_chatbot_b64url(hash_hmac('sha256', $p, $c['chave'], true)), $sig)) return false;
    $d = json_decode((string)base64_decode(strtr($p, '-_', '+/')), true);
    return is_array($d) && (int)($d['exp'] ?? 0) >= time();
}

/**
 * PIX do título — AS MESMAS REGRAS do boleto.php (o que o bot mostra tem de ser o que o boleto imprime):
 *   conta do título/contrato "própria"  → PIX da chave própria (Provedor → Bancos), ignora o gateway;
 *   senão: título importado do MK-Auth sem PIX → completa no gateway (ws_celcash_completar_importada);
 *          tem PIX do gateway → ele; não tem → PIX da chave própria (banco padrão).
 * @return array [emv, qr (URL de imagem), link (página de pagamento)]
 */
function ws_chatbot_pix(PDO $db, array &$f, array $bancos, ?array $bancoPad, array $prov): array {
    $bk = null;
    $bid = (int)($f['banco_id'] ?? 0);
    if ($bid && isset($bancos[$bid]) && trim((string)$bancos[$bid]['pix']) !== '') $bk = $bancos[$bid]; else $bk = $bancoPad;
    $propria = $bk && (($bk['emissao'] ?? '') === 'proprio');
    if (!$propria && function_exists('ws_celcash_completar_importada')) { try { ws_celcash_completar_importada($db, $f); } catch (Throwable $e) {} }
    $emv = $propria ? '' : trim((string)($f['pix_emv'] ?? ''));
    $qr  = $propria ? '' : trim((string)($f['pix_qr_url'] ?? ''));
    $link = '';
    if (!$propria) {
        // Título recém-completado: o gateway_raw foi gravado no banco agora, mas não veio no $f desta chamada.
        if (trim((string)($f['gateway_raw'] ?? '')) === '' && !empty($f['id'])) {
            try { $st = $db->prepare("SELECT gateway_raw FROM ws_fatura WHERE id=?"); $st->execute([(int)$f['id']]); $f['gateway_raw'] = (string)$st->fetchColumn(); } catch (Throwable $e) {}
        }
        $link = ws_chatbot_link_pagamento((string)($f['gateway_raw'] ?? ''), (string)($f['celcash_charge_id'] ?? ''));
        if ($link === '') $link = trim((string)($f['boleto_url'] ?? ''));   // sem página de PIX: o boleto do gateway
    }
    if ($emv === '' && $bk && function_exists('ws_pix_emv')) {
        $chave = ws_pix_chave((string)$bk['pix'], (string)($bk['tipo_chave'] ?? ''));
        $nomeP = ($prov['razao'] ?? '') ?: ($prov['fantasia'] ?? 'PROVEDOR');
        if ($chave !== '') $emv = ws_pix_emv($chave, $nomeP, (string)($prov['cidade'] ?? ''), function_exists('ws_fatura_valor_atualizado') ? ws_fatura_valor_atualizado($f) : ws_fatura_valor_cobrado($f), ws_pix_txid_nome($f['nome'] ?? '', $f['id']));   // vencido: com multa e juros
    }
    /* QR = IMAGEM EMBUTIDA "data:image/png;base64,…", exatamente como o MK-Auth mandava: o bot tira o prefixo e
       a Evolution envia a imagem. Um LINK aqui travava o fluxo (teste real 24/09: o endereço de QR da CelCoin
       gravado na fatura devolve 404, e o bot parava no QR, antes do boleto). Gerado aqui mesmo, sem site externo. */
    $qr = '';
    if ($emv !== '') { $png = ws_chatbot_qr_png($emv); if ($png !== '') $qr = 'data:image/png;base64,' . base64_encode($png); }
    return [$emv, $qr, $link];
}

/**
 * Página de pagamento PIX da cobrança (o {{pix_link}} que o bot mostra), tirada do retorno do gateway.
 * CUIDADO: em título IMPORTADO do MK-Auth o gateway_raw é a JANELA de cobranças da busca (várias, de OUTROS
 * clientes). Só vale a cobrança cujo galaxPayId é o deste título — nunca "a primeira que aparecer".
 */
function ws_chatbot_link_pagamento(string $raw, string $chargeId): string {
    $j = json_decode($raw, true);
    if (!is_array($j)) return '';
    $cands = [];
    if (isset($j['Charges']) && is_array($j['Charges'])) $cands = $j['Charges'];
    elseif (isset($j['Charge']) && is_array($j['Charge'])) $cands = [$j['Charge']];
    elseif ($j && array_keys($j) === range(0, count($j) - 1)) $cands = $j;   // lista (sem array_is_list: o servidor pode ser PHP 7.4)
    else $cands = [$j];
    $ch = null;
    foreach ($cands as $c) {
        if (!is_array($c)) continue;
        if ($chargeId !== '' && (string)($c['galaxPayId'] ?? '') === $chargeId) { $ch = $c; break; }
    }
    if ($ch === null && count($cands) === 1 && is_array($cands[0]) && ($chargeId === '' || !isset($cands[0]['galaxPayId']))) $ch = $cands[0];
    if (!$ch) return '';
    foreach ((array)($ch['Transactions'] ?? []) as $t) if (!empty($t['Pix']['page'])) return (string)$t['Pix']['page'];
    return (string)($ch['Pix']['page'] ?? ($ch['paymentLink'] ?? ''));
}

/** PNG do QR Code do texto (PIX copia-e-cola) — PHP puro: usa o gerador de QR do boleto_pdf.php e grava o PNG
 *  à mão (zlib + CRC), sem precisar da extensão GD. 6 px por módulo, margem de 4 módulos. '' se falhar. */
function ws_chatbot_qr_png(string $texto, int $px = 6): string {
    // Guardado por PIX: o mesmo copia-e-cola nunca é desenhado duas vezes (a lista do bot pede todos os títulos).
    $dir = WS_CACHE . '/qr_chatbot';
    $arq = $dir . '/' . sha1($px . '|' . $texto) . '.png';
    if (is_file($arq) && ($g = (string)@file_get_contents($arq)) !== '') return $g;
    if (!function_exists('ws_qr_matriz')) { if (!is_file(__DIR__ . '/boleto_pdf.php')) return ''; require_once __DIR__ . '/boleto_pdf.php'; }
    if (!function_exists('ws_qr_matriz') || !function_exists('gzcompress')) return '';
    $m = ws_qr_matriz($texto);
    if (!$m) return '';
    $n = count($m); $q = 4; $lado = ($n + 2 * $q) * $px;
    $P = str_repeat("\x00", $px); $B = str_repeat("\xFF", $px);           // cinza 8 bits: preto / branco
    $branca = "\x00" . str_repeat("\xFF", $lado);                         // "\x00" = filtro 0 no início da linha
    $raw = str_repeat($branca, $q * $px);                                 // margem de cima
    foreach ($m as $linha) {
        $l = "\x00" . str_repeat($B, $q);
        for ($x = 0; $x < $n; $x++) $l .= !empty($linha[$x]) ? $P : $B;
        $raw .= str_repeat($l . str_repeat($B, $q), $px);                // a linha de módulos vira $px linhas de pixel
    }
    $raw .= str_repeat($branca, $q * $px);                                // margem de baixo
    $chunk = fn(string $tipo, string $d) => pack('N', strlen($d)) . $tipo . $d . pack('N', crc32($tipo . $d));
    $png = "\x89PNG\r\n\x1a\n"
         . $chunk('IHDR', pack('NNCCCCC', $lado, $lado, 8, 0, 0, 0, 0))   // 8 bits, cinza, sem entrelaçar
         . $chunk('IDAT', gzcompress($raw, 9))
         . $chunk('IEND', '');
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($arq, $png);
    // faxina: guarda só os 500 mais recentes
    $todos = glob($dir . '/*.png') ?: [];
    if (count($todos) > 600) { usort($todos, fn($a, $b) => filemtime($a) <=> filemtime($b)); foreach (array_slice($todos, 0, count($todos) - 500) as $v) @unlink($v); }
    return $png;
}

/**
 * Títulos em aberto do CPF/CNPJ — do titular E dos adicionais dele (regra do provedor: andam juntos).
 * $qual: 'aberto' = todos os não pagos (igual ao MK-Auth, vencidos incluídos) · 'vencido' = só os já vencidos.
 */
function ws_chatbot_titulos(PDO $db, string $doc, string $qual): array {
    $doc = preg_replace('/\D/', '', $doc);
    if (strlen($doc) !== 11 && strlen($doc) !== 14) return [];
    $st = $db->prepare("SELECT id FROM ws_cliente
                         WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','') = ?");
    $st->execute([$doc]);
    $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    if (!$ids) return [];
    try {   // adicionais do(s) titular(es) encontrados
        $in = implode(',', $ids);
        foreach ($db->query("SELECT id FROM ws_cliente WHERE titular_id IN ($in)")->fetchAll(PDO::FETCH_COLUMN) as $a) $ids[] = (int)$a;
    } catch (Throwable $e) {}
    $ids = array_values(array_unique($ids));
    $in = implode(',', $ids);
    $sql = "SELECT f.*, c.nome, c.cpf_cnpj, c.status cli_status,
                   COALESCE(NULLIF(f.banco_id,0), ct.banco_id) banco_id,
                   COALESCE(NULLIF(ct.login_pppoe,''), NULLIF(ct.login_ipoe,''),
                            (SELECT COALESCE(NULLIF(c2.login_pppoe,''), c2.login_ipoe) FROM ws_contrato c2 WHERE c2.cliente_id=f.cliente_id ORDER BY c2.id LIMIT 1)) login
              FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
             WHERE f.cliente_id IN ($in) AND f.status IN ('aberto','vencido','processando')"
         . ($qual === 'vencido' ? " AND f.vencimento < CURDATE()" : "")
         /* (15/10) o cliente só vê boletos até 45 dias à frente: o carnê de 2027 gerado de uma vez ainda NÃO foi emitido no gateway (sem código de barras/PDF) e lotava a lista da 2ª via com 12+ meses. */
         . ($qual === 'todos' ? '' : " AND f.vencimento <= CURDATE() + INTERVAL 45 DAY") . " ORDER BY f.vencimento, f.id";   // 'todos' (o cliente pediu TODOS os boletos) mostra tudo; 'vencido' = todos os vencidos; 'aberto' = até 45 dias à frente
    $rows = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) return [];

    $prov = @json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
    $bancos = []; $bancoPad = null;
    try { foreach ($db->query("SELECT * FROM ws_banco WHERE ativo=1")->fetchAll(PDO::FETCH_ASSOC) as $b) $bancos[(int)$b['id']] = $b; } catch (Throwable $e) {}
    foreach ($bancos as $b) if (trim((string)$b['pix']) !== '') { $bancoPad = $b; break; }

    $hoje = date('Y-m-d'); $out = [];
    foreach ($rows as $f) {
        [$emv, $qr, $link] = ws_chatbot_pix($db, $f, $bancos, $bancoPad, $prov);
        $out[] = [
            'uuid'        => (string)($f['celcash_my_id'] ?: 'ws-' . $f['id']),
            'login'       => (string)($f['login'] ?? ''),
            'nome'        => (string)$f['nome'],
            'titulo'      => (string)$f['id'],
            'status'      => substr((string)$f['vencimento'], 0, 10) < $hoje ? 'vencido' : 'aberto',
            'cli_ativado' => (($f['cli_status'] ?? '') === 'ativo') ? 's' : 'n',
            'tipo'        => (string)($f['categoria'] ?? '') ?: 'mensalidade',
            'valor'       => number_format(ws_fatura_valor_cobrado($f), 2, '.', ''),
            'linhadig'    => (string)($f['linha_digitavel'] ?? ''),
            'datavenc'    => substr((string)$f['vencimento'], 0, 10),
            'cpf_cnpj'    => (string)($f['cpf_cnpj'] ?? ''),
            'pix'         => $emv,
            /* Link abaixo do QR no robô = página PRÓPRIA do WellSystem com o QR deste título (24/09/2026, pedido do
               provedor: "abriu o boleto CelCash, não seria para abrir o QR Code próprio?"). A página da CelCoin/boleto
               do gateway só fica quando o título não tem PIX. Ver ws_chatbot_link_proprio(). */
            'pix_link'    => $emv !== '' ? ws_chatbot_link_proprio((int)$f['id']) : $link,
            'pix_qr'      => $qr,
        ];
    }
    return $out;
}

/**
 * PIX de UMA fatura para as mensagens automáticas (QR em imagem + copia-e-cola) — as MESMAS regras do boleto e
 * do chatbot (ws_chatbot_pix). null se a fatura não existir, não estiver em aberto ou não tiver PIX.
 * @return array|null ['emv' => string, 'png' => string (bytes do PNG)]
 */
function ws_fatura_pix_png(PDO $db, int $faturaId): ?array {
    if ($faturaId <= 0) return null;
    if (is_file(__DIR__ . '/pix.php')) require_once __DIR__ . '/pix.php';
    if (is_file(__DIR__ . '/celcash.php')) require_once __DIR__ . '/celcash.php';
    try {
        $st = $db->prepare("SELECT f.*, c.nome, COALESCE(NULLIF(f.banco_id,0), ct.banco_id) banco_id
                              FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id
                             WHERE f.id=? AND f.status IN ('aberto','vencido','processando')");
        $st->execute([$faturaId]);
        $f = $st->fetch(PDO::FETCH_ASSOC);
        if (!$f) return null;
        $prov = @json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
        $bancos = []; $bancoPad = null;
        foreach ($db->query("SELECT * FROM ws_banco WHERE ativo=1")->fetchAll(PDO::FETCH_ASSOC) as $b) $bancos[(int)$b['id']] = $b;
        foreach ($bancos as $b) if (trim((string)$b['pix']) !== '') { $bancoPad = $b; break; }
        [$emv] = ws_chatbot_pix($db, $f, $bancos, $bancoPad, $prov);
        if ($emv === '') return null;
        $png = ws_chatbot_qr_png($emv);
        return $png !== '' ? ['emv' => $emv, 'png' => $png] : null;
    } catch (Throwable $e) { return null; }
}

/* QR CODE DO PIX MANUAL (24/09/2026) — o bloco "Pix - QR Code ( Manual )" do Typebot mandava uma imagem
 * FIXA guardada fora (s3.wellnet.com.br/.../QR-Code BB.jpeg). Agora o robô aponta para
 * GET /api/pix/qrcode.png e o QR é gerado AQUI, da chave PIX da conta escolhida em
 * Mensagens → Servidor → API do chatbot (sem escolha: a 1ª conta de emissão PRÓPRIA com PIX; sem ela, a 1ª com PIX).
 * É o QR da CHAVE (estático, sem valor e sem cliente): o cliente digita o valor no banco e a baixa continua
 * MANUAL (comprovante), como antes. Trocou a chave na conta → o QR do robô muda junto, sem refazer imagem.
 * Endereço público de propósito: o WhatsApp/Evolution baixa a imagem sem token, e o QR só tem a chave,
 * que o próprio robô já mostra em texto. Só responde com a API ligada. */
function ws_chatbot_pix_manual_conta(PDO $db, int $bancoId = 0): ?array {
    $lista = $db->query("SELECT * FROM ws_banco WHERE ativo=1 AND TRIM(COALESCE(pix,''))<>'' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    if (!$lista) return null;
    foreach ($lista as $b) if ($bancoId > 0 && (int)$b['id'] === $bancoId) return $b;
    foreach ($lista as $b) if (($b['emissao'] ?? '') === 'proprio') return $b;
    return $lista[0];
}

/** [emv, png] do QR estático da chave (valor opcional > 0 entra no QR). null = sem conta com PIX. */
function ws_chatbot_pix_manual(PDO $db, int $bancoId = 0, float $valor = 0, string $txid = '***'): ?array {
    if (is_file(__DIR__ . '/pix.php')) require_once __DIR__ . '/pix.php';
    $b = ws_chatbot_pix_manual_conta($db, $bancoId);
    if (!$b || !function_exists('ws_pix_emv')) return null;
    $chave = ws_pix_chave((string)$b['pix'], (string)($b['tipo_chave'] ?? ''));
    if ($chave === '') return null;
    $prov = @json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
    $nome = ($prov['razao'] ?? '') ?: (($prov['fantasia'] ?? '') ?: ((string)($b['titular'] ?? '') ?: 'PROVEDOR'));
    $emv = ws_pix_emv($chave, $nome, (string)($prov['cidade'] ?? ''), $valor > 0 ? round($valor, 2) : 0, $txid !== '' ? $txid : '***');
    $png = ws_chatbot_qr_png($emv, 8);
    return $png !== '' ? ['emv' => $emv, 'png' => $png, 'banco' => $b] : null;
}

/* PÁGINA PRÓPRIA DO PIX DE UM TÍTULO — /api/pix/pagar/<título>-<assinatura> (24/09/2026).
 * É o link que o robô manda abaixo do QR: abre no celular com o QR, o valor, o vencimento e o copia e cola
 * (botão Copiar). A assinatura (HMAC com a chave própria deste servidor) impede de trocar o número e ver o
 * título de outro cliente. A página é montada em api/index.php (rota pix/pagar). */
function ws_chatbot_link_sig(int $id): string {
    return substr(hash_hmac('sha256', 'pix|' . $id, (string)ws_chatbot_cfg()['chave']), 0, 16);
}
function ws_chatbot_link_proprio(int $id): string {
    $host = preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    // pasta do sistema no domínio ('' quando o domínio aponta direto para ele): quem chama é api/index.php
    $pasta = rtrim(str_replace('\\', '/', dirname(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/api/index.php')))), '/');
    return ($https ? 'https' : 'http') . '://' . ($host ?: 'localhost') . $pasta . '/api/pix/pagar/' . $id . '-' . ws_chatbot_link_sig($id);
}

/* QR DO PIX MANUAL COM VALOR — caminho "Chave PIX (Baixa Manual)" do robô: pede o CPF/CNPJ e chama
 * /api/pix/qrcode/<só números>.png.
 * SEMPRE A CONTA PRÓPRIA (correção de 24/09/2026 pedida pelo provedor): é a CHAVE da conta própria (a mesma do QR
 * da chave) COM O VALOR do título em aberto mais antigo do cliente (titular + adicionais) e o nome do cliente no
 * identificador (txid), para achar no extrato. O dinheiro cai na conta própria e a baixa é MANUAL, pelo comprovante
 * (Financeiro → Comprovantes PIX). Antes ia o PIX do boleto, que no gateway é o da CelCoin, e a baixa saía por lá.
 * A opção "QR Code (Baixa Automática)" e o link da página (pix_link) continuam com o PIX do boleto.
 * null (CPF inválido/sem título em aberto) → quem chama manda o QR da chave sem valor, como antes.
 * O endereço é sem token (o WhatsApp baixa a imagem direto): quem souber um CPF vê só o QR para pagar o PROVEDOR. */
function ws_chatbot_pix_cpf_png(PDO $db, string $cpf): ?string {
    $cpf = preg_replace('/\D/', '', $cpf);
    if (strlen($cpf) !== 11 && strlen($cpf) !== 14) return null;
    $t = ws_chatbot_titulos($db, $cpf, 'aberto')[0] ?? null;   // já vem por vencimento: o 1º é o mais antigo
    if (!$t || (float)$t['valor'] <= 0) return null;
    $txid = function_exists('ws_pix_txid_nome') ? ws_pix_txid_nome($t['nome'] ?? '', $t['titulo']) : '***';
    $r = ws_chatbot_pix_manual($db, (int)(ws_chatbot_cfg()['pix_manual_banco'] ?? 0), (float)$t['valor'], $txid);
    return $r['png'] ?? null;
}

/** O boleto.hhvm pode abrir este título? (API ligada, título EM ABERTO e login de um contrato do cliente.) */
function ws_chatbot_boleto_permitido(PDO $db, int $titulo, string $login): bool {
    $login = trim($login);
    if ($titulo <= 0 || $login === '' || empty(ws_chatbot_cfg()['ativo'])) return false;
    $st = $db->prepare("SELECT f.id FROM ws_fatura f JOIN ws_contrato ct ON ct.cliente_id=f.cliente_id
                         WHERE f.id=? AND f.status IN ('aberto','vencido','processando')
                           AND (ct.login_pppoe=? OR ct.login_ipoe=?) LIMIT 1");
    $st->execute([$titulo, $login, $login]);
    return (bool)$st->fetchColumn();
}


/* =====================================================================================================================
 * ÁUDIO DO CLIENTE NO ROBÔ (01/10/2026) — o cliente responde o menu FALANDO e o robô entende como se tivesse digitado.
 * A Evolution entrega o áudio ao Typebot como "audioMessage|<id da mensagem>". Logo depois de cada pergunta de menu o
 * Typebot chama POST /api/audio; aqui o áudio é baixado da Evolution (getBase64FromMediaMessage; na API oficial,
 * também pelo mediaUrl guardado no S3), transcrito pelo Whisper (OpenAI) e convertido na opção do menu
 * ("segunda via" → 2, "quero falar com atendente" → 7, "um" → 1). Para CPF ditado, os números falados viram dígitos.
 * Sem chave da OpenAI (Mensagens → API do chatbot) nada muda: o texto volta igual e o menu segue como hoje.
 * Custo: ~US$ 0,003 por minuto de áudio (gpt-4o-mini-transcribe; reserva whisper-1). Cada transcrição fica no Monitor do robô (Relatórios).
 * ================================================================================================================== */
function ws_chatbot_openai_key(): string { return trim((string)(ws_chatbot_cfg()['openai_key'] ?? '')); }

/* MÍDIA RECEBIDA PELO WEBHOOK DA EVOLUTION (02/10/2026).
 * No número OFICIAL (API da Meta / WHATSAPP-BUSINESS) a Evolution NÃO guarda o áudio/imagem que o cliente manda: o
 * findMessages não acha a mensagem e o getBase64FromMediaMessage dá erro — medido no áudio de teste. Por isso a própria
 * Evolution passa a ENTREGAR a mídia ao WellSystem no instante em que chega (webhook MESSAGES_UPSERT com base64), e o
 * arquivo fica 2 h em cache/midia_recebida/ esperando o robô pedir pelo ID da mensagem. Vale também para Baileys. */
function ws_midia_dir(): string { $d = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/midia_recebida'; if (!is_dir($d)) @mkdir($d, 0750, true); return $d; }
/** MENSAGEM JÁ VISTA (13/10/2026): a Evolution entrega o mesmo evento mais de uma vez (reenvio por lentidão, dois webhooks, SEND_MESSAGE + UPSERT). A 1ª vez devolve false e grava o id;
 *  as seguintes (30 min) devolvem true — o webhook não repete o que já fez com aquela mensagem (anexar ao chamado, resposta de comprovante, entrega de boleto pendente). Com flock. */
function ws_msg_ja_vista(string $id): bool {
    if ($id === '') return false;
    $f = ws_midia_dir() . '/vistas.json'; $h = @fopen($f, 'c+'); if (!$h) return false;
    $vista = false;
    if (flock($h, LOCK_EX)) {
        $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = [];
        foreach ($j as $k => $t) if (time() - (int)$t > 1800) unset($j[$k]);
        $k = substr(sha1($id), 0, 20);
        if (isset($j[$k])) $vista = true; else { $j[$k] = time(); ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j)); fflush($h); }
        flock($h, LOCK_UN);
    }
    fclose($h); @chmod($f, 0640);
    return $vista;
}
function ws_midia_arq(string $id): string { return ws_midia_dir() . '/' . sha1($id); }
function ws_midia_token(): string { return substr(hash_hmac('sha256', 'evolution-midia', (string)(ws_chatbot_cfg()['chave'] ?? '')), 0, 32); }
function ws_midia_webhook_url(): string {
    // endereço fixo do sistema; sem ele, o domínio por onde o robô chama a API (gravado pela própria API em cache/api_base.txt)
    $b = function_exists('ws_url_publica') ? ws_url_publica() : '';
    if ($b === '' || PHP_SAPI === 'cli' && trim((string)@file_get_contents(WS_CACHE . '/url_publica.txt')) === '') $b = trim((string)@file_get_contents(WS_CACHE . '/api_base.txt')) ?: $b;
    return $b === '' ? '' : rtrim($b, '/') . '/api/evolution/' . ws_midia_token();
}
function ws_midia_guardar(string $id, string $bin, string $mime, string $nome = ''): void {
    if ($id === '' || strlen($bin) < 100 || strlen($bin) > 16 * 1024 * 1024) return;
    $a = ws_midia_arq($id);
    @file_put_contents($a . '.tmp', $bin, LOCK_EX); @rename($a . '.tmp', $a); @chmod($a, 0640);
    @file_put_contents($a . '.json', json_encode(['mime' => $mime, 'nome' => $nome, 'em' => time()])); @chmod($a . '.json', 0640);
    if (mt_rand(1, 20) === 1) foreach (glob(ws_midia_dir() . '/*') ?: [] as $f) if (filemtime($f) < time() - 7200) @unlink($f);   // limpeza: 2 h
}
/** [binário, mime, nome] da mídia recebida, ou null. $esperar: segundos aguardando o webhook chegar (ele corre junto com o robô). */
function ws_midia_pegar(string $id, int $esperar = 0): ?array {
    if ($id === '') return null;
    $a = ws_midia_arq($id); $fim = microtime(true) + $esperar;
    do {
        if (is_file($a) && is_file($a . '.json')) { $j = json_decode((string)@file_get_contents($a . '.json'), true) ?: []; $b = (string)@file_get_contents($a); if (strlen($b) > 100) return [$b, (string)($j['mime'] ?? ''), (string)($j['nome'] ?? '')]; }
        if (microtime(true) >= $fim) break;
        usleep(400000);
    } while (true);
    return null;
}
/** Liga na Evolution o envio da mídia para o WellSystem (todas as instâncias do sistema). Devolve [instância => ok/erro]. */
function ws_midia_webhook_registrar(): array {
    if (!function_exists('ws_wa_config') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
    $c = ws_wa_config(); $srv = rtrim((string)($c['url'] ?? ''), '/'); $key = (string)($c['apikey'] ?? ''); $url = ws_midia_webhook_url();
    if ($srv === '' || $key === '' || $url === '') return ['—' => 'Evolution ou endereço público do sistema não configurado'];
    $inst = function_exists('ws_wa_instancias') ? ws_wa_instancias($c) : [(string)($c['instance'] ?? '')];
    $out = [];
    foreach (array_unique(array_filter($inst)) as $i) {
        // não sobrescreve webhook de outro sistema: só grava se a instância não tiver nenhum, ou se já for o do WellSystem
        $ch = curl_init("$srv/webhook/find/" . rawurlencode($i)); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($c, (string)$i)]]);
        $atual = json_decode((string)curl_exec($ch), true); curl_close($ch);
        $uAtual = (string)($atual['url'] ?? ''); $ligado = !empty($atual['enabled']);
        if ($ligado && $uAtual !== '' && strpos($uAtual, '/api/evolution/') === false) { $out[$i] = 'já tem outro webhook (' . parse_url($uAtual, PHP_URL_HOST) . ') — não mexi'; continue; }
        $ch = curl_init("$srv/webhook/set/" . rawurlencode($i));
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'apikey: ' . ws_wa_chave($c, (string)$i)],
            CURLOPT_POSTFIELDS => json_encode(['webhook' => ['enabled' => true, 'url' => $url, 'byEvents' => false, 'base64' => true, 'events' => ['MESSAGES_UPSERT']]])]);
        $r = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $out[$i] = $code >= 200 && $code < 300 ? 'ok' : 'HTTP ' . $code . ' ' . mb_substr((string)$r, 0, 120);
    }
    return $out;
}

/** Baixa o áudio da Evolution. Devolve [binário, mimetype] ou null. */
function ws_chatbot_audio_baixar(string $msgId, string $inst, string $server, string $apikey): ?array {
    // 0) entregue pelo webhook da Evolution (único caminho no número oficial da Meta) — espera até 8 s
    if ($m = ws_midia_pegar($msgId, 8)) return [$m[0], $m[1] ?: 'audio/ogg'];
    if (!preg_match('#^https?://[^\s/]+#i', $server)) return null;
    $server = rtrim($server, '/');
    $post = function (string $url, array $body) use ($apikey) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'apikey: ' . $apikey], CURLOPT_POSTFIELDS => json_encode($body)]);
        $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$c, json_decode((string)$r, true)];
    };
    [$c, $j] = $post("$server/chat/getBase64FromMediaMessage/" . rawurlencode($inst), ['message' => ['key' => ['id' => $msgId]], 'convertToMp4' => false]);
    if ($c >= 200 && $c < 300 && !empty($j['base64'])) {
        $bin = base64_decode((string)$j['base64'], true);
        if ($bin !== false && strlen($bin) > 100) return [$bin, (string)($j['mimetype'] ?? 'audio/ogg')];
    }
    // API oficial: a Evolution guarda a mídia no S3 e devolve o endereço em message.mediaUrl.
    [$c, $j] = $post("$server/chat/findMessages/" . rawurlencode($inst), ['where' => ['key' => ['id' => $msgId]]]);
    $recs = $j['messages']['records'] ?? ($j['records'] ?? (isset($j[0]) ? $j : []));
    foreach ((array)$recs as $m) {
        $url = (string)($m['message']['mediaUrl'] ?? ($m['message']['audioMessage']['url'] ?? ''));
        if (!preg_match('#^https?://#i', $url) || strpos($url, 'mmg.whatsapp.net') !== false) continue;   // link cifrado do WhatsApp não serve
        $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3]);
        $bin = curl_exec($ch); $cc = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $mt = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); curl_close($ch);
        if ($cc === 200 && is_string($bin) && strlen($bin) > 100) return [$bin, $mt ?: 'audio/ogg'];
    }
    return null;
}

/** Dica para a transcrição (02/10/2026): nomes que o modelo não conhece e erra — cidades, bairros e o nome do provedor. */
function ws_chatbot_dica_transcricao(string $extra = ''): string {
    static $base = null;
    if ($base === null) {
        $nomes = [];
        try { $db = ws_db();
            foreach ($db->query("SELECT nome FROM ws_cidade ORDER BY nome LIMIT 40")->fetchAll(PDO::FETCH_COLUMN) as $n) $nomes[] = $n;
            foreach ($db->query("SELECT DISTINCT nome FROM ws_bairro ORDER BY nome LIMIT 120")->fetchAll(PDO::FETCH_COLUMN) as $n) $nomes[] = $n;
        } catch (Throwable $e) {}
        $prov = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
        $base = 'Atendimento de provedor de internet' . (function_exists('ws_provedor_nome_curto') ? ' ' . ws_provedor_nome_curto() : (!empty($prov['fantasia']) ? ' ' . $prov['fantasia'] : '')) . '. Palavras: boleto, segunda via, PIX, CPF, comprovante, fibra, roteador. Lugares: ' . implode(', ', array_unique(array_filter(array_map('trim', $nomes))));
    }
    return mb_substr(trim($extra . ' ' . $base), 0, 900);
}

/* ENTENDER A RESPOSTA COM IA (02/10/2026). A transcrição sozinha devolve a FRASE ("meu nome é José da Silva", "nasci dia
   três de maio de oitenta e cinco", "é Nazaré da Mata"); o robô precisa do VALOR. Aqui um modelo barato (gpt-4o-mini,
   frações de centavo) recebe a pergunta do robô, o campo e as opções, e devolve só o valor no formato que o fluxo espera.
   Falhou/sem chave → '' (quem chama segue com a regra simples). */
function ws_chatbot_ia(string $fala, string $campo, string $pergunta, string $opcoes, string $tipo): string {
    $key = ws_chatbot_openai_key(); if ($key === '' || trim($fala) === '') return '';
    $regras = "Você converte a resposta FALADA de um cliente de provedor de internet (já transcrita) no VALOR exato que o robô de atendimento espera. "
        . "Responda só JSON {\"valor\":\"...\"}. Sem explicação. Interprete com bom senso (gírias, erros de fala, sinônimos: atrasado = vencido; o primeiro = 1). Valor vazio só se a resposta não tiver nada a ver com a pergunta.\n"
        . "- Opções numeradas: devolva SÓ o número da opção escolhida (pelo sentido, não só pela palavra). Escolha a opção MAIS PRÓXIMA do que o cliente quer, mesmo que ele não use as palavras do menu: 'está errado/tem erro/não está certo' = a opção de corrigir; 'já paguei/tenho o comprovante' = a de comprovante; 'quero um técnico/mandar alguém' = chamado técnico; 'libera aí/desbloqueia' = liberar em confiança; 'internet lenta/caiu/sem sinal' = a de problema de conexão; 'não/agora não/obrigado/só isso' em pergunta de sim/não = não.\n"
        . "- Se a PERGUNTA do robô lista opções numeradas (1️⃣ - …), devolva só o NÚMERO da opção mais próxima, mesmo que o tipo seja texto ('muito bom' = a de muito satisfeito, 'péssimo' = insatisfeito, 'mais ou menos' = indiferente, 'não quero avaliar' = não avaliar). 'copia e cola/código pix' = chave PIX.\n"
        . "- Lista de itens exatos: devolva o item EXATAMENTE como escrito na lista.\n"
        . "- CPF/CNPJ/telefone/número: só dígitos (\"vinte e três\" = 23; telefone com DDD, sem 55). CPF tem 11 dígitos e CNPJ 14: se a transcrição juntou um zero a mais (\"zero vinte e três\" virou 0203), corrija pelo que foi falado.\n"
        . "- Data: dd/mm/aaaa (ano de 2 dígitos: até 30 = 20xx, senão 19xx).\n"
        . "- Nome: só o nome da pessoa, iniciais maiúsculas (tire \"meu nome é\", \"sou o\").\n"
        . "- E-mail: minúsculo, sem espaços, \"arroba\" = @, \"ponto\" = . .\n"
        . "- Endereço/bairro/cidade/referência: só o valor, iniciais maiúsculas, sem \"eu moro na\".\n"
        . "- Outro texto livre (relato, avaliação): a frase limpa, como o cliente disse.";
    $user = "Campo: " . ($campo !== '' ? $campo : '—') . "\nTipo: $tipo\nPergunta do robô: " . mb_substr($pergunta, 0, 600)
          . ($opcoes !== '' ? "\nOpções/itens: $opcoes" : '') . "\nResposta do cliente: " . mb_substr($fala, 0, 500);
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => 'gpt-4o-mini', 'temperature' => 0, 'max_tokens' => 80, 'response_format' => ['type' => 'json_object'],
            'messages' => [['role' => 'system', 'content' => $regras], ['role' => 'user', 'content' => $user]]])]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return '';
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true);
    return ws_chatbot_acabamento(trim((string)($j['valor'] ?? '')), $campo);
}

/** Acabamento pelo tipo do campo: data com ano de 4 dígitos, e-mail sem acento, nome/endereço com da/de/do minúsculos. */
function ws_chatbot_acabamento(string $v, string $campo): string {
    if ($v === '') return '';
    $c = mb_strtolower($campo);
    if (preg_match('/whats|telefone|celular|ddd/', $c) && preg_match('/^[\d\s()+.\-]{8,}$/', $v)) { $d = preg_replace('/\D/', '', $v); if (strlen($d) >= 12 && substr($d, 0, 2) === '55') $d = substr($d, 2); return $d; }
    if (preg_match('/nasc|data/', $c) && preg_match('#^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})$#', $v, $m)) {
        $a = (int)$m[3]; if (strlen($m[3]) === 2) $a += $a <= (int)date('y') ? 2000 : 1900;
        return sprintf('%02d/%02d/%04d', $m[1], $m[2], $a);
    }
    if (preg_match('/mail/', $c)) return strtolower(str_replace(' ', '', strtr($v, ['á'=>'a','à'=>'a','â'=>'a','ã'=>'a','é'=>'e','ê'=>'e','í'=>'i','ó'=>'o','ô'=>'o','õ'=>'o','ú'=>'u','ü'=>'u','ç'=>'c','Á'=>'a','É'=>'e','Í'=>'i','Ó'=>'o','Ú'=>'u','Ã'=>'a','Õ'=>'o','Ç'=>'c'])));
    // bairro/cidade: a grafia do CADASTRO, quando o falado bate com um nome existente (sem acento/maiúscula)
    if (preg_match('/bairro|cidade/', $c)) { try { $tab = strpos($c, 'bairro') !== false ? 'ws_bairro' : 'ws_cidade'; $alvo = ws_chatbot_norm($v);
        foreach (ws_db()->query("SELECT DISTINCT nome FROM $tab LIMIT 500")->fetchAll(PDO::FETCH_COLUMN) as $nm) if (ws_chatbot_norm((string)$nm) === $alvo) return (string)$nm; } catch (Throwable $e) {} }
    if (preg_match('/nome|endere|bairro|cidade|ref|rua/', $c)) {
        $t = mb_convert_case(mb_strtolower($v, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        return (string)preg_replace_callback('/(?<=\s)(Da|De|Do|Das|Dos|E|Na|No|Em)(?=\s)/u', fn($x) => mb_strtolower($x[1]), $t);
    }
    return $v;
}

/* VÁRIOS DADOS NUMA FALA SÓ (03/10/2026). No cadastro o cliente diz "sou José da Silva, moro na Rua A 120, bairro
   Centro, Nazaré da Mata, quero o de 200 mega e vencimento dia 10" — a IA separa tudo e o robô pula as perguntas já
   respondidas (a ficha final continua para o cliente conferir/corrigir). $atuais: o que o robô já tem (não apaga nada);
   $listas: itens exatos das escolhas (cidade/plano/dia). Devolve [chave => valor|null] para TODOS os campos. */
function ws_chatbot_campos_cadastro(): array {
    return ['nome' => 'nome completo', 'cpf' => 'CPF ou CNPJ (só dígitos)', 'nascimento' => 'data de nascimento dd/mm/aaaa', 'whatsapp' => 'WhatsApp com DDD (só dígitos)',
            'endereco' => 'rua/avenida da instalação', 'numero' => 'número da casa', 'bairro' => 'bairro', 'referencia' => 'ponto de referência',
            'email' => 'e-mail', 'cidade' => 'cidade', 'plano' => 'plano/velocidade escolhido', 'vencimento' => 'dia de vencimento escolhido'];
}
function ws_chatbot_multi(string $fala, array $atuais, array $listas, string $chaveAtual, string $valorAtual): array {
    $campos = ws_chatbot_campos_cadastro(); $limpo = function ($v) { $v = trim((string)$v); return ($v === '' || strpos($v, '{{') !== false || preg_match('/^(audio|image|document|video)Message\|/', $v)) ? null : $v; };
    $out = []; foreach ($campos as $k => $d) $out[$k] = $limpo($atuais[$k] ?? '');
    if ($chaveAtual !== '' && isset($campos[$chaveAtual])) $out[$chaveAtual] = $limpo($valorAtual);
    $palavras = count(preg_split('/\s+/', trim($fala)));
    if ($palavras < 6 || ws_chatbot_openai_key() === '') return $out;   // resposta curta = só o campo perguntado (sem custo)
    $key = ws_chatbot_openai_key();
    $lst = ''; foreach ($listas as $k => $its) if ($its) $lst .= "\n- $k: escolha EXATAMENTE um destes: " . implode(' | ', $its);
    $sys = "Você extrai dados de cadastro de cliente de provedor de internet de uma mensagem (falada ou digitada). Responda só JSON com as chaves: "
         . implode(', ', array_keys($campos)) . ". Valor vazio \"\" quando a mensagem não disser. Nunca invente. Formatos: " . json_encode($campos, JSON_UNESCAPED_UNICODE)
         . ". Nome e endereço com iniciais maiúsculas. Números falados por extenso viram dígitos." . $lst;
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => 'gpt-4o-mini', 'temperature' => 0, 'max_tokens' => 400, 'response_format' => ['type' => 'json_object'],
            'messages' => [['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => mb_substr($fala, 0, 1500)]]])]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return $out;
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true);
    if (!is_array($j)) return $out;
    $rotulo = ['nome' => 'nome', 'nascimento' => 'data nascimento', 'whatsapp' => 'whatsapp', 'endereco' => 'endereço', 'bairro' => 'bairro', 'referencia' => 'referência', 'email' => 'e-mail', 'cidade' => 'cidade'];
    foreach ($campos as $k => $d) {
        if ($k === $chaveAtual && $out[$k] !== null) {   // o campo perguntado agora já veio tratado…
            $vj = trim((string)($j[$k] ?? ''));
            // …mas se o extrator achou o valor COMPLETO ("Márcio da Luz") e o tratado veio curto ("Márcio"), vale o completo (08/10/2026)
            if ($vj !== '' && isset($rotulo[$k]) && empty($listas[$k]) && mb_stripos($vj, (string)$out[$k]) !== false && mb_strlen($vj) > mb_strlen((string)$out[$k])) $out[$k] = ws_chatbot_acabamento($vj, $rotulo[$k]);
            continue;
        }
        $v = trim((string)($j[$k] ?? '')); if ($v === '') continue;
        if (!empty($listas[$k])) { $v = ws_chatbot_escolher_item($v, $listas[$k], $k, '', true); if ($v === '') continue; }
        elseif (isset($rotulo[$k])) $v = ws_chatbot_acabamento($v, $rotulo[$k]);
        if ($k === 'cpf') { $v = preg_replace('/\D/', '', $v); if (!in_array(strlen($v), [11, 14], true)) continue; }
        if ($k === 'numero') $v = preg_replace('/[^\dA-Za-z\- ]/', '', $v);
        if ($v !== '') $out[$k] = $v;
    }
    return $out;
}

/** Escolha numa LISTA de itens exatos (cidade, plano, dia): número, nome parecido ou IA → o item exato; '' = não achou. */
function ws_chatbot_escolher_item(string $fala, array $itens, string $campo = '', string $pergunta = '', bool $usarIa = true): string {
    $itens = array_values(array_filter(array_map('trim', $itens), fn($x) => $x !== '')); if (!$itens) return '';
    $n = trim(preg_replace('/\s+/', ' ', preg_replace(['/(\d)([a-z])/', '/([a-z])(\d)/'], '$1 $2', ws_chatbot_norm($fala))));   // "200mb" → "200 mb"
    $num = ['um'=>1,'uma'=>1,'primeiro'=>1,'primeira'=>1,'dois'=>2,'duas'=>2,'segundo'=>2,'segunda'=>2,'tres'=>3,'terceiro'=>3,'terceira'=>3,'quatro'=>4,'quarto'=>4,'cinco'=>5,'quinto'=>5,'seis'=>6,'sexto'=>6,'sete'=>7,'oito'=>8,'nove'=>9];
    if (preg_match('/^\D*(\d{1,2})\D*$/', $n, $m) && (int)$m[1] >= 1 && (int)$m[1] <= count($itens)) {
        // "5" pode ser o VALOR de um item ("Dia 05") e não a posição: item que tem esse número vence; senão é a posição
        $achou = []; foreach ($itens as $it) { preg_match_all('/\d+/', preg_replace('/^\W*\d*\W*/u', '', $it), $nn); foreach ($nn[0] as $x) if ((int)$x === (int)$m[1]) { $achou[] = $it; break; } }
        if (count($achou) === 1) return $achou[0];
        return $itens[(int)$m[1] - 1];
    }
    foreach (explode(' ', $n) as $w) if (isset($num[$w]) && count(explode(' ', $n)) <= 3 && $num[$w] <= count($itens)) return $itens[$num[$w] - 1];
    // DATA em qualquer formato ("30/08/2026", "30-8", "30.08.26") contra itens que são datas (boletos): compara dia e mês (e ano, se veio)
    $dt = function (string $x): ?array { return preg_match('#(\d{1,2})\s*[/.\-]\s*(\d{1,2})(?:\s*[/.\-]\s*(\d{2,4}))?#', $x, $m) ? [(int)$m[1], (int)$m[2], isset($m[3]) ? ((int)$m[3] < 100 ? 2000 + (int)$m[3] : (int)$m[3]) : 0] : null; };
    if (($df = $dt($fala)) !== null) { $ach = []; foreach ($itens as $it) if (($di = $dt($it)) && $di[0] === $df[0] && $di[1] === $df[1] && (!$df[2] || !$di[2] || $di[2] === $df[2])) $ach[] = $it; if (count($ach) === 1) return $ach[0]; }
    // nome do item contido na fala (sem emojis/números da lista): "é nazaré da mata" → "1️⃣- Nazaré da Mata-PE"
    $melhor = ''; $pts = 0;
    foreach ($itens as $it) {
        $nucleo = trim(preg_replace('/\b(pe|vel|mega|r|dia)\b/', ' ', ws_chatbot_norm(preg_replace('/^\W*\d*\W*/u', '', $it))));
        $pal = array_filter(explode(' ', $nucleo), fn($w) => mb_strlen($w) >= 3 || ctype_digit($w));
        if (!$pal) continue;
        $p = 0; foreach ($pal as $w) if (preg_match('/(^| )' . preg_quote($w, '/') . '( |$)/', $n)) $p++;
        if ($p > $pts) { $pts = $p; $melhor = $it; }
    }
    if ($melhor !== '') return $melhor;
    if (!$usarIa) return '';
    $v = ws_chatbot_ia($fala, $campo, $pergunta, implode(' | ', $itens), 'lista de itens exatos');
    if ($v !== '' && ctype_digit($v) && (int)$v >= 1 && (int)$v <= count($itens)) return $itens[(int)$v - 1];
    foreach ($itens as $it) if ($v !== '' && (ws_chatbot_norm($v) === ws_chatbot_norm($it) || (mb_strlen($v) >= 3 && strpos(ws_chatbot_norm($it), ws_chatbot_norm($v)) !== false))) return $it;
    return '';
}

/** TRANSCRIÇÕES PARA REVISÃO (15/10/2026, caso Samuel: o áudio levou ao assunto errado e não havia como ver o que ele disse). Guarda em cache/audio_transcricoes.json as ÚLTIMAS 200 falas entendidas (hora, final do número,
 *  origem, texto até 300 caracteres) — as novas empurram as velhas, sozinho. É só consulta técnica (não vai para a linha do tempo do cliente). Nunca derruba o robô. */
function ws_audio_guardar(string $jid, string $fala, string $via): void {
    try {
        $fala = trim(preg_replace('/\s+/', ' ', $fala)); if ($fala === '') return;
        $f = WS_CACHE . '/audio_transcricoes.json'; $fh = @fopen($f, 'c+'); if (!$fh) return;
        if (flock($fh, LOCK_EX)) {
            $l = json_decode((string)stream_get_contents($fh), true); if (!is_array($l)) $l = [];
            $l[] = ['h' => date('d/m H:i:s'), 'n' => substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -4), 'v' => $via, 't' => mb_substr($fala, 0, 300)];
            $l = array_slice($l, -200); ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($l, JSON_UNESCAPED_UNICODE)); flock($fh, LOCK_UN);
        }
        fclose($fh); @chmod($f, 0640);
    } catch (Throwable $e) {}
}
/** Transcreve pelo Whisper (OpenAI). '' = falhou. $dica: contexto (pergunta, lugares) que melhora nomes próprios. */
function ws_chatbot_transcrever(string $bin, string $mime, string &$erro = '', string $dica = ''): string {
    $key = ws_chatbot_openai_key();
    if ($key === '') { $erro = 'sem chave da OpenAI'; return ''; }
    if (strlen($bin) > 24 * 1024 * 1024) { $erro = 'áudio grande demais'; return ''; }
    $ext = stripos($mime, 'mpeg') !== false || stripos($mime, 'mp3') !== false ? 'mp3' : (stripos($mime, 'mp4') !== false || stripos($mime, 'm4a') !== false ? 'm4a' : (stripos($mime, 'wav') !== false ? 'wav' : 'ogg'));
    $tmp = tempnam(sys_get_temp_dir(), 'wsaud'); file_put_contents($tmp, $bin);
    /* MODELO (01/10/2026): gpt-4o-mini-transcribe = o mais barato (~US$ 0,003/min, metade do whisper-1) e melhor no português
       falado. Se a conta/OpenAI recusar o modelo, cai no whisper-1 na mesma hora — o cliente não percebe. */
    $r = ''; $c = 0; $j = [];
    foreach (['gpt-4o-mini-transcribe', 'whisper-1'] as $modelo) {
        $ch = curl_init('https://api.openai.com/v1/audio/transcriptions');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 40,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key],
            CURLOPT_POSTFIELDS => ['file' => new CURLFile($tmp, $mime ?: 'audio/ogg', "audio.$ext"), 'model' => $modelo, 'language' => 'pt', 'response_format' => 'json'] + ($dica !== '' ? ['prompt' => $dica] : [])]);
        $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $j = json_decode((string)$r, true);
        if ($c === 200 || $c === 401 || $c === 429) break;   // chave inválida / sem saldo: trocar de modelo não resolve
    }
    @unlink($tmp);
    if ($c !== 200) { $erro = 'OpenAI HTTP ' . $c . ' ' . mb_substr((string)($j['error']['message'] ?? ''), 0, 120); return ''; }
    return trim((string)($j['text'] ?? ''));
}

/* MUDAR DE ASSUNTO EM QUALQUER PONTO DO FLUXO (07/10/2026). O cliente está numa pergunta (CPF, lista de boletos, avaliação,
   "voltar ao menu?") e, em vez de responder, fala OUTRA coisa: "quero falar com atendente", "meu pix", "sem internet", "menu".
   Esta função olha o que ele disse e devolve a opção do MENU PRINCIPAL para onde o fluxo deve ir ("1".."9"), "0" = voltar ao
   menu, ou "" = sem desvio (a resposta serve à pergunta atual, ou não dá para ter certeza). O fluxo do Typebot grava isso na
   variável "desvio" e, se vier preenchida, pula para o "Desvio global" (que repete o que o Menu faria com aquela opção).
   Regras de segurança contra falso positivo:
   - resposta que a pergunta atual ACEITA (opção existente, item da lista, número) nunca desvia;
   - número puro digitado nunca desvia (1..9 do menu principal não podem valer em outra pergunta);
   - perguntas de texto livre/lista (nome, cidade, data…) só desviam por COMANDO CLARO ("menu", "voltar ao menu", "falar com
     atendente", "sair"), nunca por palavra solta dentro de um nome ou endereço;
   - menu e número (CPF): assunto por palavras-chave; empate ou dúvida → IA (gpt-4o-mini) que também pode dizer "nenhum".
   Retorna sempre string. Corpo esperado = o mesmo do /api/audio ({tipo, opcoes, itens, pergunta, campo, menu_principal?}). */
/* "JÁ SOU CLIENTE" NO MEIO DO CADASTRO (07/10/2026). Cliente entrou em "Ser Nosso Cliente", respondeu "já tenho cadastro"
   na pergunta do nome — o robô gravava "Já Tenho Cadastro" como NOME e abria o pré-cadastro assim. Agora:
   - ws_chatbot_ja_cliente(): a frase diz que a pessoa JÁ é cliente/cadastrada → o desvio leva ao MENU PRINCIPAL (0), onde ela
     escolhe o que precisa (boleto, suporte, PIX… — todos pedem o CPF e identificam o cadastro);
   - ws_chatbot_nao_e_nome(): resposta que não é nome de pessoa (frase, saudação, assunto) não vale como nome: conta como resposta
     não entendida (3 seguidas = atendente) e o pré-cadastro recusa gravar. */
function ws_chatbot_ja_cliente(string $t): bool {
    $n = ' ' . ws_chatbot_norm($t) . ' ';
    return (bool)preg_match('/ (ja|eu ja|mas ja|so que ja) (tenho|tinha|possuo|fiz|estou|to|sou|tem|e) (o |um |meu |seu |a |uma )?(cadastr|cliente|conta|plano|internet|contrato|assinante|instalad|registr)/', $n)
        || (bool)preg_match('/ (sou|somos|ja e|ja eh|eh|e) (cliente|assinante|cadastrad)/', $n)
        || (bool)preg_match('/ (tenho|possuo) (cadastro|contrato|conta) (com voces|ai|aqui)? /', $n)
        || (bool)preg_match('/ ja (tenho|tinha|tem) (internet|wifi|net|plano) (com voces|de voces|ai)/', $n);
}
/* "ESTOU SEM INTERNET" EM QUALQUER PERGUNTA (07/10/2026). Cliente sem conexão falou "estamos sem internet / no sítio", o menu entendeu
   "Ser Nosso Cliente" e o robô seguiu o CADASTRO gravando "Tô saindo do sítio e não tem internet" como WhatsApp, "Já desconectamos e
   conectamos" como número da casa e "Muitas coisas agora e nada se resolve" como e-mail. Agora a queixa de falta de internet leva ao
   SUPORTE de qualquer pergunta (menos dentro do próprio suporte) e é lembrada por 3 min para a resposta seguinte do menu. */
function ws_chatbot_sem_internet(string $t): bool {
    $n = ' ' . ws_chatbot_norm($t) . ' ';
    $net = '(internet|net|wifi|wi fi|sinal|conexao|rede)';
    return (bool)preg_match('/ (sem|ta sem|to sem|estou sem|estamos sem|fiquei sem|ficamos sem|esta sem|continua sem|ainda sem) (a |o |nenhum |nenhuma )?' . $net . ' /', $n)
        || (bool)preg_match('/ (nao|n|nem) (tem|ta|esta|tah|funciona|pega|conecta|volta|navega|carrega|abre|chega|aparece|vem|tem mais)( a| o| mais| nada)? ' . $net . ' /', $n)
        || (bool)preg_match('/ ' . $net . ' (nao|n) (funciona|pega|conecta|volta|navega|carrega|abre|chega|esta funcionando|ta funcionando|presta)/', $n)
        || (bool)preg_match('/ ' . $net . ' ((esta|ta|tah|ficou|anda|andou|fica|ficando|vive|continua|ainda) )?((muito|bem|super|mt) )?(caiu|cai|parou|sumiu|foi embora|ta caindo|esta caindo|fora|off|lenta|lento|ruim|travando|instavel|oscilando|falhando)/', $n)   // 10/10/2026: "minha internet está lenta" também
        || (bool)preg_match('/ (caiu|parou|sumiu|caindo|cai|ta caindo|esta caindo|oscilando|travando|falhando) (toda hora |muito |direto |a |o )*' . $net . ' /', $n)   // "está caindo a internet" (verbo antes)
        || (bool)preg_match('/ (luz|led) (vermelha|vermelho|piscando|los) /', $n) || (bool)preg_match('/ los (vermelho|aceso|piscando) /', $n)
        || (bool)preg_match('/ (desliguei|desligamos|reiniciei|reiniciamos|desconectei|desconectamos|tirei da tomada|tiramos da tomada) .*(liguei|ligamos|conectei|conectamos|tomada|nada|continua|nao volta|nao voltou)/', $n);
}
/** Número da opção de SUPORTE num menu "1=Suporte IA|2=…" ('' se não houver). */
function ws_chatbot_opcao_suporte(string $opcoes): string {
    foreach (explode('|', $opcoes) as $op) if (preg_match('/^\s*(\d{1,2})\s*=\s*(.+)$/u', $op, $m) && preg_match('/suporte|sem internet|problema|t[eé]cnic/iu', $m[2])) return $m[1];
    return '';
}
/** Número da opção "Falar com Atendente" num menu "1=…|7=Falar com Atendente" ('' se não houver). */
function ws_chatbot_opcao_atendente(string $opcoes): string {
    foreach (explode('|', $opcoes) as $op) if (preg_match('/^\s*(\d{1,2})\s*=\s*(.+)$/u', $op, $m) && preg_match('/atendente|humano/iu', $m[2])) return $m[1];
    return '';
}
/** A pergunta atual JÁ é do suporte? (aí a queixa é a resposta esperada, não desvio) */
function ws_chatbot_no_suporte(array $b): bool {
    return (bool)preg_match('/suporte|problema|defeito|descrev|chamado|t[eé]cnic|reinici|\\b(luz|led|onu|ont)\\b|equipamento|roteador|conex[aã]o|sinal|lentid|lenta/iu',
        (string)($b['campo'] ?? '') . ' ' . (string)($b['pergunta'] ?? '') . ' ' . (string)($b['opcoes'] ?? ''));
}
/** Últimas falas digitadas do cliente (webhook da Evolution, ≤ 5 min). */
function ws_chatbot_hist(string $jid): array {
    $jid = preg_replace('/\D/', '', $jid); if ($jid === '' || !function_exists('ws_midia_dir')) return [];
    $u = json_decode((string)@file_get_contents(ws_midia_dir() . '/ult_' . sha1($jid) . '.json'), true);
    return array_values(array_filter((array)($u['hist'] ?? []), fn($h) => is_array($h) && time() - (int)($h[0] ?? 0) <= 300));
}
function ws_chatbot_nao_e_nome(string $t): bool {
    $t = trim($t); if ($t === '') return true;
    if (preg_match('/\d/', $t)) return true;
    $n = ws_chatbot_norm($t); $pal = array_values(array_filter(explode(' ', $n)));
    if (count($pal) === 0 || mb_strlen(str_replace(' ', '', $n)) < 3) return true;
    if (ws_chatbot_ja_cliente($t)) return true;
    $proibidas = ['cadastro', 'cadastrado', 'cadastrada', 'cliente', 'tenho', 'tinha', 'ja', 'internet', 'quero', 'queria', 'preciso', 'boleto', 'plano',
                  'sim', 'nao', 'oi', 'ola', 'obrigado', 'obrigada', 'atendente', 'suporte', 'pix', 'velocidade', 'mega', 'instalar',
                  'instalacao', 'contratar', 'cancelar', 'pagar', 'fatura', 'conta', 'voces', 'voce', 'aqui', 'certo', 'ok', 'blz', 'beleza', 'menu', 'opcao'];
    if (array_intersect($pal, $proibidas)) return true;
    if (preg_match('/^(bom dia|boa tarde|boa noite|tudo bem|tudo bom)/', $n)) return true;
    return false;
}
function ws_chatbot_menu_principal_padrao(): string {
    return '1=Suporte IA|2=2º Via Boletos|3=Pagar com PIX|4=Cancelamento|5=Ser Nosso Cliente|6=Central do Assinante|7=Falar com Atendente|8=Enviar Comprovante PIX|9=Sair';
}
/** Melhor opção do MENU PRINCIPAL para o texto, só por palavras-chave, entre as opções $permitidas (ex.: ['2','3','6','8']). '' se não há uma única melhor. (14/10/2026) */
function ws_chatbot_menu_por_palavras(string $fonte, string $menuP, array $permitidas): string {
    $ch = ws_chatbot_chaves($fonte); if (!$ch) return ''; $melhor = ''; $pts = 0.0;
    foreach (explode('|', $menuP) as $op) {
        if (!preg_match('/^\s*(\d+)\s*=\s*(.+)$/u', $op, $m) || !in_array($m[1], $permitidas, true)) continue;
        $kOp = ws_chatbot_chaves($m[2]); $p = 0.0; foreach (array_intersect($ch, $kOp) as $k) $p += ['comprovante' => 2, 'atendente' => 2][$k] ?? 1;
        if ($p > 0) $p -= 0.01 * count(array_diff($kOp, $ch));
        if ($p > $pts) { $pts = $p; $melhor = $m[1]; } elseif ($p > 0 && abs($p - $pts) < 0.0001) $melhor = '';
    }
    return $melhor;
}
/** Pedido que só gente resolve (horário de funcionamento, vaga/emprego, senha/nome do wifi) — 13/10/2026; usado no desvio (qualquer pergunta) e na 1ª mensagem. $n = texto já normalizado (ws_chatbot_norm). */
function ws_chatbot_fora_alcance(string $n): bool {
    $nn = ' ' . $n . ' ';
    return (preg_match('/ (que horas|horario|horarios|ate que horas) /', $nn) && preg_match('/ (abre|abrem|fecha|fecham|funciona|funcionam|atendimento|atendem|atende|loja) /', $nn) && !preg_match('/ (boleto|fatura|vencimento|pix|plano|internet|pagar|pago) /', $nn))
        || preg_match('/ (vaga|vagas|emprego|curriculo|contratando|contratacao) /', $nn)
        || preg_match('/ (senha|nome) (do|da|de) (wifi|wi fi|rede|roteador|modem) /', $nn)
        || preg_match('/ (trocar|mudar|alterar|esqueci|saber|qual) .{0,15}(senha|nome) .{0,12}(wifi|wi fi|rede|roteador) /', $nn);
}
function ws_chatbot_desvio(string $fonte, string $final, array $b): string {
    $fonte = trim($fonte); if ($fonte === '' || preg_match('/^\w+Message\|/', $fonte)) return '';
    $tipo = in_array(($b['tipo'] ?? ''), ['numero', 'escolha', 'texto'], true) ? (string)$b['tipo'] : 'menu';
    $opcoes = (string)($b['opcoes'] ?? '');
    $menuP = trim((string)($b['menu_principal'] ?? '')); if ($menuP === '' || strpos($menuP, '{{') !== false) $menuP = ws_chatbot_menu_principal_padrao();
    $n = ws_chatbot_norm($fonte);
    /* ATENDIMENTO HUMANO EM CURSO (17/10/2026, caso Daniele Maria): o corpo que o Typebot manda no passo "poderia relatar sua solicitação?" não traz campo/pergunta, então a regra abaixo não pegava — o relato longo ("estamos sem internet…") virava desvio para o Suporte IA e o cliente recebia "Mensagem não reconhecida".
       Pela SESSÃO do número: se o cliente já está no atendimento humano (ctx 'atend') e escreve uma frase (6+ palavras), é o relato — nunca troca de assunto. Número solto ("1", "7") e frases curtas seguem a regra normal. */
    try {
        $jidS = (string)($b['remoteJid'] ?? ''); $f8S = substr(preg_replace('/\D/', '', explode('@', $jidS)[0]), -8);
        if (strlen($f8S) === 8 && strpos($jidS, '{{') === false && count(array_filter(explode(' ', $n))) >= 3) {   /* 3+ palavras (era 6, 17/10/2026, caso Rolanda: "Vai liberar a internet não" abriu outro Suporte IA com protocolo novo em cima do atendimento humano) */
            $sj = json_decode((string)@file_get_contents(WS_CACHE . '/robo_sessoes.json'), true);
            if (is_array($sj) && ($sj[$f8S]['ctx'] ?? '') === 'atend' && empty($sj[$f8S]['concl']) && time() - (int)($sj[$f8S]['em'] ?? 0) <= 1800) return '';
        }
    } catch (Throwable $e) {}
    /* RELATO DURANTE ESPERA DO ATENDENTE (16/10/2026, caso João Victor): na pergunta "poderia relatar sua solicitação?" um texto descritivo (8+ palavras) é o RELATO, não troca de assunto. */
    if (preg_match('/relat(ar|o)/iu', (string)($b['campo'] ?? '') . ' ' . (string)($b['pergunta'] ?? '')) && count(array_filter(explode(' ', $n))) >= 8) return '';
    if ($n === '' || !preg_match('/[a-z]/', $n)) return '';   // só dígitos/símbolos: é resposta, não assunto novo
    // já é o MENU PRINCIPAL: saudação/papo solto ("oi", "boa noite") só reapresenta o menu, sem dar bronca de "não entendi"; o resto cai no "não entendi" do próprio menu
    if ($tipo === 'menu' && stripos($opcoes, 'Suporte IA') !== false && stripos($opcoes, 'Falar com Atendente') !== false) {
        if (!preg_match('/^\d{1,2}$/', trim($final)) && count(array_filter(explode(' ', $n))) <= 4 && preg_match('/^(oi+e?|ola|opa|e ai|eai|bom dia|boa tarde|boa noite|tudo bem|tudo bom|alo|hello|hi)( .*)?$/', $n)) return '0';
        return '';
    }
    // 1) a pergunta atual aceita a resposta → sem desvio
    $final = trim($final);
    if ($tipo === 'menu') { if (preg_match('/^\d{1,2}$/', $final) && ($opcoes === '' || preg_match('/(^|\|)\s*' . preg_quote($final, '/') . '\s*=/', $opcoes))) {
        /* A IA escolheu uma opção do submenu atual para uma frase que fala de OUTRO assunto ("manda o boleto" dentro do menu do PIX virava "3 = Falar com Financeiro"), e isso bloqueava a troca.
           Se o que o cliente DIGITOU (não é número) tem palavra de um assunto do menu principal (2 boleto, 3 PIX, 6 central, 8 comprovante) e NENHUMA palavra em comum com a opção escolhida, o assunto pedido vence. (14/10/2026) */
        if (!preg_match('/^\d{1,2}$/', trim($fonte)) && $opcoes !== '' && preg_match('/(^|\|)\s*' . preg_quote($final, '/') . '\s*=\s*([^|]*)/', $opcoes, $moD)) {
            $kT = ws_chatbot_chaves($fonte); $kO = ws_chatbot_chaves($moD[2]);
            if ($kT && !array_intersect($kT, $kO)) { $rD = ws_chatbot_menu_por_palavras($fonte, $menuP, ['2', '3', '6', '8']); if ($rD !== '') return $rD; }
            /* "o valor não caiu / não entrou" = pagamento feito e não baixado → comprovante (mesmo sem palavra-chave de menu) */
            if (preg_match('/ (valor|dinheiro|pagamento|pix|deposito|transferencia|boleto) .{0,25}((?:nao|no|n) caiu|(?:nao|no|n) cai|nao entrou|nao chegou|nao compensou|nao baixou|nao foi baixad|nao aparece|nao consta)|(paguei|pago|transferi|depositei) .{0,40}(nao caiu|nao entrou|nao chegou|nao baixou|nao compensou|nao consta)/', ' ' . ws_chatbot_norm($fonte) . ' ') && !preg_match('/comprovante/iu', (string)$moD[2])) { $rD2 = ws_chatbot_menu_por_palavras('comprovante', $menuP, ['8']); if ($rD2 !== '') return $rD2; }
        }
        return ''; } }
    elseif ($tipo === 'escolha') { $itens = array_map('trim', explode('|', (string)($b['itens'] ?? ''))); if (in_array($final, $itens, true)) return ''; }
    elseif ($tipo === 'numero') { if ($final !== '' && !preg_match('/[a-zA-Z]/', $final)) return ''; }
    /* "O VALOR NÃO CAIU" (14/10/2026): falando de dinheiro/pagamento, "não caiu / não entrou / não chegou / não compensou" é PAGAMENTO que o cliente fez e não foi baixado (→ comprovante, 8), NÃO internet que caiu. */
    if (preg_match('/ (valor|dinheiro|pagamento|pix|deposito|transferencia|boleto) .{0,25}((?:nao|no|n) caiu|(?:nao|no|n) cai|nao entrou|nao chegou|nao compensou|nao baixou|nao foi baixad|nao aparece|nao consta)|(paguei|pago|transferi|depositei) .{0,40}(nao caiu|nao entrou|nao chegou|nao baixou|nao compensou|nao consta)/', ' ' . $n . ' ')) { $m8 = ''; foreach (explode('|', $menuP) as $op8) if (preg_match('/^\s*(\d{1,2})\s*=\s*(.+)$/u', $op8, $mm8) && preg_match('/comprovante/iu', $mm8[2])) $m8 = $mm8[1]; if ($m8 !== '') return $m8; }
    // 1b) "já tenho cadastro / já sou cliente" em qualquer pergunta (cadastro de cliente novo) → menu principal
    if (ws_chatbot_ja_cliente($fonte)) return '0';
    // 1c) "estou sem internet" no meio de outro assunto (cadastro, boleto…) → suporte
    if (ws_chatbot_sem_internet($fonte) && !ws_chatbot_no_suporte($b)) { $sup = ws_chatbot_opcao_suporte($menuP); if ($sup !== '') return $sup; }
    /* PEDIDO FORA DO ALCANCE DO ROBÔ (13/10/2026, Chatwoot): "que horas abre?", "tem vaga?", "qual a senha do wifi?" digitados em campo de nome/CPF/escolha eram lidos como
       o dado pedido (ou davam "não entendi" em loop). São assuntos que só gente resolve → vai para o atendente (7), que já diz se está dentro/fora do horário e abre o chamado. */
    $nn = ' ' . $n . ' ';
    $foraAlcance = ws_chatbot_fora_alcance($n);
    $foraAlcanceOLD = (preg_match('/ (que horas|horario|horarios|ate que horas) /', $nn) && preg_match('/ (abre|abrem|fecha|fecham|funciona|funcionam|atendimento|atendem|atende|loja) /', $nn) && !preg_match('/ (boleto|fatura|vencimento|pix|plano|internet|pagar|pago) /', $nn))
        || preg_match('/ (vaga|vagas|emprego|curriculo|contratando|contratacao) /', $nn)
        || preg_match('/ (senha|nome) (do|da|de) (wifi|wi fi|rede|roteador|modem) /', $nn)
        || preg_match('/ (trocar|mudar|alterar|esqueci|saber|qual) .{0,15}(senha|nome) .{0,12}(wifi|wi fi|rede|roteador) /', $nn);
    if ($foraAlcance && ws_chatbot_opcao_atendente($menuP) !== '') return ws_chatbot_opcao_atendente($menuP);
    // 2) comandos claros — valem em qualquer pergunta (frase curta e inteira)
    $curta = count(array_filter(explode(' ', $n))) <= 6;
    if ($curta) {
        if (preg_match('/^(quero |queria |vou |posso )?(ir |voltar |volto |retornar )?(para |pro |ao |no |pra )?(o )?(menu|menu principal|inicio|comeco)( principal)?( por favor| pf)?$/', $n) || preg_match('/^(voltar|volta|comecar de novo|recomecar|voltar ao menu|voltar pro menu)( por favor)?$/', $n)) return '0';
        if (preg_match('/^(quero |queria |preciso |gostaria de |posso |pode )?(falar|conversar)( com)?( um| uma| o| a)? ?(atendente|humano|pessoa|alguem|atendimento)( humano)?( por favor| pf)?$/', $n) || preg_match('/^(atendente|humano|atendimento humano|quero atendente)$/', $n)) return '7';
        if (preg_match('/^(sair|encerrar|finalizar|tchau|obrigado|obrigada|so isso|era so isso|pode encerrar|encerra)( por favor)?$/', $n)) return '9';
    }
    /* RELATO LIVRE (10/10/2026): "Paguei a internet e está caindo", "como posso resolver?" escritos DENTRO do atendimento/relato não mudavam de assunto
       (só dado de cadastro era protegido). Nos campos de relato/solicitação a IA atendente decide: se o assunto é outro do menu (ex.: problema técnico =
       suporte), muda sozinho. Nome, data, endereço e afins continuam sem IA aqui. */
    if ($tipo === 'texto' && preg_match('/relato|solicit|motivo|descri|problema|assunto/i', (string)($b['campo'] ?? '')) && count(array_filter(explode(' ', $n))) >= 3) {
        $oR = ws_chatbot_ia_menu($fonte, $menuP);
        if (preg_match('/^\d$/', $oR) && $oR !== '7') return $oR;   // 7 = já está falando com atendente
        return '';
    }
    /* CAMPO "NOME" (14/10/2026): "manda o boleto" / "quero pagar com pix" / "o valor não caiu" digitado no lugar do nome NÃO é nome (ws_chatbot_nao_e_nome) — o assunto pedido vence: 2 boleto, 3 PIX, 6 central, 8 comprovante, 7 atendente. */
    if ($tipo === 'texto' && preg_match('/nome/i', (string)($b['campo'] ?? '')) && !preg_match('/bairro|refer|rua|endere|cidade/i', (string)($b['campo'] ?? '')) && ws_chatbot_nao_e_nome($fonte) && !ws_chatbot_ja_cliente($fonte)) {
        $ch2 = ws_chatbot_chaves($fonte); $pt2 = 0; $m2 = '';
        foreach (explode('|', $menuP) as $op2) { if (!preg_match('/^\s*(\d+)\s*=\s*(.+)$/u', $op2, $mm2) || !in_array($mm2[1], ['2', '3', '6', '7', '8'], true)) continue; $k2all = ws_chatbot_chaves($mm2[2]); $p2 = 0; foreach (array_intersect($ch2, $k2all) as $k2) $p2 += ['comprovante' => 2, 'atendente' => 2][$k2] ?? 1; if ($p2 > 0) $p2 -= 0.01 * count(array_diff($k2all, $ch2)); if ($p2 > $pt2) { $pt2 = $p2; $m2 = $mm2[1]; } elseif (abs($p2 - $pt2) < 0.0001 && $p2 > 0) $m2 = ''; }
        if ($m2 !== '') return $m2;
    }
    if ($tipo === 'escolha' || $tipo === 'texto') return '';   // sem comando claro: é o dado que a pergunta pediu
    // 3) assunto por palavras-chave contra o menu principal
    $ch = ws_chatbot_chaves($fonte); $pesos = ['cliente' => 2, 'cancelar' => 3, 'comprovante' => 2, 'atendente' => 2, 'confianca' => 2];
    $melhor = ''; $pts = 0; $empate = false;
    foreach (explode('|', $menuP) as $op) {
        if (!preg_match('/^\s*(\d+)\s*=\s*(.+)$/u', $op, $m)) continue;
        $kOp = ws_chatbot_chaves($m[2]); $p = 0; foreach (array_intersect($ch, $kOp) as $k) $p += $pesos[$k] ?? 1;
        if ($p > 0) $p -= 0.01 * count(array_diff($kOp, $ch));   // "meu pix" casa Pagar com PIX (1 chave) melhor que Enviar Comprovante PIX (2 chaves)
        if ($p > $pts) { $pts = $p; $melhor = $m[1]; $empate = false; } elseif (abs($p - $pts) < 0.0001 && $p > 0) $empate = true;
    }
    if ($melhor !== '' && !$empate) return $melhor;
    // 4) dúvida ou empate → IA decide (ou diz que não é assunto novo)
    if (count(array_filter(explode(' ', $n))) < 2) return '';
    return ws_chatbot_ia_assunto($fonte, (string)($b['pergunta'] ?? ''), $menuP);
}

/** IA (gpt-4o-mini): a frase do cliente é um ASSUNTO NOVO do menu principal? Devolve "1".."9", "0" (voltar ao menu) ou "". */
function ws_chatbot_ia_assunto(string $fala, string $pergunta, string $menuP): string {
    $key = ws_chatbot_openai_key(); if ($key === '' || trim($fala) === '') return '';
    $sis = "Você roteia mensagens de clientes de um provedor de internet no WhatsApp. O cliente está no meio de uma pergunta do robô e escreveu algo. "
         . "Decida se ele quer mudar de ASSUNTO para uma opção do menu principal. Responda só JSON {\"opcao\":\"N\"}. "
         . "N = número da opção do menu principal que ele pediu; \"0\" = quer voltar ao menu; \"\" (vazio) se a mensagem for só uma resposta à pergunta atual, "
         . "um dado (nome, cidade, data, sim/não), ou se você não tiver CERTEZA. Em dúvida, devolva vazio.";
    $user = "Menu principal: $menuP\nPergunta atual do robô: " . mb_substr($pergunta, 0, 400) . "\nMensagem do cliente: " . mb_substr($fala, 0, 400);
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => 'gpt-4o-mini', 'temperature' => 0, 'max_tokens' => 20, 'response_format' => ['type' => 'json_object'],
            'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => $user]]])]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return '';
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true);
    $o = trim((string)($j['opcao'] ?? ''));
    return preg_match('/^\d$/', $o) ? $o : '';
}

/* LOG DO ROBÔ = SÍNTESE (07/10/2026). Antes cada áudio/resposta gerava uma linha no histórico ("áudio de 5581…: 'quero a segunda via' →
   2"), e o histórico enchia. Agora o robô só CONTA (cache/robo_resumo.json) e, quando vira o dia, grava UMA linha com o resumo do dia
   anterior: áudios entendidos, mudanças de assunto e falhas (com o motivo mais comum). Falha de áudio não vira linha avulsa. Na 1ª
   vez também apaga as linhas antigas de áudio, que eram só ruído. Tipos: audio | desvio | falha (com $motivo). */
/* =====================================================================================================================================
 * CONCLUSÃO POR INATIVIDADE (10/10/2026) — "se após X minutos não houver interatividade, faz o que era solicitado e finaliza".
 * O robô registra, por número de WhatsApp (cache/robo_sessoes.json), a hora do último toque e o ASSUNTO da última escolha de menu (PIX automático, PIX manual,
 * 2ª via, atendente). O cron (radius_sync.php, de 2 em 2 min) olha as conversas paradas há ≥ ROBO_SESSAO_MIN minutos que não terminaram (sem comprovante, sem
 * atendimento, sem avaliação, sem boleto/QR entregue) e conclui o pedido sozinho — manda o PIX (QR + copia e cola, e o PDF na 2ª via) ou abre o atendimento — e encerra.
 * Só age com cliente identificado pelo WhatsApp e uma vez por conversa; qualquer nova mensagem do cliente reinicia o relógio.
 * ===================================================================================================================================== */
/* 14/10/2026: o aviso de "falta de interação" só vale depois de MAIS de 15 min parado (era 6): antes disso o cliente que volta encontra a conversa esperando por ele (sessão do Typebot/Evolution também precisa durar mais — ver expire na Evolution). */
const ROBO_SESSAO_MIN = 16;
/** TRAVA POR CLIENTE (13/10/2026): "olha se já existe chamado → se não, cria" não é atômico — duas chamadas juntas (webhook repetido, fluxo disparando 2x) criavam dois chamados e dois avisos.
 *  Quem abre/anexa chamado de um WhatsApp pega esta trava (MySQL GET_LOCK, solta sozinha ao fechar a conexão; reentrante na mesma conexão). Falhou em travar = segue (fail-open). */
function ws_trava_tel(PDO $db, string $jidOuTel, int $seg = 8): string {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jidOuTel)[0]), -8); if (strlen($f8) < 8) return '';
    $nome = 'ws_tel_' . $f8;
    try { $q = $db->prepare('SELECT GET_LOCK(?, ?)'); $q->execute([$nome, $seg]); return $nome; } catch (Throwable $e) { return ''; }
}
function ws_destrava_tel(PDO $db, string $nome): void {
    if ($nome === '') return;
    try { $q = $db->prepare('SELECT RELEASE_LOCK(?)'); $q->execute([$nome]); } catch (Throwable $e) {}
}
/** TODOS os cadastros do MESMO cliente (13/10/2026): titular + adicionais + qualquer cadastro com o mesmo CPF/CNPJ. O cliente fala de números diferentes (dele, da esposa, do filho):
 *  chamado/solicitação/comprovante aberto em um número vale para todos. */
function ws_cliente_grupo_ids(PDO $db, int $cid): array {
    $ids = [$cid];
    try {
        $q = $db->prepare("SELECT id, titular_id, cpf_cnpj FROM ws_cliente WHERE id=?"); $q->execute([$cid]); $r = $q->fetch(PDO::FETCH_ASSOC); if (!$r) return $ids;
        $raiz = (int)($r['titular_id'] ?: $r['id']); $cpf = preg_replace('/\D/', '', (string)$r['cpf_cnpj']); $comCpf = in_array(strlen($cpf), [11, 14], true);
        $q = $db->prepare("SELECT id FROM ws_cliente WHERE id=? OR titular_id=?" . ($comCpf ? " OR REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=?" : '') . " LIMIT 30");
        $q->execute($comCpf ? [$raiz, $raiz, $cpf] : [$raiz, $raiz]);
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $i) $ids[] = (int)$i;
    } catch (Throwable $e) {}
    return array_values(array_unique($ids));
}
/* 14/10/2026: comprovante 'novo' NÃO conta como "em conferência" se o cliente já teve fatura baixada (paga) depois dele — a API/gateway baixou sozinho e o robô dizia "em conferência" depois da baixa. */
/** O cliente já tem algo em andamento? Chamado aberto, solicitação pendente ou comprovante em conferência (em QUALQUER número dele). Devolve ['tipo','id','desde','info'] ou null. */
function ws_pendencia_aberta(PDO $db, int $cid): ?array {
    $in = implode(',', array_map('intval', ws_cliente_grupo_ids($db, $cid)));
    try { $q = $db->query("SELECT id, titulo, criado_em FROM ws_chamado WHERE cliente_id IN ($in) AND status IN ('aberto','em_andamento','agendado') ORDER BY id DESC LIMIT 1"); $r = $q ? $q->fetch(PDO::FETCH_ASSOC) : null;
          if ($r) return ['tipo' => 'chamado', 'id' => (int)$r['id'], 'desde' => date('d/m H:i', strtotime((string)$r['criado_em'])), 'criado' => (string)$r['criado_em'], 'info' => (string)$r['titulo']]; } catch (Throwable $e) {}
    try { $q = $db->query("SELECT id, tipo, criado_em FROM ws_solicitacao WHERE cliente_id IN ($in) AND status='pendente' ORDER BY id DESC LIMIT 1"); $r = $q ? $q->fetch(PDO::FETCH_ASSOC) : null;
          if ($r) return ['tipo' => 'solicitacao', 'id' => (int)$r['id'], 'desde' => date('d/m H:i', strtotime((string)$r['criado_em'])), 'info' => (string)$r['tipo']]; } catch (Throwable $e) {}
    try { $q = $db->query("SELECT id, criado_em FROM ws_comprovante WHERE cliente_id IN ($in) AND status='novo' AND criado_em >= NOW() - INTERVAL 3 DAY AND NOT EXISTS (SELECT 1 FROM ws_fatura fx WHERE fx.cliente_id IN ($in) AND fx.status='pago' AND fx.data_pagamento >= DATE(ws_comprovante.criado_em)) ORDER BY id DESC LIMIT 1"); $r = $q ? $q->fetch(PDO::FETCH_ASSOC) : null;
          if ($r) return ['tipo' => 'comprovante', 'id' => (int)$r['id'], 'desde' => date('d/m H:i', strtotime((string)$r['criado_em'])), 'info' => '']; } catch (Throwable $e) {}
    return null;
}
/** Texto ao cliente quando já existe algo aberto: não abre outro, só aguarda o retorno do provedor. */
function ws_pendencia_msg(array $p, string $nome = ''): string {
    $n = $nome !== '' ? $nome : 'Tudo bem';
    if ($p['tipo'] === 'chamado') return "ℹ️ $n, você já tem o chamado *#" . (int)$p['id'] . "* aberto (desde " . $p['desde'] . ").\nNossa equipe e o provedor já foram avisados\n— não precisa abrir outro: é só aguardar o retorno.\nAgradecemos o seu contato! 🙏";
    if ($p['tipo'] === 'solicitacao') return "ℹ️ $n, você já tem uma solicitação (*nº " . (int)$p['id'] . "*, de " . $p['desde'] . ") aguardando o posicionamento do provedor.\nNão precisa pedir de novo: é só aguardar o retorno.\nAgradecemos o seu contato! 🙏";
    return "ℹ️ $n, o comprovante que você enviou em " . $p['desde'] . " está *em conferência* pelo financeiro.\nÉ só aguardar o retorno do provedor\n✅ assim que for conferido, a baixa é feita.\n\nAgradecemos! 🙏";
}
function ws_sessao_mexer(callable $fn): void {
    $f = WS_CACHE . '/robo_sessoes.json'; $h = @fopen($f, 'c+'); if (!$h) return;
    if (flock($h, LOCK_EX)) {
        $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = [];
        foreach ($j as $k => $v) if (time() - (int)($v['em'] ?? 0) > 7200) unset($j[$k]);
        $j = $fn($j); ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j, JSON_UNESCAPED_UNICODE)); fflush($h); flock($h, LOCK_UN);
    }
    fclose($h); @chmod($f, 0640);
}
/** Assunto da escolha de menu: 'pix_auto' | 'pix_manual' | 'via' | 'atend' | '' (sem ação automática: suporte, comprovante…). */
function ws_sessao_ctx_de_menu(string $opcoes, string $resposta): string {
    $resposta = trim($resposta); if (!preg_match('/^\d{1,2}$/', $resposta)) return '';
    $rot = ''; foreach (explode('|', $opcoes) as $op) if (preg_match('/^\s*' . preg_quote($resposta, '/') . '\s*=\s*(.+)$/u', $op, $m)) { $rot = ws_chatbot_norm($m[1]); break; }
    if ($rot === '' || preg_match('/comprovante|suporte|sair|central do assinante/', $rot)) return '';
    if (preg_match('/ser nosso cliente|ser cliente|contratar/', $rot)) return 'cadastro';
    if (preg_match('/atendente|cancelamento|financeiro|atendimento/', $rot)) return 'atend';
    if (preg_match('/chave pix|manual/', $rot)) return 'pix_manual';
    if (preg_match('/via|boleto/', $rot)) return 'via';
    if (preg_match('/pagar com pix|qr code|autom|pagamento on/', $rot)) return 'pix_auto';
    return '';
}
/* =====================================================================================================================================
 * UMA CONVERSA POR VEZ ENTRE AS INSTÂNCIAS (14/10/2026) — o mesmo cliente não abre atendimento nas duas instâncias ao mesmo tempo (Wellnet-01 comum + Wellnet-02 API).
 * cache/sessao_inst.json: por número (últimos 8 dígitos) {inst, em (último toque), fim (hora em que o fluxo encerrou)}. Conversa "viva" = sem fim e com toque nos últimos 30 min (= expire do Typebot).
 * A instância que NÃO é a dona da conversa viva fica CALADA (o atendente vê tudo no Chatwoot); terminou (fim) ou passou 30 min → qualquer instância pode abrir. Sem nome de instância = não bloqueia.
 * ===================================================================================================================================== */
const WS_CONVERSA_VIVA_SEG = 1800;
function ws_conversa_inst_mexer(callable $fn): void {
    $f = WS_CACHE . '/sessao_inst.json'; $h = @fopen($f, 'c+'); if (!$h) return;
    if (flock($h, LOCK_EX)) {
        $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = [];
        foreach ($j as $k => $v) if (time() - (int)($v['em'] ?? 0) > 7200) unset($j[$k]);
        $j = $fn($j); ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j)); fflush($h); flock($h, LOCK_UN);
    }
    fclose($h); @chmod($f, 0640);
}
/** Tenta abrir/continuar a conversa do número nesta instância. Devolve a instância DONA quando OUTRA já está com a conversa viva ('' = pode seguir e a conversa passa a ser desta instância). */
function ws_conversa_inst_abrir(string $jid, string $inst): string {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); $inst = trim($inst);
    if (strlen($f8) < 8 || $inst === '' || strpos($inst, '{{') !== false || preg_match('/^558100000/', preg_replace('/\D/', '', $jid))) return '';
    $dona = '';
    try { ws_conversa_inst_mexer(function (array $j) use ($f8, $inst, &$dona) {
        $e = $j[$f8] ?? null;
        if ($e && empty($e['fim']) && ($e['inst'] ?? '') !== $inst && time() - (int)($e['em'] ?? 0) <= WS_CONVERSA_VIVA_SEG) { $dona = (string)$e['inst']; return $j; }
        $j[$f8] = ['inst' => $inst, 'em' => time(), 'fim' => 0]; return $j; }); } catch (Throwable $e) {}
    return $dona;
}
/** A instância dona da conversa deu sinal de vida (cada pergunta do robô): renova o prazo. Não cria conversa nem tira de outra instância. */
function ws_conversa_inst_toque(string $jid, string $inst): void {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); $inst = trim($inst); if (strlen($f8) < 8 || $inst === '' || strpos($inst, '{{') !== false) return;
    try { ws_conversa_inst_mexer(function (array $j) use ($f8, $inst) { if (isset($j[$f8]) && ($j[$f8]['inst'] ?? '') === $inst && empty($j[$f8]['fim'])) $j[$f8]['em'] = time(); return $j; }); } catch (Throwable $e) {}
}
/** O fluxo encerrou a conversa nesta instância: a outra instância já pode atender este cliente. */
function ws_conversa_inst_fim(string $jid, string $inst): void {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); $inst = trim($inst); if (strlen($f8) < 8) return;
    try { ws_conversa_inst_mexer(function (array $j) use ($f8, $inst) { if (!isset($j[$f8])) return $j; if (time() - (int)($j[$f8]['dup'] ?? 0) <= 20) { unset($j[$f8]['dup']); return $j; }   // fim vindo do início DUPLICADO calado (mesma instância): a 1ª conversa segue viva
        if ($inst === '' || strpos($inst, '{{') !== false || ($j[$f8]['inst'] ?? '') === $inst) $j[$f8]['fim'] = time(); return $j; }); } catch (Throwable $e) {}
}
/** Marca que acabou de ser calado um início duplicado deste número (o "fecha a sessão" dele não encerra a conversa que está viva). */
function ws_conversa_inst_dup(string $jid): void {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); if (strlen($f8) < 8) return;
    try { ws_conversa_inst_mexer(function (array $j) use ($f8) { if (isset($j[$f8])) $j[$f8]['dup'] = time(); return $j; }); } catch (Throwable $e) {}
}
/** Registra que o cliente falou agora (e, se veio uma escolha de menu, o assunto dela). */
function ws_sessao_toque(string $jid, string $opcoes = '', string $resposta = '', string $ctx = '', array $dados = []): void {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); $f8 = substr($d, -8); if (strlen($f8) < 8 || preg_match('/^558100000/', $d)) return;
    if ($ctx === '') $ctx = ws_sessao_ctx_de_menu($opcoes, $resposta);
    try { ws_sessao_mexer(function (array $j) use ($f8, $jid, $ctx, $dados) { $e = $j[$f8] ?? ['ctx' => '']; if (!empty($e['concl']) || !empty($e['feito'])) $e = ['ctx' => '']; /* ciclo anterior já terminou (atendimento aberto/concluído pelo cron): assunto e dados velhos NÃO entram no ciclo novo — era o que reabria o atendimento e mandava "estamos encaminhando" de novo */ $e['jid'] = $jid; $e['em'] = time(); $e['concl'] = 0; $e['feito'] = 0; if ($ctx !== '') $e['ctx'] = $ctx; if ($dados) $e['dados'] = array_merge((array)($e['dados'] ?? []), $dados); $j[$f8] = $e; return $j; }); } catch (Throwable $e) {}
}
/** A conversa terminou por conta própria (comprovante recebido, atendimento aberto, boleto/QR entregue, avaliação…): não precisa concluir. */
function ws_sessao_concluir(string $jidOuTel): void {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jidOuTel)[0]), -8); if (strlen($f8) < 8) return;
    try { ws_sessao_mexer(function (array $j) use ($f8) { if (isset($j[$f8])) $j[$f8]['concl'] = 1; return $j; }); } catch (Throwable $e) {}
}
/** O cliente cujo CPF/CNPJ é este (boleto/QR entregue pelo fluxo): fecha a conversa dele. */
function ws_sessao_concluir_cpf(PDO $db, string $cpf): void {
    $d = preg_replace('/\D/', '', $cpf); if (strlen($d) !== 11 && strlen($d) !== 14) return;
    try { $q = $db->prepare("SELECT celular FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cpf_cnpj,''),'.',''),'-',''),'/',''),' ','')=? LIMIT 3"); $q->execute([$d]); foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $cel) ws_sessao_concluir((string)$cel); } catch (Throwable $e) {}
}
/** Manda o PIX da fatura mais atrasada do cliente (WhatsApp $jid): automático (QR da API) ou manual (QR da chave da empresa); $comPdf = também o boleto. */
function ws_robo_concluir_pix(PDO $db, string $jid, bool $comPdf = false, bool $manual = false, string $motivo = ''): ?array {
    $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8); if (strlen($f8) < 8) return null;
    require_once __DIR__ . '/whatsapp.php';
    $qf = $db->prepare("SELECT f.*, c.cpf_cnpj FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(c.celular,''),' ',''),'-',''),'(',''),')',''),8)=? AND c.status NOT IN ('cancelado','inativo','desativado') AND f.status IN ('aberto','vencido') ORDER BY (f.vencimento > CURDATE()), f.vencimento LIMIT 1");
    $qf->execute([$f8]); $ff = $qf->fetch(PDO::FETCH_ASSOC); if (!$ff) return null;
    $v = function_exists('ws_fatura_valor_cobrado') ? ws_fatura_valor_cobrado($ff) : (float)$ff['valor'];
    $png = null; $emv = '';
    if ($manual) { $rm = ws_chatbot_pix_manual($db, (int)(ws_chatbot_cfg()['pix_manual_banco'] ?? 0), (float)$v, '***'); $png = $rm['png'] ?? null; $emv = (string)($rm['emv'] ?? ''); }
    else { $px = ws_fatura_pix_png($db, (int)$ff['id']); $png = $px['png'] ?? null; $emv = (string)($px['emv'] ?? ''); }
    if (!$png) return null;
    /* UM MODELO SÓ COM A JANELA FECHADA (17/10/2026, caso Laudicea): o texto, o PDF e o QR saíam como 3 envios separados pela API; com a janela de 24 h fechada cada um virava um MODELO da Meta (3 modelos em 1 segundo, cada um cobrado). Agora, se o texto saiu como modelo, só ele sai; o PDF e o QR ficam GUARDADOS e vão quando o cliente tocar em "Sim" (mesmo critério do /api/boleto-enviar). */
    $r1 = ws_wa_enviar($jid, ($motivo !== '' ? $motivo . "\n\n" : '') . 'Aqui está o PIX da sua fatura de *R$ ' . number_format($v, 2, ',', '.') . '* (vencimento ' . date('d/m', strtotime((string)$ff['vencimento'])) . "). 😉\n\nDepois de pagar, é só mandar o comprovante por aqui.", false, ['evento' => 'pix_pedido']);
    $pdfAx = null; if ($comPdf && is_file(__DIR__ . '/boleto_pdf.php')) { require_once __DIR__ . '/boleto_pdf.php'; try { $pdfAx = ws_pdf_faturas($db, [(int)$ff['id']], 'boleto') ?: null; } catch (Throwable $e) { $pdfAx = null; } }
    if (!empty($r1['template'])) {
        $anx = []; if ($pdfAx) $anx[] = ['tipo' => 'document', 'nome' => $pdfAx['nome'], 'b64' => base64_encode($pdfAx['pdf']), 'legenda' => ''];
        $anx[] = ['tipo' => 'image', 'nome' => 'pix.png', 'b64' => base64_encode($png), 'legenda' => ($emv !== '' ? "PIX copia e cola:\n" . $emv : 'PIX')];
        try { ws_wa_pendente_guardar($jid, $anx, [(int)$ff['id']]); } catch (Throwable $e) {}
    } else {
        if ($pdfAx) ws_wa_midia($jid, 'document', $pdfAx['nome'], base64_encode($pdfAx['pdf']), '', ['evento' => 'pix_pedido']);
        ws_wa_midia($jid, 'image', 'pix.png', base64_encode($png), ($emv !== '' ? "PIX copia e cola:\n" . $emv : 'PIX'), ['evento' => 'pix_pedido']);
    }
    try { $mf = WS_CACHE . '/robo_pix_auto.json'; $mj = json_decode((string)@file_get_contents($mf), true); if (!is_array($mj)) $mj = []; foreach ($mj as $k => $t0) if (time() - (int)$t0 > 7200) unset($mj[$k]); $mj[$f8] = time(); @file_put_contents($mf, json_encode($mj), LOCK_EX); } catch (Throwable $e) {}   // marca (14/10): o robô acabou de mandar o PIX — "1"/"2" logo depois não reabre o menu (ver /api/primeira)
    return ['fatura' => (int)$ff['id'], 'valor' => $v, 'venc' => (string)$ff['vencimento']];
}
/** A conversa inteira deste WhatsApp (últimos 60 min, cliente × atendimento/robô), lida da Evolution, como linhas "Cliente: …" / "Atendimento: …". */
function ws_sessao_transcricao(string $jid, int $minutos = 60): array {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); if (strlen($d) < 10) return [];
    require_once __DIR__ . '/whatsapp.php'; $c = ws_wa_config(); $url = rtrim((string)($c['url'] ?? ''), '/'); if ($url === '') return [];
    $jids = [$d]; if (preg_match('/^55(\d{2})9(\d{8})$/', $d, $m)) $jids[] = '55' . $m[1] . $m[2]; elseif (preg_match('/^55(\d{2})(\d{8})$/', $d, $m)) $jids[] = '55' . $m[1] . '9' . $m[2];
    $insts = array_values(array_filter(array_unique(array_merge([(string)($c['instance'] ?? '')], array_map('trim', explode(',', (string)($c['instancias_extra'] ?? '')))))));
    $todas = [];
    foreach ($insts as $in) foreach ($jids as $j) {
        $ch = curl_init($url . '/chat/findMessages/' . rawurlencode($in));
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_POST => 1, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($c, $in), 'Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode(['where' => ['key' => ['remoteJid' => $j . '@s.whatsapp.net']], 'limit' => 60])]);
        $recs = json_decode((string)curl_exec($ch), true)['messages']['records'] ?? []; curl_close($ch);
        foreach ($recs as $m) { $t = (int)($m['messageTimestamp'] ?? 0); if ($t < time() - $minutos * 60) continue; $msg = (array)($m['message'] ?? []);
            $txt = (string)($msg['conversation'] ?? ($msg['extendedTextMessage']['text'] ?? ($msg['imageMessage']['caption'] ?? ($msg['documentMessage']['caption'] ?? ''))));
            if ($txt === '') { $tp = (string)($m['messageType'] ?? ''); $txt = $tp === 'imageMessage' ? '[enviou uma imagem]' : ($tp === 'documentMessage' ? '[enviou um documento/PDF]' : ($tp === 'audioMessage' ? '[enviou um áudio]' : '')); }
            if ($txt === '') continue; $todas[$t . '-' . ($m['key']['id'] ?? mt_rand())] = [$t, !empty($m['key']['fromMe']) ? 'Atendimento' : 'Cliente', mb_substr(trim(preg_replace('/\s+/', ' ', $txt)), 0, 220)]; }
    }
    ksort($todas); return array_slice(array_values($todas), -40);
}
/** A IA lê a conversa TODA e diz o que o cliente queria, se já foi atendido e o que falta fazer. Devolve ['acao','resumo','concluida','conf'] ou null (sem IA / sem conversa). */
function ws_sessao_analisar(string $jid, int $minutos = 60): ?array {
    $key = ws_chatbot_openai_key(); if ($key === '') return null;
    $lin = ws_sessao_transcricao($jid, $minutos); if (count($lin) < 2) return null;
    $txt = implode("\n", array_map(fn($l) => date('H:i', $l[0]) . ' ' . $l[1] . ': ' . $l[2], $lin));
    $sis = "Você lê a conversa COMPLETA de WhatsApp entre um cliente e o atendimento automático de um provedor de internet. O cliente parou de responder há alguns minutos. "
         . "Entenda o SENTIDO do que ele pediu juntando TUDO (ele pode misturar assuntos: falar de um pagamento e dar o CPF de OUTRA conexão para suporte; trocar de áudio para texto; mandar peças soltas). "
         . "Diga se o pedido JÁ foi atendido e, se não, qual ação o sistema deve fazer sozinho para concluir. Ações: "
         . "\"pix_auto\" (quer pagar/receber o PIX e ainda não recebeu o PIX/boleto), \"pix_manual\" (quer a chave/QR PIX manual), \"segunda_via\" (quer o boleto/2ª via e não recebeu), "
         . "\"atendimento\" (quer falar com pessoa/financeiro/cancelar, ou há assunto que só um humano resolve), \"suporte\" (problema de internet/conexão que ficou sem solução), \"cadastro\" (quer contratar e parou no meio), \"confianca\" (cliente BLOQUEADO que pediu para liberar/desbloquear ou um prazo para pagar), "
         . "\"nenhuma\" (já foi atendido, só agradeceu, conversa social, spam ou não dá para saber). Em dúvida real, \"nenhuma\". "
         . "Responda SÓ JSON: {\"resumo\":\"o que o cliente queria, em 1 frase\",\"concluida\":true|false,\"acao\":\"...\",\"confianca\":0-100}.";
    $cfg = ws_chatbot_cfg(); $modelo = trim((string)($cfg['modelo_menu'] ?? '')) ?: 'gpt-4o';
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => $modelo, 'temperature' => 0, 'max_tokens' => 160, 'response_format' => ['type' => 'json_object'], 'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => "CONVERSA:\n" . $txt]]])]);
    $r = curl_exec($ch); $cod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); if ($cod !== 200) return null;
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true); if (!is_array($j)) return null;
    $ac = (string)($j['acao'] ?? 'nenhuma'); if (!in_array($ac, ['pix_auto', 'pix_manual', 'segunda_via', 'atendimento', 'suporte', 'cadastro', 'confianca', 'nenhuma'], true)) $ac = 'nenhuma';
    return ['acao' => $ac, 'resumo' => mb_substr(trim((string)($j['resumo'] ?? '')), 0, 200), 'concluida' => !empty($j['concluida']), 'conf' => (int)($j['confianca'] ?? 0)];
}
/** Passa o resumo escrito para o provedor ("o cliente tem um problema de conexão…") para a fala com o cliente ("você tem um problema de conexão…"), com a 1ª letra maiúscula e sem ponto final. */
function ws_sessao_segunda_pessoa(string $r): string {
    $r = trim(preg_replace('/\s+/u', ' ', $r)); if ($r === '') return '';
    $r = preg_replace('/\s+(?:dele|dela)\b/iu', '', $r);   // "a mensalidade dele" → "a mensalidade" (o gênero de "seu/sua" variaria)
    $r = preg_replace(['/\bdo cliente\b/iu', '/\bao cliente\b/iu', '/\bno cliente\b/iu', '/\bo cliente\b/iu', '/\bo usuário\b/iu'], ['seu', 'a você', 'em você', 'você', 'você'], $r);
    $r = rtrim($r, " .;,");
    return mb_strtoupper(mb_substr($r, 0, 1)) . mb_substr($r, 1);
}
/** Aviso padrão ao cliente: por falta de interação, com base no que ele pedia, o sistema encaminha o que faltava. */
function ws_sessao_aviso(string $oQue): string { return "⏱️ Como ficamos um tempo sem resposta sua, e com base no que você estava solicitando, estamos encaminhando " . $oQue . "."; }
/** Cron: conclui as conversas paradas — lê a conversa inteira, entende o pedido e faz o que falta. Devolve quantas concluiu. */
function ws_sessoes_idle_run(PDO $db): int {
    $f = WS_CACHE . '/robo_sessoes.json'; $j = json_decode((string)@file_get_contents($f), true); if (!is_array($j) || !$j) return 0;
    $feitos = [];
    foreach ($j as $f8 => $e) {
        $idle = time() - (int)($e['em'] ?? 0);
        $ctx0 = (string)($e['ctx'] ?? '');
        // Bug Leide Jane (13/10/2026): ctx=atend disparava em 6 min — o cliente estava esperando atendente humano.
        // PIX/boleto: 6 min (ROBO_SESSAO_MIN). Atendimento humano (atend): só age após 30 min, para a equipe ter tempo de responder.
        $minCtx = in_array($ctx0, ['atend'], true) ? 30 : ROBO_SESSAO_MIN;
        if (!empty($e['concl']) || !empty($e['feito']) || $idle < $minCtx * 60 || $idle > 5400) continue;
        $feitos[] = [$f8, $e];
    }
    $n = 0;
    foreach ($feitos as [$f8, $e]) {
        // reserva a conversa ANTES de agir (outro cron não repete); se o cliente falou de novo nesse meio tempo, deixa
        $minha = false; ws_sessao_mexer(function (array $jj) use ($f8, $e, &$minha) { if (isset($jj[$f8]) && (int)$jj[$f8]['em'] === (int)$e['em'] && empty($jj[$f8]['feito']) && empty($jj[$f8]['concl'])) { $jj[$f8]['feito'] = 1; $minha = true; } return $jj; });
        if (!$minha) continue;
        $ctx = (string)($e['ctx'] ?? ''); $jid = (string)($e['jid'] ?? ''); $resumo = ''; $semCh = false;
        try {
            $an = ws_sessao_analisar($jid);   // a conversa INTEIRA decide; sem IA/sem conversa, vale o assunto da última escolha de menu
            if ($an) {
                $resumo = $an['resumo'];
                if ($an['concluida'] || $an['acao'] === 'nenhuma' || $an['conf'] < 70) { ws_robo_log($jid, 'conversa parada — li tudo: "' . $resumo . '" → nada a fazer (' . ($an['concluida'] ? 'já atendido' : 'sem pedido pendente') . ').'); continue; }
                $ctx = ['pix_auto' => 'pix_auto', 'pix_manual' => 'pix_manual', 'segunda_via' => 'via', 'atendimento' => 'atend', 'suporte' => 'atend', 'cadastro' => 'cadastro', 'confianca' => 'confianca'][$an['acao']] ?? '';
                if ($an['acao'] === 'suporte') $resumo = 'SUPORTE TÉCNICO sem solução — ' . $resumo;
                /* 23/10/2026 (caso Camyle, chamado #144): assunto ADMINISTRATIVO/financeiro (dúvida de boleto, pagamento, cobrança) não é suporte: não abre chamado;
                   fica só o relato (nota no Chatwoot + linha na ficha). Chamado só para SUPORTE TÉCNICO (acao "suporte") ou quando a IA não classificou. */
                $semCh = ($an['acao'] === 'atendimento');
            }
            if ($ctx === '') continue;
            if (in_array($ctx, ['pix_auto', 'pix_manual', 'via'], true)) {
                $r = ws_robo_concluir_pix($db, $jid, true, $ctx === 'pix_manual', ws_sessao_aviso($ctx === 'via' ? 'o seu boleto (2ª via) e o PIX para pagamento' : ($ctx === 'pix_manual' ? 'o seu boleto e o PIX (QR Code manual) para pagamento' : 'o seu boleto e o PIX para pagamento')));
                if ($r) { ws_robo_log($jid, 'conversa parada — entendi' . ($resumo !== '' ? ' "' . $resumo . '"' : '') . ' e concluí sozinho: enviei o boleto + o PIX' . ($ctx === 'pix_manual' ? ' manual' : '') . ' da fatura #' . $r['fatura'] . ' (R$ ' . number_format($r['valor'], 2, ',', '.') . ').'); $n++; }
            } elseif ($ctx === 'atend') {
                $ar = ws_chatbot_atendimento_abrir($db, ['jid' => $jid, 'motivo' => 'escalada', 'assunto' => $resumo !== '' ? $resumo : 'conversa parada no pedido de atendimento/financeiro', 'relato' => $resumo, 'sem_chamado' => $semCh]);
                if (empty($ar['novo'])) { ws_robo_log($jid, 'conversa parada — o pedido já estava registrado' . (!empty($ar['chamado']) ? ' (chamado #' . (int)$ar['chamado'] . ')' : '') . '; não repeti o aviso ao cliente.'); continue; }   // já tinha chamado/aviso: mandar "estamos encaminhando" de novo era repetição
                ws_robo_log($jid, 'conversa parada — entendi' . ($resumo !== '' ? ' "' . $resumo . '"' : '') . ' e registrei a solicitação' . (!empty($ar['chamado']) ? ' (chamado #' . (int)$ar['chamado'] . ')' : '') . ' para a equipe retomar.');
                $aberto = function_exists('ws_atendimento_aberto') ? !empty(ws_atendimento_aberto()['aberto']) : true;
                /* MENSAGEM ORGANIZADA (12/10/2026): o resumo da IA é escrito para o provedor ("o cliente tem um problema…", com o rótulo "SUPORTE TÉCNICO sem solução —") e era colado inteiro, entre parênteses, no texto do cliente.
                   Agora: frase principal fechada (com o tipo entre parênteses), e em linhas separadas o pedido (falando com ele, na 2ª pessoa) e a situação do atendimento (horário). */
                $tagA = preg_match('/^SUPORTE TÉCNICO sem solução\s*[—\-]\s*/u', $resumo) ? 'SUPORTE TÉCNICO sem solução' : '';
                $resCli = ws_sessao_segunda_pessoa(trim(preg_replace('/^SUPORTE TÉCNICO sem solução\s*[—\-]\s*/u', '', $resumo)));
                $msgA = ws_sessao_aviso('a sua solicitação ao nosso atendimento' . ($tagA !== '' ? ' (' . $tagA . ')' : ''))
                      . ($resCli !== '' ? "\n\n📌 *Seu pedido:* " . $resCli . '.' : '')
                      . "\n\n" . ($aberto ? '✅ O provedor já foi avisado e entra em contato com você em breve.' : '🕓 Estamos fora do horário de atendimento: a solicitação já está registrada e o provedor entrará em contato assim que o atendimento estiver disponível.');
                try { ws_wa_enviar($jid, $msgA, false, ['evento' => 'robo_concluiu']); } catch (Throwable $ex3) {}
                $n++;
            } elseif ($ctx === 'cadastro') {
                $dd = (array)($e['dados'] ?? []); $pega = function (array $ks) use ($dd) { foreach ($ks as $k) foreach ($dd as $kk => $vv) if (mb_strtolower((string)$kk) === mb_strtolower($k) && trim((string)$vv) !== '' && strpos((string)$vv, '{{') === false) return trim((string)$vv); return ''; };
                $tel = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -11); $nome = $pega(['nome', 'Nome do Cliente']); $end = trim($pega(['endereco', 'Endereço']) . ($pega(['numero', 'Nº Casa']) !== '' ? ', ' . $pega(['numero', 'Nº Casa']) : ''));
                $obs = "Pré-cadastro INCOMPLETO pelo robô do WhatsApp (o cliente parou no meio) em " . date('d/m/Y H:i') . '.' . ($resumo !== '' ? "\nO cliente queria: " . $resumo : '') . ($pega(['plano', 'Velocidade']) !== '' ? "\nPlano pedido: " . $pega(['plano', 'Velocidade']) : '') . ($pega(['cpf', 'cpf/cnpj']) !== '' ? "\nCPF/CNPJ: " . $pega(['cpf', 'cpf/cnpj']) : '') . ($pega(['nascimento', 'Data Nascimento']) !== '' ? "\nNascimento: " . $pega(['nascimento', 'Data Nascimento']) : '') . ($pega(['vencimento', 'Dia vencimento']) !== '' ? "\nVencimento: " . $pega(['vencimento', 'Dia vencimento']) : '') . "\nRetomar o contato para completar os dados.";
                $q = $db->prepare("SELECT id FROM ws_lead WHERE telefone=? AND cliente_id IS NULL AND criado_em >= NOW() - INTERVAL 1 DAY ORDER BY id DESC LIMIT 1"); $q->execute([$tel]); $lid = (int)$q->fetchColumn();
                $vals = [$nome !== '' ? $nome : ('Interessado (WhatsApp ' . $tel . ')'), $tel, $pega(['email', 'E-mail']) ?: null, $pega(['cidade', 'Nome da Cidade']) ?: null, $pega(['bairro', 'Bairro']) ?: null, $end ?: null, $obs];
                if ($lid) $db->prepare("UPDATE ws_lead SET nome=?, telefone=?, email=?, cidade=?, bairro=?, endereco=?, obs=? WHERE id=?")->execute(array_merge($vals, [$lid]));
                else { $db->prepare("INSERT INTO ws_lead (nome, telefone, email, cidade, bairro, endereco, obs, origem, etapa) VALUES (?,?,?,?,?,?,?, 'WhatsApp (robô)', 'novo')")->execute($vals); $lid = (int)$db->lastInsertId(); }
                if (is_file(__DIR__ . '/aviso_provedor_lib.php')) { require_once __DIR__ . '/aviso_provedor_lib.php'; try { ws_aviso_provedor("🆕 *Pré-cadastro INCOMPLETO pelo robô* — protocolo L{$lid}\n👤 " . $vals[0] . "\n📞 " . $tel . "\n(o cliente parou no meio — retomar o contato)", $jid, ''); } catch (Throwable $ex2) {} }
                ws_robo_log($jid, 'conversa parada — entendi o cadastro' . ($resumo !== '' ? ' "' . $resumo . '"' : '') . ' e gravei o pré-cadastro incompleto (L' . $lid . ') com o que já foi dito; avisei a equipe.');
                try { ws_wa_enviar($jid, ws_sessao_aviso('o seu cadastro para análise e ativação') . ' Nossa equipe entra em contato para completar os dados e agendar a instalação. 😊', false, ['evento' => 'robo_concluiu']); } catch (Throwable $ex3) {}
                $n++;
            } elseif ($ctx === 'confianca') {
                /* cliente bloqueado que pediu liberação: 1 dia em confiança (1 vez por mês); pediu mais de 1 dia ou já usou → solicitação ao provedor (mesma regra do robô: /api/conexao/confianca) */
                $f8c = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8);
                $qc = $db->prepare("SELECT cpf_cnpj FROM ws_cliente WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''),8)=? AND status NOT IN ('cancelado','inativo','desativado') AND COALESCE(cpf_cnpj,'')<>'' ORDER BY (titular_id IS NULL) DESC, id LIMIT 1"); $qc->execute([$f8c]); $cpfC = preg_replace('/\D/', '', (string)$qc->fetchColumn());
                if ($cpfC !== '') {
                    if (empty($_SERVER['HTTP_HOST']) || $_SERVER['HTTP_HOST'] === 'localhost') $_SERVER['HTTP_HOST'] = (string)parse_url(function_exists('ws_url_publica') ? ws_url_publica() : '', PHP_URL_HOST) ?: 'localhost';
                    $rc = ws_sup_http('POST', 'conexao/confianca', ['cpf' => $cpfC, 'relato' => $resumo, 'remoteJid' => $jid]);
                    $msgC = trim((string)($rc['mensagem'] ?? ''));
                    /* o aviso diz EXATAMENTE o que aconteceu (não as duas hipóteses): liberou 1 dia / pediu mais de 1 dia → passou para o provedor / já usou o do mês → passou para o provedor */
                    $sitC = (string)($rc['situacao'] ?? ''); $passouProv = (stripos($msgC, 'solicitação') !== false || stripos($msgC, 'provedor') !== false);
                    $oQueC = $sitC === 'confianca_liberada' ? ($passouProv ? 'o seu desbloqueio em confiança de 1 dia e, como você precisava de mais tempo, a sua solicitação ao provedor' : 'o seu desbloqueio em confiança de 1 dia')
                           : ($sitC === 'confianca_pedido' ? 'a sua solicitação de desbloqueio ao provedor' : '');
                    if ($msgC !== '') { ws_wa_enviar($jid, ($oQueC !== '' ? ws_sessao_aviso($oQueC) . "\n\n" : '') . $msgC, false, ['evento' => 'robo_concluiu']); ws_robo_log($jid, 'conversa parada — entendi' . ($resumo !== '' ? ' "' . $resumo . '"' : '') . ' e tratei o desbloqueio em confiança: ' . (string)($rc['situacao'] ?? '?') . '.'); $n++; }
                }
            }
        } catch (Throwable $ex) { @error_log('[sessoes] ' . $ex->getMessage()); }
    }
    return $n;
}

/* O QUE O CLIENTE ESCREVE DEPOIS DE ABRIR O ATENDIMENTO FICA NO CHAMADO (10/10/2026, caso do Leonardo).
 * Fora do horário o robô abre o chamado só com o assunto ("Falar com Atendente") e pergunta "Gostaria de adicionar mais alguma informação?" — mas as caixas de texto do fluxo não guardavam a
 * resposta, e o robô ainda dizia "Anotado! Sua mensagem fica junto do seu atendimento". O pedido real ("vou me mudar, preciso instalar no endereço novo") se perdia.
 * Agora toda fala do cliente (webhook da Evolution) entra como mensagem no chamado de atendimento do robô aberto nos últimos 90 min, e uma IA lê o que ele pediu: mudança de endereço, nova instalação,
 * cancelamento ou suporte viram o TIPO certo do chamado (com título e aviso ao provedor). Devolve o id do chamado ou null. */
function ws_chamado_robo_anexar(PDO $db, string $jid, string $texto): ?int {
    $trv = ws_trava_tel($db, $jid, 10);   // webhook repetido/simultâneo da mesma fala: um de cada vez, o 2º vê a fala já gravada
    try { return ws_chamado_robo_anexar_i($db, $jid, $texto); } finally { ws_destrava_tel($db, $trv); }
}
function ws_chamado_robo_anexar_i(PDO $db, string $jid, string $texto): ?int {
    $texto = trim(preg_replace('/\s+/', ' ', $texto)); $f8 = substr(preg_replace('/\D/', '', explode('@', $jid)[0]), -8);
    if (strlen($f8) < 8 || mb_strlen($texto) < 4 || preg_match('/^\s*\d{1,2}\s*$/', $texto) || preg_match('/^(sim|nao|não|ok|okay|obrigad[oa]|valeu|bom dia|boa tarde|boa noite|oi|ola|olá)\W*$/iu', $texto)) return null;
    $q = $db->prepare("SELECT ch.id, ch.tipo, ch.titulo, ch.cliente_id, cl.nome FROM ws_chamado ch JOIN ws_cliente cl ON cl.id=ch.cliente_id
                         WHERE ch.status IN ('aberto','em_andamento') AND ch.criado_em > NOW() - INTERVAL 90 MINUTE AND ch.titulo LIKE '%robô%'
                           AND RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(cl.celular,''),' ',''),'-',''),'(',''),')',''),8)=? ORDER BY ch.id DESC LIMIT 1");
    $q->execute([$f8]); $ch = $q->fetch(PDO::FETCH_ASSOC); if (!$ch) return null;
    $ult = $db->prepare("SELECT mensagem FROM ws_chamado_msg WHERE chamado_id=? AND autor_tipo='cliente' ORDER BY id DESC LIMIT 5"); $ult->execute([(int)$ch['id']]);
    foreach ($ult->fetchAll(PDO::FETCH_COLUMN) as $mj) if (trim(preg_replace('/\s+/', ' ', (string)$mj)) === $texto) return (int)$ch['id'];   // a mesma fala não entra duas vezes (confere as 5 últimas, não só a última)
    $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, usuario_id, autor_tipo, mensagem) VALUES (?, NULL, 'cliente', ?)")->execute([(int)$ch['id'], mb_substr($texto, 0, 1500)]);
    // o que ele pediu? (só o texto dele vai à IA)
    $tipo = ''; $resumo = '';
    $key = ws_chatbot_openai_key();
    if ($key !== '') {
        $sis = "Cliente de provedor de internet escreveu esta mensagem DEPOIS de pedir atendimento. Classifique o pedido: \"mudanca_endereco\" (vai se mudar / quer levar a internet para outro endereço), \"instalacao\" (quer contratar/instalar internet num lugar novo, novo ponto), "
             . "\"cancelamento\" (quer CANCELAR o serviço/contrato — atenção: \"dar baixa\", \"dá a baixa\", \"baixa no pagamento/PIX/boleto\", \"baixa aí\" falando de pagamento NÃO é cancelamento: é pedido de confirmar/baixar o pagamento → \"outro\"), \"suporte\" (problema técnico/internet ruim), \"outro\" (qualquer outro assunto ou só complemento). Responda SÓ JSON: {\"tipo\":\"...\",\"resumo\":\"o pedido em 1 frase curta\"}.";
        $ch2 = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch2, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode(['model' => (trim((string)(ws_chatbot_cfg()['modelo_menu'] ?? '')) ?: 'gpt-4o'), 'temperature' => 0, 'max_tokens' => 80, 'response_format' => ['type' => 'json_object'], 'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => mb_substr($texto, 0, 600)]]])]);
        $r = curl_exec($ch2); if ((int)curl_getinfo($ch2, CURLINFO_HTTP_CODE) === 200) { $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true); $tipo = (string)($j['tipo'] ?? ''); $resumo = mb_substr(trim((string)($j['resumo'] ?? '')), 0, 160); }
        curl_close($ch2);
    }
    $map = ['mudanca_endereco' => ['mudana_de_endereo', 'Mudança de endereço (pedido pelo robô)'], 'instalacao' => ['instalacao', 'Nova instalação (pedido pelo robô)'], 'cancelamento' => ['cancelamento', 'Cancelamento (pedido pelo robô)'], 'suporte' => ['suporte', 'Suporte técnico (pedido pelo robô)']];
    if (isset($map[$tipo]) && (string)$ch['tipo'] === 'atendimento') {
        [$tp, $tit] = $map[$tipo];
        $db->prepare("UPDATE ws_chamado SET tipo=?, titulo=?, descricao=CONCAT(IFNULL(descricao,''), '\nPedido do cliente: ', ?) WHERE id=?")->execute([$tp, $tit, mb_substr($texto, 0, 600), (int)$ch['id']]);
        if (function_exists('ws_evento')) { try { ws_evento($db, (int)$ch['cliente_id'], 'robo', 'Robô — o pedido do cliente virou «' . $tit . '» no chamado #' . (int)$ch['id'] . ': ' . ($resumo !== '' ? $resumo : mb_substr($texto, 0, 100))); } catch (Throwable $e) {} }
        if (is_file(__DIR__ . '/aviso_provedor_lib.php')) { require_once __DIR__ . '/aviso_provedor_lib.php'; try { ws_aviso_provedor("📌 *{$tit}* — chamado #" . (int)$ch['id'] . "\n👤 " . $ch['nome'] . "\n💬 " . ($resumo !== '' ? $resumo : mb_substr($texto, 0, 160)) . "\nDetalhes em Chamados.", $jid, ''); } catch (Throwable $e) {} }
    } else if (function_exists('ws_evento')) { try { ws_evento($db, (int)$ch['cliente_id'], 'robo', 'Robô — registrei no chamado #' . (int)$ch['id'] . ' o que o cliente escreveu: "' . mb_substr($texto, 0, 120) . '"'); } catch (Throwable $e) {} }
    return (int)$ch['id'];
}
/* LOG CURTO DO ROBÔ (10/10/2026): UMA linha por ação relevante (entrou direto no assunto, ficou calado, comprovante repetido/já baixado, mudou de assunto,
   pedido de confiança…), na linha do tempo do cliente (achado pelo WhatsApp) — aparece em Relatórios → Log → 🤖 Robô / Central e na ficha. Nunca derruba o robô. */
function ws_robo_log(string $jidOuTel, string $texto, ?int $cid = null): void {
    try {
        if (!function_exists('ws_evento')) return;
        $db = ws_db(); $tel = substr(preg_replace('/\D/', '', explode('@', $jidOuTel)[0]), -8);
        if ($cid === null && strlen($tel) === 8) {
            $q = $db->prepare("SELECT id FROM ws_cliente WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(celular,''),' ',''),'-',''),'(',''),')',''),8)=? ORDER BY (titular_id IS NULL) DESC, id LIMIT 1");
            $q->execute([$tel]); $c = $q->fetchColumn(); $cid = $c ? (int)$c : null;
        }
        if (preg_match('/^558100000/', preg_replace('/\D/', '', $jidOuTel))) return;   // números de teste não gravam
        ws_evento($db, $cid, 'robo', mb_substr('Robô — ' . trim(preg_replace('/\s+/', ' ', $texto)), 0, 220));
    } catch (Throwable $e) {}
}
function ws_chatbot_resumo(string $tipo, string $motivo = ''): void {
    $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/robo_resumo.json';
    $hoje = date('Y-m-d');
    $r = json_decode((string)@file_get_contents($f), true);
    $primeira = !is_array($r);
    if ($primeira) $r = ['dia' => $hoje, 'audio' => 0, 'desvio' => 0, 'falha' => 0, 'motivos' => []];
    if (($r['dia'] ?? '') !== $hoje) {   // virou o dia: fecha o anterior numa linha só
        if (function_exists('ws_evento') && ((int)$r['audio'] + (int)$r['desvio'] + (int)$r['falha']) > 0) {
            arsort($r['motivos']); $top = $r['motivos'] ? array_key_first($r['motivos']) : '';
            try { ws_evento(ws_db(), null, 'robo', 'Robô do WhatsApp — resumo de ' . date('d/m', strtotime((string)$r['dia'])) . ': ' . (int)$r['audio'] . ' áudio(s) entendido(s) · ' . (int)$r['desvio'] . ' mudança(s) de assunto · ' . (int)$r['falha'] . ' falha(s)' . ($top !== '' ? " (principal: $top)" : '')); } catch (Throwable $e) {}
        }
        $r = ['dia' => $hoje, 'audio' => 0, 'desvio' => 0, 'falha' => 0, 'motivos' => []];
    }
    if (isset($r[$tipo])) $r[$tipo] = (int)$r[$tipo] + 1;
    if ($tipo === 'falha' && $motivo !== '') { $m = mb_substr(trim(preg_replace('/[\d~]+/', '', $motivo)), 0, 40); $r['motivos'][$m] = (int)($r['motivos'][$m] ?? 0) + 1; }
    @file_put_contents($f, json_encode($r, JSON_UNESCAPED_UNICODE)); @chmod($f, 0640);
    if ($primeira) { try { ws_db()->exec("DELETE FROM ws_evento WHERE tipo='robo' AND (texto LIKE 'Robô do WhatsApp — áudio%' OR texto LIKE 'Robô do WhatsApp — atendimento começou por áudio%')"); } catch (Throwable $e) {} }
}

/* NÃO FICAR PRESO NO ERRO (07/10/2026): conta, por número de WhatsApp, as respostas SEGUIDAS que a pergunta não entendeu (menu,
   lista ou CPF). Resposta boa ou mudança de assunto zera. Na 3ª seguida o robô deixa de insistir e encaminha para o ATENDENTE
   (desvio "7"). Arquivo cache/robo_erros.json; entradas somem sozinhas após 30 min sem fala. */
function ws_chatbot_resposta_invalida(string $fonte, string $final, array $b): bool {
    $fonte = trim($fonte); if ($fonte === '' || preg_match('/^\w+Message\|/', $fonte)) return false;
    $tipo = in_array(($b['tipo'] ?? ''), ['numero', 'escolha', 'texto'], true) ? (string)$b['tipo'] : 'menu';
    $final = trim($final);
    if ($tipo === 'texto') {
        $cp = mb_strtolower((string)($b['campo'] ?? '') . ' ' . (string)($b['pergunta'] ?? ''), 'UTF-8'); $v = $final !== '' ? $final : $fonte;
        if (preg_match('/nome/', $cp) && !preg_match('/bairro|refer|rua|endere/', $cp)) return ws_chatbot_nao_e_nome($v);
        if (preg_match('/mail/', $cp)) return !preg_match('/@/', $v) && !preg_match('/n[aã]o (tenho|possuo|uso)|sem e.?mail/iu', $fonte);
        if (preg_match('/whats|celular|telefone|ddd/', $cp)) return strlen(preg_replace('/\D/', '', $v)) < 10;
        if (preg_match('/nasc/', $cp)) return !preg_match('/\d/', $v);
        if (preg_match('/\bn[º°]|n[uú]mero/u', $cp) && !preg_match('/whats|celular|telefone|cpf|cnpj/', $cp)) return !preg_match('/\d/', $v) && !preg_match('/\bs\s*\/?\s*n\b|sem n[uú]mero/iu', $v);
        return false;
    }
    if ($tipo === 'escolha') return !in_array($final, array_map('trim', explode('|', (string)($b['itens'] ?? ''))), true);
    if ($tipo === 'numero') { if ($final === '0') return false; $d = preg_replace('/\D/', '', $final); return preg_match('/[a-zA-Z]/', $final) || !preg_match('/^\d{10,14}$/', $d); }
    $opcoes = (string)($b['opcoes'] ?? '');
    return !(preg_match('/^\d{1,2}$/', $final) && ($opcoes === '' || preg_match('/(^|\|)\s*' . preg_quote($final, '/') . '\s*=/', $opcoes)));
}
/** Mensagem curta para o cliente quando a resposta não serve para a pergunta (o fluxo repete a pergunta com ela). */
function ws_chatbot_motivo_invalido(array $b): string {
    $tipo = (string)($b['tipo'] ?? ''); $cp = mb_strtolower((string)($b['campo'] ?? '') . ' ' . (string)($b['pergunta'] ?? ''), 'UTF-8');
    if ($tipo === 'numero') return 'Digite só os números do CPF (11 dígitos) ou CNPJ (14 dígitos). 👇';
    if (preg_match('/whats|celular|telefone|ddd/', $cp)) return 'Digite o DDD + número do WhatsApp. Ex.: 81 99999-9999 (ou responda *este mesmo*).';
    if (preg_match('/mail/', $cp)) return 'Informe um e-mail válido. Ex.: nome@gmail.com (ou responda *não tenho*).';
    if (preg_match('/nasc/', $cp)) return 'Informe a data de nascimento. Ex.: 28/04/1980';
    if (preg_match('/\bn[º°]|n[uú]mero/u', $cp)) return 'Informe só o *número* da casa (ou *S/N* se não tiver).';
    if (preg_match('/nome/', $cp)) return 'Informe o *nome completo* de quem vai ficar no cadastro.';
    return 'Não entendi a sua resposta. Pode responder de novo?';
}
function ws_chatbot_erros(string $jid, bool $erro): int {
    $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/robo_erros.json';
    $d = json_decode((string)@file_get_contents($f), true); if (!is_array($d)) $d = [];
    $agora = time(); foreach ($d as $k => $v) if ($agora - (int)($v['em'] ?? 0) > 1800) unset($d[$k]);
    $k = substr(sha1($jid), 0, 16); $n = $erro ? (int)($d[$k]['n'] ?? 0) + 1 : 0;
    if ($n > 0) $d[$k] = ['n' => $n, 'em' => $agora]; else unset($d[$k]);
    @file_put_contents($f, json_encode($d)); @chmod($f, 0640);
    return $n;
}
/* RESPOSTA DE MENU, FALADA OU DIGITADA (07/10/2026): quem entende primeiro é a IA, pelo SENTIDO ("quero um técnico" = abrir chamado,
   "está errado" = corrigir, "chave pix" = a opção da chave e não a do QR). A regra de palavras ficava na frente e, em empate
   (várias opções com "pix", "suporte"…), escolhia a PRIMEIRA — errado em ~1 de cada 8 frases nos testes. Agora:
   1) número escrito/dito curto ("2", "opção dois") → direto, sem IA (de graça e instantâneo);
   2) senão a IA escolhe a opção; só vale se o número existir no menu;
   3) IA fora do ar/sem certeza → regra de palavras (como antes). Devolve o dígito da opção ou a fala original. */
/* ATENDENTE INTELIGENTE (10/10/2026) — a IA DECIDE primeiro; as regras (ws_chatbot_regras_menu) ficam só de RESERVA (IA fora do ar / sem certeza).
   Antes a IA era um "conversor" (gpt-4o-mini, 80 tokens) e oscilava. Agora é um atendente: recebe TUDO o que o cliente falou, em ordem, e o menu,
   e escolhe pelo sentido. Só vai à OpenAI o texto que o cliente escreveu e o menu (como já era) — nenhum dado da conta/cadastro dele. */
function ws_chatbot_ia_menu(string $fala, string $opcoes): string {
    $key = ws_chatbot_openai_key(); if ($key === '' || trim($fala) === '' || $opcoes === '') return '';
    $cfg = ws_chatbot_cfg(); $modelo = trim((string)($cfg['modelo_menu'] ?? '')) ?: 'gpt-4o';
    $sis = "Você é o atendente de um provedor de internet por WhatsApp. O cliente acabou de falar e o robô precisa levá-lo DIRETO ao assunto certo do menu, sem fazê-lo digitar número. "
         . "Leia tudo o que o cliente disse (as falas vêm em ordem) e escolha a opção do menu que resolve o que ele quer, pelo SENTIDO: gírias, erros de digitação, frases longas ou misturadas. "
         . "Se disse que JÁ pagou (fez PIX, transferência, pagamento, vai mandar comprovante) = a opção de comprovante, nunca a de pagar. "
         . "Problema técnico (caiu, lenta, sem sinal, wifi, roteador, luz vermelha, ping, técnico, visita) = suporte. Mudar vencimento, endereço, senha ou dados = central do assinante. "
         . "Boleto, fatura, quanto devo, 2ª via = a opção de 2ª via. Quer pagar agora = pagar com PIX. Contratar, plano, preço, cobertura, mais velocidade = ser cliente. Cancelar o contrato/plano/serviço = cancelamento. Encerrar a CONVERSA (encerrar atendimento, finalizar, tchau, obrigado era só isso, nada mais, pode encerrar) = a opção de sair — isso NÃO é cancelamento. Falar com pessoa = atendente. "
         . "Pedir para liberar/desbloquear a internet, 'deixa liberada até segunda', 'só pago dia tal', 'liberação em confiança' = suporte (lá o robô libera em confiança). "
         . "Só saudação, 'preciso de ajuda', 'queria uma informação' ou algo sem assunto = opcao vazia (o menu aparece). Se houver dúvida real entre duas opções, vazia. "
         . "Mensagem que NÃO é para o provedor — propaganda, golpe, corrente, link de oferta, ou conversa pessoal com outra pessoa ('bom dia seu Roberto', 'kk') — marque \"ignorar\":true (o robô fica calado). "
         . "Responda SÓ JSON: {\"opcao\":\"<número ou vazio>\",\"confianca\":0-100,\"ignorar\":false}.";
    $usr = "MENU:\n" . str_replace('|', "\n", $opcoes) . "\n\nO QUE O CLIENTE FALOU (em ordem):\n" . mb_substr($fala, 0, 700);
    /* CUSTO DA IA (14/10): temperatura 0 = mesma frase + mesmo menu dão a mesma resposta; repetição em 10 min (cliente reenvia, webhook repete, teste) usa a resposta guardada em vez de pagar de novo. */
    $ckM = WS_CACHE . '/ia_menu_' . sha1($modelo . '|' . $opcoes . '|' . mb_substr($fala, 0, 700)) . '.txt';
    if (is_file($ckM) && time() - filemtime($ckM) < 600) return (string)@file_get_contents($ckM);
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => $modelo, 'temperature' => 0, 'max_tokens' => 40, 'response_format' => ['type' => 'json_object'],
            'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => $usr]]])]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return '';
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true);
    $o = trim((string)($j['opcao'] ?? '')); $conf = (int)($j['confianca'] ?? 0);
    $resM = (!empty($j['ignorar']) && $conf >= 70 && $o === '') ? 'IGNORAR' : ((preg_match('/^\d{1,2}$/', $o) && $conf >= 60) ? $o : '');   // IGNORAR = spam / conversa pessoal: quem chamou decide se cala (só /api/primeira)
    @file_put_contents($ckM, $resM);
    foreach (glob(WS_CACHE . '/ia_menu_*.txt') ?: [] as $vM) if (time() - (int)@filemtime($vM) > 900) @unlink($vM);
    return $resM;
}
/* REGRAS FIXAS DO MENU PRINCIPAL (10/10/2026) — varredura com ~140 frases reais: a IA oscilava ("Realizei o pagamento" ora 8, ora 3, ora 2;
   "preciso de um técnico" → PIX; "trocar o vencimento" → suporte). O que tem sentido inequívoco é decidido AQUI, sem IA, e o número da opção
   é achado pelo NOME dela no menu (não por posição fixa). Só vale quando o menu tem a opção. '' = não decidiu (segue para a IA). */
function ws_chatbot_regras_menu(string $fala, string $opcoes): string {
    $n = ' ' . ws_chatbot_norm($fala) . ' ';
    $achar = function (string $re) use ($opcoes): string { foreach (explode('|', $opcoes) as $o) if (preg_match('/^\s*(\d{1,2})\s*=\s*(.+)$/u', $o, $m) && preg_match($re, ws_chatbot_norm($m[2]))) return $m[1]; return ''; };
    $negou = (bool)preg_match('/ (nao|ainda nao|n|nunca|sem) (paguei|pagou|fiz|realizei|efetuei|consegui pagar) /', $n);
    // 1) JÁ PAGOU / vai mandar comprovante → comprovante (nunca "pagar com PIX" nem 2ª via)
    if (!$negou && preg_match('/ (paguei|pago ja|ja paguei|ja pago|ja foi pago|ja fiz o pagamento|realizei (o |um |meu )?(pagamento|pix)|fiz (o |um |meu )?(pagamento|pix|transferencia|deposito)|efetuei (o |um |meu )?(pagamento|pix)|acabei de pagar|pagamento (feito|efetuado|realizado|ja feito)|transferi|mandei (o |um )?(pix|comprovante)|enviei (o |um )?(pix|comprovante)|segue (o )?comprovante|vou (te )?(enviar|mandar) (o )?comprovante|comprovante) /', $n)
        && ($d = $achar('/comprovante/')) !== '') return $d;
    // 2) cobertura: "vocês atendem na minha rua?", "tem internet na minha região?" → ser cliente
    if (!preg_match('/ (nao|n|nem) (tem|ta|esta|funciona) /', $n) && preg_match('/ (atende|atendem|cobertura|chega (ai|aqui|la|ate)|tem (internet|fibra|sinal|rede|cobertura) (ai |ali |na |no |em |pra |para |ate )?(minha|meu|nossa|nosso|regiao|rua|bairro|cidade|localidade|zona|casa|sitio)|(tem|existe) (como )?(instalar|instalacao)) /', $n)
        && ($d = $achar('/(ser nosso cliente|ser cliente|contratar|novo cliente)/')) !== '') return $d;
    if (preg_match('/ sem (acesso|sinal|conexao|net|internet) /', $n) && ($d = $achar('/suporte/')) !== '') return $d;
    if (preg_match('/ (ping|pingando|lag|latencia|delay) /', $n) && ($d = $achar('/suporte/')) !== '') return $d;   // jogo/ping alto = suporte
    // 2b) internet "não está boa", oscilando, instável, fraca → suporte (mesmo sem dizer "caiu")
    if (preg_match('/ (internet|net|wifi|wi fi|sinal|conexao|roteador|modem|fibra) /', $n) && preg_match('/ (nao (esta|ta|tah|anda) (boa|bom|legal|estavel|normal|funcionando|prestando|pegando)|oscil\w*|instavel|fraco|fraca|fraquinh\w*|fraquin\w*|ruim|lenta|lento|travand\w*|cai|caindo|caiu|parou|falhando|picotando) /', $n)
        && !preg_match('/ (cancel\w*|boleto|fatura|pagamento|pagar|contratar|plano novo) /', $n) && ($d = $achar('/suporte/')) !== '') return $d;
    // 3) técnico / chamado / visita → suporte
    if (preg_match('/ (tecnico|chamado|visita|assistencia) /', $n) && !preg_match('/ (cancel|boleto|fatura|pix|pagamento) /', $n) && ($d = $achar('/suporte/')) !== '') return $d;
    // 4) mudar vencimento / endereço / dados → central do assinante
    if (preg_match('/ (trocar|troca|mudar|mudanca|alterar|alteracao|mudei|atualizar|corrigir) .{0,30}(vencimento|data de vencimento|dia de vencimento|dia do vencimento|endereco|senha|dados|cadastro|email|telefone) /', $n)
        || preg_match('/ (vencimento|dia do vencimento|data de vencimento) (para|pro|pra|pro dia) /', $n)) { if (($d = $achar('/central/')) !== '') return $d; }
    // 5) mais velocidade / mudar de plano / planos e preços → ser cliente (planos)
    if (preg_match('/ (aumentar|melhorar|subir|upgrade|trocar|mudar|alterar|contratar) .{0,25}(velocidade|plano|mega|pacote) /', $n) || preg_match('/ (quais|qual|quanto).{0,25}(plano|planos|pacote|valor do plano|custa) /', $n)) { if (($d = $achar('/(ser nosso cliente|ser cliente|contratar|novo cliente)/')) !== '') return $d; }
    // 6) valor / vencimento / código da fatura → 2ª via
    if (preg_match('/ (quanto|qual).{0,12}(devo|deve|devendo|debito|em aberto|pendente|pendencia) /', $n) && ($d = $achar('/(boleto|2 via|segunda via)/')) !== '') return $d;
    if (preg_match('/ (valor|quanto|data|quando|dia).{0,25}(fatura|boleto|mensalidade|vence|vencimento) /', $n) && !preg_match('/ (trocar|mudar|alterar) /', $n) && ($d = $achar('/(boleto|2 via|segunda via)/')) !== '') return $d;
    return '';
}
function ws_chatbot_menu_resposta(string $fala, string $opcoes, string $campo = '', string $pergunta = ''): string {
    $fala = preg_replace('/\b(intenet|inernet|internete|internt|intenete|interente|interne|inetrnet|intrenet)\b/iu', 'internet', $fala);   // erro de digitação comum
    $existe = function (string $d) use ($opcoes): bool { return $d !== '' && preg_match('/^\d{1,2}$/', $d) && preg_match('/(^|\|)\s*' . preg_quote($d, '/') . '\s*=/', $opcoes); };
    /* NÚMERO DIGITADO É ESCOLHA, NÃO FRASE (13/10/2026): quem digita "7" (ou "opção 7", "sete") escolheu a opção 7 do menu — vai direto, sem IA. Antes o "7" ia para a IA como se fosse uma frase
       ("O QUE O CLIENTE FALOU: 7") e ela podia devolver outra opção (Central do Assinante / Central de atendimento) em vez de "Falar com Atendente". */
    $nD = trim(ws_chatbot_norm($fala));
    $wD = ['dois' => '2', 'duas' => '2', 'tres' => '3', 'quatro' => '4', 'cinco' => '5', 'seis' => '6', 'meia' => '6', 'sete' => '7', 'oito' => '8', 'nove' => '9'];
    if (preg_match('/^(?:(?:a |o )?(?:opcao|numero|opcao numero) )?(\d{1,2}|dois|duas|tres|quatro|cinco|seis|meia|sete|oito|nove)$/', $nD, $mD)) { $dD = $wD[$mD[1]] ?? $mD[1]; if ($existe($dD)) return $dD; }
    if (preg_match('/^[\d\s().+\-\/]{7,}$/', trim($fala))) return $fala;   // número comprido (CPF, telefone, protocolo) não é opção de menu — a IA não pode "adivinhar" uma
    // só saudação ("boa noite pessoal", "e aí"): não há assunto — não escolhe opção nenhuma, o menu aparece
    if (preg_match('/^\s*((oi+|ola|opa|alo|salve|eae|e a[ií]|bom dia|boa tarde|boa noite|tudo bem|tudo bom|pessoal|gente|galera|amigo|amiga|moco|moca|por favor|td bem|sim|ok|okay|certo|blz|beleza|entendi|combinado)[\s!.,?]*)+$/iu', ws_chatbot_norm($fala))) return $fala;
    // propaganda/golpe com link ("o Kwai liberou R$ 300… clica no link"): não é assunto do provedor — robô calado
    if ($campo === 'assunto do cliente' && preg_match('#https?://|www\.#i', $fala) && preg_match('/(clic|ganh|liber[ao]u|bonus|promo|oferta|sorteio|premio|gratis|desconto|resgat|indiqu|cadastre-se)/iu', $fala)) return 'IGNORAR';
    if ($campo === 'assunto do cliente' || $campo === 'opção do menu') { $iaM = ws_chatbot_ia_menu($fala, $opcoes); if ($iaM === 'IGNORAR') { if ($campo === 'assunto do cliente') return 'IGNORAR'; } elseif ($existe($iaM)) return $iaM; }   // 1º a IA atendente
    if (($rg = ws_chatbot_regras_menu($fala, $opcoes)) !== '' && $existe($rg)) return $rg;   // 2º regras de reserva
    // pedido vago ("oi, queria uma informação", "preciso de ajuda"): ainda sem assunto — não chuta opção, o menu aparece
    if (preg_match('/^( (oi|ola|bom dia|boa tarde|boa noite|queria|gostaria|quero|preciso|de|uma|um|umas|ajuda|informacao|informacoes|duvida|duvidas|saber|perguntar|pergunta|pedir|tirar|por favor|pf|pfv|so|sobre|um pouco))+ $/', ' ' . ws_chatbot_norm($fala) . ' ')) return $fala;
    if (preg_match('/ (nao|ainda nao|n) (paguei|pagou|fiz o pagamento) /', ' ' . ws_chatbot_norm($fala) . ' ')) return $fala;   // "não paguei ainda": sem assunto certo, o menu decide (a IA chutava 9)
    if (ws_chatbot_sem_internet($fala) && !preg_match('/\d\s*=\s*sem (acesso|internet)/iu', $opcoes) && ($sup = ws_chatbot_opcao_suporte($opcoes)) !== '') return $sup;   // "estamos sem internet" = suporte, sem IA
    $kw = ws_chatbot_resposta($fala, $opcoes, 'menu');
    $n = ws_chatbot_norm($fala);
    $livres = ['opcao', 'o', 'a', 'numero', 'e', 'quero', 'de', 'zero', 'um', 'uma', 'dois', 'duas', 'tres', 'quatro', 'cinco', 'seis', 'meia', 'sete', 'oito', 'nove'];
    $soNumero = ($n !== '' && count(array_filter(explode(' ', $n), fn($w) => $w !== '' && !ctype_digit($w) && !in_array($w, $livres, true))) === 0);
    if ($soNumero && $existe($kw)) return $kw;
    $ia = ws_chatbot_ia($fala, $campo !== '' ? $campo : 'opção do menu', $pergunta, $opcoes, 'opções numeradas');
    if ($existe($ia)) return $ia;
    return $existe($kw) ? $kw : $fala;
}
/* TEXTO DIGITADO TAMBÉM É ENTENDIDO (07/10/2026). Antes o digitado só ganhava "acabamento" (maiúsculas, data com 4 dígitos); só o ÁUDIO passava
   pela IA. Resultado: "muito bom" na avaliação virava "muito bom" (o fluxo esperava 1–5 e repetia "não entendi"), "meu nome é maria"
   virava "Meu Nome É Maria", "joao arroba gmail ponto com" não virava e-mail. Agora, se o texto NÃO está no formato que o campo pede, a IA
   converte pelo sentido (mesmas regras do áudio). Texto já limpo não gasta IA. Pergunta com opções numeradas → devolve o NÚMERO da opção. */
/* AVALIAÇÃO EM TEXTO LIVRE (10/10/2026): "bom", "ótimo atendimento", "5 estrelas", "não quero avaliar" → número da opção (Muito Satisfeito=1 … Não Avaliar=5).
   Regras fixas, sem IA — a IA dava 1 para "obrigado, foi bom" e 5 para "5 estrelas". '' = não decidiu. */
function ws_chatbot_avaliacao_regra(string $texto, string $pergunta): string {
    if (!preg_match('/satisfeito/iu', $pergunta) || !preg_match('/n[aã]o avaliar/iu', $pergunta)) return '';
    $n = ' ' . ws_chatbot_norm($texto) . ' ';
    if (preg_match('/^\s*[1-5]\s*$/', $n)) return trim($n);
    if (preg_match('/ (nao quero avaliar|nao avaliar|prefiro nao|nao vou avaliar|pular|sem avaliar|nao quero responder) /', $n)) return '5';
    if (preg_match('/ (pessimo|horrivel|terrivel|ruim|insatisfeito|nao gostei|nao resolv|nao resolveu|decepcion|lixo|demorado|demora|nao fui atendido|mal atendido) /', $n)) return '4';
    if (preg_match('/ (mais ou menos|indiferente|regular|razoavel|normal|medio|nem bom nem ruim) /', $n)) return '3';
    if (preg_match('/ (muito bom|muito satisfeito|otimo|excelente|perfeito|maravilh\w*|nota 10|nota dez|10|dez|cinco estrelas|5 estrelas|show|top|amei|adorei|nota mil|sensacional|espetacular|nota maxima) /', $n)) return '1';
    if (preg_match('/ (bom|bem|satisfeito|gostei|legal|valeu|obrigad\w*|resolveu|resolvido|atendeu|ajudou|tranquilo|beleza|blz|ok) /', $n)) return '2';
    return '';
}
function ws_chatbot_texto_entender(string $texto, string $campo, string $pergunta): string {
    $v = ws_chatbot_acabamento($texto, $campo); if ($v === '') $v = $texto;
    $c = mb_strtolower($campo, 'UTF-8'); $nPal = count(array_filter(preg_split('/\s+/', trim($texto))));
    if ($c === '' || strpos($c, 'ws_') === 0) return $v;
    $numerada = (bool)preg_match('/(\d\x{FE0F}?\x{20E3})|(^|\n)\s*\d\s*[-.)]/u', $pergunta);
    if (($av = ws_chatbot_avaliacao_regra($texto, $pergunta)) !== '') return $av;
    if ($numerada) $ia = !preg_match('/^\s*\d\s*$/', $texto);
    elseif (preg_match('/nome/', $c)) $ia = preg_match('/^(meu nome|sou |me chamo|aqui e|aqui é|e o |é o |eh )/iu', trim($texto)) || $nPal > 4 || ws_chatbot_nao_e_nome($texto);
    elseif (preg_match('/nasc|data/', $c)) $ia = !preg_match('#^\d{2}/\d{2}/\d{4}$#', $v);
    elseif (preg_match('/mail/', $c)) $ia = !preg_match('/^[^@\s]+@[^@\s]+\.[^@\s]+$/', $v);
    elseif (preg_match('/whats|telefone|celular|ddd/', $c)) $ia = !preg_match('/^\d{10,11}$/', preg_replace('/\D/', '', $v)) && preg_match('/[a-zA-Z]/', $texto);
    elseif (preg_match('/n[ºo°]|numero|número/u', $c)) $ia = !preg_match('/^(\d{1,6}[a-zA-Z]?|s\/?n)$/i', trim($v));
    else $ia = $nPal > 5 || preg_match('/^(eu )?(moro|fica|e |é |perto|ali )/iu', trim($texto));
    if (!$ia) return $v;
    $r = ws_chatbot_ia($texto, $campo, $pergunta, '', $numerada ? 'opções numeradas' : 'texto');
    return $r !== '' ? $r : $v;
}
/* ATENDIMENTO ABERTO PELO ROBÔ (07/10/2026): quando o robô passa o cliente para uma PESSOA — fora do horário ou por escalada (3 respostas
   não entendidas) — o pedido não pode se perder. Esta função registra:
   - cliente identificado pelo WhatsApp → CHAMADO (tipo "atendimento") na tela Chamados (reusa o aberto das últimas 12 h, sem duplicar) e
     uma linha na linha do tempo da ficha;
   - número desconhecido (ainda não é cliente) → só a linha no log e o aviso à equipe;
   - aviso por WhatsApp aos números de Chamados → Notificações (os mesmos dos chamados do robô).
   LOG ENXUTO: UMA linha curta por atendimento; áudio só é MENCIONADO ("por áudio"), nunca transcrito. Números de teste (5581000000…)
   não gravam nem avisam ninguém. Devolve ['chamado'=>int, 'cliente'=>?int, 'novo'=>bool]. */
function ws_chatbot_atendimento_abrir(PDO $db, array $d): array {
    $jid = preg_replace('/\D/', '', explode('@', (string)($d['jid'] ?? ''))[0]);
    $motivo = (string)($d['motivo'] ?? 'fora_horario');
    $nome = mb_substr(trim((string)($d['nome'] ?? '')), 0, 80);
    $proto = trim((string)($d['protocolo'] ?? '')); $audio = !empty($d['audio']);
    $assunto = mb_substr(trim((string)($d['assunto'] ?? '')), 0, 80);
    if ($jid === '' || preg_match('/^558100000/', $jid)) return ['chamado' => 0, 'cliente' => null, 'novo' => false];   // vazio ou número de teste
    // quem é? (últimos 9 dígitos do celular/telefone)
    $cid = null; $cnome = '';
    $fim = substr($jid, -8);   // 8 últimos dígitos: WhatsApp antigo vem sem o 9º dígito, o cadastro com
    try {
        $norm = fn($c) => "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE($c,' ',''),'-',''),'(',''),')',''),'+','')";
        $q = $db->prepare("SELECT id, nome FROM ws_cliente WHERE status NOT IN ('cancelado','desativado') AND (" . $norm('celular') . " LIKE ? OR " . $norm('telefone') . " LIKE ?) ORDER BY (titular_id IS NULL) DESC, id LIMIT 1");
        $q->execute(['%' . $fim, '%' . $fim]); $r = $q->fetch(PDO::FETCH_ASSOC);
        if ($r) { $cid = (int)$r['id']; $cnome = (string)$r['nome']; }
    } catch (Throwable $e) {}
    $ptxt = $motivo === 'pedido' ? 'Cliente pediu técnico/atendente no suporte do robô e ainda não foi identificado' : ($motivo === 'escalada' ? 'Robô não entendeu 3 respostas seguidas e passou para o atendente' : 'Fora do horário de atendimento');
    $titulo = $motivo === 'pedido' ? 'Pedido de atendimento no suporte do robô' : ($motivo === 'escalada' ? 'Atendimento pedido pelo robô (não entendeu)' : 'Atendimento fora do horário (robô)');
    $desc = "$ptxt.\nWhatsApp: $jid" . ($nome !== '' ? "\nNome informado: $nome" : '') . ($proto !== '' ? "\nProtocolo do robô: $proto" : '') . ($assunto !== '' ? "\nAssunto: $assunto" : '')
          . ($audio ? "\nO cliente falou por áudio." : '') . (trim((string)($d['relato'] ?? '')) !== '' ? "\nRelato: " . mb_substr(trim((string)$d['relato']), 0, 400) : '');
    $chId = 0; $novo = false; $pend = null;
    $trv = ws_trava_tel($db, $jid);   // um atendimento por vez por WhatsApp (sem chamado nem aviso em dobro)
    if ($cid) {
        try {
            /* QUALQUER chamado do robô ainda aberto (12 h) serve — "Sem internet (aberto pelo robô)", "Atendimento fora do horário", "Mudança de endereço (pedido pelo robô)"… —: o pedido novo entra nele,
               em vez de abrir um segundo chamado para o mesmo cliente (mesma regra de /api/conexao/chamado e ws_sup_chamado_pedido). */
            /* AGORA VALE PARA O CLIENTE, NÃO PARA O NÚMERO (13/10/2026): chamado aberto, solicitação pendente ou comprovante em conferência em QUALQUER número/cadastro do mesmo cliente (titular, adicional, mesmo CPF)
               = não abre outro nem avisa de novo; o cliente é informado e aguarda o provedor. */
            $pend = ws_pendencia_aberta($db, $cid);
            $chId = ($pend && $pend['tipo'] === 'chamado') ? (int)$pend['id'] : 0;
            if ($pend && $pend['tipo'] !== 'chamado' && function_exists('ws_evento')) { try { ws_evento($db, $cid, 'robo', 'Robô — cliente pediu atendimento de novo; já há ' . ($pend['tipo'] === 'solicitacao' ? 'a solicitação nº ' : 'um comprovante em conferência #') . (int)$pend['id'] . ' em andamento — avisei e não abri outro.'); } catch (Throwable $e) {} }
            if ($chId) {
                $msgV = 'Cliente voltou a pedir atendimento pelo robô.' . ($proto !== '' ? " Protocolo $proto." : '');
                $uV = $db->prepare("SELECT mensagem, criado_em FROM ws_chamado_msg WHERE chamado_id=? AND autor_tipo='sistema' ORDER BY id DESC LIMIT 1"); $uV->execute([$chId]); $rV = $uV->fetch(PDO::FETCH_ASSOC);
                if (!($rV && (string)$rV['mensagem'] === $msgV && time() - strtotime((string)$rV['criado_em']) < 1800)) $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, autor_tipo, mensagem) VALUES (?, 'sistema', ?)")->execute([$chId, $msgV]);   // a mesma linha não entra 2x em 30 min
            }
            elseif (!$pend) {
                if (!empty($d['sem_chamado'])) { $novo = true; }   // administrativo: só o relato (linha na ficha + nota/aviso), sem chamado
                else {
                    $db->prepare("INSERT INTO ws_chamado (cliente_id, tipo, titulo, descricao, prioridade, status) VALUES (?, 'atendimento', ?, ?, ?, 'aberto')")
                       ->execute([$cid, $titulo, $desc, preg_match('/cancel/i', $assunto) ? 'alta' : 'normal']);
                    $chId = (int)$db->lastInsertId(); $novo = true;
                }
            }
        } catch (Throwable $e) {}
    } else {   // desconhecido: não repete aviso nem linha para o mesmo número em 6 h
        $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/robo_atend.json';
        $x = json_decode((string)@file_get_contents($f), true); if (!is_array($x)) $x = [];
        foreach ($x as $k => $t) if (time() - (int)$t > 21600) unset($x[$k]);
        $k = substr(sha1($jid), 0, 16); if (isset($x[$k])) { ws_destrava_tel($db, $trv); return ['chamado' => 0, 'cliente' => null, 'novo' => false]; }   // 1 aviso por número em 6 h, qualquer que seja o motivo (pedido/escalada/fora do horário = o mesmo cliente esperando)
        $x[$k] = time(); @file_put_contents($f, json_encode($x), LOCK_EX); @chmod($f, 0640); $novo = true;
    }
    if ($novo) {
        $linha = 'Robô — ' . ($motivo === 'pedido' ? 'cliente pediu técnico no suporte (ainda sem identificar): equipe avisada' : ($motivo === 'escalada' ? 'passou para o atendente (3 respostas não entendidas)' : 'fora do horário: atendimento aberto'))
               . ($assunto !== '' ? " · $assunto" : '') . ($proto !== '' ? " · protocolo $proto" : '') . ($chId ? " · chamado #$chId" : '') . ' · WhatsApp ' . $jid . ($audio ? ' · por áudio' : '');
        if (function_exists('ws_evento')) { try { ws_evento($db, $cid, 'robo', $linha); } catch (Throwable $e) {} }
        // Aviso ao PROVEDOR (não à gerência nem aos técnicos): número do provedor; se falhar, na conversa do cliente.
        if (is_file(__DIR__ . '/aviso_provedor_lib.php')) {
            require_once __DIR__ . '/aviso_provedor_lib.php';
            $txt = ($motivo === 'pedido' ? "🙋 *Cliente pediu técnico no suporte do robô*" : ($motivo === 'escalada' ? "🤖➡️👤 *Robô pediu ajuda*" : "🌙 *Atendimento fora do horário*")) . ($chId ? " — chamado #$chId" : '') . "\n👤 " . ($cnome !== '' ? $cnome : ($nome !== '' ? "$nome (não identificado)" : 'Contato não identificado')) . "\n📱 $jid"
                 . ($assunto !== '' ? "\n📌 $assunto" : '') . ((trim((string)($d['relato'] ?? '')) !== '' && ($nA = ws_chatbot_norm($assunto)) !== ($nR = ws_chatbot_norm((string)$d['relato'])) && ($nA === '' || (strpos($nA, $nR) === false && strpos($nR, $nA) === false))) ? "\n💬 " . mb_substr(trim((string)$d['relato']), 0, 300) : '')   /* (15/10, caso Marcelo Dias) assunto e relato iguais saíam duas vezes no aviso */ . ($proto !== '' ? "\n🔖 Protocolo $proto" : '') . ($audio ? "\n🎤 Falou por áudio" : '');
            try { ws_aviso_provedor($txt, (string)$jid); } catch (Throwable $e) {}
        }
    }
    ws_destrava_tel($db, $trv);
    $pendMsg = !empty($pend) ? ws_pendencia_msg($pend, $cnome !== '' ? mb_convert_case(mb_strtolower(explode(' ', trim($cnome))[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8') : '') : '';
    return ['chamado' => $chId, 'cliente' => $cid, 'novo' => $novo, 'pendencia' => $pendMsg];
}
/* HORÁRIO DE ATENDIMENTO REAL (07/10/2026). O robô decidia "fora do horário" só pela SAUDAÇÃO ("Boa noite" = fora): sábado à tarde, domingo,
   feriado e madrugada de "bom dia" passavam como horário comercial e o cliente ouvia "já iremos lhe atender" sem ninguém lá. Agora vale
   a regra do provedor: padrão Seg–Sex 08:00–18:00, Sáb 08:00–16:00, Dom fechado, feriado fechado (nacionais fixos + Carnaval, Sexta-feira
   Santa e Corpus Christi calculados pela Páscoa). Ajustes em cache/horario_atendimento.json (entra no backup):
   {"seg_sex":["08:00","18:00"],"sab":["08:00","16:00"],"dom":null,"feriados_extra":["03/05","24/06/2026"]}  — "dd/mm" vale todo ano.
   Fuso America/Recife. ws_atendimento_aberto() → ['aberto'=>bool,'motivo'=>string]. Endpoint: POST /api/horario → {fora:"sim|nao"}. */
function ws_horario_cfg(): array {
    $def = ['seg_sex' => ['08:00', '18:00'], 'sab' => ['08:00', '16:00'], 'dom' => null, 'feriados_extra' => ['17/05', '08/12']];   // feriados locais (17/05, 08/12 — pedido 17/10/2026); Carnaval (seg e ter) já vem em ws_feriados_ano
    $f = (defined('WS_CACHE') ? WS_CACHE : __DIR__ . '/cache') . '/horario_atendimento.json';
    $c = json_decode((string)@file_get_contents($f), true);
    return is_array($c) ? array_merge($def, $c) : $def;
}
function ws_feriados_ano(int $ano): array {
    $a = $ano % 19; $b = intdiv($ano, 100); $c = $ano % 100; $d = intdiv($b, 4); $e = $b % 4; $f = intdiv($b + 8, 25); $g = intdiv($b - $f + 1, 3);
    $h = (19 * $a + $b - $d - $g + 15) % 30; $i = intdiv($c, 4); $k = $c % 4; $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7; $m = intdiv($a + 11 * $h + 22 * $l, 451);
    $mes = intdiv($h + $l - 7 * $m + 114, 31); $dia = (($h + $l - 7 * $m + 114) % 31) + 1;
    $pascoa = new DateTime(sprintf('%04d-%02d-%02d', $ano, $mes, $dia));
    $mov = fn(int $n) => (clone $pascoa)->modify(($n >= 0 ? '+' : '') . $n . ' days')->format('Y-m-d');
    $fx = ['01-01' => 'Confraternização Universal', '04-21' => 'Tiradentes', '05-01' => 'Dia do Trabalho', '09-07' => 'Independência', '10-12' => 'N. Sra. Aparecida', '11-02' => 'Finados', '11-15' => 'Proclamação da República', '12-25' => 'Natal'];
    $r = []; foreach ($fx as $md => $n) $r["$ano-$md"] = $n;
    $r[$mov(-48)] = 'Carnaval'; $r[$mov(-47)] = 'Carnaval'; $r[$mov(-2)] = 'Sexta-feira Santa'; $r[$mov(60)] = 'Corpus Christi';
    foreach ((array)(ws_horario_cfg()['feriados_extra'] ?? []) as $x) {
        $x = trim((string)$x);
        if (preg_match('#^(\d{2})/(\d{2})$#', $x, $mm)) $r["$ano-{$mm[2]}-{$mm[1]}"] = 'Feriado local';
        elseif (preg_match('#^(\d{2})/(\d{2})/(\d{4})$#', $x, $mm) && (int)$mm[3] === $ano) $r["$ano-{$mm[2]}-{$mm[1]}"] = 'Feriado local';
    }
    return $r;
}
function ws_atendimento_aberto(?int $ts = null): array {
    $agora = new DateTime('@' . ($ts ?? time())); $agora->setTimezone(new DateTimeZone('America/Recife'));
    $fer = ws_feriados_ano((int)$agora->format('Y')); $dia = $agora->format('Y-m-d');
    if (isset($fer[$dia])) return ['aberto' => false, 'motivo' => 'feriado: ' . $fer[$dia]];
    $dow = (int)$agora->format('N'); $cfg = ws_horario_cfg();
    $faixa = $dow <= 5 ? ($cfg['seg_sex'] ?? null) : ($dow === 6 ? ($cfg['sab'] ?? null) : ($cfg['dom'] ?? null));
    if (!is_array($faixa) || count($faixa) < 2) return ['aberto' => false, 'motivo' => 'dia sem atendimento'];
    $hm = $agora->format('H:i');
    return ($hm >= $faixa[0] && $hm < $faixa[1]) ? ['aberto' => true, 'motivo' => ''] : ['aberto' => false, 'motivo' => "fora da faixa {$faixa[0]}–{$faixa[1]}"];
}
/* ===== GESTOR DO "ESTOU SEM INTERNET" (08/10/2026) =====================================================================
   Antes: menu duro (nome → submenu → CPF → diagnóstico) e, à noite, "Falar com o suporte" caía no aviso de fora do horário SEM verificar
   boleto, SEM reiniciar e SEM abrir chamado técnico. Agora um agente conduz a conversa inteira, 24 h (o autoatendimento não depende de
   horário comercial; só conversar com PESSOA depende):
     1. descobre quem é pelo WhatsApp (celular/telefone do cadastro) — só pede o CPF se não achar ou se houver mais de um titular;
     2. diagnostica na hora (/api/conexao): pendência/boleto em aberto + PIX, rota presa, ONU sem sinal, offline…;
     3. entende o que o cliente diz (digitado ou áudio): reiniciar, "já reiniciei/desliguei 3 vezes", "quero um técnico", "voltou",
        liberar em confiança, paguei/PIX, menu, atendente — e EXECUTA (reconectar, chamado técnico, confiança);
     4. nunca fica preso: dúvida 3 vezes seguidas = abre o chamado técnico.
   Reaproveita os endpoints que já existem (conexao, reconectar, confianca, chamado) por chamada interna — mesmas travas e logs. */
function ws_sup_http(string $metodo, string $caminho, array $corpo = []): array {
    $ch = curl_init('https://127.0.0.1/api/' . ltrim($caminho, '/'));
    $h = ['Host: ' . (string)($_SERVER['HTTP_HOST'] ?? 'localhost'), 'Content-Type: application/json', 'Authorization: ' . ws_chatbot_header_auth()];
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 70, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => $h, CURLOPT_CUSTOMREQUEST => $metodo]);
    if ($metodo !== 'GET') curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($corpo, JSON_UNESCAPED_UNICODE));
    $r = curl_exec($ch); curl_close($ch);
    $j = json_decode((string)$r, true);
    return is_array($j) ? $j : [];
}
/** Titulares ativos cujo celular/telefone termina igual ao número do WhatsApp (últimos 9 dígitos). Devolve [['cpf','nome','id'],…] sem repetir CPF. */
function ws_sup_clientes_por_whats(PDO $db, string $jid): array {
    $fim = substr(preg_replace('/\D/', '', $jid), -8); if (strlen($fim) < 8) return [];   // 8 últimos: o WhatsApp antigo vem SEM o 9º dígito (5581 9596 4040) e o cadastro COM (81 99596 4040)
    $norm = fn($c) => "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE($c,' ',''),'-',''),'(',''),')',''),'+','')";
    $out = [];
    try {
        $q = $db->prepare("SELECT id, nome, cpf_cnpj FROM ws_cliente WHERE status NOT IN ('cancelado','desativado') AND COALESCE(cpf_cnpj,'')<>'' AND (" . $norm('celular') . " LIKE ? OR " . $norm('telefone') . " LIKE ?) ORDER BY (titular_id IS NULL) DESC, id LIMIT 8");
        $q->execute(['%' . $fim, '%' . $fim]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $d = preg_replace('/\D/', '', (string)$r['cpf_cnpj']); if (strlen($d) >= 11 && !isset($out[$d])) $out[$d] = ['cpf' => $d, 'nome' => (string)$r['nome'], 'id' => (int)$r['id']]; }
    } catch (Throwable $e) {}
    return array_values($out);
}
/** Titulares ativos achados pelo NOME dito/escrito ("escola paulo freire continua sem internet"): ignora palavras de conversa e exige TODAS as demais no nome. Até 5, sem repetir CPF. */
function ws_sup_clientes_por_nome(PDO $db, string $texto): array {
    $ruido = ' de da do dos das a o e os as minha meu sou aqui continua continuo sem internet net caiu lenta nao esta ta ainda ja bom dia tarde noite oi ola preciso favor por pra para com cliente sinal wifi estou funciona funcionando voltou problema cadastro nome titular em na no um uma la ai ate quando desde ontem hoje mais muito toda hora fora ar parou queda ruim ';
    $tok = []; foreach (explode(' ', ws_chatbot_norm($texto)) as $w) if (strlen($w) >= 3 && strpos($ruido, ' ' . $w . ' ') === false) $tok[$w] = $w;
    $tok = array_slice(array_values($tok), 0, 4); if (!$tok) return [];
    $out = [];
    try {
        $sql = "SELECT nome, cpf_cnpj FROM ws_cliente WHERE status NOT IN ('cancelado','desativado') AND COALESCE(cpf_cnpj,'')<>''" . str_repeat(' AND nome LIKE ?', count($tok)) . ' ORDER BY (titular_id IS NULL) DESC, id LIMIT 12';
        $q = $db->prepare($sql); $q->execute(array_map(fn($w) => '%' . $w . '%', $tok));
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $d = preg_replace('/\D/', '', (string)$r['cpf_cnpj']); if (strlen($d) >= 11 && !isset($out[$d])) $out[$d] = ['cpf' => $d, 'nome' => (string)$r['nome']]; }
    } catch (Throwable $e) {}
    return count($tok) === 1 && count($out) > 5 ? [] : array_slice(array_values($out), 0, 5);
}
/** O que o cliente quer: reconectar | chamado | confianca | resolvido | menu | humano | comprovante | pix | '' (não entendi). Palavras primeiro; IA só na dúvida. */
function ws_sup_intencao(string $texto, string $situacao = ''): string {
    $t = trim(preg_replace('/[\x{FE0F}\x{20E3}]/u', '', $texto)); if ($t === '') return '';   // "3️⃣" (emoji) vale como "3"
    /* 12/10/2026: bloqueado por pendência NÃO oferece reiniciar nem chamado técnico — as opções são 1 = boleto, 2 = confiança (o 3 NÃO vale — ver abaixo). */
    /* (16/10/2026, caso Eduarda Clécia — GRAVE) bloqueado: só 1 e 2 existem. O "3" antigo liberava em confiança e liberou quem digitou 3 sem querer: agora 3 NÃO é opção (o robô pede de novo). Liberar em confiança só com o 2 ou pedido escrito claro ("liberar em confiança"). */
    if (preg_match('/^\s*([1-3])\s*$/', $t, $m)) return $situacao === 'bloqueado' ? ['1' => 'boleto', '2' => 'confianca', '3' => ''][$m[1]] : ['1' => 'reconectar', '2' => 'chamado', '3' => ''][$m[1]];   // conectado: só 1 e 2 existem ("3" = liberar em confiança não faz sentido sem bloqueio)
    // Bug Rogério (13/10/2026): "7" (opção falar com atendente do menu principal) digitada dentro do Suporte IA não era reconhecida — o robô só aceitava 1, 2 ou 3. Agora "7" e textos equivalentes redirecionam para humano.
    if (preg_match('/^\s*7\s*$/', $t)) return 'humano';
    $n = ' ' . ws_chatbot_norm($t) . ' ';
    if (preg_match('/ (atendente|humano|pessoa|falar com|atendimento humano|quero atendente) /', $n)) return 'humano';
    // trocar senha / nome / canal do Wi-Fi (ACS embutido) — antes do resto para "trocar a senha do wifi" não virar chamado (08/10/2026)
    if (preg_match('/ (troc|mud|alter|coloc|redefin|esquec|quer\w* (troc|mud|alter))\w* .*(senha|nome|canal|wi ?fi|wifi)| (senha|nome|canal) (d[oa] )?(wi ?fi|wifi|rede|internet) |esqueci a senha/', $n)) return 'wifi';
    // já tentou / continua sem / quer técnico → chamado (NUNCA mandar reiniciar de novo quem diz que já reiniciou)
    if (preg_match('/ ja (reinici|deslig|religu|tent|fiz|troquei|testei)| (reiniciei|desliguei|religuei|reiniciamos|tentei|testei)|(reinici|deslig|religu)\w* (varias|duas|tres|quatro|cinco|\d+) vez|continua sem|continuo sem|ainda (sem|nao)|nao (voltou|resolveu|funcion|normaliz|volta)|nada resolve|ninguem resolve|tecnic|visita| vir (aqui|ai|em casa|na minha|ate)|venha| mandar alguem|mandem alguem|abrir (um )?chamado| chamado /', $n)) return 'chamado';
    /* (15/10, caso Gessica Thais: "meu celular pega internet, mas a televisão não quer conectar") problema em UM aparelho/app enquanto a internet funciona em outro = ORIENTAR (passo a passo do aparelho), não reiniciar a conexão nem abrir chamado de cara. */
    if (preg_match('/ (tv|televisao|smart tv|tv box|tvbox|chromecast|fire stick|firestick|roku|notebook|computador|pc|playstation|ps4|ps5|xbox|video game|videogame|camera|impressora|alexa|tablet|ipad) .{0,45}(nao|n) (esta |ta |tá )?(querendo |consegue |conecta|pega|funciona|abre|carrega|entra|acha|encontra)/', $n) && !preg_match('/ (sem internet|internet caiu|caiu a internet|tudo sem|nenhum aparelho|nada funciona|nada pega) /', $n)) return 'orientar';
    if (preg_match('/ (reconect|reinici|reset|religa|ligar de novo|derrub|tentar de novo|tenta de novo)/', $n)) return 'reconectar';
    if (preg_match('/ (confianca|liber|desbloque|destrav) /', $n)) return 'confianca';
    if (preg_match('/ (voltou|funcionou|normalizou|resolveu|resolvido|esta funcionando|ta funcionando|tudo certo|deu certo|ja voltou) /', $n) || preg_match('/^ (obrigad[oa]|valeu|ok|blz) /', $n)) return 'resolvido';
    if (preg_match('/ (comprovante|paguei|ja paguei|pagamento feito) /', $n)) return 'comprovante';
    if (preg_match('/ (segunda via|2 via|2a via|2o via|boleto|fatura|codigo de barras) /', $n) && !preg_match('/ pix /', $n)) return 'boleto';   // 12/10/2026: boleto tem resposta própria (baixa em até 2 dias úteis); antes caía no PIX
    if (preg_match('/ (pix|pagar|pagamento) /', $n)) return 'pix';
    if (preg_match('/^ (menu|voltar|inicio|sair) /', $n)) return 'menu';
    /* PEDIDO FORA DA ALÇADA DO ROBÔ (12/10/2026, caso José Eduardo): equipamento extra/comodato/repetidor, mudança de endereço, instalação nova → atendimento humano com chamado */
    if (preg_match('/ (comodato|repetidor|extensor|mesh|outro roteador|roteador (novo|extra|outro|adicional|a mais)|mais um roteador|ponto (extra|adicional)|mudanca de endereco|mudar de endereco|mudanca de local|transferencia de endereco|transferir (a |minha |essa |esta )?(internet|ponto|plano|contrato)|levar (a |minha |essa |esta )?internet|levar (o |meu |esse )?(ponto|plano|contrato)|mudar (a |minha |essa )?internet|novo endereco|outro endereco|outra casa|nova casa|vou me mudar|estou me mudando|me mudando|me mudar|me mudei|instalar (a |o |uma |um )?(internet|ponto|roteador)|nova instalacao) /', $n)) return 'outro';
    if (preg_match('/ (atendente|humano|pessoa|alguem|falar com)/', $n) && !preg_match('/ suporte /', $n)) return 'humano';
    if (preg_match('/ suporte /', $n)) return 'chamado';
    $ia = ws_sup_ia_intencao($t, $situacao);
    /* (16/10/2026) liberar em confiança só por PEDIDO CLARO: a IA não decide isso sozinha para quem está bloqueado (frase vaga virava desbloqueio). */
    /* (16/10/2026) bloqueado por pendência: verificar → mostrar boleto/confiança; chamado técnico NÃO nasce de frase vaga ("quero minha internet de volta") — só depois do procedimento ou com pedido escrito de chamado/técnico/visita. */
    if ($ia === 'chamado' && $situacao === 'bloqueado' && !preg_match('/ (chamado|tecnic[oa]|visita|suporte) /', $n)) return '';
    if ($ia === 'confianca' && $situacao === 'bloqueado' && !preg_match('/ (confianca|liber|desbloque|destrav) /', $n)) return '';
    return $ia;
}
/** ORIENTAÇÃO DO APARELHO (15/10/2026): a internet do cliente está ATIVA (diagnóstico feito) e o problema é de UM aparelho/app. A IA (gpt-4o-mini, resposta curta) dá o passo a passo daquele aparelho em linguagem simples, sem prometer
 *  técnico nem pedir dados. Só o texto do cliente vai à OpenAI. Sem chave/erro: roteiro padrão (TV/aparelho). Devolve o texto (sem a oferta de chamado — quem chama acrescenta). */
function ws_sup_orientar(string $texto, string $nome = ''): string {
    $padrao = "Como a internet está chegando normalmente (o celular usa), o problema parece ser só desse aparelho. Tente nesta ordem:\n\n1️⃣ No aparelho, abra as configurações de *Wi-Fi/rede* e confira se ele está ligado na rede da sua casa (a senha é a mesma do celular).\n2️⃣ Se estiver conectado e sem internet: *desconecte da rede e conecte de novo* (em alguns aparelhos é \"esquecer rede\" e digitar a senha outra vez).\n3️⃣ *Desligue o aparelho da tomada por 1 minuto* e ligue de novo.\n4️⃣ Se ele estiver longe do roteador, aproxime ou use o cabo de rede, se tiver.";
    $key = ws_chatbot_openai_key(); if ($key === '' || trim($texto) === '') return $padrao;
    $sis = "Você é o atendente de suporte de um provedor de internet, falando no WhatsApp com um cliente leigo. A conexão do cliente JÁ foi verificada e está ATIVA. Ele relata problema em UM aparelho ou aplicativo específico (por exemplo TV, notebook, videogame, câmera) enquanto outro aparelho (celular) funciona. "
         . "Responda em português do Brasil, simples e acolhedor, SEM saudação e SEM repetir a pergunta. Comece em uma frase dizendo que a internet está chegando bem e que o problema parece ser só desse aparelho. Depois dê de 3 a 5 passos PRÁTICOS e curtos, numerados (1️⃣ 2️⃣ 3️⃣…), específicos para o aparelho citado: "
         . "conferir se está ligado na rede Wi-Fi certa; desconectar e conectar de novo / esquecer a rede e digitar a senha; reiniciar o aparelho (tirar da tomada 1 min); aproximar do roteador ou usar cabo; em TV/box conferir data e hora e atualizar o aplicativo; se o aparelho for antigo, testar a rede de 2,4 GHz. "
         . "NÃO peça CPF, senha nem dados pessoais; NÃO mande reiniciar nem trocar o roteador; NÃO prometa técnico, prazo ou visita; NÃO invente marcas ou menus que você não conhece — diga o caminho de forma geral (Configurações → Rede/Wi-Fi). No máximo 900 caracteres. Não termine oferecendo atendimento (isso é acrescentado depois).";
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => 'gpt-4o-mini', 'temperature' => 0.3, 'max_tokens' => 380,
            'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => mb_substr($texto, 0, 500)]]], JSON_UNESCAPED_UNICODE)]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return $padrao;
    $t = trim((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''));
    if ($t === '' || mb_strlen($t) < 40) return $padrao;
    return mb_substr($t, 0, 1100);
}
function ws_sup_ia_intencao(string $texto, string $situacao): string {
    $key = ws_chatbot_openai_key(); if ($key === '') return '';
    $sis = "Você entende o que um cliente de provedor de internet quer, no WhatsApp, quando está SEM INTERNET. Responda só JSON {\"i\":\"...\"} com UM destes: "
         . "orientar (diz que a internet funciona em um aparelho mas UM aparelho/app específico — TV, notebook, videogame, câmera — não conecta ou não funciona: precisa de orientação, não de reinício), reconectar (quer que o robô reinicie/reconecte a internet), chamado (quer técnico/visita/abrir chamado, ou diz que já tentou e continua sem), confianca (quer liberar em confiança), "
         . "resolvido (voltou, funcionou, agradeceu), comprovante (já pagou/tem comprovante), pix (quer pagar/PIX), boleto (quer o boleto/2ª via), menu (voltar ao início), humano (quer falar com atendente), "
         . "outro (pede algo que NÃO é consertar a internet nem pagar: ganhar/instalar equipamento extra, comodato, repetidor, mudança de endereço, instalação nova, contrato, dúvida comercial — "
         . "NUNCA use outro para lentidão, queda, roteador/wi-fi com problema ou sem internet: isso é reconectar ou chamado), "
         . "ou vazio se não der para saber. Em dúvida entre reconectar e chamado, se o cliente diz que JÁ reiniciou, é chamado.";
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['model' => 'gpt-4o-mini', 'temperature' => 0, 'max_tokens' => 20, 'response_format' => ['type' => 'json_object'],
            'messages' => [['role' => 'system', 'content' => $sis], ['role' => 'user', 'content' => "Situação da conexão: " . ($situacao ?: '—') . "\nMensagem do cliente: " . mb_substr($texto, 0, 400)]]])]);
    $r = curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($c !== 200) return '';
    $j = json_decode((string)(json_decode((string)$r, true)['choices'][0]['message']['content'] ?? ''), true);
    $i = trim((string)($j['i'] ?? ''));
    return in_array($i, ['orientar', 'reconectar', 'chamado', 'confianca', 'resolvido', 'comprovante', 'pix', 'boleto', 'menu', 'humano', 'outro'], true) ? $i : '';
}

/** Áudio do passo de SUPORTE (12/10/2026, caso José Eduardo): o /api/audio não transcreve áudio com mais de 75 s (modo econômico) e o suporte respondia "não consegui ouvir".
 *  Aqui o áudio de quem está sendo atendido vale até 180 s (mesmo teto mensal e mesmo contador de uso). Recebe a referência "audioMessage|id". Devolve a fala ou ''. */
function ws_sup_audio_texto(string $marcador, array $b): string {
    if (!preg_match('/^audioMessage\|(\S+)/', trim($marcador), $ma) || ws_chatbot_openai_key() === '') return '';
    $srv = (string)($b['serverUrl'] ?? ''); $key = (string)($b['apiKey'] ?? ''); $inst = (string)($b['instanceName'] ?? '');
    if ($srv === '' || $key === '' || strpos($srv . $key . $inst, '{{') !== false) {
        if (!function_exists('ws_wa_config') && is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_wa_config')) { $wc = ws_wa_config(); $srv = (string)$wc['url']; $key = (string)$wc['apikey']; if ($inst === '' || strpos($inst, '{{') !== false) $inst = (string)$wc['instance']; }
    }
    $aud = ws_chatbot_audio_baixar($ma[1], $inst, $srv, $key); if (!$aud) return '';
    $seg = (int)ceil(strlen($aud[0]) / 2000); if ($seg > 180) return '';
    $teto = max(0, (int)(ws_chatbot_cfg()['audio_teto_min'] ?? 1000));
    $uf = WS_CACHE . '/audio_uso.json'; $uso = json_decode((string)@file_get_contents($uf), true) ?: [];
    if (($uso['mes'] ?? '') !== date('Y-m')) $uso = ['mes' => date('Y-m'), 'seg' => 0, 'qtd' => 0];
    if ($teto > 0 && ($uso['seg'] + $seg) > $teto * 60) return '';
    $err = ''; $fala = ws_chatbot_transcrever($aud[0], $aud[1] ?: 'audio/ogg', $err);
    if ($fala !== '') { $uso['seg'] += $seg; $uso['qtd']++; @file_put_contents($uf, json_encode($uso)); @chmod($uf, 0640); ws_audio_guardar((string)($b['remoteJid'] ?? ''), $fala, 'suporte'); }
    return $fala;
}

/** O QUE O CLIENTE DISSE ANTES DE ENTRAR NO SUPORTE (12/10/2026, caso Nailma Cristina): "estamos sem internet" abre o suporte, mas o texto não vinha na chamada — se o cliente não era
 *  identificado e desistia (disse "menu"), o relato se perdia e o aviso ao provedor saía só com "Falar com Atendente". Lê a fala mais recente (últimos 10 min) guardada pelo webhook da Evolution. */
function ws_sup_relato_inicial(string $jid): string {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); if ($d === '') return '';
    $u = json_decode((string)@file_get_contents(ws_midia_dir() . '/ult_' . sha1($d) . '.json'), true); if (!is_array($u)) return '';
    $melhor = '';
    foreach ((array)($u['hist'] ?? []) as $h) {
        if (!is_array($h) || time() - (int)($h[0] ?? 0) > 600) continue;
        $t = trim((string)($h[1] ?? ''));
        if (mb_strlen($t) >= 8 && !preg_match('/^\s*(menu|voltar|sair|inicio|início)\s*$/iu', $t) && !preg_match('/^[\d\s.\/-]{6,}$/', $t)) $melhor = $t;   // a mais recente que é um relato (não menu nem só números)
    }
    return mb_substr($melhor, 0, 480);
}
/** Relato guardado na sessão do suporte (até 3 h), para o aviso do atendimento humano. */
function ws_sup_relato_sessao(string $jid): string {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); if ($d === '') return '';
    $todas = json_decode((string)@file_get_contents(WS_CACHE . '/suporte_relato.json'), true); if (!is_array($todas)) return '';
    $e = $todas[substr(sha1($d), 0, 16)] ?? null;
    return is_array($e) && time() - (int)($e['em'] ?? 0) <= 10800 ? (string)($e['t'] ?? '') : '';
}
function ws_sup_relato_guardar(string $jid, string $texto): void {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); $texto = trim($texto); if ($d === '' || $texto === '') return;
    $arq = WS_CACHE . '/suporte_relato.json'; $todas = json_decode((string)@file_get_contents($arq), true); if (!is_array($todas)) $todas = [];
    foreach ($todas as $k => $v) if (time() - (int)($v['em'] ?? 0) > 10800) unset($todas[$k]);
    $todas[substr(sha1($d), 0, 16)] = ['t' => mb_substr($texto, 0, 480), 'em' => time()];
    @file_put_contents($arq, json_encode($todas)); @chmod($arq, 0640);
}

/** A fala mais recente do cliente (últimos $seg segundos), guardada pelo webhook da Evolution. */
function ws_sup_ultima_fala(string $jid, int $seg = 180): string {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); if ($d === '') return '';
    $u = json_decode((string)@file_get_contents(ws_midia_dir() . '/ult_' . sha1($d) . '.json'), true); if (!is_array($u)) return '';
    $h = (array)($u['hist'] ?? []); $x = end($h);
    return is_array($x) && time() - (int)($x[0] ?? 0) <= $seg ? trim((string)($x[1] ?? '')) : '';
}
/** Legenda da imagem/arquivo que o cliente acabou de mandar (a última mensagem dele é mídia e a legenda foi gravada junto, no mesmo instante). '' se não houve legenda. */
function ws_sup_legenda(string $jid): string {
    $d = preg_replace('/\D/', '', explode('@', $jid)[0]); if ($d === '') return '';
    $u = json_decode((string)@file_get_contents(ws_midia_dir() . '/ult_' . sha1($d) . '.json'), true);
    if (!is_array($u) || ($u['tipo'] ?? 'texto') === 'texto' || time() - (int)($u['em'] ?? 0) > 180) return '';
    $h = (array)($u['hist'] ?? []); $x = end($h);
    if (!is_array($x) || (int)($x[0] ?? 0) < (int)$u['em'] - 3) return '';   // a legenda tem que ser da própria mídia, não uma fala antiga
    $t = trim((string)($x[1] ?? '')); return mb_strlen($t) >= 4 && !preg_match('/^\d{1,2}$/', $t) ? $t : '';
}
/** DEPOIS DO ATENDIMENTO ABERTO (12/10/2026, caso Karolyna): o cliente que pediu atendente (fora do horário) e escreve "minha net não tá funcionando" não deve ouvir só "gostaria de adicionar
 *  mais alguma informação?" — problema de internet vai ao SUPORTE INTELIGENTE (24 h: verifica a conexão, reinicia, abre chamado técnico). Outros pedidos seguem para o atendimento humano.
 *  Devolve 'suporte' ou 'continuar'. */
function ws_sup_pos_atendimento_acao(string $jid): string {
    for ($k = 0; $k < 6; $k++) { $t = ws_sup_ultima_fala($jid); if ($t !== '' && !preg_match('/^\d{1,2}$/', $t)) break; usleep(400000); }   // o webhook da Evolution corre junto com o fluxo: espera a fala aparecer (até ~2,4 s)
    if (mb_strlen($t) < 4 || preg_match('/^\w+Message\|/', $t)) return 'continuar';
    if (ws_chatbot_sem_internet($t)) return 'suporte';
    return in_array(ws_sup_intencao($t, ''), ['reconectar', 'chamado', 'confianca', 'wifi'], true) ? 'suporte' : 'continuar';
}

/** TEXTO PADRÃO do pedido que fica para o atendimento humano (o mesmo que o fluxo mostrava fixo). */
function ws_sup_msg_humano(string $proto = ''): string {
    return "✅ Recebi sua solicitação.\nPara esse tipo de solicitação é necessário o *atendimento humano*: ela já ficou anexada ao seu chamado" . ($proto !== '' ? " (protocolo *$proto*)" : '') . " e, assim que possível, nossa equipe entrará em contato com você. 🙏\n\nSe quiser acrescentar mais alguma informação, é só escrever.";
}
/** PEDIDO DE RECIBO (12/10/2026, caso Ivanildo, bloqueado): o robô respondia "precisa de atendimento humano". Recibo só existe depois de pagamento confirmado: ele diz se há boleto em aberto e que,
 *  se já pagou, é só enviar o comprovante — o recibo vai depois da conferência. Cliente em dia: informa o último pagamento. Não identificado: orientação geral. */
function ws_sup_msg_recibo(PDO $db, string $jid, string $proto = '', bool $soComprovante = false): string {
    $fecho = $proto !== '' ? "\n\n🙏 Seu pedido ficou anexado ao chamado (protocolo *$proto*) e a equipe acompanha assim que possível." : '';
    $enviar = "✅ Se você *já pagou*, envie o *comprovante* (foto ou PDF) aqui na conversa.\nDepois da *conferência*, o recibo é enviado automaticamente para este WhatsApp.";
    $ach = ws_sup_clientes_por_whats($db, $jid);
    if (!$ach) return ($soComprovante ? '' : "🧾 O *recibo* só é emitido depois que o pagamento é confirmado.\n\n") . $enviar . $fecho;
    $cid = (int)$ach[0]['id']; $nome = mb_convert_case(mb_strtolower(explode(' ', trim((string)$ach[0]['nome']))[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
    try {
        $ids = [$cid]; foreach ($db->query("SELECT id FROM ws_cliente WHERE titular_id=" . $cid)->fetchAll(PDO::FETCH_COLUMN) as $a) $ids[] = (int)$a; $in = implode(',', $ids);
        $bloq = (string)$db->query("SELECT status FROM ws_cliente WHERE id=" . $cid)->fetchColumn() === 'bloqueado';
        $ab = $db->query("SELECT * FROM ws_fatura WHERE cliente_id IN ($in) AND status IN ('aberto','vencido','processando') AND vencimento <= CURDATE() ORDER BY vencimento, id LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
        if ($ab) {
            $lin = ''; foreach ($ab as $f) $lin .= "\n• *R$ " . number_format((float)(function_exists('ws_fatura_valor_cobrado') ? ws_fatura_valor_cobrado($f) : $f['valor']), 2, ',', '.') . '* — venc. ' . date('d/m/Y', strtotime((string)$f['vencimento']));
            return "🧾 $nome, o *recibo* só é emitido depois que o pagamento é confirmado.\n\n📌 Você tem " . (count($ab) > 1 ? 'boletos' : 'boleto') . " em aberto:$lin\n\n" . $enviar
                 . ($bloq ? "\n\n🔒 Sua internet está bloqueada por pendência; quando o pagamento for confirmado, a liberação é automática." : '') . $fecho;
        }
        $pg = $db->query("SELECT data_pagamento, valor_pago, valor FROM ws_fatura WHERE cliente_id IN ($in) AND status='pago' ORDER BY data_pagamento DESC, id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        if ($pg) return "🧾 $nome, não há boleto vencido em aberto no seu cadastro. Seu último pagamento foi em *" . date('d/m/Y', strtotime((string)$pg['data_pagamento'])) . "* (R$ " . number_format((float)($pg['valor_pago'] ?: $pg['valor']), 2, ',', '.') . ") e o recibo é enviado automaticamente para este WhatsApp quando o pagamento é confirmado.\n\n"
                      . "✅ Se não recebeu, a equipe confere e reenvia." . $fecho;
    } catch (Throwable $e) {}
    return ($soComprovante ? '' : "🧾 $nome, o *recibo* só é emitido depois que o pagamento é confirmado.\n\n") . $enviar . $fecho;
}
/** O que fazer com a fala do cliente DEPOIS de o atendimento ser aberto: ['acao' => 'suporte'|'recibo'|'comprovante'|'continuar', 'mensagem' => texto que o fluxo mostra]. */
function ws_sup_pos_atendimento(string $jid, string $proto = ''): array {
    $acao = ws_sup_pos_atendimento_acao($jid); $def = ws_sup_msg_humano($proto);
    if ($acao === 'suporte') return ['acao' => 'suporte', 'mensagem' => $def];
    $t = ws_sup_ultima_fala($jid); $n = ' ' . ws_chatbot_norm($t) . ' ';
    try {
        $db = ws_db();
        if (preg_match('/ (recibo|comprovante de pagamento|comprovante do pagamento|comprovante de pagto) /', $n) && !preg_match('/ (enviar|mandar|segue|em anexo|enviei|mandei|envio) /', $n)) return ['acao' => 'recibo', 'mensagem' => ws_sup_msg_recibo($db, $jid, $proto)];
        /* "ALGUM RETORNO?" (14/10/2026): cliente com chamado/solicitação/comprovante em aberto perguntando pelo andamento recebe o STATUS dele (número, desde quando), não o texto genérico de "atendimento humano". */
        if (preg_match('/ (retorno|novidade|novidades|previsao|andamento|status|noticia|noticias|resposta|alguem (vai|vem|ja)|ja (vem|vieram|viram|resolveram)|quando (vem|vao|vai)|e ai|cade|nada ainda|ainda nada|alguma coisa) /', $n) || preg_match('/ (algum|alguma) (retorno|novidade|resposta|previsao) /', $n)) {
            $ach0 = ws_sup_clientes_por_whats($db, $jid);
            if ($ach0) { $pd = ws_pendencia_aberta($db, (int)$ach0[0]['id']); if ($pd) return ['acao' => 'status', 'mensagem' => ws_pendencia_msg($pd, mb_convert_case(mb_strtolower(explode(' ', trim((string)$ach0[0]['nome']))[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8'))]; }
        }
        if (ws_sup_intencao($t, '') === 'comprovante') return ['acao' => 'comprovante', 'mensagem' => ws_sup_msg_recibo($db, $jid, $proto, true)];
    } catch (Throwable $e) {}
    /* PEDIDO QUE TEM MENU (14/10/2026): fora do horário o cliente escrevia "Mande o Pix" / "quero o boleto" e recebia "precisa de atendimento humano". Pedido que o robô PODE atender vai para o MENU certo
       (desvio_opcao → grupo "Desvio global" do fluxo): 2 = boleto, 3 = PIX, 6 = central, 8 = comprovante. Atendente (7), cancelamento (4), cadastro (5) e sair (9) NÃO desviam por aqui. */
    try {
        $dv = ws_chatbot_desvio($t, '', ['tipo' => 'menu', 'opcoes' => '', 'menu_principal' => '']);
        if (in_array($dv, ['2', '3', '6', '8'], true)) return ['acao' => 'menu', 'mensagem' => $def, 'desvio_opcao' => $dv];
    } catch (Throwable $e) {}
    return ['acao' => 'continuar', 'mensagem' => $def];
}

/** PEDIDO QUE O ROBÔ NÃO RESOLVE (12/10/2026): abre (ou reaproveita) o chamado do cliente com o que ele pediu e avisa o provedor.
 *  Cliente que JÁ tem chamado aberto (enquanto estiver aberto — fechado libera abrir outro) não ganha outro: o pedido novo entra como mensagem no chamado existente e o robô avisa que já está aberto.
 *  Devolve ['chamado'=>id, 'existia'=>bool, 'desde'=>'dd/mm HH:MM', 'nome'=>primeiro nome] ou ['chamado'=>0] quando não acha o cadastro. */
function ws_sup_chamado_pedido(PDO $db, string $jid, string $texto, string $proto = ''): array {
    $trv = ws_trava_tel($db, $jid);   // um pedido por vez por WhatsApp: o 2º encontra o chamado do 1º e só anexa
    try { return ws_sup_chamado_pedido_i($db, $jid, $texto, $proto); } finally { ws_destrava_tel($db, $trv); }
}
function ws_sup_chamado_pedido_i(PDO $db, string $jid, string $texto, string $proto = ''): array {
    $jid = preg_replace('/\D/', '', explode('@', $jid)[0]); $texto = trim(preg_replace('/\s+/', ' ', $texto));
    $ach = $jid !== '' ? ws_sup_clientes_por_whats($db, $jid) : [];
    if (!$ach) return ['chamado' => 0];
    $cid = (int)$ach[0]['id']; $nome = (string)$ach[0]['nome'];
    try {
        $pend = ws_pendencia_aberta($db, $cid);   // chamado/solicitação/comprovante em QUALQUER número do mesmo cliente
        if ($pend && $pend['tipo'] !== 'chamado') {
            if (function_exists('ws_evento')) { try { ws_evento($db, $cid, 'robo', 'Robô — cliente pediu atendimento de novo; já há ' . ($pend['tipo'] === 'solicitacao' ? 'a solicitação nº ' : 'um comprovante em conferência #') . (int)$pend['id'] . ' — avisei, não abri chamado.'); } catch (Throwable $e) {} }
            return ['chamado' => 0, 'pend_msg' => ws_pendencia_msg($pend, mb_convert_case(mb_strtolower(explode(' ', trim($nome))[0], 'UTF-8'), MB_CASE_TITLE, 'UTF-8'))];
        }
        $ex = $pend ? ['id' => $pend['id'], 'criado_em' => (string)$pend['criado']] : null;
        if ($ex) {
            if ($texto !== '') $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, usuario_id, autor_tipo, mensagem) VALUES (?, NULL, 'cliente', ?)")->execute([(int)$ex['id'], mb_substr($texto, 0, 1500)]);
            if (function_exists('ws_evento')) { try { ws_evento($db, $cid, 'robo', 'Robô — cliente pediu atendimento de novo; já existe o chamado #' . (int)$ex['id'] . ' aberto, avisei e agradeci o contato' . ($texto !== '' ? ': "' . mb_substr($texto, 0, 100) . '"' : '') . '.'); } catch (Throwable $e) {} }
            return ['chamado' => (int)$ex['id'], 'existia' => true, 'desde' => date('d/m H:i', strtotime((string)$ex['criado_em'])), 'nome' => $nome];
        }
        $db->prepare("INSERT INTO ws_chamado (cliente_id, tipo, titulo, descricao, prioridade, status) VALUES (?, 'atendimento', ?, ?, 'normal', 'aberto')")
           ->execute([$cid, 'Solicitação pedida ao robô (precisa de atendimento humano)', "Pedido fora da alçada do robô.\nWhatsApp: $jid" . ($proto !== '' ? "\nProtocolo do robô: $proto" : '') . ($texto !== '' ? "\nO cliente disse: " . mb_substr($texto, 0, 500) : '')]);
        $chId = (int)$db->lastInsertId();
        /* (15/10, caso Samuel: transferência de endereço ficou como 'atendimento' genérico) a fala já era gravada AQUI antes de chamar a IA, e a IA via "fala repetida" e saía sem classificar: o tipo nunca virava mudança de endereço/instalação.
           Agora a IA classifica PRIMEIRO (e grava a fala); só se ela não gravar (texto curto) a fala entra aqui. */
        $anx = null; if (function_exists('ws_chamado_robo_anexar') && $texto !== '') { try { $anx = ws_chamado_robo_anexar($db, $jid, $texto); } catch (Throwable $e) {} }
        if ($texto !== '' && !$anx) $db->prepare("INSERT INTO ws_chamado_msg (chamado_id, usuario_id, autor_tipo, mensagem) VALUES (?, NULL, 'cliente', ?)")->execute([$chId, mb_substr($texto, 0, 1500)]);
        if (function_exists('ws_evento')) { try { ws_evento($db, $cid, 'robo', 'Robô — pedido fora da alçada dele: abri o chamado #' . $chId . ' para o atendimento humano' . ($texto !== '' ? ': "' . mb_substr($texto, 0, 100) . '"' : '') . '.'); } catch (Throwable $e) {} }
        $tt = $db->prepare("SELECT titulo FROM ws_chamado WHERE id=?"); $tt->execute([$chId]); $jaAvisou = (string)$tt->fetchColumn() !== 'Solicitação pedida ao robô (precisa de atendimento humano)';   // se a IA já trocou o tipo, ws_chamado_robo_anexar avisou o provedor: não avisa duas vezes (cada mensagem custa)
        if (!$jaAvisou && is_file(__DIR__ . '/aviso_provedor_lib.php')) { require_once __DIR__ . '/aviso_provedor_lib.php'; try { ws_aviso_provedor("🙋 *Pedido para o atendimento humano* — chamado #$chId\n👤 $nome\n💬 " . ($texto !== '' ? mb_substr($texto, 0, 300) : 'sem texto') . "\nO robô avisou o cliente que entraremos em contato.", $jid, ''); } catch (Throwable $e) {} }
        return ['chamado' => $chId, 'existia' => false, 'nome' => $nome];
    } catch (Throwable $e) { return ['chamado' => 0]; }
}

/** Texto sem acento, minúsculo, só letras/números/espaço. */
function ws_chatbot_norm(string $t): string {
    $t = mb_strtolower($t, 'UTF-8');
    $t = strtr($t, ['á'=>'a','à'=>'a','â'=>'a','ã'=>'a','é'=>'e','ê'=>'e','í'=>'i','ó'=>'o','ô'=>'o','õ'=>'o','ú'=>'u','ü'=>'u','ç'=>'c','º'=>'o','ª'=>'a']);
    return trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z0-9 ]/', ' ', $t)));
}

/** Palavras-chave canônicas de uma frase (sinônimos do atendimento de provedor). */
function ws_chatbot_chaves(string $t): array {
    $t = ' ' . ws_chatbot_norm($t) . ' ';
    $sin = [
        'boleto'      => ['boleto', 'fatura', 'segunda via', '2 via', '2o via', '2a via', 'conta', 'mensalidade', 'codigo de barra'],
        'pix'         => ['pix', 'pagar', 'pagamento', 'qr code', 'qrcode', 'chave'],
        'internet'    => ['internet', 'sem net', 'net ', 'conexao', 'sinal', 'caiu', 'lenta', 'lento', 'nao funciona', 'nao pega', 'wifi', 'roteador', 'suporte', 'tecnico', 'reconect', 'reinici', 'religa'],
        'atendente'   => ['atendente', 'atendimento', 'humano', 'pessoa', 'falar com', 'conversar'],
        'cancelar'    => ['cancelar', 'cancelamento', 'cancela', 'desistir'],
        'cliente'     => ['ser cliente', 'contratar', 'assinar', 'instalar', 'instalacao', 'quero internet', 'novo cliente', 'nosso cliente', 'plano', 'planos'],
        'central'     => ['central', 'assinante', 'aplicativo', 'app'],
        'comprovante' => ['comprovante', 'paguei', 'ja paguei', 'recibo', 'enviar comprovante'],
        'sair'        => ['sair', 'encerrar', 'finalizar', 'tchau', 'obrigado', 'so isso'],
        'chamado'     => ['chamado', 'abrir chamado', 'visita', 'tecnico'],
        'confianca'   => ['confianca', 'liber', 'desbloque'],
        'vencido'     => ['vencido', 'vencida', 'atrasad', 'venceu', 'em atraso', 'passou'],   // (02/10/2026) boleto vencido x a vencer
        'avencer'     => ['a vencer', 'vai vencer', 'nao venceu', 'proximo', 'em dia', 'do mes'],
        'menu'        => ['menu', 'voltar', 'inicio'],
        'sim'         => [' sim ', 'pode', 'claro', 'isso mesmo', 'correto', 'confirmo'],
        'corrigir'    => ['corrig', 'errad', 'incorret', 'tem erro', 'alterar dado'],
        'nao'         => [' nao '],
    ];
    $out = [];
    foreach ($sin as $k => $lista) foreach ($lista as $p) if (strpos($t, strpos($p, ' ') === 0 ? $p : ' ' . trim($p)) !== false) { $out[$k] = true; break; }
    return array_keys($out);
}

/**
 * Converte a fala na resposta que o menu espera.
 *   $tipo 'numero' → só os dígitos ("zero dois três..." → "023...") — CPF ditado;
 *   $tipo 'menu'   → número da opção. $opcoes = "1=Suporte IA|2=2ª Via Boletos|..." (o texto do próprio menu).
 */
function ws_chatbot_resposta(string $fala, string $opcoes = '', string $tipo = 'menu'): string {
    $n = ws_chatbot_norm($fala);
    $num = ['zero'=>'0','um'=>'1','uma'=>'1','dois'=>'2','duas'=>'2','tres'=>'3','quatro'=>'4','cinco'=>'5','seis'=>'6','meia'=>'6','sete'=>'7','oito'=>'8','nove'=>'9'];
    if ($tipo === 'numero') {
        $d = implode('', array_map(fn($w) => ctype_digit($w) ? $w : ($num[$w] ?? ''), explode(' ', $n)));
        return $d !== '' ? $d : $fala;
    }
    // 1) número dito/escrito numa resposta curta: "2", "opção dois", "o três"
    $pal = array_values(array_filter(explode(' ', $n), fn($w) => !in_array($w, ['opcao', 'o', 'a', 'numero', 'e', 'quero', 'a', 'de'], true)));
    if (count($pal) <= 2) foreach ($pal as $w) { if (preg_match('/^\d$/', $w)) return $w; if (isset($num[$w])) return $num[$w]; }
    // 2) assunto falado x texto de cada opção do menu
    $ch = ws_chatbot_chaves($fala); $melhor = ''; $pts = 0;
    if ($ch && $opcoes !== '') foreach (explode('|', $opcoes) as $op) {
        if (!preg_match('/^\s*(\d+)\s*=\s*(.+)$/u', $op, $m)) continue;
        // assunto específico (contratar, cancelar, comprovante, atendente, liberação) vale mais que o genérico "internet":
        // "quero contratar internet" é Ser cliente, não Suporte (testado com a OpenAI em 01/10/2026)
        $peso = ["cliente" => 2, "cancelar" => 2, "comprovante" => 2, "atendente" => 2, "confianca" => 2];
        $p = 0; foreach (array_intersect($ch, ws_chatbot_chaves($m[2])) as $k) $p += $peso[$k] ?? 1;
        if ($p > $pts) { $pts = $p; $melhor = $m[1]; }
    }
    if ($melhor !== '') return $melhor;
    // 3) número em qualquer ponto da fala ("é a opção número três por favor")
    foreach (explode(' ', $n) as $w) { if (preg_match('/^\d$/', $w)) return $w; if (isset($num[$w]) && $w !== 'uma' && $w !== 'um') return $num[$w]; }
    return $fala;
}
