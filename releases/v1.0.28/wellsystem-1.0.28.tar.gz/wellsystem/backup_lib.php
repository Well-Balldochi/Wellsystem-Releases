<?php
/**
 * WellSystem — Backup do banco (dump SQL em PHP, sem mysqldump) + agendamento diário.
 * Config em cache/backup.json. Envio por e-mail usa mailer.php (SMTP).
 */
require_once __DIR__ . '/config.php';

/**
 * Formata um tamanho em bytes usando a unidade adequada (KB, MB ou GB).
 * Único ponto de formatação de tamanho de arquivo em todo o sistema —
 * usar sempre esta função em vez de "/1024 . ' KB'" espalhado pelo código.
 */
function ws_fmt_tamanho(int $bytes): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2, ',', '.') . ' GB';
    if ($bytes >= 1048576)    return number_format($bytes / 1048576, 1, ',', '.') . ' MB';
    return number_format($bytes / 1024, 1, ',', '.') . ' KB';
}

function ws_backup_config(): array {
    $def = ['ativo' => 1, 'hora' => '03:00', 'email' => ''];
    $f = WS_CACHE . '/backup.json';
    if (is_file($f)) { $c = json_decode(@file_get_contents($f), true); if (is_array($c)) return array_merge($def, $c); }
    return $def;
}
function ws_backup_salvar(array $c): bool {
    ws_dir(WS_CACHE); // garante que cache/ existe antes de tentar gravar
    $ok = @file_put_contents(WS_CACHE . '/backup.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/backup.json', 0640);
    return $ok !== false;
}

/** Gera o dump SQL de todas as tabelas (exclui as voláteis grandes). */
function ws_backup_sql(PDO $db): string {
    @set_time_limit(0); @ini_set('memory_limit', '1536M');   // banco grande (100 MB+) não cabe nos 128 MB padrão: página em branco
    $excl = ['radacct', 'radpostauth', 'ws_online_hist', 'ws_backup_config'];   // ws_backup_config sai de ws_backup_config_sql()
    $tabelas = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $out = "-- WellSystem ERP backup — " . date('c') . "\n";
    $out .= "SET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n";
    foreach ($tabelas as $t) {
        if (in_array($t, $excl, true)) continue;
        $create = $db->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM);
        $out .= "DROP TABLE IF EXISTS `$t`;\n" . ($create[1] ?? '') . ";\n";
        $rows = $db->query("SELECT * FROM `$t`");
        $cols = null;
        while ($r = $rows->fetch(PDO::FETCH_ASSOC)) {
            if ($cols === null) $cols = '`' . implode('`,`', array_keys($r)) . '`';
            $vals = array_map(function ($v) use ($db) { return $v === null ? 'NULL' : $db->quote((string)$v); }, array_values($r));
            $out .= "INSERT INTO `$t` ($cols) VALUES (" . implode(',', $vals) . ");\n";
        }
        $out .= "\n";
    }
    $out .= ws_backup_config_sql($db);
    $out .= "SET FOREIGN_KEY_CHECKS=1;\n";
    return $out;
}

/* =====================================================================================================
 * CONFIGURAÇÕES + LOGO DENTRO DO MESMO .SQL
 * -----------------------------------------------------------------------------------------------------
 * O dump só levava TABELAS. A régua de cobrança está em tabela (ws_regua) e já ia; mas as REGRAS de
 * cobrança (cache/cobranca.json), as MENSAGENS automáticas (mensagens.json, msg_auto.json), a LOGO,
 * provedor, recursos, SMTP, WhatsApp, textos de boleto/recibo, central, NFS-e, gateway, concentradores
 * etc. moram em arquivos — e ficavam de fora. Restaurar um backup devolvia os clientes e perdia o jeito
 * do provedor trabalhar.
 *
 * Agora o dump ganha uma tabela extra, ws_backup_config, gerada NA HORA a partir dos arquivos (não
 * grava nada no banco ao fazer backup). Cada linha = um arquivo, conteúdo em base64 (sem ';' nem
 * quebra de linha — atravessa o restaurador comando-a-comando do backup.php sem se partir).
 * Na restauração, ws_backup_config_restaurar() regrava os arquivos e apaga a tabela.
 *
 * FICAM DE FORA de propósito: credencial do banco (wellsystem_db.json — em outro servidor quebraria a
 * conexão), ativação/licença (vale por servidor), token temporário do gateway e tudo que é fila,
 * cache ou estado de execução (se restaurado, reenviaria mensagens ou mostraria dado velho). */
function ws_backup_config_itens(): array {
    $fora = ['wellsystem_db.json', 'ativacao.json', 'celcash_token.json', 'schema_ok.json', 'sessoes_online.json',
             'conexao_viva.json', 'mensagens_enviadas.json', 'msg_eventos_fila.json', 'msg_eventos_enviados.json',
             'msg_estado_bloqueio.json', 'velocidade_pendente.json', 'derrubar_pendente.json', 'rede_pendente.json',
             'zonas_sync.json', 'olt_autofind_nativo.json', 'demo.json', 'demo_users.json', 'demo_sessions.json',
             'manutencao_login.json', 'wa_janela.json', 'backup_links.json'];
    $itens = [];
    $dirs = array_unique(array_filter([WS_CACHE, function_exists('ws_cache_dir') ? ws_cache_dir() : '']));
    foreach ($dirs as $d) {
        foreach (glob($d . '/*.json') ?: [] as $f) {
            $b = basename($f);
            if (in_array($b, $fora, true) || isset($itens['cache/' . $b])) continue;
            // amostras ao vivo do gráfico de tráfego (trafego_srv_<id>.json): estado, não configuração
            if (preg_match('/^trafego_srv_(\d+|l\d+)\.json$/', $b)) continue;
            if (filesize($f) > 2 * 1048576) continue;   // JSON de config é pequeno; grande = cache/lixo
            $itens['cache/' . $b] = $f;
        }
    }
    // Logo e imagens do sistema (logo da marca, logo do boleto/documentos, fundo do login…).
    if (defined('WS_UP_SISTEMA') && is_dir(WS_UP_SISTEMA)) {
        foreach (glob(WS_UP_SISTEMA . '/*') ?: [] as $f) {
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            if (!in_array($ext, ws_backup_exts_sistema(), true)) continue;
            if (is_file($f) && filesize($f) <= 8 * 1048576) $itens['uploads/sistema/' . basename($f)] = $f;
        }
    }
    /* CONFIGURAÇÃO DA OLT E LOGOS GUARDADAS EM TEXTO (cache_trafego/): conexão, usuários, auto-conectar, cadastro
       ONU→cliente, nomes de VLAN, modelos, e as logos da OLT e da página principal (wellsystem_logo*.txt, em
       data:image). Ficavam de fora: o backup só lia cache/*.json — era por isso que "a logo não ia".
       Só a lista abaixo: o resto da pasta é cache e estado da OLT (se voltasse, mostraria dado velho). */
    foreach (ws_backup_olt_dirs() as $d) {
        foreach (ws_backup_olt_arquivos() as $b) {
            $f = $d . '/' . $b;
            if (is_file($f) && filesize($f) <= 8 * 1048576 && !isset($itens['cache_trafego/' . $b])) $itens['cache_trafego/' . $b] = $f;
        }
    }
    /* TODOS OS ARQUIVOS ENVIADOS (30/09/2026 — "subir do zero e ficar igual"): fotos dos equipamentos em comodato,
       documentos e anexos dos clientes, fotos dos operadores e da Central, comprovantes PIX, fotos de modelos de ONU.
       Antes só iam as imagens da raiz de uploads/sistema. Só tipos seguros (imagem/PDF/documento), até 10 MB cada. */
    if (defined('WS_UPLOADS') && is_dir(WS_UPLOADS)) {
        $base = rtrim(str_replace(chr(92), '/', WS_UPLOADS), '/');
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(WS_UPLOADS, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $arq) {
            if (!$arq->isFile() || $arq->getSize() > 10 * 1048576) continue;
            $rel = ltrim(substr(str_replace(chr(92), '/', $arq->getPathname()), strlen($base)), '/');
            if (!ws_backup_rel_ok($rel)) continue;
            if (!isset($itens['uploads/' . $rel])) $itens['uploads/' . $rel] = $arq->getPathname();
        }
    }
    // MODELOS DE DOCUMENTO (contratos, ficha, carta, recibo — docs_templates/*.txt, editados na tela Documentos).
    // Ficavam de fora (30/09/2026): restaurar perdia o contrato do provedor e voltava o texto de fábrica.
    foreach (glob(WS_DIR . '/docs_templates/*.txt') ?: [] as $f) {
        if (preg_match('/^[a-z_]+\.txt$/', basename($f)) && filesize($f) <= 8 * 1048576) $itens['docs_templates/' . basename($f)] = $f;
    }
    // Logo antiga ainda em assets/ (branding.json aponta para lá).
    foreach (glob(WS_DIR . '/assets/logo_*') ?: [] as $f) {
        if (is_file($f) && filesize($f) <= 3 * 1048576) $itens['assets/' . basename($f)] = $f;
    }
    return $itens;
}
/** Tipos aceitos de uploads/sistema/ (logo, logo do boleto, fundos, anexos das mensagens, modelo do boleto). */
/** Caminho relativo de arquivo enviado aceito no backup/restauração: só letras/números/._-/ , sem "..", sem arquivo
 *  oculto e com extensão segura — um .sql adulterado não consegue plantar .php nem sair da pasta uploads/. */
function ws_backup_rel_ok(string $rel): bool {
    if ($rel === '' || strpos($rel, '..') !== false || !preg_match('~^[A-Za-z0-9_\-][A-Za-z0-9_\-./]*$~', $rel)) return false;
    foreach (explode('/', $rel) as $parte) if ($parte === '' || $parte[0] === '.') return false;
    return in_array(strtolower(pathinfo($rel, PATHINFO_EXTENSION)), array_merge(ws_backup_exts_sistema(), ['mp4', 'xlsx', 'xls', 'csv', 'doc']), true);
}
function ws_backup_exts_sistema(): array { return ['png','jpg','jpeg','gif','webp','svg','ico','pdf','docx','odt','html','htm','txt']; }
/** Arquivos de CONFIGURAÇÃO da pasta da OLT que entram no backup (o resto é cache/estado). */
function ws_backup_olt_arquivos(): array {
    return ['olt_conexao.json', 'olt_usuarios.json', 'olt_autoconnect.json', 'olt_cad_url.json', 'olt_cadastro.json',
            'olt_vlan_nomes.json', 'olt_modelos.json', 'olt_perfis_olt.json', 'ws_bridge.json', 'olt_smartolt.json', 'olt_limites_sinal.json',
            'wellsystem_logo.txt', 'wellsystem_logo_olt.txt',
            // 21/10/2026: fotos dos modelos de ONU/ONT enviadas pela OLT (base64) e demais opções da OLT — sem isto sumiam ao reinstalar/restaurar.
            'olt_modelo_img.json', 'olt_opcoes.json', 'olt_meta.json', 'olt_autorizacoes.json', 'olt_perfis.json',
            // 24/10/2026: agendamento do backup diário da OLT (ativo/hora/e-mail/SMTP) — não estava na lista e se perdia ao restaurar o servidor (OLT sem backup por e-mail sem ninguém notar).
            'olt_backup_ag.json'];
}
/** Onde a pasta da OLT pode estar (a da raiz; a antiga olt/ só se a da raiz não tiver o arquivo). */
function ws_backup_olt_dirs(): array { return array_values(array_filter([WS_DIR . '/cache_trafego', WS_DIR . '/olt/cache_trafego'], 'is_dir')); }

function ws_backup_config_sql(PDO $db): string {
    // Comentário em /* */ e NÃO em "--": o restaurador do backup.php pula todo trecho que começa com
    // "--", e isso levaria junto o DROP TABLE colado logo abaixo.
    $out = "/* Configurações do sistema (regras de cobrança, mensagens, logo...) — ver ws_backup_config_itens() */ DROP TABLE IF EXISTS `ws_backup_config`;\n";
    $out .= "CREATE TABLE `ws_backup_config` (`caminho` VARCHAR(190) NOT NULL PRIMARY KEY, `conteudo` LONGTEXT NOT NULL, `gerado_em` DATETIME NULL) DEFAULT CHARSET=utf8mb4;\n";
    foreach (ws_backup_config_itens() as $rel => $f) {
        $c = @file_get_contents($f);
        if ($c === false) continue;
        $out .= "INSERT INTO `ws_backup_config` (`caminho`,`conteudo`,`gerado_em`) VALUES ("
              . $db->quote($rel) . ",'" . base64_encode($c) . "'," . $db->quote(date('Y-m-d H:i:s')) . ");\n";
    }
    return $out . "\n";
}
/** Depois de restaurar um .sql: regrava as configurações e a logo que vieram nele. Devolve quantos
 *  arquivos voltaram. Só escreve em cache/, uploads/sistema/ e assets/logo_* — o caminho gravado no
 *  backup é validado, nunca usado cru (um .sql adulterado não escreve fora dessas pastas). */
function ws_backup_config_restaurar(PDO $db): int {
    try { $rows = $db->query("SELECT caminho, conteudo FROM ws_backup_config")->fetchAll(PDO::FETCH_ASSOC); }
    catch (Throwable $e) { return 0; }   // backup antigo, sem configurações: nada a fazer
    $n = 0;
    foreach ($rows as $r) {
        $rel = str_replace('\\', '/', (string)$r['caminho']);
        $b = basename($rel);
        if ($b === '' || $b[0] === '.' || strpos($rel, '..') !== false) continue;
        // Fora de cache/*.json, só imagem/documento: um .sql adulterado não pode plantar um .php.
        $ext = strtolower(pathinfo($b, PATHINFO_EXTENSION));
        $ehDoc = strpos($rel, 'docs_templates/') === 0 && preg_match('/^[a-z_]+\.txt$/', $b);   // modelo de documento: só .txt de nome simples
        if (strpos($rel, 'cache/') !== 0 && strpos($rel, 'cache_trafego/') !== 0 && !$ehDoc && !in_array($ext, ws_backup_exts_sistema(), true)) continue;
        if (strpos($rel, 'cache/') === 0 && substr($b, -5) === '.json') $dest = WS_CACHE . '/' . $b;
        elseif (strpos($rel, 'uploads/sistema/') === 0 && substr_count($rel, '/') === 2 && defined('WS_UP_SISTEMA')) { ws_dir(WS_UP_SISTEMA); $dest = WS_UP_SISTEMA . '/' . $b; }
        elseif (strpos($rel, 'uploads/') === 0 && defined('WS_UPLOADS') && ws_backup_rel_ok(substr($rel, 8))) {
            $dest = WS_UPLOADS . '/' . substr($rel, 8);
            if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0775, true);
            // comprovantes têm dado bancário: a pasta volta com o .htaccess que bloqueia acesso direto
            if (strpos($rel, 'uploads/comprovantes/') === 0 && is_file(__DIR__ . '/comprovantes_lib.php')) { require_once __DIR__ . '/comprovantes_lib.php'; if (function_exists('ws_comp_dir')) ws_comp_dir(); }
        }
        elseif (strpos($rel, 'assets/logo_') === 0) { ws_dir(WS_DIR . '/assets'); $dest = WS_DIR . '/assets/' . $b; }
        elseif ($ehDoc) { ws_dir(WS_DIR . '/docs_templates'); $dest = WS_DIR . '/docs_templates/' . $b; }
        elseif (strpos($rel, 'cache_trafego/') === 0 && in_array($b, ws_backup_olt_arquivos(), true)) { ws_dir(WS_DIR . '/cache_trafego'); $dest = WS_DIR . '/cache_trafego/' . $b; }
        else continue;
        $c = base64_decode((string)$r['conteudo'], true);
        if ($c === false) continue;
        // cache_trafego é lido também pelo cron da OLT (outro usuário): 0666 como a própria OLT grava.
        if (@file_put_contents($dest, $c) !== false) { @chmod($dest, strpos($rel, 'cache/') === 0 ? 0640 : (strpos($rel, 'cache_trafego/') === 0 ? 0666 : 0644)); $n++; }   // imagem precisa ser lida pelo servidor web
    }
    try { $db->exec("DROP TABLE IF EXISTS ws_backup_config"); } catch (Throwable $e) {}
    return $n;
}

/** Gera + envia por e-mail. Retorna [bool, msg]. */
function ws_backup_enviar(PDO $db, string $to = ''): array {
    @set_time_limit(0); @ini_set('memory_limit', '1536M');
    require_once __DIR__ . '/mailer.php';
    $cfg = ws_backup_config();
    $to = trim($to) !== '' ? trim($to) : ($cfg['email'] ?? '');
    if ($to === '') return [false, 'E-mail de destino vazio.'];
    $sql = ws_backup_sql($db);
    $nome = 'wellsystem-backup-' . date('Ymd-His') . '.sql'; $mimeB = 'application/sql';
    if (($xzB = ws_backup_xz($sql)) !== null) { $sql = $xzB; $nome .= '.xz'; $mimeB = 'application/x-xz'; }
    elseif (function_exists('gzencode') && ($gzB = @gzencode($sql, 6)) !== false && $gzB !== '') { $sql = $gzB; $nome .= '.gz'; $mimeB = 'application/gzip'; }   // compactado: anexo ~10x menor
    return ws_email_anexo_partes($to, 'Backup WellSystem — ' . date('d/m/Y'),
        "Backup automático do WellSystem ERP — " . date('d/m/Y H:i') . ".", $nome, $sql, $mimeB);
}

/** Resolve a pasta de backups do banco, com o mesmo plano B automático da cache/: se não der pra
 *  gravar em backups/ (permissão/SELinux), usa uma pasta temporária do sistema sem travar o recurso. */
function ws_resolver_backup_dir(): string {
    $preferida = __DIR__ . '/backups';
    if (ws_dir_realmente_gravavel($preferida)) return $preferida;
    $fallback = rtrim(sys_get_temp_dir(), '/\\') . '/wellsystem_backups_' . substr(md5(__DIR__), 0, 10);
    if (ws_dir_realmente_gravavel($fallback)) { define('WS_BACKUP_DIR_FALLBACK', true); return $fallback; }
    return $preferida;
}
define('WS_BACKUP_DIR', ws_resolver_backup_dir());

/** Gera o dump e SALVA um arquivo .sql em backups/. Retorna o caminho, ou lança exceção se falhar (pasta sem permissão etc). */
function ws_backup_gravar(PDO $db): string {
    if (!ws_dir_realmente_gravavel(WS_BACKUP_DIR)) {
        throw new RuntimeException('A pasta de backups (' . WS_BACKUP_DIR . ') não existe ou não tem permissão de escrita' . (function_exists('ws_diag_permissao') ? ws_diag_permissao(WS_BACKUP_DIR) : '') . '.');
    }
    $nome = 'wellsystem-' . date('Ymd-His') . '.sql';
    $path = WS_BACKUP_DIR . '/' . $nome;
    $sql = ws_backup_sql($db);
    if ($sql === '' || strpos($sql, 'INSERT INTO') === false) {
        throw new RuntimeException('O dump saiu vazio — confira a conexão com o banco.');
    }
    $ok = @file_put_contents($path, $sql);
    if ($ok === false) {
        throw new RuntimeException('Não consegui gravar o arquivo em ' . $path . ' — confira permissão de escrita da pasta.');
    }
    @chmod($path, 0640);
    // mantém no máx. 60 arquivos (limpa os mais antigos)
    $arqs = glob(WS_BACKUP_DIR . '/*.sql') ?: []; usort($arqs, fn($a, $b) => filemtime($a) <=> filemtime($b));
    while (count($arqs) > 60) { @unlink(array_shift($arqs)); }
    return $path;
}
/** Lista os backups salvos (mais novos primeiro). */
function ws_backup_lista(): array {
    $arqs = glob(WS_BACKUP_DIR . '/*.sql') ?: [];
    usort($arqs, fn($a, $b) => filemtime($b) <=> filemtime($a));
    return $arqs;
}
function ws_backup_dest_config(): array {
    $f = WS_CACHE . '/backup_dest.json';
    $def = ['email' => '', 'whatsapp' => '', 'tg_token' => '', 'tg_chat' => '',
            'ftp_host' => '', 'ftp_user' => '', 'ftp_pass' => '', 'ftp_path' => '/', 'mega_user' => '', 'mega_pass' => '', 'cripto_senha' => ''];
    if (is_file($f)) { $c = json_decode(@file_get_contents($f), true); if (is_array($c)) return array_merge($def, $c); }
    return $def;
}
function ws_backup_dest_salvar(array $c): bool {
    ws_dir(WS_CACHE);
    $ok = @file_put_contents(WS_CACHE . '/backup_dest.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_CACHE . '/backup_dest.json', 0640);
    return $ok !== false;
}

/** Canal ligado? Cada destino tem um liga/desliga (on_email, on_whatsapp, on_telegram, on_ftp, on_mega).
 *  Sem a chave (config antiga) = ligado, então nada que já funcionava deixa de enviar. */
function ws_backup_canal_on(array $d, string $canal): bool {
    return !array_key_exists('on_' . $canal, $d) || !empty($d['on_' . $canal]);
}
/** LINK SEGURO PARA BACKUP GRANDE (24/10/2026): o backup compactado (~16–18 MB e crescendo) passa do limite do e-mail e era DIVIDIDO em partes. Agora o arquivo INTEIRO fica numa pasta do servidor e o e-mail leva só o link
 *  (token aleatório de 48 caracteres, validade de 7 dias, máx. 10 downloads) + a conferência SHA-256. Nada é retirado do backup. Página pública: backup_link.php. O estado dos links (cache/backup_links.json) NÃO vai no backup de configuração. */
function ws_backup_links_arq(): string { return WS_CACHE . '/backup_links.json'; }
function ws_backup_links_ler(): array { $j = json_decode((string)@file_get_contents(ws_backup_links_arq()), true); return is_array($j) ? $j : []; }
function ws_backup_links_gravar(array $j): void { @file_put_contents(ws_backup_links_arq(), json_encode($j), LOCK_EX); @chmod(ws_backup_links_arq(), 0640); }
/** Cria o link. Devolve ['url','sha','tam','exp'] ou null (aí quem chamou usa o método antigo, em partes — nunca perde o backup). */
function ws_backup_link_criar(string $nome, string $conteudo, int $dias = 7): ?array {
    try {
        $base = function_exists('ws_url_publica') ? ws_url_publica() : '';
        if ($base === '' || !preg_match('#^https?://#i', $base)) $base = rtrim(trim((string)@file_get_contents(WS_CACHE . '/api_base.txt')), '/');
        if ($base === '' || !preg_match('#^https?://#i', $base)) return null;
        $dir = ws_resolver_backup_dir(); $tok = bin2hex(random_bytes(24));
        $arq = rtrim($dir, '/') . '/envio_' . substr($tok, 0, 12) . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $nome);
        if (@file_put_contents($arq, $conteudo, LOCK_EX) === false) return null;
        @chmod($arq, 0640);
        $j = ws_backup_links_ler();
        foreach ($j as $t => $v) if ((int)($v['exp'] ?? 0) < time() || !is_file((string)($v['arq'] ?? ''))) { @unlink((string)($v['arq'] ?? '')); unset($j[$t]); }   // limpa vencidos
        $exp = time() + $dias * 86400; $sha = hash('sha256', $conteudo);
        $j[$tok] = ['arq' => $arq, 'nome' => $nome, 'exp' => $exp, 'sha' => $sha, 'tam' => strlen($conteudo), 'n' => 0];
        ws_backup_links_gravar($j);
        return ['url' => rtrim($base, '/') . '/backup_link.php?t=' . $tok, 'sha' => $sha, 'tam' => strlen($conteudo), 'exp' => $exp];
    } catch (Throwable $e) { return null; }
}
/** Valida o token e conta o download. Devolve [caminho, nome, tamanho] ou null (inexistente, vencido ou acima de 10 downloads). */
function ws_backup_link_abrir(string $tok): ?array {
    $j = ws_backup_links_ler(); $v = $j[$tok] ?? null;
    if (!is_array($v) || (int)($v['exp'] ?? 0) < time() || (int)($v['n'] ?? 0) >= 10 || !is_file((string)($v['arq'] ?? ''))) return null;
    $j[$tok]['n'] = (int)$v['n'] + 1; ws_backup_links_gravar($j);
    return [(string)$v['arq'], (string)$v['nome'], (int)filesize((string)$v['arq'])];
}
/** COMPACTAÇÃO FORTE PARA O ANEXO (17/10/2026): o .gz do backup passou de 30 MB e o Gmail (limite 25 MB por e-mail) deixou de aceitar; o .xz sai com ~13 MB (4x menor que o .gz neste banco). Usa o comando xz do servidor;
 *  sem xz/exec (ou falha) devolve null e quem chamou usa o .gz de sempre. Abrir: 7-Zip (Windows) ou `xz -d` (Linux/Mac). */
function ws_backup_xz(string $dados): ?string {
    if ($dados === '' || !function_exists('proc_open') || strlen($dados) < 5 * 1048576) return null;   // pequeno: o .gz já resolve
    $bin = null; foreach (['/usr/bin/xz', '/bin/xz', '/usr/local/bin/xz'] as $c) if (is_executable($c)) { $bin = $c; break; }
    if ($bin === null) return null;
    // arquivo temporário nos dois lados (sem pipes: nada de travar por buffer cheio)
    $dir = sys_get_temp_dir(); $in = tempnam($dir, 'wsxz'); $out = $in . '.xz';
    try {
        if (@file_put_contents($in, $dados) === false) return null;
        $p = @proc_open([$bin, '-6', '-T0', '-c', $in], [0 => ['file', '/dev/null', 'r'], 1 => ['file', $out, 'w'], 2 => ['file', '/dev/null', 'w']], $pipes);
        if (!is_resource($p)) return null;
        $fim = time() + 240; $rc = -1;
        while (true) { $st = proc_get_status($p); if (!$st['running']) { $rc = (int)$st['exitcode']; break; } if (time() > $fim) { proc_terminate($p, 9); break; } usleep(200000); }
        proc_close($p);
        $res = ($rc === 0 && is_file($out)) ? (string)@file_get_contents($out) : '';
        return (strlen($res) > 100 && substr($res, 0, 6) === "\xFD" . "7zXZ\x00") ? $res : null;
    } finally { @unlink($in); @unlink($out); }
}
/** ABRIR .xz (17/10/2026): descompacta o backup .sql.xz direto para o arquivo de destino (sem carregar tudo na memória). Devolve true/false. Precisa do comando xz do servidor. */
function ws_backup_xz_abrir(string $origem, string $destino): bool {
    if (!function_exists('proc_open')) return false;
    $bin = null; foreach (['/usr/bin/xz', '/bin/xz', '/usr/local/bin/xz'] as $c) if (is_executable($c)) { $bin = $c; break; }
    if ($bin === null) return false;
    $p = @proc_open([$bin, '-dc', $origem], [0 => ['file', '/dev/null', 'r'], 1 => ['file', $destino, 'w'], 2 => ['file', '/dev/null', 'w']], $pipes);
    if (!is_resource($p)) return false;
    $fim = time() + 300; $rc = -1;
    while (true) { $st = proc_get_status($p); if (!$st['running']) { $rc = (int)$st['exitcode']; break; } if (time() > $fim) { proc_terminate($p, 9); break; } usleep(200000); }
    proc_close($p);
    if ($rc !== 0 || !is_file($destino) || filesize($destino) < 100) { @unlink($destino); return false; }
    return true;
}
/** Anexo pronto pra envio: o .sql vai COMPACTADO (.gz, ~10x menor) — anexo enorme era recusado/estourava
 *  o tempo do SMTP e do WhatsApp. Já .gz/.zip segue como está. Retorna [nome, conteúdo, mime]. */
function ws_backup_anexo_envio(string $path): array {
    @set_time_limit(0); @ini_set('memory_limit', '1536M');
    $nome = basename($path); $cont = (string)@file_get_contents($path);
    if (preg_match('/\.gz$/i', $nome)) return [$nome, $cont, 'application/gzip'];
    if (preg_match('/\.zip$/i', $nome)) return [$nome, $cont, 'application/zip'];
    $semCripto = (string)(ws_backup_dest_config()['cripto_senha'] ?? '') === '';   // cifrado segue .gz (a restauração do .wsbk espera .gz)
    $xz = $semCripto ? ws_backup_xz($cont) : null;
    if ($xz !== null) { $nome .= '.xz'; $cont = $xz; return [$nome, $cont, 'application/x-xz']; }
    if (function_exists('gzencode')) { $gz = @gzencode($cont, 6); if ($gz !== false && $gz !== '') { $nome .= '.gz'; $cont = $gz; } }
    // Senha de criptografia preenchida (Backup → Destinos): o que SAI do servidor vai cifrado (.wsbk). Ver ws_backup_cifrar().
    $senhaCr = (string)(ws_backup_dest_config()['cripto_senha'] ?? '');
    if ($senhaCr !== '' && function_exists('openssl_encrypt')) return [$nome . '.wsbk', ws_backup_cifrar($cont, $senhaCr), 'application/octet-stream'];
    return [$nome, $cont, preg_match('/\.gz$/', $nome) ? 'application/gzip' : 'application/sql'];
}
/** Envia UM arquivo pra TODOS os destinos configurados. Retorna resumo por canal. */
function ws_backup_enviar_arquivo(string $path, array $pular = []): array {
    @set_time_limit(0); @ini_set('memory_limit', '1536M');   // o .sql de 100 MB+ é lido inteiro e compactado: estourava os 128 MB (erro 500 ao enviar)
    if (!is_file($path)) return ['erro' => 'arquivo não encontrado'];
    $d = ws_backup_dest_config();
    $nome = basename($path);
    [$nomeEnv, $conteudo, $mimeEnv] = ws_backup_anexo_envio($path);
    $res = [];
    // Arquivo de envio (compactado/cifrado) para os canais que mandam arquivo do disco (Telegram, FTP).
    $tmpEnv = sys_get_temp_dir() . '/' . $nomeEnv; @file_put_contents($tmpEnv, $conteudo);
    // e-mail
    if (!in_array('email', $pular, true) && ws_backup_canal_on($d, 'email') && trim($d['email']) !== '' && is_file(__DIR__ . '/mailer.php')) {
        require_once __DIR__ . '/mailer.php';
        [$ok, $m] = ws_email_anexo_partes($d['email'], 'Backup WellSystem — ' . date('d/m/Y'), 'Backup em anexo (' . $nomeEnv . ', ' . round(strlen($conteudo) / 1024) . ' KB).' . (preg_match('/\.xz$/', $nomeEnv) ? "

Arquivo .xz: abra com o 7-Zip (Windows) ou 'xz -d' (Linux/Mac); depois use Backup → Restaurar com o .sql." : ''), $nomeEnv, $conteudo, $mimeEnv);
        $res['email'] = $ok ? 'ok' : $m;
    }
    // WhatsApp (documento via Evolution)
    if (!in_array('whatsapp', $pular, true) && ws_backup_canal_on($d, 'whatsapp') && trim($d['whatsapp']) !== '' && is_file(__DIR__ . '/whatsapp.php')) {
        require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_wa_documento')) {
            $r = ws_wa_documento($d['whatsapp'], $nomeEnv, base64_encode($conteudo), ['evento' => 'backup', 'interna' => true]);
            // Item 5: com a API oficial da Meta e a janela de 24h fechada (bem comum pra um número que
            // só recebe aviso do sistema), o envio de mídia cai pra TEMPLATE — que é só texto, sem
            // anexo. Antes isso batia como "ok" igual a um envio completo, e o arquivo sumia em
            // silêncio. Agora o log conta a verdade e já aponta a correção.
            if (!empty($r['ok']) && !empty($r['template'])) {
                $res['whatsapp'] = 'ok, MAS SEM O ARQUIVO — a janela de 24h do número oficial está fechada: saiu só o aviso. Para receber o arquivo, mande qualquer mensagem para o número oficial (abre a janela) e envie o backup de novo; ele também pode ser baixado aqui na tela de Backup.';
            } elseif (!empty($r['ok']) && !empty($r['arquivo_direto'])) {
                $res['whatsapp'] = 'ok — arquivo enviado direto (se não chegar, a janela de 24h do número oficial estava fechada e saiu só o aviso).';
            } else {
                $res['whatsapp'] = !empty($r['ok']) ? 'ok' : ($r['raw'] ?? 'falha');
            }
        }
    }
    // Telegram (Bot API sendDocument)
    if (!in_array('telegram', $pular, true) && ws_backup_canal_on($d, 'telegram') && trim($d['tg_token']) !== '' && trim($d['tg_chat']) !== '') {
        $url = "https://api.telegram.org/bot{$d['tg_token']}/sendDocument";
        $cf = new CURLFile($tmpEnv, $mimeEnv, $nomeEnv);
        $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60,
            CURLOPT_POSTFIELDS => ['chat_id' => $d['tg_chat'], 'document' => $cf, 'caption' => 'Backup WellSystem ' . date('d/m/Y')]]);
        $r = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $res['telegram'] = ($code === 200 && strpos((string)$r, '"ok":true') !== false) ? 'ok' : 'falha';
    }
    // FTP
    if (!in_array('ftp', $pular, true) && ws_backup_canal_on($d, 'ftp') && trim($d['ftp_host']) !== '' && function_exists('ftp_connect')) {
        $cx = @ftp_connect($d['ftp_host'], 21, 20);
        if ($cx && @ftp_login($cx, $d['ftp_user'], $d['ftp_pass'])) {
            @ftp_pasv($cx, true);
            $dest = rtrim($d['ftp_path'] ?: '/', '/') . '/' . $nomeEnv;
            $res['ftp'] = @ftp_put($cx, $dest, $tmpEnv, FTP_BINARY) ? 'ok' : 'falha no envio';
            @ftp_close($cx);
        } else $res['ftp'] = 'não conectou';
    }
    // Mega: requer megatools/SDK — sinaliza pra configurar via ferramenta externa.
    if (!in_array('mega', $pular, true) && ws_backup_canal_on($d, 'mega') && trim($d['mega_user']) !== '') $res['mega'] = 'requer megatools no servidor';
    @unlink($tmpEnv);
    if ($res && substr($nomeEnv, -5) === '.wsbk') $res['criptografia'] = 'AES-256 (arquivo .wsbk)';
    return $res ?: ['aviso' => 'nenhum destino configurado'];
}

/** Envia UM backup já gerado para os destinos padrão (Destinos de envio + e-mail da aba Agendamento,
 *  sem duplicar se for o mesmo endereço) e registra em cache/backup.log. Único ponto de envio
 *  reaproveitado pelo automático (radius_sync.php) e por QUALQUER botão "gerar backup agora" do
 *  sistema (ws_backup_gerar em seguranca.php) — antes só o automático mandava; os botões manuais
 *  de Provedor/Manutenção só geravam o arquivo e nunca tentavam enviar nada. */
function ws_backup_enviar_padrao(string $path, string $origem = 'manual', array $pular = []): array {
    $cfg = ws_backup_config();
    $res = ws_backup_enviar_arquivo($path, $pular);
    $emailAgenda = trim($cfg['email'] ?? '');
    $emailDestinos = trim((string)(ws_backup_dest_config()['email'] ?? ''));
    if ($emailAgenda !== '' && !in_array('email_agenda', $pular, true) && strcasecmp($emailAgenda, $emailDestinos) !== 0 && is_file(__DIR__ . '/mailer.php')) {
        require_once __DIR__ . '/mailer.php';
        [$nmA, $ctA, $mmA] = ws_backup_anexo_envio($path);
        [$okE, $mE] = ws_email_anexo_partes($emailAgenda, 'Backup WellSystem — ' . date('d/m/Y'), 'Backup em anexo (' . $nmA . ').', $nmA, $ctA, $mmA);
        $res['email_agenda'] = $okE ? 'ok' : $mE;
    }
    @file_put_contents(WS_CACHE . '/backup.log', date('Y-m-d H:i:s') . " $origem: " . json_encode($res, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
    return $res;
}
/** Diagnóstico do backup automático — MESMO modelo do backup da OLT (olt_backup_auto_check):
 *  grava o MOTIVO de cada passada (rodou, pulou e por quê, ou falhou) num arquivo único, pra dar pra
 *  ver por que o automático não saiu sem precisar entrar no servidor. Não polui backup.log (que é só
 *  o histórico de envios reais); é sempre a ÚLTIMA passada, sobrescrito a cada rodada do cron. */
function ws_backup_ag_diag(string $msg): void {
    @file_put_contents(WS_CACHE . '/backup_ag_diag.txt', date('Y-m-d H:i:s') . ' ' . $msg);
    @chmod(WS_CACHE . '/backup_ag_diag.txt', 0666);
}
/** Cron: se ativo e a hora marcada já passou hoje e ainda não enviou hoje, envia. */
function ws_backup_auto_check(PDO $db): void {
    $cfg = ws_backup_config();
    if (empty($cfg['ativo'])) { ws_backup_ag_diag('Backup automático DESATIVADO — marque "Ativar backup automático diário" e Salve (aba Agendamento).'); return; }
    // Auto-cura de permissão (causa do loop de reenvio): garante que cache/ existe e está gravável —
    // igual ao padrão já usado em ws_dir() no resto do sistema — e, se o PRÓPRIO backup_ultimo.txt já
    // existir com dono/permissão de outro processo (ex.: criado via FTP, ou addon recriado como root),
    // relaxa a permissão do arquivo antes de tentar gravar a marca de "já enviei hoje".
    ws_dir(WS_CACHE);
    $marca = WS_CACHE . '/backup_ultimo.txt';
    if (is_file($marca) && !is_writable($marca)) @chmod($marca, 0640);
    // Controle por HORÁRIO AGENDADO (não por "já enviou hoje"): remarcar o horário volta a disparar.
    [$pend, $slot, $why] = ws_agenda_slot($marca, (string)($cfg['hora'] ?? '03:00'));
    if (!$pend) { ws_backup_ag_diag($why === 'antes' ? 'Ainda não deu o horário (agora ' . date('H:i') . ', agendado ' . ($cfg['hora'] ?? '03:00') . ').' : 'Horário de hoje (' . $slot . ') já cumprido — próximo só no próximo horário agendado.'); return; }
    // Tentativas: canal que falhou (ex.: e-mail) é refeito a cada 5 min, no máx. 3 vezes por horário; o que já
    // saiu NÃO é reenviado (sem duplicar) e o mesmo arquivo é reaproveitado (sem gerar dump de novo).
    $tryF = WS_CACHE . '/backup_auto_try.txt'; $tn = 0; $jaOk = []; $pathTry = '';
    if (is_file($tryF)) { $tp = json_decode((string)@file_get_contents($tryF), true);
        if (is_array($tp) && ($tp['slot'] ?? '') === $slot) { $tn = (int)($tp['n'] ?? 0); $jaOk = (array)($tp['ok'] ?? []); $pathTry = (string)($tp['path'] ?? '');
            if ((time() - (int)($tp['ts'] ?? 0)) < 300) { ws_backup_ag_diag('Aguardando nova tentativa (' . $tn . '/3 neste horário) — veja backup.log.'); return; } } }
    $destinos = ws_backup_dest_config();
    $temDestino = trim((string)$cfg['email']) !== ''
        || (ws_backup_canal_on($destinos, 'email') && trim((string)$destinos['email']) !== '')
        || (ws_backup_canal_on($destinos, 'whatsapp') && trim((string)$destinos['whatsapp']) !== '')
        || (ws_backup_canal_on($destinos, 'telegram') && trim((string)$destinos['tg_token']) !== '')
        || (ws_backup_canal_on($destinos, 'ftp') && trim((string)$destinos['ftp_host']) !== '');
    if (!$temDestino) {
        ws_backup_ag_diag('Nenhum destino configurado (aba Destinos de envio, ou e-mail na aba Agendamento) — o backup seria gerado mas não teria para onde ir.');
        return;
    }
    /* Item 5: trava por arquivo (flock) contra 2 execuções do cron ao mesmo tempo — o radius_sync.php
     * roda de 2 em 2 min, e se uma rodada demorar mais que isso (rede lenta, Mikrotik/OLT emperrada),
     * duas podiam passar pelo "if" acima juntas, ANTES de qualquer uma gravar a marca de "já enviei
     * hoje" — daí o backup saía em duplicidade, em horários avulsos. Com a trava, só uma roda por vez;
     * a outra desiste na hora (LOCK_NB) e tenta de novo no próximo ciclo do cron. */
    $lock = @fopen(WS_CACHE . '/backup_auto.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) { if ($lock) fclose($lock); ws_backup_ag_diag('Outra passada do cron já estava gerando o backup agora — esta tentou de novo no próximo ciclo.'); return; }
    try {
        // Confere de novo JÁ COM A TRAVA: outro processo pode ter enviado enquanto esta esperava.
        [$pend2] = ws_agenda_slot($marca, (string)($cfg['hora'] ?? '03:00'));
        if (!$pend2) { ws_backup_ag_diag('Horário já cumprido (outra passada concluiu primeiro).'); return; }
        // Gera, salva na pasta e envia pra TODOS os destinos configurados (email/whatsapp/telegram/ftp).
        $path = ($pathTry !== '' && is_file($pathTry)) ? $pathTry : ws_backup_gravar($db);
        $res = ws_backup_enviar_padrao($path, 'auto', $jaOk);
        $pend = [];
        foreach ($res as $canal => $v) {
            if (!in_array($canal, ['email', 'whatsapp', 'telegram', 'email_agenda'], true)) continue;   // FTP/Mega sem configurar não travam o resto
            if (is_string($v) && strpos($v, 'ok') === 0) $jaOk[] = $canal; else $pend[] = $canal;
        }
        if ($pend && $tn + 1 < 3) {
            @file_put_contents($tryF, json_encode(['slot' => $slot, 'n' => $tn + 1, 'ts' => time(), 'path' => $path, 'ok' => array_values(array_unique($jaOk))]));
            ws_backup_ag_diag('Falhou em: ' . implode(', ', $pend) . ' (tentativa ' . ($tn + 1) . '/3, nova em 5 min) — ' . json_encode($res, JSON_UNESCAPED_UNICODE));
            return;
        }
        @unlink($tryF);
        $marcaOk = @file_put_contents($marca, $slot); @chmod($marca, 0640);
        if ($marcaOk === false) {
            // Não deixa isso passar batido: sem conseguir gravar a marca, o PRÓXIMO cron (2 min depois)
            // vai achar que ainda não enviou hoje e reenvia — e reenvia de novo — o dia inteiro.
            // Usa ws_diag_permissao() (já existe em config.php) pra apontar dono/permissão real em vez
            // de um aviso genérico — dá pra corrigir de primeira sem entrar no servidor pra investigar.
            $diag = function_exists('ws_diag_permissao') ? ' — ' . ws_diag_permissao(WS_CACHE) : '';
            @file_put_contents(WS_CACHE . '/backup.log', date('Y-m-d H:i:s') . ' auto: aviso_marca=NÃO conseguiu gravar ' . $marca . $diag . "\n", FILE_APPEND);
        }
        ws_backup_ag_diag('Rodou — ' . json_encode($res, JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) {
        /* Antes, uma falha aqui dentro (ex.: pasta de backups sem permissão, banco fora, dump vazio)
         * subia até o radius_sync.php e caía num catch(Throwable){} genérico — sumia sem deixar
         * rastro nenhum, e o backup ficava tentando (e falhando) todo santo dia, em silêncio total.
         * Agora o motivo real fica registrado nos dois lugares que o admin já olha. */
        @file_put_contents(WS_CACHE . '/backup.log', date('Y-m-d H:i:s') . " auto FALHOU: " . $e->getMessage() . "\n", FILE_APPEND);
        ws_backup_ag_diag('FALHOU: ' . $e->getMessage());
    } finally {
        flock($lock, LOCK_UN); fclose($lock);
    }
}
/* =====================================================================================================================
 * BACKUP EXTERNO CRIPTOGRAFADO + TESTE DE RESTAURAÇÃO (01/10/2026)
 * Criptografia: com a "senha de criptografia" preenchida em Backup → Destinos, TODO backup que SAI do servidor (e-mail,
 *   WhatsApp, Telegram, FTP) vai cifrado em AES-256-GCM (chave derivada da senha por PBKDF2-SHA256, 200 mil rodadas),
 *   arquivo ".wsbk". Sem a senha ninguém lê os dados dos clientes, nem quem pegar o e-mail/FTP. A cópia local (dentro do
 *   servidor) continua normal. Para restaurar: Backup → enviar o .wsbk + a senha. GUARDE A SENHA: sem ela não há volta.
 * Teste de restauração: toda semana (backup_teste_run.php no cron) o último backup é RESTAURADO num banco temporário
 *   (<banco>_restteste), as tabelas principais são comparadas com o banco em uso e o temporário é apagado. Resultado em
 *   Backup e na Saúde do sistema. Nunca toca no banco em uso: views/linhas que citam o banco do RADIUS são puladas.
 * ================================================================================================================== */
const WS_BACKUP_CRIPTO_MAGIA = "WSBK1";

function ws_backup_cifrar(string $bin, string $senha): string {
    $salt = random_bytes(16); $iv = random_bytes(12);
    $chave = hash_pbkdf2('sha256', $senha, $salt, 200000, 32, true);
    $tag = '';
    $ct = openssl_encrypt($bin, 'aes-256-gcm', $chave, OPENSSL_RAW_DATA, $iv, $tag, WS_BACKUP_CRIPTO_MAGIA, 16);
    if ($ct === false) throw new RuntimeException('falha ao criptografar o backup');
    return WS_BACKUP_CRIPTO_MAGIA . $salt . $iv . $tag . $ct;
}
/** null = senha errada ou arquivo corrompido. */
function ws_backup_decifrar(string $blob, string $senha): ?string {
    if (strncmp($blob, WS_BACKUP_CRIPTO_MAGIA, 5) !== 0 || strlen($blob) < 5 + 16 + 12 + 16 + 1) return null;
    $salt = substr($blob, 5, 16); $iv = substr($blob, 21, 12); $tag = substr($blob, 33, 16); $ct = substr($blob, 49);
    $chave = hash_pbkdf2('sha256', $senha, $salt, 200000, 32, true);
    $pt = openssl_decrypt($ct, 'aes-256-gcm', $chave, OPENSSL_RAW_DATA, $iv, $tag, WS_BACKUP_CRIPTO_MAGIA);
    return $pt === false ? null : $pt;
}

/** Restaura o backup num banco TEMPORÁRIO, compara com o banco em uso e apaga. Grava cache/backup_teste.json. */
function ws_backup_teste_restaurar(?string $arquivo = null): array {
    @set_time_limit(0);
    $ini = microtime(true);
    $res = ['em' => time(), 'ok' => false, 'arquivo' => '', 'detalhes' => [], 'erro' => ''];
    $salvar = function () use (&$res, $ini) {
        $res['segundos'] = (int)round(microtime(true) - $ini);
        @file_put_contents(WS_CACHE . '/backup_teste.json', json_encode($res, JSON_UNESCAPED_UNICODE)); @chmod(WS_CACHE . '/backup_teste.json', 0640);
        if (function_exists('ws_evento')) try { ws_evento(ws_db(), null, 'backup', ($res['ok'] ? '✅ Teste de restauração OK' : '❌ Teste de restauração FALHOU') . ': ' . $res['arquivo'] . ($res['erro'] !== '' ? ' — ' . $res['erro'] : '')); } catch (Throwable $e) {}
        return $res;
    };
    try {
        if ($arquivo === null) {
            $l = glob(WS_BACKUP_DIR . '/*.sql') ?: [];
            usort($l, fn($a, $b) => filemtime($b) <=> filemtime($a));
            $arquivo = $l[0] ?? '';
        }
        $res['arquivo'] = basename((string)$arquivo);
        if ($arquivo === '' || !is_file($arquivo)) throw new RuntimeException('nenhum backup .sql na pasta para testar');
        $prod = ws_db(); $nomeProd = (string)$prod->query('SELECT DATABASE()')->fetchColumn();
        $nomeTeste = $nomeProd . '_restteste';
        if (!preg_match('/^[A-Za-z0-9_]+$/', $nomeTeste) || $nomeTeste === $nomeProd) throw new RuntimeException('nome de banco inválido');
        $c = ws_db_config();
        $pdo = new PDO("mysql:host={$c['host']};port={$c['porta']};charset=utf8mb4", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("DROP DATABASE IF EXISTS `$nomeTeste`");
        $pdo->exec("CREATE DATABASE `$nomeTeste` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$nomeTeste`");
        try {
            $sql = (string)file_get_contents($arquivo);
            if (strpos($sql, 'WellSystem') === false) throw new RuntimeException('o arquivo não parece um backup do WellSystem');
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            $n = 0; $erros = 0; $pulados = 0;
            foreach (explode(";\n", $sql) as $stmt) {
                $stmt = trim($stmt);
                if ($stmt === '' || strncmp($stmt, '--', 2) === 0) continue;
                // Proteção: nada que cite outro banco (views do RADIUS) nem troque de banco roda no teste.
                if (preg_match('/^\s*USE\s|`radius`\.|`mkradius`\.|\bVIEW\b|DEFINER\s*=/i', $stmt) || preg_match('/`' . preg_quote($nomeProd, '/') . '`\./', $stmt)) { $pulados++; continue; }
                try { $pdo->exec($stmt); $n++; } catch (Throwable $e) { $erros++; }
            }
            unset($sql);
            // Confere as tabelas que importam: precisam existir e ter (quase) o mesmo tanto de linhas do banco em uso.
            $ok = true;
            foreach (['ws_cliente', 'ws_contrato', 'ws_fatura', 'ws_pagamento', 'ws_plano', 'ws_usuario'] as $t) {
                $p = (int)$prod->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
                try { $b = (int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); } catch (Throwable $e) { $b = -1; }
                $bom = $b >= 0 && ($p === 0 || $b >= (int)floor($p * 0.95));
                $res['detalhes'][$t] = ['backup' => $b, 'em_uso' => $p, 'ok' => $bom];
                if (!$bom) $ok = false;
            }
            $res['instrucoes'] = $n; $res['erros'] = $erros; $res['pulados'] = $pulados;
            $res['ok'] = $ok;
            if (!$ok) $res['erro'] = 'tabelas principais incompletas no backup';
        } finally {
            try { $pdo->exec("DROP DATABASE IF EXISTS `$nomeTeste`"); } catch (Throwable $e) {}
        }
    } catch (Throwable $e) {
        $res['erro'] = mb_substr($e->getMessage(), 0, 200);
    }
    return $salvar();
}
