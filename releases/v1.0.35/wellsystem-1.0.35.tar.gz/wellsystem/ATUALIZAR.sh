#!/bin/bash
# =================================================================================================
# WellSystem — publica uma versão nova no servidor. Um comando, qualquer cenário.
#
#     bash ATUALIZAR.sh
#
# Rode de dentro da pasta do pacote novo, onde quer que ela esteja. NÃO é preciso dizer onde o
# sistema está instalado: o script descobre sozinho (ws-ambiente.sh) e age conforme o cenário.
#
#   servidor  WellSystem direto no servidor (INSTALAR.sh), normalmente em /var/www/wellsystem.
#             Publica o código e também mantém o que é do servidor: tarefas agendadas, menu de
#             terminal, scripts do FreeRADIUS próprio e configuração de cache do Apache.
#   mkauth    Addon em /opt/mk-auth/admin/addons/wellsystem. Publica SÓ o código do addon — o
#             servidor, o FreeRADIUS, o Apache e o menu do root são do MK-Auth e não são tocados.
#   addon     Addon dentro de outro ERP. Mesma regra: só o código.
#   docker    Não copia arquivo nenhum: mostra o comando que reconstrói a imagem na pasta do
#             projeto (o código de um container mora DENTRO da imagem).
#
# Para forçar um destino específico (servidor com duas instalações, por exemplo):
#     WS_DESTINO=/caminho/do/sistema bash ATUALIZAR.sh
#
# O QUE ELE NÃO TOCA — de propósito, em nenhum cenário:
#   cache/           configuração desta instalação (banco, ativação, preferências)
#   uploads/         fotos, documentos e anexos dos clientes (e o Mkfiles da OLT)
#   cache_trafego/   conexão da OLT, histórico de tráfego, relatórios
#   assets/          logo enviada pela tela (o --delete a apagava a cada atualização)
#   backups/         BACKUPS DO BANCO feitos pela tela de Backup
#   Mkfiles/         fotos de modelos de ONU/ONT (pasta antiga, de antes de uploads/mkfiles)
#
# backups/ entrou nesta lista depois de o defeito ser encontrado: ela não estava protegida, e o
# "rsync --delete" deixava a pasta do servidor igual à do pacote — ou seja, APAGAVA os backups do
# banco a cada atualização (ou os trocava pelos do computador que gerou o pacote).
#
# Mkfiles entrou pelo mesmo motivo, antes: as fotos dos equipamentos ficavam em <projeto>/Mkfiles,
# e o --delete as apagava a cada publicação. O lugar definitivo passou a ser uploads/mkfiles.
#
# São as pastas que pertencem AO SERVIDOR, não ao pacote. Sobrescrevê-las devolveria a instalação
# ao estado de fábrica. As colunas novas do banco se criam sozinhas na primeira página aberta.
# =================================================================================================
set -e

cd "$(dirname "$0")"
ORIGEM="$(pwd -P)"

[ "$(id -u)" = "0" ] || { echo "ERRO: rode como root (sudo bash ATUALIZAR.sh)" >&2; exit 1; }
[ -f "$ORIGEM/config.php" ] || { echo "ERRO: rode de dentro da pasta do pacote do WellSystem." >&2; exit 1; }
[ -f "$ORIGEM/ws-ambiente.sh" ] || { echo "ERRO: ws-ambiente.sh nao veio no pacote — gere o pacote de novo." >&2; exit 1; }
# shellcheck source=ws-ambiente.sh
. "$ORIGEM/ws-ambiente.sh"

echo ''
echo '================================================='
echo ' WellSystem — atualizacao'
echo '================================================='

# ---- 0) dentro de um container? ----------------------------------------------------------------
if ws_amb_dentro_container; then
    echo 'Este script esta rodando DENTRO de um container.'
    echo 'Em Docker o codigo fica na imagem: atualize no servidor (host), na pasta do projeto:'
    echo '    docker compose up -d --build'
    exit 1
fi

# ---- 1) onde está o sistema -------------------------------------------------------------------
if [ -n "${WS_DESTINO:-}" ]; then
    DESTINO="$(cd "$WS_DESTINO" 2>/dev/null && pwd -P)" || { echo "ERRO: WS_DESTINO=$WS_DESTINO nao existe." >&2; exit 1; }
    ws_amb_eh_wellsystem "$DESTINO" || { echo "ERRO: $DESTINO nao e uma instalacao do WellSystem." >&2; exit 1; }
else
    mapfile -t INSTALACOES < <(ws_amb_instalacoes "$ORIGEM")

    if [ "${#INSTALACOES[@]}" -eq 0 ]; then
        # Nada publicado no servidor. Pode ser Docker — o compose diz onde está o projeto.
        mapfile -t CONTAINERS < <(ws_amb_docker)
        if [ "${#CONTAINERS[@]}" -gt 0 ]; then
            PASTA_COMPOSE="${CONTAINERS[0]#*|}"
            echo "Cenario detectado: DOCKER (container ${CONTAINERS[0]%%|*})"
            echo ''
            echo 'Em Docker nao se copia arquivo: o codigo mora dentro da imagem. Para atualizar,'
            echo 'copie o conteudo deste pacote para a pasta do projeto e reconstrua:'
            echo ''
            if [ -n "$PASTA_COMPOSE" ]; then
                echo "    rsync -a --exclude cache/ --exclude uploads/ --exclude cache_trafego/ --exclude backups/ --exclude .env \\"
                echo "          \"$ORIGEM\"/ \"$PASTA_COMPOSE\"/"
                echo "    cd \"$PASTA_COMPOSE\" && docker compose up -d --build"
            else
                echo '    (pasta do projeto nao identificada pelo docker compose)'
                echo '    cd <pasta onde esta o docker-compose.yml> && docker compose up -d --build'
            fi
            echo ''
            echo 'Nada foi alterado.'
            exit 0
        fi
        echo 'ERRO: nao encontrei o WellSystem publicado neste servidor.' >&2
        echo '      Servidor novo? Use o INSTALAR.sh.' >&2
        echo '      Instalado num lugar fora do padrao? Informe:  WS_DESTINO=/caminho bash ATUALIZAR.sh' >&2
        exit 1
    fi

    if [ "${#INSTALACOES[@]}" -eq 1 ]; then
        DESTINO="${INSTALACOES[0]}"
    else
        echo 'Encontrei mais de uma instalacao do WellSystem neste servidor:'
        i=1; for d in "${INSTALACOES[@]}"; do echo "    $i) $d  [$(ws_amb_cenario "$d")]"; i=$((i+1)); done
        if [ -t 0 ]; then
            printf 'Qual atualizar? (numero): '; read -r escolha
            DESTINO="${INSTALACOES[$((escolha-1))]:-}"
            [ -n "$DESTINO" ] && [ "$escolha" -ge 1 ] 2>/dev/null || { echo 'Escolha invalida. Nada foi alterado.' >&2; exit 1; }
        else
            echo 'Sem terminal para perguntar. Rode de novo informando:  WS_DESTINO=/caminho bash ATUALIZAR.sh' >&2
            exit 1
        fi
    fi
fi

CENARIO="$(ws_amb_cenario "$DESTINO")"
DONO="$(ws_amb_dono "$DESTINO")"
echo "instalacao: $DESTINO"
echo "cenario:    $CENARIO"
echo "dono:       $DONO"
echo ''

# ---- 2) código --------------------------------------------------------------------------------
# Leitura dos comprovantes PIX (selo antifraude): instala o que faltar (PDF + OCR em português). Opcional e silencioso.
if command -v apt-get >/dev/null 2>&1; then
    for pkg in poppler-utils tesseract-ocr tesseract-ocr-por; do
        dpkg -s "$pkg" >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$pkg" >/dev/null 2>&1 || true
    done
    # SNMP (gráficos e sinal da OLT): servidor sem o pacote ganha na atualização. O Apache precisa REINICIAR (não recarregar): o apt pode
    # atualizar o PHP junto, e um "reload" deixa o módulo antigo na memória com as extensões novas — o banco deixa de abrir (21/10/2026).
    if ! command -v snmpwalk >/dev/null 2>&1 || ! php -m 2>/dev/null | grep -qi '^snmp$'; then
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends snmp php-snmp >/dev/null 2>&1 \
            && { systemctl restart apache2 >/dev/null 2>&1 || systemctl restart httpd >/dev/null 2>&1 || true; } || true
    fi
fi

echo "==> publicando o codigo"
# --exclude protege o que é do servidor. rsync é o preferido (copia só o que mudou).
if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete \
          --exclude 'cache/' --exclude 'uploads/' --exclude 'cache_trafego/' --exclude 'backups/' --exclude 'assets/' \
          --exclude 'Mkfiles/' --exclude '.env' --exclude '.git/' --exclude 'docs_templates/' \
          "$ORIGEM"/ "$DESTINO"/
else
    # SEM rsync: item a item, PULANDO as pastas do servidor. Um "cp -a origem/. destino/" copiaria
    # cache/ e uploads/ do pacote por cima das do servidor — o contrário do prometido acima.
    for item in "$ORIGEM"/* "$ORIGEM"/.[!.]*; do
        [ -e "$item" ] || continue
        nome="$(basename "$item")"
        case "$nome" in cache|uploads|cache_trafego|backups|assets|Mkfiles|.env|.git|docs_templates) continue ;; esac
        cp -a "$item" "$DESTINO/" 2>/dev/null || true
    done
fi
# MODELOS DE DOCUMENTO (contratos, recibo, ficha, carta): são do PROVEDOR depois de editados. A atualização só
# ACRESCENTA o modelo que ainda não existe no servidor; nunca sobrescreve um que o provedor ajustou (antes o
# rsync --delete trocava o contrato editado pelo de fábrica a cada atualização).
if [ -d "$ORIGEM/docs_templates" ]; then
    mkdir -p "$DESTINO/docs_templates"
    for m in "$ORIGEM"/docs_templates/*.txt; do
        [ -e "$m" ] || continue
        [ -e "$DESTINO/docs_templates/$(basename "$m")" ] || cp -a "$m" "$DESTINO/docs_templates/" 2>/dev/null || true
    done
fi

# ---- 3) dono e permissões — com o dono DETECTADO, não um usuário fixo --------------------------
# uploads/mkfiles: fotos de modelo de ONU/ONT; dentro de uploads/ porque é a pasta que sobrevive à
# publicação e já tem o .htaccess que proíbe execução de PHP.
mkdir -p "$DESTINO/cache" "$DESTINO/uploads" "$DESTINO/uploads/mkfiles" "$DESTINO/assets" "$DESTINO/cache_trafego" "$DESTINO/backups"
chown -R "$DONO" "$DESTINO"
chmod -R 775 "$DESTINO/cache" "$DESTINO/uploads" "$DESTINO/assets" "$DESTINO/cache_trafego" "$DESTINO/backups"
[ -d "$DESTINO/Mkfiles" ] && chmod -R 775 "$DESTINO/Mkfiles" 2>/dev/null || true

# Todo script volta a ser executável e sem os \r do Windows (o unzip de um ZIP feito no Windows não
# preserva o bit de execução, e o \r dá o enganoso "bad interpreter: /bin/sh^M").
for s in "$ORIGEM"/*.sh "$DESTINO"/*.sh; do
    [ -f "$s" ] || continue
    sed -i 's/\r$//' "$s" 2>/dev/null || true
    chmod +x "$s" 2>/dev/null || true
done

# ---- 4) configuração do banco — vale para todos os cenários ------------------------------------
echo "==> configuracao do banco"
# A pasta do espelho persistente nasce em TODO cenário (não só quando cache/ já tem a config): num
# addon em que o PHP ainda grava em /var/tmp, é ela que passa a guardar a cópia que sobrevive ao
# reboot. O PHP só não cria sozinho porque /var/lib pertence ao root.
mkdir -p /var/lib/wellsystem && chown "$DONO" /var/lib/wellsystem 2>/dev/null && chmod 750 /var/lib/wellsystem 2>/dev/null || true
# Confere se está no lugar e CONECTA; se sumiu (reboot com /tmp privado, cópia de pasta), restaura
# de um espelho ou, no cenário servidor, da senha guardada pelo INSTALAR.sh.
ws_amb_restaurar_config_banco "$DESTINO" "$CENARIO" "$DONO"
ws_amb_espelhar_config_banco "$DESTINO" "$DONO"

# ---- 5) o que é do SERVIDOR — só quando o servidor é nosso -------------------------------------
if [ "$CENARIO" = "servidor" ]; then
    echo "==> servidor: scripts, tarefas agendadas, menu e Apache"

    # Scripts de sistema do FreeRADIUS próprio: ficam fora da pasta web (só o root os altera).
    for s in ws-certificado.sh ws-radius-fallback.sh; do
        [ -f "$ORIGEM/$s" ] && install -m 750 -o root -g "${DONO##*:}" "$ORIGEM/$s" "/usr/local/sbin/$s"
    done

    # TAREFAS AUTOMÁTICAS — reescritas a cada atualização: rotina nova só roda se entrar aqui.
    # A lista é a mesma do INSTALAR.sh; as duas precisam andar juntas.
    if [ -d /etc/cron.d ]; then
        U="${DONO%%:*}"
        cat > /etc/cron.d/wellsystem <<CRON
*/2 * * * * $U php $DESTINO/radius_sync.php >/dev/null 2>&1
* * * * * $U php $DESTINO/lytex_run.php >/dev/null 2>&1
* * * * * $U php $DESTINO/emitir_pendentes_run.php 3 0 >/dev/null 2>&1
* * * * * $U php $DESTINO/emitir_pendentes_run.php 3 1 >/dev/null 2>&1
* * * * * $U php $DESTINO/emitir_pendentes_run.php 3 2 >/dev/null 2>&1
* * * * * $U php $DESTINO/bb_pix_run.php >/dev/null 2>&1
* * * * * $U php $DESTINO/saude_run.php >/dev/null 2>&1
* * * * * root php $DESTINO/atualizar_run.php >/dev/null 2>&1
*/10 * * * * $U php $DESTINO/zonas_sync.php >/dev/null 2>&1
0 9   * * * $U php $DESTINO/cobranca_run.php >/dev/null 2>&1
30 6  * * * $U php $DESTINO/faturar_run.php >/dev/null 2>&1
0 3   * * * $U php $DESTINO/backup_run.php >/dev/null 2>&1
30 4  * * 0 $U php $DESTINO/backup_teste_run.php >/dev/null 2>&1
* * * * * root $DESTINO/olt_monitor.sh scan >/dev/null 2>&1
1 0 1 * * root $DESTINO/olt_monitor.sh relatorio >/dev/null 2>&1
CRON
        chmod 644 /etc/cron.d/wellsystem
        echo '    tarefas agendadas atualizadas'
    fi

    # Menu de terminal: mora fora da pasta do sistema, então o rsync não o alcança.
    # Também (re)escreve a abertura automática no login do root — servidor que só recebia
    # atualização tinha o comando, mas o menu nunca abria sozinho ao entrar pelo PuTTY/SSH.
    ws_amb_menu_instalar "$DESTINO"

    # Cache e compressão dos estáticos na configuração do Apache (testa antes; desfaz se falhar).
    [ -f "$DESTINO/ws-apache-desempenho.sh" ] && bash "$DESTINO/ws-apache-desempenho.sh" "$DESTINO"
    # Menu do servidor no navegador (Provedor → Menu do servidor): ttyd + Apache, com teste e reversão.
    [ -f "$DESTINO/ws-terminal-web.sh" ] && bash "$DESTINO/ws-terminal-web.sh" "$DESTINO"
    # Nome resumido na sessão IPoE: atualiza a regra do FreeRADIUS (cópia, teste -CX e volta
    # automática; só reinicia o FreeRADIUS se a regra realmente mudou).
    [ -f "$DESTINO/ws-radius-alias.sh" ] && { bash "$DESTINO/ws-radius-alias.sh" --pasta "$DESTINO" || true; }
    # Sessão presa do mesmo MAC: o cliente que cai e volta entra de novo, sem ser recusado.
    [ -f "$DESTINO/ws-radius-sessao-mac.sh" ] && { bash "$DESTINO/ws-radius-sessao-mac.sh" || true; }
    # Log de autenticação do FreeRADIUS sempre ligado (Login OK / incorrect com motivo; sem senhas).
    [ -f "$DESTINO/ws-radius-log.sh" ] && { bash "$DESTINO/ws-radius-log.sh" || true; }
else
    echo "==> $CENARIO: servidor, Apache, cron e menu do root NAO foram tocados (nao sao do WellSystem)"
    # Nome resumido na sessão IPoE também aqui:
    #   mkauth  o FreeRADIUS é do MK-Auth e já lê sis_cliente.nome_res — o WellSystem grava o nome
    #           resumido lá (mkauth_bridge.php, no cadastro e no cron). Nada no FreeRADIUS.
    #   addon   só se o FreeRADIUS local autentica pelo banco do WellSystem (--auto confere);
    #           o FreeRADIUS de outro ERP, lendo o banco dele, não é tocado.
    if [ "$CENARIO" != "mkauth" ] && [ -f "$DESTINO/ws-radius-alias.sh" ]; then
        bash "$DESTINO/ws-radius-alias.sh" --pasta "$DESTINO" --auto || true
    fi
    if [ "$CENARIO" != "mkauth" ] && [ -f "$DESTINO/ws-radius-sessao-mac.sh" ]; then
        bash "$DESTINO/ws-radius-sessao-mac.sh" --auto || true
    fi
    if [ "$CENARIO" != "mkauth" ] && [ -f "$DESTINO/ws-radius-log.sh" ]; then
        bash "$DESTINO/ws-radius-log.sh" --auto || true
    fi
fi

# ---- 6) recarregar — só o que o cenário permite ------------------------------------------------
echo "==> recarregando"
ws_amb_recarregar "$CENARIO"

echo ''
echo 'PRONTO — recarregue a pagina com Ctrl+F5.'
