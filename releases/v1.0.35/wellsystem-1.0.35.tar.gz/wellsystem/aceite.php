<?php
/**
 * WellSystem — página PÚBLICA do aceite eletrônico do contrato (aceite.php?t=<token>). Regras em aceite_lib.php.
 * Sem login: quem abre é o cliente, pelo link único que recebeu no WhatsApp. Confirma com os 3 primeiros dígitos do
 * CPF/CNPJ do titular. Mostra só os documentos DELE; nada interno do sistema aparece aqui.
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/aceite_lib.php';
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$db = ws_db(); ws_aceite_garantir($db);
$tok = preg_replace('/[^a-f0-9]/', '', (string)($_GET['t'] ?? $_POST['t'] ?? ''));
$reg = null;
if (strlen($tok) === 40) { $q = $db->prepare("SELECT * FROM ws_contrato_aceite WHERE token=?"); $q->execute([$tok]); $reg = $q->fetch(PDO::FETCH_ASSOC) ?: null; }
$prov = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
$provNome = (function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: (($prov['razao'] ?? '') ?: 'Provedor')));
$logo = function_exists('ws_doc_logo_atual') ? ws_doc_logo_atual() : '';
/* PRÓXIMOS PASSOS depois do aceite (01/10/2026, pedido do provedor: "o cliente clica e vai para onde?"): botões com ícone para
   falar com o provedor no WhatsApp, abrir a Central do Assinante (2ª via, PIX, chamados) e salvar o comprovante. */
$waProv = preg_replace('/\D/', '', (string)(($prov['telefone'] ?? '') ?: ($prov['whatsapp'] ?? '')));
if ($waProv !== '' && strlen($waProv) <= 11) $waProv = '55' . ltrim($waProv, '0');
$cenCfg = json_decode((string)@file_get_contents(WS_CACHE . '/central.json'), true) ?: [];
$linkCentral = !empty($cenCfg['host']) ? 'https://' . preg_replace('/[^a-z0-9.\-]/i', '', (string)$cenCfg['host']) : (function_exists('ws_url_publica') ? ws_url_publica() . '/portal.php' : 'portal.php');
$erro = ''; $cli = null; $docs = [];
$estado = 'invalido';
if ($reg) {
    $q = $db->prepare("SELECT id, nome, cpf_cnpj, celular FROM ws_cliente WHERE id=?"); $q->execute([(int)$reg['cliente_id']]); $cli = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$cli) $estado = 'invalido';
    elseif ($reg['status'] === 'aceito') $estado = 'aceito';
    elseif ((int)$reg['tentativas'] >= 5) $estado = 'travado';
    elseif (strtotime($reg['criado_em']) < time() - WS_ACEITE_VALIDADE_DIAS * 86400) $estado = 'expirado';
    else $estado = 'aberto';
}
if ($estado === 'aberto') {
    $docs = ws_aceite_documentos($db, (int)$cli['id']);
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $doc = preg_replace('/\D/', '', (string)$cli['cpf_cnpj']);
        $dig = preg_replace('/\D/', '', (string)($_POST['dig'] ?? ''));
        if (empty($_POST['li'])) $erro = 'Marque que você leu e aceita os documentos.';
        elseif (strlen($doc) < 3 || $dig !== substr($doc, 0, 3)) {
            $db->prepare("UPDATE ws_contrato_aceite SET tentativas=tentativas+1 WHERE id=?")->execute([(int)$reg['id']]);
            $erro = 'Os 3 primeiros dígitos do CPF/CNPJ não conferem.' . ((int)$reg['tentativas'] + 1 >= 5 ? ' Link bloqueado — peça um novo ao atendimento.' : '');
            if ((int)$reg['tentativas'] + 1 >= 5) $estado = 'travado';
        } else {
            // Grava EXATAMENTE o que foi mostrado (textos já preenchidos) e o hash deles — é a prova do que foi aceito.
            $snap = '';
            foreach ($docs as $d) $snap .= "===== {$d['nome']} =====\n" . $d['texto'] . "\n\n";
            $hash = hash('sha256', $snap);
            $ip = mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
            $db->prepare("UPDATE ws_contrato_aceite SET status='aceito', aceito_em=NOW(), ip=?, navegador=?, hash_doc=?, documento=? WHERE id=? AND status='pendente'")
               ->execute([$ip, mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), $hash, $snap, (int)$reg['id']]);
            if (function_exists('ws_evento')) ws_evento($db, (int)$cli['id'], 'contrato', 'Contrato aceito eletronicamente pelo cliente (IP ' . $ip . ', código ' . ws_aceite_codigo($hash) . ').');
            if (!empty($cli['celular']) && is_file(__DIR__ . '/whatsapp.php')) {
                require_once __DIR__ . '/whatsapp.php';
                try { ws_wa_enviar((string)$cli['celular'], "✅ *Contrato aceito*\n\nOlá, " . explode(' ', trim((string)$cli['nome']))[0] . "! Registramos o seu aceite eletrônico em " . date('d/m/Y \à\s H:i') . ".\nCódigo de verificação: *" . ws_aceite_codigo($hash) . "*\n\n" . $provNome, false, ['evento' => 'contrato', 'automatica' => true]); } catch (Throwable $e) {}
            }
            header('Location: aceite.php?t=' . $tok); exit;
        }
    }
}
if ($estado === 'aceito') { $q = $db->prepare("SELECT * FROM ws_contrato_aceite WHERE id=?"); $q->execute([(int)$reg['id']]); $reg = $q->fetch(PDO::FETCH_ASSOC); }
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Aceite do contrato — <?= $h($provNome) ?></title><?= function_exists('ws_favicon_tags') ? ws_favicon_tags() : '' ?>
<style>
:root{--cor:#9E2A3B;--txt:#1f2937;--mut:#6b7280;--bg:#f4f5f7;--card:#fff;--ok:#047857}
@media (prefers-color-scheme:dark){:root{--txt:#e5e7eb;--mut:#9ca3af;--bg:#111318;--card:#1b1e25}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);font:15px/1.55 'Segoe UI',Roboto,Arial,sans-serif}
.wrap{max-width:860px;margin:0 auto;padding:16px}
.topo{display:flex;align-items:center;gap:12px;margin:6px 0 14px}.topo img{max-height:46px;max-width:180px;object-fit:contain}
.topo b{font-size:17px}
.card{background:var(--card);border-radius:14px;padding:16px 18px;box-shadow:0 6px 22px -14px rgba(0,0,0,.35);margin-bottom:14px}
.doc{max-height:58vh;overflow:auto;border:1px solid rgba(128,128,128,.25);border-radius:10px;padding:14px;background:#fff;color:#111;font-family:Georgia,'Times New Roman',serif;font-size:14px}
.doc pre{white-space:pre-wrap;font-family:inherit;margin:0}.doc img{max-width:100%;height:auto}.doc table{max-width:100%}
h2{font-size:16px;margin:0 0 10px}
label.li{display:flex;gap:10px;align-items:flex-start;margin:12px 0;font-size:14.5px}label.li input{width:20px;height:20px;margin-top:2px;flex:none}
input.dig{width:120px;font-size:20px;letter-spacing:6px;text-align:center;padding:10px;border:1px solid rgba(128,128,128,.45);border-radius:10px;background:transparent;color:inherit}
button{width:100%;margin-top:14px;padding:15px;border:0;border-radius:12px;background:var(--cor);color:#fff;font-weight:800;font-size:16px;cursor:pointer}
.erro{background:#fee2e2;color:#991b1b;border-radius:10px;padding:10px 12px;margin-bottom:10px}
.ok{text-align:center}.ok .ic{font-size:46px}.cod{font:700 20px ui-monospace,Consolas,monospace;letter-spacing:2px;color:var(--ok)}
.mut{color:var(--mut);font-size:13px}
.passos{display:grid;gap:10px;margin-top:14px}.passos a{display:flex;align-items:center;gap:12px;padding:13px 14px;border-radius:12px;border:1px solid rgba(128,128,128,.3);text-decoration:none;color:inherit;text-align:left}
.passos a b{display:block;font-size:15px}.passos a span{font-size:13px;color:var(--mut)}.passos a i{font-style:normal;font-size:26px;flex:none}
.passos a.pri{background:var(--cor);color:#fff;border-color:var(--cor)}.passos a.pri span{color:#ffffffcc}
@media print{.naoimp{display:none}.doc{max-height:none;border:0}}
</style></head><body><div class="wrap">
<div class="topo"><?php if ($logo): ?><img src="<?= $h(function_exists('ws_img') ? ws_img($logo) : $logo) ?>" alt=""><?php endif; ?><b><?= $h($provNome) ?></b></div>

<?php if ($estado === 'aberto'): ?>
  <div class="card"><h2>Olá, <?= $h(explode(' ', trim((string)$cli['nome']))[0]) ?>! Leia e aceite o seu contrato</h2>
    <p class="mut" style="margin:0">São <?= count($docs) ?> documento(s), já preenchidos com os seus dados. Role cada um até o fim.</p></div>
  <?php foreach ($docs as $d): ?>
    <div class="card"><h2>📄 <?= $h($d['nome']) ?></h2>
      <div class="doc"><?php if ($d['html']): ?><?= $d['texto'] /* modelo HTML do provedor; dados já escapados em ws_doc_render */ ?><?php else: ?><pre><?= $h($d['texto']) ?></pre><?php endif; ?></div></div>
  <?php endforeach; ?>
  <form method="post" class="card naoimp" autocomplete="off">
    <?php if ($erro): ?><div class="erro"><?= $h($erro) ?></div><?php endif; ?>
    <input type="hidden" name="t" value="<?= $h($tok) ?>">
    <label class="li"><input type="checkbox" name="li" value="1" required> Li e aceito o Contrato do Assinante e o Termo de Prestação de Serviços acima.</label>
    <p style="margin:6px 0">Para confirmar que é você, digite os <b>3 primeiros dígitos</b> do CPF/CNPJ do titular:</p>
    <input class="dig" name="dig" inputmode="numeric" maxlength="3" pattern="\d{3}" required placeholder="•••">
    <button>✍️ Aceitar contrato</button>
    <p class="mut" style="margin:10px 0 0">Ao aceitar, registramos data, hora, endereço de acesso e o conteúdo exato destes documentos, com validade de assinatura eletrônica (Lei 14.063/2020).</p>
  </form>
<?php elseif ($estado === 'aceito'): ?>
  <div class="card ok"><div class="ic">✅</div><h2>Contrato aceito</h2>
    <p>Aceito em <b><?= date('d/m/Y \à\s H:i', strtotime($reg['aceito_em'])) ?></b>.</p>
    <p class="mut">Código de verificação</p><p class="cod"><?= $h(ws_aceite_codigo((string)$reg['hash_doc'])) ?></p>
    <div class="passos naoimp">
      <p style="margin:4px 0 0;text-align:left"><b>E agora?</b> Pronto, está tudo certo com o seu contrato. Se a instalação ainda não foi feita, nossa equipe entra em contato para combinar o dia. Você também pode:</p>
      <?php if ($waProv !== ''): ?><a class="pri" href="https://wa.me/<?= $h($waProv) ?>?text=<?= rawurlencode('Olá! Acabei de aceitar o contrato (código ' . ws_aceite_codigo((string)$reg['hash_doc']) . ').') ?>"><i>💬</i><div><b>Falar com a gente no WhatsApp</b><span>dúvidas, agendar a instalação</span></div></a><?php endif; ?>
      <a href="<?= $h($linkCentral) ?>"><i>👤</i><div><b>Central do Assinante</b><span>2ª via, PIX, chamados e seus dados</span></div></a>
      <a href="#" onclick="window.print();return false"><i>🖨️</i><div><b>Salvar o comprovante (PDF)</b><span>guarde o código de verificação</span></div></a>
    </div></div>
  <div class="card"><h2>Documentos aceitos</h2><div class="doc"><pre><?= $h(strip_tags((string)$reg['documento'])) ?></pre></div></div>
<?php else: ?>
  <div class="card ok"><div class="ic"><?= $estado === 'expirado' ? '⌛' : '🔒' ?></div>
    <h2><?= $estado === 'expirado' ? 'Este link expirou' : ($estado === 'travado' ? 'Link bloqueado por segurança' : 'Link inválido') ?></h2>
    <p class="mut">Peça um novo link ao atendimento de <?= $h($provNome) ?>.</p></div>
<?php endif; ?>
</div></body></html>
