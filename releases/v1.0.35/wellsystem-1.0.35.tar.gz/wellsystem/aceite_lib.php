<?php
/**
 * WellSystem — ACEITE ELETRÔNICO DO CONTRATO (01/10/2026).
 * O operador manda pelo WhatsApp um link único (Documentos do cliente → "Enviar para aceite"). O cliente abre no celular,
 * lê o Contrato do Assinante + o Termo de Prestação de Serviços já preenchidos, confirma a identidade com os 3 primeiros
 * dígitos do CPF/CNPJ e aceita. Fica registrado (tabela ws_contrato_aceite, permanente):
 *   data/hora, IP, navegador, os textos EXATOS que ele aceitou e o hash SHA-256 desses textos (código de verificação).
 * O bloco %aceite% dos contratos passa a mostrar "Aceito eletronicamente em … · código …".
 * Link vale 30 dias; 5 confirmações erradas travam o link (gera-se outro).
 */
require_once __DIR__ . '/docs_lib.php';

const WS_ACEITE_VALIDADE_DIAS = 30;

function ws_aceite_garantir(PDO $db): void {
    static $ok = false; if ($ok) return;
    $db->exec("CREATE TABLE IF NOT EXISTS ws_contrato_aceite (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        token CHAR(40) NOT NULL,
        status VARCHAR(12) NOT NULL DEFAULT 'pendente',
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        enviado_por VARCHAR(80) DEFAULT NULL,
        tentativas TINYINT NOT NULL DEFAULT 0,
        aceito_em DATETIME DEFAULT NULL,
        ip VARCHAR(45) DEFAULT NULL,
        navegador VARCHAR(255) DEFAULT NULL,
        hash_doc CHAR(64) DEFAULT NULL,
        documento MEDIUMTEXT DEFAULT NULL,
        UNIQUE KEY uk_token (token), INDEX idx_cli (cliente_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $ok = true;
}

/** Endereço público do sistema (o mesmo domínio por onde o operador está acessando). */
function ws_aceite_base(): string {
    if (function_exists('ws_url_publica') && ($u = ws_url_publica()) !== '') return $u;   // sempre o domínio, nunca o IP
    $host = preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $pasta = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https' : 'http') . '://' . ($host ?: 'localhost') . $pasta;
}

/** Cria (ou reaproveita o pendente válido) e devolve [token, link]. */
function ws_aceite_criar(PDO $db, int $clienteId, string $por = ''): array {
    ws_aceite_garantir($db);
    $q = $db->prepare("SELECT token FROM ws_contrato_aceite WHERE cliente_id=? AND status='pendente' AND tentativas<5 AND criado_em >= NOW() - INTERVAL " . WS_ACEITE_VALIDADE_DIAS . " DAY ORDER BY id DESC LIMIT 1");
    $q->execute([$clienteId]); $tok = (string)$q->fetchColumn();
    if ($tok === '') {
        $tok = bin2hex(random_bytes(20));
        $db->prepare("INSERT INTO ws_contrato_aceite (cliente_id, token, enviado_por) VALUES (?,?,?)")->execute([$clienteId, $tok, mb_substr($por, 0, 80)]);
    }
    return [$tok, ws_aceite_base() . '/aceite.php?t=' . $tok];
}

/** Textos que o cliente aceita: Contrato do Assinante + Termo de Prestação de Serviços, já preenchidos. */
function ws_aceite_documentos(PDO $db, int $clienteId): array {
    $out = [];
    foreach (['contrato' => 'Contrato do Assinante', 'contrato_ps' => 'Termo de Prestação de Serviços'] as $m => $nome) {
        if (!is_file(WS_DOCS_TPL . "/$m.txt")) continue;
        $out[$m] = ['nome' => $nome, 'html' => ws_doc_eh_html(ws_doc_tpl($m)), 'texto' => ws_doc_render($db, $m, $clienteId)];
    }
    return $out;
}

/** Último aceite concluído do cliente (ou null). */
function ws_aceite_do_cliente(PDO $db, int $clienteId): ?array {
    try { ws_aceite_garantir($db);
        $q = $db->prepare("SELECT id, aceito_em, ip, hash_doc FROM ws_contrato_aceite WHERE cliente_id=? AND status='aceito' ORDER BY aceito_em DESC LIMIT 1");
        $q->execute([$clienteId]); $r = $q->fetch(PDO::FETCH_ASSOC); return $r ?: null;
    } catch (Throwable $e) { return null; }
}

/** Código curto de verificação (do hash dos textos aceitos), ex.: 7F3A-91C2-0B5E. */
function ws_aceite_codigo(string $hash): string { return strtoupper(implode('-', str_split(substr($hash, 0, 12), 4))); }
