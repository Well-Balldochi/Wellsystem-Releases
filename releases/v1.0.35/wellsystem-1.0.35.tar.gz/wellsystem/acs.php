<?php
/**
 * WellSystem — Servidores → ACS / TR-069 (08/10/2026). Tela do provedor para o ACS embutido (acs_cwmp.php + acs_lib.php):
 * endereço/usuário/senha para apontar as ONUs, equipamentos que já falaram com o servidor e as ações (reiniciar, ler/trocar Wi-Fi).
 * Só nível 3+ (infraestrutura). Nada aqui altera OLT, contrato ou cliente.
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
if (!function_exists('ws_pode_infra') || !ws_pode_infra()) { http_response_code(403); echo 'Sem permissão.'; exit; }
require_once __DIR__ . '/acs_lib.php';
$db = ws_db(); ws_acs_tabelas($db);
$cfg = ws_acs_cfg();
$msg = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $a = (string)($_POST['acao'] ?? ''); $did = (int)($_POST['disp'] ?? 0);
    if ($a === 'config') {
        $cfg['ativo'] = empty($_POST['ativo']) ? 0 : 1;
        $cfg['intervalo'] = max(60, min(86400, (int)($_POST['intervalo'] ?? 300)));
        ws_acs_cfg_salvar($cfg); $msg = '✅ Configuração salva.';
    } elseif ($a === 'novasenha') {
        $cfg['senha'] = bin2hex(random_bytes(12)); ws_acs_cfg_salvar($cfg);
        $msg = '✅ Senha nova gerada. Os equipamentos já configurados precisam receber a nova senha.';
    } elseif ($a === 'vincular' && $did > 0) {   // vínculo manual equipamento → cliente (pelo ID do cliente no WellSystem)
        $cid = (int)($_POST['cliente'] ?? 0);
        $q = $db->prepare("SELECT c.id, (SELECT id FROM ws_contrato WHERE cliente_id=c.id ORDER BY (status='ativo') DESC, id DESC LIMIT 1) ct FROM ws_cliente c WHERE c.id=?"); $q->execute([$cid]); $r = $q->fetch(PDO::FETCH_ASSOC);
        if ($r) { $db->prepare("UPDATE ws_acs_dispositivo SET cliente_id=?, contrato_id=? WHERE id=?")->execute([$cid, $r['ct'] ?: null, $did]); $msg = '✅ Equipamento vinculado ao cliente #' . $cid . '.'; }
        else $msg = '❌ Cliente não encontrado.';
    } elseif ($did > 0 && in_array($a, ['reboot', 'ler', 'wifi'], true)) {
        $q = $db->prepare("SELECT id FROM ws_acs_dispositivo WHERE id=?"); $q->execute([$did]);
        if ($q->fetchColumn()) {
            if ($a === 'reboot') { ws_acs_enfileirar($db, $did, 'reboot', [], 'tela:' . (string)(ws_user()['nome'] ?? '')); $msg = '✅ Reinício na fila — executa no próximo contato do equipamento (até ' . (int)ceil($cfg['intervalo'] / 60) . ' min).'; }
            elseif ($a === 'ler') { ws_acs_enfileirar($db, $did, 'wifi_ler', [], 'tela'); $msg = '✅ Leitura na fila.'; }
            else {
                $v = ws_acs_wifi_validar(['banda' => $_POST['banda'] ?? '2.4', 'canal' => ($_POST['canal'] ?? '') === '' ? null : $_POST['canal'], 'ssid' => $_POST['ssid'] ?? '', 'senha' => $_POST['senha'] ?? '']);
                if (!$v['ok']) $msg = '❌ ' . $v['erro'];
                else { ws_acs_enfileirar($db, $did, 'wifi', ['q' => $v['q']], 'tela:' . (string)(ws_user()['nome'] ?? '')); $msg = '✅ Troca de Wi-Fi na fila — executa no próximo contato do equipamento.'; }
            }
        }
    }
    $_SESSION['ws_flash'] = $msg; header('Location: acs.php'); exit;
}
if (!empty($_SESSION['ws_flash'])) { $msg = (string)$_SESSION['ws_flash']; unset($_SESSION['ws_flash']); }
$disp = $db->query("SELECT d.*, c.nome AS cliente FROM ws_acs_dispositivo d LEFT JOIN ws_cliente c ON c.id=d.cliente_id ORDER BY d.ultimo_inform DESC LIMIT 300")->fetchAll(PDO::FETCH_ASSOC);
$tarefas = $db->query("SELECT t.*, d.serial FROM ws_acs_tarefa t JOIN ws_acs_dispositivo d ON d.id=t.dispositivo_id ORDER BY t.id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC);
$ha = function (?string $dt): string { if (!$dt) return '—'; $s = max(0, time() - strtotime($dt)); return $s < 90 ? 'agora' : ($s < 3600 ? floor($s / 60) . ' min' : ($s < 86400 ? floor($s / 3600) . ' h' : floor($s / 86400) . ' d')); };
$url = ws_acs_url();
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — ACS / TR-069</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
.acs-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:14px;margin-bottom:16px}
.acs-k{font-family:ui-monospace,Consolas,monospace;font-size:13px;background:var(--surface-2,rgba(127,127,127,.12));padding:3px 8px;border-radius:7px;overflow-wrap:anywhere;user-select:all}
.acs-wifi{display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end;margin-top:6px}
.acs-wifi input,.acs-wifi select{width:auto;min-width:0;padding:5px 8px;font-size:12.5px}
.acs-st-ok{color:var(--ok)}.acs-st-erro{color:var(--err)}.acs-st-pendente,.acs-st-enviada{color:var(--muted)}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('servidores') ?></header>
<main class="ws-main">
  <h2 style="margin:0 0 6px">📡 ACS / TR-069 — gerência remota das ONUs</h2>
  <p class="ws-muted" style="margin:0 0 14px;font-size:13px">Servidor embutido no WellSystem (sem Docker, sem instalação): a ONU liga para cá de tempos em tempos e leva as tarefas pendentes (reiniciar, ler/trocar Wi-Fi). O robô de atendimento usa a mesma fila.</p>
  <?php if ($msg !== ''): ?><div class="ws-panel" style="margin:0 0 12px"><?= h($msg) ?></div><?php endif; ?>
  <div class="acs-grid">
    <div class="ws-panel">
      <b>Como apontar uma ONU</b>
      <p class="ws-muted" style="font-size:12.5px;margin:6px 0">No equipamento (ou no perfil TR-069 da OLT), preencha:</p>
      <div>URL do ACS: <span class="acs-k"><?= h($url) ?></span></div>
      <div style="margin-top:6px">Usuário: <span class="acs-k"><?= h($cfg['usuario']) ?></span></div>
      <div style="margin-top:6px">Senha: <span class="acs-k"><?= h($cfg['senha']) ?></span></div>
      <p class="ws-muted" style="font-size:12px;margin:8px 0 0">O primeiro contato liga sozinho o "inform periódico" (a cada <?= (int)$cfg['intervalo'] ?> s). O equipamento aparece na tabela abaixo e é ligado ao cliente pelo número de série.</p>
    </div>
    <form method="post" class="ws-panel">
      <input type="hidden" name="acao" value="config">
      <b>Configuração</b>
      <label class="ws-chk" style="display:flex;gap:6px;align-items:center;margin:8px 0"><input type="checkbox" name="ativo" value="1" <?= !empty($cfg['ativo']) ? 'checked' : '' ?> style="width:auto"> ACS ligado (recebe contato dos equipamentos)</label>
      <label style="display:block;font-size:12.5px">Intervalo do inform periódico (segundos)<input type="number" name="intervalo" min="60" max="86400" value="<?= (int)$cfg['intervalo'] ?>"></label>
      <div style="display:flex;gap:8px;margin-top:10px"><button class="ws-btn verde">Salvar</button></div>
    </form>
  </div>

  <h3>Equipamentos (<?= count($disp) ?>)</h3>
  <div class="ws-table-wrap"><table class="ws-table">
    <thead><tr><th>Equipamento</th><th>Cliente</th><th>Último contato</th><th>IP</th><th>Ações</th></tr></thead><tbody>
    <?php if (!$disp): ?><tr><td colspan="5" class="ws-muted" style="text-align:center">Nenhum equipamento falou com o ACS ainda. Configure a URL acima em uma ONU de teste.</td></tr><?php endif; ?>
    <?php foreach ($disp as $d): $on = $d['ultimo_inform'] && (time() - strtotime($d['ultimo_inform'])) < 3 * (int)$cfg['intervalo']; ?>
      <tr>
        <td><b><?= h($d['produto'] ?: '—') ?></b> <span class="ws-muted"><?= h($d['fabricante']) ?></span><br><span class="acs-k"><?= h($d['serial']) ?></span><div class="ws-muted" style="font-size:11.5px"><?= h($d['versao_sw']) ?> · <?= h($d['modelo_dados']) ?></div></td>
        <td><?= $d['cliente_id'] ? '<a href="erp.php?p=cliente&id=' . (int)$d['cliente_id'] . '">' . h($d['cliente']) . '</a>' : '<span class="ws-muted">não vinculado</span>' ?>
          <form method="post" class="acs-wifi"><input type="hidden" name="acao" value="vincular"><input type="hidden" name="disp" value="<?= (int)$d['id'] ?>"><input name="cliente" placeholder="ID do cliente" size="9"><button class="ws-btn">Vincular</button></form></td>
        <td><?= $on ? '🟢' : '🔴' ?> há <?= h($ha($d['ultimo_inform'])) ?></td>
        <td><?= h($d['ip']) ?></td>
        <td>
          <form method="post" style="display:inline"><input type="hidden" name="disp" value="<?= (int)$d['id'] ?>"><button class="ws-btn" name="acao" value="ler">🔎 Ler Wi-Fi</button>
            <button class="ws-btn" name="acao" value="reboot" onclick="return confirm('Reiniciar este equipamento?')">🔄 Reiniciar</button></form>
          <form method="post" class="acs-wifi"><input type="hidden" name="acao" value="wifi"><input type="hidden" name="disp" value="<?= (int)$d['id'] ?>">
            <select name="banda"><option value="2.4">2,4 GHz</option><option value="5">5 GHz</option></select>
            <input name="canal" placeholder="canal (0=auto)" size="9"><input name="ssid" placeholder="nome da rede" size="12"><input name="senha" placeholder="senha (8+)" size="10" autocomplete="off">
            <button class="ws-btn primary">Trocar Wi-Fi</button></form>
        </td>
      </tr>
    <?php endforeach; ?></tbody></table></div>

  <h3 style="margin-top:18px">Últimas tarefas</h3>
  <div class="ws-table-wrap"><table class="ws-table">
    <thead><tr><th>#</th><th>Equipamento</th><th>Tarefa</th><th>Situação</th><th>Resultado</th><th>Criada</th></tr></thead><tbody>
    <?php foreach ($tarefas as $t): ?>
      <tr><td><?= (int)$t['id'] ?></td><td class="acs-k"><?= h($t['serial']) ?></td><td><?= h($t['tipo']) ?><?= $t['origem'] ? ' <span class="ws-muted">(' . h($t['origem']) . ')</span>' : '' ?></td>
        <td class="acs-st-<?= h($t['status']) ?>"><?= h($t['status']) ?></td><td style="max-width:420px;overflow-wrap:anywhere"><?= h(mb_substr((string)$t['resultado'], 0, 160)) ?></td><td><?= h($ha($t['criado_em'])) ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
  <form method="post" style="margin-top:14px" onsubmit="return confirm('Gerar uma senha nova? Os equipamentos já configurados deixarão de falar com o ACS até receberem a nova.')"><input type="hidden" name="acao" value="novasenha"><button class="ws-btn">🔑 Gerar senha nova do ACS</button></form>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
