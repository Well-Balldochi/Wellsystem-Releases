<?php
/**
 * WellSystem — endpoint CWMP/TR-069 que as ONUs/roteadores chamam (08/10/2026). Regras e funções em acs_lib.php.
 * URL para configurar no equipamento: https://SEU-ERP/acs_cwmp.php  (usuário/senha: tela "ACS / TR-069").
 * Só responde a equipamento autenticado; qualquer outra chamada recebe 401 e não toca em nada.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/api_chatbot.php';   // ws_chatbot_header_auth()
require_once __DIR__ . '/acs_lib.php';

header_remove('X-Powered-By');
$cfg = ws_acs_cfg();
if (empty($cfg['ativo'])) { http_response_code(503); exit; }

// Abrir o endereço no navegador (GET) só mostra que o ACS está de pé — quem fala CWMP usa POST e passa pela senha abaixo.
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? '')) === 'GET') { header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: no-store'); echo "WellSystem ACS ativo.
"; exit; }
// ---- autenticação (HTTP Basic) ----
$u = (string)($_SERVER['PHP_AUTH_USER'] ?? ''); $p = (string)($_SERVER['PHP_AUTH_PW'] ?? '');
if ($u === '' && preg_match('/^\s*basic\s+(.+)$/i', ws_chatbot_header_auth(), $m)) { $dec = explode(':', (string)base64_decode($m[1]), 2); $u = $dec[0]; $p = $dec[1] ?? ''; }
if (!hash_equals((string)$cfg['usuario'], $u) || !hash_equals((string)$cfg['senha'], $p)) {
    usleep(300000);
    header('WWW-Authenticate: Basic realm="WellSystem ACS"'); http_response_code(401); exit;
}

$db = ws_db();
ws_acs_tabelas($db);
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
$corpo = (string)file_get_contents('php://input');
header('Content-Type: text/xml; charset=utf-8');
header('Cache-Control: no-store');

/** Equipamento desta sessão: cookie assinado; sem cookie (alguns CPE não guardam), o que fez Inform deste IP nos últimos 2 min. */
$achaDisp = function () use ($db, $ip, $cfg): ?array {
    if (!empty($_COOKIE['wsacs']) && preg_match('/^(\d+)\.([0-9a-f]{20})$/', (string)$_COOKIE['wsacs'], $m) && hash_equals(substr(hash_hmac('sha256', $m[1], (string)$cfg['senha']), 0, 20), $m[2])) {
        $q = $db->prepare("SELECT * FROM ws_acs_dispositivo WHERE id=?"); $q->execute([(int)$m[1]]); $r = $q->fetch(PDO::FETCH_ASSOC); if ($r) return $r;
    }
    $q = $db->prepare("SELECT * FROM ws_acs_dispositivo WHERE ip=? AND ultimo_inform >= NOW() - INTERVAL 2 MINUTE ORDER BY ultimo_inform DESC LIMIT 1"); $q->execute([$ip]);
    $r = $q->fetch(PDO::FETCH_ASSOC); return $r ?: null;
};
/** Manda a próxima tarefa do equipamento, ou encerra a sessão (204). */
$proxima = function (array $disp, string $ns) use ($db) {
    $t = ws_acs_proxima($db, (int)$disp['id']);
    if (!$t) { http_response_code(204); exit; }
    $disp = $db->query("SELECT * FROM ws_acs_dispositivo WHERE id=" . (int)$disp['id'])->fetch(PDO::FETCH_ASSOC);
    $rpc = ws_acs_rpc_da_tarefa($db, $t, $disp);
    if ($rpc === null) { http_response_code(204); exit; }
    $db->prepare("UPDATE ws_acs_tarefa SET status='enviada', enviado_em=NOW() WHERE id=?")->execute([$t['id']]);
    echo ws_acs_xml($rpc, 'ws-' . $t['id'], $ns); exit;
};

if (trim($corpo) === '') {   // POST vazio = "pode mandar o que tiver" (depois do InformResponse ou de uma resposta)
    $disp = $achaDisp(); if (!$disp) { http_response_code(204); exit; }
    $proxima($disp, WS_ACS_NS_PADRAO);
}
$env = ws_acs_ler($corpo);
if (!$env) { http_response_code(400); exit; }
$ns = $env['ns'] !== '' ? $env['ns'] : WS_ACS_NS_PADRAO;

if ($env['metodo'] === 'Inform') {
    $disp = ws_acs_inform($db, $env, $ip);
    if (!$disp) { http_response_code(400); exit; }
    // tarefas "enviada" que ficaram sem resposta numa sessão anterior voltam à fila (a ONU caiu/reiniciou no meio)
    $db->prepare("UPDATE ws_acs_tarefa SET status='pendente' WHERE dispositivo_id=? AND status='enviada' AND enviado_em < NOW() - INTERVAL 2 MINUTE AND tipo<>'reboot'")->execute([$disp['id']]);
    $db->prepare("UPDATE ws_acs_tarefa SET status='ok', resultado='Equipamento reiniciou (voltou a falar com o ACS)', concluido_em=NOW() WHERE dispositivo_id=? AND status='enviada' AND tipo='reboot'")->execute([$disp['id']]);
    setcookie('wsacs', (int)$disp['id'] . '.' . substr(hash_hmac('sha256', (string)(int)$disp['id'], (string)$cfg['senha']), 0, 20), ['path' => '/', 'httponly' => true, 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite' => 'Lax']);
    echo ws_acs_xml('<cwmp:InformResponse><MaxEnvelopes>1</MaxEnvelopes></cwmp:InformResponse>', $env['id'] !== '' ? $env['id'] : 'ws', $ns);
    exit;
}
if ($env['metodo'] === 'TransferComplete') { echo ws_acs_xml('<cwmp:TransferCompleteResponse/>', $env['id'] !== '' ? $env['id'] : 'ws', $ns); exit; }

// resposta (ou falha) do equipamento a uma tarefa nossa
$disp = $achaDisp(); if (!$disp) { http_response_code(204); exit; }
ws_acs_resposta_tarefa($db, $disp, $env);
$proxima($disp, $ns);
