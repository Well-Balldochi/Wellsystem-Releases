<?php
/**
 * WellSystem — ACS TR-069 (CWMP) EMBUTIDO (08/10/2026).
 *
 * O servidor de gerência das ONUs/roteadores é PHP puro, dentro do próprio WellSystem: sem Docker, sem GenieACS, sem MongoDB, sem porta
 * nova — a ONU fala HTTPS com `acs_cwmp.php` (mesmo Apache/vhost do ERP). Sobe junto com o pacote em qualquer Linux novo; credenciais
 * e tabelas nascem sozinhas no primeiro uso (nada de passo manual).
 *
 *   • acs_cwmp.php  → endpoint CWMP (Inform, GetParameterValues, SetParameterValues, Reboot) — só fala com equipamento autenticado;
 *   • acs.php       → tela do provedor (equipamentos, ações, URL/usuário/senha para apontar as ONUs);
 *   • /api/suporte  → o robô pede "trocar Wi-Fi" / "reiniciar a ONU" e a ação entra na fila do equipamento (ws_acs_enfileirar).
 *
 * Como a ONU quase nunca é alcançável de fora (CGNAT/VLAN de gerência), quem manda é ela: a cada "inform periódico" (padrão 5 min) ela
 * liga para cá e leva as tarefas pendentes. O próprio ACS liga o inform periódico no primeiro contato.
 * Nada aqui mexe em OLT, cliente ou contrato; só lê/grava ws_acs_* e acs.json (cache/).
 */

if (!defined('WS_ACS_NS_PADRAO')) define('WS_ACS_NS_PADRAO', 'urn:dslforum-org:cwmp-1-0');

/** Configuração do ACS (cache/acs.json). Credenciais aleatórias nascem sozinhas na primeira leitura. */
function ws_acs_cfg(): array {
    $f = WS_CACHE . '/acs.json';
    $c = json_decode((string)@file_get_contents($f), true); if (!is_array($c)) $c = [];
    $novo = false;
    if (empty($c['usuario'])) { $c['usuario'] = 'acs' . bin2hex(random_bytes(3)); $novo = true; }
    if (empty($c['senha']))   { $c['senha'] = bin2hex(random_bytes(12)); $novo = true; }
    if (!isset($c['ativo']))  { $c['ativo'] = 1; $novo = true; }
    if (empty($c['intervalo'])) { $c['intervalo'] = 300; $novo = true; }
    if ($novo) ws_acs_cfg_salvar($c);
    return $c;
}
function ws_acs_cfg_salvar(array $c): void { @file_put_contents(WS_CACHE . '/acs.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); @chmod(WS_CACHE . '/acs.json', 0640); }

/** Endereço que as ONUs devem usar (o mesmo do ERP). */
function ws_acs_url(): string {
    $base = trim((string)@file_get_contents(WS_CACHE . '/api_base.txt'));   // guardado pela API: https://host/api
    if ($base !== '') return preg_replace('#/api/?$#', '', $base) . '/acs_cwmp.php';
    $h = (string)($_SERVER['HTTP_HOST'] ?? 'SEU-SERVIDOR');
    $https = (($_SERVER['HTTPS'] ?? '') !== '' && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    return ($https ? 'https' : 'http') . '://' . $h . '/acs_cwmp.php';
}

function ws_acs_tabelas(PDO $db): void {
    static $ok = false; if ($ok) return; $ok = true;
    $db->exec("CREATE TABLE IF NOT EXISTS ws_acs_dispositivo (
        id INT AUTO_INCREMENT PRIMARY KEY,
        serial VARCHAR(80) NOT NULL,
        oui VARCHAR(12) DEFAULT NULL,
        fabricante VARCHAR(80) DEFAULT NULL,
        produto VARCHAR(80) DEFAULT NULL,
        versao_sw VARCHAR(80) DEFAULT NULL,
        modelo_dados VARCHAR(8) NOT NULL DEFAULT 'tr098',
        ip VARCHAR(45) DEFAULT NULL,
        url_conexao VARCHAR(255) DEFAULT NULL,
        contrato_id INT DEFAULT NULL,
        cliente_id INT DEFAULT NULL,
        parametros MEDIUMTEXT DEFAULT NULL,
        provisionado TINYINT NOT NULL DEFAULT 0,
        ultimo_inform DATETIME DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_serial (serial), INDEX idx_contrato (contrato_id), INDEX idx_cliente (cliente_id), INDEX idx_inform (ultimo_inform)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $db->exec("CREATE TABLE IF NOT EXISTS ws_acs_tarefa (
        id INT AUTO_INCREMENT PRIMARY KEY,
        dispositivo_id INT NOT NULL,
        tipo VARCHAR(20) NOT NULL,
        dados MEDIUMTEXT DEFAULT NULL,
        status VARCHAR(12) NOT NULL DEFAULT 'pendente',
        resultado MEDIUMTEXT DEFAULT NULL,
        origem VARCHAR(40) DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        enviado_em DATETIME DEFAULT NULL,
        concluido_em DATETIME DEFAULT NULL,
        INDEX idx_disp (dispositivo_id, status), INDEX idx_status (status, criado_em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/* ---------- vínculo equipamento ↔ contrato ---------- */
/** Formatos em que o MESMO serial aparece no cadastro: "DD72E68F797D" (GPON) ↔ "44443732e68f797d" (hex que o WellSystem guarda) ↔ texto cru. */
function ws_acs_serial_formas(string $serial, string $oui = ''): array {
    $s = trim($serial); if ($s === '') return [];
    $f = [strtolower($s), strtolower(preg_replace('/[^0-9A-Za-z]/', '', $s))];
    $lim = preg_replace('/[^0-9A-Za-z]/', '', $s);
    if (preg_match('/^([A-Za-z0-9]{4})([0-9A-Fa-f]{8})$/', $lim, $m)) $f[] = strtolower(bin2hex($m[1]) . $m[2]);     // vendor ASCII + 8 hex = o hex do WellSystem
    if (preg_match('/^[0-9A-Fa-f]{16}$/', $lim)) $f[] = strtolower($lim);
    if ($oui !== '') $f[] = strtolower($oui . $lim);
    return array_values(array_unique(array_filter($f)));
}
/** IP de internet que o equipamento diz ter (WAN PPPoE/DHCP) — o roteador do cliente não tem o serial da ONU cadastrada, mas tem o IP da sessão dele. */
function ws_acs_ip_wan(array $params): string {
    foreach ($params as $k => $v) {
        if (preg_match('/(WANIPConnection|WANPPPConnection)\.\d+\.ExternalIPAddress$/', (string)$k) || preg_match('/^Device\.IP\.Interface\.\d+\.IPv4Address\.\d+\.IPAddress$/', (string)$k)) {
            $v = trim((string)$v);
            if (filter_var($v, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && $v !== '0.0.0.0' && strpos($v, '192.168.') !== 0 && strpos($v, '10.') !== 0 && strpos($v, '127.') !== 0 && strpos($v, '169.254.') !== 0) return $v;
        }
    }
    return '';
}
function ws_acs_vincular(PDO $db, string $serial, string $oui = '', string $ipWan = ''): array {
    $formas = ws_acs_serial_formas($serial, $oui);
    if (!$formas && $ipWan === '') return [0, 0];
    $in = implode(',', array_fill(0, count($formas), '?'));
    try {
        $q = $db->prepare("SELECT id, cliente_id FROM ws_contrato WHERE LOWER(sn_onu) IN ($in) OR LOWER(equip_serial) IN ($in) OR LOWER(ont_id) IN ($in) ORDER BY (status='ativo') DESC, id DESC LIMIT 1");
        if ($formas) { $q->execute(array_merge($formas, $formas, $formas)); $r = $q->fetch(PDO::FETCH_ASSOC); if ($r) return [(int)$r['id'], (int)$r['cliente_id']]; }
        // roteador do cliente: acha pelo IP de internet da sessão dele (só se for 1 contrato, e sessão recente)
        if ($ipWan !== '') {
            $q2 = $db->prepare("SELECT id, cliente_id FROM ws_contrato WHERE ultimo_ip=? AND ultimo_ip_em >= NOW() - INTERVAL 3 DAY LIMIT 2"); $q2->execute([$ipWan]); $rs = $q2->fetchAll(PDO::FETCH_ASSOC);
            if (count($rs) === 1) return [(int)$rs[0]['id'], (int)$rs[0]['cliente_id']];
        }
        return [0, 0];
    } catch (Throwable $e) { return [0, 0]; }
}

/* ---------- XML (CWMP/SOAP) ---------- */
function ws_acs_xml(string $corpo, string $id, string $ns = WS_ACS_NS_PADRAO): string {
    return '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
        . '<soap-env:Envelope xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-enc="http://schemas.xmlsoap.org/soap/encoding/" '
        . 'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:cwmp="' . htmlspecialchars($ns, ENT_QUOTES) . '">'
        . '<soap-env:Header><cwmp:ID soap-env:mustUnderstand="1">' . htmlspecialchars($id, ENT_XML1) . '</cwmp:ID></soap-env:Header>'
        . '<soap-env:Body>' . $corpo . '</soap-env:Body></soap-env:Envelope>';
}
function ws_acs_rpc_get(array $nomes): string {
    $x = '<cwmp:GetParameterValues><ParameterNames soap-enc:arrayType="xsd:string[' . count($nomes) . ']">';
    foreach ($nomes as $n) $x .= '<string>' . htmlspecialchars((string)$n, ENT_XML1) . '</string>';
    return $x . '</ParameterNames></cwmp:GetParameterValues>';
}
/** $params: [ [nome, valor, tipo(string|boolean|unsignedInt|int)], … ] */
function ws_acs_rpc_set(array $params): string {
    $x = '<cwmp:SetParameterValues><ParameterList soap-enc:arrayType="cwmp:ParameterValueStruct[' . count($params) . ']">';
    foreach ($params as $p) {
        $tipo = in_array(($p[2] ?? 'string'), ['string', 'boolean', 'unsignedInt', 'int'], true) ? $p[2] : 'string';
        $x .= '<ParameterValueStruct><Name>' . htmlspecialchars((string)$p[0], ENT_XML1) . '</Name><Value xsi:type="xsd:' . $tipo . '">' . htmlspecialchars((string)$p[1], ENT_XML1) . '</Value></ParameterValueStruct>';
    }
    return $x . '</ParameterList><ParameterKey>ws' . time() . '</ParameterKey></cwmp:SetParameterValues>';
}
function ws_acs_rpc_reboot(): string { return '<cwmp:Reboot><CommandKey>ws' . time() . '</CommandKey></cwmp:Reboot>'; }

/** Lê o envelope: ['metodo'=>'Inform', 'id'=>…, 'ns'=>…, 'dom'=>DOMXPath, 'corpo'=>DOMElement] ou null se não for CWMP. */
function ws_acs_ler(string $xml): ?array {
    if (trim($xml) === '') return null;
    $prev = libxml_use_internal_errors(true);
    if (PHP_VERSION_ID < 80000 && function_exists('libxml_disable_entity_loader')) @libxml_disable_entity_loader(true);
    $d = new DOMDocument();
    $ok = @$d->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS);
    libxml_clear_errors(); libxml_use_internal_errors($prev);
    if (!$ok || !$d->documentElement) return null;
    $xp = new DOMXPath($d);
    $corpo = $xp->query("//*[local-name()='Body']/*")->item(0); if (!$corpo) return null;
    $idN = $xp->query("//*[local-name()='Header']/*[local-name()='ID']")->item(0);
    return ['metodo' => $corpo->localName, 'id' => $idN ? trim($idN->textContent) : '', 'ns' => (string)$corpo->namespaceURI, 'xp' => $xp, 'corpo' => $corpo];
}
/** Pares nome=>valor de uma lista ParameterValueStruct dentro de $no. */
function ws_acs_pares(DOMXPath $xp, DOMNode $no): array {
    $out = [];
    foreach ($xp->query(".//*[local-name()='ParameterValueStruct']", $no) as $s) {
        $n = $xp->query("./*[local-name()='Name']", $s)->item(0); $v = $xp->query("./*[local-name()='Value']", $s)->item(0);
        if ($n) $out[trim($n->textContent)] = $v ? trim($v->textContent) : '';
    }
    return $out;
}

/* ---------- dispositivo / tarefas ---------- */
function ws_acs_modelo_dados(array $params): string {
    foreach ($params as $k => $_) if (strpos((string)$k, 'Device.') === 0) return 'tr181';
    return 'tr098';
}
function ws_acs_param_prefixo(string $modelo): string { return $modelo === 'tr181' ? 'Device.' : 'InternetGatewayDevice.'; }

function ws_acs_enfileirar(PDO $db, int $dispId, string $tipo, array $dados = [], string $origem = 'manual'): int {
    ws_acs_tabelas($db);
    $db->prepare("INSERT INTO ws_acs_tarefa (dispositivo_id, tipo, dados, origem) VALUES (?,?,?,?)")->execute([$dispId, $tipo, json_encode($dados, JSON_UNESCAPED_UNICODE), mb_substr($origem, 0, 40)]);
    return (int)$db->lastInsertId();
}
/** Equipamento do contrato/cliente que já falou com o ACS (o mais recente). */
function ws_acs_do_contrato(PDO $db, int $contratoId = 0, int $clienteId = 0): ?array {
    ws_acs_tabelas($db);
    $q = $db->prepare("SELECT * FROM ws_acs_dispositivo WHERE (contrato_id=? AND ?>0) OR (cliente_id=? AND ?>0) ORDER BY ultimo_inform DESC LIMIT 1");
    $q->execute([$contratoId, $contratoId, $clienteId, $clienteId]); $r = $q->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}
/** Wi-Fi: índices das redes (2.4 GHz / 5 GHz) a partir dos parâmetros já lidos do equipamento. [banda => índice] */
function ws_acs_wlan_indices(array $params): array {
    $idx = [];
    foreach ($params as $k => $v) {
        if (preg_match('/\.WLANConfiguration\.(\d+)\.(OperatingFrequencyBand|Standard|Channel|SSID)$/', (string)$k, $m)) $idx[(int)$m[1]][$m[2]] = (string)$v;
        elseif (preg_match('/^Device\.WiFi\.Radio\.(\d+)\.OperatingFrequencyBand$/', (string)$k, $m)) $idx[(int)$m[1]]['OperatingFrequencyBand'] = (string)$v;
    }
    $out = [];
    ksort($idx);
    foreach ($idx as $i => $a) {
        $banda = stripos($a['OperatingFrequencyBand'] ?? '', '5') !== false ? '5' : (stripos($a['OperatingFrequencyBand'] ?? '', '2.4') !== false ? '2.4' : ($i >= 5 ? '5' : '2.4'));
        if (!isset($out[$banda])) $out[$banda] = $i;
    }
    return $out;
}
/** Parâmetros TR-069 para trocar Wi-Fi. $q = ['banda'=>'2.4'|'5', 'canal'=>int, 'ssid'=>..., 'senha'=>...].
 *  $conhecidos = parâmetros que o equipamento mostrou ao ser lido: só manda o que ELE tem (um nome inexistente derruba o Set inteiro, Fault 9005).
 *  Devolve ['params'=>[...], 'faltou'=>[o que o equipamento não expõe]]. */
function ws_acs_wifi_params(string $modelo, int $idx, array $q, ?array $conhecidos = null): array {
    $tem = function (string $n) use ($conhecidos): bool { return $conhecidos === null || isset($conhecidos[$n]); };
    $b = $modelo === 'tr181' ? null : "InternetGatewayDevice.LANDevice.1.WLANConfiguration.$idx.";
    $canal = $modelo === 'tr181' ? "Device.WiFi.Radio.$idx." : $b;
    $ssid  = $modelo === 'tr181' ? "Device.WiFi.SSID.$idx.SSID" : $b . 'SSID';
    $senhas = $modelo === 'tr181' ? ["Device.WiFi.AccessPoint.$idx.Security.KeyPassphrase"]
            : [$b . 'KeyPassphrase', $b . 'PreSharedKey.1.KeyPassphrase', $b . 'PreSharedKey.1.PreSharedKey'];
    $p = []; $falta = [];
    if (isset($q['canal'])) {
        if ($tem($canal . 'Channel')) {
            if ($tem($canal . 'AutoChannelEnable')) $p[] = [$canal . 'AutoChannelEnable', $q['canal'] > 0 ? 'false' : 'true', 'boolean'];
            if ($q['canal'] > 0) $p[] = [$canal . 'Channel', (string)$q['canal'], 'unsignedInt'];
            elseif (!$tem($canal . 'AutoChannelEnable')) $falta[] = 'canal automático';
        } else $falta[] = 'canal';
    }
    if (!empty($q['ssid'])) { if ($tem($ssid)) $p[] = [$ssid, $q['ssid'], 'string']; else $falta[] = 'nome da rede'; }
    if (!empty($q['senha'])) {
        $ach = null; foreach ($senhas as $n) if ($tem($n) && ($conhecidos === null || isset($conhecidos[$n]))) { $ach = $n; break; }
        if ($ach !== null) $p[] = [$ach, $q['senha'], 'string']; else $falta[] = 'senha';
    }
    return ['params' => $p, 'faltou' => $falta];
}

/** Valida o pedido de Wi-Fi (o que o cliente/atendente pode pedir). Devolve ['ok'=>bool, 'erro'=>texto, 'q'=>normalizado]. */
function ws_acs_wifi_validar(array $q): array {
    $o = [];
    $banda = (string)($q['banda'] ?? '2.4'); $o['banda'] = $banda === '5' ? '5' : '2.4';
    if (isset($q['canal']) && $q['canal'] !== '' && $q['canal'] !== null) {
        $c = (int)$q['canal'];
        $validos = $o['banda'] === '5' ? [0, 36, 40, 44, 48, 149, 153, 157, 161, 165] : array_merge([0], range(1, 11));
        if (!in_array($c, $validos, true)) return ['ok' => false, 'erro' => $o['banda'] === '5' ? 'Canal 5 GHz válido: 36, 40, 44, 48, 149, 153, 157, 161 ou 165 (0 = automático).' : 'Canal 2,4 GHz válido: 1 a 11 (0 = automático).'];
        $o['canal'] = $c;
    }
    if (!empty($q['ssid'])) { $s = trim((string)$q['ssid']); if (mb_strlen($s) < 2 || mb_strlen($s) > 32 || preg_match('/[\x00-\x1f"<>&]/', $s)) return ['ok' => false, 'erro' => 'Nome da rede: de 2 a 32 caracteres, sem aspas nem símbolos < > &.']; $o['ssid'] = $s; }
    if (!empty($q['senha'])) { $s = (string)$q['senha']; if (strlen($s) < 8 || strlen($s) > 63 || preg_match('/[\x00-\x1f"<>&]/', $s)) return ['ok' => false, 'erro' => 'Senha do Wi-Fi: de 8 a 63 caracteres, sem aspas nem símbolos < > &.']; $o['senha'] = $s; }
    if (count($o) <= 1) return ['ok' => false, 'erro' => 'Diga o que mudar: canal, nome da rede ou senha.'];
    return ['ok' => true, 'q' => $o];
}

/* ---------- sessão CWMP ---------- */
function ws_acs_proxima(PDO $db, int $dispId): ?array {
    $q = $db->prepare("SELECT * FROM ws_acs_tarefa WHERE dispositivo_id=? AND status='pendente' ORDER BY id LIMIT 1");
    $q->execute([$dispId]); $t = $q->fetch(PDO::FETCH_ASSOC); return $t ?: null;
}
/** Monta o RPC da tarefa. Devolve [corpoXml, rotuloTarefa] ou null (tarefa sem o que enviar: já marcada como erro). */
function ws_acs_rpc_da_tarefa(PDO $db, array $t, array $disp): ?string {
    $d = json_decode((string)$t['dados'], true) ?: []; $modelo = (string)$disp['modelo_dados'];
    $pref = ws_acs_param_prefixo($modelo);
    switch ($t['tipo']) {
        case 'reboot': return ws_acs_rpc_reboot();
        case 'get':    return ws_acs_rpc_get((array)($d['nomes'] ?? []));
        case 'set':    return ws_acs_rpc_set((array)($d['params'] ?? []));
        case 'wifi_ler': return ws_acs_rpc_get($modelo === 'tr181' ? ['Device.WiFi.Radio.', 'Device.WiFi.SSID.'] : [$pref . 'LANDevice.1.WLANConfiguration.']);
        case 'wifi':
            if (empty($d['fase'])) {   // fase 1: lê a árvore Wi-Fi para saber os índices (2.4/5 GHz) deste equipamento
                $nomes = $modelo === 'tr181' ? ['Device.WiFi.Radio.', 'Device.WiFi.SSID.'] : [$pref . 'LANDevice.1.WLANConfiguration.'];
                return ws_acs_rpc_get($nomes);
            }
            return ws_acs_rpc_set((array)($d['params'] ?? []));
    }
    $db->prepare("UPDATE ws_acs_tarefa SET status='erro', resultado='Tipo de tarefa desconhecido', concluido_em=NOW() WHERE id=?")->execute([$t['id']]);
    return null;
}
/** Resposta do equipamento a uma tarefa (id do SOAP = "ws-<tarefa>"). */
function ws_acs_resposta_tarefa(PDO $db, array $disp, array $env): void {
    if (!preg_match('/^ws-(\d+)$/', (string)$env['id'], $m)) return;
    $tid = (int)$m[1];
    $q = $db->prepare("SELECT * FROM ws_acs_tarefa WHERE id=? AND dispositivo_id=?"); $q->execute([$tid, $disp['id']]); $t = $q->fetch(PDO::FETCH_ASSOC);
    if (!$t) return;
    $xp = $env['xp']; $corpo = $env['corpo']; $metodo = $env['metodo'];
    $fim = function (string $st, string $res) use ($db, $tid) { $db->prepare("UPDATE ws_acs_tarefa SET status=?, resultado=?, concluido_em=NOW() WHERE id=?")->execute([$st, mb_substr($res, 0, 60000), $tid]); };
    if ($metodo === 'Fault') {
        $cod = $xp->query(".//*[local-name()='FaultCode']", $corpo); $msg = $xp->query(".//*[local-name()='FaultString']", $corpo);
        $det = $xp->query(".//*[local-name()='SetParameterValuesFault']", $corpo); $extra = '';
        foreach ($det as $f) { $pn = $xp->query("./*[local-name()='ParameterName']", $f)->item(0); $fs = $xp->query("./*[local-name()='FaultString']", $f)->item(0); $extra .= ' [' . ($pn ? trim($pn->textContent) : '') . ': ' . ($fs ? trim($fs->textContent) : '') . ']'; }
        $fim('erro', 'Falha ' . ($cod->length ? trim($cod->item(0)->textContent) : '?') . ': ' . ($msg->length ? trim($msg->item(0)->textContent) : '') . $extra);
        return;
    }
    if ($metodo === 'GetParameterValuesResponse') {
        $pares = ws_acs_pares($xp, $corpo);
        $atual = json_decode((string)$disp['parametros'], true) ?: []; $atual = array_merge($atual, $pares);
        if (count($atual) > 600) $atual = array_slice($atual, -600, null, true);
        $db->prepare("UPDATE ws_acs_dispositivo SET parametros=? WHERE id=?")->execute([json_encode($atual, JSON_UNESCAPED_UNICODE), $disp['id']]);
        if ($t['tipo'] === 'wifi' && empty((json_decode((string)$t['dados'], true) ?: [])['fase'])) {   // fase 2: com os índices lidos, monta o Set
            $d = json_decode((string)$t['dados'], true) ?: []; $q = (array)($d['q'] ?? []); $ind = ws_acs_wlan_indices($atual);
            $idx = $ind[$q['banda'] ?? '2.4'] ?? null;
            if ($idx === null) { $fim('erro', 'Este equipamento não tem rede Wi-Fi ' . ($q['banda'] ?? '2.4') . ' GHz gerenciável (ONU em modo bridge ou sem rádio).'); return; }
            $w = ws_acs_wifi_params((string)$disp['modelo_dados'], $idx, $q, $atual);
            if (!$w['params'] || $w['faltou']) { $fim('erro', 'Este equipamento não expõe para troca remota: ' . ($w['faltou'] ? implode(', ', $w['faltou']) : 'nada do pedido') . '.'); return; }
            $d['fase'] = 2; $d['params'] = $w['params']; $d['indice'] = $idx;
            $db->prepare("UPDATE ws_acs_tarefa SET dados=?, status='pendente', enviado_em=NULL WHERE id=?")->execute([json_encode($d, JSON_UNESCAPED_UNICODE), $tid]);
            return;
        }
        $fim('ok', json_encode($pares, JSON_UNESCAPED_UNICODE));
        return;
    }
    if ($metodo === 'SetParameterValuesResponse') {
        $st = $xp->query(".//*[local-name()='Status']", $corpo)->item(0); $s = $st ? trim($st->textContent) : '0';
        $fim('ok', $s === '1' ? 'Aplicado (o equipamento pode reiniciar a rede/Wi-Fi para valer).' : 'Aplicado.');
        return;
    }
    if ($metodo === 'RebootResponse') { $fim('ok', 'Reinício aceito pelo equipamento.'); return; }
    $fim('ok', $metodo);
}

/** Registra o Inform: cria/atualiza o equipamento, vincula ao contrato e liga o inform periódico na primeira vez. Devolve o dispositivo. */
function ws_acs_inform(PDO $db, array $env, string $ip): ?array {
    ws_acs_tabelas($db);
    $xp = $env['xp']; $corpo = $env['corpo'];
    $camp = function (string $n) use ($xp, $corpo): string { $x = $xp->query(".//*[local-name()='DeviceId']/*[local-name()='$n']", $corpo)->item(0); return $x ? trim($x->textContent) : ''; };
    $serial = mb_substr($camp('SerialNumber'), 0, 80); if ($serial === '') return null;
    $pares = ws_acs_pares($xp, $corpo);
    $modelo = ws_acs_modelo_dados($pares);
    $pref = ws_acs_param_prefixo($modelo);
    $url = (string)($pares[$pref . 'ManagementServer.ConnectionRequestURL'] ?? '');
    $sw = (string)($pares[$pref . 'DeviceInfo.SoftwareVersion'] ?? '');
    $q = $db->prepare("SELECT * FROM ws_acs_dispositivo WHERE serial=?"); $q->execute([$serial]); $d = $q->fetch(PDO::FETCH_ASSOC);
    [$ctId, $clId] = ws_acs_vincular($db, $serial, $camp('OUI'), ws_acs_ip_wan($pares));
    if (!$d) {
        $db->prepare("INSERT INTO ws_acs_dispositivo (serial,oui,fabricante,produto,versao_sw,modelo_dados,ip,url_conexao,contrato_id,cliente_id,parametros,ultimo_inform) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([$serial, $camp('OUI'), mb_substr($camp('Manufacturer'), 0, 80), mb_substr($camp('ProductClass'), 0, 80), mb_substr($sw, 0, 80), $modelo, $ip, mb_substr($url, 0, 255), $ctId ?: null, $clId ?: null, json_encode($pares, JSON_UNESCAPED_UNICODE)]);
        $q->execute([$serial]); $d = $q->fetch(PDO::FETCH_ASSOC);
    } else {
        $atual = json_decode((string)$d['parametros'], true) ?: []; $atual = array_merge($atual, $pares);
        $db->prepare("UPDATE ws_acs_dispositivo SET fabricante=?, produto=?, versao_sw=?, modelo_dados=?, ip=?, url_conexao=?, contrato_id=COALESCE(?,contrato_id), cliente_id=COALESCE(?,cliente_id), parametros=?, ultimo_inform=NOW() WHERE id=?")
           ->execute([mb_substr($camp('Manufacturer'), 0, 80), mb_substr($camp('ProductClass'), 0, 80), mb_substr($sw, 0, 80), $modelo, $ip, mb_substr($url, 0, 255), $ctId ?: null, $clId ?: null, json_encode($atual, JSON_UNESCAPED_UNICODE), $d['id']]);
        $q->execute([$serial]); $d = $q->fetch(PDO::FETCH_ASSOC);
    }
    if (!(int)$d['provisionado']) {   // 1º contato: pede à ONU que ligue sozinha de tempos em tempos (é assim que as tarefas chegam nela)
        $cfg = ws_acs_cfg();
        ws_acs_enfileirar($db, (int)$d['id'], 'set', ['params' => [[$pref . 'ManagementServer.PeriodicInformEnable', 'true', 'boolean'], [$pref . 'ManagementServer.PeriodicInformInterval', (string)(int)$cfg['intervalo'], 'unsignedInt']]], 'auto-provisionar');
        $db->prepare("UPDATE ws_acs_dispositivo SET provisionado=1 WHERE id=?")->execute([$d['id']]);
    }
    return $d;
}

/** Equipamento do titular (ou adicionais) pelo CPF/CNPJ, o que falou com o ACS mais recentemente. */
function ws_acs_do_cpf(PDO $db, string $cpf): ?array {
    ws_acs_tabelas($db);
    $cpf = preg_replace('/\D/', '', $cpf); if (strlen($cpf) < 11) return null;
    try {
        $q = $db->prepare("SELECT d.* FROM ws_acs_dispositivo d JOIN ws_cliente c ON c.id=d.cliente_id WHERE REPLACE(REPLACE(REPLACE(c.cpf_cnpj,'.',''),'-',''),'/','')=? ORDER BY d.ultimo_inform DESC LIMIT 1");
        $q->execute([$cpf]); $r = $q->fetch(PDO::FETCH_ASSOC); return $r ?: null;
    } catch (Throwable $e) { return null; }
}
/** Extrai de uma fala/texto o pedido de Wi-Fi: ['banda','canal','ssid','senha'] (só o que veio). */
function ws_acs_wifi_pedido(string $t): array {
    $o = [];
    $enchimento = '(?:\s+(?:para|pra|pro|é|e|seria|vai ser|nova|novo|agora))*\s*[:=]?\s*';
    if (preg_match('/senha' . $enchimento . '["“\']?([^\s"”\']{8,63})/iu', $t, $m)) $o['senha'] = $m[1];
    $sem = preg_replace('/nome\s+da\s+rede|nome\s+do\s+wi-?\s?fi|nome\s+da\s+internet/iu', 'nome', $t);
    if (preg_match('/(?:nome|rede)' . $enchimento . '["“\']?([^\s"”\']{2,32})/iu', $sem, $m) && !preg_match('/^(do|da|de|wi|wifi|senha|canal|nova|novo|para|pra)$/iu', $m[1])) $o['ssid'] = $m[1];
    if (preg_match('/canal' . $enchimento . '(\d{1,3})/iu', $t, $m)) $o['canal'] = (int)$m[1];
    $o['banda'] = preg_match('/\b5\s*(?:g|ghz|giga)\b|cinco\s*g/iu', $t) ? '5' : '2.4';
    return $o;
}
