<?php
/**
 * WellSystem — Servidor de anexos (com autenticação).
 * anexo.php?id=N  → devolve o arquivo se o solicitante tiver permissão:
 *   - operador logado (painel), OU
 *   - o próprio cliente logado na Central do Assinante (só os anexos dele).
 * ?download=1 força baixar; senão exibe inline (imagem/PDF).
 */
require __DIR__ . '/config.php';
require __DIR__ . '/anexos.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { http_response_code(400); exit('id?'); }

$db = ws_db();
$st = $db->prepare("SELECT * FROM ws_anexo WHERE id=?"); $st->execute([$id]); $a = $st->fetch();
if (!$a) { http_response_code(404); exit('não encontrado'); }

// Autorização
$operador = !empty($_SESSION['ws_user']);
$dono = !empty($_SESSION['ws_portal']) && (int)$_SESSION['ws_portal']['id'] === (int)$a['cliente_id'];
if (!$operador && !$dono) { http_response_code(403); exit('sem permissão'); }

$caminho = WS_UPLOADS . '/' . $a['arquivo'];
if (!is_file($caminho)) { http_response_code(404); exit('arquivo ausente'); }

header('Content-Type: ' . ($a['mime'] ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($caminho));
$disp = isset($_GET['download']) ? 'attachment' : 'inline';
header('Content-Disposition: ' . $disp . '; filename="' . rawurlencode($a['nome_original'] ?: $a['arquivo']) . '"');
header('X-Content-Type-Options: nosniff');
readfile($caminho);
