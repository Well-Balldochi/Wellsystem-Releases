<?php
/**
 * WellSystem — Anexos (documentos/fotos do cliente).
 *
 * Upload seguro: valida tipo/tamanho, gera nome aleatório e guarda em uploads/ (não público —
 * a pasta tem .htaccess "deny all"). Os arquivos são servidos SÓ por anexo.php, com autenticação.
 */
require_once __DIR__ . '/config.php';

if (!defined('WS_UPLOADS')) define('WS_UPLOADS', WS_DIR . '/uploads');

const WS_ANEXO_MIMES = [
    'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
    'image/gif' => 'gif', 'application/pdf' => 'pdf',
];
const WS_ANEXO_MAX = 8388608; // 8 MB

/** Garante a pasta uploads/ protegida (mkdir/.htaccess pelo código). */
function ws_uploads_dir(): string {
    if (!is_dir(WS_UPLOADS)) @mkdir(WS_UPLOADS, 0775, true);
    $ht = WS_UPLOADS . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht,
        "Require all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
    return WS_UPLOADS;
}

/**
 * Processa um upload ($_FILES['arquivo']).
 * @return array [ok, erro]
 */
function ws_anexo_salvar(PDO $db, int $clienteId, ?int $contratoId, string $tipo, array $file): array {
    if (empty($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return ['ok' => false, 'erro' => 'Falha no upload.'];
    if ($file['size'] > WS_ANEXO_MAX) return ['ok' => false, 'erro' => 'Arquivo maior que 8 MB.'];

    $mime = function_exists('finfo_file')
        ? (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name'])
        : ($file['type'] ?? '');
    if (!isset(WS_ANEXO_MIMES[$mime])) return ['ok' => false, 'erro' => 'Tipo não permitido (use JPG/PNG/WEBP/GIF/PDF).'];

    ws_uploads_dir();
    // Documentos do CLIENTE ficam ISOLADOS em uploads/anexos/ — sem qualquer correlação com
    // foto de operador (uploads/operadores/) ou de equipamento (uploads/equipamentos/).
    $dirAnx = WS_UPLOADS . '/anexos';
    if (!is_dir($dirAnx)) @mkdir($dirAnx, 0775, true);
    $ext = WS_ANEXO_MIMES[$mime];
    $nome = 'anexos/' . bin2hex(random_bytes(16)) . '.' . $ext;   // caminho relativo guardado no banco
    if (!ws_mover_upload($file['tmp_name'], WS_UPLOADS . '/' . $nome))
        return ['ok' => false, 'erro' => 'Não foi possível gravar o arquivo (permissão da pasta uploads/anexos/).'];

    $tipo = in_array($tipo, ['documento','foto_instalacao','onu','contrato','outro'], true) ? $tipo : 'outro';
    $db->prepare("INSERT INTO ws_anexo (cliente_id,contrato_id,tipo,nome_original,arquivo,mime,tamanho)
                  VALUES (?,?,?,?,?,?,?)")
       ->execute([$clienteId, $contratoId ?: null, $tipo, substr((string)$file['name'], 0, 200), $nome, $mime, (int)$file['size']]);
    return ['ok' => true];
}

/** Remove um anexo (registro + arquivo físico). */
function ws_anexo_excluir(PDO $db, int $id): void {
    $st = $db->prepare("SELECT arquivo FROM ws_anexo WHERE id=?"); $st->execute([$id]);
    if ($a = $st->fetchColumn()) @unlink(WS_UPLOADS . '/' . $a);
    $db->prepare("DELETE FROM ws_anexo WHERE id=?")->execute([$id]);
}

/** É imagem? (para mostrar como thumbnail). */
function ws_anexo_eh_imagem(?string $mime): bool { return $mime && strpos($mime, 'image/') === 0; }
