<?php
/**
 * WellSystem ERP — ATENDIMENTO: assistente de primeira entrada + painel (WhatsApp, robô, Chatwoot, n8n) com clique.
 * Só nível 3+ (mexe em integração). Regras e dados: atendimento_lib.php.
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/atendimento_lib.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$pode = function_exists('ws_pode_editar_api') ? ws_pode_editar_api() : true;
$msg = ''; $erro = '';

/* QR code (AJAX) — só quem pode editar */
if ($pode && isset($_GET['qr'])) {
    header('Content-Type: application/json; charset=utf-8');
    $nome = preg_replace('/[^A-Za-z0-9._-]/', '', (string)$_GET['qr']);
    [$ok, $img, $txt] = ws_at_qr($nome);
    echo json_encode(['ok' => $ok, 'img' => $img, 'msg' => $txt], JSON_UNESCAPED_UNICODE); exit;
}

if ($pode && isset($_GET['estado'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['estado' => ws_at_estado_instancia(preg_replace('/[^A-Za-z0-9._-]/', '', (string)$_GET['estado']))]); exit;
}

if ($pode && isset($_GET['modelo'])) {   // baixa o modelo do robô já com os dados deste provedor
    $q = $_GET['modelo'] === 'fora' ? 'fora' : 'atendimento'; $jm = ws_robo_modelo_json($q);
    if ($jm === '') { http_response_code(404); echo 'Modelo não encontrado.'; exit; }
    header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="robo-' . $q . '-' . trim(preg_replace('/[^a-z0-9]+/i', '-', ws_provedor_nome_curto()), '-') . '.json"'); echo $jm; exit;
}

$acao = $_SERVER['REQUEST_METHOD'] === 'POST' ? (string)($_POST['acao'] ?? '') : '';
if ($acao !== '' && !$pode) { $erro = 'Só quem é administrador (nível 3 ou mais) pode alterar o atendimento.'; $acao = ''; }

/* ---- primeira entrada: salvar as escolhas e criar o que for preciso ---- */
if ($acao === 'assistente') {
    $empresa = trim((string)($_POST['empresa'] ?? '')); $slug = ws_at_slug($empresa);
    $num = ((int)($_POST['num'] ?? 1)) === 2 ? 2 : 1;
    $tipo1 = ($_POST['tipo1'] ?? 'comum') === 'api' ? 'api' : 'comum';
    $tipo2 = ($_POST['tipo2'] ?? 'api') === 'comum' ? 'comum' : 'api';
    $url = trim((string)($_POST['evo_url'] ?? '')); $chave = trim((string)($_POST['evo_chave'] ?? ''));
    $waAtual = ws_wa_config(); if ($url === '') $url = (string)($waAtual['url'] ?? ''); if ($chave === '') $chave = (string)($waAtual['apikey'] ?? '');   // vazio = usa a ponte já configurada neste servidor
    if ($empresa === '') $erro = 'Informe o nome da empresa.';
    else {
        ws_at_salvar(['configurado' => 1, 'pulou' => 0, 'empresa' => $empresa, 'slug' => $slug, 'num' => $num,
            'inst' => [['nome' => $slug . '-01', 'tipo' => $tipo1, 'ativa' => 1], ['nome' => $slug . '-02', 'tipo' => $tipo2, 'ativa' => $num === 2 ? 1 : 0]]]);
        $meta = ['token' => trim((string)($_POST['meta_token'] ?? '')), 'numero_id' => trim((string)($_POST['meta_numero'] ?? '')), 'waba' => trim((string)($_POST['meta_waba'] ?? ''))];
        ws_at_aplicar_whatsapp($url, $chave);
        $a = ws_at_cfg(); $avisos = [];
        if ($url !== '' && $chave !== '') foreach ($a['inst'] as $i) if (!empty($i['ativa'])) { $r = ws_at_criar_instancia($i['nome'], $i['tipo'], $meta); if ($r !== '') $avisos[] = $i['nome'] . ': ' . $r; }
        header('Location: atendimento.php?ok=1' . ($avisos ? '&aviso=' . rawurlencode(implode(' | ', $avisos)) : '')); exit;
    }
}
if ($acao === 'pular') { ws_at_salvar(['pulou' => 1]); header('Location: erp.php'); exit; }

/* ---- painel ---- */
if ($acao === 'evolution') {
    $url = trim((string)($_POST['evo_url'] ?? '')); $chave = trim((string)($_POST['evo_chave'] ?? ''));
    ws_at_aplicar_whatsapp($url, $chave); $msg = 'Endereço da Evolution salvo.';
}
if ($acao === 'criar') {
    $nome = preg_replace('/[^A-Za-z0-9._-]/', '', (string)($_POST['inst'] ?? ''));
    $a = ws_at_cfg(); $tipo = 'comum'; foreach ($a['inst'] as $i) if ($i['nome'] === $nome) $tipo = $i['tipo'];
    $r = ws_at_criar_instancia($nome, $tipo, ['token' => $_POST['meta_token'] ?? '', 'numero_id' => $_POST['meta_numero'] ?? '', 'waba' => $_POST['meta_waba'] ?? '']);
    if ($r === '') $msg = 'Instância ' . $nome . ' pronta.'; else $erro = $r;
}
if ($acao === 'segunda') {   // ativa / desativa o 2º número com um clique
    $a = ws_at_cfg(); $lig = !empty($_POST['ligar']);
    $a['inst'][1]['ativa'] = $lig ? 1 : 0; if ($a['inst'][1]['nome'] === '') $a['inst'][1]['nome'] = ($a['slug'] ?: 'Empresa') . '-02';
    if (isset($_POST['tipo2'])) $a['inst'][1]['tipo'] = $_POST['tipo2'] === 'comum' ? 'comum' : 'api';
    ws_at_salvar(['num' => $lig ? 2 : 1, 'inst' => $a['inst']]); ws_at_aplicar_whatsapp('', '');
    $msg = $lig ? 'Segundo número ativado. Crie a instância e conecte.' : 'Segundo número desativado.';
}
if ($acao === 'robo') {
    $a = ws_at_cfg(); $lig = !empty($_POST['ligar']);
    $tbUrl = trim((string)($_POST['tb_url'] ?? $a['tb_url'])); $tbSlug = trim((string)($_POST['tb_slug'] ?? $a['tb_slug']));
    $alvo = ''; foreach ($a['inst'] as $i) if (!empty($i['ativa']) && $i['tipo'] === 'comum') { $alvo = $i['nome']; break; }
    if ($alvo === '') foreach ($a['inst'] as $i) if (!empty($i['ativa'])) { $alvo = $i['nome']; break; }
    $r = $alvo === '' ? 'Nenhum número ativo.' : ws_at_robo($alvo, $lig, $tbUrl, $tbSlug);
    if ($r === '') { ws_at_salvar(['robo' => $lig ? 1 : 0, 'tb_url' => $tbUrl, 'tb_slug' => $tbSlug]); $msg = $lig ? 'Robô ligado.' : 'Robô desligado. Só atendimento humano.'; }
    else $erro = $r;
}
if ($acao === 'robo_base') { ws_at_salvar(['base_url' => rtrim(trim((string)($_POST['base_url'] ?? '')), '/')]); $msg = 'Endereço do sistema salvo.'; }
if ($acao === 'robo_importar') {
    $a0 = ws_at_cfg(); $tbU = trim((string)($_POST['tb_url'] ?? $a0['tb_url']));
    $r = ws_robo_importar_typebot($tbU, trim((string)($_POST['tb_api'] ?? '')), trim((string)($_POST['tb_ws'] ?? '')), ($_POST['qual'] ?? 'atendimento') === 'fora' ? 'fora' : 'atendimento');
    if (!empty($r['ok'])) { ws_at_salvar(['tb_url' => rtrim($tbU, '/'), 'tb_slug' => $r['slug']]); $msg = 'Fluxo importado e publicado (código ' . $r['slug'] . '). Agora clique em Ligar robô.'; }
    else $erro = $r['erro'] ?? 'Falha ao importar.';
}
if ($acao === 'chatwoot') {
    $a = ws_at_cfg(); $lig = !empty($_POST['ligar']);
    $url = trim((string)($_POST['cw_url'] ?? $a['cw_url'])); $tok = trim((string)($_POST['cw_token'] ?? '')); if ($tok === '') $tok = (string)$a['cw_token']; $conta = trim((string)($_POST['cw_conta'] ?? $a['cw_conta'])) ?: '1';
    $falhas = [];
    foreach ($a['inst'] as $i) if (!empty($i['ativa'])) { $r = ws_at_chatwoot($i['nome'], $lig, $url, $tok, $conta); if ($r !== '') $falhas[] = $i['nome'] . ': ' . $r; }
    if (!$falhas) { ws_at_salvar(['chatwoot' => $lig ? 1 : 0, 'cw_url' => $url, 'cw_token' => $tok, 'cw_conta' => $conta]); $msg = $lig ? 'Chatwoot ligado.' : 'Chatwoot desligado.'; }
    else $erro = implode(' | ', $falhas);
}
if ($acao === 'n8n') {
    $lig = !empty($_POST['ligar']); $u = rtrim(trim((string)($_POST['n8n_url'] ?? '')), '/');
    if ($lig && $u === '') $erro = 'Informe o endereço do n8n.';
    else { ws_at_salvar(['n8n' => $lig ? 1 : 0, 'n8n_url' => $u]); ws_wa_salvar(['meta_guardar_url' => $lig ? $u . '/webhook/recibo-guardar' : '']); $msg = $lig ? 'n8n ligado.' : 'n8n desligado.'; }
}
if (isset($_GET['ok'])) $msg = 'Configuração salva.';
if (isset($_GET['aviso'])) $erro = (string)$_GET['aviso'];

$a = ws_at_cfg(); $wa = ws_wa_config();
$assistente = isset($_GET['assistente']) || ($a['configurado'] ?? 0) == 0;
$estados = ['conectado' => ['🟢', 'conectado'], 'desconectado' => ['🟠', 'desconectado — escaneie o QR'], 'nao_criada' => ['⚪', 'ainda não criada'], 'sem_evolution' => ['⚪', 'Evolution não configurada']];
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Atendimento</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
.at-grade{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:14px;margin:14px 0}
.at-card{background:var(--surface,#fff);border:1px solid var(--border,#ddd);border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:10px;min-width:0}
.at-card h3{margin:0;font-size:16px}
.at-card label{display:flex;flex-direction:column;gap:4px;font-size:13px;font-weight:600}
.at-card input,.at-card select{width:100%;box-sizing:border-box;padding:9px 10px;border-radius:8px;border:1px solid var(--border,#ccc);background:var(--bg,#fff);color:inherit;font:inherit}
.at-linha{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.at-estado{font-size:13px}
.at-qr img{max-width:100%;width:260px;height:auto;border-radius:10px;background:#fff;padding:8px}
.at-wiz{max-width:720px;margin:0 auto}
.at-radio{display:flex;gap:14px;flex-wrap:wrap}.at-radio label{flex-direction:row;align-items:center;gap:6px;font-weight:500}
.at-radio input{width:auto}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('') ?></header>
<main class="ws-main">
<h2 style="margin:6px 0">💬 Atendimento — WhatsApp e robô</h2>
<?php if ($msg !== ''): ?><div class="ws-alert ok"><?= $h($msg) ?></div><?php endif; ?>
<?php if ($erro !== ''): ?><div class="ws-alert err"><?= $h($erro) ?></div><?php endif; ?>
<?php if (!$pode): ?><div class="ws-alert err">Só administradores (nível 3 ou mais) podem configurar o atendimento.</div></main></body></html><?php exit; endif; ?>

<?php if ($assistente): ?>
<form method="post" class="at-card at-wiz">
  <input type="hidden" name="acao" value="assistente">
  <h3>Bem-vindo ao WellSystem ERP — vamos configurar o atendimento</h3>
  <p class="ws-muted" style="margin:0;font-size:13px">São 3 perguntas. Tudo pode ser mudado depois, com um clique, nesta mesma tela.</p>
  <label>Nome da empresa
    <input name="empresa" required maxlength="60" placeholder="Ex.: Acme Telecom" value="<?= $h($a['empresa'] !== '' ? $a['empresa'] : (function_exists('ws_licenca_empresa') ? ws_licenca_empresa() : '')) ?>" oninput="var s=this.value.normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Za-z0-9]+/g,'-').replace(/^-|-$/g,'')||'Empresa';document.getElementById('atNomes').textContent=s+'-01 e '+s+'-02'">
  </label>
  <div class="ws-muted" style="font-size:12px">Os números de WhatsApp ficam com os nomes: <b id="atNomes">Empresa-01 e Empresa-02</b></div>
  <div><b style="font-size:13px">Quantos números de WhatsApp a empresa usa?</b>
    <div class="at-radio"><label><input type="radio" name="num" value="1" checked onchange="atNum()"> Um número</label><label><input type="radio" name="num" value="2" onchange="atNum()"> Dois números</label></div></div>
  <div class="at-linha" style="gap:14px">
    <label style="flex:1 1 220px">Número 1<select name="tipo1" onchange="atMeta()"><option value="comum">WhatsApp normal (QR code)</option><option value="api">API oficial da Meta</option></select></label>
    <label id="atT2" style="flex:1 1 220px;display:none">Número 2<select name="tipo2" onchange="atMeta()"><option value="api">API oficial da Meta</option><option value="comum">WhatsApp normal (QR code)</option></select></label>
  </div>
  <div id="atMeta" style="display:none;gap:8px;flex-direction:column">
    <label>Token da Meta<input name="meta_token" autocomplete="off"></label>
    <label>ID do número na Meta<input name="meta_numero" autocomplete="off"></label>
    <label>ID da conta do WhatsApp Business<input name="meta_waba" autocomplete="off"></label>
  </div>
  <?php if (trim((string)($wa['url'] ?? '')) !== ''): ?>
  <div class="ws-muted" style="font-size:13px">🟢 A ponte de WhatsApp deste servidor já está pronta. Se a empresa preferir a Evolution dela, informe o endereço e a chave:</div>
  <?php endif; ?>
  <div class="at-linha" style="gap:14px">
    <label style="flex:1 1 260px">Endereço da Evolution da empresa (opcional)<input name="evo_url" placeholder="https://evolution.suaempresa.com.br"></label>
    <label style="flex:1 1 220px">Chave da Evolution<input name="evo_chave" type="password" autocomplete="off"></label>
  </div>
  <div class="ws-muted" style="font-size:12px">O atendimento começa <b>só humano</b> (sem robô). Para ligar o robô, o Chatwoot ou o n8n, use os botões do painel depois.</div>
  <div class="at-linha"><button class="ws-btn primary">Salvar e continuar</button>
    <button class="ws-btn" name="acao" value="pular" formnovalidate>Configurar depois</button></div>
</form>
<script>
function atNum(){var d=document.querySelector('input[name=num]:checked').value==='2';document.getElementById('atT2').style.display=d?'flex':'none';atMeta();}
function atMeta(){var t1=document.querySelector('[name=tipo1]').value,d=document.querySelector('input[name=num]:checked').value==='2',t2=document.querySelector('[name=tipo2]').value;
  document.getElementById('atMeta').style.display=(t1==='api'||(d&&t2==='api'))?'flex':'none';}
</script>
<?php else: ?>
<div class="at-card" style="margin-bottom:6px">
  <b><?= $h($a['empresa'] ?: 'Empresa') ?></b>
  <form method="post" class="at-linha"><input type="hidden" name="acao" value="evolution">
    <label style="flex:1 1 260px">Evolution — endereço<input name="evo_url" value="<?= $h($wa['url'] ?? '') ?>" placeholder="https://evolution.suaempresa.com.br"></label>
    <label style="flex:1 1 200px">Chave<input name="evo_chave" type="password" autocomplete="off" placeholder="<?= !empty($wa['apikey']) ? '•••••• (mantida)' : '' ?>"></label>
    <button class="ws-btn" style="align-self:flex-end">Salvar</button></form>
</div>

<h3 style="margin:14px 0 0">Números de WhatsApp</h3>
<div class="at-grade">
<?php foreach ($a['inst'] as $k => $i):
    if ($k === 1 && empty($i['ativa'])): ?>
  <div class="at-card"><h3>Segundo número</h3><div class="ws-muted" style="font-size:13px">Desativado. Ative quando a empresa tiver outro WhatsApp.</div>
    <form method="post" class="at-linha"><input type="hidden" name="acao" value="segunda"><input type="hidden" name="ligar" value="1">
      <select name="tipo2" style="flex:1 1 180px"><option value="api">API oficial da Meta</option><option value="comum">WhatsApp normal (QR)</option></select>
      <button class="ws-btn primary">Ativar</button></form></div>
<?php continue; endif;
    if ($i['nome'] === '') continue;
    $st = ws_at_estado_instancia($i['nome']); [$ic, $tx] = $estados[$st] ?? ['⚪', $st]; ?>
  <div class="at-card"><h3><?= $h($i['nome']) ?> <small class="ws-muted">· <?= $i['tipo'] === 'api' ? 'API oficial da Meta' : 'WhatsApp normal' ?></small></h3>
    <div class="at-estado"><?= $ic ?> <?= $h($tx) ?></div>
    <div class="at-linha">
    <?php if ($st === 'nao_criada'): ?>
      <form method="post" class="at-linha" style="width:100%"><input type="hidden" name="acao" value="criar"><input type="hidden" name="inst" value="<?= $h($i['nome']) ?>">
        <?php if ($i['tipo'] === 'api'): ?><input name="meta_token" placeholder="Token da Meta" style="flex:1 1 140px"><input name="meta_numero" placeholder="ID do número" style="flex:1 1 120px"><input name="meta_waba" placeholder="ID da conta Business" style="flex:1 1 120px"><?php endif; ?>
        <button class="ws-btn primary">Criar instância</button></form>
    <?php elseif ($i['tipo'] === 'comum' && $st !== 'conectado' && $st !== 'sem_evolution'): ?>
      <button class="ws-btn primary" type="button" onclick="atQr('<?= $h($i['nome']) ?>',this)">Mostrar QR code</button>
    <?php endif; ?>
    <?php if ($k === 1): ?><form method="post"><input type="hidden" name="acao" value="segunda"><button class="ws-btn" onclick="return confirm('Desativar o segundo número?')">Desativar</button></form><?php endif; ?>
    </div>
    <div class="at-qr" id="qr-<?= $h($i['nome']) ?>"></div>
  </div>
<?php endforeach; ?>
</div>

<h3 style="margin:14px 0 0">Serviços de atendimento</h3>
<div class="at-grade">
  <div class="at-card"><h3>🤖 Robô (Typebot)</h3>
    <div class="at-estado"><?= !empty($a['robo']) ? '🟢 ligado' : '⚪ desligado — só atendimento humano' ?></div>
    <form method="post" class="at-card" style="border:0;padding:0"><input type="hidden" name="acao" value="robo">
      <label>Endereço do Typebot (onde os fluxos rodam)<input name="tb_url" value="<?= $h($a['tb_url']) ?>" placeholder="https://app.suaempresa.com.br"></label>
      <label>Código do fluxo publicado<input name="tb_slug" value="<?= $h($a['tb_slug']) ?>" placeholder="ex.: meu-atendimento"></label>
      <div class="at-linha"><?php if (empty($a['robo'])): ?><button class="ws-btn primary" name="ligar" value="1">Ligar robô</button><?php else: ?><button class="ws-btn" name="ligar" value="1">Salvar</button><button class="ws-btn" name="ligar" value="0">Desligar</button><?php endif; ?></div></form>
    <details style="margin-top:4px"><summary style="cursor:pointer;font-weight:700;font-size:13px">Modelos do robô (fluxos prontos para o Typebot)</summary>
      <div class="ws-muted" style="font-size:12.5px;margin:8px 0">Os dois fluxos já vêm prontos, com o nome e os endereços desta empresa. Baixe o arquivo e importe no Typebot (Importar fluxo), publique e coloque o código do fluxo acima. Ou use a importação automática com o token da API do Typebot.</div>
      <form method="post" class="at-card" style="border:0;padding:0"><input type="hidden" name="acao" value="robo_base"><label>Endereço deste sistema que o Typebot acessa<input name="base_url" value="<?= $h(ws_robo_base_url()) ?>" placeholder="https://sistema.suaempresa.com.br"></label><div class="at-linha"><button class="ws-btn">Salvar endereço</button></div></form>
      <div class="at-linha" style="margin:8px 0"><a class="ws-btn primary" href="atendimento.php?modelo=atendimento">⬇ Modelo: Atendimento</a><a class="ws-btn" href="atendimento.php?modelo=fora">⬇ Modelo: Fora do horário</a></div>
      <form method="post" class="at-card" style="border:0;padding:0" onsubmit="return confirm('Importar e publicar o fluxo no Typebot agora?')"><input type="hidden" name="acao" value="robo_importar">
        <label>Token da API do Typebot (Configurações → Minha conta → Tokens de API)<input name="tb_api" type="password" autocomplete="off"></label>
        <label>ID do espaço de trabalho<input name="tb_ws" placeholder="ex.: cm2tp9ir…" autocomplete="off"></label>
        <label>Qual fluxo<select name="qual"><option value="atendimento">Atendimento</option><option value="fora">Fora do horário</option></select></label>
        <div class="at-linha"><button class="ws-btn">Importar e publicar</button></div></form>
    </details></div>
  <div class="at-card"><h3>🗂️ Chatwoot (caixa de atendimento)</h3>
    <div class="at-estado"><?= !empty($a['chatwoot']) ? '🟢 ligado' : '⚪ desligado' ?></div>
    <form method="post" class="at-card" style="border:0;padding:0"><input type="hidden" name="acao" value="chatwoot">
      <label>Endereço do Chatwoot<input name="cw_url" value="<?= $h($a['cw_url']) ?>" placeholder="https://chat.suaempresa.com.br"></label>
      <label>Token de acesso<input name="cw_token" type="password" autocomplete="off" placeholder="<?= $a['cw_token'] !== '' ? '•••••• (mantido)' : '' ?>"></label>
      <label>Número da conta<input name="cw_conta" value="<?= $h($a['cw_conta']) ?>"></label>
      <div class="at-linha"><?php if (empty($a['chatwoot'])): ?><button class="ws-btn primary" name="ligar" value="1">Ligar Chatwoot</button><?php else: ?><button class="ws-btn" name="ligar" value="1">Salvar</button><button class="ws-btn" name="ligar" value="0">Desligar</button><?php endif; ?></div></form></div>
  <div class="at-card"><h3>⚙️ n8n (automações)</h3>
    <div class="at-estado"><?= !empty($a['n8n']) ? '🟢 ligado' : '⚪ desligado' ?></div>
    <form method="post" class="at-card" style="border:0;padding:0"><input type="hidden" name="acao" value="n8n">
      <label>Endereço do n8n<input name="n8n_url" value="<?= $h($a['n8n_url']) ?>" placeholder="https://n8n.suaempresa.com.br"></label>
      <div class="at-linha"><?php if (empty($a['n8n'])): ?><button class="ws-btn primary" name="ligar" value="1">Ligar n8n</button><?php else: ?><button class="ws-btn" name="ligar" value="1">Salvar</button><button class="ws-btn" name="ligar" value="0">Desligar</button><?php endif; ?></div></form></div>
</div>
<p><a class="ws-btn" href="atendimento.php?assistente=1">Refazer o assistente</a></p>
<script>
var atTimer={};
function atQr(n,b){var el=document.getElementById('qr-'+n);
  function qr(){el.firstChild||(el.textContent='Gerando o QR code...');
    fetch('atendimento.php?qr='+encodeURIComponent(n)).then(function(r){return r.json();}).then(function(j){
      el.innerHTML=j.img?'<img alt="QR code" src="'+j.img+'"><div class="ws-muted" style="font-size:12px">No celular: WhatsApp → Aparelhos conectados → Conectar um aparelho.</div>':(j.msg||'Sem QR.');
    }).catch(function(){el.textContent='Não consegui o QR code.';});}
  function conf(){fetch('atendimento.php?estado='+encodeURIComponent(n)).then(function(r){return r.json();}).then(function(j){
      if(j.estado==='conectado'){clearInterval(atTimer[n+'q']);clearInterval(atTimer[n+'e']);el.innerHTML='<b>🟢 Conectado!</b>';var st=el.parentNode.querySelector('.at-estado');if(st)st.textContent='🟢 conectado';if(b)b.style.display='none';setTimeout(function(){location.reload();},1500);}
    }).catch(function(){});}
  clearInterval(atTimer[n+'q']);clearInterval(atTimer[n+'e']);qr();atTimer[n+'q']=setInterval(qr,25000);atTimer[n+'e']=setInterval(conf,3000);}
</script>
<?php endif; ?>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
