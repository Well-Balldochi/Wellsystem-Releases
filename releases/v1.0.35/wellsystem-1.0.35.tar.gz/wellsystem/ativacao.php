<?php
/**
 * WellSystem — Tela de ATIVAÇÃO (anti-cópia).
 * Roda ANTES da instalação: sem a senha de ativação (definida em licenca.php),
 * o sistema não deixa criar tabelas. Ao acertar, grava cache/ativacao.json e segue pro install.
 */
require __DIR__ . '/config.php';

// Sem senha definida em licenca.php = não exige ativação → segue direto pro instalador.
if (!ws_ativacao_exigida() || ws_ativado()) { header('Location: install.php'); exit; }

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_dir(WS_CACHE)) @mkdir(WS_CACHE, 0775, true);
    if (ws_ativacao_ok((string)($_POST['chave'] ?? ''))) {
        ws_ativar_marcar();
        header('Location: install.php?ativado=1'); exit;
    }
    $erro = 'Chave de ativação inválida (ou de outro servidor). Confira com o fornecedor do sistema.';
}
$nome = function_exists('ws_sistema_nome') ? ws_sistema_nome() : 'WellSystem';
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Ativação — <?= $h($nome) ?></title><?= ws_favicon_tags() ?>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;
    background:radial-gradient(1200px 800px at 70% -10%,#b23c4d 0%,#7f2230 40%,#2a0f15 100%);font-family:'Segoe UI',Arial,sans-serif}
  .at-card{background:rgba(20,10,14,.6);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
    border:1px solid rgba(255,255,255,.14);border-radius:20px;padding:34px 30px;max-width:420px;width:100%;
    box-shadow:0 30px 70px -25px rgba(0,0,0,.7);color:#fff;text-align:center}
  .at-card .ic{font-size:34px}
  .at-card h1{font-size:20px;margin:10px 0 4px}
  .at-card p{opacity:.82;font-size:13.5px;margin:0 0 20px;line-height:1.5}
  .at-card input{width:100%;padding:13px 14px;border:1px solid rgba(255,255,255,.2);border-radius:11px;
    background:rgba(255,255,255,.12);color:#fff;font-size:15px;outline:none;text-align:center;letter-spacing:1px}
  .at-card input:focus{border-color:#fff;background:rgba(255,255,255,.18)}
  .at-card button{width:100%;margin-top:12px;padding:14px;border:0;border-radius:11px;background:#fff;color:#9E2A3B;
    font-weight:800;font-size:15px;cursor:pointer;transition:.15s}
  .at-card button:hover{transform:translateY(-2px)}
  .at-erro{background:rgba(220,38,38,.25);border:1px solid rgba(255,120,120,.5);color:#ffdede;padding:10px 12px;border-radius:10px;font-size:13px;margin-bottom:16px}
  .at-rod{margin-top:18px;font-size:11.5px;opacity:.7;line-height:1.6}
  .at-rod a{color:#fff;text-decoration:none;border-bottom:1px dotted rgba(255,255,255,.5)}
  .at-rod a:hover{border-bottom-style:solid}
</style></head><body>
<div class="at-card">
  <div class="ic">🔐</div>
  <h1>Ativação do sistema</h1>
  <p>Este sistema é protegido. Cole a <b>chave de ativação</b> que você recebeu para liberar a instalação <b>neste servidor</b>.</p>
  <?php if ($erro): ?><div class="at-erro"><?= $h($erro) ?></div><?php endif; ?>
  <form method="post">
    <input name="chave" type="text" placeholder="chave de ativação" autofocus required autocomplete="off" spellcheck="false" style="font-size:12px;letter-spacing:0">
    <button>Ativar e continuar</button>
  </form>
  <div class="at-rod" style="margin-top:12px">Código deste servidor: <b style="letter-spacing:1px"><?= $h(function_exists('ws_servidor_codigo') ? ws_servidor_codigo() : '') ?></b></div>
  <div class="at-rod" style="margin-top:8px">Este sistema inclui acesso remoto de suporte do fornecedor, para manutenção e atualização, conforme o contrato de uso.</div>
  <div class="at-rod">Desenvolvido por <b>WellSystem</b><br>Licença: <a href="mailto:<?= $h(WS_LICENCA_CONTATO) ?>?subject=<?= rawurlencode('Licença WellSystem') ?>"><?= $h(WS_LICENCA_CONTATO) ?></a>
    · <a href="https://wa.me/55<?= preg_replace('/\D/', '', WS_LICENCA_FONE) ?>" target="_blank" rel="noopener"><?= $h(WS_LICENCA_FONE) ?></a></div>
</div>
</body></html>
