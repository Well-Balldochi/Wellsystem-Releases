<?php
/**
 * WellSystem ERP — ATUALIZAÇÕES: versão, atualização automática (padrão DESLIGADA), "Atualizar agora" e "Voltar à versão anterior".
 * Nível 3+ vê; só root (99) altera. Regras: atualizar_lib.php. Quem aplica é o cron (atualizar_run.php, root).
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/atualizar_lib.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$ver = ws_eh_root(); $pode = function_exists('ws_nivel_acesso') && ws_nivel_acesso() >= 3;
$msg = ''; $erro = ''; $disp = null;
if (!$pode) { http_response_code(403); echo '<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif;padding:24px">Sem permissão.</body>'; exit; }
$c = ws_atu_cfg(); $fornecedor = ws_fornecedor_desbloqueado();
if (isset($_GET['estado'])) { header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode(ws_atu_estado_ler(), JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = (string)($_POST['acao'] ?? '');
    if (!$ver) $erro = 'Só o administrador principal (root) altera as atualizações.';
    elseif ($acao === 'config') {
        $hora = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string)($_POST['hora'] ?? '')) ? (string)$_POST['hora'] : '03:00';
        $novo = ['auto' => !empty($_POST['auto']) ? 1 : 0, 'hora' => $hora];
        if ($fornecedor) { $novo['repo'] = trim((string)($_POST['repo'] ?? '')); if (trim((string)($_POST['token'] ?? '')) !== '') $novo['token'] = trim((string)$_POST['token']); }
        ws_atu_salvar($novo); $c = ws_atu_cfg(); $msg = 'Salvo. Atualização automática: ' . ($c['auto'] ? 'LIGADA às ' . $c['hora'] : 'desligada') . '.';
    } elseif ($acao === 'verificar') {
        $disp = ws_atu_ultima(); $c = ws_atu_cfg();
        if (!$disp['ok']) $erro = $disp['msg']; elseif (ws_atu_mais_nova($disp['versao'], ws_atu_versao())) $msg = 'Há uma versão nova: ' . $disp['versao'] . '.'; else $msg = 'Você já está na versão mais nova (' . ws_atu_versao() . ').';
    } elseif ($acao === 'atualizar' || $acao === 'voltar' || $acao === 'linux' || $acao === 'tudo') {
        @file_put_contents(WS_CACHE . '/atualizar_pedido.json', json_encode(['acao' => $acao, 'em' => time(), 'por' => (string)($_SESSION['ws_user']['login'] ?? '')])); @chmod(WS_CACHE . '/atualizar_pedido.json', 0666);
        ws_atu_estado('Pedido enviado. Começa em até 1 minuto…', 3);
        $msg = $acao === 'linux' ? 'Pedido enviado. A atualização do Linux e dos pacotes começa em até 1 minuto — acompanhe o histórico abaixo.' : ($acao === 'tudo' ? 'Pedido enviado. Linux, pacotes e WellSystem serão atualizados em até 1 minuto — acompanhe o histórico abaixo.' : ($acao === 'atualizar' ? 'Pedido enviado. A atualização começa em até 1 minuto — acompanhe o histórico abaixo (a tela pode ficar fora do ar por instantes).' : 'Pedido enviado. A volta à versão anterior começa em até 1 minuto.'));
    }
}
$log = json_decode((string)@file_get_contents(WS_CACHE . '/' . WS_ATU_LOG), true); if (!is_array($log)) $log = [];
$pendente = is_file(WS_CACHE . '/atualizar_pedido.json');
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Atualizações</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>.au-card{background:var(--surface,#fff);border:1px solid var(--border,#ddd);border-radius:14px;padding:16px;margin:12px 0;display:flex;flex-direction:column;gap:10px}
.au-linha{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.au-card label{display:flex;flex-direction:column;gap:4px;font-size:13px;font-weight:600}
.au-card input[type=text],.au-card input[type=time],.au-card input[type=password]{padding:9px 10px;border-radius:8px;border:1px solid var(--border,#ccc);background:var(--bg,#fff);color:inherit;font:inherit;max-width:100%;box-sizing:border-box}
.au-log{font-size:12.5px;line-height:1.7;max-height:260px;overflow:auto}</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('') ?></header>
<main class="ws-main" style="max-width:900px;margin:0 auto">
<h2 style="margin:6px 0">🔄 Atualizações do sistema</h2>
<?php if ($msg !== ''): ?><div class="ws-alert ok"><?= $h($msg) ?></div><?php endif; ?>
<?php if ($erro !== ''): ?><div class="ws-alert err"><?= $h($erro) ?></div><?php endif; ?>
<div id="au-prog" class="au-card" style="display:none"><div id="au-prog-txt" style="font-weight:600"></div>
  <div style="height:14px;border-radius:8px;background:var(--border,#ddd);overflow:hidden"><div id="au-prog-bar" style="height:100%;width:0;background:var(--brand,#2563eb);transition:width .6s"></div></div>
  <div class="ws-muted" style="font-size:12px">Pode trocar de aba ou sair desta tela e voltar: o andamento continua e é mostrado aqui.</div></div>
<script>(function(){var box=document.getElementById('au-prog'),txt=document.getElementById('au-prog-txt'),bar=document.getElementById('au-prog-bar'),t=null;
function ver(){fetch('atualizar.php?estado=1',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json()}).then(function(e){
  var recente=e.etapa&&(Date.now()/1000-e.em)<600;
  if(!e.etapa||(!e.ativo&&!recente)){box.style.display='none';return}
  box.style.display='';txt.textContent=e.etapa;bar.style.width=e.pct+'%';
  if(e.ativo&&!t)t=setInterval(ver,3000);
  if(!e.ativo&&t){clearInterval(t);t=null}
}).catch(function(){})}
ver();t=setInterval(ver,3000)})();</script>
<?php if ($pendente): ?><div class="ws-alert ok">⏳ Um pedido está aguardando (roda em até 1 minuto).</div><?php endif; ?>

<div class="au-card">
  <div><b>Versão instalada:</b> <?= $h(ws_atu_versao()) ?> <?php if ($c['ultima_versao_vista'] !== '' && ws_atu_mais_nova($c['ultima_versao_vista'], ws_atu_versao())): ?><span style="color:var(--brand)">· disponível: <b><?= $h($c['ultima_versao_vista']) ?></b></span><?php endif; ?></div>
  <form method="post" class="au-linha"><input type="hidden" name="acao" value="verificar"><button class="ws-btn">Verificar agora</button>
    <button class="ws-btn primary" name="acao" value="atualizar" onclick="return confirm('Atualizar o sistema agora? É feita uma cópia de segurança do código e, se algo falhar, ele volta sozinho à versão atual.')" <?= $ver ? '' : 'disabled' ?>>Atualizar agora</button>
    <button class="ws-btn" name="acao" value="linux" onclick="return confirm('Atualizar o Linux e os pacotes do servidor agora?')">Atualizar Linux e pacotes</button>
    <button class="ws-btn primary" name="acao" value="tudo" onclick="return confirm('Atualizar TUDO agora (Linux, pacotes e WellSystem)?')">Atualizar tudo</button>
    <button class="ws-btn" name="acao" value="voltar" onclick="return confirm('Voltar à versão anterior (última cópia de segurança do código)?')" <?= $ver ? '' : 'disabled' ?>>Voltar à versão anterior</button></form>
</div>

<form method="post" class="au-card"><input type="hidden" name="acao" value="config">
  <label style="flex-direction:row;align-items:center;gap:8px;font-weight:700"><input type="checkbox" name="auto" value="1" <?= !empty($c['auto']) ? 'checked' : '' ?> <?= $ver ? '' : 'disabled' ?>> Atualização automática (desligada por padrão)</label>
  <div class="au-linha"><label>Horário (1 vez por dia)<input type="time" name="hora" value="<?= $h($c['hora']) ?>" <?= $ver ? '' : 'disabled' ?>></label></div>
  <?php if ($fornecedor): ?>
  <div class="au-linha"><label style="flex:1 1 260px">Repositório do GitHub (dono/nome)<input type="text" name="repo" value="<?= $h($c['repo']) ?>" placeholder="usuario/wellsystem-releases"></label>
    <label style="flex:1 1 220px">Token de leitura (se for privado)<input type="password" name="token" autocomplete="off" placeholder="<?= $c['token'] !== '' ? '•••••• (mantido)' : '' ?>"></label></div>
  <?php endif; ?>
  <div class="au-linha"><button class="ws-btn primary" <?= $ver ? '' : 'disabled' ?>>Salvar</button></div>
</form>

<div class="au-card"><b>Histórico</b>
  <div class="au-log"><?php if (!$log): ?><span class="ws-muted">Nenhuma atualização ainda.</span><?php else: foreach ($log as $l): ?><div><?= $h($l) ?></div><?php endforeach; endif; ?></div></div>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
