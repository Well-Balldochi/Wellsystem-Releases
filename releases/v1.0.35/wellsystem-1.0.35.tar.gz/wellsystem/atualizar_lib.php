<?php
/**
 * WellSystem — ATUALIZAÇÃO pelo GitHub (Releases), com ligar/desligar. Padrão de instalação: DESLIGADA (só "Atualizar agora").
 *
 * Como funciona: o fornecedor publica uma Release no GitHub com dois arquivos — wellsystem-X.Y.Z.tar.gz e wellsystem-X.Y.Z.tar.gz.sig.
 * A .sig é a assinatura Ed25519 (mesma chave privada das ativações) de "X.Y.Z|<sha256 do .tar.gz>". O servidor SÓ aplica pacote cuja assinatura
 * confere com a chave pública do sistema; pacote adulterado ou de terceiros é recusado. Aplicação (root, por atualizar_run.php no cron):
 * copia de segurança do código → ATUALIZAR.sh do pacote novo → conferência de sintaxe e da página → volta sozinho se algo falhar.
 * Nunca toca em cache/, uploads/, backups/, cache_trafego/ (é o que o ATUALIZAR.sh já protege).
 * Config em cache/atualizacao.json: auto (0|1), hora ('03:00'), repo ('dono/repositorio'), token (opcional, repositório privado).
 */
if (!defined('WS_CACHE')) require_once __DIR__ . '/config.php';

const WS_ATU_ARQ = 'atualizacao.json';
const WS_ATU_LOG = 'atualizacao_log.json';

function ws_atu_cfg(): array {
    $c = json_decode((string)@file_get_contents(WS_CACHE . '/' . WS_ATU_ARQ), true);
    $pad = ['auto' => 0, 'hora' => '03:00', 'repo' => defined('WS_ATUALIZACAO_REPO') ? (string)WS_ATUALIZACAO_REPO : '', 'token' => '', 'ultimo_check' => 0, 'ultima_versao_vista' => ''];
    return is_array($c) ? array_merge($pad, $c) : $pad;
}
function ws_atu_salvar(array $novo): void {
    $c = array_merge(ws_atu_cfg(), $novo);
    @file_put_contents(WS_CACHE . '/' . WS_ATU_ARQ, json_encode($c, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX); @chmod(WS_CACHE . '/' . WS_ATU_ARQ, 0640);
}
/** Versão instalada (arquivo VERSAO na raiz do sistema). */
function ws_atu_versao(): string {
    $v = trim((string)@file_get_contents(__DIR__ . '/VERSAO'));
    return preg_match('/^\d+\.\d+\.\d+$/', $v) ? $v : '0.0.0';
}
/** Estado da atualização em andamento (barra de progresso). Gravado no servidor: a tela pode ser fechada e reaberta. */
function ws_atu_estado(string $etapa, int $pct, bool $ativo = true): void {
    $f = WS_CACHE . '/atualizar_estado.json';
    @file_put_contents($f, json_encode(['etapa' => $etapa, 'pct' => max(0, min(100, $pct)), 'ativo' => $ativo, 'em' => time()], JSON_UNESCAPED_UNICODE), LOCK_EX); @chmod($f, 0666);
}
function ws_atu_estado_ler(): array {
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/atualizar_estado.json'), true);
    if (!is_array($j) || empty($j['etapa'])) return ['etapa' => '', 'pct' => 0, 'ativo' => false, 'em' => 0];
    if (!empty($j['ativo']) && time() - (int)$j['em'] > 1800) $j['ativo'] = false;   // travou/morreu: não fica a barra para sempre
    return $j;
}
function ws_atu_log(string $linha): void {
    $f = WS_CACHE . '/' . WS_ATU_LOG; $l = json_decode((string)@file_get_contents($f), true); if (!is_array($l)) $l = [];
    array_unshift($l, date('d/m/Y H:i') . ' — ' . $linha); $l = array_slice($l, 0, 30);
    @file_put_contents($f, json_encode($l, JSON_UNESCAPED_UNICODE), LOCK_EX); @chmod($f, 0644);
}
function ws_atu_http(string $url, string $token = '', int $tempo = 30, string $saida = ''): array {
    $ch = curl_init($url);
    $h = ['User-Agent: WellSystem-Atualizador', 'Accept: ' . (($saida !== '' || strpos($url, '/releases/assets/') !== false) ? 'application/octet-stream' : 'application/vnd.github+json')]; if ($token !== '') $h[] = 'Authorization: Bearer ' . $token;
    $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_MAXREDIRS => 5, CURLOPT_TIMEOUT => $tempo, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_HTTPHEADER => $h];
    $fp = null; if ($saida !== '') { $fp = fopen($saida, 'wb'); $o[CURLOPT_RETURNTRANSFER] = 0; $o[CURLOPT_FILE] = $fp; }
    curl_setopt_array($ch, $o); $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $e = curl_error($ch); curl_close($ch); if ($fp) fclose($fp);
    return [$s, $saida !== '' ? '' : (string)$r, $e];
}
/** Consulta a última Release. ['ok','versao','tar_url','sig_url','msg'] — sem baixar nada. */
function ws_atu_ultima(): array {
    $c = ws_atu_cfg(); $repo = trim($c['repo']);
    if (!preg_match('#^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$#', $repo)) return ['ok' => false, 'msg' => 'Repositório do GitHub não configurado.'];
    [$s, $raw, $e] = ws_atu_http("https://api.github.com/repos/$repo/releases/latest", (string)$c['token'], 20);
    if ($s !== 200) return ['ok' => false, 'msg' => $s === 404 ? 'Nenhuma release encontrada (ou repositório privado sem token).' : 'GitHub respondeu HTTP ' . $s . ($e !== '' ? " ($e)" : '')];
    $j = json_decode($raw, true); $ver = ltrim((string)($j['tag_name'] ?? ''), 'vV');
    if (!preg_match('/^\d+\.\d+\.\d+$/', $ver)) return ['ok' => false, 'msg' => 'A release não tem versão no formato X.Y.Z.'];
    $tar = ''; $sig = '';
    foreach ((array)($j['assets'] ?? []) as $a) {
        $n = (string)($a['name'] ?? ''); $u = (string)($c['token'] !== '' ? ($a['url'] ?? '') : ($a['browser_download_url'] ?? ''));
        if ($n === "wellsystem-$ver.tar.gz") $tar = $u; elseif ($n === "wellsystem-$ver.tar.gz.sig") $sig = $u;
    }
    if ($tar === '' || $sig === '') return ['ok' => false, 'msg' => "A release $ver não tem os dois arquivos (wellsystem-$ver.tar.gz e .sig)."];
    ws_atu_salvar(['ultimo_check' => time(), 'ultima_versao_vista' => $ver]);
    return ['ok' => true, 'versao' => $ver, 'tar_url' => $tar, 'sig_url' => $sig, 'msg' => ''];
}
function ws_atu_mais_nova(string $a, string $b): bool { return version_compare($a, $b, '>'); }

/** Confere a assinatura de um pacote baixado: "versao|sha256" assinado com a chave privada do fornecedor. */
function ws_atu_assinatura_ok(string $arquivo, string $versao, string $sigBase64): bool {
    if (!function_exists('sodium_crypto_sign_verify_detached')) return false;
    $pub = base64_decode((string)(defined('WS_LICENCA_PUBKEY') ? WS_LICENCA_PUBKEY : ''), true); $sig = base64_decode(trim($sigBase64), true);
    if ($pub === false || $sig === false || strlen($pub) !== 32 || strlen($sig) !== 64 || !is_file($arquivo)) return false;
    try { return sodium_crypto_sign_verify_detached($sig, $versao . '|' . hash_file('sha256', $arquivo), $pub); } catch (Throwable $e) { return false; }
}
/** Baixa, confere e DEVOLVE o caminho do pacote pronto (ou '' + motivo). Não aplica. */
function ws_atu_baixar(array $u, string $pasta): array {
    $c = ws_atu_cfg(); @mkdir($pasta, 0700, true);
    $tar = "$pasta/wellsystem-{$u['versao']}.tar.gz";
    [$s1, , $e1] = ws_atu_http($u['tar_url'], (string)$c['token'], 600, $tar);
    [$s2, $sig] = ws_atu_http($u['sig_url'], (string)$c['token'], 30);
    if ($s1 !== 200 || $s2 !== 200) return ['', 'Falha ao baixar a release (HTTP ' . $s1 . '/' . $s2 . ')'];
    if (!ws_atu_assinatura_ok($tar, $u['versao'], $sig)) { @unlink($tar); return ['', 'ASSINATURA INVÁLIDA — pacote recusado.']; }
    return [$tar, ''];
}
