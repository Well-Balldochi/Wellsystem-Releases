<?php
/** Mostra as últimas falas de áudio que o robô entendeu (cache/audio_transcricoes.json) — só pelo terminal. Uso: php audio_ver.php [quantas, padrão 20] */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$f = __DIR__ . '/cache/audio_transcricoes.json';
$l = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
$n = max(1, (int)($argv[1] ?? 20));
if (!$l) { echo "Nenhuma transcrição guardada ainda.\n"; exit; }
foreach (array_slice($l, -$n) as $x) echo $x['h'] . '  final ' . $x['n'] . '  [' . $x['v'] . ']  ' . $x['t'] . "\n";
