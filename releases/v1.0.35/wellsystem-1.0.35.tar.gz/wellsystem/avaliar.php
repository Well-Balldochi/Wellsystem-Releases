<?php
/**
 * WellSystem — página PÚBLICA da pesquisa de satisfação (avaliar.php?c=<chamado>-<assinatura>). Regras em satisfacao_lib.php.
 * Sem login: o link vai só para o cliente do chamado e é assinado (não dá para avaliar o chamado de outro trocando o número).
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/satisfacao_lib.php';
header('X-Robots-Tag: noindex, nofollow'); header('Referrer-Policy: no-referrer');
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$db = ws_db();
$ok = false; $ch = null; $feito = false;
if (preg_match('/^(\d+)-([a-f0-9]{16})$/', (string)($_GET['c'] ?? $_POST['c'] ?? ''), $m) && hash_equals(ws_satisf_sig((int)$m[1]), $m[2])) {
    $q = $db->prepare("SELECT ch.id, ch.titulo, ch.avaliacao, ch.cliente_id, c.nome FROM ws_chamado ch JOIN ws_cliente c ON c.id=ch.cliente_id WHERE ch.id=?");
    $q->execute([(int)$m[1]]); $ch = $q->fetch(PDO::FETCH_ASSOC) ?: null; $ok = (bool)$ch;
}
$prov = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: [];
$provNome = (function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: (($prov['razao'] ?? '') ?: 'Provedor')));
if ($ok && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $ch['avaliacao'] === null) {
    $nota = max(1, min(5, (int)($_POST['nota'] ?? 0)));
    $com = mb_substr(trim((string)($_POST['comentario'] ?? '')), 0, 300);
    $db->prepare("UPDATE ws_chamado SET avaliacao=?, avaliacao_comentario=?, avaliacao_em=NOW() WHERE id=? AND avaliacao IS NULL")->execute([$nota, $com !== '' ? $com : null, (int)$ch['id']]);
    if (function_exists('ws_evento')) ws_evento($db, (int)$ch['cliente_id'], 'chamado', "Cliente avaliou o chamado #{$ch['id']} com $nota estrela(s) pela pesquisa de satisfação" . ($com !== '' ? ": \"$com\"" : '.'));
    if ($nota <= 2 && function_exists('ws_evento')) {
        /* 06/10/2026: cliente insatisfeito NÃO vai mais para o número da gerência (ela só recebe servidor fora do ar /
           saúde / erro crítico). Fica na linha do tempo do cliente e no chamado, onde o atendimento — que já conversa com
           ele pelo WhatsApp (instância com a conversa aberta) — vê na hora. */
        try {
            ws_evento($db, (int)$ch['cliente_id'], 'chamado', "⚠️ Cliente INSATISFEITO ($nota/5) no chamado #{$ch['id']}: {$ch['titulo']}" . ($com !== '' ? " — \"$com\"" : '') . '. Vale um contato para recuperar.');
            $db->prepare("INSERT INTO ws_chamado_msg (chamado_id,usuario_id,autor_tipo,mensagem) VALUES (?,NULL,'sistema',?)")
               ->execute([(int)$ch['id'], "⚠️ Cliente avaliou com $nota/5" . ($com !== '' ? ": \"$com\"" : '.') . ' Vale um contato para recuperar.']);
        } catch (Throwable $e) {}
    }
    header('Location: avaliar.php?c=' . rawurlencode((string)$_POST['c']) . '&ok=1'); exit;
}
if ($ok && $ch['avaliacao'] !== null) $feito = true;
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Avalie o atendimento — <?= $h($provNome) ?></title><?= function_exists('ws_favicon_tags') ? ws_favicon_tags() : '' ?>
<style>
:root{--cor:#9E2A3B;--txt:#1f2937;--mut:#6b7280;--bg:#f4f5f7;--card:#fff}
@media (prefers-color-scheme:dark){:root{--txt:#e5e7eb;--mut:#9ca3af;--bg:#111318;--card:#1b1e25}}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--txt);font:16px/1.5 'Segoe UI',Roboto,Arial,sans-serif;padding:16px}
.card{background:var(--card);border-radius:18px;padding:24px 20px;max-width:440px;width:100%;text-align:center;box-shadow:0 10px 30px -18px rgba(0,0,0,.4)}
h1{font-size:19px;margin:6px 0 4px}.mut{color:var(--mut);font-size:14px}
.est{display:flex;justify-content:center;gap:6px;margin:18px 0 6px;flex-direction:row-reverse}
.est input{display:none}.est label{font-size:44px;cursor:pointer;color:#d1d5db;transition:.12s;line-height:1}
.est label:hover,.est label:hover~label,.est input:checked~label{color:#f59e0b}
textarea{width:100%;min-height:70px;border:1px solid rgba(128,128,128,.4);border-radius:12px;padding:10px;font:inherit;background:transparent;color:inherit;margin-top:10px}
button{width:100%;margin-top:14px;padding:14px;border:0;border-radius:12px;background:var(--cor);color:#fff;font-weight:800;font-size:16px;cursor:pointer}
.ic{font-size:44px}
</style></head><body><div class="card">
<?php if (!$ok): ?>
  <div class="ic">🔒</div><h1>Link inválido</h1><p class="mut">Confira o link recebido no WhatsApp.</p>
<?php elseif ($feito || isset($_GET['ok'])): ?>
  <div class="ic">💚</div><h1>Obrigado pela avaliação!</h1><p class="mut">Sua opinião ajuda <?= $h($provNome) ?> a melhorar sempre.</p>
<?php else: ?>
  <div class="mut"><?= $h($provNome) ?></div>
  <h1>Como foi o seu atendimento?</h1>
  <p class="mut">Chamado nº <?= (int)$ch['id'] ?><?= $ch['titulo'] ? ' — ' . $h($ch['titulo']) : '' ?></p>
  <form method="post"><input type="hidden" name="c" value="<?= $h($_GET['c'] ?? '') ?>">
    <div class="est"><?php for ($i = 5; $i >= 1; $i--): ?><input type="radio" id="n<?= $i ?>" name="nota" value="<?= $i ?>" required><label for="n<?= $i ?>" title="<?= $i ?>">★</label><?php endfor; ?></div>
    <textarea name="comentario" maxlength="300" placeholder="Quer comentar algo? (opcional)"></textarea>
    <button>Enviar avaliação</button>
  </form>
<?php endif; ?>
</div></body></html>
