<?php
/**
 * WellSystem — Download de backup (somente admin logado).
 * backup_download.php?arquivo=wellsystem_YYYYmmdd_HHMMSS.sql.gz
 */
require __DIR__ . '/config.php';
require __DIR__ . '/seguranca.php';

if (empty($_SESSION['ws_user']) || ($_SESSION['ws_user']['nivel'] ?? '') !== 'admin') { http_response_code(403); exit('só admin'); }

$arq = basename((string)($_GET['arquivo'] ?? ''));
if (!preg_match('/^wellsystem_\d{8}_\d{6}\.sql(\.gz)?$/', $arq)) { http_response_code(400); exit('nome inválido'); }

$caminho = ws_backup_dir() . '/' . $arq;
if (!is_file($caminho)) { http_response_code(404); exit('não encontrado'); }

header('Content-Type: application/octet-stream');
header('Content-Length: ' . filesize($caminho));
header('Content-Disposition: attachment; filename="' . $arq . '"');
readfile($caminho);
