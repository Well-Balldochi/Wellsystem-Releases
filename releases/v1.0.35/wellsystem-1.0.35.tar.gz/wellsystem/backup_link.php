<?php
/**
 * WellSystem — download do backup por LINK SEGURO (24/10/2026). Sem login: quem tem o link (token aleatório de 48 caracteres, enviado só ao e-mail do backup) baixa o arquivo inteiro.
 * Validade de 7 dias e até 10 downloads; regras em backup_lib.php (ws_backup_link_criar / ws_backup_link_abrir).
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/backup_lib.php';
header('X-Robots-Tag: noindex, nofollow'); header('Referrer-Policy: no-referrer');
$t = (string)($_GET['t'] ?? '');
$r = preg_match('/^[a-f0-9]{48}$/', $t) ? ws_backup_link_abrir($t) : null;
if (!$r) { http_response_code(404); header('Content-Type: text/html; charset=utf-8'); echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Link inválido</title><p style="font-family:sans-serif;margin:40px">Link inválido ou expirado.</p>'; exit; }
@set_time_limit(0); while (ob_get_level()) @ob_end_clean();
header('Content-Type: application/octet-stream'); header('Content-Length: ' . $r[2]); header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $r[1]) . '"'); header('Cache-Control: no-store');
$fh = fopen($r[0], 'rb'); if ($fh) { while (!feof($fh)) { echo fread($fh, 1048576); flush(); } fclose($fh); }