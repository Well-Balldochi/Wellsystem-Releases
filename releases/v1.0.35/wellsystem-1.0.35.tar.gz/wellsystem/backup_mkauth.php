<?php
/**
 * WellSystem — tela "Backup para MK-Auth" (mkauth_export.php faz o trabalho). Só nível 3 e Root.
 * 1) guarda um backup real do MK-Auth como MODELO (estrutura/configuração que o MK-Auth espera);
 * 2) o operador marca as cidades e o que levar;
 * 3) baixa o <SERIAL>.maz e restaura no MK-Auth (Backup → Restaurar).
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
if (!ws_pode_configurar()) { http_response_code(403); exit('Exclusivo de nível 3 e root.'); }
require_once __DIR__ . '/mkauth_export.php';
/* (17/10/2026) HTTP 500 ao gerar com todas as cidades/opções: o PHP da web tem memory_limit de 128 MB e o backup usa ~250 MB (24 mil títulos + caixa). Sobe o limite só nesta tela (o servidor permite). */
@ini_set('memory_limit', '1536M'); @set_time_limit(900);
$db = ws_db();
$msg = ''; $err = '';

if (isset($_GET['baixar'])) {   // só arquivos da pasta de saída, pelo nome exato
    $n = basename((string)$_GET['baixar']); $f = MKE_DIR . '/saida/' . $n;
    if (!preg_match('/^\d{8}-\d{6}_[A-Za-z0-9]+\.maz$/', $n) || !is_file($f)) { http_response_code(404); exit('Arquivo não encontrado (vale por 24 h).'); }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . preg_replace('/^\d{8}-\d{6}_/', '', $n) . '"');
    header('Content-Length: ' . filesize($f));
    readfile($f); exit;
}
$res = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (($_POST['acao'] ?? '') === 'modelo') {
            if (empty($_FILES['maz']['tmp_name']) || (int)$_FILES['maz']['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Escolha o arquivo .maz gerado no MK-Auth.');
            [$ok, $m] = mke_modelo_salvar($_FILES['maz']['tmp_name'], (string)$_FILES['maz']['name']);
            if (!$ok) throw new RuntimeException($m); $msg = $m;
        } elseif (($_POST['acao'] ?? '') === 'gerar') {
            $res = mke_gerar($db, (array)($_POST['ramais'] ?? []), ['pagos' => !empty($_POST['pagos']), 'cancelados' => !empty($_POST['cancelados']), 'caixa' => !empty($_POST['caixa'])]);
            if (function_exists('ws_evento')) try { ws_evento($db, null, 'backup', 'Backup para MK-Auth gerado: ' . $res['resumo']['clientes'] . ' clientes, ' . $res['resumo']['titulos'] . ' títulos.'); } catch (Throwable $e) {}
        }
    } catch (Throwable $e) { $err = $e->getMessage(); }
}
$info = mke_modelo_info();
$ramais = [];
try { $ramais = $db->query("SELECT r.id, r.nome, c.nome cidade, (SELECT COUNT(*) FROM ws_cliente cl WHERE cl.ramal_id=r.id AND cl.titular_id IS NULL) n
                            FROM ws_ramal r JOIN ws_cidade c ON c.id=r.cidade_id WHERE r.ativo=1 ORDER BY c.nome, r.nome")->fetchAll(); } catch (Throwable $e) {}
$semRamal = 0; try { $semRamal = (int)$db->query("SELECT COUNT(*) FROM ws_cliente WHERE titular_id IS NULL AND (ramal_id IS NULL OR ramal_id=0)")->fetchColumn(); } catch (Throwable $e) {}
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Backup para MK-Auth</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>.bm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,420px),1fr));gap:14px}
.bm-c{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:14px 16px}
.bm-c h3{margin:0 0 8px;font-size:16px}.bm-ok{border-color:var(--ok)}.bm-l{display:flex;gap:8px;align-items:center;margin:5px 0}
.bm-n{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;margin:10px 0}
.bm-n div{background:var(--surface-2,var(--bg));border-radius:10px;padding:8px 10px}.bm-n b{display:block;font-size:20px}</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('config') ?></header>
<main class="ws-main">
  <h2 style="margin:0 0 4px">🗄️ Backup para MK-Auth</h2>
  <p class="ws-muted" style="margin:0 0 12px;font-size:13px">Gera um arquivo <b>.maz</b> no formato do MK-Auth com os clientes, logins, planos, bloqueios e títulos do WellSystem, pronto para restaurar num MK-Auth limpo (Backup → Restaurar).</p>
  <?php if ($msg): ?><div class="ws-alert" style="border-color:var(--ok)">✅ <?= h($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="ws-alert">⚠️ <?= h($err) ?></div><?php endif; ?>
  <?php if ($res): ?>
  <div class="bm-c bm-ok" style="margin-bottom:14px"><h3>✅ Backup pronto</h3>
    <div class="bm-n"><div>Clientes<b><?= (int)$res['resumo']['clientes'] ?></b></div><div>Adicionais<b><?= (int)$res['resumo']['adicionais'] ?></b></div>
      <div>Títulos<b><?= (int)$res['resumo']['titulos'] ?></b></div><div>Bloqueados<b><?= (int)$res['resumo']['bloqueados'] ?></b></div><div>Caixa<b><?= (int)$res['resumo']['caixa'] ?></b></div></div>
    <?php foreach ($res['avisos'] as $a): ?><div class="ws-muted" style="font-size:13px">• <?= h($a) ?></div><?php endforeach; ?>
    <p style="margin:10px 0 6px"><a class="ws-btn primary" href="backup_mkauth.php?baixar=<?= h(rawurlencode(basename($res['arquivo']))) ?>">⬇ Baixar <?= h($res['nome']) ?></a>
      <span class="ws-muted" style="font-size:12px">MD5 <?= h($res['md5']) ?> · disponível por 24 h</span></p>
    <div class="ws-muted" style="font-size:12.5px">No MK-Auth: <b>Backup → Restaurar</b> e envie este arquivo. As configurações (NAS, contas, operadores, provedor) são as do modelo.</div>
  </div>
  <?php endif; ?>
  <div class="bm-grid">
    <form class="bm-c" method="post" enctype="multipart/form-data"><h3>1 · Modelo do MK-Auth</h3>
      <?php if ($info): ?><div class="bm-l">✅ <span>Modelo guardado: <b><?= h($info['nome']) ?></b> — serial <?= h($info['serial']) ?>, <?= number_format($info['tamanho'] / 1048576, 1, ',', '.') ?> MB, de <?= date('d/m/Y H:i', $info['data']) ?></span></div>
      <?php else: ?><div class="bm-l">⚠️ <span>Nenhum modelo ainda. Gere um backup no MK-Auth e envie aqui.</span></div><?php endif; ?>
      <p class="ws-muted" style="font-size:12.5px;margin:6px 0">O modelo dá a estrutura exata das tabelas e as configurações do MK-Auth. Troque quando atualizar a versão do MK-Auth.</p>
      <input type="hidden" name="acao" value="modelo"><input type="file" name="maz" accept=".maz" required>
      <button class="ws-btn" style="margin-top:8px">Enviar modelo</button>
    </form>
    <form class="bm-c" method="post" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='Gerando… (pode levar 1 minuto)'"><h3>2 · O que levar</h3>
      <input type="hidden" name="acao" value="gerar">
      <b style="font-size:13px">Cidades</b> <span class="ws-muted" style="font-size:12px">(nenhuma marcada = todas<?= $semRamal ? ", inclusive $semRamal sem cidade" : '' ?>)</span>
      <?php foreach ($ramais as $r): ?><label class="bm-l"><input type="checkbox" name="ramais[]" value="<?= (int)$r['id'] ?>"> <?= h($r['cidade'] . ' — ' . $r['nome']) ?> <span class="ws-muted">(<?= (int)$r['n'] ?>)</span></label><?php endforeach; ?>
      <hr style="border:0;border-top:1px solid var(--border);margin:10px 0">
      <label class="bm-l"><input type="checkbox" checked disabled> Clientes, adicionais, logins, planos e bloqueios</label>
      <label class="bm-l"><input type="checkbox" checked disabled> Títulos em aberto e vencidos</label>
      <label class="bm-l"><input type="checkbox" name="pagos" value="1" checked> Títulos pagos (histórico)</label>
      <label class="bm-l"><input type="checkbox" name="caixa" value="1" checked> Caixa (um lançamento por pagamento)</label>
      <label class="bm-l"><input type="checkbox" name="cancelados" value="1"> Clientes cancelados e títulos cancelados</label>
      <button class="ws-btn primary" style="margin-top:10px" <?= $info ? '' : 'disabled' ?>>Gerar backup para MK-Auth</button>
    </form>
  </div>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
