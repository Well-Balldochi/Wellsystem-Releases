<?php
/**
 * WellSystem — TESTE DE RESTAURAÇÃO do backup (cron semanal e botão em Backup). Só linha de comando.
 * Restaura o último backup num banco temporário, confere e apaga. Regras em ws_backup_teste_restaurar() (backup_lib.php).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php';
require_once __DIR__ . '/backup_lib.php';
$trava = fopen(WS_CACHE . '/backup_teste.lock', 'c');
if (!$trava || !flock($trava, LOCK_EX | LOCK_NB)) exit(0);
$r = ws_backup_teste_restaurar();
echo ($r['ok'] ? 'OK' : 'FALHOU') . ' ' . $r['arquivo'] . ' ' . ($r['erro'] ?? '') . "\n";
