<?php
/**
 * WellSystem — API PIX DO BANCO DO BRASIL: baixa automática do PIX PRÓPRIO (QR/chave da conta do provedor). 01/10/2026.
 *
 * O PROBLEMA: PIX pago direto na chave/QR próprio cai na conta e ninguém avisa o sistema — a baixa era manual e o
 * comprovante (print) podia ser falso. Com a API PIX do BB (developers.bb.com.br, permissão pix.read), o WellSystem:
 *   1. a cada minuto lê os PIX RECEBIDOS na conta (GET /pix?inicio&fim) e grava cada um em ws_pix_recebido (o E2E é
 *      único: nada é processado duas vezes);
 *   2. acha o título: identificador do QR (txid = nome do cliente em CamelCase, ws_pix_txid_nome(), ou "WS<nº>")
 *      ou, sem identificador, o CPF/CNPJ de quem pagou → título em aberto do cliente com o MESMO valor cobrado
 *      (o mais antigo, se houver mais de um) → BAIXA AUTOMÁTICA (recibo + desbloqueio, igual às outras baixas);
 *      sem título que bata = fica em "PIX recebidos não identificados" (Financeiro → Gateway) para o operador;
 *   3. comprovante mandado pelo robô: o E2E lido (selo antifraude) é CONSULTADO no banco (GET /pix/{e2e}). Achou =
 *      pagamento confirmado (a conciliação dá a baixa). Não achou = "⚠️ PIX não encontrado na conta" (comprovante
 *      falso) — a baixa por aquele comprovante é recusada.
 * Credenciais em cache/bb_pix.json (0640, como as outras APIs). Certificado da empresa (e-CNPJ, exigido pelo BB na
 * conexão mTLS) convertido para PEM em /var/lib/wellsystem/bb/ — FORA do site, 0600.
 * Sem a API configurada nada disto roda e o resto do sistema segue igual (Provedor → Integrações mostra o que falta).
 */
require_once __DIR__ . '/config.php';

const WS_BB_DIR = '/var/lib/wellsystem/bb';

function ws_bb_cfg(): array {
    $d = ['ambiente' => 'producao', 'client_id' => '', 'client_secret' => '', 'app_key' => '', 'banco_id' => 0,
          'url_oauth' => '', 'url_api' => '', 'cert' => '', 'key' => '', 'auto_comprovante' => 1];   // auto_comprovante: baixa sozinha o comprovante do WhatsApp JÁ CONFIRMADO NO BANCO (ver ws_comp_auto_baixa)
    $j = json_decode((string)@file_get_contents(WS_CACHE . '/bb_pix.json'), true);
    return is_array($j) ? array_merge($d, $j) : $d;
}
function ws_bb_salvar(array $c): void {
    @file_put_contents(WS_CACHE . '/bb_pix.json', json_encode(array_merge(ws_bb_cfg(), $c), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    @chmod(WS_CACHE . '/bb_pix.json', 0640);
}
function ws_bb_pronto(): bool { $c = ws_bb_cfg(); return $c['client_id'] !== '' && $c['client_secret'] !== '' && $c['app_key'] !== ''; }

/** Endereços oficiais do BB (podem ser trocados na tela, campo avançado, se o BB mudar). */
function ws_bb_urls(): array {
    $c = ws_bb_cfg(); $h = $c['ambiente'] === 'homologacao';
    return ['oauth' => $c['url_oauth'] ?: ($h ? 'https://oauth.hm.bb.com.br/oauth/token' : 'https://oauth.bb.com.br/oauth/token'),
            'api'   => rtrim($c['url_api'] ?: ($h ? 'https://api.hm.bb.com.br/pix/v2' : 'https://api-pix.bb.com.br/pix/v2'), '/')];
}

function ws_bb_sql(): string {
    return "CREATE TABLE IF NOT EXISTS ws_pix_recebido (
        id INT AUTO_INCREMENT PRIMARY KEY,
        e2e VARCHAR(40) NOT NULL,
        txid VARCHAR(40) DEFAULT NULL,
        valor DECIMAL(10,2) NOT NULL,
        horario DATETIME DEFAULT NULL,
        pagador_doc VARCHAR(20) DEFAULT NULL,
        pagador_nome VARCHAR(120) DEFAULT NULL,
        info VARCHAR(200) DEFAULT NULL,
        situacao VARCHAR(16) NOT NULL DEFAULT 'novo',
        fatura_id INT DEFAULT NULL,
        cliente_id INT DEFAULT NULL,
        obs VARCHAR(255) DEFAULT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_e2e (e2e), INDEX idx_sit (situacao, horario)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
}

/** Requisição à API (token em cache; mTLS com o certificado da empresa, se enviado). [código, json, texto]. */
function ws_bb_http(string $metodo, string $url, array $hdr = [], ?string $corpo = null): array {
    $c = ws_bb_cfg();
    $ch = curl_init($url);
    $op = [CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $hdr];
    if ($corpo !== null) $op[CURLOPT_POSTFIELDS] = $corpo;
    if ($c['cert'] !== '' && is_file($c['cert'])) { $op[CURLOPT_SSLCERT] = $c['cert']; if ($c['key'] !== '' && is_file($c['key'])) $op[CURLOPT_SSLKEY] = $c['key']; }
    curl_setopt_array($ch, $op);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($raw === false) return [0, null, 'curl: ' . $err];
    return [$code, json_decode((string)$raw, true), (string)$raw];
}

function ws_bb_token(bool $novo = false): string {
    $f = WS_CACHE . '/bb_pix_token.json';
    $t = json_decode((string)@file_get_contents($f), true);
    if (!$novo && is_array($t) && ($t['exp'] ?? 0) > time() + 60) return (string)$t['t'];
    $c = ws_bb_cfg();
    [$code, $j, $raw] = ws_bb_http('POST', ws_bb_urls()['oauth'], ['Authorization: Basic ' . base64_encode($c['client_id'] . ':' . $c['client_secret']),
        'Content-Type: application/x-www-form-urlencoded'], 'grant_type=client_credentials&scope=pix.read');
    if ($code < 200 || $code >= 300 || empty($j['access_token'])) throw new RuntimeException('BB recusou o login da API (HTTP ' . $code . '): ' . mb_substr($raw, 0, 200));
    @file_put_contents($f, json_encode(['t' => $j['access_token'], 'exp' => time() + (int)($j['expires_in'] ?? 600)])); @chmod($f, 0640);
    return (string)$j['access_token'];
}

/** GET autenticado na API PIX (com a gw-dev-app-key que o BB exige). */
function ws_bb_get(string $caminho, array $q = []): array {
    $q['gw-dev-app-key'] = ws_bb_cfg()['app_key'];
    $url = ws_bb_urls()['api'] . $caminho . '?' . http_build_query($q);
    $r = ws_bb_http('GET', $url, ['Authorization: Bearer ' . ws_bb_token()]);
    if ($r[0] === 401) $r = ws_bb_http('GET', $url, ['Authorization: Bearer ' . ws_bb_token(true)]);   // token vencido antes da hora
    return $r;
}

/** PIX recebidos entre dois momentos (todas as páginas). */
function ws_bb_recebidos(int $de, int $ate): array {
    $out = [];
    for ($pg = 0; $pg < 50; $pg++) {
        [$code, $j, $raw] = ws_bb_get('/pix', ['inicio' => gmdate('Y-m-d\TH:i:s\Z', $de), 'fim' => gmdate('Y-m-d\TH:i:s\Z', $ate), 'paginacao.paginaAtual' => $pg]);
        if ($code === 404) break;   // nenhum PIX no período
        if ($code < 200 || $code >= 300 || !is_array($j)) throw new RuntimeException('BB: consulta de PIX recebidos falhou (HTTP ' . $code . '): ' . mb_substr($raw, 0, 200));
        foreach ((array)($j['pix'] ?? []) as $p) if (is_array($p) && !empty($p['endToEndId'])) $out[] = $p;
        if ($pg + 1 >= (int)($j['parametros']['paginacao']['quantidadeDePaginas'] ?? 1)) break;
    }
    return $out;
}

/** Um PIX pelo E2E (confirmação do comprovante). null = não existe na conta; exceção = falha de comunicação. */
function ws_bb_pix_e2e(string $e2e): ?array {
    [$code, $j, $raw] = ws_bb_get('/pix/' . rawurlencode($e2e));
    if ($code === 404) return null;
    if ($code < 200 || $code >= 300 || !is_array($j)) throw new RuntimeException('BB: consulta do PIX falhou (HTTP ' . $code . ')');
    return $j;
}

/** Acha o título de um PIX recebido. [fatura|null, cliente_id|null, motivo]. */
function ws_bb_casar(PDO $db, array $p): array {
    $valor = round((float)($p['valor'] ?? 0), 2);
    $txid = trim((string)($p['txid'] ?? ''));
    $doc = preg_replace('/\D/', '', (string)($p['pagador']['cpf'] ?? ($p['pagador']['cnpj'] ?? '')));
    $clientes = [];
    if (preg_match('/^WS(\d+)$/i', $txid, $m)) {   // QR do modelo enviado: WS + número do título
        $q = $db->prepare("SELECT cliente_id FROM ws_fatura WHERE id=?"); $q->execute([(int)$m[1]]); if ($cid = (int)$q->fetchColumn()) $clientes[$cid] = 'título no QR';
    }
    if (!$clientes && $txid !== '' && !preg_match('/^\*+$/', $txid)) {   // QR próprio: txid = nome do cliente em CamelCase
        if (!function_exists('ws_pix_txid_nome') && is_file(__DIR__ . '/pix.php')) require_once __DIR__ . '/pix.php';
        $prim = preg_replace('/^([A-Z][a-z]*).*/', '$1', $txid);
        $q = $db->prepare("SELECT id, nome FROM ws_cliente WHERE nome LIKE ? LIMIT 400"); $q->execute([$prim . '%']);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $c) if (function_exists('ws_pix_txid_nome') && strcasecmp(ws_pix_txid_nome($c['nome'], 0), $txid) === 0) $clientes[(int)$c['id']] = 'identificador do QR';
    }
    if (!$clientes && (strlen($doc) === 11 || strlen($doc) === 14)) {   // chave digitada: CPF/CNPJ de quem pagou
        $q = $db->prepare("SELECT id FROM ws_cliente WHERE REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/',''),' ','')=? LIMIT 5"); $q->execute([$doc]);
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $cid) $clientes[(int)$cid] = 'CPF/CNPJ do pagador';
    }
    if (!$clientes) return [null, null, 'sem cliente pelo identificador/CPF'];
    $in = implode(',', array_map('intval', array_keys($clientes)));
    $fs = $db->query("SELECT * FROM ws_fatura WHERE cliente_id IN ($in) AND status IN ('aberto','vencido') ORDER BY vencimento, id")->fetchAll(PDO::FETCH_ASSOC);
    // valor do título OU o valor com multa e juros no dia do PIX (cliente que pagou atrasado o valor atualizado)
    foreach ($fs as $f) if (abs(ws_fatura_valor_cobrado($f) - $valor) < 0.01 || abs((float)$f['valor'] - $valor) < 0.01 || (function_exists('ws_fatura_valor_atualizado') && abs(ws_fatura_valor_atualizado($f, !empty($p['horario']) ? substr((string)$p['horario'], 0, 10) : null) - $valor) < 0.02)) return [$f, (int)$f['cliente_id'], $clientes[(int)$f['cliente_id']] ?? ''];
    return [null, (int)array_key_first($clientes), 'cliente achado (' . reset($clientes) . '), mas nenhum título em aberto de R$ ' . number_format($valor, 2, ',', '.')];
}

/** Baixa pelo PIX conferido no banco — mesma regra das baixas automáticas (recibo + desbloqueio). */
function ws_bb_baixar(PDO $db, array $f, array $p): bool {
    $valor = round((float)$p['valor'], 2);
    $ts = strtotime((string)($p['horario'] ?? '')) ?: time();
    $db->beginTransaction();
    try {
        $up = $db->prepare("UPDATE ws_fatura SET status='pago', data_pagamento=?, valor_pago=? WHERE id=? AND status<>'pago'");
        $up->execute([date('Y-m-d', $ts), $valor, $f['id']]);
        if ($up->rowCount() === 0) { $db->rollBack(); return false; }
        // QUEM PAGOU (08/10/2026): nome do pagador que o BANCO informou, quando é outra pessoa (terceiro) — vai para o Caixa e para o recibo; o próprio cliente fica em branco ("O próprio cliente")
        if (!function_exists('ws_comp_nomes_batem') && is_file(__DIR__ . '/comprovantes_lib.php')) require_once __DIR__ . '/comprovantes_lib.php';
        $pp = trim((string)($p['_pago_por'] ?? ''));
        if ($pp === '' && !empty($p['pagador']['nome']) && function_exists('ws_comp_nomes_batem')) {
            $nc = $db->prepare("SELECT nome FROM ws_cliente WHERE id=?"); $nc->execute([(int)$f['cliente_id']]); $nomeCli = (string)$nc->fetchColumn();
            if ($nomeCli !== '' && !ws_comp_nomes_batem((string)$p['pagador']['nome'], $nomeCli)) $pp = mb_convert_case(mb_strtolower((string)$p['pagador']['nome'], 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        }
        /* 09/10/2026 (pedido do provedor): no Caixa, no recibo e no resumo fica CLARO que foi a BAIXA AUTOMÁTICA (PIX/QR conferido no
           banco), e não um atendente — "Recebido por: Baixa automática PIX/QR". */
        $db->prepare("INSERT INTO ws_pagamento (fatura_id,data_pgto,valor_pago,forma,origem,obs,coletor,pago_por) VALUES (?,?,?, 'pix', 'banco', ?, 'Baixa automática PIX/QR', ?)")
           ->execute([$f['id'], date('Y-m-d', $ts), $valor, mb_substr('Baixa automática PIX/QR — conferido no Banco do Brasil' . (!empty($p['_comprovante']) ? ' (comprovante do WhatsApp #' . (int)$p['_comprovante'] . ')' : '') . ' · E2E ' . $p['endToEndId'], 0, 255), mb_substr($pp, 0, 120) ?: null]);
        if (function_exists('ws_evento')) ws_evento($db, (int)$f['cliente_id'], 'fatura', "Baixa automática PIX/QR (conferido no Banco do Brasil): Fatura #{$f['id']} R$ " . number_format($valor, 2, ',', '.') . ' · E2E ' . $p['endToEndId']);
        $db->commit();
    } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
    // selo do comprovante com o mesmo E2E (se o cliente mandou pelo robô): fica atrelado a esta baixa
    try { $db->prepare("UPDATE ws_pix_selo SET fatura_id=?, cliente_id=?, usado_em=NOW(), usado_por='Banco do Brasil (automático)' WHERE e2e=? AND duplicado_de IS NULL AND usado_em IS NULL")
             ->execute([$f['id'], (int)$f['cliente_id'], $p['endToEndId']]); } catch (Throwable $e) {}
    if (is_file(__DIR__ . '/radius_lib.php')) { require_once __DIR__ . '/radius_lib.php'; try { ws_rad_apos_pagamento($db, (int)$f['contrato_id']); } catch (Throwable $e) {} }
    if (is_file(__DIR__ . '/whatsapp.php')) {
        require_once __DIR__ . '/whatsapp.php';
        if (function_exists('ws_recibo_config') && !empty(ws_recibo_config()['auto']) && function_exists('ws_recibo_enviar')) { try { ws_recibo_enviar($db, (int)$f['id'], 'gateway'); } catch (Throwable $e) {} }
    }
    return true;
}

/** Trata UM PIX recebido (da lista do banco ou confirmado pelo comprovante): grava (uma vez só) e dá baixa se casar. */
function ws_bb_processar(PDO $db, array $p): string {
    try { $db->exec(ws_bb_sql()); } catch (Throwable $e) {}
    $ins = $db->prepare("INSERT IGNORE INTO ws_pix_recebido (e2e, txid, valor, horario, pagador_doc, pagador_nome, info) VALUES (?,?,?,?,?,?,?)");
    $ins->execute([$p['endToEndId'], mb_substr((string)($p['txid'] ?? ''), 0, 40) ?: null, round((float)($p['valor'] ?? 0), 2),
        ($t = strtotime((string)($p['horario'] ?? ''))) ? date('Y-m-d H:i:s', $t) : null,
        preg_replace('/\D/', '', (string)($p['pagador']['cpf'] ?? ($p['pagador']['cnpj'] ?? ''))) ?: null,
        mb_substr((string)($p['pagador']['nome'] ?? ''), 0, 120) ?: null, mb_substr((string)($p['infoPagador'] ?? ''), 0, 200) ?: null]);
    if ($ins->rowCount() === 0) return 'repetido';   // já processado antes
    [$f, $cid, $motivo] = ws_bb_casar($db, $p);
    $sit = 'sem_titulo'; $fid = null;
    if ($f) { try { if (ws_bb_baixar($db, $f, $p)) { $sit = 'baixado'; $fid = (int)$f['id']; } else $sit = 'ja_pago'; } catch (Throwable $e) { $sit = 'erro'; $motivo = $e->getMessage(); } }
    $db->prepare("UPDATE ws_pix_recebido SET situacao=?, fatura_id=?, cliente_id=?, obs=? WHERE e2e=?")->execute([$sit, $fid, $cid, mb_substr((string)$motivo, 0, 255), $p['endToEndId']]);
    return $sit;
}

/** Conciliação: lê os PIX recebidos na janela e dá baixa no que casar. [lidos, novos, baixas]. */
function ws_bb_conciliar(PDO $db, int $janelaMin = 120): array {
    $res = ['lidos' => 0, 'novos' => 0, 'baixas' => 0];
    if (!ws_bb_pronto()) return $res;
    $lista = ws_bb_recebidos(time() - $janelaMin * 60, time());
    $res['lidos'] = count($lista);
    foreach ($lista as $p) { $s = ws_bb_processar($db, $p); if ($s !== 'repetido') $res['novos']++; if ($s === 'baixado') $res['baixas']++; }
    return $res;
}

/** Comprovante do robô com E2E lido: confere no banco. 'banco_ok' (existe; baixa se casar) | 'banco_nao' (não existe = falso) | '' (sem como conferir).
 *  09/10/2026 — SEM FRAUDE FALSA POR ERRO DE LEITURA: o E2E tem letras maiúsculas/minúsculas (Mercado Pago, Nubank…) e o OCR troca
 *  O/0, l/1 e às vezes come ou inventa uma letra. Se o E2E exato não existir, procura na conta os PIX do MESMO minuto (o horário está
 *  dentro do próprio E2E) e do mesmo valor: E2E quase igual = é ele (devolve o E2E real em $real). "banco_nao" só quando a conta foi
 *  consultada e NÃO há nenhum PIX parecido (mesmo horário/valor) — aí sim o comprovante é falso. Na dúvida: '' (o financeiro confere). */
function ws_bb_conferir_comprovante(PDO $db, string $e2e, ?float $valor = null, ?string &$real = null): string {
    $real = $e2e;
    if ($e2e === '' || !ws_bb_pronto()) return '';
    try { $p = ws_bb_pix_e2e($e2e); } catch (Throwable $e) { return ''; }   // banco fora do ar: não acusa ninguém
    if ($p) { if (empty($p['endToEndId'])) $p['endToEndId'] = $e2e; $real = (string)$p['endToEndId']; ws_bb_processar($db, $p); return 'banco_ok'; }
    // não achou o E2E exato: procura parecido no minuto do PIX (±15 min)
    if (!preg_match('/^E\d{8}(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/i', $e2e, $m)) return '';
    $t = gmmktime((int)$m[4], (int)$m[5], 0, (int)$m[2], (int)$m[3], (int)$m[1]); if (!$t) return '';
    try { $lista = ws_bb_recebidos($t - 900, $t + 900); } catch (Throwable $e) { return ''; }
    $norm = fn(string $x) => strtr(strtoupper($x), ['O' => '0', 'I' => '1', 'L' => '1']);
    $alvo = $norm($e2e); $mesmoValor = 0; $achado = null;
    foreach ($lista as $q) {
        $e = (string)($q['endToEndId'] ?? ''); if ($e === '') continue;
        $vOk = $valor === null || abs(round((float)($q['valor'] ?? 0), 2) - $valor) < 0.01;
        if ($vOk) $mesmoValor++;
        $ne = $norm($e);
        if (substr($ne, 0, 21) === substr($alvo, 0, 21) && levenshtein(substr($ne, 21), substr($alvo, 21)) <= 3 && $vOk) { $achado = $q; break; }
    }
    if ($achado) { $real = (string)$achado['endToEndId']; ws_bb_processar($db, $achado); return 'banco_ok'; }
    return $mesmoValor > 0 ? '' : 'banco_nao';   // há PIX do mesmo valor no horário mas o ID não bateu: não acusa (financeiro confere)
}
/** Testa credenciais + certificado: login e consulta das últimas 24 h. [ok, msg]. */
function ws_bb_testar(): array {
    @unlink(WS_CACHE . '/bb_pix_token.json');
    try { ws_bb_token(true); $n = count(ws_bb_recebidos(time() - 86400, time())); return [true, "Conexão OK com o Banco do Brasil — $n PIX recebido(s) nas últimas 24 h."]; }
    catch (Throwable $e) { return [false, $e->getMessage()]; }
}

/** Certificado e-CNPJ (.pfx/.p12 + senha) → PEM em /var/lib/wellsystem/bb (fora do site, 0600). [ok, msg]. */
function ws_bb_certificado(string $tmp, string $senha): array {
    if (!is_dir(WS_BB_DIR) && !@mkdir(WS_BB_DIR, 0700, true)) return [false, 'Sem permissão para criar ' . WS_BB_DIR . '.'];
    $certs = [];
    if (!@openssl_pkcs12_read((string)file_get_contents($tmp), $certs, $senha)) return [false, 'Não consegui abrir o certificado: senha errada ou arquivo inválido (.pfx/.p12).'];
    $pem = $certs['cert'] . (isset($certs['extracerts']) ? implode('', (array)$certs['extracerts']) : '');
    $kp = WS_BB_DIR . '/chave.pem'; $cp = WS_BB_DIR . '/certificado.pem';
    file_put_contents($cp, $pem); file_put_contents($kp, $certs['pkey']); @chmod($cp, 0600); @chmod($kp, 0600);
    $info = openssl_x509_parse($certs['cert']) ?: [];
    ws_bb_salvar(['cert' => $cp, 'key' => $kp]);
    return [true, 'Certificado instalado: ' . ($info['subject']['CN'] ?? 'empresa') . (isset($info['validTo_time_t']) ? ' · válido até ' . date('d/m/Y', $info['validTo_time_t']) : '') . '.'];
}
