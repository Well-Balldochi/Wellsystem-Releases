<?php
/**
 * WellSystem — CONCILIAÇÃO DO PIX PRÓPRIO NO BANCO DO BRASIL (cron a cada minuto: /etc/cron.d/wellsystem).
 * Sem a API do BB configurada (Financeiro → Gateway → Banco do Brasil) termina na hora: até lá a baixa do PIX
 * próprio continua sendo conferida pelo financeiro, como sempre. Lógica em ws_bb_conciliar() (bb_pix.php).
 * Janela de 2 h a cada rodada (o BB pode demorar a listar um PIX); o E2E único impede baixa em dobro.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require __DIR__ . '/config.php';
if (!is_file(__DIR__ . '/bb_pix.php')) exit;
require_once __DIR__ . '/bb_pix.php';
if (!ws_bb_pronto()) exit;
$trava = @fopen(WS_CACHE . '/bb_pix_run.lock', 'c');
if (!$trava || !flock($trava, LOCK_EX | LOCK_NB)) exit;
try {
    $r = ws_bb_conciliar(ws_db(), 120);
    @file_put_contents(WS_CACHE . '/bb_pix_status.json', json_encode(['em' => time(), 'ok' => true] + $r));
} catch (Throwable $e) {
    @file_put_contents(WS_CACHE . '/bb_pix_status.json', json_encode(['em' => time(), 'ok' => false, 'erro' => mb_substr($e->getMessage(), 0, 300)]));
}
@chmod(WS_CACHE . '/bb_pix_status.json', 0640);
flock($trava, LOCK_UN); fclose($trava);
