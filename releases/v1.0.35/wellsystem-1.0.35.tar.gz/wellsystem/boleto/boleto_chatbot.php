<?php
/**
 * WellSystem — /boleto/boleto.hhvm?titulo=ID&contrato=LOGIN (mesmo endereço do MK-Auth).
 * O n8n busca este HTML e o converte em PDF para mandar no WhatsApp. Abre SÓ título em aberto cujo
 * login confere com um contrato do cliente, e só com a API do chatbot ligada (api_chatbot.php).
 */
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/api_chatbot.php';
$titulo = (int)($_GET['titulo'] ?? 0);
$login  = (string)($_GET['contrato'] ?? '');
if (!ws_chatbot_boleto_permitido(ws_db(), $titulo, $login)) {
    http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); exit('Boleto não encontrado.');
}
define('WS_BOLETO_CHATBOT', $titulo);
require dirname(__DIR__) . '/boleto.php';
