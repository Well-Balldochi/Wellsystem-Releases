<?php
/**
 * WellSystem ERP — Modelos de Boleto/Carnê (edição FORA do código).
 * Tudo que dá pra tirar do PHP fica aqui em arquivos editáveis:
 *   - HTML do modelo próprio  → uploads/sistema/boleto-modelo.html   (boleto.php já lê)
 *   - Textos/instruções       → <cache>/boleto_textos.json            (boleto.php já lê)
 * Assim o operador troca layout e textos por upload/tela, sem tocar em nenhum .php.
 * Acesso: só nível 3+ e root (ws_pode_configurar).
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
if (!ws_pode_configurar()) { $_SESSION['ws_flash_err'] = '❌ Acesso restrito (nível 3+ e root).'; header('Location: erp.php?p=dashboard'); exit; }

$arqModelo  = WS_UP_SISTEMA . '/boleto-modelo.html';
$arqTextos  = WS_CACHE . '/boleto_textos.json';
$msg = '';

// ---- Ações (gravam em arquivo, nunca no código) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if ($acao === 'salvar_textos') {
        $t = ['instrucoes' => trim($_POST['instrucoes'] ?? '')];
        @file_put_contents($arqTextos, json_encode($t, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        $msg = '✅ Textos salvos.';
    } elseif ($acao === 'salvar_html') {
        $html = (string)($_POST['html'] ?? '');
        if (trim($html) === '') { @unlink($arqModelo); $msg = '✅ Modelo próprio removido (volta a usar o carnê padrão do sistema).'; }
        else { @file_put_contents($arqModelo, $html); $msg = '✅ Modelo HTML salvo.'; }
    } elseif ($acao === 'upload_html' && !empty($_FILES['arquivo']['tmp_name'])) {
        $f = $_FILES['arquivo'];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['html', 'htm'], true)) { $msg = '❌ Envie um arquivo .html.'; }
        elseif ($f['size'] > 512 * 1024) { $msg = '❌ Arquivo grande demais (máx. 512 KB).'; }
        else { ws_mover_upload($f['tmp_name'], $arqModelo); $msg = '✅ Modelo enviado por upload.'; }
    } elseif ($acao === 'upload_logo' && !empty($_FILES['logo']['tmp_name'])) {
        $f = $_FILES['logo'];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['png','jpg','jpeg','webp','gif','svg'], true)) { $msg = '❌ Use PNG, JPG, WEBP, GIF ou SVG.'; }
        elseif ($f['size'] > 2 * 1024 * 1024) { $msg = '❌ Logo maior que 2 MB.'; }
        else {
            if (!is_dir(WS_UP_SISTEMA)) @mkdir(WS_UP_SISTEMA, 0775, true);
            foreach (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: [] as $old) @unlink($old);
            if (ws_mover_upload($f['tmp_name'], WS_UP_SISTEMA . '/doc-logo.' . $ext)) $msg = '✅ Logo do boleto/carnê salva.';
            else $msg = '❌ Não consegui gravar em uploads/sistema/ (permissão da pasta no servidor).';
        }
    } elseif ($acao === 'remover_logo') {
        foreach (glob(WS_UP_SISTEMA . '/doc-logo.*') ?: [] as $old) @unlink($old);
        $msg = '✅ Logo do boleto removida (volta a usar a logo da marca do sistema).';
    }
}
$logoBoleto = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? null;

$htmlAtual   = is_file($arqModelo) ? (string)@file_get_contents($arqModelo) : '';
$textosAtual = is_file($arqTextos) ? (json_decode((string)@file_get_contents($arqTextos), true) ?: []) : [];
$instrucoes  = $textosAtual['instrucoes'] ?? "Boleto disponível na Central do Assinante %provedornome%.\nApós o vencimento cobrar multa de %multa%% e juros de %juros%% ao mês.\nApós vencido, sujeito à suspensão dos serviços conforme contrato.";
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Modelos de Boleto</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>">
<style>
  .bt-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  @media(max-width:900px){.bt-grid{grid-template-columns:1fr}}
  .bt-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px 20px;box-shadow:var(--shadow)}
  .bt-card h3{margin:0 0 6px}
  .bt-card textarea{width:100%;font-family:monospace;font-size:12.5px;padding:8px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:inherit;resize:vertical}
  .bt-var{font-size:12px;color:var(--muted);line-height:1.9}
  .bt-var code{background:rgba(125,125,125,.15);padding:1px 6px;border-radius:4px}
  .bt-msg{background:#ecfdf5;border:1px solid #10b981;color:#065f46;border-radius:8px;padding:10px 12px;margin-bottom:14px}
</style></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('provedor') ?></header><main class="ws-main">
<div class="ws-head-row"><h2>🧾 Modelos de Boleto/Carnê</h2>
  <a class="ws-btn" href="provedor.php?p=dados">← Provedor</a></div>
<p class="ws-muted" style="font-size:13px;max-width:760px">Aqui você edita o <b>layout</b> e os <b>textos</b> do boleto <b>sem mexer no código</b> — tudo é gravado em arquivos (<code>uploads/sistema/</code> e cache). O <code>boleto.php</code> lê esses arquivos automaticamente na próxima impressão.</p>

<?php if ($msg): ?><div class="bt-msg"><?= h($msg) ?></div><?php endif; ?>

<div class="bt-card" style="margin-bottom:16px">
  <h3>Logo do boleto/carnê (independente do topo)</h3>
  <p class="ws-muted" style="font-size:12px">Esta logo aparece só no boleto/carnê. O topo do sistema usa a logo da Marca (Config → Geral). Sem esta, o boleto usa a da marca.</p>
  <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
    <?php if ($logoBoleto): ?>
      <img src="<?= h(ws_img("uploads/sistema/" . basename($logoBoleto) . "?v=" . @filemtime($logoBoleto))) ?>" alt="logo" style="max-height:56px;max-width:200px;object-fit:contain;background:#fff;border:1px solid var(--border);border-radius:6px;padding:6px">
    <?php else: ?><span class="ws-muted" style="font-size:12px">Nenhuma logo específica — usando a da marca.</span><?php endif; ?>
    <form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center">
      <input type="hidden" name="acao" value="upload_logo">
      <input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,.gif,.svg">
      <button class="ws-btn primary" type="submit">Enviar logo</button>
    </form>
    <?php if ($logoBoleto): ?>
      <form method="post" onsubmit="return confirm('Remover a logo do boleto?')"><input type="hidden" name="acao" value="remover_logo"><button class="ws-btn" type="submit">Remover</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="bt-grid">
  <div class="bt-card">
    <h3>Textos / Instruções</h3>
    <p class="ws-muted" style="font-size:12px">Aparecem no bloco “Instruções de responsabilidade do Beneficiário”.</p>
    <form method="post">
      <input type="hidden" name="acao" value="salvar_textos">
      <textarea name="instrucoes" rows="7"><?= h($instrucoes) ?></textarea>
      <div class="bt-var" style="margin:8px 0">
        Variáveis: <code>%provedornome%</code> <code>%multa%</code> <code>%juros%</code>
        <code>%nomecliente%</code> <code>%valortitulo%</code> <code>%diavencimento%</code>
      </div>
      <button class="ws-btn primary" type="submit">Salvar textos</button>
    </form>
  </div>

  <div class="bt-card">
    <h3>Modelo HTML próprio (opcional)</h3>
    <p class="ws-muted" style="font-size:12px">Se preenchido, substitui o carnê padrão. Deixe vazio e salve para voltar ao padrão do sistema.</p>
    <form method="post" enctype="multipart/form-data" style="margin-bottom:10px">
      <input type="hidden" name="acao" value="upload_html">
      <input type="file" name="arquivo" accept=".html,.htm">
      <button class="ws-btn" type="submit">Enviar arquivo .html</button>
    </form>
    <form method="post">
      <input type="hidden" name="acao" value="salvar_html">
      <textarea name="html" rows="12" placeholder="Cole aqui o HTML do modelo, ou deixe vazio para usar o padrão..."><?= h($htmlAtual) ?></textarea>
      <div class="bt-var" style="margin:8px 0">
        Variáveis: <code>%nomecliente%</code> <code>%valortitulo%</code> <code>%diavencimento%</code>
        <code>%nossonumero%</code> <code>%provedornome%</code> <code>%pixqr%</code> <code>%pixcopiaecola%</code>
      </div>
      <button class="ws-btn primary" type="submit">Salvar HTML</button>
    </form>
  </div>
</div>
</main><?= ws_footer_bar() ?></body></html>
