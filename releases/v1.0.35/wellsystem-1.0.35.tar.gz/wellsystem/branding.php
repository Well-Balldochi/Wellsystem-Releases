<?php
/**
 * WellSystem — Marca / white-label. Nome e logo do sistema, aplicados em todas as telas.
 * Config em cache/branding.json; a logo fica em assets/ (pública, pra aparecer no login/portal).
 */
require_once __DIR__ . '/config.php';

define('WS_BRANDING_CFG', WS_CACHE . '/branding.json');
define('WS_ASSETS', WS_DIR . '/assets');

const WS_LOGO_MIMES = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', 'image/gif' => 'gif'];

/** Config da marca (nome, logo, cor primária opcional). */
function ws_branding(): array {
    $def = ['nome' => 'WellSystem', 'logo' => '', 'cor' => '', 'logo_url' => ''];
    if (is_file(WS_BRANDING_CFG)) {
        $c = json_decode(@file_get_contents(WS_BRANDING_CFG), true);
        if (is_array($c)) return array_merge($def, $c);
    }
    return $def;
}

function ws_branding_salvar(array $cfg): void {
    if (function_exists('ws_eh_root') && !ws_eh_root() && !empty($_SESSION['ws_user'])) {
        return; // Apenas o usuário ROOT pode alterar a marca / logo do sistema
    }
    /* NOME DO SISTEMA = marca de registro (marca_registro.php): só muda com a senha root do banco,
       conferida antes por quem chama ($GLOBALS['ws_marca_autorizada']). Sem ela o nome fica como está. */
    if (array_key_exists('nome', $cfg) && trim((string)$cfg['nome']) !== (string)ws_branding()['nome'] && empty($GLOBALS['ws_marca_autorizada'])) {
        unset($cfg['nome']); $GLOBALS['ws_marca_negada'] = true;
    }
    @file_put_contents(WS_BRANDING_CFG, json_encode(array_merge(ws_branding(), $cfg), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @chmod(WS_BRANDING_CFG, 0640);
}

/** Confere a senha root do banco quando o formulário da marca tenta trocar o NOME do sistema. */
function ws_marca_autorizar_nome(string $nomeNovo): void {
    if ($nomeNovo === (string)ws_branding()['nome']) return;
    if (is_file(__DIR__ . '/marca_registro.php')) require_once __DIR__ . '/marca_registro.php';
    if (function_exists('ws_marca_senha_root_ok') && ws_marca_senha_root_ok((string)($_POST['senha_root_banco'] ?? ''))) $GLOBALS['ws_marca_autorizada'] = true;
}

/** Logo padrão de sistema novo (selo + "Wellsystem ERP"), usada no topo/login enquanto o provedor não envia a dele. */
function ws_brand_logo_padrao(): string {
    return is_file(__DIR__ . '/img/wellsystem-logo-padrao.png') ? 'img/wellsystem-logo-padrao.png' : '';
}

/** Deixa a URL digitada pelo provedor pronta para gravar: '' (sem link) ou http(s)://... válida.
 *  "meusite.com.br" vira "https://meusite.com.br". Qualquer outra coisa (javascript:, texto solto) → null = recusada. */
function ws_brand_url_normalizar(string $url): ?string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $url)) $url = 'https://' . $url;
    if (!preg_match('#^https?://#i', $url) || filter_var($url, FILTER_VALIDATE_URL) === false) return null;
    $host = (string)parse_url($url, PHP_URL_HOST);
    if ($host === '' || strpos($host, '.') === false) return null;
    return $url;
}

/** LINK DA LOGO DO TOPO (ERP e OLT) = site do PROVEDOR, a critério dele (Configurações > Geral > Marca).
 *  Vazio = logo sem link. O selo do RODAPÉ não usa isto: leva ao site do dono do código (ws_dono_url()). */
function ws_brand_logo_url(): string {
    $u = ws_brand_url_normalizar((string)(ws_branding()['logo_url'] ?? ''));
    return $u ?? '';
}

/** Nome do sistema (para <title> etc). */
function ws_sistema_nome(): string { return ws_branding()['nome'] ?: 'WellSystem'; }

/** Marca do topo (logo se houver, senão o nome estilizado). */
/** Caminho da logo (relativo à raiz) usada em TODO o sistema: 1º a logo da Marca (branding.json);
 *  se não houver, cai na logo do boleto/documentos (uploads/sistema/doc-logo.*). Assim UMA única
 *  logo já cobre topo + boleto/carnê + documentos. Retorna '' se não houver nenhuma. */
function ws_brand_logo_arquivo(): string {
    $b = ws_branding();
    /* LOGO EM assets/ VAI PARA uploads/sistema/ (uma vez): a publicação de versão nova apagava assets/.
       Copia, confere e só então aponta a marca para a cópia — o arquivo antigo fica onde estava. */
    if (!empty($b['logo']) && strpos((string)$b['logo'], 'assets/') === 0 && is_file(ws_caminho_fisico($b['logo'])) && defined('WS_UP_SISTEMA')) {
        $dest = WS_UP_SISTEMA . '/' . basename((string)$b['logo']);
        if (!is_dir(WS_UP_SISTEMA)) @mkdir(WS_UP_SISTEMA, 0775, true);
        if ((is_file($dest) || @copy(ws_caminho_fisico($b['logo']), $dest)) && @filesize($dest) === @filesize(ws_caminho_fisico($b['logo']))) {
            $b['logo'] = 'uploads/sistema/' . basename((string)$b['logo']);
            @file_put_contents(WS_BRANDING_CFG, json_encode($b, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }
    if (!empty($b['logo']) && is_file(ws_caminho_fisico($b['logo']))) return $b['logo'];
    $d = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? '';
    return $d ? ('uploads/sistema/' . basename($d)) : '';
}

/* ---- FORMATO DA LOGO: faixa (comprida) ou redonda (selo/círculo) ----------------------
 * Tem provedor com a logo em FAIXA — o nome escrito na horizontal, bem mais larga que alta.
 * E tem provedor com a logo em SELO REDONDO, que é um círculo desenhado dentro de um
 * quadrado. Nesse segundo caso, os quatro cantos do quadrado ficam sobrando em volta do
 * círculo e a marca fica pequena e torta dentro do espaço do topo.
 *
 * Regra: faixa aparece inteira; selo aparece SÓ O CÍRCULO (os cantos são recortados).
 *
 * Como o sistema decide sozinho: mede a imagem. Largura e altura quase iguais = selo, então
 * recorta no círculo. Bem mais larga que alta = faixa, então não recorta nada.
 *
 * Medir custa uma leitura de disco. Por isso o resultado fica guardado em
 * cache/logo_formato.json junto com a data do arquivo: trocou a logo, mede de novo; não
 * trocou, lê do cache. Nenhuma página paga essa conta duas vezes.
 *
 * E quem manda, no fim, é o operador — em Configurações > Geral > Marca do sistema:
 *   'auto'     (padrão) o sistema decide pela medida da imagem
 *   'circulo'  recorta sempre no círculo
 *   'original' nunca recorta, mostra a imagem como ela é
 */
function ws_brand_logo_formato(string $rel = ''): string {
    $modo = ws_branding()['logo_formato'] ?? 'auto';
    if ($modo === 'circulo')  return 'redonda';
    if ($modo === 'original') return 'faixa';

    if ($rel === '') $rel = ws_brand_logo_arquivo();
    if ($rel === '') return 'faixa';
    $fis = ws_caminho_fisico($rel);
    if (!is_file($fis)) return 'faixa';

    // A chave junta arquivo + data: qualquer troca de logo invalida o cache sozinha.
    $chave = $rel . '|' . (int)@filemtime($fis);
    $cf = WS_CACHE . '/logo_formato.json';
    if (is_file($cf)) {
        $c = json_decode((string)@file_get_contents($cf), true);
        if (is_array($c) && ($c['chave'] ?? '') === $chave && !empty($c['formato'])) return $c['formato'];
    }

    $formato = 'faixa';
    [$larg, $alt] = ws_brand_logo_medida($fis);
    /* Folga de 0,80 a 1,25: o selo às vezes vem com uma tarja fina embaixo ou uma margem
       desigual e não fica exatamente quadrado — continua sendo um selo. Fora dessa faixa
       é logo comprida de verdade e não pode ser recortada. */
    if ($larg > 0 && $alt > 0) {
        $r = $larg / $alt;
        if ($r >= 0.80 && $r <= 1.25) $formato = 'redonda';
    }

    @file_put_contents($cf, json_encode(['chave' => $chave, 'formato' => $formato]));
    @chmod($cf, 0640);
    return $formato;
}

/** Largura e altura da imagem, em pixels. Trata SVG à mão, porque getimagesize() não lê SVG. */
function ws_brand_logo_medida(string $fis): array {
    if (strtolower(pathinfo($fis, PATHINFO_EXTENSION)) === 'svg') {
        $ini = (string)@file_get_contents($fis, false, null, 0, 2048);
        // O viewBox é a medida real do desenho; vem antes de width/height na preferência.
        if (preg_match('/viewBox\s*=\s*["\']\s*[-\d.]+[,\s]+[-\d.]+[,\s]+([\d.]+)[,\s]+([\d.]+)/i', $ini, $m)) {
            return [(float)$m[1], (float)$m[2]];
        }
        if (preg_match('/\bwidth\s*=\s*["\']([\d.]+)/i', $ini, $mw)
         && preg_match('/\bheight\s*=\s*["\']([\d.]+)/i', $ini, $mh)) {
            return [(float)$mw[1], (float)$mh[1]];
        }
        return [0, 0]; // sem medida legível: trata como faixa, que é o comportamento antigo
    }
    $i = @getimagesize($fis);
    return $i ? [(float)$i[0], (float)$i[1]] : [0, 0];
}

/** Classe CSS da logo: acrescenta ws-logo-redonda quando for selo/círculo. */
function ws_brand_logo_classe(string $base, string $rel): string {
    return $base . (ws_brand_logo_formato($rel) === 'redonda' ? ' ws-logo-redonda' : '');
}

function ws_brand_sm(): string {
    // DEMO: mostra sempre "WellSystem" (não a logo/marca real do provedor).
    if (function_exists('ws_em_demo') && ws_em_demo()) return '<div class="ws-brand-sm" title="WellSystem">' . ws_nome_estilizado('WellSystem') . '</div>';
    $rel = ws_brand_logo_arquivo();
    if ($rel === '') $rel = ws_brand_logo_padrao();   // sistema novo: logo padrão Wellsystem ERP
    if ($rel !== '' && is_file(ws_caminho_fisico($rel))) {
        $src = $rel . '?v=' . @filemtime(ws_caminho_fisico($rel));
        // logo do topo clicável -> site do PROVEDOR (Configurações > Geral > Marca); sem URL, logo sem link
        $img = '<img class="' . ws_brand_logo_classe('ws-logo', $rel) . '" src="' . h(function_exists('ws_img') ? ws_img($src) : $src) . '" alt="WellSystem">';
        $url = ws_brand_logo_url();
        if ($url === '') return '<span class="ws-logo-link">' . $img . '</span>';
        return '<a class="ws-logo-link" href="' . h($url) . '" target="_blank" rel="noopener" title="' . h(preg_replace('#^https?://#i', '', $url)) . '">' . $img . '</a>';
    }
    return '<div class="ws-brand-sm" title="WellSystem">' . ws_nome_estilizado(ws_branding()['nome']) . '</div>';
}

/** Marca grande (login/install/portal). */
function ws_brand_big(): string {
    if (function_exists('ws_em_demo') && ws_em_demo()) return '<h1 class="ws-brand" title="WellSystem">' . ws_nome_estilizado('WellSystem') . '</h1>';
    $rel = ws_brand_logo_arquivo();
    if ($rel === '') $rel = ws_brand_logo_padrao();   // sistema novo: logo padrão Wellsystem ERP
    if ($rel !== '' && is_file(ws_caminho_fisico($rel))) {
        $src = $rel . '?v=' . @filemtime(ws_caminho_fisico($rel));
        return '<img class="' . ws_brand_logo_classe('ws-logo-lg', $rel) . '" src="' . h(function_exists('ws_img') ? ws_img($src) : $src) . '" alt="WellSystem" title="WellSystem">';
    }
    return '<h1 class="ws-brand" title="WellSystem">' . ws_nome_estilizado(ws_branding()['nome']) . '</h1>';
}

/** "WellSystem" -> Well<span>System</span>; nome custom -> tudo em gradiente. */
function ws_nome_estilizado(string $nome): string {
    if (strcasecmp($nome, 'WellSystem') === 0) return 'Well<span>System</span>';
    return '<span>' . h($nome) . '</span>';
}

/** <style> que sobrescreve a cor primária, se o admin definir uma. */
function ws_branding_style(): string {
    $cor = trim(ws_branding()['cor'] ?? '');
    if ($cor === '' || !preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) return '';
    return "<style>:root{--brand:$cor;--brand-3:$cor;--grad-brand:linear-gradient(135deg,$cor,$cor)}</style>";
}

/**
 * Salva o upload da logo em assets/ e atualiza a config. @return [ok, erro]
 */
function ws_logo_upload(array $file): array {
    if (empty($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return ['ok' => false, 'erro' => 'Falha no upload.'];
    if ($file['size'] > 8 * 1024 * 1024) return ['ok' => false, 'erro' => 'Logo maior que 8 MB.'];
    $mime = function_exists('finfo_file') ? (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']) : ($file['type'] ?? '');
    if (!isset(WS_LOGO_MIMES[$mime])) return ['ok' => false, 'erro' => 'Use PNG, JPG, WEBP, SVG ou GIF.'];

    /* Pastas criadas e com permissão ajustada pelo PRÓPRIO código, antes de tentar gravar.
       WS_UPLOADS já se muda sozinho para um lugar gravável quando a pasta do addon não aceita
       escrita (ver ws_resolver_uploads_dir), então "uploads/sistema" aqui é uma garantia, não
       uma esperança. */
    if (function_exists('ws_garantir_pastas')) ws_garantir_pastas();

    // remove logo anterior
    $ant = ws_branding()['logo'] ?? '';
    if ($ant && is_file(ws_caminho_fisico($ant))) @unlink(ws_caminho_fisico($ant));

    $nome = 'logo_' . bin2hex(random_bytes(6)) . '.' . WS_LOGO_MIMES[$mime];
    /* 1ª opção: uploads/sistema/ — sobrevive a toda atualização e ao Docker (a logo em assets/ era
       apagada pela publicação de versão nova). 2ª: assets/, se uploads/ não aceitar gravação. Só
       falha se as DUAS falharem, e aí a mensagem diz onde ele tentou. */
    $e1 = $e2 = '';
    if (ws_mover_upload($file['tmp_name'], WS_UP_SISTEMA . '/' . $nome, $e2)) {
        ws_branding_salvar(['logo' => 'uploads/sistema/' . $nome]); return ['ok' => true];
    }
    if (ws_mover_upload($file['tmp_name'], WS_ASSETS . '/' . $nome, $e1)) {
        ws_branding_salvar(['logo' => 'assets/' . $nome]); return ['ok' => true];
    }
    /* O MOTIVO REAL, VINDO DO PHP — não mais um palpite meu.
     * $e1 e $e2 trazem a mensagem que o próprio PHP deu em cada tentativa (move, rename, copy),
     * que é o que separa permissão de open_basedir, de disable_functions e de disco cheio. */
    return ['ok' => false, 'erro' => 'Não consegui gravar a logo. '
            . 'Em assets/: ' . ($e1 !== '' ? $e1 : 'motivo não informado pelo PHP') . '. '
            . 'Em uploads/sistema/: ' . ($e2 !== '' ? $e2 : 'motivo não informado pelo PHP') . '.'];
}

/** Remove a logo (volta ao nome textual). */
function ws_logo_remover(): void {
    $ant = ws_branding()['logo'] ?? '';
    if ($ant && is_file(ws_caminho_fisico($ant))) @unlink(ws_caminho_fisico($ant));
    ws_branding_salvar(['logo' => '']);
}

/* ---- Galeria de fundos da TELA DE LOGIN (upload separado da central) ---- */
function ws_login_bgs(): array {
    $f = WS_CACHE . '/login_bg.json';
    if (is_file($f)) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j) && !empty($j['bgs'])) return array_values(array_filter($j['bgs'], fn($p) => is_file(ws_caminho_fisico($p)))); }
    return [];
}
/** Uma foto de fundo aleatória para o login (ou '' se não houver). */
function ws_login_bg_aleatorio(): string { $b = ws_login_bgs(); return $b ? $b[array_rand($b)] : ''; }
/** Upload de VÁRIAS fotos de fundo do login. Retorna quantas foram adicionadas. */
function ws_login_bg_upload(array $files): int {
    // Guarda o motivo da primeira falha para a tela poder mostrar (antes sumia em silencio).
    $GLOBALS['ws_login_bg_erro'] = ''; $eBg = '';
    if (!is_dir(WS_UP_SISTEMA)) @mkdir(WS_UP_SISTEMA, 0775, true);
    $cur = ws_login_bgs(); $add = 0;
    if (is_array($files['name'] ?? null)) {
        foreach ($files['name'] as $i => $orig) {
            if (($files['error'][$i] ?? 1) !== UPLOAD_ERR_OK) continue;
            $ext = strtolower(pathinfo((string)$orig, PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg','jpeg','png','webp'], true) || (int)($files['size'][$i] ?? 0) > 8 * 1024 * 1024) continue;
            $nome = 'login-bg-' . date('YmdHis') . '-' . $i . '.' . $ext;
            // ws_mover_upload() cobre move/rename/copy e ajusta a permissão do arquivo.
            if (ws_mover_upload($files['tmp_name'][$i], WS_UP_SISTEMA . '/' . $nome, $eBg)) {
                $cur[] = 'uploads/sistema/' . $nome; $add++;
            } elseif ($eBg !== '' && $GLOBALS['ws_login_bg_erro'] === '') $GLOBALS['ws_login_bg_erro'] = $eBg;
        }
    }
    @file_put_contents(WS_CACHE . '/login_bg.json', json_encode(['bgs' => array_values($cur)], JSON_UNESCAPED_SLASHES)); @chmod(WS_CACHE . '/login_bg.json', 0640);
    return $add;
}
/** Apaga todas as fotos de fundo do login. */
function ws_login_bg_limpar(): void {
    foreach (ws_login_bgs() as $p) @unlink(ws_caminho_fisico($p));
    @unlink(WS_CACHE . '/login_bg.json');
}
/** Remove as fotos de fundo do login SELECIONADAS (por nome do arquivo). Retorna quantas saíram. */
function ws_login_bg_excluir(array $sel): int {
    $alvos = array_map(fn($p) => 'uploads/sistema/' . basename((string)$p), $sel);
    $cur = ws_login_bgs(); $rem = 0; $novo = [];
    foreach ($cur as $p) {
        if (in_array($p, $alvos, true)) { @unlink(ws_caminho_fisico($p)); $rem++; }
        else $novo[] = $p;
    }
    if ($novo) @file_put_contents(WS_CACHE . '/login_bg.json', json_encode(['bgs' => array_values($novo)], JSON_UNESCAPED_SLASHES));
    else @unlink(WS_CACHE . '/login_bg.json');
    return $rem;
}
