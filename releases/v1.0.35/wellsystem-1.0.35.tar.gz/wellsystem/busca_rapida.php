<?php
/**
 * WellSystem — BUSCA RÁPIDA DA LUPA DO TOPO (clientes + títulos em aberto, com baixa direta).
 *  GET  busca_rapida.php?q=maria     → JSON: até 8 clientes (mesma regra da busca da lista de Clientes) com os títulos
 *                                       em aberto (mais antigo primeiro) e o valor a pagar HOJE (multa/juros inclusos).
 *  GET  busca_rapida.php?ok=1&pago=ID → resposta da baixa (financeiro.php redireciona para cá): JSON {ok:true}.
 * A BAIXA em si NÃO é feita aqui: o navegador envia o MESMO POST do botão "Receber" da ficha (financeiro.php,
 * acao=baixa_manual) — mesmas travas (duplicidade, antifraude), mesmo recibo, mesmo desbloqueio, mesmo log.
 * Só operador logado. Cancelado/desativado fica fora (regra do provedor).
 */
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (empty($_SESSION['ws_user'])) { http_response_code(401); echo json_encode(['ok' => false, 'erro' => 'sessao']); exit; }
$db = ws_db();

if (isset($_GET['pago'])) {   // retorno da baixa: confere que o título realmente ficou pago
    $st = $db->prepare("SELECT status FROM ws_fatura WHERE id=?"); $st->execute([(int)$_GET['pago']]);
    echo json_encode(['ok' => ($st->fetchColumn() === 'pago'), 'pago' => (int)$_GET['pago']]); exit;
}

$q = trim((string)($_GET['q'] ?? ''));
if (mb_strlen($q) < 3) { echo json_encode(['ok' => true, 'clientes' => []]); exit; }

$par = [];
$cond = ws_busca_clientes_cond($db, $q, $par);
if ($cond === '') { echo json_encode(['ok' => true, 'clientes' => []]); exit; }
$st = $db->prepare("SELECT c.id, c.nome, c.cpf_cnpj, c.status, c.celular, c.logradouro, c.numero, c.bairro,
                           (SELECT COALESCE(NULLIF(ct.login_pppoe,''), ct.login_ipoe) FROM ws_contrato ct WHERE ct.cliente_id=c.id AND ct.status<>'cancelado' ORDER BY ct.id LIMIT 1) login
                    FROM ws_cliente c
                    WHERE c.status NOT IN ('cancelado','desativado') AND ($cond)
                    ORDER BY c.nome LIMIT 8");
$st->execute($par);
$cli = $st->fetchAll(PDO::FETCH_ASSOC);

$sf = $db->prepare("SELECT f.id, f.vencimento, f.valor, f.taxa_emissao, f.banco_id, f.status
                    FROM ws_fatura f WHERE f.cliente_id=? AND f.status IN ('aberto','vencido')" . ws_sql_fatura_viva('f') . "
                    ORDER BY f.vencimento, f.id");
$saida = [];
foreach ($cli as $c) {
    $sf->execute([(int)$c['id']]); $ts = $sf->fetchAll(PDO::FETCH_ASSOC);
    $tit = []; $tot = 0.0;
    foreach (array_slice($ts, 0, 12) as $t) {
        [$dias, $multa, $mora, $devido] = ws_fatura_encargos($t);
        $n2 = fn($v) => number_format((float)$v, 2, ',', '');   // "1234,56" — o formato que a baixa aceita
        $tit[] = ['id' => (int)$t['id'], 'venc' => date('d/m/Y', strtotime((string)$t['vencimento'])), 'dias' => $dias,
                  'valor' => $devido, 'valor_fmt' => number_format($devido, 2, ',', '.'), 'valor_txt' => $n2($devido),
                  'base_txt' => $n2($t['valor']), 'taxa_txt' => $n2($t['taxa_emissao'] ?? 0), 'mm_txt' => $n2($multa + $mora)];
    }
    foreach ($ts as $t) $tot += ws_fatura_encargos($t)[3];
    $saida[] = ['id' => (int)$c['id'], 'nome' => (string)$c['nome'], 'cpf' => (string)$c['cpf_cnpj'], 'status' => (string)$c['status'],
                'login' => (string)($c['login'] ?? ''), 'fone' => (string)$c['celular'],
                'end' => trim($c['logradouro'] . ' ' . $c['numero'] . ' - ' . $c['bairro'], ' -'),
                'abertos' => count($ts), 'total_fmt' => number_format($tot, 2, ',', '.'), 'titulos' => $tit];
}
$reciboAuto = false;
if (is_file(__DIR__ . '/whatsapp.php')) { require_once __DIR__ . '/whatsapp.php'; $reciboAuto = function_exists('ws_recibo_config') && !empty(ws_recibo_config()['auto']); }
echo json_encode(['ok' => true, 'clientes' => $saida, 'recibo_auto' => $reciboAuto], JSON_UNESCAPED_UNICODE);
