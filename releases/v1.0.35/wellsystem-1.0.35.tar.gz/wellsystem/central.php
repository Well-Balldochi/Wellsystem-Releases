<?php
/**
 * WellSystem ERP — Central de modelos/imagens.
 * Faz upload de modelos e imagens do sistema (logos, carnê, avisos) para
 * uploads/sistema. As imagens de clientes ficam em uploads/clientes.
 * Reaproveita a sessão do erp.php. 100% responsivo.
 */
require __DIR__ . '/config.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$user = $_SESSION['ws_user']['nome'] ?? '';
$flash = '';
$permit = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'pdf'];

/* ------------------------------------------------------------------ ACTIONS */
if (($_POST['acao'] ?? '') === 'upload' && !empty($_FILES['arquivo']['name'])) {
    ws_dir(WS_UP_SISTEMA);
    // Aceita 1 arquivo, VÁRIOS arquivos ou uma PASTA inteira (input multiple/webkitdirectory).
    $F = $_FILES['arquivo'];
    $nomes = is_array($F['name']) ? $F['name'] : [$F['name']];
    $ok = 0; $pulados = 0; $erroUp = ''; $eUp = '';
    foreach ($nomes as $i => $orig) {
        $tmp = is_array($F['tmp_name']) ? $F['tmp_name'][$i] : $F['tmp_name'];
        $err = is_array($F['error']) ? $F['error'][$i] : $F['error'];
        $sz  = is_array($F['size']) ? $F['size'][$i] : $F['size'];
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if ($err !== UPLOAD_ERR_OK || !in_array($ext, $permit, true) || $sz > 50 * 1024 * 1024) { $pulados++; continue; }
        $slug = preg_replace('/[^a-z0-9\-_]+/i', '-', pathinfo($orig, PATHINFO_FILENAME));
        $nome = substr($slug, 0, 40) . '-' . date('YmdHis') . '-' . $i . '.' . $ext;
        // Falha de gravacao para de ser silenciosa: o motivo do PHP sobe para o aviso da tela.
        if (ws_mover_upload($tmp, WS_UP_SISTEMA . '/' . $nome, $eUp)) $ok++;
        else { $pulados++; if ($eUp !== '' && $erroUp === '') $erroUp = $eUp; }
    }
    $flash = "$ok arquivo(s) enviado(s)" . ($pulados ? ", $pulados ignorado(s)" : '') . '.'
           . ($erroUp !== '' ? ' Falha ao gravar: ' . $erroUp : '');
}
if (isset($_GET['del'])) {
    $alvo = basename($_GET['del']);
    $path = WS_UP_SISTEMA . '/' . $alvo;
    if (is_file($path)) @unlink($path);
    header('Location: central.php'); exit;
}
// Excluir em LOTE os modelos marcados (checkbox único/todos).
if (($_POST['acao'] ?? '') === 'excluir_modelos_sel') {
    foreach ((array)($_POST['arqs'] ?? []) as $n) {
        $p = WS_UP_SISTEMA . '/' . basename((string)$n);
        if (is_file($p)) @unlink($p);
    }
    header('Location: central.php'); exit;
}
// Central do assinante: escolhe padrão ou personalizada (subida por FTP em central_files/).
define('WS_CENTRAL_DIR', __DIR__ . '/central_files');
define('WS_CENTRAL_CFG', WS_CACHE . '/central.json');
ws_dir(WS_CENTRAL_DIR);
// Descobre as centrais disponíveis = subpastas de central_files/ que tenham um index (.htm/.html/.php).
function ws_central_disponiveis(): array {
    $out = [];
    foreach (glob(WS_CENTRAL_DIR . '/*', GLOB_ONLYDIR) ?: [] as $d) {
        $nome = basename($d);
        // A pasta genérica "padrao" é redundante com a opção "Padrão do sistema" (que é do próprio código),
        // então não vira uma opção separada — evita confusão de ter duas "padrão".
        $idx = '';
        foreach (['index.htm','index.html','index.php'] as $c) if (is_file("$d/$c")) { $idx = $c; break; }
        if ($idx !== '') $out[$nome] = $idx;
    }
    return $out;
}
/* ENVIAR UMA CENTRAL POR ZIP (sem FTP): extrai em central_files/<nome>, recusa caminhos perigosos e exige um index na raiz. Só quem configura o sistema. */
function ws_central_apagar_dir(string $d): void {
    if (!is_dir($d)) return;
    foreach (array_diff(scandir($d) ?: [], ['.', '..']) as $x) { $c = "$d/$x"; is_dir($c) && !is_link($c) ? ws_central_apagar_dir($c) : @unlink($c); }
    @rmdir($d);
}
if (($_POST['acao'] ?? '') === 'central_upload') {
    if (function_exists('ws_pode_configurar') && !ws_pode_configurar()) { http_response_code(403); exit('Sem permissão.'); }
    $zf = $_FILES['central_zip'] ?? null; $erroC = '';
    $nomeC = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($_POST['central_nome'] ?? ''));
    if (!$zf || ($zf['error'] ?? 4) !== UPLOAD_ERR_OK || !class_exists('ZipArchive')) $erroC = 'Envie um arquivo .zip (ou este servidor não tem suporte a ZIP).';
    elseif (strtolower(pathinfo((string)$zf['name'], PATHINFO_EXTENSION)) !== 'zip' || (int)$zf['size'] > 200 * 1024 * 1024) $erroC = 'Arquivo inválido: precisa ser um .zip de até 200 MB.';
    else {
        if ($nomeC === '') $nomeC = preg_replace('/[^A-Za-z0-9_-]/', '', pathinfo((string)$zf['name'], PATHINFO_FILENAME));
        if ($nomeC === '') $nomeC = 'Central_' . date('Ymd_His');
        $dest = WS_CENTRAL_DIR . '/' . $nomeC;
        if (is_dir($dest)) $erroC = "Já existe uma central chamada \"$nomeC\". Escolha outro nome.";
        else {
            $zip = new ZipArchive();
            if ($zip->open($zf['tmp_name']) !== true) $erroC = 'Não consegui abrir o ZIP.';
            else {
                $seguro = $zip->numFiles > 0 && $zip->numFiles <= 20000;
                for ($i = 0; $seguro && $i < $zip->numFiles; $i++) { $n = str_replace(chr(92), '/', (string)$zip->getNameIndex($i)); if ($n === '' || $n[0] === '/' || strpos($n, '../') !== false || preg_match('#^[A-Za-z]:#', $n)) $seguro = false; }
                if (!$seguro) { $zip->close(); $erroC = 'ZIP recusado (caminhos inválidos, vazio ou arquivos demais).'; }
                else {
                    ws_dir($dest); $zip->extractTo($dest); $zip->close();
                    $itens = array_values(array_diff(scandir($dest) ?: [], ['.', '..']));   // ZIP com tudo dentro de UMA pasta: sobe um nível
                    if (count($itens) === 1 && is_dir("$dest/{$itens[0]}")) { $in = "$dest/{$itens[0]}"; foreach (array_diff(scandir($in) ?: [], ['.', '..']) as $x) @rename("$in/$x", "$dest/$x"); @rmdir($in); }
                    $tem = false; foreach (['index.htm', 'index.html', 'index.php'] as $c) if (is_file("$dest/$c")) $tem = true;
                    if (!$tem) { ws_central_apagar_dir($dest); $erroC = 'O ZIP não tem um index.html (ou index.htm / index.php) na raiz.'; }
                    else $flash = "Central \"$nomeC\" enviada. Escolha-a em \"Central ativa\" e clique em Aplicar central.";
                }
            }
        }
    }
    if ($erroC !== '') $flash = $erroC;
}
$centraisDisp = ws_central_disponiveis();
if (($_POST['acao'] ?? '') === 'central_apply') {
    $folder = basename($_POST['folder'] ?? '');
    /* VÁRIOS DOMÍNIOS para a mesma central — separados por vírgula, espaço ou linha.
     * Um provedor pode publicar a central em mais de um endereço (assinante.dominio,
     * cliente.dominio, 2via.dominio). Aceitando só um, o segundo endereço caía no painel do
     * operador — que é o oposto do que se quer expor ao assinante.
     * Limpa cada item: tira "https://", barra final e caminho, para funcionar mesmo quando o
     * operador cola a URL inteira em vez do domínio. */
    /* NOME DA VARIÁVEL: $dom, e NUNCA $h.
     * $h é a função de escape definida no topo deste arquivo ($h = fn($v) => htmlspecialchars(...)).
     * Usá-la como variável de foreach a substitui por uma string, e todo "$h(...)" do HTML abaixo
     * passa a ser "chamada de função" com o nome do último domínio — derrubando a página inteira
     * com "Call to undefined function assinante.seudominio.com.br()". E só depois de SALVAR, que é
     * quando este bloco roda: o formulário abre normal e quebra ao confirmar. */
    $hostsCentral = [];
    foreach (preg_split('/[\s,;]+/', (string)($_POST['host'] ?? '')) as $dom) {
        $dom = strtolower(trim($dom));
        if ($dom === '') continue;
        $dom = preg_replace('#^https?://#', '', $dom);   // colaram a URL inteira
        $dom = explode('/', $dom, 2)[0];                 // tira qualquer caminho
        $dom = explode(':', $dom, 2)[0];                 // tira a porta
        if ($dom !== '' && !in_array($dom, $hostsCentral, true)) $hostsCentral[] = $dom;
    }
    // "host" continua gravado (compatibilidade com o que já lê esse campo); "hosts" é a lista.
    $hostCentral = implode(', ', $hostsCentral);
    // "" (vazio) = usar a CENTRAL PADRÃO do sistema (portal.php), ignorando pastas.
    if ($folder === '' || !isset($centraisDisp[$folder])) {
        @file_put_contents(WS_CENTRAL_CFG, json_encode(['folder' => '', 'index' => '', 'host' => $hostCentral, 'hosts' => $hostsCentral], JSON_UNESCAPED_UNICODE)); @chmod(WS_CENTRAL_CFG, 0640);
        $flash = 'Central PADRÃO do sistema (portal) aplicada.';
    } else {
        $idx = ltrim(preg_replace('#[^A-Za-z0-9_./-]#', '', $_POST['index'] ?? ''), '/');
        if ($idx === '' || !is_file(WS_CENTRAL_DIR . "/$folder/$idx")) $idx = $centraisDisp[$folder];
        @file_put_contents(WS_CENTRAL_CFG, json_encode(['folder' => $folder, 'index' => $idx, 'host' => $hostCentral, 'hosts' => $hostsCentral], JSON_UNESCAPED_UNICODE)); @chmod(WS_CENTRAL_CFG, 0640);
        $flash = 'Central aplicada: ' . $folder . '/' . $idx . '.';
    }
    if ($hostCentral !== '') $flash .= " Domínio configurado: $hostCentral (quem acessar esse endereço já cai direto na central).";
}
/* Recursos da Central por template (ligar/desligar): central_recursos.php. Só quem pode configurar o sistema. */
require_once __DIR__ . '/central_recursos.php';
if (($_POST['acao'] ?? '') === 'central_recursos') {
    if (function_exists('ws_pode_configurar') && !ws_pode_configurar()) { http_response_code(403); exit('Sem permissão.'); }
    $flash = ws_central_rec_salvar($_POST) ? 'Recursos da Central salvos. Vale já para os próximos acessos dos assinantes.' : 'Não foi possível gravar cache/central_recursos.json (verifique a permissão da pasta cache).';
}
$centralCfg = is_file(WS_CENTRAL_CFG) ? (json_decode(@file_get_contents(WS_CENTRAL_CFG), true) ?: []) : (is_dir(WS_CENTRAL_DIR . '/padrao') ? ['folder' => 'padrao', 'index' => 'index.html'] : []);
if (($centralCfg['folder'] ?? '') === 'Central_Wellnet' && !is_dir(WS_CENTRAL_DIR . '/Central_Wellnet') && is_dir(WS_CENTRAL_DIR . '/padrao')) $centralCfg['folder'] = 'padrao';
// Aparência do portal (título, logo, foto de fundo). Grava em cache/portal.json.
define('WS_PORTAL_CFG', WS_CACHE . '/portal.json');
$portalCfg = is_file(WS_PORTAL_CFG) ? (json_decode(@file_get_contents(WS_PORTAL_CFG), true) ?: []) : [];
if (empty($portalCfg['bgs']) && !empty($portalCfg['bg'])) $portalCfg['bgs'] = [$portalCfg['bg']];   // migra formato antigo
$portalCfg['bgs'] = array_values(array_filter($portalCfg['bgs'] ?? [], fn($p) => is_file(ws_caminho_fisico($p))));
if (($_POST['acao'] ?? '') === 'portal_bg') {
    ws_dir(WS_UP_SISTEMA);
    $portalCfg['titulo'] = trim($_POST['titulo'] ?? '') ?: 'ACESSE A CENTRAL';
    $portalCfg['mostrar_logo'] = isset($_POST['mostrar_logo']) ? 1 : 0;
    // Aceita VÁRIAS imagens (bg[]) — o portal escolhe uma aleatória a cada acesso.
    $F = $_FILES['bg'] ?? null; $add = 0;
    $erroBg = ''; $eBg = '';
    if ($F && is_array($F['name'])) {
        foreach ($F['name'] as $i => $orig) {
            if (($F['error'][$i] ?? 1) !== UPLOAD_ERR_OK) continue;
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg','jpeg','png','webp'], true) || $F['size'][$i] > 8*1024*1024) continue;
            $nome = 'portal-bg-' . date('YmdHis') . '-' . $i . '.' . $ext;
            // Motivo da falha vai para o aviso: fundo que nao sobe sem explicacao e o pior caso.
            if (ws_mover_upload($F['tmp_name'][$i], WS_UP_SISTEMA . '/' . $nome, $eBg)) { $portalCfg['bgs'][] = 'uploads/sistema/' . $nome; $add++; }
            elseif ($eBg !== '' && $erroBg === '') $erroBg = $eBg;
        }
    }
    unset($portalCfg['bg']);
    @file_put_contents(WS_PORTAL_CFG, json_encode($portalCfg, JSON_UNESCAPED_SLASHES)); @chmod(WS_PORTAL_CFG, 0640);
    $flash .= 'Aparência salva' . ($add ? " · $add imagem(ns) adicionada(s)" : '') . '.'
            . ($erroBg !== '' ? ' Falha ao gravar a imagem: ' . $erroBg : '');
}
if (isset($_GET['bg_del'])) {   // remove UMA imagem
    $alvo = 'uploads/sistema/' . basename($_GET['bg_del']);
    $portalCfg['bgs'] = array_values(array_filter($portalCfg['bgs'] ?? [], fn($p) => $p !== $alvo));
    @unlink(ws_caminho_fisico($alvo));
    @file_put_contents(WS_PORTAL_CFG, json_encode($portalCfg, JSON_UNESCAPED_SLASHES)); $flash = 'Imagem removida.';
}
if (($_POST['acao'] ?? '') === 'excluir_portal_bg_sel') {   // remove as MARCADAS (único/todas)
    foreach ((array)($_POST['bgs'] ?? []) as $n) {
        $alvo = 'uploads/sistema/' . basename((string)$n);
        $portalCfg['bgs'] = array_values(array_filter($portalCfg['bgs'] ?? [], fn($p) => $p !== $alvo));
        @unlink(ws_caminho_fisico($alvo));
    }
    @file_put_contents(WS_PORTAL_CFG, json_encode($portalCfg, JSON_UNESCAPED_SLASHES));
    header('Location: central.php'); exit;
}
$portalBgs = $portalCfg['bgs'] ?? [];

$arquivos = [];
foreach (glob(WS_UP_SISTEMA . '/*') ?: [] as $a) {
    if (!is_file($a)) continue;
    // NÃO lista aqui os arquivos que já têm seção própria (fundos do portal, fundos do login, logo dos
    // documentos) — assim o bloco "Arquivos enviados" fica INDEPENDENTE, sem duplicar o que aparece acima.
    $bn = basename($a);
    if (preg_match('/^(portal-bg-|login-bg-|doc-logo\.)/', $bn)) continue;
    $arquivos[] = $a;
}
usort($arquivos, fn($x, $y) => filemtime($y) <=> filemtime($x));
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Central</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('config') ?></header>
<main class="ws-main">
<?php if ($flash): ?><div class="ws-alert ok"><?= $h($flash) ?></div><?php endif; ?>

<div class="ws-head-row"><h2>🛰️ Central do assinante</h2></div>
<p class="ws-muted" style="margin:-4px 0 16px;max-width:820px">Aqui você configura o <b>portal que seus clientes acessam</b>. São 4 partes independentes: <b>(1)</b> Qual central fica no ar, <b>(2)</b> A aparência do portal, <b>(3)</b> Enviar modelos/imagens e <b>(4)</b> Gerenciar os arquivos enviados.</p>

<!-- 1) CENTRAL ATIVA -->
<div class="ws-panel" style="margin-bottom:16px">
  <div class="ws-head-row ws-tarja" style="margin:0 0 10px"><h3>1 · Central ativa <span class="ws-muted" style="font-weight:400;font-size:13px">— o que o cliente vê</span></h3></div>
  <p class="ws-muted" style="font-size:13px;margin-bottom:8px">Escolha <b>uma</b> central para ficar no ar. São dois tipos:</p>
  <ul class="ws-muted" style="font-size:13px;margin:0 0 10px;padding-left:18px;line-height:1.7">
    <li><b>★ Padrão do sistema (portal)</b> — a central que <b>já vem no código</b> do WellSystem. Você personaliza ela aqui mesmo na seção <b>2 · Aparência</b> (título, logo e fundos). É a <b>recomendada</b> — não precisa mexer em FTP.</li>
    <li><b>Central por FTP</b> (ex.: <code>Central_MeuProvedor</code>) — é um <b>site próprio em HTML</b> que você subiu por FTP dentro de <code>central_files/</code>. A opção <b>pega o nome da pasta</b> que você importou; cada pasta com um <code>index.htm/html</code> vira uma opção. Use quando quer um layout todo seu, feito por fora.</li>
  </ul>
  <p class="ws-muted" style="font-size:12.5px;margin:0 0 8px">👉 Sem um site próprio? Deixe no <b>Padrão do sistema</b>. O campo <b>Arquivo inicial</b> só vale para a central por FTP (qual arquivo abre primeiro). O <b>Domínio</b> é opcional.</p>
  <form method="post" enctype="multipart/form-data" class="ws-form grid" style="margin:0 0 14px">
    <input type="hidden" name="acao" value="central_upload">
    <label>Enviar uma central (arquivo .zip) <input type="file" name="central_zip" accept=".zip" required></label>
    <label>Nome da pasta (opcional) <input name="central_nome" placeholder="Central_MeuProvedor" maxlength="40"></label>
    <div class="c4"><button class="ws-btn">⬆ Enviar central</button> <span class="ws-muted" style="font-size:12px">O ZIP precisa ter o index.html na raiz. Depois de enviar, escolha a central abaixo e clique em Aplicar.</span></div>
  </form>
  <form method="post" class="ws-form grid">
    <input type="hidden" name="acao" value="central_apply">
    <label>Central ativa <select name="folder">
      <option value="" <?= (($centralCfg['folder']??'')==='')?'selected':'' ?>>★ Padrão do sistema (portal — recomendado)</option>
      <?php foreach ($centraisDisp as $folder => $idx): ?>
        <option value="<?= $h($folder) ?>" <?= (($centralCfg['folder']??'')===$folder)?'selected':'' ?>><?= $folder === 'padrao' ? 'Central clássica (modelo pronto)' : $h($folder) . ' (enviada)' ?></option>
      <?php endforeach; ?>
    </select></label>
    <label>Arquivo inicial <input name="index" value="<?= $h($centralCfg['index'] ?? 'index.html') ?>" placeholder="index.html ou pages/index.html"></label>
    <label class="c2">Domínio da central (opcional) <input name="host" value="<?= $h($centralCfg['host'] ?? '') ?>" placeholder="assinante.seuprovedor.com.br">
      <span class="ws-muted" style="font-size:11.5px;display:block;margin-top:3px">Se você aponta esse domínio pra mesma instalação do WellSystem, preencha aqui — assim, quem acessar direto esse endereço já cai na central, sem precisar digitar <code>central_pub.php</code> no final.</span></label>
    <div class="c4" style="display:flex;gap:8px"><button class="ws-btn verde">Aplicar central</button>
      <a class="ws-btn" href="central_pub.php" target="_blank">👁 Ver central atual</a></div>
  </form>
  <p class="ws-muted" style="font-size:12px;margin-top:6px">Ativa agora: <b><?= ($centralCfg['folder'] ?? '')==='' ? 'Padrão do sistema (portal)' : $h($centralCfg['folder']) ?></b> · URL pública: <code>central_pub.php</code><?= !empty($centralCfg['host']) ? ' · Domínio: <code>'.$h($centralCfg['host']).'</code>' : '' ?></p>
</div>

<!-- 2) APARÊNCIA DO PORTAL -->
<div class="ws-panel" style="margin-bottom:16px">
  <div class="ws-head-row ws-tarja" style="margin:0 0 10px"><h3>2 · Aparência do portal <span class="ws-muted" style="font-weight:400;font-size:13px">— título, logo e fundos</span></h3></div>
  <p class="ws-muted" style="font-size:13px">Vale para a <b>central padrão</b>. Suba <b>várias imagens de fundo</b> e o portal <b>sorteia uma a cada acesso</b>. Tudo é editável e pode ser trocado quando quiser.</p>
  <form method="post" enctype="multipart/form-data" class="ws-form grid" style="margin-top:8px">
    <input type="hidden" name="acao" value="portal_bg">
    <label class="c2">Título do portal <input name="titulo" value="<?= $h($portalCfg['titulo'] ?? 'ACESSE A CENTRAL') ?>" placeholder="ACESSE A CENTRAL"></label>
    <label class="c2">Adicionar fundos (várias) <input type="file" name="bg[]" accept=".jpg,.jpeg,.png,.webp" multiple></label>
    <label class="c4 ws-chk"><input type="checkbox" name="mostrar_logo" <?= !empty($portalCfg['mostrar_logo'])?'checked':'' ?>> Mostrar o logo no card (mesmo com foto de fundo)</label>
    <div class="c4"><button class="ws-btn verde">Salvar aparência</button> <a class="ws-btn" href="portal.php" target="_blank">👁 Ver portal</a></div>
  </form>
  <?php if ($portalBgs): ?>
  <form method="post" onsubmit="return wsPbgDel(this)">
    <input type="hidden" name="acao" value="excluir_portal_bg_sel">
    <label style="font-size:13px;display:flex;align-items:center;gap:6px;margin:14px 0 6px"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"> Marcar todos</label>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <?php foreach ($portalBgs as $b): ?>
        <label style="position:relative;display:block;cursor:pointer" title="Marcar para excluir">
          <input type="checkbox" class="ws-chk-item" name="bgs[]" value="<?= h(basename($b)) ?>" style="position:absolute;top:5px;left:5px;z-index:2">
          <img src="<?= $h(ws_img($b)) ?>" style="height:70px;border-radius:8px;border:1px solid var(--border);display:block">
        </label>
      <?php endforeach; ?>
    </div>
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <button class="ws-btn danger">🗑 Excluir selecionados</button>
      <span class="ws-muted" style="font-size:12px"><?= count($portalBgs) ?> fundo(s) — o portal sorteia um a cada acesso.</span>
    </div>
  </form>
  <script>function wsPbgDel(f){var n=f.querySelectorAll('.ws-chk-item:checked').length;if(!n){alert('Marque ao menos um fundo.');return false;}return confirm('Excluir '+n+' fundo(s) do portal?');}</script>
  <?php else: ?>
  <p class="ws-muted" style="font-size:12px;margin-top:10px">Nenhum fundo enviado ainda — o portal usa o fundo padrão.</p>
  <?php endif; ?>
</div>

<!-- 3) BIBLIOTECA DE ARQUIVOS -->
<div class="ws-panel" style="margin-bottom:16px">
  <div class="ws-head-row ws-tarja" style="margin:0 0 10px"><h3>3 · Biblioteca de arquivos <span class="ws-muted" style="font-weight:400;font-size:13px">— guardar arquivos no servidor (opcional)</span></h3></div>
  <p class="ws-muted" style="font-size:13px;margin-bottom:6px">Um espaço livre para <b>guardar arquivos no servidor</b> e ter à mão — uma imagem, um PDF, um aviso. Depois você pode <b>abrir ou baixar</b> cada um pela lista abaixo (seção 4).</p>
  <p class="ws-muted" style="font-size:12.5px;margin:0 0 10px;padding:8px 10px;background:rgba(2,132,199,.08);border-radius:8px">ℹ️ <b>Importante:</b> isto é só um repositório — <b>não</b> troca o logo, os fundos do portal/login nem os boletos. Logo e fundos ficam nas seções <b>1</b> e <b>2</b>; layout do carnê/boleto é automático no sistema.</p>
  <form method="post" enctype="multipart/form-data" class="ws-form grid">
    <input type="hidden" name="acao" value="upload">
    <label class="c2">Enviar arquivos <input type="file" name="arquivo[]" accept=".jpg,.jpeg,.png,.gif,.webp,.svg,.pdf" multiple onchange="if(this.files.length)this.form.submit()"></label>
    <label class="c2">Ou uma pasta inteira <input type="file" name="arquivo[]" webkitdirectory directory multiple onchange="if(this.files.length)this.form.submit()"></label>
    <div class="c4"><span class="ws-muted" style="font-size:12px">Formatos: <?= implode(', ', $permit) ?> · até 50 MB cada.</span> <button class="ws-btn verde" style="margin-left:8px">Enviar (ou já sobe ao escolher)</button></div>
  </form>
</div>

<!-- 4) ARQUIVOS GUARDADOS -->
<div class="ws-panel">
  <div class="ws-head-row ws-tarja" style="margin:0 0 6px"><h3>4 · Arquivos guardados (<?= count($arquivos) ?>)</h3>
    <?php if ($arquivos): ?><label style="font-size:13px;display:flex;align-items:center;gap:6px;color:#fff"><input type="checkbox" onclick="wsChkAll(this)" title="Marcar todos"> Marcar todos</label><?php endif; ?></div>
  <p class="ws-muted" style="font-size:13px;margin:0 0 10px">São os arquivos que você enviou na seção 3. <b>Clique</b> num arquivo para abrir/baixar; <b>marque</b> (único ou todos) e <b>exclua</b> os que não quiser mais. Fundos do portal/login e logo <b>não</b> aparecem aqui — têm suas próprias seções.</p>
<form method="post" onsubmit="return wsModelosDel(this)">
<input type="hidden" name="acao" value="excluir_modelos_sel">
<div class="ws-galeria">
<?php foreach ($arquivos as $a): $nome = basename($a); $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
  $url = function_exists('ws_img') ? ws_img('uploads/sistema/' . $nome) : 'uploads/sistema/' . rawurlencode($nome); $img = !in_array($ext, ['pdf', 'svg'], true); ?>
  <figure class="ws-galeria-item" style="position:relative">
    <label style="position:absolute;top:6px;left:6px;z-index:2;background:rgba(255,255,255,.92);border:1px solid var(--border);border-radius:5px;padding:2px 4px;line-height:0"><input type="checkbox" class="ws-chk-item" name="arqs[]" value="<?= $h($nome) ?>"></label>
    <?php if ($img): ?><a href="<?= $url ?>" target="_blank"><img src="<?= $url ?>" alt="<?= $h($nome) ?>"></a>
    <?php else: ?><a href="<?= $url ?>" target="_blank" class="ws-arq-icon"><?= strtoupper($ext) ?></a><?php endif; ?>
    <figcaption><span title="<?= $h($nome) ?>"><?= $h($nome) ?></span>
      <a href="central.php?del=<?= rawurlencode($nome) ?>" onclick="return confirm('Excluir este arquivo?')" style="color:var(--err)">excluir</a>
    </figcaption>
  </figure>
<?php endforeach; if (!$arquivos) echo '<p class="ws-muted">Nenhum modelo enviado ainda.</p>'; ?>
</div>
<?php if ($arquivos): ?><div style="margin-top:10px"><button class="ws-btn danger">🗑 Excluir selecionados</button></div><?php endif; ?>
</form>
</div><?php // fecha painel "4 · Arquivos enviados" ?>
<script>function wsModelosDel(f){var n=f.querySelectorAll('.ws-chk-item:checked').length;if(!n){alert('Marque ao menos um arquivo.');return false;}return confirm('Excluir '+n+' arquivo(s) selecionado(s)?');}</script>
<div class="ws-panel" style="margin-top:16px">
  <div class="ws-head-row ws-tarja" style="margin:0 0 10px"><h3>5 · Recursos da Central <span class="ws-muted" style="font-weight:400;font-size:13px">— o que o assinante pode fazer (vale para templates de central, ex.: Central_MeuProvedor)</span></h3></div>
  <p class="ws-muted" style="margin:0 0 12px">Desmarcou = a opção some do menu <b>e</b> o servidor recusa o acesso direto. Login, sessão e “só os dados do próprio cliente” ficam sempre protegidos. Para travar uma opção no código (o painel não muda), defina <code>WS_CENTRAL_REC_FORCE</code> no config.php.</p>
  <?= ws_central_rec_painel($h) ?>
</div>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>
