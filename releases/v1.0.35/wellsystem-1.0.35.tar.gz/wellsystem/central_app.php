<?php
/**
 * WellSystem — Central do assinante com TEMPLATE (ex.: Central_Wellnet), já LOGADA.
 *
 * O login é o da central padrão (portal.php: CPF/CNPJ + nascimento, sessão $_SESSION['ws_portal']).
 * Este arquivo serve TODAS as páginas do template ligadas aos dados reais do WellSystem:
 *   ?p=index|2_via|faturas|pay_pix|comprovante|servicos|relatorio|suporte|atualizar_dados|
 *      trocar_senha|foto|disco_virtual|downloads|fale_conosco
 *   ?a=<ação>  formulários e downloads (POST com _csrf; os GET só leem, e o desbloqueio leva token)
 * Regra de ouro: TODA consulta filtra por cliente_id da sessão — nada aqui aceita "id de outro cliente".
 * O motor de template (blocos/variáveis/links) está em central_template.php.
 */
require __DIR__ . '/config.php';

if (function_exists('ws_ativacao_exigida') && ws_ativacao_exigida() && !ws_ativado()) {
    http_response_code(503); header('Content-Type: text/html; charset=utf-8');
    exit('<!doctype html><meta charset="utf-8"><title>Indisponível</title><p style="font:15px system-ui;text-align:center;margin:18vh 20px">Central temporariamente indisponível. Procure o seu provedor.</p>');
}
require_once __DIR__ . '/radius_lib.php';
require_once __DIR__ . '/central_template.php';
require_once __DIR__ . '/central_recursos.php';
require_once __DIR__ . '/solicitacoes_lib.php';
require_once __DIR__ . '/anexos.php';
require_once __DIR__ . '/schema_endereco.php';

$tpl = ws_central_tpl_ativa();
if (!$tpl) { header('Location: portal.php'); exit; }                       // central padrão: nada a fazer aqui
if (!ws_central_rec('acesso')) {                                              // Central em manutenção: derruba a sessão e avisa no login
    unset($_SESSION['ws_portal'], $_SESSION['ws_central_csrf']); $_SESSION['ws_central_erro'] = 'Central em manutenção. Volte em instantes ou fale com o seu provedor.';
    header('Location: central_pub.php'); exit;
}
if (empty($_SESSION['ws_portal']['id'])) { header('Location: central_pub.php'); exit; }

$db  = ws_db();
$cid = (int)$_SESSION['ws_portal']['id'];
if (empty($_SESSION['ws_central_csrf'])) $_SESSION['ws_central_csrf'] = bin2hex(random_bytes(16));
$csrf = (string)$_SESSION['ws_central_csrf'];

$st = $db->prepare("SELECT * FROM ws_cliente WHERE id=? AND status<>'cancelado'");
$st->execute([$cid]); $row = $st->fetch(PDO::FETCH_ASSOC);
if (!$row) { unset($_SESSION['ws_portal']); header('Location: central_pub.php'); exit; }

$st = $db->prepare("SELECT ct.*, p.nome plano, p.valor plano_valor, p.down_kbps, p.up_kbps FROM ws_contrato ct
                    LEFT JOIN ws_plano p ON p.id=ct.plano_id WHERE ct.cliente_id=? AND ct.status<>'cancelado' ORDER BY ct.id");
$st->execute([$cid]); $cts = $st->fetchAll(PDO::FETCH_ASSOC);

$prov = [];
if (is_file(WS_CACHE . '/provedor.json')) { $j = json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true); if (is_array($j)) $prov = $j; }
$C = ['db' => $db, 'cid' => $cid, 'c' => $row, 'cts' => $cts, 'prov' => $prov, 'tpl' => $tpl, 'csrf' => $csrf];

/* ------------------------------------------------------------------ utilitários */
function ca_flash(string $tipo, string $msg): void { $_SESSION['ws_central_flash'] = [$tipo, $msg]; }
function ca_ir(string $destino): void { header('Location: ' . $destino); exit; }
function ca_bytes($b): string { $b = (float)$b; $u = ['B', 'KB', 'MB', 'GB', 'TB']; $i = 0; while ($b >= 1024 && $i < 4) { $b /= 1024; $i++; } return number_format($b, $i >= 2 ? 1 : 0, ',', '.') . ' ' . $u[$i]; }
function ca_data($d): string { $t = $d ? strtotime((string)$d) : 0; return $t ? date('d/m/Y', $t) : '—'; }
function ca_dinheiro($v): string { return number_format((float)$v, 2, ',', '.'); }
function ca_so_num($v): string { return preg_replace('/\D/', '', (string)$v); }
function ca_norm($v): string { return mb_strtolower(trim(preg_replace('/\s+/', ' ', (string)$v))); }
function ca_logins(array $cts): array { $o = []; foreach ($cts as $c) foreach (['login_pppoe', 'login_ipoe'] as $k) if (!empty($c[$k])) $o[$c[$k]] = 1; return array_keys($o); }
function ca_exigir_post(string $volta): void {
    $ok = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['_csrf']) && hash_equals((string)($_SESSION['ws_central_csrf'] ?? ''), (string)$_POST['_csrf']);
    if (!$ok) { ca_flash('err', 'Sessão expirada ou envio inválido. Tente de novo.'); ca_ir($volta); }
}
/** Fatura do cliente (nunca de outro) ou null. */
function ca_fatura(array $C, int $id): ?array {
    $s = $C['db']->prepare("SELECT * FROM ws_fatura WHERE id=? AND cliente_id=?"); $s->execute([$id, $C['cid']]);
    $f = $s->fetch(PDO::FETCH_ASSOC); return $f ?: null;
}
function ca_chamado(array $C, int $id): ?array {
    $s = $C['db']->prepare("SELECT * FROM ws_chamado WHERE id=? AND cliente_id=?"); $s->execute([$id, $C['cid']]);
    $f = $s->fetch(PDO::FETCH_ASSOC); return $f ?: null;
}
function ca_tipo_chamado(string $assunto): string {
    $a = ca_norm($assunto);
    if ($a === 'financeiro') return 'financeiro';
    if (in_array($a, ['cancelamento', 'transferencia', 'transferência', 'retirada de kit', 'cadastro'], true)) return 'outro';
    return 'suporte';
}
/** Logins do cliente na ordem do cadastro: login => ['ct' => contrato, 'tipo' => 'pppoe'|'ipoe']. O primeiro é o principal. */
function ca_logins_mapa(array $cts): array {
    $m = [];
    foreach ($cts as $ct) foreach (['pppoe' => 'login_pppoe', 'ipoe' => 'login_ipoe'] as $tipo => $col) {
        $l = trim((string)($ct[$col] ?? ''));
        if ($l !== '' && !isset($m[$l])) $m[$l] = ['ct' => $ct, 'tipo' => $tipo];
    }
    return $m;
}
/** Primeiro contrato que tem login desse tipo ('pppoe'|'ipoe'), com o login. */
function ca_login_do_tipo(array $cts, string $tipo): ?array {
    foreach (ca_logins_mapa($cts) as $l => $x) if ($x['tipo'] === $tipo) return ['login' => $l, 'ct' => $x['ct']];
    return null;
}
/** Situação de uma fatura para exibir: [texto, badge, ícone]. */
function ca_situacao(array $f): array {
    if (($f['status'] ?? '') === 'pago') return ['pago', 'success', 'check'];
    if (($f['status'] ?? '') === 'cancelado') return ['cancelado', 'info', 'ban'];
    return strtotime((string)$f['vencimento']) < strtotime('today') ? ['vencido', 'danger', 'exclamation-triangle'] : ['aberto', 'warning', 'clock-o'];
}
/** Faturas em aberto (a vencer + vencidas) do cliente. */
function ca_abertas(array $C, int $lim = 60): array {
    $s = $C['db']->prepare("SELECT * FROM ws_fatura WHERE cliente_id=? AND status IN('aberto','vencido','processando') ORDER BY vencimento LIMIT " . (int)$lim);
    $s->execute([$C['cid']]); return $s->fetchAll(PDO::FETCH_ASSOC);
}
/** URL da imagem do QR, ou '' quando não pode: o QR do gateway sempre vale; gerar por api.qrserver.com só com 'pix_qr_externo' ligado. */
function ca_qr(string $emv, string $qrUrl = ''): string {
    if ($qrUrl !== '' && preg_match('#^https://#i', $qrUrl)) return $qrUrl;
    return ws_central_rec('pix_qr_externo') ? 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=0&data=' . rawurlencode($emv) : '';
}
function ca_foto_arquivo(int $cid): string { $g = glob(WS_UPLOADS . '/central_fotos/' . $cid . '.*'); return ($g && is_file($g[0])) ? $g[0] : ''; }

/* ------------------------------------------------------------------ AÇÕES (?a=) */
$a = (string)($_GET['a'] ?? '');
if ($a !== '') {
    /* AUTORIZAÇÃO por recurso (central_recursos.php): ação => recurso exigido. Desligado = recusado aqui no servidor,
       mesmo que alguém digite o endereço ou envie o formulário à mão. */
    $exige = ['foto_img' => 'pg_foto', 'foto' => 'pg_foto', 'desbloquear' => 'desbloqueio', 'nota' => 'nfse', 'lgpd' => 'lgpd', 'busca_cep' => 'cep_busca',
              'down' => 'pg_downloads', 'baixar' => 'pg_disco', 'ins_chamado' => 'suporte_abrir', 'responder' => 'suporte_responder', 'contato' => 'pg_fale_conosco',
              'comprovante' => 'pg_comprovante', 'upload_disco' => 'disco_upload', 'delfiles' => 'disco_apagar', 'altsenha_princ' => 'pg_senha', 'altsenha_adic' => 'senha_adicionais',
              'altcliente' => 'pg_dados'];
    if (isset($exige[$a]) && !ws_central_rec($exige[$a])) {
        if (in_array($a, ['foto_img', 'busca_cep', 'down', 'baixar'], true)) { http_response_code(403); exit('Recurso indisponível.'); }
        ca_flash('err', 'Este recurso não está disponível no momento.'); ca_ir('central_app.php');
    }
    switch ($a) {
    case 'sair':
        unset($_SESSION['ws_portal'], $_SESSION['ws_central_csrf']); ca_ir('central_pub.php');

    case 'foto_img': {                                   // a própria foto (só o dono: a sessão decide)
        $f = ca_foto_arquivo($cid);
        if ($f === '') { http_response_code(404); exit; }
        $m = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][strtolower(pathinfo($f, PATHINFO_EXTENSION))] ?? 'application/octet-stream';
        header('Content-Type: ' . $m); header('Content-Length: ' . filesize($f)); header('Cache-Control: private, max-age=3600'); header('X-Content-Type-Options: nosniff');
        readfile($f); exit;
    }

    case 'desbloquear': {                                // libera em confiança (mesma regra do portal.php)
        if (!hash_equals($csrf, (string)($_GET['t'] ?? ''))) { ca_flash('err', 'Link expirado. Abra a Central de novo.'); ca_ir('central_app.php'); }
        $msg = 'Sua conexão não está bloqueada.'; $tipo = 'err';
        foreach ($cts as $ct) {
            if (ws_rad_em_confianca($ct)) { $msg = 'Sua conexão já está liberada em confiança.'; $tipo = 'ok'; continue; }
            if (!ws_rad_deve_bloquear($db, $ct)) continue;
            if (ws_central_confianca_no_ciclo($ct)) { $msg = 'Você já usou o desbloqueio de confiança neste ciclo. Um novo desbloqueio fica disponível em ' . date('d/m/Y', ws_central_confianca_proximo($ct)) . '. Regularize o pagamento.'; continue; }
            $dias = ws_central_param('confianca_dias');
            if (ws_rad_confiar($db, $ct, $dias)) { ws_evento($db, $cid, 'confianca', "Desbloqueio de confiança (self-service, $dias dias)"); $msg = "Conexão liberada por $dias dias! Regularize o pagamento para não ser bloqueado de novo."; $tipo = 'ok'; break; }
            $msg = ws_rad_confiar_aviso() ?: 'Não foi possível liberar agora. Fale com o suporte.';
        }
        ca_flash($tipo, $msg); ca_ir('central_app.php');
    }

    case 'nota': {                                       // NFS-e da fatura (só a do cliente, só autorizada)
        $f = ca_fatura($C, (int)($_GET['f'] ?? 0));
        $u = '';
        if ($f) { $s = $db->prepare("SELECT url_pdf FROM ws_nfse WHERE fatura_id=? AND cliente_id=? AND status='autorizada' AND url_pdf<>'' ORDER BY id DESC LIMIT 1"); $s->execute([$f['id'], $cid]); $u = (string)$s->fetchColumn(); }
        if ($u !== '' && preg_match('#^https?://#i', $u)) ca_ir($u);
        ca_flash('err', 'Nota fiscal ainda não disponível para esta fatura.'); ca_ir('central_app.php?p=faturas');
    }

    case 'lgpd': {                                       // cópia dos dados do próprio titular (LGPD)
        $end = ws_end_cliente($db, $cid);
        $d = ['cliente' => ['nome' => $row['nome'], 'cpf_cnpj' => $row['cpf_cnpj'], 'email' => $row['email'], 'celular' => $row['celular'], 'telefone' => $row['telefone'], 'nascimento' => $row['data_nasc'], 'endereco' => $end], 'contratos' => [], 'faturas' => []];
        foreach ($cts as $ct) $d['contratos'][] = ['plano' => $ct['plano'], 'login' => $ct['login_pppoe'], 'valor' => $ct['valor'], 'dia_vencimento' => $ct['dia_vencimento'], 'status' => $ct['status'], 'ativacao' => $ct['data_ativacao']];
        $s = $db->prepare("SELECT competencia,vencimento,valor,status,data_pagamento FROM ws_fatura WHERE cliente_id=? ORDER BY vencimento DESC LIMIT 500"); $s->execute([$cid]); $d['faturas'] = $s->fetchAll(PDO::FETCH_ASSOC);
        header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="meus-dados.json"');
        echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); exit;
    }

    case 'busca_cep': {                                  // preenche endereço pelo CEP (ViaCEP), só logado
        header('Content-Type: application/json; charset=utf-8');
        $cep = ca_so_num($_GET['cep'] ?? '');
        $r = null;
        if (strlen($cep) === 8 && function_exists('curl_init')) {
            $ch = curl_init('https://viacep.com.br/ws/' . $cep . '/json/'); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 4, CURLOPT_CONNECTTIMEOUT => 3]);
            $j = json_decode((string)curl_exec($ch), true); curl_close($ch);
            if (is_array($j) && empty($j['erro'])) $r = ['endereco' => $j['logradouro'] ?? '', 'bairro' => $j['bairro'] ?? '', 'complemento' => $j['complemento'] ?? '', 'cidade' => $j['localidade'] ?? '', 'estado' => $j['uf'] ?? ''];
        }
        echo json_encode($r ?: 'ERRO'); exit;
    }

    case 'down': case 'baixar': {                        // downloads do provedor / arquivos do cliente
        if ($a === 'baixar') {
            $s = $db->prepare("SELECT * FROM ws_anexo WHERE id=? AND cliente_id=?"); $s->execute([(int)($_GET['id'] ?? 0), $cid]); $x = $s->fetch(PDO::FETCH_ASSOC);
            $cam = $x ? WS_UPLOADS . '/' . $x['arquivo'] : ''; $nome = $x ? ($x['nome_original'] ?: basename($x['arquivo'])) : ''; $mime = $x['mime'] ?? '';
        } else {
            $b64 = strtr((string)($_GET['id'] ?? ''), '-_', '+/'); $rel = base64_decode($b64 . str_repeat('=', (4 - strlen($b64) % 4) % 4), true); $base = realpath(WS_UPLOADS . '/central_downloads');
            $real = ($rel !== false && $base) ? realpath($base . '/' . $rel) : false;
            $cam = ($real && strncmp($real, $base . DIRECTORY_SEPARATOR, strlen($base) + 1) === 0) ? $real : ''; $nome = $cam ? basename($cam) : ''; $mime = '';
        }
        if ($cam === '' || !is_file($cam)) { http_response_code(404); exit('Arquivo não encontrado.'); }
        header('Content-Type: ' . ($mime ?: 'application/octet-stream')); header('Content-Length: ' . filesize($cam));
        header('Content-Disposition: attachment; filename="' . rawurlencode($nome) . '"'); header('X-Content-Type-Options: nosniff');
        readfile($cam); exit;
    }

    case 'foto': {
        ca_exigir_post('central_app.php?p=foto');
        $f = $_FILES['arquivo'] ?? null;
        if (!$f || (int)($f['error'] ?? 1) !== UPLOAD_ERR_OK) { ca_flash('err', 'Escolha uma imagem.'); ca_ir('central_app.php?p=foto'); }
        $mime = function_exists('finfo_file') ? (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']) : '';
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? '';
        $mb = ws_central_param('foto_mb');
        if ($ext === '' || $f['size'] > $mb * 1048576) { ca_flash('err', "Use JPG, PNG ou WEBP de até $mb MB."); ca_ir('central_app.php?p=foto'); }
        $dir = WS_UPLOADS . '/central_fotos'; if (!is_dir($dir)) @mkdir($dir, 0775, true);
        foreach (glob($dir . '/' . $cid . '.*') ?: [] as $velha) @unlink($velha);
        $err = ''; if (!ws_mover_upload($f['tmp_name'], $dir . '/' . $cid . '.' . $ext, $err)) { ca_flash('err', 'Não foi possível gravar a foto.'); ca_ir('central_app.php?p=foto'); }
        ca_flash('ok', 'Foto atualizada.'); ca_ir('central_app.php?p=foto');
    }

    case 'ins_chamado': {
        ca_exigir_post('central_app.php?p=suporte');
        $ass = trim((string)($_POST['assunto'] ?? '')); $msg = trim((string)($_POST['msg'] ?? ''));
        if ($ass === '' || $msg === '') { ca_flash('err', 'Preencha o assunto e a mensagem.'); ca_ir('central_app.php?p=suporte&page=ins_chamado'); }
        $ctid = $cts ? (int)$cts[0]['id'] : null;
        $db->prepare("INSERT INTO ws_chamado (cliente_id,contrato_id,tipo,titulo,descricao,prioridade,status) VALUES (?,?,?,?,?,'normal','aberto')")
           ->execute([$cid, $ctid, ca_tipo_chamado($ass), mb_substr($ass, 0, 160), mb_substr($msg, 0, 5000)]);
        $novo = (int)$db->lastInsertId();
        ws_evento($db, $cid, 'chamado', 'Chamado aberto pelo cliente: ' . mb_substr($ass, 0, 120));
        ca_flash('ok', 'Chamado ' . $novo . ' aberto! Nossa equipe vai te retornar.'); ca_ir('central_app.php?p=suporte&page=mensagens&chamado=' . $novo);
    }

    case 'responder': {
        $ch = (int)($_POST['chamado'] ?? 0);
        ca_exigir_post('central_app.php?p=suporte&page=mensagens&chamado=' . $ch);
        $c = ca_chamado($C, $ch); $msg = trim((string)($_POST['msg'] ?? ''));
        if (!$c || $msg === '') { ca_flash('err', 'Escreva a mensagem.'); ca_ir('central_app.php?p=suporte'); }
        if ($c['status'] === 'cancelado') { ca_flash('err', 'Este chamado foi cancelado. Abra um novo.'); ca_ir('central_app.php?p=suporte'); }
        $db->prepare("INSERT INTO ws_chamado_msg (chamado_id,autor_tipo,mensagem) VALUES (?, 'cliente', ?)")->execute([$ch, mb_substr($msg, 0, 5000)]);
        if ($c['status'] === 'resolvido') $db->prepare("UPDATE ws_chamado SET status='aberto', fechado_em=NULL WHERE id=?")->execute([$ch]);
        else $db->prepare("UPDATE ws_chamado SET atualizado_em=NOW() WHERE id=?")->execute([$ch]);
        ws_evento($db, $cid, 'chamado', 'Cliente respondeu o chamado #' . $ch);
        ca_flash('ok', 'Mensagem enviada.'); ca_ir('central_app.php?p=suporte&page=mensagens&chamado=' . $ch);
    }

    case 'contato': {
        ca_exigir_post('central_app.php?p=fale_conosco');
        $ass = trim((string)($_POST['assunto'] ?? 'Outros')); $msg = trim((string)($_POST['msg'] ?? ''));
        if ($msg === '') { ca_flash('err', 'Escreva a mensagem.'); ca_ir('central_app.php?p=fale_conosco'); }
        $ctid = $cts ? (int)$cts[0]['id'] : null;
        $db->prepare("INSERT INTO ws_chamado (cliente_id,contrato_id,tipo,titulo,descricao,prioridade,status) VALUES (?,?,?,?,?,'normal','aberto')")
           ->execute([$cid, $ctid, ca_tipo_chamado($ass), 'Fale conosco: ' . mb_substr($ass, 0, 120), mb_substr($msg, 0, 5000)]);
        if (!empty($_FILES['arquivo']['tmp_name']) && (int)($_FILES['arquivo']['error'] ?? 1) === UPLOAD_ERR_OK) { try { ws_anexo_salvar($db, $cid, $ctid, 'outro', $_FILES['arquivo']); } catch (Throwable $e) {} }
        ws_evento($db, $cid, 'chamado', 'Mensagem enviada pela Central (Fale conosco): ' . mb_substr($ass, 0, 100));
        ca_flash('ok', 'Mensagem enviada! Vamos te responder em breve.'); ca_ir('central_app.php?p=fale_conosco');
    }

    case 'comprovante': {
        ca_exigir_post('central_app.php?p=comprovante');
        $f = ca_fatura($C, (int)($_POST['txt_titulo'] ?? 0)); $up = $_FILES['txt_arquivo'] ?? null;
        if (!$f || $f['status'] === 'pago') { ca_flash('err', 'Fatura inválida.'); ca_ir('central_app.php?p=comprovante'); }
        if (!$up || (int)($up['error'] ?? 1) !== UPLOAD_ERR_OK || $up['size'] > WS_ANEXO_MAX) { ca_flash('err', 'Envie o comprovante (JPG, PNG, WEBP ou PDF, até 8 MB).'); ca_ir('central_app.php?p=comprovante&page=confirmar&uuid=' . (int)$f['id']); }
        $mime = function_exists('finfo_file') ? (new finfo(FILEINFO_MIME_TYPE))->file($up['tmp_name']) : '';
        if (!isset(WS_ANEXO_MIMES[$mime])) { ca_flash('err', 'Tipo não permitido. Use JPG, PNG, WEBP ou PDF.'); ca_ir('central_app.php?p=comprovante&page=confirmar&uuid=' . (int)$f['id']); }
        require_once __DIR__ . '/comprovantes_lib.php';
        try { $db->exec(ws_comp_sql()); } catch (Throwable $e) {}
        $sub = date('Y-m'); $dir = ws_comp_dir() . '/' . $sub; if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $arq = $sub . '/c' . $cid . '_' . bin2hex(random_bytes(8)) . '.' . WS_ANEXO_MIMES[$mime];
        $err = ''; if (!ws_mover_upload($up['tmp_name'], ws_comp_dir() . '/' . $arq, $err)) { ca_flash('err', 'Não foi possível gravar o arquivo agora.'); ca_ir('central_app.php?p=comprovante'); }
        $obs = mb_substr('Central — fatura #' . $f['id'] . ' (venc. ' . ca_data($f['vencimento']) . ')' . (trim((string)($_POST['txt_msg'] ?? '')) !== '' ? ': ' . trim((string)$_POST['txt_msg']) : ''), 0, 255);
        $arqs = [0 => ['arquivo' => $arq, 'mime' => $mime, 'nome' => mb_substr((string)$up['name'], 0, 120), 'tam' => (int)$up['size'], 'sha1' => sha1_file(ws_comp_dir() . '/' . $arq)]];
        $db->prepare("INSERT INTO ws_comprovante (telefone,nome_informado,cpf,cliente_id,mensagens,arquivos,baixado,obs) VALUES (?,?,?,?,?,?, 'ok', ?)")
           ->execute([ca_so_num($row['celular']) ?: null, mb_substr((string)$row['nome'], 0, 160), ca_so_num($row['cpf_cnpj']) ?: null, $cid,
                      json_encode([['tipo' => 'upload', 'id' => 'central']]), json_encode($arqs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $obs]);
        ws_evento($db, $cid, 'fatura', 'Cliente enviou comprovante pela Central (fatura #' . $f['id'] . ')');
        ca_flash('ok', 'Comprovante enviado! Vamos conferir e dar baixa.'); ca_ir('central_app.php?p=comprovante');
    }

    case 'upload_disco': {
        ca_exigir_post('central_app.php?p=disco_virtual');
        $s = $db->prepare("SELECT COALESCE(SUM(tamanho),0) FROM ws_anexo WHERE cliente_id=?"); $s->execute([$cid]); $usado = (int)$s->fetchColumn();
        $up = $_FILES['file'] ?? null;
        if (!$up || (int)($up['error'] ?? 1) !== UPLOAD_ERR_OK) { ca_flash('err', 'Escolha um arquivo.'); ca_ir('central_app.php?p=disco_virtual&page=upload'); }
        $cota = ws_central_param('disco_mb');
        if ($usado + (int)$up['size'] > $cota * 1048576) { ca_flash('err', "Espaço do disco virtual esgotado ($cota MB)."); ca_ir('central_app.php?p=disco_virtual'); }
        $r = ws_anexo_salvar($db, $cid, null, 'outro', $up);
        ca_flash($r['ok'] ? 'ok' : 'err', $r['ok'] ? 'Arquivo enviado.' : (string)$r['erro']); ca_ir('central_app.php?p=disco_virtual');
    }

    case 'delfiles': {                                   // só apaga o que é do cliente (tipo "outro"); contrato/documentos do provedor ficam
        ca_exigir_post('central_app.php?p=disco_virtual');
        $n = 0;
        foreach ((array)($_POST['v_file'] ?? []) as $id) {
            $s = $db->prepare("SELECT id FROM ws_anexo WHERE id=? AND cliente_id=? AND tipo='outro'"); $s->execute([(int)$id, $cid]);
            if ($s->fetchColumn()) { ws_anexo_excluir($db, (int)$id); $n++; }
        }
        ca_flash($n ? 'ok' : 'err', $n ? "$n arquivo(s) removido(s)." : 'Nada removido (arquivos do provedor não podem ser apagados por aqui).'); ca_ir('central_app.php?p=disco_virtual');
    }

    case 'altsenha_princ': case 'altsenha_adic': {       // PEDIDO de nova senha da conexão (PPPoE/IPoE): só vale depois da validação da equipe
        ca_exigir_post('central_app.php?p=trocar_senha');
        $login = (string)($_POST['login'] ?? ''); $n1 = (string)($_POST['senha'] ?? ''); $n2 = (string)($_POST['senha2'] ?? '');
        $mapa = ca_logins_mapa($cts); $alvo = $mapa[$login] ?? null; $chaves = array_keys($mapa);
        if (!$alvo || ($login !== ($chaves[0] ?? '') && !ws_central_rec('senha_adicionais'))) { ca_flash('err', 'Usuário inválido.'); ca_ir('central_app.php?p=trocar_senha'); }
        $volta = 'central_app.php?p=trocar_senha&page=senha&tipo_login=' . substr($a, 9) . '&login=' . rawurlencode($login);
        if ($n1 !== $n2) { ca_flash('err', 'As senhas não conferem.'); ca_ir($volta); }
        $smin = ws_central_param('senha_min');
        if (strlen($n1) < $smin || strlen($n1) > 64) { ca_flash('err', "A senha precisa ter de $smin a 64 caracteres."); ca_ir($volta); }
        $cif = ws_sol_cifrar($n1);                                                   // nunca fica em texto puro na fila
        if ($cif === '') { ca_flash('err', 'Não foi possível registrar o pedido com segurança agora. Fale com o suporte.'); ca_ir($volta); }
        try {
            ws_sol_criar($db, $cid, (int)$alvo['ct']['id'], $alvo['tipo'] === 'ipoe' ? 'senha_ipoe' : 'senha_pppoe', ['senha' => ['de' => '', 'para' => '']], $cif, 'Login: ' . $login);
        } catch (Throwable $e) { ca_flash('err', 'Não foi possível registrar o pedido agora. Tente de novo em instantes.'); ca_ir($volta); }
        ca_flash('ok', 'Pedido enviado! A nova senha será aplicada assim que a nossa equipe validar. Você vê o resultado aqui na Central.'); ca_ir('central_app.php?p=trocar_senha');
    }

    case 'altcliente': {                                 // PEDIDOS de alteração: nada é gravado no cadastro sem a validação da equipe
        ca_exigir_post('central_app.php?p=atualizar_dados');
        $volta = 'central_app.php?p=atualizar_dados';
        $recContato = ws_central_rec('dados_contato'); $recCadastro = ws_central_rec('dados_cadastro'); $recLogin = ws_central_rec('login_trocar');
        if (!$recContato && !$recCadastro && !$recLogin) { ca_flash('err', 'A alteração de dados está desativada.'); ca_ir($volta); }
        $end = ws_end_cliente($db, $cid);
        $post = function (string $k): string { return trim((string)($_POST[$k] ?? '')); };
        /** Só entra no pedido o que MUDOU (campo em branco = "não mexi"). $num: compara só dígitos. */
        $diff = function (array $mapa) use ($post): array {
            $o = [];
            foreach ($mapa as $campo => [$de, $novo, $num]) {
                $novo = trim((string)$novo); if ($novo === '') continue;
                $igual = $num ? ca_so_num($de) === ca_so_num($novo) : ca_norm($de) === ca_norm($novo);
                if (!$igual) $o[$campo] = ['de' => mb_substr((string)$de, 0, 120), 'para' => mb_substr($novo, 0, 120)];
            }
            return $o;
        };
        $erro = function (string $m) use ($volta) { ca_flash('err', $m); ca_ir($volta); };
        $pedidos = 0; $aplicadoNaHora = false;
        try {
            // 1) contato
            if ($recContato) {
                $c = $diff(['email' => [$row['email'], $post('email'), 0], 'celular' => [$row['celular'], ca_so_num($post('celular')), 1], 'telefone' => [$row['telefone'], ca_so_num($post('telefone')), 1]]);
                if (isset($c['email']) && !filter_var($c['email']['para'], FILTER_VALIDATE_EMAIL)) $erro('E-mail inválido.');
                foreach (['celular', 'telefone'] as $k) if (isset($c[$k]) && (strlen($c[$k]['para']) < 10 || strlen($c[$k]['para']) > 11)) $erro('Celular/telefone inválido (use DDD + número).');
                if ($c && ws_central_rec('dados_contato_direto')) {                       // opção do provedor: contato sem validação
                    $n = ['email' => $row['email'], 'celular' => $row['celular'], 'telefone' => $row['telefone']];
                    foreach ($c as $k => $v) $n[$k] = $v['para'];
                    $db->prepare("UPDATE ws_cliente SET email=?, celular=?, telefone=? WHERE id=?")->execute([$n['email'] ?: null, $n['celular'], $n['telefone'] ?: null, $cid]);
                    ws_evento($db, $cid, 'cadastro', 'Cliente atualizou contato pela Central (sem validação, por opção do provedor).'); $aplicadoNaHora = true;
                } elseif ($c) { ws_sol_criar($db, $cid, null, 'contato', $c); $pedidos++; }
            }
            // 2) titularidade e 3) endereço
            if ($recCadastro) {
                $nasc = $post('nascimento'); $nascIso = '';
                if ($nasc !== '') { if (!preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $nasc, $m) || !checkdate((int)$m[2], (int)$m[1], (int)$m[3])) $erro('Data de nascimento inválida (use dd/mm/aaaa).'); $nascIso = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]); }
                $t = $diff(['nome' => [$row['nome'], $post('nome'), 0], 'data_nasc' => [(string)$row['data_nasc'], $nascIso, 0], 'rg_ie' => [$row['rg_ie'], $post('rg'), 0], 'cpf_cnpj' => [$row['cpf_cnpj'], $post('cpf_cnpj'), 1]]);
                if (isset($t['cpf_cnpj']) && !in_array(strlen(ca_so_num($t['cpf_cnpj']['para'])), [11, 14], true)) $erro('CPF/CNPJ inválido.');
                if ($t) { ws_sol_criar($db, $cid, null, 'titularidade', $t); $pedidos++; }
                $en = $diff(['cep' => [$end['cep'], $post('cep_res'), 1], 'logradouro' => [$end['logradouro'], $post('endereco_res'), 0], 'numero' => [$end['numero'], $post('numero_res'), 0], 'complemento' => [$end['complemento'], $post('complemento_res'), 0],
                             'bairro' => [$end['bairro'], $post('bairro_res'), 0], 'cidade' => [$end['cidade'], $post('cidade_res'), 0], 'uf' => [$end['uf'], mb_strtoupper($post('estado_res')), 0]]);
                if (isset($en['uf']) && !preg_match('/^[A-Z]{2}$/', $en['uf']['para'])) $erro('UF inválida.');
                if ($en) { ws_sol_criar($db, $cid, null, 'endereco', $en); $pedidos++; }
                // endereço de cobrança (cob_*): pedido próprio, não mexe no de instalação
                $ec = $diff(['cep' => [(string)($row['cob_cep'] ?? ''), $post('cep'), 1], 'logradouro' => [(string)($row['cob_logradouro'] ?? ''), $post('endereco'), 0], 'numero' => [(string)($row['cob_numero'] ?? ''), $post('numero'), 0],
                              'complemento' => [(string)($row['cob_complemento'] ?? ''), $post('complemento'), 0], 'bairro' => [(string)($row['cob_bairro'] ?? ''), $post('bairro'), 0],
                              'cidade' => [(string)($row['cob_cidade'] ?? ''), $post('cidade'), 0], 'uf' => [(string)($row['cob_uf'] ?? ''), mb_strtoupper($post('estado')), 0]]);
                if (isset($ec['uf']) && !preg_match('/^[A-Z]{2}$/', $ec['uf']['para'])) $erro('UF inválida.');
                if ($ec) { ws_sol_criar($db, $cid, null, 'endereco_cobranca', $ec); $pedidos++; }
            }
            // 4) login PPPoE / IPoE
            if ($recLogin) foreach (['pppoe' => 'login', 'ipoe' => 'login_ipoe'] as $tipo => $campo) {
                $atual = ca_login_do_tipo($cts, $tipo); $novo = $post($campo);
                if (!$atual || $novo === '' || $novo === $atual['login']) continue;
                if (!ws_sol_login_valido($novo)) $erro('Login inválido: use de 3 a 60 letras, números, ponto, traço, _ ou @.');
                if (ws_sol_login_em_uso($db, $novo, (int)$atual['ct']['id'])) $erro('Este login já está em uso. Escolha outro.');
                ws_sol_criar($db, $cid, (int)$atual['ct']['id'], $tipo === 'ipoe' ? 'login_ipoe' : 'login_pppoe', ['login' => ['de' => $atual['login'], 'para' => $novo]], '', 'Contrato #' . $atual['ct']['id']);
                $pedidos++;
            }
        } catch (Throwable $e) { $erro('Não foi possível registrar o pedido agora. Tente de novo em instantes.'); }
        if ($pedidos) ca_flash('ok', ($aplicadoNaHora ? 'Contato atualizado. ' : '') . 'Pedido enviado! As alterações serão aplicadas automaticamente assim que a nossa equipe validar.');
        else          ca_flash($aplicadoNaHora ? 'ok' : 'err', $aplicadoNaHora ? 'Contato atualizado.' : 'Nenhuma alteração para enviar.');
        ca_ir($volta);
    }
    }
    http_response_code(404); exit('Ação inválida.');
}

/* ------------------------------------------------------------------ TELAS (?p=) */
$p = (string)($_GET['p'] ?? 'index');
if (!in_array($p, ['index', '2_via', 'faturas', 'pay_pix', 'comprovante', 'servicos', 'relatorio', 'suporte', 'atualizar_dados', 'trocar_senha', 'foto', 'disco_virtual', 'downloads', 'fale_conosco'], true)) $p = 'index';
$page = (string)($_GET['page'] ?? '');

/* AUTORIZAÇÃO por recurso (central_recursos.php): tela => recurso exigido. Desligado = some do menu (abaixo) E a URL é recusada. */
$telaRec = ['2_via' => 'pg_2via', 'faturas' => 'pg_faturas', 'comprovante' => 'pg_comprovante', 'servicos' => 'pg_servicos', 'relatorio' => 'pg_relatorio', 'suporte' => 'pg_suporte',
            'atualizar_dados' => 'pg_dados', 'trocar_senha' => 'pg_senha', 'foto' => 'pg_foto', 'disco_virtual' => 'pg_disco', 'downloads' => 'pg_downloads', 'fale_conosco' => 'pg_fale_conosco'];
if ($p === 'pay_pix' ? !ws_central_rec('pix') : (isset($telaRec[$p]) && !ws_central_rec($telaRec[$p]))) { ca_flash('err', 'Este recurso não está disponível no momento.'); ca_ir('central_app.php'); }
$ocultar = [];
foreach ($telaRec as $tela => $rec) if (!ws_central_rec($rec)) $ocultar[] = 'page:' . $tela;
if (!ws_central_rec('avisos_sino')) $ocultar[] = 'sino';

/* Comum a todas: nome, foto, avisos do sino, menus, redes sociais. */
$abertas = ca_abertas($C);
$hoje = strtotime('today'); $nVenc = 0; $nProx = 0;
foreach ($abertas as $f) { $t = strtotime($f['vencimento']); if ($t < $hoje) $nVenc++; elseif ($t <= $hoje + 3 * 86400) $nProx++; }
$bloqueado = false;
foreach ($cts as $ct) if (!ws_rad_em_confianca($ct) && ws_rad_deve_bloquear($db, $ct)) $bloqueado = true;
$avisos = [];
if ($bloqueado) $avisos[] = ['CLIENTE_AVISO_MSG' => ws_central_rec('desbloqueio') ? 'Sua conexão está bloqueada. Regularize ou libere em confiança.' : 'Sua conexão está bloqueada. Regularize o pagamento.', 'CLIENTE_AVISO_LINK' => 'central_app.php?p=index'];
if ($nVenc)     $avisos[] = ['CLIENTE_AVISO_MSG' => "Você tem $nVenc fatura(s) vencida(s).", 'CLIENTE_AVISO_LINK' => 'central_app.php?p=2_via'];
$sol = ws_sol_do_cliente($db, $cid);
if ($sol['pendentes']) $avisos[] = ['CLIENTE_AVISO_MSG' => 'Você tem ' . $sol['pendentes'] . ' pedido(s) aguardando validação da nossa equipe.', 'CLIENTE_AVISO_LINK' => 'central_app.php?p=atualizar_dados'];
foreach ($sol['decididas'] as $dec) $avisos[] = ['CLIENTE_AVISO_MSG' => ws_sol_rotulo($dec['tipo']) . ': ' . ($dec['status'] === 'aprovada' ? 'aprovado e já aplicado.' : ($dec['status'] === 'recusada' ? 'recusado' . ($dec['motivo'] ? ' — ' . $dec['motivo'] : '') . '.' : 'não foi possível aplicar; fale com o suporte.')), 'CLIENTE_AVISO_LINK' => 'central_app.php?p=index'];
if ($nProx)     $avisos[] = ['CLIENTE_AVISO_MSG' => "$nProx fatura(s) vence(m) nos próximos 3 dias.", 'CLIENTE_AVISO_LINK' => 'central_app.php?p=2_via'];

if (!ws_central_rec('avisos_sino')) $avisos = [];
$nomes = preg_split('/\s+/', trim((string)$row['nome']));
$pnome = (function_exists('ws_provedor_nome_curto') ? ws_provedor_nome_curto() : (($prov['fantasia'] ?? '') ?: ($prov['razao'] ?? 'Provedor')));
$waNum = ca_so_num($prov['whatsapp'] ?? $prov['telefone'] ?? ''); if ($waNum !== '' && strlen($waNum) <= 11) $waNum = '55' . $waNum;
$temLogin = (bool)ca_logins_mapa($cts);
$fone = ca_so_num($row['celular'] ?: $row['telefone']);
$vars = [
    'CLIENTE_NOME' => (string)$row['nome'], 'CLIENTE_NOME_RES' => implode(' ', array_slice($nomes, 0, 2)), 'CLIENTE_EMAIL' => (string)$row['email'],
    'CLIENTE_LOGIN' => (string)(ca_login_do_tipo($cts, 'pppoe')['login'] ?? ''), 'CLIENTE_LOGIN_IPOE' => (string)(ca_login_do_tipo($cts, 'ipoe')['login'] ?? ''), 'CLIENTE_FONE' => $fone, 'TOTAL_AVISOS' => count($avisos),
    'WHATSAPP' => $waNum, 'INSTAGRAM' => (string)($prov['instagram'] ?? ''), 'FACEBOOK' => (string)($prov['facebook'] ?? ''), 'YOUTUBE' => '', 'TIKTOK' => '',
    'TWITTER' => '', 'LINKEDIN' => '', 'TELEGRAM' => '', 'SKYPE' => '', 'KWAI' => '', 'CLIENTE_CONTA_CARTAO' => '',
];
if (!ws_central_rec('redes_sociais')) foreach (['WHATSAPP', 'INSTAGRAM', 'FACEBOOK'] as $k) $vars[$k] = '';   // vazio: o JS do template remove o botão
$blocos = ['DADOSAVISOS' => $avisos, 'MENUSENHA' => $temLogin && ws_central_rec('pg_senha'), 'MENU2VIA' => ws_central_rec('pg_2via'), 'MENUDISCO' => ws_central_rec('pg_disco'),
           'MENUCHAMADOS' => ws_central_rec('pg_suporte'), 'MENUFALE' => ws_central_rec('pg_fale_conosco'),
           'CLIENTECARTAOTH' => false, 'CLIENTECARTAOTR' => false, 'WEBCAM1' => false, 'WEBCAM2' => false];

$logoRel = function_exists('ws_brand_logo_arquivo') ? ws_brand_logo_arquivo() : '';
if ($logoRel === '' && function_exists('ws_brand_logo_padrao')) $logoRel = ws_brand_logo_padrao();
$logo = ($logoRel !== '' && is_file(ws_caminho_fisico($logoRel))) ? ws_img($logoRel . '?v=' . @filemtime(ws_caminho_fisico($logoRel))) : '';
$fotoArq = ws_central_rec('pg_foto') ? ca_foto_arquivo($cid) : '';
$foto = $fotoArq !== '' ? 'central_app.php?a=foto_img&v=' . @filemtime($fotoArq) : $tpl['urlBase'] . '/images/100x100.png';

$flash = $_SESSION['ws_central_flash'] ?? null; unset($_SESSION['ws_central_flash']);
$opc = ['csrf' => $csrf, 'flash' => $flash, 'logo' => $logo, 'foto' => $foto, 'prov' => $pnome];
$logins = ca_logins($cts);

/** Sessões (radacct) dos logins do cliente: [linhas formatadas, tem_mais]. */
$sessoes = function (int $lim, int $off) use ($db, $logins): array {
    if (!$logins) return [[], false];
    try {
        $in = implode(',', array_fill(0, count($logins), '?'));
        $q = $db->prepare("SELECT username,acctstarttime,acctstoptime,acctinputoctets,acctoutputoctets FROM radacct WHERE username IN ($in) ORDER BY acctstarttime DESC LIMIT " . ($lim + 1) . ' OFFSET ' . (int)$off);
        $q->execute($logins); $r = $q->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return [[], false]; }
    $mais = count($r) > $lim; $r = array_slice($r, 0, $lim); $out = [];
    foreach ($r as $s) {
        $ini = strtotime((string)$s['acctstarttime']); $fim = $s['acctstoptime'] ? strtotime((string)$s['acctstoptime']) : time(); $d = max(0, $fim - $ini);
        $out[] = ['REL_USERNAME' => $s['username'], 'REL_DATA' => $ini ? date('d/m/Y H:i', $ini) : '—', 'REL_DURACAO' => sprintf('%02d:%02d:%02d', intdiv($d, 3600), intdiv($d % 3600, 60), $d % 60),
                  'REL_TRAFEGO' => ca_bytes((float)$s['acctinputoctets'] + (float)$s['acctoutputoctets']) . ($s['acctstoptime'] ? '' : ' (online)')];
    }
    return [$out, $mais];
};

switch ($p) {

case 'index': {
    $tot = 0.0;
    if ($logins) { try { $in = implode(',', array_fill(0, count($logins), '?')); $q = $db->prepare("SELECT COALESCE(SUM(acctinputoctets+acctoutputoctets),0) FROM radacct WHERE username IN ($in) AND acctstarttime >= ?"); $q->execute(array_merge($logins, [date('Y-m-01 00:00:00')])); $tot = (float)$q->fetchColumn(); } catch (Throwable $e) {} }
    $q = $db->prepare("SELECT * FROM ws_fatura WHERE cliente_id=? AND status<>'cancelado' ORDER BY vencimento DESC LIMIT 5"); $q->execute([$cid]);
    $fat = [];
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $f) { [$txt, $bad, $ico] = ca_situacao($f); $fat[] = ['FATURA_UUID' => $f['id'], 'FATURA_VALOR' => ca_dinheiro(ws_fatura_valor_cobrado($f)), 'FATURA_VENCIMENTO' => ca_data($f['vencimento']), 'FATURA_STATUS' => $txt, 'FATURA_BADGE' => $bad, 'FATURA_ICONE' => $ico]; }
    [$rel] = $sessoes(5, 0);
    $q = $db->prepare("SELECT COUNT(*) FROM ws_chamado WHERE cliente_id=? AND status IN('aberto','em_andamento','agendado')"); $q->execute([$cid]); $nCh = (int)$q->fetchColumn();
    $pcfg = is_file(WS_CACHE . '/portal.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/portal.json'), true) ?: []) : [];
    $meus = (ws_central_rec('aviso_provedor') && trim((string)($pcfg['aviso'] ?? '')) !== '') ? [['MY_AVISO' => (string)$pcfg['aviso'], 'MY_NAMEAVISO' => 'aviso1']] : [];
    $vars += ['TOTAL_TRAFEGO' => ca_bytes($tot), 'TOTAL_TITULOS' => count($abertas), 'TOTAL_CHAMADOS' => $nCh];
    $blocos += ['LIBERAR' => $bloqueado && ws_central_rec('desbloqueio'), 'FATURAS' => true, 'DADOSFATURAS' => $fat, 'REL' => true, 'DADOSREL' => $rel, 'MYAVISOS' => (bool)$meus, 'DADOSMYAVISOS' => $meus, 'ZEROMYAVISOS' => !$meus];
    break;
}

case '2_via': {
    $fat = []; $ids = [];
    foreach ($abertas as $f) {
        $pix = !ws_central_rec('pix') ? '' : (trim((string)$f['pix_emv']) !== ''
            ? '<a href="central_app.php?p=pay_pix&f=' . (int)$f['id'] . '" title="Pagar com PIX"><i class="fa fa-qrcode"></i></a>'
            : '<a href="boleto.php?fatura=' . (int)$f['id'] . '" target="_blank" title="O PIX está no boleto"><i class="fa fa-qrcode"></i></a>');
        $comp = preg_match('/^(\d{4})-(\d{2})$/', (string)$f['competencia'], $m) ? "$m[2]/$m[1]" : '';
        $fat[] = ['FATURA_ID' => $f['id'], 'FATURA_UUID' => $f['id'], 'PAY_PIX' => ws_tpl_raw($pix), 'FATURA_VALOR' => ca_dinheiro(ws_fatura_valor_cobrado($f)), 'FATURA_VENCIMENTO' => ca_data($f['vencimento']), 'FATURA_DESCRICAO' => 'Mensalidade' . ($comp ? " $comp" : '')];
        $ids[] = (int)$f['id'];
    }
    $carnes = (ws_central_rec('carne') && count($ids) >= 2) ? [['CARNE_CODIGO' => implode(',', array_slice($ids, 0, 12)), 'CARNE_PARCELAS' => min(12, count($ids))]] : [];
    $blocos += ['FATURAS' => true, 'DADOSFATURAS' => $fat, 'SECAOCARNES' => (bool)$carnes, 'CARNES' => true, 'DADOSCARNES' => $carnes];
    break;
}

case 'pay_pix': {
    $f = ca_fatura($C, (int)($_GET['f'] ?? 0));
    if (!$f || $f['status'] === 'pago' || trim((string)$f['pix_emv']) === '') { ca_flash('err', 'PIX indisponível para esta fatura — use o boleto.'); ca_ir('central_app.php?p=2_via'); }
    $qr = ca_qr((string)$f['pix_emv'], (string)$f['pix_qr_url']);
    $vars += ['QRCODE' => ws_tpl_raw($qr !== '' ? '<img src="' . h($qr) . '" alt="QR Code PIX" width="220" height="220" style="background:#fff;padding:6px;border-radius:8px">' : '<p>Use o código PIX abaixo (copia e cola) no app do seu banco.</p>'), 'COPIACOLA' => (string)$f['pix_emv']];
    break;
}

case 'faturas': {
    $q = $db->prepare("SELECT * FROM ws_fatura WHERE cliente_id=? AND status<>'cancelado' ORDER BY vencimento DESC LIMIT 120"); $q->execute([$cid]); $todas = $q->fetchAll(PDO::FETCH_ASSOC);
    $nf = []; try { $q = $db->prepare("SELECT DISTINCT fatura_id FROM ws_nfse WHERE cliente_id=? AND status='autorizada' AND url_pdf<>''"); $q->execute([$cid]); foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $x) $nf[(int)$x] = 1; } catch (Throwable $e) {}
    $fat = []; $recNf = ws_central_rec('nfse'); $recRec = ws_central_rec('recibo');
    foreach ($todas as $f) $fat[] = ['FATURA_ID' => $f['id'], 'FATURA_UUID' => $f['id'], 'FATURA_VALOR' => ca_dinheiro(ws_fatura_valor_cobrado($f)), 'FATURA_VENCIMENTO' => ca_data($f['vencimento']),
        '_blocos' => ['NFE1' => $recNf && isset($nf[(int)$f['id']]), 'NFE0' => !($recNf && isset($nf[(int)$f['id']])), 'RECIBO1' => $recRec && $f['status'] === 'pago', 'RECIBO0' => !($recRec && $f['status'] === 'pago')]];
    $blocos += ['PAGEENTENDA' => $page === 'entenda', 'PAGEDEFAULT' => $page !== 'entenda', 'FATURAS' => true, 'DADOSFATURAS' => $fat];
    break;
}

case 'comprovante': {
    $conf = null;
    if ($page === 'confirmar') { $conf = ca_fatura($C, (int)($_GET['uuid'] ?? 0)); if (!$conf || $conf['status'] === 'pago') $conf = null; }
    $fat = [];
    foreach ($abertas as $f) $fat[] = ['FATURA_ID' => $f['id'], 'FATURA_UUID' => $f['id'], 'FATURA_VALOR' => ca_dinheiro(ws_fatura_valor_cobrado($f)), 'FATURA_VENCIMENTO' => ca_data($f['vencimento'])];
    $vars += ['UUID_LANC' => $conf ? (string)$conf['id'] : '', 'ID_TITULO' => $conf ? (string)$conf['id'] : ''];
    $blocos += ['PAGECONFIRMAR' => (bool)$conf, 'PAGEDEFAULT' => !$conf, 'FATURAS' => true, 'DADOSFATURAS' => $fat];
    break;
}

case 'servicos': {
    $pl = [];
    foreach ($cts as $ct) $pl[] = ['PLANO_NOME' => $ct['plano'] ?: ('Contrato #' . $ct['id']), 'PLANO_VALOR' => ca_dinheiro($ct['valor'] !== null && $ct['valor'] !== '' ? $ct['valor'] : $ct['plano_valor'])];
    $blocos += ['CONTRATO' => $cts && ws_central_rec('contrato'), 'PLANOS' => $pl, 'SERVICOS' => false];
    break;
}

case 'relatorio': {
    $pag = max(1, (int)($_GET['pag'] ?? 1)); $lim = 15;
    [$rel, $mais] = $sessoes($lim, ($pag - 1) * $lim);
    $vars += ['PAGINA_ANT' => 'central_app.php?p=relatorio&pag=' . ($pag - 1), 'PAGINA_PRO' => 'central_app.php?p=relatorio&pag=' . ($pag + 1)];
    $blocos += ['REL' => true, 'DADOSREL' => $rel, 'PAGANT' => $pag > 1, 'PAGPRO' => $mais];
    break;
}

case 'suporte': {
    $ch = (int)($_GET['chamado'] ?? 0); $c = ($page === 'mensagens' && $ch) ? ca_chamado($C, $ch) : null;
    if ($page === 'mensagens' && !$c) ca_ir('central_app.php?p=suporte');
    if ($page === 'ins_chamado' && !ws_central_rec('suporte_abrir')) { ca_flash('err', 'A abertura de chamados está desativada.'); ca_ir('central_app.php?p=suporte'); }
    if (!ws_central_rec('suporte_responder')) $ocultar[] = 'form:responder';
    $ab = []; $fe = [];
    if (!$c && $page !== 'ins_chamado') {
        $q = $db->prepare("SELECT id,status,criado_em,atualizado_em,fechado_em FROM ws_chamado WHERE cliente_id=? ORDER BY id DESC LIMIT 60"); $q->execute([$cid]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $x) {
            if (in_array($x['status'], ['resolvido', 'cancelado'], true)) $fe[] = ['CHAMADO_FECHADOCODIGO' => $x['id'], 'CHAMADO_FECHADODATA' => ca_data($x['fechado_em'] ?: $x['atualizado_em'])];
            else $ab[] = ['CHAMADO_ABERTOCODIGO' => $x['id'], 'CHAMADO_ABERTODATA' => ca_data($x['criado_em'])];
        }
    }
    $msgs = [];
    if ($c) {
        $msgs[] = ['MSG_POSICAO' => 'right', 'MSG_TEXTO' => (string)$c['descricao'] !== '' ? (string)$c['descricao'] : (string)$c['titulo'], 'MSG_DATA' => date('d/m/Y H:i', strtotime((string)$c['criado_em'])), '_blocos' => ['MSGCHECK' => true]];
        $q = $db->prepare("SELECT autor_tipo,mensagem,criado_em FROM ws_chamado_msg WHERE chamado_id=? AND autor_tipo<>'sistema' ORDER BY id LIMIT 200"); $q->execute([$ch]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $m) $msgs[] = ['MSG_POSICAO' => $m['autor_tipo'] === 'cliente' ? 'right' : 'left', 'MSG_TEXTO' => $m['mensagem'], 'MSG_DATA' => date('d/m/Y H:i', strtotime((string)$m['criado_em'])), '_blocos' => ['MSGCHECK' => $m['autor_tipo'] === 'cliente']];
    }
    $vars += ['CHAMADO_CODIGO' => $c ? (string)$c['id'] : 'novo', 'CHAMADO_ASSUNTO' => $c ? (string)$c['titulo'] : '', 'CHAMADO_DATA' => date('d/m/Y H:i')];
    $blocos += ['PAGEMENSAGENS' => (bool)$c, 'PAGEINSERIR' => $page === 'ins_chamado', 'PAGEDEFAULT' => !$c && $page !== 'ins_chamado', 'MENSAGENS' => true, 'DADOSMENSAGENS' => $msgs,
                'CHAMADOSABERTOS' => true, 'DADOSCHAMADOSABERTOS' => $ab, 'CHAMADOSFECHADOS' => true, 'DADOSCHAMADOSFECHADOS' => $fe, 'OPENCHAMADO' => ws_central_rec('suporte_abrir')];
    break;
}

case 'atualizar_dados': {
    $e = ws_end_cliente($db, $cid);
    $vars += ['CLIENTE_NASCIMENTO' => $row['data_nasc'] ? date('d/m/Y', strtotime((string)$row['data_nasc'])) : '', 'CLIENTE_RG' => (string)$row['rg_ie'], 'CLIENTE_CPF_CNPJ' => h_doc($row['cpf_cnpj']),
        'CLIENTE_FONE' => ca_so_num($row['telefone']), 'CLIENTE_CELULAR' => ca_so_num($row['celular']), 'CLIENTE_UUID_CLIENTE' => '',
        'CLIENTE_CEP_RES' => (string)$e['cep'], 'CLIENTE_ENDERECO_RES' => (string)$e['logradouro'], 'CLIENTE_NUMERO_RES' => (string)$e['numero'], 'CLIENTE_COMPLEMENTO_RES' => (string)$e['complemento'],
        'CLIENTE_BAIRRO_RES' => (string)$e['bairro'], 'CLIENTE_CIDADE_RES' => (string)$e['cidade'], 'CLIENTE_ESTADO_RES' => (string)$e['uf'],
        'CLIENTE_CEP' => (string)($row['cob_cep'] ?? ''), 'CLIENTE_ENDERECO' => (string)($row['cob_logradouro'] ?? ''), 'CLIENTE_NUMERO' => (string)($row['cob_numero'] ?? ''), 'CLIENTE_COMPLEMENTO' => (string)($row['cob_complemento'] ?? ''),
        'CLIENTE_BAIRRO' => (string)($row['cob_bairro'] ?? ''), 'CLIENTE_CIDADE' => (string)($row['cob_cidade'] ?? ''), 'CLIENTE_ESTADO' => (string)($row['cob_uf'] ?? '')];   // endereço de cobrança (cob_*)
    $rl = ws_central_rec('login_trocar');
    $blocos += ['ALTLOGIN' => $rl && ca_login_do_tipo($cts, 'pppoe') !== null, 'ALTLOGINIPOE' => $rl && ca_login_do_tipo($cts, 'ipoe') !== null, 'ALTCPF' => true];
    if (!ws_central_rec('lgpd')) $ocultar[] = 'lgpd';
    // campos que o cliente pode PEDIR para alterar; o resto fica só para consulta (sem nenhum editável = sem botão de enviar)
    $ed = [];
    if (ws_central_rec('dados_contato'))  $ed = array_merge($ed, ['email', 'celular', 'telefone']);
    if (ws_central_rec('dados_cadastro')) $ed = array_merge($ed, ['nome', 'nascimento', 'rg', 'cpf_cnpj', 'cep_res', 'endereco_res', 'numero_res', 'complemento_res', 'bairro_res', 'cidade_res', 'estado_res',
                                                              'cep', 'endereco', 'numero', 'complemento', 'bairro', 'cidade', 'estado']);   // + cobrança
    if ($rl) $ed = array_merge($ed, ['login', 'login_ipoe']);
    $ocultar[] = 'editavel:' . implode(',', $ed);
    $avisoValida = true;
    break;
}

case 'trocar_senha': {
    $login = (string)($_GET['login'] ?? ''); $achou = false; $adic = []; $recAdic = ws_central_rec('senha_adicionais');
    foreach (array_keys(ca_logins_mapa($cts)) as $i => $l) { if ($login !== '' && $l === $login && ($i === 0 || $recAdic)) $achou = true; if ($recAdic && $i > 0) $adic[] = ['USERNAME' => $l]; }
    $avisoValida = true;
    $tipo = (string)($_GET['tipo_login'] ?? '') === 'adic' ? 'adic' : 'princ';
    $vars += ['TIPO' => $tipo, 'LOGIN' => $achou ? $login : '', 'SENHA' => '', 'USERNAME' => ''];
    $blocos += ['PAGESENHA' => $page === 'senha' && $achou, 'PAGEDEFAULT' => !($page === 'senha' && $achou), 'ADICIONAIS' => true, 'DADOSADICIONAIS' => $adic];
    break;
}

case 'foto': break;

case 'disco_virtual': {
    $pag = max(1, (int)($_GET['pag'] ?? 1)); $lim = 15; $total = ws_central_param('disco_mb') * 1048576;
    $q = $db->prepare("SELECT COALESCE(SUM(tamanho),0) FROM ws_anexo WHERE cliente_id=?"); $q->execute([$cid]); $usado = (int)$q->fetchColumn();
    $q = $db->prepare("SELECT id,nome_original,arquivo,mime,tamanho FROM ws_anexo WHERE cliente_id=? ORDER BY id DESC LIMIT " . ($lim + 1) . ' OFFSET ' . (($pag - 1) * $lim)); $q->execute([$cid]);
    $r = $q->fetchAll(PDO::FETCH_ASSOC); $mais = count($r) > $lim; $r = array_slice($r, 0, $lim); $arq = [];
    foreach ($r as $x) $arq[] = ['ARQUIVO_ID' => $x['id'], 'ARQUIVO_NOME' => $x['nome_original'] ?: basename($x['arquivo']), 'ARQUIVO_TAM' => ca_bytes($x['tamanho']),
        'ARQUIVO_ICONE' => strpos((string)$x['mime'], 'image/') === 0 ? 'fa-file-image-o' : ($x['mime'] === 'application/pdf' ? 'fa-file-pdf-o' : 'fa-file-o')];
    $vars += ['DISCO_USADO' => ca_bytes($usado), 'DISCO_TOTAL' => ca_bytes($total), 'DISCO_PERC' => (string)min(100, (int)round($usado * 100 / $total)), 'PAGINA_ANT' => (string)($pag - 1), 'PAGINA_PRO' => (string)($pag + 1)];
    $upOk = ws_central_rec('disco_upload'); if ($page === 'upload' && !$upOk) ca_ir('central_app.php?p=disco_virtual');
    if (!$upOk) $ocultar[] = 'id:btn_adicionar';
    if (!ws_central_rec('disco_apagar')) $ocultar[] = 'id:btn_remover';
    $blocos += ['PAGEUPLOAD' => $page === 'upload', 'PAGEDEFAULT' => $page !== 'upload', 'ARQUIVOS' => true, 'DADOSARQUIVOS' => $arq, 'PAGANT' => $pag > 1, 'PAGPRO' => $mais];
    break;
}

case 'downloads': {                                  // arquivos que o provedor solta em uploads/central_downloads/[Categoria/]arquivo
    $dl = []; $base = realpath(WS_UPLOADS . '/central_downloads');
    if ($base) {
        foreach (array_merge(glob($base . '/*') ?: [], glob($base . '/*/*') ?: []) as $f) {
            if (!is_file($f) || basename($f)[0] === '.') continue;
            $rel = ltrim(substr($f, strlen($base)), '/\\'); $cat = strpos($rel, '/') !== false ? dirname($rel) : 'Geral';
            $dl[] = ['DOWNLOAD_ID' => rtrim(strtr(base64_encode(str_replace('\\', '/', $rel)), '+/', '-_'), '='), 'DOWNLOAD_NOME' => pathinfo($f, PATHINFO_FILENAME), 'DOWNLOAD_DESC' => strtoupper(pathinfo($f, PATHINFO_EXTENSION)) . ' · ' . ca_bytes(filesize($f)), 'DOWNLOAD_CAT' => $cat];
        }
    }
    $blocos += ['DOWN' => true, 'DADOSDOWN' => $dl];
    break;
}

case 'fale_conosco': break;
}

$opc['ocultar'] = $ocultar;
if (!empty($avisoValida) && empty($opc['flash'][1])) {                   // nas telas que só PEDEM: explica a validação (ou lembra do pedido em andamento)
    $pend = $sol['pendentes'];
    $opc['flash'] = ['info', $pend ? "Você tem $pend pedido(s) aguardando validação da nossa equipe. Assim que aprovados, a troca é feita automaticamente." : 'Por segurança, alterações de login, senha, titularidade e endereço passam por validação da nossa equipe e são aplicadas automaticamente após a aprovação.'];
}
if (!ws_central_tpl_pagina($tpl, $p, $blocos, $vars, $opc)) { http_response_code(500); echo 'Página do template indisponível.'; }
