<?php
/**
 * WellSystem — AVISOS DO ROBÔ PARA O PROVEDOR (07/10/2026, regra do provedor).
 * Chamado aberto pelo robô, pré-cadastro, pedido de confiança, solicitação (vencimento/plano) e "robô pediu ajuda"/
 * fora do horário aparecem PARA O PROVEDOR NA INSTÂNCIA EM QUE O CLIENTE FALOU — não vão para número pessoal, nem para
 * a gerência (gerência = saúde dos servidores, falha crítica do WellSystem e WellSystem OLT).
 *
 *   1º  CHATWOOT (Evolution ligada ao Chatwoot): NOTA PRIVADA na conversa do cliente, na caixa da instância em que ele
 *       falou (a mais recente). O provedor vê no atendimento; o CLIENTE NÃO RECEBE NADA. Credenciais vêm da própria
 *       Evolution (GET /chatwoot/find/{instância}), guardadas 6 h em cache/chatwoot_cfg.json — nada para configurar.
 *   2º  WhatsApp comum (Evolution sem API oficial, sem Chatwoot): mensagem "para si mesmo" na instância (conversa
 *       "Você" do WhatsApp daquele número) — o provedor vê no celular/WhatsApp Web da instância.
 *   3º  Último recurso: texto na conversa do cliente com o robô (aí o cliente também vê).
 * Nunca lança. @return array ['enviados'=>int, 'via'=>'chatwoot'|'instancia'|'cliente'|'', 'erros'=>string[]]
 */
if (is_file(__DIR__ . '/whatsapp.php')) require_once __DIR__ . '/whatsapp.php';

function ws_cw_http(string $metodo, string $url, string $token, ?array $corpo = null): array {
    $ch = curl_init($url);
    $h = ['api_access_token: ' . $token, 'Accept: application/json'];
    if ($corpo !== null) $h[] = 'Content-Type: application/json';
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_CUSTOMREQUEST => $metodo,
        CURLOPT_HTTPHEADER => $h] + ($corpo !== null ? [CURLOPT_POSTFIELDS => json_encode($corpo, JSON_UNESCAPED_UNICODE)] : []));
    $r = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return [$code, json_decode((string)$r, true)];
}

/** Configuração do Chatwoot de cada instância, perguntada à Evolution. [] = sem Chatwoot. */
function ws_cw_cfg(bool $renovar = false): array {
    $arq = WS_CACHE . '/chatwoot_cfg.json';
    $c = json_decode((string)@file_get_contents($arq), true);
    if (!$renovar && is_array($c) && (time() - (int)($c['em'] ?? 0)) < 21600) return (array)($c['inst'] ?? []);
    $out = [];
    if (function_exists('ws_wa_config') && function_exists('ws_wa_instancias')) {
        $wa = ws_wa_config();
        if (($wa['gateway'] ?? 'evolution') === 'evolution' && ($wa['url'] ?? '') !== '' && ($wa['apikey'] ?? '') !== '') {
            foreach (array_unique(array_merge(ws_wa_instancias($wa), function_exists('ws_wa_instancias_comum') ? ws_wa_instancias_comum($wa) : [])) as $inst) {
                $ch = curl_init(rtrim($wa['url'], '/') . '/chatwoot/find/' . rawurlencode($inst));
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['apikey: ' . ws_wa_chave($wa, (string)$inst)]]);
                $j = json_decode((string)curl_exec($ch), true); curl_close($ch);
                if (is_array($j) && !empty($j['enabled']) && !empty($j['url']) && !empty($j['token']))
                    $out[$inst] = ['url' => rtrim((string)$j['url'], '/'), 'conta' => (string)($j['accountId'] ?? $j['account_id'] ?? '1'), 'token' => (string)$j['token'], 'caixa' => (string)($j['nameInbox'] ?? $j['name_inbox'] ?? $inst)];
            }
        }
    }
    @file_put_contents($arq, json_encode(['em' => time(), 'inst' => $out])); @chmod($arq, 0640);
    return $out;
}

/** Nota privada na conversa mais recente do cliente (na caixa da instância indicada, se houver). '' = ok; senão o motivo. */
function ws_cw_nota_privada(string $foneCliente, string $texto, string $instancia = ''): string {
    $cfgs = ws_cw_cfg(); if (!$cfgs) return 'Chatwoot não ligado na Evolution';
    $dig = preg_replace('/\D/', '', $foneCliente); if (strlen($dig) < 8) return 'sem telefone do cliente';
    $fim8 = substr($dig, -8);   // casa com ou sem o 9º dígito e com/sem 55
    // agrupa por conta (as instâncias costumam usar a mesma conta)
    $porConta = [];
    foreach ($cfgs as $inst => $c) $porConta[$c['url'] . '|' . $c['conta']][$inst] = $c;
    $motivo = 'cliente sem conversa no Chatwoot';
    foreach ($porConta as $insts) {
        $c0 = reset($insts); $base = $c0['url'] . '/api/v1/accounts/' . rawurlencode($c0['conta']);
        [$code, $j] = ws_cw_http('GET', $base . '/contacts/search?q=' . rawurlencode($fim8), $c0['token']);
        if ($code === 401 || $code === 403) { ws_cw_cfg(true); return 'Chatwoot recusou a credencial (renovada para a próxima)'; }
        $contatos = array_values(array_filter((array)($j['payload'] ?? []), fn($p) => substr(preg_replace('/\D/', '', (string)($p['phone_number'] ?? '')), -8) === $fim8));
        if (!$contatos) continue;
        // caixas (inbox) das instâncias desta conta: nome → id
        [, $jb] = ws_cw_http('GET', $base . '/inboxes', $c0['token']);
        $caixaId = []; foreach ((array)($jb['payload'] ?? []) as $ib) $caixaId[(string)($ib['name'] ?? '')] = (int)($ib['id'] ?? 0);
        $preferida = ($instancia !== '' && isset($insts[$instancia])) ? ($caixaId[$insts[$instancia]['caixa']] ?? 0) : 0;
        $daqui = array_filter(array_map(fn($c) => $caixaId[$c['caixa']] ?? 0, $insts));
        $melhor = null;
        foreach ($contatos as $ct) {
            [, $jc] = ws_cw_http('GET', $base . '/contacts/' . (int)$ct['id'] . '/conversations', $c0['token']);
            foreach ((array)($jc['payload'] ?? []) as $cv) {
                $ib = (int)($cv['inbox_id'] ?? 0); if ($daqui && !in_array($ib, $daqui, true)) continue;
                $t = (int)($cv['last_activity_at'] ?? $cv['timestamp'] ?? 0) + ($preferida && $ib === $preferida ? 10 ** 10 : 0);
                if (!$melhor || $t > $melhor[0]) $melhor = [$t, (int)$cv['id']];
            }
        }
        if (!$melhor) continue;
        /* SEM NOTA REPETIDA (13/10/2026): antes de gravar, olha as últimas mensagens da conversa; se a MESMA nota privada já está lá (últimos 30 min — webhook repetido, dois processos
           ao mesmo tempo, cache perdido), não grava de novo. */
        [$cm, $jm] = ws_cw_http('GET', $base . '/conversations/' . $melhor[1] . '/messages', $c0['token']);
        if ($cm >= 200 && $cm < 300) {
            $msgs = (array)($jm['payload'] ?? (isset($jm[0]) ? $jm : []));
            $alvoN = preg_replace('/\s+/', ' ', trim($texto));
            foreach (array_slice($msgs, -15) as $mm) {
                if (!is_array($mm) || empty($mm['private'])) continue;
                if (time() - (int)($mm['created_at'] ?? 0) > 1800) continue;
                if (preg_replace('/\s+/', ' ', trim((string)($mm['content'] ?? ''))) === $alvoN) return '';
            }
        }
        [$code, ] = ws_cw_http('POST', $base . '/conversations/' . $melhor[1] . '/messages', $c0['token'],
                               ['content' => $texto, 'message_type' => 'outgoing', 'private' => true]);
        if ($code >= 200 && $code < 300) return '';
        $motivo = "Chatwoot HTTP $code ao gravar a nota";
    }
    return $motivo;
}

/** TRAVA CONTRA AVISO REPETIDO (13/10/2026): todo aviso ao provedor passa por aqui, então a regra vale para TODOS os caminhos (chamado, pré-cadastro, confiança, solicitação, "robô pediu ajuda").
 *  Mesmo cliente + mesmo texto em 15 min = repetição (webhook reenviado, fluxo chamado 2x). Mesmo cliente + mesmo tipo de aviso + mesmo nº (#chamado / L-protocolo) em 6 h = repetição.
 *  Reserva ANTES de enviar (com flock — dois processos juntos não passam os dois); se nada foi entregue, a reserva é desfeita para uma nova tentativa poder sair.
 *  Devolve [true, chaves] quando PODE enviar, [false, []] quando é repetido. */
function ws_aviso_reservar(string $texto, string $foneCliente): array {
    $fim8 = substr(preg_replace('/\D/', '', explode('@', $foneCliente)[0]), -8);
    $norm = preg_replace('/\s+/', ' ', trim($texto));
    $k1 = 'T' . substr(sha1($fim8 . '|' . $norm), 0, 20);
    $linha1 = preg_replace('/[#\d]+/u', '', (string)strtok(trim($texto), "\n"));   // 1ª linha = o tipo do aviso (sem os números)
    $nums = preg_match_all('/(?:#|\bL)(\d+)/u', $norm, $mn) ? implode(',', array_unique($mn[1])) : '';
    $k2 = $nums !== '' ? 'N' . substr(sha1($fim8 . '|' . $nums . '|' . preg_replace('/\W+/u', '', $linha1)), 0, 20) : '';
    $f = WS_CACHE . '/aviso_provedor_dedupe.json'; $h = @fopen($f, 'c+'); if (!$h) return [true, []];   // sem como travar: envia (melhor repetir do que perder aviso)
    $ok = true; $chaves = [];
    if (flock($h, LOCK_EX)) {
        $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = [];
        foreach ($j as $k => $t) if (time() - (int)$t > 21600) unset($j[$k]);
        if (isset($j[$k1]) && time() - (int)$j[$k1] < 900) $ok = false;
        if ($ok && $k2 !== '' && isset($j[$k2])) $ok = false;
        if ($ok) { $j[$k1] = time(); $chaves[] = $k1; if ($k2 !== '') { $j[$k2] = time(); $chaves[] = $k2; } }
        ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j)); fflush($h); flock($h, LOCK_UN);
    }
    fclose($h); @chmod($f, 0640);
    return [$ok, $chaves];
}
function ws_aviso_liberar(array $chaves): void {
    if (!$chaves) return;
    $f = WS_CACHE . '/aviso_provedor_dedupe.json'; $h = @fopen($f, 'c+'); if (!$h) return;
    if (flock($h, LOCK_EX)) { $j = json_decode((string)stream_get_contents($h), true); if (!is_array($j)) $j = []; foreach ($chaves as $k) unset($j[$k]); ftruncate($h, 0); rewind($h); fwrite($h, json_encode($j)); fflush($h); flock($h, LOCK_UN); }
    fclose($h);
}

function ws_aviso_provedor(string $texto, string $foneCliente = '', string $instancia = ''): array {
    $out = ['enviados' => 0, 'via' => '', 'erros' => []];
    $instancia = strpos($instancia, '{{') !== false ? '' : trim($instancia);
    $fc = preg_replace('/@.*$/', '', trim($foneCliente));
    [$podeAvisar, $chavesAviso] = ws_aviso_reservar($texto, $fc);
    if (!$podeAvisar) { $out['via'] = 'repetido'; return $out; }   // já avisado: não manda de novo
    $r0 = ws_aviso_provedor_enviar($texto, $fc, $instancia, $out);
    if (empty($r0['enviados'])) ws_aviso_liberar($chavesAviso);   // nada saiu: libera para a próxima tentativa
    return $r0;
}

function ws_aviso_provedor_enviar(string $texto, string $fc, string $instancia, array $out): array {
    // 1º Chatwoot: nota privada na conversa do cliente (o cliente não recebe)
    try {
        $m = ws_cw_nota_privada($fc, "🤖 Aviso do WellSystem\n\n" . $texto, $instancia);
        if ($m === '') { $out['enviados'] = 1; $out['via'] = 'chatwoot'; return $out; }
        $out['erros'][] = $m;
    } catch (Throwable $e) { $out['erros'][] = 'Chatwoot: ' . $e->getMessage(); }
    if (!function_exists('ws_wa_enviar')) { $out['erros'][] = 'WhatsApp indisponível'; return $out; }
    // 2º WhatsApp comum (sem API oficial): mensagem para o próprio número da instância (conversa "Você")
    try {
        $wa = function_exists('ws_wa_config') ? ws_wa_config() : [];
        if (($wa['gateway'] ?? 'evolution') === 'evolution' && empty($wa['meta_oficial']) && function_exists('ws_wa_evo_um') && function_exists('ws_wa_numero_proprio')) {
            $inst = $instancia !== '' ? $instancia : (string)($wa['instance'] ?? '');
            $proprio = $inst !== '' ? ws_wa_numero_proprio(['instance' => $inst] + $wa) : '';
            if ($proprio !== '') {
                $r = ws_wa_evo_um('texto', $inst, $proprio, "🤖 Aviso do WellSystem\n\n" . $texto, $wa);
                if (!empty($r['ok'])) { $out['enviados'] = 1; $out['via'] = 'instancia'; return $out; }
                $out['erros'][] = "instância $inst: " . mb_substr(trim((string)($r['raw'] ?? 'falha')), 0, 120);
            }
        }
    } catch (Throwable $e) { $out['erros'][] = 'instância: ' . $e->getMessage(); }
    // 3º último recurso: na conversa do cliente com o robô (o cliente também vê)
    if ($fc !== '' && preg_replace('/\D/', '', $fc) !== '') {
        try {
            $r = ws_wa_enviar($fc, $texto, false, ['evento' => 'chamado', 'automatica' => true, 'so_janela' => true] + ($instancia !== '' ? ['so_janela_instancias' => [$instancia]] : []));
            if (!empty($r['ok'])) { $out['enviados'] = 1; $out['via'] = 'cliente'; return $out; }
            $out['erros'][] = 'cliente ' . $fc . ': ' . mb_substr(trim((string)($r['raw'] ?? 'falha')), 0, 160);
        } catch (Throwable $e) { $out['erros'][] = 'cliente: ' . $e->getMessage(); }
    }
    @error_log('[aviso_provedor] não entregue: ' . implode(' | ', $out['erros']));
    return $out;
}

/** ATENDENTE (pessoa) FALOU NAS ÚLTIMAS HORAS? (16/10/2026, caso Kássia): o robô respondia "Tá certo" do cliente com saudação + despedida, de novo a cada "tá certo", logo depois de uma atendente conversar com ela.
 *  No Chatwoot o robô e as pessoas aparecem como "agente"; o usuário do robô é o que assina a saudação/menu ("Olá !!", "Bem-vindo ao atendimento"); mensagem enviada por OUTRO usuário, não privada, é de gente. */
function ws_cw_humano_falou_recente(string $foneCliente, int $horas = 12): bool {
    try {
        $cfgs = ws_cw_cfg(); if (!$cfgs) return false; $fim8 = substr(preg_replace('/\D/', '', $foneCliente), -8); if (strlen($fim8) < 8) return false;
        $c0 = reset($cfgs); $base = $c0['url'] . '/api/v1/accounts/' . rawurlencode($c0['conta']);
        [, $j] = ws_cw_http('GET', $base . '/contacts/search?q=' . rawurlencode($fim8), $c0['token']);
        $limite = time() - $horas * 3600;
        foreach ((array)($j['payload'] ?? []) as $ct) {
            if (substr(preg_replace('/\D/', '', (string)($ct['phone_number'] ?? '')), -8) !== $fim8) continue;
            [, $jc] = ws_cw_http('GET', $base . '/contacts/' . (int)$ct['id'] . '/conversations', $c0['token']);
            foreach ((array)($jc['payload'] ?? []) as $cv) {
                if ((int)($cv['last_activity_at'] ?? 0) < $limite) continue;
                [, $jm] = ws_cw_http('GET', $base . '/conversations/' . (int)$cv['id'] . '/messages', $c0['token']);
                $msgs = array_slice((array)($jm['payload'] ?? []), -40); $robo = [];
                foreach ($msgs as $m) { if ((int)($m['message_type'] ?? 0) === 1 && preg_match('/^\*{0,2}(Olá|Bem-vindo)|Agradece seu contato/u', trim((string)($m['content'] ?? ''))) && !empty($m['sender']['id'])) $robo[(int)$m['sender']['id']] = 1; }
                foreach ($msgs as $m) {
                    if ((int)($m['message_type'] ?? 0) !== 1 || !empty($m['private']) || (int)($m['created_at'] ?? 0) < $limite) continue;
                    $sid = (int)($m['sender']['id'] ?? 0); if (($m['sender']['type'] ?? '') === 'user' && $sid > 0 && !isset($robo[$sid])) return true;
                }
            }
        }
    } catch (Throwable $e) {}
    return false;
}

/** O MENU PRINCIPAL FOI ENVIADO AO CLIENTE NOS ÚLTIMOS $segundos? (24/10/2026, caso Fernanda: o robô mandava saudação + menu de novo logo depois de já ter mandado o menu e o cliente ter respondido.)
 *  Procura, nas conversas do contato com atividade recente, uma mensagem de saída "Digite uma das opções". Qualquer falha = false (o robô age como antes). */
function ws_cw_menu_enviado_recente(string $foneCliente, int $segundos = 600): bool {
    try {
        $cfgs = ws_cw_cfg(); if (!$cfgs) return false; $fim8 = substr(preg_replace('/\D/', '', $foneCliente), -8); if (strlen($fim8) < 8) return false;
        $c0 = reset($cfgs); $base = $c0['url'] . '/api/v1/accounts/' . rawurlencode($c0['conta']);
        [, $j] = ws_cw_http('GET', $base . '/contacts/search?q=' . rawurlencode($fim8), $c0['token']); $limite = time() - $segundos;
        foreach ((array)($j['payload'] ?? []) as $ct) {
            if (substr(preg_replace('/\D/', '', (string)($ct['phone_number'] ?? '')), -8) !== $fim8) continue;
            [, $jc] = ws_cw_http('GET', $base . '/contacts/' . (int)$ct['id'] . '/conversations', $c0['token']);
            foreach ((array)($jc['payload'] ?? []) as $cv) {
                if ((int)($cv['last_activity_at'] ?? 0) < $limite) continue;
                [, $jm] = ws_cw_http('GET', $base . '/conversations/' . (int)$cv['id'] . '/messages', $c0['token']);
                foreach (array_slice((array)($jm['payload'] ?? []), -40) as $m) if ((int)($m['message_type'] ?? 0) === 1 && (int)($m['created_at'] ?? 0) >= $limite && preg_match('/Digite uma das op/iu', (string)($m['content'] ?? ''))) return true;
            }
        }
    } catch (Throwable $e) {}
    return false;
}
/** A mensagem de saída é o MENU PRINCIPAL ("Digite uma das opções")? (parte pura, testável) */
function ws_cw_texto_e_menu(string $texto): bool { return (bool)preg_match('/Digite uma das op/iu', $texto); }
/** A ÚLTIMA mensagem que o robô/sistema mandou a este cliente (nos últimos $segundos) foi o MENU PRINCIPAL? (26/10/2026, caso 0617: o cliente via o menu, digitava 1 ou 7 e o robô mandava saudação + menu de novo.)
 *  Só vale se NADA foi enviado depois do menu — se o robô falou outra coisa, o número não é resposta ao menu. Qualquer falha = false (o robô age como antes). */
function ws_cw_ultima_saida_e_menu(string $foneCliente, int $segundos = 600): bool {
    try {
        $cfgs = ws_cw_cfg(); if (!$cfgs) return false; $fim8 = substr(preg_replace('/\D/', '', $foneCliente), -8); if (strlen($fim8) < 8) return false;
        $c0 = reset($cfgs); $base = $c0['url'] . '/api/v1/accounts/' . rawurlencode($c0['conta']);
        [, $j] = ws_cw_http('GET', $base . '/contacts/search?q=' . rawurlencode($fim8), $c0['token']); $limite = time() - $segundos; $ult = null;
        foreach ((array)($j['payload'] ?? []) as $ct) {
            if (substr(preg_replace('/\D/', '', (string)($ct['phone_number'] ?? '')), -8) !== $fim8) continue;
            [, $jc] = ws_cw_http('GET', $base . '/contacts/' . (int)$ct['id'] . '/conversations', $c0['token']);
            foreach ((array)($jc['payload'] ?? []) as $cv) {
                if ((int)($cv['last_activity_at'] ?? 0) < $limite) continue;
                [, $jm] = ws_cw_http('GET', $base . '/conversations/' . (int)$cv['id'] . '/messages', $c0['token']);
                foreach (array_slice((array)($jm['payload'] ?? []), -40) as $m) {
                    if ((int)($m['message_type'] ?? 0) !== 1 || !empty($m['private'])) continue;
                    if ($ult === null || (int)($m['created_at'] ?? 0) > (int)$ult['created_at']) $ult = $m;
                }
            }
        }
        return $ult !== null && (int)$ult['created_at'] >= $limite && ws_cw_texto_e_menu((string)($ult['content'] ?? ''));
    } catch (Throwable $e) { return false; }
}

/** A mensagem de saída é a DESPEDIDA do robô ("Agradece seu contato")? (parte pura, testável) */
function ws_cw_texto_e_despedida(string $texto): bool { return (bool)preg_match('/Agradece seu contato/iu', $texto); }
/** A ÚLTIMA mensagem que o robô/sistema mandou a este cliente (nos últimos $segundos) foi a DESPEDIDA do atendimento? (27/10/2026, caso Marilak: chamado aberto, robô despediu-se, o cliente respondeu "Ok" e veio saudação + menu de novo.)
 *  Só vale se NADA foi enviado depois da despedida. Qualquer falha = false (o robô age como antes). */
function ws_cw_ultima_saida_e_despedida(string $foneCliente, int $segundos = 600): bool {
    try {
        $cfgs = ws_cw_cfg(); if (!$cfgs) return false; $fim8 = substr(preg_replace('/\D/', '', $foneCliente), -8); if (strlen($fim8) < 8) return false;
        $c0 = reset($cfgs); $base = $c0['url'] . '/api/v1/accounts/' . rawurlencode($c0['conta']);
        [, $j] = ws_cw_http('GET', $base . '/contacts/search?q=' . rawurlencode($fim8), $c0['token']); $limite = time() - $segundos; $ult = null;
        foreach ((array)($j['payload'] ?? []) as $ct) {
            if (substr(preg_replace('/\D/', '', (string)($ct['phone_number'] ?? '')), -8) !== $fim8) continue;
            [, $jc] = ws_cw_http('GET', $base . '/contacts/' . (int)$ct['id'] . '/conversations', $c0['token']);
            foreach ((array)($jc['payload'] ?? []) as $cv) {
                if ((int)($cv['last_activity_at'] ?? 0) < $limite) continue;
                [, $jm] = ws_cw_http('GET', $base . '/conversations/' . (int)$cv['id'] . '/messages', $c0['token']);
                foreach (array_slice((array)($jm['payload'] ?? []), -40) as $m) {
                    if ((int)($m['message_type'] ?? 0) !== 1 || !empty($m['private'])) continue;
                    if ($ult === null || (int)($m['created_at'] ?? 0) > (int)$ult['created_at']) $ult = $m;
                }
            }
        }
        return $ult !== null && (int)$ult['created_at'] >= $limite && ws_cw_texto_e_despedida((string)($ult['content'] ?? ''));
    } catch (Throwable $e) { return false; }
}
/**
 * DOCUMENTO DO ATENDENTE DIGITADO NA CAIXA DA COMUM (01) — 23/10/2026. Regra do dono: PDF/recibo/boleto NUNCA saem pela comum; saem pela API (02). A Evolution da API não entrega uma conversa que pertence à caixa
 * da comum (o envio "sumia": nem pela 01 nem pela 02), então o arquivo é REPOSTADO como mensagem de saída na conversa do MESMO cliente na caixa da API — o Chatwoot avisa a caixa da API, o intermediário
 * (/api/cwproxy) a entrega pela API como qualquer resposta digitada ali. A cópia original na caixa da comum NÃO é enviada (o intermediário não a repassa). $simular=true só mostra o que faria.
 * Devolve [bool ok, string texto]. Nunca cai para a comum: sem conversa do cliente na caixa da API ou qualquer falha → [false, motivo] e o intermediário deixa uma NOTA PRIVADA avisando a equipe.
 */
function ws_cwproxy_repostar(array $pl, string $api, bool $simular = false): array {
    try {
        $cfs = ws_cw_cfg(); $cw = $cfs[$api] ?? (reset($cfs) ?: null); if (!$cw) return [false, 'Chatwoot não configurado'];
        $base = rtrim((string)$cw['url'], '/') . '/api/v1/accounts/' . rawurlencode((string)$cw['conta']); $tok = (string)$cw['token'];
        $h = function (string $m, string $p, $b = null, bool $multi = false) use ($base, $tok): array {
            $ch = curl_init($base . $p); $hd = ['api_access_token: ' . $tok]; if (!$multi) $hd[] = 'Content-Type: application/json';
            $o = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_TIMEOUT => 40, CURLOPT_HTTPHEADER => $hd];
            if ($b !== null) $o[CURLOPT_POSTFIELDS] = $multi ? $b : json_encode($b, JSON_UNESCAPED_UNICODE); curl_setopt_array($ch, $o);
            $r = curl_exec($ch); $s = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$s, json_decode((string)$r, true)];
        };
        [, $jI] = $h('GET', '/inboxes'); $idApi = 0; foreach ((array)($jI['payload'] ?? []) as $ib) if ((string)$ib['name'] === $api) $idApi = (int)$ib['id'];
        $contato = (int)($pl['conversation']['meta']['sender']['id'] ?? 0);
        if (!$idApi || !$contato) return [false, 'não achei a caixa da API ou o contato'];
        [, $jv] = $h('GET', "/contacts/$contato/conversations"); $conv = 0; $ult = -1;
        foreach ((array)($jv['payload'] ?? []) as $cv) if ((int)($cv['inbox_id'] ?? 0) === $idApi && (int)($cv['last_activity_at'] ?? 0) > $ult) { $ult = (int)$cv['last_activity_at']; $conv = (int)$cv['id']; }
        if (!$conv) return [false, 'o cliente ainda não tem conversa na caixa da API (Wellnet-02)'];
        $anx = array_values(array_filter((array)($pl['attachments'] ?? []), fn($a) => !empty($a['data_url'])));
        if (!$anx) return [false, 'sem arquivo para reenviar'];
        if ($simular) return [true, "simulado: reenviaria " . count($anx) . " arquivo(s) para a conversa #$conv da caixa $api"];
        $texto = trim((string)($pl['content'] ?? '')); $n = 0;
        foreach ($anx as $i => $a) {
            $url = (string)$a['data_url']; $p = parse_url($url); if (!$p || !in_array(strtolower((string)($p['scheme'] ?? '')), ['http', 'https'], true) || empty($p['host'])) return [false, 'endereço do arquivo inválido'];
            $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 40, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_MAXFILESIZE => 16777216]);
            $bin = curl_exec($ch); $cod = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $mime = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); curl_close($ch);
            if ($bin === false || $cod !== 200 || strlen((string)$bin) < 10) return [false, 'não consegui baixar o arquivo do Chatwoot (HTTP ' . $cod . ')'];
            $nome = preg_replace('/[^A-Za-z0-9._-]+/', '_', basename((string)parse_url($url, PHP_URL_PATH))) ?: ('arquivo_' . ($i + 1));
            $tmp = tempnam(sys_get_temp_dir(), 'cwr'); file_put_contents($tmp, $bin);
            [$s] = $h('POST', "/conversations/$conv/messages", ['content' => $i === 0 ? $texto : '', 'message_type' => 'outgoing', 'private' => 'false', 'attachments[]' => new CURLFile($tmp, strtok($mime, ';') ?: 'application/octet-stream', $nome)], true);
            @unlink($tmp); if ($s < 200 || $s >= 300) return [false, "o Chatwoot recusou o arquivo (HTTP $s)"]; $n++;
        }
        return [true, "reenviado: $n arquivo(s) pela caixa $api (conversa #$conv)"];
    } catch (Throwable $e) { return [false, 'falha: ' . mb_substr($e->getMessage(), 0, 120)]; }
}
/** Nota PRIVADA numa conversa do Chatwoot (só a equipe vê; não envia nada ao cliente). */
function ws_cwproxy_nota(array $pl, string $api, string $texto): void {
    try {
        $cfs = ws_cw_cfg(); $cw = $cfs[$api] ?? (reset($cfs) ?: null); $conv = (int)($pl['conversation']['id'] ?? 0); if (!$cw || !$conv) return;
        $ch = curl_init(rtrim((string)$cw['url'], '/') . '/api/v1/accounts/' . rawurlencode((string)$cw['conta']) . "/conversations/$conv/messages");
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_POST => 1, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['api_access_token: ' . (string)$cw['token'], 'Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode(['content' => $texto, 'message_type' => 'outgoing', 'private' => true], JSON_UNESCAPED_UNICODE)]);
        curl_exec($ch); curl_close($ch);
    } catch (Throwable $e) {}
}
