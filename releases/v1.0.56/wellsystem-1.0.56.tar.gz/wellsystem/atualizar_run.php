<?php
/**
 * WellSystem — rotina da ATUALIZAÇÃO (cron, a cada minuto, como ROOT). Só linha de comando. Regras em atualizar_lib.php.
 *   · pedido da tela (cache/atualizar_pedido.json): "Atualizar agora" ou "Voltar à versão anterior";
 *   · automática: só se estiver LIGADA, na hora marcada (1x por dia) e se houver versão mais nova.
 * Quem aplica é ws-atualizar-aplicar.sh (copia de segurança + ATUALIZAR.sh + conferência + volta sozinho se falhar).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/config.php';
require_once __DIR__ . '/atualizar_lib.php';
if (function_exists('posix_geteuid') && posix_geteuid() !== 0) exit(0);   // só root aplica atualização
$trava = fopen(WS_CACHE . '/atualizar.lock', 'c'); if (!$trava || !flock($trava, LOCK_EX | LOCK_NB)) exit(0);

/* FREERADIUS × LISTA DE NAS: o FreeRADIUS só lê a tabela `nas` (concentradores) ao iniciar. Backup restaurado ou concentrador novo =
   "unknown client" no log, autenticação e contabilização ignoradas. Aqui, a cada minuto como root, confere a lista e reinicia o serviço
   (cerca de 2 s; quem está conectado continua) quando ela mudou desde o último início. Guarda só o hash, nunca o secret. */
try {
    $nasLinhas = ws_db()->query("SELECT id, nasname, secret FROM nas ORDER BY id")->fetchAll(PDO::FETCH_NUM);
    $nasHash = md5(json_encode($nasLinhas)); $nasArq = WS_CACHE . '/nas_freeradius.hash';
    if ($nasLinhas && $nasHash !== trim((string)@file_get_contents($nasArq))) {
        exec('systemctl restart freeradius 2>&1', $nasOut, $nasRc);
        if ($nasRc === 0) { @file_put_contents($nasArq, $nasHash); @chmod($nasArq, 0640); ws_atu_log('FreeRADIUS reiniciado: a lista de concentradores (NAS) mudou.'); }
    }
} catch (Throwable $e) {}

/* HORA CERTA e LOGS PARA O SERVIDOR DE LOGS (31/10/2026): chrony com NTP.br e, se ligado na tela Logs de conexão, envio do log do RADIUS, dos acessos e dos
   registros de conexão (radacct) ao servidor de logs. Só aplica quando a configuração muda; tudo em logs_envio_lib.php. */
if (is_file(__DIR__ . '/logs_envio_lib.php')) { require_once __DIR__ . '/logs_envio_lib.php'; ws_logs_envio_rodar(); }

/* REINICIAR O SERVIDOR (card "Reiniciar o servidor" da Manutenção, 23/10/2026): a web (www-data) só grava o pedido; aqui, como root, reinicia. O pedido é APAGADO ANTES de reiniciar — se não for possível apagar,
   NÃO reinicia (nunca entra em laço de reinício) — e pedido com mais de 10 min é ignorado. */
$rebArq = WS_CACHE . '/reiniciar_servidor.pedido';
if (is_file($rebArq)) {
    $rb = json_decode((string)@file_get_contents($rebArq), true); $rbIdade = time() - (int)($rb['em'] ?? 0); $rbApagou = @unlink($rebArq);
    if ($rbApagou && $rbIdade >= 0 && $rbIdade < 600) { ws_atu_log('Reinício do servidor pedido por ' . (string)($rb['por'] ?? '?') . ': reiniciando agora.'); @exec('sync; systemctl reboot 2>&1'); exit(0); }
    if ($rbApagou) ws_atu_log('Pedido de reinício antigo (mais de 10 min) ignorado.');
}

$pedidoArq = WS_CACHE . '/atualizar_pedido.json';
$pedido = is_file($pedidoArq) ? (json_decode((string)@file_get_contents($pedidoArq), true) ?: []) : [];
$c = ws_atu_cfg(); $acao = '';
if (!empty($pedido['acao']) && in_array($pedido['acao'], ['atualizar', 'voltar', 'linux', 'tudo'], true)) { $acao = $pedido['acao']; @unlink($pedidoArq); }
elseif (!empty($c['auto']) && date('H:i') === (string)$c['hora'] && date('Y-m-d') !== (string)($c['ultimo_auto'] ?? '')) { $acao = 'auto'; ws_atu_salvar(['ultimo_auto' => date('Y-m-d')]); }
if ($acao === '') exit(0);
if ($acao === 'atualizar' || $acao === 'auto') ws_atu_estado('Verificando a versão do WellSystem…', 10);

$aplicar = __DIR__ . '/ws-atualizar-aplicar.sh';
if ($acao === 'linux' || $acao === 'tudo') {   // Linux e pacotes do sistema (apt), sem perguntas
    ws_atu_log('atualizando o Linux e os pacotes (apt)…');
    ws_atu_estado('Atualizando a lista de pacotes do Linux…', 10);
    @exec('[ -f /usr/local/sbin/ws-apt-fonte.sh ] && bash /usr/local/sbin/ws-apt-fonte.sh 2>&1');   // garante a fonte online do Debian
    $out = []; exec('DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>&1', $out, $rc);
    /* 21/10/2026: o apt só RECARREGA o Apache quando o PHP é atualizado — o módulo antigo fica na memória com as extensões novas e o banco deixa de abrir
       ("Não consegui abrir o banco de dados"). Se a versão do PHP mudou, o Apache é REINICIADO ao fim. */
    $phpVer = function () { return trim((string)@shell_exec("dpkg-query -W -f='\${Package} \${Version}\\n' 'libapache2-mod-php*' 'php8*-cli' 'php8*-common' 2>/dev/null")); };
    $phpAntes = $phpVer();
    /* 23/10/2026: "upgrade" nunca instala o KERNEL novo do Debian (o pacote muda de nome e fica "mantido para trás") — correção de segurança do kernel ficava de fora. "full-upgrade --no-remove" instala os pacotes
       novos e ABORTA se algo precisar ser removido (nunca remove nada). O kernel novo só vale depois de REINICIAR o servidor (isso o botão não faz). */
    if ($rc === 0) { ws_atu_estado('Atualizando o Linux e os pacotes (pode levar vários minutos)…', 25); $out = []; exec('DEBIAN_FRONTEND=noninteractive apt-get -y -qq -o Dpkg::Options::=--force-confold --no-remove full-upgrade 2>&1', $out, $rc); }
    if ($rc === 0 && $phpAntes !== '' && $phpVer() !== $phpAntes) { @exec('systemctl restart apache2 2>&1'); ws_atu_log('PHP atualizado pelo Linux: Apache reiniciado.'); }
    ws_atu_log($rc === 0 ? 'Linux e pacotes atualizados.' : 'FALHA ao atualizar o Linux: ' . mb_substr(implode(' ', array_slice($out, -2)), 0, 200));
    if ($acao === 'linux') { ws_atu_estado($rc === 0 ? 'Linux e pacotes atualizados.' : 'Falhou ao atualizar o Linux — veja o histórico.', 100, false); exit($rc); }
    ws_atu_estado('Linux atualizado. Verificando a versão do WellSystem…', 55);
    $acao = 'atualizar';
}
if ($acao === 'voltar') {
    ws_atu_log('voltando à versão anterior (pedido pela tela)…');
    ws_atu_estado('Voltando à versão anterior…', 40); $out = []; exec('bash ' . escapeshellarg($aplicar) . ' --voltar 2>&1', $out, $rc); ws_atu_estado($rc === 0 ? 'Versão anterior restaurada.' : 'Falhou ao voltar a versão.', 100, false);
    ws_atu_log($rc === 0 ? 'versão anterior restaurada: ' . ws_atu_versao() : 'FALHA ao voltar: ' . mb_substr(implode(' ', array_slice($out, -2)), 0, 200));
    exit($rc);
}
$u = ws_atu_ultima();
if (!$u['ok']) { ws_atu_log('verificação: ' . $u['msg']); ws_atu_estado('Não foi possível verificar: ' . $u['msg'], 100, false); exit(0); }
if (!ws_atu_mais_nova($u['versao'], ws_atu_versao())) { if ($acao === 'atualizar') ws_atu_log('já está na versão mais nova (' . ws_atu_versao() . ').'); ws_atu_estado('Já está na versão mais nova (' . ws_atu_versao() . ').', 100, false); exit(0); }
ws_atu_log("baixando a versão {$u['versao']} (instalada: " . ws_atu_versao() . ')…');
ws_atu_estado("Baixando a versão {$u['versao']}…", 65);
[$tar, $erro] = ws_atu_baixar($u, sys_get_temp_dir() . '/wellsystem-atu-' . getmypid());
if ($tar === '') { ws_atu_log('NÃO atualizado: ' . $erro); ws_atu_estado('Não atualizado: ' . $erro, 100, false); exit(1); }
ws_atu_estado('Aplicando a atualização (cópia de segurança, instalação e conferência)…', 80);
$out = []; exec('bash ' . escapeshellarg($aplicar) . ' ' . escapeshellarg($tar) . ' ' . escapeshellarg($u['versao']) . ' 2>&1', $out, $rc);
@unlink($tar); @rmdir(dirname($tar));
ws_atu_estado($rc === 0 ? "Atualizado para a versão {$u['versao']}." : 'Falhou e voltou à versão anterior — veja o histórico.', 100, false);
ws_atu_log($rc === 0 ? "atualizado para a versão {$u['versao']}." : "FALHOU e voltou à versão anterior: " . mb_substr(implode(' ', array_slice($out, -3)), 0, 240));
exit($rc);
