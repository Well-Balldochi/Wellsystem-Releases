<?php
/**
 * WellSystem ERP — Backup do banco (baixar, enviar por e-mail, agendar diário). Admin.
 */
require __DIR__ . '/config.php';
require_once __DIR__ . '/backup_lib.php';
require_once __DIR__ . '/mailer.php';
if (empty($_SESSION['ws_user'])) { header('Location: erp.php'); exit; }
$admin = ($_SESSION['ws_user']['nivel'] ?? '') === 'admin';
$h  = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$user = $_SESSION['ws_user']['nome'] ?? '';
if (!$admin) { http_response_code(403); echo '<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;max-width:560px;margin:60px auto;padding:0 16px"><h2>Acesso restrito</h2><p>Backup é exclusivo para administradores.</p><p><a href="erp.php?p=dashboard">← Início</a></p></body>'; exit; }
$db = ws_db();
$flash = '';

// Baixar agora (download direto)
if (($_GET['baixar'] ?? '') === '1') {
    $sql = ws_backup_sql($db);
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="wellsystem-backup-' . date('Ymd-His') . '.sql"');
    echo $sql; exit;
}
// BACKUP COMPLETO (ZIP): TUDO — todos os arquivos do addon (código, css, js, img, uploads),
// a config persistente (cache/*.json), o dump do banco (banco.sql) e um LEIAME de restauração.
// Serve pra subir numa OUTRA instalação sem dor de cabeça.
if (($_GET['completo'] ?? '') === '1') {
    if (!class_exists('ZipArchive')) { $_SESSION['ws_flash'] = '❌ A extensão ZipArchive não está habilitada neste PHP — não dá pra gerar o ZIP completo.'; header('Location: backup.php?t=lista'); exit; }
    @set_time_limit(0); @ini_set('memory_limit', '512M');
    $tmpDir = is_writable(WS_CACHE) ? WS_CACHE : sys_get_temp_dir();
    $tmp = $tmpDir . '/wellsystem-completo-' . date('Ymd-His') . '.zip';
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { $_SESSION['ws_flash'] = '❌ Não consegui criar o arquivo ZIP (permissão da pasta temporária).'; header('Location: backup.php?t=lista'); exit; }
    $base = realpath(WS_DIR);
    // Pastas que NÃO entram (evita recursão do próprio backup e lixo).
    $excluir = ['/backups', '/cache_trafego', '/.git', '/node_modules'];
    try {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($it as $f) {
            $abs = $f->getPathname(); $rel = str_replace('\\', '/', substr($abs, strlen($base) + 1));
            $pula = false; foreach ($excluir as $e) { if (strpos('/' . $rel, $e . '/') === 0 || '/' . $rel === $e) { $pula = true; break; } }
            if ($pula) continue;
            if ($f->isDir()) $zip->addEmptyDir($rel); else @$zip->addFile($abs, $rel);
        }
    } catch (Throwable $e) {}
    // Config persistente (pode estar em /var/tmp) → vai pra cache/ do zip pra restaurar idêntico.
    foreach (glob(WS_CACHE . '/*.json') ?: [] as $cf) @$zip->addFile($cf, 'cache/' . basename($cf));
    // Dump do banco + instruções de restauração.
    $zip->addFromString('banco.sql', ws_backup_sql($db));
    $zip->addFromString('LEIAME-RESTAURAR.txt',
        "WellSystem — BACKUP COMPLETO\nGerado em: " . date('d/m/Y H:i:s') . "\n\n"
        . "COMO RESTAURAR EM OUTRA INSTALACAO:\n"
        . "1) Suba TODOS os arquivos deste zip para a pasta do addon (ex.: /opt/mk-auth/admin/addons/wellsystem_crm/).\n"
        . "2) Importe o banco.sql no MySQL/MariaDB (o banco 'wellsystem').\n"
        . "3) Copie a pasta cache/ (config) para a cache/ do addon — ou deixe o sistema recriar sozinho.\n"
        . "4) Abra ws_reset_cache.php uma vez e recarregue.\n");
    $zip->close();
    if (!is_file($tmp)) { $_SESSION['ws_flash'] = '❌ Falha ao montar o ZIP completo.'; header('Location: backup.php?t=lista'); exit; }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($tmp) . '"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp); @unlink($tmp); exit;
}
// Salvar agendamento
if (($_POST['acao'] ?? '') === 'salvar_agenda') {
    $ok = ws_backup_salvar(['ativo' => isset($_POST['ativo']) ? 1 : 0, 'hora' => preg_match('/^\d{2}:\d{2}$/', $_POST['hora'] ?? '') ? $_POST['hora'] : '03:00', 'email' => trim($_POST['email'] ?? '')]);
    if ($ok) { header('Location: backup.php?t=agenda&ok=1'); exit; }
    $_SESSION['ws_flash'] = '❌ Não consegui gravar o agendamento — a pasta "cache/" não tem permissão de escrita para o PHP neste servidor' . ws_diag_permissao(WS_CACHE) . '. Ajuste com chmod/chown (ex.: chmod 775 cache) e tente salvar de novo.';
    header('Location: backup.php?t=agenda'); exit;
}
// Salvar SMTP
if (($_POST['acao'] ?? '') === 'salvar_smtp') {
    $ok = ws_smtp_salvar(['smtp_host' => trim($_POST['smtp_host'] ?? ''), 'smtp_port' => (int)($_POST['smtp_port'] ?? 587),
        'smtp_seg' => in_array($_POST['smtp_seg'] ?? 'tls', ['ssl','tls','none'], true) ? $_POST['smtp_seg'] : 'tls',
        'smtp_user' => trim($_POST['smtp_user'] ?? ''), 'smtp_pass' => (string)($_POST['smtp_pass'] ?? ''), 'smtp_from' => trim($_POST['smtp_from'] ?? '')]);
    if ($ok) { header('Location: backup.php?t=smtp&ok=1'); exit; }
    $_SESSION['ws_flash'] = '❌ Não consegui gravar as configurações de SMTP — a pasta "cache/" não tem permissão de escrita para o PHP neste servidor' . ws_diag_permissao(WS_CACHE) . '.';
    header('Location: backup.php?t=smtp'); exit;
}
// Enviar por e-mail agora (compat)
if (($_POST['acao'] ?? '') === 'enviar') {
    [$ok, $msg] = ws_backup_enviar($db, trim($_POST['email'] ?? ''));
    $_SESSION['ws_flash'] = ($ok ? '✅ ' : '❌ ') . $msg; header('Location: backup.php?t=lista'); exit;
}
// Gerar e SALVAR um backup na pasta
if (($_GET['gerar'] ?? '') === '1') {
    try { $p = ws_backup_gravar($db); $_SESSION['ws_flash'] = '✅ Backup gerado: ' . basename($p) . ' (' . ws_fmt_tamanho(filesize($p)) . ').'; }
    catch (Throwable $e) { $_SESSION['ws_flash'] = '❌ ' . $e->getMessage(); }
    header('Location: backup.php?t=lista'); exit;
}
// Excluir um backup salvo
if (isset($_GET['del'])) { if (!ws_pode_deletar()) { header('Location: backup.php?t=lista'); exit; } $p = WS_BACKUP_DIR . '/' . basename($_GET['del']); if (is_file($p)) @unlink($p); header('Location: backup.php?t=lista'); exit; }
// Baixar um backup salvo
if (isset($_GET['file'])) { $p = WS_BACKUP_DIR . '/' . basename($_GET['file']); if (is_file($p)) { header('Content-Type: application/sql'); header('Content-Disposition: attachment; filename="' . basename($p) . '"'); readfile($p); } exit; }
// Restaurar um backup salvo (importa o .sql de volta ao banco)
if (($_GET['restaurar'] ?? '') !== '') {
    if (!$admin) { http_response_code(403); exit; }
    $arq = basename($_GET['restaurar']);
    $p = WS_BACKUP_DIR . '/' . $arq;
    if (!is_file($p) || !str_ends_with($arq, '.sql')) { $_SESSION['ws_flash'] = '❌ Arquivo de backup não encontrado ou inválido.'; header('Location: backup.php?t=lista'); exit; }
    if (!isset($_GET['confirm'])) {
        // Tela de confirmação
        echo '<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><title>Confirmar restauração</title>';
        echo '<link rel="stylesheet" href="css/wellsystem.css?v=' . ws_ver('css/wellsystem.css') . '"></head><body>';
        echo '<header class="ws-top-wrap">' . ws_topo_completo('config') . '</header><main class="ws-main">';
        echo '<div class="ws-panel" style="border-color:var(--err);max-width:600px;margin:40px auto">';
        echo '<h3>⚠️ Confirmar restauração do banco</h3>';
        echo '<p>Você está prestes a restaurar o backup:</p><p><code>' . htmlspecialchars($arq) . '</code></p>';
        echo '<div class="ws-alert err" style="margin:12px 0"><b>ATENÇÃO:</b> Esta ação irá SUBSTITUIR todos os dados atuais do banco pelo conteúdo do backup selecionado. Esta operação <b>não pode ser desfeita</b>.</div>';
        echo '<p>Recomendamos gerar um backup do estado atual antes de continuar.</p>';
        echo '<div style="display:flex;gap:10px;margin-top:16px">';
        echo '<a class="ws-btn" href="backup.php?t=lista">← Cancelar (voltar)</a>';
        echo '<a class="ws-btn verde" href="backup.php?gerar=1&_redir=' . urlencode('backup.php?restaurar=' . rawurlencode($arq) . '&confirm=1') . '">💾 Gerar backup atual e depois restaurar</a>';
        echo '<a class="ws-btn" style="background:var(--err);color:#fff" href="backup.php?restaurar=' . rawurlencode($arq) . '&confirm=1">⚠️ Restaurar agora (sem salvar)</a>';
        echo '</div></div></main></body></html>';
        exit;
    }
    // Executa a restauração
    try {
        // Lê em blocos de 1 MB (backup de centenas de MB não cabe na memória do PHP) e executa cada instrução ao fechar com ";\n".
        @set_time_limit(0); @ini_set('memory_limit', '512M');
        $fh = @fopen($p, 'rb');
        if (!$fh) throw new RuntimeException('Não foi possível ler o arquivo de backup.');
        $db->exec('SET FOREIGN_KEY_CHECKS=0');
        $buf = '';
        while (true) {
            $chunk = fread($fh, 1048576);
            $fim = ($chunk === false || $chunk === '');
            $buf .= (string)$chunk;
            $partes = explode(";\n", $buf);
            $buf = $fim ? '' : array_pop($partes);
            foreach ($partes as $stmt) {
                $stmt = trim($stmt);
                if ($stmt !== '' && !str_starts_with($stmt, '--')) { try { $db->exec($stmt . ';'); } catch (Throwable $ei) {} }
            }
            unset($partes);
            if ($fim) break;
        }
        fclose($fh);
        $db->exec('SET FOREIGN_KEY_CHECKS=1');
        // Configurações + logo que vieram no .sql (regras de cobrança, mensagens, provedor...).
        $nCfg = ws_backup_config_restaurar($db);
        /* Restauração NÃO dispara aviso: o status dos contratos mudou de uma vez e o cron leria isso como bloqueio/liberação de cliente (já mandou "ONLINE" a clientes reais). Esquece o estado antigo e zera a fila: a 1ª passada só tira a foto. */
        foreach (["msg_estado_bloqueio.json", "msg_eventos_fila.json", "msg_eventos_enviados.json"] as $arqMsg) @unlink(WS_CACHE . "/" . $arqMsg);
        @unlink(WS_CACHE . '/nas_freeradius.hash');   // a lista de concentradores (NAS) veio no backup: o FreeRADIUS a relê em até 1 min (rotina do root)
        /* "Restaurar com segurança" (Manutenção): deixa o envio de WhatsApp PAUSADO depois de restaurar — servidor de teste não pode mandar mensagem a cliente real. */
        if (!empty($_GET['pausar']) && is_file(__DIR__ . '/whatsapp.php')) {
            require_once __DIR__ . '/whatsapp.php';
            $waP = ws_wa_config(); $autoP = WS_CACHE . '/msg_auto.json'; $aj = is_file($autoP) ? (json_decode((string)@file_get_contents($autoP), true) ?: []) : [];
            $antesP = (string)($waP['gateway'] ?? 'evolution'); if ($antesP === 'desativado') $antesP = (string)($waP['gateway_antes'] ?? 'evolution');
            ws_wa_salvar(['gateway_antes' => $antesP, 'gateway' => 'desativado']);
            $aj['ativo_antes'] = (int)($aj['ativo'] ?? 1) ?: (int)($aj['ativo_antes'] ?? 1); $aj['ativo'] = 0;
            @file_put_contents($autoP, json_encode($aj)); @chmod($autoP, 0640);
        }
        /* Sistema "igual ao de antes" já na hora (30/09/2026): colunas/tabelas novas desta versão (backup de versão
           anterior) e o RADIUS reconstruído a partir dos clientes restaurados — sem esperar o cron de 2 min. */
        try { ws_selfheal($db); } catch (Throwable $e) {}
        $nRad = 0;
        if (is_file(__DIR__ . '/radius_lib.php')) { require_once __DIR__ . '/radius_lib.php'; try { $rr = ws_rad_sync_tudo($db); $nRad = (int)($rr['contratos'] ?? $rr['total'] ?? 0); } catch (Throwable $e) {} }
        $_SESSION['ws_flash'] = '✅ Banco restaurado com sucesso a partir do backup: ' . $arq
            . ($nCfg ? " — e $nCfg arquivo(s) de configuração, fotos, documentos e modelos." : ' (backup sem configurações — só o banco).')
            . ' RADIUS sincronizado com os clientes restaurados.';
    } catch (Throwable $e) {
        $_SESSION['ws_flash'] = '❌ Falha ao restaurar: ' . $e->getMessage();
    }
    header('Location: backup.php?t=lista'); exit;
}
// Upload de backup externo (.sql) para restaurar
if (($_POST['acao'] ?? '') === 'upload_restaurar') {
    if (!$admin) { http_response_code(403); exit; }
    $f = $_FILES['arquivo_sql'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) { $_SESSION['ws_flash'] = '❌ Erro no upload do arquivo. Verifique o tamanho máximo permitido.'; header('Location: backup.php?t=lista'); exit; }
    $nomeUp = strtolower($f['name']);
    if (!preg_match('/\.(sql|sql\.gz|sql\.xz|xz|wsbk)$/', $nomeUp)) { $_SESSION['ws_flash'] = '❌ Envie um arquivo .sql, .sql.gz, .sql.xz ou .wsbk (backup criptografado).'; header('Location: backup.php?t=lista'); exit; }
    // .xz (o backup que chega por e-mail, ~4x menor que o .gz): descompacta direto para a pasta de backups (17/10/2026)
    if (preg_match('/\.xz$/', $nomeUp)) {
        $dest = WS_BACKUP_DIR . '/upload-' . date('Ymd-His') . '-' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', preg_replace('/\.(sql\.xz|xz|sql)$/i', '', basename($f['name']))) . '.sql';
        if (!ws_backup_xz_abrir($f['tmp_name'], $dest)) { $_SESSION['ws_flash'] = '❌ Não consegui abrir o .xz (o servidor precisa do comando xz, pacote xz-utils). Descompacte no seu computador (7-Zip) e envie o .sql.'; header('Location: backup.php?t=lista'); exit; }
        if (strpos((string)file_get_contents($dest, false, null, 0, 400), 'WellSystem') === false) { @unlink($dest); $_SESSION['ws_flash'] = '❌ O arquivo não é um backup do WellSystem.'; header('Location: backup.php?t=lista'); exit; }
        $_SESSION['ws_flash'] = '✅ Backup aberto e salvo: ' . basename($dest) . ' — clique em "Restaurar" para aplicá-lo.'; header('Location: backup.php?t=lista'); exit;
    }
    // Backup externo: .wsbk (cifrado) é aberto com a senha; .gz é descompactado — na pasta fica sempre o .sql.
    if (preg_match('/\.(gz|wsbk)$/', $nomeUp)) {
        $bin = (string)@file_get_contents($f['tmp_name']);
        if (substr($nomeUp, -5) === '.wsbk') { $bin = ws_backup_decifrar($bin, (string)($_POST['senha_backup'] ?? ''));
            if ($bin === null) { $_SESSION['ws_flash'] = '❌ Senha de criptografia incorreta (ou arquivo corrompido).'; header('Location: backup.php?t=lista'); exit; } }
        if (strncmp($bin, "\x1f\x8b", 2) === 0) $bin = (string)@gzdecode($bin);
        if ($bin === '' || strpos(substr($bin, 0, 400), 'WellSystem') === false) { $_SESSION['ws_flash'] = '❌ O arquivo não é um backup do WellSystem.'; header('Location: backup.php?t=lista'); exit; }
        $dest = WS_BACKUP_DIR . '/upload-' . date('Ymd-His') . '-' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', preg_replace('/\.(sql\.gz|sql|wsbk|gz)$/i', '', basename($f['name']))) . '.sql';
        if (@file_put_contents($dest, $bin) === false) { $_SESSION['ws_flash'] = '❌ Não foi possível gravar na pasta de backups.'; header('Location: backup.php?t=lista'); exit; }
        $_SESSION['ws_flash'] = '✅ Backup aberto e salvo: ' . basename($dest) . ' — clique em "Restaurar" para aplicá-lo.'; header('Location: backup.php?t=lista'); exit;
    }
    // Salva o arquivo enviado na pasta de backups
    $dest = WS_BACKUP_DIR . '/upload-' . date('Ymd-His') . '-' . preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', basename($f['name']));
    if (!ws_mover_upload($f['tmp_name'], $dest)) { $_SESSION['ws_flash'] = '❌ Não foi possível mover o arquivo enviado (permissão na pasta de backups?).'; header('Location: backup.php?t=lista'); exit; }
    $_SESSION['ws_flash'] = '✅ Backup enviado com sucesso: ' . basename($dest) . ' — clique em "Restaurar" para aplicá-lo.';
    header('Location: backup.php?t=lista'); exit;
}
// Enviar backups selecionados para TODOS os destinos configurados
/* EXCLUIR SELECIONADOS — os backups marcados na lista. Mesma permissão do "excluir" de um só (ws_pode_deletar).
   Só apaga arquivo .sql de DENTRO da pasta de backups (basename + extensão conferidos): nome adulterado não sai dela. */
if (isset($_POST['excluir_sel'])) {
    if (!ws_pode_deletar()) { $_SESSION['ws_flash'] = '❌ Seu nível de acesso não permite excluir backup.'; header('Location: backup.php?t=lista'); exit; }
    $n = 0;
    foreach ((array)($_POST['arqs'] ?? []) as $arq) {
        $b = basename((string)$arq);
        if ($b === '' || strtolower(pathinfo($b, PATHINFO_EXTENSION)) !== 'sql') continue;
        $p = WS_BACKUP_DIR . '/' . $b;
        if (is_file($p) && @unlink($p)) $n++;
    }
    $_SESSION['ws_flash'] = $n ? "🗑️ $n backup(s) excluído(s)." : 'Nenhum backup marcado.';
    header('Location: backup.php?t=lista'); exit;
}
if (($_POST['acao'] ?? '') === 'enviar_sel') {
    $arqs = (array)($_POST['arqs'] ?? []);
    if (empty($arqs)) { try { $arqs = [basename(ws_backup_gravar($db))]; } catch (Throwable $e) { $_SESSION['ws_flash'] = '❌ ' . $e->getMessage(); header('Location: backup.php?t=lista'); exit; } }
    $linhas = [];
    foreach ($arqs as $a) { $r = ws_backup_enviar_arquivo(WS_BACKUP_DIR . '/' . basename($a)); $linhas[] = basename($a) . ': ' . implode(', ', array_map(fn($k, $v) => "$k=$v", array_keys($r), $r)); }
    $_SESSION['ws_flash'] = 'Envio: ' . implode(' | ', $linhas); header('Location: backup.php?t=lista'); exit;
}
// TESTE DE RESTAURAÇÃO agora (roda em segundo plano — o banco temporário leva alguns minutos). Ver ws_backup_teste_restaurar().
if (($_POST['acao'] ?? '') === 'teste_restauracao' && $admin) {
    $php = is_file(PHP_BINDIR . '/php') ? PHP_BINDIR . '/php' : 'php';
    @exec('nohup ' . escapeshellarg($php) . ' ' . escapeshellarg(__DIR__ . '/backup_teste_run.php') . ' > /dev/null 2>&1 &');
    $_SESSION['ws_flash'] = '🧪 Teste de restauração iniciado — o resultado aparece aqui em alguns minutos.'; header('Location: backup.php?t=lista'); exit;
}
// Salvar destinos
if (($_POST['acao'] ?? '') === 'salvar_dest') {
    $ok = ws_backup_dest_salvar([
        'email' => trim($_POST['d_email'] ?? ''), 'whatsapp' => trim($_POST['d_whatsapp'] ?? ''),
        'tg_token' => trim($_POST['d_tg_token'] ?? ''), 'tg_chat' => trim($_POST['d_tg_chat'] ?? ''),
        'ftp_host' => trim($_POST['d_ftp_host'] ?? ''), 'ftp_user' => trim($_POST['d_ftp_user'] ?? ''),
        'ftp_pass' => (string)($_POST['d_ftp_pass'] ?? ''), 'ftp_path' => trim($_POST['d_ftp_path'] ?? '/'), 'ftp_path_olt' => trim($_POST['d_ftp_path_olt'] ?? ''),
        'mega_user' => trim($_POST['d_mega_user'] ?? ''), 'mega_pass' => (string)($_POST['d_mega_pass'] ?? ''),
        'on_email' => !empty($_POST['on_email']) ? 1 : 0, 'on_whatsapp' => !empty($_POST['on_whatsapp']) ? 1 : 0,
        'on_telegram' => !empty($_POST['on_telegram']) ? 1 : 0, 'on_ftp' => !empty($_POST['on_ftp']) ? 1 : 0,
        'on_mega' => !empty($_POST['on_mega']) ? 1 : 0,
        // Senha de criptografia: vazio mantém a atual; "apagar" desliga (backup externo volta a sair sem cifra).
        'cripto_senha' => !empty($_POST['d_cripto_apagar']) ? '' : ((string)($_POST['d_cripto_senha'] ?? '') !== '' ? (string)$_POST['d_cripto_senha'] : (string)(ws_backup_dest_config()['cripto_senha'] ?? '')),
    ]);
    if ($ok) { header('Location: backup.php?t=destinos&ok=1'); exit; }
    $_SESSION['ws_flash'] = '❌ Não consegui gravar os destinos de envio — a pasta "cache/" não tem permissão de escrita para o PHP neste servidor' . ws_diag_permissao(WS_CACHE) . '.';
    header('Location: backup.php?t=destinos'); exit;
}
if (!empty($_SESSION['ws_flash'])) { $flash = $_SESSION['ws_flash']; unset($_SESSION['ws_flash']); }

$cfg = ws_backup_config(); $smtp = ws_smtp_config(); $dest = ws_backup_dest_config(); $lista = ws_backup_lista();
$ultimo = is_file(WS_CACHE . '/backup_ultimo.txt') ? trim((string)file_get_contents(WS_CACHE . '/backup_ultimo.txt')) : '';
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>WellSystem — Backup</title>
<link rel="stylesheet" href="css/wellsystem.css?v=<?= ws_ver('css/wellsystem.css') ?>"></head><body>
<header class="ws-top-wrap"><?= ws_topo_completo('config') ?></header>
<main class="ws-main">
<?php if (isset($_GET['ok'])): ?><div class="ws-alert ok">Salvo.</div><?php endif; ?>
<?php if ($flash): $erro = str_starts_with($flash, '❌'); ?><div class="ws-alert <?= $erro?'err':'ok' ?>"><?= $h($flash) ?></div><?php endif; ?>

<div class="ws-head-row"><h2>Backup do banco <span class="ws-tag bloqueado" style="font-size:11px">admin</span></h2>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="ws-btn primary" href="backup.php?gerar=1">💾 Gerar backup agora</a>
    <a class="ws-btn" href="backup.php?baixar=1">⬇️ Baixar banco (.sql)</a>
    <a class="ws-btn" href="backup.php?completo=1" title="ZIP com TODOS os arquivos + banco + config + LEIAME — pronto pra subir em outra instalação" onclick="this.style.opacity=.6;this.textContent='⏳ Montando ZIP…';">📦 Backup COMPLETO (arquivos + banco)</a>
  </div></div>

<?php $abaB = $_GET['t'] ?? 'agenda';
$numPendentes = count($_SESSION['ws_import_dups'] ?? []); ?>
<div class="ws-search">
  <a class="ws-btn <?= $abaB==='agenda'?'primary':'' ?>" href="backup.php?t=agenda">⏰ Agendamento</a>
  <a class="ws-btn <?= $abaB==='lista'?'primary':'' ?>" href="backup.php?t=lista">🗂️ Backups salvos (<?= count($lista) ?>)</a>
  <a class="ws-btn <?= $abaB==='destinos'?'primary':'' ?>" href="backup.php?t=destinos">📨 Destinos de envio</a>
  <a class="ws-btn <?= $abaB==='smtp'?'primary':'' ?>" href="backup.php?t=smtp">✉️ Servidor de e-mail (SMTP)</a>
  <a class="ws-btn" href="importar.php" style="margin-left:auto">🛠️ Correção de Cadastros <?= $numPendentes > 0 ? "<span class='ws-badge-erro' style='margin-left:4px'>$numPendentes pendente(s)</span>" : "" ?></a>
</div>

<?php if ($abaB === 'agenda'): ?>
<div class="ws-panel" style="border-color:<?= $cfg['ativo']?'var(--ok)':'var(--err)' ?>">
  <h3><?= $cfg['ativo'] ? '✅ Backup automático diário ATIVO' : '⚠️ Backup automático diário DESATIVADO' ?></h3>
  <p class="ws-muted" style="font-size:13px">
    Todo dia, no horário marcado, o sistema gera um backup novo, <b>salva na aba "Backups salvos"</b> e <b>envia para todos os destinos configurados</b> (e-mail/WhatsApp/Telegram/FTP) — é o mesmo processo, de ponta a ponta. Roda junto do cron <code>radius_sync.php</code> (sem precisar de outro cron separado).
  </p>
  <?php if ($ultimo): ?><p class="ws-muted">Último backup automático enviado: <b><?= $h($ultimo) ?></b></p>
  <?php else: ?><p class="ws-muted">Ainda não rodou automaticamente hoje — assim que o cron passar do horário marcado, roda sozinho.</p><?php endif; ?>
  <?php $diagB = WS_CACHE . '/backup_ag_diag.txt'; if (is_file($diagB)): ?>
  <p class="ws-muted" style="font-size:12.5px">🔎 Última passada do cron: <b><?= $h(trim((string)@file_get_contents($diagB))) ?></b></p>
  <?php endif; ?>
  <form method="post" class="ws-form grid" style="margin-top:6px">
    <input type="hidden" name="acao" value="salvar_agenda">
    <label class="c4"><input type="checkbox" name="ativo" <?= $cfg['ativo'] ? 'checked' : '' ?>> Ativar backup automático diário (padrão: ativado)</label>
    <label>Horário <input type="time" name="hora" value="<?= $h($cfg['hora']) ?>"></label>
    <label class="c2">E-mail de destino (opcional, além dos "Destinos de envio") <input type="email" name="email" value="<?= $h($cfg['email']) ?>" placeholder="voce@email.com"></label>
    <div class="c4"><button class="ws-btn verde">Salvar agendamento</button></div>
  </form>
</div>
<?php
  // Item 5: log das últimas tentativas automáticas (email/whatsapp/telegram/ftp, sucesso ou falha por
  // canal) — antes só existia dentro de cache/backup.log, sem tela nenhuma pra ver sem entrar no
  // servidor. Mostra as últimas 10 linhas, mais recente primeiro.
  $logP = WS_CACHE . '/backup.log';
  $logLinhas = is_file($logP) ? array_filter(array_map('trim', file($logP) ?: [])) : [];
  $logLinhas = array_slice(array_reverse($logLinhas), 0, 10);
?>
<div class="ws-panel" style="margin-top:16px">
  <h3>📜 Últimas tentativas automáticas</h3>
  <?php if (!$logLinhas): ?>
    <p class="ws-muted" style="font-size:13px">Nenhuma tentativa registrada ainda.</p>
  <?php else: ?>
    <div style="overflow-x:auto"><pre style="font-size:12px;white-space:pre-wrap;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;margin:0"><?php
      foreach ($logLinhas as $ln) echo $h($ln) . "\n";
    ?></pre></div>
    <p class="ws-muted" style="font-size:12px;margin-top:8px">💡 "ok, MAS SEM O ARQUIVO" no WhatsApp = chegou só o aviso, porque a janela de 24h do número oficial estava fechada; mande uma mensagem para o número oficial e envie de novo. "aviso_marca" = o backup foi reenviado sem parar naquele dia por falta de permissão de escrita em cache/.</p>
  <?php endif; ?>
</div>

<?php elseif ($abaB === 'lista'): ?>
<div class="ws-panel">
  <h3>Backups salvos — gerados automaticamente todo dia no horário agendado, ou manualmente em "Gerar backup agora" (<?= count($lista) ?>)</h3>
  <form method="post"><input type="hidden" name="acao" value="enviar_sel">
    <div style="overflow-x:auto"><table class="ws-table"><thead><tr>
      <th class="sel"><input type="checkbox" onclick="document.querySelectorAll('.bkchk').forEach(e=>e.checked=this.checked)"></th>
      <th>Arquivo</th><th>Tamanho</th><th>Data</th><th>Ações</th>
    </tr></thead><tbody>
    <?php foreach ($lista as $a): $n=basename($a); ?>
      <tr><td class="sel"><input type="checkbox" class="bkchk" name="arqs[]" value="<?= $h($n) ?>"></td>
      <td><code><?= $h($n) ?></code></td><td><?= ws_fmt_tamanho(filesize($a)) ?></td>
      <td><?= date('d/m/Y H:i', filemtime($a)) ?></td>
      <td><div class="ws-acoes"><a href="backup.php?file=<?= rawurlencode($n) ?>">⬇️ baixar</a>
        <a href="backup.php?restaurar=<?= rawurlencode($n) ?>" style="color:var(--ok)">🔄 restaurar</a>
        <a href="backup.php?del=<?= rawurlencode($n) ?>" onclick="return confirm('Excluir este backup?')" style="color:var(--err)">🗑️ excluir</a></div></td></tr>
    <?php endforeach; if(!$lista) echo '<tr><td colspan="5" class="ws-muted">Nenhum backup salvo ainda. Ative o agendamento na aba "Agendamento" ou clique em "Gerar backup agora".</td></tr>'; ?>
    </tbody></table></div>
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button class="ws-btn verde">📤 Enviar selecionados (ou gera 1 novo) para os destinos</button>
      <button type="submit" name="excluir_sel" value="1" class="ws-btn danger" onclick="var n=document.querySelectorAll('.bkchk:checked').length; if(!n){ alert('Marque ao menos um backup para excluir.'); return false; } return confirm('Excluir ' + n + ' backup(s) marcado(s)? Esta ação não pode ser desfeita.');">🗑️ Excluir selecionados</button></div>
  </form>

  <div class="ws-panel" style="margin-top:18px;border-color:var(--ok)">
    <h3>📤 Subir backup de outra data (.sql, .sql.gz, .sql.xz ou .wsbk)</h3>
    <p class="ws-muted" style="font-size:13px">Envie um backup gerado por este sistema. O <code>.wsbk</code> é o backup <b>criptografado</b> que sai por e-mail/WhatsApp/Telegram/FTP: informe a senha de criptografia. Após o upload ele aparece na lista acima e você restaura em <b>🔄 restaurar</b>.</p>
    <form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px">
      <input type="hidden" name="acao" value="upload_restaurar">
      <input type="file" name="arquivo_sql" accept=".sql,.gz,.xz,.wsbk" required style="flex:1;min-width:200px;padding:6px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--text)">
      <input type="password" name="senha_backup" autocomplete="off" placeholder="senha (só para .wsbk)" style="max-width:200px">
      <button class="ws-btn verde" type="submit">⬆️ Enviar e adicionar à lista</button>
    </form>
  </div>
  <?php $bt = json_decode((string)@file_get_contents(WS_CACHE . '/backup_teste.json'), true) ?: []; ?>
  <div class="ws-panel" style="margin-top:18px">
    <h3>🧪 Teste de restauração</h3>
    <p class="ws-muted" style="font-size:13px">Toda semana o último backup é <b>restaurado num banco temporário</b>, conferido contra o banco em uso (clientes, contratos, faturas, pagamentos, planos, operadores) e apagado. Garante que o backup realmente volta quando precisar. O banco em uso nunca é tocado.</p>
    <?php if ($bt): ?>
      <p style="font-size:13.5px"><?= !empty($bt['ok']) ? '🟢 <b>Último teste OK</b>' : '🔴 <b>Último teste FALHOU</b>' ?> — <?= date('d/m/Y H:i', (int)$bt['em']) ?> · <?= $h($bt['arquivo'] ?? '') ?><?= !empty($bt['segundos']) ? ' · ' . (int)$bt['segundos'] . ' s' : '' ?><?= !empty($bt['erro']) ? ' · ' . $h($bt['erro']) : '' ?></p>
      <?php if (!empty($bt['detalhes'])): ?><div class="ws-table-wrap"><table class="ws-table" style="max-width:560px"><thead><tr><th class="ws-th-esq">Tabela</th><th>No backup</th><th>Em uso</th><th></th></tr></thead><tbody>
        <?php foreach ($bt['detalhes'] as $tb => $dd): ?><tr><td class="ws-th-esq"><?= $h($tb) ?></td><td><?= (int)$dd['backup'] ?></td><td><?= (int)$dd['em_uso'] ?></td><td><?= !empty($dd['ok']) ? '✅' : '❌' ?></td></tr><?php endforeach; ?>
      </tbody></table></div><?php endif; ?>
    <?php else: ?><p class="ws-muted" style="font-size:13px">Ainda não testado.</p><?php endif; ?>
    <?php if ($admin): ?><form method="post" style="margin-top:8px"><input type="hidden" name="acao" value="teste_restauracao"><button class="ws-btn">🧪 Testar restauração agora</button></form><?php endif; ?>
  </div>
</div>

<?php elseif ($abaB === 'destinos'): ?>
<div class="ws-panel">
  <h3>Destinos de envio</h3>
  <p class="ws-muted" style="font-size:13px">Preencha os que quiser. Ao enviar, o backup vai para <b>todos</b> os destinos configurados.</p>
  <form method="post" class="ws-form grid">
    <input type="hidden" name="acao" value="salvar_dest">
    <label class="c2">📧 E-mail <span style="float:right;font-weight:600;font-size:12px"><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" name="on_email" value="1" style="width:auto" <?= ws_backup_canal_on($dest, 'email') ? 'checked' : '' ?>> enviar</label></span> <input name="d_email" value="<?= $h($dest['email']) ?>" placeholder="voce@email.com"></label>
    <label class="c2">📲 WhatsApp (nº) <span style="float:right;font-weight:600;font-size:12px"><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" name="on_whatsapp" value="1" style="width:auto" <?= ws_backup_canal_on($dest, 'whatsapp') ? 'checked' : '' ?>> enviar</label></span> <input name="d_whatsapp" value="<?= $h($dest['whatsapp']) ?>" placeholder="5581999999999"></label>
    <label class="c2">✈️ Telegram Bot Token <span style="float:right;font-weight:600;font-size:12px"><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" name="on_telegram" value="1" style="width:auto" <?= ws_backup_canal_on($dest, 'telegram') ? 'checked' : '' ?>> enviar</label></span> <input name="d_tg_token" value="<?= $h($dest['tg_token']) ?>" placeholder="123456:ABC..."></label>
    <label class="c2">✈️ Telegram Chat ID <input name="d_tg_chat" value="<?= $h($dest['tg_chat']) ?>"></label>
    <label>🗄️ FTP Host <span style="float:right;font-weight:600;font-size:12px"><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" name="on_ftp" value="1" style="width:auto" <?= ws_backup_canal_on($dest, 'ftp') ? 'checked' : '' ?>> enviar</label></span> <input name="d_ftp_host" value="<?= $h($dest['ftp_host']) ?>"></label>
    <label>FTP Usuário <input name="d_ftp_user" value="<?= $h($dest['ftp_user']) ?>"></label>
    <label>FTP Senha <input type="password" name="d_ftp_pass" value="<?= $h($dest['ftp_pass']) ?>"></label>
    <label>FTP Pasta <input name="d_ftp_path" value="<?= $h($dest['ftp_path']) ?>" placeholder="/backups"></label>
    <label>FTP Pasta da OLT <input name="d_ftp_path_olt" value="<?= $h($dest['ftp_path_olt'] ?? '') ?>" placeholder="/OLT"></label>
    <label>☁️ Mega usuário <span style="float:right;font-weight:600;font-size:12px"><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" name="on_mega" value="1" style="width:auto" <?= ws_backup_canal_on($dest, 'mega') ? 'checked' : '' ?>> enviar</label></span> <input name="d_mega_user" value="<?= $h($dest['mega_user']) ?>" placeholder="requer megatools"></label>
    <label>Mega senha <input type="password" name="d_mega_pass" value="<?= $h($dest['mega_pass']) ?>"></label>
    <?php $crOn = (string)($dest['cripto_senha'] ?? '') !== ''; ?>
    <label class="c2">🔐 Senha de criptografia do backup externo <input type="password" name="d_cripto_senha" autocomplete="new-password" minlength="8" placeholder="<?= $crOn ? 'definida — deixe vazio para manter' : 'mínimo 8 caracteres' ?>"></label>
    <div class="c2 ws-muted" style="font-size:12px;align-self:center"><?= $crOn ? '🟢 <b>Ligada</b>: tudo que sai do servidor vai cifrado (AES-256, arquivo .wsbk).' : '⚪ <b>Desligada</b>: o backup sai do servidor sem criptografia.' ?>
      <b>Guarde esta senha fora do sistema</b> — sem ela o backup externo não pode ser restaurado.
      <?php if ($crOn): ?><label style="display:inline-flex;gap:4px;align-items:center"><input type="checkbox" name="d_cripto_apagar" value="1" style="width:auto"> desligar</label><?php endif; ?></div>
    <div class="c4"><button class="ws-btn verde">Salvar destinos</button></div>
  </form>
</div>

<?php else: // smtp ?>
<div class="ws-panel">
  <h3>Servidor de e-mail (SMTP)</h3>
  <p class="ws-muted" style="font-size:13px">Usado pelo backup e por outros envios. Ex.: Gmail — host <code>smtp.gmail.com</code>, porta <code>587</code>, TLS, senha de app.</p>
  <form method="post" class="ws-form grid">
    <input type="hidden" name="acao" value="salvar_smtp">
    <label class="c2">Host <input name="smtp_host" value="<?= $h($smtp['smtp_host']) ?>" placeholder="smtp.gmail.com"></label>
    <label>Porta <input name="smtp_port" value="<?= $h($smtp['smtp_port']) ?>"></label>
    <label>Segurança <select name="smtp_seg">
      <?php foreach (['tls'=>'TLS (587)','ssl'=>'SSL (465)','none'=>'Nenhuma'] as $k=>$v) echo "<option value='$k' ".($smtp['smtp_seg']===$k?'selected':'').">$v</option>"; ?>
    </select></label>
    <label class="c2">Usuário <input name="smtp_user" value="<?= $h($smtp['smtp_user']) ?>" placeholder="voce@gmail.com"></label>
    <label class="c2">Senha <input type="password" id="smtp_pass" name="smtp_pass" value="<?= $h($smtp['smtp_pass']) ?>">
      <span style="font-size:12px;display:inline-flex;gap:5px;align-items:center;margin-top:4px"><input type="checkbox" onclick="var k=document.getElementById('smtp_pass');k.type=k.type==='password'?'text':'password'"> mostrar</span></label>
    <label class="c2">Remetente (From) <input name="smtp_from" value="<?= $h($smtp['smtp_from']) ?>" placeholder="voce@gmail.com"></label>
    <div class="c4"><button class="ws-btn verde">Salvar SMTP</button></div>
  </form>
</div>
<?php endif; ?>
</main>
<script src="js/wellsystem.js?v=<?= ws_ver('js/wellsystem.js') ?>"></script>
<?= ws_footer_bar() ?>
</body></html>