<?php
/**
 * WellSystem — REVISÃO DO ATENDIMENTO (02/11/2026, pedido do dono depois do caso Emilly Vitória).
 * Coleta as conversas do Chatwoot desde a última revisão e aponta, por categoria, o que saiu errado:
 *   cliente_reclamou   — cliente escreveu "não é meu", "errado", "outro nome"... (palavras de reclamação)
 *   boleto_outro_nome  — PDF de boleto anexado cujo nome não bate com o do contato da conversa
 *   menu_apos_obrigado — robô mandou o menu logo depois de "obrigado/ok"
 *   sem_quebra_de_linha— mensagem do robô longa, sem uma frase por linha (padrão do dono)
 *   sem_marcador       — mensagem do robô com vários blocos e nenhum marcador (✅ ℹ️ ⚠️ 🧾 🔒 🔓)
 * Grava o relatório em cache/atendimento_revisao.json e acumula cada achado em cache/atendimento_aprendizado.jsonl
 * (histórico para virar caso na teste_regressao.php). Só LÊ o Chatwoot — não envia nada a cliente.
 */
require_once __DIR__ . '/aviso_provedor_lib.php';

function ws_atend_revisar(int $desde = 0, int $maxPaginas = 40): array {
    $arqEstado = WS_CACHE . '/atendimento_revisao.json';
    $est = json_decode((string)@file_get_contents($arqEstado), true);
    if (!$desde) $desde = (int)($est['ate'] ?? 0) ?: (time() - 86400);
    $agora = time(); $achados = []; $total = 0; $vistos = [];
    foreach (ws_cw_cfg() as $cfg) {
        $base = $cfg['url'] . '/api/v1/accounts/' . $cfg['conta']; $tok = $cfg['token'];
        if (isset($vistos[$base])) continue; $vistos[$base] = 1;
        for ($pg = 1; $pg <= $maxPaginas; $pg++) {
            [, $r] = ws_cw_http('GET', $base . '/conversations?status=all&assignee_type=all&page=' . $pg, $tok);
            $lista = $r['data']['payload'] ?? [];
            if (!$lista) break;
            $parar = true;
            foreach ($lista as $c) {
                if ((int)($c['last_activity_at'] ?? 0) < $desde) continue;
                $parar = false; $total++;
                $id = (int)$c['id']; $nome = (string)($c['meta']['sender']['name'] ?? '?');
                [, $m] = ws_cw_http('GET', $base . '/conversations/' . $id . '/messages', $tok);
                $ant = '';
                foreach ((array)($m['payload'] ?? []) as $x) {
                    $t = (string)($x['content'] ?? ''); $tp = (int)($x['message_type'] ?? 1); $quando = (int)($x['created_at'] ?? 0);
                    $nova = $quando >= $desde;
                    $add = function (string $cat, string $det) use (&$achados, $id, $nome, $quando) {
                        $achados[] = ['conversa' => $id, 'contato' => $nome, 'quando' => date('d/m H:i', $quando), 'categoria' => $cat, 'detalhe' => mb_substr(preg_replace('/\s+/', ' ', $det), 0, 160)];
                    };
                    if ($tp === 0) {
                        if ($nova && (preg_match('/(não é|nao é|errad|outro nome|nome de outr|trocad|não era|nao era|não sou|nao sou|absurdo|reclam)/iu', $t) || preg_match('/(pix|boleto|cobran).{0,40}nome d[eao]\s+\p{L}+/iu', $t) || preg_match('/nome d[eao]\s+\p{L}+.{0,40}(pix|boleto|cobran)/iu', $t))) $add('cliente_reclamou', $t);
                        $ant = $t; continue;
                    }
                    if (!$nova) continue;
                    if (preg_match('/^\s*(obrigad|valeu|ok\b|tmj|blz|certo)/iu', $ant) && preg_match('/(menu|digite o n|escolha uma op)/iu', $t)) $add('menu_apos_obrigado', 'cliente: ' . $ant . ' → robô: ' . $t);
                    foreach ((array)($x['attachments'] ?? []) as $a) {
                        if (preg_match('#boleto-([^/]*)-\d+\.pdf#iu', urldecode((string)($a['data_url'] ?? $a['file_name'] ?? '')), $b)) {
                            $k = function ($s) { return preg_replace('/[^a-z]/', '', strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', (string)$s))); };
                            $arq = $k($b[1]); $p1 = substr($k(explode(' ', trim($nome))[0] ?? ''), 0, 3);
                            if ($p1 !== '' && strlen($arq) >= 4 && strpos($arq, $p1) !== 0 && strpos($arq, $p1) === false) $add('boleto_outro_nome', 'arquivo: ' . $b[1] . ' / contato: ' . $nome);
                        }
                    }
                    // Padrão de texto do dono: uma frase por linha, linha em branco entre blocos, marcador no começo do bloco.
                    if ($tp === 1 && mb_strlen($t) > 160 && strpos($t, "\n") === false && strpos($t, '00020126') === false && !preg_match('#https?://\S{80,}#', $t)) $add('sem_quebra_de_linha', $t);
                    elseif ($tp === 1 && mb_strlen($t) > 220 && substr_count($t, "\n\n") >= 1 && !preg_match('/[✅ℹ⚠🧾🔒🔓📌👋🙏🤝]/u', $t) && strpos($t, '00020126') === false) $add('sem_marcador', $t);
                }
            }
            if ($parar) break;
        }
    }
    $rel = ['ate' => $agora, 'de' => $desde, 'conversas' => $total, 'achados' => $achados, 'gerado_em' => date('c')];
    @file_put_contents($arqEstado, json_encode($rel, JSON_UNESCAPED_UNICODE)); @chmod($arqEstado, 0664);
    if ($achados) {
        $linhas = '';
        foreach ($achados as $a) $linhas .= json_encode(['em' => date('c')] + $a, JSON_UNESCAPED_UNICODE) . "\n";
        @file_put_contents(WS_CACHE . '/atendimento_aprendizado.jsonl', $linhas, FILE_APPEND | LOCK_EX);
    }
    return $rel;
}
