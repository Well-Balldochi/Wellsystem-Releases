<?php
/**
 * WellSystem — Backup automático do banco (cron).
 * CLI:  php backup_run.php
 * HTTP: backup_run.php?token=SEGREDO  (cron_token em cache/wellsystem_db.json)
 * Sugestão de cron: diário de madrugada  ->  0 3 * * * php /caminho/wellsystem/backup_run.php
 */
require __DIR__ . '/config.php'; require_once __DIR__ . '/espelho_lib.php'; ws_espelho_so_principal();   // ESPELHO (05/11/2026): rotina autom�tica - s� o servidor PRINCIPAL roda (a r�plica e a quarentena saem calados)
require __DIR__ . '/seguranca.php';

$cli = (php_sapi_name() === 'cli');
if (!$cli) {
    $tok = ws_db_config()['cron_token'] ?? '';
    if ($tok === '' || ($_GET['token'] ?? '') !== $tok) { http_response_code(403); exit('forbidden'); }
    header('Content-Type: application/json; charset=utf-8');
}
$r = ws_backup_gerar(false);   // só GERA o arquivo local; o ENVIO é feito UMA vez, no horário da tela Backup → Agendamento (cron do radius_sync). Antes este cron também enviava e chegava e-mail em horário avulso (ex.: 07:00).
// ws_backup_gerar() já tenta enviar (e-mail/WhatsApp/Telegram/FTP) pelos destinos configurados em
// Backup → Destinos de envio; o resultado de cada canal vem em $r['envio'].
echo $cli ? (($r['ok'] ? 'OK ' . $r['arquivo'] . (!empty($r['envio']) ? ' envio=' . json_encode($r['envio'], JSON_UNESCAPED_UNICODE) : '') : 'ERRO ' . ($r['erro'] ?? '')) . "\n") : json_encode($r);
