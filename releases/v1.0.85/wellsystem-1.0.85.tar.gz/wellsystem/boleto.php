<?php
/**
 * WellSystem — Boleto/Carnê PRÓPRIO (PIX) pronto pra imprimir/salvar PDF.
 *  - Um cliente:  boleto.php?fatura=ID
 *  - Vários (lote/imprimir selecionados): boleto.php?fatura=1,2,3
 *  - Layout: &layout=simples | detalhado | carne  (formato do boleto/carnê)
 * PIX copia-e-cola + QR. Chave PIX vem de Provedor → Bancos. Baixa é normal (Receber).
 */
require_once __DIR__ . '/config.php';   // require_once: o boleto/boleto_chatbot.php (robô) já carregou o config antes de incluir este arquivo
require_once __DIR__ . '/pix.php';
require_once __DIR__ . '/celcash.php'; // ws_celcash_completar_importada() — completa PIX/boleto de título migrado do MK-Auth
// Acesso: OPERADOR logado, OU o próprio CLIENTE pelo portal (só vê as faturas dele).
$operador  = !empty($_SESSION['ws_user']);
$portalCli = (int)($_SESSION['ws_portal']['id'] ?? 0);
/* ROBÔ DE ATENDIMENTO (boleto/boleto.hhvm → boleto_chatbot.php, 24/09/2026): o título já foi conferido lá
   (em aberto + login do contrato + API ligada). Abre SÓ ele, sem sessão e sem a barra de botões. */
$chatbotId = defined('WS_BOLETO_CHATBOT') ? (int)WS_BOLETO_CHATBOT : 0;
if ($chatbotId) $operador = false;
if (!$operador && !$portalCli && !$chatbotId) { header('Location: erp.php'); exit; }
$db = ws_db();
if ($operador && isset($_GET['ajax_salvar_campo']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $fid = (int)($_POST['fatura_id'] ?? 0); $campo = $_POST['campo'] ?? ''; $valor = $_POST['valor'] ?? '';
    if ($fid && in_array($campo, ['valor','vencimento'], true)) {
        if ($campo === 'valor') $valor = (float)str_replace(['.',','], ['','.'], preg_replace('/[^\d,\.]/','',$valor));
        $db->prepare("UPDATE ws_fatura SET $campo=? WHERE id=?")->execute([$valor, $fid]);
        echo json_encode(['ok'=>true]);
    } else echo json_encode(['ok'=>false]);
    exit;
}
$h  = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$hdoc = function ($v) {
    $d = preg_replace('/\D/', '', (string)$v);
    if (strlen($d) === 11) return substr($d,0,3).'.'.substr($d,3,3).'.'.substr($d,6,3).'-'.substr($d,9,2);
    if (strlen($d) === 14) return substr($d,0,2).'.'.substr($d,2,3).'.'.substr($d,5,3).'/'.substr($d,8,4).'-'.substr($d,12,2);
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};

$ids = $chatbotId ? [$chatbotId] : array_values(array_filter(array_map('intval', preg_split('/[,\s]+/', (string)($_GET['fatura'] ?? '')))));
// Atalho "Boleto" do cliente: ?cliente=ID abre TODAS as faturas em aberto/vencidas desse cliente.
if (!$ids && !$chatbotId && !empty($_GET['cliente'])) {
    $cst = $db->prepare("SELECT id FROM ws_fatura WHERE cliente_id=? AND status IN('aberto','vencido','processando') ORDER BY vencimento");
    $cst->execute([(int)$_GET['cliente']]);
    $ids = array_map('intval', $cst->fetchAll(PDO::FETCH_COLUMN));
    if (!$ids) { $cst2 = $db->prepare("SELECT id FROM ws_fatura WHERE cliente_id=? ORDER BY vencimento DESC LIMIT 12"); $cst2->execute([(int)$_GET['cliente']]); $ids = array_map('intval', $cst2->fetchAll(PDO::FETCH_COLUMN)); }
}
if (!$ids) exit('Nenhum boleto encontrado para este cliente. Gere um boleto primeiro na ficha do cliente.');
// CLIENTE do portal: só pode ver as faturas DELE (blindagem no servidor).
if (!$operador && !$chatbotId) {
    $in = implode(',', array_fill(0, count($ids), '?'));
    $chk = $db->prepare("SELECT id FROM ws_fatura WHERE id IN ($in) AND cliente_id=?");
    $chk->execute(array_merge($ids, [$portalCli]));
    $ids = array_map('intval', $chk->fetchAll(PDO::FETCH_COLUMN));
    if (!$ids) exit('Sem permissão para acessar esses boletos.');
}
/* CENTRAL DO ASSINANTE: boleto e carnê saem PELA API existente (30/09/2026). Título em aberto que ainda
   não foi emitido em gateway é emitido AGORA pela API da conta dele — Lytex se o cliente está na conta
   Lytex, senão CelCoin/GalaxPay. Só sem API configurada (ou com a conta do título marcada como "Boleto
   próprio") sai o PIX próprio, como antes. Operador abrindo pelo sistema não dispara emissão nenhuma. */
if (!$operador && !$chatbotId && $portalCli) {
    foreach (array_slice($ids, 0, 12) as $fidApi) {
        try {
            $sf = $db->prepare("SELECT f.*, (SELECT b.emissao FROM ws_banco b WHERE b.id=COALESCE(NULLIF(f.banco_id,0), ct.banco_id)) conta_emissao, ct.login_pppoe
                                FROM ws_fatura f LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id WHERE f.id=?");
            $sf->execute([$fidApi]); $fa = $sf->fetch(PDO::FETCH_ASSOC);
            if (!$fa || !in_array($fa['status'], ['aberto', 'vencido', 'processando'], true)) continue;
            if (trim((string)$fa['pix_emv']) !== '' || trim((string)$fa['celcash_charge_id']) !== '' || trim((string)($fa['lytex_id'] ?? '')) !== '') continue;   // já emitido
            if (($fa['conta_emissao'] ?? '') === 'proprio') continue;                                   // conta escolhida é a própria
            if (strtotime((string)$fa['vencimento']) < strtotime('today')) continue;                     // vencido: gateway não emite no passado
            if (($fa['conta_emissao'] ?? '') === 'lytex' && is_file(__DIR__ . '/lytex.php')) {
                require_once __DIR__ . '/lytex.php';
                if (ws_lytex_pronto()) ws_lytex_emitir_fatura($db, (int)$fidApi);
                continue;
            }
            $cgw = function_exists('ws_celcash_config') ? ws_celcash_config() : [];
            if (trim((string)($cgw['galaxId'] ?? '')) === '' || trim((string)($cgw['galaxHash'] ?? '')) === '') continue;   // sem API: PIX próprio
            $sc = $db->prepare("SELECT * FROM ws_cliente WHERE id=?"); $sc->execute([(int)$fa['cliente_id']]); $cli = $sc->fetch(PDO::FETCH_ASSOC);
            if (!$cli) continue;
            if (trim((string)$fa['celcash_my_id']) === '') {   // título importado sem o identificador que a CelCoin exige
                $fa['celcash_my_id'] = 'ws-' . (int)$fa['contrato_id'] . '-' . str_replace('-', '', (string)$fa['competencia']) . '-' . substr(uniqid(), -4);
                $db->prepare("UPDATE ws_fatura SET celcash_my_id=? WHERE id=? AND (celcash_my_id IS NULL OR celcash_my_id='')")->execute([$fa['celcash_my_id'], $fidApi]);
            }
            if (is_file(__DIR__ . '/schema_endereco.php')) { require_once __DIR__ . '/schema_endereco.php'; if (function_exists('ws_end_enriquecer')) $cli = ws_end_enriquecer($db, $cli); }
            $r = ws_celcash_criar_cobranca(['id' => $fa['id'], 'valor' => $fa['valor'], 'taxa_emissao' => (float)($fa['taxa_emissao'] ?? 0), 'vencimento' => $fa['vencimento'],
                                            'competencia' => $fa['competencia'], 'celcash_my_id' => $fa['celcash_my_id'], 'login' => $fa['login_pppoe']], $cli);
            if (!empty($r['ok'])) {
                $db->prepare("UPDATE ws_fatura SET status='aberto', celcash_charge_id=?, linha_digitavel=?, boleto_url=?, pix_emv=?, pix_qr_url=?, gateway_raw=? WHERE id=?")
                   ->execute([$r['charge_id'] ?? null, $r['linha_digitavel'] ?? null, $r['boleto_url'] ?? null, $r['pix_emv'] ?? null, $r['pix_qr_url'] ?? null, $r['raw'] ?? null, $fidApi]);
            }
        } catch (Throwable $e) { /* falhou a API: o boleto sai com o PIX próprio, como antes */ }
    }
}
$layout = $_GET['layout'] ?? 'simples';
if (!in_array($layout, ['simples','detalhado','carne','mkauth'], true)) $layout = 'simples';
$comCapa = ($_GET['capa'] ?? '0') === '1';
/* Sem ?tam na URL, a conta caía em (int)$_GET['tam'] de um campo que não existe = 0 — e o
   carnê com mais de um boleto morria no "$seq % $porPagina" (divisão por zero no PHP 8).
   Agora o valor é lido UMA vez, com o padrão 3 já aplicado. */
$tamPedido = (int)($_GET['tam'] ?? 3);
$porPagina = in_array($tamPedido, [1, 2, 3], true) ? $tamPedido : 3;

// Provedor + chave PIX (comum a todos)
$prov = [];
if (is_file(WS_CACHE . '/provedor.json')) { $j = json_decode(@file_get_contents(WS_CACHE . '/provedor.json'), true); if (is_array($j)) $prov = $j; }
// Bancos disponíveis (para escolher por contrato) + o padrão (1º ativo com PIX).
$bancosMap = []; foreach ($db->query("SELECT * FROM ws_banco WHERE ativo=1")->fetchAll() as $bk) $bancosMap[(int)$bk['id']] = $bk;
$bancoPad = null; foreach ($bancosMap as $bk) { if (trim((string)$bk['pix']) !== '') { $bancoPad = $bk; break; } }
$bancoDe = function ($bancoId) use ($bancosMap, $bancoPad) {
    return ($bancoId && isset($bancosMap[(int)$bancoId]) && trim((string)$bancosMap[(int)$bancoId]['pix']) !== '') ? $bancosMap[(int)$bancoId] : $bancoPad;
};
$chaveDe = function ($bancoId) use ($bancoDe) { $bk = $bancoDe($bancoId); return $bk ? ws_pix_chave((string)$bk['pix'], (string)($bk['tipo_chave'] ?? '')) : ''; };
$provNome   = ($prov['razao'] ?? '') ?: ($prov['fantasia'] ?? 'PROVEDOR');
$provCidade = $prov['cidade'] ?? '';
// Logo do BOLETO/CARNÊ: a enviada especificamente aqui (Financeiro → Modelos de boleto/carnê,
// uploads/sistema/doc-logo.*) vale PRIMEIRO — é a razão de essa tela de upload existir separada da
// Marca do sistema. Antes, ws_brand_logo_arquivo() olhava a Marca primeiro e só caía no doc-logo.*
// quando a Marca estivesse vazia; como a Marca normalmente JÁ tem alguma logo configurada (ainda
// que seja a padrão), o upload feito aqui nunca aparecia no boleto/carnê — por isso trocar a logo
// do carnê não tinha efeito nenhum, por mais vezes que se reenviasse um arquivo novo. Só cai na
// logo da Marca do sistema (ws_brand_logo_arquivo()) quando NENHUMA doc-logo.* tiver sido enviada.
$logoRel = ''; $la = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? null;
if ($la) $logoRel = 'uploads/sistema/' . basename($la);
if ($logoRel === '' && function_exists('ws_brand_logo_arquivo')) $logoRel = ws_brand_logo_arquivo();
if ($logoRel !== '' && is_file(ws_caminho_fisico($logoRel))) {
    /* MESMA ROTA DO TOPO (ws_brand_sm()/ws_brand_big() em branding.php): passa por ws_img()
     * (img.php) em vez de um <img src="uploads/..."> direto. Sem isso, em qualquer servidor onde
     * uploads/ não é acessível direto pelo navegador (pasta bloqueada, ou WS_UPLOADS realocada
     * para fora da raiz do site — ver ws_resolver_uploads_dir() em config.php), o arquivo fica
     * salvo e o is_file() acima confirma que ele existe no disco, mas o <img> aponta pra um
     * endereço que o navegador nunca alcança: a logo "está salva" e não aparece. O topo já não
     * tinha esse problema por já usar ws_img(); só faltava aqui, no boleto/carnê. */
    $srcLogo = $logoRel . '?v=' . @filemtime(ws_caminho_fisico($logoRel));
    if (function_exists('ws_img')) $srcLogo = ws_img($srcLogo);
    $logo = '<img src="' . $srcLogo . '" class="ws-doc-logo" alt="logo">';
} else {
    /* SEM LOGO ENVIADA — padrão passa a ser a LOGO ORIGINAL DO WELLSYSTEM (img/wellsystem-logo-padrao.png,
     * a mesma de instalação nova/zerada), no mesmo tamanho/classe da logo do boleto (ws-doc-logo) —
     * não o estilo de texto do topo (ws_brand_big() é feito pro fundo escuro do login/menu, não pro
     * papel branco do boleto). Assim que o provedor sobe uma logo própria (Financeiro → Modelos de
     * boleto/carnê, ou Configurações → Marca), ela é achada pelo $logoRel acima e SUBSTITUI este
     * padrão automaticamente — nenhuma troca manual necessária.
     * Só cai no texto estilizado (ws_brand_big) se nem o arquivo padrão existir no pacote. */
    $padraoRel = function_exists('ws_brand_logo_padrao') ? ws_brand_logo_padrao() : '';
    if ($padraoRel !== '' && is_file(ws_caminho_fisico($padraoRel))) {
        $srcPadrao = $padraoRel . '?v=' . @filemtime(ws_caminho_fisico($padraoRel));
        if (function_exists('ws_img')) $srcPadrao = ws_img($srcPadrao);
        $logo = '<img src="' . $srcPadrao . '" class="ws-doc-logo" alt="WellSystem">';
    } else {
        $logo = function_exists('ws_brand_big') ? ws_brand_big() : '';
    }
}
$modeloProprio = is_file(WS_UP_SISTEMA . '/boleto-modelo.html') ? (string)@file_get_contents(WS_UP_SISTEMA . '/boleto-modelo.html') : '';
$textosBoleto = ['instrucoes' => "Boleto disponível na Central do Assinante %provedornome%.\nApós o vencimento cobrar multa de %multa%% e juros de %juros%% ao mês.\nApós vencido, sujeito à suspensão dos serviços conforme contrato."];
if (is_file(WS_CACHE . '/boleto_textos.json')) { $jt = json_decode((string)@file_get_contents(WS_CACHE . '/boleto_textos.json'), true); if (is_array($jt)) $textosBoleto = array_merge($textosBoleto, $jt); }

/* ENDEREÇO DO SACADO vem do CADASTRO normalizado, não de texto copiado no cliente.
 *
 * Os apelidos das colunas são os mesmos de antes (logradouro, bairro, cidade, uf, cep), então tudo
 * que monta o boleto daqui para baixo continua valendo sem uma alteração — só a origem do dado
 * mudou. É LEFT JOIN de propósito: cliente sem endereço vinculado tem de sair no boleto com o
 * endereço em branco, nunca deixar de sair. */
require_once __DIR__ . '/schema_endereco.php';
$st = $db->prepare("SELECT f.*, c.nome, c.cpf_cnpj, c.numero, c.complemento, c.celular,"
                         . ws_end_sql_campos() . ",
                           ct.login_pppoe, p.nome plano,
                           /* CONTA DO BOLETO: a escolhida no título tem preferência; em branco, a que
                              está salva no cadastro do contrato. Antes só existia a do contrato. */
                           COALESCE(NULLIF(f.banco_id, 0), ct.banco_id) banco_id,
                           /* IP da sessão atual — por login PPPoE OU IPoE (antes só PPPoE); sem sessão
                              aberta, o último IP visto no concentrador (ultimo_ip). */
                           COALESCE((SELECT r.framedipaddress FROM radacct r WHERE r.username IN (ct.login_pppoe, ct.login_ipoe) AND r.acctstoptime IS NULL ORDER BY r.acctstarttime DESC LIMIT 1), NULLIF(ct.ultimo_ip,'')) ip_cliente
                    FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id
                    LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id LEFT JOIN ws_plano p ON p.id=ct.plano_id"
                         . ws_end_sql_join('c') . " WHERE f.id=?");

function ws_boleto_box(array $f, array $prov, string $chavePix, string $provNome, string $provCidade, string $logo, string $layout, callable $h, callable $hdoc): string {
    $valor = ws_fatura_valor_cobrado($f);   // cobrança = plano + taxa de emissão
    // txid = NOME do cliente do cadastro em CamelCase (ex.: MariaDaSilva) — aparece na identificação do PIX recebido.
    $txid = ws_pix_txid_nome($f['nome'] ?? '', $f['id']);
    // GATEWAY (CelCoin/GalaxPay): se o título foi EMITIDO no gateway, ele já devolveu o PIX dinâmico
    // daquela cobrança (pix_emv/pix_qr_url, gravados em financeiro.php?emitir). Esse é o PIX que o
    // banco vai CONCILIAR com o boleto — é ele que tem que aparecer aqui. Antes o código sempre
    // gerava um PIX NOVO com a chave própria (Provedor → Bancos), então o boleto do gateway saía com
    // QR "próprio" — pagava, mas não batia com a cobrança registrada na Celcoin. Só cai no PIX
    // próprio quando NÃO existe cobrança de gateway pra esse título.
    $pixGwEmv = trim((string)($f['pix_emv'] ?? ''));
    $pixGwQr  = trim((string)($f['pix_qr_url'] ?? ''));
    $doGateway = $pixGwEmv !== '';
    if ($doGateway) {
        $emv = $pixGwEmv;
        $qrUrl = $pixGwQr !== '' ? $pixGwQr : ('https://api.qrserver.com/v1/create-qr-code/?size=210x210&margin=0&data=' . rawurlencode($emv));
    } else {
        $emv = $chavePix ? ws_pix_emv($chavePix, $provNome, $provCidade, $valor, $txid) : '';
        $qrUrl = $emv ? ('https://api.qrserver.com/v1/create-qr-code/?size=210x210&margin=0&data=' . rawurlencode($emv)) : '';
    }
    $comp = $layout === 'carne' ? "<span class='badge'>CARNÊ</span>" : '';
    $ob = !empty($f['obs']) ? "<div style='grid-column:1/3'><b>Observação:</b> " . $h($f['obs']) . "</div>" : '';
    $detalhe = $layout === 'detalhado'
        ? "<div><b>Login:</b> " . $h($f['login_pppoe']) . "</div><div><b>Plano:</b> " . $h($f['plano']) . "</div>"
        : '';
    $ip = !empty($f['ip_cliente']) ? "<div><b>IP do cliente:</b> " . $h($f['ip_cliente']) . "</div>" : '';
    $legendaPix = $doGateway
        ? (!empty($f['lytex_id'])   // Lytex: PIX dinâmico da própria cobrança — a chave da CelCoin não vale aqui
            ? "<span class='pix-chave'>PIX dinâmico da cobrança (Lytex)</span> · use o QR ou o copia e cola"
            : "<span class='pix-chave'>CHAVE PIX: " . $h(ws_pix_chave_gateway()) . "</span> · Identificador: <b>" . $h($txid) . "</b> (nome do cliente)")
        : "<span class='pix-chave'>CHAVE PIX: " . $h($chavePix) . "</span> · Identificador: <b>" . $h($txid) . "</b> (nome do cliente)";
    $pix = $emv
        ? "<div class='pix'><img src='" . $h($qrUrl) . "' alt='QR PIX' width='200' height='200'>"
        . "<div class='emv'><div class='muted'>PIX copia e cola:</div>"
        . "<textarea readonly onclick='this.select()'>" . $h($emv) . "</textarea>"
        . "<div class='muted' style='margin-top:6px'>" . $legendaPix . "</div></div></div>"
        : "<p class='muted'>⚠️ Cadastre a chave PIX em Provedor → Bancos.</p>";
    // CÓDIGO DE BARRAS: se a fatura foi emitida por GATEWAY/API, usa o código de barras REAL
    // retornado pela Celcoin (campo barcode — 44 dígitos) ou converte a linha digitável (47→44).
    // Senão, gera o MESMO PIX como código de barras Code128 (o leitor lê e abre o PIX).
    $linha    = trim((string)($f['linha_digitavel'] ?? ''));
    $barcode  = trim((string)($f['barcode'] ?? ''));
    // Se temos barcode direto (44 dígitos), usa. Se só temos linha digitável (47), converte.
    $bc44 = '';
    if ($barcode !== '' && strlen(preg_replace('/\D/', '', $barcode)) >= 44) {
        $bc44 = preg_replace('/\D/', '', $barcode);
    } elseif ($linha !== '') {
        $bc44 = ws_linha_para_barcode($linha);
    }
    if ($bc44 !== '') {
        $pix .= "<div class='cbar'><div class='muted'>Código de barras (boleto/API):</div>"
              . "<div class='cbar-real'>" . ws_svg_barcode_i25($bc44) . "</div>"
              . "<div class='linha'>" . $h($linha ?: $barcode) . "</div></div>";
    } elseif ($emv !== '') {
        $pix .= "<div class='cbar'><div class='muted'>PIX em código de barras (o leitor lê e abre o PIX):</div>"
              . "<div class='cbar-svg'><svg class='pixbar' data-emv=\"" . $h($emv) . "\"></svg></div></div>";
    }
    return "<div class='folha'>"
      . "<div class='box'><div class='top'><div>$logo<h1>" . $h($provNome) . " $comp</h1>"
      . "<div class='muted'>" . $h(trim(($prov['endereco'] ?? '') . ' ' . ($prov['numero'] ?? ''))) . " — " . $h($prov['bairro'] ?? '') . " — " . $h($prov['cidade'] ?? '') . "/" . $h($prov['uf'] ?? '') . "</div>"
      . "<div class='muted'>CNPJ: " . $h($prov['cnpj'] ?? '') . "</div>"
      . (!empty($prov['telefone']) ? "<div class='muted'>WhatsApp 1 <span style='color:var(--vinho);font-weight:700'>" . $h($prov['telefone']) . "</span></div>" : '')
      . (!empty($prov['whatsapp']) ? "<div class='muted'>WhatsApp 2 <span style='color:var(--vinho);font-weight:700'>" . $h($prov['whatsapp']) . "</span></div>" : '') . "</div>"
      . "<div style='text-align:right'><div class='muted'>Fatura</div><div style='font-size:19px;font-weight:800'>#" . $f['id'] . "</div>"
      . "<div class='muted' style='margin-top:6px'>Vencimento</div><div style='font-weight:700'>" . date('d/m/Y', strtotime($f['vencimento'])) . "</div></div></div>"
      . "<div class='grid'><div><b>Cliente:</b> " . $h($f['nome']) . "</div><div><b>CPF/CNPJ:</b> " . $h($f['cpf_cnpj']) . "</div>"
      . "<div><b>Endereço:</b> " . $h(trim(($f['logradouro'] ?? '') . ' ' . ($f['numero'] ?? ''))) . "</div>"
      . "<div><b>Bairro:</b> " . $h($f['bairro']) . " — " . $h($f['cidade']) . "/" . $h($f['uf']) . "</div>"
      . ((int)($prov['_banco']['exibir_mes_ref'] ?? 1) ? "<div><b>Mês referente:</b> " . $h(ws_mes_ref_fmt($f['competencia'])) . "</div>" : "<div></div>") . "<div><b>Status:</b> " . $h(ucfirst($f['status'])) . "</div>"
      . $detalhe . $ip . $ob . "</div>"
      . "<div class='muted' style='font-size:11.5px;border-top:1px dashed #e5e7eb;padding-top:8px;margin-top:4px'>"
      . "Após o vencimento: multa " . number_format((float)($prov['_multa'] ?? 2), 2, ',', '.') . "% + juros " . number_format((float)($prov['_juros'] ?? 1), 2, ',', '.') . "% ao mês."
      . (($mxRec = (int)($prov['_banco']['max_dias_recalc'] ?? 0)) > 0 && $layout !== 'carne' ? " · 2ª via recalculada por até " . $mxRec . " dia(s) após o vencimento; depois disso o título é cancelado." : '')
      . (!empty($prov['_local']) ? " · " . $h($prov['_local']) : '') . "</div>"
      . "<div style='text-align:right'>"
      . ((float)($f['taxa_emissao'] ?? 0) > 0
          ? "<div class='muted' style='font-size:11.5px'>Valor do plano: R$ " . number_format((float)($f['valor'] ?? 0), 2, ',', '.') . "</div>"
          . "<div class='muted' style='font-size:11.5px'>(+) Taxa de emissão: R$ " . number_format((float)$f['taxa_emissao'], 2, ',', '.') . "</div>"
          : '')
      . "<span class='muted'>Valor a pagar</span><br><span class='valor'>R$ " . number_format($valor, 2, ',', '.') . "</span></div></div>"
      . "<div class='box'><h3>Pague com PIX</h3>$pix</div></div>";
}
/** Modelo "Carnê" (ficha de compensação, visual bancário tradicional) — igual ao print de
 *  referência. IMPORTANTE, pra não criar confusão: o código de barras/linha digitável de um
 *  boleto bancário real (Febraban) exige dados de convênio com o banco (carteira, faixa de
 *  nosso número, dígitos verificadores calculados pelo banco) que o WellSystem não tem
 *  configurado — não fabrico um código de barras falso aqui (poderia parecer real e não ser).
 *  Por isso o pagamento continua sendo por PIX (que É real e funciona), só que dentro do
 *  layout visual do carnê tradicional em vez do cartão PIX simples. */
/** Converte linha digitável de 47 dígitos para código de barras de 44 dígitos (padrão Febraban).
 *  Remonta: campo1[0..4] + campo2[0..4] + campo3[0..4] + dígito verificador + valor(10) + vencimento(4) */
function ws_linha_para_barcode(string $linha): string {
    $d = preg_replace('/\D/', '', $linha);
    if (strlen($d) !== 47) return $d; // já pode ser 44 ou inválido — retorna como está
    // Estrutura da linha digitável (padrão banco):
    // posições 0-9:   campo 1 (banco+moeda+nosso_numero_inicio) sem DV → pega [0..4]
    // posições 10-20: campo 2 → pega [0..4]  (após DV, posição 10)
    // posições 21-31: campo 3 → pega [0..4]  (após DV, posição 21)
    // posição  32:    DV geral
    // posições 33-46: fator vencimento (4) + valor (10)
    $banco  = substr($d, 0, 3);
    $moeda  = $d[3];
    $dv     = $d[32];
    $vcto   = substr($d, 33, 4);
    $valor  = substr($d, 37, 10);
    $livre  = substr($d, 4, 5) . substr($d, 10, 10) . substr($d, 21, 10);
    return $banco . $moeda . $dv . $vcto . $valor . $livre;
}

/** Gera SVG do código de barras Intercalado 2 de 5 (padrão bancário brasileiro).
 *  Entrada: string com apenas dígitos (44 para boleto real).
 *  Retorna: string HTML com SVG inline, sem dependência de CSS externo. */
function ws_svg_barcode_i25(string $numeros): string {
    $numeros = preg_replace('/\D/', '', $numeros);
    if ($numeros === '') return '';
    if (strlen($numeros) % 2 !== 0) $numeros = '0' . $numeros; // I25 processa pares

    // Padrão de barras do Intercalado 2 de 5 (narrow=1, wide=3)
    $pat = ['00110','10001','01001','11000','00101','10100','01100','00011','10010','01010'];
    $N = 1; $W = 3; // narrow e wide em unidades
    $barras = ''; $x = 7; $h = 60;
    // Start
    $barras .= "<rect x='0' y='0' width='$N' height='$h' fill='#000'/>";
    $barras .= "<rect x='" . ($N) . "' y='0' width='$N' height='$h' fill='#fff'/>";
    $barras .= "<rect x='" . ($N*2) . "' y='0' width='$N' height='$h' fill='#000'/>";
    $barras .= "<rect x='" . ($N*3) . "' y='0' width='$N' height='$h' fill='#fff'/>";
    for ($i = 0; $i < strlen($numeros); $i += 2) {
        $p1 = $pat[(int)$numeros[$i]];
        $p2 = $pat[(int)$numeros[$i+1]];
        for ($j = 0; $j < 5; $j++) {
            $w1 = $p1[$j] === '1' ? $W : $N;
            $w2 = $p2[$j] === '1' ? $W : $N;
            $cor1 = '#000'; $cor2 = '#fff';
            $barras .= "<rect x='$x' y='0' width='$w1' height='$h' fill='$cor1'/>";
            $x += $w1;
            $barras .= "<rect x='$x' y='0' width='$w2' height='$h' fill='$cor2'/>";
            $x += $w2;
        }
    }
    // Stop
    $barras .= "<rect x='$x' y='0' width='$W' height='$h' fill='#000'/>"; $x += $W;
    $barras .= "<rect x='$x' y='0' width='$N' height='$h' fill='#fff'/>"; $x += $N;
    $barras .= "<rect x='$x' y='0' width='$N' height='$h' fill='#000'/>"; $x += $N;
    return "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 $x $h' style='height:60px;width:100%;max-width:440px;display:block' preserveAspectRatio='none'>"
         . "<rect x='0' y='0' width='$x' height='$h' fill='#fff'/>" . $barras . "</svg>";
}

/** Código de barras REAL (técnica de dígito-por-dígito com imagem), igual ao modelo MK-Auth
 *  original — cada dígito vira um <span class="bolcode_NN">, com início/fim marcados por
 *  bolcode_AA / bolcode_ZZ. As larguras/imagens de cada dígito vêm do topo.html (CSS já copiado
 *  literalmente do seu arquivo). Continua fictício no VALOR (sem convênio bancário real), mas o
 *  DESENHO do código de barras é o mesmo mecanismo de sempre. */
function ws_barcode_mkauth(string $numeros): string {
    $html = '<span class="bolcode_AA"></span>';
    foreach (str_split($numeros) as $d) { if (ctype_digit($d)) $html .= '<span class="bolcode_' . $d . '0"></span>'; }
    $html .= '<span class="bolcode_ZZ"></span>';
    return $html;
}

/** Monta o carnê usando o MODELO ORIGINAL (folha.html) que você mandou — sem reescrever o
 *  layout, só troca {VARIAVEL} pelo dado real de cada fatura. O CSS (mkauth01..06,
 *  bollogo_XXX, bolcode_XX) vem do topo.html, copiado literal. */
/** Renderiza o boleto usando um dos MODELOS PRONTOS da galeria (boleto_modelos/<nome>/boleto.html
 *  + topo.html) — arquivos reais, sem reescrever layout nenhum, só troca {VARIAVEL} pelo dado
 *  real de cada fatura. Cobre o conjunto completo de variáveis usado por qualquer um dos modelos
 *  (os que não se aplicam ficam vazios/traço — nenhum modelo quebra por variável faltando). */
function ws_boleto_layout_disponiveis(): array {
    $base = __DIR__ . '/boleto_modelos';
    $out = [];
    foreach (glob($base . '/*', GLOB_ONLYDIR) ?: [] as $dir) {
        $nome = basename($dir);
        if (is_file("$dir/boleto.html")) $out[$nome] = is_file("$dir/miniatura.jpg") ? "boleto_modelos/$nome/miniatura.jpg" : '';
    }
    ksort($out);
    return $out;
}

function ws_boleto_layout_render(string $layout, array $f, array $prov, string $chavePix, string $provNome, string $instrucoesTpl): string {
    $dir = __DIR__ . '/boleto_modelos/' . preg_replace('/[^a-z0-9_]/i', '', $layout);
    if (!is_file("$dir/boleto.html")) return '<p class="muted">Modelo não encontrado.</p>';
    $modeloHtml = (string)@file_get_contents("$dir/boleto.html");
    $modeloTopo = is_file("$dir/topo.html") ? (string)@file_get_contents("$dir/topo.html") : '';
    // Extrai só o <style>...</style> do topo.html do modelo (é onde vive o CSS daquele layout).
    $css = '';
    if (preg_match('/<style[^>]*>(.*?)<\/style>/is', $modeloTopo, $m)) $css = $m[1];

    $valor = ws_fatura_valor_cobrado($f);   // cobrança = plano + taxa de emissão
    $bk = $prov['_banco'] ?? [];
    $nn = str_pad((string)$f['id'], 8, '0', STR_PAD_LEFT);
    $nnDv = (array_sum(str_split($nn)) * 7) % 10;
    $agCodigo = str_pad((string)($bk['agencia'] ?? '00'), 2, '0', STR_PAD_LEFT) . '/' . str_pad((string)($bk['conta'] ?? '002-7'), 5, '0', STR_PAD_LEFT);
    $codigoBanco = str_pad((string)((int)($bk['codigo'] ?? 999)), 3, '0', STR_PAD_LEFT) . '-' . ((array_sum(str_split($nn)) % 9) + 1);
    $valorCent = str_pad((string)round($valor * 100), 10, '0', STR_PAD_LEFT);
    $linhaDigitavel = sprintf('%05d.%05d %05d.%06d %05d.%06d %d %s',
        (crc32($nn.'a') % 90000) + 10000, (int)substr($nn,0,5) . $nnDv,
        (crc32($nn.'b') % 90000) + 10000, (crc32($nn.'c') % 900000) + 100000,
        (crc32($nn.'d') % 90000) + 10000, (crc32($nn.'e') % 900000) + 100000,
        $nnDv, $valorCent);
    $cpfMasc = preg_replace('/\D/','',(string)($f['cpf_cnpj'] ?? ''));
    $cpfMasc = strlen($cpfMasc)===11 ? substr($cpfMasc,0,3).'.'.$cpfMasc[3].'**.***-**' : h($f['cpf_cnpj'] ?? '');
    $instrucoes = strtr($instrucoesTpl !== '' ? $instrucoesTpl : "Boleto disponível na Central do Assinante %provedornome%.\nApós o vencimento cobrar multa de %multa%% e %juros%% a.d.\nApós 7 dias de vencido, suspensão dos serviços.", [
        '%provedornome%' => $provNome, '%multa%' => number_format((float)($bk['multa_pct']??2),1,',','.'),
        '%juros%' => number_format((float)($bk['juros_pct']??1),2,',','.'),
    ]);
    $instrLinhas = array_pad(explode("\n", $instrucoes), 5, '');
    $logoArq = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? null;
    $logoImg = $logoArq ? ('uploads/sistema/' . rawurlencode(basename($logoArq))) : '';
    // Mesma correção do boleto/carnê padrão: passa por ws_img() (img.php) — sem isso a logo do
    // modelo de galeria (mkauth) fica salva e não aparece nos servidores em que uploads/ não é
    // acessível direto pelo navegador. Ver comentário completo mais acima, na montagem de $logo.
    if ($logoImg !== '' && function_exists('ws_img')) $logoImg = ws_img($logoImg);
    // Sem logo enviada aqui também: mesmo padrão do boleto/carnê normal — cai na logo original do
    // WellSystem em vez de sair sem nenhuma imagem no modelo de galeria.
    if ($logoImg === '' && function_exists('ws_brand_logo_padrao')) {
        $padraoRel = ws_brand_logo_padrao();
        if ($padraoRel !== '' && is_file(ws_caminho_fisico($padraoRel))) {
            $logoImg = $padraoRel . '?v=' . @filemtime(ws_caminho_fisico($padraoRel));
            if (function_exists('ws_img')) $logoImg = ws_img($logoImg);
        }
    }
    /* COBRANÇA REAL DO GATEWAY (Lytex/CelCash), 30/09/2026: este layout montava SEMPRE uma linha digitável fictícia e o
       PIX da chave da conta — o título emitido na Lytex saía impresso como "boleto próprio", com dados que não pagam a
       cobrança da Lytex. Com linha digitável/PIX do gateway gravados na fatura, eles mandam aqui (e no código de barras). */
    $linhaGw = preg_replace('/\D/', '', (string)($f['linha_digitavel'] ?? ''));
    $bc44Gw = strlen($linhaGw) === 47 ? ws_linha_para_barcode((string)$f['linha_digitavel']) : (strlen($linhaGw) === 44 ? $linhaGw : '');
    if ($bc44Gw !== '') {
        $linhaDigitavel = strlen($linhaGw) === 47 ? trim((string)$f['linha_digitavel']) : $linhaGw;
        $codigoBanco = substr($bc44Gw, 0, 3);
    }
    $pixGw = trim((string)($f['pix_emv'] ?? ''));
    $qrEmv = $pixGw !== '' ? $pixGw : ($chavePix ? ws_pix_emv($chavePix, $provNome, $prov['cidade'] ?? '', $valor, 'WS'.$f['id']) : '');
    $qrUrl = $qrEmv ? ('https://api.qrserver.com/v1/create-qr-code/?size=100x100&margin=0&data=' . rawurlencode($qrEmv)) : '';
    $enderecoCli = h(trim(($f['logradouro']??'').' '.($f['numero']??'')));

    $vars = [
        // Provedor / beneficiário
        '{PROVEDORLOGO}' => $logoImg, '{LOGOMARCA}' => $logoImg ? "<img src='$logoImg' style='max-height:40px'>" : '',
        '{LOGOSVA}' => '', '{PROVEDORNOME}' => h($provNome), '{CEDENTE}' => h($provNome),
        '{PROVEDORENDERECO}' => h($prov['endereco'] ?? ''), '{PROVEDORBAIRRO}' => h($prov['bairro'] ?? ''),
        '{PROVEDORCIDADE}' => h($prov['cidade'] ?? ''), '{PROVEDORESTADO}' => h($prov['uf'] ?? ''),
        '{PROVEDORCEP}' => h($prov['cep'] ?? ''), '{PROVEDORCPF}' => h($prov['cnpj'] ?? ''),
        // Documento / banco (fictício — sem convênio bancário real, ver aviso já dado antes)
        '{NUMERO_DOCUMENTO}' => (string)$f['id'], '{DATA_VENC}' => date('d/m/Y', strtotime($f['vencimento'])),
        '{AGENCIA_CODIGO}' => $agCodigo, '{NOSSO_NUMERO}' => $nn . '-' . $nnDv,
        '{ESPECIE}' => 'R$', '{ESPECIE_DOC}' => 'DM', '{VALOR_BOLETO}' => number_format($valor, 2, ',', '.'),
        '{VALOR_COBRADO}' => number_format($valor, 2, ',', '.'), '{VALOR_UNITARIO}' => number_format($valor, 2, ',', '.'),
        '{CODIGO_BANCO_COM_DV}' => $codigoBanco, '{LINHA_DIGITAVEL}' => $linhaDigitavel,
        '{LOCAL_PAGAMENTO}' => 'TODOS OS BANCOS, CASA LOTÉRICA OU CORRESPONDENTE BANCÁRIO.',
        '{DATA_DOCUMENTO}' => date('d/m/Y'), '{DATA_PROC}' => date('d/m/Y'), '{DATA_ORIGINAL}' => date('d/m/Y', strtotime($f['vencimento'])),
        '{CARTEIRA}' => 'XX', '{VAR_CARTEIRA}' => '', '{QUANTIDADE}' => '1', '{REFERENCIA}' => (string)$f['id'],
        '{TAXA_BOLETO}' => number_format((float)($f['taxa_emissao'] ?? 0), 2, ',', '.'),
        '{ACRESCIMO}' => number_format((float)($f['taxa_emissao'] ?? 0), 2, ',', '.'), '{DESCONTO}' => '0,00',
        '{MULTA_MORA}' => number_format((float)($bk['multa_pct']??2),1,',','.') . '% + ' . number_format((float)($bk['juros_pct']??1),1,',','.') . '%a.m.',
        '{TEXTO_MULTAMORA}' => 'Após o vencimento cobrar multa de ' . number_format((float)($bk['multa_pct']??2),1,',','.') . '% e juros de ' . number_format((float)($bk['juros_pct']??1),1,',','.') . '% ao mês.',
        // Instruções
        '{INSTRUCOES1}' => h($instrLinhas[0]), '{INSTRUCOES2}' => h($instrLinhas[1]),
        '{INSTRUCOES3}' => h($instrLinhas[2]), '{INSTRUCOES4}' => h($instrLinhas[3]), '{INSTRUCOES5}' => h($instrLinhas[4]),
        // PIX
        '{QRCODE}' => $qrUrl, '{COPIACOLA}' => h($qrEmv), '{LINKCOPIACOLA}' => h($qrEmv),
        // Pagador (sacado)
        '{SACADO_NOME}' => h($f['nome'] ?? ''), '{SACADO_IDNOME}' => h($f['nome'] ?? ''), '{TIPO_PSACADO}' => 'CPF:',
        '{SACADO_CPF}' => $cpfMasc, '{SACADO_CPF2}' => $cpfMasc, '{SACADO_ENDERECO}' => $enderecoCli,
        '{SACADO_BAIRRO}' => h($f['bairro']??''), '{SACADO_CIDADE}' => h($f['cidade']??''), '{SACADO_ESTADO}' => h($f['uf']??''),
        '{SACADO_CEP}' => h($f['cep']??''), '{SACADO_COMPLEMENTO}' => '', '{SACADO_AVALISTA}' => '',
        // Demonstrativos/consumo (não aplicável no WellSystem — fica vazio, nenhum modelo quebra por isso)
        '{DEMONSTRATIVO1}'=>'', '{DEMONSTRATIVO2}'=>'', '{DEMONSTRATIVO3}'=>'', '{DEMONSTRATIVO4}'=>'',
        '{CHAMADOS_ANT}'=>'—','{CHAMADOS_ATUAL}'=>'—','{CONEXOES_ANT}'=>'—','{CONEXOES_ATUAL}'=>'—',
        '{CONTAS_ANT}'=>'—','{CONTAS_ATUAL}'=>'—','{DADOS_ANT}'=>'—','{DADOS_ATUAL}'=>'—',
        '{MESANO_ANT}'=>'—','{MESANO_ATUAL}'=>date('m/Y'),'{MOVIMENTO}'=>'—','{TEMPO_ANT}'=>'—','{TEMPO_ATUAL}'=>'—',
        '{TITULONN}' => (string)$f['id'], '{KNOME}'=>'', '{KVALOR}'=>'', '{KKNOME}'=>'', '{KKVALOR}'=>'', '{ZNOME}'=>'', '{ZVALOR}'=>'',
        // Código de barras real (técnica de imagem por dígito, igual ao original)
        '{BOLETO_BARCODE2}' => ws_barcode_mkauth($bc44Gw !== '' ? $bc44Gw : preg_replace('/\D/', '', $linhaDigitavel)),
    ];
    $out = strtr($modeloHtml, $vars);
    $out = preg_replace('/<!-- BEGIN BLOCK_\w+ -->|<!-- END BLOCK_\w+ -->/', '', $out);
    return ($css ? "<style>$css</style>" : '') . $out;
}

function ws_carne_ficha(array $f, array $prov, string $chavePix, string $provNome, callable $h, string $instrucoesTpl = ''): string {
    $valor = ws_fatura_valor_cobrado($f);   // cobrança = plano + taxa de emissão
    $txid = ws_pix_txid_nome($f['nome'] ?? '', $f['id']);

    // GATEWAY (CelCoin/GalaxPay): usa o PIX dinâmico do gateway quando disponível — é o correto,
    // vinculado ao boleto emitido. Só cai no PIX próprio (chave do provedor) se não houver gateway.
    $pixGwEmv = trim((string)($f['pix_emv'] ?? ''));
    $pixGwQr  = trim((string)($f['pix_qr_url'] ?? ''));
    $doGateway = $pixGwEmv !== '';
    if ($doGateway) {
        $emv   = $pixGwEmv;
        $qrUrl = $pixGwQr !== '' ? $pixGwQr : ('https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=0&data=' . rawurlencode($emv));
    } else {
        $emv   = $chavePix ? ws_pix_emv($chavePix, $provNome, $prov['cidade'] ?? '', $valor, $txid) : '';
        $qrUrl = $emv ? ('https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=0&data=' . rawurlencode($emv)) : '';
    }

    $cpfMasc = preg_replace('/\D/','',(string)($f['cpf_cnpj'] ?? ''));
    $cpfMasc = strlen($cpfMasc)===11 ? substr($cpfMasc,0,3).'.'.$cpfMasc[3].'**.***-**' : h($f['cpf_cnpj'] ?? '');
    $bk = $prov['_banco'] ?? [];
    // Nosso Número + DV fictício (só visual) — determinístico a partir do ID da fatura, SEM
    // pretensão de validade bancária real (avisado no rodapé). Linha digitável no mesmo espírito.
    $nn = str_pad((string)$f['id'], 8, '0', STR_PAD_LEFT);
    $nnDv = (array_sum(str_split($nn)) * 7) % 10;
    $valorCent = str_pad((string)round($valor * 100), 10, '0', STR_PAD_LEFT);

    // LINHA DIGITÁVEL: usa a real (gateway) se houver, senão a fictícia visual.
    $linhaReal = trim((string)($f['linha_digitavel'] ?? ''));
    $linhaFicticia = sprintf('%05d.%05d %05d.%06d %05d.%06d %d %s',
        (crc32($nn.'a') % 90000) + 10000, (int)substr($nn,0,5) . $nnDv,
        (crc32($nn.'b') % 90000) + 10000, (crc32($nn.'c') % 900000) + 100000,
        (crc32($nn.'d') % 90000) + 10000, (crc32($nn.'e') % 900000) + 100000,
        $nnDv, $valorCent);
    $linhaExibida = $linhaReal !== '' ? $linhaReal : $linhaFicticia;

    $codigoTopo = str_pad((string)((int)($bk['codigo'] ?? 999)), 3, '0', STR_PAD_LEFT) . '-' . ((array_sum(str_split($nn)) % 9) + 1);
    $dataDoc = date('d/m/Y');
    $agCodigo = str_pad((string)($bk['agencia'] ?? '00'), 2, '0', STR_PAD_LEFT) . '/' . str_pad((string)($bk['conta'] ?? '002-7'), 5, '0', STR_PAD_LEFT);
    $vencFmt = date('d/m/Y', strtotime($f['vencimento']));
    $nossoNum = $nn . '-' . $nnDv;
    $endereco = h(trim(($f['logradouro']??'').' '.($f['numero']??''))) . ' — ' . h($f['bairro']??'') . ' — ' . h($f['cidade']??'') . '/' . h($f['uf']??'');
    $instrucoes = strtr($instrucoesTpl !== '' ? $instrucoesTpl : "Boleto disponível na Central do Assinante %provedornome%.\nApós o vencimento cobrar multa de %multa%% e juros de %juros%% ao mês.\nApós vencido, sujeito à suspensão dos serviços conforme contrato.", [
        '%provedornome%' => $provNome, '%multa%' => number_format((float)($bk['multa_pct']??2),1,',','.'),
        '%juros%' => number_format((float)($bk['juros_pct']??1),1,',','.'), '%nomecliente%' => $f['nome'] ?? '',
        '%valortitulo%' => number_format($valor,2,',','.'), '%diavencimento%' => $vencFmt,
    ]);
    // Divide as mensagens numa linha em branco: o que estiver ANTES da 1ª linha vazia sai no topo
    // do bloco; o que estiver DEPOIS sai por último (abaixo de wellnet.com.br), na ordem digitada.
    // Normaliza quebras de linha do Windows (\r\n) e Mac antigo (\r) para \n, senão a divisão falha.
    $instrucoes = str_replace(["\r\n", "\r"], "\n", $instrucoes);
    $instrPart = preg_split("/\n[ \t]*\n/", $instrucoes, 2);
    $instrTopo = $instrPart[0] ?? '';
    $instrBase = $instrPart[1] ?? '';
    $mapLinhas = fn($txt) => implode('', array_map(fn($l) => trim($l) === '' ? "<div class='msg-gap'></div>" : "<div class='msg-l'>" . h($l) . "</div>", explode("\n", (string)$txt)));

    $valFmt = number_format($valor,2,',','.');
    // Com logo: mostra SÓ a logo (não repete o nome do provedor ao lado). Sem logo: "W" + nome.
    $logoHtml = trim((string)($prov['_logo'] ?? '')) !== '' ? $prov['_logo'] : ("<span class='w'>W</span><b>" . h($provNome) . "</b>");
    $telefone = $prov['telefone'] ?? '';
    $whats = $prov['whatsapp'] ?? '';

    // CÓDIGO DE BARRAS: usa real do gateway quando disponível; senão o fictício visual.
    $barcode = trim((string)($f['barcode'] ?? ''));
    $bc44 = '';
    if ($barcode !== '' && strlen(preg_replace('/\D/', '', $barcode)) >= 44) {
        $bc44 = preg_replace('/\D/', '', $barcode);
    } elseif ($linhaReal !== '') {
        $bc44 = ws_linha_para_barcode($linhaReal);
    }
    $svgBarras = $bc44 !== '' ? ws_svg_barcode_i25($bc44) : ws_svg_barcode_ficticio($nn . $nnDv . $valorCent);

    // ---- CANHOTO (coluna esquerda, estreita) — resumo pro cliente destacar/guardar. ----
    $canhoto = "<div class='cnL'>"
      . "<div class='cnLogo'>{$logoHtml}</div>"
      . "<div class='cf'><i>Número do Documento</i><b>" . $f['id'] . "</b></div>"
      . "<div class='cf'><i>Vencimento</i><b>" . $vencFmt . "</b></div>"
      . "<div class='cf'><i>Agência/Código</i><b>" . h($agCodigo) . "</b></div>"
      . "<div class='cf'><i>Nosso Número</i><b>" . $nossoNum . "</b></div>"
      . "<div class='cf'><i>Espécie</i><b>R$</b></div>"
      . "<div class='cf'><i>(=) Valor do Documento</i><b>" . number_format((float)($f['valor'] ?? 0), 2, ',', '.') . "</b></div>"
      . "<div class='cf'><i>(-) Desconto/Abatimento</i><b>&nbsp;</b></div>"
      . "<div class='cf'><i>(+) Mora/Multa</i><b>&nbsp;</b></div>"
      . ((float)($f['taxa_emissao'] ?? 0) > 0 ? "<div class='cf'><i>(+) Taxa de Emissão</i><b>" . number_format((float)$f['taxa_emissao'], 2, ',', '.') . "</b></div>" : '')
      . "<div class='cf'><i>(=) Valor Cobrado</i><b>" . ((float)($f['taxa_emissao'] ?? 0) > 0 ? $valFmt : '&nbsp;') . "</b></div>"
      . "<div class='cf'><i>CPF/CNPJ</i><b>" . $cpfMasc . "</b></div>"
      . "<div class='cf' style='display:block'><i>Beneficiário</i><br><b>" . h($provNome) . "</b><br><span class='cnpj-b'>CNPJ: " . h($prov['cnpj'] ?? '') . "</span></div>"
      /* (07/10/2026) os 2 WhatsApp ocupam o espaço que sobra embaixo do canhoto, DISTRIBUÍDOS por igual (antes colados no
         fim, com espaço vazio embaixo) e com letra maior. */
      . (($telefone || $whats) ? "<div class='cnZap'>"
          . ($telefone ? "<div class='zap'><span class='zl'>WhatsApp 1</span><span class='zn'>" . h($telefone) . "</span></div>" : '')
          . ($whats ? "<div class='zap'><span class='zl'>WhatsApp 2</span><span class='zn'>" . h($whats) . "</span></div>" : '')
          . "</div>" : '')
      . "</div>";

    // ---- FICHA (coluna direita, larga) — ficha de compensação tradicional. ----
    $pixChaveInfo = $doGateway
        ? (!empty($f['lytex_id']) ? "<span class='pix-chave'>PIX dinâmico (Lytex)</span>" : "<span class='pix-chave'>CHAVE PIX: " . h(ws_pix_chave_gateway()) . "</span>")
        : ($chavePix ? "<span class='pix-chave'>CHAVE PIX: " . h($chavePix) . "</span>" : '');
    $ficha = "<div class='cnR'>"
      . "<div class='cabec'><div class='bco'>" . h($codigoTopo) . "</div><div class='ld'>" . $linhaExibida . "</div></div>"
      . "<div class='row r-lp'><div class='cel'><i>Local de Pagamento</i><span>TODOS OS BANCOS, CASA LOTÉRICA OU CORRESPONDENTE BANCÁRIO.</span></div><div class='cel'><i>Vencimento</i><b>" . $vencFmt . "</b></div></div>"
      . "<div class='row r-ben'><div class='cel'><i>Beneficiário</i><span>" . h($provNome) . " - CNPJ: " . h($prov['cnpj'] ?? '') . "</span></div><div class='cel'><i>Agência/Código</i><b>" . h($agCodigo) . "</b></div></div>"
      . "<div class='row r-doc'><div class='cel'><i>Data Doc.</i><span>" . $dataDoc . "</span></div><div class='cel'><i>Nº Documento</i><span>" . $f['id'] . "</span></div><div class='cel'><i>Espécie Doc</i><span>Real</span></div><div class='cel'><i>Aceite</i><span>N</span></div><div class='cel'><i>Data Process.</i><span>" . $dataDoc . "</span></div><div class='cel'><i>Nosso Número</i><span>" . $nossoNum . "</span></div></div>"
      . "<div class='row r-uso'><div class='cel'><i>Uso do Banco</i><span>2335-3</span></div><div class='cel'><i>Carteira</i><span>31034-4</span></div><div class='cel'><i>Espécie</i><span>Real</span></div><div class='cel'><i>Quantidade</i><span>&nbsp;</span></div><div class='cel'><i>Valor</i><span>PIX</span></div><div class='cel'><i>(=) Valor Documento</i><b>" . number_format((float)($f['valor'] ?? 0), 2, ',', '.') . "</b></div></div>"
      . "<div class='corpo'>"
      . "<div class='instr'><b>Instruções de responsabilidade do Beneficiário:</b>"
      . $mapLinhas($instrTopo)
      . (((int)($bk['exibir_mes_ref'] ?? 1) && trim((string)($f['competencia'] ?? '')) !== '') ? "<div class='msg-l'><b>Mês referente: " . h(ws_mes_ref_fmt($f['competencia'])) . "</b></div>" : '')
      . (($emv || !empty($bk['anatel']) || !empty($prov['site'])) ? "<div class='msg-gap'></div>" : '')
      . ($pixChaveInfo ? "<div class='msg-l'>{$pixChaveInfo}</div>" : '')
      . (!empty($bk['anatel']) ? "<div class='msg-l'>Autorizado Anatel Ato " . h($bk['anatel']) . "</div>" : '')
      . (!empty($prov['site']) ? "<div class='msg-l'>" . h($prov['site']) . "</div>" : '')
      . ($instrBase !== '' ? "<div class='msg-gap'></div>" . $mapLinhas($instrBase) : '') . "</div>"
      . ($emv ? "<div class='qrbox'><img class='qr' src='" . h($qrUrl) . "' width='82' height='82' alt='QR PIX'></div>" : '')
      . "<div class='lat grid'>"
      . "<div class='cel'><i>(-) Desconto/Abatimento</i><span>&nbsp;</span></div>"
      . "<div class='cel'><i>(+) Mora/Multa</i><span>&nbsp;</span></div>"
      . ((float)($f['taxa_emissao'] ?? 0) > 0 ? "<div class='cel'><i>(+) Taxa de Emissão</i><span>R$ " . number_format((float)$f['taxa_emissao'], 2, ',', '.') . "</span></div>" : '')
      . "<div class='cel'><i>(=) Valor Cobrado</i><b style='display:block;margin-top:4px;margin-left:6px'>R$ " . $valFmt . "</b></div>"
      . "</div></div>"
      . "<div class='pag'><b>Pagador:</b> " . h($f['nome']) . " - CPF: " . $cpfMasc . "<br>" . $endereco . "<br><i>Pagador/Avalista</i></div>"
      . "<div class='rod'><div class='barras'>" . $svgBarras . "</div>"
      . "<div class='aut'>Autenticação Mecânica<br><b>Ficha de Compensação</b></div></div>"
      . "</div>";

    return "<div class='cn2'>" . $canhoto . $ficha . "</div>"
      . "<div class='corte'></div>";
}

/** Barra de código de barras — puramente VISUAL (não codifica nada de verdade, não é lido por
 *  leitor de código de barras real). Serve só pra dar a aparência tradicional de boleto. As larguras
 *  das barras são determinísticas (a partir do "nosso número"), então a MESMA fatura sempre gera a
 *  MESMA barra visualmente (não é aleatório a cada impressão). */
function ws_svg_barcode_ficticio(string $seed): string {
    // Padrão de larguras estilo Code128 (fino/grosso alternando de verdade) — ainda fictício
    // (não codifica dado real), mas com aparência bem mais próxima de um código de barras real:
    // várias barras finas seguidas, ocasionais grossas, sem espaçamento uniforme repetitivo.
    $base = preg_replace('/\D/', '', $seed);
    // MUITAS barras finas (quase tudo 1 unidade, poucas grossas) — quanto mais barras num viewBox
    // largo, mais finas elas aparecem esticadas, ficando bem parecidas com o código real Febraban.
    $digitos = str_split(str_repeat($base . '0123456789', 9));
    $barras = ''; $x = 1; $h = 60;
    foreach ($digitos as $i => $d) {
        if ($i > 430) break;
        $n = (int)$d;
        $w = [1,1,1,1,1,1,1,1,1,2][$n % 10]; // predomina 1 unidade (bem fina), rara de 2
        $preto = ($i + $n) % 3 !== 0;        // ritmo irregular preto/branco
        if ($preto) $barras .= "<rect x='$x' y='0' width='$w' height='$h' fill='#000'/>";
        $x += $w;
    }
    $x += 1;
    return "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 $x $h' style='height:60px;width:100%;max-width:440px;display:block' preserveAspectRatio='none'>"
         . "<rect x='0' y='0' width='$x' height='$h' fill='#fff'/>" . $barras . "</svg>";
}

?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<?php if ($chatbotId):
    /* Robô: o n8n entrega SÓ este HTML ao conversor de PDF, sem o endereço de origem — sem <base>, a logo
       (img.php?…) e o resto dos caminhos relativos não seriam achados. */
    $wsBase = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https' ? 'https' : 'http')
            . '://' . preg_replace('/[^A-Za-z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'))
            . rtrim(str_replace('\\', '/', dirname(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/x/x.php')))), '/') . '/'; ?>
<base href="<?= htmlspecialchars($wsBase, ENT_QUOTES, 'UTF-8') ?>">
<style>.barra{display:none!important}</style>
<?php endif; ?>
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Boleto PIX</title>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<style>
  :root{--vinho:#9E2A3B}*{box-sizing:border-box}
  body{font-family:'Segoe UI',Arial,sans-serif;max-width:210mm;margin:0 auto;padding:8mm;color:#1f2937;background:#fff;box-sizing:border-box}
  /* Logo do boleto SEMPRE limitada — nunca estoura o layout, seja qual for a imagem enviada. */
  .ws-doc-logo{max-height:84px;max-width:300px;width:auto;object-fit:contain}
  .ws-logo,.ws-logo-lg{max-height:84px;max-width:300px;width:auto;object-fit:contain}
  .ficha-2col{width:100%;box-sizing:border-box}
  .ficha-tb{table-layout:fixed;width:100%}
  .barra{position:sticky;top:0;background:var(--vinho);color:#fff;padding:8px;border-radius:8px;margin-bottom:12px;z-index:5;display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:8px}
  .barra button,.barra select{background:#fff;color:var(--vinho);border:0;padding:8px 14px;border-radius:6px;font-weight:700;cursor:pointer;margin:0 4px}
  .barra-nota{display:inline-block;background:rgba(255,255,255,.18);color:#fff;font-size:12px;padding:6px 10px;border-radius:6px;margin:0 4px}
  .folha{margin-bottom:16px}
  .box{border:1px solid #e5e7eb;border-radius:12px;padding:16px;margin-bottom:10px}
  .top{display:flex;justify-content:space-between;gap:14px;border-bottom:2px solid var(--vinho);padding-bottom:10px;margin-bottom:10px}
  .top h1{font-size:17px;margin:0 0 4px;color:var(--vinho)}
  .badge{font-size:11px;background:var(--vinho);color:#fff;padding:2px 8px;border-radius:20px;vertical-align:middle}
  .muted{color:#6b7280;font-size:12.5px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:5px 18px;font-size:13px;margin-bottom:10px}
  .valor{font-size:26px;font-weight:800;color:var(--vinho)}
  .box h3{margin:0 0 10px;color:var(--vinho)}
  .pix{display:flex;gap:16px;align-items:center;flex-wrap:wrap}
  .pix img{border:1px solid #e5e7eb;border-radius:8px}
  .emv{flex:1;min-width:230px}
  .emv textarea{width:100%;height:76px;font-family:monospace;font-size:10.5px;padding:6px;border:1px solid #e5e7eb;border-radius:8px;resize:none}
  /* ---- Modelo Carnê (padrão ficha de compensação): canhoto (esq.) + ficha (dir.) ---- */
  .cn2{display:flex;border:0;margin-bottom:4px;font-size:9px;line-height:1.18;color:#000;background:#fff}
  .corte{border-top:1px dashed #555;text-align:right;font-size:7px;color:#555;margin:2px 0 8px}
  .cnL{width:178px;flex:none;border-right:1px dashed #666;padding:4px 7px;display:flex;flex-direction:column;gap:3px}
  .cnLogo{display:flex;align-items:center;justify-content:center;gap:4px;border-bottom:1.5px solid #000;padding-bottom:3px;margin-bottom:3px;min-height:44px}
  .cnLogo b{font-size:12px;color:var(--vinho);letter-spacing:.3px}
  .cnLogo img{max-height:44px;max-width:100%;object-fit:contain}
  .cnLogo .w{background:var(--vinho);color:#fff;font-weight:900;padding:0 5px;border-radius:2px;font-size:13px}
  .cf{border-bottom:1px solid #000;padding:1px 0;display:flex;justify-content:space-between;align-items:baseline;gap:4px}
  .cf i{font-style:normal;font-size:6.5px;color:#111}
  .cf b{font-size:9px}
  .red{color:var(--vinho);font-weight:700;border-bottom:0;display:block;text-align:center}
  .cnR{flex:1;min-width:0;display:flex;flex-direction:column}
  .cabec{display:flex;align-items:stretch;border-bottom:2px solid #000}
  .cabec .bco{font-size:16px;font-weight:800;padding:3px 8px;border-right:2px solid #000;letter-spacing:1px}
  .cabec .ld{flex:1;text-align:right;font-family:'Courier New',monospace;font-size:11px;font-weight:700;padding:4px 7px 2px;align-self:flex-end}
  .row{display:grid;border-bottom:1px solid #000}
  .cel{border-right:1px solid #000;padding:1px 5px 2px;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
  .cel:last-child{border-right:0}
  .cel i{display:block;font-style:normal;font-size:6.5px;color:#111}
  .cel b,.cel span{font-size:9px}
  .r-lp,.r-ben{grid-template-columns:1fr 150px}
  .r-doc{grid-template-columns:1fr 1fr 1fr .7fr 1.2fr 1.3fr}
  .r-uso{grid-template-columns:1fr 1fr 1fr 1fr 1fr 1.3fr}
  .corpo{display:flex;border-bottom:1px solid #000;flex:1}
  .instr{flex:1;padding:4px 6px;font-size:8.5px;line-height:1.4;border-right:1px solid #000}
  .instr b{font-size:8.5px}
  /* QR do CARNÊ: tamanho em variável — o script no fim da página AMPLIA até a altura da faixa (instruções/valores)
     sem mudar a altura do carnê. Sem script = tamanho antigo (108px tela / 80px impressão). */
  .qrbox{flex:none;width:var(--qr-tela,108px);display:flex;align-items:center;justify-content:flex-start;border-right:1px solid #000;padding:0}
  .qrbox .qr{width:calc(var(--qr-tela,108px) - 1px);height:calc(var(--qr-tela,108px) - 1px);border:1px solid #000;box-sizing:border-box}
  .lat{flex:none;width:150px;display:flex;flex-direction:column}
  .lat .cel{border-right:0;border-bottom:1px solid #000;padding:3px 5px 4px;text-align:center}
  .lat .cel i{text-align:left}
  .lat .cel:last-child{border-bottom:0;justify-content:center;display:flex;flex-direction:column;flex:1}
  .lat b{color:var(--vinho);font-size:12px;display:block;text-align:center}
  .pag{border-bottom:1px solid #000;padding:3px 6px;font-size:8.5px}
  .pag i{font-style:normal;font-size:6.5px;color:#111}
  /* LETRA MAIOR SEM MUDAR O TAMANHO DO CARNÊ (03/10/2026): dados do pagador e "Valor Cobrado" ao lado do QR.
     A altura de cada linha fica TRAVADA no valor antigo (8,5px × 1,18 no pagador; 12px × 1,18 no valor) — a
     letra cresce dentro da mesma linha. Pagador numa linha só por item (nome / endereço), com "…" se não couber,
     para nunca quebrar em mais linhas. */
  .pag{font-size:10.5px;line-height:10.016px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .pag *{line-height:0}
  .lat .cel b{font-size:16px;line-height:14.16px}
  .msg-l{margin-top:1px}
  .msg-gap{height:5px}
  .pix-chave{color:var(--vinho);font-weight:700}
  .cbar{margin-top:10px;border-top:1px dashed #e5e7eb;padding-top:8px}
  .cbar .muted{font-size:11px;color:#6b7280;margin-bottom:4px}
  .cbar-svg{overflow-x:auto;max-width:100%}
  .cbar-svg svg.pixbar{width:100%;height:64px;display:block}
  .cbar .linha{font-family:monospace;font-size:12px;letter-spacing:.5px;margin-top:4px;word-break:break-all}
  .cnpj-b{font-size:8.5px;font-weight:600;color:#000}
  /* WhatsApp do canhoto: preenchem o espaço livre embaixo, distribuídos por igual, letra maior */
  .cnZap{flex:1;display:flex;flex-direction:column;justify-content:space-evenly;min-height:34px;padding:2px 0}
  .cnZap .zap{display:flex;justify-content:space-between;align-items:baseline;gap:4px}
  .cnZap .zl{font-size:9.5px;font-weight:600;color:#000}
  .cnZap .zn{font-size:11.5px;font-weight:800;color:var(--vinho);white-space:nowrap}
  .rod{display:flex;align-items:flex-end;justify-content:space-between;padding:3px 6px 2px;gap:8px}
  .barras{flex:1}
  .aut{font-size:7px;text-align:right;white-space:nowrap}
  .capa{border:2px solid var(--vinho);border-radius:10px;padding:22px;text-align:center;margin-bottom:14px;box-sizing:border-box}
  .capa h1{color:var(--vinho);font-size:22px;margin:8px 0}
  @media print{.barra{display:none}body{padding:0;max-width:none}.folha{page-break-after:always}.folha:last-child{page-break-after:auto}.box{border-color:#ccc}
    .capa{padding:22px;margin:0}
    .topo-fichas{height:10mm}}
  @media(max-width:480px){.cn2{flex-direction:column}.cnL{width:100%;border-right:0;border-bottom:1px dashed #666}.corpo{flex-direction:column}.qrbox,.lat{width:100%;border-right:0}}
  /* Edição rápida antes de imprimir (valor/vencimento) — some sozinho ao imprimir */
  .ficha-editar{background:#fffbea;border:1px dashed #d97706;border-radius:6px;padding:6px 8px;margin-bottom:6px;font-size:10.5px;display:flex;gap:10px;flex-wrap:wrap;align-items:center}
  .ficha-editar input{font-size:11px;padding:2px 5px;border:1px solid #ccc;border-radius:4px;width:90px}
  @media print{.ficha-editar{display:none}}
</style></head><body>
<div class="barra">
  <button onclick="window.print()">🖨️ Imprimir / Salvar PDF (<?= count($ids) ?>)</button>
  <?php /* Cartão de crédito pela Lytex (opção em Financeiro → Gateway): botão para a página segura de pagamento dela. */
  if (count($ids) === 1 && is_file(__DIR__ . '/lytex.php')) { require_once __DIR__ . '/lytex.php';
      $fq = $db->prepare("SELECT lytex_id, gateway_raw, status FROM ws_fatura WHERE id=?"); $fq->execute([(int)$ids[0]]); $fc = $fq->fetch(PDO::FETCH_ASSOC) ?: [];
      $lkC = in_array($fc['status'] ?? '', ['aberto', 'vencido'], true) ? ws_lytex_link_cartao($fc) : '';
      if ($lkC !== '') echo '<a href="' . htmlspecialchars($lkC, ENT_QUOTES) . '" target="_blank" rel="noopener" style="background:#fff;color:#111;border-radius:6px;padding:7px 14px;font-weight:700;text-decoration:none;margin-left:6px">💳 Pagar com cartão</a>'; } ?>
  <script>
    function wsFichaAtualizar(fid, campo, valor){
      fetch('boleto.php?ajax_salvar_campo=1', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: 'fatura_id='+fid+'&campo='+campo+'&valor='+encodeURIComponent(valor)})
        .then(function(r){return r.json()}).then(function(d){ if(d.ok) location.reload(); else alert('Falha ao salvar.'); });
    }
  </script>
  <select onchange="location='boleto.php?fatura=<?= implode(',', $ids) ?>&layout='+this.value+'<?= $comCapa?'&capa=1':'' ?>&tam=<?= $porPagina ?><?= isset($_GET['modelo'])?'&modelo='.urlencode($_GET['modelo']):'' ?>'">
    <?php foreach (['simples'=>'Boleto (simples)','detalhado'=>'Boleto (detalhado)','carne'=>'Carnê (WellSystem)'] as $k=>$v) echo "<option value='$k' ".($layout===$k?'selected':'').">$v</option>"; ?>
  </select>
  <?php if ($layout === 'mkauth'): $modeloAtual = preg_replace('/[^a-z0-9_]/i', '', $_GET['modelo'] ?? 'proprio') ?: 'proprio'; ?>
  <select onchange="location='boleto.php?fatura=<?= implode(',', $ids) ?>&layout=mkauth&tam=<?= $porPagina ?><?= $comCapa?'&capa=1':'' ?>&modelo='+this.value">
    <?php foreach (ws_boleto_layout_disponiveis() as $nomeModelo => $mini) echo "<option value='" . h($nomeModelo) . "' " . ($modeloAtual===$nomeModelo?'selected':'') . ">" . h(ucwords(str_replace('_',' ',$nomeModelo))) . "</option>"; ?>
  </select>
  <?php if ($mini = (ws_boleto_layout_disponiveis()[$modeloAtual] ?? '')): ?>
    <a href="<?= h($mini) ?>" target="_blank" title="Ver miniatura deste modelo">🖼️ ver modelo</a>
  <?php endif; ?>
  <?php endif; ?>
  <?php if ($layout === 'carne' || $layout === 'mkauth'): ?>
  <select onchange="location='boleto.php?fatura=<?= implode(',', $ids) ?>&layout=<?= $layout ?>&tam=<?= $porPagina ?><?= $layout==='mkauth'?'&modelo='.urlencode($modeloAtual ?? 'proprio'):'' ?>&capa='+this.value">
    <option value="0" <?= !$comCapa?'selected':'' ?>>Sem capa</option>
    <option value="1" <?= $comCapa?'selected':'' ?>>Com capa</option>
  </select>
  <?php endif; ?>
  <?php if ($layout === 'carne'): ?>
  <select onchange="location='boleto.php?fatura=<?= implode(',', $ids) ?>&layout=<?= $layout ?>&capa=<?= $comCapa?1:0 ?>&tam='+this.value" title="Quantas fichas cabem por página impressa (A4)">
    <option value="3" <?= $porPagina===3?'selected':'' ?>>3 por página (padrão)</option>
    <option value="2" <?= $porPagina===2?'selected':'' ?>>2 por página</option>
    <option value="1" <?= $porPagina===1?'selected':'' ?>>1 por página (cheia)</option>
  </select>
  <?php elseif ($layout === 'mkauth'): ?>
  <span class="barra-nota" title="Cada modelo de galeria ocupa uma folha A4 inteira">1 boleto por folha</span>
  <?php endif; ?>
</div>
<?php
if (($layout === 'carne' || $layout === 'mkauth') && $comCapa):
    $primeiro = null; $st->execute([$ids[0]]); $primeiro = $st->fetch();
    if ($primeiro): ?>
<div class="capa">
  <?= $logo ?>
  <h1><?= $h($provNome) ?></h1>
  <p class="muted">CNPJ: <?= $h($prov['cnpj'] ?? '') ?> · <?= $h($prov['telefone'] ?? '') ?></p>
  <hr style="margin:20px 0;border-color:#eee">
  <h2>Carnê de pagamento</h2>
  <p><b><?= $h($primeiro['nome']) ?></b></p>
  <p class="muted">Contém <?= count($ids) ?> ficha(s) de pagamento</p>
</div>
<div class="ficha-quebra"></div>
<?php endif; endif; ?>
<?php if ($layout === 'carne'): ?><div class="topo-fichas"></div><?php endif; ?>
<?php
$achou = 0; $seq = 0;
foreach ($ids as $id) { $st->execute([$id]); $f = $st->fetch(); if ($f) {
    $f['taxa_emissao'] = ws_fatura_taxa_efetiva($f);   // taxa do cadastro do provedor entra como acréscimo ao imprimir (título sem taxa gravada)
    /* Título vindo da migração MK-Auth: tem celcash_charge_id (selo "Galaxpay") mas ainda não tem
       o PIX/boleto reais daquela cobrança — completa AQUI, uma vez, sem gerar cobrança nova. Ver
       o comentário de ws_celcash_completar_importada() em celcash.php para o motivo completo.

       MAS só faz sentido buscar no gateway se a CONTA escolhida pro título (a do próprio título,
       ou a do contrato) for mesmo do tipo "gateway" (ws_banco.emissao='gateway'). Quando o operador
       escolhe uma conta "própria" (ex.: WELLNET local) — na ficha do contrato, campo "Conta do
       boleto/PIX" — a intenção é clara: parar de usar o CelCoin/GalaxPay para ESTE título e passar a
       cobrar pela chave própria. Sem esta checagem, a busca no gateway roda igual, acha a cobrança
       de verdade (agora que está corrigida) e o PIX/boleto do gateway SEMPRE vence na hora de
       montar a ficha — o QR não desaparece por acaso, ele passa a ser o do gateway (ou, se aquela
       cobrança específica não tiver PIX, fica em branco) e a escolha de conta própria é ignorada.
       Também limpamos qualquer PIX/boleto de gateway JÁ GRAVADO na fatura nesse caso — cobre o
       título que já ficou com esse dado gravado antes desta checagem existir. Isso é só para MONTAR
       a ficha impressa; não apaga nada no banco de dados. */
    /* 30/09/2026: a conta do TÍTULO vale mesmo SEM chave PIX. $bancoDe() troca conta sem PIX pela conta padrão (ela
       serve para achar uma CHAVE); usada aqui, a conta "LYTEX (API)" (sem chave própria) virava a conta padrão
       "boleto próprio" → a linha digitável e o PIX da Lytex eram apagados e o boleto saía com o PIX da chave do provedor. */
    $bkTitulo = $bancosMap[(int)($f['banco_id'] ?? 0)] ?? $bancoDe($f['banco_id'] ?? 0);
    $contaPropria = !empty($bkTitulo) && (($bkTitulo['emissao'] ?? '') === 'proprio');
    if ($contaPropria) {
        $f['pix_emv'] = $f['pix_qr_url'] = $f['boleto_url'] = $f['linha_digitavel'] = $f['barcode'] = null;
        /* VENCIDO (01/10/2026): o boleto/PIX PRÓPRIO sai com o valor ATUALIZADO (multa + juros até hoje, a mesma conta da
           baixa — ws_fatura_encargos). Só na impressão: a fatura no banco de dados continua com o valor e o vencimento originais. */
        if (function_exists('ws_fatura_encargos') && in_array((string)($f['status'] ?? ''), ['aberto', 'vencido'], true)) {
            [$dEnc, $mEnc, $jEnc] = ws_fatura_encargos($f);
            if ($dEnc > 0) { $f['valor'] = round((float)$f['valor'] + $mEnc + $jEnc, 2);
                $f['obs'] = trim((string)($f['obs'] ?? '') . ' Valor atualizado até ' . date('d/m/Y') . ': multa R$ ' . number_format($mEnc, 2, ',', '.') . ' + juros R$ ' . number_format($jEnc, 2, ',', '.') . ' (' . $dEnc . ' dia(s) de atraso).'); }
        }
    } elseif (function_exists('ws_celcash_completar_importada')) {
        ws_celcash_completar_importada($db, $f);
    }
    $bk = $bkTitulo;
    $prov['_local'] = $bk['local_pgto'] ?? ''; $prov['_multa'] = $bk['multa_pct'] ?? 2; $prov['_juros'] = $bk['juros_pct'] ?? 1;
    $prov['_banco'] = $bk ?: []; $prov['_logo'] = $logo;
    if ($modeloProprio !== '') {
        // Modelo HTML enviado pelo operador — troca as variáveis pelos dados reais da fatura.
        // PIX do gateway (Lytex/CelCash) quando a cobrança foi emitida lá; senão o PIX da chave da conta
        $emvM = trim((string)($f['pix_emv'] ?? '')) !== '' ? trim((string)$f['pix_emv'])
               : ($chaveDe($f['banco_id'] ?? 0) ? ws_pix_emv($chaveDe($f['banco_id'] ?? 0), $provNome, $prov['cidade'] ?? '', ws_fatura_valor_cobrado($f), 'WS'.$f['id']) : '');
        $qrM = $emvM ? ('https://api.qrserver.com/v1/create-qr-code/?size=130x130&margin=0&data=' . rawurlencode($emvM)) : '';
        echo '<div class="ficha-slot"><div class="ficha-in">' . strtr($modeloProprio, [
            '%nomecliente%' => $h($f['nome'] ?? ''), '%valortitulo%' => number_format(ws_fatura_valor_cobrado($f),2,',','.'),
            '%diavencimento%' => date('d/m/Y', strtotime($f['vencimento'])), '%nossonumero%' => str_pad((string)$f['id'],8,'0',STR_PAD_LEFT),
            '%provedornome%' => $h($provNome), '%pixqr%' => $qrM, '%pixcopiaecola%' => h($emvM),
            '%linhadigitavel%' => h((string)($f['linha_digitavel'] ?? '')),
        ]) . '</div></div>';
        $seq++; if ($seq % $porPagina === 0 && $seq < count($ids)) echo '<div class="ficha-quebra"></div><div class="topo-fichas"></div>';
    } elseif ($layout === 'mkauth') {
        $modeloEscolhido = preg_replace('/[^a-z0-9_]/i', '', $_GET['modelo'] ?? 'proprio') ?: 'proprio';
        echo '<div class="ficha-slot ficha-mkauth">' . ws_boleto_layout_render($modeloEscolhido, $f, $prov, $chaveDe($f['banco_id'] ?? 0), $provNome, $textosBoleto['instrucoes']) . '</div>';
        $seq++;
        // Modelo de galeria = folha A4 inteira (794×1123px) → sempre 1 por página.
        if ($seq < count($ids)) echo '<div class="ficha-quebra"></div>';
    } elseif ($layout === 'carne') {
        echo '<div class="ficha-slot"><div class="ficha-in">' . ws_carne_ficha($f, $prov, $chaveDe($f['banco_id'] ?? 0), $provNome, $h, $textosBoleto['instrucoes']) . '</div></div>';
        $seq++;
        // Quebra de página a cada N fichas (N = tamanho escolhido), pra imprimir certinho no papel.
        // + espaçador do topo (só aparece na impressão): a margem de segurança vale em TODAS as folhas.
        if ($seq % $porPagina === 0 && $seq < count($ids)) echo '<div class="ficha-quebra"></div><div class="topo-fichas"></div>';
    } else {
        echo ws_boleto_box($f, $prov, $chaveDe($f['banco_id'] ?? 0), $provNome, $provCidade, $logo, $layout, $h, $hdoc);
    }
    $achou++;
} }
if (!$achou) echo '<p class="muted">Nenhuma fatura encontrada.</p>';
?>
<?php if (($layout === 'carne' || $layout === 'mkauth') && $achou): ?>
<style>
  /* Quebra de página entre grupos de fichas (inserida no PHP a cada N fichas). Sem linha nenhuma. */
  .ficha-quebra{page-break-after:always;height:0;line-height:0;font-size:0;border:0;margin:0}
  .ficha-slot{overflow:hidden}
  <?php if ($layout === 'carne'):
  /* CARNÊ N POR FOLHA — ENCAIXE EXATO (07/10/2026).
     - Folha A4 com margem de 5mm (a impressora não corta a 1ª ficha: com margem 0 a borda ficava na área que a
       impressora não imprime) e cada ficha numa FAIXA FIXA de 1/N da área útil → nunca estoura para cima, para
       baixo nem para o lado.
     - A ficha é desenhada no tamanho base e AMPLIADA por igual (letra, QR, código de barras, logo) até encher a
       faixa: o fator é medido NO PRÓPRIO COMPUTADOR que imprime (fontes do Windows etc.), antes da impressão,
       com o layout de impressão simulado (classe medir-print). Assim cabe exatamente, sem cortar.
     - Sem o script (navegador antigo), fator 1 = ficha base dentro da faixa, que já cabe. */
  /* (07/10/2026 16h) margem da PÁGINA = 0 → o navegador NÃO imprime cabeçalho/rodapé (data, endereço, título, nº da página);
     a área de segurança da impressora fica DENTRO da folha (8 mm em cima/embaixo, 7 mm nos lados), maior que antes (5/6 mm),
     porque no modo padrão ainda encostava em cima e embaixo. */
  $mgV = 8; $mgH = 7; $gapMm = 3;
  $areaH = 297 - 2 * $mgV; $areaW = 210 - 2 * $mgH;
  $altMm = floor((($areaH - $porPagina * $gapMm) / $porPagina) * 10) / 10;   // N faixas + N espaços ≤ área útil
  $regras = "
    .cn2{font-size:8.5px;line-height:1.2;margin:0}
    .cnLogo{min-height:46px;padding-bottom:2px;margin-bottom:2px}
    .cnLogo img{max-height:44px;max-width:100%}
    .cf{padding:0}
    .cf i,.cel i{font-size:6.5px}
    .cf b,.cel b,.cel span{font-size:8.5px}
    .cel{padding:1px 4px 1px}
    .cabec .bco{font-size:14px;padding:1px 6px}
    .cabec .ld{font-size:10px;padding:2px 6px 1px}
    .instr{padding:2px 5px;font-size:8px;line-height:1.3}
    .msg-l{margin-top:0}
    .msg-gap{height:3px}
    .qrbox{width:var(--qr-print,84px);padding:0}
    .qrbox .qr{width:calc(var(--qr-print,84px) - 1px);height:calc(var(--qr-print,84px) - 1px)}
    .lat{width:128px}
    .lat .cel{padding:1px 5px 1px}
    .r-lp,.r-ben{grid-template-columns:1fr 128px}
    .pag{padding:1px 5px;font-size:9.5px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .pag *{line-height:1.15}
    .lat .cel b{font-size:13px;line-height:1.1}
    .ficha-slot .barras svg{height:48px}
    .ficha-slot{width:{$areaW}mm;height:{$altMm}mm;max-height:{$altMm}mm;overflow:hidden;margin:0 0 {$gapMm}mm 0;box-sizing:border-box;page-break-inside:avoid;break-inside:avoid}
    .ficha-in{width:calc({$areaW}mm / var(--fz,1));zoom:var(--fz,1)}
    .ficha-slot{border-bottom:1px dashed #555}                         /* linha de corte (pontilhada) abaixo de cada ficha */
    .ficha-editar,.topo-fichas,.barra{display:none!important}
  ";
  // mesma regra usada para MEDIR na tela (body.medir-print) — prefixo em cada seletor
  $regrasMedir = preg_replace_callback('/([^{}]+)\{/', fn($m) => implode(',', array_map(fn($sel) => 'body.medir-print ' . trim($sel), explode(',', $m[1]))) . '{', $regras);
  ?>
  @media print{
    @page{ size:A4; margin:0 }
    html{ padding:0!important; margin:0!important; background:#fff }
    body{ padding:0 <?= $mgH ?>mm!important; margin:0!important; max-width:none!important; background:#fff }
    /* espaço de segurança no TOPO de CADA folha (1ª ficha da folha), não só da primeira */
    .capa{ margin-top:<?= $mgV ?>mm!important }
    <?= $regras ?>
    .topo-fichas{ display:block!important; height:<?= $mgV ?>mm!important; margin:0!important; padding:0!important }
  }
  <?= $regrasMedir ?>
  body.medir-print .ficha-in{zoom:1!important}
  <?php else: ?>
  /* Modelos de galeria (MK-Auth): cada boleto é uma folha A4 fixa (794×1123px).
     Impressão sem margem extra pra a arte casar com a borda do papel. */
  @media print{
    @page{ size:A4; margin:0 }
    body{ padding:0; max-width:none; margin:0 }
    .ficha-slot{ page-break-inside:avoid; page-break-after:always; }
    .ficha-slot:last-of-type{ page-break-after:auto }
  }
  <?php endif; ?>
</style>
<?php endif; ?>
<p class="muted ws-rodape-gerado" style="text-align:center">Gerado pelo WellSystem ERP · <?= date('d/m/Y H:i\h') ?></p>
<style>@media print{.ws-rodape-gerado{display:none}}</style>
<script>
  /* QR DO CARNÊ MAIOR, NO ESPAÇO QUE JÁ EXISTE: cada faixa (.corpo) tem a altura dada pelas instruções/valores e o
     QR ficava menor que ela. Aqui o QR cresce até a altura da faixa; se isso fizer o texto quebrar e a faixa crescer,
     volta (busca binária) ao MAIOR tamanho que NÃO muda a altura -> o carnê continua do mesmo tamanho e cabem as
     mesmas fichas por folha. Tela (--qr-tela) e impressão (--qr-print) são medidas separadamente. */
  (function(){
    function ajustar(varName, base){
      document.querySelectorAll('.corpo').forEach(function(c){
        var box = c.querySelector('.qrbox'); if(!box) return;
        box.style.removeProperty(varName);
        var h0 = c.getBoundingClientRect().height; if(!h0) return;
        var cabe = function(px){ box.style.setProperty(varName, px+'px'); return c.getBoundingClientRect().height <= h0 + 0.01; };   // altura NÃO pode crescer
        var lo = base, hi = Math.min(Math.floor(h0) - 1, 170);
        if(hi <= lo){ box.style.removeProperty(varName); return; }
        if(cabe(hi)) return;                         // cabe inteiro na altura da faixa
        while(hi - lo > 1){ var m = Math.floor((lo+hi)/2); if(cabe(m)) lo = m; else hi = m; }
        box.style.setProperty(varName, lo+'px');
      });
    }
    function tela(){ ajustar('--qr-tela', 108); }
    function impressao(){ if (document.body.getAttribute('data-carne-fz')) return;   // carnê: já encaixado (abaixo)
                          ajustar('--qr-print', 80); }
    window.wsQrAjustar = ajustar;
    if (document.readyState === 'complete') tela(); else window.addEventListener('load', tela);
    // impressão: mede com o layout de impressão ativo (fontes/colunas menores)
    try { var mq = window.matchMedia('print'); var f = function(e){ if(e.matches) impressao(); };
      if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); } catch(e){}
    window.addEventListener('beforeprint', function(){ setTimeout(impressao, 0); });
  })();
  /* CARNÊ — ENCAIXE EXATO NA FAIXA (07/10/2026). Simula o layout de impressão na tela (body.medir-print), com as
     fontes deste computador, e acha o MAIOR fator de ampliação (--fz) em que a ficha, desenhada com largura
     faixa/fz, ainda cabe na altura da faixa (altura × fz ≤ faixa). Tudo cresce junto: letra, QR, barras, logo.
     O QR também cresce dentro da própria faixa da ficha (sem mudar a altura). Roda ao abrir e antes de imprimir. */
  (function(){
    var FAIXA_MM = <?= ($layout === 'carne' && isset($altMm)) ? json_encode((float)$altMm) : 'null' ?>;
    if (!FAIXA_MM || !document.querySelector('.ficha-in')) return;
    var MM = 96 / 25.4, b = document.body;
    function encaixar(){
      b.classList.add('medir-print');
      var fichas = [].slice.call(document.querySelectorAll('.ficha-in'));
      var alvo = FAIXA_MM * MM * 0.96;                           // 4% de folga: não encosta nas bordas da faixa
      function alturaCom(fz){                                    // altura FINAL (ampliada) da ficha mais alta
        b.style.setProperty('--fz', fz);
        if (window.wsQrAjustar) window.wsQrAjustar('--qr-print', 84);
        var m = 0; fichas.forEach(function(f){ m = Math.max(m, f.getBoundingClientRect().height); });
        return m * fz;
      }
      /* teto 1,22: acima disso a largura de desenho (faixa/fz) fica estreita, as colunas apertam e o texto corta
         (acontecia com 1 e 2 por folha). Com 3 por folha o limite é a altura (~1,1). */
      var lo = 0.6, hi = 1.22;
      if (alturaCom(1) > alvo) hi = 1; else lo = 1;               // base já não cabe? então reduz (nunca estoura)
      for (var k = 0; k < 18; k++) { var m = (lo + hi) / 2; if (alturaCom(m) <= alvo) lo = m; else hi = m; }
      var fz = Math.floor(lo * 1000) / 1000;
      alturaCom(fz);                                             // deixa o QR ajustado no fator escolhido
      b.style.setProperty('--fz', fz); b.setAttribute('data-carne-fz', fz);
      b.classList.remove('medir-print');
    }
    var feito = false;
    function rodar(){ try { encaixar(); feito = true; } catch(e){ b.classList.remove('medir-print'); } }
    if (document.readyState === 'complete') rodar(); else window.addEventListener('load', rodar);
    window.addEventListener('beforeprint', function(){ if (!feito) rodar(); });
    // fontes da web carregando depois mudam as medidas: refaz quando terminarem
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function(){ if (feito) rodar(); });
  })();
  // Gera o PIX como CÓDIGO DE BARRAS (Code128 do EMV) — mesmo conteúdo do QR; o leitor lê e abre o PIX.
  (function(){
    if (typeof JsBarcode === 'undefined') return;
    document.querySelectorAll('svg.pixbar').forEach(function(svg){
      var emv = svg.getAttribute('data-emv') || ''; if(!emv) return;
      try { JsBarcode(svg, emv, {format:'CODE128', displayValue:false, margin:0, height:60, width:1}); } catch(e){}
    });
  })();
</script>
</body></html>
