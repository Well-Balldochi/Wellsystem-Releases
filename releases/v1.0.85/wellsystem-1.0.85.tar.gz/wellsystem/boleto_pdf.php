<?php
/**
 * WellSystem — BOLETO e CARNÊ em PDF gerados no próprio servidor (para anexar nas mensagens).
 *
 * Por que aqui e não no boleto.php: o boleto.php é uma página HTML para o navegador imprimir. Para
 * mandar o PDF pelo WhatsApp sem ninguém abrir tela nenhuma, o arquivo tem de nascer no servidor —
 * e sem depender de nada instalado no Linux (wkhtmltopdf, Chrome) nem de site externo.
 * Por isso este arquivo tem:
 *   - um gerador de QR Code (PIX) em PHP puro (modo byte, correção M, versões 1–40);
 *   - um gravador de PDF mínimo (Helvetica, linhas, retângulos e imagem JPEG).
 * O QR é desenhado com retângulos vetoriais: não precisa de GD nem de imagem.
 *
 * Código de barras SÓ quando a fatura tem linha digitável REAL (emitida por gateway/banco).
 * Sem ela, o pagamento é pelo PIX — nunca se desenha código de barras inventado.
 *
 * Uso: ws_pdf_faturas($db, [ids], 'boleto'|'carne') → ['pdf' => bytes, 'nome' => arquivo] ou null.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/pix.php';

/* =============================================================================================
 * QR CODE (ISO/IEC 18004) — modo byte, nível M. Retorna matriz [linha][coluna] de bool (true=escuro).
 * ============================================================================================= */
function ws_qr_gf_mul(int $x, int $y): int {
    $z = 0;
    for ($i = 7; $i >= 0; $i--) { $z = ($z << 1) ^ (($z >> 7) * 0x11D); $z ^= (($y >> $i) & 1) * $x; }
    return $z & 0xFF;
}
function ws_qr_rs_divisor(int $grau): array {
    $r = array_fill(0, $grau, 0); $r[$grau - 1] = 1; $raiz = 1;
    for ($i = 0; $i < $grau; $i++) {
        for ($j = 0; $j < $grau; $j++) { $r[$j] = ws_qr_gf_mul($r[$j], $raiz); if ($j + 1 < $grau) $r[$j] ^= $r[$j + 1]; }
        $raiz = ws_qr_gf_mul($raiz, 0x02);
    }
    return $r;
}
function ws_qr_rs_resto(array $dados, array $div): array {
    $r = array_fill(0, count($div), 0);
    foreach ($dados as $b) {
        $f = $b ^ array_shift($r); $r[] = 0;
        foreach ($div as $i => $d) $r[$i] ^= ws_qr_gf_mul($d, $f);
    }
    return $r;
}
function ws_qr_modulos_brutos(int $v): int {
    $r = (16 * $v + 128) * $v + 64;
    if ($v >= 2) { $n = intdiv($v, 7) + 2; $r -= (25 * $n - 10) * $n - 55; if ($v >= 7) $r -= 36; }
    return $r;
}
function ws_qr_alinhamento(int $v): array {
    if ($v === 1) return [];
    $n = intdiv($v, 7) + 2; $tam = $v * 4 + 17;
    $passo = ($v === 32) ? 26 : (int)(ceil(($v * 4 + 4) / ($n * 2 - 2)) * 2);
    $r = [6];
    for ($p = $tam - 7; count($r) < $n; $p -= $passo) array_splice($r, 1, 0, [$p]);
    return $r;
}
function ws_qr_matriz(string $texto): ?array {
    // Nível M
    static $ECC = [-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28];
    static $BLOCOS = [-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49];
    $bytes = array_values(unpack('C*', $texto) ?: []);
    $len = count($bytes);
    $ver = 0;
    for ($v = 1; $v <= 40; $v++) {
        $capDados = intdiv(ws_qr_modulos_brutos($v), 8) - $ECC[$v] * $BLOCOS[$v];
        $bitsCont = $v < 10 ? 8 : 16;
        if (4 + $bitsCont + 8 * $len <= $capDados * 8) { $ver = $v; break; }
    }
    if (!$ver) return null;
    $capDados = intdiv(ws_qr_modulos_brutos($ver), 8) - $ECC[$ver] * $BLOCOS[$ver];
    // Bits: modo byte (0100) + contagem + dados + terminador + completa byte + preenchimento
    $bits = '0100' . str_pad(decbin($len), $ver < 10 ? 8 : 16, '0', STR_PAD_LEFT);
    foreach ($bytes as $b) $bits .= str_pad(decbin($b), 8, '0', STR_PAD_LEFT);
    $bits .= str_repeat('0', min(4, $capDados * 8 - strlen($bits)));
    $bits .= str_repeat('0', (8 - strlen($bits) % 8) % 8);
    $cw = array_map('bindec', str_split($bits, 8));
    for ($pad = 0xEC; count($cw) < $capDados; $pad ^= 0xEC ^ 0x11) $cw[] = $pad;
    // Blocos + correção + intercalação
    $nb = $BLOCOS[$ver]; $eccLen = $ECC[$ver];
    $brutos = intdiv(ws_qr_modulos_brutos($ver), 8);
    $curtos = $nb - $brutos % $nb; $tamCurto = intdiv($brutos, $nb);
    $div = ws_qr_rs_divisor($eccLen);
    $blocos = []; $eccs = []; $k = 0;
    for ($i = 0; $i < $nb; $i++) {
        $n = $tamCurto - $eccLen + ($i < $curtos ? 0 : 1);
        $d = array_slice($cw, $k, $n); $k += $n;
        $blocos[] = $d; $eccs[] = ws_qr_rs_resto($d, $div);
    }
    $final = [];
    for ($i = 0; $i < $tamCurto + 1; $i++) foreach ($blocos as $d) if ($i < count($d)) $final[] = $d[$i];
    for ($i = 0; $i < $eccLen; $i++) foreach ($eccs as $e) $final[] = $e[$i];

    $tam = $ver * 4 + 17;
    $m = array_fill(0, $tam, array_fill(0, $tam, false));
    $fn = array_fill(0, $tam, array_fill(0, $tam, false));
    $set = function (int $x, int $y, bool $escuro) use (&$m, &$fn) { $m[$y][$x] = $escuro; $fn[$y][$x] = true; };
    for ($i = 0; $i < $tam; $i++) { $set(6, $i, $i % 2 === 0); $set($i, 6, $i % 2 === 0); }
    foreach ([[3, 3], [$tam - 4, 3], [3, $tam - 4]] as [$cx, $cy]) {
        for ($dy = -4; $dy <= 4; $dy++) for ($dx = -4; $dx <= 4; $dx++) {
            $xx = $cx + $dx; $yy = $cy + $dy;
            if ($xx >= 0 && $xx < $tam && $yy >= 0 && $yy < $tam) { $dist = max(abs($dx), abs($dy)); $set($xx, $yy, $dist !== 2 && $dist !== 4); }
        }
    }
    $al = ws_qr_alinhamento($ver); $na = count($al);
    for ($i = 0; $i < $na; $i++) for ($j = 0; $j < $na; $j++) {
        if (($i === 0 && $j === 0) || ($i === 0 && $j === $na - 1) || ($i === $na - 1 && $j === 0)) continue;
        for ($dy = -2; $dy <= 2; $dy++) for ($dx = -2; $dx <= 2; $dx++) $set($al[$i] + $dx, $al[$j] + $dy, max(abs($dx), abs($dy)) !== 1);
    }
    $formato = function (int $mask) use (&$set, $tam) {
        $dados = (0 << 3) | $mask;   // nível M = 00
        $rem = $dados;
        for ($i = 0; $i < 10; $i++) $rem = ($rem << 1) ^ (($rem >> 9) * 0x537);
        $b = (($dados << 10) | $rem) ^ 0x5412;
        $bit = fn($i) => (($b >> $i) & 1) === 1;
        for ($i = 0; $i < 6; $i++) $set(8, $i, $bit($i));
        $set(8, 7, $bit(6)); $set(8, 8, $bit(7)); $set(7, 8, $bit(8));
        for ($i = 9; $i < 15; $i++) $set(14 - $i, 8, $bit($i));
        for ($i = 0; $i < 8; $i++) $set($tam - 1 - $i, 8, $bit($i));
        for ($i = 8; $i < 15; $i++) $set(8, $tam - 15 + $i, $bit($i));
        $set(8, $tam - 8, true);
    };
    $formato(0);
    if ($ver >= 7) {
        $rem = $ver;
        for ($i = 0; $i < 12; $i++) $rem = ($rem << 1) ^ (($rem >> 11) * 0x1F25);
        $b = ($ver << 12) | $rem;
        for ($i = 0; $i < 18; $i++) { $bit = (($b >> $i) & 1) === 1; $a = $tam - 11 + $i % 3; $c = intdiv($i, 3); $set($a, $c, $bit); $set($c, $a, $bit); }
    }
    // Dados em zigue-zague
    $i = 0; $totalBits = count($final) * 8;
    for ($dir = $tam - 1; $dir >= 1; $dir -= 2) {
        if ($dir === 6) $dir = 5;
        for ($vert = 0; $vert < $tam; $vert++) for ($j = 0; $j < 2; $j++) {
            $x = $dir - $j; $sobe = (($dir + 1) & 2) === 0; $y = $sobe ? $tam - 1 - $vert : $vert;
            if (!$fn[$y][$x] && $i < $totalBits) { $m[$y][$x] = (($final[$i >> 3] >> (7 - ($i & 7))) & 1) === 1; $i++; }
        }
    }
    $mascara = function (array $mat, int $k) use ($fn, $tam): array {
        for ($y = 0; $y < $tam; $y++) for ($x = 0; $x < $tam; $x++) {
            if ($fn[$y][$x]) continue;
            switch ($k) {
                case 0: $inv = ($x + $y) % 2 === 0; break;
                case 1: $inv = $y % 2 === 0; break;
                case 2: $inv = $x % 3 === 0; break;
                case 3: $inv = ($x + $y) % 3 === 0; break;
                case 4: $inv = (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0; break;
                case 5: $inv = $x * $y % 2 + $x * $y % 3 === 0; break;
                case 6: $inv = ($x * $y % 2 + $x * $y % 3) % 2 === 0; break;
                default: $inv = (($x + $y) % 2 + $x * $y % 3) % 2 === 0;
            }
            if ($inv) $mat[$y][$x] = !$mat[$y][$x];
        }
        return $mat;
    };
    $penalidade = function (array $mat) use ($tam): int {
        $p = 0; $escuros = 0;
        $linhas = [];
        for ($y = 0; $y < $tam; $y++) { $s = ''; for ($x = 0; $x < $tam; $x++) { $s .= $mat[$y][$x] ? '1' : '0'; if ($mat[$y][$x]) $escuros++; } $linhas[] = $s; }
        $colunas = [];
        for ($x = 0; $x < $tam; $x++) { $s = ''; for ($y = 0; $y < $tam; $y++) $s .= $mat[$y][$x] ? '1' : '0'; $colunas[] = $s; }
        foreach (array_merge($linhas, $colunas) as $s) {
            if (preg_match_all('/0{5,}|1{5,}/', $s, $mm)) foreach ($mm[0] as $run) $p += 3 + strlen($run) - 5;
            $pad = '0000' . $s . '0000';
            $p += 40 * (substr_count($pad, '00001011101') + substr_count($pad, '10111010000'));
        }
        for ($y = 0; $y < $tam - 1; $y++) for ($x = 0; $x < $tam - 1; $x++) {
            $c = $mat[$y][$x];
            if ($c === $mat[$y][$x + 1] && $c === $mat[$y + 1][$x] && $c === $mat[$y + 1][$x + 1]) $p += 3;
        }
        $total = $tam * $tam;
        $k = (int)ceil(abs($escuros * 20 - $total * 10) / $total) - 1;
        return $p + max(0, $k) * 10;
    };
    $melhor = null; $melhorP = PHP_INT_MAX;
    for ($k = 0; $k < 8; $k++) {
        $formato($k);
        $cand = $mascara($m, $k);
        // o formato foi gravado em $m pelo $set: copia a área de formato para o candidato
        $pp = $penalidade($cand);
        if ($pp < $melhorP) { $melhorP = $pp; $melhor = $k; }
    }
    $formato($melhor);
    return $mascara($m, $melhor);
}

/* =============================================================================================
 * PDF mínimo — A4 retrato, medidas em milímetros a partir do canto superior esquerdo.
 * ============================================================================================= */
function ws_pdf_larguras(bool $negrito): array {
    static $cache = [];
    if (isset($cache[$negrito])) return $cache[$negrito];
    $n = [' '=>278,'!'=>278,'"'=>355,'#'=>556,'$'=>556,'%'=>889,'&'=>667,"'"=>191,'('=>333,')'=>333,'*'=>389,'+'=>584,','=>278,'-'=>333,'.'=>278,'/'=>278,
          ':'=>278,';'=>278,'<'=>584,'='=>584,'>'=>584,'?'=>556,'@'=>1015,'A'=>667,'B'=>667,'C'=>722,'D'=>722,'E'=>667,'F'=>611,'G'=>778,'H'=>722,'I'=>278,
          'J'=>500,'K'=>667,'L'=>556,'M'=>833,'N'=>722,'O'=>778,'P'=>667,'Q'=>778,'R'=>722,'S'=>667,'T'=>611,'U'=>722,'V'=>667,'W'=>944,'X'=>667,'Y'=>667,
          'Z'=>611,'['=>278,'\\'=>278,']'=>278,'^'=>469,'_'=>556,'`'=>333,'a'=>556,'b'=>556,'c'=>500,'d'=>556,'e'=>556,'f'=>278,'g'=>556,'h'=>556,'i'=>222,
          'j'=>222,'k'=>500,'l'=>222,'m'=>833,'n'=>556,'o'=>556,'p'=>556,'q'=>556,'r'=>333,'s'=>500,'t'=>278,'u'=>556,'v'=>500,'w'=>722,'x'=>500,'y'=>500,
          'z'=>500,'{'=>334,'|'=>260,'}'=>334,'~'=>584];
    $b = [' '=>278,'!'=>333,'"'=>474,'#'=>556,'$'=>556,'%'=>889,'&'=>722,"'"=>238,'('=>333,')'=>333,'*'=>389,'+'=>584,','=>278,'-'=>333,'.'=>278,'/'=>278,
          ':'=>333,';'=>333,'<'=>584,'='=>584,'>'=>584,'?'=>611,'@'=>975,'A'=>722,'B'=>722,'C'=>722,'D'=>722,'E'=>667,'F'=>611,'G'=>778,'H'=>722,'I'=>278,
          'J'=>556,'K'=>722,'L'=>611,'M'=>833,'N'=>722,'O'=>778,'P'=>667,'Q'=>778,'R'=>722,'S'=>667,'T'=>611,'U'=>722,'V'=>667,'W'=>944,'X'=>667,'Y'=>667,
          'Z'=>611,'['=>333,'\\'=>278,']'=>333,'^'=>584,'_'=>556,'`'=>333,'a'=>556,'b'=>611,'c'=>556,'d'=>611,'e'=>556,'f'=>333,'g'=>611,'h'=>611,'i'=>278,
          'j'=>278,'k'=>556,'l'=>278,'m'=>889,'n'=>611,'o'=>611,'p'=>611,'q'=>611,'r'=>389,'s'=>556,'t'=>333,'u'=>611,'v'=>556,'w'=>778,'x'=>556,'y'=>556,
          'z'=>500,'{'=>389,'|'=>280,'}'=>389,'~'=>584];
    $t = $negrito ? $b : $n;
    for ($d = 0; $d <= 9; $d++) $t[(string)$d] = 556;
    return $cache[$negrito] = $t;
}
/** UTF-8 → WinAnsi (o que a Helvetica padrão do PDF entende). Emoji e o que não existir somem. */
function ws_pdf_ansi(string $s): string {
    $s = preg_replace('/[\x{1F000}-\x{1FFFF}\x{2600}-\x{27BF}\x{FE0F}\x{200D}]/u', '', $s);
    $r = @iconv('UTF-8', 'CP1252//TRANSLIT//IGNORE', $s);
    return $r === false ? preg_replace('/[^\x20-\x7E]/', '?', $s) : $r;
}

class WsPdf {
    public float $W = 210.0; public float $H = 297.0;
    private array $paginas = []; private string $atual = '';
    private array $imagens = []; private string $fonte = 'F1'; private float $tam = 10; private bool $negrito = false;
    private const K = 72 / 25.4;

    public function pagina(): void { if ($this->atual !== '' || $this->paginas) $this->paginas[] = $this->atual; $this->atual = ''; }
    private function n(float $v): string { return rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.') ?: '0'; }
    private function px(float $mm): string { return $this->n($mm * self::K); }
    private function py(float $mm): string { return $this->n(($this->H - $mm) * self::K); }

    public function fonte(float $tam, bool $negrito = false): void { $this->tam = $tam; $this->negrito = $negrito; $this->fonte = $negrito ? 'F2' : 'F1'; }
    public function cor(int $r, int $g, int $b): void { $this->atual .= sprintf("%.3F %.3F %.3F rg %.3F %.3F %.3F RG\n", $r / 255, $g / 255, $b / 255, $r / 255, $g / 255, $b / 255); }
    public function largura(string $txt): float {
        $w = ws_pdf_larguras($this->negrito); $s = ws_pdf_ansi($txt); $t = 0;
        for ($i = 0, $n = strlen($s); $i < $n; $i++) { $c = $s[$i]; $t += $w[$c] ?? (ord($c) >= 192 ? 556 : 500); }
        return $t * $this->tam / 1000 / self::K;
    }
    /** Texto com a LINHA DE BASE em y (mm). $alinh: L, R ou C em relação a x. */
    public function texto(float $x, float $y, string $txt, string $alinh = 'L'): void {
        if ($alinh === 'R') $x -= $this->largura($txt); elseif ($alinh === 'C') $x -= $this->largura($txt) / 2;
        $s = strtr(ws_pdf_ansi($txt), ['\\' => '\\\\', '(' => '\\(', ')' => '\\)', "\r" => '', "\n" => ' ']);
        $this->atual .= "BT /{$this->fonte} " . $this->n($this->tam) . " Tf " . $this->px($x) . ' ' . $this->py($y) . " Td ($s) Tj ET\n";
    }
    /** Quebra o texto na largura dada; devolve as linhas. */
    public function quebrar(string $txt, float $larg): array {
        $out = [];
        foreach (preg_split("/\r\n|\n|\r/", $txt) as $par) {
            $linha = '';
            foreach (preg_split('/(\s+)/', $par, -1, PREG_SPLIT_NO_EMPTY) as $pal) {
                $tent = $linha === '' ? $pal : "$linha $pal";
                if ($this->largura($tent) <= $larg) { $linha = $tent; continue; }
                if ($linha !== '') $out[] = $linha;
                // palavra maior que a linha (ex.: PIX copia e cola): corta por caractere
                while ($this->largura($pal) > $larg) {
                    $k = 1; while ($k < mb_strlen($pal) && $this->largura(mb_substr($pal, 0, $k + 1)) <= $larg) $k++;
                    $out[] = mb_substr($pal, 0, $k); $pal = mb_substr($pal, $k);
                }
                $linha = $pal;
            }
            $out[] = $linha;
        }
        return $out;
    }
    /** Parágrafo: escreve as linhas a partir de y (linha de base) e devolve o y seguinte. */
    public function paragrafo(float $x, float $y, string $txt, float $larg, float $entre, int $maxLinhas = 0): float {
        $ls = $this->quebrar($txt, $larg);
        if ($maxLinhas > 0 && count($ls) > $maxLinhas) { $ls = array_slice($ls, 0, $maxLinhas); }
        foreach ($ls as $l) { $this->texto($x, $y, $l); $y += $entre; }
        return $y;
    }
    public function retangulo(float $x, float $y, float $w, float $h, bool $preencher = false, float $linha = 0.2): void {
        $this->atual .= $this->n($linha * self::K) . " w " . $this->px($x) . ' ' . $this->py($y + $h) . ' ' . $this->px($w) . ' ' . $this->px($h) . ($preencher ? " re f\n" : " re S\n");
    }
    public function linha(float $x1, float $y1, float $x2, float $y2, float $esp = 0.2, bool $tracejada = false): void {
        $this->atual .= ($tracejada ? "[2 1.5] 0 d " : '') . $this->n($esp * self::K) . " w " . $this->px($x1) . ' ' . $this->py($y1) . ' m ' . $this->px($x2) . ' ' . $this->py($y2) . " l S" . ($tracejada ? " [] 0 d" : '') . "\n";
    }
    public function qr(float $x, float $y, float $lado, array $mat): void {
        $n = count($mat); $q = 4; $mod = $lado / ($n + 2 * $q);
        $this->atual .= "0 0 0 rg\n";
        for ($r = 0; $r < $n; $r++) {
            $c = 0;
            while ($c < $n) {
                if (!$mat[$r][$c]) { $c++; continue; }
                $ini = $c; while ($c < $n && $mat[$r][$c]) $c++;
                // um retângulo por trecho escuro da linha (arquivo menor, sem fresta entre módulos)
                $this->atual .= $this->px($x + ($q + $ini) * $mod) . ' ' . $this->py($y + ($q + $r + 1) * $mod) . ' ' . $this->px(($c - $ini) * $mod) . ' ' . $this->px($mod * 1.0) . " re\n";
            }
        }
        $this->atual .= "f\n";
    }
    /** Código de barras Intercalado 2 de 5 (padrão dos boletos brasileiros). */
    public function barras_i25(float $x, float $y, float $altura, string $digitos, float $fina = 0.254): void {
        $pad = ['00110','10001','01001','11000','00101','10100','01100','00011','10010','01010'];
        if (strlen($digitos) % 2) $digitos = '0' . $digitos;
        $grossa = $fina * 3;
        $seq = [[0, 0], [0, 1], [0, 0], [0, 1]];   // início: fina barra, fina espaço, fina barra, fina espaço
        for ($i = 0; $i < strlen($digitos); $i += 2) {
            $b = $pad[(int)$digitos[$i]]; $e = $pad[(int)$digitos[$i + 1]];
            for ($k = 0; $k < 5; $k++) { $seq[] = [(int)$b[$k], 0]; $seq[] = [(int)$e[$k], 1]; }
        }
        $seq[] = [1, 0]; $seq[] = [0, 1]; $seq[] = [0, 0];   // fim: grossa barra, fina espaço, fina barra
        $this->atual .= "0 0 0 rg\n";
        foreach ($seq as [$larga, $espaco]) {
            $w = $larga ? $grossa : $fina;
            if (!$espaco) $this->atual .= $this->px($x) . ' ' . $this->py($y + $altura) . ' ' . $this->px($w) . ' ' . $this->px($altura) . " re\n";
            $x += $w;
        }
        $this->atual .= "f\n";
    }
    /** Imagem JPEG (bytes). PNG é convertido com GD quando existir; sem GD, a imagem é ignorada. */
    public function imagem(string $bytes, float $x, float $y, float $w, float $h): void {
        if (substr($bytes, 0, 3) !== "\xFF\xD8\xFF") {
            if (!function_exists('imagecreatefromstring')) return;
            $im = @imagecreatefromstring($bytes); if (!$im) return;
            $fundo = imagecreatetruecolor(imagesx($im), imagesy($im));
            imagefill($fundo, 0, 0, imagecolorallocate($fundo, 255, 255, 255));
            imagecopy($fundo, $im, 0, 0, 0, 0, imagesx($im), imagesy($im));
            ob_start(); imagejpeg($fundo, null, 90); $bytes = (string)ob_get_clean();
        }
        $inf = @getimagesizefromstring($bytes); if (!$inf) return;
        $id = 'I' . (count($this->imagens) + 1);
        $this->imagens[$id] = ['dados' => $bytes, 'w' => $inf[0], 'h' => $inf[1], 'canais' => $inf['channels'] ?? 3];
        $this->atual .= "q " . $this->px($w) . " 0 0 " . $this->px($h) . ' ' . $this->px($x) . ' ' . $this->py($y + $h) . " cm /$id Do Q\n";
    }
    public function saida(): string {
        $paginas = $this->paginas; $paginas[] = $this->atual;
        $objs = []; $n = 0;
        $novo = function () use (&$n) { return ++$n; };
        $catalogo = $novo(); $pagesId = $novo(); $f1 = $novo(); $f2 = $novo();
        $objs[$f1] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
        $objs[$f2] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
        $imgIds = [];
        foreach ($this->imagens as $nome => $im) {
            $id = $novo(); $imgIds[$nome] = $id;
            $cs = $im['canais'] == 1 ? '/DeviceGray' : ($im['canais'] == 4 ? '/DeviceCMYK' : '/DeviceRGB');
            $objs[$id] = "<< /Type /XObject /Subtype /Image /Width {$im['w']} /Height {$im['h']} /ColorSpace $cs /BitsPerComponent 8 /Filter /DCTDecode /Length " . strlen($im['dados']) . " >>\nstream\n" . $im['dados'] . "\nendstream";
        }
        $xobj = ''; foreach ($imgIds as $nome => $id) $xobj .= "/$nome $id 0 R ";
        $recursos = "<< /Font << /F1 $f1 0 R /F2 $f2 0 R >>" . ($xobj !== '' ? " /XObject << $xobj>>" : '') . " >>";
        $kids = [];
        foreach ($paginas as $conteudo) {
            $cid = $novo(); $pid = $novo(); $kids[] = "$pid 0 R";
            if (function_exists('gzcompress')) {
                $z = gzcompress($conteudo);
                $objs[$cid] = "<< /Filter /FlateDecode /Length " . strlen($z) . " >>\nstream\n$z\nendstream";
            } else {
                $objs[$cid] = "<< /Length " . strlen($conteudo) . " >>\nstream\n$conteudo\nendstream";
            }
            $objs[$pid] = "<< /Type /Page /Parent $pagesId 0 R /MediaBox [0 0 595.28 841.89] /Resources $recursos /Contents $cid 0 R >>";
        }
        $objs[$catalogo] = "<< /Type /Catalog /Pages $pagesId 0 R >>";
        $objs[$pagesId] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count " . count($kids) . " >>";
        ksort($objs);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"; $offs = [];
        foreach ($objs as $id => $corpo) { $offs[$id] = strlen($pdf); $pdf .= "$id 0 obj\n$corpo\nendobj\n"; }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . ($n + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $n; $i++) $pdf .= sprintf("%010d 00000 n \n", $offs[$i]);
        $pdf .= "trailer\n<< /Size " . ($n + 1) . " /Root $catalogo 0 R >>\nstartxref\n$xref\n%%EOF";
        return $pdf;
    }
}

/* =============================================================================================
 * BOLETO / CARNÊ
 * ============================================================================================= */
/** Linha digitável (47 dígitos, boleto bancário) → código de barras (44). Outros formatos: ''. */
function ws_pdf_linha_para_barras(string $linha): string {
    $d = preg_replace('/\D/', '', $linha);
    if (strlen($d) === 47) return substr($d, 0, 4) . substr($d, 32, 1) . substr($d, 33, 14) . substr($d, 4, 5) . substr($d, 10, 10) . substr($d, 21, 10);
    if (strlen($d) === 48 && $d[0] === '8') return substr($d, 0, 11) . substr($d, 12, 11) . substr($d, 24, 11) . substr($d, 36, 11);
    return strlen($d) === 44 ? $d : '';
}

/** Dados de cada fatura para o PDF (mesma origem do boleto.php: cadastro, banco do contrato, PIX). */
function ws_pdf_dados(PDO $db, array $ids): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    if (!$ids) return [];
    $prov = is_file(WS_CACHE . '/provedor.json') ? (json_decode((string)@file_get_contents(WS_CACHE . '/provedor.json'), true) ?: []) : [];
    $provNome = ($prov['razao'] ?? '') ?: ($prov['fantasia'] ?? 'PROVEDOR');
    $bancos = [];
    try { foreach ($db->query("SELECT * FROM ws_banco WHERE ativo=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $b) $bancos[(int)$b['id']] = $b; } catch (Throwable $e) {}
    $bancoPad = null; foreach ($bancos as $b) if (trim((string)($b['pix'] ?? '')) !== '') { $bancoPad = $b; break; }
    if (is_file(__DIR__ . '/schema_endereco.php')) { require_once __DIR__ . '/schema_endereco.php'; }
    $camposEnd = function_exists('ws_end_sql_campos') ? (", " . ws_end_sql_campos()) : ", c.logradouro, c.bairro, c.cidade, c.uf, c.cep";
    $joinEnd = function_exists('ws_end_sql_join') ? ws_end_sql_join('c') : '';
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $db->prepare("SELECT f.*, c.nome, c.cpf_cnpj, c.numero" . $camposEnd . ", ct.login_pppoe, ct.banco_id, p.nome plano
                        FROM ws_fatura f JOIN ws_cliente c ON c.id=f.cliente_id
                        LEFT JOIN ws_contrato ct ON ct.id=f.contrato_id LEFT JOIN ws_plano p ON p.id=ct.plano_id" . $joinEnd . "
                        WHERE f.id IN ($in) ORDER BY f.vencimento, f.id");
    $st->execute($ids);
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
        if (!function_exists("ws_fatura_cobranca_sanear") && is_file(__DIR__ . "/celcash.php")) require_once __DIR__ . "/celcash.php";
        if (function_exists('ws_fatura_cobranca_sanear')) ws_fatura_cobranca_sanear($db, $f);   // PDF nunca sai com linha/PIX de cobrança de outro cliente
        $f['taxa_emissao'] = ws_fatura_taxa_efetiva($f);   // taxa do cadastro do provedor entra como acréscimo (título sem taxa gravada)
        $bk = (!empty($f['banco_id']) && isset($bancos[(int)$f['banco_id']]) && trim((string)$bancos[(int)$f['banco_id']]['pix']) !== '') ? $bancos[(int)$f['banco_id']] : $bancoPad;
        $chave = $bk ? ws_pix_chave((string)$bk['pix'], (string)($bk['tipo_chave'] ?? '')) : '';
        $txid = ws_pix_txid_nome($f['nome'] ?? '', $f['id']);
        $f['_emv'] = $chave !== '' ? ws_pix_emv($chave, $provNome, (string)($prov['cidade'] ?? ''), ws_fatura_valor_cobrado($f), $txid) : '';
        // Título da Lytex: o PIX é o DA COBRANÇA (baixa automática) — PIX de chave própria aqui pagaria fora da Lytex.
        if (!empty($f['lytex_id']) && trim((string)($f['pix_emv'] ?? '')) !== '') { $f['_emv'] = trim((string)$f['pix_emv']); $chave = ''; }
        $f['_chave'] = $chave; $f['_txid'] = $txid;
        $f['_multa'] = (float)($bk['multa_pct'] ?? 2); $f['_juros'] = (float)($bk['juros_pct'] ?? 1);
        $f['_exibir_mes'] = (int)($bk['exibir_mes_ref'] ?? 1); $f['_max_recalc'] = (int)($bk['max_dias_recalc'] ?? 0);
        $out[] = $f;
    }
    return ['prov' => $prov, 'provNome' => $provNome, 'faturas' => $out];
}

/* Logo do PDF (mensagens automáticas, anexos do WhatsApp) — MESMA ordem do boleto.php (24/09/2026):
 * 1º a LOGO DO BOLETO (Financeiro → Modelos de boleto/carnê, uploads/sistema/doc-logo.*);
 * só sem ela, a logo da Marca do sistema. Antes olhava a Marca primeiro — como a Marca sempre tem
 * alguma logo, o PDF saía com a logo da PÁGINA e não a do boleto. */
function ws_pdf_logo(): string {
    $la = glob(WS_UP_SISTEMA . '/doc-logo.*')[0] ?? null;
    if ($la) return (string)@file_get_contents($la);
    $rel = function_exists('ws_brand_logo_arquivo') ? ws_brand_logo_arquivo() : '';
    if ($rel === '') return '';
    $fis = function_exists('ws_caminho_fisico') ? ws_caminho_fisico($rel) : (__DIR__ . '/' . $rel);
    return is_file($fis) ? (string)@file_get_contents($fis) : '';
}

/** Gera o PDF. $modo: 'boleto' (1 página por fatura) ou 'carne' (3 fichas por página). */
function ws_pdf_faturas(PDO $db, array $ids, string $modo = 'boleto'): ?array {
    if (is_file(__DIR__ . '/branding.php')) require_once __DIR__ . '/branding.php';
    $d = ws_pdf_dados($db, $ids);
    if (empty($d['faturas'])) return null;
    $prov = $d['prov']; $provNome = $d['provNome']; $logo = ws_pdf_logo();
    $pdf = new WsPdf();
    $dinheiro = fn($v) => 'R$ ' . number_format((float)$v, 2, ',', '.');
    $data = fn($v) => $v ? date('d/m/Y', strtotime((string)$v)) : '-';
    $vinho = [158, 42, 59];
    $docCli = function ($v) { $d = preg_replace('/\D/', '', (string)$v);
        if (strlen($d) === 11) return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $d);
        if (strlen($d) === 14) return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $d);
        return trim((string)$v) !== '' ? trim((string)$v) : '-'; };
    $n = count($d['faturas']);

    if ($modo === 'carne') {
        foreach ($d['faturas'] as $i => $f) {
            if ($i % 3 === 0) $pdf->pagina();
            $y0 = 8 + ($i % 3) * 94; $x0 = 8;
            // canhoto
            $pdf->cor(0, 0, 0); $pdf->retangulo($x0, $y0, 194, 88);
            $pdf->linha($x0 + 52, $y0, $x0 + 52, $y0 + 88, 0.2, true);
            $pdf->fonte(8.5, true); $pdf->cor(...$vinho);
            $pdf->paragrafo($x0 + 3, $y0 + 6, $provNome, 46, 3.6, 2);
            $pdf->cor(0, 0, 0);
            $lin = [['Parcela', ($i + 1) . '/' . $n], ['Fatura nº', (string)$f['id']], ['Vencimento', $data($f['vencimento'])], ['Valor', $dinheiro(ws_fatura_valor_cobrado($f))]];
            if (!empty($f['_exibir_mes'])) $lin[] = ['Mês referente', ws_mes_ref_fmt($f['competencia'] ?? '')];
            $yy = $y0 + 16;
            foreach ($lin as [$r, $v]) { $pdf->fonte(6.5); $pdf->texto($x0 + 3, $yy, $r); $pdf->fonte(9, true); $pdf->texto($x0 + 3, $yy + 4, $v); $yy += 10; }
            $pdf->fonte(6.5); $pdf->texto($x0 + 3, $yy, 'Cliente');
            $pdf->fonte(7.5, true); $pdf->paragrafo($x0 + 3, $yy + 3.6, (string)$f['nome'], 46, 3.3, 3);
            $pdf->fonte(6); $pdf->texto($x0 + 3, $y0 + 85, 'Via do cliente');
            // ficha
            $xr = $x0 + 56;
            if ($logo !== '') $pdf->imagem($logo, $xr, $y0 + 3, 28, 10);
            $pdf->fonte(10, true); $pdf->cor(...$vinho); $pdf->texto($xr + ($logo !== '' ? 31 : 0), $y0 + 7.5, mb_substr($provNome, 0, 48));
            $pdf->cor(0, 0, 0); $pdf->fonte(7);
            $pdf->texto($xr + ($logo !== '' ? 31 : 0), $y0 + 11.5, trim('CNPJ ' . ($prov['cnpj'] ?? '') . ((($prov['telefone'] ?? '') !== '') ? '   WhatsApp ' . $prov['telefone'] : '')));
            $pdf->fonte(7); $pdf->texto($x0 + 191, $y0 + 6, 'Vencimento', 'R');
            $pdf->fonte(12, true); $pdf->texto($x0 + 191, $y0 + 11.5, $data($f['vencimento']), 'R');
            $pdf->linha($xr, $y0 + 14.5, $x0 + 191, $y0 + 14.5);
            $pdf->fonte(7); $pdf->texto($xr, $y0 + 19, 'Pagador');
            $pdf->fonte(8.5, true); $pdf->texto($xr, $y0 + 23, mb_substr((string)$f['nome'], 0, 60));
            $pdf->fonte(7.5); $pdf->texto($xr, $y0 + 27, 'CPF/CNPJ ' . $docCli($f['cpf_cnpj']) . '    Fatura nº ' . $f['id'] . '    Parcela ' . ($i + 1) . '/' . $n);
            $pdf->fonte(7); $pdf->texto($x0 + 191, $y0 + 19, 'Valor a pagar', 'R');
            $pdf->fonte(13, true); $pdf->cor(...$vinho); $pdf->texto($x0 + 191, $y0 + 25, $dinheiro(ws_fatura_valor_cobrado($f)), 'R'); $pdf->cor(0, 0, 0);
            if ((float)($f['taxa_emissao'] ?? 0) > 0) {
                $pdf->fonte(5.3); $pdf->cor(90, 90, 90);
                $pdf->texto($x0 + 191, $y0 + 28.3, 'inclui taxa ' . $dinheiro($f['taxa_emissao']), 'R');
                $pdf->cor(0, 0, 0);
            }
            $yq = $y0 + 31;
            if ($f['_emv'] !== '' && ($m = ws_qr_matriz($f['_emv']))) {
                $pdf->qr($xr - 1, $yq - 1, 36, $m);
                $pdf->fonte(8, true); $pdf->texto($xr + 37, $yq + 3, 'Pague com PIX: leia o QR Code ou use o copia e cola');
                $pdf->fonte(6.2); $pdf->paragrafo($xr + 37, $yq + 7, $f['_emv'], 96, 2.7, 6);
                $pdf->fonte(6.5); $pdf->texto($xr + 37, $yq + 25, 'Chave PIX: ' . $f['_chave']);
            } else {
                $pdf->fonte(8); $pdf->texto($xr, $yq + 5, 'Chave PIX não cadastrada (Provedor -> Bancos).');
            }
            $linhaDig = trim((string)($f['linha_digitavel'] ?? ''));
            $barras = ws_pdf_linha_para_barras($linhaDig);
            if ($linhaDig !== '' && $barras !== '') {
                $pdf->fonte(8, true); $pdf->texto($xr + 37, $yq + 31, $linhaDig);
                $pdf->barras_i25($xr + 37, $yq + 33, 11, $barras, 0.23);
            } else {
                $pdf->fonte(6.3);
                $pdf->paragrafo($xr + 37, $yq + 31, 'Após o vencimento: multa de ' . number_format($f['_multa'], 2, ',', '.') . '% e juros de ' . number_format($f['_juros'], 2, ',', '.') . '% ao mês. Após vencido, sujeito à suspensão dos serviços conforme contrato.', 96, 2.8, 4);
            }
            if ($i % 3 !== 2 && $i < $n - 1) $pdf->linha(4, $y0 + 91, 206, $y0 + 91, 0.2, true);
        }
        $nome = 'carne-' . preg_replace('/[^A-Za-z0-9]/', '', (string)($d['faturas'][0]['_txid'] ?? 'cliente')) . '.pdf';
        return ['pdf' => $pdf->saida(), 'nome' => $nome];
    }

    foreach ($d['faturas'] as $f) {
        $pdf->pagina();
        $x = 14; $w = 182; $y = 14;
        // Cabeçalho
        $xt = $x;
        if ($logo !== '') { $pdf->imagem($logo, $x, $y, 42, 15); $xt = $x + 46; }
        $pdf->fonte(14, true); $pdf->cor(...$vinho); $pdf->texto($xt, $y + 5, mb_substr($provNome, 0, 45));
        $pdf->cor(60, 60, 60); $pdf->fonte(8);
        $ender = trim(($prov['endereco'] ?? '') . ' ' . ($prov['numero'] ?? '')) . ((($prov['bairro'] ?? '') !== '') ? ' - ' . $prov['bairro'] : '') . ((($prov['cidade'] ?? '') !== '') ? ' - ' . $prov['cidade'] . '/' . ($prov['uf'] ?? '') : '');
        $yy = $y + 9.5;
        if (($prov['cnpj'] ?? '') !== '') { $pdf->texto($xt, $yy, 'CNPJ: ' . $prov['cnpj']); $yy += 3.8; }
        if (trim($ender, ' -/') !== '') { $pdf->texto($xt, $yy, $ender); $yy += 3.8; }
        $zap = trim((($prov['telefone'] ?? '') !== '' ? 'WhatsApp ' . $prov['telefone'] : '') . ((($prov['whatsapp'] ?? '') !== '') ? '   ' . $prov['whatsapp'] : ''));
        if ($zap !== '') $pdf->texto($xt, $yy, $zap);
        $pdf->cor(0, 0, 0);
        $pdf->fonte(8); $pdf->texto($x + $w, $y + 3, 'Fatura', 'R');
        $pdf->fonte(13, true); $pdf->texto($x + $w, $y + 8.5, '#' . $f['id'], 'R');
        $pdf->fonte(8); $pdf->texto($x + $w, $y + 13.5, 'Vencimento', 'R');
        $pdf->fonte(12, true); $pdf->texto($x + $w, $y + 19, $data($f['vencimento']), 'R');
        $y += 25; $pdf->cor(...$vinho); $pdf->retangulo($x, $y, $w, 0.8, true); $pdf->cor(0, 0, 0);

        // Pagador
        $y += 8; $pdf->fonte(9, true); $pdf->texto($x, $y, 'PAGADOR');
        $y += 2; $pdf->retangulo($x, $y, $w, 30);
        $pdf->fonte(10.5, true); $pdf->texto($x + 3, $y + 6, mb_substr((string)$f['nome'], 0, 70));
        $pdf->fonte(8.5);
        $pdf->texto($x + 3, $y + 11.5, 'CPF/CNPJ: ' . $docCli($f['cpf_cnpj']));
        $endCli = trim(($f['logradouro'] ?? '') . ' ' . ($f['numero'] ?? ''));
        $pdf->texto($x + 3, $y + 16.5, 'Endereço: ' . mb_substr($endCli !== '' ? $endCli : '-', 0, 90));
        $pdf->texto($x + 3, $y + 21.5, 'Bairro: ' . ($f['bairro'] ?? '-') . '   Cidade: ' . ($f['cidade'] ?? '-') . (($f['uf'] ?? '') !== '' ? '/' . $f['uf'] : ''));
        $pdf->texto($x + 3, $y + 26.5, ltrim((!empty($f['_exibir_mes']) ? 'Mês referente: ' . ws_mes_ref_fmt($f['competencia'] ?? '-') : '') . (($f['plano'] ?? '') !== '' ? '   Plano: ' . $f['plano'] : '') . (($f['login_pppoe'] ?? '') !== '' ? '   Login: ' . $f['login_pppoe'] : '')));

        // Valor (caixa mais alta quando há taxa de emissão, pra caber a linha do detalhamento sem sobrepor nada)
        $temTaxa = (float)($f['taxa_emissao'] ?? 0) > 0;
        $altValor = $temTaxa ? 23 : 18;
        $y += 36; $pdf->cor(248, 240, 242); $pdf->retangulo($x, $y, $w, $altValor, true); $pdf->cor(0, 0, 0);
        $pdf->fonte(9); $pdf->texto($x + 4, $y + 7, 'Vencimento');
        $pdf->fonte(12, true); $pdf->texto($x + 4, $y + 13.5, $data($f['vencimento']));
        $status = $f['status'] === 'pago' ? 'PAGO' : ((strtotime((string)$f['vencimento']) < strtotime(date('Y-m-d'))) ? 'VENCIDO' : 'EM ABERTO');
        $pdf->fonte(9); $pdf->texto($x + 70, $y + 7, 'Situação');
        $pdf->fonte(11, true); $pdf->texto($x + 70, $y + 13.5, $status);
        $pdf->fonte(9); $pdf->texto($x + $w - 4, $y + 7, 'Valor a pagar', 'R');
        $pdf->fonte(17, true); $pdf->cor(...$vinho); $pdf->texto($x + $w - 4, $y + 14.5, $dinheiro(ws_fatura_valor_cobrado($f)), 'R'); $pdf->cor(0, 0, 0);
        if ($temTaxa) {
            $pdf->fonte(7); $pdf->cor(90, 90, 90);
            $pdf->texto($x + $w - 4, $y + 19.5, 'Plano ' . $dinheiro($f['valor']) . '  +  Taxa de emissão ' . $dinheiro($f['taxa_emissao']), 'R');
            $pdf->cor(0, 0, 0);
        }

        // PIX
        $y += 26 + ($altValor - 18); $pdf->fonte(9, true); $pdf->texto($x, $y, 'PAGUE COM PIX');
        $y += 2; $pdf->retangulo($x, $y, $w, 66);
        if ($f['_emv'] !== '' && ($m = ws_qr_matriz($f['_emv']))) {
            $pdf->qr($x + 2, $y + 2, 62, $m);
            $pdf->fonte(9.5, true); $pdf->texto($x + 68, $y + 8, 'Abra o app do seu banco e leia o QR Code');
            $pdf->fonte(8.5); $pdf->texto($x + 68, $y + 13, 'ou copie o código PIX abaixo (PIX copia e cola):');
            $pdf->fonte(7.5); $yy = $pdf->paragrafo($x + 68, $y + 19, $f['_emv'], $w - 72, 3.3, 9);
            $pdf->fonte(8.5); $pdf->texto($x + 68, $yy + 3, 'Chave PIX: ' . $f['_chave']);
            $pdf->texto($x + 68, $yy + 8, 'Identificador: ' . $f['_txid']);
        } else {
            $pdf->fonte(10); $pdf->texto($x + 4, $y + 10, 'Chave PIX não cadastrada (Provedor -> Bancos).');
        }

        // Linha digitável e código de barras (só boleto real, emitido por gateway/banco)
        $y += 72;
        $linhaDig = trim((string)($f['linha_digitavel'] ?? ''));
        $barras = ws_pdf_linha_para_barras($linhaDig);
        if ($linhaDig !== '' && $barras !== '') {
            $pdf->fonte(9, true); $pdf->texto($x, $y, 'BOLETO BANCÁRIO');
            $pdf->fonte(11, true); $pdf->texto($x, $y + 6, $linhaDig);
            $pdf->barras_i25($x, $y + 9, 13, $barras);
            $y += 28;
        }

        // Instruções
        $pdf->fonte(9, true); $pdf->texto($x, $y, 'INSTRUÇÕES');
        $pdf->fonte(8.5);
        $instr = "Após o vencimento: multa de " . number_format($f['_multa'], 2, ',', '.') . "% e juros de " . number_format($f['_juros'], 2, ',', '.') . "% ao mês.\n"
               . "Após vencido, sujeito à suspensão dos serviços conforme contrato.\n"
               . "O pagamento pelo PIX é identificado pelo nome do cliente.";
        if (($f['_max_recalc'] ?? 0) > 0) $instr .= "\n2ª via recalculada (multa + juros) por até " . (int)$f['_max_recalc'] . " dia(s) após o vencimento; depois disso o título é cancelado.";
        if (!empty($f['obs'])) $instr .= "\nObservação: " . $f['obs'];
        $pdf->paragrafo($x, $y + 5, $instr, $w, 4.2, 8);

        $pdf->fonte(7); $pdf->cor(120, 120, 120);
        $pdf->texto($x + $w / 2, 287, 'Documento gerado por Wellsystem ERP em ' . date('d/m/Y H:i'), 'C');
        $pdf->cor(0, 0, 0);
    }
    $nome = ($n > 1 ? 'boletos-' : 'boleto-') . preg_replace('/[^A-Za-z0-9]/', '', (string)($d['faturas'][0]['_txid'] ?? 'cliente')) . '.pdf';
    return ['pdf' => $pdf->saida(), 'nome' => $nome];
}
